<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-02-26 10:32:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-26 10:32:26 --> Config Class Initialized
INFO - 2022-02-26 10:32:26 --> Hooks Class Initialized
DEBUG - 2022-02-26 10:32:26 --> UTF-8 Support Enabled
INFO - 2022-02-26 10:32:26 --> Utf8 Class Initialized
INFO - 2022-02-26 10:32:26 --> URI Class Initialized
DEBUG - 2022-02-26 10:32:26 --> No URI present. Default controller set.
INFO - 2022-02-26 10:32:26 --> Router Class Initialized
INFO - 2022-02-26 10:32:26 --> Output Class Initialized
INFO - 2022-02-26 10:32:26 --> Security Class Initialized
DEBUG - 2022-02-26 10:32:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-26 10:32:26 --> Input Class Initialized
INFO - 2022-02-26 10:32:26 --> Language Class Initialized
INFO - 2022-02-26 10:32:26 --> Loader Class Initialized
INFO - 2022-02-26 10:32:26 --> Helper loaded: url_helper
INFO - 2022-02-26 10:32:26 --> Helper loaded: form_helper
INFO - 2022-02-26 10:32:26 --> Helper loaded: common_helper
INFO - 2022-02-26 10:32:26 --> Database Driver Class Initialized
DEBUG - 2022-02-26 10:32:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-26 10:32:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-26 10:32:26 --> Controller Class Initialized
INFO - 2022-02-26 10:32:26 --> Form Validation Class Initialized
DEBUG - 2022-02-26 10:32:26 --> Encrypt Class Initialized
DEBUG - 2022-02-26 10:32:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-26 10:32:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-26 10:32:26 --> Email Class Initialized
INFO - 2022-02-26 10:32:26 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-26 10:32:26 --> Calendar Class Initialized
INFO - 2022-02-26 10:32:26 --> Model "Login_model" initialized
INFO - 2022-02-26 10:32:26 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-26 10:32:26 --> Final output sent to browser
DEBUG - 2022-02-26 10:32:26 --> Total execution time: 0.0249
ERROR - 2022-02-26 10:32:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-26 10:32:47 --> Config Class Initialized
INFO - 2022-02-26 10:32:47 --> Hooks Class Initialized
DEBUG - 2022-02-26 10:32:47 --> UTF-8 Support Enabled
INFO - 2022-02-26 10:32:47 --> Utf8 Class Initialized
INFO - 2022-02-26 10:32:47 --> URI Class Initialized
DEBUG - 2022-02-26 10:32:47 --> No URI present. Default controller set.
INFO - 2022-02-26 10:32:47 --> Router Class Initialized
INFO - 2022-02-26 10:32:47 --> Output Class Initialized
INFO - 2022-02-26 10:32:47 --> Security Class Initialized
DEBUG - 2022-02-26 10:32:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-26 10:32:47 --> Input Class Initialized
INFO - 2022-02-26 10:32:47 --> Language Class Initialized
INFO - 2022-02-26 10:32:47 --> Loader Class Initialized
INFO - 2022-02-26 10:32:47 --> Helper loaded: url_helper
INFO - 2022-02-26 10:32:47 --> Helper loaded: form_helper
INFO - 2022-02-26 10:32:47 --> Helper loaded: common_helper
INFO - 2022-02-26 10:32:47 --> Database Driver Class Initialized
DEBUG - 2022-02-26 10:32:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-26 10:32:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-26 10:32:47 --> Controller Class Initialized
INFO - 2022-02-26 10:32:47 --> Form Validation Class Initialized
DEBUG - 2022-02-26 10:32:47 --> Encrypt Class Initialized
DEBUG - 2022-02-26 10:32:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-26 10:32:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-26 10:32:47 --> Email Class Initialized
INFO - 2022-02-26 10:32:47 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-26 10:32:47 --> Calendar Class Initialized
INFO - 2022-02-26 10:32:47 --> Model "Login_model" initialized
INFO - 2022-02-26 10:32:47 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-26 10:32:47 --> Final output sent to browser
DEBUG - 2022-02-26 10:32:47 --> Total execution time: 0.0207
ERROR - 2022-02-26 11:01:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-26 11:01:30 --> Config Class Initialized
INFO - 2022-02-26 11:01:30 --> Hooks Class Initialized
DEBUG - 2022-02-26 11:01:30 --> UTF-8 Support Enabled
INFO - 2022-02-26 11:01:30 --> Utf8 Class Initialized
INFO - 2022-02-26 11:01:30 --> URI Class Initialized
DEBUG - 2022-02-26 11:01:30 --> No URI present. Default controller set.
INFO - 2022-02-26 11:01:30 --> Router Class Initialized
INFO - 2022-02-26 11:01:30 --> Output Class Initialized
INFO - 2022-02-26 11:01:30 --> Security Class Initialized
DEBUG - 2022-02-26 11:01:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-26 11:01:30 --> Input Class Initialized
INFO - 2022-02-26 11:01:30 --> Language Class Initialized
INFO - 2022-02-26 11:01:30 --> Loader Class Initialized
INFO - 2022-02-26 11:01:30 --> Helper loaded: url_helper
INFO - 2022-02-26 11:01:30 --> Helper loaded: form_helper
INFO - 2022-02-26 11:01:30 --> Helper loaded: common_helper
INFO - 2022-02-26 11:01:30 --> Database Driver Class Initialized
DEBUG - 2022-02-26 11:01:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-26 11:01:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-26 11:01:30 --> Controller Class Initialized
INFO - 2022-02-26 11:01:30 --> Form Validation Class Initialized
DEBUG - 2022-02-26 11:01:30 --> Encrypt Class Initialized
DEBUG - 2022-02-26 11:01:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-26 11:01:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-26 11:01:30 --> Email Class Initialized
INFO - 2022-02-26 11:01:30 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-26 11:01:30 --> Calendar Class Initialized
INFO - 2022-02-26 11:01:30 --> Model "Login_model" initialized
INFO - 2022-02-26 11:01:30 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-26 11:01:30 --> Final output sent to browser
DEBUG - 2022-02-26 11:01:30 --> Total execution time: 0.0323
ERROR - 2022-02-26 11:07:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-26 11:07:25 --> Config Class Initialized
INFO - 2022-02-26 11:07:25 --> Hooks Class Initialized
DEBUG - 2022-02-26 11:07:25 --> UTF-8 Support Enabled
INFO - 2022-02-26 11:07:25 --> Utf8 Class Initialized
INFO - 2022-02-26 11:07:25 --> URI Class Initialized
DEBUG - 2022-02-26 11:07:25 --> No URI present. Default controller set.
INFO - 2022-02-26 11:07:25 --> Router Class Initialized
INFO - 2022-02-26 11:07:25 --> Output Class Initialized
INFO - 2022-02-26 11:07:25 --> Security Class Initialized
DEBUG - 2022-02-26 11:07:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-26 11:07:25 --> Input Class Initialized
INFO - 2022-02-26 11:07:25 --> Language Class Initialized
INFO - 2022-02-26 11:07:25 --> Loader Class Initialized
INFO - 2022-02-26 11:07:25 --> Helper loaded: url_helper
INFO - 2022-02-26 11:07:25 --> Helper loaded: form_helper
INFO - 2022-02-26 11:07:25 --> Helper loaded: common_helper
INFO - 2022-02-26 11:07:25 --> Database Driver Class Initialized
DEBUG - 2022-02-26 11:07:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-26 11:07:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-26 11:07:25 --> Controller Class Initialized
INFO - 2022-02-26 11:07:25 --> Form Validation Class Initialized
DEBUG - 2022-02-26 11:07:25 --> Encrypt Class Initialized
DEBUG - 2022-02-26 11:07:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-26 11:07:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-26 11:07:25 --> Email Class Initialized
INFO - 2022-02-26 11:07:25 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-26 11:07:25 --> Calendar Class Initialized
INFO - 2022-02-26 11:07:25 --> Model "Login_model" initialized
INFO - 2022-02-26 11:07:25 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-26 11:07:25 --> Final output sent to browser
DEBUG - 2022-02-26 11:07:25 --> Total execution time: 0.0370
ERROR - 2022-02-26 11:13:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-26 11:13:00 --> Config Class Initialized
INFO - 2022-02-26 11:13:00 --> Hooks Class Initialized
DEBUG - 2022-02-26 11:13:00 --> UTF-8 Support Enabled
INFO - 2022-02-26 11:13:00 --> Utf8 Class Initialized
INFO - 2022-02-26 11:13:00 --> URI Class Initialized
DEBUG - 2022-02-26 11:13:00 --> No URI present. Default controller set.
INFO - 2022-02-26 11:13:00 --> Router Class Initialized
INFO - 2022-02-26 11:13:00 --> Output Class Initialized
INFO - 2022-02-26 11:13:00 --> Security Class Initialized
DEBUG - 2022-02-26 11:13:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-26 11:13:00 --> Input Class Initialized
INFO - 2022-02-26 11:13:00 --> Language Class Initialized
INFO - 2022-02-26 11:13:00 --> Loader Class Initialized
INFO - 2022-02-26 11:13:00 --> Helper loaded: url_helper
INFO - 2022-02-26 11:13:00 --> Helper loaded: form_helper
INFO - 2022-02-26 11:13:00 --> Helper loaded: common_helper
INFO - 2022-02-26 11:13:00 --> Database Driver Class Initialized
DEBUG - 2022-02-26 11:13:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-26 11:13:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-26 11:13:00 --> Controller Class Initialized
INFO - 2022-02-26 11:13:00 --> Form Validation Class Initialized
DEBUG - 2022-02-26 11:13:00 --> Encrypt Class Initialized
DEBUG - 2022-02-26 11:13:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-26 11:13:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-26 11:13:00 --> Email Class Initialized
INFO - 2022-02-26 11:13:00 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-26 11:13:00 --> Calendar Class Initialized
INFO - 2022-02-26 11:13:00 --> Model "Login_model" initialized
INFO - 2022-02-26 11:13:00 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-26 11:13:00 --> Final output sent to browser
DEBUG - 2022-02-26 11:13:00 --> Total execution time: 0.1616
ERROR - 2022-02-26 14:19:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-26 14:19:33 --> Config Class Initialized
INFO - 2022-02-26 14:19:33 --> Hooks Class Initialized
DEBUG - 2022-02-26 14:19:33 --> UTF-8 Support Enabled
INFO - 2022-02-26 14:19:33 --> Utf8 Class Initialized
INFO - 2022-02-26 14:19:33 --> URI Class Initialized
DEBUG - 2022-02-26 14:19:33 --> No URI present. Default controller set.
INFO - 2022-02-26 14:19:33 --> Router Class Initialized
INFO - 2022-02-26 14:19:33 --> Output Class Initialized
INFO - 2022-02-26 14:19:33 --> Security Class Initialized
DEBUG - 2022-02-26 14:19:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-26 14:19:33 --> Input Class Initialized
INFO - 2022-02-26 14:19:33 --> Language Class Initialized
INFO - 2022-02-26 14:19:33 --> Loader Class Initialized
INFO - 2022-02-26 14:19:33 --> Helper loaded: url_helper
INFO - 2022-02-26 14:19:33 --> Helper loaded: form_helper
INFO - 2022-02-26 14:19:33 --> Helper loaded: common_helper
INFO - 2022-02-26 14:19:33 --> Database Driver Class Initialized
DEBUG - 2022-02-26 14:19:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-26 14:19:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-26 14:19:33 --> Controller Class Initialized
INFO - 2022-02-26 14:19:33 --> Form Validation Class Initialized
DEBUG - 2022-02-26 14:19:33 --> Encrypt Class Initialized
DEBUG - 2022-02-26 14:19:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-26 14:19:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-26 14:19:33 --> Email Class Initialized
INFO - 2022-02-26 14:19:33 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-26 14:19:33 --> Calendar Class Initialized
INFO - 2022-02-26 14:19:33 --> Model "Login_model" initialized
INFO - 2022-02-26 14:19:33 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-26 14:19:33 --> Final output sent to browser
DEBUG - 2022-02-26 14:19:33 --> Total execution time: 0.0244
ERROR - 2022-02-26 14:19:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-26 14:19:34 --> Config Class Initialized
INFO - 2022-02-26 14:19:34 --> Hooks Class Initialized
DEBUG - 2022-02-26 14:19:34 --> UTF-8 Support Enabled
INFO - 2022-02-26 14:19:34 --> Utf8 Class Initialized
INFO - 2022-02-26 14:19:34 --> URI Class Initialized
INFO - 2022-02-26 14:19:34 --> Router Class Initialized
INFO - 2022-02-26 14:19:34 --> Output Class Initialized
INFO - 2022-02-26 14:19:34 --> Security Class Initialized
DEBUG - 2022-02-26 14:19:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-26 14:19:34 --> Input Class Initialized
INFO - 2022-02-26 14:19:34 --> Language Class Initialized
ERROR - 2022-02-26 14:19:34 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2022-02-26 14:19:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-26 14:19:58 --> Config Class Initialized
INFO - 2022-02-26 14:19:58 --> Hooks Class Initialized
DEBUG - 2022-02-26 14:19:58 --> UTF-8 Support Enabled
INFO - 2022-02-26 14:19:58 --> Utf8 Class Initialized
INFO - 2022-02-26 14:19:58 --> URI Class Initialized
INFO - 2022-02-26 14:19:58 --> Router Class Initialized
INFO - 2022-02-26 14:19:58 --> Output Class Initialized
INFO - 2022-02-26 14:19:58 --> Security Class Initialized
DEBUG - 2022-02-26 14:19:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-26 14:19:58 --> Input Class Initialized
INFO - 2022-02-26 14:19:58 --> Language Class Initialized
INFO - 2022-02-26 14:19:58 --> Loader Class Initialized
INFO - 2022-02-26 14:19:58 --> Helper loaded: url_helper
INFO - 2022-02-26 14:19:58 --> Helper loaded: form_helper
INFO - 2022-02-26 14:19:58 --> Helper loaded: common_helper
INFO - 2022-02-26 14:19:58 --> Database Driver Class Initialized
DEBUG - 2022-02-26 14:19:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-26 14:19:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-26 14:19:58 --> Controller Class Initialized
INFO - 2022-02-26 14:19:58 --> Form Validation Class Initialized
DEBUG - 2022-02-26 14:19:58 --> Encrypt Class Initialized
DEBUG - 2022-02-26 14:19:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-26 14:19:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-26 14:19:58 --> Email Class Initialized
INFO - 2022-02-26 14:19:58 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-26 14:19:58 --> Calendar Class Initialized
INFO - 2022-02-26 14:19:58 --> Model "Login_model" initialized
INFO - 2022-02-26 14:19:58 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-26 14:19:58 --> Final output sent to browser
DEBUG - 2022-02-26 14:19:58 --> Total execution time: 0.0212
ERROR - 2022-02-26 14:19:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-26 14:19:58 --> Config Class Initialized
INFO - 2022-02-26 14:19:58 --> Hooks Class Initialized
DEBUG - 2022-02-26 14:19:58 --> UTF-8 Support Enabled
INFO - 2022-02-26 14:19:58 --> Utf8 Class Initialized
INFO - 2022-02-26 14:19:58 --> URI Class Initialized
DEBUG - 2022-02-26 14:19:58 --> No URI present. Default controller set.
INFO - 2022-02-26 14:19:58 --> Router Class Initialized
INFO - 2022-02-26 14:19:58 --> Output Class Initialized
INFO - 2022-02-26 14:19:58 --> Security Class Initialized
DEBUG - 2022-02-26 14:19:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-26 14:19:58 --> Input Class Initialized
INFO - 2022-02-26 14:19:58 --> Language Class Initialized
INFO - 2022-02-26 14:19:58 --> Loader Class Initialized
INFO - 2022-02-26 14:19:58 --> Helper loaded: url_helper
INFO - 2022-02-26 14:19:58 --> Helper loaded: form_helper
INFO - 2022-02-26 14:19:58 --> Helper loaded: common_helper
INFO - 2022-02-26 14:19:58 --> Database Driver Class Initialized
DEBUG - 2022-02-26 14:19:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-26 14:19:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-26 14:19:58 --> Controller Class Initialized
INFO - 2022-02-26 14:19:58 --> Form Validation Class Initialized
DEBUG - 2022-02-26 14:19:58 --> Encrypt Class Initialized
DEBUG - 2022-02-26 14:19:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-26 14:19:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-26 14:19:58 --> Email Class Initialized
INFO - 2022-02-26 14:19:58 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-26 14:19:58 --> Calendar Class Initialized
INFO - 2022-02-26 14:19:58 --> Model "Login_model" initialized
INFO - 2022-02-26 14:19:58 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-26 14:19:58 --> Final output sent to browser
DEBUG - 2022-02-26 14:19:58 --> Total execution time: 0.0238
ERROR - 2022-02-26 14:19:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-26 14:19:59 --> Config Class Initialized
INFO - 2022-02-26 14:19:59 --> Hooks Class Initialized
DEBUG - 2022-02-26 14:19:59 --> UTF-8 Support Enabled
INFO - 2022-02-26 14:19:59 --> Utf8 Class Initialized
INFO - 2022-02-26 14:19:59 --> URI Class Initialized
INFO - 2022-02-26 14:19:59 --> Router Class Initialized
INFO - 2022-02-26 14:19:59 --> Output Class Initialized
INFO - 2022-02-26 14:19:59 --> Security Class Initialized
DEBUG - 2022-02-26 14:19:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-26 14:19:59 --> Input Class Initialized
INFO - 2022-02-26 14:19:59 --> Language Class Initialized
INFO - 2022-02-26 14:19:59 --> Loader Class Initialized
INFO - 2022-02-26 14:19:59 --> Helper loaded: url_helper
INFO - 2022-02-26 14:19:59 --> Helper loaded: form_helper
INFO - 2022-02-26 14:19:59 --> Helper loaded: common_helper
INFO - 2022-02-26 14:19:59 --> Database Driver Class Initialized
DEBUG - 2022-02-26 14:19:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-26 14:19:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-26 14:19:59 --> Controller Class Initialized
INFO - 2022-02-26 14:19:59 --> Form Validation Class Initialized
DEBUG - 2022-02-26 14:19:59 --> Encrypt Class Initialized
DEBUG - 2022-02-26 14:19:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-26 14:19:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-26 14:19:59 --> Email Class Initialized
INFO - 2022-02-26 14:19:59 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-26 14:19:59 --> Calendar Class Initialized
INFO - 2022-02-26 14:19:59 --> Model "Login_model" initialized
ERROR - 2022-02-26 14:19:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-26 14:19:59 --> Config Class Initialized
INFO - 2022-02-26 14:19:59 --> Hooks Class Initialized
DEBUG - 2022-02-26 14:19:59 --> UTF-8 Support Enabled
INFO - 2022-02-26 14:19:59 --> Utf8 Class Initialized
INFO - 2022-02-26 14:19:59 --> URI Class Initialized
INFO - 2022-02-26 14:19:59 --> Router Class Initialized
INFO - 2022-02-26 14:19:59 --> Output Class Initialized
INFO - 2022-02-26 14:19:59 --> Security Class Initialized
DEBUG - 2022-02-26 14:19:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-26 14:19:59 --> Input Class Initialized
INFO - 2022-02-26 14:19:59 --> Language Class Initialized
INFO - 2022-02-26 14:19:59 --> Loader Class Initialized
INFO - 2022-02-26 14:19:59 --> Helper loaded: url_helper
INFO - 2022-02-26 14:19:59 --> Helper loaded: form_helper
INFO - 2022-02-26 14:19:59 --> Helper loaded: common_helper
INFO - 2022-02-26 14:19:59 --> Database Driver Class Initialized
DEBUG - 2022-02-26 14:19:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-26 14:19:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-26 14:19:59 --> Controller Class Initialized
INFO - 2022-02-26 14:19:59 --> Form Validation Class Initialized
DEBUG - 2022-02-26 14:19:59 --> Encrypt Class Initialized
DEBUG - 2022-02-26 14:19:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-26 14:19:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-26 14:19:59 --> Email Class Initialized
INFO - 2022-02-26 14:19:59 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-26 14:19:59 --> Calendar Class Initialized
INFO - 2022-02-26 14:19:59 --> Model "Login_model" initialized
ERROR - 2022-02-26 20:21:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-26 20:21:07 --> Config Class Initialized
INFO - 2022-02-26 20:21:07 --> Hooks Class Initialized
DEBUG - 2022-02-26 20:21:07 --> UTF-8 Support Enabled
INFO - 2022-02-26 20:21:07 --> Utf8 Class Initialized
INFO - 2022-02-26 20:21:07 --> URI Class Initialized
DEBUG - 2022-02-26 20:21:07 --> No URI present. Default controller set.
INFO - 2022-02-26 20:21:07 --> Router Class Initialized
INFO - 2022-02-26 20:21:07 --> Output Class Initialized
INFO - 2022-02-26 20:21:07 --> Security Class Initialized
DEBUG - 2022-02-26 20:21:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-26 20:21:07 --> Input Class Initialized
INFO - 2022-02-26 20:21:07 --> Language Class Initialized
INFO - 2022-02-26 20:21:07 --> Loader Class Initialized
INFO - 2022-02-26 20:21:07 --> Helper loaded: url_helper
INFO - 2022-02-26 20:21:07 --> Helper loaded: form_helper
INFO - 2022-02-26 20:21:07 --> Helper loaded: common_helper
INFO - 2022-02-26 20:21:07 --> Database Driver Class Initialized
DEBUG - 2022-02-26 20:21:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-26 20:21:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-26 20:21:07 --> Controller Class Initialized
INFO - 2022-02-26 20:21:07 --> Form Validation Class Initialized
DEBUG - 2022-02-26 20:21:07 --> Encrypt Class Initialized
DEBUG - 2022-02-26 20:21:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-26 20:21:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-26 20:21:07 --> Email Class Initialized
INFO - 2022-02-26 20:21:07 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-26 20:21:07 --> Calendar Class Initialized
INFO - 2022-02-26 20:21:07 --> Model "Login_model" initialized
INFO - 2022-02-26 20:21:07 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-26 20:21:07 --> Final output sent to browser
DEBUG - 2022-02-26 20:21:07 --> Total execution time: 0.0316
ERROR - 2022-02-26 20:21:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-26 20:21:07 --> Config Class Initialized
INFO - 2022-02-26 20:21:07 --> Hooks Class Initialized
DEBUG - 2022-02-26 20:21:07 --> UTF-8 Support Enabled
INFO - 2022-02-26 20:21:07 --> Utf8 Class Initialized
INFO - 2022-02-26 20:21:07 --> URI Class Initialized
INFO - 2022-02-26 20:21:07 --> Router Class Initialized
INFO - 2022-02-26 20:21:07 --> Output Class Initialized
INFO - 2022-02-26 20:21:07 --> Security Class Initialized
DEBUG - 2022-02-26 20:21:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-26 20:21:07 --> Input Class Initialized
INFO - 2022-02-26 20:21:07 --> Language Class Initialized
ERROR - 2022-02-26 20:21:07 --> 404 Page Not Found: Register/index
ERROR - 2022-02-26 20:21:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-26 20:21:11 --> Config Class Initialized
INFO - 2022-02-26 20:21:11 --> Hooks Class Initialized
DEBUG - 2022-02-26 20:21:11 --> UTF-8 Support Enabled
INFO - 2022-02-26 20:21:11 --> Utf8 Class Initialized
INFO - 2022-02-26 20:21:11 --> URI Class Initialized
INFO - 2022-02-26 20:21:11 --> Router Class Initialized
INFO - 2022-02-26 20:21:11 --> Output Class Initialized
INFO - 2022-02-26 20:21:11 --> Security Class Initialized
DEBUG - 2022-02-26 20:21:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-26 20:21:11 --> Input Class Initialized
INFO - 2022-02-26 20:21:11 --> Language Class Initialized
INFO - 2022-02-26 20:21:11 --> Loader Class Initialized
INFO - 2022-02-26 20:21:11 --> Helper loaded: url_helper
INFO - 2022-02-26 20:21:11 --> Helper loaded: form_helper
INFO - 2022-02-26 20:21:11 --> Helper loaded: common_helper
INFO - 2022-02-26 20:21:11 --> Database Driver Class Initialized
DEBUG - 2022-02-26 20:21:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-26 20:21:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-26 20:21:11 --> Controller Class Initialized
INFO - 2022-02-26 20:21:11 --> Form Validation Class Initialized
DEBUG - 2022-02-26 20:21:11 --> Encrypt Class Initialized
DEBUG - 2022-02-26 20:21:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-26 20:21:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-26 20:21:11 --> Email Class Initialized
INFO - 2022-02-26 20:21:11 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-26 20:21:11 --> Calendar Class Initialized
INFO - 2022-02-26 20:21:11 --> Model "Login_model" initialized
INFO - 2022-02-26 20:21:11 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-26 20:21:11 --> Final output sent to browser
DEBUG - 2022-02-26 20:21:11 --> Total execution time: 0.0325
ERROR - 2022-02-26 20:21:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-26 20:21:12 --> Config Class Initialized
INFO - 2022-02-26 20:21:12 --> Hooks Class Initialized
DEBUG - 2022-02-26 20:21:12 --> UTF-8 Support Enabled
INFO - 2022-02-26 20:21:12 --> Utf8 Class Initialized
INFO - 2022-02-26 20:21:12 --> URI Class Initialized
DEBUG - 2022-02-26 20:21:12 --> No URI present. Default controller set.
INFO - 2022-02-26 20:21:12 --> Router Class Initialized
INFO - 2022-02-26 20:21:12 --> Output Class Initialized
INFO - 2022-02-26 20:21:12 --> Security Class Initialized
DEBUG - 2022-02-26 20:21:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-26 20:21:12 --> Input Class Initialized
INFO - 2022-02-26 20:21:12 --> Language Class Initialized
INFO - 2022-02-26 20:21:12 --> Loader Class Initialized
INFO - 2022-02-26 20:21:12 --> Helper loaded: url_helper
INFO - 2022-02-26 20:21:12 --> Helper loaded: form_helper
INFO - 2022-02-26 20:21:12 --> Helper loaded: common_helper
INFO - 2022-02-26 20:21:12 --> Database Driver Class Initialized
DEBUG - 2022-02-26 20:21:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-26 20:21:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-26 20:21:12 --> Controller Class Initialized
INFO - 2022-02-26 20:21:12 --> Form Validation Class Initialized
DEBUG - 2022-02-26 20:21:12 --> Encrypt Class Initialized
DEBUG - 2022-02-26 20:21:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-26 20:21:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-26 20:21:12 --> Email Class Initialized
INFO - 2022-02-26 20:21:12 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-26 20:21:12 --> Calendar Class Initialized
INFO - 2022-02-26 20:21:12 --> Model "Login_model" initialized
INFO - 2022-02-26 20:21:12 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-26 20:21:12 --> Final output sent to browser
DEBUG - 2022-02-26 20:21:12 --> Total execution time: 0.0329
ERROR - 2022-02-26 20:21:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-26 20:21:15 --> Config Class Initialized
INFO - 2022-02-26 20:21:15 --> Hooks Class Initialized
DEBUG - 2022-02-26 20:21:15 --> UTF-8 Support Enabled
INFO - 2022-02-26 20:21:15 --> Utf8 Class Initialized
INFO - 2022-02-26 20:21:15 --> URI Class Initialized
INFO - 2022-02-26 20:21:15 --> Router Class Initialized
INFO - 2022-02-26 20:21:15 --> Output Class Initialized
INFO - 2022-02-26 20:21:15 --> Security Class Initialized
DEBUG - 2022-02-26 20:21:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-26 20:21:15 --> Input Class Initialized
INFO - 2022-02-26 20:21:15 --> Language Class Initialized
INFO - 2022-02-26 20:21:15 --> Loader Class Initialized
INFO - 2022-02-26 20:21:15 --> Helper loaded: url_helper
INFO - 2022-02-26 20:21:15 --> Helper loaded: form_helper
INFO - 2022-02-26 20:21:15 --> Helper loaded: common_helper
INFO - 2022-02-26 20:21:15 --> Database Driver Class Initialized
DEBUG - 2022-02-26 20:21:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-26 20:21:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-26 20:21:15 --> Controller Class Initialized
INFO - 2022-02-26 20:21:15 --> Form Validation Class Initialized
DEBUG - 2022-02-26 20:21:15 --> Encrypt Class Initialized
DEBUG - 2022-02-26 20:21:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-26 20:21:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-26 20:21:15 --> Email Class Initialized
INFO - 2022-02-26 20:21:15 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-26 20:21:15 --> Calendar Class Initialized
INFO - 2022-02-26 20:21:15 --> Model "Login_model" initialized
ERROR - 2022-02-26 20:21:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-26 20:21:18 --> Config Class Initialized
INFO - 2022-02-26 20:21:18 --> Hooks Class Initialized
DEBUG - 2022-02-26 20:21:18 --> UTF-8 Support Enabled
INFO - 2022-02-26 20:21:18 --> Utf8 Class Initialized
INFO - 2022-02-26 20:21:18 --> URI Class Initialized
INFO - 2022-02-26 20:21:18 --> Router Class Initialized
INFO - 2022-02-26 20:21:18 --> Output Class Initialized
INFO - 2022-02-26 20:21:18 --> Security Class Initialized
DEBUG - 2022-02-26 20:21:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-26 20:21:18 --> Input Class Initialized
INFO - 2022-02-26 20:21:18 --> Language Class Initialized
INFO - 2022-02-26 20:21:18 --> Loader Class Initialized
INFO - 2022-02-26 20:21:18 --> Helper loaded: url_helper
INFO - 2022-02-26 20:21:18 --> Helper loaded: form_helper
INFO - 2022-02-26 20:21:18 --> Helper loaded: common_helper
INFO - 2022-02-26 20:21:18 --> Database Driver Class Initialized
DEBUG - 2022-02-26 20:21:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-26 20:21:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-26 20:21:18 --> Controller Class Initialized
INFO - 2022-02-26 20:21:18 --> Form Validation Class Initialized
DEBUG - 2022-02-26 20:21:18 --> Encrypt Class Initialized
DEBUG - 2022-02-26 20:21:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-26 20:21:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-26 20:21:18 --> Email Class Initialized
INFO - 2022-02-26 20:21:18 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-26 20:21:18 --> Calendar Class Initialized
INFO - 2022-02-26 20:21:18 --> Model "Login_model" initialized
INFO - 2022-02-26 20:21:18 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-26 20:21:18 --> Final output sent to browser
DEBUG - 2022-02-26 20:21:18 --> Total execution time: 0.0226
ERROR - 2022-02-26 20:49:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-26 20:49:31 --> Config Class Initialized
INFO - 2022-02-26 20:49:31 --> Hooks Class Initialized
DEBUG - 2022-02-26 20:49:31 --> UTF-8 Support Enabled
INFO - 2022-02-26 20:49:31 --> Utf8 Class Initialized
INFO - 2022-02-26 20:49:31 --> URI Class Initialized
DEBUG - 2022-02-26 20:49:31 --> No URI present. Default controller set.
INFO - 2022-02-26 20:49:31 --> Router Class Initialized
INFO - 2022-02-26 20:49:31 --> Output Class Initialized
INFO - 2022-02-26 20:49:31 --> Security Class Initialized
DEBUG - 2022-02-26 20:49:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-26 20:49:31 --> Input Class Initialized
INFO - 2022-02-26 20:49:31 --> Language Class Initialized
INFO - 2022-02-26 20:49:31 --> Loader Class Initialized
INFO - 2022-02-26 20:49:31 --> Helper loaded: url_helper
INFO - 2022-02-26 20:49:31 --> Helper loaded: form_helper
INFO - 2022-02-26 20:49:31 --> Helper loaded: common_helper
INFO - 2022-02-26 20:49:31 --> Database Driver Class Initialized
DEBUG - 2022-02-26 20:49:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-26 20:49:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-26 20:49:31 --> Controller Class Initialized
INFO - 2022-02-26 20:49:31 --> Form Validation Class Initialized
DEBUG - 2022-02-26 20:49:31 --> Encrypt Class Initialized
DEBUG - 2022-02-26 20:49:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-26 20:49:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-26 20:49:31 --> Email Class Initialized
INFO - 2022-02-26 20:49:31 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-26 20:49:31 --> Calendar Class Initialized
INFO - 2022-02-26 20:49:31 --> Model "Login_model" initialized
INFO - 2022-02-26 20:49:31 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-26 20:49:31 --> Final output sent to browser
DEBUG - 2022-02-26 20:49:31 --> Total execution time: 0.0345
ERROR - 2022-02-26 21:06:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-26 21:06:50 --> Config Class Initialized
INFO - 2022-02-26 21:06:50 --> Hooks Class Initialized
DEBUG - 2022-02-26 21:06:50 --> UTF-8 Support Enabled
INFO - 2022-02-26 21:06:50 --> Utf8 Class Initialized
INFO - 2022-02-26 21:06:50 --> URI Class Initialized
DEBUG - 2022-02-26 21:06:50 --> No URI present. Default controller set.
INFO - 2022-02-26 21:06:50 --> Router Class Initialized
INFO - 2022-02-26 21:06:50 --> Output Class Initialized
INFO - 2022-02-26 21:06:50 --> Security Class Initialized
DEBUG - 2022-02-26 21:06:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-26 21:06:50 --> Input Class Initialized
INFO - 2022-02-26 21:06:50 --> Language Class Initialized
INFO - 2022-02-26 21:06:51 --> Loader Class Initialized
INFO - 2022-02-26 21:06:51 --> Helper loaded: url_helper
INFO - 2022-02-26 21:06:51 --> Helper loaded: form_helper
INFO - 2022-02-26 21:06:51 --> Helper loaded: common_helper
INFO - 2022-02-26 21:06:51 --> Database Driver Class Initialized
DEBUG - 2022-02-26 21:06:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-26 21:06:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-26 21:06:51 --> Controller Class Initialized
INFO - 2022-02-26 21:06:51 --> Form Validation Class Initialized
DEBUG - 2022-02-26 21:06:51 --> Encrypt Class Initialized
DEBUG - 2022-02-26 21:06:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-26 21:06:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-26 21:06:51 --> Email Class Initialized
INFO - 2022-02-26 21:06:51 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-26 21:06:51 --> Calendar Class Initialized
INFO - 2022-02-26 21:06:51 --> Model "Login_model" initialized
INFO - 2022-02-26 21:06:51 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-26 21:06:51 --> Final output sent to browser
DEBUG - 2022-02-26 21:06:51 --> Total execution time: 0.0417
ERROR - 2022-02-26 21:32:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-26 21:32:42 --> Config Class Initialized
INFO - 2022-02-26 21:32:42 --> Hooks Class Initialized
DEBUG - 2022-02-26 21:32:42 --> UTF-8 Support Enabled
INFO - 2022-02-26 21:32:42 --> Utf8 Class Initialized
INFO - 2022-02-26 21:32:42 --> URI Class Initialized
INFO - 2022-02-26 21:32:42 --> Router Class Initialized
INFO - 2022-02-26 21:32:42 --> Output Class Initialized
INFO - 2022-02-26 21:32:42 --> Security Class Initialized
DEBUG - 2022-02-26 21:32:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-26 21:32:42 --> Input Class Initialized
INFO - 2022-02-26 21:32:42 --> Language Class Initialized
ERROR - 2022-02-26 21:32:42 --> 404 Page Not Found: Humanstxt/index
ERROR - 2022-02-26 21:32:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-26 21:32:43 --> Config Class Initialized
INFO - 2022-02-26 21:32:43 --> Hooks Class Initialized
DEBUG - 2022-02-26 21:32:43 --> UTF-8 Support Enabled
INFO - 2022-02-26 21:32:43 --> Utf8 Class Initialized
INFO - 2022-02-26 21:32:43 --> URI Class Initialized
INFO - 2022-02-26 21:32:43 --> Router Class Initialized
INFO - 2022-02-26 21:32:43 --> Output Class Initialized
INFO - 2022-02-26 21:32:43 --> Security Class Initialized
DEBUG - 2022-02-26 21:32:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-26 21:32:43 --> Input Class Initialized
INFO - 2022-02-26 21:32:43 --> Language Class Initialized
ERROR - 2022-02-26 21:32:43 --> 404 Page Not Found: Adstxt/index
ERROR - 2022-02-26 21:32:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-26 21:32:44 --> Config Class Initialized
INFO - 2022-02-26 21:32:44 --> Hooks Class Initialized
DEBUG - 2022-02-26 21:32:44 --> UTF-8 Support Enabled
INFO - 2022-02-26 21:32:44 --> Utf8 Class Initialized
INFO - 2022-02-26 21:32:44 --> URI Class Initialized
DEBUG - 2022-02-26 21:32:44 --> No URI present. Default controller set.
INFO - 2022-02-26 21:32:44 --> Router Class Initialized
INFO - 2022-02-26 21:32:44 --> Output Class Initialized
INFO - 2022-02-26 21:32:44 --> Security Class Initialized
DEBUG - 2022-02-26 21:32:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-26 21:32:44 --> Input Class Initialized
INFO - 2022-02-26 21:32:44 --> Language Class Initialized
INFO - 2022-02-26 21:32:44 --> Loader Class Initialized
INFO - 2022-02-26 21:32:44 --> Helper loaded: url_helper
INFO - 2022-02-26 21:32:44 --> Helper loaded: form_helper
INFO - 2022-02-26 21:32:44 --> Helper loaded: common_helper
INFO - 2022-02-26 21:32:44 --> Database Driver Class Initialized
DEBUG - 2022-02-26 21:32:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-26 21:32:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-26 21:32:44 --> Controller Class Initialized
INFO - 2022-02-26 21:32:44 --> Form Validation Class Initialized
DEBUG - 2022-02-26 21:32:44 --> Encrypt Class Initialized
DEBUG - 2022-02-26 21:32:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-26 21:32:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-26 21:32:44 --> Email Class Initialized
INFO - 2022-02-26 21:32:44 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-26 21:32:44 --> Calendar Class Initialized
INFO - 2022-02-26 21:32:44 --> Model "Login_model" initialized
INFO - 2022-02-26 21:32:44 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-26 21:32:44 --> Final output sent to browser
DEBUG - 2022-02-26 21:32:44 --> Total execution time: 0.1442
