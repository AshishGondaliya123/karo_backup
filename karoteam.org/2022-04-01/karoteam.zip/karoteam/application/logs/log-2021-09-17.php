<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-09-17 01:21:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-17 01:21:16 --> Config Class Initialized
INFO - 2021-09-17 01:21:16 --> Hooks Class Initialized
DEBUG - 2021-09-17 01:21:16 --> UTF-8 Support Enabled
INFO - 2021-09-17 01:21:16 --> Utf8 Class Initialized
INFO - 2021-09-17 01:21:16 --> URI Class Initialized
INFO - 2021-09-17 01:21:16 --> Router Class Initialized
INFO - 2021-09-17 01:21:16 --> Output Class Initialized
INFO - 2021-09-17 01:21:16 --> Security Class Initialized
DEBUG - 2021-09-17 01:21:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-17 01:21:16 --> Input Class Initialized
INFO - 2021-09-17 01:21:16 --> Language Class Initialized
INFO - 2021-09-17 01:21:16 --> Loader Class Initialized
INFO - 2021-09-17 01:21:16 --> Helper loaded: url_helper
INFO - 2021-09-17 01:21:16 --> Helper loaded: form_helper
INFO - 2021-09-17 01:21:16 --> Helper loaded: common_helper
INFO - 2021-09-17 01:21:16 --> Database Driver Class Initialized
DEBUG - 2021-09-17 01:21:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-17 01:21:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-17 01:21:16 --> Controller Class Initialized
INFO - 2021-09-17 01:21:16 --> Form Validation Class Initialized
DEBUG - 2021-09-17 01:21:16 --> Encrypt Class Initialized
DEBUG - 2021-09-17 01:21:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-09-17 01:21:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-09-17 01:21:16 --> Email Class Initialized
INFO - 2021-09-17 01:21:16 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-09-17 01:21:16 --> Calendar Class Initialized
INFO - 2021-09-17 01:21:16 --> Model "Login_model" initialized
INFO - 2021-09-17 01:21:16 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-09-17 01:21:16 --> Final output sent to browser
DEBUG - 2021-09-17 01:21:16 --> Total execution time: 0.0439
ERROR - 2021-09-17 12:47:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-17 12:47:22 --> Config Class Initialized
INFO - 2021-09-17 12:47:22 --> Hooks Class Initialized
DEBUG - 2021-09-17 12:47:22 --> UTF-8 Support Enabled
INFO - 2021-09-17 12:47:22 --> Utf8 Class Initialized
INFO - 2021-09-17 12:47:22 --> URI Class Initialized
INFO - 2021-09-17 12:47:22 --> Router Class Initialized
INFO - 2021-09-17 12:47:22 --> Output Class Initialized
INFO - 2021-09-17 12:47:22 --> Security Class Initialized
DEBUG - 2021-09-17 12:47:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-17 12:47:22 --> Input Class Initialized
INFO - 2021-09-17 12:47:22 --> Language Class Initialized
ERROR - 2021-09-17 12:47:22 --> 404 Page Not Found: Wp-content/index
