<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-06-13 01:05:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-13 01:05:52 --> Config Class Initialized
INFO - 2021-06-13 01:05:52 --> Hooks Class Initialized
DEBUG - 2021-06-13 01:05:52 --> UTF-8 Support Enabled
INFO - 2021-06-13 01:05:52 --> Utf8 Class Initialized
INFO - 2021-06-13 01:05:52 --> URI Class Initialized
DEBUG - 2021-06-13 01:05:52 --> No URI present. Default controller set.
INFO - 2021-06-13 01:05:52 --> Router Class Initialized
INFO - 2021-06-13 01:05:52 --> Output Class Initialized
INFO - 2021-06-13 01:05:52 --> Security Class Initialized
DEBUG - 2021-06-13 01:05:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-13 01:05:52 --> Input Class Initialized
INFO - 2021-06-13 01:05:52 --> Language Class Initialized
INFO - 2021-06-13 01:05:52 --> Loader Class Initialized
INFO - 2021-06-13 01:05:52 --> Helper loaded: url_helper
INFO - 2021-06-13 01:05:52 --> Helper loaded: form_helper
INFO - 2021-06-13 01:05:52 --> Helper loaded: common_helper
INFO - 2021-06-13 01:05:52 --> Database Driver Class Initialized
DEBUG - 2021-06-13 01:05:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-13 01:05:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-13 01:05:52 --> Controller Class Initialized
INFO - 2021-06-13 01:05:52 --> Form Validation Class Initialized
DEBUG - 2021-06-13 01:05:52 --> Encrypt Class Initialized
DEBUG - 2021-06-13 01:05:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-06-13 01:05:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-06-13 01:05:52 --> Email Class Initialized
INFO - 2021-06-13 01:05:52 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-06-13 01:05:52 --> Calendar Class Initialized
INFO - 2021-06-13 01:05:52 --> Model "Login_model" initialized
INFO - 2021-06-13 01:05:52 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-06-13 01:05:52 --> Final output sent to browser
DEBUG - 2021-06-13 01:05:52 --> Total execution time: 0.0344
ERROR - 2021-06-13 05:03:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-13 05:03:08 --> Config Class Initialized
INFO - 2021-06-13 05:03:08 --> Hooks Class Initialized
DEBUG - 2021-06-13 05:03:08 --> UTF-8 Support Enabled
INFO - 2021-06-13 05:03:08 --> Utf8 Class Initialized
INFO - 2021-06-13 05:03:08 --> URI Class Initialized
DEBUG - 2021-06-13 05:03:08 --> No URI present. Default controller set.
INFO - 2021-06-13 05:03:08 --> Router Class Initialized
INFO - 2021-06-13 05:03:08 --> Output Class Initialized
INFO - 2021-06-13 05:03:08 --> Security Class Initialized
DEBUG - 2021-06-13 05:03:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-13 05:03:08 --> Input Class Initialized
INFO - 2021-06-13 05:03:08 --> Language Class Initialized
INFO - 2021-06-13 05:03:08 --> Loader Class Initialized
INFO - 2021-06-13 05:03:08 --> Helper loaded: url_helper
INFO - 2021-06-13 05:03:08 --> Helper loaded: form_helper
INFO - 2021-06-13 05:03:08 --> Helper loaded: common_helper
INFO - 2021-06-13 05:03:08 --> Database Driver Class Initialized
DEBUG - 2021-06-13 05:03:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-13 05:03:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-13 05:03:08 --> Controller Class Initialized
INFO - 2021-06-13 05:03:08 --> Form Validation Class Initialized
DEBUG - 2021-06-13 05:03:08 --> Encrypt Class Initialized
DEBUG - 2021-06-13 05:03:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-06-13 05:03:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-06-13 05:03:08 --> Email Class Initialized
INFO - 2021-06-13 05:03:08 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-06-13 05:03:08 --> Calendar Class Initialized
INFO - 2021-06-13 05:03:08 --> Model "Login_model" initialized
INFO - 2021-06-13 05:03:08 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-06-13 05:03:08 --> Final output sent to browser
DEBUG - 2021-06-13 05:03:08 --> Total execution time: 0.0343
ERROR - 2021-06-13 06:09:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-13 06:09:21 --> Config Class Initialized
INFO - 2021-06-13 06:09:21 --> Hooks Class Initialized
DEBUG - 2021-06-13 06:09:21 --> UTF-8 Support Enabled
INFO - 2021-06-13 06:09:21 --> Utf8 Class Initialized
INFO - 2021-06-13 06:09:21 --> URI Class Initialized
DEBUG - 2021-06-13 06:09:21 --> No URI present. Default controller set.
INFO - 2021-06-13 06:09:21 --> Router Class Initialized
INFO - 2021-06-13 06:09:21 --> Output Class Initialized
INFO - 2021-06-13 06:09:21 --> Security Class Initialized
DEBUG - 2021-06-13 06:09:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-13 06:09:21 --> Input Class Initialized
INFO - 2021-06-13 06:09:21 --> Language Class Initialized
INFO - 2021-06-13 06:09:21 --> Loader Class Initialized
INFO - 2021-06-13 06:09:21 --> Helper loaded: url_helper
INFO - 2021-06-13 06:09:21 --> Helper loaded: form_helper
INFO - 2021-06-13 06:09:21 --> Helper loaded: common_helper
INFO - 2021-06-13 06:09:21 --> Database Driver Class Initialized
DEBUG - 2021-06-13 06:09:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-13 06:09:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-13 06:09:21 --> Controller Class Initialized
INFO - 2021-06-13 06:09:21 --> Form Validation Class Initialized
DEBUG - 2021-06-13 06:09:21 --> Encrypt Class Initialized
DEBUG - 2021-06-13 06:09:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-06-13 06:09:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-06-13 06:09:21 --> Email Class Initialized
INFO - 2021-06-13 06:09:21 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-06-13 06:09:21 --> Calendar Class Initialized
INFO - 2021-06-13 06:09:21 --> Model "Login_model" initialized
INFO - 2021-06-13 06:09:21 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-06-13 06:09:21 --> Final output sent to browser
DEBUG - 2021-06-13 06:09:21 --> Total execution time: 0.0327
ERROR - 2021-06-13 07:56:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-13 07:56:28 --> Config Class Initialized
INFO - 2021-06-13 07:56:28 --> Hooks Class Initialized
DEBUG - 2021-06-13 07:56:28 --> UTF-8 Support Enabled
INFO - 2021-06-13 07:56:28 --> Utf8 Class Initialized
INFO - 2021-06-13 07:56:28 --> URI Class Initialized
DEBUG - 2021-06-13 07:56:28 --> No URI present. Default controller set.
INFO - 2021-06-13 07:56:28 --> Router Class Initialized
INFO - 2021-06-13 07:56:28 --> Output Class Initialized
INFO - 2021-06-13 07:56:28 --> Security Class Initialized
DEBUG - 2021-06-13 07:56:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-13 07:56:28 --> Input Class Initialized
INFO - 2021-06-13 07:56:28 --> Language Class Initialized
INFO - 2021-06-13 07:56:28 --> Loader Class Initialized
INFO - 2021-06-13 07:56:28 --> Helper loaded: url_helper
INFO - 2021-06-13 07:56:28 --> Helper loaded: form_helper
INFO - 2021-06-13 07:56:28 --> Helper loaded: common_helper
INFO - 2021-06-13 07:56:28 --> Database Driver Class Initialized
DEBUG - 2021-06-13 07:56:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-13 07:56:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-13 07:56:28 --> Controller Class Initialized
INFO - 2021-06-13 07:56:28 --> Form Validation Class Initialized
DEBUG - 2021-06-13 07:56:28 --> Encrypt Class Initialized
DEBUG - 2021-06-13 07:56:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-06-13 07:56:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-06-13 07:56:28 --> Email Class Initialized
INFO - 2021-06-13 07:56:28 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-06-13 07:56:28 --> Calendar Class Initialized
INFO - 2021-06-13 07:56:28 --> Model "Login_model" initialized
INFO - 2021-06-13 07:56:28 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-06-13 07:56:28 --> Final output sent to browser
DEBUG - 2021-06-13 07:56:28 --> Total execution time: 0.0362
ERROR - 2021-06-13 15:20:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-13 15:20:28 --> Config Class Initialized
INFO - 2021-06-13 15:20:28 --> Hooks Class Initialized
DEBUG - 2021-06-13 15:20:28 --> UTF-8 Support Enabled
INFO - 2021-06-13 15:20:28 --> Utf8 Class Initialized
INFO - 2021-06-13 15:20:28 --> URI Class Initialized
DEBUG - 2021-06-13 15:20:28 --> No URI present. Default controller set.
INFO - 2021-06-13 15:20:28 --> Router Class Initialized
INFO - 2021-06-13 15:20:28 --> Output Class Initialized
INFO - 2021-06-13 15:20:28 --> Security Class Initialized
DEBUG - 2021-06-13 15:20:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-13 15:20:28 --> Input Class Initialized
INFO - 2021-06-13 15:20:28 --> Language Class Initialized
INFO - 2021-06-13 15:20:28 --> Loader Class Initialized
INFO - 2021-06-13 15:20:28 --> Helper loaded: url_helper
INFO - 2021-06-13 15:20:28 --> Helper loaded: form_helper
INFO - 2021-06-13 15:20:28 --> Helper loaded: common_helper
INFO - 2021-06-13 15:20:28 --> Database Driver Class Initialized
DEBUG - 2021-06-13 15:20:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-13 15:20:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-13 15:20:28 --> Controller Class Initialized
INFO - 2021-06-13 15:20:28 --> Form Validation Class Initialized
DEBUG - 2021-06-13 15:20:28 --> Encrypt Class Initialized
DEBUG - 2021-06-13 15:20:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-06-13 15:20:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-06-13 15:20:28 --> Email Class Initialized
INFO - 2021-06-13 15:20:28 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-06-13 15:20:28 --> Calendar Class Initialized
INFO - 2021-06-13 15:20:28 --> Model "Login_model" initialized
INFO - 2021-06-13 15:20:28 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-06-13 15:20:28 --> Final output sent to browser
DEBUG - 2021-06-13 15:20:28 --> Total execution time: 0.0416
