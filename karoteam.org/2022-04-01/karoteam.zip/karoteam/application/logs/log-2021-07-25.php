<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-07-25 04:12:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-25 04:12:19 --> Config Class Initialized
INFO - 2021-07-25 04:12:19 --> Hooks Class Initialized
DEBUG - 2021-07-25 04:12:19 --> UTF-8 Support Enabled
INFO - 2021-07-25 04:12:19 --> Utf8 Class Initialized
INFO - 2021-07-25 04:12:19 --> URI Class Initialized
DEBUG - 2021-07-25 04:12:19 --> No URI present. Default controller set.
INFO - 2021-07-25 04:12:19 --> Router Class Initialized
INFO - 2021-07-25 04:12:19 --> Output Class Initialized
INFO - 2021-07-25 04:12:19 --> Security Class Initialized
DEBUG - 2021-07-25 04:12:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-25 04:12:19 --> Input Class Initialized
INFO - 2021-07-25 04:12:19 --> Language Class Initialized
INFO - 2021-07-25 04:12:19 --> Loader Class Initialized
INFO - 2021-07-25 04:12:19 --> Helper loaded: url_helper
INFO - 2021-07-25 04:12:19 --> Helper loaded: form_helper
INFO - 2021-07-25 04:12:19 --> Helper loaded: common_helper
INFO - 2021-07-25 04:12:19 --> Database Driver Class Initialized
DEBUG - 2021-07-25 04:12:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-25 04:12:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-25 04:12:19 --> Controller Class Initialized
INFO - 2021-07-25 04:12:19 --> Form Validation Class Initialized
DEBUG - 2021-07-25 04:12:19 --> Encrypt Class Initialized
DEBUG - 2021-07-25 04:12:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-07-25 04:12:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-07-25 04:12:19 --> Email Class Initialized
INFO - 2021-07-25 04:12:19 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-07-25 04:12:19 --> Calendar Class Initialized
INFO - 2021-07-25 04:12:19 --> Model "Login_model" initialized
INFO - 2021-07-25 04:12:19 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-07-25 04:12:19 --> Final output sent to browser
DEBUG - 2021-07-25 04:12:19 --> Total execution time: 0.0401
ERROR - 2021-07-25 13:09:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-25 13:09:14 --> Config Class Initialized
INFO - 2021-07-25 13:09:14 --> Hooks Class Initialized
DEBUG - 2021-07-25 13:09:14 --> UTF-8 Support Enabled
INFO - 2021-07-25 13:09:14 --> Utf8 Class Initialized
INFO - 2021-07-25 13:09:14 --> URI Class Initialized
DEBUG - 2021-07-25 13:09:14 --> No URI present. Default controller set.
INFO - 2021-07-25 13:09:14 --> Router Class Initialized
INFO - 2021-07-25 13:09:14 --> Output Class Initialized
INFO - 2021-07-25 13:09:14 --> Security Class Initialized
DEBUG - 2021-07-25 13:09:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-25 13:09:14 --> Input Class Initialized
INFO - 2021-07-25 13:09:14 --> Language Class Initialized
INFO - 2021-07-25 13:09:14 --> Loader Class Initialized
INFO - 2021-07-25 13:09:14 --> Helper loaded: url_helper
INFO - 2021-07-25 13:09:14 --> Helper loaded: form_helper
INFO - 2021-07-25 13:09:14 --> Helper loaded: common_helper
INFO - 2021-07-25 13:09:14 --> Database Driver Class Initialized
DEBUG - 2021-07-25 13:09:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-25 13:09:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-25 13:09:14 --> Controller Class Initialized
INFO - 2021-07-25 13:09:14 --> Form Validation Class Initialized
DEBUG - 2021-07-25 13:09:14 --> Encrypt Class Initialized
DEBUG - 2021-07-25 13:09:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-07-25 13:09:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-07-25 13:09:14 --> Email Class Initialized
INFO - 2021-07-25 13:09:14 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-07-25 13:09:14 --> Calendar Class Initialized
INFO - 2021-07-25 13:09:14 --> Model "Login_model" initialized
INFO - 2021-07-25 13:09:14 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-07-25 13:09:14 --> Final output sent to browser
DEBUG - 2021-07-25 13:09:14 --> Total execution time: 0.0666
