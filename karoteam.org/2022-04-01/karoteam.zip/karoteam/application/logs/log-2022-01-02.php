<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-01-02 11:28:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-02 11:28:32 --> Config Class Initialized
INFO - 2022-01-02 11:28:32 --> Hooks Class Initialized
DEBUG - 2022-01-02 11:28:32 --> UTF-8 Support Enabled
INFO - 2022-01-02 11:28:32 --> Utf8 Class Initialized
INFO - 2022-01-02 11:28:32 --> URI Class Initialized
DEBUG - 2022-01-02 11:28:32 --> No URI present. Default controller set.
INFO - 2022-01-02 11:28:32 --> Router Class Initialized
INFO - 2022-01-02 11:28:32 --> Output Class Initialized
INFO - 2022-01-02 11:28:32 --> Security Class Initialized
DEBUG - 2022-01-02 11:28:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-02 11:28:32 --> Input Class Initialized
INFO - 2022-01-02 11:28:32 --> Language Class Initialized
INFO - 2022-01-02 11:28:32 --> Loader Class Initialized
INFO - 2022-01-02 11:28:32 --> Helper loaded: url_helper
INFO - 2022-01-02 11:28:32 --> Helper loaded: form_helper
INFO - 2022-01-02 11:28:32 --> Helper loaded: common_helper
INFO - 2022-01-02 11:28:32 --> Database Driver Class Initialized
DEBUG - 2022-01-02 11:28:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-02 11:28:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-02 11:28:32 --> Controller Class Initialized
INFO - 2022-01-02 11:28:32 --> Form Validation Class Initialized
DEBUG - 2022-01-02 11:28:32 --> Encrypt Class Initialized
DEBUG - 2022-01-02 11:28:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-02 11:28:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-02 11:28:32 --> Email Class Initialized
INFO - 2022-01-02 11:28:32 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-02 11:28:32 --> Calendar Class Initialized
INFO - 2022-01-02 11:28:32 --> Model "Login_model" initialized
INFO - 2022-01-02 11:28:32 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-02 11:28:32 --> Final output sent to browser
DEBUG - 2022-01-02 11:28:32 --> Total execution time: 0.0353
ERROR - 2022-01-02 13:24:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-02 13:24:10 --> Config Class Initialized
INFO - 2022-01-02 13:24:10 --> Hooks Class Initialized
DEBUG - 2022-01-02 13:24:10 --> UTF-8 Support Enabled
INFO - 2022-01-02 13:24:10 --> Utf8 Class Initialized
INFO - 2022-01-02 13:24:10 --> URI Class Initialized
INFO - 2022-01-02 13:24:10 --> Router Class Initialized
INFO - 2022-01-02 13:24:10 --> Output Class Initialized
INFO - 2022-01-02 13:24:10 --> Security Class Initialized
DEBUG - 2022-01-02 13:24:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-02 13:24:10 --> Input Class Initialized
INFO - 2022-01-02 13:24:10 --> Language Class Initialized
ERROR - 2022-01-02 13:24:10 --> 404 Page Not Found: Humanstxt/index
ERROR - 2022-01-02 13:24:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-02 13:24:11 --> Config Class Initialized
INFO - 2022-01-02 13:24:11 --> Hooks Class Initialized
DEBUG - 2022-01-02 13:24:11 --> UTF-8 Support Enabled
INFO - 2022-01-02 13:24:11 --> Utf8 Class Initialized
INFO - 2022-01-02 13:24:11 --> URI Class Initialized
INFO - 2022-01-02 13:24:11 --> Router Class Initialized
INFO - 2022-01-02 13:24:11 --> Output Class Initialized
INFO - 2022-01-02 13:24:11 --> Security Class Initialized
DEBUG - 2022-01-02 13:24:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-02 13:24:11 --> Input Class Initialized
INFO - 2022-01-02 13:24:11 --> Language Class Initialized
ERROR - 2022-01-02 13:24:11 --> 404 Page Not Found: Adstxt/index
ERROR - 2022-01-02 13:24:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-02 13:24:12 --> Config Class Initialized
INFO - 2022-01-02 13:24:12 --> Hooks Class Initialized
DEBUG - 2022-01-02 13:24:12 --> UTF-8 Support Enabled
INFO - 2022-01-02 13:24:12 --> Utf8 Class Initialized
INFO - 2022-01-02 13:24:12 --> URI Class Initialized
DEBUG - 2022-01-02 13:24:12 --> No URI present. Default controller set.
INFO - 2022-01-02 13:24:12 --> Router Class Initialized
INFO - 2022-01-02 13:24:12 --> Output Class Initialized
INFO - 2022-01-02 13:24:12 --> Security Class Initialized
DEBUG - 2022-01-02 13:24:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-02 13:24:12 --> Input Class Initialized
INFO - 2022-01-02 13:24:12 --> Language Class Initialized
INFO - 2022-01-02 13:24:12 --> Loader Class Initialized
INFO - 2022-01-02 13:24:12 --> Helper loaded: url_helper
INFO - 2022-01-02 13:24:12 --> Helper loaded: form_helper
INFO - 2022-01-02 13:24:12 --> Helper loaded: common_helper
INFO - 2022-01-02 13:24:12 --> Database Driver Class Initialized
DEBUG - 2022-01-02 13:24:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-02 13:24:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-02 13:24:12 --> Controller Class Initialized
INFO - 2022-01-02 13:24:12 --> Form Validation Class Initialized
DEBUG - 2022-01-02 13:24:12 --> Encrypt Class Initialized
DEBUG - 2022-01-02 13:24:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-02 13:24:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-02 13:24:12 --> Email Class Initialized
INFO - 2022-01-02 13:24:12 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-02 13:24:12 --> Calendar Class Initialized
INFO - 2022-01-02 13:24:12 --> Model "Login_model" initialized
INFO - 2022-01-02 13:24:12 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-02 13:24:12 --> Final output sent to browser
DEBUG - 2022-01-02 13:24:12 --> Total execution time: 0.0322
ERROR - 2022-01-02 14:16:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-02 14:16:50 --> Config Class Initialized
INFO - 2022-01-02 14:16:50 --> Hooks Class Initialized
DEBUG - 2022-01-02 14:16:50 --> UTF-8 Support Enabled
INFO - 2022-01-02 14:16:50 --> Utf8 Class Initialized
INFO - 2022-01-02 14:16:50 --> URI Class Initialized
DEBUG - 2022-01-02 14:16:50 --> No URI present. Default controller set.
INFO - 2022-01-02 14:16:50 --> Router Class Initialized
INFO - 2022-01-02 14:16:50 --> Output Class Initialized
INFO - 2022-01-02 14:16:50 --> Security Class Initialized
DEBUG - 2022-01-02 14:16:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-02 14:16:50 --> Input Class Initialized
INFO - 2022-01-02 14:16:50 --> Language Class Initialized
INFO - 2022-01-02 14:16:50 --> Loader Class Initialized
INFO - 2022-01-02 14:16:50 --> Helper loaded: url_helper
INFO - 2022-01-02 14:16:50 --> Helper loaded: form_helper
INFO - 2022-01-02 14:16:50 --> Helper loaded: common_helper
INFO - 2022-01-02 14:16:50 --> Database Driver Class Initialized
DEBUG - 2022-01-02 14:16:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-02 14:16:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-02 14:16:50 --> Controller Class Initialized
INFO - 2022-01-02 14:16:50 --> Form Validation Class Initialized
DEBUG - 2022-01-02 14:16:50 --> Encrypt Class Initialized
DEBUG - 2022-01-02 14:16:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-02 14:16:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-02 14:16:50 --> Email Class Initialized
INFO - 2022-01-02 14:16:50 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-02 14:16:50 --> Calendar Class Initialized
INFO - 2022-01-02 14:16:50 --> Model "Login_model" initialized
INFO - 2022-01-02 14:16:50 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-02 14:16:50 --> Final output sent to browser
DEBUG - 2022-01-02 14:16:50 --> Total execution time: 0.0407
ERROR - 2022-01-02 14:16:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-02 14:16:50 --> Config Class Initialized
INFO - 2022-01-02 14:16:50 --> Hooks Class Initialized
DEBUG - 2022-01-02 14:16:50 --> UTF-8 Support Enabled
INFO - 2022-01-02 14:16:50 --> Utf8 Class Initialized
INFO - 2022-01-02 14:16:50 --> URI Class Initialized
INFO - 2022-01-02 14:16:50 --> Router Class Initialized
INFO - 2022-01-02 14:16:50 --> Output Class Initialized
INFO - 2022-01-02 14:16:50 --> Security Class Initialized
DEBUG - 2022-01-02 14:16:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-02 14:16:50 --> Input Class Initialized
INFO - 2022-01-02 14:16:50 --> Language Class Initialized
ERROR - 2022-01-02 14:16:50 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2022-01-02 14:17:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-02 14:17:23 --> Config Class Initialized
INFO - 2022-01-02 14:17:23 --> Hooks Class Initialized
DEBUG - 2022-01-02 14:17:23 --> UTF-8 Support Enabled
INFO - 2022-01-02 14:17:23 --> Utf8 Class Initialized
INFO - 2022-01-02 14:17:23 --> URI Class Initialized
DEBUG - 2022-01-02 14:17:23 --> No URI present. Default controller set.
INFO - 2022-01-02 14:17:23 --> Router Class Initialized
INFO - 2022-01-02 14:17:23 --> Output Class Initialized
INFO - 2022-01-02 14:17:23 --> Security Class Initialized
DEBUG - 2022-01-02 14:17:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-02 14:17:23 --> Input Class Initialized
INFO - 2022-01-02 14:17:23 --> Language Class Initialized
INFO - 2022-01-02 14:17:23 --> Loader Class Initialized
INFO - 2022-01-02 14:17:23 --> Helper loaded: url_helper
INFO - 2022-01-02 14:17:23 --> Helper loaded: form_helper
INFO - 2022-01-02 14:17:23 --> Helper loaded: common_helper
INFO - 2022-01-02 14:17:23 --> Database Driver Class Initialized
DEBUG - 2022-01-02 14:17:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-02 14:17:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-02 14:17:23 --> Controller Class Initialized
INFO - 2022-01-02 14:17:23 --> Form Validation Class Initialized
DEBUG - 2022-01-02 14:17:23 --> Encrypt Class Initialized
DEBUG - 2022-01-02 14:17:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-02 14:17:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-02 14:17:23 --> Email Class Initialized
INFO - 2022-01-02 14:17:23 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-02 14:17:23 --> Calendar Class Initialized
INFO - 2022-01-02 14:17:23 --> Model "Login_model" initialized
INFO - 2022-01-02 14:17:23 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-02 14:17:23 --> Final output sent to browser
DEBUG - 2022-01-02 14:17:23 --> Total execution time: 0.0222
ERROR - 2022-01-02 14:17:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-02 14:17:23 --> Config Class Initialized
INFO - 2022-01-02 14:17:23 --> Hooks Class Initialized
DEBUG - 2022-01-02 14:17:23 --> UTF-8 Support Enabled
INFO - 2022-01-02 14:17:23 --> Utf8 Class Initialized
INFO - 2022-01-02 14:17:23 --> URI Class Initialized
INFO - 2022-01-02 14:17:23 --> Router Class Initialized
INFO - 2022-01-02 14:17:23 --> Output Class Initialized
INFO - 2022-01-02 14:17:23 --> Security Class Initialized
DEBUG - 2022-01-02 14:17:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-02 14:17:23 --> Input Class Initialized
INFO - 2022-01-02 14:17:23 --> Language Class Initialized
INFO - 2022-01-02 14:17:23 --> Loader Class Initialized
INFO - 2022-01-02 14:17:23 --> Helper loaded: url_helper
INFO - 2022-01-02 14:17:23 --> Helper loaded: form_helper
INFO - 2022-01-02 14:17:23 --> Helper loaded: common_helper
INFO - 2022-01-02 14:17:23 --> Database Driver Class Initialized
DEBUG - 2022-01-02 14:17:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-02 14:17:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-02 14:17:23 --> Controller Class Initialized
INFO - 2022-01-02 14:17:23 --> Form Validation Class Initialized
DEBUG - 2022-01-02 14:17:23 --> Encrypt Class Initialized
DEBUG - 2022-01-02 14:17:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-02 14:17:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-02 14:17:23 --> Email Class Initialized
INFO - 2022-01-02 14:17:23 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-02 14:17:23 --> Calendar Class Initialized
INFO - 2022-01-02 14:17:23 --> Model "Login_model" initialized
INFO - 2022-01-02 14:17:23 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-02 14:17:23 --> Final output sent to browser
DEBUG - 2022-01-02 14:17:23 --> Total execution time: 0.0217
ERROR - 2022-01-02 14:17:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-02 14:17:24 --> Config Class Initialized
INFO - 2022-01-02 14:17:24 --> Hooks Class Initialized
DEBUG - 2022-01-02 14:17:24 --> UTF-8 Support Enabled
INFO - 2022-01-02 14:17:24 --> Utf8 Class Initialized
INFO - 2022-01-02 14:17:24 --> URI Class Initialized
INFO - 2022-01-02 14:17:24 --> Router Class Initialized
INFO - 2022-01-02 14:17:24 --> Output Class Initialized
INFO - 2022-01-02 14:17:24 --> Security Class Initialized
DEBUG - 2022-01-02 14:17:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-02 14:17:24 --> Input Class Initialized
INFO - 2022-01-02 14:17:24 --> Language Class Initialized
INFO - 2022-01-02 14:17:24 --> Loader Class Initialized
INFO - 2022-01-02 14:17:24 --> Helper loaded: url_helper
INFO - 2022-01-02 14:17:24 --> Helper loaded: form_helper
INFO - 2022-01-02 14:17:24 --> Helper loaded: common_helper
INFO - 2022-01-02 14:17:24 --> Database Driver Class Initialized
DEBUG - 2022-01-02 14:17:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-02 14:17:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-02 14:17:24 --> Controller Class Initialized
INFO - 2022-01-02 14:17:24 --> Form Validation Class Initialized
DEBUG - 2022-01-02 14:17:24 --> Encrypt Class Initialized
DEBUG - 2022-01-02 14:17:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-02 14:17:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-02 14:17:24 --> Email Class Initialized
INFO - 2022-01-02 14:17:24 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-02 14:17:24 --> Calendar Class Initialized
INFO - 2022-01-02 14:17:24 --> Model "Login_model" initialized
ERROR - 2022-01-02 14:17:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-02 14:17:24 --> Config Class Initialized
INFO - 2022-01-02 14:17:24 --> Hooks Class Initialized
DEBUG - 2022-01-02 14:17:24 --> UTF-8 Support Enabled
INFO - 2022-01-02 14:17:24 --> Utf8 Class Initialized
INFO - 2022-01-02 14:17:24 --> URI Class Initialized
INFO - 2022-01-02 14:17:24 --> Router Class Initialized
INFO - 2022-01-02 14:17:24 --> Output Class Initialized
INFO - 2022-01-02 14:17:24 --> Security Class Initialized
DEBUG - 2022-01-02 14:17:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-02 14:17:24 --> Input Class Initialized
INFO - 2022-01-02 14:17:24 --> Language Class Initialized
INFO - 2022-01-02 14:17:24 --> Loader Class Initialized
INFO - 2022-01-02 14:17:24 --> Helper loaded: url_helper
INFO - 2022-01-02 14:17:24 --> Helper loaded: form_helper
INFO - 2022-01-02 14:17:24 --> Helper loaded: common_helper
INFO - 2022-01-02 14:17:24 --> Database Driver Class Initialized
DEBUG - 2022-01-02 14:17:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-02 14:17:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-02 14:17:24 --> Controller Class Initialized
INFO - 2022-01-02 14:17:24 --> Form Validation Class Initialized
DEBUG - 2022-01-02 14:17:24 --> Encrypt Class Initialized
DEBUG - 2022-01-02 14:17:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-02 14:17:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-02 14:17:24 --> Email Class Initialized
INFO - 2022-01-02 14:17:24 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-02 14:17:24 --> Calendar Class Initialized
INFO - 2022-01-02 14:17:24 --> Model "Login_model" initialized
ERROR - 2022-01-02 19:08:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-02 19:08:20 --> Config Class Initialized
INFO - 2022-01-02 19:08:20 --> Hooks Class Initialized
DEBUG - 2022-01-02 19:08:20 --> UTF-8 Support Enabled
INFO - 2022-01-02 19:08:20 --> Utf8 Class Initialized
INFO - 2022-01-02 19:08:20 --> URI Class Initialized
DEBUG - 2022-01-02 19:08:20 --> No URI present. Default controller set.
INFO - 2022-01-02 19:08:20 --> Router Class Initialized
INFO - 2022-01-02 19:08:20 --> Output Class Initialized
INFO - 2022-01-02 19:08:20 --> Security Class Initialized
DEBUG - 2022-01-02 19:08:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-02 19:08:20 --> Input Class Initialized
INFO - 2022-01-02 19:08:20 --> Language Class Initialized
INFO - 2022-01-02 19:08:20 --> Loader Class Initialized
INFO - 2022-01-02 19:08:20 --> Helper loaded: url_helper
INFO - 2022-01-02 19:08:20 --> Helper loaded: form_helper
INFO - 2022-01-02 19:08:20 --> Helper loaded: common_helper
INFO - 2022-01-02 19:08:20 --> Database Driver Class Initialized
DEBUG - 2022-01-02 19:08:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-02 19:08:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-02 19:08:20 --> Controller Class Initialized
INFO - 2022-01-02 19:08:20 --> Form Validation Class Initialized
DEBUG - 2022-01-02 19:08:20 --> Encrypt Class Initialized
DEBUG - 2022-01-02 19:08:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-02 19:08:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-02 19:08:20 --> Email Class Initialized
INFO - 2022-01-02 19:08:20 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-02 19:08:20 --> Calendar Class Initialized
INFO - 2022-01-02 19:08:20 --> Model "Login_model" initialized
INFO - 2022-01-02 19:08:20 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-02 19:08:20 --> Final output sent to browser
DEBUG - 2022-01-02 19:08:20 --> Total execution time: 0.0366
ERROR - 2022-01-02 20:50:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-02 20:50:14 --> Config Class Initialized
INFO - 2022-01-02 20:50:14 --> Hooks Class Initialized
DEBUG - 2022-01-02 20:50:14 --> UTF-8 Support Enabled
INFO - 2022-01-02 20:50:14 --> Utf8 Class Initialized
INFO - 2022-01-02 20:50:14 --> URI Class Initialized
DEBUG - 2022-01-02 20:50:14 --> No URI present. Default controller set.
INFO - 2022-01-02 20:50:14 --> Router Class Initialized
INFO - 2022-01-02 20:50:14 --> Output Class Initialized
INFO - 2022-01-02 20:50:14 --> Security Class Initialized
DEBUG - 2022-01-02 20:50:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-02 20:50:14 --> Input Class Initialized
INFO - 2022-01-02 20:50:14 --> Language Class Initialized
INFO - 2022-01-02 20:50:14 --> Loader Class Initialized
INFO - 2022-01-02 20:50:14 --> Helper loaded: url_helper
INFO - 2022-01-02 20:50:14 --> Helper loaded: form_helper
INFO - 2022-01-02 20:50:14 --> Helper loaded: common_helper
INFO - 2022-01-02 20:50:14 --> Database Driver Class Initialized
DEBUG - 2022-01-02 20:50:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-02 20:50:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-02 20:50:14 --> Controller Class Initialized
INFO - 2022-01-02 20:50:14 --> Form Validation Class Initialized
DEBUG - 2022-01-02 20:50:14 --> Encrypt Class Initialized
DEBUG - 2022-01-02 20:50:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-02 20:50:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-02 20:50:14 --> Email Class Initialized
INFO - 2022-01-02 20:50:14 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-02 20:50:14 --> Calendar Class Initialized
INFO - 2022-01-02 20:50:14 --> Model "Login_model" initialized
INFO - 2022-01-02 20:50:14 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-02 20:50:14 --> Final output sent to browser
DEBUG - 2022-01-02 20:50:14 --> Total execution time: 0.0229
ERROR - 2022-01-02 20:55:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-02 20:55:01 --> Config Class Initialized
INFO - 2022-01-02 20:55:01 --> Hooks Class Initialized
DEBUG - 2022-01-02 20:55:01 --> UTF-8 Support Enabled
INFO - 2022-01-02 20:55:01 --> Utf8 Class Initialized
INFO - 2022-01-02 20:55:01 --> URI Class Initialized
INFO - 2022-01-02 20:55:01 --> Router Class Initialized
INFO - 2022-01-02 20:55:01 --> Output Class Initialized
INFO - 2022-01-02 20:55:01 --> Security Class Initialized
DEBUG - 2022-01-02 20:55:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-02 20:55:01 --> Input Class Initialized
INFO - 2022-01-02 20:55:01 --> Language Class Initialized
ERROR - 2022-01-02 20:55:01 --> 404 Page Not Found: Src/app.js
ERROR - 2022-01-02 20:55:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-02 20:55:01 --> Config Class Initialized
INFO - 2022-01-02 20:55:01 --> Hooks Class Initialized
DEBUG - 2022-01-02 20:55:01 --> UTF-8 Support Enabled
INFO - 2022-01-02 20:55:01 --> Utf8 Class Initialized
INFO - 2022-01-02 20:55:01 --> URI Class Initialized
INFO - 2022-01-02 20:55:01 --> Router Class Initialized
INFO - 2022-01-02 20:55:01 --> Output Class Initialized
INFO - 2022-01-02 20:55:01 --> Security Class Initialized
DEBUG - 2022-01-02 20:55:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-02 20:55:01 --> Input Class Initialized
INFO - 2022-01-02 20:55:01 --> Language Class Initialized
ERROR - 2022-01-02 20:55:01 --> 404 Page Not Found: Src/app.js
ERROR - 2022-01-02 21:03:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-02 21:03:21 --> Config Class Initialized
INFO - 2022-01-02 21:03:21 --> Hooks Class Initialized
DEBUG - 2022-01-02 21:03:21 --> UTF-8 Support Enabled
INFO - 2022-01-02 21:03:21 --> Utf8 Class Initialized
INFO - 2022-01-02 21:03:21 --> URI Class Initialized
DEBUG - 2022-01-02 21:03:21 --> No URI present. Default controller set.
INFO - 2022-01-02 21:03:21 --> Router Class Initialized
INFO - 2022-01-02 21:03:21 --> Output Class Initialized
INFO - 2022-01-02 21:03:21 --> Security Class Initialized
DEBUG - 2022-01-02 21:03:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-02 21:03:21 --> Input Class Initialized
INFO - 2022-01-02 21:03:21 --> Language Class Initialized
INFO - 2022-01-02 21:03:21 --> Loader Class Initialized
INFO - 2022-01-02 21:03:21 --> Helper loaded: url_helper
INFO - 2022-01-02 21:03:21 --> Helper loaded: form_helper
INFO - 2022-01-02 21:03:21 --> Helper loaded: common_helper
INFO - 2022-01-02 21:03:21 --> Database Driver Class Initialized
DEBUG - 2022-01-02 21:03:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-02 21:03:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-02 21:03:21 --> Controller Class Initialized
INFO - 2022-01-02 21:03:21 --> Form Validation Class Initialized
DEBUG - 2022-01-02 21:03:21 --> Encrypt Class Initialized
DEBUG - 2022-01-02 21:03:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-02 21:03:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-02 21:03:21 --> Email Class Initialized
INFO - 2022-01-02 21:03:21 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-02 21:03:21 --> Calendar Class Initialized
INFO - 2022-01-02 21:03:21 --> Model "Login_model" initialized
INFO - 2022-01-02 21:03:21 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-02 21:03:21 --> Final output sent to browser
DEBUG - 2022-01-02 21:03:21 --> Total execution time: 0.0269
ERROR - 2022-01-02 22:01:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-02 22:01:19 --> Config Class Initialized
INFO - 2022-01-02 22:01:19 --> Hooks Class Initialized
DEBUG - 2022-01-02 22:01:19 --> UTF-8 Support Enabled
INFO - 2022-01-02 22:01:19 --> Utf8 Class Initialized
INFO - 2022-01-02 22:01:19 --> URI Class Initialized
DEBUG - 2022-01-02 22:01:19 --> No URI present. Default controller set.
INFO - 2022-01-02 22:01:19 --> Router Class Initialized
INFO - 2022-01-02 22:01:19 --> Output Class Initialized
INFO - 2022-01-02 22:01:19 --> Security Class Initialized
DEBUG - 2022-01-02 22:01:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-02 22:01:19 --> Input Class Initialized
INFO - 2022-01-02 22:01:19 --> Language Class Initialized
INFO - 2022-01-02 22:01:19 --> Loader Class Initialized
INFO - 2022-01-02 22:01:19 --> Helper loaded: url_helper
INFO - 2022-01-02 22:01:19 --> Helper loaded: form_helper
INFO - 2022-01-02 22:01:19 --> Helper loaded: common_helper
INFO - 2022-01-02 22:01:19 --> Database Driver Class Initialized
DEBUG - 2022-01-02 22:01:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-02 22:01:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-02 22:01:19 --> Controller Class Initialized
INFO - 2022-01-02 22:01:19 --> Form Validation Class Initialized
DEBUG - 2022-01-02 22:01:19 --> Encrypt Class Initialized
DEBUG - 2022-01-02 22:01:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-02 22:01:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-02 22:01:19 --> Email Class Initialized
INFO - 2022-01-02 22:01:19 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-02 22:01:19 --> Calendar Class Initialized
INFO - 2022-01-02 22:01:19 --> Model "Login_model" initialized
INFO - 2022-01-02 22:01:19 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-02 22:01:19 --> Final output sent to browser
DEBUG - 2022-01-02 22:01:19 --> Total execution time: 0.0568
ERROR - 2022-01-02 23:48:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-02 23:48:40 --> Config Class Initialized
INFO - 2022-01-02 23:48:40 --> Hooks Class Initialized
DEBUG - 2022-01-02 23:48:40 --> UTF-8 Support Enabled
INFO - 2022-01-02 23:48:40 --> Utf8 Class Initialized
INFO - 2022-01-02 23:48:40 --> URI Class Initialized
DEBUG - 2022-01-02 23:48:40 --> No URI present. Default controller set.
INFO - 2022-01-02 23:48:40 --> Router Class Initialized
INFO - 2022-01-02 23:48:40 --> Output Class Initialized
INFO - 2022-01-02 23:48:40 --> Security Class Initialized
DEBUG - 2022-01-02 23:48:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-02 23:48:40 --> Input Class Initialized
INFO - 2022-01-02 23:48:40 --> Language Class Initialized
INFO - 2022-01-02 23:48:40 --> Loader Class Initialized
INFO - 2022-01-02 23:48:40 --> Helper loaded: url_helper
INFO - 2022-01-02 23:48:40 --> Helper loaded: form_helper
INFO - 2022-01-02 23:48:40 --> Helper loaded: common_helper
INFO - 2022-01-02 23:48:40 --> Database Driver Class Initialized
DEBUG - 2022-01-02 23:48:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-02 23:48:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-02 23:48:40 --> Controller Class Initialized
INFO - 2022-01-02 23:48:40 --> Form Validation Class Initialized
DEBUG - 2022-01-02 23:48:40 --> Encrypt Class Initialized
DEBUG - 2022-01-02 23:48:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-02 23:48:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-02 23:48:40 --> Email Class Initialized
INFO - 2022-01-02 23:48:40 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-02 23:48:40 --> Calendar Class Initialized
INFO - 2022-01-02 23:48:40 --> Model "Login_model" initialized
INFO - 2022-01-02 23:48:40 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-02 23:48:40 --> Final output sent to browser
DEBUG - 2022-01-02 23:48:40 --> Total execution time: 0.0246
