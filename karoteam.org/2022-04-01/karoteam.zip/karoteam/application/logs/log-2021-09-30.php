<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-09-30 13:17:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-30 13:17:02 --> Config Class Initialized
INFO - 2021-09-30 13:17:02 --> Hooks Class Initialized
DEBUG - 2021-09-30 13:17:02 --> UTF-8 Support Enabled
INFO - 2021-09-30 13:17:02 --> Utf8 Class Initialized
INFO - 2021-09-30 13:17:02 --> URI Class Initialized
DEBUG - 2021-09-30 13:17:02 --> No URI present. Default controller set.
INFO - 2021-09-30 13:17:02 --> Router Class Initialized
INFO - 2021-09-30 13:17:02 --> Output Class Initialized
INFO - 2021-09-30 13:17:02 --> Security Class Initialized
DEBUG - 2021-09-30 13:17:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-30 13:17:02 --> Input Class Initialized
INFO - 2021-09-30 13:17:02 --> Language Class Initialized
INFO - 2021-09-30 13:17:02 --> Loader Class Initialized
INFO - 2021-09-30 13:17:02 --> Helper loaded: url_helper
INFO - 2021-09-30 13:17:02 --> Helper loaded: form_helper
INFO - 2021-09-30 13:17:02 --> Helper loaded: common_helper
INFO - 2021-09-30 13:17:02 --> Database Driver Class Initialized
DEBUG - 2021-09-30 13:17:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-30 13:17:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-30 13:17:02 --> Controller Class Initialized
INFO - 2021-09-30 13:17:02 --> Form Validation Class Initialized
DEBUG - 2021-09-30 13:17:02 --> Encrypt Class Initialized
DEBUG - 2021-09-30 13:17:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-09-30 13:17:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-09-30 13:17:02 --> Email Class Initialized
INFO - 2021-09-30 13:17:02 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-09-30 13:17:02 --> Calendar Class Initialized
INFO - 2021-09-30 13:17:02 --> Model "Login_model" initialized
INFO - 2021-09-30 13:17:02 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-09-30 13:17:02 --> Final output sent to browser
DEBUG - 2021-09-30 13:17:02 --> Total execution time: 0.0573
ERROR - 2021-09-30 13:17:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-30 13:17:08 --> Config Class Initialized
INFO - 2021-09-30 13:17:08 --> Hooks Class Initialized
DEBUG - 2021-09-30 13:17:08 --> UTF-8 Support Enabled
INFO - 2021-09-30 13:17:08 --> Utf8 Class Initialized
INFO - 2021-09-30 13:17:08 --> URI Class Initialized
INFO - 2021-09-30 13:17:08 --> Router Class Initialized
INFO - 2021-09-30 13:17:08 --> Output Class Initialized
INFO - 2021-09-30 13:17:08 --> Security Class Initialized
DEBUG - 2021-09-30 13:17:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-30 13:17:08 --> Input Class Initialized
INFO - 2021-09-30 13:17:08 --> Language Class Initialized
ERROR - 2021-09-30 13:17:08 --> 404 Page Not Found: Wordpress/index
ERROR - 2021-09-30 13:17:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-30 13:17:13 --> Config Class Initialized
INFO - 2021-09-30 13:17:13 --> Hooks Class Initialized
DEBUG - 2021-09-30 13:17:13 --> UTF-8 Support Enabled
INFO - 2021-09-30 13:17:13 --> Utf8 Class Initialized
INFO - 2021-09-30 13:17:13 --> URI Class Initialized
INFO - 2021-09-30 13:17:13 --> Router Class Initialized
INFO - 2021-09-30 13:17:13 --> Output Class Initialized
INFO - 2021-09-30 13:17:13 --> Security Class Initialized
DEBUG - 2021-09-30 13:17:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-30 13:17:13 --> Input Class Initialized
INFO - 2021-09-30 13:17:13 --> Language Class Initialized
ERROR - 2021-09-30 13:17:13 --> 404 Page Not Found: Wp/index
ERROR - 2021-09-30 13:17:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-30 13:17:22 --> Config Class Initialized
INFO - 2021-09-30 13:17:22 --> Hooks Class Initialized
DEBUG - 2021-09-30 13:17:22 --> UTF-8 Support Enabled
INFO - 2021-09-30 13:17:22 --> Utf8 Class Initialized
INFO - 2021-09-30 13:17:22 --> URI Class Initialized
INFO - 2021-09-30 13:17:22 --> Router Class Initialized
INFO - 2021-09-30 13:17:22 --> Output Class Initialized
INFO - 2021-09-30 13:17:22 --> Security Class Initialized
DEBUG - 2021-09-30 13:17:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-30 13:17:22 --> Input Class Initialized
INFO - 2021-09-30 13:17:22 --> Language Class Initialized
ERROR - 2021-09-30 13:17:22 --> 404 Page Not Found: Blog/index
ERROR - 2021-09-30 13:17:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-30 13:17:28 --> Config Class Initialized
INFO - 2021-09-30 13:17:28 --> Hooks Class Initialized
DEBUG - 2021-09-30 13:17:28 --> UTF-8 Support Enabled
INFO - 2021-09-30 13:17:28 --> Utf8 Class Initialized
INFO - 2021-09-30 13:17:28 --> URI Class Initialized
INFO - 2021-09-30 13:17:28 --> Router Class Initialized
INFO - 2021-09-30 13:17:28 --> Output Class Initialized
INFO - 2021-09-30 13:17:28 --> Security Class Initialized
DEBUG - 2021-09-30 13:17:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-30 13:17:28 --> Input Class Initialized
INFO - 2021-09-30 13:17:28 --> Language Class Initialized
ERROR - 2021-09-30 13:17:28 --> 404 Page Not Found: New/index
ERROR - 2021-09-30 13:17:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-30 13:17:36 --> Config Class Initialized
INFO - 2021-09-30 13:17:36 --> Hooks Class Initialized
DEBUG - 2021-09-30 13:17:36 --> UTF-8 Support Enabled
INFO - 2021-09-30 13:17:36 --> Utf8 Class Initialized
INFO - 2021-09-30 13:17:36 --> URI Class Initialized
INFO - 2021-09-30 13:17:36 --> Router Class Initialized
INFO - 2021-09-30 13:17:36 --> Output Class Initialized
INFO - 2021-09-30 13:17:36 --> Security Class Initialized
DEBUG - 2021-09-30 13:17:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-30 13:17:36 --> Input Class Initialized
INFO - 2021-09-30 13:17:36 --> Language Class Initialized
ERROR - 2021-09-30 13:17:36 --> 404 Page Not Found: Old/index
ERROR - 2021-09-30 13:17:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-30 13:17:43 --> Config Class Initialized
INFO - 2021-09-30 13:17:43 --> Hooks Class Initialized
DEBUG - 2021-09-30 13:17:43 --> UTF-8 Support Enabled
INFO - 2021-09-30 13:17:43 --> Utf8 Class Initialized
INFO - 2021-09-30 13:17:43 --> URI Class Initialized
INFO - 2021-09-30 13:17:43 --> Router Class Initialized
INFO - 2021-09-30 13:17:43 --> Output Class Initialized
INFO - 2021-09-30 13:17:43 --> Security Class Initialized
DEBUG - 2021-09-30 13:17:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-30 13:17:43 --> Input Class Initialized
INFO - 2021-09-30 13:17:43 --> Language Class Initialized
ERROR - 2021-09-30 13:17:43 --> 404 Page Not Found: Backup/index
ERROR - 2021-09-30 13:17:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-30 13:17:48 --> Config Class Initialized
INFO - 2021-09-30 13:17:48 --> Hooks Class Initialized
DEBUG - 2021-09-30 13:17:48 --> UTF-8 Support Enabled
INFO - 2021-09-30 13:17:48 --> Utf8 Class Initialized
INFO - 2021-09-30 13:17:48 --> URI Class Initialized
INFO - 2021-09-30 13:17:48 --> Router Class Initialized
INFO - 2021-09-30 13:17:48 --> Output Class Initialized
INFO - 2021-09-30 13:17:48 --> Security Class Initialized
DEBUG - 2021-09-30 13:17:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-30 13:17:48 --> Input Class Initialized
INFO - 2021-09-30 13:17:48 --> Language Class Initialized
ERROR - 2021-09-30 13:17:48 --> 404 Page Not Found: Oldsite/index
ERROR - 2021-09-30 13:17:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-30 13:17:55 --> Config Class Initialized
INFO - 2021-09-30 13:17:55 --> Hooks Class Initialized
DEBUG - 2021-09-30 13:17:55 --> UTF-8 Support Enabled
INFO - 2021-09-30 13:17:55 --> Utf8 Class Initialized
INFO - 2021-09-30 13:17:55 --> URI Class Initialized
INFO - 2021-09-30 13:17:55 --> Router Class Initialized
INFO - 2021-09-30 13:17:55 --> Output Class Initialized
INFO - 2021-09-30 13:17:55 --> Security Class Initialized
DEBUG - 2021-09-30 13:17:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-30 13:17:55 --> Input Class Initialized
INFO - 2021-09-30 13:17:55 --> Language Class Initialized
ERROR - 2021-09-30 13:17:55 --> 404 Page Not Found: Back/index
ERROR - 2021-09-30 20:48:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-30 20:48:53 --> Config Class Initialized
INFO - 2021-09-30 20:48:53 --> Hooks Class Initialized
DEBUG - 2021-09-30 20:48:53 --> UTF-8 Support Enabled
INFO - 2021-09-30 20:48:53 --> Utf8 Class Initialized
INFO - 2021-09-30 20:48:53 --> URI Class Initialized
INFO - 2021-09-30 20:48:53 --> Router Class Initialized
INFO - 2021-09-30 20:48:53 --> Output Class Initialized
INFO - 2021-09-30 20:48:53 --> Security Class Initialized
DEBUG - 2021-09-30 20:48:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-30 20:48:53 --> Input Class Initialized
INFO - 2021-09-30 20:48:53 --> Language Class Initialized
ERROR - 2021-09-30 20:48:53 --> 404 Page Not Found: Wp-admin/css
ERROR - 2021-09-30 21:46:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-30 21:46:29 --> Config Class Initialized
INFO - 2021-09-30 21:46:29 --> Hooks Class Initialized
DEBUG - 2021-09-30 21:46:29 --> UTF-8 Support Enabled
INFO - 2021-09-30 21:46:29 --> Utf8 Class Initialized
INFO - 2021-09-30 21:46:29 --> URI Class Initialized
DEBUG - 2021-09-30 21:46:29 --> No URI present. Default controller set.
INFO - 2021-09-30 21:46:29 --> Router Class Initialized
INFO - 2021-09-30 21:46:29 --> Output Class Initialized
INFO - 2021-09-30 21:46:29 --> Security Class Initialized
DEBUG - 2021-09-30 21:46:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-30 21:46:29 --> Input Class Initialized
INFO - 2021-09-30 21:46:29 --> Language Class Initialized
INFO - 2021-09-30 21:46:29 --> Loader Class Initialized
INFO - 2021-09-30 21:46:29 --> Helper loaded: url_helper
INFO - 2021-09-30 21:46:29 --> Helper loaded: form_helper
INFO - 2021-09-30 21:46:29 --> Helper loaded: common_helper
INFO - 2021-09-30 21:46:29 --> Database Driver Class Initialized
DEBUG - 2021-09-30 21:46:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-30 21:46:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-30 21:46:29 --> Controller Class Initialized
INFO - 2021-09-30 21:46:29 --> Form Validation Class Initialized
DEBUG - 2021-09-30 21:46:29 --> Encrypt Class Initialized
DEBUG - 2021-09-30 21:46:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-09-30 21:46:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-09-30 21:46:29 --> Email Class Initialized
INFO - 2021-09-30 21:46:29 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-09-30 21:46:29 --> Calendar Class Initialized
INFO - 2021-09-30 21:46:29 --> Model "Login_model" initialized
INFO - 2021-09-30 21:46:29 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-09-30 21:46:29 --> Final output sent to browser
DEBUG - 2021-09-30 21:46:29 --> Total execution time: 0.0399
