<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-12-16 00:43:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-16 00:43:14 --> Config Class Initialized
INFO - 2021-12-16 00:43:14 --> Hooks Class Initialized
DEBUG - 2021-12-16 00:43:14 --> UTF-8 Support Enabled
INFO - 2021-12-16 00:43:14 --> Utf8 Class Initialized
INFO - 2021-12-16 00:43:14 --> URI Class Initialized
INFO - 2021-12-16 00:43:14 --> Router Class Initialized
INFO - 2021-12-16 00:43:14 --> Output Class Initialized
INFO - 2021-12-16 00:43:14 --> Security Class Initialized
DEBUG - 2021-12-16 00:43:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 00:43:14 --> Input Class Initialized
INFO - 2021-12-16 00:43:14 --> Language Class Initialized
INFO - 2021-12-16 00:43:14 --> Loader Class Initialized
INFO - 2021-12-16 00:43:14 --> Helper loaded: url_helper
INFO - 2021-12-16 00:43:14 --> Helper loaded: form_helper
INFO - 2021-12-16 00:43:14 --> Helper loaded: common_helper
INFO - 2021-12-16 00:43:14 --> Database Driver Class Initialized
DEBUG - 2021-12-16 00:43:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 00:43:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 00:43:14 --> Controller Class Initialized
INFO - 2021-12-16 00:43:14 --> Form Validation Class Initialized
DEBUG - 2021-12-16 00:43:14 --> Encrypt Class Initialized
INFO - 2021-12-16 00:43:14 --> Model "Login_model" initialized
INFO - 2021-12-16 00:43:14 --> Model "Dashboard_model" initialized
INFO - 2021-12-16 00:43:14 --> Model "Case_model" initialized
ERROR - 2021-12-16 00:43:14 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'GROUP BY  CALCULATEAGE(YEAR(patient_dob))
     
     UNION 
     
  SELECT calcu' at line 7 - Invalid query: SELECT SUM(TotalPatient) as TotalPatient ,AgeGroup
FROM
( 
SELECT CALCULATEAGE(YEAR(patient_dob)) AS AgeGroup, COUNT(CALCULATEAGE(YEAR(patient_dob)))  AS TotalPatient FROM patient_master
       
    WHERE  IFNULL(`status`,0)!= '1' AND patient_dob IS NOT NULL AND patient_dob != '0000-00-00'  AND patient_master.created_by = 
     GROUP BY  CALCULATEAGE(YEAR(patient_dob))
     
     UNION 
     
  SELECT calculateWithoutDOBAge(SUBSTRING(patient_age,1,2)) AS AgeGroup, COUNT(calculateWithoutDOBAge(SUBSTRING(patient_age,1,2))) AS 
  TotalPatient FROM patient_master WHERE IFNULL(`status`,0)!= '1' AND IFNULL(patient_dob,'')='0000-00-00'  AND IFNULL(patient_age,'')!=''  AND patient_master.created_by = 
        GROUP BY calculateWithoutDOBAge(SUBSTRING(patient_age,1,2))
        )B GROUP BY AgeGroup
INFO - 2021-12-16 00:43:14 --> Language file loaded: language/english/db_lang.php
ERROR - 2021-12-16 00:44:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-16 00:44:46 --> Config Class Initialized
INFO - 2021-12-16 00:44:46 --> Hooks Class Initialized
DEBUG - 2021-12-16 00:44:46 --> UTF-8 Support Enabled
INFO - 2021-12-16 00:44:46 --> Utf8 Class Initialized
INFO - 2021-12-16 00:44:46 --> URI Class Initialized
DEBUG - 2021-12-16 00:44:46 --> No URI present. Default controller set.
INFO - 2021-12-16 00:44:46 --> Router Class Initialized
INFO - 2021-12-16 00:44:46 --> Output Class Initialized
INFO - 2021-12-16 00:44:46 --> Security Class Initialized
DEBUG - 2021-12-16 00:44:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 00:44:46 --> Input Class Initialized
INFO - 2021-12-16 00:44:46 --> Language Class Initialized
INFO - 2021-12-16 00:44:46 --> Loader Class Initialized
INFO - 2021-12-16 00:44:46 --> Helper loaded: url_helper
INFO - 2021-12-16 00:44:46 --> Helper loaded: form_helper
INFO - 2021-12-16 00:44:46 --> Helper loaded: common_helper
INFO - 2021-12-16 00:44:46 --> Database Driver Class Initialized
DEBUG - 2021-12-16 00:44:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 00:44:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 00:44:46 --> Controller Class Initialized
INFO - 2021-12-16 00:44:46 --> Form Validation Class Initialized
DEBUG - 2021-12-16 00:44:46 --> Encrypt Class Initialized
DEBUG - 2021-12-16 00:44:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-16 00:44:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-16 00:44:46 --> Email Class Initialized
INFO - 2021-12-16 00:44:46 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-16 00:44:46 --> Calendar Class Initialized
INFO - 2021-12-16 00:44:46 --> Model "Login_model" initialized
INFO - 2021-12-16 00:44:46 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-16 00:44:46 --> Final output sent to browser
DEBUG - 2021-12-16 00:44:46 --> Total execution time: 0.0232
ERROR - 2021-12-16 01:10:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-16 01:10:07 --> Config Class Initialized
INFO - 2021-12-16 01:10:07 --> Hooks Class Initialized
DEBUG - 2021-12-16 01:10:07 --> UTF-8 Support Enabled
INFO - 2021-12-16 01:10:07 --> Utf8 Class Initialized
INFO - 2021-12-16 01:10:07 --> URI Class Initialized
INFO - 2021-12-16 01:10:07 --> Router Class Initialized
INFO - 2021-12-16 01:10:07 --> Output Class Initialized
INFO - 2021-12-16 01:10:07 --> Security Class Initialized
DEBUG - 2021-12-16 01:10:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 01:10:07 --> Input Class Initialized
INFO - 2021-12-16 01:10:07 --> Language Class Initialized
ERROR - 2021-12-16 01:10:07 --> 404 Page Not Found: Ckfinder/ckfinder.js
ERROR - 2021-12-16 03:22:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-16 03:22:28 --> Config Class Initialized
INFO - 2021-12-16 03:22:28 --> Hooks Class Initialized
DEBUG - 2021-12-16 03:22:28 --> UTF-8 Support Enabled
INFO - 2021-12-16 03:22:28 --> Utf8 Class Initialized
INFO - 2021-12-16 03:22:28 --> URI Class Initialized
DEBUG - 2021-12-16 03:22:28 --> No URI present. Default controller set.
INFO - 2021-12-16 03:22:28 --> Router Class Initialized
INFO - 2021-12-16 03:22:28 --> Output Class Initialized
INFO - 2021-12-16 03:22:28 --> Security Class Initialized
DEBUG - 2021-12-16 03:22:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 03:22:28 --> Input Class Initialized
INFO - 2021-12-16 03:22:28 --> Language Class Initialized
INFO - 2021-12-16 03:22:28 --> Loader Class Initialized
INFO - 2021-12-16 03:22:28 --> Helper loaded: url_helper
INFO - 2021-12-16 03:22:28 --> Helper loaded: form_helper
INFO - 2021-12-16 03:22:28 --> Helper loaded: common_helper
INFO - 2021-12-16 03:22:28 --> Database Driver Class Initialized
DEBUG - 2021-12-16 03:22:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 03:22:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 03:22:28 --> Controller Class Initialized
INFO - 2021-12-16 03:22:28 --> Form Validation Class Initialized
DEBUG - 2021-12-16 03:22:28 --> Encrypt Class Initialized
DEBUG - 2021-12-16 03:22:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-16 03:22:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-16 03:22:28 --> Email Class Initialized
INFO - 2021-12-16 03:22:28 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-16 03:22:28 --> Calendar Class Initialized
INFO - 2021-12-16 03:22:28 --> Model "Login_model" initialized
INFO - 2021-12-16 03:22:28 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-16 03:22:28 --> Final output sent to browser
DEBUG - 2021-12-16 03:22:28 --> Total execution time: 0.0355
ERROR - 2021-12-16 03:22:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-16 03:22:29 --> Config Class Initialized
INFO - 2021-12-16 03:22:29 --> Hooks Class Initialized
DEBUG - 2021-12-16 03:22:29 --> UTF-8 Support Enabled
INFO - 2021-12-16 03:22:29 --> Utf8 Class Initialized
INFO - 2021-12-16 03:22:29 --> URI Class Initialized
DEBUG - 2021-12-16 03:22:29 --> No URI present. Default controller set.
INFO - 2021-12-16 03:22:29 --> Router Class Initialized
INFO - 2021-12-16 03:22:29 --> Output Class Initialized
INFO - 2021-12-16 03:22:29 --> Security Class Initialized
DEBUG - 2021-12-16 03:22:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 03:22:29 --> Input Class Initialized
INFO - 2021-12-16 03:22:29 --> Language Class Initialized
INFO - 2021-12-16 03:22:29 --> Loader Class Initialized
INFO - 2021-12-16 03:22:29 --> Helper loaded: url_helper
INFO - 2021-12-16 03:22:29 --> Helper loaded: form_helper
INFO - 2021-12-16 03:22:29 --> Helper loaded: common_helper
INFO - 2021-12-16 03:22:29 --> Database Driver Class Initialized
DEBUG - 2021-12-16 03:22:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 03:22:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 03:22:29 --> Controller Class Initialized
INFO - 2021-12-16 03:22:29 --> Form Validation Class Initialized
DEBUG - 2021-12-16 03:22:29 --> Encrypt Class Initialized
DEBUG - 2021-12-16 03:22:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-16 03:22:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-16 03:22:29 --> Email Class Initialized
INFO - 2021-12-16 03:22:29 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-16 03:22:29 --> Calendar Class Initialized
INFO - 2021-12-16 03:22:29 --> Model "Login_model" initialized
INFO - 2021-12-16 03:22:29 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-16 03:22:29 --> Final output sent to browser
DEBUG - 2021-12-16 03:22:29 --> Total execution time: 0.0311
ERROR - 2021-12-16 03:22:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-16 03:22:29 --> Config Class Initialized
INFO - 2021-12-16 03:22:29 --> Hooks Class Initialized
DEBUG - 2021-12-16 03:22:29 --> UTF-8 Support Enabled
INFO - 2021-12-16 03:22:29 --> Utf8 Class Initialized
INFO - 2021-12-16 03:22:29 --> URI Class Initialized
INFO - 2021-12-16 03:22:29 --> Router Class Initialized
INFO - 2021-12-16 03:22:29 --> Output Class Initialized
INFO - 2021-12-16 03:22:29 --> Security Class Initialized
DEBUG - 2021-12-16 03:22:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 03:22:29 --> Input Class Initialized
INFO - 2021-12-16 03:22:29 --> Language Class Initialized
ERROR - 2021-12-16 03:22:29 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
ERROR - 2021-12-16 03:22:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-16 03:22:31 --> Config Class Initialized
INFO - 2021-12-16 03:22:31 --> Hooks Class Initialized
DEBUG - 2021-12-16 03:22:31 --> UTF-8 Support Enabled
INFO - 2021-12-16 03:22:31 --> Utf8 Class Initialized
INFO - 2021-12-16 03:22:31 --> URI Class Initialized
INFO - 2021-12-16 03:22:31 --> Router Class Initialized
INFO - 2021-12-16 03:22:31 --> Output Class Initialized
INFO - 2021-12-16 03:22:31 --> Security Class Initialized
DEBUG - 2021-12-16 03:22:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 03:22:31 --> Input Class Initialized
INFO - 2021-12-16 03:22:31 --> Language Class Initialized
ERROR - 2021-12-16 03:22:31 --> 404 Page Not Found: Blog/wp-includes
ERROR - 2021-12-16 03:22:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-16 03:22:31 --> Config Class Initialized
INFO - 2021-12-16 03:22:31 --> Hooks Class Initialized
DEBUG - 2021-12-16 03:22:31 --> UTF-8 Support Enabled
INFO - 2021-12-16 03:22:31 --> Utf8 Class Initialized
INFO - 2021-12-16 03:22:31 --> URI Class Initialized
INFO - 2021-12-16 03:22:31 --> Router Class Initialized
INFO - 2021-12-16 03:22:31 --> Output Class Initialized
INFO - 2021-12-16 03:22:31 --> Security Class Initialized
DEBUG - 2021-12-16 03:22:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 03:22:31 --> Input Class Initialized
INFO - 2021-12-16 03:22:31 --> Language Class Initialized
ERROR - 2021-12-16 03:22:31 --> 404 Page Not Found: Web/wp-includes
ERROR - 2021-12-16 03:22:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-16 03:22:32 --> Config Class Initialized
INFO - 2021-12-16 03:22:32 --> Hooks Class Initialized
DEBUG - 2021-12-16 03:22:32 --> UTF-8 Support Enabled
INFO - 2021-12-16 03:22:32 --> Utf8 Class Initialized
INFO - 2021-12-16 03:22:32 --> URI Class Initialized
INFO - 2021-12-16 03:22:32 --> Router Class Initialized
INFO - 2021-12-16 03:22:32 --> Output Class Initialized
INFO - 2021-12-16 03:22:32 --> Security Class Initialized
DEBUG - 2021-12-16 03:22:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 03:22:32 --> Input Class Initialized
INFO - 2021-12-16 03:22:32 --> Language Class Initialized
ERROR - 2021-12-16 03:22:32 --> 404 Page Not Found: Wordpress/wp-includes
ERROR - 2021-12-16 03:22:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-16 03:22:32 --> Config Class Initialized
INFO - 2021-12-16 03:22:32 --> Hooks Class Initialized
DEBUG - 2021-12-16 03:22:32 --> UTF-8 Support Enabled
INFO - 2021-12-16 03:22:32 --> Utf8 Class Initialized
INFO - 2021-12-16 03:22:32 --> URI Class Initialized
INFO - 2021-12-16 03:22:32 --> Router Class Initialized
INFO - 2021-12-16 03:22:32 --> Output Class Initialized
INFO - 2021-12-16 03:22:32 --> Security Class Initialized
DEBUG - 2021-12-16 03:22:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 03:22:32 --> Input Class Initialized
INFO - 2021-12-16 03:22:32 --> Language Class Initialized
ERROR - 2021-12-16 03:22:32 --> 404 Page Not Found: Website/wp-includes
ERROR - 2021-12-16 03:22:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-16 03:22:33 --> Config Class Initialized
INFO - 2021-12-16 03:22:33 --> Hooks Class Initialized
DEBUG - 2021-12-16 03:22:33 --> UTF-8 Support Enabled
INFO - 2021-12-16 03:22:33 --> Utf8 Class Initialized
INFO - 2021-12-16 03:22:33 --> URI Class Initialized
INFO - 2021-12-16 03:22:33 --> Router Class Initialized
INFO - 2021-12-16 03:22:33 --> Output Class Initialized
INFO - 2021-12-16 03:22:33 --> Security Class Initialized
DEBUG - 2021-12-16 03:22:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 03:22:33 --> Input Class Initialized
INFO - 2021-12-16 03:22:33 --> Language Class Initialized
ERROR - 2021-12-16 03:22:33 --> 404 Page Not Found: Wp/wp-includes
ERROR - 2021-12-16 03:22:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-16 03:22:33 --> Config Class Initialized
INFO - 2021-12-16 03:22:33 --> Hooks Class Initialized
DEBUG - 2021-12-16 03:22:33 --> UTF-8 Support Enabled
INFO - 2021-12-16 03:22:33 --> Utf8 Class Initialized
INFO - 2021-12-16 03:22:33 --> URI Class Initialized
INFO - 2021-12-16 03:22:33 --> Router Class Initialized
INFO - 2021-12-16 03:22:33 --> Output Class Initialized
INFO - 2021-12-16 03:22:33 --> Security Class Initialized
DEBUG - 2021-12-16 03:22:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 03:22:33 --> Input Class Initialized
INFO - 2021-12-16 03:22:33 --> Language Class Initialized
ERROR - 2021-12-16 03:22:33 --> 404 Page Not Found: News/wp-includes
ERROR - 2021-12-16 03:22:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-16 03:22:34 --> Config Class Initialized
INFO - 2021-12-16 03:22:34 --> Hooks Class Initialized
DEBUG - 2021-12-16 03:22:34 --> UTF-8 Support Enabled
INFO - 2021-12-16 03:22:34 --> Utf8 Class Initialized
INFO - 2021-12-16 03:22:34 --> URI Class Initialized
INFO - 2021-12-16 03:22:34 --> Router Class Initialized
INFO - 2021-12-16 03:22:34 --> Output Class Initialized
INFO - 2021-12-16 03:22:34 --> Security Class Initialized
DEBUG - 2021-12-16 03:22:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 03:22:34 --> Input Class Initialized
INFO - 2021-12-16 03:22:34 --> Language Class Initialized
ERROR - 2021-12-16 03:22:34 --> 404 Page Not Found: 2020/wp-includes
ERROR - 2021-12-16 03:22:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-16 03:22:34 --> Config Class Initialized
INFO - 2021-12-16 03:22:34 --> Hooks Class Initialized
DEBUG - 2021-12-16 03:22:34 --> UTF-8 Support Enabled
INFO - 2021-12-16 03:22:34 --> Utf8 Class Initialized
INFO - 2021-12-16 03:22:34 --> URI Class Initialized
INFO - 2021-12-16 03:22:34 --> Router Class Initialized
INFO - 2021-12-16 03:22:34 --> Output Class Initialized
INFO - 2021-12-16 03:22:34 --> Security Class Initialized
DEBUG - 2021-12-16 03:22:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 03:22:34 --> Input Class Initialized
INFO - 2021-12-16 03:22:34 --> Language Class Initialized
ERROR - 2021-12-16 03:22:34 --> 404 Page Not Found: 2019/wp-includes
ERROR - 2021-12-16 03:22:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-16 03:22:35 --> Config Class Initialized
INFO - 2021-12-16 03:22:35 --> Hooks Class Initialized
DEBUG - 2021-12-16 03:22:35 --> UTF-8 Support Enabled
INFO - 2021-12-16 03:22:35 --> Utf8 Class Initialized
INFO - 2021-12-16 03:22:35 --> URI Class Initialized
INFO - 2021-12-16 03:22:35 --> Router Class Initialized
INFO - 2021-12-16 03:22:35 --> Output Class Initialized
INFO - 2021-12-16 03:22:35 --> Security Class Initialized
DEBUG - 2021-12-16 03:22:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 03:22:35 --> Input Class Initialized
INFO - 2021-12-16 03:22:35 --> Language Class Initialized
ERROR - 2021-12-16 03:22:35 --> 404 Page Not Found: Shop/wp-includes
ERROR - 2021-12-16 03:22:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-16 03:22:35 --> Config Class Initialized
INFO - 2021-12-16 03:22:35 --> Hooks Class Initialized
DEBUG - 2021-12-16 03:22:35 --> UTF-8 Support Enabled
INFO - 2021-12-16 03:22:35 --> Utf8 Class Initialized
INFO - 2021-12-16 03:22:35 --> URI Class Initialized
INFO - 2021-12-16 03:22:35 --> Router Class Initialized
INFO - 2021-12-16 03:22:35 --> Output Class Initialized
INFO - 2021-12-16 03:22:35 --> Security Class Initialized
DEBUG - 2021-12-16 03:22:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 03:22:35 --> Input Class Initialized
INFO - 2021-12-16 03:22:35 --> Language Class Initialized
ERROR - 2021-12-16 03:22:35 --> 404 Page Not Found: Wp1/wp-includes
ERROR - 2021-12-16 03:22:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-16 03:22:36 --> Config Class Initialized
INFO - 2021-12-16 03:22:36 --> Hooks Class Initialized
DEBUG - 2021-12-16 03:22:36 --> UTF-8 Support Enabled
INFO - 2021-12-16 03:22:36 --> Utf8 Class Initialized
INFO - 2021-12-16 03:22:36 --> URI Class Initialized
INFO - 2021-12-16 03:22:36 --> Router Class Initialized
INFO - 2021-12-16 03:22:36 --> Output Class Initialized
INFO - 2021-12-16 03:22:36 --> Security Class Initialized
DEBUG - 2021-12-16 03:22:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 03:22:36 --> Input Class Initialized
INFO - 2021-12-16 03:22:36 --> Language Class Initialized
ERROR - 2021-12-16 03:22:36 --> 404 Page Not Found: Test/wp-includes
ERROR - 2021-12-16 03:22:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-16 03:22:36 --> Config Class Initialized
INFO - 2021-12-16 03:22:36 --> Hooks Class Initialized
DEBUG - 2021-12-16 03:22:36 --> UTF-8 Support Enabled
INFO - 2021-12-16 03:22:36 --> Utf8 Class Initialized
INFO - 2021-12-16 03:22:36 --> URI Class Initialized
INFO - 2021-12-16 03:22:36 --> Router Class Initialized
INFO - 2021-12-16 03:22:36 --> Output Class Initialized
INFO - 2021-12-16 03:22:36 --> Security Class Initialized
DEBUG - 2021-12-16 03:22:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 03:22:36 --> Input Class Initialized
INFO - 2021-12-16 03:22:36 --> Language Class Initialized
ERROR - 2021-12-16 03:22:36 --> 404 Page Not Found: Wp2/wp-includes
ERROR - 2021-12-16 03:22:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-16 03:22:37 --> Config Class Initialized
INFO - 2021-12-16 03:22:37 --> Hooks Class Initialized
DEBUG - 2021-12-16 03:22:37 --> UTF-8 Support Enabled
INFO - 2021-12-16 03:22:37 --> Utf8 Class Initialized
INFO - 2021-12-16 03:22:37 --> URI Class Initialized
INFO - 2021-12-16 03:22:37 --> Router Class Initialized
INFO - 2021-12-16 03:22:37 --> Output Class Initialized
INFO - 2021-12-16 03:22:37 --> Security Class Initialized
DEBUG - 2021-12-16 03:22:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 03:22:37 --> Input Class Initialized
INFO - 2021-12-16 03:22:37 --> Language Class Initialized
ERROR - 2021-12-16 03:22:37 --> 404 Page Not Found: Site/wp-includes
ERROR - 2021-12-16 03:22:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-16 03:22:37 --> Config Class Initialized
INFO - 2021-12-16 03:22:37 --> Hooks Class Initialized
DEBUG - 2021-12-16 03:22:37 --> UTF-8 Support Enabled
INFO - 2021-12-16 03:22:37 --> Utf8 Class Initialized
INFO - 2021-12-16 03:22:37 --> URI Class Initialized
INFO - 2021-12-16 03:22:37 --> Router Class Initialized
INFO - 2021-12-16 03:22:37 --> Output Class Initialized
INFO - 2021-12-16 03:22:37 --> Security Class Initialized
DEBUG - 2021-12-16 03:22:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 03:22:37 --> Input Class Initialized
INFO - 2021-12-16 03:22:37 --> Language Class Initialized
ERROR - 2021-12-16 03:22:37 --> 404 Page Not Found: Cms/wp-includes
ERROR - 2021-12-16 03:22:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-16 03:22:38 --> Config Class Initialized
INFO - 2021-12-16 03:22:38 --> Hooks Class Initialized
DEBUG - 2021-12-16 03:22:38 --> UTF-8 Support Enabled
INFO - 2021-12-16 03:22:38 --> Utf8 Class Initialized
INFO - 2021-12-16 03:22:38 --> URI Class Initialized
INFO - 2021-12-16 03:22:38 --> Router Class Initialized
INFO - 2021-12-16 03:22:38 --> Output Class Initialized
INFO - 2021-12-16 03:22:38 --> Security Class Initialized
DEBUG - 2021-12-16 03:22:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 03:22:38 --> Input Class Initialized
INFO - 2021-12-16 03:22:38 --> Language Class Initialized
ERROR - 2021-12-16 03:22:38 --> 404 Page Not Found: Sito/wp-includes
ERROR - 2021-12-16 06:22:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-16 06:22:08 --> Config Class Initialized
INFO - 2021-12-16 06:22:08 --> Hooks Class Initialized
DEBUG - 2021-12-16 06:22:08 --> UTF-8 Support Enabled
INFO - 2021-12-16 06:22:08 --> Utf8 Class Initialized
INFO - 2021-12-16 06:22:08 --> URI Class Initialized
DEBUG - 2021-12-16 06:22:08 --> No URI present. Default controller set.
INFO - 2021-12-16 06:22:08 --> Router Class Initialized
INFO - 2021-12-16 06:22:08 --> Output Class Initialized
INFO - 2021-12-16 06:22:08 --> Security Class Initialized
DEBUG - 2021-12-16 06:22:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 06:22:08 --> Input Class Initialized
INFO - 2021-12-16 06:22:08 --> Language Class Initialized
INFO - 2021-12-16 06:22:08 --> Loader Class Initialized
INFO - 2021-12-16 06:22:08 --> Helper loaded: url_helper
INFO - 2021-12-16 06:22:08 --> Helper loaded: form_helper
INFO - 2021-12-16 06:22:08 --> Helper loaded: common_helper
INFO - 2021-12-16 06:22:08 --> Database Driver Class Initialized
DEBUG - 2021-12-16 06:22:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 06:22:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 06:22:08 --> Controller Class Initialized
INFO - 2021-12-16 06:22:08 --> Form Validation Class Initialized
DEBUG - 2021-12-16 06:22:08 --> Encrypt Class Initialized
DEBUG - 2021-12-16 06:22:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-16 06:22:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-16 06:22:08 --> Email Class Initialized
INFO - 2021-12-16 06:22:08 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-16 06:22:08 --> Calendar Class Initialized
INFO - 2021-12-16 06:22:08 --> Model "Login_model" initialized
INFO - 2021-12-16 06:22:08 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-16 06:22:08 --> Final output sent to browser
DEBUG - 2021-12-16 06:22:08 --> Total execution time: 0.0230
ERROR - 2021-12-16 06:26:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-16 06:26:46 --> Config Class Initialized
INFO - 2021-12-16 06:26:46 --> Hooks Class Initialized
DEBUG - 2021-12-16 06:26:46 --> UTF-8 Support Enabled
INFO - 2021-12-16 06:26:46 --> Utf8 Class Initialized
INFO - 2021-12-16 06:26:46 --> URI Class Initialized
DEBUG - 2021-12-16 06:26:46 --> No URI present. Default controller set.
INFO - 2021-12-16 06:26:46 --> Router Class Initialized
INFO - 2021-12-16 06:26:46 --> Output Class Initialized
INFO - 2021-12-16 06:26:46 --> Security Class Initialized
DEBUG - 2021-12-16 06:26:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 06:26:46 --> Input Class Initialized
INFO - 2021-12-16 06:26:46 --> Language Class Initialized
INFO - 2021-12-16 06:26:46 --> Loader Class Initialized
INFO - 2021-12-16 06:26:46 --> Helper loaded: url_helper
INFO - 2021-12-16 06:26:46 --> Helper loaded: form_helper
INFO - 2021-12-16 06:26:46 --> Helper loaded: common_helper
INFO - 2021-12-16 06:26:46 --> Database Driver Class Initialized
DEBUG - 2021-12-16 06:26:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 06:26:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 06:26:46 --> Controller Class Initialized
INFO - 2021-12-16 06:26:46 --> Form Validation Class Initialized
DEBUG - 2021-12-16 06:26:46 --> Encrypt Class Initialized
DEBUG - 2021-12-16 06:26:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-16 06:26:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-16 06:26:46 --> Email Class Initialized
INFO - 2021-12-16 06:26:46 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-16 06:26:46 --> Calendar Class Initialized
INFO - 2021-12-16 06:26:46 --> Model "Login_model" initialized
INFO - 2021-12-16 06:26:46 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-16 06:26:46 --> Final output sent to browser
DEBUG - 2021-12-16 06:26:46 --> Total execution time: 0.0241
ERROR - 2021-12-16 06:29:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-16 06:29:04 --> Config Class Initialized
INFO - 2021-12-16 06:29:04 --> Hooks Class Initialized
DEBUG - 2021-12-16 06:29:04 --> UTF-8 Support Enabled
INFO - 2021-12-16 06:29:04 --> Utf8 Class Initialized
INFO - 2021-12-16 06:29:04 --> URI Class Initialized
INFO - 2021-12-16 06:29:04 --> Router Class Initialized
INFO - 2021-12-16 06:29:04 --> Output Class Initialized
INFO - 2021-12-16 06:29:04 --> Security Class Initialized
DEBUG - 2021-12-16 06:29:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 06:29:04 --> Input Class Initialized
INFO - 2021-12-16 06:29:04 --> Language Class Initialized
INFO - 2021-12-16 06:29:04 --> Loader Class Initialized
INFO - 2021-12-16 06:29:04 --> Helper loaded: url_helper
INFO - 2021-12-16 06:29:04 --> Helper loaded: form_helper
INFO - 2021-12-16 06:29:04 --> Helper loaded: common_helper
INFO - 2021-12-16 06:29:04 --> Database Driver Class Initialized
DEBUG - 2021-12-16 06:29:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 06:29:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 06:29:04 --> Controller Class Initialized
INFO - 2021-12-16 06:29:04 --> Form Validation Class Initialized
DEBUG - 2021-12-16 06:29:04 --> Encrypt Class Initialized
INFO - 2021-12-16 06:29:04 --> Model "Login_model" initialized
INFO - 2021-12-16 06:29:04 --> Model "Dashboard_model" initialized
INFO - 2021-12-16 06:29:04 --> Model "Case_model" initialized
ERROR - 2021-12-16 06:29:04 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'GROUP BY  CALCULATEAGE(YEAR(patient_dob))
     
     UNION 
     
  SELECT calcu' at line 7 - Invalid query: SELECT SUM(TotalPatient) as TotalPatient ,AgeGroup
FROM
( 
SELECT CALCULATEAGE(YEAR(patient_dob)) AS AgeGroup, COUNT(CALCULATEAGE(YEAR(patient_dob)))  AS TotalPatient FROM patient_master
       
    WHERE  IFNULL(`status`,0)!= '1' AND patient_dob IS NOT NULL AND patient_dob != '0000-00-00'  AND patient_master.created_by = 
     GROUP BY  CALCULATEAGE(YEAR(patient_dob))
     
     UNION 
     
  SELECT calculateWithoutDOBAge(SUBSTRING(patient_age,1,2)) AS AgeGroup, COUNT(calculateWithoutDOBAge(SUBSTRING(patient_age,1,2))) AS 
  TotalPatient FROM patient_master WHERE IFNULL(`status`,0)!= '1' AND IFNULL(patient_dob,'')='0000-00-00'  AND IFNULL(patient_age,'')!=''  AND patient_master.created_by = 
        GROUP BY calculateWithoutDOBAge(SUBSTRING(patient_age,1,2))
        )B GROUP BY AgeGroup
INFO - 2021-12-16 06:29:04 --> Language file loaded: language/english/db_lang.php
ERROR - 2021-12-16 06:37:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-16 06:37:50 --> Config Class Initialized
INFO - 2021-12-16 06:37:50 --> Hooks Class Initialized
DEBUG - 2021-12-16 06:37:50 --> UTF-8 Support Enabled
INFO - 2021-12-16 06:37:50 --> Utf8 Class Initialized
INFO - 2021-12-16 06:37:50 --> URI Class Initialized
DEBUG - 2021-12-16 06:37:50 --> No URI present. Default controller set.
INFO - 2021-12-16 06:37:50 --> Router Class Initialized
INFO - 2021-12-16 06:37:50 --> Output Class Initialized
INFO - 2021-12-16 06:37:50 --> Security Class Initialized
DEBUG - 2021-12-16 06:37:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 06:37:50 --> Input Class Initialized
INFO - 2021-12-16 06:37:50 --> Language Class Initialized
INFO - 2021-12-16 06:37:50 --> Loader Class Initialized
INFO - 2021-12-16 06:37:50 --> Helper loaded: url_helper
INFO - 2021-12-16 06:37:50 --> Helper loaded: form_helper
INFO - 2021-12-16 06:37:50 --> Helper loaded: common_helper
INFO - 2021-12-16 06:37:50 --> Database Driver Class Initialized
DEBUG - 2021-12-16 06:37:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 06:37:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 06:37:50 --> Controller Class Initialized
INFO - 2021-12-16 06:37:50 --> Form Validation Class Initialized
DEBUG - 2021-12-16 06:37:50 --> Encrypt Class Initialized
DEBUG - 2021-12-16 06:37:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-16 06:37:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-16 06:37:50 --> Email Class Initialized
INFO - 2021-12-16 06:37:50 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-16 06:37:50 --> Calendar Class Initialized
INFO - 2021-12-16 06:37:50 --> Model "Login_model" initialized
INFO - 2021-12-16 06:37:50 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-16 06:37:50 --> Final output sent to browser
DEBUG - 2021-12-16 06:37:50 --> Total execution time: 0.0323
ERROR - 2021-12-16 06:38:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-16 06:38:32 --> Config Class Initialized
INFO - 2021-12-16 06:38:32 --> Hooks Class Initialized
DEBUG - 2021-12-16 06:38:32 --> UTF-8 Support Enabled
INFO - 2021-12-16 06:38:32 --> Utf8 Class Initialized
INFO - 2021-12-16 06:38:32 --> URI Class Initialized
INFO - 2021-12-16 06:38:32 --> Router Class Initialized
INFO - 2021-12-16 06:38:32 --> Output Class Initialized
INFO - 2021-12-16 06:38:32 --> Security Class Initialized
DEBUG - 2021-12-16 06:38:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 06:38:32 --> Input Class Initialized
INFO - 2021-12-16 06:38:32 --> Language Class Initialized
INFO - 2021-12-16 06:38:32 --> Loader Class Initialized
INFO - 2021-12-16 06:38:32 --> Helper loaded: url_helper
INFO - 2021-12-16 06:38:32 --> Helper loaded: form_helper
INFO - 2021-12-16 06:38:32 --> Helper loaded: common_helper
INFO - 2021-12-16 06:38:32 --> Database Driver Class Initialized
DEBUG - 2021-12-16 06:38:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 06:38:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 06:38:32 --> Controller Class Initialized
INFO - 2021-12-16 06:38:32 --> Form Validation Class Initialized
DEBUG - 2021-12-16 06:38:32 --> Encrypt Class Initialized
DEBUG - 2021-12-16 06:38:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-16 06:38:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-16 06:38:32 --> Email Class Initialized
INFO - 2021-12-16 06:38:32 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-16 06:38:32 --> Calendar Class Initialized
INFO - 2021-12-16 06:38:32 --> Model "Login_model" initialized
INFO - 2021-12-16 06:38:32 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2021-12-16 06:38:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-16 06:38:33 --> Config Class Initialized
INFO - 2021-12-16 06:38:33 --> Hooks Class Initialized
DEBUG - 2021-12-16 06:38:33 --> UTF-8 Support Enabled
INFO - 2021-12-16 06:38:33 --> Utf8 Class Initialized
INFO - 2021-12-16 06:38:33 --> URI Class Initialized
INFO - 2021-12-16 06:38:33 --> Router Class Initialized
INFO - 2021-12-16 06:38:33 --> Output Class Initialized
INFO - 2021-12-16 06:38:33 --> Security Class Initialized
DEBUG - 2021-12-16 06:38:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 06:38:33 --> Input Class Initialized
INFO - 2021-12-16 06:38:33 --> Language Class Initialized
INFO - 2021-12-16 06:38:33 --> Loader Class Initialized
INFO - 2021-12-16 06:38:33 --> Helper loaded: url_helper
INFO - 2021-12-16 06:38:33 --> Helper loaded: form_helper
INFO - 2021-12-16 06:38:33 --> Helper loaded: common_helper
INFO - 2021-12-16 06:38:33 --> Database Driver Class Initialized
DEBUG - 2021-12-16 06:38:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 06:38:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 06:38:33 --> Controller Class Initialized
INFO - 2021-12-16 06:38:33 --> Form Validation Class Initialized
DEBUG - 2021-12-16 06:38:33 --> Encrypt Class Initialized
INFO - 2021-12-16 06:38:33 --> Model "Login_model" initialized
INFO - 2021-12-16 06:38:33 --> Model "Dashboard_model" initialized
INFO - 2021-12-16 06:38:33 --> Model "Case_model" initialized
ERROR - 2021-12-16 06:38:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-16 06:38:35 --> Config Class Initialized
INFO - 2021-12-16 06:38:35 --> Hooks Class Initialized
DEBUG - 2021-12-16 06:38:35 --> UTF-8 Support Enabled
INFO - 2021-12-16 06:38:35 --> Utf8 Class Initialized
INFO - 2021-12-16 06:38:35 --> URI Class Initialized
INFO - 2021-12-16 06:38:35 --> Router Class Initialized
INFO - 2021-12-16 06:38:35 --> Output Class Initialized
INFO - 2021-12-16 06:38:35 --> Security Class Initialized
DEBUG - 2021-12-16 06:38:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 06:38:35 --> Input Class Initialized
INFO - 2021-12-16 06:38:35 --> Language Class Initialized
INFO - 2021-12-16 06:38:35 --> Loader Class Initialized
INFO - 2021-12-16 06:38:35 --> Helper loaded: url_helper
INFO - 2021-12-16 06:38:35 --> Helper loaded: form_helper
INFO - 2021-12-16 06:38:35 --> Helper loaded: common_helper
INFO - 2021-12-16 06:38:35 --> Database Driver Class Initialized
DEBUG - 2021-12-16 06:38:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 06:38:45 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-16 06:38:55 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2021-12-16 06:38:55 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-16 06:38:55 --> Final output sent to browser
DEBUG - 2021-12-16 06:38:55 --> Total execution time: 21.5205
INFO - 2021-12-16 06:38:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 06:38:55 --> Controller Class Initialized
INFO - 2021-12-16 06:38:55 --> Form Validation Class Initialized
DEBUG - 2021-12-16 06:38:55 --> Encrypt Class Initialized
DEBUG - 2021-12-16 06:38:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-16 06:38:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-16 06:38:55 --> Email Class Initialized
INFO - 2021-12-16 06:38:55 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-16 06:38:55 --> Calendar Class Initialized
INFO - 2021-12-16 06:38:55 --> Model "Login_model" initialized
INFO - 2021-12-16 06:38:55 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2021-12-16 06:38:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-16 06:38:55 --> Config Class Initialized
INFO - 2021-12-16 06:38:55 --> Hooks Class Initialized
DEBUG - 2021-12-16 06:38:55 --> UTF-8 Support Enabled
INFO - 2021-12-16 06:38:55 --> Utf8 Class Initialized
INFO - 2021-12-16 06:38:55 --> URI Class Initialized
INFO - 2021-12-16 06:38:55 --> Router Class Initialized
INFO - 2021-12-16 06:38:55 --> Output Class Initialized
INFO - 2021-12-16 06:38:55 --> Security Class Initialized
DEBUG - 2021-12-16 06:38:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 06:38:55 --> Input Class Initialized
INFO - 2021-12-16 06:38:55 --> Language Class Initialized
INFO - 2021-12-16 06:38:55 --> Loader Class Initialized
INFO - 2021-12-16 06:38:55 --> Helper loaded: url_helper
INFO - 2021-12-16 06:38:55 --> Helper loaded: form_helper
INFO - 2021-12-16 06:38:55 --> Helper loaded: common_helper
INFO - 2021-12-16 06:38:55 --> Database Driver Class Initialized
DEBUG - 2021-12-16 06:38:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 06:38:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 06:38:55 --> Controller Class Initialized
INFO - 2021-12-16 06:38:55 --> Form Validation Class Initialized
DEBUG - 2021-12-16 06:38:55 --> Encrypt Class Initialized
INFO - 2021-12-16 06:38:55 --> Model "Login_model" initialized
INFO - 2021-12-16 06:38:55 --> Model "Dashboard_model" initialized
INFO - 2021-12-16 06:38:55 --> Model "Case_model" initialized
INFO - 2021-12-16 06:39:05 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-16 06:39:15 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2021-12-16 06:39:15 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-16 06:39:15 --> Final output sent to browser
DEBUG - 2021-12-16 06:39:15 --> Total execution time: 19.5647
ERROR - 2021-12-16 06:39:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-16 06:39:16 --> Config Class Initialized
INFO - 2021-12-16 06:39:16 --> Hooks Class Initialized
DEBUG - 2021-12-16 06:39:16 --> UTF-8 Support Enabled
INFO - 2021-12-16 06:39:16 --> Utf8 Class Initialized
INFO - 2021-12-16 06:39:16 --> URI Class Initialized
INFO - 2021-12-16 06:39:16 --> Router Class Initialized
INFO - 2021-12-16 06:39:16 --> Output Class Initialized
INFO - 2021-12-16 06:39:16 --> Security Class Initialized
DEBUG - 2021-12-16 06:39:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 06:39:16 --> Input Class Initialized
INFO - 2021-12-16 06:39:16 --> Language Class Initialized
ERROR - 2021-12-16 06:39:16 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-12-16 06:44:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-16 06:44:56 --> Config Class Initialized
INFO - 2021-12-16 06:44:56 --> Hooks Class Initialized
DEBUG - 2021-12-16 06:44:56 --> UTF-8 Support Enabled
INFO - 2021-12-16 06:44:56 --> Utf8 Class Initialized
INFO - 2021-12-16 06:44:56 --> URI Class Initialized
INFO - 2021-12-16 06:44:56 --> Router Class Initialized
INFO - 2021-12-16 06:44:56 --> Output Class Initialized
INFO - 2021-12-16 06:44:56 --> Security Class Initialized
DEBUG - 2021-12-16 06:44:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 06:44:56 --> Input Class Initialized
INFO - 2021-12-16 06:44:56 --> Language Class Initialized
INFO - 2021-12-16 06:44:56 --> Loader Class Initialized
INFO - 2021-12-16 06:44:56 --> Helper loaded: url_helper
INFO - 2021-12-16 06:44:56 --> Helper loaded: form_helper
INFO - 2021-12-16 06:44:56 --> Helper loaded: common_helper
INFO - 2021-12-16 06:44:56 --> Database Driver Class Initialized
DEBUG - 2021-12-16 06:44:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 06:44:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 06:44:56 --> Controller Class Initialized
INFO - 2021-12-16 06:44:56 --> Form Validation Class Initialized
DEBUG - 2021-12-16 06:44:56 --> Encrypt Class Initialized
INFO - 2021-12-16 06:44:56 --> Model "Login_model" initialized
INFO - 2021-12-16 06:44:56 --> Model "Dashboard_model" initialized
INFO - 2021-12-16 06:44:56 --> Model "Case_model" initialized
ERROR - 2021-12-16 06:44:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-16 06:44:59 --> Config Class Initialized
INFO - 2021-12-16 06:44:59 --> Hooks Class Initialized
DEBUG - 2021-12-16 06:44:59 --> UTF-8 Support Enabled
INFO - 2021-12-16 06:44:59 --> Utf8 Class Initialized
INFO - 2021-12-16 06:44:59 --> URI Class Initialized
INFO - 2021-12-16 06:44:59 --> Router Class Initialized
INFO - 2021-12-16 06:44:59 --> Output Class Initialized
INFO - 2021-12-16 06:44:59 --> Security Class Initialized
DEBUG - 2021-12-16 06:44:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 06:44:59 --> Input Class Initialized
INFO - 2021-12-16 06:44:59 --> Language Class Initialized
INFO - 2021-12-16 06:44:59 --> Loader Class Initialized
INFO - 2021-12-16 06:44:59 --> Helper loaded: url_helper
INFO - 2021-12-16 06:44:59 --> Helper loaded: form_helper
INFO - 2021-12-16 06:44:59 --> Helper loaded: common_helper
INFO - 2021-12-16 06:44:59 --> Database Driver Class Initialized
DEBUG - 2021-12-16 06:44:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 06:44:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 06:44:59 --> Controller Class Initialized
INFO - 2021-12-16 06:44:59 --> Form Validation Class Initialized
DEBUG - 2021-12-16 06:44:59 --> Encrypt Class Initialized
INFO - 2021-12-16 06:44:59 --> Model "Login_model" initialized
INFO - 2021-12-16 06:44:59 --> Model "Dashboard_model" initialized
INFO - 2021-12-16 06:44:59 --> Model "Case_model" initialized
INFO - 2021-12-16 06:45:11 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-16 06:45:13 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-16 06:45:22 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2021-12-16 06:45:22 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-16 06:45:22 --> Final output sent to browser
DEBUG - 2021-12-16 06:45:22 --> Total execution time: 25.3143
INFO - 2021-12-16 06:45:24 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2021-12-16 06:45:24 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-16 06:45:24 --> Final output sent to browser
DEBUG - 2021-12-16 06:45:24 --> Total execution time: 24.7544
ERROR - 2021-12-16 06:45:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-16 06:45:28 --> Config Class Initialized
INFO - 2021-12-16 06:45:28 --> Hooks Class Initialized
DEBUG - 2021-12-16 06:45:28 --> UTF-8 Support Enabled
INFO - 2021-12-16 06:45:28 --> Utf8 Class Initialized
INFO - 2021-12-16 06:45:28 --> URI Class Initialized
INFO - 2021-12-16 06:45:28 --> Router Class Initialized
INFO - 2021-12-16 06:45:28 --> Output Class Initialized
INFO - 2021-12-16 06:45:28 --> Security Class Initialized
DEBUG - 2021-12-16 06:45:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 06:45:28 --> Input Class Initialized
INFO - 2021-12-16 06:45:28 --> Language Class Initialized
ERROR - 2021-12-16 06:45:28 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-12-16 06:46:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-16 06:46:16 --> Config Class Initialized
INFO - 2021-12-16 06:46:16 --> Hooks Class Initialized
DEBUG - 2021-12-16 06:46:16 --> UTF-8 Support Enabled
INFO - 2021-12-16 06:46:16 --> Utf8 Class Initialized
INFO - 2021-12-16 06:46:16 --> URI Class Initialized
INFO - 2021-12-16 06:46:16 --> Router Class Initialized
INFO - 2021-12-16 06:46:16 --> Output Class Initialized
INFO - 2021-12-16 06:46:16 --> Security Class Initialized
DEBUG - 2021-12-16 06:46:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 06:46:16 --> Input Class Initialized
INFO - 2021-12-16 06:46:16 --> Language Class Initialized
INFO - 2021-12-16 06:46:16 --> Loader Class Initialized
INFO - 2021-12-16 06:46:16 --> Helper loaded: url_helper
INFO - 2021-12-16 06:46:16 --> Helper loaded: form_helper
INFO - 2021-12-16 06:46:16 --> Helper loaded: common_helper
INFO - 2021-12-16 06:46:16 --> Database Driver Class Initialized
DEBUG - 2021-12-16 06:46:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 06:46:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 06:46:16 --> Controller Class Initialized
INFO - 2021-12-16 06:46:16 --> Form Validation Class Initialized
DEBUG - 2021-12-16 06:46:16 --> Encrypt Class Initialized
INFO - 2021-12-16 06:46:16 --> Model "Login_model" initialized
INFO - 2021-12-16 06:46:16 --> Model "Dashboard_model" initialized
INFO - 2021-12-16 06:46:16 --> Model "Case_model" initialized
INFO - 2021-12-16 06:46:24 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-16 06:46:34 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2021-12-16 06:46:34 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-16 06:46:34 --> Final output sent to browser
DEBUG - 2021-12-16 06:46:34 --> Total execution time: 17.6101
ERROR - 2021-12-16 06:46:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-16 06:46:35 --> Config Class Initialized
INFO - 2021-12-16 06:46:35 --> Hooks Class Initialized
DEBUG - 2021-12-16 06:46:35 --> UTF-8 Support Enabled
INFO - 2021-12-16 06:46:35 --> Utf8 Class Initialized
INFO - 2021-12-16 06:46:35 --> URI Class Initialized
INFO - 2021-12-16 06:46:35 --> Router Class Initialized
INFO - 2021-12-16 06:46:35 --> Output Class Initialized
INFO - 2021-12-16 06:46:35 --> Security Class Initialized
DEBUG - 2021-12-16 06:46:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 06:46:35 --> Input Class Initialized
INFO - 2021-12-16 06:46:35 --> Language Class Initialized
ERROR - 2021-12-16 06:46:35 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-12-16 06:47:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-16 06:47:14 --> Config Class Initialized
INFO - 2021-12-16 06:47:14 --> Hooks Class Initialized
DEBUG - 2021-12-16 06:47:14 --> UTF-8 Support Enabled
INFO - 2021-12-16 06:47:14 --> Utf8 Class Initialized
INFO - 2021-12-16 06:47:14 --> URI Class Initialized
INFO - 2021-12-16 06:47:14 --> Router Class Initialized
INFO - 2021-12-16 06:47:14 --> Output Class Initialized
INFO - 2021-12-16 06:47:14 --> Security Class Initialized
DEBUG - 2021-12-16 06:47:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 06:47:14 --> Input Class Initialized
INFO - 2021-12-16 06:47:14 --> Language Class Initialized
INFO - 2021-12-16 06:47:14 --> Loader Class Initialized
INFO - 2021-12-16 06:47:14 --> Helper loaded: url_helper
INFO - 2021-12-16 06:47:14 --> Helper loaded: form_helper
INFO - 2021-12-16 06:47:14 --> Helper loaded: common_helper
INFO - 2021-12-16 06:47:14 --> Database Driver Class Initialized
DEBUG - 2021-12-16 06:47:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 06:47:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 06:47:14 --> Controller Class Initialized
INFO - 2021-12-16 06:47:14 --> Form Validation Class Initialized
DEBUG - 2021-12-16 06:47:14 --> Encrypt Class Initialized
INFO - 2021-12-16 06:47:14 --> Model "Login_model" initialized
INFO - 2021-12-16 06:47:14 --> Model "Dashboard_model" initialized
INFO - 2021-12-16 06:47:14 --> Model "Case_model" initialized
INFO - 2021-12-16 06:47:24 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-16 06:47:33 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2021-12-16 06:47:33 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-16 06:47:33 --> Final output sent to browser
DEBUG - 2021-12-16 06:47:33 --> Total execution time: 18.6077
ERROR - 2021-12-16 06:47:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-16 06:47:35 --> Config Class Initialized
INFO - 2021-12-16 06:47:35 --> Hooks Class Initialized
DEBUG - 2021-12-16 06:47:35 --> UTF-8 Support Enabled
INFO - 2021-12-16 06:47:35 --> Utf8 Class Initialized
INFO - 2021-12-16 06:47:35 --> URI Class Initialized
INFO - 2021-12-16 06:47:35 --> Router Class Initialized
INFO - 2021-12-16 06:47:35 --> Output Class Initialized
INFO - 2021-12-16 06:47:35 --> Security Class Initialized
DEBUG - 2021-12-16 06:47:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 06:47:35 --> Input Class Initialized
INFO - 2021-12-16 06:47:35 --> Language Class Initialized
ERROR - 2021-12-16 06:47:35 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-12-16 06:48:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-16 06:48:08 --> Config Class Initialized
INFO - 2021-12-16 06:48:08 --> Hooks Class Initialized
DEBUG - 2021-12-16 06:48:08 --> UTF-8 Support Enabled
INFO - 2021-12-16 06:48:08 --> Utf8 Class Initialized
INFO - 2021-12-16 06:48:08 --> URI Class Initialized
INFO - 2021-12-16 06:48:08 --> Router Class Initialized
INFO - 2021-12-16 06:48:08 --> Output Class Initialized
INFO - 2021-12-16 06:48:08 --> Security Class Initialized
DEBUG - 2021-12-16 06:48:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 06:48:08 --> Input Class Initialized
INFO - 2021-12-16 06:48:08 --> Language Class Initialized
INFO - 2021-12-16 06:48:08 --> Loader Class Initialized
INFO - 2021-12-16 06:48:08 --> Helper loaded: url_helper
INFO - 2021-12-16 06:48:08 --> Helper loaded: form_helper
INFO - 2021-12-16 06:48:08 --> Helper loaded: common_helper
INFO - 2021-12-16 06:48:08 --> Database Driver Class Initialized
DEBUG - 2021-12-16 06:48:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 06:48:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 06:48:08 --> Controller Class Initialized
INFO - 2021-12-16 06:48:08 --> Form Validation Class Initialized
DEBUG - 2021-12-16 06:48:08 --> Encrypt Class Initialized
INFO - 2021-12-16 06:48:08 --> Model "Login_model" initialized
INFO - 2021-12-16 06:48:08 --> Model "Dashboard_model" initialized
INFO - 2021-12-16 06:48:08 --> Model "Case_model" initialized
INFO - 2021-12-16 06:48:16 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-16 06:48:27 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2021-12-16 06:48:27 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-16 06:48:27 --> Final output sent to browser
DEBUG - 2021-12-16 06:48:27 --> Total execution time: 18.9352
ERROR - 2021-12-16 06:48:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-16 06:48:29 --> Config Class Initialized
INFO - 2021-12-16 06:48:29 --> Hooks Class Initialized
DEBUG - 2021-12-16 06:48:29 --> UTF-8 Support Enabled
INFO - 2021-12-16 06:48:29 --> Utf8 Class Initialized
INFO - 2021-12-16 06:48:29 --> URI Class Initialized
INFO - 2021-12-16 06:48:29 --> Router Class Initialized
INFO - 2021-12-16 06:48:29 --> Output Class Initialized
INFO - 2021-12-16 06:48:29 --> Security Class Initialized
DEBUG - 2021-12-16 06:48:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 06:48:29 --> Input Class Initialized
INFO - 2021-12-16 06:48:29 --> Language Class Initialized
ERROR - 2021-12-16 06:48:29 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-12-16 06:51:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-16 06:51:36 --> Config Class Initialized
INFO - 2021-12-16 06:51:36 --> Hooks Class Initialized
DEBUG - 2021-12-16 06:51:36 --> UTF-8 Support Enabled
INFO - 2021-12-16 06:51:36 --> Utf8 Class Initialized
INFO - 2021-12-16 06:51:36 --> URI Class Initialized
INFO - 2021-12-16 06:51:36 --> Router Class Initialized
INFO - 2021-12-16 06:51:36 --> Output Class Initialized
INFO - 2021-12-16 06:51:36 --> Security Class Initialized
DEBUG - 2021-12-16 06:51:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 06:51:36 --> Input Class Initialized
INFO - 2021-12-16 06:51:36 --> Language Class Initialized
INFO - 2021-12-16 06:51:36 --> Loader Class Initialized
INFO - 2021-12-16 06:51:36 --> Helper loaded: url_helper
INFO - 2021-12-16 06:51:36 --> Helper loaded: form_helper
INFO - 2021-12-16 06:51:36 --> Helper loaded: common_helper
INFO - 2021-12-16 06:51:36 --> Database Driver Class Initialized
DEBUG - 2021-12-16 06:51:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 06:51:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 06:51:36 --> Controller Class Initialized
INFO - 2021-12-16 06:51:36 --> Form Validation Class Initialized
DEBUG - 2021-12-16 06:51:36 --> Encrypt Class Initialized
INFO - 2021-12-16 06:51:36 --> Model "Login_model" initialized
INFO - 2021-12-16 06:51:36 --> Model "Dashboard_model" initialized
INFO - 2021-12-16 06:51:36 --> Model "Case_model" initialized
ERROR - 2021-12-16 06:51:36 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'GROUP BY  CALCULATEAGE(YEAR(patient_dob))
     
     UNION 
     
  SELECT calcu' at line 7 - Invalid query: SELECT SUM(TotalPatient) as TotalPatient ,AgeGroup
FROM
( 
SELECT CALCULATEAGE(YEAR(patient_dob)) AS AgeGroup, COUNT(CALCULATEAGE(YEAR(patient_dob)))  AS TotalPatient FROM patient_master
       
    WHERE  IFNULL(`status`,0)!= '1' AND patient_dob IS NOT NULL AND patient_dob != '0000-00-00'  AND patient_master.created_by = 
     GROUP BY  CALCULATEAGE(YEAR(patient_dob))
     
     UNION 
     
  SELECT calculateWithoutDOBAge(SUBSTRING(patient_age,1,2)) AS AgeGroup, COUNT(calculateWithoutDOBAge(SUBSTRING(patient_age,1,2))) AS 
  TotalPatient FROM patient_master WHERE IFNULL(`status`,0)!= '1' AND IFNULL(patient_dob,'')='0000-00-00'  AND IFNULL(patient_age,'')!=''  AND patient_master.created_by = 
        GROUP BY calculateWithoutDOBAge(SUBSTRING(patient_age,1,2))
        )B GROUP BY AgeGroup
INFO - 2021-12-16 06:51:36 --> Language file loaded: language/english/db_lang.php
ERROR - 2021-12-16 06:51:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-16 06:51:43 --> Config Class Initialized
INFO - 2021-12-16 06:51:43 --> Hooks Class Initialized
DEBUG - 2021-12-16 06:51:43 --> UTF-8 Support Enabled
INFO - 2021-12-16 06:51:43 --> Utf8 Class Initialized
INFO - 2021-12-16 06:51:43 --> URI Class Initialized
DEBUG - 2021-12-16 06:51:43 --> No URI present. Default controller set.
INFO - 2021-12-16 06:51:43 --> Router Class Initialized
INFO - 2021-12-16 06:51:43 --> Output Class Initialized
INFO - 2021-12-16 06:51:43 --> Security Class Initialized
DEBUG - 2021-12-16 06:51:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 06:51:43 --> Input Class Initialized
INFO - 2021-12-16 06:51:43 --> Language Class Initialized
INFO - 2021-12-16 06:51:43 --> Loader Class Initialized
INFO - 2021-12-16 06:51:43 --> Helper loaded: url_helper
INFO - 2021-12-16 06:51:43 --> Helper loaded: form_helper
INFO - 2021-12-16 06:51:43 --> Helper loaded: common_helper
INFO - 2021-12-16 06:51:43 --> Database Driver Class Initialized
DEBUG - 2021-12-16 06:51:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 06:51:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 06:51:43 --> Controller Class Initialized
INFO - 2021-12-16 06:51:43 --> Form Validation Class Initialized
DEBUG - 2021-12-16 06:51:43 --> Encrypt Class Initialized
DEBUG - 2021-12-16 06:51:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-16 06:51:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-16 06:51:43 --> Email Class Initialized
INFO - 2021-12-16 06:51:43 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-16 06:51:43 --> Calendar Class Initialized
INFO - 2021-12-16 06:51:43 --> Model "Login_model" initialized
INFO - 2021-12-16 06:51:43 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-16 06:51:43 --> Final output sent to browser
DEBUG - 2021-12-16 06:51:43 --> Total execution time: 0.0500
ERROR - 2021-12-16 06:51:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-16 06:51:46 --> Config Class Initialized
INFO - 2021-12-16 06:51:46 --> Hooks Class Initialized
DEBUG - 2021-12-16 06:51:46 --> UTF-8 Support Enabled
INFO - 2021-12-16 06:51:46 --> Utf8 Class Initialized
INFO - 2021-12-16 06:51:46 --> URI Class Initialized
INFO - 2021-12-16 06:51:46 --> Router Class Initialized
INFO - 2021-12-16 06:51:46 --> Output Class Initialized
INFO - 2021-12-16 06:51:46 --> Security Class Initialized
DEBUG - 2021-12-16 06:51:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 06:51:46 --> Input Class Initialized
INFO - 2021-12-16 06:51:46 --> Language Class Initialized
INFO - 2021-12-16 06:51:46 --> Loader Class Initialized
INFO - 2021-12-16 06:51:46 --> Helper loaded: url_helper
INFO - 2021-12-16 06:51:46 --> Helper loaded: form_helper
INFO - 2021-12-16 06:51:46 --> Helper loaded: common_helper
INFO - 2021-12-16 06:51:46 --> Database Driver Class Initialized
DEBUG - 2021-12-16 06:51:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 06:51:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 06:51:46 --> Controller Class Initialized
INFO - 2021-12-16 06:51:46 --> Form Validation Class Initialized
DEBUG - 2021-12-16 06:51:46 --> Encrypt Class Initialized
DEBUG - 2021-12-16 06:51:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-16 06:51:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-16 06:51:46 --> Email Class Initialized
INFO - 2021-12-16 06:51:46 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-16 06:51:46 --> Calendar Class Initialized
INFO - 2021-12-16 06:51:46 --> Model "Login_model" initialized
INFO - 2021-12-16 06:51:46 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2021-12-16 06:51:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-16 06:51:47 --> Config Class Initialized
INFO - 2021-12-16 06:51:47 --> Hooks Class Initialized
DEBUG - 2021-12-16 06:51:47 --> UTF-8 Support Enabled
INFO - 2021-12-16 06:51:47 --> Utf8 Class Initialized
INFO - 2021-12-16 06:51:47 --> URI Class Initialized
INFO - 2021-12-16 06:51:47 --> Router Class Initialized
INFO - 2021-12-16 06:51:47 --> Output Class Initialized
INFO - 2021-12-16 06:51:47 --> Security Class Initialized
DEBUG - 2021-12-16 06:51:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 06:51:47 --> Input Class Initialized
INFO - 2021-12-16 06:51:47 --> Language Class Initialized
INFO - 2021-12-16 06:51:47 --> Loader Class Initialized
INFO - 2021-12-16 06:51:47 --> Helper loaded: url_helper
INFO - 2021-12-16 06:51:47 --> Helper loaded: form_helper
INFO - 2021-12-16 06:51:47 --> Helper loaded: common_helper
INFO - 2021-12-16 06:51:47 --> Database Driver Class Initialized
DEBUG - 2021-12-16 06:51:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 06:51:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 06:51:47 --> Controller Class Initialized
INFO - 2021-12-16 06:51:47 --> Form Validation Class Initialized
DEBUG - 2021-12-16 06:51:47 --> Encrypt Class Initialized
INFO - 2021-12-16 06:51:47 --> Model "Login_model" initialized
INFO - 2021-12-16 06:51:47 --> Model "Dashboard_model" initialized
INFO - 2021-12-16 06:51:47 --> Model "Case_model" initialized
ERROR - 2021-12-16 06:51:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-16 06:51:59 --> Config Class Initialized
INFO - 2021-12-16 06:51:59 --> Hooks Class Initialized
DEBUG - 2021-12-16 06:51:59 --> UTF-8 Support Enabled
INFO - 2021-12-16 06:51:59 --> Utf8 Class Initialized
INFO - 2021-12-16 06:51:59 --> URI Class Initialized
INFO - 2021-12-16 06:51:59 --> Router Class Initialized
INFO - 2021-12-16 06:51:59 --> Output Class Initialized
INFO - 2021-12-16 06:51:59 --> Security Class Initialized
DEBUG - 2021-12-16 06:51:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 06:51:59 --> Input Class Initialized
INFO - 2021-12-16 06:51:59 --> Language Class Initialized
INFO - 2021-12-16 06:51:59 --> Loader Class Initialized
INFO - 2021-12-16 06:51:59 --> Helper loaded: url_helper
INFO - 2021-12-16 06:51:59 --> Helper loaded: form_helper
INFO - 2021-12-16 06:51:59 --> Helper loaded: common_helper
INFO - 2021-12-16 06:51:59 --> Database Driver Class Initialized
DEBUG - 2021-12-16 06:51:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 06:52:00 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-16 06:52:14 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2021-12-16 06:52:14 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-16 06:52:14 --> Final output sent to browser
DEBUG - 2021-12-16 06:52:14 --> Total execution time: 27.2124
INFO - 2021-12-16 06:52:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 06:52:14 --> Controller Class Initialized
INFO - 2021-12-16 06:52:14 --> Form Validation Class Initialized
DEBUG - 2021-12-16 06:52:14 --> Encrypt Class Initialized
DEBUG - 2021-12-16 06:52:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-16 06:52:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-16 06:52:14 --> Email Class Initialized
INFO - 2021-12-16 06:52:14 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-16 06:52:14 --> Calendar Class Initialized
INFO - 2021-12-16 06:52:14 --> Model "Login_model" initialized
INFO - 2021-12-16 06:52:14 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2021-12-16 06:52:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-16 06:52:15 --> Config Class Initialized
INFO - 2021-12-16 06:52:15 --> Hooks Class Initialized
DEBUG - 2021-12-16 06:52:15 --> UTF-8 Support Enabled
INFO - 2021-12-16 06:52:15 --> Utf8 Class Initialized
INFO - 2021-12-16 06:52:15 --> URI Class Initialized
INFO - 2021-12-16 06:52:15 --> Router Class Initialized
INFO - 2021-12-16 06:52:15 --> Output Class Initialized
INFO - 2021-12-16 06:52:15 --> Security Class Initialized
DEBUG - 2021-12-16 06:52:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 06:52:15 --> Input Class Initialized
INFO - 2021-12-16 06:52:15 --> Language Class Initialized
INFO - 2021-12-16 06:52:15 --> Loader Class Initialized
INFO - 2021-12-16 06:52:15 --> Helper loaded: url_helper
INFO - 2021-12-16 06:52:15 --> Helper loaded: form_helper
INFO - 2021-12-16 06:52:15 --> Helper loaded: common_helper
INFO - 2021-12-16 06:52:15 --> Database Driver Class Initialized
DEBUG - 2021-12-16 06:52:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 06:52:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 06:52:15 --> Controller Class Initialized
INFO - 2021-12-16 06:52:15 --> Form Validation Class Initialized
DEBUG - 2021-12-16 06:52:15 --> Encrypt Class Initialized
INFO - 2021-12-16 06:52:15 --> Model "Login_model" initialized
INFO - 2021-12-16 06:52:15 --> Model "Dashboard_model" initialized
INFO - 2021-12-16 06:52:15 --> Model "Case_model" initialized
INFO - 2021-12-16 06:52:27 --> File loaded: /home3/karoteam/public_html/application/views/header.php
ERROR - 2021-12-16 06:52:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-16 06:52:34 --> Config Class Initialized
INFO - 2021-12-16 06:52:34 --> Hooks Class Initialized
DEBUG - 2021-12-16 06:52:34 --> UTF-8 Support Enabled
INFO - 2021-12-16 06:52:34 --> Utf8 Class Initialized
INFO - 2021-12-16 06:52:34 --> URI Class Initialized
INFO - 2021-12-16 06:52:34 --> Router Class Initialized
INFO - 2021-12-16 06:52:34 --> Output Class Initialized
INFO - 2021-12-16 06:52:34 --> Security Class Initialized
DEBUG - 2021-12-16 06:52:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 06:52:34 --> Input Class Initialized
INFO - 2021-12-16 06:52:34 --> Language Class Initialized
INFO - 2021-12-16 06:52:34 --> Loader Class Initialized
INFO - 2021-12-16 06:52:34 --> Helper loaded: url_helper
INFO - 2021-12-16 06:52:34 --> Helper loaded: form_helper
INFO - 2021-12-16 06:52:34 --> Helper loaded: common_helper
INFO - 2021-12-16 06:52:34 --> Database Driver Class Initialized
DEBUG - 2021-12-16 06:52:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 06:52:38 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2021-12-16 06:52:38 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-16 06:52:38 --> Final output sent to browser
DEBUG - 2021-12-16 06:52:38 --> Total execution time: 23.6722
INFO - 2021-12-16 06:52:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 06:52:38 --> Controller Class Initialized
INFO - 2021-12-16 06:52:38 --> Form Validation Class Initialized
DEBUG - 2021-12-16 06:52:38 --> Encrypt Class Initialized
DEBUG - 2021-12-16 06:52:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-16 06:52:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-16 06:52:38 --> Email Class Initialized
INFO - 2021-12-16 06:52:38 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-16 06:52:38 --> Calendar Class Initialized
INFO - 2021-12-16 06:52:38 --> Model "Login_model" initialized
INFO - 2021-12-16 06:52:38 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2021-12-16 06:52:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-16 06:52:39 --> Config Class Initialized
INFO - 2021-12-16 06:52:39 --> Hooks Class Initialized
DEBUG - 2021-12-16 06:52:39 --> UTF-8 Support Enabled
INFO - 2021-12-16 06:52:39 --> Utf8 Class Initialized
INFO - 2021-12-16 06:52:39 --> URI Class Initialized
INFO - 2021-12-16 06:52:39 --> Router Class Initialized
INFO - 2021-12-16 06:52:39 --> Output Class Initialized
INFO - 2021-12-16 06:52:39 --> Security Class Initialized
DEBUG - 2021-12-16 06:52:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 06:52:39 --> Input Class Initialized
INFO - 2021-12-16 06:52:39 --> Language Class Initialized
INFO - 2021-12-16 06:52:39 --> Loader Class Initialized
INFO - 2021-12-16 06:52:39 --> Helper loaded: url_helper
INFO - 2021-12-16 06:52:39 --> Helper loaded: form_helper
INFO - 2021-12-16 06:52:39 --> Helper loaded: common_helper
INFO - 2021-12-16 06:52:39 --> Database Driver Class Initialized
DEBUG - 2021-12-16 06:52:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 06:52:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 06:52:39 --> Controller Class Initialized
INFO - 2021-12-16 06:52:39 --> Form Validation Class Initialized
DEBUG - 2021-12-16 06:52:39 --> Encrypt Class Initialized
INFO - 2021-12-16 06:52:39 --> Model "Login_model" initialized
INFO - 2021-12-16 06:52:39 --> Model "Dashboard_model" initialized
INFO - 2021-12-16 06:52:39 --> Model "Case_model" initialized
INFO - 2021-12-16 06:52:50 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-16 06:53:02 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2021-12-16 06:53:02 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-16 06:53:02 --> Final output sent to browser
DEBUG - 2021-12-16 06:53:02 --> Total execution time: 23.3702
ERROR - 2021-12-16 06:53:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-16 06:53:03 --> Config Class Initialized
INFO - 2021-12-16 06:53:03 --> Hooks Class Initialized
DEBUG - 2021-12-16 06:53:03 --> UTF-8 Support Enabled
INFO - 2021-12-16 06:53:03 --> Utf8 Class Initialized
INFO - 2021-12-16 06:53:03 --> URI Class Initialized
INFO - 2021-12-16 06:53:03 --> Router Class Initialized
INFO - 2021-12-16 06:53:03 --> Output Class Initialized
INFO - 2021-12-16 06:53:03 --> Security Class Initialized
DEBUG - 2021-12-16 06:53:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 06:53:03 --> Input Class Initialized
INFO - 2021-12-16 06:53:03 --> Language Class Initialized
ERROR - 2021-12-16 06:53:03 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-12-16 06:53:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-16 06:53:12 --> Config Class Initialized
INFO - 2021-12-16 06:53:12 --> Hooks Class Initialized
DEBUG - 2021-12-16 06:53:12 --> UTF-8 Support Enabled
INFO - 2021-12-16 06:53:12 --> Utf8 Class Initialized
INFO - 2021-12-16 06:53:12 --> URI Class Initialized
INFO - 2021-12-16 06:53:12 --> Router Class Initialized
INFO - 2021-12-16 06:53:12 --> Output Class Initialized
INFO - 2021-12-16 06:53:12 --> Security Class Initialized
DEBUG - 2021-12-16 06:53:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 06:53:12 --> Input Class Initialized
INFO - 2021-12-16 06:53:12 --> Language Class Initialized
INFO - 2021-12-16 06:53:12 --> Loader Class Initialized
INFO - 2021-12-16 06:53:12 --> Helper loaded: url_helper
INFO - 2021-12-16 06:53:12 --> Helper loaded: form_helper
INFO - 2021-12-16 06:53:12 --> Helper loaded: common_helper
INFO - 2021-12-16 06:53:12 --> Database Driver Class Initialized
DEBUG - 2021-12-16 06:53:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 06:53:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 06:53:12 --> Controller Class Initialized
INFO - 2021-12-16 06:53:12 --> Form Validation Class Initialized
DEBUG - 2021-12-16 06:53:12 --> Encrypt Class Initialized
INFO - 2021-12-16 06:53:12 --> Model "Patient_model" initialized
INFO - 2021-12-16 06:53:12 --> Model "Patientcase_model" initialized
INFO - 2021-12-16 06:53:12 --> Model "Referredby_model" initialized
INFO - 2021-12-16 06:53:12 --> Model "Prefix_master" initialized
INFO - 2021-12-16 06:53:12 --> Model "Hospital_model" initialized
INFO - 2021-12-16 06:53:12 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-16 06:53:12 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2021-12-16 06:53:12 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-16 06:53:12 --> Final output sent to browser
DEBUG - 2021-12-16 06:53:12 --> Total execution time: 0.0663
ERROR - 2021-12-16 06:53:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-16 06:53:13 --> Config Class Initialized
INFO - 2021-12-16 06:53:13 --> Hooks Class Initialized
DEBUG - 2021-12-16 06:53:13 --> UTF-8 Support Enabled
INFO - 2021-12-16 06:53:13 --> Utf8 Class Initialized
INFO - 2021-12-16 06:53:13 --> URI Class Initialized
INFO - 2021-12-16 06:53:13 --> Router Class Initialized
INFO - 2021-12-16 06:53:13 --> Output Class Initialized
INFO - 2021-12-16 06:53:13 --> Security Class Initialized
DEBUG - 2021-12-16 06:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 06:53:13 --> Input Class Initialized
INFO - 2021-12-16 06:53:13 --> Language Class Initialized
ERROR - 2021-12-16 06:53:13 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-12-16 06:53:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-16 06:53:15 --> Config Class Initialized
INFO - 2021-12-16 06:53:15 --> Hooks Class Initialized
DEBUG - 2021-12-16 06:53:15 --> UTF-8 Support Enabled
INFO - 2021-12-16 06:53:15 --> Utf8 Class Initialized
INFO - 2021-12-16 06:53:15 --> URI Class Initialized
INFO - 2021-12-16 06:53:15 --> Router Class Initialized
INFO - 2021-12-16 06:53:15 --> Output Class Initialized
INFO - 2021-12-16 06:53:15 --> Security Class Initialized
DEBUG - 2021-12-16 06:53:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 06:53:15 --> Input Class Initialized
INFO - 2021-12-16 06:53:15 --> Language Class Initialized
INFO - 2021-12-16 06:53:15 --> Loader Class Initialized
INFO - 2021-12-16 06:53:15 --> Helper loaded: url_helper
INFO - 2021-12-16 06:53:15 --> Helper loaded: form_helper
INFO - 2021-12-16 06:53:15 --> Helper loaded: common_helper
INFO - 2021-12-16 06:53:15 --> Database Driver Class Initialized
DEBUG - 2021-12-16 06:53:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 06:53:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 06:53:15 --> Controller Class Initialized
INFO - 2021-12-16 06:53:15 --> Form Validation Class Initialized
DEBUG - 2021-12-16 06:53:15 --> Encrypt Class Initialized
INFO - 2021-12-16 06:53:15 --> Model "Patient_model" initialized
INFO - 2021-12-16 06:53:15 --> Model "Patientcase_model" initialized
INFO - 2021-12-16 06:53:15 --> Model "Referredby_model" initialized
INFO - 2021-12-16 06:53:15 --> Model "Prefix_master" initialized
INFO - 2021-12-16 06:53:15 --> Model "Hospital_model" initialized
INFO - 2021-12-16 06:53:15 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-16 06:53:23 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2021-12-16 06:53:23 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
ERROR - 2021-12-16 06:53:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-16 06:53:25 --> Config Class Initialized
INFO - 2021-12-16 06:53:25 --> Hooks Class Initialized
DEBUG - 2021-12-16 06:53:25 --> UTF-8 Support Enabled
INFO - 2021-12-16 06:53:25 --> Utf8 Class Initialized
INFO - 2021-12-16 06:53:25 --> URI Class Initialized
INFO - 2021-12-16 06:53:25 --> Router Class Initialized
INFO - 2021-12-16 06:53:25 --> Output Class Initialized
INFO - 2021-12-16 06:53:25 --> Security Class Initialized
DEBUG - 2021-12-16 06:53:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 06:53:25 --> Input Class Initialized
INFO - 2021-12-16 06:53:25 --> Language Class Initialized
ERROR - 2021-12-16 06:53:25 --> 404 Page Not Found: Karoclient/usersprofile
INFO - 2021-12-16 06:53:30 --> Final output sent to browser
DEBUG - 2021-12-16 06:53:30 --> Total execution time: 8.1048
ERROR - 2021-12-16 06:53:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-16 06:53:48 --> Config Class Initialized
INFO - 2021-12-16 06:53:48 --> Hooks Class Initialized
DEBUG - 2021-12-16 06:53:48 --> UTF-8 Support Enabled
INFO - 2021-12-16 06:53:48 --> Utf8 Class Initialized
INFO - 2021-12-16 06:53:48 --> URI Class Initialized
INFO - 2021-12-16 06:53:48 --> Router Class Initialized
INFO - 2021-12-16 06:53:48 --> Output Class Initialized
INFO - 2021-12-16 06:53:48 --> Security Class Initialized
DEBUG - 2021-12-16 06:53:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 06:53:48 --> Input Class Initialized
INFO - 2021-12-16 06:53:48 --> Language Class Initialized
INFO - 2021-12-16 06:53:48 --> Loader Class Initialized
INFO - 2021-12-16 06:53:48 --> Helper loaded: url_helper
INFO - 2021-12-16 06:53:48 --> Helper loaded: form_helper
INFO - 2021-12-16 06:53:48 --> Helper loaded: common_helper
INFO - 2021-12-16 06:53:48 --> Database Driver Class Initialized
DEBUG - 2021-12-16 06:53:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 06:53:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 06:53:48 --> Controller Class Initialized
INFO - 2021-12-16 06:53:48 --> Form Validation Class Initialized
DEBUG - 2021-12-16 06:53:48 --> Encrypt Class Initialized
INFO - 2021-12-16 06:53:48 --> Model "Referredby_model" initialized
INFO - 2021-12-16 06:53:48 --> Model "Users_model" initialized
INFO - 2021-12-16 06:53:48 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-16 06:53:48 --> File loaded: /home3/karoteam/public_html/application/views/users/index.php
INFO - 2021-12-16 06:53:48 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-16 06:53:48 --> Final output sent to browser
DEBUG - 2021-12-16 06:53:48 --> Total execution time: 0.0849
ERROR - 2021-12-16 06:53:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-16 06:53:49 --> Config Class Initialized
INFO - 2021-12-16 06:53:49 --> Hooks Class Initialized
DEBUG - 2021-12-16 06:53:49 --> UTF-8 Support Enabled
INFO - 2021-12-16 06:53:49 --> Utf8 Class Initialized
INFO - 2021-12-16 06:53:49 --> URI Class Initialized
INFO - 2021-12-16 06:53:49 --> Router Class Initialized
INFO - 2021-12-16 06:53:49 --> Output Class Initialized
INFO - 2021-12-16 06:53:49 --> Security Class Initialized
DEBUG - 2021-12-16 06:53:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 06:53:49 --> Input Class Initialized
INFO - 2021-12-16 06:53:49 --> Language Class Initialized
ERROR - 2021-12-16 06:53:49 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-12-16 06:54:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-16 06:54:02 --> Config Class Initialized
INFO - 2021-12-16 06:54:02 --> Hooks Class Initialized
DEBUG - 2021-12-16 06:54:02 --> UTF-8 Support Enabled
INFO - 2021-12-16 06:54:02 --> Utf8 Class Initialized
INFO - 2021-12-16 06:54:02 --> URI Class Initialized
INFO - 2021-12-16 06:54:02 --> Router Class Initialized
INFO - 2021-12-16 06:54:02 --> Output Class Initialized
INFO - 2021-12-16 06:54:02 --> Security Class Initialized
DEBUG - 2021-12-16 06:54:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 06:54:02 --> Input Class Initialized
INFO - 2021-12-16 06:54:02 --> Language Class Initialized
INFO - 2021-12-16 06:54:02 --> Loader Class Initialized
INFO - 2021-12-16 06:54:02 --> Helper loaded: url_helper
INFO - 2021-12-16 06:54:02 --> Helper loaded: form_helper
INFO - 2021-12-16 06:54:02 --> Helper loaded: common_helper
INFO - 2021-12-16 06:54:02 --> Database Driver Class Initialized
DEBUG - 2021-12-16 06:54:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 06:54:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 06:54:02 --> Controller Class Initialized
INFO - 2021-12-16 06:54:02 --> Form Validation Class Initialized
DEBUG - 2021-12-16 06:54:02 --> Encrypt Class Initialized
INFO - 2021-12-16 06:54:02 --> Model "Referredby_model" initialized
INFO - 2021-12-16 06:54:02 --> Model "Users_model" initialized
INFO - 2021-12-16 06:54:02 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-16 06:54:02 --> File loaded: /home3/karoteam/public_html/application/views/users/index.php
INFO - 2021-12-16 06:54:02 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-16 06:54:02 --> Final output sent to browser
DEBUG - 2021-12-16 06:54:02 --> Total execution time: 0.0364
ERROR - 2021-12-16 06:54:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-16 06:54:03 --> Config Class Initialized
INFO - 2021-12-16 06:54:03 --> Hooks Class Initialized
DEBUG - 2021-12-16 06:54:03 --> UTF-8 Support Enabled
INFO - 2021-12-16 06:54:03 --> Utf8 Class Initialized
INFO - 2021-12-16 06:54:03 --> URI Class Initialized
INFO - 2021-12-16 06:54:03 --> Router Class Initialized
INFO - 2021-12-16 06:54:03 --> Output Class Initialized
INFO - 2021-12-16 06:54:03 --> Security Class Initialized
DEBUG - 2021-12-16 06:54:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 06:54:03 --> Input Class Initialized
INFO - 2021-12-16 06:54:03 --> Language Class Initialized
ERROR - 2021-12-16 06:54:03 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-12-16 06:54:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-16 06:54:03 --> Config Class Initialized
INFO - 2021-12-16 06:54:03 --> Hooks Class Initialized
DEBUG - 2021-12-16 06:54:03 --> UTF-8 Support Enabled
INFO - 2021-12-16 06:54:03 --> Utf8 Class Initialized
INFO - 2021-12-16 06:54:03 --> URI Class Initialized
INFO - 2021-12-16 06:54:03 --> Router Class Initialized
INFO - 2021-12-16 06:54:03 --> Output Class Initialized
INFO - 2021-12-16 06:54:03 --> Security Class Initialized
DEBUG - 2021-12-16 06:54:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 06:54:03 --> Input Class Initialized
INFO - 2021-12-16 06:54:03 --> Language Class Initialized
ERROR - 2021-12-16 06:54:03 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-12-16 06:54:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-16 06:54:26 --> Config Class Initialized
INFO - 2021-12-16 06:54:26 --> Hooks Class Initialized
DEBUG - 2021-12-16 06:54:26 --> UTF-8 Support Enabled
INFO - 2021-12-16 06:54:26 --> Utf8 Class Initialized
INFO - 2021-12-16 06:54:26 --> URI Class Initialized
INFO - 2021-12-16 06:54:26 --> Router Class Initialized
INFO - 2021-12-16 06:54:26 --> Output Class Initialized
INFO - 2021-12-16 06:54:26 --> Security Class Initialized
DEBUG - 2021-12-16 06:54:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 06:54:26 --> Input Class Initialized
INFO - 2021-12-16 06:54:26 --> Language Class Initialized
INFO - 2021-12-16 06:54:26 --> Loader Class Initialized
INFO - 2021-12-16 06:54:26 --> Helper loaded: url_helper
INFO - 2021-12-16 06:54:26 --> Helper loaded: form_helper
INFO - 2021-12-16 06:54:26 --> Helper loaded: common_helper
INFO - 2021-12-16 06:54:26 --> Database Driver Class Initialized
DEBUG - 2021-12-16 06:54:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 06:54:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 06:54:26 --> Controller Class Initialized
INFO - 2021-12-16 06:54:26 --> Form Validation Class Initialized
DEBUG - 2021-12-16 06:54:26 --> Encrypt Class Initialized
INFO - 2021-12-16 06:54:26 --> Model "Referredby_model" initialized
INFO - 2021-12-16 06:54:26 --> Model "Users_model" initialized
INFO - 2021-12-16 06:54:26 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-16 06:54:26 --> File loaded: /home3/karoteam/public_html/application/views/users/index.php
INFO - 2021-12-16 06:54:26 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-16 06:54:26 --> Final output sent to browser
DEBUG - 2021-12-16 06:54:26 --> Total execution time: 0.0269
ERROR - 2021-12-16 06:54:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-16 06:54:27 --> Config Class Initialized
INFO - 2021-12-16 06:54:27 --> Hooks Class Initialized
DEBUG - 2021-12-16 06:54:27 --> UTF-8 Support Enabled
INFO - 2021-12-16 06:54:27 --> Utf8 Class Initialized
INFO - 2021-12-16 06:54:27 --> URI Class Initialized
INFO - 2021-12-16 06:54:27 --> Router Class Initialized
INFO - 2021-12-16 06:54:27 --> Output Class Initialized
INFO - 2021-12-16 06:54:27 --> Security Class Initialized
DEBUG - 2021-12-16 06:54:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 06:54:27 --> Input Class Initialized
INFO - 2021-12-16 06:54:27 --> Language Class Initialized
INFO - 2021-12-16 06:54:27 --> Loader Class Initialized
INFO - 2021-12-16 06:54:27 --> Helper loaded: url_helper
INFO - 2021-12-16 06:54:27 --> Helper loaded: form_helper
INFO - 2021-12-16 06:54:27 --> Helper loaded: common_helper
INFO - 2021-12-16 06:54:27 --> Database Driver Class Initialized
DEBUG - 2021-12-16 06:54:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 06:54:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 06:54:27 --> Controller Class Initialized
INFO - 2021-12-16 06:54:27 --> Form Validation Class Initialized
DEBUG - 2021-12-16 06:54:27 --> Encrypt Class Initialized
INFO - 2021-12-16 06:54:27 --> Model "Login_model" initialized
INFO - 2021-12-16 06:54:27 --> Model "Dashboard_model" initialized
INFO - 2021-12-16 06:54:27 --> Model "Case_model" initialized
ERROR - 2021-12-16 06:54:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-16 06:54:35 --> Config Class Initialized
INFO - 2021-12-16 06:54:35 --> Hooks Class Initialized
DEBUG - 2021-12-16 06:54:35 --> UTF-8 Support Enabled
INFO - 2021-12-16 06:54:35 --> Utf8 Class Initialized
INFO - 2021-12-16 06:54:35 --> URI Class Initialized
INFO - 2021-12-16 06:54:35 --> Router Class Initialized
INFO - 2021-12-16 06:54:35 --> Output Class Initialized
INFO - 2021-12-16 06:54:35 --> Security Class Initialized
DEBUG - 2021-12-16 06:54:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 06:54:35 --> Input Class Initialized
INFO - 2021-12-16 06:54:35 --> Language Class Initialized
INFO - 2021-12-16 06:54:35 --> Loader Class Initialized
INFO - 2021-12-16 06:54:35 --> Helper loaded: url_helper
INFO - 2021-12-16 06:54:36 --> Helper loaded: form_helper
INFO - 2021-12-16 06:54:36 --> Helper loaded: common_helper
INFO - 2021-12-16 06:54:36 --> Database Driver Class Initialized
DEBUG - 2021-12-16 06:54:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 06:54:36 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-16 06:54:46 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2021-12-16 06:54:46 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-16 06:54:46 --> Final output sent to browser
DEBUG - 2021-12-16 06:54:46 --> Total execution time: 18.6996
INFO - 2021-12-16 06:54:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 06:54:46 --> Controller Class Initialized
INFO - 2021-12-16 06:54:46 --> Form Validation Class Initialized
DEBUG - 2021-12-16 06:54:46 --> Encrypt Class Initialized
INFO - 2021-12-16 06:54:46 --> Model "Login_model" initialized
INFO - 2021-12-16 06:54:46 --> Model "Dashboard_model" initialized
INFO - 2021-12-16 06:54:46 --> Model "Case_model" initialized
INFO - 2021-12-16 06:54:56 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-16 06:55:07 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2021-12-16 06:55:07 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-16 06:55:07 --> Final output sent to browser
DEBUG - 2021-12-16 06:55:07 --> Total execution time: 31.8616
ERROR - 2021-12-16 06:55:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-16 06:55:08 --> Config Class Initialized
INFO - 2021-12-16 06:55:08 --> Hooks Class Initialized
DEBUG - 2021-12-16 06:55:08 --> UTF-8 Support Enabled
INFO - 2021-12-16 06:55:08 --> Utf8 Class Initialized
INFO - 2021-12-16 06:55:08 --> URI Class Initialized
INFO - 2021-12-16 06:55:08 --> Router Class Initialized
INFO - 2021-12-16 06:55:08 --> Output Class Initialized
INFO - 2021-12-16 06:55:08 --> Security Class Initialized
DEBUG - 2021-12-16 06:55:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 06:55:08 --> Input Class Initialized
INFO - 2021-12-16 06:55:08 --> Language Class Initialized
ERROR - 2021-12-16 06:55:08 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-12-16 06:58:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-16 06:58:19 --> Config Class Initialized
INFO - 2021-12-16 06:58:19 --> Hooks Class Initialized
DEBUG - 2021-12-16 06:58:19 --> UTF-8 Support Enabled
INFO - 2021-12-16 06:58:19 --> Utf8 Class Initialized
INFO - 2021-12-16 06:58:19 --> URI Class Initialized
INFO - 2021-12-16 06:58:19 --> Router Class Initialized
INFO - 2021-12-16 06:58:19 --> Output Class Initialized
INFO - 2021-12-16 06:58:19 --> Security Class Initialized
DEBUG - 2021-12-16 06:58:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 06:58:19 --> Input Class Initialized
INFO - 2021-12-16 06:58:19 --> Language Class Initialized
INFO - 2021-12-16 06:58:19 --> Loader Class Initialized
INFO - 2021-12-16 06:58:19 --> Helper loaded: url_helper
INFO - 2021-12-16 06:58:19 --> Helper loaded: form_helper
INFO - 2021-12-16 06:58:19 --> Helper loaded: common_helper
INFO - 2021-12-16 06:58:19 --> Database Driver Class Initialized
DEBUG - 2021-12-16 06:58:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 06:58:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 06:58:19 --> Controller Class Initialized
INFO - 2021-12-16 06:58:19 --> Form Validation Class Initialized
DEBUG - 2021-12-16 06:58:19 --> Encrypt Class Initialized
INFO - 2021-12-16 06:58:19 --> Model "Patient_model" initialized
INFO - 2021-12-16 06:58:19 --> Model "Patientcase_model" initialized
INFO - 2021-12-16 06:58:19 --> Model "Referredby_model" initialized
INFO - 2021-12-16 06:58:19 --> Model "Prefix_master" initialized
INFO - 2021-12-16 06:58:19 --> Model "Hospital_model" initialized
INFO - 2021-12-16 06:58:19 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-16 06:58:19 --> File loaded: /home3/karoteam/public_html/application/views/patient/patient_by_category.php
INFO - 2021-12-16 06:58:19 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-16 06:58:19 --> Final output sent to browser
DEBUG - 2021-12-16 06:58:19 --> Total execution time: 0.0423
ERROR - 2021-12-16 06:58:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-16 06:58:20 --> Config Class Initialized
INFO - 2021-12-16 06:58:20 --> Hooks Class Initialized
DEBUG - 2021-12-16 06:58:20 --> UTF-8 Support Enabled
INFO - 2021-12-16 06:58:20 --> Utf8 Class Initialized
INFO - 2021-12-16 06:58:20 --> URI Class Initialized
INFO - 2021-12-16 06:58:20 --> Router Class Initialized
INFO - 2021-12-16 06:58:20 --> Output Class Initialized
INFO - 2021-12-16 06:58:20 --> Security Class Initialized
DEBUG - 2021-12-16 06:58:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 06:58:20 --> Input Class Initialized
INFO - 2021-12-16 06:58:20 --> Language Class Initialized
ERROR - 2021-12-16 06:58:20 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-12-16 06:58:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-16 06:58:45 --> Config Class Initialized
INFO - 2021-12-16 06:58:45 --> Hooks Class Initialized
DEBUG - 2021-12-16 06:58:45 --> UTF-8 Support Enabled
INFO - 2021-12-16 06:58:45 --> Utf8 Class Initialized
INFO - 2021-12-16 06:58:45 --> URI Class Initialized
INFO - 2021-12-16 06:58:45 --> Router Class Initialized
INFO - 2021-12-16 06:58:45 --> Output Class Initialized
INFO - 2021-12-16 06:58:45 --> Security Class Initialized
DEBUG - 2021-12-16 06:58:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 06:58:45 --> Input Class Initialized
INFO - 2021-12-16 06:58:45 --> Language Class Initialized
INFO - 2021-12-16 06:58:45 --> Loader Class Initialized
INFO - 2021-12-16 06:58:45 --> Helper loaded: url_helper
INFO - 2021-12-16 06:58:45 --> Helper loaded: form_helper
INFO - 2021-12-16 06:58:45 --> Helper loaded: common_helper
INFO - 2021-12-16 06:58:45 --> Database Driver Class Initialized
DEBUG - 2021-12-16 06:58:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 06:58:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 06:58:45 --> Controller Class Initialized
INFO - 2021-12-16 06:58:45 --> Form Validation Class Initialized
DEBUG - 2021-12-16 06:58:45 --> Encrypt Class Initialized
INFO - 2021-12-16 06:58:45 --> Model "Patient_model" initialized
INFO - 2021-12-16 06:58:45 --> Model "Patientcase_model" initialized
INFO - 2021-12-16 06:58:45 --> Model "Prefix_master" initialized
INFO - 2021-12-16 06:58:45 --> Model "Users_model" initialized
INFO - 2021-12-16 06:58:45 --> Model "Hospital_model" initialized
INFO - 2021-12-16 06:58:45 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-16 06:58:45 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2021-12-16 06:58:45 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-16 06:58:45 --> Final output sent to browser
DEBUG - 2021-12-16 06:58:45 --> Total execution time: 0.0682
ERROR - 2021-12-16 06:58:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-16 06:58:46 --> Config Class Initialized
INFO - 2021-12-16 06:58:46 --> Hooks Class Initialized
DEBUG - 2021-12-16 06:58:46 --> UTF-8 Support Enabled
INFO - 2021-12-16 06:58:46 --> Utf8 Class Initialized
INFO - 2021-12-16 06:58:46 --> URI Class Initialized
INFO - 2021-12-16 06:58:46 --> Router Class Initialized
INFO - 2021-12-16 06:58:46 --> Output Class Initialized
INFO - 2021-12-16 06:58:46 --> Security Class Initialized
DEBUG - 2021-12-16 06:58:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 06:58:46 --> Input Class Initialized
INFO - 2021-12-16 06:58:46 --> Language Class Initialized
ERROR - 2021-12-16 06:58:46 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-12-16 06:58:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-16 06:58:59 --> Config Class Initialized
INFO - 2021-12-16 06:58:59 --> Hooks Class Initialized
DEBUG - 2021-12-16 06:58:59 --> UTF-8 Support Enabled
INFO - 2021-12-16 06:58:59 --> Utf8 Class Initialized
INFO - 2021-12-16 06:58:59 --> URI Class Initialized
INFO - 2021-12-16 06:58:59 --> Router Class Initialized
INFO - 2021-12-16 06:58:59 --> Output Class Initialized
INFO - 2021-12-16 06:58:59 --> Security Class Initialized
DEBUG - 2021-12-16 06:58:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 06:58:59 --> Input Class Initialized
INFO - 2021-12-16 06:58:59 --> Language Class Initialized
INFO - 2021-12-16 06:58:59 --> Loader Class Initialized
INFO - 2021-12-16 06:58:59 --> Helper loaded: url_helper
INFO - 2021-12-16 06:58:59 --> Helper loaded: form_helper
INFO - 2021-12-16 06:58:59 --> Helper loaded: common_helper
INFO - 2021-12-16 06:58:59 --> Database Driver Class Initialized
DEBUG - 2021-12-16 06:58:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 06:58:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 06:58:59 --> Controller Class Initialized
INFO - 2021-12-16 06:58:59 --> Form Validation Class Initialized
DEBUG - 2021-12-16 06:58:59 --> Encrypt Class Initialized
INFO - 2021-12-16 06:58:59 --> Model "Login_model" initialized
INFO - 2021-12-16 06:58:59 --> Model "Dashboard_model" initialized
INFO - 2021-12-16 06:58:59 --> Model "Case_model" initialized
ERROR - 2021-12-16 06:59:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-16 06:59:03 --> Config Class Initialized
INFO - 2021-12-16 06:59:03 --> Hooks Class Initialized
DEBUG - 2021-12-16 06:59:03 --> UTF-8 Support Enabled
INFO - 2021-12-16 06:59:03 --> Utf8 Class Initialized
INFO - 2021-12-16 06:59:03 --> URI Class Initialized
INFO - 2021-12-16 06:59:03 --> Router Class Initialized
INFO - 2021-12-16 06:59:03 --> Output Class Initialized
INFO - 2021-12-16 06:59:03 --> Security Class Initialized
DEBUG - 2021-12-16 06:59:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 06:59:03 --> Input Class Initialized
INFO - 2021-12-16 06:59:03 --> Language Class Initialized
INFO - 2021-12-16 06:59:03 --> Loader Class Initialized
INFO - 2021-12-16 06:59:03 --> Helper loaded: url_helper
INFO - 2021-12-16 06:59:03 --> Helper loaded: form_helper
INFO - 2021-12-16 06:59:03 --> Helper loaded: common_helper
INFO - 2021-12-16 06:59:03 --> Database Driver Class Initialized
DEBUG - 2021-12-16 06:59:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 06:59:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 06:59:03 --> Controller Class Initialized
INFO - 2021-12-16 06:59:03 --> Form Validation Class Initialized
DEBUG - 2021-12-16 06:59:03 --> Encrypt Class Initialized
INFO - 2021-12-16 06:59:03 --> Model "Login_model" initialized
INFO - 2021-12-16 06:59:03 --> Model "Dashboard_model" initialized
INFO - 2021-12-16 06:59:03 --> Model "Case_model" initialized
INFO - 2021-12-16 06:59:14 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-16 06:59:17 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-16 06:59:26 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2021-12-16 06:59:26 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-16 06:59:26 --> Final output sent to browser
DEBUG - 2021-12-16 06:59:26 --> Total execution time: 26.4528
ERROR - 2021-12-16 06:59:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-16 06:59:27 --> Config Class Initialized
INFO - 2021-12-16 06:59:27 --> Hooks Class Initialized
DEBUG - 2021-12-16 06:59:27 --> UTF-8 Support Enabled
INFO - 2021-12-16 06:59:27 --> Utf8 Class Initialized
INFO - 2021-12-16 06:59:27 --> URI Class Initialized
INFO - 2021-12-16 06:59:27 --> Router Class Initialized
INFO - 2021-12-16 06:59:27 --> Output Class Initialized
INFO - 2021-12-16 06:59:27 --> Security Class Initialized
DEBUG - 2021-12-16 06:59:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 06:59:27 --> Input Class Initialized
INFO - 2021-12-16 06:59:27 --> Language Class Initialized
ERROR - 2021-12-16 06:59:27 --> 404 Page Not Found: Karoclient/usersprofile
INFO - 2021-12-16 06:59:28 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2021-12-16 06:59:28 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-16 06:59:28 --> Final output sent to browser
DEBUG - 2021-12-16 06:59:28 --> Total execution time: 25.4643
ERROR - 2021-12-16 06:59:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-16 06:59:29 --> Config Class Initialized
INFO - 2021-12-16 06:59:29 --> Hooks Class Initialized
DEBUG - 2021-12-16 06:59:29 --> UTF-8 Support Enabled
INFO - 2021-12-16 06:59:29 --> Utf8 Class Initialized
INFO - 2021-12-16 06:59:29 --> URI Class Initialized
INFO - 2021-12-16 06:59:29 --> Router Class Initialized
INFO - 2021-12-16 06:59:29 --> Output Class Initialized
INFO - 2021-12-16 06:59:29 --> Security Class Initialized
DEBUG - 2021-12-16 06:59:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 06:59:29 --> Input Class Initialized
INFO - 2021-12-16 06:59:29 --> Language Class Initialized
ERROR - 2021-12-16 06:59:29 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-12-16 08:29:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-16 08:29:30 --> Config Class Initialized
INFO - 2021-12-16 08:29:30 --> Hooks Class Initialized
DEBUG - 2021-12-16 08:29:30 --> UTF-8 Support Enabled
INFO - 2021-12-16 08:29:30 --> Utf8 Class Initialized
INFO - 2021-12-16 08:29:30 --> URI Class Initialized
DEBUG - 2021-12-16 08:29:30 --> No URI present. Default controller set.
INFO - 2021-12-16 08:29:30 --> Router Class Initialized
INFO - 2021-12-16 08:29:30 --> Output Class Initialized
INFO - 2021-12-16 08:29:30 --> Security Class Initialized
DEBUG - 2021-12-16 08:29:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 08:29:30 --> Input Class Initialized
INFO - 2021-12-16 08:29:30 --> Language Class Initialized
INFO - 2021-12-16 08:29:30 --> Loader Class Initialized
INFO - 2021-12-16 08:29:30 --> Helper loaded: url_helper
INFO - 2021-12-16 08:29:30 --> Helper loaded: form_helper
INFO - 2021-12-16 08:29:30 --> Helper loaded: common_helper
INFO - 2021-12-16 08:29:30 --> Database Driver Class Initialized
DEBUG - 2021-12-16 08:29:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 08:29:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 08:29:30 --> Controller Class Initialized
INFO - 2021-12-16 08:29:30 --> Form Validation Class Initialized
DEBUG - 2021-12-16 08:29:30 --> Encrypt Class Initialized
DEBUG - 2021-12-16 08:29:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-16 08:29:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-16 08:29:30 --> Email Class Initialized
INFO - 2021-12-16 08:29:30 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-16 08:29:30 --> Calendar Class Initialized
INFO - 2021-12-16 08:29:30 --> Model "Login_model" initialized
INFO - 2021-12-16 08:29:30 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-16 08:29:30 --> Final output sent to browser
DEBUG - 2021-12-16 08:29:30 --> Total execution time: 0.0372
ERROR - 2021-12-16 10:19:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-16 10:19:08 --> Config Class Initialized
INFO - 2021-12-16 10:19:08 --> Hooks Class Initialized
DEBUG - 2021-12-16 10:19:08 --> UTF-8 Support Enabled
INFO - 2021-12-16 10:19:08 --> Utf8 Class Initialized
INFO - 2021-12-16 10:19:08 --> URI Class Initialized
DEBUG - 2021-12-16 10:19:08 --> No URI present. Default controller set.
INFO - 2021-12-16 10:19:08 --> Router Class Initialized
INFO - 2021-12-16 10:19:08 --> Output Class Initialized
INFO - 2021-12-16 10:19:08 --> Security Class Initialized
DEBUG - 2021-12-16 10:19:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 10:19:08 --> Input Class Initialized
INFO - 2021-12-16 10:19:08 --> Language Class Initialized
INFO - 2021-12-16 10:19:08 --> Loader Class Initialized
INFO - 2021-12-16 10:19:08 --> Helper loaded: url_helper
INFO - 2021-12-16 10:19:08 --> Helper loaded: form_helper
INFO - 2021-12-16 10:19:08 --> Helper loaded: common_helper
INFO - 2021-12-16 10:19:08 --> Database Driver Class Initialized
DEBUG - 2021-12-16 10:19:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 10:19:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 10:19:08 --> Controller Class Initialized
INFO - 2021-12-16 10:19:08 --> Form Validation Class Initialized
DEBUG - 2021-12-16 10:19:08 --> Encrypt Class Initialized
DEBUG - 2021-12-16 10:19:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-16 10:19:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-16 10:19:08 --> Email Class Initialized
INFO - 2021-12-16 10:19:08 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-16 10:19:08 --> Calendar Class Initialized
INFO - 2021-12-16 10:19:08 --> Model "Login_model" initialized
INFO - 2021-12-16 10:19:08 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-16 10:19:08 --> Final output sent to browser
DEBUG - 2021-12-16 10:19:08 --> Total execution time: 0.0235
ERROR - 2021-12-16 14:16:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-16 14:16:30 --> Config Class Initialized
INFO - 2021-12-16 14:16:30 --> Hooks Class Initialized
DEBUG - 2021-12-16 14:16:30 --> UTF-8 Support Enabled
INFO - 2021-12-16 14:16:30 --> Utf8 Class Initialized
INFO - 2021-12-16 14:16:30 --> URI Class Initialized
DEBUG - 2021-12-16 14:16:30 --> No URI present. Default controller set.
INFO - 2021-12-16 14:16:30 --> Router Class Initialized
INFO - 2021-12-16 14:16:30 --> Output Class Initialized
INFO - 2021-12-16 14:16:30 --> Security Class Initialized
DEBUG - 2021-12-16 14:16:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 14:16:30 --> Input Class Initialized
INFO - 2021-12-16 14:16:30 --> Language Class Initialized
INFO - 2021-12-16 14:16:30 --> Loader Class Initialized
INFO - 2021-12-16 14:16:30 --> Helper loaded: url_helper
INFO - 2021-12-16 14:16:30 --> Helper loaded: form_helper
INFO - 2021-12-16 14:16:30 --> Helper loaded: common_helper
INFO - 2021-12-16 14:16:30 --> Database Driver Class Initialized
DEBUG - 2021-12-16 14:16:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 14:16:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 14:16:30 --> Controller Class Initialized
INFO - 2021-12-16 14:16:30 --> Form Validation Class Initialized
DEBUG - 2021-12-16 14:16:30 --> Encrypt Class Initialized
DEBUG - 2021-12-16 14:16:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-16 14:16:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-16 14:16:30 --> Email Class Initialized
INFO - 2021-12-16 14:16:30 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-16 14:16:30 --> Calendar Class Initialized
INFO - 2021-12-16 14:16:30 --> Model "Login_model" initialized
INFO - 2021-12-16 14:16:30 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-16 14:16:30 --> Final output sent to browser
DEBUG - 2021-12-16 14:16:30 --> Total execution time: 0.0313
ERROR - 2021-12-16 14:16:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-16 14:16:31 --> Config Class Initialized
INFO - 2021-12-16 14:16:31 --> Hooks Class Initialized
DEBUG - 2021-12-16 14:16:31 --> UTF-8 Support Enabled
INFO - 2021-12-16 14:16:31 --> Utf8 Class Initialized
INFO - 2021-12-16 14:16:31 --> URI Class Initialized
INFO - 2021-12-16 14:16:31 --> Router Class Initialized
INFO - 2021-12-16 14:16:31 --> Output Class Initialized
INFO - 2021-12-16 14:16:31 --> Security Class Initialized
DEBUG - 2021-12-16 14:16:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 14:16:31 --> Input Class Initialized
INFO - 2021-12-16 14:16:31 --> Language Class Initialized
ERROR - 2021-12-16 14:16:31 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2021-12-16 14:16:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-16 14:16:41 --> Config Class Initialized
INFO - 2021-12-16 14:16:41 --> Hooks Class Initialized
DEBUG - 2021-12-16 14:16:41 --> UTF-8 Support Enabled
INFO - 2021-12-16 14:16:41 --> Utf8 Class Initialized
INFO - 2021-12-16 14:16:41 --> URI Class Initialized
INFO - 2021-12-16 14:16:41 --> Router Class Initialized
INFO - 2021-12-16 14:16:41 --> Output Class Initialized
INFO - 2021-12-16 14:16:41 --> Security Class Initialized
DEBUG - 2021-12-16 14:16:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 14:16:41 --> Input Class Initialized
INFO - 2021-12-16 14:16:41 --> Language Class Initialized
INFO - 2021-12-16 14:16:41 --> Loader Class Initialized
INFO - 2021-12-16 14:16:41 --> Helper loaded: url_helper
INFO - 2021-12-16 14:16:41 --> Helper loaded: form_helper
INFO - 2021-12-16 14:16:41 --> Helper loaded: common_helper
INFO - 2021-12-16 14:16:41 --> Database Driver Class Initialized
DEBUG - 2021-12-16 14:16:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 14:16:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 14:16:41 --> Controller Class Initialized
INFO - 2021-12-16 14:16:41 --> Form Validation Class Initialized
DEBUG - 2021-12-16 14:16:41 --> Encrypt Class Initialized
DEBUG - 2021-12-16 14:16:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-16 14:16:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-16 14:16:41 --> Email Class Initialized
INFO - 2021-12-16 14:16:41 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-16 14:16:41 --> Calendar Class Initialized
INFO - 2021-12-16 14:16:41 --> Model "Login_model" initialized
INFO - 2021-12-16 14:16:41 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-16 14:16:41 --> Final output sent to browser
DEBUG - 2021-12-16 14:16:41 --> Total execution time: 0.0312
ERROR - 2021-12-16 14:16:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-16 14:16:41 --> Config Class Initialized
INFO - 2021-12-16 14:16:41 --> Hooks Class Initialized
DEBUG - 2021-12-16 14:16:41 --> UTF-8 Support Enabled
INFO - 2021-12-16 14:16:41 --> Utf8 Class Initialized
INFO - 2021-12-16 14:16:41 --> URI Class Initialized
INFO - 2021-12-16 14:16:41 --> Router Class Initialized
INFO - 2021-12-16 14:16:41 --> Output Class Initialized
INFO - 2021-12-16 14:16:41 --> Security Class Initialized
DEBUG - 2021-12-16 14:16:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 14:16:41 --> Input Class Initialized
INFO - 2021-12-16 14:16:41 --> Language Class Initialized
INFO - 2021-12-16 14:16:41 --> Loader Class Initialized
INFO - 2021-12-16 14:16:41 --> Helper loaded: url_helper
INFO - 2021-12-16 14:16:41 --> Helper loaded: form_helper
INFO - 2021-12-16 14:16:41 --> Helper loaded: common_helper
INFO - 2021-12-16 14:16:41 --> Database Driver Class Initialized
DEBUG - 2021-12-16 14:16:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 14:16:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 14:16:41 --> Controller Class Initialized
INFO - 2021-12-16 14:16:41 --> Form Validation Class Initialized
DEBUG - 2021-12-16 14:16:41 --> Encrypt Class Initialized
DEBUG - 2021-12-16 14:16:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-16 14:16:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-16 14:16:41 --> Email Class Initialized
INFO - 2021-12-16 14:16:41 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-16 14:16:41 --> Calendar Class Initialized
INFO - 2021-12-16 14:16:41 --> Model "Login_model" initialized
ERROR - 2021-12-16 14:16:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-16 14:16:42 --> Config Class Initialized
INFO - 2021-12-16 14:16:42 --> Hooks Class Initialized
DEBUG - 2021-12-16 14:16:42 --> UTF-8 Support Enabled
INFO - 2021-12-16 14:16:42 --> Utf8 Class Initialized
INFO - 2021-12-16 14:16:42 --> URI Class Initialized
INFO - 2021-12-16 14:16:42 --> Router Class Initialized
INFO - 2021-12-16 14:16:42 --> Output Class Initialized
INFO - 2021-12-16 14:16:42 --> Security Class Initialized
DEBUG - 2021-12-16 14:16:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 14:16:42 --> Input Class Initialized
INFO - 2021-12-16 14:16:42 --> Language Class Initialized
INFO - 2021-12-16 14:16:42 --> Loader Class Initialized
INFO - 2021-12-16 14:16:42 --> Helper loaded: url_helper
INFO - 2021-12-16 14:16:42 --> Helper loaded: form_helper
INFO - 2021-12-16 14:16:42 --> Helper loaded: common_helper
INFO - 2021-12-16 14:16:42 --> Database Driver Class Initialized
DEBUG - 2021-12-16 14:16:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 14:16:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 14:16:42 --> Controller Class Initialized
INFO - 2021-12-16 14:16:42 --> Form Validation Class Initialized
DEBUG - 2021-12-16 14:16:42 --> Encrypt Class Initialized
DEBUG - 2021-12-16 14:16:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-16 14:16:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-16 14:16:42 --> Email Class Initialized
INFO - 2021-12-16 14:16:42 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-16 14:16:42 --> Calendar Class Initialized
INFO - 2021-12-16 14:16:42 --> Model "Login_model" initialized
ERROR - 2021-12-16 14:16:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-16 14:16:43 --> Config Class Initialized
INFO - 2021-12-16 14:16:43 --> Hooks Class Initialized
DEBUG - 2021-12-16 14:16:43 --> UTF-8 Support Enabled
INFO - 2021-12-16 14:16:43 --> Utf8 Class Initialized
INFO - 2021-12-16 14:16:43 --> URI Class Initialized
DEBUG - 2021-12-16 14:16:43 --> No URI present. Default controller set.
INFO - 2021-12-16 14:16:43 --> Router Class Initialized
INFO - 2021-12-16 14:16:43 --> Output Class Initialized
INFO - 2021-12-16 14:16:43 --> Security Class Initialized
DEBUG - 2021-12-16 14:16:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 14:16:43 --> Input Class Initialized
INFO - 2021-12-16 14:16:43 --> Language Class Initialized
INFO - 2021-12-16 14:16:43 --> Loader Class Initialized
INFO - 2021-12-16 14:16:43 --> Helper loaded: url_helper
INFO - 2021-12-16 14:16:43 --> Helper loaded: form_helper
INFO - 2021-12-16 14:16:43 --> Helper loaded: common_helper
INFO - 2021-12-16 14:16:43 --> Database Driver Class Initialized
DEBUG - 2021-12-16 14:16:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 14:16:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 14:16:43 --> Controller Class Initialized
INFO - 2021-12-16 14:16:43 --> Form Validation Class Initialized
DEBUG - 2021-12-16 14:16:43 --> Encrypt Class Initialized
DEBUG - 2021-12-16 14:16:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-16 14:16:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-16 14:16:43 --> Email Class Initialized
INFO - 2021-12-16 14:16:43 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-16 14:16:43 --> Calendar Class Initialized
INFO - 2021-12-16 14:16:43 --> Model "Login_model" initialized
INFO - 2021-12-16 14:16:43 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-16 14:16:43 --> Final output sent to browser
DEBUG - 2021-12-16 14:16:43 --> Total execution time: 0.0217
ERROR - 2021-12-16 15:22:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-16 15:22:52 --> Config Class Initialized
INFO - 2021-12-16 15:22:52 --> Hooks Class Initialized
DEBUG - 2021-12-16 15:22:52 --> UTF-8 Support Enabled
INFO - 2021-12-16 15:22:52 --> Utf8 Class Initialized
INFO - 2021-12-16 15:22:52 --> URI Class Initialized
DEBUG - 2021-12-16 15:22:52 --> No URI present. Default controller set.
INFO - 2021-12-16 15:22:52 --> Router Class Initialized
INFO - 2021-12-16 15:22:52 --> Output Class Initialized
INFO - 2021-12-16 15:22:52 --> Security Class Initialized
DEBUG - 2021-12-16 15:22:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 15:22:52 --> Input Class Initialized
INFO - 2021-12-16 15:22:52 --> Language Class Initialized
INFO - 2021-12-16 15:22:52 --> Loader Class Initialized
INFO - 2021-12-16 15:22:52 --> Helper loaded: url_helper
INFO - 2021-12-16 15:22:52 --> Helper loaded: form_helper
INFO - 2021-12-16 15:22:52 --> Helper loaded: common_helper
INFO - 2021-12-16 15:22:52 --> Database Driver Class Initialized
DEBUG - 2021-12-16 15:22:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 15:22:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 15:22:52 --> Controller Class Initialized
INFO - 2021-12-16 15:22:52 --> Form Validation Class Initialized
DEBUG - 2021-12-16 15:22:52 --> Encrypt Class Initialized
DEBUG - 2021-12-16 15:22:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-16 15:22:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-16 15:22:52 --> Email Class Initialized
INFO - 2021-12-16 15:22:52 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-16 15:22:52 --> Calendar Class Initialized
INFO - 2021-12-16 15:22:52 --> Model "Login_model" initialized
INFO - 2021-12-16 15:22:52 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-16 15:22:52 --> Final output sent to browser
DEBUG - 2021-12-16 15:22:52 --> Total execution time: 0.0245
ERROR - 2021-12-16 15:50:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-16 15:50:59 --> Config Class Initialized
INFO - 2021-12-16 15:50:59 --> Hooks Class Initialized
DEBUG - 2021-12-16 15:50:59 --> UTF-8 Support Enabled
INFO - 2021-12-16 15:50:59 --> Utf8 Class Initialized
INFO - 2021-12-16 15:50:59 --> URI Class Initialized
DEBUG - 2021-12-16 15:50:59 --> No URI present. Default controller set.
INFO - 2021-12-16 15:50:59 --> Router Class Initialized
INFO - 2021-12-16 15:50:59 --> Output Class Initialized
INFO - 2021-12-16 15:50:59 --> Security Class Initialized
DEBUG - 2021-12-16 15:50:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 15:50:59 --> Input Class Initialized
INFO - 2021-12-16 15:50:59 --> Language Class Initialized
INFO - 2021-12-16 15:50:59 --> Loader Class Initialized
INFO - 2021-12-16 15:50:59 --> Helper loaded: url_helper
INFO - 2021-12-16 15:50:59 --> Helper loaded: form_helper
INFO - 2021-12-16 15:50:59 --> Helper loaded: common_helper
INFO - 2021-12-16 15:51:00 --> Database Driver Class Initialized
DEBUG - 2021-12-16 15:51:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 15:51:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 15:51:00 --> Controller Class Initialized
INFO - 2021-12-16 15:51:00 --> Form Validation Class Initialized
DEBUG - 2021-12-16 15:51:00 --> Encrypt Class Initialized
DEBUG - 2021-12-16 15:51:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-16 15:51:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-16 15:51:00 --> Email Class Initialized
INFO - 2021-12-16 15:51:00 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-16 15:51:00 --> Calendar Class Initialized
INFO - 2021-12-16 15:51:00 --> Model "Login_model" initialized
INFO - 2021-12-16 15:51:00 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-16 15:51:00 --> Final output sent to browser
DEBUG - 2021-12-16 15:51:00 --> Total execution time: 0.0264
ERROR - 2021-12-16 19:46:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-16 19:46:45 --> Config Class Initialized
INFO - 2021-12-16 19:46:45 --> Hooks Class Initialized
DEBUG - 2021-12-16 19:46:45 --> UTF-8 Support Enabled
INFO - 2021-12-16 19:46:45 --> Utf8 Class Initialized
INFO - 2021-12-16 19:46:45 --> URI Class Initialized
DEBUG - 2021-12-16 19:46:45 --> No URI present. Default controller set.
INFO - 2021-12-16 19:46:45 --> Router Class Initialized
INFO - 2021-12-16 19:46:45 --> Output Class Initialized
INFO - 2021-12-16 19:46:45 --> Security Class Initialized
DEBUG - 2021-12-16 19:46:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 19:46:45 --> Input Class Initialized
INFO - 2021-12-16 19:46:45 --> Language Class Initialized
INFO - 2021-12-16 19:46:45 --> Loader Class Initialized
INFO - 2021-12-16 19:46:45 --> Helper loaded: url_helper
INFO - 2021-12-16 19:46:45 --> Helper loaded: form_helper
INFO - 2021-12-16 19:46:45 --> Helper loaded: common_helper
INFO - 2021-12-16 19:46:45 --> Database Driver Class Initialized
DEBUG - 2021-12-16 19:46:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 19:46:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 19:46:45 --> Controller Class Initialized
INFO - 2021-12-16 19:46:45 --> Form Validation Class Initialized
DEBUG - 2021-12-16 19:46:45 --> Encrypt Class Initialized
DEBUG - 2021-12-16 19:46:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-16 19:46:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-16 19:46:45 --> Email Class Initialized
INFO - 2021-12-16 19:46:45 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-16 19:46:45 --> Calendar Class Initialized
INFO - 2021-12-16 19:46:45 --> Model "Login_model" initialized
INFO - 2021-12-16 19:46:45 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-16 19:46:45 --> Final output sent to browser
DEBUG - 2021-12-16 19:46:45 --> Total execution time: 0.0354
