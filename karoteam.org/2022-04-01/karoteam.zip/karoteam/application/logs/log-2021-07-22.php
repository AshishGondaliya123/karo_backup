<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-07-22 02:00:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-22 02:00:28 --> Config Class Initialized
INFO - 2021-07-22 02:00:28 --> Hooks Class Initialized
DEBUG - 2021-07-22 02:00:28 --> UTF-8 Support Enabled
INFO - 2021-07-22 02:00:28 --> Utf8 Class Initialized
INFO - 2021-07-22 02:00:28 --> URI Class Initialized
INFO - 2021-07-22 02:00:28 --> Router Class Initialized
INFO - 2021-07-22 02:00:28 --> Output Class Initialized
INFO - 2021-07-22 02:00:28 --> Security Class Initialized
DEBUG - 2021-07-22 02:00:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-22 02:00:28 --> Input Class Initialized
INFO - 2021-07-22 02:00:28 --> Language Class Initialized
ERROR - 2021-07-22 02:00:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-22 08:36:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-22 08:36:43 --> Config Class Initialized
INFO - 2021-07-22 08:36:43 --> Hooks Class Initialized
DEBUG - 2021-07-22 08:36:43 --> UTF-8 Support Enabled
INFO - 2021-07-22 08:36:43 --> Utf8 Class Initialized
INFO - 2021-07-22 08:36:43 --> URI Class Initialized
INFO - 2021-07-22 08:36:43 --> Router Class Initialized
INFO - 2021-07-22 08:36:43 --> Output Class Initialized
INFO - 2021-07-22 08:36:43 --> Security Class Initialized
DEBUG - 2021-07-22 08:36:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-22 08:36:43 --> Input Class Initialized
INFO - 2021-07-22 08:36:43 --> Language Class Initialized
ERROR - 2021-07-22 08:36:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-22 08:45:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-22 08:45:10 --> Config Class Initialized
INFO - 2021-07-22 08:45:10 --> Hooks Class Initialized
DEBUG - 2021-07-22 08:45:10 --> UTF-8 Support Enabled
INFO - 2021-07-22 08:45:10 --> Utf8 Class Initialized
INFO - 2021-07-22 08:45:10 --> URI Class Initialized
INFO - 2021-07-22 08:45:10 --> Router Class Initialized
INFO - 2021-07-22 08:45:10 --> Output Class Initialized
INFO - 2021-07-22 08:45:10 --> Security Class Initialized
DEBUG - 2021-07-22 08:45:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-22 08:45:10 --> Input Class Initialized
INFO - 2021-07-22 08:45:10 --> Language Class Initialized
ERROR - 2021-07-22 08:45:10 --> 404 Page Not Found: Sitemap0xml/index
ERROR - 2021-07-22 08:54:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-22 08:54:27 --> Config Class Initialized
INFO - 2021-07-22 08:54:27 --> Hooks Class Initialized
DEBUG - 2021-07-22 08:54:27 --> UTF-8 Support Enabled
INFO - 2021-07-22 08:54:27 --> Utf8 Class Initialized
INFO - 2021-07-22 08:54:27 --> URI Class Initialized
INFO - 2021-07-22 08:54:27 --> Router Class Initialized
INFO - 2021-07-22 08:54:27 --> Output Class Initialized
INFO - 2021-07-22 08:54:27 --> Security Class Initialized
DEBUG - 2021-07-22 08:54:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-22 08:54:27 --> Input Class Initialized
INFO - 2021-07-22 08:54:27 --> Language Class Initialized
ERROR - 2021-07-22 08:54:27 --> 404 Page Not Found: Sitemap_0xml/index
ERROR - 2021-07-22 08:54:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-22 08:54:36 --> Config Class Initialized
INFO - 2021-07-22 08:54:36 --> Hooks Class Initialized
DEBUG - 2021-07-22 08:54:36 --> UTF-8 Support Enabled
INFO - 2021-07-22 08:54:36 --> Utf8 Class Initialized
INFO - 2021-07-22 08:54:36 --> URI Class Initialized
INFO - 2021-07-22 08:54:36 --> Router Class Initialized
INFO - 2021-07-22 08:54:36 --> Output Class Initialized
INFO - 2021-07-22 08:54:36 --> Security Class Initialized
DEBUG - 2021-07-22 08:54:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-22 08:54:36 --> Input Class Initialized
INFO - 2021-07-22 08:54:36 --> Language Class Initialized
ERROR - 2021-07-22 08:54:36 --> 404 Page Not Found: Sitemap_0xml/index
ERROR - 2021-07-22 08:54:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-22 08:54:54 --> Config Class Initialized
INFO - 2021-07-22 08:54:54 --> Hooks Class Initialized
DEBUG - 2021-07-22 08:54:54 --> UTF-8 Support Enabled
INFO - 2021-07-22 08:54:54 --> Utf8 Class Initialized
INFO - 2021-07-22 08:54:54 --> URI Class Initialized
INFO - 2021-07-22 08:54:54 --> Router Class Initialized
INFO - 2021-07-22 08:54:54 --> Output Class Initialized
INFO - 2021-07-22 08:54:54 --> Security Class Initialized
DEBUG - 2021-07-22 08:54:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-22 08:54:54 --> Input Class Initialized
INFO - 2021-07-22 08:54:54 --> Language Class Initialized
ERROR - 2021-07-22 08:54:54 --> 404 Page Not Found: Sitemap_index_0xml/index
