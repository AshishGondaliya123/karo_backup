<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-02-20 01:09:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-20 01:09:08 --> Config Class Initialized
INFO - 2022-02-20 01:09:08 --> Hooks Class Initialized
DEBUG - 2022-02-20 01:09:08 --> UTF-8 Support Enabled
INFO - 2022-02-20 01:09:08 --> Utf8 Class Initialized
INFO - 2022-02-20 01:09:08 --> URI Class Initialized
DEBUG - 2022-02-20 01:09:08 --> No URI present. Default controller set.
INFO - 2022-02-20 01:09:08 --> Router Class Initialized
INFO - 2022-02-20 01:09:08 --> Output Class Initialized
INFO - 2022-02-20 01:09:08 --> Security Class Initialized
DEBUG - 2022-02-20 01:09:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-20 01:09:08 --> Input Class Initialized
INFO - 2022-02-20 01:09:08 --> Language Class Initialized
INFO - 2022-02-20 01:09:08 --> Loader Class Initialized
INFO - 2022-02-20 01:09:08 --> Helper loaded: url_helper
INFO - 2022-02-20 01:09:08 --> Helper loaded: form_helper
INFO - 2022-02-20 01:09:08 --> Helper loaded: common_helper
INFO - 2022-02-20 01:09:08 --> Database Driver Class Initialized
DEBUG - 2022-02-20 01:09:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-20 01:09:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-20 01:09:08 --> Controller Class Initialized
INFO - 2022-02-20 01:09:08 --> Form Validation Class Initialized
DEBUG - 2022-02-20 01:09:08 --> Encrypt Class Initialized
DEBUG - 2022-02-20 01:09:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-20 01:09:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-20 01:09:08 --> Email Class Initialized
INFO - 2022-02-20 01:09:08 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-20 01:09:08 --> Calendar Class Initialized
INFO - 2022-02-20 01:09:08 --> Model "Login_model" initialized
INFO - 2022-02-20 01:09:08 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-20 01:09:08 --> Final output sent to browser
DEBUG - 2022-02-20 01:09:08 --> Total execution time: 0.0243
ERROR - 2022-02-20 01:54:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-20 01:54:36 --> Config Class Initialized
INFO - 2022-02-20 01:54:36 --> Hooks Class Initialized
DEBUG - 2022-02-20 01:54:36 --> UTF-8 Support Enabled
INFO - 2022-02-20 01:54:36 --> Utf8 Class Initialized
INFO - 2022-02-20 01:54:36 --> URI Class Initialized
DEBUG - 2022-02-20 01:54:36 --> No URI present. Default controller set.
INFO - 2022-02-20 01:54:36 --> Router Class Initialized
INFO - 2022-02-20 01:54:36 --> Output Class Initialized
INFO - 2022-02-20 01:54:36 --> Security Class Initialized
DEBUG - 2022-02-20 01:54:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-20 01:54:36 --> Input Class Initialized
INFO - 2022-02-20 01:54:36 --> Language Class Initialized
INFO - 2022-02-20 01:54:36 --> Loader Class Initialized
INFO - 2022-02-20 01:54:36 --> Helper loaded: url_helper
INFO - 2022-02-20 01:54:36 --> Helper loaded: form_helper
INFO - 2022-02-20 01:54:36 --> Helper loaded: common_helper
INFO - 2022-02-20 01:54:36 --> Database Driver Class Initialized
DEBUG - 2022-02-20 01:54:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-20 01:54:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-20 01:54:36 --> Controller Class Initialized
INFO - 2022-02-20 01:54:36 --> Form Validation Class Initialized
DEBUG - 2022-02-20 01:54:36 --> Encrypt Class Initialized
DEBUG - 2022-02-20 01:54:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-20 01:54:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-20 01:54:36 --> Email Class Initialized
INFO - 2022-02-20 01:54:36 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-20 01:54:36 --> Calendar Class Initialized
INFO - 2022-02-20 01:54:36 --> Model "Login_model" initialized
INFO - 2022-02-20 01:54:36 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-20 01:54:36 --> Final output sent to browser
DEBUG - 2022-02-20 01:54:36 --> Total execution time: 0.0275
ERROR - 2022-02-20 05:56:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-20 05:56:01 --> Config Class Initialized
INFO - 2022-02-20 05:56:01 --> Hooks Class Initialized
DEBUG - 2022-02-20 05:56:01 --> UTF-8 Support Enabled
INFO - 2022-02-20 05:56:01 --> Utf8 Class Initialized
INFO - 2022-02-20 05:56:01 --> URI Class Initialized
DEBUG - 2022-02-20 05:56:01 --> No URI present. Default controller set.
INFO - 2022-02-20 05:56:01 --> Router Class Initialized
INFO - 2022-02-20 05:56:01 --> Output Class Initialized
INFO - 2022-02-20 05:56:01 --> Security Class Initialized
DEBUG - 2022-02-20 05:56:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-20 05:56:01 --> Input Class Initialized
INFO - 2022-02-20 05:56:01 --> Language Class Initialized
INFO - 2022-02-20 05:56:01 --> Loader Class Initialized
INFO - 2022-02-20 05:56:01 --> Helper loaded: url_helper
INFO - 2022-02-20 05:56:01 --> Helper loaded: form_helper
INFO - 2022-02-20 05:56:01 --> Helper loaded: common_helper
INFO - 2022-02-20 05:56:01 --> Database Driver Class Initialized
DEBUG - 2022-02-20 05:56:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-20 05:56:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-20 05:56:01 --> Controller Class Initialized
INFO - 2022-02-20 05:56:01 --> Form Validation Class Initialized
DEBUG - 2022-02-20 05:56:01 --> Encrypt Class Initialized
DEBUG - 2022-02-20 05:56:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-20 05:56:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-20 05:56:01 --> Email Class Initialized
INFO - 2022-02-20 05:56:01 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-20 05:56:01 --> Calendar Class Initialized
INFO - 2022-02-20 05:56:01 --> Model "Login_model" initialized
INFO - 2022-02-20 05:56:01 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-20 05:56:01 --> Final output sent to browser
DEBUG - 2022-02-20 05:56:01 --> Total execution time: 0.0330
ERROR - 2022-02-20 05:57:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-20 05:57:25 --> Config Class Initialized
INFO - 2022-02-20 05:57:25 --> Hooks Class Initialized
DEBUG - 2022-02-20 05:57:25 --> UTF-8 Support Enabled
INFO - 2022-02-20 05:57:25 --> Utf8 Class Initialized
INFO - 2022-02-20 05:57:25 --> URI Class Initialized
DEBUG - 2022-02-20 05:57:25 --> No URI present. Default controller set.
INFO - 2022-02-20 05:57:25 --> Router Class Initialized
INFO - 2022-02-20 05:57:25 --> Output Class Initialized
INFO - 2022-02-20 05:57:25 --> Security Class Initialized
DEBUG - 2022-02-20 05:57:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-20 05:57:25 --> Input Class Initialized
INFO - 2022-02-20 05:57:25 --> Language Class Initialized
INFO - 2022-02-20 05:57:25 --> Loader Class Initialized
INFO - 2022-02-20 05:57:25 --> Helper loaded: url_helper
INFO - 2022-02-20 05:57:25 --> Helper loaded: form_helper
INFO - 2022-02-20 05:57:25 --> Helper loaded: common_helper
INFO - 2022-02-20 05:57:25 --> Database Driver Class Initialized
DEBUG - 2022-02-20 05:57:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-20 05:57:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-20 05:57:25 --> Controller Class Initialized
INFO - 2022-02-20 05:57:25 --> Form Validation Class Initialized
DEBUG - 2022-02-20 05:57:25 --> Encrypt Class Initialized
DEBUG - 2022-02-20 05:57:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-20 05:57:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-20 05:57:25 --> Email Class Initialized
INFO - 2022-02-20 05:57:25 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-20 05:57:25 --> Calendar Class Initialized
INFO - 2022-02-20 05:57:25 --> Model "Login_model" initialized
INFO - 2022-02-20 05:57:25 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-20 05:57:25 --> Final output sent to browser
DEBUG - 2022-02-20 05:57:25 --> Total execution time: 0.0211
ERROR - 2022-02-20 05:57:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-20 05:57:33 --> Config Class Initialized
INFO - 2022-02-20 05:57:33 --> Hooks Class Initialized
DEBUG - 2022-02-20 05:57:33 --> UTF-8 Support Enabled
INFO - 2022-02-20 05:57:33 --> Utf8 Class Initialized
INFO - 2022-02-20 05:57:33 --> URI Class Initialized
DEBUG - 2022-02-20 05:57:33 --> No URI present. Default controller set.
INFO - 2022-02-20 05:57:33 --> Router Class Initialized
INFO - 2022-02-20 05:57:33 --> Output Class Initialized
INFO - 2022-02-20 05:57:33 --> Security Class Initialized
DEBUG - 2022-02-20 05:57:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-20 05:57:33 --> Input Class Initialized
INFO - 2022-02-20 05:57:33 --> Language Class Initialized
INFO - 2022-02-20 05:57:33 --> Loader Class Initialized
INFO - 2022-02-20 05:57:33 --> Helper loaded: url_helper
INFO - 2022-02-20 05:57:33 --> Helper loaded: form_helper
INFO - 2022-02-20 05:57:33 --> Helper loaded: common_helper
INFO - 2022-02-20 05:57:33 --> Database Driver Class Initialized
DEBUG - 2022-02-20 05:57:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-20 05:57:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-20 05:57:33 --> Controller Class Initialized
INFO - 2022-02-20 05:57:33 --> Form Validation Class Initialized
DEBUG - 2022-02-20 05:57:33 --> Encrypt Class Initialized
DEBUG - 2022-02-20 05:57:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-20 05:57:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-20 05:57:33 --> Email Class Initialized
INFO - 2022-02-20 05:57:33 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-20 05:57:33 --> Calendar Class Initialized
INFO - 2022-02-20 05:57:33 --> Model "Login_model" initialized
INFO - 2022-02-20 05:57:33 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-20 05:57:33 --> Final output sent to browser
DEBUG - 2022-02-20 05:57:33 --> Total execution time: 0.0226
ERROR - 2022-02-20 14:16:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-20 14:16:59 --> Config Class Initialized
INFO - 2022-02-20 14:16:59 --> Hooks Class Initialized
DEBUG - 2022-02-20 14:16:59 --> UTF-8 Support Enabled
INFO - 2022-02-20 14:16:59 --> Utf8 Class Initialized
INFO - 2022-02-20 14:16:59 --> URI Class Initialized
DEBUG - 2022-02-20 14:16:59 --> No URI present. Default controller set.
INFO - 2022-02-20 14:16:59 --> Router Class Initialized
INFO - 2022-02-20 14:16:59 --> Output Class Initialized
INFO - 2022-02-20 14:16:59 --> Security Class Initialized
DEBUG - 2022-02-20 14:16:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-20 14:16:59 --> Input Class Initialized
INFO - 2022-02-20 14:16:59 --> Language Class Initialized
INFO - 2022-02-20 14:16:59 --> Loader Class Initialized
INFO - 2022-02-20 14:16:59 --> Helper loaded: url_helper
INFO - 2022-02-20 14:16:59 --> Helper loaded: form_helper
INFO - 2022-02-20 14:16:59 --> Helper loaded: common_helper
INFO - 2022-02-20 14:16:59 --> Database Driver Class Initialized
DEBUG - 2022-02-20 14:16:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-20 14:16:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-20 14:16:59 --> Controller Class Initialized
INFO - 2022-02-20 14:16:59 --> Form Validation Class Initialized
DEBUG - 2022-02-20 14:16:59 --> Encrypt Class Initialized
DEBUG - 2022-02-20 14:16:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-20 14:16:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-20 14:16:59 --> Email Class Initialized
INFO - 2022-02-20 14:16:59 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-20 14:16:59 --> Calendar Class Initialized
INFO - 2022-02-20 14:16:59 --> Model "Login_model" initialized
INFO - 2022-02-20 14:16:59 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-20 14:16:59 --> Final output sent to browser
DEBUG - 2022-02-20 14:16:59 --> Total execution time: 0.0235
ERROR - 2022-02-20 14:16:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-20 14:16:59 --> Config Class Initialized
INFO - 2022-02-20 14:16:59 --> Hooks Class Initialized
DEBUG - 2022-02-20 14:16:59 --> UTF-8 Support Enabled
INFO - 2022-02-20 14:16:59 --> Utf8 Class Initialized
INFO - 2022-02-20 14:16:59 --> URI Class Initialized
INFO - 2022-02-20 14:16:59 --> Router Class Initialized
INFO - 2022-02-20 14:16:59 --> Output Class Initialized
INFO - 2022-02-20 14:17:00 --> Security Class Initialized
DEBUG - 2022-02-20 14:17:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-20 14:17:00 --> Input Class Initialized
INFO - 2022-02-20 14:17:00 --> Language Class Initialized
ERROR - 2022-02-20 14:17:00 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2022-02-20 14:17:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-20 14:17:30 --> Config Class Initialized
INFO - 2022-02-20 14:17:30 --> Hooks Class Initialized
DEBUG - 2022-02-20 14:17:30 --> UTF-8 Support Enabled
INFO - 2022-02-20 14:17:30 --> Utf8 Class Initialized
INFO - 2022-02-20 14:17:30 --> URI Class Initialized
INFO - 2022-02-20 14:17:30 --> Router Class Initialized
INFO - 2022-02-20 14:17:30 --> Output Class Initialized
INFO - 2022-02-20 14:17:30 --> Security Class Initialized
DEBUG - 2022-02-20 14:17:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-20 14:17:30 --> Input Class Initialized
INFO - 2022-02-20 14:17:30 --> Language Class Initialized
INFO - 2022-02-20 14:17:30 --> Loader Class Initialized
INFO - 2022-02-20 14:17:30 --> Helper loaded: url_helper
INFO - 2022-02-20 14:17:30 --> Helper loaded: form_helper
INFO - 2022-02-20 14:17:30 --> Helper loaded: common_helper
INFO - 2022-02-20 14:17:30 --> Database Driver Class Initialized
DEBUG - 2022-02-20 14:17:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-20 14:17:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-20 14:17:30 --> Controller Class Initialized
INFO - 2022-02-20 14:17:30 --> Form Validation Class Initialized
DEBUG - 2022-02-20 14:17:30 --> Encrypt Class Initialized
DEBUG - 2022-02-20 14:17:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-20 14:17:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-20 14:17:30 --> Email Class Initialized
INFO - 2022-02-20 14:17:30 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-20 14:17:30 --> Calendar Class Initialized
INFO - 2022-02-20 14:17:30 --> Model "Login_model" initialized
ERROR - 2022-02-20 14:17:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-20 14:17:31 --> Config Class Initialized
INFO - 2022-02-20 14:17:31 --> Hooks Class Initialized
DEBUG - 2022-02-20 14:17:31 --> UTF-8 Support Enabled
INFO - 2022-02-20 14:17:31 --> Utf8 Class Initialized
INFO - 2022-02-20 14:17:31 --> URI Class Initialized
INFO - 2022-02-20 14:17:31 --> Router Class Initialized
INFO - 2022-02-20 14:17:31 --> Output Class Initialized
INFO - 2022-02-20 14:17:31 --> Security Class Initialized
DEBUG - 2022-02-20 14:17:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-20 14:17:31 --> Input Class Initialized
INFO - 2022-02-20 14:17:31 --> Language Class Initialized
INFO - 2022-02-20 14:17:31 --> Loader Class Initialized
INFO - 2022-02-20 14:17:31 --> Helper loaded: url_helper
INFO - 2022-02-20 14:17:31 --> Helper loaded: form_helper
INFO - 2022-02-20 14:17:31 --> Helper loaded: common_helper
INFO - 2022-02-20 14:17:31 --> Database Driver Class Initialized
DEBUG - 2022-02-20 14:17:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-20 14:17:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-20 14:17:31 --> Controller Class Initialized
INFO - 2022-02-20 14:17:31 --> Form Validation Class Initialized
DEBUG - 2022-02-20 14:17:31 --> Encrypt Class Initialized
DEBUG - 2022-02-20 14:17:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-20 14:17:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-20 14:17:31 --> Email Class Initialized
INFO - 2022-02-20 14:17:31 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-20 14:17:31 --> Calendar Class Initialized
INFO - 2022-02-20 14:17:31 --> Model "Login_model" initialized
ERROR - 2022-02-20 14:17:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-20 14:17:32 --> Config Class Initialized
INFO - 2022-02-20 14:17:32 --> Hooks Class Initialized
DEBUG - 2022-02-20 14:17:32 --> UTF-8 Support Enabled
INFO - 2022-02-20 14:17:32 --> Utf8 Class Initialized
INFO - 2022-02-20 14:17:32 --> URI Class Initialized
DEBUG - 2022-02-20 14:17:32 --> No URI present. Default controller set.
INFO - 2022-02-20 14:17:32 --> Router Class Initialized
INFO - 2022-02-20 14:17:32 --> Output Class Initialized
INFO - 2022-02-20 14:17:32 --> Security Class Initialized
DEBUG - 2022-02-20 14:17:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-20 14:17:32 --> Input Class Initialized
INFO - 2022-02-20 14:17:32 --> Language Class Initialized
INFO - 2022-02-20 14:17:32 --> Loader Class Initialized
INFO - 2022-02-20 14:17:32 --> Helper loaded: url_helper
INFO - 2022-02-20 14:17:32 --> Helper loaded: form_helper
INFO - 2022-02-20 14:17:32 --> Helper loaded: common_helper
INFO - 2022-02-20 14:17:32 --> Database Driver Class Initialized
DEBUG - 2022-02-20 14:17:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-20 14:17:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-20 14:17:32 --> Controller Class Initialized
INFO - 2022-02-20 14:17:32 --> Form Validation Class Initialized
DEBUG - 2022-02-20 14:17:32 --> Encrypt Class Initialized
DEBUG - 2022-02-20 14:17:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-20 14:17:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-20 14:17:32 --> Email Class Initialized
INFO - 2022-02-20 14:17:32 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-20 14:17:32 --> Calendar Class Initialized
INFO - 2022-02-20 14:17:32 --> Model "Login_model" initialized
INFO - 2022-02-20 14:17:32 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-20 14:17:32 --> Final output sent to browser
DEBUG - 2022-02-20 14:17:32 --> Total execution time: 0.0338
ERROR - 2022-02-20 14:17:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-20 14:17:33 --> Config Class Initialized
INFO - 2022-02-20 14:17:33 --> Hooks Class Initialized
DEBUG - 2022-02-20 14:17:33 --> UTF-8 Support Enabled
INFO - 2022-02-20 14:17:33 --> Utf8 Class Initialized
INFO - 2022-02-20 14:17:33 --> URI Class Initialized
INFO - 2022-02-20 14:17:33 --> Router Class Initialized
INFO - 2022-02-20 14:17:33 --> Output Class Initialized
INFO - 2022-02-20 14:17:33 --> Security Class Initialized
DEBUG - 2022-02-20 14:17:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-20 14:17:33 --> Input Class Initialized
INFO - 2022-02-20 14:17:33 --> Language Class Initialized
INFO - 2022-02-20 14:17:33 --> Loader Class Initialized
INFO - 2022-02-20 14:17:33 --> Helper loaded: url_helper
INFO - 2022-02-20 14:17:33 --> Helper loaded: form_helper
INFO - 2022-02-20 14:17:33 --> Helper loaded: common_helper
INFO - 2022-02-20 14:17:33 --> Database Driver Class Initialized
DEBUG - 2022-02-20 14:17:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-20 14:17:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-20 14:17:33 --> Controller Class Initialized
INFO - 2022-02-20 14:17:33 --> Form Validation Class Initialized
DEBUG - 2022-02-20 14:17:33 --> Encrypt Class Initialized
DEBUG - 2022-02-20 14:17:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-20 14:17:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-20 14:17:33 --> Email Class Initialized
INFO - 2022-02-20 14:17:33 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-20 14:17:33 --> Calendar Class Initialized
INFO - 2022-02-20 14:17:33 --> Model "Login_model" initialized
INFO - 2022-02-20 14:17:33 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-20 14:17:33 --> Final output sent to browser
DEBUG - 2022-02-20 14:17:33 --> Total execution time: 0.0340
ERROR - 2022-02-20 15:42:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-20 15:42:45 --> Config Class Initialized
INFO - 2022-02-20 15:42:45 --> Hooks Class Initialized
DEBUG - 2022-02-20 15:42:45 --> UTF-8 Support Enabled
INFO - 2022-02-20 15:42:45 --> Utf8 Class Initialized
INFO - 2022-02-20 15:42:45 --> URI Class Initialized
DEBUG - 2022-02-20 15:42:45 --> No URI present. Default controller set.
INFO - 2022-02-20 15:42:45 --> Router Class Initialized
INFO - 2022-02-20 15:42:45 --> Output Class Initialized
INFO - 2022-02-20 15:42:45 --> Security Class Initialized
DEBUG - 2022-02-20 15:42:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-20 15:42:45 --> Input Class Initialized
INFO - 2022-02-20 15:42:45 --> Language Class Initialized
INFO - 2022-02-20 15:42:45 --> Loader Class Initialized
INFO - 2022-02-20 15:42:45 --> Helper loaded: url_helper
INFO - 2022-02-20 15:42:45 --> Helper loaded: form_helper
INFO - 2022-02-20 15:42:45 --> Helper loaded: common_helper
INFO - 2022-02-20 15:42:45 --> Database Driver Class Initialized
DEBUG - 2022-02-20 15:42:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-20 15:42:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-20 15:42:45 --> Controller Class Initialized
INFO - 2022-02-20 15:42:45 --> Form Validation Class Initialized
DEBUG - 2022-02-20 15:42:45 --> Encrypt Class Initialized
DEBUG - 2022-02-20 15:42:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-20 15:42:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-20 15:42:45 --> Email Class Initialized
INFO - 2022-02-20 15:42:45 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-20 15:42:45 --> Calendar Class Initialized
INFO - 2022-02-20 15:42:45 --> Model "Login_model" initialized
INFO - 2022-02-20 15:42:45 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-20 15:42:45 --> Final output sent to browser
DEBUG - 2022-02-20 15:42:45 --> Total execution time: 0.0364
ERROR - 2022-02-20 16:37:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-20 16:37:06 --> Config Class Initialized
INFO - 2022-02-20 16:37:06 --> Hooks Class Initialized
DEBUG - 2022-02-20 16:37:06 --> UTF-8 Support Enabled
INFO - 2022-02-20 16:37:06 --> Utf8 Class Initialized
INFO - 2022-02-20 16:37:06 --> URI Class Initialized
DEBUG - 2022-02-20 16:37:06 --> No URI present. Default controller set.
INFO - 2022-02-20 16:37:06 --> Router Class Initialized
INFO - 2022-02-20 16:37:06 --> Output Class Initialized
INFO - 2022-02-20 16:37:06 --> Security Class Initialized
DEBUG - 2022-02-20 16:37:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-20 16:37:06 --> Input Class Initialized
INFO - 2022-02-20 16:37:06 --> Language Class Initialized
INFO - 2022-02-20 16:37:06 --> Loader Class Initialized
INFO - 2022-02-20 16:37:06 --> Helper loaded: url_helper
INFO - 2022-02-20 16:37:06 --> Helper loaded: form_helper
INFO - 2022-02-20 16:37:06 --> Helper loaded: common_helper
INFO - 2022-02-20 16:37:06 --> Database Driver Class Initialized
DEBUG - 2022-02-20 16:37:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-20 16:37:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-20 16:37:06 --> Controller Class Initialized
INFO - 2022-02-20 16:37:06 --> Form Validation Class Initialized
DEBUG - 2022-02-20 16:37:06 --> Encrypt Class Initialized
DEBUG - 2022-02-20 16:37:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-20 16:37:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-20 16:37:06 --> Email Class Initialized
INFO - 2022-02-20 16:37:06 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-20 16:37:06 --> Calendar Class Initialized
INFO - 2022-02-20 16:37:06 --> Model "Login_model" initialized
INFO - 2022-02-20 16:37:06 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-20 16:37:06 --> Final output sent to browser
DEBUG - 2022-02-20 16:37:06 --> Total execution time: 0.0453
ERROR - 2022-02-20 16:37:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-20 16:37:07 --> Config Class Initialized
INFO - 2022-02-20 16:37:07 --> Hooks Class Initialized
DEBUG - 2022-02-20 16:37:07 --> UTF-8 Support Enabled
INFO - 2022-02-20 16:37:07 --> Utf8 Class Initialized
INFO - 2022-02-20 16:37:07 --> URI Class Initialized
DEBUG - 2022-02-20 16:37:07 --> No URI present. Default controller set.
INFO - 2022-02-20 16:37:07 --> Router Class Initialized
INFO - 2022-02-20 16:37:07 --> Output Class Initialized
INFO - 2022-02-20 16:37:07 --> Security Class Initialized
DEBUG - 2022-02-20 16:37:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-20 16:37:07 --> Input Class Initialized
INFO - 2022-02-20 16:37:07 --> Language Class Initialized
INFO - 2022-02-20 16:37:07 --> Loader Class Initialized
INFO - 2022-02-20 16:37:07 --> Helper loaded: url_helper
INFO - 2022-02-20 16:37:07 --> Helper loaded: form_helper
INFO - 2022-02-20 16:37:07 --> Helper loaded: common_helper
INFO - 2022-02-20 16:37:07 --> Database Driver Class Initialized
DEBUG - 2022-02-20 16:37:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-20 16:37:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-20 16:37:07 --> Controller Class Initialized
INFO - 2022-02-20 16:37:07 --> Form Validation Class Initialized
DEBUG - 2022-02-20 16:37:07 --> Encrypt Class Initialized
DEBUG - 2022-02-20 16:37:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-20 16:37:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-20 16:37:07 --> Email Class Initialized
INFO - 2022-02-20 16:37:07 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-20 16:37:07 --> Calendar Class Initialized
INFO - 2022-02-20 16:37:07 --> Model "Login_model" initialized
INFO - 2022-02-20 16:37:07 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-20 16:37:07 --> Final output sent to browser
DEBUG - 2022-02-20 16:37:07 --> Total execution time: 0.0503
ERROR - 2022-02-20 16:37:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-20 16:37:08 --> Config Class Initialized
INFO - 2022-02-20 16:37:08 --> Hooks Class Initialized
DEBUG - 2022-02-20 16:37:08 --> UTF-8 Support Enabled
INFO - 2022-02-20 16:37:08 --> Utf8 Class Initialized
INFO - 2022-02-20 16:37:08 --> URI Class Initialized
DEBUG - 2022-02-20 16:37:08 --> No URI present. Default controller set.
INFO - 2022-02-20 16:37:08 --> Router Class Initialized
INFO - 2022-02-20 16:37:08 --> Output Class Initialized
INFO - 2022-02-20 16:37:08 --> Security Class Initialized
DEBUG - 2022-02-20 16:37:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-20 16:37:08 --> Input Class Initialized
INFO - 2022-02-20 16:37:08 --> Language Class Initialized
INFO - 2022-02-20 16:37:08 --> Loader Class Initialized
INFO - 2022-02-20 16:37:08 --> Helper loaded: url_helper
INFO - 2022-02-20 16:37:08 --> Helper loaded: form_helper
INFO - 2022-02-20 16:37:08 --> Helper loaded: common_helper
INFO - 2022-02-20 16:37:08 --> Database Driver Class Initialized
DEBUG - 2022-02-20 16:37:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-20 16:37:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-20 16:37:08 --> Controller Class Initialized
INFO - 2022-02-20 16:37:08 --> Form Validation Class Initialized
DEBUG - 2022-02-20 16:37:08 --> Encrypt Class Initialized
DEBUG - 2022-02-20 16:37:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-20 16:37:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-20 16:37:08 --> Email Class Initialized
INFO - 2022-02-20 16:37:08 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-20 16:37:08 --> Calendar Class Initialized
INFO - 2022-02-20 16:37:08 --> Model "Login_model" initialized
INFO - 2022-02-20 16:37:08 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-20 16:37:08 --> Final output sent to browser
DEBUG - 2022-02-20 16:37:08 --> Total execution time: 0.0426
ERROR - 2022-02-20 16:37:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-20 16:37:10 --> Config Class Initialized
INFO - 2022-02-20 16:37:10 --> Hooks Class Initialized
DEBUG - 2022-02-20 16:37:10 --> UTF-8 Support Enabled
INFO - 2022-02-20 16:37:10 --> Utf8 Class Initialized
INFO - 2022-02-20 16:37:10 --> URI Class Initialized
INFO - 2022-02-20 16:37:10 --> Router Class Initialized
INFO - 2022-02-20 16:37:10 --> Output Class Initialized
INFO - 2022-02-20 16:37:10 --> Security Class Initialized
DEBUG - 2022-02-20 16:37:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-20 16:37:10 --> Input Class Initialized
INFO - 2022-02-20 16:37:10 --> Language Class Initialized
ERROR - 2022-02-20 16:37:10 --> 404 Page Not Found: Blog/wp-includes
ERROR - 2022-02-20 16:37:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-20 16:37:10 --> Config Class Initialized
INFO - 2022-02-20 16:37:10 --> Hooks Class Initialized
DEBUG - 2022-02-20 16:37:10 --> UTF-8 Support Enabled
INFO - 2022-02-20 16:37:10 --> Utf8 Class Initialized
INFO - 2022-02-20 16:37:10 --> URI Class Initialized
INFO - 2022-02-20 16:37:10 --> Router Class Initialized
INFO - 2022-02-20 16:37:10 --> Output Class Initialized
INFO - 2022-02-20 16:37:10 --> Security Class Initialized
DEBUG - 2022-02-20 16:37:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-20 16:37:10 --> Input Class Initialized
INFO - 2022-02-20 16:37:10 --> Language Class Initialized
ERROR - 2022-02-20 16:37:10 --> 404 Page Not Found: Web/wp-includes
ERROR - 2022-02-20 16:37:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-20 16:37:12 --> Config Class Initialized
INFO - 2022-02-20 16:37:12 --> Hooks Class Initialized
DEBUG - 2022-02-20 16:37:12 --> UTF-8 Support Enabled
INFO - 2022-02-20 16:37:12 --> Utf8 Class Initialized
INFO - 2022-02-20 16:37:12 --> URI Class Initialized
INFO - 2022-02-20 16:37:12 --> Router Class Initialized
INFO - 2022-02-20 16:37:12 --> Output Class Initialized
INFO - 2022-02-20 16:37:12 --> Security Class Initialized
DEBUG - 2022-02-20 16:37:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-20 16:37:12 --> Input Class Initialized
INFO - 2022-02-20 16:37:12 --> Language Class Initialized
ERROR - 2022-02-20 16:37:12 --> 404 Page Not Found: Wordpress/wp-includes
ERROR - 2022-02-20 16:37:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-20 16:37:13 --> Config Class Initialized
INFO - 2022-02-20 16:37:13 --> Hooks Class Initialized
DEBUG - 2022-02-20 16:37:13 --> UTF-8 Support Enabled
INFO - 2022-02-20 16:37:13 --> Utf8 Class Initialized
INFO - 2022-02-20 16:37:13 --> URI Class Initialized
INFO - 2022-02-20 16:37:13 --> Router Class Initialized
INFO - 2022-02-20 16:37:13 --> Output Class Initialized
INFO - 2022-02-20 16:37:13 --> Security Class Initialized
DEBUG - 2022-02-20 16:37:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-20 16:37:13 --> Input Class Initialized
INFO - 2022-02-20 16:37:13 --> Language Class Initialized
ERROR - 2022-02-20 16:37:13 --> 404 Page Not Found: Website/wp-includes
ERROR - 2022-02-20 16:37:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-20 16:37:14 --> Config Class Initialized
INFO - 2022-02-20 16:37:14 --> Hooks Class Initialized
DEBUG - 2022-02-20 16:37:14 --> UTF-8 Support Enabled
INFO - 2022-02-20 16:37:14 --> Utf8 Class Initialized
INFO - 2022-02-20 16:37:14 --> URI Class Initialized
INFO - 2022-02-20 16:37:14 --> Router Class Initialized
INFO - 2022-02-20 16:37:14 --> Output Class Initialized
INFO - 2022-02-20 16:37:14 --> Security Class Initialized
DEBUG - 2022-02-20 16:37:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-20 16:37:14 --> Input Class Initialized
INFO - 2022-02-20 16:37:14 --> Language Class Initialized
ERROR - 2022-02-20 16:37:14 --> 404 Page Not Found: Wp/wp-includes
ERROR - 2022-02-20 16:37:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-20 16:37:16 --> Config Class Initialized
INFO - 2022-02-20 16:37:16 --> Hooks Class Initialized
DEBUG - 2022-02-20 16:37:16 --> UTF-8 Support Enabled
INFO - 2022-02-20 16:37:16 --> Utf8 Class Initialized
INFO - 2022-02-20 16:37:16 --> URI Class Initialized
INFO - 2022-02-20 16:37:16 --> Router Class Initialized
INFO - 2022-02-20 16:37:16 --> Output Class Initialized
INFO - 2022-02-20 16:37:16 --> Security Class Initialized
DEBUG - 2022-02-20 16:37:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-20 16:37:16 --> Input Class Initialized
INFO - 2022-02-20 16:37:16 --> Language Class Initialized
ERROR - 2022-02-20 16:37:16 --> 404 Page Not Found: News/wp-includes
ERROR - 2022-02-20 16:37:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-20 16:37:18 --> Config Class Initialized
INFO - 2022-02-20 16:37:18 --> Hooks Class Initialized
DEBUG - 2022-02-20 16:37:18 --> UTF-8 Support Enabled
INFO - 2022-02-20 16:37:18 --> Utf8 Class Initialized
INFO - 2022-02-20 16:37:18 --> URI Class Initialized
INFO - 2022-02-20 16:37:18 --> Router Class Initialized
INFO - 2022-02-20 16:37:18 --> Output Class Initialized
INFO - 2022-02-20 16:37:18 --> Security Class Initialized
DEBUG - 2022-02-20 16:37:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-20 16:37:18 --> Input Class Initialized
INFO - 2022-02-20 16:37:18 --> Language Class Initialized
ERROR - 2022-02-20 16:37:18 --> 404 Page Not Found: 2020/wp-includes
ERROR - 2022-02-20 16:37:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-20 16:37:19 --> Config Class Initialized
INFO - 2022-02-20 16:37:19 --> Hooks Class Initialized
DEBUG - 2022-02-20 16:37:19 --> UTF-8 Support Enabled
INFO - 2022-02-20 16:37:19 --> Utf8 Class Initialized
INFO - 2022-02-20 16:37:19 --> URI Class Initialized
INFO - 2022-02-20 16:37:19 --> Router Class Initialized
INFO - 2022-02-20 16:37:19 --> Output Class Initialized
INFO - 2022-02-20 16:37:19 --> Security Class Initialized
DEBUG - 2022-02-20 16:37:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-20 16:37:19 --> Input Class Initialized
INFO - 2022-02-20 16:37:19 --> Language Class Initialized
ERROR - 2022-02-20 16:37:19 --> 404 Page Not Found: 2019/wp-includes
ERROR - 2022-02-20 16:37:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-20 16:37:21 --> Config Class Initialized
INFO - 2022-02-20 16:37:21 --> Hooks Class Initialized
DEBUG - 2022-02-20 16:37:21 --> UTF-8 Support Enabled
INFO - 2022-02-20 16:37:21 --> Utf8 Class Initialized
INFO - 2022-02-20 16:37:21 --> URI Class Initialized
INFO - 2022-02-20 16:37:21 --> Router Class Initialized
INFO - 2022-02-20 16:37:21 --> Output Class Initialized
INFO - 2022-02-20 16:37:21 --> Security Class Initialized
DEBUG - 2022-02-20 16:37:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-20 16:37:21 --> Input Class Initialized
INFO - 2022-02-20 16:37:21 --> Language Class Initialized
ERROR - 2022-02-20 16:37:21 --> 404 Page Not Found: Shop/wp-includes
ERROR - 2022-02-20 16:37:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-20 16:37:23 --> Config Class Initialized
INFO - 2022-02-20 16:37:23 --> Hooks Class Initialized
DEBUG - 2022-02-20 16:37:23 --> UTF-8 Support Enabled
INFO - 2022-02-20 16:37:23 --> Utf8 Class Initialized
INFO - 2022-02-20 16:37:23 --> URI Class Initialized
INFO - 2022-02-20 16:37:23 --> Router Class Initialized
INFO - 2022-02-20 16:37:23 --> Output Class Initialized
INFO - 2022-02-20 16:37:23 --> Security Class Initialized
DEBUG - 2022-02-20 16:37:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-20 16:37:23 --> Input Class Initialized
INFO - 2022-02-20 16:37:23 --> Language Class Initialized
ERROR - 2022-02-20 16:37:23 --> 404 Page Not Found: Wp1/wp-includes
ERROR - 2022-02-20 16:37:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-20 16:37:26 --> Config Class Initialized
INFO - 2022-02-20 16:37:26 --> Hooks Class Initialized
DEBUG - 2022-02-20 16:37:26 --> UTF-8 Support Enabled
INFO - 2022-02-20 16:37:26 --> Utf8 Class Initialized
INFO - 2022-02-20 16:37:26 --> URI Class Initialized
INFO - 2022-02-20 16:37:26 --> Router Class Initialized
INFO - 2022-02-20 16:37:26 --> Output Class Initialized
INFO - 2022-02-20 16:37:26 --> Security Class Initialized
DEBUG - 2022-02-20 16:37:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-20 16:37:26 --> Input Class Initialized
INFO - 2022-02-20 16:37:26 --> Language Class Initialized
ERROR - 2022-02-20 16:37:26 --> 404 Page Not Found: Test/wp-includes
ERROR - 2022-02-20 16:37:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-20 16:37:28 --> Config Class Initialized
INFO - 2022-02-20 16:37:28 --> Hooks Class Initialized
DEBUG - 2022-02-20 16:37:28 --> UTF-8 Support Enabled
INFO - 2022-02-20 16:37:28 --> Utf8 Class Initialized
INFO - 2022-02-20 16:37:28 --> URI Class Initialized
INFO - 2022-02-20 16:37:28 --> Router Class Initialized
INFO - 2022-02-20 16:37:28 --> Output Class Initialized
INFO - 2022-02-20 16:37:28 --> Security Class Initialized
DEBUG - 2022-02-20 16:37:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-20 16:37:28 --> Input Class Initialized
INFO - 2022-02-20 16:37:28 --> Language Class Initialized
ERROR - 2022-02-20 16:37:28 --> 404 Page Not Found: Wp2/wp-includes
ERROR - 2022-02-20 16:37:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-20 16:37:30 --> Config Class Initialized
INFO - 2022-02-20 16:37:30 --> Hooks Class Initialized
DEBUG - 2022-02-20 16:37:30 --> UTF-8 Support Enabled
INFO - 2022-02-20 16:37:30 --> Utf8 Class Initialized
INFO - 2022-02-20 16:37:30 --> URI Class Initialized
INFO - 2022-02-20 16:37:30 --> Router Class Initialized
INFO - 2022-02-20 16:37:30 --> Output Class Initialized
INFO - 2022-02-20 16:37:30 --> Security Class Initialized
DEBUG - 2022-02-20 16:37:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-20 16:37:30 --> Input Class Initialized
INFO - 2022-02-20 16:37:30 --> Language Class Initialized
ERROR - 2022-02-20 16:37:30 --> 404 Page Not Found: Site/wp-includes
ERROR - 2022-02-20 16:37:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-20 16:37:32 --> Config Class Initialized
INFO - 2022-02-20 16:37:32 --> Hooks Class Initialized
DEBUG - 2022-02-20 16:37:32 --> UTF-8 Support Enabled
INFO - 2022-02-20 16:37:32 --> Utf8 Class Initialized
INFO - 2022-02-20 16:37:32 --> URI Class Initialized
INFO - 2022-02-20 16:37:32 --> Router Class Initialized
INFO - 2022-02-20 16:37:32 --> Output Class Initialized
INFO - 2022-02-20 16:37:32 --> Security Class Initialized
DEBUG - 2022-02-20 16:37:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-20 16:37:32 --> Input Class Initialized
INFO - 2022-02-20 16:37:32 --> Language Class Initialized
ERROR - 2022-02-20 16:37:32 --> 404 Page Not Found: Cms/wp-includes
ERROR - 2022-02-20 16:37:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-20 16:37:34 --> Config Class Initialized
INFO - 2022-02-20 16:37:34 --> Hooks Class Initialized
DEBUG - 2022-02-20 16:37:34 --> UTF-8 Support Enabled
INFO - 2022-02-20 16:37:34 --> Utf8 Class Initialized
INFO - 2022-02-20 16:37:34 --> URI Class Initialized
INFO - 2022-02-20 16:37:34 --> Router Class Initialized
INFO - 2022-02-20 16:37:34 --> Output Class Initialized
INFO - 2022-02-20 16:37:34 --> Security Class Initialized
DEBUG - 2022-02-20 16:37:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-20 16:37:34 --> Input Class Initialized
INFO - 2022-02-20 16:37:34 --> Language Class Initialized
ERROR - 2022-02-20 16:37:34 --> 404 Page Not Found: Sito/wp-includes
ERROR - 2022-02-20 22:18:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-20 22:18:21 --> Config Class Initialized
INFO - 2022-02-20 22:18:21 --> Hooks Class Initialized
DEBUG - 2022-02-20 22:18:21 --> UTF-8 Support Enabled
INFO - 2022-02-20 22:18:21 --> Utf8 Class Initialized
INFO - 2022-02-20 22:18:21 --> URI Class Initialized
DEBUG - 2022-02-20 22:18:21 --> No URI present. Default controller set.
INFO - 2022-02-20 22:18:21 --> Router Class Initialized
INFO - 2022-02-20 22:18:21 --> Output Class Initialized
INFO - 2022-02-20 22:18:21 --> Security Class Initialized
DEBUG - 2022-02-20 22:18:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-20 22:18:21 --> Input Class Initialized
INFO - 2022-02-20 22:18:21 --> Language Class Initialized
INFO - 2022-02-20 22:18:21 --> Loader Class Initialized
INFO - 2022-02-20 22:18:21 --> Helper loaded: url_helper
INFO - 2022-02-20 22:18:21 --> Helper loaded: form_helper
INFO - 2022-02-20 22:18:21 --> Helper loaded: common_helper
INFO - 2022-02-20 22:18:21 --> Database Driver Class Initialized
DEBUG - 2022-02-20 22:18:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-20 22:18:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-20 22:18:21 --> Controller Class Initialized
INFO - 2022-02-20 22:18:21 --> Form Validation Class Initialized
DEBUG - 2022-02-20 22:18:21 --> Encrypt Class Initialized
DEBUG - 2022-02-20 22:18:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-20 22:18:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-20 22:18:21 --> Email Class Initialized
INFO - 2022-02-20 22:18:21 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-20 22:18:21 --> Calendar Class Initialized
INFO - 2022-02-20 22:18:21 --> Model "Login_model" initialized
INFO - 2022-02-20 22:18:21 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-20 22:18:21 --> Final output sent to browser
DEBUG - 2022-02-20 22:18:21 --> Total execution time: 0.0243
ERROR - 2022-02-20 22:18:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-20 22:18:28 --> Config Class Initialized
INFO - 2022-02-20 22:18:28 --> Hooks Class Initialized
DEBUG - 2022-02-20 22:18:28 --> UTF-8 Support Enabled
INFO - 2022-02-20 22:18:28 --> Utf8 Class Initialized
INFO - 2022-02-20 22:18:28 --> URI Class Initialized
INFO - 2022-02-20 22:18:28 --> Router Class Initialized
INFO - 2022-02-20 22:18:28 --> Output Class Initialized
INFO - 2022-02-20 22:18:28 --> Security Class Initialized
DEBUG - 2022-02-20 22:18:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-20 22:18:28 --> Input Class Initialized
INFO - 2022-02-20 22:18:28 --> Language Class Initialized
ERROR - 2022-02-20 22:18:28 --> 404 Page Not Found: Sitemapxml/index
