<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-09-18 04:27:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-18 04:27:34 --> Config Class Initialized
INFO - 2021-09-18 04:27:34 --> Hooks Class Initialized
DEBUG - 2021-09-18 04:27:34 --> UTF-8 Support Enabled
INFO - 2021-09-18 04:27:34 --> Utf8 Class Initialized
INFO - 2021-09-18 04:27:34 --> URI Class Initialized
DEBUG - 2021-09-18 04:27:34 --> No URI present. Default controller set.
INFO - 2021-09-18 04:27:34 --> Router Class Initialized
INFO - 2021-09-18 04:27:34 --> Output Class Initialized
INFO - 2021-09-18 04:27:34 --> Security Class Initialized
DEBUG - 2021-09-18 04:27:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-18 04:27:34 --> Input Class Initialized
INFO - 2021-09-18 04:27:34 --> Language Class Initialized
INFO - 2021-09-18 04:27:34 --> Loader Class Initialized
INFO - 2021-09-18 04:27:34 --> Helper loaded: url_helper
INFO - 2021-09-18 04:27:34 --> Helper loaded: form_helper
INFO - 2021-09-18 04:27:34 --> Helper loaded: common_helper
INFO - 2021-09-18 04:27:34 --> Database Driver Class Initialized
DEBUG - 2021-09-18 04:27:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-18 04:27:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-18 04:27:34 --> Controller Class Initialized
INFO - 2021-09-18 04:27:34 --> Form Validation Class Initialized
DEBUG - 2021-09-18 04:27:34 --> Encrypt Class Initialized
DEBUG - 2021-09-18 04:27:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-09-18 04:27:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-09-18 04:27:34 --> Email Class Initialized
INFO - 2021-09-18 04:27:34 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-09-18 04:27:34 --> Calendar Class Initialized
INFO - 2021-09-18 04:27:34 --> Model "Login_model" initialized
INFO - 2021-09-18 04:27:34 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-09-18 04:27:34 --> Final output sent to browser
DEBUG - 2021-09-18 04:27:34 --> Total execution time: 0.0472
ERROR - 2021-09-18 04:27:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-18 04:27:42 --> Config Class Initialized
INFO - 2021-09-18 04:27:42 --> Hooks Class Initialized
DEBUG - 2021-09-18 04:27:42 --> UTF-8 Support Enabled
INFO - 2021-09-18 04:27:42 --> Utf8 Class Initialized
INFO - 2021-09-18 04:27:42 --> URI Class Initialized
DEBUG - 2021-09-18 04:27:42 --> No URI present. Default controller set.
INFO - 2021-09-18 04:27:42 --> Router Class Initialized
INFO - 2021-09-18 04:27:42 --> Output Class Initialized
INFO - 2021-09-18 04:27:42 --> Security Class Initialized
DEBUG - 2021-09-18 04:27:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-18 04:27:42 --> Input Class Initialized
INFO - 2021-09-18 04:27:42 --> Language Class Initialized
INFO - 2021-09-18 04:27:42 --> Loader Class Initialized
INFO - 2021-09-18 04:27:42 --> Helper loaded: url_helper
INFO - 2021-09-18 04:27:42 --> Helper loaded: form_helper
INFO - 2021-09-18 04:27:42 --> Helper loaded: common_helper
INFO - 2021-09-18 04:27:42 --> Database Driver Class Initialized
DEBUG - 2021-09-18 04:27:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-18 04:27:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-18 04:27:42 --> Controller Class Initialized
INFO - 2021-09-18 04:27:42 --> Form Validation Class Initialized
DEBUG - 2021-09-18 04:27:42 --> Encrypt Class Initialized
DEBUG - 2021-09-18 04:27:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-09-18 04:27:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-09-18 04:27:42 --> Email Class Initialized
INFO - 2021-09-18 04:27:42 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-09-18 04:27:42 --> Calendar Class Initialized
INFO - 2021-09-18 04:27:42 --> Model "Login_model" initialized
INFO - 2021-09-18 04:27:42 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-09-18 04:27:42 --> Final output sent to browser
DEBUG - 2021-09-18 04:27:42 --> Total execution time: 0.0191
