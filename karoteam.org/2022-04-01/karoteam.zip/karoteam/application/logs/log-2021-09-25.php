<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-09-25 02:07:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-25 02:07:55 --> Config Class Initialized
INFO - 2021-09-25 02:07:55 --> Hooks Class Initialized
DEBUG - 2021-09-25 02:07:55 --> UTF-8 Support Enabled
INFO - 2021-09-25 02:07:55 --> Utf8 Class Initialized
INFO - 2021-09-25 02:07:55 --> URI Class Initialized
DEBUG - 2021-09-25 02:07:55 --> No URI present. Default controller set.
INFO - 2021-09-25 02:07:55 --> Router Class Initialized
INFO - 2021-09-25 02:07:55 --> Output Class Initialized
INFO - 2021-09-25 02:07:55 --> Security Class Initialized
DEBUG - 2021-09-25 02:07:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-25 02:07:55 --> Input Class Initialized
INFO - 2021-09-25 02:07:55 --> Language Class Initialized
INFO - 2021-09-25 02:07:55 --> Loader Class Initialized
INFO - 2021-09-25 02:07:55 --> Helper loaded: url_helper
INFO - 2021-09-25 02:07:55 --> Helper loaded: form_helper
INFO - 2021-09-25 02:07:55 --> Helper loaded: common_helper
INFO - 2021-09-25 02:07:55 --> Database Driver Class Initialized
DEBUG - 2021-09-25 02:07:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-25 02:07:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-25 02:07:55 --> Controller Class Initialized
INFO - 2021-09-25 02:07:55 --> Form Validation Class Initialized
DEBUG - 2021-09-25 02:07:55 --> Encrypt Class Initialized
DEBUG - 2021-09-25 02:07:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-09-25 02:07:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-09-25 02:07:55 --> Email Class Initialized
INFO - 2021-09-25 02:07:55 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-09-25 02:07:55 --> Calendar Class Initialized
INFO - 2021-09-25 02:07:55 --> Model "Login_model" initialized
INFO - 2021-09-25 02:07:55 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-09-25 02:07:55 --> Final output sent to browser
DEBUG - 2021-09-25 02:07:55 --> Total execution time: 0.0833
ERROR - 2021-09-25 02:32:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-25 02:32:23 --> Config Class Initialized
INFO - 2021-09-25 02:32:23 --> Hooks Class Initialized
DEBUG - 2021-09-25 02:32:23 --> UTF-8 Support Enabled
INFO - 2021-09-25 02:32:23 --> Utf8 Class Initialized
INFO - 2021-09-25 02:32:23 --> URI Class Initialized
DEBUG - 2021-09-25 02:32:23 --> No URI present. Default controller set.
INFO - 2021-09-25 02:32:23 --> Router Class Initialized
INFO - 2021-09-25 02:32:23 --> Output Class Initialized
INFO - 2021-09-25 02:32:23 --> Security Class Initialized
DEBUG - 2021-09-25 02:32:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-25 02:32:23 --> Input Class Initialized
INFO - 2021-09-25 02:32:23 --> Language Class Initialized
INFO - 2021-09-25 02:32:23 --> Loader Class Initialized
INFO - 2021-09-25 02:32:23 --> Helper loaded: url_helper
INFO - 2021-09-25 02:32:23 --> Helper loaded: form_helper
INFO - 2021-09-25 02:32:23 --> Helper loaded: common_helper
INFO - 2021-09-25 02:32:23 --> Database Driver Class Initialized
DEBUG - 2021-09-25 02:32:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-25 02:32:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-25 02:32:23 --> Controller Class Initialized
INFO - 2021-09-25 02:32:23 --> Form Validation Class Initialized
DEBUG - 2021-09-25 02:32:23 --> Encrypt Class Initialized
DEBUG - 2021-09-25 02:32:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-09-25 02:32:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-09-25 02:32:23 --> Email Class Initialized
INFO - 2021-09-25 02:32:23 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-09-25 02:32:23 --> Calendar Class Initialized
INFO - 2021-09-25 02:32:23 --> Model "Login_model" initialized
INFO - 2021-09-25 02:32:23 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-09-25 02:32:23 --> Final output sent to browser
DEBUG - 2021-09-25 02:32:23 --> Total execution time: 0.0327
ERROR - 2021-09-25 02:32:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-25 02:32:24 --> Config Class Initialized
INFO - 2021-09-25 02:32:24 --> Hooks Class Initialized
DEBUG - 2021-09-25 02:32:24 --> UTF-8 Support Enabled
INFO - 2021-09-25 02:32:24 --> Utf8 Class Initialized
INFO - 2021-09-25 02:32:24 --> URI Class Initialized
INFO - 2021-09-25 02:32:24 --> Router Class Initialized
INFO - 2021-09-25 02:32:24 --> Output Class Initialized
INFO - 2021-09-25 02:32:24 --> Security Class Initialized
DEBUG - 2021-09-25 02:32:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-25 02:32:24 --> Input Class Initialized
INFO - 2021-09-25 02:32:24 --> Language Class Initialized
ERROR - 2021-09-25 02:32:24 --> 404 Page Not Found: Robotstxt/index
