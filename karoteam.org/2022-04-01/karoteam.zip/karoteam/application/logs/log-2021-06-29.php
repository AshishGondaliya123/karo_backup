<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-06-29 10:27:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-29 10:27:10 --> Config Class Initialized
INFO - 2021-06-29 10:27:10 --> Hooks Class Initialized
DEBUG - 2021-06-29 10:27:10 --> UTF-8 Support Enabled
INFO - 2021-06-29 10:27:10 --> Utf8 Class Initialized
INFO - 2021-06-29 10:27:10 --> URI Class Initialized
DEBUG - 2021-06-29 10:27:10 --> No URI present. Default controller set.
INFO - 2021-06-29 10:27:10 --> Router Class Initialized
INFO - 2021-06-29 10:27:10 --> Output Class Initialized
INFO - 2021-06-29 10:27:10 --> Security Class Initialized
DEBUG - 2021-06-29 10:27:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 10:27:10 --> Input Class Initialized
INFO - 2021-06-29 10:27:10 --> Language Class Initialized
INFO - 2021-06-29 10:27:10 --> Loader Class Initialized
INFO - 2021-06-29 10:27:10 --> Helper loaded: url_helper
INFO - 2021-06-29 10:27:10 --> Helper loaded: form_helper
INFO - 2021-06-29 10:27:10 --> Helper loaded: common_helper
INFO - 2021-06-29 10:27:10 --> Database Driver Class Initialized
DEBUG - 2021-06-29 10:27:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 10:27:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 10:27:10 --> Controller Class Initialized
INFO - 2021-06-29 10:27:10 --> Form Validation Class Initialized
DEBUG - 2021-06-29 10:27:10 --> Encrypt Class Initialized
DEBUG - 2021-06-29 10:27:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-06-29 10:27:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-06-29 10:27:10 --> Email Class Initialized
INFO - 2021-06-29 10:27:10 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-06-29 10:27:10 --> Calendar Class Initialized
INFO - 2021-06-29 10:27:10 --> Model "Login_model" initialized
INFO - 2021-06-29 10:27:10 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-06-29 10:27:10 --> Final output sent to browser
DEBUG - 2021-06-29 10:27:10 --> Total execution time: 0.0370
ERROR - 2021-06-29 10:27:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-29 10:27:11 --> Config Class Initialized
INFO - 2021-06-29 10:27:11 --> Hooks Class Initialized
DEBUG - 2021-06-29 10:27:11 --> UTF-8 Support Enabled
INFO - 2021-06-29 10:27:11 --> Utf8 Class Initialized
INFO - 2021-06-29 10:27:11 --> URI Class Initialized
INFO - 2021-06-29 10:27:11 --> Router Class Initialized
INFO - 2021-06-29 10:27:11 --> Output Class Initialized
INFO - 2021-06-29 10:27:11 --> Security Class Initialized
DEBUG - 2021-06-29 10:27:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 10:27:11 --> Input Class Initialized
INFO - 2021-06-29 10:27:11 --> Language Class Initialized
ERROR - 2021-06-29 10:27:11 --> 404 Page Not Found: Robotstxt/index
