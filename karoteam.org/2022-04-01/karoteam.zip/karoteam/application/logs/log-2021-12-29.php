<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-12-29 00:56:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-29 00:56:24 --> Config Class Initialized
INFO - 2021-12-29 00:56:24 --> Hooks Class Initialized
DEBUG - 2021-12-29 00:56:24 --> UTF-8 Support Enabled
INFO - 2021-12-29 00:56:24 --> Utf8 Class Initialized
INFO - 2021-12-29 00:56:24 --> URI Class Initialized
DEBUG - 2021-12-29 00:56:24 --> No URI present. Default controller set.
INFO - 2021-12-29 00:56:24 --> Router Class Initialized
INFO - 2021-12-29 00:56:24 --> Output Class Initialized
INFO - 2021-12-29 00:56:24 --> Security Class Initialized
DEBUG - 2021-12-29 00:56:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-29 00:56:24 --> Input Class Initialized
INFO - 2021-12-29 00:56:24 --> Language Class Initialized
INFO - 2021-12-29 00:56:24 --> Loader Class Initialized
INFO - 2021-12-29 00:56:24 --> Helper loaded: url_helper
INFO - 2021-12-29 00:56:24 --> Helper loaded: form_helper
INFO - 2021-12-29 00:56:24 --> Helper loaded: common_helper
INFO - 2021-12-29 00:56:24 --> Database Driver Class Initialized
DEBUG - 2021-12-29 00:56:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-29 00:56:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-29 00:56:24 --> Controller Class Initialized
INFO - 2021-12-29 00:56:24 --> Form Validation Class Initialized
DEBUG - 2021-12-29 00:56:24 --> Encrypt Class Initialized
DEBUG - 2021-12-29 00:56:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-29 00:56:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-29 00:56:24 --> Email Class Initialized
INFO - 2021-12-29 00:56:24 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-29 00:56:24 --> Calendar Class Initialized
INFO - 2021-12-29 00:56:24 --> Model "Login_model" initialized
INFO - 2021-12-29 00:56:24 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-29 00:56:24 --> Final output sent to browser
DEBUG - 2021-12-29 00:56:24 --> Total execution time: 0.0313
ERROR - 2021-12-29 04:46:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-29 04:46:25 --> Config Class Initialized
INFO - 2021-12-29 04:46:25 --> Hooks Class Initialized
DEBUG - 2021-12-29 04:46:25 --> UTF-8 Support Enabled
INFO - 2021-12-29 04:46:25 --> Utf8 Class Initialized
INFO - 2021-12-29 04:46:25 --> URI Class Initialized
DEBUG - 2021-12-29 04:46:25 --> No URI present. Default controller set.
INFO - 2021-12-29 04:46:25 --> Router Class Initialized
INFO - 2021-12-29 04:46:25 --> Output Class Initialized
INFO - 2021-12-29 04:46:25 --> Security Class Initialized
DEBUG - 2021-12-29 04:46:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-29 04:46:25 --> Input Class Initialized
INFO - 2021-12-29 04:46:25 --> Language Class Initialized
INFO - 2021-12-29 04:46:25 --> Loader Class Initialized
INFO - 2021-12-29 04:46:25 --> Helper loaded: url_helper
INFO - 2021-12-29 04:46:25 --> Helper loaded: form_helper
INFO - 2021-12-29 04:46:25 --> Helper loaded: common_helper
INFO - 2021-12-29 04:46:25 --> Database Driver Class Initialized
DEBUG - 2021-12-29 04:46:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-29 04:46:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-29 04:46:25 --> Controller Class Initialized
INFO - 2021-12-29 04:46:25 --> Form Validation Class Initialized
DEBUG - 2021-12-29 04:46:25 --> Encrypt Class Initialized
DEBUG - 2021-12-29 04:46:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-29 04:46:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-29 04:46:25 --> Email Class Initialized
INFO - 2021-12-29 04:46:25 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-29 04:46:25 --> Calendar Class Initialized
INFO - 2021-12-29 04:46:25 --> Model "Login_model" initialized
INFO - 2021-12-29 04:46:25 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-29 04:46:25 --> Final output sent to browser
DEBUG - 2021-12-29 04:46:25 --> Total execution time: 0.0325
ERROR - 2021-12-29 06:13:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-29 06:13:18 --> Config Class Initialized
INFO - 2021-12-29 06:13:18 --> Hooks Class Initialized
DEBUG - 2021-12-29 06:13:18 --> UTF-8 Support Enabled
INFO - 2021-12-29 06:13:18 --> Utf8 Class Initialized
INFO - 2021-12-29 06:13:18 --> URI Class Initialized
DEBUG - 2021-12-29 06:13:18 --> No URI present. Default controller set.
INFO - 2021-12-29 06:13:18 --> Router Class Initialized
INFO - 2021-12-29 06:13:18 --> Output Class Initialized
INFO - 2021-12-29 06:13:18 --> Security Class Initialized
DEBUG - 2021-12-29 06:13:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-29 06:13:18 --> Input Class Initialized
INFO - 2021-12-29 06:13:18 --> Language Class Initialized
INFO - 2021-12-29 06:13:18 --> Loader Class Initialized
INFO - 2021-12-29 06:13:18 --> Helper loaded: url_helper
INFO - 2021-12-29 06:13:18 --> Helper loaded: form_helper
INFO - 2021-12-29 06:13:18 --> Helper loaded: common_helper
INFO - 2021-12-29 06:13:18 --> Database Driver Class Initialized
DEBUG - 2021-12-29 06:13:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-29 06:13:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-29 06:13:18 --> Controller Class Initialized
INFO - 2021-12-29 06:13:18 --> Form Validation Class Initialized
DEBUG - 2021-12-29 06:13:18 --> Encrypt Class Initialized
DEBUG - 2021-12-29 06:13:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-29 06:13:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-29 06:13:18 --> Email Class Initialized
INFO - 2021-12-29 06:13:18 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-29 06:13:18 --> Calendar Class Initialized
INFO - 2021-12-29 06:13:18 --> Model "Login_model" initialized
INFO - 2021-12-29 06:13:18 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-29 06:13:18 --> Final output sent to browser
DEBUG - 2021-12-29 06:13:18 --> Total execution time: 0.0301
ERROR - 2021-12-29 10:00:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-29 10:00:45 --> Config Class Initialized
INFO - 2021-12-29 10:00:45 --> Hooks Class Initialized
DEBUG - 2021-12-29 10:00:45 --> UTF-8 Support Enabled
INFO - 2021-12-29 10:00:45 --> Utf8 Class Initialized
INFO - 2021-12-29 10:00:45 --> URI Class Initialized
DEBUG - 2021-12-29 10:00:45 --> No URI present. Default controller set.
INFO - 2021-12-29 10:00:45 --> Router Class Initialized
INFO - 2021-12-29 10:00:45 --> Output Class Initialized
INFO - 2021-12-29 10:00:45 --> Security Class Initialized
DEBUG - 2021-12-29 10:00:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-29 10:00:45 --> Input Class Initialized
INFO - 2021-12-29 10:00:45 --> Language Class Initialized
INFO - 2021-12-29 10:00:45 --> Loader Class Initialized
INFO - 2021-12-29 10:00:45 --> Helper loaded: url_helper
INFO - 2021-12-29 10:00:45 --> Helper loaded: form_helper
INFO - 2021-12-29 10:00:45 --> Helper loaded: common_helper
INFO - 2021-12-29 10:00:45 --> Database Driver Class Initialized
DEBUG - 2021-12-29 10:00:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-29 10:00:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-29 10:00:45 --> Controller Class Initialized
INFO - 2021-12-29 10:00:45 --> Form Validation Class Initialized
DEBUG - 2021-12-29 10:00:45 --> Encrypt Class Initialized
DEBUG - 2021-12-29 10:00:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-29 10:00:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-29 10:00:45 --> Email Class Initialized
INFO - 2021-12-29 10:00:45 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-29 10:00:45 --> Calendar Class Initialized
INFO - 2021-12-29 10:00:45 --> Model "Login_model" initialized
INFO - 2021-12-29 10:00:45 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-29 10:00:45 --> Final output sent to browser
DEBUG - 2021-12-29 10:00:45 --> Total execution time: 0.0422
ERROR - 2021-12-29 14:22:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-29 14:22:22 --> Config Class Initialized
INFO - 2021-12-29 14:22:22 --> Hooks Class Initialized
DEBUG - 2021-12-29 14:22:22 --> UTF-8 Support Enabled
INFO - 2021-12-29 14:22:22 --> Utf8 Class Initialized
INFO - 2021-12-29 14:22:22 --> URI Class Initialized
DEBUG - 2021-12-29 14:22:22 --> No URI present. Default controller set.
INFO - 2021-12-29 14:22:22 --> Router Class Initialized
INFO - 2021-12-29 14:22:22 --> Output Class Initialized
INFO - 2021-12-29 14:22:22 --> Security Class Initialized
DEBUG - 2021-12-29 14:22:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-29 14:22:22 --> Input Class Initialized
INFO - 2021-12-29 14:22:22 --> Language Class Initialized
INFO - 2021-12-29 14:22:22 --> Loader Class Initialized
INFO - 2021-12-29 14:22:22 --> Helper loaded: url_helper
INFO - 2021-12-29 14:22:22 --> Helper loaded: form_helper
INFO - 2021-12-29 14:22:22 --> Helper loaded: common_helper
INFO - 2021-12-29 14:22:22 --> Database Driver Class Initialized
DEBUG - 2021-12-29 14:22:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-29 14:22:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-29 14:22:22 --> Controller Class Initialized
INFO - 2021-12-29 14:22:22 --> Form Validation Class Initialized
DEBUG - 2021-12-29 14:22:22 --> Encrypt Class Initialized
DEBUG - 2021-12-29 14:22:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-29 14:22:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-29 14:22:22 --> Email Class Initialized
INFO - 2021-12-29 14:22:22 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-29 14:22:22 --> Calendar Class Initialized
INFO - 2021-12-29 14:22:22 --> Model "Login_model" initialized
INFO - 2021-12-29 14:22:22 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-29 14:22:22 --> Final output sent to browser
DEBUG - 2021-12-29 14:22:22 --> Total execution time: 0.0247
ERROR - 2021-12-29 14:22:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-29 14:22:23 --> Config Class Initialized
INFO - 2021-12-29 14:22:23 --> Hooks Class Initialized
DEBUG - 2021-12-29 14:22:23 --> UTF-8 Support Enabled
INFO - 2021-12-29 14:22:23 --> Utf8 Class Initialized
INFO - 2021-12-29 14:22:23 --> URI Class Initialized
INFO - 2021-12-29 14:22:23 --> Router Class Initialized
INFO - 2021-12-29 14:22:23 --> Output Class Initialized
INFO - 2021-12-29 14:22:23 --> Security Class Initialized
DEBUG - 2021-12-29 14:22:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-29 14:22:23 --> Input Class Initialized
INFO - 2021-12-29 14:22:23 --> Language Class Initialized
ERROR - 2021-12-29 14:22:23 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2021-12-29 14:22:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-29 14:22:38 --> Config Class Initialized
INFO - 2021-12-29 14:22:38 --> Hooks Class Initialized
DEBUG - 2021-12-29 14:22:38 --> UTF-8 Support Enabled
INFO - 2021-12-29 14:22:38 --> Utf8 Class Initialized
INFO - 2021-12-29 14:22:38 --> URI Class Initialized
DEBUG - 2021-12-29 14:22:38 --> No URI present. Default controller set.
INFO - 2021-12-29 14:22:38 --> Router Class Initialized
INFO - 2021-12-29 14:22:38 --> Output Class Initialized
INFO - 2021-12-29 14:22:38 --> Security Class Initialized
DEBUG - 2021-12-29 14:22:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-29 14:22:38 --> Input Class Initialized
INFO - 2021-12-29 14:22:38 --> Language Class Initialized
INFO - 2021-12-29 14:22:38 --> Loader Class Initialized
INFO - 2021-12-29 14:22:38 --> Helper loaded: url_helper
INFO - 2021-12-29 14:22:38 --> Helper loaded: form_helper
INFO - 2021-12-29 14:22:38 --> Helper loaded: common_helper
INFO - 2021-12-29 14:22:38 --> Database Driver Class Initialized
DEBUG - 2021-12-29 14:22:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-29 14:22:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-29 14:22:38 --> Controller Class Initialized
INFO - 2021-12-29 14:22:38 --> Form Validation Class Initialized
DEBUG - 2021-12-29 14:22:38 --> Encrypt Class Initialized
DEBUG - 2021-12-29 14:22:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-29 14:22:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-29 14:22:38 --> Email Class Initialized
INFO - 2021-12-29 14:22:38 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-29 14:22:38 --> Calendar Class Initialized
INFO - 2021-12-29 14:22:38 --> Model "Login_model" initialized
INFO - 2021-12-29 14:22:38 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-29 14:22:38 --> Final output sent to browser
DEBUG - 2021-12-29 14:22:38 --> Total execution time: 0.0234
ERROR - 2021-12-29 14:22:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-29 14:22:38 --> Config Class Initialized
INFO - 2021-12-29 14:22:38 --> Hooks Class Initialized
DEBUG - 2021-12-29 14:22:38 --> UTF-8 Support Enabled
INFO - 2021-12-29 14:22:38 --> Utf8 Class Initialized
INFO - 2021-12-29 14:22:38 --> URI Class Initialized
INFO - 2021-12-29 14:22:38 --> Router Class Initialized
INFO - 2021-12-29 14:22:38 --> Output Class Initialized
INFO - 2021-12-29 14:22:38 --> Security Class Initialized
DEBUG - 2021-12-29 14:22:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-29 14:22:38 --> Input Class Initialized
INFO - 2021-12-29 14:22:38 --> Language Class Initialized
INFO - 2021-12-29 14:22:38 --> Loader Class Initialized
INFO - 2021-12-29 14:22:38 --> Helper loaded: url_helper
INFO - 2021-12-29 14:22:38 --> Helper loaded: form_helper
INFO - 2021-12-29 14:22:38 --> Helper loaded: common_helper
INFO - 2021-12-29 14:22:38 --> Database Driver Class Initialized
DEBUG - 2021-12-29 14:22:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-29 14:22:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-29 14:22:38 --> Controller Class Initialized
INFO - 2021-12-29 14:22:38 --> Form Validation Class Initialized
DEBUG - 2021-12-29 14:22:38 --> Encrypt Class Initialized
DEBUG - 2021-12-29 14:22:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-29 14:22:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-29 14:22:38 --> Email Class Initialized
INFO - 2021-12-29 14:22:38 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-29 14:22:38 --> Calendar Class Initialized
INFO - 2021-12-29 14:22:38 --> Model "Login_model" initialized
ERROR - 2021-12-29 14:22:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-29 14:22:40 --> Config Class Initialized
INFO - 2021-12-29 14:22:40 --> Hooks Class Initialized
DEBUG - 2021-12-29 14:22:40 --> UTF-8 Support Enabled
INFO - 2021-12-29 14:22:40 --> Utf8 Class Initialized
INFO - 2021-12-29 14:22:40 --> URI Class Initialized
INFO - 2021-12-29 14:22:40 --> Router Class Initialized
INFO - 2021-12-29 14:22:40 --> Output Class Initialized
INFO - 2021-12-29 14:22:40 --> Security Class Initialized
DEBUG - 2021-12-29 14:22:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-29 14:22:40 --> Input Class Initialized
INFO - 2021-12-29 14:22:40 --> Language Class Initialized
INFO - 2021-12-29 14:22:40 --> Loader Class Initialized
INFO - 2021-12-29 14:22:40 --> Helper loaded: url_helper
INFO - 2021-12-29 14:22:40 --> Helper loaded: form_helper
INFO - 2021-12-29 14:22:40 --> Helper loaded: common_helper
INFO - 2021-12-29 14:22:40 --> Database Driver Class Initialized
DEBUG - 2021-12-29 14:22:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-29 14:22:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-29 14:22:40 --> Controller Class Initialized
INFO - 2021-12-29 14:22:40 --> Form Validation Class Initialized
DEBUG - 2021-12-29 14:22:40 --> Encrypt Class Initialized
DEBUG - 2021-12-29 14:22:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-29 14:22:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-29 14:22:40 --> Email Class Initialized
INFO - 2021-12-29 14:22:40 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-29 14:22:40 --> Calendar Class Initialized
INFO - 2021-12-29 14:22:40 --> Model "Login_model" initialized
ERROR - 2021-12-29 14:22:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-29 14:22:41 --> Config Class Initialized
INFO - 2021-12-29 14:22:41 --> Hooks Class Initialized
DEBUG - 2021-12-29 14:22:41 --> UTF-8 Support Enabled
INFO - 2021-12-29 14:22:41 --> Utf8 Class Initialized
INFO - 2021-12-29 14:22:41 --> URI Class Initialized
INFO - 2021-12-29 14:22:41 --> Router Class Initialized
INFO - 2021-12-29 14:22:41 --> Output Class Initialized
INFO - 2021-12-29 14:22:41 --> Security Class Initialized
DEBUG - 2021-12-29 14:22:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-29 14:22:41 --> Input Class Initialized
INFO - 2021-12-29 14:22:41 --> Language Class Initialized
INFO - 2021-12-29 14:22:41 --> Loader Class Initialized
INFO - 2021-12-29 14:22:41 --> Helper loaded: url_helper
INFO - 2021-12-29 14:22:41 --> Helper loaded: form_helper
INFO - 2021-12-29 14:22:41 --> Helper loaded: common_helper
INFO - 2021-12-29 14:22:41 --> Database Driver Class Initialized
DEBUG - 2021-12-29 14:22:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-29 14:22:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-29 14:22:41 --> Controller Class Initialized
INFO - 2021-12-29 14:22:41 --> Form Validation Class Initialized
DEBUG - 2021-12-29 14:22:41 --> Encrypt Class Initialized
DEBUG - 2021-12-29 14:22:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-29 14:22:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-29 14:22:41 --> Email Class Initialized
INFO - 2021-12-29 14:22:41 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-29 14:22:41 --> Calendar Class Initialized
INFO - 2021-12-29 14:22:41 --> Model "Login_model" initialized
INFO - 2021-12-29 14:22:41 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-29 14:22:41 --> Final output sent to browser
DEBUG - 2021-12-29 14:22:41 --> Total execution time: 0.0488
ERROR - 2021-12-29 15:24:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-29 15:24:35 --> Config Class Initialized
INFO - 2021-12-29 15:24:35 --> Hooks Class Initialized
DEBUG - 2021-12-29 15:24:35 --> UTF-8 Support Enabled
INFO - 2021-12-29 15:24:35 --> Utf8 Class Initialized
INFO - 2021-12-29 15:24:35 --> URI Class Initialized
DEBUG - 2021-12-29 15:24:35 --> No URI present. Default controller set.
INFO - 2021-12-29 15:24:35 --> Router Class Initialized
INFO - 2021-12-29 15:24:35 --> Output Class Initialized
INFO - 2021-12-29 15:24:35 --> Security Class Initialized
DEBUG - 2021-12-29 15:24:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-29 15:24:35 --> Input Class Initialized
INFO - 2021-12-29 15:24:35 --> Language Class Initialized
INFO - 2021-12-29 15:24:35 --> Loader Class Initialized
INFO - 2021-12-29 15:24:35 --> Helper loaded: url_helper
INFO - 2021-12-29 15:24:35 --> Helper loaded: form_helper
INFO - 2021-12-29 15:24:35 --> Helper loaded: common_helper
INFO - 2021-12-29 15:24:35 --> Database Driver Class Initialized
DEBUG - 2021-12-29 15:24:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-29 15:24:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-29 15:24:35 --> Controller Class Initialized
INFO - 2021-12-29 15:24:35 --> Form Validation Class Initialized
DEBUG - 2021-12-29 15:24:35 --> Encrypt Class Initialized
DEBUG - 2021-12-29 15:24:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-29 15:24:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-29 15:24:35 --> Email Class Initialized
INFO - 2021-12-29 15:24:35 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-29 15:24:35 --> Calendar Class Initialized
INFO - 2021-12-29 15:24:35 --> Model "Login_model" initialized
INFO - 2021-12-29 15:24:35 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-29 15:24:35 --> Final output sent to browser
DEBUG - 2021-12-29 15:24:35 --> Total execution time: 0.0261
ERROR - 2021-12-29 16:39:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-29 16:39:32 --> Config Class Initialized
INFO - 2021-12-29 16:39:32 --> Hooks Class Initialized
DEBUG - 2021-12-29 16:39:32 --> UTF-8 Support Enabled
INFO - 2021-12-29 16:39:32 --> Utf8 Class Initialized
INFO - 2021-12-29 16:39:32 --> URI Class Initialized
DEBUG - 2021-12-29 16:39:32 --> No URI present. Default controller set.
INFO - 2021-12-29 16:39:32 --> Router Class Initialized
INFO - 2021-12-29 16:39:32 --> Output Class Initialized
INFO - 2021-12-29 16:39:32 --> Security Class Initialized
DEBUG - 2021-12-29 16:39:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-29 16:39:32 --> Input Class Initialized
INFO - 2021-12-29 16:39:32 --> Language Class Initialized
INFO - 2021-12-29 16:39:32 --> Loader Class Initialized
INFO - 2021-12-29 16:39:32 --> Helper loaded: url_helper
INFO - 2021-12-29 16:39:32 --> Helper loaded: form_helper
INFO - 2021-12-29 16:39:32 --> Helper loaded: common_helper
INFO - 2021-12-29 16:39:32 --> Database Driver Class Initialized
DEBUG - 2021-12-29 16:39:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-29 16:39:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-29 16:39:32 --> Controller Class Initialized
INFO - 2021-12-29 16:39:32 --> Form Validation Class Initialized
DEBUG - 2021-12-29 16:39:32 --> Encrypt Class Initialized
DEBUG - 2021-12-29 16:39:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-29 16:39:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-29 16:39:32 --> Email Class Initialized
INFO - 2021-12-29 16:39:32 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-29 16:39:32 --> Calendar Class Initialized
INFO - 2021-12-29 16:39:32 --> Model "Login_model" initialized
INFO - 2021-12-29 16:39:32 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-29 16:39:32 --> Final output sent to browser
DEBUG - 2021-12-29 16:39:32 --> Total execution time: 0.0497
ERROR - 2021-12-29 21:30:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-29 21:30:27 --> Config Class Initialized
INFO - 2021-12-29 21:30:27 --> Hooks Class Initialized
DEBUG - 2021-12-29 21:30:27 --> UTF-8 Support Enabled
INFO - 2021-12-29 21:30:27 --> Utf8 Class Initialized
INFO - 2021-12-29 21:30:27 --> URI Class Initialized
DEBUG - 2021-12-29 21:30:27 --> No URI present. Default controller set.
INFO - 2021-12-29 21:30:27 --> Router Class Initialized
INFO - 2021-12-29 21:30:27 --> Output Class Initialized
INFO - 2021-12-29 21:30:28 --> Security Class Initialized
DEBUG - 2021-12-29 21:30:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-29 21:30:28 --> Input Class Initialized
INFO - 2021-12-29 21:30:28 --> Language Class Initialized
INFO - 2021-12-29 21:30:28 --> Loader Class Initialized
INFO - 2021-12-29 21:30:28 --> Helper loaded: url_helper
INFO - 2021-12-29 21:30:28 --> Helper loaded: form_helper
INFO - 2021-12-29 21:30:28 --> Helper loaded: common_helper
INFO - 2021-12-29 21:30:28 --> Database Driver Class Initialized
DEBUG - 2021-12-29 21:30:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-29 21:30:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-29 21:30:28 --> Controller Class Initialized
INFO - 2021-12-29 21:30:28 --> Form Validation Class Initialized
DEBUG - 2021-12-29 21:30:28 --> Encrypt Class Initialized
DEBUG - 2021-12-29 21:30:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-29 21:30:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-29 21:30:28 --> Email Class Initialized
INFO - 2021-12-29 21:30:28 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-29 21:30:28 --> Calendar Class Initialized
INFO - 2021-12-29 21:30:28 --> Model "Login_model" initialized
INFO - 2021-12-29 21:30:28 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-29 21:30:28 --> Final output sent to browser
DEBUG - 2021-12-29 21:30:28 --> Total execution time: 0.3152
ERROR - 2021-12-29 21:30:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-29 21:30:34 --> Config Class Initialized
INFO - 2021-12-29 21:30:34 --> Hooks Class Initialized
DEBUG - 2021-12-29 21:30:34 --> UTF-8 Support Enabled
INFO - 2021-12-29 21:30:34 --> Utf8 Class Initialized
INFO - 2021-12-29 21:30:34 --> URI Class Initialized
DEBUG - 2021-12-29 21:30:34 --> No URI present. Default controller set.
INFO - 2021-12-29 21:30:34 --> Router Class Initialized
INFO - 2021-12-29 21:30:34 --> Output Class Initialized
INFO - 2021-12-29 21:30:34 --> Security Class Initialized
DEBUG - 2021-12-29 21:30:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-29 21:30:34 --> Input Class Initialized
INFO - 2021-12-29 21:30:34 --> Language Class Initialized
INFO - 2021-12-29 21:30:34 --> Loader Class Initialized
INFO - 2021-12-29 21:30:34 --> Helper loaded: url_helper
INFO - 2021-12-29 21:30:34 --> Helper loaded: form_helper
INFO - 2021-12-29 21:30:34 --> Helper loaded: common_helper
INFO - 2021-12-29 21:30:34 --> Database Driver Class Initialized
DEBUG - 2021-12-29 21:30:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-29 21:30:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-29 21:30:34 --> Controller Class Initialized
INFO - 2021-12-29 21:30:34 --> Form Validation Class Initialized
DEBUG - 2021-12-29 21:30:34 --> Encrypt Class Initialized
DEBUG - 2021-12-29 21:30:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-29 21:30:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-29 21:30:34 --> Email Class Initialized
INFO - 2021-12-29 21:30:34 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-29 21:30:34 --> Calendar Class Initialized
INFO - 2021-12-29 21:30:34 --> Model "Login_model" initialized
INFO - 2021-12-29 21:30:34 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-29 21:30:34 --> Final output sent to browser
DEBUG - 2021-12-29 21:30:34 --> Total execution time: 0.0407
ERROR - 2021-12-29 21:30:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-29 21:30:43 --> Config Class Initialized
INFO - 2021-12-29 21:30:43 --> Hooks Class Initialized
DEBUG - 2021-12-29 21:30:43 --> UTF-8 Support Enabled
INFO - 2021-12-29 21:30:43 --> Utf8 Class Initialized
INFO - 2021-12-29 21:30:43 --> URI Class Initialized
INFO - 2021-12-29 21:30:43 --> Router Class Initialized
INFO - 2021-12-29 21:30:43 --> Output Class Initialized
INFO - 2021-12-29 21:30:43 --> Security Class Initialized
DEBUG - 2021-12-29 21:30:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-29 21:30:43 --> Input Class Initialized
INFO - 2021-12-29 21:30:43 --> Language Class Initialized
ERROR - 2021-12-29 21:30:43 --> 404 Page Not Found: Well-known/security.txt
ERROR - 2021-12-29 21:30:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-29 21:30:44 --> Config Class Initialized
INFO - 2021-12-29 21:30:44 --> Hooks Class Initialized
DEBUG - 2021-12-29 21:30:44 --> UTF-8 Support Enabled
INFO - 2021-12-29 21:30:44 --> Utf8 Class Initialized
INFO - 2021-12-29 21:30:44 --> URI Class Initialized
INFO - 2021-12-29 21:30:44 --> Router Class Initialized
INFO - 2021-12-29 21:30:44 --> Output Class Initialized
INFO - 2021-12-29 21:30:44 --> Security Class Initialized
DEBUG - 2021-12-29 21:30:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-29 21:30:44 --> Input Class Initialized
INFO - 2021-12-29 21:30:44 --> Language Class Initialized
ERROR - 2021-12-29 21:30:44 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2021-12-29 21:31:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-29 21:31:31 --> Config Class Initialized
INFO - 2021-12-29 21:31:31 --> Hooks Class Initialized
DEBUG - 2021-12-29 21:31:31 --> UTF-8 Support Enabled
INFO - 2021-12-29 21:31:31 --> Utf8 Class Initialized
INFO - 2021-12-29 21:31:31 --> URI Class Initialized
INFO - 2021-12-29 21:31:31 --> Router Class Initialized
INFO - 2021-12-29 21:31:31 --> Output Class Initialized
INFO - 2021-12-29 21:31:31 --> Security Class Initialized
DEBUG - 2021-12-29 21:31:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-29 21:31:31 --> Input Class Initialized
INFO - 2021-12-29 21:31:31 --> Language Class Initialized
ERROR - 2021-12-29 21:31:31 --> 404 Page Not Found: Well-known/security.txt
ERROR - 2021-12-29 21:31:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-29 21:31:31 --> Config Class Initialized
INFO - 2021-12-29 21:31:31 --> Hooks Class Initialized
DEBUG - 2021-12-29 21:31:31 --> UTF-8 Support Enabled
INFO - 2021-12-29 21:31:31 --> Utf8 Class Initialized
INFO - 2021-12-29 21:31:31 --> URI Class Initialized
INFO - 2021-12-29 21:31:31 --> Router Class Initialized
INFO - 2021-12-29 21:31:31 --> Output Class Initialized
INFO - 2021-12-29 21:31:31 --> Security Class Initialized
DEBUG - 2021-12-29 21:31:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-29 21:31:31 --> Input Class Initialized
INFO - 2021-12-29 21:31:31 --> Language Class Initialized
ERROR - 2021-12-29 21:31:31 --> 404 Page Not Found: Sitemapxml/index
