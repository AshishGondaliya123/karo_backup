<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-04-01 00:24:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-04-01 00:24:08 --> Config Class Initialized
INFO - 2022-04-01 00:24:08 --> Hooks Class Initialized
DEBUG - 2022-04-01 00:24:08 --> UTF-8 Support Enabled
INFO - 2022-04-01 00:24:08 --> Utf8 Class Initialized
INFO - 2022-04-01 00:24:08 --> URI Class Initialized
DEBUG - 2022-04-01 00:24:08 --> No URI present. Default controller set.
INFO - 2022-04-01 00:24:08 --> Router Class Initialized
INFO - 2022-04-01 00:24:08 --> Output Class Initialized
INFO - 2022-04-01 00:24:08 --> Security Class Initialized
DEBUG - 2022-04-01 00:24:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-01 00:24:08 --> Input Class Initialized
INFO - 2022-04-01 00:24:08 --> Language Class Initialized
INFO - 2022-04-01 00:24:08 --> Loader Class Initialized
INFO - 2022-04-01 00:24:08 --> Helper loaded: url_helper
INFO - 2022-04-01 00:24:08 --> Helper loaded: form_helper
INFO - 2022-04-01 00:24:08 --> Helper loaded: common_helper
INFO - 2022-04-01 00:24:08 --> Database Driver Class Initialized
DEBUG - 2022-04-01 00:24:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-01 00:24:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-01 00:24:08 --> Controller Class Initialized
INFO - 2022-04-01 00:24:08 --> Form Validation Class Initialized
DEBUG - 2022-04-01 00:24:08 --> Encrypt Class Initialized
DEBUG - 2022-04-01 00:24:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-04-01 00:24:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-04-01 00:24:08 --> Email Class Initialized
INFO - 2022-04-01 00:24:08 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-04-01 00:24:08 --> Calendar Class Initialized
INFO - 2022-04-01 00:24:08 --> Model "Login_model" initialized
INFO - 2022-04-01 00:24:08 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-04-01 00:24:08 --> Final output sent to browser
DEBUG - 2022-04-01 00:24:08 --> Total execution time: 0.0642
ERROR - 2022-04-01 00:24:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-04-01 00:24:18 --> Config Class Initialized
INFO - 2022-04-01 00:24:18 --> Hooks Class Initialized
DEBUG - 2022-04-01 00:24:18 --> UTF-8 Support Enabled
INFO - 2022-04-01 00:24:18 --> Utf8 Class Initialized
INFO - 2022-04-01 00:24:18 --> URI Class Initialized
INFO - 2022-04-01 00:24:18 --> Router Class Initialized
INFO - 2022-04-01 00:24:18 --> Output Class Initialized
INFO - 2022-04-01 00:24:18 --> Security Class Initialized
DEBUG - 2022-04-01 00:24:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-01 00:24:18 --> Input Class Initialized
INFO - 2022-04-01 00:24:18 --> Language Class Initialized
INFO - 2022-04-01 00:24:18 --> Loader Class Initialized
INFO - 2022-04-01 00:24:18 --> Helper loaded: url_helper
INFO - 2022-04-01 00:24:18 --> Helper loaded: form_helper
INFO - 2022-04-01 00:24:18 --> Helper loaded: common_helper
INFO - 2022-04-01 00:24:18 --> Database Driver Class Initialized
DEBUG - 2022-04-01 00:24:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-01 00:24:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-01 00:24:18 --> Controller Class Initialized
INFO - 2022-04-01 00:24:18 --> Form Validation Class Initialized
DEBUG - 2022-04-01 00:24:18 --> Encrypt Class Initialized
DEBUG - 2022-04-01 00:24:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-04-01 00:24:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-04-01 00:24:18 --> Email Class Initialized
INFO - 2022-04-01 00:24:18 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-04-01 00:24:18 --> Calendar Class Initialized
INFO - 2022-04-01 00:24:18 --> Model "Login_model" initialized
INFO - 2022-04-01 00:24:18 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-04-01 00:24:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-04-01 00:24:18 --> Config Class Initialized
INFO - 2022-04-01 00:24:18 --> Hooks Class Initialized
DEBUG - 2022-04-01 00:24:18 --> UTF-8 Support Enabled
INFO - 2022-04-01 00:24:18 --> Utf8 Class Initialized
INFO - 2022-04-01 00:24:18 --> URI Class Initialized
INFO - 2022-04-01 00:24:18 --> Router Class Initialized
INFO - 2022-04-01 00:24:18 --> Output Class Initialized
INFO - 2022-04-01 00:24:18 --> Security Class Initialized
DEBUG - 2022-04-01 00:24:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-01 00:24:18 --> Input Class Initialized
INFO - 2022-04-01 00:24:18 --> Language Class Initialized
INFO - 2022-04-01 00:24:18 --> Loader Class Initialized
INFO - 2022-04-01 00:24:18 --> Helper loaded: url_helper
INFO - 2022-04-01 00:24:18 --> Helper loaded: form_helper
INFO - 2022-04-01 00:24:18 --> Helper loaded: common_helper
INFO - 2022-04-01 00:24:18 --> Database Driver Class Initialized
DEBUG - 2022-04-01 00:24:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-01 00:24:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-01 00:24:18 --> Controller Class Initialized
INFO - 2022-04-01 00:24:18 --> Form Validation Class Initialized
DEBUG - 2022-04-01 00:24:18 --> Encrypt Class Initialized
INFO - 2022-04-01 00:24:18 --> Model "Login_model" initialized
INFO - 2022-04-01 00:24:18 --> Model "Dashboard_model" initialized
INFO - 2022-04-01 00:24:18 --> Model "Case_model" initialized
INFO - 2022-04-01 00:24:27 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-04-01 00:24:38 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2022-04-01 00:24:38 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-04-01 00:24:38 --> Final output sent to browser
DEBUG - 2022-04-01 00:24:38 --> Total execution time: 19.6802
ERROR - 2022-04-01 00:24:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-04-01 00:24:47 --> Config Class Initialized
INFO - 2022-04-01 00:24:47 --> Hooks Class Initialized
DEBUG - 2022-04-01 00:24:47 --> UTF-8 Support Enabled
INFO - 2022-04-01 00:24:47 --> Utf8 Class Initialized
INFO - 2022-04-01 00:24:47 --> URI Class Initialized
INFO - 2022-04-01 00:24:47 --> Router Class Initialized
INFO - 2022-04-01 00:24:47 --> Output Class Initialized
INFO - 2022-04-01 00:24:47 --> Security Class Initialized
DEBUG - 2022-04-01 00:24:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-01 00:24:47 --> Input Class Initialized
INFO - 2022-04-01 00:24:47 --> Language Class Initialized
INFO - 2022-04-01 00:24:47 --> Loader Class Initialized
INFO - 2022-04-01 00:24:47 --> Helper loaded: url_helper
INFO - 2022-04-01 00:24:47 --> Helper loaded: form_helper
INFO - 2022-04-01 00:24:47 --> Helper loaded: common_helper
INFO - 2022-04-01 00:24:47 --> Database Driver Class Initialized
DEBUG - 2022-04-01 00:24:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-01 00:24:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-01 00:24:47 --> Controller Class Initialized
INFO - 2022-04-01 00:24:47 --> Form Validation Class Initialized
DEBUG - 2022-04-01 00:24:47 --> Encrypt Class Initialized
INFO - 2022-04-01 00:24:47 --> Model "Patient_model" initialized
INFO - 2022-04-01 00:24:47 --> Model "Patientcase_model" initialized
INFO - 2022-04-01 00:24:47 --> Model "Referredby_model" initialized
INFO - 2022-04-01 00:24:47 --> Model "Prefix_master" initialized
INFO - 2022-04-01 00:24:47 --> Model "Hospital_model" initialized
INFO - 2022-04-01 00:24:47 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-04-01 00:24:54 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-04-01 00:24:54 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-04-01 00:24:56 --> Final output sent to browser
DEBUG - 2022-04-01 00:24:56 --> Total execution time: 7.1215
ERROR - 2022-04-01 00:25:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-04-01 00:25:43 --> Config Class Initialized
INFO - 2022-04-01 00:25:43 --> Hooks Class Initialized
DEBUG - 2022-04-01 00:25:43 --> UTF-8 Support Enabled
INFO - 2022-04-01 00:25:43 --> Utf8 Class Initialized
INFO - 2022-04-01 00:25:43 --> URI Class Initialized
INFO - 2022-04-01 00:25:43 --> Router Class Initialized
INFO - 2022-04-01 00:25:43 --> Output Class Initialized
INFO - 2022-04-01 00:25:43 --> Security Class Initialized
DEBUG - 2022-04-01 00:25:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-01 00:25:43 --> Input Class Initialized
INFO - 2022-04-01 00:25:43 --> Language Class Initialized
INFO - 2022-04-01 00:25:43 --> Loader Class Initialized
INFO - 2022-04-01 00:25:43 --> Helper loaded: url_helper
INFO - 2022-04-01 00:25:43 --> Helper loaded: form_helper
INFO - 2022-04-01 00:25:43 --> Helper loaded: common_helper
INFO - 2022-04-01 00:25:43 --> Database Driver Class Initialized
DEBUG - 2022-04-01 00:25:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-01 00:25:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-01 00:25:43 --> Controller Class Initialized
INFO - 2022-04-01 00:25:43 --> Form Validation Class Initialized
DEBUG - 2022-04-01 00:25:43 --> Encrypt Class Initialized
INFO - 2022-04-01 00:25:43 --> Model "Patient_model" initialized
INFO - 2022-04-01 00:25:43 --> Model "Patientcase_model" initialized
INFO - 2022-04-01 00:25:43 --> Model "Referredby_model" initialized
INFO - 2022-04-01 00:25:43 --> Model "Prefix_master" initialized
INFO - 2022-04-01 00:25:43 --> Model "Hospital_model" initialized
INFO - 2022-04-01 00:25:43 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-04-01 00:25:43 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-04-01 00:25:43 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-04-01 00:25:43 --> Final output sent to browser
DEBUG - 2022-04-01 00:25:43 --> Total execution time: 0.2400
ERROR - 2022-04-01 00:35:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-04-01 00:35:47 --> Config Class Initialized
INFO - 2022-04-01 00:35:47 --> Hooks Class Initialized
DEBUG - 2022-04-01 00:35:47 --> UTF-8 Support Enabled
INFO - 2022-04-01 00:35:47 --> Utf8 Class Initialized
INFO - 2022-04-01 00:35:47 --> URI Class Initialized
INFO - 2022-04-01 00:35:47 --> Router Class Initialized
INFO - 2022-04-01 00:35:47 --> Output Class Initialized
INFO - 2022-04-01 00:35:47 --> Security Class Initialized
DEBUG - 2022-04-01 00:35:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-01 00:35:47 --> Input Class Initialized
INFO - 2022-04-01 00:35:47 --> Language Class Initialized
INFO - 2022-04-01 00:35:47 --> Loader Class Initialized
INFO - 2022-04-01 00:35:47 --> Helper loaded: url_helper
INFO - 2022-04-01 00:35:47 --> Helper loaded: form_helper
INFO - 2022-04-01 00:35:47 --> Helper loaded: common_helper
INFO - 2022-04-01 00:35:47 --> Database Driver Class Initialized
DEBUG - 2022-04-01 00:35:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-01 00:35:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-01 00:35:47 --> Controller Class Initialized
INFO - 2022-04-01 00:35:47 --> Form Validation Class Initialized
DEBUG - 2022-04-01 00:35:47 --> Encrypt Class Initialized
INFO - 2022-04-01 00:35:47 --> Model "Patient_model" initialized
INFO - 2022-04-01 00:35:47 --> Model "Patientcase_model" initialized
INFO - 2022-04-01 00:35:47 --> Model "Referredby_model" initialized
INFO - 2022-04-01 00:35:47 --> Model "Prefix_master" initialized
INFO - 2022-04-01 00:35:47 --> Model "Hospital_model" initialized
ERROR - 2022-04-01 00:35:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-04-01 00:35:47 --> Config Class Initialized
INFO - 2022-04-01 00:35:47 --> Hooks Class Initialized
DEBUG - 2022-04-01 00:35:47 --> UTF-8 Support Enabled
INFO - 2022-04-01 00:35:47 --> Utf8 Class Initialized
INFO - 2022-04-01 00:35:47 --> URI Class Initialized
INFO - 2022-04-01 00:35:47 --> Router Class Initialized
INFO - 2022-04-01 00:35:47 --> Output Class Initialized
INFO - 2022-04-01 00:35:47 --> Security Class Initialized
DEBUG - 2022-04-01 00:35:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-01 00:35:47 --> Input Class Initialized
INFO - 2022-04-01 00:35:47 --> Language Class Initialized
INFO - 2022-04-01 00:35:47 --> Loader Class Initialized
INFO - 2022-04-01 00:35:47 --> Helper loaded: url_helper
INFO - 2022-04-01 00:35:47 --> Helper loaded: form_helper
INFO - 2022-04-01 00:35:47 --> Helper loaded: common_helper
INFO - 2022-04-01 00:35:47 --> Database Driver Class Initialized
DEBUG - 2022-04-01 00:35:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-01 00:35:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-01 00:35:47 --> Controller Class Initialized
INFO - 2022-04-01 00:35:47 --> Form Validation Class Initialized
DEBUG - 2022-04-01 00:35:47 --> Encrypt Class Initialized
INFO - 2022-04-01 00:35:47 --> Model "Patient_model" initialized
INFO - 2022-04-01 00:35:47 --> Model "Patientcase_model" initialized
INFO - 2022-04-01 00:35:47 --> Model "Referredby_model" initialized
INFO - 2022-04-01 00:35:47 --> Model "Prefix_master" initialized
INFO - 2022-04-01 00:35:47 --> Model "Hospital_model" initialized
INFO - 2022-04-01 00:35:47 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-04-01 00:35:47 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-04-01 00:35:47 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-04-01 00:35:47 --> Final output sent to browser
DEBUG - 2022-04-01 00:35:47 --> Total execution time: 0.0284
ERROR - 2022-04-01 00:35:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-04-01 00:35:48 --> Config Class Initialized
INFO - 2022-04-01 00:35:48 --> Hooks Class Initialized
DEBUG - 2022-04-01 00:35:48 --> UTF-8 Support Enabled
INFO - 2022-04-01 00:35:48 --> Utf8 Class Initialized
INFO - 2022-04-01 00:35:48 --> URI Class Initialized
INFO - 2022-04-01 00:35:48 --> Router Class Initialized
INFO - 2022-04-01 00:35:48 --> Output Class Initialized
INFO - 2022-04-01 00:35:48 --> Security Class Initialized
DEBUG - 2022-04-01 00:35:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-01 00:35:48 --> Input Class Initialized
INFO - 2022-04-01 00:35:48 --> Language Class Initialized
INFO - 2022-04-01 00:35:48 --> Loader Class Initialized
INFO - 2022-04-01 00:35:48 --> Helper loaded: url_helper
INFO - 2022-04-01 00:35:48 --> Helper loaded: form_helper
INFO - 2022-04-01 00:35:48 --> Helper loaded: common_helper
INFO - 2022-04-01 00:35:48 --> Database Driver Class Initialized
DEBUG - 2022-04-01 00:35:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-01 00:35:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-01 00:35:48 --> Controller Class Initialized
INFO - 2022-04-01 00:35:48 --> Form Validation Class Initialized
DEBUG - 2022-04-01 00:35:48 --> Encrypt Class Initialized
INFO - 2022-04-01 00:35:48 --> Model "Patient_model" initialized
INFO - 2022-04-01 00:35:48 --> Model "Patientcase_model" initialized
INFO - 2022-04-01 00:35:48 --> Model "Prefix_master" initialized
INFO - 2022-04-01 00:35:48 --> Model "Users_model" initialized
INFO - 2022-04-01 00:35:48 --> Model "Hospital_model" initialized
INFO - 2022-04-01 00:35:49 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-04-01 00:35:49 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-04-01 00:35:49 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-04-01 00:35:49 --> Final output sent to browser
DEBUG - 2022-04-01 00:35:49 --> Total execution time: 0.9521
ERROR - 2022-04-01 01:05:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-04-01 01:05:01 --> Config Class Initialized
INFO - 2022-04-01 01:05:01 --> Hooks Class Initialized
DEBUG - 2022-04-01 01:05:01 --> UTF-8 Support Enabled
INFO - 2022-04-01 01:05:01 --> Utf8 Class Initialized
INFO - 2022-04-01 01:05:01 --> URI Class Initialized
INFO - 2022-04-01 01:05:01 --> Router Class Initialized
INFO - 2022-04-01 01:05:01 --> Output Class Initialized
INFO - 2022-04-01 01:05:01 --> Security Class Initialized
DEBUG - 2022-04-01 01:05:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-01 01:05:01 --> Input Class Initialized
INFO - 2022-04-01 01:05:01 --> Language Class Initialized
INFO - 2022-04-01 01:05:01 --> Loader Class Initialized
INFO - 2022-04-01 01:05:01 --> Helper loaded: url_helper
INFO - 2022-04-01 01:05:01 --> Helper loaded: form_helper
INFO - 2022-04-01 01:05:01 --> Helper loaded: common_helper
INFO - 2022-04-01 01:05:01 --> Database Driver Class Initialized
DEBUG - 2022-04-01 01:05:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-01 01:05:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-01 01:05:01 --> Controller Class Initialized
INFO - 2022-04-01 01:05:01 --> Form Validation Class Initialized
DEBUG - 2022-04-01 01:05:01 --> Encrypt Class Initialized
INFO - 2022-04-01 01:05:01 --> Model "Patient_model" initialized
INFO - 2022-04-01 01:05:01 --> Model "Patientcase_model" initialized
INFO - 2022-04-01 01:05:01 --> Model "Referredby_model" initialized
INFO - 2022-04-01 01:05:01 --> Model "Prefix_master" initialized
INFO - 2022-04-01 01:05:01 --> Model "Hospital_model" initialized
INFO - 2022-04-01 01:05:01 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-04-01 01:05:08 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-04-01 01:05:08 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-04-01 01:05:09 --> Final output sent to browser
DEBUG - 2022-04-01 01:05:09 --> Total execution time: 6.9109
ERROR - 2022-04-01 01:06:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-04-01 01:06:23 --> Config Class Initialized
INFO - 2022-04-01 01:06:23 --> Hooks Class Initialized
DEBUG - 2022-04-01 01:06:23 --> UTF-8 Support Enabled
INFO - 2022-04-01 01:06:23 --> Utf8 Class Initialized
INFO - 2022-04-01 01:06:23 --> URI Class Initialized
INFO - 2022-04-01 01:06:23 --> Router Class Initialized
INFO - 2022-04-01 01:06:23 --> Output Class Initialized
INFO - 2022-04-01 01:06:23 --> Security Class Initialized
DEBUG - 2022-04-01 01:06:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-01 01:06:23 --> Input Class Initialized
INFO - 2022-04-01 01:06:23 --> Language Class Initialized
INFO - 2022-04-01 01:06:23 --> Loader Class Initialized
INFO - 2022-04-01 01:06:23 --> Helper loaded: url_helper
INFO - 2022-04-01 01:06:23 --> Helper loaded: form_helper
INFO - 2022-04-01 01:06:23 --> Helper loaded: common_helper
INFO - 2022-04-01 01:06:23 --> Database Driver Class Initialized
DEBUG - 2022-04-01 01:06:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-01 01:06:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-01 01:06:23 --> Controller Class Initialized
INFO - 2022-04-01 01:06:23 --> Form Validation Class Initialized
DEBUG - 2022-04-01 01:06:23 --> Encrypt Class Initialized
INFO - 2022-04-01 01:06:23 --> Model "Patient_model" initialized
INFO - 2022-04-01 01:06:23 --> Model "Patientcase_model" initialized
INFO - 2022-04-01 01:06:23 --> Model "Referredby_model" initialized
INFO - 2022-04-01 01:06:23 --> Model "Prefix_master" initialized
INFO - 2022-04-01 01:06:23 --> Model "Hospital_model" initialized
INFO - 2022-04-01 01:06:23 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-04-01 01:06:23 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-04-01 01:06:23 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-04-01 01:06:23 --> Final output sent to browser
DEBUG - 2022-04-01 01:06:23 --> Total execution time: 0.0300
ERROR - 2022-04-01 01:07:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-04-01 01:07:07 --> Config Class Initialized
INFO - 2022-04-01 01:07:07 --> Hooks Class Initialized
DEBUG - 2022-04-01 01:07:07 --> UTF-8 Support Enabled
INFO - 2022-04-01 01:07:07 --> Utf8 Class Initialized
INFO - 2022-04-01 01:07:07 --> URI Class Initialized
INFO - 2022-04-01 01:07:07 --> Router Class Initialized
INFO - 2022-04-01 01:07:07 --> Output Class Initialized
INFO - 2022-04-01 01:07:07 --> Security Class Initialized
DEBUG - 2022-04-01 01:07:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-01 01:07:07 --> Input Class Initialized
INFO - 2022-04-01 01:07:07 --> Language Class Initialized
INFO - 2022-04-01 01:07:07 --> Loader Class Initialized
INFO - 2022-04-01 01:07:07 --> Helper loaded: url_helper
INFO - 2022-04-01 01:07:07 --> Helper loaded: form_helper
INFO - 2022-04-01 01:07:07 --> Helper loaded: common_helper
INFO - 2022-04-01 01:07:07 --> Database Driver Class Initialized
DEBUG - 2022-04-01 01:07:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-01 01:07:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-01 01:07:07 --> Controller Class Initialized
INFO - 2022-04-01 01:07:07 --> Model "Referredby_model" initialized
INFO - 2022-04-01 01:07:07 --> Final output sent to browser
DEBUG - 2022-04-01 01:07:07 --> Total execution time: 0.0100
ERROR - 2022-04-01 01:07:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-04-01 01:07:13 --> Config Class Initialized
INFO - 2022-04-01 01:07:13 --> Hooks Class Initialized
DEBUG - 2022-04-01 01:07:13 --> UTF-8 Support Enabled
INFO - 2022-04-01 01:07:13 --> Utf8 Class Initialized
INFO - 2022-04-01 01:07:13 --> URI Class Initialized
INFO - 2022-04-01 01:07:13 --> Router Class Initialized
INFO - 2022-04-01 01:07:13 --> Output Class Initialized
INFO - 2022-04-01 01:07:13 --> Security Class Initialized
DEBUG - 2022-04-01 01:07:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-01 01:07:13 --> Input Class Initialized
INFO - 2022-04-01 01:07:13 --> Language Class Initialized
INFO - 2022-04-01 01:07:13 --> Loader Class Initialized
INFO - 2022-04-01 01:07:13 --> Helper loaded: url_helper
INFO - 2022-04-01 01:07:13 --> Helper loaded: form_helper
INFO - 2022-04-01 01:07:13 --> Helper loaded: common_helper
INFO - 2022-04-01 01:07:13 --> Database Driver Class Initialized
DEBUG - 2022-04-01 01:07:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-01 01:07:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-01 01:07:13 --> Controller Class Initialized
INFO - 2022-04-01 01:07:13 --> Model "Referredby_model" initialized
INFO - 2022-04-01 01:07:13 --> Final output sent to browser
DEBUG - 2022-04-01 01:07:13 --> Total execution time: 0.0086
ERROR - 2022-04-01 01:12:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-04-01 01:12:07 --> Config Class Initialized
INFO - 2022-04-01 01:12:07 --> Hooks Class Initialized
DEBUG - 2022-04-01 01:12:07 --> UTF-8 Support Enabled
INFO - 2022-04-01 01:12:07 --> Utf8 Class Initialized
INFO - 2022-04-01 01:12:07 --> URI Class Initialized
INFO - 2022-04-01 01:12:07 --> Router Class Initialized
INFO - 2022-04-01 01:12:07 --> Output Class Initialized
INFO - 2022-04-01 01:12:07 --> Security Class Initialized
DEBUG - 2022-04-01 01:12:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-01 01:12:07 --> Input Class Initialized
INFO - 2022-04-01 01:12:07 --> Language Class Initialized
INFO - 2022-04-01 01:12:07 --> Loader Class Initialized
INFO - 2022-04-01 01:12:07 --> Helper loaded: url_helper
INFO - 2022-04-01 01:12:07 --> Helper loaded: form_helper
INFO - 2022-04-01 01:12:07 --> Helper loaded: common_helper
INFO - 2022-04-01 01:12:07 --> Database Driver Class Initialized
DEBUG - 2022-04-01 01:12:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-01 01:12:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-01 01:12:07 --> Controller Class Initialized
INFO - 2022-04-01 01:12:07 --> Form Validation Class Initialized
DEBUG - 2022-04-01 01:12:07 --> Encrypt Class Initialized
INFO - 2022-04-01 01:12:07 --> Model "Patient_model" initialized
INFO - 2022-04-01 01:12:07 --> Model "Patientcase_model" initialized
INFO - 2022-04-01 01:12:07 --> Model "Referredby_model" initialized
INFO - 2022-04-01 01:12:07 --> Model "Prefix_master" initialized
INFO - 2022-04-01 01:12:07 --> Model "Hospital_model" initialized
ERROR - 2022-04-01 01:12:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-04-01 01:12:07 --> Config Class Initialized
INFO - 2022-04-01 01:12:07 --> Hooks Class Initialized
DEBUG - 2022-04-01 01:12:07 --> UTF-8 Support Enabled
INFO - 2022-04-01 01:12:07 --> Utf8 Class Initialized
INFO - 2022-04-01 01:12:07 --> URI Class Initialized
INFO - 2022-04-01 01:12:07 --> Router Class Initialized
INFO - 2022-04-01 01:12:07 --> Output Class Initialized
INFO - 2022-04-01 01:12:07 --> Security Class Initialized
DEBUG - 2022-04-01 01:12:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-01 01:12:07 --> Input Class Initialized
INFO - 2022-04-01 01:12:07 --> Language Class Initialized
INFO - 2022-04-01 01:12:07 --> Loader Class Initialized
INFO - 2022-04-01 01:12:07 --> Helper loaded: url_helper
INFO - 2022-04-01 01:12:07 --> Helper loaded: form_helper
INFO - 2022-04-01 01:12:07 --> Helper loaded: common_helper
INFO - 2022-04-01 01:12:07 --> Database Driver Class Initialized
DEBUG - 2022-04-01 01:12:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-01 01:12:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-01 01:12:07 --> Controller Class Initialized
INFO - 2022-04-01 01:12:07 --> Form Validation Class Initialized
DEBUG - 2022-04-01 01:12:07 --> Encrypt Class Initialized
INFO - 2022-04-01 01:12:07 --> Model "Patient_model" initialized
INFO - 2022-04-01 01:12:07 --> Model "Patientcase_model" initialized
INFO - 2022-04-01 01:12:07 --> Model "Referredby_model" initialized
INFO - 2022-04-01 01:12:07 --> Model "Prefix_master" initialized
INFO - 2022-04-01 01:12:07 --> Model "Hospital_model" initialized
INFO - 2022-04-01 01:12:07 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-04-01 01:12:07 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-04-01 01:12:07 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-04-01 01:12:07 --> Final output sent to browser
DEBUG - 2022-04-01 01:12:07 --> Total execution time: 0.0275
ERROR - 2022-04-01 01:12:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-04-01 01:12:08 --> Config Class Initialized
INFO - 2022-04-01 01:12:08 --> Hooks Class Initialized
DEBUG - 2022-04-01 01:12:08 --> UTF-8 Support Enabled
INFO - 2022-04-01 01:12:08 --> Utf8 Class Initialized
INFO - 2022-04-01 01:12:08 --> URI Class Initialized
INFO - 2022-04-01 01:12:08 --> Router Class Initialized
INFO - 2022-04-01 01:12:08 --> Output Class Initialized
INFO - 2022-04-01 01:12:08 --> Security Class Initialized
DEBUG - 2022-04-01 01:12:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-01 01:12:08 --> Input Class Initialized
INFO - 2022-04-01 01:12:08 --> Language Class Initialized
INFO - 2022-04-01 01:12:08 --> Loader Class Initialized
INFO - 2022-04-01 01:12:08 --> Helper loaded: url_helper
INFO - 2022-04-01 01:12:08 --> Helper loaded: form_helper
INFO - 2022-04-01 01:12:08 --> Helper loaded: common_helper
INFO - 2022-04-01 01:12:08 --> Database Driver Class Initialized
DEBUG - 2022-04-01 01:12:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-01 01:12:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-01 01:12:08 --> Controller Class Initialized
INFO - 2022-04-01 01:12:08 --> Form Validation Class Initialized
DEBUG - 2022-04-01 01:12:08 --> Encrypt Class Initialized
INFO - 2022-04-01 01:12:08 --> Model "Patient_model" initialized
INFO - 2022-04-01 01:12:08 --> Model "Patientcase_model" initialized
INFO - 2022-04-01 01:12:08 --> Model "Prefix_master" initialized
INFO - 2022-04-01 01:12:08 --> Model "Users_model" initialized
INFO - 2022-04-01 01:12:08 --> Model "Hospital_model" initialized
INFO - 2022-04-01 01:12:08 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-04-01 01:12:08 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-04-01 01:12:08 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-04-01 01:12:08 --> Final output sent to browser
DEBUG - 2022-04-01 01:12:08 --> Total execution time: 0.0492
ERROR - 2022-04-01 01:29:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-04-01 01:29:29 --> Config Class Initialized
INFO - 2022-04-01 01:29:29 --> Hooks Class Initialized
DEBUG - 2022-04-01 01:29:29 --> UTF-8 Support Enabled
INFO - 2022-04-01 01:29:29 --> Utf8 Class Initialized
INFO - 2022-04-01 01:29:29 --> URI Class Initialized
INFO - 2022-04-01 01:29:29 --> Router Class Initialized
INFO - 2022-04-01 01:29:29 --> Output Class Initialized
INFO - 2022-04-01 01:29:29 --> Security Class Initialized
DEBUG - 2022-04-01 01:29:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-01 01:29:29 --> Input Class Initialized
INFO - 2022-04-01 01:29:29 --> Language Class Initialized
INFO - 2022-04-01 01:29:29 --> Loader Class Initialized
INFO - 2022-04-01 01:29:29 --> Helper loaded: url_helper
INFO - 2022-04-01 01:29:29 --> Helper loaded: form_helper
INFO - 2022-04-01 01:29:29 --> Helper loaded: common_helper
INFO - 2022-04-01 01:29:29 --> Database Driver Class Initialized
DEBUG - 2022-04-01 01:29:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-01 01:29:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-01 01:29:29 --> Controller Class Initialized
INFO - 2022-04-01 01:29:29 --> Form Validation Class Initialized
DEBUG - 2022-04-01 01:29:29 --> Encrypt Class Initialized
INFO - 2022-04-01 01:29:29 --> Model "Patient_model" initialized
INFO - 2022-04-01 01:29:29 --> Model "Patientcase_model" initialized
INFO - 2022-04-01 01:29:29 --> Model "Referredby_model" initialized
INFO - 2022-04-01 01:29:29 --> Model "Prefix_master" initialized
INFO - 2022-04-01 01:29:29 --> Model "Hospital_model" initialized
INFO - 2022-04-01 01:29:29 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-04-01 01:29:35 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-04-01 01:29:35 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-04-01 01:29:37 --> Final output sent to browser
DEBUG - 2022-04-01 01:29:37 --> Total execution time: 6.2543
ERROR - 2022-04-01 01:30:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-04-01 01:30:04 --> Config Class Initialized
INFO - 2022-04-01 01:30:04 --> Hooks Class Initialized
DEBUG - 2022-04-01 01:30:04 --> UTF-8 Support Enabled
INFO - 2022-04-01 01:30:04 --> Utf8 Class Initialized
INFO - 2022-04-01 01:30:04 --> URI Class Initialized
INFO - 2022-04-01 01:30:04 --> Router Class Initialized
INFO - 2022-04-01 01:30:04 --> Output Class Initialized
INFO - 2022-04-01 01:30:04 --> Security Class Initialized
DEBUG - 2022-04-01 01:30:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-01 01:30:04 --> Input Class Initialized
INFO - 2022-04-01 01:30:04 --> Language Class Initialized
INFO - 2022-04-01 01:30:04 --> Loader Class Initialized
INFO - 2022-04-01 01:30:04 --> Helper loaded: url_helper
INFO - 2022-04-01 01:30:04 --> Helper loaded: form_helper
INFO - 2022-04-01 01:30:04 --> Helper loaded: common_helper
INFO - 2022-04-01 01:30:04 --> Database Driver Class Initialized
DEBUG - 2022-04-01 01:30:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-01 01:30:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-01 01:30:04 --> Controller Class Initialized
INFO - 2022-04-01 01:30:04 --> Form Validation Class Initialized
DEBUG - 2022-04-01 01:30:04 --> Encrypt Class Initialized
INFO - 2022-04-01 01:30:04 --> Model "Patient_model" initialized
INFO - 2022-04-01 01:30:04 --> Model "Patientcase_model" initialized
INFO - 2022-04-01 01:30:04 --> Model "Referredby_model" initialized
INFO - 2022-04-01 01:30:04 --> Model "Prefix_master" initialized
INFO - 2022-04-01 01:30:04 --> Model "Hospital_model" initialized
INFO - 2022-04-01 01:30:04 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-04-01 01:30:04 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-04-01 01:30:04 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-04-01 01:30:04 --> Final output sent to browser
DEBUG - 2022-04-01 01:30:04 --> Total execution time: 0.0308
ERROR - 2022-04-01 01:39:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-04-01 01:39:01 --> Config Class Initialized
INFO - 2022-04-01 01:39:01 --> Hooks Class Initialized
DEBUG - 2022-04-01 01:39:01 --> UTF-8 Support Enabled
INFO - 2022-04-01 01:39:01 --> Utf8 Class Initialized
INFO - 2022-04-01 01:39:01 --> URI Class Initialized
INFO - 2022-04-01 01:39:01 --> Router Class Initialized
INFO - 2022-04-01 01:39:01 --> Output Class Initialized
INFO - 2022-04-01 01:39:01 --> Security Class Initialized
DEBUG - 2022-04-01 01:39:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-01 01:39:01 --> Input Class Initialized
INFO - 2022-04-01 01:39:01 --> Language Class Initialized
INFO - 2022-04-01 01:39:01 --> Loader Class Initialized
INFO - 2022-04-01 01:39:01 --> Helper loaded: url_helper
INFO - 2022-04-01 01:39:01 --> Helper loaded: form_helper
INFO - 2022-04-01 01:39:01 --> Helper loaded: common_helper
INFO - 2022-04-01 01:39:01 --> Database Driver Class Initialized
DEBUG - 2022-04-01 01:39:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-01 01:39:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-01 01:39:01 --> Controller Class Initialized
INFO - 2022-04-01 01:39:01 --> Form Validation Class Initialized
DEBUG - 2022-04-01 01:39:01 --> Encrypt Class Initialized
INFO - 2022-04-01 01:39:01 --> Model "Patient_model" initialized
INFO - 2022-04-01 01:39:01 --> Model "Patientcase_model" initialized
INFO - 2022-04-01 01:39:01 --> Model "Referredby_model" initialized
INFO - 2022-04-01 01:39:01 --> Model "Prefix_master" initialized
INFO - 2022-04-01 01:39:01 --> Model "Hospital_model" initialized
ERROR - 2022-04-01 01:39:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-04-01 01:39:01 --> Config Class Initialized
INFO - 2022-04-01 01:39:01 --> Hooks Class Initialized
DEBUG - 2022-04-01 01:39:01 --> UTF-8 Support Enabled
INFO - 2022-04-01 01:39:01 --> Utf8 Class Initialized
INFO - 2022-04-01 01:39:01 --> URI Class Initialized
INFO - 2022-04-01 01:39:01 --> Router Class Initialized
INFO - 2022-04-01 01:39:01 --> Output Class Initialized
INFO - 2022-04-01 01:39:01 --> Security Class Initialized
DEBUG - 2022-04-01 01:39:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-01 01:39:01 --> Input Class Initialized
INFO - 2022-04-01 01:39:01 --> Language Class Initialized
INFO - 2022-04-01 01:39:01 --> Loader Class Initialized
INFO - 2022-04-01 01:39:01 --> Helper loaded: url_helper
INFO - 2022-04-01 01:39:01 --> Helper loaded: form_helper
INFO - 2022-04-01 01:39:01 --> Helper loaded: common_helper
INFO - 2022-04-01 01:39:01 --> Database Driver Class Initialized
DEBUG - 2022-04-01 01:39:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-01 01:39:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-01 01:39:01 --> Controller Class Initialized
INFO - 2022-04-01 01:39:01 --> Form Validation Class Initialized
DEBUG - 2022-04-01 01:39:01 --> Encrypt Class Initialized
INFO - 2022-04-01 01:39:01 --> Model "Patient_model" initialized
INFO - 2022-04-01 01:39:01 --> Model "Patientcase_model" initialized
INFO - 2022-04-01 01:39:01 --> Model "Referredby_model" initialized
INFO - 2022-04-01 01:39:01 --> Model "Prefix_master" initialized
INFO - 2022-04-01 01:39:01 --> Model "Hospital_model" initialized
INFO - 2022-04-01 01:39:01 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-04-01 01:39:01 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-04-01 01:39:01 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-04-01 01:39:01 --> Final output sent to browser
DEBUG - 2022-04-01 01:39:01 --> Total execution time: 0.0957
ERROR - 2022-04-01 01:39:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-04-01 01:39:02 --> Config Class Initialized
INFO - 2022-04-01 01:39:02 --> Hooks Class Initialized
DEBUG - 2022-04-01 01:39:02 --> UTF-8 Support Enabled
INFO - 2022-04-01 01:39:02 --> Utf8 Class Initialized
INFO - 2022-04-01 01:39:02 --> URI Class Initialized
INFO - 2022-04-01 01:39:02 --> Router Class Initialized
INFO - 2022-04-01 01:39:02 --> Output Class Initialized
INFO - 2022-04-01 01:39:02 --> Security Class Initialized
DEBUG - 2022-04-01 01:39:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-01 01:39:02 --> Input Class Initialized
INFO - 2022-04-01 01:39:02 --> Language Class Initialized
INFO - 2022-04-01 01:39:02 --> Loader Class Initialized
INFO - 2022-04-01 01:39:02 --> Helper loaded: url_helper
INFO - 2022-04-01 01:39:02 --> Helper loaded: form_helper
INFO - 2022-04-01 01:39:02 --> Helper loaded: common_helper
INFO - 2022-04-01 01:39:02 --> Database Driver Class Initialized
DEBUG - 2022-04-01 01:39:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-01 01:39:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-01 01:39:02 --> Controller Class Initialized
INFO - 2022-04-01 01:39:02 --> Form Validation Class Initialized
DEBUG - 2022-04-01 01:39:02 --> Encrypt Class Initialized
INFO - 2022-04-01 01:39:02 --> Model "Patient_model" initialized
INFO - 2022-04-01 01:39:02 --> Model "Patientcase_model" initialized
INFO - 2022-04-01 01:39:02 --> Model "Prefix_master" initialized
INFO - 2022-04-01 01:39:02 --> Model "Users_model" initialized
INFO - 2022-04-01 01:39:02 --> Model "Hospital_model" initialized
INFO - 2022-04-01 01:39:02 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-04-01 01:39:02 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-04-01 01:39:02 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-04-01 01:39:02 --> Final output sent to browser
DEBUG - 2022-04-01 01:39:02 --> Total execution time: 0.0503
ERROR - 2022-04-01 02:34:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-04-01 02:34:35 --> Config Class Initialized
INFO - 2022-04-01 02:34:35 --> Hooks Class Initialized
DEBUG - 2022-04-01 02:34:35 --> UTF-8 Support Enabled
INFO - 2022-04-01 02:34:35 --> Utf8 Class Initialized
INFO - 2022-04-01 02:34:35 --> URI Class Initialized
DEBUG - 2022-04-01 02:34:35 --> No URI present. Default controller set.
INFO - 2022-04-01 02:34:35 --> Router Class Initialized
INFO - 2022-04-01 02:34:35 --> Output Class Initialized
INFO - 2022-04-01 02:34:35 --> Security Class Initialized
DEBUG - 2022-04-01 02:34:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-01 02:34:35 --> Input Class Initialized
INFO - 2022-04-01 02:34:35 --> Language Class Initialized
INFO - 2022-04-01 02:34:35 --> Loader Class Initialized
INFO - 2022-04-01 02:34:35 --> Helper loaded: url_helper
INFO - 2022-04-01 02:34:35 --> Helper loaded: form_helper
INFO - 2022-04-01 02:34:35 --> Helper loaded: common_helper
INFO - 2022-04-01 02:34:35 --> Database Driver Class Initialized
DEBUG - 2022-04-01 02:34:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-01 02:34:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-01 02:34:35 --> Controller Class Initialized
INFO - 2022-04-01 02:34:35 --> Form Validation Class Initialized
DEBUG - 2022-04-01 02:34:35 --> Encrypt Class Initialized
DEBUG - 2022-04-01 02:34:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-04-01 02:34:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-04-01 02:34:35 --> Email Class Initialized
INFO - 2022-04-01 02:34:35 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-04-01 02:34:35 --> Calendar Class Initialized
INFO - 2022-04-01 02:34:35 --> Model "Login_model" initialized
INFO - 2022-04-01 02:34:35 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-04-01 02:34:35 --> Final output sent to browser
DEBUG - 2022-04-01 02:34:35 --> Total execution time: 0.0547
