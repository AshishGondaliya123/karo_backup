<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-06-08 00:08:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-08 00:08:18 --> Config Class Initialized
INFO - 2021-06-08 00:08:18 --> Hooks Class Initialized
DEBUG - 2021-06-08 00:08:18 --> UTF-8 Support Enabled
INFO - 2021-06-08 00:08:18 --> Utf8 Class Initialized
INFO - 2021-06-08 00:08:18 --> URI Class Initialized
DEBUG - 2021-06-08 00:08:18 --> No URI present. Default controller set.
INFO - 2021-06-08 00:08:18 --> Router Class Initialized
INFO - 2021-06-08 00:08:18 --> Output Class Initialized
INFO - 2021-06-08 00:08:18 --> Security Class Initialized
DEBUG - 2021-06-08 00:08:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-08 00:08:18 --> Input Class Initialized
INFO - 2021-06-08 00:08:18 --> Language Class Initialized
INFO - 2021-06-08 00:08:18 --> Loader Class Initialized
INFO - 2021-06-08 00:08:18 --> Helper loaded: url_helper
INFO - 2021-06-08 00:08:18 --> Helper loaded: form_helper
INFO - 2021-06-08 00:08:18 --> Helper loaded: common_helper
INFO - 2021-06-08 00:08:18 --> Database Driver Class Initialized
DEBUG - 2021-06-08 00:08:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-08 00:08:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-08 00:08:18 --> Controller Class Initialized
INFO - 2021-06-08 00:08:18 --> Form Validation Class Initialized
DEBUG - 2021-06-08 00:08:18 --> Encrypt Class Initialized
DEBUG - 2021-06-08 00:08:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-06-08 00:08:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-06-08 00:08:18 --> Email Class Initialized
INFO - 2021-06-08 00:08:18 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-06-08 00:08:18 --> Calendar Class Initialized
INFO - 2021-06-08 00:08:18 --> Model "Login_model" initialized
INFO - 2021-06-08 00:08:18 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-06-08 00:08:18 --> Final output sent to browser
DEBUG - 2021-06-08 00:08:18 --> Total execution time: 0.0356
ERROR - 2021-06-08 02:55:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-08 02:55:36 --> Config Class Initialized
INFO - 2021-06-08 02:55:36 --> Hooks Class Initialized
DEBUG - 2021-06-08 02:55:36 --> UTF-8 Support Enabled
INFO - 2021-06-08 02:55:36 --> Utf8 Class Initialized
INFO - 2021-06-08 02:55:36 --> URI Class Initialized
DEBUG - 2021-06-08 02:55:36 --> No URI present. Default controller set.
INFO - 2021-06-08 02:55:36 --> Router Class Initialized
INFO - 2021-06-08 02:55:36 --> Output Class Initialized
INFO - 2021-06-08 02:55:36 --> Security Class Initialized
DEBUG - 2021-06-08 02:55:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-08 02:55:36 --> Input Class Initialized
INFO - 2021-06-08 02:55:36 --> Language Class Initialized
INFO - 2021-06-08 02:55:36 --> Loader Class Initialized
INFO - 2021-06-08 02:55:36 --> Helper loaded: url_helper
INFO - 2021-06-08 02:55:36 --> Helper loaded: form_helper
INFO - 2021-06-08 02:55:36 --> Helper loaded: common_helper
INFO - 2021-06-08 02:55:36 --> Database Driver Class Initialized
DEBUG - 2021-06-08 02:55:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-08 02:55:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-08 02:55:36 --> Controller Class Initialized
INFO - 2021-06-08 02:55:36 --> Form Validation Class Initialized
DEBUG - 2021-06-08 02:55:36 --> Encrypt Class Initialized
DEBUG - 2021-06-08 02:55:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-06-08 02:55:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-06-08 02:55:36 --> Email Class Initialized
INFO - 2021-06-08 02:55:36 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-06-08 02:55:36 --> Calendar Class Initialized
INFO - 2021-06-08 02:55:36 --> Model "Login_model" initialized
INFO - 2021-06-08 02:55:36 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-06-08 02:55:36 --> Final output sent to browser
DEBUG - 2021-06-08 02:55:36 --> Total execution time: 0.0368
ERROR - 2021-06-08 12:36:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-08 12:36:26 --> Config Class Initialized
INFO - 2021-06-08 12:36:26 --> Hooks Class Initialized
DEBUG - 2021-06-08 12:36:26 --> UTF-8 Support Enabled
INFO - 2021-06-08 12:36:26 --> Utf8 Class Initialized
INFO - 2021-06-08 12:36:26 --> URI Class Initialized
DEBUG - 2021-06-08 12:36:26 --> No URI present. Default controller set.
INFO - 2021-06-08 12:36:26 --> Router Class Initialized
INFO - 2021-06-08 12:36:26 --> Output Class Initialized
INFO - 2021-06-08 12:36:26 --> Security Class Initialized
DEBUG - 2021-06-08 12:36:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-08 12:36:26 --> Input Class Initialized
INFO - 2021-06-08 12:36:26 --> Language Class Initialized
INFO - 2021-06-08 12:36:26 --> Loader Class Initialized
INFO - 2021-06-08 12:36:26 --> Helper loaded: url_helper
INFO - 2021-06-08 12:36:26 --> Helper loaded: form_helper
INFO - 2021-06-08 12:36:26 --> Helper loaded: common_helper
INFO - 2021-06-08 12:36:26 --> Database Driver Class Initialized
DEBUG - 2021-06-08 12:36:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-08 12:36:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-08 12:36:26 --> Controller Class Initialized
INFO - 2021-06-08 12:36:26 --> Form Validation Class Initialized
DEBUG - 2021-06-08 12:36:26 --> Encrypt Class Initialized
DEBUG - 2021-06-08 12:36:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-06-08 12:36:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-06-08 12:36:26 --> Email Class Initialized
INFO - 2021-06-08 12:36:26 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-06-08 12:36:26 --> Calendar Class Initialized
INFO - 2021-06-08 12:36:26 --> Model "Login_model" initialized
INFO - 2021-06-08 12:36:26 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-06-08 12:36:26 --> Final output sent to browser
DEBUG - 2021-06-08 12:36:26 --> Total execution time: 0.0382
ERROR - 2021-06-08 14:01:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-08 14:01:06 --> Config Class Initialized
INFO - 2021-06-08 14:01:06 --> Hooks Class Initialized
DEBUG - 2021-06-08 14:01:06 --> UTF-8 Support Enabled
INFO - 2021-06-08 14:01:06 --> Utf8 Class Initialized
INFO - 2021-06-08 14:01:06 --> URI Class Initialized
DEBUG - 2021-06-08 14:01:06 --> No URI present. Default controller set.
INFO - 2021-06-08 14:01:06 --> Router Class Initialized
INFO - 2021-06-08 14:01:06 --> Output Class Initialized
INFO - 2021-06-08 14:01:06 --> Security Class Initialized
DEBUG - 2021-06-08 14:01:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-08 14:01:06 --> Input Class Initialized
INFO - 2021-06-08 14:01:06 --> Language Class Initialized
INFO - 2021-06-08 14:01:06 --> Loader Class Initialized
INFO - 2021-06-08 14:01:06 --> Helper loaded: url_helper
INFO - 2021-06-08 14:01:06 --> Helper loaded: form_helper
INFO - 2021-06-08 14:01:06 --> Helper loaded: common_helper
INFO - 2021-06-08 14:01:06 --> Database Driver Class Initialized
DEBUG - 2021-06-08 14:01:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-08 14:01:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-08 14:01:06 --> Controller Class Initialized
INFO - 2021-06-08 14:01:06 --> Form Validation Class Initialized
DEBUG - 2021-06-08 14:01:06 --> Encrypt Class Initialized
DEBUG - 2021-06-08 14:01:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-06-08 14:01:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-06-08 14:01:06 --> Email Class Initialized
INFO - 2021-06-08 14:01:06 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-06-08 14:01:06 --> Calendar Class Initialized
INFO - 2021-06-08 14:01:06 --> Model "Login_model" initialized
INFO - 2021-06-08 14:01:06 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-06-08 14:01:06 --> Final output sent to browser
DEBUG - 2021-06-08 14:01:06 --> Total execution time: 0.0411
ERROR - 2021-06-08 14:57:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-08 14:57:36 --> Config Class Initialized
INFO - 2021-06-08 14:57:36 --> Hooks Class Initialized
DEBUG - 2021-06-08 14:57:36 --> UTF-8 Support Enabled
INFO - 2021-06-08 14:57:36 --> Utf8 Class Initialized
INFO - 2021-06-08 14:57:36 --> URI Class Initialized
DEBUG - 2021-06-08 14:57:36 --> No URI present. Default controller set.
INFO - 2021-06-08 14:57:36 --> Router Class Initialized
INFO - 2021-06-08 14:57:36 --> Output Class Initialized
INFO - 2021-06-08 14:57:36 --> Security Class Initialized
DEBUG - 2021-06-08 14:57:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-08 14:57:36 --> Input Class Initialized
INFO - 2021-06-08 14:57:36 --> Language Class Initialized
INFO - 2021-06-08 14:57:36 --> Loader Class Initialized
INFO - 2021-06-08 14:57:36 --> Helper loaded: url_helper
INFO - 2021-06-08 14:57:36 --> Helper loaded: form_helper
INFO - 2021-06-08 14:57:36 --> Helper loaded: common_helper
INFO - 2021-06-08 14:57:36 --> Database Driver Class Initialized
DEBUG - 2021-06-08 14:57:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-08 14:57:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-08 14:57:36 --> Controller Class Initialized
INFO - 2021-06-08 14:57:36 --> Form Validation Class Initialized
DEBUG - 2021-06-08 14:57:36 --> Encrypt Class Initialized
DEBUG - 2021-06-08 14:57:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-06-08 14:57:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-06-08 14:57:36 --> Email Class Initialized
INFO - 2021-06-08 14:57:36 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-06-08 14:57:36 --> Calendar Class Initialized
INFO - 2021-06-08 14:57:36 --> Model "Login_model" initialized
INFO - 2021-06-08 14:57:36 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-06-08 14:57:36 --> Final output sent to browser
DEBUG - 2021-06-08 14:57:36 --> Total execution time: 0.0489
ERROR - 2021-06-08 18:31:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-08 18:31:27 --> Config Class Initialized
INFO - 2021-06-08 18:31:27 --> Hooks Class Initialized
DEBUG - 2021-06-08 18:31:27 --> UTF-8 Support Enabled
INFO - 2021-06-08 18:31:27 --> Utf8 Class Initialized
INFO - 2021-06-08 18:31:27 --> URI Class Initialized
DEBUG - 2021-06-08 18:31:27 --> No URI present. Default controller set.
INFO - 2021-06-08 18:31:27 --> Router Class Initialized
INFO - 2021-06-08 18:31:27 --> Output Class Initialized
INFO - 2021-06-08 18:31:27 --> Security Class Initialized
DEBUG - 2021-06-08 18:31:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-08 18:31:27 --> Input Class Initialized
INFO - 2021-06-08 18:31:27 --> Language Class Initialized
INFO - 2021-06-08 18:31:27 --> Loader Class Initialized
INFO - 2021-06-08 18:31:27 --> Helper loaded: url_helper
INFO - 2021-06-08 18:31:27 --> Helper loaded: form_helper
INFO - 2021-06-08 18:31:27 --> Helper loaded: common_helper
INFO - 2021-06-08 18:31:27 --> Database Driver Class Initialized
DEBUG - 2021-06-08 18:31:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-08 18:31:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-08 18:31:27 --> Controller Class Initialized
INFO - 2021-06-08 18:31:27 --> Form Validation Class Initialized
DEBUG - 2021-06-08 18:31:27 --> Encrypt Class Initialized
DEBUG - 2021-06-08 18:31:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-06-08 18:31:27 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2021-06-08 18:31:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-08 18:31:27 --> Config Class Initialized
INFO - 2021-06-08 18:31:27 --> Hooks Class Initialized
DEBUG - 2021-06-08 18:31:27 --> UTF-8 Support Enabled
INFO - 2021-06-08 18:31:27 --> Utf8 Class Initialized
INFO - 2021-06-08 18:31:27 --> Email Class Initialized
INFO - 2021-06-08 18:31:27 --> URI Class Initialized
INFO - 2021-06-08 18:31:27 --> Router Class Initialized
INFO - 2021-06-08 18:31:27 --> Output Class Initialized
INFO - 2021-06-08 18:31:27 --> Security Class Initialized
DEBUG - 2021-06-08 18:31:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-08 18:31:27 --> Input Class Initialized
INFO - 2021-06-08 18:31:27 --> Language Class Initialized
INFO - 2021-06-08 18:31:27 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-06-08 18:31:27 --> Calendar Class Initialized
ERROR - 2021-06-08 18:31:27 --> 404 Page Not Found: Robotstxt/index
INFO - 2021-06-08 18:31:27 --> Model "Login_model" initialized
INFO - 2021-06-08 18:31:27 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-06-08 18:31:27 --> Final output sent to browser
DEBUG - 2021-06-08 18:31:27 --> Total execution time: 0.0443
ERROR - 2021-06-08 18:31:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-08 18:31:28 --> Config Class Initialized
INFO - 2021-06-08 18:31:28 --> Hooks Class Initialized
DEBUG - 2021-06-08 18:31:28 --> UTF-8 Support Enabled
INFO - 2021-06-08 18:31:28 --> Utf8 Class Initialized
INFO - 2021-06-08 18:31:28 --> URI Class Initialized
DEBUG - 2021-06-08 18:31:28 --> No URI present. Default controller set.
INFO - 2021-06-08 18:31:28 --> Router Class Initialized
INFO - 2021-06-08 18:31:28 --> Output Class Initialized
INFO - 2021-06-08 18:31:28 --> Security Class Initialized
DEBUG - 2021-06-08 18:31:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-08 18:31:28 --> Input Class Initialized
INFO - 2021-06-08 18:31:28 --> Language Class Initialized
INFO - 2021-06-08 18:31:28 --> Loader Class Initialized
INFO - 2021-06-08 18:31:28 --> Helper loaded: url_helper
INFO - 2021-06-08 18:31:28 --> Helper loaded: form_helper
INFO - 2021-06-08 18:31:28 --> Helper loaded: common_helper
INFO - 2021-06-08 18:31:28 --> Database Driver Class Initialized
DEBUG - 2021-06-08 18:31:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-08 18:31:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-08 18:31:28 --> Controller Class Initialized
INFO - 2021-06-08 18:31:28 --> Form Validation Class Initialized
DEBUG - 2021-06-08 18:31:28 --> Encrypt Class Initialized
DEBUG - 2021-06-08 18:31:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-06-08 18:31:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-06-08 18:31:28 --> Email Class Initialized
INFO - 2021-06-08 18:31:28 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-06-08 18:31:28 --> Calendar Class Initialized
INFO - 2021-06-08 18:31:28 --> Model "Login_model" initialized
INFO - 2021-06-08 18:31:28 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-06-08 18:31:28 --> Final output sent to browser
DEBUG - 2021-06-08 18:31:28 --> Total execution time: 0.0216
ERROR - 2021-06-08 18:31:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-08 18:31:29 --> Config Class Initialized
INFO - 2021-06-08 18:31:29 --> Hooks Class Initialized
DEBUG - 2021-06-08 18:31:29 --> UTF-8 Support Enabled
INFO - 2021-06-08 18:31:29 --> Utf8 Class Initialized
INFO - 2021-06-08 18:31:29 --> URI Class Initialized
INFO - 2021-06-08 18:31:29 --> Router Class Initialized
INFO - 2021-06-08 18:31:29 --> Output Class Initialized
INFO - 2021-06-08 18:31:29 --> Security Class Initialized
DEBUG - 2021-06-08 18:31:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-08 18:31:29 --> Input Class Initialized
INFO - 2021-06-08 18:31:29 --> Language Class Initialized
ERROR - 2021-06-08 18:31:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-08 18:31:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-08 18:31:31 --> Config Class Initialized
INFO - 2021-06-08 18:31:31 --> Hooks Class Initialized
DEBUG - 2021-06-08 18:31:31 --> UTF-8 Support Enabled
INFO - 2021-06-08 18:31:31 --> Utf8 Class Initialized
INFO - 2021-06-08 18:31:31 --> URI Class Initialized
INFO - 2021-06-08 18:31:31 --> Router Class Initialized
INFO - 2021-06-08 18:31:31 --> Output Class Initialized
INFO - 2021-06-08 18:31:31 --> Security Class Initialized
DEBUG - 2021-06-08 18:31:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-08 18:31:31 --> Input Class Initialized
INFO - 2021-06-08 18:31:31 --> Language Class Initialized
INFO - 2021-06-08 18:31:31 --> Loader Class Initialized
INFO - 2021-06-08 18:31:31 --> Helper loaded: url_helper
INFO - 2021-06-08 18:31:31 --> Helper loaded: form_helper
INFO - 2021-06-08 18:31:31 --> Helper loaded: common_helper
INFO - 2021-06-08 18:31:31 --> Database Driver Class Initialized
DEBUG - 2021-06-08 18:31:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-08 18:31:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-08 18:31:31 --> Controller Class Initialized
INFO - 2021-06-08 18:31:31 --> Form Validation Class Initialized
DEBUG - 2021-06-08 18:31:31 --> Encrypt Class Initialized
DEBUG - 2021-06-08 18:31:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-06-08 18:31:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-06-08 18:31:31 --> Email Class Initialized
INFO - 2021-06-08 18:31:31 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-06-08 18:31:31 --> Calendar Class Initialized
INFO - 2021-06-08 18:31:31 --> Model "Login_model" initialized
INFO - 2021-06-08 18:31:31 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2021-06-08 18:31:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-08 18:31:32 --> Config Class Initialized
INFO - 2021-06-08 18:31:32 --> Hooks Class Initialized
DEBUG - 2021-06-08 18:31:32 --> UTF-8 Support Enabled
INFO - 2021-06-08 18:31:32 --> Utf8 Class Initialized
INFO - 2021-06-08 18:31:32 --> URI Class Initialized
INFO - 2021-06-08 18:31:32 --> Router Class Initialized
INFO - 2021-06-08 18:31:32 --> Output Class Initialized
INFO - 2021-06-08 18:31:32 --> Security Class Initialized
DEBUG - 2021-06-08 18:31:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-08 18:31:32 --> Input Class Initialized
INFO - 2021-06-08 18:31:32 --> Language Class Initialized
INFO - 2021-06-08 18:31:32 --> Loader Class Initialized
INFO - 2021-06-08 18:31:32 --> Helper loaded: url_helper
INFO - 2021-06-08 18:31:32 --> Helper loaded: form_helper
INFO - 2021-06-08 18:31:32 --> Helper loaded: common_helper
INFO - 2021-06-08 18:31:32 --> Database Driver Class Initialized
DEBUG - 2021-06-08 18:31:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-08 18:31:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-08 18:31:32 --> Controller Class Initialized
INFO - 2021-06-08 18:31:32 --> Form Validation Class Initialized
DEBUG - 2021-06-08 18:31:32 --> Encrypt Class Initialized
INFO - 2021-06-08 18:31:32 --> Model "Login_model" initialized
INFO - 2021-06-08 18:31:32 --> Model "Dashboard_model" initialized
INFO - 2021-06-08 18:31:32 --> Model "Case_model" initialized
INFO - 2021-06-08 18:31:35 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/header.php
INFO - 2021-06-08 18:31:41 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/dashboard/index.php
INFO - 2021-06-08 18:31:41 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/footer.php
INFO - 2021-06-08 18:31:41 --> Final output sent to browser
DEBUG - 2021-06-08 18:31:41 --> Total execution time: 9.0244
ERROR - 2021-06-08 18:31:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-08 18:31:41 --> Config Class Initialized
INFO - 2021-06-08 18:31:41 --> Hooks Class Initialized
DEBUG - 2021-06-08 18:31:41 --> UTF-8 Support Enabled
INFO - 2021-06-08 18:31:41 --> Utf8 Class Initialized
INFO - 2021-06-08 18:31:41 --> URI Class Initialized
INFO - 2021-06-08 18:31:41 --> Router Class Initialized
INFO - 2021-06-08 18:31:41 --> Output Class Initialized
INFO - 2021-06-08 18:31:41 --> Security Class Initialized
DEBUG - 2021-06-08 18:31:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-08 18:31:41 --> Input Class Initialized
INFO - 2021-06-08 18:31:41 --> Language Class Initialized
ERROR - 2021-06-08 18:31:41 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-06-08 18:31:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-08 18:31:52 --> Config Class Initialized
INFO - 2021-06-08 18:31:52 --> Hooks Class Initialized
DEBUG - 2021-06-08 18:31:52 --> UTF-8 Support Enabled
INFO - 2021-06-08 18:31:52 --> Utf8 Class Initialized
INFO - 2021-06-08 18:31:52 --> URI Class Initialized
INFO - 2021-06-08 18:31:52 --> Router Class Initialized
INFO - 2021-06-08 18:31:52 --> Output Class Initialized
INFO - 2021-06-08 18:31:52 --> Security Class Initialized
DEBUG - 2021-06-08 18:31:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-08 18:31:52 --> Input Class Initialized
INFO - 2021-06-08 18:31:52 --> Language Class Initialized
INFO - 2021-06-08 18:31:52 --> Loader Class Initialized
INFO - 2021-06-08 18:31:52 --> Helper loaded: url_helper
INFO - 2021-06-08 18:31:52 --> Helper loaded: form_helper
INFO - 2021-06-08 18:31:52 --> Helper loaded: common_helper
INFO - 2021-06-08 18:31:52 --> Database Driver Class Initialized
DEBUG - 2021-06-08 18:31:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-08 18:31:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-08 18:31:52 --> Controller Class Initialized
INFO - 2021-06-08 18:31:52 --> Form Validation Class Initialized
INFO - 2021-06-08 18:31:52 --> Model "Report_model" initialized
INFO - 2021-06-08 18:31:52 --> Model "Case_model" initialized
INFO - 2021-06-08 18:31:52 --> Model "Hospital_model" initialized
INFO - 2021-06-08 18:31:52 --> Model "Donner_model" initialized
INFO - 2021-06-08 18:31:52 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/header.php
INFO - 2021-06-08 18:31:52 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/reports/case_wise_patient_details.php
INFO - 2021-06-08 18:31:52 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/footer.php
INFO - 2021-06-08 18:31:52 --> Final output sent to browser
DEBUG - 2021-06-08 18:31:52 --> Total execution time: 0.0212
ERROR - 2021-06-08 18:31:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-08 18:31:53 --> Config Class Initialized
INFO - 2021-06-08 18:31:53 --> Hooks Class Initialized
DEBUG - 2021-06-08 18:31:53 --> UTF-8 Support Enabled
INFO - 2021-06-08 18:31:53 --> Utf8 Class Initialized
INFO - 2021-06-08 18:31:53 --> URI Class Initialized
INFO - 2021-06-08 18:31:53 --> Router Class Initialized
INFO - 2021-06-08 18:31:53 --> Output Class Initialized
INFO - 2021-06-08 18:31:53 --> Security Class Initialized
DEBUG - 2021-06-08 18:31:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-08 18:31:53 --> Input Class Initialized
INFO - 2021-06-08 18:31:53 --> Language Class Initialized
ERROR - 2021-06-08 18:31:53 --> 404 Page Not Found: Karoclient/usersprofile
