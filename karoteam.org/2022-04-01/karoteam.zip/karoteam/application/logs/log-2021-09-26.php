<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-09-26 02:33:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-26 02:33:41 --> Config Class Initialized
INFO - 2021-09-26 02:33:41 --> Hooks Class Initialized
DEBUG - 2021-09-26 02:33:41 --> UTF-8 Support Enabled
INFO - 2021-09-26 02:33:41 --> Utf8 Class Initialized
INFO - 2021-09-26 02:33:41 --> URI Class Initialized
INFO - 2021-09-26 02:33:41 --> Router Class Initialized
INFO - 2021-09-26 02:33:41 --> Output Class Initialized
INFO - 2021-09-26 02:33:41 --> Security Class Initialized
DEBUG - 2021-09-26 02:33:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-26 02:33:41 --> Input Class Initialized
INFO - 2021-09-26 02:33:41 --> Language Class Initialized
ERROR - 2021-09-26 02:33:41 --> 404 Page Not Found: 2indexphp/index
ERROR - 2021-09-26 02:33:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-26 02:33:41 --> Config Class Initialized
INFO - 2021-09-26 02:33:41 --> Hooks Class Initialized
DEBUG - 2021-09-26 02:33:41 --> UTF-8 Support Enabled
INFO - 2021-09-26 02:33:41 --> Utf8 Class Initialized
INFO - 2021-09-26 02:33:41 --> URI Class Initialized
INFO - 2021-09-26 02:33:41 --> Router Class Initialized
INFO - 2021-09-26 02:33:41 --> Output Class Initialized
INFO - 2021-09-26 02:33:41 --> Security Class Initialized
DEBUG - 2021-09-26 02:33:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-26 02:33:41 --> Input Class Initialized
INFO - 2021-09-26 02:33:41 --> Language Class Initialized
ERROR - 2021-09-26 02:33:41 --> 404 Page Not Found: 1indexphp/index
ERROR - 2021-09-26 12:04:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-26 12:04:11 --> Config Class Initialized
INFO - 2021-09-26 12:04:11 --> Hooks Class Initialized
DEBUG - 2021-09-26 12:04:11 --> UTF-8 Support Enabled
INFO - 2021-09-26 12:04:11 --> Utf8 Class Initialized
INFO - 2021-09-26 12:04:11 --> URI Class Initialized
DEBUG - 2021-09-26 12:04:11 --> No URI present. Default controller set.
INFO - 2021-09-26 12:04:11 --> Router Class Initialized
INFO - 2021-09-26 12:04:11 --> Output Class Initialized
INFO - 2021-09-26 12:04:11 --> Security Class Initialized
DEBUG - 2021-09-26 12:04:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-26 12:04:11 --> Input Class Initialized
INFO - 2021-09-26 12:04:11 --> Language Class Initialized
INFO - 2021-09-26 12:04:11 --> Loader Class Initialized
INFO - 2021-09-26 12:04:11 --> Helper loaded: url_helper
INFO - 2021-09-26 12:04:11 --> Helper loaded: form_helper
INFO - 2021-09-26 12:04:11 --> Helper loaded: common_helper
INFO - 2021-09-26 12:04:11 --> Database Driver Class Initialized
DEBUG - 2021-09-26 12:04:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-26 12:04:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-26 12:04:11 --> Controller Class Initialized
INFO - 2021-09-26 12:04:11 --> Form Validation Class Initialized
DEBUG - 2021-09-26 12:04:11 --> Encrypt Class Initialized
DEBUG - 2021-09-26 12:04:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-09-26 12:04:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-09-26 12:04:11 --> Email Class Initialized
INFO - 2021-09-26 12:04:11 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-09-26 12:04:11 --> Calendar Class Initialized
INFO - 2021-09-26 12:04:11 --> Model "Login_model" initialized
INFO - 2021-09-26 12:04:11 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-09-26 12:04:11 --> Final output sent to browser
DEBUG - 2021-09-26 12:04:11 --> Total execution time: 0.0442
ERROR - 2021-09-26 12:04:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-26 12:04:11 --> Config Class Initialized
INFO - 2021-09-26 12:04:11 --> Hooks Class Initialized
DEBUG - 2021-09-26 12:04:11 --> UTF-8 Support Enabled
INFO - 2021-09-26 12:04:11 --> Utf8 Class Initialized
INFO - 2021-09-26 12:04:11 --> URI Class Initialized
DEBUG - 2021-09-26 12:04:11 --> No URI present. Default controller set.
INFO - 2021-09-26 12:04:11 --> Router Class Initialized
INFO - 2021-09-26 12:04:11 --> Output Class Initialized
INFO - 2021-09-26 12:04:11 --> Security Class Initialized
DEBUG - 2021-09-26 12:04:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-26 12:04:11 --> Input Class Initialized
INFO - 2021-09-26 12:04:11 --> Language Class Initialized
INFO - 2021-09-26 12:04:11 --> Loader Class Initialized
INFO - 2021-09-26 12:04:11 --> Helper loaded: url_helper
INFO - 2021-09-26 12:04:11 --> Helper loaded: form_helper
INFO - 2021-09-26 12:04:11 --> Helper loaded: common_helper
INFO - 2021-09-26 12:04:11 --> Database Driver Class Initialized
DEBUG - 2021-09-26 12:04:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-26 12:04:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-26 12:04:11 --> Controller Class Initialized
INFO - 2021-09-26 12:04:11 --> Form Validation Class Initialized
DEBUG - 2021-09-26 12:04:11 --> Encrypt Class Initialized
DEBUG - 2021-09-26 12:04:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-09-26 12:04:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-09-26 12:04:11 --> Email Class Initialized
INFO - 2021-09-26 12:04:11 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-09-26 12:04:11 --> Calendar Class Initialized
INFO - 2021-09-26 12:04:11 --> Model "Login_model" initialized
INFO - 2021-09-26 12:04:11 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-09-26 12:04:11 --> Final output sent to browser
DEBUG - 2021-09-26 12:04:11 --> Total execution time: 0.0201
ERROR - 2021-09-26 12:04:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-26 12:04:12 --> Config Class Initialized
INFO - 2021-09-26 12:04:12 --> Hooks Class Initialized
DEBUG - 2021-09-26 12:04:12 --> UTF-8 Support Enabled
INFO - 2021-09-26 12:04:12 --> Utf8 Class Initialized
INFO - 2021-09-26 12:04:12 --> URI Class Initialized
INFO - 2021-09-26 12:04:12 --> Router Class Initialized
INFO - 2021-09-26 12:04:12 --> Output Class Initialized
INFO - 2021-09-26 12:04:12 --> Security Class Initialized
DEBUG - 2021-09-26 12:04:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-26 12:04:12 --> Input Class Initialized
INFO - 2021-09-26 12:04:12 --> Language Class Initialized
ERROR - 2021-09-26 12:04:12 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
ERROR - 2021-09-26 12:04:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-26 12:04:12 --> Config Class Initialized
INFO - 2021-09-26 12:04:12 --> Hooks Class Initialized
DEBUG - 2021-09-26 12:04:12 --> UTF-8 Support Enabled
INFO - 2021-09-26 12:04:12 --> Utf8 Class Initialized
INFO - 2021-09-26 12:04:12 --> URI Class Initialized
DEBUG - 2021-09-26 12:04:12 --> No URI present. Default controller set.
INFO - 2021-09-26 12:04:12 --> Router Class Initialized
INFO - 2021-09-26 12:04:12 --> Output Class Initialized
INFO - 2021-09-26 12:04:12 --> Security Class Initialized
DEBUG - 2021-09-26 12:04:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-26 12:04:12 --> Input Class Initialized
INFO - 2021-09-26 12:04:12 --> Language Class Initialized
INFO - 2021-09-26 12:04:12 --> Loader Class Initialized
INFO - 2021-09-26 12:04:12 --> Helper loaded: url_helper
INFO - 2021-09-26 12:04:12 --> Helper loaded: form_helper
INFO - 2021-09-26 12:04:12 --> Helper loaded: common_helper
INFO - 2021-09-26 12:04:12 --> Database Driver Class Initialized
DEBUG - 2021-09-26 12:04:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-26 12:04:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-26 12:04:12 --> Controller Class Initialized
INFO - 2021-09-26 12:04:12 --> Form Validation Class Initialized
DEBUG - 2021-09-26 12:04:12 --> Encrypt Class Initialized
DEBUG - 2021-09-26 12:04:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-09-26 12:04:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-09-26 12:04:12 --> Email Class Initialized
INFO - 2021-09-26 12:04:12 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-09-26 12:04:12 --> Calendar Class Initialized
INFO - 2021-09-26 12:04:12 --> Model "Login_model" initialized
INFO - 2021-09-26 12:04:12 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-09-26 12:04:12 --> Final output sent to browser
DEBUG - 2021-09-26 12:04:12 --> Total execution time: 0.0307
ERROR - 2021-09-26 12:04:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-26 12:04:13 --> Config Class Initialized
INFO - 2021-09-26 12:04:13 --> Hooks Class Initialized
DEBUG - 2021-09-26 12:04:13 --> UTF-8 Support Enabled
INFO - 2021-09-26 12:04:13 --> Utf8 Class Initialized
INFO - 2021-09-26 12:04:13 --> URI Class Initialized
INFO - 2021-09-26 12:04:13 --> Router Class Initialized
INFO - 2021-09-26 12:04:13 --> Output Class Initialized
INFO - 2021-09-26 12:04:13 --> Security Class Initialized
DEBUG - 2021-09-26 12:04:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-26 12:04:13 --> Input Class Initialized
INFO - 2021-09-26 12:04:13 --> Language Class Initialized
ERROR - 2021-09-26 12:04:13 --> 404 Page Not Found: Blog/wp-includes
ERROR - 2021-09-26 12:04:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-26 12:04:13 --> Config Class Initialized
INFO - 2021-09-26 12:04:13 --> Hooks Class Initialized
DEBUG - 2021-09-26 12:04:13 --> UTF-8 Support Enabled
INFO - 2021-09-26 12:04:13 --> Utf8 Class Initialized
INFO - 2021-09-26 12:04:13 --> URI Class Initialized
INFO - 2021-09-26 12:04:13 --> Router Class Initialized
INFO - 2021-09-26 12:04:13 --> Output Class Initialized
INFO - 2021-09-26 12:04:13 --> Security Class Initialized
DEBUG - 2021-09-26 12:04:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-26 12:04:13 --> Input Class Initialized
INFO - 2021-09-26 12:04:13 --> Language Class Initialized
ERROR - 2021-09-26 12:04:13 --> 404 Page Not Found: Web/wp-includes
ERROR - 2021-09-26 12:04:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-26 12:04:14 --> Config Class Initialized
INFO - 2021-09-26 12:04:14 --> Hooks Class Initialized
DEBUG - 2021-09-26 12:04:14 --> UTF-8 Support Enabled
INFO - 2021-09-26 12:04:14 --> Utf8 Class Initialized
INFO - 2021-09-26 12:04:14 --> URI Class Initialized
INFO - 2021-09-26 12:04:14 --> Router Class Initialized
INFO - 2021-09-26 12:04:14 --> Output Class Initialized
INFO - 2021-09-26 12:04:14 --> Security Class Initialized
DEBUG - 2021-09-26 12:04:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-26 12:04:14 --> Input Class Initialized
INFO - 2021-09-26 12:04:14 --> Language Class Initialized
ERROR - 2021-09-26 12:04:14 --> 404 Page Not Found: Wordpress/wp-includes
ERROR - 2021-09-26 12:04:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-26 12:04:14 --> Config Class Initialized
INFO - 2021-09-26 12:04:14 --> Hooks Class Initialized
DEBUG - 2021-09-26 12:04:14 --> UTF-8 Support Enabled
INFO - 2021-09-26 12:04:14 --> Utf8 Class Initialized
INFO - 2021-09-26 12:04:14 --> URI Class Initialized
INFO - 2021-09-26 12:04:14 --> Router Class Initialized
INFO - 2021-09-26 12:04:14 --> Output Class Initialized
INFO - 2021-09-26 12:04:14 --> Security Class Initialized
DEBUG - 2021-09-26 12:04:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-26 12:04:14 --> Input Class Initialized
INFO - 2021-09-26 12:04:14 --> Language Class Initialized
ERROR - 2021-09-26 12:04:14 --> 404 Page Not Found: Website/wp-includes
ERROR - 2021-09-26 12:04:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-26 12:04:15 --> Config Class Initialized
INFO - 2021-09-26 12:04:15 --> Hooks Class Initialized
DEBUG - 2021-09-26 12:04:15 --> UTF-8 Support Enabled
INFO - 2021-09-26 12:04:15 --> Utf8 Class Initialized
INFO - 2021-09-26 12:04:15 --> URI Class Initialized
INFO - 2021-09-26 12:04:15 --> Router Class Initialized
INFO - 2021-09-26 12:04:15 --> Output Class Initialized
INFO - 2021-09-26 12:04:15 --> Security Class Initialized
DEBUG - 2021-09-26 12:04:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-26 12:04:15 --> Input Class Initialized
INFO - 2021-09-26 12:04:15 --> Language Class Initialized
ERROR - 2021-09-26 12:04:15 --> 404 Page Not Found: Wp/wp-includes
ERROR - 2021-09-26 12:04:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-26 12:04:15 --> Config Class Initialized
INFO - 2021-09-26 12:04:15 --> Hooks Class Initialized
DEBUG - 2021-09-26 12:04:15 --> UTF-8 Support Enabled
INFO - 2021-09-26 12:04:15 --> Utf8 Class Initialized
INFO - 2021-09-26 12:04:15 --> URI Class Initialized
INFO - 2021-09-26 12:04:15 --> Router Class Initialized
INFO - 2021-09-26 12:04:15 --> Output Class Initialized
INFO - 2021-09-26 12:04:15 --> Security Class Initialized
DEBUG - 2021-09-26 12:04:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-26 12:04:15 --> Input Class Initialized
INFO - 2021-09-26 12:04:15 --> Language Class Initialized
ERROR - 2021-09-26 12:04:15 --> 404 Page Not Found: News/wp-includes
ERROR - 2021-09-26 12:04:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-26 12:04:16 --> Config Class Initialized
INFO - 2021-09-26 12:04:16 --> Hooks Class Initialized
DEBUG - 2021-09-26 12:04:16 --> UTF-8 Support Enabled
INFO - 2021-09-26 12:04:16 --> Utf8 Class Initialized
INFO - 2021-09-26 12:04:16 --> URI Class Initialized
INFO - 2021-09-26 12:04:16 --> Router Class Initialized
INFO - 2021-09-26 12:04:16 --> Output Class Initialized
INFO - 2021-09-26 12:04:16 --> Security Class Initialized
DEBUG - 2021-09-26 12:04:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-26 12:04:16 --> Input Class Initialized
INFO - 2021-09-26 12:04:16 --> Language Class Initialized
ERROR - 2021-09-26 12:04:16 --> 404 Page Not Found: Wp1/wp-includes
ERROR - 2021-09-26 12:04:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-26 12:04:16 --> Config Class Initialized
INFO - 2021-09-26 12:04:16 --> Hooks Class Initialized
DEBUG - 2021-09-26 12:04:16 --> UTF-8 Support Enabled
INFO - 2021-09-26 12:04:16 --> Utf8 Class Initialized
INFO - 2021-09-26 12:04:16 --> URI Class Initialized
INFO - 2021-09-26 12:04:16 --> Router Class Initialized
INFO - 2021-09-26 12:04:16 --> Output Class Initialized
INFO - 2021-09-26 12:04:16 --> Security Class Initialized
DEBUG - 2021-09-26 12:04:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-26 12:04:16 --> Input Class Initialized
INFO - 2021-09-26 12:04:16 --> Language Class Initialized
ERROR - 2021-09-26 12:04:16 --> 404 Page Not Found: Test/wp-includes
ERROR - 2021-09-26 12:04:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-26 12:04:17 --> Config Class Initialized
INFO - 2021-09-26 12:04:17 --> Hooks Class Initialized
DEBUG - 2021-09-26 12:04:17 --> UTF-8 Support Enabled
INFO - 2021-09-26 12:04:17 --> Utf8 Class Initialized
INFO - 2021-09-26 12:04:17 --> URI Class Initialized
INFO - 2021-09-26 12:04:17 --> Router Class Initialized
INFO - 2021-09-26 12:04:17 --> Output Class Initialized
INFO - 2021-09-26 12:04:17 --> Security Class Initialized
DEBUG - 2021-09-26 12:04:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-26 12:04:17 --> Input Class Initialized
INFO - 2021-09-26 12:04:17 --> Language Class Initialized
ERROR - 2021-09-26 12:04:17 --> 404 Page Not Found: Wp2/wp-includes
ERROR - 2021-09-26 12:04:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-26 12:04:17 --> Config Class Initialized
INFO - 2021-09-26 12:04:17 --> Hooks Class Initialized
DEBUG - 2021-09-26 12:04:17 --> UTF-8 Support Enabled
INFO - 2021-09-26 12:04:17 --> Utf8 Class Initialized
INFO - 2021-09-26 12:04:17 --> URI Class Initialized
INFO - 2021-09-26 12:04:17 --> Router Class Initialized
INFO - 2021-09-26 12:04:17 --> Output Class Initialized
INFO - 2021-09-26 12:04:17 --> Security Class Initialized
DEBUG - 2021-09-26 12:04:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-26 12:04:17 --> Input Class Initialized
INFO - 2021-09-26 12:04:17 --> Language Class Initialized
ERROR - 2021-09-26 12:04:17 --> 404 Page Not Found: Site/wp-includes
ERROR - 2021-09-26 12:04:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-26 12:04:18 --> Config Class Initialized
INFO - 2021-09-26 12:04:18 --> Hooks Class Initialized
DEBUG - 2021-09-26 12:04:18 --> UTF-8 Support Enabled
INFO - 2021-09-26 12:04:18 --> Utf8 Class Initialized
INFO - 2021-09-26 12:04:18 --> URI Class Initialized
INFO - 2021-09-26 12:04:18 --> Router Class Initialized
INFO - 2021-09-26 12:04:18 --> Output Class Initialized
INFO - 2021-09-26 12:04:18 --> Security Class Initialized
DEBUG - 2021-09-26 12:04:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-26 12:04:18 --> Input Class Initialized
INFO - 2021-09-26 12:04:18 --> Language Class Initialized
ERROR - 2021-09-26 12:04:18 --> 404 Page Not Found: Cms/wp-includes
ERROR - 2021-09-26 12:04:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-26 12:04:18 --> Config Class Initialized
INFO - 2021-09-26 12:04:18 --> Hooks Class Initialized
DEBUG - 2021-09-26 12:04:18 --> UTF-8 Support Enabled
INFO - 2021-09-26 12:04:18 --> Utf8 Class Initialized
INFO - 2021-09-26 12:04:18 --> URI Class Initialized
INFO - 2021-09-26 12:04:18 --> Router Class Initialized
INFO - 2021-09-26 12:04:18 --> Output Class Initialized
INFO - 2021-09-26 12:04:18 --> Security Class Initialized
DEBUG - 2021-09-26 12:04:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-26 12:04:18 --> Input Class Initialized
INFO - 2021-09-26 12:04:18 --> Language Class Initialized
ERROR - 2021-09-26 12:04:18 --> 404 Page Not Found: Sito/wp-includes
ERROR - 2021-09-26 16:37:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-26 16:37:59 --> Config Class Initialized
INFO - 2021-09-26 16:37:59 --> Hooks Class Initialized
DEBUG - 2021-09-26 16:37:59 --> UTF-8 Support Enabled
INFO - 2021-09-26 16:37:59 --> Utf8 Class Initialized
INFO - 2021-09-26 16:37:59 --> URI Class Initialized
INFO - 2021-09-26 16:37:59 --> Router Class Initialized
INFO - 2021-09-26 16:37:59 --> Output Class Initialized
INFO - 2021-09-26 16:37:59 --> Security Class Initialized
DEBUG - 2021-09-26 16:37:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-26 16:37:59 --> Input Class Initialized
INFO - 2021-09-26 16:37:59 --> Language Class Initialized
ERROR - 2021-09-26 16:37:59 --> 404 Page Not Found: Wp-content/index
ERROR - 2021-09-26 21:23:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-26 21:23:53 --> Config Class Initialized
INFO - 2021-09-26 21:23:53 --> Hooks Class Initialized
DEBUG - 2021-09-26 21:23:53 --> UTF-8 Support Enabled
INFO - 2021-09-26 21:23:53 --> Utf8 Class Initialized
INFO - 2021-09-26 21:23:53 --> URI Class Initialized
DEBUG - 2021-09-26 21:23:53 --> No URI present. Default controller set.
INFO - 2021-09-26 21:23:53 --> Router Class Initialized
INFO - 2021-09-26 21:23:53 --> Output Class Initialized
INFO - 2021-09-26 21:23:53 --> Security Class Initialized
DEBUG - 2021-09-26 21:23:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-26 21:23:53 --> Input Class Initialized
INFO - 2021-09-26 21:23:53 --> Language Class Initialized
INFO - 2021-09-26 21:23:53 --> Loader Class Initialized
INFO - 2021-09-26 21:23:53 --> Helper loaded: url_helper
INFO - 2021-09-26 21:23:53 --> Helper loaded: form_helper
INFO - 2021-09-26 21:23:53 --> Helper loaded: common_helper
INFO - 2021-09-26 21:23:53 --> Database Driver Class Initialized
DEBUG - 2021-09-26 21:23:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-26 21:23:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-26 21:23:53 --> Controller Class Initialized
INFO - 2021-09-26 21:23:53 --> Form Validation Class Initialized
DEBUG - 2021-09-26 21:23:53 --> Encrypt Class Initialized
DEBUG - 2021-09-26 21:23:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-09-26 21:23:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-09-26 21:23:53 --> Email Class Initialized
INFO - 2021-09-26 21:23:53 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-09-26 21:23:53 --> Calendar Class Initialized
INFO - 2021-09-26 21:23:53 --> Model "Login_model" initialized
INFO - 2021-09-26 21:23:53 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-09-26 21:23:53 --> Final output sent to browser
DEBUG - 2021-09-26 21:23:53 --> Total execution time: 0.1261
