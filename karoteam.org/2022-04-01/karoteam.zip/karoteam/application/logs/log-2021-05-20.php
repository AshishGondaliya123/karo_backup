<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-05-20 15:13:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-20 15:13:50 --> Config Class Initialized
INFO - 2021-05-20 15:13:50 --> Hooks Class Initialized
DEBUG - 2021-05-20 15:13:50 --> UTF-8 Support Enabled
INFO - 2021-05-20 15:13:50 --> Utf8 Class Initialized
INFO - 2021-05-20 15:13:50 --> URI Class Initialized
DEBUG - 2021-05-20 15:13:50 --> No URI present. Default controller set.
INFO - 2021-05-20 15:13:50 --> Router Class Initialized
INFO - 2021-05-20 15:13:50 --> Output Class Initialized
INFO - 2021-05-20 15:13:50 --> Security Class Initialized
DEBUG - 2021-05-20 15:13:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-20 15:13:50 --> Input Class Initialized
INFO - 2021-05-20 15:13:50 --> Language Class Initialized
INFO - 2021-05-20 15:13:50 --> Loader Class Initialized
INFO - 2021-05-20 15:13:50 --> Helper loaded: url_helper
INFO - 2021-05-20 15:13:50 --> Helper loaded: form_helper
INFO - 2021-05-20 15:13:50 --> Helper loaded: common_helper
INFO - 2021-05-20 15:13:50 --> Database Driver Class Initialized
DEBUG - 2021-05-20 15:13:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-20 15:13:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-20 15:13:50 --> Controller Class Initialized
INFO - 2021-05-20 15:13:50 --> Form Validation Class Initialized
DEBUG - 2021-05-20 15:13:50 --> Encrypt Class Initialized
DEBUG - 2021-05-20 15:13:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-05-20 15:13:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-05-20 15:13:50 --> Email Class Initialized
INFO - 2021-05-20 15:13:50 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-05-20 15:13:50 --> Calendar Class Initialized
INFO - 2021-05-20 15:13:50 --> Model "Login_model" initialized
INFO - 2021-05-20 15:13:50 --> File loaded: /home/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-05-20 15:13:50 --> Final output sent to browser
DEBUG - 2021-05-20 15:13:50 --> Total execution time: 0.1114
ERROR - 2021-05-20 20:14:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-20 20:14:40 --> Config Class Initialized
INFO - 2021-05-20 20:14:40 --> Hooks Class Initialized
DEBUG - 2021-05-20 20:14:40 --> UTF-8 Support Enabled
INFO - 2021-05-20 20:14:40 --> Utf8 Class Initialized
INFO - 2021-05-20 20:14:40 --> URI Class Initialized
DEBUG - 2021-05-20 20:14:40 --> No URI present. Default controller set.
INFO - 2021-05-20 20:14:40 --> Router Class Initialized
INFO - 2021-05-20 20:14:40 --> Output Class Initialized
INFO - 2021-05-20 20:14:40 --> Security Class Initialized
DEBUG - 2021-05-20 20:14:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-20 20:14:40 --> Input Class Initialized
INFO - 2021-05-20 20:14:40 --> Language Class Initialized
INFO - 2021-05-20 20:14:40 --> Loader Class Initialized
INFO - 2021-05-20 20:14:40 --> Helper loaded: url_helper
INFO - 2021-05-20 20:14:40 --> Helper loaded: form_helper
INFO - 2021-05-20 20:14:40 --> Helper loaded: common_helper
INFO - 2021-05-20 20:14:40 --> Database Driver Class Initialized
DEBUG - 2021-05-20 20:14:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-20 20:14:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-20 20:14:40 --> Controller Class Initialized
INFO - 2021-05-20 20:14:40 --> Form Validation Class Initialized
DEBUG - 2021-05-20 20:14:40 --> Encrypt Class Initialized
DEBUG - 2021-05-20 20:14:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-05-20 20:14:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-05-20 20:14:40 --> Email Class Initialized
INFO - 2021-05-20 20:14:40 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-05-20 20:14:40 --> Calendar Class Initialized
INFO - 2021-05-20 20:14:40 --> Model "Login_model" initialized
INFO - 2021-05-20 20:14:41 --> File loaded: /home/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-05-20 20:14:41 --> Final output sent to browser
DEBUG - 2021-05-20 20:14:41 --> Total execution time: 0.1045
ERROR - 2021-05-20 20:53:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-20 20:53:41 --> Config Class Initialized
INFO - 2021-05-20 20:53:41 --> Hooks Class Initialized
DEBUG - 2021-05-20 20:53:41 --> UTF-8 Support Enabled
INFO - 2021-05-20 20:53:41 --> Utf8 Class Initialized
INFO - 2021-05-20 20:53:41 --> URI Class Initialized
DEBUG - 2021-05-20 20:53:41 --> No URI present. Default controller set.
INFO - 2021-05-20 20:53:41 --> Router Class Initialized
INFO - 2021-05-20 20:53:41 --> Output Class Initialized
INFO - 2021-05-20 20:53:41 --> Security Class Initialized
DEBUG - 2021-05-20 20:53:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-20 20:53:41 --> Input Class Initialized
INFO - 2021-05-20 20:53:41 --> Language Class Initialized
INFO - 2021-05-20 20:53:41 --> Loader Class Initialized
INFO - 2021-05-20 20:53:41 --> Helper loaded: url_helper
INFO - 2021-05-20 20:53:41 --> Helper loaded: form_helper
INFO - 2021-05-20 20:53:41 --> Helper loaded: common_helper
INFO - 2021-05-20 20:53:41 --> Database Driver Class Initialized
DEBUG - 2021-05-20 20:53:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-20 20:53:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-20 20:53:41 --> Controller Class Initialized
INFO - 2021-05-20 20:53:41 --> Form Validation Class Initialized
DEBUG - 2021-05-20 20:53:41 --> Encrypt Class Initialized
DEBUG - 2021-05-20 20:53:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-05-20 20:53:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-05-20 20:53:41 --> Email Class Initialized
INFO - 2021-05-20 20:53:41 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-05-20 20:53:41 --> Calendar Class Initialized
INFO - 2021-05-20 20:53:41 --> Model "Login_model" initialized
INFO - 2021-05-20 20:53:41 --> File loaded: /home/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-05-20 20:53:41 --> Final output sent to browser
DEBUG - 2021-05-20 20:53:41 --> Total execution time: 0.1515
ERROR - 2021-05-20 23:06:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-20 23:06:18 --> Config Class Initialized
INFO - 2021-05-20 23:06:18 --> Hooks Class Initialized
DEBUG - 2021-05-20 23:06:18 --> UTF-8 Support Enabled
INFO - 2021-05-20 23:06:18 --> Utf8 Class Initialized
INFO - 2021-05-20 23:06:18 --> URI Class Initialized
DEBUG - 2021-05-20 23:06:18 --> No URI present. Default controller set.
INFO - 2021-05-20 23:06:18 --> Router Class Initialized
INFO - 2021-05-20 23:06:18 --> Output Class Initialized
INFO - 2021-05-20 23:06:18 --> Security Class Initialized
DEBUG - 2021-05-20 23:06:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-20 23:06:18 --> Input Class Initialized
INFO - 2021-05-20 23:06:18 --> Language Class Initialized
INFO - 2021-05-20 23:06:18 --> Loader Class Initialized
INFO - 2021-05-20 23:06:18 --> Helper loaded: url_helper
INFO - 2021-05-20 23:06:18 --> Helper loaded: form_helper
INFO - 2021-05-20 23:06:18 --> Helper loaded: common_helper
INFO - 2021-05-20 23:06:18 --> Database Driver Class Initialized
DEBUG - 2021-05-20 23:06:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-20 23:06:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-20 23:06:18 --> Controller Class Initialized
INFO - 2021-05-20 23:06:18 --> Form Validation Class Initialized
DEBUG - 2021-05-20 23:06:18 --> Encrypt Class Initialized
DEBUG - 2021-05-20 23:06:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-05-20 23:06:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-05-20 23:06:18 --> Email Class Initialized
INFO - 2021-05-20 23:06:18 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-05-20 23:06:18 --> Calendar Class Initialized
INFO - 2021-05-20 23:06:18 --> Model "Login_model" initialized
INFO - 2021-05-20 23:06:18 --> File loaded: /home/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-05-20 23:06:18 --> Final output sent to browser
DEBUG - 2021-05-20 23:06:18 --> Total execution time: 0.1061
