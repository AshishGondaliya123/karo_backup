<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-12-09 04:29:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 04:29:31 --> Config Class Initialized
INFO - 2021-12-09 04:29:31 --> Hooks Class Initialized
DEBUG - 2021-12-09 04:29:31 --> UTF-8 Support Enabled
INFO - 2021-12-09 04:29:31 --> Utf8 Class Initialized
INFO - 2021-12-09 04:29:31 --> URI Class Initialized
DEBUG - 2021-12-09 04:29:31 --> No URI present. Default controller set.
INFO - 2021-12-09 04:29:31 --> Router Class Initialized
INFO - 2021-12-09 04:29:31 --> Output Class Initialized
INFO - 2021-12-09 04:29:31 --> Security Class Initialized
DEBUG - 2021-12-09 04:29:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 04:29:31 --> Input Class Initialized
INFO - 2021-12-09 04:29:31 --> Language Class Initialized
INFO - 2021-12-09 04:29:31 --> Loader Class Initialized
INFO - 2021-12-09 04:29:31 --> Helper loaded: url_helper
INFO - 2021-12-09 04:29:31 --> Helper loaded: form_helper
INFO - 2021-12-09 04:29:31 --> Helper loaded: common_helper
INFO - 2021-12-09 04:29:31 --> Database Driver Class Initialized
DEBUG - 2021-12-09 04:29:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 04:29:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 04:29:31 --> Controller Class Initialized
INFO - 2021-12-09 04:29:31 --> Form Validation Class Initialized
DEBUG - 2021-12-09 04:29:31 --> Encrypt Class Initialized
DEBUG - 2021-12-09 04:29:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-09 04:29:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-09 04:29:31 --> Email Class Initialized
INFO - 2021-12-09 04:29:31 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-09 04:29:31 --> Calendar Class Initialized
INFO - 2021-12-09 04:29:31 --> Model "Login_model" initialized
INFO - 2021-12-09 04:29:31 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-09 04:29:31 --> Final output sent to browser
DEBUG - 2021-12-09 04:29:31 --> Total execution time: 0.0237
ERROR - 2021-12-09 07:35:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 07:35:16 --> Config Class Initialized
INFO - 2021-12-09 07:35:16 --> Hooks Class Initialized
DEBUG - 2021-12-09 07:35:16 --> UTF-8 Support Enabled
INFO - 2021-12-09 07:35:16 --> Utf8 Class Initialized
INFO - 2021-12-09 07:35:16 --> URI Class Initialized
DEBUG - 2021-12-09 07:35:16 --> No URI present. Default controller set.
INFO - 2021-12-09 07:35:16 --> Router Class Initialized
INFO - 2021-12-09 07:35:16 --> Output Class Initialized
INFO - 2021-12-09 07:35:16 --> Security Class Initialized
DEBUG - 2021-12-09 07:35:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 07:35:16 --> Input Class Initialized
INFO - 2021-12-09 07:35:16 --> Language Class Initialized
INFO - 2021-12-09 07:35:16 --> Loader Class Initialized
INFO - 2021-12-09 07:35:16 --> Helper loaded: url_helper
INFO - 2021-12-09 07:35:16 --> Helper loaded: form_helper
INFO - 2021-12-09 07:35:16 --> Helper loaded: common_helper
INFO - 2021-12-09 07:35:16 --> Database Driver Class Initialized
DEBUG - 2021-12-09 07:35:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 07:35:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 07:35:16 --> Controller Class Initialized
INFO - 2021-12-09 07:35:16 --> Form Validation Class Initialized
DEBUG - 2021-12-09 07:35:16 --> Encrypt Class Initialized
DEBUG - 2021-12-09 07:35:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-09 07:35:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-09 07:35:16 --> Email Class Initialized
INFO - 2021-12-09 07:35:16 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-09 07:35:16 --> Calendar Class Initialized
INFO - 2021-12-09 07:35:16 --> Model "Login_model" initialized
INFO - 2021-12-09 07:35:16 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-09 07:35:16 --> Final output sent to browser
DEBUG - 2021-12-09 07:35:16 --> Total execution time: 0.0239
ERROR - 2021-12-09 08:04:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 08:04:03 --> Config Class Initialized
INFO - 2021-12-09 08:04:03 --> Hooks Class Initialized
DEBUG - 2021-12-09 08:04:03 --> UTF-8 Support Enabled
INFO - 2021-12-09 08:04:03 --> Utf8 Class Initialized
INFO - 2021-12-09 08:04:03 --> URI Class Initialized
DEBUG - 2021-12-09 08:04:03 --> No URI present. Default controller set.
INFO - 2021-12-09 08:04:03 --> Router Class Initialized
INFO - 2021-12-09 08:04:03 --> Output Class Initialized
INFO - 2021-12-09 08:04:03 --> Security Class Initialized
DEBUG - 2021-12-09 08:04:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 08:04:03 --> Input Class Initialized
INFO - 2021-12-09 08:04:03 --> Language Class Initialized
INFO - 2021-12-09 08:04:03 --> Loader Class Initialized
INFO - 2021-12-09 08:04:03 --> Helper loaded: url_helper
INFO - 2021-12-09 08:04:03 --> Helper loaded: form_helper
INFO - 2021-12-09 08:04:03 --> Helper loaded: common_helper
INFO - 2021-12-09 08:04:03 --> Database Driver Class Initialized
DEBUG - 2021-12-09 08:04:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 08:04:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 08:04:03 --> Controller Class Initialized
INFO - 2021-12-09 08:04:03 --> Form Validation Class Initialized
DEBUG - 2021-12-09 08:04:03 --> Encrypt Class Initialized
DEBUG - 2021-12-09 08:04:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-09 08:04:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-09 08:04:03 --> Email Class Initialized
INFO - 2021-12-09 08:04:03 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-09 08:04:03 --> Calendar Class Initialized
INFO - 2021-12-09 08:04:03 --> Model "Login_model" initialized
INFO - 2021-12-09 08:04:03 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-09 08:04:03 --> Final output sent to browser
DEBUG - 2021-12-09 08:04:03 --> Total execution time: 0.0244
ERROR - 2021-12-09 10:29:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 10:29:06 --> Config Class Initialized
INFO - 2021-12-09 10:29:06 --> Hooks Class Initialized
DEBUG - 2021-12-09 10:29:06 --> UTF-8 Support Enabled
INFO - 2021-12-09 10:29:06 --> Utf8 Class Initialized
INFO - 2021-12-09 10:29:06 --> URI Class Initialized
DEBUG - 2021-12-09 10:29:06 --> No URI present. Default controller set.
INFO - 2021-12-09 10:29:06 --> Router Class Initialized
INFO - 2021-12-09 10:29:06 --> Output Class Initialized
INFO - 2021-12-09 10:29:06 --> Security Class Initialized
DEBUG - 2021-12-09 10:29:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 10:29:06 --> Input Class Initialized
INFO - 2021-12-09 10:29:06 --> Language Class Initialized
INFO - 2021-12-09 10:29:06 --> Loader Class Initialized
INFO - 2021-12-09 10:29:06 --> Helper loaded: url_helper
INFO - 2021-12-09 10:29:06 --> Helper loaded: form_helper
INFO - 2021-12-09 10:29:06 --> Helper loaded: common_helper
INFO - 2021-12-09 10:29:06 --> Database Driver Class Initialized
DEBUG - 2021-12-09 10:29:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 10:29:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 10:29:06 --> Controller Class Initialized
INFO - 2021-12-09 10:29:06 --> Form Validation Class Initialized
DEBUG - 2021-12-09 10:29:06 --> Encrypt Class Initialized
DEBUG - 2021-12-09 10:29:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-09 10:29:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-09 10:29:06 --> Email Class Initialized
INFO - 2021-12-09 10:29:06 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-09 10:29:06 --> Calendar Class Initialized
INFO - 2021-12-09 10:29:06 --> Model "Login_model" initialized
INFO - 2021-12-09 10:29:06 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-09 10:29:06 --> Final output sent to browser
DEBUG - 2021-12-09 10:29:06 --> Total execution time: 0.0230
ERROR - 2021-12-09 10:29:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 10:29:09 --> Config Class Initialized
INFO - 2021-12-09 10:29:09 --> Hooks Class Initialized
DEBUG - 2021-12-09 10:29:09 --> UTF-8 Support Enabled
INFO - 2021-12-09 10:29:09 --> Utf8 Class Initialized
INFO - 2021-12-09 10:29:09 --> URI Class Initialized
DEBUG - 2021-12-09 10:29:09 --> No URI present. Default controller set.
INFO - 2021-12-09 10:29:09 --> Router Class Initialized
INFO - 2021-12-09 10:29:09 --> Output Class Initialized
INFO - 2021-12-09 10:29:09 --> Security Class Initialized
DEBUG - 2021-12-09 10:29:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 10:29:09 --> Input Class Initialized
INFO - 2021-12-09 10:29:09 --> Language Class Initialized
INFO - 2021-12-09 10:29:09 --> Loader Class Initialized
INFO - 2021-12-09 10:29:09 --> Helper loaded: url_helper
INFO - 2021-12-09 10:29:09 --> Helper loaded: form_helper
INFO - 2021-12-09 10:29:09 --> Helper loaded: common_helper
INFO - 2021-12-09 10:29:09 --> Database Driver Class Initialized
DEBUG - 2021-12-09 10:29:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 10:29:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 10:29:09 --> Controller Class Initialized
INFO - 2021-12-09 10:29:09 --> Form Validation Class Initialized
DEBUG - 2021-12-09 10:29:09 --> Encrypt Class Initialized
DEBUG - 2021-12-09 10:29:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-09 10:29:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-09 10:29:09 --> Email Class Initialized
INFO - 2021-12-09 10:29:09 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-09 10:29:09 --> Calendar Class Initialized
INFO - 2021-12-09 10:29:09 --> Model "Login_model" initialized
INFO - 2021-12-09 10:29:09 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-09 10:29:09 --> Final output sent to browser
DEBUG - 2021-12-09 10:29:09 --> Total execution time: 0.0224
ERROR - 2021-12-09 10:29:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 10:29:45 --> Config Class Initialized
INFO - 2021-12-09 10:29:45 --> Hooks Class Initialized
DEBUG - 2021-12-09 10:29:45 --> UTF-8 Support Enabled
INFO - 2021-12-09 10:29:45 --> Utf8 Class Initialized
INFO - 2021-12-09 10:29:45 --> URI Class Initialized
DEBUG - 2021-12-09 10:29:45 --> No URI present. Default controller set.
INFO - 2021-12-09 10:29:45 --> Router Class Initialized
INFO - 2021-12-09 10:29:45 --> Output Class Initialized
INFO - 2021-12-09 10:29:45 --> Security Class Initialized
DEBUG - 2021-12-09 10:29:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 10:29:45 --> Input Class Initialized
INFO - 2021-12-09 10:29:45 --> Language Class Initialized
INFO - 2021-12-09 10:29:45 --> Loader Class Initialized
INFO - 2021-12-09 10:29:45 --> Helper loaded: url_helper
INFO - 2021-12-09 10:29:45 --> Helper loaded: form_helper
INFO - 2021-12-09 10:29:45 --> Helper loaded: common_helper
INFO - 2021-12-09 10:29:45 --> Database Driver Class Initialized
DEBUG - 2021-12-09 10:29:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 10:29:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 10:29:45 --> Controller Class Initialized
INFO - 2021-12-09 10:29:45 --> Form Validation Class Initialized
DEBUG - 2021-12-09 10:29:45 --> Encrypt Class Initialized
DEBUG - 2021-12-09 10:29:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-09 10:29:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-09 10:29:45 --> Email Class Initialized
INFO - 2021-12-09 10:29:45 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-09 10:29:45 --> Calendar Class Initialized
INFO - 2021-12-09 10:29:45 --> Model "Login_model" initialized
INFO - 2021-12-09 10:29:45 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-09 10:29:45 --> Final output sent to browser
DEBUG - 2021-12-09 10:29:45 --> Total execution time: 0.0218
ERROR - 2021-12-09 10:47:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 10:47:00 --> Config Class Initialized
INFO - 2021-12-09 10:47:00 --> Hooks Class Initialized
DEBUG - 2021-12-09 10:47:00 --> UTF-8 Support Enabled
INFO - 2021-12-09 10:47:00 --> Utf8 Class Initialized
INFO - 2021-12-09 10:47:00 --> URI Class Initialized
DEBUG - 2021-12-09 10:47:00 --> No URI present. Default controller set.
INFO - 2021-12-09 10:47:00 --> Router Class Initialized
INFO - 2021-12-09 10:47:00 --> Output Class Initialized
INFO - 2021-12-09 10:47:00 --> Security Class Initialized
DEBUG - 2021-12-09 10:47:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 10:47:00 --> Input Class Initialized
INFO - 2021-12-09 10:47:00 --> Language Class Initialized
INFO - 2021-12-09 10:47:00 --> Loader Class Initialized
INFO - 2021-12-09 10:47:00 --> Helper loaded: url_helper
INFO - 2021-12-09 10:47:00 --> Helper loaded: form_helper
INFO - 2021-12-09 10:47:00 --> Helper loaded: common_helper
INFO - 2021-12-09 10:47:00 --> Database Driver Class Initialized
DEBUG - 2021-12-09 10:47:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 10:47:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 10:47:00 --> Controller Class Initialized
INFO - 2021-12-09 10:47:00 --> Form Validation Class Initialized
DEBUG - 2021-12-09 10:47:00 --> Encrypt Class Initialized
DEBUG - 2021-12-09 10:47:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-09 10:47:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-09 10:47:00 --> Email Class Initialized
INFO - 2021-12-09 10:47:00 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-09 10:47:00 --> Calendar Class Initialized
INFO - 2021-12-09 10:47:00 --> Model "Login_model" initialized
INFO - 2021-12-09 10:47:00 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-09 10:47:00 --> Final output sent to browser
DEBUG - 2021-12-09 10:47:00 --> Total execution time: 0.0230
ERROR - 2021-12-09 11:19:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 11:19:37 --> Config Class Initialized
INFO - 2021-12-09 11:19:37 --> Hooks Class Initialized
DEBUG - 2021-12-09 11:19:37 --> UTF-8 Support Enabled
INFO - 2021-12-09 11:19:37 --> Utf8 Class Initialized
INFO - 2021-12-09 11:19:37 --> URI Class Initialized
DEBUG - 2021-12-09 11:19:37 --> No URI present. Default controller set.
INFO - 2021-12-09 11:19:37 --> Router Class Initialized
INFO - 2021-12-09 11:19:37 --> Output Class Initialized
INFO - 2021-12-09 11:19:37 --> Security Class Initialized
DEBUG - 2021-12-09 11:19:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 11:19:37 --> Input Class Initialized
INFO - 2021-12-09 11:19:37 --> Language Class Initialized
INFO - 2021-12-09 11:19:37 --> Loader Class Initialized
INFO - 2021-12-09 11:19:37 --> Helper loaded: url_helper
INFO - 2021-12-09 11:19:37 --> Helper loaded: form_helper
INFO - 2021-12-09 11:19:37 --> Helper loaded: common_helper
INFO - 2021-12-09 11:19:37 --> Database Driver Class Initialized
DEBUG - 2021-12-09 11:19:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 11:19:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 11:19:37 --> Controller Class Initialized
INFO - 2021-12-09 11:19:37 --> Form Validation Class Initialized
DEBUG - 2021-12-09 11:19:37 --> Encrypt Class Initialized
DEBUG - 2021-12-09 11:19:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-09 11:19:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-09 11:19:37 --> Email Class Initialized
INFO - 2021-12-09 11:19:37 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-09 11:19:37 --> Calendar Class Initialized
INFO - 2021-12-09 11:19:37 --> Model "Login_model" initialized
INFO - 2021-12-09 11:19:37 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-09 11:19:37 --> Final output sent to browser
DEBUG - 2021-12-09 11:19:37 --> Total execution time: 0.0374
ERROR - 2021-12-09 13:26:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 13:26:05 --> Config Class Initialized
INFO - 2021-12-09 13:26:05 --> Hooks Class Initialized
DEBUG - 2021-12-09 13:26:05 --> UTF-8 Support Enabled
INFO - 2021-12-09 13:26:05 --> Utf8 Class Initialized
INFO - 2021-12-09 13:26:05 --> URI Class Initialized
DEBUG - 2021-12-09 13:26:05 --> No URI present. Default controller set.
INFO - 2021-12-09 13:26:05 --> Router Class Initialized
INFO - 2021-12-09 13:26:05 --> Output Class Initialized
INFO - 2021-12-09 13:26:05 --> Security Class Initialized
DEBUG - 2021-12-09 13:26:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 13:26:05 --> Input Class Initialized
INFO - 2021-12-09 13:26:05 --> Language Class Initialized
INFO - 2021-12-09 13:26:05 --> Loader Class Initialized
INFO - 2021-12-09 13:26:05 --> Helper loaded: url_helper
INFO - 2021-12-09 13:26:05 --> Helper loaded: form_helper
INFO - 2021-12-09 13:26:05 --> Helper loaded: common_helper
INFO - 2021-12-09 13:26:05 --> Database Driver Class Initialized
DEBUG - 2021-12-09 13:26:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 13:26:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 13:26:05 --> Controller Class Initialized
INFO - 2021-12-09 13:26:05 --> Form Validation Class Initialized
DEBUG - 2021-12-09 13:26:05 --> Encrypt Class Initialized
DEBUG - 2021-12-09 13:26:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-09 13:26:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-09 13:26:05 --> Email Class Initialized
INFO - 2021-12-09 13:26:05 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-09 13:26:05 --> Calendar Class Initialized
INFO - 2021-12-09 13:26:05 --> Model "Login_model" initialized
INFO - 2021-12-09 13:26:05 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-09 13:26:05 --> Final output sent to browser
DEBUG - 2021-12-09 13:26:05 --> Total execution time: 0.0386
ERROR - 2021-12-09 14:16:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 14:16:41 --> Config Class Initialized
INFO - 2021-12-09 14:16:41 --> Hooks Class Initialized
DEBUG - 2021-12-09 14:16:41 --> UTF-8 Support Enabled
INFO - 2021-12-09 14:16:41 --> Utf8 Class Initialized
INFO - 2021-12-09 14:16:41 --> URI Class Initialized
DEBUG - 2021-12-09 14:16:41 --> No URI present. Default controller set.
INFO - 2021-12-09 14:16:41 --> Router Class Initialized
INFO - 2021-12-09 14:16:41 --> Output Class Initialized
INFO - 2021-12-09 14:16:41 --> Security Class Initialized
DEBUG - 2021-12-09 14:16:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 14:16:41 --> Input Class Initialized
INFO - 2021-12-09 14:16:41 --> Language Class Initialized
INFO - 2021-12-09 14:16:41 --> Loader Class Initialized
INFO - 2021-12-09 14:16:41 --> Helper loaded: url_helper
INFO - 2021-12-09 14:16:41 --> Helper loaded: form_helper
INFO - 2021-12-09 14:16:41 --> Helper loaded: common_helper
INFO - 2021-12-09 14:16:41 --> Database Driver Class Initialized
DEBUG - 2021-12-09 14:16:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 14:16:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 14:16:41 --> Controller Class Initialized
INFO - 2021-12-09 14:16:41 --> Form Validation Class Initialized
DEBUG - 2021-12-09 14:16:41 --> Encrypt Class Initialized
DEBUG - 2021-12-09 14:16:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-09 14:16:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-09 14:16:41 --> Email Class Initialized
INFO - 2021-12-09 14:16:42 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-09 14:16:42 --> Calendar Class Initialized
INFO - 2021-12-09 14:16:42 --> Model "Login_model" initialized
INFO - 2021-12-09 14:16:42 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-09 14:16:42 --> Final output sent to browser
DEBUG - 2021-12-09 14:16:42 --> Total execution time: 0.0270
ERROR - 2021-12-09 14:16:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 14:16:42 --> Config Class Initialized
INFO - 2021-12-09 14:16:42 --> Hooks Class Initialized
DEBUG - 2021-12-09 14:16:42 --> UTF-8 Support Enabled
INFO - 2021-12-09 14:16:42 --> Utf8 Class Initialized
INFO - 2021-12-09 14:16:42 --> URI Class Initialized
INFO - 2021-12-09 14:16:42 --> Router Class Initialized
INFO - 2021-12-09 14:16:42 --> Output Class Initialized
INFO - 2021-12-09 14:16:42 --> Security Class Initialized
DEBUG - 2021-12-09 14:16:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 14:16:42 --> Input Class Initialized
INFO - 2021-12-09 14:16:42 --> Language Class Initialized
ERROR - 2021-12-09 14:16:43 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2021-12-09 14:17:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 14:17:59 --> Config Class Initialized
INFO - 2021-12-09 14:17:59 --> Hooks Class Initialized
DEBUG - 2021-12-09 14:17:59 --> UTF-8 Support Enabled
INFO - 2021-12-09 14:17:59 --> Utf8 Class Initialized
INFO - 2021-12-09 14:17:59 --> URI Class Initialized
INFO - 2021-12-09 14:17:59 --> Router Class Initialized
INFO - 2021-12-09 14:17:59 --> Output Class Initialized
INFO - 2021-12-09 14:17:59 --> Security Class Initialized
DEBUG - 2021-12-09 14:17:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 14:17:59 --> Input Class Initialized
INFO - 2021-12-09 14:17:59 --> Language Class Initialized
INFO - 2021-12-09 14:17:59 --> Loader Class Initialized
INFO - 2021-12-09 14:17:59 --> Helper loaded: url_helper
INFO - 2021-12-09 14:17:59 --> Helper loaded: form_helper
INFO - 2021-12-09 14:17:59 --> Helper loaded: common_helper
INFO - 2021-12-09 14:17:59 --> Database Driver Class Initialized
DEBUG - 2021-12-09 14:17:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 14:17:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 14:17:59 --> Controller Class Initialized
INFO - 2021-12-09 14:17:59 --> Form Validation Class Initialized
DEBUG - 2021-12-09 14:17:59 --> Encrypt Class Initialized
DEBUG - 2021-12-09 14:17:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-09 14:17:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-09 14:17:59 --> Email Class Initialized
INFO - 2021-12-09 14:17:59 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-09 14:17:59 --> Calendar Class Initialized
INFO - 2021-12-09 14:17:59 --> Model "Login_model" initialized
ERROR - 2021-12-09 14:17:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 14:17:59 --> Config Class Initialized
INFO - 2021-12-09 14:17:59 --> Hooks Class Initialized
DEBUG - 2021-12-09 14:17:59 --> UTF-8 Support Enabled
INFO - 2021-12-09 14:17:59 --> Utf8 Class Initialized
INFO - 2021-12-09 14:17:59 --> URI Class Initialized
INFO - 2021-12-09 14:17:59 --> Router Class Initialized
INFO - 2021-12-09 14:17:59 --> Output Class Initialized
INFO - 2021-12-09 14:17:59 --> Security Class Initialized
DEBUG - 2021-12-09 14:17:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 14:17:59 --> Input Class Initialized
INFO - 2021-12-09 14:17:59 --> Language Class Initialized
INFO - 2021-12-09 14:17:59 --> Loader Class Initialized
INFO - 2021-12-09 14:17:59 --> Helper loaded: url_helper
INFO - 2021-12-09 14:17:59 --> Helper loaded: form_helper
INFO - 2021-12-09 14:17:59 --> Helper loaded: common_helper
INFO - 2021-12-09 14:17:59 --> Database Driver Class Initialized
DEBUG - 2021-12-09 14:17:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 14:17:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 14:17:59 --> Controller Class Initialized
INFO - 2021-12-09 14:17:59 --> Form Validation Class Initialized
DEBUG - 2021-12-09 14:17:59 --> Encrypt Class Initialized
DEBUG - 2021-12-09 14:17:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-09 14:17:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-09 14:17:59 --> Email Class Initialized
INFO - 2021-12-09 14:17:59 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-09 14:17:59 --> Calendar Class Initialized
INFO - 2021-12-09 14:17:59 --> Model "Login_model" initialized
ERROR - 2021-12-09 14:18:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 14:18:00 --> Config Class Initialized
INFO - 2021-12-09 14:18:00 --> Hooks Class Initialized
DEBUG - 2021-12-09 14:18:00 --> UTF-8 Support Enabled
INFO - 2021-12-09 14:18:00 --> Utf8 Class Initialized
INFO - 2021-12-09 14:18:00 --> URI Class Initialized
DEBUG - 2021-12-09 14:18:00 --> No URI present. Default controller set.
INFO - 2021-12-09 14:18:00 --> Router Class Initialized
INFO - 2021-12-09 14:18:00 --> Output Class Initialized
INFO - 2021-12-09 14:18:00 --> Security Class Initialized
DEBUG - 2021-12-09 14:18:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 14:18:00 --> Input Class Initialized
INFO - 2021-12-09 14:18:00 --> Language Class Initialized
INFO - 2021-12-09 14:18:00 --> Loader Class Initialized
INFO - 2021-12-09 14:18:00 --> Helper loaded: url_helper
INFO - 2021-12-09 14:18:00 --> Helper loaded: form_helper
INFO - 2021-12-09 14:18:00 --> Helper loaded: common_helper
INFO - 2021-12-09 14:18:00 --> Database Driver Class Initialized
DEBUG - 2021-12-09 14:18:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 14:18:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 14:18:00 --> Controller Class Initialized
INFO - 2021-12-09 14:18:00 --> Form Validation Class Initialized
DEBUG - 2021-12-09 14:18:00 --> Encrypt Class Initialized
DEBUG - 2021-12-09 14:18:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-09 14:18:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-09 14:18:00 --> Email Class Initialized
INFO - 2021-12-09 14:18:00 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-09 14:18:00 --> Calendar Class Initialized
INFO - 2021-12-09 14:18:00 --> Model "Login_model" initialized
INFO - 2021-12-09 14:18:00 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-09 14:18:00 --> Final output sent to browser
DEBUG - 2021-12-09 14:18:00 --> Total execution time: 0.0315
ERROR - 2021-12-09 14:18:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 14:18:01 --> Config Class Initialized
INFO - 2021-12-09 14:18:01 --> Hooks Class Initialized
DEBUG - 2021-12-09 14:18:01 --> UTF-8 Support Enabled
INFO - 2021-12-09 14:18:01 --> Utf8 Class Initialized
INFO - 2021-12-09 14:18:01 --> URI Class Initialized
INFO - 2021-12-09 14:18:01 --> Router Class Initialized
INFO - 2021-12-09 14:18:01 --> Output Class Initialized
INFO - 2021-12-09 14:18:01 --> Security Class Initialized
DEBUG - 2021-12-09 14:18:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 14:18:01 --> Input Class Initialized
INFO - 2021-12-09 14:18:01 --> Language Class Initialized
INFO - 2021-12-09 14:18:01 --> Loader Class Initialized
INFO - 2021-12-09 14:18:01 --> Helper loaded: url_helper
INFO - 2021-12-09 14:18:01 --> Helper loaded: form_helper
INFO - 2021-12-09 14:18:01 --> Helper loaded: common_helper
INFO - 2021-12-09 14:18:01 --> Database Driver Class Initialized
DEBUG - 2021-12-09 14:18:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 14:18:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 14:18:01 --> Controller Class Initialized
INFO - 2021-12-09 14:18:01 --> Form Validation Class Initialized
DEBUG - 2021-12-09 14:18:01 --> Encrypt Class Initialized
DEBUG - 2021-12-09 14:18:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-09 14:18:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-09 14:18:01 --> Email Class Initialized
INFO - 2021-12-09 14:18:01 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-09 14:18:01 --> Calendar Class Initialized
INFO - 2021-12-09 14:18:01 --> Model "Login_model" initialized
INFO - 2021-12-09 14:18:01 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-09 14:18:01 --> Final output sent to browser
DEBUG - 2021-12-09 14:18:01 --> Total execution time: 0.0289
ERROR - 2021-12-09 15:11:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 15:11:13 --> Config Class Initialized
INFO - 2021-12-09 15:11:13 --> Hooks Class Initialized
DEBUG - 2021-12-09 15:11:13 --> UTF-8 Support Enabled
INFO - 2021-12-09 15:11:13 --> Utf8 Class Initialized
INFO - 2021-12-09 15:11:13 --> URI Class Initialized
DEBUG - 2021-12-09 15:11:13 --> No URI present. Default controller set.
INFO - 2021-12-09 15:11:13 --> Router Class Initialized
INFO - 2021-12-09 15:11:13 --> Output Class Initialized
INFO - 2021-12-09 15:11:13 --> Security Class Initialized
DEBUG - 2021-12-09 15:11:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 15:11:13 --> Input Class Initialized
INFO - 2021-12-09 15:11:13 --> Language Class Initialized
INFO - 2021-12-09 15:11:13 --> Loader Class Initialized
INFO - 2021-12-09 15:11:13 --> Helper loaded: url_helper
INFO - 2021-12-09 15:11:13 --> Helper loaded: form_helper
INFO - 2021-12-09 15:11:13 --> Helper loaded: common_helper
INFO - 2021-12-09 15:11:13 --> Database Driver Class Initialized
DEBUG - 2021-12-09 15:11:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 15:11:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 15:11:13 --> Controller Class Initialized
INFO - 2021-12-09 15:11:13 --> Form Validation Class Initialized
DEBUG - 2021-12-09 15:11:13 --> Encrypt Class Initialized
DEBUG - 2021-12-09 15:11:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-09 15:11:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-09 15:11:13 --> Email Class Initialized
INFO - 2021-12-09 15:11:13 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-09 15:11:13 --> Calendar Class Initialized
INFO - 2021-12-09 15:11:13 --> Model "Login_model" initialized
INFO - 2021-12-09 15:11:13 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-09 15:11:13 --> Final output sent to browser
DEBUG - 2021-12-09 15:11:13 --> Total execution time: 0.0371
ERROR - 2021-12-09 16:03:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 16:03:19 --> Config Class Initialized
INFO - 2021-12-09 16:03:19 --> Hooks Class Initialized
DEBUG - 2021-12-09 16:03:19 --> UTF-8 Support Enabled
INFO - 2021-12-09 16:03:19 --> Utf8 Class Initialized
INFO - 2021-12-09 16:03:19 --> URI Class Initialized
DEBUG - 2021-12-09 16:03:19 --> No URI present. Default controller set.
INFO - 2021-12-09 16:03:19 --> Router Class Initialized
INFO - 2021-12-09 16:03:19 --> Output Class Initialized
INFO - 2021-12-09 16:03:19 --> Security Class Initialized
DEBUG - 2021-12-09 16:03:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 16:03:19 --> Input Class Initialized
INFO - 2021-12-09 16:03:19 --> Language Class Initialized
INFO - 2021-12-09 16:03:19 --> Loader Class Initialized
INFO - 2021-12-09 16:03:19 --> Helper loaded: url_helper
INFO - 2021-12-09 16:03:19 --> Helper loaded: form_helper
INFO - 2021-12-09 16:03:19 --> Helper loaded: common_helper
INFO - 2021-12-09 16:03:19 --> Database Driver Class Initialized
DEBUG - 2021-12-09 16:03:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 16:03:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 16:03:19 --> Controller Class Initialized
INFO - 2021-12-09 16:03:19 --> Form Validation Class Initialized
DEBUG - 2021-12-09 16:03:19 --> Encrypt Class Initialized
DEBUG - 2021-12-09 16:03:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-09 16:03:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-09 16:03:19 --> Email Class Initialized
INFO - 2021-12-09 16:03:19 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-09 16:03:19 --> Calendar Class Initialized
INFO - 2021-12-09 16:03:19 --> Model "Login_model" initialized
INFO - 2021-12-09 16:03:19 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-09 16:03:19 --> Final output sent to browser
DEBUG - 2021-12-09 16:03:19 --> Total execution time: 0.0242
ERROR - 2021-12-09 16:03:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 16:03:19 --> Config Class Initialized
INFO - 2021-12-09 16:03:19 --> Hooks Class Initialized
DEBUG - 2021-12-09 16:03:19 --> UTF-8 Support Enabled
INFO - 2021-12-09 16:03:19 --> Utf8 Class Initialized
INFO - 2021-12-09 16:03:19 --> URI Class Initialized
INFO - 2021-12-09 16:03:19 --> Router Class Initialized
INFO - 2021-12-09 16:03:19 --> Output Class Initialized
INFO - 2021-12-09 16:03:19 --> Security Class Initialized
DEBUG - 2021-12-09 16:03:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 16:03:19 --> Input Class Initialized
INFO - 2021-12-09 16:03:19 --> Language Class Initialized
ERROR - 2021-12-09 16:03:19 --> 404 Page Not Found: Test_404_page/index
ERROR - 2021-12-09 16:03:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 16:03:20 --> Config Class Initialized
INFO - 2021-12-09 16:03:20 --> Hooks Class Initialized
DEBUG - 2021-12-09 16:03:20 --> UTF-8 Support Enabled
INFO - 2021-12-09 16:03:20 --> Utf8 Class Initialized
INFO - 2021-12-09 16:03:20 --> URI Class Initialized
INFO - 2021-12-09 16:03:20 --> Router Class Initialized
INFO - 2021-12-09 16:03:20 --> Output Class Initialized
INFO - 2021-12-09 16:03:20 --> Security Class Initialized
DEBUG - 2021-12-09 16:03:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 16:03:20 --> Input Class Initialized
INFO - 2021-12-09 16:03:20 --> Language Class Initialized
ERROR - 2021-12-09 16:03:20 --> 404 Page Not Found: Issmall/index
ERROR - 2021-12-09 16:03:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 16:03:21 --> Config Class Initialized
INFO - 2021-12-09 16:03:21 --> Hooks Class Initialized
DEBUG - 2021-12-09 16:03:21 --> UTF-8 Support Enabled
INFO - 2021-12-09 16:03:21 --> Utf8 Class Initialized
INFO - 2021-12-09 16:03:21 --> URI Class Initialized
INFO - 2021-12-09 16:03:21 --> Router Class Initialized
INFO - 2021-12-09 16:03:21 --> Output Class Initialized
INFO - 2021-12-09 16:03:21 --> Security Class Initialized
DEBUG - 2021-12-09 16:03:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 16:03:21 --> Input Class Initialized
INFO - 2021-12-09 16:03:21 --> Language Class Initialized
ERROR - 2021-12-09 16:03:21 --> 404 Page Not Found: Fckeditor/fckconfig.js
ERROR - 2021-12-09 16:03:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 16:03:22 --> Config Class Initialized
INFO - 2021-12-09 16:03:22 --> Hooks Class Initialized
DEBUG - 2021-12-09 16:03:22 --> UTF-8 Support Enabled
INFO - 2021-12-09 16:03:22 --> Utf8 Class Initialized
INFO - 2021-12-09 16:03:22 --> URI Class Initialized
INFO - 2021-12-09 16:03:22 --> Router Class Initialized
INFO - 2021-12-09 16:03:22 --> Output Class Initialized
INFO - 2021-12-09 16:03:22 --> Security Class Initialized
DEBUG - 2021-12-09 16:03:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 16:03:22 --> Input Class Initialized
INFO - 2021-12-09 16:03:22 --> Language Class Initialized
ERROR - 2021-12-09 16:03:22 --> 404 Page Not Found: Fckeditor/editor
ERROR - 2021-12-09 16:03:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 16:03:22 --> Config Class Initialized
INFO - 2021-12-09 16:03:22 --> Hooks Class Initialized
DEBUG - 2021-12-09 16:03:22 --> UTF-8 Support Enabled
INFO - 2021-12-09 16:03:22 --> Utf8 Class Initialized
INFO - 2021-12-09 16:03:22 --> URI Class Initialized
INFO - 2021-12-09 16:03:22 --> Router Class Initialized
INFO - 2021-12-09 16:03:22 --> Output Class Initialized
INFO - 2021-12-09 16:03:22 --> Security Class Initialized
DEBUG - 2021-12-09 16:03:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 16:03:22 --> Input Class Initialized
INFO - 2021-12-09 16:03:22 --> Language Class Initialized
ERROR - 2021-12-09 16:03:22 --> 404 Page Not Found: Fckeditor/license.txt
ERROR - 2021-12-09 16:03:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 16:03:23 --> Config Class Initialized
INFO - 2021-12-09 16:03:23 --> Hooks Class Initialized
DEBUG - 2021-12-09 16:03:23 --> UTF-8 Support Enabled
INFO - 2021-12-09 16:03:23 --> Utf8 Class Initialized
INFO - 2021-12-09 16:03:23 --> URI Class Initialized
INFO - 2021-12-09 16:03:23 --> Router Class Initialized
INFO - 2021-12-09 16:03:23 --> Output Class Initialized
INFO - 2021-12-09 16:03:23 --> Security Class Initialized
DEBUG - 2021-12-09 16:03:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 16:03:23 --> Input Class Initialized
INFO - 2021-12-09 16:03:23 --> Language Class Initialized
ERROR - 2021-12-09 16:03:23 --> 404 Page Not Found: Fckeditor/editor
ERROR - 2021-12-09 16:03:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 16:03:23 --> Config Class Initialized
INFO - 2021-12-09 16:03:23 --> Hooks Class Initialized
DEBUG - 2021-12-09 16:03:23 --> UTF-8 Support Enabled
INFO - 2021-12-09 16:03:23 --> Utf8 Class Initialized
INFO - 2021-12-09 16:03:23 --> URI Class Initialized
INFO - 2021-12-09 16:03:23 --> Router Class Initialized
INFO - 2021-12-09 16:03:23 --> Output Class Initialized
INFO - 2021-12-09 16:03:23 --> Security Class Initialized
DEBUG - 2021-12-09 16:03:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 16:03:23 --> Input Class Initialized
INFO - 2021-12-09 16:03:23 --> Language Class Initialized
ERROR - 2021-12-09 16:03:23 --> 404 Page Not Found: Fckeditor/fckeditor.js
ERROR - 2021-12-09 16:03:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 16:03:24 --> Config Class Initialized
INFO - 2021-12-09 16:03:24 --> Hooks Class Initialized
DEBUG - 2021-12-09 16:03:24 --> UTF-8 Support Enabled
INFO - 2021-12-09 16:03:24 --> Utf8 Class Initialized
INFO - 2021-12-09 16:03:24 --> URI Class Initialized
INFO - 2021-12-09 16:03:24 --> Router Class Initialized
INFO - 2021-12-09 16:03:24 --> Output Class Initialized
INFO - 2021-12-09 16:03:24 --> Security Class Initialized
DEBUG - 2021-12-09 16:03:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 16:03:24 --> Input Class Initialized
INFO - 2021-12-09 16:03:24 --> Language Class Initialized
ERROR - 2021-12-09 16:03:24 --> 404 Page Not Found: FCK/editor
ERROR - 2021-12-09 16:03:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 16:03:28 --> Config Class Initialized
INFO - 2021-12-09 16:03:28 --> Hooks Class Initialized
DEBUG - 2021-12-09 16:03:28 --> UTF-8 Support Enabled
INFO - 2021-12-09 16:03:28 --> Utf8 Class Initialized
INFO - 2021-12-09 16:03:28 --> URI Class Initialized
INFO - 2021-12-09 16:03:28 --> Router Class Initialized
INFO - 2021-12-09 16:03:28 --> Output Class Initialized
INFO - 2021-12-09 16:03:28 --> Security Class Initialized
DEBUG - 2021-12-09 16:03:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 16:03:28 --> Input Class Initialized
INFO - 2021-12-09 16:03:28 --> Language Class Initialized
ERROR - 2021-12-09 16:03:28 --> 404 Page Not Found: FCK/fckeditor.js
ERROR - 2021-12-09 16:03:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 16:03:29 --> Config Class Initialized
INFO - 2021-12-09 16:03:29 --> Hooks Class Initialized
DEBUG - 2021-12-09 16:03:29 --> UTF-8 Support Enabled
INFO - 2021-12-09 16:03:29 --> Utf8 Class Initialized
INFO - 2021-12-09 16:03:29 --> URI Class Initialized
INFO - 2021-12-09 16:03:29 --> Router Class Initialized
INFO - 2021-12-09 16:03:29 --> Output Class Initialized
INFO - 2021-12-09 16:03:29 --> Security Class Initialized
DEBUG - 2021-12-09 16:03:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 16:03:29 --> Input Class Initialized
INFO - 2021-12-09 16:03:29 --> Language Class Initialized
ERROR - 2021-12-09 16:03:29 --> 404 Page Not Found: Fckeditorjs/index
ERROR - 2021-12-09 16:03:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 16:03:29 --> Config Class Initialized
INFO - 2021-12-09 16:03:29 --> Hooks Class Initialized
DEBUG - 2021-12-09 16:03:29 --> UTF-8 Support Enabled
INFO - 2021-12-09 16:03:29 --> Utf8 Class Initialized
INFO - 2021-12-09 16:03:29 --> URI Class Initialized
INFO - 2021-12-09 16:03:29 --> Router Class Initialized
INFO - 2021-12-09 16:03:29 --> Output Class Initialized
INFO - 2021-12-09 16:03:29 --> Security Class Initialized
DEBUG - 2021-12-09 16:03:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 16:03:29 --> Input Class Initialized
INFO - 2021-12-09 16:03:29 --> Language Class Initialized
ERROR - 2021-12-09 16:03:29 --> 404 Page Not Found: Editor/fckeditor.js
ERROR - 2021-12-09 16:03:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 16:03:30 --> Config Class Initialized
INFO - 2021-12-09 16:03:30 --> Hooks Class Initialized
DEBUG - 2021-12-09 16:03:30 --> UTF-8 Support Enabled
INFO - 2021-12-09 16:03:30 --> Utf8 Class Initialized
INFO - 2021-12-09 16:03:30 --> URI Class Initialized
INFO - 2021-12-09 16:03:30 --> Router Class Initialized
INFO - 2021-12-09 16:03:30 --> Output Class Initialized
INFO - 2021-12-09 16:03:30 --> Security Class Initialized
DEBUG - 2021-12-09 16:03:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 16:03:30 --> Input Class Initialized
INFO - 2021-12-09 16:03:30 --> Language Class Initialized
ERROR - 2021-12-09 16:03:30 --> 404 Page Not Found: Editor/js
ERROR - 2021-12-09 16:03:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 16:03:31 --> Config Class Initialized
INFO - 2021-12-09 16:03:31 --> Hooks Class Initialized
DEBUG - 2021-12-09 16:03:31 --> UTF-8 Support Enabled
INFO - 2021-12-09 16:03:31 --> Utf8 Class Initialized
INFO - 2021-12-09 16:03:31 --> URI Class Initialized
DEBUG - 2021-12-09 16:03:31 --> No URI present. Default controller set.
INFO - 2021-12-09 16:03:31 --> Router Class Initialized
INFO - 2021-12-09 16:03:31 --> Output Class Initialized
INFO - 2021-12-09 16:03:31 --> Security Class Initialized
DEBUG - 2021-12-09 16:03:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 16:03:31 --> Input Class Initialized
INFO - 2021-12-09 16:03:31 --> Language Class Initialized
INFO - 2021-12-09 16:03:31 --> Loader Class Initialized
INFO - 2021-12-09 16:03:31 --> Helper loaded: url_helper
INFO - 2021-12-09 16:03:31 --> Helper loaded: form_helper
INFO - 2021-12-09 16:03:31 --> Helper loaded: common_helper
INFO - 2021-12-09 16:03:31 --> Database Driver Class Initialized
DEBUG - 2021-12-09 16:03:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 16:03:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 16:03:31 --> Controller Class Initialized
INFO - 2021-12-09 16:03:31 --> Form Validation Class Initialized
DEBUG - 2021-12-09 16:03:31 --> Encrypt Class Initialized
DEBUG - 2021-12-09 16:03:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-09 16:03:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-09 16:03:31 --> Email Class Initialized
INFO - 2021-12-09 16:03:31 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-09 16:03:31 --> Calendar Class Initialized
INFO - 2021-12-09 16:03:31 --> Model "Login_model" initialized
INFO - 2021-12-09 16:03:31 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-09 16:03:31 --> Final output sent to browser
DEBUG - 2021-12-09 16:03:31 --> Total execution time: 0.0266
ERROR - 2021-12-09 16:03:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 16:03:31 --> Config Class Initialized
INFO - 2021-12-09 16:03:31 --> Hooks Class Initialized
DEBUG - 2021-12-09 16:03:31 --> UTF-8 Support Enabled
INFO - 2021-12-09 16:03:31 --> Utf8 Class Initialized
INFO - 2021-12-09 16:03:31 --> URI Class Initialized
INFO - 2021-12-09 16:03:31 --> Router Class Initialized
INFO - 2021-12-09 16:03:31 --> Output Class Initialized
INFO - 2021-12-09 16:03:31 --> Security Class Initialized
DEBUG - 2021-12-09 16:03:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 16:03:31 --> Input Class Initialized
INFO - 2021-12-09 16:03:31 --> Language Class Initialized
ERROR - 2021-12-09 16:03:31 --> 404 Page Not Found: Tpl/user
ERROR - 2021-12-09 16:03:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 16:03:32 --> Config Class Initialized
INFO - 2021-12-09 16:03:32 --> Hooks Class Initialized
DEBUG - 2021-12-09 16:03:32 --> UTF-8 Support Enabled
INFO - 2021-12-09 16:03:32 --> Utf8 Class Initialized
INFO - 2021-12-09 16:03:32 --> URI Class Initialized
INFO - 2021-12-09 16:03:32 --> Router Class Initialized
INFO - 2021-12-09 16:03:32 --> Output Class Initialized
INFO - 2021-12-09 16:03:32 --> Security Class Initialized
DEBUG - 2021-12-09 16:03:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 16:03:32 --> Input Class Initialized
INFO - 2021-12-09 16:03:32 --> Language Class Initialized
ERROR - 2021-12-09 16:03:32 --> 404 Page Not Found: Tpl/login
ERROR - 2021-12-09 16:03:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 16:03:32 --> Config Class Initialized
INFO - 2021-12-09 16:03:32 --> Hooks Class Initialized
DEBUG - 2021-12-09 16:03:32 --> UTF-8 Support Enabled
INFO - 2021-12-09 16:03:32 --> Utf8 Class Initialized
INFO - 2021-12-09 16:03:32 --> URI Class Initialized
INFO - 2021-12-09 16:03:32 --> Router Class Initialized
INFO - 2021-12-09 16:03:32 --> Output Class Initialized
INFO - 2021-12-09 16:03:32 --> Security Class Initialized
DEBUG - 2021-12-09 16:03:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 16:03:32 --> Input Class Initialized
INFO - 2021-12-09 16:03:32 --> Language Class Initialized
ERROR - 2021-12-09 16:03:32 --> 404 Page Not Found: New_gb/help
ERROR - 2021-12-09 16:03:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 16:03:32 --> Config Class Initialized
INFO - 2021-12-09 16:03:32 --> Hooks Class Initialized
DEBUG - 2021-12-09 16:03:32 --> UTF-8 Support Enabled
INFO - 2021-12-09 16:03:32 --> Utf8 Class Initialized
INFO - 2021-12-09 16:03:32 --> URI Class Initialized
INFO - 2021-12-09 16:03:32 --> Router Class Initialized
INFO - 2021-12-09 16:03:32 --> Output Class Initialized
INFO - 2021-12-09 16:03:32 --> Security Class Initialized
DEBUG - 2021-12-09 16:03:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 16:03:32 --> Input Class Initialized
INFO - 2021-12-09 16:03:32 --> Language Class Initialized
ERROR - 2021-12-09 16:03:32 --> 404 Page Not Found: Web2/login_template
ERROR - 2021-12-09 16:03:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 16:03:33 --> Config Class Initialized
INFO - 2021-12-09 16:03:33 --> Hooks Class Initialized
DEBUG - 2021-12-09 16:03:33 --> UTF-8 Support Enabled
INFO - 2021-12-09 16:03:33 --> Utf8 Class Initialized
INFO - 2021-12-09 16:03:33 --> URI Class Initialized
INFO - 2021-12-09 16:03:33 --> Router Class Initialized
INFO - 2021-12-09 16:03:33 --> Output Class Initialized
INFO - 2021-12-09 16:03:33 --> Security Class Initialized
DEBUG - 2021-12-09 16:03:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 16:03:33 --> Input Class Initialized
INFO - 2021-12-09 16:03:33 --> Language Class Initialized
ERROR - 2021-12-09 16:03:33 --> 404 Page Not Found: Ckeditor/ckeditor.js
ERROR - 2021-12-09 16:03:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 16:03:33 --> Config Class Initialized
INFO - 2021-12-09 16:03:33 --> Hooks Class Initialized
DEBUG - 2021-12-09 16:03:33 --> UTF-8 Support Enabled
INFO - 2021-12-09 16:03:33 --> Utf8 Class Initialized
INFO - 2021-12-09 16:03:33 --> URI Class Initialized
INFO - 2021-12-09 16:03:33 --> Router Class Initialized
INFO - 2021-12-09 16:03:33 --> Output Class Initialized
INFO - 2021-12-09 16:03:33 --> Security Class Initialized
DEBUG - 2021-12-09 16:03:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 16:03:33 --> Input Class Initialized
INFO - 2021-12-09 16:03:33 --> Language Class Initialized
ERROR - 2021-12-09 16:03:33 --> 404 Page Not Found: Docs/index
ERROR - 2021-12-09 16:03:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 16:03:33 --> Config Class Initialized
INFO - 2021-12-09 16:03:33 --> Hooks Class Initialized
DEBUG - 2021-12-09 16:03:33 --> UTF-8 Support Enabled
INFO - 2021-12-09 16:03:33 --> Utf8 Class Initialized
INFO - 2021-12-09 16:03:33 --> URI Class Initialized
INFO - 2021-12-09 16:03:33 --> Router Class Initialized
INFO - 2021-12-09 16:03:33 --> Output Class Initialized
INFO - 2021-12-09 16:03:33 --> Security Class Initialized
DEBUG - 2021-12-09 16:03:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 16:03:33 --> Input Class Initialized
INFO - 2021-12-09 16:03:33 --> Language Class Initialized
ERROR - 2021-12-09 16:03:33 --> 404 Page Not Found: Docscss/index
ERROR - 2021-12-09 16:03:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 16:03:34 --> Config Class Initialized
INFO - 2021-12-09 16:03:34 --> Hooks Class Initialized
DEBUG - 2021-12-09 16:03:34 --> UTF-8 Support Enabled
INFO - 2021-12-09 16:03:34 --> Utf8 Class Initialized
INFO - 2021-12-09 16:03:34 --> URI Class Initialized
INFO - 2021-12-09 16:03:34 --> Router Class Initialized
INFO - 2021-12-09 16:03:34 --> Output Class Initialized
INFO - 2021-12-09 16:03:34 --> Security Class Initialized
DEBUG - 2021-12-09 16:03:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 16:03:34 --> Input Class Initialized
INFO - 2021-12-09 16:03:34 --> Language Class Initialized
ERROR - 2021-12-09 16:03:34 --> 404 Page Not Found: Phpmyadmin/themes
ERROR - 2021-12-09 16:03:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 16:03:34 --> Config Class Initialized
INFO - 2021-12-09 16:03:34 --> Hooks Class Initialized
DEBUG - 2021-12-09 16:03:34 --> UTF-8 Support Enabled
INFO - 2021-12-09 16:03:34 --> Utf8 Class Initialized
INFO - 2021-12-09 16:03:34 --> URI Class Initialized
INFO - 2021-12-09 16:03:34 --> Router Class Initialized
INFO - 2021-12-09 16:03:34 --> Output Class Initialized
INFO - 2021-12-09 16:03:34 --> Security Class Initialized
DEBUG - 2021-12-09 16:03:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 16:03:34 --> Input Class Initialized
INFO - 2021-12-09 16:03:34 --> Language Class Initialized
ERROR - 2021-12-09 16:03:34 --> 404 Page Not Found: Phpmyadmin/favicon.ico
ERROR - 2021-12-09 16:03:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 16:03:34 --> Config Class Initialized
INFO - 2021-12-09 16:03:34 --> Hooks Class Initialized
DEBUG - 2021-12-09 16:03:34 --> UTF-8 Support Enabled
INFO - 2021-12-09 16:03:34 --> Utf8 Class Initialized
INFO - 2021-12-09 16:03:34 --> URI Class Initialized
INFO - 2021-12-09 16:03:34 --> Router Class Initialized
INFO - 2021-12-09 16:03:34 --> Output Class Initialized
INFO - 2021-12-09 16:03:34 --> Security Class Initialized
DEBUG - 2021-12-09 16:03:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 16:03:34 --> Input Class Initialized
INFO - 2021-12-09 16:03:34 --> Language Class Initialized
ERROR - 2021-12-09 16:03:34 --> 404 Page Not Found: Phpmyadmin/docs.css
ERROR - 2021-12-09 16:03:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 16:03:35 --> Config Class Initialized
INFO - 2021-12-09 16:03:35 --> Hooks Class Initialized
DEBUG - 2021-12-09 16:03:35 --> UTF-8 Support Enabled
INFO - 2021-12-09 16:03:35 --> Utf8 Class Initialized
INFO - 2021-12-09 16:03:35 --> URI Class Initialized
INFO - 2021-12-09 16:03:35 --> Router Class Initialized
INFO - 2021-12-09 16:03:35 --> Output Class Initialized
INFO - 2021-12-09 16:03:35 --> Security Class Initialized
DEBUG - 2021-12-09 16:03:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 16:03:35 --> Input Class Initialized
INFO - 2021-12-09 16:03:35 --> Language Class Initialized
ERROR - 2021-12-09 16:03:35 --> 404 Page Not Found: Auth/login
ERROR - 2021-12-09 16:03:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 16:03:35 --> Config Class Initialized
INFO - 2021-12-09 16:03:35 --> Hooks Class Initialized
DEBUG - 2021-12-09 16:03:35 --> UTF-8 Support Enabled
INFO - 2021-12-09 16:03:35 --> Utf8 Class Initialized
INFO - 2021-12-09 16:03:35 --> URI Class Initialized
INFO - 2021-12-09 16:03:35 --> Router Class Initialized
INFO - 2021-12-09 16:03:35 --> Output Class Initialized
INFO - 2021-12-09 16:03:35 --> Security Class Initialized
DEBUG - 2021-12-09 16:03:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 16:03:35 --> Input Class Initialized
INFO - 2021-12-09 16:03:35 --> Language Class Initialized
ERROR - 2021-12-09 16:03:35 --> 404 Page Not Found: Licensetxt/index
ERROR - 2021-12-09 16:03:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 16:03:36 --> Config Class Initialized
INFO - 2021-12-09 16:03:36 --> Hooks Class Initialized
DEBUG - 2021-12-09 16:03:36 --> UTF-8 Support Enabled
INFO - 2021-12-09 16:03:36 --> Utf8 Class Initialized
INFO - 2021-12-09 16:03:36 --> URI Class Initialized
INFO - 2021-12-09 16:03:36 --> Router Class Initialized
INFO - 2021-12-09 16:03:36 --> Output Class Initialized
INFO - 2021-12-09 16:03:36 --> Security Class Initialized
DEBUG - 2021-12-09 16:03:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 16:03:36 --> Input Class Initialized
INFO - 2021-12-09 16:03:36 --> Language Class Initialized
ERROR - 2021-12-09 16:03:36 --> 404 Page Not Found: E/master
ERROR - 2021-12-09 16:03:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 16:03:36 --> Config Class Initialized
INFO - 2021-12-09 16:03:36 --> Hooks Class Initialized
DEBUG - 2021-12-09 16:03:36 --> UTF-8 Support Enabled
INFO - 2021-12-09 16:03:36 --> Utf8 Class Initialized
INFO - 2021-12-09 16:03:36 --> URI Class Initialized
INFO - 2021-12-09 16:03:36 --> Router Class Initialized
INFO - 2021-12-09 16:03:36 --> Output Class Initialized
INFO - 2021-12-09 16:03:36 --> Security Class Initialized
DEBUG - 2021-12-09 16:03:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 16:03:36 --> Input Class Initialized
INFO - 2021-12-09 16:03:36 --> Language Class Initialized
ERROR - 2021-12-09 16:03:36 --> 404 Page Not Found: Master/login.aspx
ERROR - 2021-12-09 16:03:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 16:03:36 --> Config Class Initialized
INFO - 2021-12-09 16:03:36 --> Hooks Class Initialized
DEBUG - 2021-12-09 16:03:36 --> UTF-8 Support Enabled
INFO - 2021-12-09 16:03:36 --> Utf8 Class Initialized
INFO - 2021-12-09 16:03:36 --> URI Class Initialized
INFO - 2021-12-09 16:03:36 --> Router Class Initialized
INFO - 2021-12-09 16:03:36 --> Output Class Initialized
INFO - 2021-12-09 16:03:36 --> Security Class Initialized
DEBUG - 2021-12-09 16:03:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 16:03:36 --> Input Class Initialized
INFO - 2021-12-09 16:03:36 --> Language Class Initialized
ERROR - 2021-12-09 16:03:36 --> 404 Page Not Found: Common/help
ERROR - 2021-12-09 16:03:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 16:03:37 --> Config Class Initialized
INFO - 2021-12-09 16:03:37 --> Hooks Class Initialized
DEBUG - 2021-12-09 16:03:37 --> UTF-8 Support Enabled
INFO - 2021-12-09 16:03:37 --> Utf8 Class Initialized
INFO - 2021-12-09 16:03:37 --> URI Class Initialized
INFO - 2021-12-09 16:03:37 --> Router Class Initialized
INFO - 2021-12-09 16:03:37 --> Output Class Initialized
INFO - 2021-12-09 16:03:37 --> Security Class Initialized
DEBUG - 2021-12-09 16:03:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 16:03:37 --> Input Class Initialized
INFO - 2021-12-09 16:03:37 --> Language Class Initialized
ERROR - 2021-12-09 16:03:37 --> 404 Page Not Found: Common/help
ERROR - 2021-12-09 16:03:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 16:03:37 --> Config Class Initialized
INFO - 2021-12-09 16:03:37 --> Hooks Class Initialized
DEBUG - 2021-12-09 16:03:37 --> UTF-8 Support Enabled
INFO - 2021-12-09 16:03:37 --> Utf8 Class Initialized
INFO - 2021-12-09 16:03:37 --> URI Class Initialized
INFO - 2021-12-09 16:03:37 --> Router Class Initialized
INFO - 2021-12-09 16:03:37 --> Output Class Initialized
INFO - 2021-12-09 16:03:37 --> Security Class Initialized
DEBUG - 2021-12-09 16:03:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 16:03:37 --> Input Class Initialized
INFO - 2021-12-09 16:03:37 --> Language Class Initialized
ERROR - 2021-12-09 16:03:37 --> 404 Page Not Found: Coremail/common
ERROR - 2021-12-09 16:03:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 16:03:37 --> Config Class Initialized
INFO - 2021-12-09 16:03:37 --> Hooks Class Initialized
DEBUG - 2021-12-09 16:03:37 --> UTF-8 Support Enabled
INFO - 2021-12-09 16:03:37 --> Utf8 Class Initialized
INFO - 2021-12-09 16:03:37 --> URI Class Initialized
INFO - 2021-12-09 16:03:37 --> Router Class Initialized
INFO - 2021-12-09 16:03:37 --> Output Class Initialized
INFO - 2021-12-09 16:03:37 --> Security Class Initialized
DEBUG - 2021-12-09 16:03:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 16:03:37 --> Input Class Initialized
INFO - 2021-12-09 16:03:37 --> Language Class Initialized
ERROR - 2021-12-09 16:03:37 --> 404 Page Not Found: Coremail/common
ERROR - 2021-12-09 16:03:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 16:03:38 --> Config Class Initialized
INFO - 2021-12-09 16:03:38 --> Hooks Class Initialized
DEBUG - 2021-12-09 16:03:38 --> UTF-8 Support Enabled
INFO - 2021-12-09 16:03:38 --> Utf8 Class Initialized
INFO - 2021-12-09 16:03:38 --> URI Class Initialized
INFO - 2021-12-09 16:03:38 --> Router Class Initialized
INFO - 2021-12-09 16:03:38 --> Output Class Initialized
INFO - 2021-12-09 16:03:38 --> Security Class Initialized
DEBUG - 2021-12-09 16:03:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 16:03:38 --> Input Class Initialized
INFO - 2021-12-09 16:03:38 --> Language Class Initialized
ERROR - 2021-12-09 16:03:38 --> 404 Page Not Found: Images/login
ERROR - 2021-12-09 16:03:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 16:03:38 --> Config Class Initialized
INFO - 2021-12-09 16:03:38 --> Hooks Class Initialized
DEBUG - 2021-12-09 16:03:38 --> UTF-8 Support Enabled
INFO - 2021-12-09 16:03:38 --> Utf8 Class Initialized
INFO - 2021-12-09 16:03:38 --> URI Class Initialized
INFO - 2021-12-09 16:03:38 --> Router Class Initialized
INFO - 2021-12-09 16:03:38 --> Output Class Initialized
INFO - 2021-12-09 16:03:38 --> Security Class Initialized
DEBUG - 2021-12-09 16:03:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 16:03:38 --> Input Class Initialized
INFO - 2021-12-09 16:03:38 --> Language Class Initialized
ERROR - 2021-12-09 16:03:38 --> 404 Page Not Found: Images/login
ERROR - 2021-12-09 16:03:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 16:03:38 --> Config Class Initialized
INFO - 2021-12-09 16:03:38 --> Hooks Class Initialized
DEBUG - 2021-12-09 16:03:38 --> UTF-8 Support Enabled
INFO - 2021-12-09 16:03:38 --> Utf8 Class Initialized
INFO - 2021-12-09 16:03:38 --> URI Class Initialized
INFO - 2021-12-09 16:03:38 --> Router Class Initialized
INFO - 2021-12-09 16:03:38 --> Output Class Initialized
INFO - 2021-12-09 16:03:38 --> Security Class Initialized
DEBUG - 2021-12-09 16:03:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 16:03:38 --> Input Class Initialized
INFO - 2021-12-09 16:03:38 --> Language Class Initialized
ERROR - 2021-12-09 16:03:38 --> 404 Page Not Found: Images/login
ERROR - 2021-12-09 16:03:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 16:03:39 --> Config Class Initialized
INFO - 2021-12-09 16:03:39 --> Hooks Class Initialized
DEBUG - 2021-12-09 16:03:39 --> UTF-8 Support Enabled
INFO - 2021-12-09 16:03:39 --> Utf8 Class Initialized
INFO - 2021-12-09 16:03:39 --> URI Class Initialized
INFO - 2021-12-09 16:03:39 --> Router Class Initialized
INFO - 2021-12-09 16:03:39 --> Output Class Initialized
INFO - 2021-12-09 16:03:39 --> Security Class Initialized
DEBUG - 2021-12-09 16:03:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 16:03:39 --> Input Class Initialized
INFO - 2021-12-09 16:03:39 --> Language Class Initialized
ERROR - 2021-12-09 16:03:39 --> 404 Page Not Found: Next/img
ERROR - 2021-12-09 16:03:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 16:03:39 --> Config Class Initialized
INFO - 2021-12-09 16:03:39 --> Hooks Class Initialized
DEBUG - 2021-12-09 16:03:39 --> UTF-8 Support Enabled
INFO - 2021-12-09 16:03:39 --> Utf8 Class Initialized
INFO - 2021-12-09 16:03:39 --> URI Class Initialized
INFO - 2021-12-09 16:03:39 --> Router Class Initialized
INFO - 2021-12-09 16:03:39 --> Output Class Initialized
INFO - 2021-12-09 16:03:39 --> Security Class Initialized
DEBUG - 2021-12-09 16:03:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 16:03:39 --> Input Class Initialized
INFO - 2021-12-09 16:03:39 --> Language Class Initialized
ERROR - 2021-12-09 16:03:39 --> 404 Page Not Found: Maintloginjsp/index
ERROR - 2021-12-09 16:03:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 16:03:40 --> Config Class Initialized
INFO - 2021-12-09 16:03:40 --> Hooks Class Initialized
DEBUG - 2021-12-09 16:03:40 --> UTF-8 Support Enabled
INFO - 2021-12-09 16:03:40 --> Utf8 Class Initialized
INFO - 2021-12-09 16:03:40 --> URI Class Initialized
INFO - 2021-12-09 16:03:40 --> Router Class Initialized
INFO - 2021-12-09 16:03:40 --> Output Class Initialized
INFO - 2021-12-09 16:03:40 --> Security Class Initialized
DEBUG - 2021-12-09 16:03:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 16:03:40 --> Input Class Initialized
INFO - 2021-12-09 16:03:40 --> Language Class Initialized
ERROR - 2021-12-09 16:03:40 --> 404 Page Not Found: Ckfinder/ckfinder.html
ERROR - 2021-12-09 16:03:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 16:03:40 --> Config Class Initialized
INFO - 2021-12-09 16:03:40 --> Hooks Class Initialized
DEBUG - 2021-12-09 16:03:40 --> UTF-8 Support Enabled
INFO - 2021-12-09 16:03:40 --> Utf8 Class Initialized
INFO - 2021-12-09 16:03:40 --> URI Class Initialized
INFO - 2021-12-09 16:03:40 --> Router Class Initialized
INFO - 2021-12-09 16:03:40 --> Output Class Initialized
INFO - 2021-12-09 16:03:40 --> Security Class Initialized
DEBUG - 2021-12-09 16:03:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 16:03:40 --> Input Class Initialized
INFO - 2021-12-09 16:03:40 --> Language Class Initialized
ERROR - 2021-12-09 16:03:40 --> 404 Page Not Found: Ckfinder/install.txt
ERROR - 2021-12-09 16:03:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 16:03:40 --> Config Class Initialized
INFO - 2021-12-09 16:03:40 --> Hooks Class Initialized
DEBUG - 2021-12-09 16:03:40 --> UTF-8 Support Enabled
INFO - 2021-12-09 16:03:40 --> Utf8 Class Initialized
INFO - 2021-12-09 16:03:40 --> URI Class Initialized
INFO - 2021-12-09 16:03:40 --> Router Class Initialized
INFO - 2021-12-09 16:03:40 --> Output Class Initialized
INFO - 2021-12-09 16:03:40 --> Security Class Initialized
DEBUG - 2021-12-09 16:03:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 16:03:40 --> Input Class Initialized
INFO - 2021-12-09 16:03:40 --> Language Class Initialized
ERROR - 2021-12-09 16:03:40 --> 404 Page Not Found: Ckeditor/ckfinder
ERROR - 2021-12-09 16:03:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 16:03:41 --> Config Class Initialized
INFO - 2021-12-09 16:03:41 --> Hooks Class Initialized
DEBUG - 2021-12-09 16:03:41 --> UTF-8 Support Enabled
INFO - 2021-12-09 16:03:41 --> Utf8 Class Initialized
INFO - 2021-12-09 16:03:41 --> URI Class Initialized
INFO - 2021-12-09 16:03:41 --> Router Class Initialized
INFO - 2021-12-09 16:03:41 --> Output Class Initialized
INFO - 2021-12-09 16:03:41 --> Security Class Initialized
DEBUG - 2021-12-09 16:03:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 16:03:41 --> Input Class Initialized
INFO - 2021-12-09 16:03:41 --> Language Class Initialized
ERROR - 2021-12-09 16:03:41 --> 404 Page Not Found: Ckeditor/ckfinder
ERROR - 2021-12-09 16:03:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 16:03:41 --> Config Class Initialized
INFO - 2021-12-09 16:03:41 --> Hooks Class Initialized
DEBUG - 2021-12-09 16:03:41 --> UTF-8 Support Enabled
INFO - 2021-12-09 16:03:41 --> Utf8 Class Initialized
INFO - 2021-12-09 16:03:41 --> URI Class Initialized
INFO - 2021-12-09 16:03:41 --> Router Class Initialized
INFO - 2021-12-09 16:03:41 --> Output Class Initialized
INFO - 2021-12-09 16:03:41 --> Security Class Initialized
DEBUG - 2021-12-09 16:03:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 16:03:41 --> Input Class Initialized
INFO - 2021-12-09 16:03:41 --> Language Class Initialized
ERROR - 2021-12-09 16:03:41 --> 404 Page Not Found: Admin/index
ERROR - 2021-12-09 16:03:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 16:03:41 --> Config Class Initialized
INFO - 2021-12-09 16:03:41 --> Hooks Class Initialized
DEBUG - 2021-12-09 16:03:41 --> UTF-8 Support Enabled
INFO - 2021-12-09 16:03:41 --> Utf8 Class Initialized
INFO - 2021-12-09 16:03:41 --> URI Class Initialized
INFO - 2021-12-09 16:03:41 --> Router Class Initialized
INFO - 2021-12-09 16:03:41 --> Output Class Initialized
INFO - 2021-12-09 16:03:41 --> Security Class Initialized
DEBUG - 2021-12-09 16:03:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 16:03:41 --> Input Class Initialized
INFO - 2021-12-09 16:03:41 --> Language Class Initialized
ERROR - 2021-12-09 16:03:41 --> 404 Page Not Found: Listphp/index
ERROR - 2021-12-09 16:03:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 16:03:41 --> Config Class Initialized
INFO - 2021-12-09 16:03:41 --> Hooks Class Initialized
DEBUG - 2021-12-09 16:03:41 --> UTF-8 Support Enabled
INFO - 2021-12-09 16:03:41 --> Utf8 Class Initialized
INFO - 2021-12-09 16:03:41 --> URI Class Initialized
INFO - 2021-12-09 16:03:41 --> Router Class Initialized
INFO - 2021-12-09 16:03:41 --> Output Class Initialized
INFO - 2021-12-09 16:03:41 --> Security Class Initialized
DEBUG - 2021-12-09 16:03:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 16:03:42 --> Input Class Initialized
INFO - 2021-12-09 16:03:42 --> Language Class Initialized
ERROR - 2021-12-09 16:03:42 --> 404 Page Not Found: Admin/template
ERROR - 2021-12-09 16:03:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 16:03:42 --> Config Class Initialized
INFO - 2021-12-09 16:03:42 --> Hooks Class Initialized
DEBUG - 2021-12-09 16:03:42 --> UTF-8 Support Enabled
INFO - 2021-12-09 16:03:42 --> Utf8 Class Initialized
INFO - 2021-12-09 16:03:42 --> URI Class Initialized
INFO - 2021-12-09 16:03:42 --> Router Class Initialized
INFO - 2021-12-09 16:03:42 --> Output Class Initialized
INFO - 2021-12-09 16:03:42 --> Security Class Initialized
DEBUG - 2021-12-09 16:03:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 16:03:42 --> Input Class Initialized
INFO - 2021-12-09 16:03:42 --> Language Class Initialized
ERROR - 2021-12-09 16:03:42 --> 404 Page Not Found: Help/ch_gb
ERROR - 2021-12-09 16:03:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 16:03:42 --> Config Class Initialized
INFO - 2021-12-09 16:03:42 --> Hooks Class Initialized
DEBUG - 2021-12-09 16:03:42 --> UTF-8 Support Enabled
INFO - 2021-12-09 16:03:42 --> Utf8 Class Initialized
INFO - 2021-12-09 16:03:42 --> URI Class Initialized
INFO - 2021-12-09 16:03:42 --> Router Class Initialized
INFO - 2021-12-09 16:03:42 --> Output Class Initialized
INFO - 2021-12-09 16:03:42 --> Security Class Initialized
DEBUG - 2021-12-09 16:03:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 16:03:42 --> Input Class Initialized
INFO - 2021-12-09 16:03:42 --> Language Class Initialized
ERROR - 2021-12-09 16:03:42 --> 404 Page Not Found: Admin/index.php
ERROR - 2021-12-09 16:03:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 16:03:43 --> Config Class Initialized
INFO - 2021-12-09 16:03:43 --> Hooks Class Initialized
DEBUG - 2021-12-09 16:03:43 --> UTF-8 Support Enabled
INFO - 2021-12-09 16:03:43 --> Utf8 Class Initialized
INFO - 2021-12-09 16:03:43 --> URI Class Initialized
INFO - 2021-12-09 16:03:43 --> Router Class Initialized
INFO - 2021-12-09 16:03:43 --> Output Class Initialized
INFO - 2021-12-09 16:03:43 --> Security Class Initialized
DEBUG - 2021-12-09 16:03:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 16:03:43 --> Input Class Initialized
INFO - 2021-12-09 16:03:43 --> Language Class Initialized
ERROR - 2021-12-09 16:03:43 --> 404 Page Not Found: Bencandyphp/index
ERROR - 2021-12-09 16:03:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 16:03:43 --> Config Class Initialized
INFO - 2021-12-09 16:03:43 --> Hooks Class Initialized
DEBUG - 2021-12-09 16:03:43 --> UTF-8 Support Enabled
INFO - 2021-12-09 16:03:43 --> Utf8 Class Initialized
INFO - 2021-12-09 16:03:43 --> URI Class Initialized
DEBUG - 2021-12-09 16:03:43 --> No URI present. Default controller set.
INFO - 2021-12-09 16:03:43 --> Router Class Initialized
INFO - 2021-12-09 16:03:43 --> Output Class Initialized
INFO - 2021-12-09 16:03:43 --> Security Class Initialized
DEBUG - 2021-12-09 16:03:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 16:03:43 --> Input Class Initialized
INFO - 2021-12-09 16:03:43 --> Language Class Initialized
INFO - 2021-12-09 16:03:43 --> Loader Class Initialized
INFO - 2021-12-09 16:03:43 --> Helper loaded: url_helper
INFO - 2021-12-09 16:03:43 --> Helper loaded: form_helper
INFO - 2021-12-09 16:03:43 --> Helper loaded: common_helper
INFO - 2021-12-09 16:03:43 --> Database Driver Class Initialized
DEBUG - 2021-12-09 16:03:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 16:03:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 16:03:43 --> Controller Class Initialized
INFO - 2021-12-09 16:03:43 --> Form Validation Class Initialized
DEBUG - 2021-12-09 16:03:43 --> Encrypt Class Initialized
DEBUG - 2021-12-09 16:03:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-09 16:03:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-09 16:03:43 --> Email Class Initialized
INFO - 2021-12-09 16:03:43 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-09 16:03:43 --> Calendar Class Initialized
INFO - 2021-12-09 16:03:43 --> Model "Login_model" initialized
INFO - 2021-12-09 16:03:43 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-09 16:03:43 --> Final output sent to browser
DEBUG - 2021-12-09 16:03:43 --> Total execution time: 0.0220
ERROR - 2021-12-09 16:03:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 16:03:43 --> Config Class Initialized
INFO - 2021-12-09 16:03:43 --> Hooks Class Initialized
DEBUG - 2021-12-09 16:03:43 --> UTF-8 Support Enabled
INFO - 2021-12-09 16:03:43 --> Utf8 Class Initialized
INFO - 2021-12-09 16:03:43 --> URI Class Initialized
DEBUG - 2021-12-09 16:03:43 --> No URI present. Default controller set.
INFO - 2021-12-09 16:03:43 --> Router Class Initialized
INFO - 2021-12-09 16:03:43 --> Output Class Initialized
INFO - 2021-12-09 16:03:43 --> Security Class Initialized
DEBUG - 2021-12-09 16:03:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 16:03:43 --> Input Class Initialized
INFO - 2021-12-09 16:03:43 --> Language Class Initialized
INFO - 2021-12-09 16:03:43 --> Loader Class Initialized
INFO - 2021-12-09 16:03:43 --> Helper loaded: url_helper
INFO - 2021-12-09 16:03:43 --> Helper loaded: form_helper
INFO - 2021-12-09 16:03:43 --> Helper loaded: common_helper
INFO - 2021-12-09 16:03:43 --> Database Driver Class Initialized
DEBUG - 2021-12-09 16:03:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 16:03:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 16:03:43 --> Controller Class Initialized
INFO - 2021-12-09 16:03:43 --> Form Validation Class Initialized
DEBUG - 2021-12-09 16:03:43 --> Encrypt Class Initialized
DEBUG - 2021-12-09 16:03:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-09 16:03:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-09 16:03:43 --> Email Class Initialized
INFO - 2021-12-09 16:03:43 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-09 16:03:43 --> Calendar Class Initialized
INFO - 2021-12-09 16:03:43 --> Model "Login_model" initialized
INFO - 2021-12-09 16:03:43 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-09 16:03:43 --> Final output sent to browser
DEBUG - 2021-12-09 16:03:43 --> Total execution time: 0.0236
ERROR - 2021-12-09 16:03:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 16:03:44 --> Config Class Initialized
INFO - 2021-12-09 16:03:44 --> Hooks Class Initialized
DEBUG - 2021-12-09 16:03:44 --> UTF-8 Support Enabled
INFO - 2021-12-09 16:03:44 --> Utf8 Class Initialized
INFO - 2021-12-09 16:03:44 --> URI Class Initialized
DEBUG - 2021-12-09 16:03:44 --> No URI present. Default controller set.
INFO - 2021-12-09 16:03:44 --> Router Class Initialized
INFO - 2021-12-09 16:03:44 --> Output Class Initialized
INFO - 2021-12-09 16:03:44 --> Security Class Initialized
DEBUG - 2021-12-09 16:03:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 16:03:44 --> Input Class Initialized
INFO - 2021-12-09 16:03:44 --> Language Class Initialized
INFO - 2021-12-09 16:03:44 --> Loader Class Initialized
INFO - 2021-12-09 16:03:44 --> Helper loaded: url_helper
INFO - 2021-12-09 16:03:44 --> Helper loaded: form_helper
INFO - 2021-12-09 16:03:44 --> Helper loaded: common_helper
INFO - 2021-12-09 16:03:44 --> Database Driver Class Initialized
DEBUG - 2021-12-09 16:03:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 16:03:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 16:03:44 --> Controller Class Initialized
INFO - 2021-12-09 16:03:44 --> Form Validation Class Initialized
DEBUG - 2021-12-09 16:03:44 --> Encrypt Class Initialized
DEBUG - 2021-12-09 16:03:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-09 16:03:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-09 16:03:44 --> Email Class Initialized
INFO - 2021-12-09 16:03:44 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-09 16:03:44 --> Calendar Class Initialized
INFO - 2021-12-09 16:03:44 --> Model "Login_model" initialized
INFO - 2021-12-09 16:03:44 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-09 16:03:44 --> Final output sent to browser
DEBUG - 2021-12-09 16:03:44 --> Total execution time: 0.0223
ERROR - 2021-12-09 16:03:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 16:03:46 --> Config Class Initialized
INFO - 2021-12-09 16:03:46 --> Hooks Class Initialized
DEBUG - 2021-12-09 16:03:46 --> UTF-8 Support Enabled
INFO - 2021-12-09 16:03:46 --> Utf8 Class Initialized
INFO - 2021-12-09 16:03:46 --> URI Class Initialized
DEBUG - 2021-12-09 16:03:46 --> No URI present. Default controller set.
INFO - 2021-12-09 16:03:46 --> Router Class Initialized
INFO - 2021-12-09 16:03:46 --> Output Class Initialized
INFO - 2021-12-09 16:03:46 --> Security Class Initialized
DEBUG - 2021-12-09 16:03:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 16:03:46 --> Input Class Initialized
INFO - 2021-12-09 16:03:46 --> Language Class Initialized
INFO - 2021-12-09 16:03:46 --> Loader Class Initialized
INFO - 2021-12-09 16:03:46 --> Helper loaded: url_helper
INFO - 2021-12-09 16:03:46 --> Helper loaded: form_helper
INFO - 2021-12-09 16:03:46 --> Helper loaded: common_helper
INFO - 2021-12-09 16:03:46 --> Database Driver Class Initialized
DEBUG - 2021-12-09 16:03:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 16:03:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 16:03:46 --> Controller Class Initialized
INFO - 2021-12-09 16:03:46 --> Form Validation Class Initialized
DEBUG - 2021-12-09 16:03:46 --> Encrypt Class Initialized
DEBUG - 2021-12-09 16:03:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-09 16:03:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-09 16:03:46 --> Email Class Initialized
INFO - 2021-12-09 16:03:46 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-09 16:03:46 --> Calendar Class Initialized
INFO - 2021-12-09 16:03:46 --> Model "Login_model" initialized
INFO - 2021-12-09 16:03:46 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-09 16:03:46 --> Final output sent to browser
DEBUG - 2021-12-09 16:03:46 --> Total execution time: 0.0214
ERROR - 2021-12-09 16:03:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 16:03:47 --> Config Class Initialized
INFO - 2021-12-09 16:03:47 --> Hooks Class Initialized
DEBUG - 2021-12-09 16:03:47 --> UTF-8 Support Enabled
INFO - 2021-12-09 16:03:47 --> Utf8 Class Initialized
INFO - 2021-12-09 16:03:47 --> URI Class Initialized
INFO - 2021-12-09 16:03:47 --> Router Class Initialized
INFO - 2021-12-09 16:03:47 --> Output Class Initialized
INFO - 2021-12-09 16:03:47 --> Security Class Initialized
DEBUG - 2021-12-09 16:03:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 16:03:47 --> Input Class Initialized
INFO - 2021-12-09 16:03:47 --> Language Class Initialized
ERROR - 2021-12-09 16:03:47 --> 404 Page Not Found: CuteSoft_Client/CuteEditor
ERROR - 2021-12-09 16:03:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 16:03:47 --> Config Class Initialized
INFO - 2021-12-09 16:03:47 --> Hooks Class Initialized
DEBUG - 2021-12-09 16:03:47 --> UTF-8 Support Enabled
INFO - 2021-12-09 16:03:47 --> Utf8 Class Initialized
INFO - 2021-12-09 16:03:47 --> URI Class Initialized
INFO - 2021-12-09 16:03:47 --> Router Class Initialized
INFO - 2021-12-09 16:03:47 --> Output Class Initialized
INFO - 2021-12-09 16:03:47 --> Security Class Initialized
DEBUG - 2021-12-09 16:03:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 16:03:47 --> Input Class Initialized
INFO - 2021-12-09 16:03:47 --> Language Class Initialized
ERROR - 2021-12-09 16:03:47 --> 404 Page Not Found: CuteSoft_Client/CuteEditor
ERROR - 2021-12-09 16:03:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 16:03:48 --> Config Class Initialized
INFO - 2021-12-09 16:03:48 --> Hooks Class Initialized
DEBUG - 2021-12-09 16:03:48 --> UTF-8 Support Enabled
INFO - 2021-12-09 16:03:48 --> Utf8 Class Initialized
INFO - 2021-12-09 16:03:48 --> URI Class Initialized
INFO - 2021-12-09 16:03:48 --> Router Class Initialized
INFO - 2021-12-09 16:03:48 --> Output Class Initialized
INFO - 2021-12-09 16:03:48 --> Security Class Initialized
DEBUG - 2021-12-09 16:03:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 16:03:48 --> Input Class Initialized
INFO - 2021-12-09 16:03:48 --> Language Class Initialized
ERROR - 2021-12-09 16:03:48 --> 404 Page Not Found: CuteSoft_Client/CuteEditor
ERROR - 2021-12-09 16:03:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 16:03:48 --> Config Class Initialized
INFO - 2021-12-09 16:03:48 --> Hooks Class Initialized
DEBUG - 2021-12-09 16:03:48 --> UTF-8 Support Enabled
INFO - 2021-12-09 16:03:48 --> Utf8 Class Initialized
INFO - 2021-12-09 16:03:48 --> URI Class Initialized
INFO - 2021-12-09 16:03:48 --> Router Class Initialized
INFO - 2021-12-09 16:03:48 --> Output Class Initialized
INFO - 2021-12-09 16:03:48 --> Security Class Initialized
DEBUG - 2021-12-09 16:03:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 16:03:48 --> Input Class Initialized
INFO - 2021-12-09 16:03:48 --> Language Class Initialized
ERROR - 2021-12-09 16:03:48 --> 404 Page Not Found: CuteSoft_Client/CuteEditor
ERROR - 2021-12-09 16:03:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 16:03:48 --> Config Class Initialized
INFO - 2021-12-09 16:03:48 --> Hooks Class Initialized
DEBUG - 2021-12-09 16:03:48 --> UTF-8 Support Enabled
INFO - 2021-12-09 16:03:48 --> Utf8 Class Initialized
INFO - 2021-12-09 16:03:48 --> URI Class Initialized
INFO - 2021-12-09 16:03:48 --> Router Class Initialized
INFO - 2021-12-09 16:03:48 --> Output Class Initialized
INFO - 2021-12-09 16:03:48 --> Security Class Initialized
DEBUG - 2021-12-09 16:03:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 16:03:48 --> Input Class Initialized
INFO - 2021-12-09 16:03:48 --> Language Class Initialized
ERROR - 2021-12-09 16:03:48 --> 404 Page Not Found: Admin/inc
ERROR - 2021-12-09 16:03:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 16:03:49 --> Config Class Initialized
INFO - 2021-12-09 16:03:49 --> Hooks Class Initialized
DEBUG - 2021-12-09 16:03:49 --> UTF-8 Support Enabled
INFO - 2021-12-09 16:03:49 --> Utf8 Class Initialized
INFO - 2021-12-09 16:03:49 --> URI Class Initialized
INFO - 2021-12-09 16:03:49 --> Router Class Initialized
INFO - 2021-12-09 16:03:49 --> Output Class Initialized
INFO - 2021-12-09 16:03:49 --> Security Class Initialized
DEBUG - 2021-12-09 16:03:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 16:03:49 --> Input Class Initialized
INFO - 2021-12-09 16:03:49 --> Language Class Initialized
ERROR - 2021-12-09 16:03:49 --> 404 Page Not Found: Admin/js
ERROR - 2021-12-09 16:03:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 16:03:49 --> Config Class Initialized
INFO - 2021-12-09 16:03:49 --> Hooks Class Initialized
DEBUG - 2021-12-09 16:03:49 --> UTF-8 Support Enabled
INFO - 2021-12-09 16:03:49 --> Utf8 Class Initialized
INFO - 2021-12-09 16:03:49 --> URI Class Initialized
INFO - 2021-12-09 16:03:49 --> Router Class Initialized
INFO - 2021-12-09 16:03:49 --> Output Class Initialized
INFO - 2021-12-09 16:03:49 --> Security Class Initialized
DEBUG - 2021-12-09 16:03:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 16:03:49 --> Input Class Initialized
INFO - 2021-12-09 16:03:49 --> Language Class Initialized
ERROR - 2021-12-09 16:03:49 --> 404 Page Not Found: Ids/admin
ERROR - 2021-12-09 16:03:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 16:03:50 --> Config Class Initialized
INFO - 2021-12-09 16:03:50 --> Hooks Class Initialized
DEBUG - 2021-12-09 16:03:50 --> UTF-8 Support Enabled
INFO - 2021-12-09 16:03:50 --> Utf8 Class Initialized
INFO - 2021-12-09 16:03:50 --> URI Class Initialized
INFO - 2021-12-09 16:03:50 --> Router Class Initialized
INFO - 2021-12-09 16:03:50 --> Output Class Initialized
INFO - 2021-12-09 16:03:50 --> Security Class Initialized
DEBUG - 2021-12-09 16:03:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 16:03:50 --> Input Class Initialized
INFO - 2021-12-09 16:03:50 --> Language Class Initialized
ERROR - 2021-12-09 16:03:50 --> 404 Page Not Found: Ids/admin
ERROR - 2021-12-09 16:03:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 16:03:50 --> Config Class Initialized
INFO - 2021-12-09 16:03:50 --> Hooks Class Initialized
DEBUG - 2021-12-09 16:03:50 --> UTF-8 Support Enabled
INFO - 2021-12-09 16:03:50 --> Utf8 Class Initialized
INFO - 2021-12-09 16:03:50 --> URI Class Initialized
INFO - 2021-12-09 16:03:50 --> Router Class Initialized
INFO - 2021-12-09 16:03:50 --> Output Class Initialized
INFO - 2021-12-09 16:03:50 --> Security Class Initialized
DEBUG - 2021-12-09 16:03:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 16:03:50 --> Input Class Initialized
INFO - 2021-12-09 16:03:50 --> Language Class Initialized
ERROR - 2021-12-09 16:03:50 --> 404 Page Not Found: Siteserver/upgrade
ERROR - 2021-12-09 16:03:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 16:03:50 --> Config Class Initialized
INFO - 2021-12-09 16:03:50 --> Hooks Class Initialized
DEBUG - 2021-12-09 16:03:50 --> UTF-8 Support Enabled
INFO - 2021-12-09 16:03:50 --> Utf8 Class Initialized
INFO - 2021-12-09 16:03:50 --> URI Class Initialized
INFO - 2021-12-09 16:03:50 --> Router Class Initialized
INFO - 2021-12-09 16:03:50 --> Output Class Initialized
INFO - 2021-12-09 16:03:50 --> Security Class Initialized
DEBUG - 2021-12-09 16:03:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 16:03:50 --> Input Class Initialized
INFO - 2021-12-09 16:03:50 --> Language Class Initialized
ERROR - 2021-12-09 16:03:50 --> 404 Page Not Found: Siteserver/login.aspx
ERROR - 2021-12-09 16:03:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 16:03:51 --> Config Class Initialized
INFO - 2021-12-09 16:03:51 --> Hooks Class Initialized
DEBUG - 2021-12-09 16:03:51 --> UTF-8 Support Enabled
INFO - 2021-12-09 16:03:51 --> Utf8 Class Initialized
INFO - 2021-12-09 16:03:51 --> URI Class Initialized
INFO - 2021-12-09 16:03:51 --> Router Class Initialized
INFO - 2021-12-09 16:03:51 --> Output Class Initialized
INFO - 2021-12-09 16:03:51 --> Security Class Initialized
DEBUG - 2021-12-09 16:03:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 16:03:51 --> Input Class Initialized
INFO - 2021-12-09 16:03:51 --> Language Class Initialized
ERROR - 2021-12-09 16:03:51 --> 404 Page Not Found: UserCenter/css
ERROR - 2021-12-09 16:03:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 16:03:51 --> Config Class Initialized
INFO - 2021-12-09 16:03:51 --> Hooks Class Initialized
DEBUG - 2021-12-09 16:03:51 --> UTF-8 Support Enabled
INFO - 2021-12-09 16:03:51 --> Utf8 Class Initialized
INFO - 2021-12-09 16:03:51 --> URI Class Initialized
INFO - 2021-12-09 16:03:51 --> Router Class Initialized
INFO - 2021-12-09 16:03:51 --> Output Class Initialized
INFO - 2021-12-09 16:03:51 --> Security Class Initialized
DEBUG - 2021-12-09 16:03:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 16:03:51 --> Input Class Initialized
INFO - 2021-12-09 16:03:51 --> Language Class Initialized
ERROR - 2021-12-09 16:03:51 --> 404 Page Not Found: Dialog/dialog.js
ERROR - 2021-12-09 16:03:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 16:03:51 --> Config Class Initialized
INFO - 2021-12-09 16:03:51 --> Hooks Class Initialized
DEBUG - 2021-12-09 16:03:51 --> UTF-8 Support Enabled
INFO - 2021-12-09 16:03:51 --> Utf8 Class Initialized
INFO - 2021-12-09 16:03:51 --> URI Class Initialized
INFO - 2021-12-09 16:03:51 --> Router Class Initialized
INFO - 2021-12-09 16:03:51 --> Output Class Initialized
INFO - 2021-12-09 16:03:51 --> Security Class Initialized
DEBUG - 2021-12-09 16:03:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 16:03:51 --> Input Class Initialized
INFO - 2021-12-09 16:03:51 --> Language Class Initialized
ERROR - 2021-12-09 16:03:51 --> 404 Page Not Found: Editorjs/index
ERROR - 2021-12-09 16:03:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 16:03:52 --> Config Class Initialized
INFO - 2021-12-09 16:03:52 --> Hooks Class Initialized
DEBUG - 2021-12-09 16:03:52 --> UTF-8 Support Enabled
INFO - 2021-12-09 16:03:52 --> Utf8 Class Initialized
INFO - 2021-12-09 16:03:52 --> URI Class Initialized
INFO - 2021-12-09 16:03:52 --> Router Class Initialized
INFO - 2021-12-09 16:03:52 --> Output Class Initialized
INFO - 2021-12-09 16:03:52 --> Security Class Initialized
DEBUG - 2021-12-09 16:03:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 16:03:52 --> Input Class Initialized
INFO - 2021-12-09 16:03:52 --> Language Class Initialized
ERROR - 2021-12-09 16:03:52 --> 404 Page Not Found: Indexcgi/index
ERROR - 2021-12-09 16:03:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 16:03:52 --> Config Class Initialized
INFO - 2021-12-09 16:03:52 --> Hooks Class Initialized
DEBUG - 2021-12-09 16:03:52 --> UTF-8 Support Enabled
INFO - 2021-12-09 16:03:52 --> Utf8 Class Initialized
INFO - 2021-12-09 16:03:52 --> URI Class Initialized
INFO - 2021-12-09 16:03:52 --> Router Class Initialized
INFO - 2021-12-09 16:03:52 --> Output Class Initialized
INFO - 2021-12-09 16:03:52 --> Security Class Initialized
DEBUG - 2021-12-09 16:03:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 16:03:52 --> Input Class Initialized
INFO - 2021-12-09 16:03:52 --> Language Class Initialized
ERROR - 2021-12-09 16:03:52 --> 404 Page Not Found: Cgi/index.cgi
ERROR - 2021-12-09 16:03:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 16:03:53 --> Config Class Initialized
INFO - 2021-12-09 16:03:53 --> Hooks Class Initialized
DEBUG - 2021-12-09 16:03:53 --> UTF-8 Support Enabled
INFO - 2021-12-09 16:03:53 --> Utf8 Class Initialized
INFO - 2021-12-09 16:03:53 --> URI Class Initialized
INFO - 2021-12-09 16:03:53 --> Router Class Initialized
INFO - 2021-12-09 16:03:53 --> Output Class Initialized
INFO - 2021-12-09 16:03:53 --> Security Class Initialized
DEBUG - 2021-12-09 16:03:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 16:03:53 --> Input Class Initialized
INFO - 2021-12-09 16:03:53 --> Language Class Initialized
ERROR - 2021-12-09 16:03:53 --> 404 Page Not Found: Default/images
ERROR - 2021-12-09 16:03:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 16:03:53 --> Config Class Initialized
INFO - 2021-12-09 16:03:53 --> Hooks Class Initialized
DEBUG - 2021-12-09 16:03:53 --> UTF-8 Support Enabled
INFO - 2021-12-09 16:03:53 --> Utf8 Class Initialized
INFO - 2021-12-09 16:03:53 --> URI Class Initialized
INFO - 2021-12-09 16:03:53 --> Router Class Initialized
INFO - 2021-12-09 16:03:53 --> Output Class Initialized
INFO - 2021-12-09 16:03:53 --> Security Class Initialized
DEBUG - 2021-12-09 16:03:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 16:03:53 --> Input Class Initialized
INFO - 2021-12-09 16:03:53 --> Language Class Initialized
ERROR - 2021-12-09 16:03:53 --> 404 Page Not Found: Extman/default
ERROR - 2021-12-09 16:03:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 16:03:54 --> Config Class Initialized
INFO - 2021-12-09 16:03:54 --> Hooks Class Initialized
DEBUG - 2021-12-09 16:03:54 --> UTF-8 Support Enabled
INFO - 2021-12-09 16:03:54 --> Utf8 Class Initialized
INFO - 2021-12-09 16:03:54 --> URI Class Initialized
INFO - 2021-12-09 16:03:54 --> Router Class Initialized
INFO - 2021-12-09 16:03:54 --> Output Class Initialized
INFO - 2021-12-09 16:03:54 --> Security Class Initialized
DEBUG - 2021-12-09 16:03:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 16:03:54 --> Input Class Initialized
INFO - 2021-12-09 16:03:54 --> Language Class Initialized
ERROR - 2021-12-09 16:03:54 --> 404 Page Not Found: Default/css
ERROR - 2021-12-09 16:03:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 16:03:54 --> Config Class Initialized
INFO - 2021-12-09 16:03:54 --> Hooks Class Initialized
DEBUG - 2021-12-09 16:03:54 --> UTF-8 Support Enabled
INFO - 2021-12-09 16:03:54 --> Utf8 Class Initialized
INFO - 2021-12-09 16:03:54 --> URI Class Initialized
INFO - 2021-12-09 16:03:54 --> Router Class Initialized
INFO - 2021-12-09 16:03:54 --> Output Class Initialized
INFO - 2021-12-09 16:03:54 --> Security Class Initialized
DEBUG - 2021-12-09 16:03:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 16:03:54 --> Input Class Initialized
INFO - 2021-12-09 16:03:54 --> Language Class Initialized
ERROR - 2021-12-09 16:03:54 --> 404 Page Not Found: App/home
ERROR - 2021-12-09 16:04:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 16:04:06 --> Config Class Initialized
INFO - 2021-12-09 16:04:06 --> Hooks Class Initialized
DEBUG - 2021-12-09 16:04:06 --> UTF-8 Support Enabled
INFO - 2021-12-09 16:04:06 --> Utf8 Class Initialized
INFO - 2021-12-09 16:04:06 --> URI Class Initialized
INFO - 2021-12-09 16:04:06 --> Router Class Initialized
INFO - 2021-12-09 16:04:06 --> Output Class Initialized
INFO - 2021-12-09 16:04:06 --> Security Class Initialized
DEBUG - 2021-12-09 16:04:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 16:04:06 --> Input Class Initialized
INFO - 2021-12-09 16:04:06 --> Language Class Initialized
ERROR - 2021-12-09 16:04:06 --> 404 Page Not Found: Admin/SouthidcEditor
ERROR - 2021-12-09 16:04:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 16:04:07 --> Config Class Initialized
INFO - 2021-12-09 16:04:07 --> Hooks Class Initialized
DEBUG - 2021-12-09 16:04:07 --> UTF-8 Support Enabled
INFO - 2021-12-09 16:04:07 --> Utf8 Class Initialized
INFO - 2021-12-09 16:04:07 --> URI Class Initialized
INFO - 2021-12-09 16:04:07 --> Router Class Initialized
INFO - 2021-12-09 16:04:07 --> Output Class Initialized
INFO - 2021-12-09 16:04:07 --> Security Class Initialized
DEBUG - 2021-12-09 16:04:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 16:04:07 --> Input Class Initialized
INFO - 2021-12-09 16:04:07 --> Language Class Initialized
ERROR - 2021-12-09 16:04:07 --> 404 Page Not Found: Admin/SouthidcEditor
ERROR - 2021-12-09 16:04:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 16:04:07 --> Config Class Initialized
INFO - 2021-12-09 16:04:07 --> Hooks Class Initialized
DEBUG - 2021-12-09 16:04:07 --> UTF-8 Support Enabled
INFO - 2021-12-09 16:04:07 --> Utf8 Class Initialized
INFO - 2021-12-09 16:04:07 --> URI Class Initialized
INFO - 2021-12-09 16:04:07 --> Router Class Initialized
INFO - 2021-12-09 16:04:07 --> Output Class Initialized
INFO - 2021-12-09 16:04:07 --> Security Class Initialized
DEBUG - 2021-12-09 16:04:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 16:04:07 --> Input Class Initialized
INFO - 2021-12-09 16:04:07 --> Language Class Initialized
ERROR - 2021-12-09 16:04:07 --> 404 Page Not Found: Admin/SouthidcEditor
ERROR - 2021-12-09 16:04:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 16:04:07 --> Config Class Initialized
INFO - 2021-12-09 16:04:07 --> Hooks Class Initialized
DEBUG - 2021-12-09 16:04:07 --> UTF-8 Support Enabled
INFO - 2021-12-09 16:04:07 --> Utf8 Class Initialized
INFO - 2021-12-09 16:04:07 --> URI Class Initialized
INFO - 2021-12-09 16:04:07 --> Router Class Initialized
INFO - 2021-12-09 16:04:07 --> Output Class Initialized
INFO - 2021-12-09 16:04:07 --> Security Class Initialized
DEBUG - 2021-12-09 16:04:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 16:04:07 --> Input Class Initialized
INFO - 2021-12-09 16:04:07 --> Language Class Initialized
ERROR - 2021-12-09 16:04:07 --> 404 Page Not Found: App/login.jsp
ERROR - 2021-12-09 16:04:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 16:04:08 --> Config Class Initialized
INFO - 2021-12-09 16:04:08 --> Hooks Class Initialized
DEBUG - 2021-12-09 16:04:08 --> UTF-8 Support Enabled
INFO - 2021-12-09 16:04:08 --> Utf8 Class Initialized
INFO - 2021-12-09 16:04:08 --> URI Class Initialized
INFO - 2021-12-09 16:04:08 --> Router Class Initialized
INFO - 2021-12-09 16:04:08 --> Output Class Initialized
INFO - 2021-12-09 16:04:08 --> Security Class Initialized
DEBUG - 2021-12-09 16:04:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 16:04:08 --> Input Class Initialized
INFO - 2021-12-09 16:04:08 --> Language Class Initialized
ERROR - 2021-12-09 16:04:08 --> 404 Page Not Found: App/js
ERROR - 2021-12-09 16:04:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 16:04:08 --> Config Class Initialized
INFO - 2021-12-09 16:04:08 --> Hooks Class Initialized
DEBUG - 2021-12-09 16:04:08 --> UTF-8 Support Enabled
INFO - 2021-12-09 16:04:08 --> Utf8 Class Initialized
INFO - 2021-12-09 16:04:08 --> URI Class Initialized
INFO - 2021-12-09 16:04:08 --> Router Class Initialized
INFO - 2021-12-09 16:04:08 --> Output Class Initialized
INFO - 2021-12-09 16:04:08 --> Security Class Initialized
DEBUG - 2021-12-09 16:04:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 16:04:08 --> Input Class Initialized
INFO - 2021-12-09 16:04:08 --> Language Class Initialized
ERROR - 2021-12-09 16:04:08 --> 404 Page Not Found: Console/js
ERROR - 2021-12-09 16:04:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 16:04:08 --> Config Class Initialized
INFO - 2021-12-09 16:04:08 --> Hooks Class Initialized
DEBUG - 2021-12-09 16:04:08 --> UTF-8 Support Enabled
INFO - 2021-12-09 16:04:08 --> Utf8 Class Initialized
INFO - 2021-12-09 16:04:08 --> URI Class Initialized
INFO - 2021-12-09 16:04:08 --> Router Class Initialized
INFO - 2021-12-09 16:04:08 --> Output Class Initialized
INFO - 2021-12-09 16:04:08 --> Security Class Initialized
DEBUG - 2021-12-09 16:04:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 16:04:08 --> Input Class Initialized
INFO - 2021-12-09 16:04:08 --> Language Class Initialized
ERROR - 2021-12-09 16:04:08 --> 404 Page Not Found: Console/include
ERROR - 2021-12-09 16:04:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 16:04:09 --> Config Class Initialized
INFO - 2021-12-09 16:04:09 --> Hooks Class Initialized
DEBUG - 2021-12-09 16:04:09 --> UTF-8 Support Enabled
INFO - 2021-12-09 16:04:09 --> Utf8 Class Initialized
INFO - 2021-12-09 16:04:09 --> URI Class Initialized
INFO - 2021-12-09 16:04:09 --> Router Class Initialized
INFO - 2021-12-09 16:04:09 --> Output Class Initialized
INFO - 2021-12-09 16:04:09 --> Security Class Initialized
DEBUG - 2021-12-09 16:04:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 16:04:09 --> Input Class Initialized
INFO - 2021-12-09 16:04:09 --> Language Class Initialized
ERROR - 2021-12-09 16:04:09 --> 404 Page Not Found: Console/auth
ERROR - 2021-12-09 16:04:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 16:04:09 --> Config Class Initialized
INFO - 2021-12-09 16:04:09 --> Hooks Class Initialized
DEBUG - 2021-12-09 16:04:09 --> UTF-8 Support Enabled
INFO - 2021-12-09 16:04:09 --> Utf8 Class Initialized
INFO - 2021-12-09 16:04:09 --> URI Class Initialized
INFO - 2021-12-09 16:04:09 --> Router Class Initialized
INFO - 2021-12-09 16:04:09 --> Output Class Initialized
INFO - 2021-12-09 16:04:09 --> Security Class Initialized
DEBUG - 2021-12-09 16:04:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 16:04:09 --> Input Class Initialized
INFO - 2021-12-09 16:04:09 --> Language Class Initialized
ERROR - 2021-12-09 16:04:09 --> 404 Page Not Found: Console/js
ERROR - 2021-12-09 16:04:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 16:04:09 --> Config Class Initialized
INFO - 2021-12-09 16:04:09 --> Hooks Class Initialized
DEBUG - 2021-12-09 16:04:09 --> UTF-8 Support Enabled
INFO - 2021-12-09 16:04:09 --> Utf8 Class Initialized
INFO - 2021-12-09 16:04:09 --> URI Class Initialized
INFO - 2021-12-09 16:04:09 --> Router Class Initialized
INFO - 2021-12-09 16:04:09 --> Output Class Initialized
INFO - 2021-12-09 16:04:09 --> Security Class Initialized
DEBUG - 2021-12-09 16:04:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 16:04:09 --> Input Class Initialized
INFO - 2021-12-09 16:04:09 --> Language Class Initialized
ERROR - 2021-12-09 16:04:09 --> 404 Page Not Found: App/images
ERROR - 2021-12-09 16:04:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 16:04:10 --> Config Class Initialized
INFO - 2021-12-09 16:04:10 --> Hooks Class Initialized
DEBUG - 2021-12-09 16:04:10 --> UTF-8 Support Enabled
INFO - 2021-12-09 16:04:10 --> Utf8 Class Initialized
INFO - 2021-12-09 16:04:10 --> URI Class Initialized
INFO - 2021-12-09 16:04:10 --> Router Class Initialized
INFO - 2021-12-09 16:04:10 --> Output Class Initialized
INFO - 2021-12-09 16:04:10 --> Security Class Initialized
DEBUG - 2021-12-09 16:04:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 16:04:10 --> Input Class Initialized
INFO - 2021-12-09 16:04:10 --> Language Class Initialized
ERROR - 2021-12-09 16:04:10 --> 404 Page Not Found: App/images
ERROR - 2021-12-09 16:04:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 16:04:10 --> Config Class Initialized
INFO - 2021-12-09 16:04:10 --> Hooks Class Initialized
DEBUG - 2021-12-09 16:04:10 --> UTF-8 Support Enabled
INFO - 2021-12-09 16:04:10 --> Utf8 Class Initialized
INFO - 2021-12-09 16:04:10 --> URI Class Initialized
INFO - 2021-12-09 16:04:10 --> Router Class Initialized
INFO - 2021-12-09 16:04:10 --> Output Class Initialized
INFO - 2021-12-09 16:04:10 --> Security Class Initialized
DEBUG - 2021-12-09 16:04:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 16:04:10 --> Input Class Initialized
INFO - 2021-12-09 16:04:10 --> Language Class Initialized
ERROR - 2021-12-09 16:04:10 --> 404 Page Not Found: Addons/theme
ERROR - 2021-12-09 16:04:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 16:04:11 --> Config Class Initialized
INFO - 2021-12-09 16:04:11 --> Hooks Class Initialized
DEBUG - 2021-12-09 16:04:11 --> UTF-8 Support Enabled
INFO - 2021-12-09 16:04:11 --> Utf8 Class Initialized
INFO - 2021-12-09 16:04:11 --> URI Class Initialized
INFO - 2021-12-09 16:04:11 --> Router Class Initialized
INFO - 2021-12-09 16:04:11 --> Output Class Initialized
INFO - 2021-12-09 16:04:11 --> Security Class Initialized
DEBUG - 2021-12-09 16:04:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 16:04:11 --> Input Class Initialized
INFO - 2021-12-09 16:04:11 --> Language Class Initialized
ERROR - 2021-12-09 16:04:11 --> 404 Page Not Found: Apps/admin
ERROR - 2021-12-09 16:04:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 16:04:11 --> Config Class Initialized
INFO - 2021-12-09 16:04:11 --> Hooks Class Initialized
DEBUG - 2021-12-09 16:04:11 --> UTF-8 Support Enabled
INFO - 2021-12-09 16:04:11 --> Utf8 Class Initialized
INFO - 2021-12-09 16:04:11 --> URI Class Initialized
INFO - 2021-12-09 16:04:11 --> Router Class Initialized
INFO - 2021-12-09 16:04:11 --> Output Class Initialized
INFO - 2021-12-09 16:04:11 --> Security Class Initialized
DEBUG - 2021-12-09 16:04:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 16:04:11 --> Input Class Initialized
INFO - 2021-12-09 16:04:11 --> Language Class Initialized
ERROR - 2021-12-09 16:04:11 --> 404 Page Not Found: Addons/theme
ERROR - 2021-12-09 16:04:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 16:04:12 --> Config Class Initialized
INFO - 2021-12-09 16:04:12 --> Hooks Class Initialized
DEBUG - 2021-12-09 16:04:12 --> UTF-8 Support Enabled
INFO - 2021-12-09 16:04:12 --> Utf8 Class Initialized
INFO - 2021-12-09 16:04:12 --> URI Class Initialized
INFO - 2021-12-09 16:04:12 --> Router Class Initialized
INFO - 2021-12-09 16:04:12 --> Output Class Initialized
INFO - 2021-12-09 16:04:12 --> Security Class Initialized
DEBUG - 2021-12-09 16:04:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 16:04:12 --> Input Class Initialized
INFO - 2021-12-09 16:04:12 --> Language Class Initialized
ERROR - 2021-12-09 16:04:12 --> 404 Page Not Found: Addons/theme
ERROR - 2021-12-09 16:04:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 16:04:13 --> Config Class Initialized
INFO - 2021-12-09 16:04:13 --> Hooks Class Initialized
DEBUG - 2021-12-09 16:04:13 --> UTF-8 Support Enabled
INFO - 2021-12-09 16:04:13 --> Utf8 Class Initialized
INFO - 2021-12-09 16:04:13 --> URI Class Initialized
INFO - 2021-12-09 16:04:13 --> Router Class Initialized
INFO - 2021-12-09 16:04:13 --> Output Class Initialized
INFO - 2021-12-09 16:04:13 --> Security Class Initialized
DEBUG - 2021-12-09 16:04:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 16:04:13 --> Input Class Initialized
INFO - 2021-12-09 16:04:13 --> Language Class Initialized
ERROR - 2021-12-09 16:04:13 --> 404 Page Not Found: Helpnew/faq
ERROR - 2021-12-09 16:04:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 16:04:13 --> Config Class Initialized
INFO - 2021-12-09 16:04:13 --> Hooks Class Initialized
DEBUG - 2021-12-09 16:04:13 --> UTF-8 Support Enabled
INFO - 2021-12-09 16:04:13 --> Utf8 Class Initialized
INFO - 2021-12-09 16:04:13 --> URI Class Initialized
INFO - 2021-12-09 16:04:13 --> Router Class Initialized
INFO - 2021-12-09 16:04:13 --> Output Class Initialized
INFO - 2021-12-09 16:04:13 --> Security Class Initialized
DEBUG - 2021-12-09 16:04:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 16:04:13 --> Input Class Initialized
INFO - 2021-12-09 16:04:13 --> Language Class Initialized
ERROR - 2021-12-09 16:04:13 --> 404 Page Not Found: Ymail/images
ERROR - 2021-12-09 16:04:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 16:04:14 --> Config Class Initialized
INFO - 2021-12-09 16:04:14 --> Hooks Class Initialized
DEBUG - 2021-12-09 16:04:14 --> UTF-8 Support Enabled
INFO - 2021-12-09 16:04:14 --> Utf8 Class Initialized
INFO - 2021-12-09 16:04:14 --> URI Class Initialized
INFO - 2021-12-09 16:04:14 --> Router Class Initialized
INFO - 2021-12-09 16:04:14 --> Output Class Initialized
INFO - 2021-12-09 16:04:14 --> Security Class Initialized
DEBUG - 2021-12-09 16:04:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 16:04:14 --> Input Class Initialized
INFO - 2021-12-09 16:04:14 --> Language Class Initialized
ERROR - 2021-12-09 16:04:14 --> 404 Page Not Found: READMEtxt/index
ERROR - 2021-12-09 16:04:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 16:04:14 --> Config Class Initialized
INFO - 2021-12-09 16:04:14 --> Hooks Class Initialized
DEBUG - 2021-12-09 16:04:14 --> UTF-8 Support Enabled
INFO - 2021-12-09 16:04:14 --> Utf8 Class Initialized
INFO - 2021-12-09 16:04:14 --> URI Class Initialized
INFO - 2021-12-09 16:04:14 --> Router Class Initialized
INFO - 2021-12-09 16:04:14 --> Output Class Initialized
INFO - 2021-12-09 16:04:14 --> Security Class Initialized
DEBUG - 2021-12-09 16:04:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 16:04:14 --> Input Class Initialized
INFO - 2021-12-09 16:04:14 --> Language Class Initialized
ERROR - 2021-12-09 16:04:14 --> 404 Page Not Found: Pub/guiedit
ERROR - 2021-12-09 16:04:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 16:04:15 --> Config Class Initialized
INFO - 2021-12-09 16:04:15 --> Hooks Class Initialized
DEBUG - 2021-12-09 16:04:15 --> UTF-8 Support Enabled
INFO - 2021-12-09 16:04:15 --> Utf8 Class Initialized
INFO - 2021-12-09 16:04:15 --> URI Class Initialized
INFO - 2021-12-09 16:04:15 --> Router Class Initialized
INFO - 2021-12-09 16:04:15 --> Output Class Initialized
INFO - 2021-12-09 16:04:15 --> Security Class Initialized
DEBUG - 2021-12-09 16:04:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 16:04:15 --> Input Class Initialized
INFO - 2021-12-09 16:04:15 --> Language Class Initialized
ERROR - 2021-12-09 16:04:15 --> 404 Page Not Found: Pub/skins
ERROR - 2021-12-09 16:04:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 16:04:16 --> Config Class Initialized
INFO - 2021-12-09 16:04:16 --> Hooks Class Initialized
DEBUG - 2021-12-09 16:04:16 --> UTF-8 Support Enabled
INFO - 2021-12-09 16:04:16 --> Utf8 Class Initialized
INFO - 2021-12-09 16:04:16 --> URI Class Initialized
INFO - 2021-12-09 16:04:16 --> Router Class Initialized
INFO - 2021-12-09 16:04:16 --> Output Class Initialized
INFO - 2021-12-09 16:04:16 --> Security Class Initialized
DEBUG - 2021-12-09 16:04:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 16:04:16 --> Input Class Initialized
INFO - 2021-12-09 16:04:16 --> Language Class Initialized
ERROR - 2021-12-09 16:04:16 --> 404 Page Not Found: Docs/DOCUMENTATION.txt
ERROR - 2021-12-09 16:04:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 16:04:16 --> Config Class Initialized
INFO - 2021-12-09 16:04:16 --> Hooks Class Initialized
DEBUG - 2021-12-09 16:04:16 --> UTF-8 Support Enabled
INFO - 2021-12-09 16:04:16 --> Utf8 Class Initialized
INFO - 2021-12-09 16:04:16 --> URI Class Initialized
INFO - 2021-12-09 16:04:16 --> Router Class Initialized
INFO - 2021-12-09 16:04:16 --> Output Class Initialized
INFO - 2021-12-09 16:04:16 --> Security Class Initialized
DEBUG - 2021-12-09 16:04:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 16:04:16 --> Input Class Initialized
INFO - 2021-12-09 16:04:16 --> Language Class Initialized
ERROR - 2021-12-09 16:04:16 --> 404 Page Not Found: Skin/frontend
ERROR - 2021-12-09 16:04:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 16:04:17 --> Config Class Initialized
INFO - 2021-12-09 16:04:17 --> Hooks Class Initialized
DEBUG - 2021-12-09 16:04:17 --> UTF-8 Support Enabled
INFO - 2021-12-09 16:04:17 --> Utf8 Class Initialized
INFO - 2021-12-09 16:04:17 --> URI Class Initialized
INFO - 2021-12-09 16:04:17 --> Router Class Initialized
INFO - 2021-12-09 16:04:17 --> Output Class Initialized
INFO - 2021-12-09 16:04:17 --> Security Class Initialized
DEBUG - 2021-12-09 16:04:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 16:04:17 --> Input Class Initialized
INFO - 2021-12-09 16:04:17 --> Language Class Initialized
ERROR - 2021-12-09 16:04:17 --> 404 Page Not Found: Advfile/ad12.js
ERROR - 2021-12-09 16:04:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 16:04:17 --> Config Class Initialized
INFO - 2021-12-09 16:04:17 --> Hooks Class Initialized
DEBUG - 2021-12-09 16:04:17 --> UTF-8 Support Enabled
INFO - 2021-12-09 16:04:17 --> Utf8 Class Initialized
INFO - 2021-12-09 16:04:17 --> URI Class Initialized
INFO - 2021-12-09 16:04:17 --> Router Class Initialized
INFO - 2021-12-09 16:04:17 --> Output Class Initialized
INFO - 2021-12-09 16:04:17 --> Security Class Initialized
DEBUG - 2021-12-09 16:04:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 16:04:17 --> Input Class Initialized
INFO - 2021-12-09 16:04:17 --> Language Class Initialized
ERROR - 2021-12-09 16:04:17 --> 404 Page Not Found: Install/index
ERROR - 2021-12-09 16:04:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 16:04:18 --> Config Class Initialized
INFO - 2021-12-09 16:04:18 --> Hooks Class Initialized
DEBUG - 2021-12-09 16:04:18 --> UTF-8 Support Enabled
INFO - 2021-12-09 16:04:18 --> Utf8 Class Initialized
INFO - 2021-12-09 16:04:18 --> URI Class Initialized
INFO - 2021-12-09 16:04:18 --> Router Class Initialized
INFO - 2021-12-09 16:04:18 --> Output Class Initialized
INFO - 2021-12-09 16:04:18 --> Security Class Initialized
DEBUG - 2021-12-09 16:04:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 16:04:18 --> Input Class Initialized
INFO - 2021-12-09 16:04:18 --> Language Class Initialized
ERROR - 2021-12-09 16:04:18 --> 404 Page Not Found: Inc/playerKinds.xml
ERROR - 2021-12-09 16:04:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 16:04:18 --> Config Class Initialized
INFO - 2021-12-09 16:04:18 --> Hooks Class Initialized
DEBUG - 2021-12-09 16:04:18 --> UTF-8 Support Enabled
INFO - 2021-12-09 16:04:18 --> Utf8 Class Initialized
INFO - 2021-12-09 16:04:18 --> URI Class Initialized
INFO - 2021-12-09 16:04:18 --> Router Class Initialized
INFO - 2021-12-09 16:04:18 --> Output Class Initialized
INFO - 2021-12-09 16:04:18 --> Security Class Initialized
DEBUG - 2021-12-09 16:04:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 16:04:18 --> Input Class Initialized
INFO - 2021-12-09 16:04:18 --> Language Class Initialized
ERROR - 2021-12-09 16:04:18 --> 404 Page Not Found: Pluginphp/index
ERROR - 2021-12-09 16:04:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 16:04:19 --> Config Class Initialized
INFO - 2021-12-09 16:04:19 --> Hooks Class Initialized
DEBUG - 2021-12-09 16:04:19 --> UTF-8 Support Enabled
INFO - 2021-12-09 16:04:19 --> Utf8 Class Initialized
INFO - 2021-12-09 16:04:19 --> URI Class Initialized
INFO - 2021-12-09 16:04:19 --> Router Class Initialized
INFO - 2021-12-09 16:04:19 --> Output Class Initialized
INFO - 2021-12-09 16:04:19 --> Security Class Initialized
DEBUG - 2021-12-09 16:04:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 16:04:19 --> Input Class Initialized
INFO - 2021-12-09 16:04:19 --> Language Class Initialized
ERROR - 2021-12-09 16:04:19 --> 404 Page Not Found: Template/1
ERROR - 2021-12-09 16:04:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 16:04:19 --> Config Class Initialized
INFO - 2021-12-09 16:04:19 --> Hooks Class Initialized
DEBUG - 2021-12-09 16:04:19 --> UTF-8 Support Enabled
INFO - 2021-12-09 16:04:19 --> Utf8 Class Initialized
INFO - 2021-12-09 16:04:19 --> URI Class Initialized
INFO - 2021-12-09 16:04:19 --> Router Class Initialized
INFO - 2021-12-09 16:04:19 --> Output Class Initialized
INFO - 2021-12-09 16:04:19 --> Security Class Initialized
DEBUG - 2021-12-09 16:04:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 16:04:19 --> Input Class Initialized
INFO - 2021-12-09 16:04:19 --> Language Class Initialized
ERROR - 2021-12-09 16:04:19 --> 404 Page Not Found: Back/scripts
ERROR - 2021-12-09 16:04:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 16:04:19 --> Config Class Initialized
INFO - 2021-12-09 16:04:19 --> Hooks Class Initialized
DEBUG - 2021-12-09 16:04:19 --> UTF-8 Support Enabled
INFO - 2021-12-09 16:04:19 --> Utf8 Class Initialized
INFO - 2021-12-09 16:04:19 --> URI Class Initialized
INFO - 2021-12-09 16:04:19 --> Router Class Initialized
INFO - 2021-12-09 16:04:19 --> Output Class Initialized
INFO - 2021-12-09 16:04:19 --> Security Class Initialized
DEBUG - 2021-12-09 16:04:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 16:04:19 --> Input Class Initialized
INFO - 2021-12-09 16:04:19 --> Language Class Initialized
ERROR - 2021-12-09 16:04:19 --> 404 Page Not Found: Wq_StranJFjs/index
ERROR - 2021-12-09 16:04:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 16:04:20 --> Config Class Initialized
INFO - 2021-12-09 16:04:20 --> Hooks Class Initialized
DEBUG - 2021-12-09 16:04:20 --> UTF-8 Support Enabled
INFO - 2021-12-09 16:04:20 --> Utf8 Class Initialized
INFO - 2021-12-09 16:04:20 --> URI Class Initialized
INFO - 2021-12-09 16:04:20 --> Router Class Initialized
INFO - 2021-12-09 16:04:20 --> Output Class Initialized
INFO - 2021-12-09 16:04:20 --> Security Class Initialized
DEBUG - 2021-12-09 16:04:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 16:04:20 --> Input Class Initialized
INFO - 2021-12-09 16:04:20 --> Language Class Initialized
ERROR - 2021-12-09 16:04:20 --> 404 Page Not Found: Admin/login.asp
ERROR - 2021-12-09 16:04:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 16:04:27 --> Config Class Initialized
INFO - 2021-12-09 16:04:27 --> Hooks Class Initialized
DEBUG - 2021-12-09 16:04:27 --> UTF-8 Support Enabled
INFO - 2021-12-09 16:04:27 --> Utf8 Class Initialized
INFO - 2021-12-09 16:04:27 --> URI Class Initialized
INFO - 2021-12-09 16:04:27 --> Router Class Initialized
INFO - 2021-12-09 16:04:27 --> Output Class Initialized
INFO - 2021-12-09 16:04:27 --> Security Class Initialized
DEBUG - 2021-12-09 16:04:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 16:04:27 --> Input Class Initialized
INFO - 2021-12-09 16:04:27 --> Language Class Initialized
ERROR - 2021-12-09 16:04:27 --> 404 Page Not Found: Admin/login.aspx
ERROR - 2021-12-09 16:04:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 16:04:28 --> Config Class Initialized
INFO - 2021-12-09 16:04:28 --> Hooks Class Initialized
DEBUG - 2021-12-09 16:04:28 --> UTF-8 Support Enabled
INFO - 2021-12-09 16:04:28 --> Utf8 Class Initialized
INFO - 2021-12-09 16:04:28 --> URI Class Initialized
INFO - 2021-12-09 16:04:28 --> Router Class Initialized
INFO - 2021-12-09 16:04:28 --> Output Class Initialized
INFO - 2021-12-09 16:04:28 --> Security Class Initialized
DEBUG - 2021-12-09 16:04:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 16:04:28 --> Input Class Initialized
INFO - 2021-12-09 16:04:28 --> Language Class Initialized
ERROR - 2021-12-09 16:04:28 --> 404 Page Not Found: Erroraspx/index
ERROR - 2021-12-09 16:04:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 16:04:28 --> Config Class Initialized
INFO - 2021-12-09 16:04:28 --> Hooks Class Initialized
DEBUG - 2021-12-09 16:04:28 --> UTF-8 Support Enabled
INFO - 2021-12-09 16:04:28 --> Utf8 Class Initialized
INFO - 2021-12-09 16:04:28 --> URI Class Initialized
INFO - 2021-12-09 16:04:28 --> Router Class Initialized
INFO - 2021-12-09 16:04:28 --> Output Class Initialized
INFO - 2021-12-09 16:04:28 --> Security Class Initialized
DEBUG - 2021-12-09 16:04:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 16:04:28 --> Input Class Initialized
INFO - 2021-12-09 16:04:28 --> Language Class Initialized
ERROR - 2021-12-09 16:04:28 --> 404 Page Not Found: DeptWebsiteActiondo/index
ERROR - 2021-12-09 16:04:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 16:04:29 --> Config Class Initialized
INFO - 2021-12-09 16:04:29 --> Hooks Class Initialized
DEBUG - 2021-12-09 16:04:29 --> UTF-8 Support Enabled
INFO - 2021-12-09 16:04:29 --> Utf8 Class Initialized
INFO - 2021-12-09 16:04:29 --> URI Class Initialized
INFO - 2021-12-09 16:04:29 --> Router Class Initialized
INFO - 2021-12-09 16:04:29 --> Output Class Initialized
INFO - 2021-12-09 16:04:29 --> Security Class Initialized
DEBUG - 2021-12-09 16:04:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 16:04:29 --> Input Class Initialized
INFO - 2021-12-09 16:04:29 --> Language Class Initialized
ERROR - 2021-12-09 16:04:29 --> 404 Page Not Found: Help/user
ERROR - 2021-12-09 16:04:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 16:04:29 --> Config Class Initialized
INFO - 2021-12-09 16:04:29 --> Hooks Class Initialized
DEBUG - 2021-12-09 16:04:29 --> UTF-8 Support Enabled
INFO - 2021-12-09 16:04:29 --> Utf8 Class Initialized
INFO - 2021-12-09 16:04:29 --> URI Class Initialized
INFO - 2021-12-09 16:04:29 --> Router Class Initialized
INFO - 2021-12-09 16:04:29 --> Output Class Initialized
INFO - 2021-12-09 16:04:29 --> Security Class Initialized
DEBUG - 2021-12-09 16:04:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 16:04:29 --> Input Class Initialized
INFO - 2021-12-09 16:04:29 --> Language Class Initialized
ERROR - 2021-12-09 16:04:29 --> 404 Page Not Found: Themes/graphics
ERROR - 2021-12-09 16:04:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 16:04:29 --> Config Class Initialized
INFO - 2021-12-09 16:04:29 --> Hooks Class Initialized
DEBUG - 2021-12-09 16:04:29 --> UTF-8 Support Enabled
INFO - 2021-12-09 16:04:29 --> Utf8 Class Initialized
INFO - 2021-12-09 16:04:29 --> URI Class Initialized
INFO - 2021-12-09 16:04:29 --> Router Class Initialized
INFO - 2021-12-09 16:04:29 --> Output Class Initialized
INFO - 2021-12-09 16:04:29 --> Security Class Initialized
DEBUG - 2021-12-09 16:04:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 16:04:29 --> Input Class Initialized
INFO - 2021-12-09 16:04:29 --> Language Class Initialized
ERROR - 2021-12-09 16:04:29 --> 404 Page Not Found: Themes/default
ERROR - 2021-12-09 16:04:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 16:04:30 --> Config Class Initialized
INFO - 2021-12-09 16:04:30 --> Hooks Class Initialized
DEBUG - 2021-12-09 16:04:30 --> UTF-8 Support Enabled
INFO - 2021-12-09 16:04:30 --> Utf8 Class Initialized
INFO - 2021-12-09 16:04:30 --> URI Class Initialized
INFO - 2021-12-09 16:04:30 --> Router Class Initialized
INFO - 2021-12-09 16:04:30 --> Output Class Initialized
INFO - 2021-12-09 16:04:30 --> Security Class Initialized
DEBUG - 2021-12-09 16:04:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 16:04:30 --> Input Class Initialized
INFO - 2021-12-09 16:04:30 --> Language Class Initialized
ERROR - 2021-12-09 16:04:30 --> 404 Page Not Found: Themes/default
ERROR - 2021-12-09 16:04:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 16:04:30 --> Config Class Initialized
INFO - 2021-12-09 16:04:30 --> Hooks Class Initialized
DEBUG - 2021-12-09 16:04:30 --> UTF-8 Support Enabled
INFO - 2021-12-09 16:04:30 --> Utf8 Class Initialized
INFO - 2021-12-09 16:04:30 --> URI Class Initialized
INFO - 2021-12-09 16:04:30 --> Router Class Initialized
INFO - 2021-12-09 16:04:30 --> Output Class Initialized
INFO - 2021-12-09 16:04:30 --> Security Class Initialized
DEBUG - 2021-12-09 16:04:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 16:04:30 --> Input Class Initialized
INFO - 2021-12-09 16:04:30 --> Language Class Initialized
ERROR - 2021-12-09 16:04:30 --> 404 Page Not Found: Whir_system/login.aspx
ERROR - 2021-12-09 16:04:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 16:04:31 --> Config Class Initialized
INFO - 2021-12-09 16:04:31 --> Hooks Class Initialized
DEBUG - 2021-12-09 16:04:31 --> UTF-8 Support Enabled
INFO - 2021-12-09 16:04:31 --> Utf8 Class Initialized
INFO - 2021-12-09 16:04:31 --> URI Class Initialized
INFO - 2021-12-09 16:04:31 --> Router Class Initialized
INFO - 2021-12-09 16:04:31 --> Output Class Initialized
INFO - 2021-12-09 16:04:31 --> Security Class Initialized
DEBUG - 2021-12-09 16:04:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 16:04:31 --> Input Class Initialized
INFO - 2021-12-09 16:04:31 --> Language Class Initialized
ERROR - 2021-12-09 16:04:31 --> 404 Page Not Found: Whir_system/module
ERROR - 2021-12-09 16:04:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 16:04:31 --> Config Class Initialized
INFO - 2021-12-09 16:04:31 --> Hooks Class Initialized
DEBUG - 2021-12-09 16:04:31 --> UTF-8 Support Enabled
INFO - 2021-12-09 16:04:31 --> Utf8 Class Initialized
INFO - 2021-12-09 16:04:31 --> URI Class Initialized
INFO - 2021-12-09 16:04:31 --> Router Class Initialized
INFO - 2021-12-09 16:04:31 --> Output Class Initialized
INFO - 2021-12-09 16:04:31 --> Security Class Initialized
DEBUG - 2021-12-09 16:04:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 16:04:31 --> Input Class Initialized
INFO - 2021-12-09 16:04:31 --> Language Class Initialized
ERROR - 2021-12-09 16:04:31 --> 404 Page Not Found: System/Login.aspx
ERROR - 2021-12-09 16:04:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 16:04:31 --> Config Class Initialized
INFO - 2021-12-09 16:04:31 --> Hooks Class Initialized
DEBUG - 2021-12-09 16:04:31 --> UTF-8 Support Enabled
INFO - 2021-12-09 16:04:31 --> Utf8 Class Initialized
INFO - 2021-12-09 16:04:31 --> URI Class Initialized
INFO - 2021-12-09 16:04:31 --> Router Class Initialized
INFO - 2021-12-09 16:04:31 --> Output Class Initialized
INFO - 2021-12-09 16:04:31 --> Security Class Initialized
DEBUG - 2021-12-09 16:04:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 16:04:31 --> Input Class Initialized
INFO - 2021-12-09 16:04:31 --> Language Class Initialized
ERROR - 2021-12-09 16:04:31 --> 404 Page Not Found: Dokuphp/index
ERROR - 2021-12-09 16:04:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 16:04:32 --> Config Class Initialized
INFO - 2021-12-09 16:04:32 --> Hooks Class Initialized
DEBUG - 2021-12-09 16:04:32 --> UTF-8 Support Enabled
INFO - 2021-12-09 16:04:32 --> Utf8 Class Initialized
INFO - 2021-12-09 16:04:32 --> URI Class Initialized
INFO - 2021-12-09 16:04:32 --> Router Class Initialized
INFO - 2021-12-09 16:04:32 --> Output Class Initialized
INFO - 2021-12-09 16:04:32 --> Security Class Initialized
DEBUG - 2021-12-09 16:04:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 16:04:32 --> Input Class Initialized
INFO - 2021-12-09 16:04:32 --> Language Class Initialized
ERROR - 2021-12-09 16:04:32 --> 404 Page Not Found: Style/default
ERROR - 2021-12-09 16:04:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 16:04:32 --> Config Class Initialized
INFO - 2021-12-09 16:04:32 --> Hooks Class Initialized
DEBUG - 2021-12-09 16:04:32 --> UTF-8 Support Enabled
INFO - 2021-12-09 16:04:32 --> Utf8 Class Initialized
INFO - 2021-12-09 16:04:32 --> URI Class Initialized
INFO - 2021-12-09 16:04:32 --> Router Class Initialized
INFO - 2021-12-09 16:04:32 --> Output Class Initialized
INFO - 2021-12-09 16:04:32 --> Security Class Initialized
DEBUG - 2021-12-09 16:04:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 16:04:32 --> Input Class Initialized
INFO - 2021-12-09 16:04:32 --> Language Class Initialized
ERROR - 2021-12-09 16:04:32 --> 404 Page Not Found: Kindeditor-minjs/index
ERROR - 2021-12-09 16:04:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 16:04:33 --> Config Class Initialized
INFO - 2021-12-09 16:04:33 --> Hooks Class Initialized
DEBUG - 2021-12-09 16:04:33 --> UTF-8 Support Enabled
INFO - 2021-12-09 16:04:33 --> Utf8 Class Initialized
INFO - 2021-12-09 16:04:33 --> URI Class Initialized
INFO - 2021-12-09 16:04:33 --> Router Class Initialized
INFO - 2021-12-09 16:04:33 --> Output Class Initialized
INFO - 2021-12-09 16:04:33 --> Security Class Initialized
DEBUG - 2021-12-09 16:04:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 16:04:33 --> Input Class Initialized
INFO - 2021-12-09 16:04:33 --> Language Class Initialized
ERROR - 2021-12-09 16:04:33 --> 404 Page Not Found: Kindeditorjs/index
ERROR - 2021-12-09 16:04:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 16:04:33 --> Config Class Initialized
INFO - 2021-12-09 16:04:33 --> Hooks Class Initialized
DEBUG - 2021-12-09 16:04:33 --> UTF-8 Support Enabled
INFO - 2021-12-09 16:04:33 --> Utf8 Class Initialized
INFO - 2021-12-09 16:04:33 --> URI Class Initialized
INFO - 2021-12-09 16:04:33 --> Router Class Initialized
INFO - 2021-12-09 16:04:33 --> Output Class Initialized
INFO - 2021-12-09 16:04:33 --> Security Class Initialized
DEBUG - 2021-12-09 16:04:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 16:04:33 --> Input Class Initialized
INFO - 2021-12-09 16:04:33 --> Language Class Initialized
ERROR - 2021-12-09 16:04:33 --> 404 Page Not Found: Lang/en.js
ERROR - 2021-12-09 16:04:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 16:04:34 --> Config Class Initialized
INFO - 2021-12-09 16:04:34 --> Hooks Class Initialized
DEBUG - 2021-12-09 16:04:34 --> UTF-8 Support Enabled
INFO - 2021-12-09 16:04:34 --> Utf8 Class Initialized
INFO - 2021-12-09 16:04:34 --> URI Class Initialized
INFO - 2021-12-09 16:04:34 --> Router Class Initialized
INFO - 2021-12-09 16:04:34 --> Output Class Initialized
INFO - 2021-12-09 16:04:34 --> Security Class Initialized
DEBUG - 2021-12-09 16:04:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 16:04:34 --> Input Class Initialized
INFO - 2021-12-09 16:04:34 --> Language Class Initialized
ERROR - 2021-12-09 16:04:34 --> 404 Page Not Found: Themes/default
ERROR - 2021-12-09 16:04:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 16:04:34 --> Config Class Initialized
INFO - 2021-12-09 16:04:34 --> Hooks Class Initialized
DEBUG - 2021-12-09 16:04:34 --> UTF-8 Support Enabled
INFO - 2021-12-09 16:04:34 --> Utf8 Class Initialized
INFO - 2021-12-09 16:04:34 --> URI Class Initialized
INFO - 2021-12-09 16:04:34 --> Router Class Initialized
INFO - 2021-12-09 16:04:34 --> Output Class Initialized
INFO - 2021-12-09 16:04:34 --> Security Class Initialized
DEBUG - 2021-12-09 16:04:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 16:04:34 --> Input Class Initialized
INFO - 2021-12-09 16:04:34 --> Language Class Initialized
ERROR - 2021-12-09 16:04:34 --> 404 Page Not Found: Examples/index.html
ERROR - 2021-12-09 16:04:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 16:04:35 --> Config Class Initialized
INFO - 2021-12-09 16:04:35 --> Hooks Class Initialized
DEBUG - 2021-12-09 16:04:35 --> UTF-8 Support Enabled
INFO - 2021-12-09 16:04:35 --> Utf8 Class Initialized
INFO - 2021-12-09 16:04:35 --> URI Class Initialized
INFO - 2021-12-09 16:04:35 --> Router Class Initialized
INFO - 2021-12-09 16:04:35 --> Output Class Initialized
INFO - 2021-12-09 16:04:35 --> Security Class Initialized
DEBUG - 2021-12-09 16:04:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 16:04:35 --> Input Class Initialized
INFO - 2021-12-09 16:04:35 --> Language Class Initialized
ERROR - 2021-12-09 16:04:35 --> 404 Page Not Found: Examples/file-manager.html
ERROR - 2021-12-09 16:04:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 16:04:35 --> Config Class Initialized
INFO - 2021-12-09 16:04:35 --> Hooks Class Initialized
DEBUG - 2021-12-09 16:04:35 --> UTF-8 Support Enabled
INFO - 2021-12-09 16:04:35 --> Utf8 Class Initialized
INFO - 2021-12-09 16:04:35 --> URI Class Initialized
INFO - 2021-12-09 16:04:35 --> Router Class Initialized
INFO - 2021-12-09 16:04:35 --> Output Class Initialized
INFO - 2021-12-09 16:04:35 --> Security Class Initialized
DEBUG - 2021-12-09 16:04:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 16:04:35 --> Input Class Initialized
INFO - 2021-12-09 16:04:35 --> Language Class Initialized
ERROR - 2021-12-09 16:04:35 --> 404 Page Not Found: Plugins/filemanager
ERROR - 2021-12-09 16:04:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 16:04:35 --> Config Class Initialized
INFO - 2021-12-09 16:04:35 --> Hooks Class Initialized
DEBUG - 2021-12-09 16:04:35 --> UTF-8 Support Enabled
INFO - 2021-12-09 16:04:35 --> Utf8 Class Initialized
INFO - 2021-12-09 16:04:35 --> URI Class Initialized
INFO - 2021-12-09 16:04:35 --> Router Class Initialized
INFO - 2021-12-09 16:04:35 --> Output Class Initialized
INFO - 2021-12-09 16:04:35 --> Security Class Initialized
DEBUG - 2021-12-09 16:04:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 16:04:35 --> Input Class Initialized
INFO - 2021-12-09 16:04:35 --> Language Class Initialized
ERROR - 2021-12-09 16:04:35 --> 404 Page Not Found: Plugins/anchor
ERROR - 2021-12-09 16:04:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 16:04:36 --> Config Class Initialized
INFO - 2021-12-09 16:04:36 --> Hooks Class Initialized
DEBUG - 2021-12-09 16:04:36 --> UTF-8 Support Enabled
INFO - 2021-12-09 16:04:36 --> Utf8 Class Initialized
INFO - 2021-12-09 16:04:36 --> URI Class Initialized
INFO - 2021-12-09 16:04:36 --> Router Class Initialized
INFO - 2021-12-09 16:04:36 --> Output Class Initialized
INFO - 2021-12-09 16:04:36 --> Security Class Initialized
DEBUG - 2021-12-09 16:04:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 16:04:36 --> Input Class Initialized
INFO - 2021-12-09 16:04:36 --> Language Class Initialized
ERROR - 2021-12-09 16:04:36 --> 404 Page Not Found: Aspnet/README.txt
ERROR - 2021-12-09 16:04:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 16:04:36 --> Config Class Initialized
INFO - 2021-12-09 16:04:36 --> Hooks Class Initialized
DEBUG - 2021-12-09 16:04:36 --> UTF-8 Support Enabled
INFO - 2021-12-09 16:04:36 --> Utf8 Class Initialized
INFO - 2021-12-09 16:04:36 --> URI Class Initialized
INFO - 2021-12-09 16:04:36 --> Router Class Initialized
INFO - 2021-12-09 16:04:36 --> Output Class Initialized
INFO - 2021-12-09 16:04:36 --> Security Class Initialized
DEBUG - 2021-12-09 16:04:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 16:04:36 --> Input Class Initialized
INFO - 2021-12-09 16:04:36 --> Language Class Initialized
ERROR - 2021-12-09 16:04:36 --> 404 Page Not Found: Examples/readonly.html
ERROR - 2021-12-09 16:04:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 16:04:37 --> Config Class Initialized
INFO - 2021-12-09 16:04:37 --> Hooks Class Initialized
DEBUG - 2021-12-09 16:04:37 --> UTF-8 Support Enabled
INFO - 2021-12-09 16:04:37 --> Utf8 Class Initialized
INFO - 2021-12-09 16:04:37 --> URI Class Initialized
INFO - 2021-12-09 16:04:37 --> Router Class Initialized
INFO - 2021-12-09 16:04:37 --> Output Class Initialized
INFO - 2021-12-09 16:04:37 --> Security Class Initialized
DEBUG - 2021-12-09 16:04:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 16:04:37 --> Input Class Initialized
INFO - 2021-12-09 16:04:37 --> Language Class Initialized
ERROR - 2021-12-09 16:04:37 --> 404 Page Not Found: Media/com_hikashop
ERROR - 2021-12-09 16:04:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 16:04:37 --> Config Class Initialized
INFO - 2021-12-09 16:04:37 --> Hooks Class Initialized
DEBUG - 2021-12-09 16:04:37 --> UTF-8 Support Enabled
INFO - 2021-12-09 16:04:37 --> Utf8 Class Initialized
INFO - 2021-12-09 16:04:37 --> URI Class Initialized
INFO - 2021-12-09 16:04:37 --> Router Class Initialized
INFO - 2021-12-09 16:04:37 --> Output Class Initialized
INFO - 2021-12-09 16:04:37 --> Security Class Initialized
DEBUG - 2021-12-09 16:04:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 16:04:37 --> Input Class Initialized
INFO - 2021-12-09 16:04:37 --> Language Class Initialized
ERROR - 2021-12-09 16:04:37 --> 404 Page Not Found: Templates/jsn_glass_pro
ERROR - 2021-12-09 16:04:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 16:04:38 --> Config Class Initialized
INFO - 2021-12-09 16:04:38 --> Hooks Class Initialized
DEBUG - 2021-12-09 16:04:38 --> UTF-8 Support Enabled
INFO - 2021-12-09 16:04:38 --> Utf8 Class Initialized
INFO - 2021-12-09 16:04:38 --> URI Class Initialized
INFO - 2021-12-09 16:04:38 --> Router Class Initialized
INFO - 2021-12-09 16:04:38 --> Output Class Initialized
INFO - 2021-12-09 16:04:38 --> Security Class Initialized
DEBUG - 2021-12-09 16:04:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 16:04:38 --> Input Class Initialized
INFO - 2021-12-09 16:04:38 --> Language Class Initialized
ERROR - 2021-12-09 16:04:38 --> 404 Page Not Found: Script/valid_formdata.js
ERROR - 2021-12-09 16:04:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 16:04:38 --> Config Class Initialized
INFO - 2021-12-09 16:04:38 --> Hooks Class Initialized
DEBUG - 2021-12-09 16:04:38 --> UTF-8 Support Enabled
INFO - 2021-12-09 16:04:38 --> Utf8 Class Initialized
INFO - 2021-12-09 16:04:38 --> URI Class Initialized
INFO - 2021-12-09 16:04:38 --> Router Class Initialized
INFO - 2021-12-09 16:04:38 --> Output Class Initialized
INFO - 2021-12-09 16:04:38 --> Security Class Initialized
DEBUG - 2021-12-09 16:04:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 16:04:38 --> Input Class Initialized
INFO - 2021-12-09 16:04:38 --> Language Class Initialized
ERROR - 2021-12-09 16:04:38 --> 404 Page Not Found: Admin/start
ERROR - 2021-12-09 16:04:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 16:04:39 --> Config Class Initialized
INFO - 2021-12-09 16:04:39 --> Hooks Class Initialized
DEBUG - 2021-12-09 16:04:39 --> UTF-8 Support Enabled
INFO - 2021-12-09 16:04:39 --> Utf8 Class Initialized
INFO - 2021-12-09 16:04:39 --> URI Class Initialized
INFO - 2021-12-09 16:04:39 --> Router Class Initialized
INFO - 2021-12-09 16:04:39 --> Output Class Initialized
INFO - 2021-12-09 16:04:39 --> Security Class Initialized
DEBUG - 2021-12-09 16:04:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 16:04:39 --> Input Class Initialized
INFO - 2021-12-09 16:04:39 --> Language Class Initialized
ERROR - 2021-12-09 16:04:39 --> 404 Page Not Found: User/Login.aspx
ERROR - 2021-12-09 16:04:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 16:04:39 --> Config Class Initialized
INFO - 2021-12-09 16:04:39 --> Hooks Class Initialized
DEBUG - 2021-12-09 16:04:39 --> UTF-8 Support Enabled
INFO - 2021-12-09 16:04:39 --> Utf8 Class Initialized
INFO - 2021-12-09 16:04:39 --> URI Class Initialized
INFO - 2021-12-09 16:04:39 --> Router Class Initialized
INFO - 2021-12-09 16:04:39 --> Output Class Initialized
INFO - 2021-12-09 16:04:39 --> Security Class Initialized
DEBUG - 2021-12-09 16:04:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 16:04:39 --> Input Class Initialized
INFO - 2021-12-09 16:04:39 --> Language Class Initialized
ERROR - 2021-12-09 16:04:39 --> 404 Page Not Found: API/DW
ERROR - 2021-12-09 16:04:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 16:04:39 --> Config Class Initialized
INFO - 2021-12-09 16:04:39 --> Hooks Class Initialized
DEBUG - 2021-12-09 16:04:39 --> UTF-8 Support Enabled
INFO - 2021-12-09 16:04:39 --> Utf8 Class Initialized
INFO - 2021-12-09 16:04:39 --> URI Class Initialized
INFO - 2021-12-09 16:04:39 --> Router Class Initialized
INFO - 2021-12-09 16:04:39 --> Output Class Initialized
INFO - 2021-12-09 16:04:39 --> Security Class Initialized
DEBUG - 2021-12-09 16:04:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 16:04:39 --> Input Class Initialized
INFO - 2021-12-09 16:04:39 --> Language Class Initialized
ERROR - 2021-12-09 16:04:39 --> 404 Page Not Found: API/DW
ERROR - 2021-12-09 16:28:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 16:28:04 --> Config Class Initialized
INFO - 2021-12-09 16:28:04 --> Hooks Class Initialized
DEBUG - 2021-12-09 16:28:04 --> UTF-8 Support Enabled
INFO - 2021-12-09 16:28:04 --> Utf8 Class Initialized
INFO - 2021-12-09 16:28:04 --> URI Class Initialized
DEBUG - 2021-12-09 16:28:04 --> No URI present. Default controller set.
INFO - 2021-12-09 16:28:04 --> Router Class Initialized
INFO - 2021-12-09 16:28:04 --> Output Class Initialized
INFO - 2021-12-09 16:28:04 --> Security Class Initialized
DEBUG - 2021-12-09 16:28:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 16:28:04 --> Input Class Initialized
INFO - 2021-12-09 16:28:04 --> Language Class Initialized
INFO - 2021-12-09 16:28:04 --> Loader Class Initialized
INFO - 2021-12-09 16:28:04 --> Helper loaded: url_helper
INFO - 2021-12-09 16:28:04 --> Helper loaded: form_helper
INFO - 2021-12-09 16:28:04 --> Helper loaded: common_helper
INFO - 2021-12-09 16:28:04 --> Database Driver Class Initialized
DEBUG - 2021-12-09 16:28:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 16:28:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 16:28:04 --> Controller Class Initialized
INFO - 2021-12-09 16:28:04 --> Form Validation Class Initialized
DEBUG - 2021-12-09 16:28:04 --> Encrypt Class Initialized
DEBUG - 2021-12-09 16:28:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-09 16:28:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-09 16:28:04 --> Email Class Initialized
INFO - 2021-12-09 16:28:04 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-09 16:28:04 --> Calendar Class Initialized
INFO - 2021-12-09 16:28:04 --> Model "Login_model" initialized
INFO - 2021-12-09 16:28:04 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-09 16:28:04 --> Final output sent to browser
DEBUG - 2021-12-09 16:28:04 --> Total execution time: 0.0318
ERROR - 2021-12-09 21:16:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 21:16:41 --> Config Class Initialized
INFO - 2021-12-09 21:16:41 --> Hooks Class Initialized
DEBUG - 2021-12-09 21:16:41 --> UTF-8 Support Enabled
INFO - 2021-12-09 21:16:41 --> Utf8 Class Initialized
INFO - 2021-12-09 21:16:41 --> URI Class Initialized
DEBUG - 2021-12-09 21:16:41 --> No URI present. Default controller set.
INFO - 2021-12-09 21:16:41 --> Router Class Initialized
INFO - 2021-12-09 21:16:41 --> Output Class Initialized
INFO - 2021-12-09 21:16:41 --> Security Class Initialized
DEBUG - 2021-12-09 21:16:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 21:16:41 --> Input Class Initialized
INFO - 2021-12-09 21:16:41 --> Language Class Initialized
INFO - 2021-12-09 21:16:41 --> Loader Class Initialized
INFO - 2021-12-09 21:16:41 --> Helper loaded: url_helper
INFO - 2021-12-09 21:16:41 --> Helper loaded: form_helper
INFO - 2021-12-09 21:16:41 --> Helper loaded: common_helper
INFO - 2021-12-09 21:16:41 --> Database Driver Class Initialized
DEBUG - 2021-12-09 21:16:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 21:16:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 21:16:41 --> Controller Class Initialized
INFO - 2021-12-09 21:16:41 --> Form Validation Class Initialized
DEBUG - 2021-12-09 21:16:41 --> Encrypt Class Initialized
DEBUG - 2021-12-09 21:16:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-09 21:16:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-09 21:16:41 --> Email Class Initialized
INFO - 2021-12-09 21:16:41 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-09 21:16:41 --> Calendar Class Initialized
INFO - 2021-12-09 21:16:41 --> Model "Login_model" initialized
INFO - 2021-12-09 21:16:41 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-09 21:16:41 --> Final output sent to browser
DEBUG - 2021-12-09 21:16:41 --> Total execution time: 0.0266
ERROR - 2021-12-09 23:18:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-09 23:18:22 --> Config Class Initialized
INFO - 2021-12-09 23:18:22 --> Hooks Class Initialized
DEBUG - 2021-12-09 23:18:22 --> UTF-8 Support Enabled
INFO - 2021-12-09 23:18:22 --> Utf8 Class Initialized
INFO - 2021-12-09 23:18:22 --> URI Class Initialized
DEBUG - 2021-12-09 23:18:22 --> No URI present. Default controller set.
INFO - 2021-12-09 23:18:22 --> Router Class Initialized
INFO - 2021-12-09 23:18:22 --> Output Class Initialized
INFO - 2021-12-09 23:18:22 --> Security Class Initialized
DEBUG - 2021-12-09 23:18:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 23:18:22 --> Input Class Initialized
INFO - 2021-12-09 23:18:22 --> Language Class Initialized
INFO - 2021-12-09 23:18:22 --> Loader Class Initialized
INFO - 2021-12-09 23:18:22 --> Helper loaded: url_helper
INFO - 2021-12-09 23:18:22 --> Helper loaded: form_helper
INFO - 2021-12-09 23:18:22 --> Helper loaded: common_helper
INFO - 2021-12-09 23:18:22 --> Database Driver Class Initialized
DEBUG - 2021-12-09 23:18:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 23:18:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 23:18:22 --> Controller Class Initialized
INFO - 2021-12-09 23:18:22 --> Form Validation Class Initialized
DEBUG - 2021-12-09 23:18:22 --> Encrypt Class Initialized
DEBUG - 2021-12-09 23:18:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-09 23:18:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-09 23:18:22 --> Email Class Initialized
INFO - 2021-12-09 23:18:22 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-09 23:18:22 --> Calendar Class Initialized
INFO - 2021-12-09 23:18:22 --> Model "Login_model" initialized
INFO - 2021-12-09 23:18:22 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-09 23:18:22 --> Final output sent to browser
DEBUG - 2021-12-09 23:18:22 --> Total execution time: 0.0515
