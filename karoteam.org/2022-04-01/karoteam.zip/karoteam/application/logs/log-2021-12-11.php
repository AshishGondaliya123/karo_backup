<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-12-11 03:45:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-11 03:45:12 --> Config Class Initialized
INFO - 2021-12-11 03:45:12 --> Hooks Class Initialized
DEBUG - 2021-12-11 03:45:12 --> UTF-8 Support Enabled
INFO - 2021-12-11 03:45:12 --> Utf8 Class Initialized
INFO - 2021-12-11 03:45:12 --> URI Class Initialized
DEBUG - 2021-12-11 03:45:12 --> No URI present. Default controller set.
INFO - 2021-12-11 03:45:12 --> Router Class Initialized
INFO - 2021-12-11 03:45:12 --> Output Class Initialized
INFO - 2021-12-11 03:45:12 --> Security Class Initialized
DEBUG - 2021-12-11 03:45:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 03:45:12 --> Input Class Initialized
INFO - 2021-12-11 03:45:12 --> Language Class Initialized
INFO - 2021-12-11 03:45:12 --> Loader Class Initialized
INFO - 2021-12-11 03:45:12 --> Helper loaded: url_helper
INFO - 2021-12-11 03:45:12 --> Helper loaded: form_helper
INFO - 2021-12-11 03:45:12 --> Helper loaded: common_helper
INFO - 2021-12-11 03:45:12 --> Database Driver Class Initialized
DEBUG - 2021-12-11 03:45:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 03:45:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 03:45:12 --> Controller Class Initialized
INFO - 2021-12-11 03:45:12 --> Form Validation Class Initialized
DEBUG - 2021-12-11 03:45:12 --> Encrypt Class Initialized
DEBUG - 2021-12-11 03:45:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-11 03:45:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-11 03:45:12 --> Email Class Initialized
INFO - 2021-12-11 03:45:12 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-11 03:45:12 --> Calendar Class Initialized
INFO - 2021-12-11 03:45:12 --> Model "Login_model" initialized
INFO - 2021-12-11 03:45:12 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-11 03:45:12 --> Final output sent to browser
DEBUG - 2021-12-11 03:45:12 --> Total execution time: 0.0271
ERROR - 2021-12-11 04:01:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-11 04:01:42 --> Config Class Initialized
INFO - 2021-12-11 04:01:42 --> Hooks Class Initialized
DEBUG - 2021-12-11 04:01:42 --> UTF-8 Support Enabled
INFO - 2021-12-11 04:01:42 --> Utf8 Class Initialized
INFO - 2021-12-11 04:01:42 --> URI Class Initialized
DEBUG - 2021-12-11 04:01:42 --> No URI present. Default controller set.
INFO - 2021-12-11 04:01:42 --> Router Class Initialized
INFO - 2021-12-11 04:01:42 --> Output Class Initialized
INFO - 2021-12-11 04:01:42 --> Security Class Initialized
DEBUG - 2021-12-11 04:01:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 04:01:42 --> Input Class Initialized
INFO - 2021-12-11 04:01:42 --> Language Class Initialized
INFO - 2021-12-11 04:01:42 --> Loader Class Initialized
INFO - 2021-12-11 04:01:42 --> Helper loaded: url_helper
INFO - 2021-12-11 04:01:42 --> Helper loaded: form_helper
INFO - 2021-12-11 04:01:42 --> Helper loaded: common_helper
INFO - 2021-12-11 04:01:42 --> Database Driver Class Initialized
DEBUG - 2021-12-11 04:01:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 04:01:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 04:01:42 --> Controller Class Initialized
INFO - 2021-12-11 04:01:42 --> Form Validation Class Initialized
DEBUG - 2021-12-11 04:01:42 --> Encrypt Class Initialized
DEBUG - 2021-12-11 04:01:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-11 04:01:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-11 04:01:42 --> Email Class Initialized
INFO - 2021-12-11 04:01:42 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-11 04:01:42 --> Calendar Class Initialized
INFO - 2021-12-11 04:01:42 --> Model "Login_model" initialized
INFO - 2021-12-11 04:01:42 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-11 04:01:42 --> Final output sent to browser
DEBUG - 2021-12-11 04:01:42 --> Total execution time: 0.0240
ERROR - 2021-12-11 05:50:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-11 05:50:06 --> Config Class Initialized
INFO - 2021-12-11 05:50:06 --> Hooks Class Initialized
DEBUG - 2021-12-11 05:50:06 --> UTF-8 Support Enabled
INFO - 2021-12-11 05:50:06 --> Utf8 Class Initialized
INFO - 2021-12-11 05:50:06 --> URI Class Initialized
DEBUG - 2021-12-11 05:50:06 --> No URI present. Default controller set.
INFO - 2021-12-11 05:50:06 --> Router Class Initialized
INFO - 2021-12-11 05:50:06 --> Output Class Initialized
INFO - 2021-12-11 05:50:06 --> Security Class Initialized
DEBUG - 2021-12-11 05:50:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 05:50:06 --> Input Class Initialized
INFO - 2021-12-11 05:50:06 --> Language Class Initialized
INFO - 2021-12-11 05:50:06 --> Loader Class Initialized
INFO - 2021-12-11 05:50:06 --> Helper loaded: url_helper
INFO - 2021-12-11 05:50:06 --> Helper loaded: form_helper
INFO - 2021-12-11 05:50:06 --> Helper loaded: common_helper
INFO - 2021-12-11 05:50:06 --> Database Driver Class Initialized
DEBUG - 2021-12-11 05:50:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 05:50:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 05:50:06 --> Controller Class Initialized
INFO - 2021-12-11 05:50:06 --> Form Validation Class Initialized
DEBUG - 2021-12-11 05:50:06 --> Encrypt Class Initialized
DEBUG - 2021-12-11 05:50:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-11 05:50:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-11 05:50:06 --> Email Class Initialized
INFO - 2021-12-11 05:50:06 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-11 05:50:06 --> Calendar Class Initialized
INFO - 2021-12-11 05:50:06 --> Model "Login_model" initialized
INFO - 2021-12-11 05:50:06 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-11 05:50:06 --> Final output sent to browser
DEBUG - 2021-12-11 05:50:06 --> Total execution time: 0.0359
ERROR - 2021-12-11 07:42:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-11 07:42:27 --> Config Class Initialized
INFO - 2021-12-11 07:42:27 --> Hooks Class Initialized
DEBUG - 2021-12-11 07:42:27 --> UTF-8 Support Enabled
INFO - 2021-12-11 07:42:27 --> Utf8 Class Initialized
INFO - 2021-12-11 07:42:27 --> URI Class Initialized
DEBUG - 2021-12-11 07:42:27 --> No URI present. Default controller set.
INFO - 2021-12-11 07:42:27 --> Router Class Initialized
INFO - 2021-12-11 07:42:27 --> Output Class Initialized
INFO - 2021-12-11 07:42:27 --> Security Class Initialized
DEBUG - 2021-12-11 07:42:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 07:42:27 --> Input Class Initialized
INFO - 2021-12-11 07:42:27 --> Language Class Initialized
INFO - 2021-12-11 07:42:27 --> Loader Class Initialized
INFO - 2021-12-11 07:42:27 --> Helper loaded: url_helper
INFO - 2021-12-11 07:42:27 --> Helper loaded: form_helper
INFO - 2021-12-11 07:42:27 --> Helper loaded: common_helper
INFO - 2021-12-11 07:42:27 --> Database Driver Class Initialized
DEBUG - 2021-12-11 07:42:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 07:42:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 07:42:27 --> Controller Class Initialized
INFO - 2021-12-11 07:42:27 --> Form Validation Class Initialized
DEBUG - 2021-12-11 07:42:27 --> Encrypt Class Initialized
DEBUG - 2021-12-11 07:42:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-11 07:42:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-11 07:42:27 --> Email Class Initialized
INFO - 2021-12-11 07:42:27 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-11 07:42:27 --> Calendar Class Initialized
INFO - 2021-12-11 07:42:27 --> Model "Login_model" initialized
INFO - 2021-12-11 07:42:27 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-11 07:42:27 --> Final output sent to browser
DEBUG - 2021-12-11 07:42:27 --> Total execution time: 0.0257
ERROR - 2021-12-11 08:04:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-11 08:04:28 --> Config Class Initialized
INFO - 2021-12-11 08:04:28 --> Hooks Class Initialized
DEBUG - 2021-12-11 08:04:28 --> UTF-8 Support Enabled
INFO - 2021-12-11 08:04:28 --> Utf8 Class Initialized
INFO - 2021-12-11 08:04:28 --> URI Class Initialized
DEBUG - 2021-12-11 08:04:28 --> No URI present. Default controller set.
INFO - 2021-12-11 08:04:28 --> Router Class Initialized
INFO - 2021-12-11 08:04:28 --> Output Class Initialized
INFO - 2021-12-11 08:04:28 --> Security Class Initialized
DEBUG - 2021-12-11 08:04:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 08:04:28 --> Input Class Initialized
INFO - 2021-12-11 08:04:28 --> Language Class Initialized
INFO - 2021-12-11 08:04:28 --> Loader Class Initialized
INFO - 2021-12-11 08:04:28 --> Helper loaded: url_helper
INFO - 2021-12-11 08:04:28 --> Helper loaded: form_helper
INFO - 2021-12-11 08:04:28 --> Helper loaded: common_helper
INFO - 2021-12-11 08:04:28 --> Database Driver Class Initialized
DEBUG - 2021-12-11 08:04:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 08:04:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 08:04:28 --> Controller Class Initialized
INFO - 2021-12-11 08:04:28 --> Form Validation Class Initialized
DEBUG - 2021-12-11 08:04:28 --> Encrypt Class Initialized
DEBUG - 2021-12-11 08:04:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-11 08:04:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-11 08:04:28 --> Email Class Initialized
INFO - 2021-12-11 08:04:28 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-11 08:04:28 --> Calendar Class Initialized
INFO - 2021-12-11 08:04:28 --> Model "Login_model" initialized
INFO - 2021-12-11 08:04:28 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-11 08:04:28 --> Final output sent to browser
DEBUG - 2021-12-11 08:04:28 --> Total execution time: 0.0344
ERROR - 2021-12-11 08:52:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-11 08:52:15 --> Config Class Initialized
INFO - 2021-12-11 08:52:15 --> Hooks Class Initialized
DEBUG - 2021-12-11 08:52:15 --> UTF-8 Support Enabled
INFO - 2021-12-11 08:52:15 --> Utf8 Class Initialized
INFO - 2021-12-11 08:52:15 --> URI Class Initialized
DEBUG - 2021-12-11 08:52:15 --> No URI present. Default controller set.
INFO - 2021-12-11 08:52:15 --> Router Class Initialized
INFO - 2021-12-11 08:52:15 --> Output Class Initialized
INFO - 2021-12-11 08:52:15 --> Security Class Initialized
DEBUG - 2021-12-11 08:52:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 08:52:15 --> Input Class Initialized
INFO - 2021-12-11 08:52:15 --> Language Class Initialized
INFO - 2021-12-11 08:52:15 --> Loader Class Initialized
INFO - 2021-12-11 08:52:15 --> Helper loaded: url_helper
INFO - 2021-12-11 08:52:15 --> Helper loaded: form_helper
INFO - 2021-12-11 08:52:15 --> Helper loaded: common_helper
INFO - 2021-12-11 08:52:15 --> Database Driver Class Initialized
DEBUG - 2021-12-11 08:52:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 08:52:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 08:52:15 --> Controller Class Initialized
INFO - 2021-12-11 08:52:15 --> Form Validation Class Initialized
DEBUG - 2021-12-11 08:52:15 --> Encrypt Class Initialized
DEBUG - 2021-12-11 08:52:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-11 08:52:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-11 08:52:15 --> Email Class Initialized
INFO - 2021-12-11 08:52:15 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-11 08:52:15 --> Calendar Class Initialized
INFO - 2021-12-11 08:52:15 --> Model "Login_model" initialized
INFO - 2021-12-11 08:52:15 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-11 08:52:15 --> Final output sent to browser
DEBUG - 2021-12-11 08:52:15 --> Total execution time: 0.0308
ERROR - 2021-12-11 10:29:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-11 10:29:51 --> Config Class Initialized
INFO - 2021-12-11 10:29:51 --> Hooks Class Initialized
DEBUG - 2021-12-11 10:29:51 --> UTF-8 Support Enabled
INFO - 2021-12-11 10:29:51 --> Utf8 Class Initialized
INFO - 2021-12-11 10:29:51 --> URI Class Initialized
DEBUG - 2021-12-11 10:29:51 --> No URI present. Default controller set.
INFO - 2021-12-11 10:29:51 --> Router Class Initialized
INFO - 2021-12-11 10:29:51 --> Output Class Initialized
INFO - 2021-12-11 10:29:51 --> Security Class Initialized
DEBUG - 2021-12-11 10:29:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 10:29:51 --> Input Class Initialized
INFO - 2021-12-11 10:29:51 --> Language Class Initialized
INFO - 2021-12-11 10:29:51 --> Loader Class Initialized
INFO - 2021-12-11 10:29:51 --> Helper loaded: url_helper
INFO - 2021-12-11 10:29:51 --> Helper loaded: form_helper
INFO - 2021-12-11 10:29:51 --> Helper loaded: common_helper
INFO - 2021-12-11 10:29:51 --> Database Driver Class Initialized
DEBUG - 2021-12-11 10:29:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 10:29:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 10:29:51 --> Controller Class Initialized
INFO - 2021-12-11 10:29:51 --> Form Validation Class Initialized
DEBUG - 2021-12-11 10:29:51 --> Encrypt Class Initialized
DEBUG - 2021-12-11 10:29:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-11 10:29:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-11 10:29:51 --> Email Class Initialized
INFO - 2021-12-11 10:29:51 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-11 10:29:51 --> Calendar Class Initialized
INFO - 2021-12-11 10:29:51 --> Model "Login_model" initialized
INFO - 2021-12-11 10:29:51 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-11 10:29:51 --> Final output sent to browser
DEBUG - 2021-12-11 10:29:51 --> Total execution time: 0.0471
ERROR - 2021-12-11 10:29:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-11 10:29:52 --> Config Class Initialized
INFO - 2021-12-11 10:29:52 --> Hooks Class Initialized
DEBUG - 2021-12-11 10:29:52 --> UTF-8 Support Enabled
INFO - 2021-12-11 10:29:52 --> Utf8 Class Initialized
INFO - 2021-12-11 10:29:52 --> URI Class Initialized
DEBUG - 2021-12-11 10:29:52 --> No URI present. Default controller set.
INFO - 2021-12-11 10:29:52 --> Router Class Initialized
INFO - 2021-12-11 10:29:52 --> Output Class Initialized
INFO - 2021-12-11 10:29:52 --> Security Class Initialized
DEBUG - 2021-12-11 10:29:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 10:29:52 --> Input Class Initialized
INFO - 2021-12-11 10:29:52 --> Language Class Initialized
INFO - 2021-12-11 10:29:52 --> Loader Class Initialized
INFO - 2021-12-11 10:29:52 --> Helper loaded: url_helper
INFO - 2021-12-11 10:29:52 --> Helper loaded: form_helper
INFO - 2021-12-11 10:29:52 --> Helper loaded: common_helper
INFO - 2021-12-11 10:29:52 --> Database Driver Class Initialized
DEBUG - 2021-12-11 10:29:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 10:29:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 10:29:52 --> Controller Class Initialized
INFO - 2021-12-11 10:29:52 --> Form Validation Class Initialized
DEBUG - 2021-12-11 10:29:52 --> Encrypt Class Initialized
DEBUG - 2021-12-11 10:29:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-11 10:29:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-11 10:29:52 --> Email Class Initialized
INFO - 2021-12-11 10:29:52 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-11 10:29:52 --> Calendar Class Initialized
INFO - 2021-12-11 10:29:52 --> Model "Login_model" initialized
INFO - 2021-12-11 10:29:52 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-11 10:29:52 --> Final output sent to browser
DEBUG - 2021-12-11 10:29:52 --> Total execution time: 0.0324
ERROR - 2021-12-11 10:31:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-11 10:31:09 --> Config Class Initialized
INFO - 2021-12-11 10:31:09 --> Hooks Class Initialized
DEBUG - 2021-12-11 10:31:09 --> UTF-8 Support Enabled
INFO - 2021-12-11 10:31:09 --> Utf8 Class Initialized
INFO - 2021-12-11 10:31:09 --> URI Class Initialized
DEBUG - 2021-12-11 10:31:09 --> No URI present. Default controller set.
INFO - 2021-12-11 10:31:09 --> Router Class Initialized
INFO - 2021-12-11 10:31:09 --> Output Class Initialized
INFO - 2021-12-11 10:31:09 --> Security Class Initialized
DEBUG - 2021-12-11 10:31:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 10:31:09 --> Input Class Initialized
INFO - 2021-12-11 10:31:09 --> Language Class Initialized
INFO - 2021-12-11 10:31:09 --> Loader Class Initialized
INFO - 2021-12-11 10:31:09 --> Helper loaded: url_helper
INFO - 2021-12-11 10:31:09 --> Helper loaded: form_helper
INFO - 2021-12-11 10:31:09 --> Helper loaded: common_helper
INFO - 2021-12-11 10:31:09 --> Database Driver Class Initialized
DEBUG - 2021-12-11 10:31:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 10:31:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 10:31:09 --> Controller Class Initialized
INFO - 2021-12-11 10:31:09 --> Form Validation Class Initialized
DEBUG - 2021-12-11 10:31:09 --> Encrypt Class Initialized
DEBUG - 2021-12-11 10:31:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-11 10:31:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-11 10:31:09 --> Email Class Initialized
INFO - 2021-12-11 10:31:09 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-11 10:31:09 --> Calendar Class Initialized
INFO - 2021-12-11 10:31:09 --> Model "Login_model" initialized
INFO - 2021-12-11 10:31:09 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-11 10:31:09 --> Final output sent to browser
DEBUG - 2021-12-11 10:31:09 --> Total execution time: 0.0351
ERROR - 2021-12-11 14:21:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-11 14:21:42 --> Config Class Initialized
INFO - 2021-12-11 14:21:42 --> Hooks Class Initialized
DEBUG - 2021-12-11 14:21:42 --> UTF-8 Support Enabled
INFO - 2021-12-11 14:21:42 --> Utf8 Class Initialized
INFO - 2021-12-11 14:21:42 --> URI Class Initialized
DEBUG - 2021-12-11 14:21:42 --> No URI present. Default controller set.
INFO - 2021-12-11 14:21:42 --> Router Class Initialized
INFO - 2021-12-11 14:21:42 --> Output Class Initialized
INFO - 2021-12-11 14:21:42 --> Security Class Initialized
DEBUG - 2021-12-11 14:21:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 14:21:42 --> Input Class Initialized
INFO - 2021-12-11 14:21:42 --> Language Class Initialized
INFO - 2021-12-11 14:21:42 --> Loader Class Initialized
INFO - 2021-12-11 14:21:42 --> Helper loaded: url_helper
INFO - 2021-12-11 14:21:42 --> Helper loaded: form_helper
INFO - 2021-12-11 14:21:42 --> Helper loaded: common_helper
INFO - 2021-12-11 14:21:42 --> Database Driver Class Initialized
DEBUG - 2021-12-11 14:21:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 14:21:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 14:21:42 --> Controller Class Initialized
INFO - 2021-12-11 14:21:42 --> Form Validation Class Initialized
DEBUG - 2021-12-11 14:21:42 --> Encrypt Class Initialized
DEBUG - 2021-12-11 14:21:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-11 14:21:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-11 14:21:42 --> Email Class Initialized
INFO - 2021-12-11 14:21:42 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-11 14:21:42 --> Calendar Class Initialized
INFO - 2021-12-11 14:21:42 --> Model "Login_model" initialized
INFO - 2021-12-11 14:21:42 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-11 14:21:42 --> Final output sent to browser
DEBUG - 2021-12-11 14:21:42 --> Total execution time: 0.0250
ERROR - 2021-12-11 14:21:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-11 14:21:43 --> Config Class Initialized
INFO - 2021-12-11 14:21:43 --> Hooks Class Initialized
DEBUG - 2021-12-11 14:21:43 --> UTF-8 Support Enabled
INFO - 2021-12-11 14:21:43 --> Utf8 Class Initialized
INFO - 2021-12-11 14:21:43 --> URI Class Initialized
INFO - 2021-12-11 14:21:43 --> Router Class Initialized
INFO - 2021-12-11 14:21:43 --> Output Class Initialized
INFO - 2021-12-11 14:21:43 --> Security Class Initialized
DEBUG - 2021-12-11 14:21:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 14:21:43 --> Input Class Initialized
INFO - 2021-12-11 14:21:43 --> Language Class Initialized
ERROR - 2021-12-11 14:21:43 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2021-12-11 14:22:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-11 14:22:11 --> Config Class Initialized
INFO - 2021-12-11 14:22:11 --> Hooks Class Initialized
DEBUG - 2021-12-11 14:22:11 --> UTF-8 Support Enabled
INFO - 2021-12-11 14:22:11 --> Utf8 Class Initialized
INFO - 2021-12-11 14:22:11 --> URI Class Initialized
DEBUG - 2021-12-11 14:22:11 --> No URI present. Default controller set.
INFO - 2021-12-11 14:22:11 --> Router Class Initialized
INFO - 2021-12-11 14:22:11 --> Output Class Initialized
INFO - 2021-12-11 14:22:11 --> Security Class Initialized
DEBUG - 2021-12-11 14:22:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 14:22:11 --> Input Class Initialized
INFO - 2021-12-11 14:22:11 --> Language Class Initialized
INFO - 2021-12-11 14:22:11 --> Loader Class Initialized
INFO - 2021-12-11 14:22:11 --> Helper loaded: url_helper
INFO - 2021-12-11 14:22:11 --> Helper loaded: form_helper
INFO - 2021-12-11 14:22:11 --> Helper loaded: common_helper
INFO - 2021-12-11 14:22:11 --> Database Driver Class Initialized
DEBUG - 2021-12-11 14:22:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 14:22:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 14:22:11 --> Controller Class Initialized
INFO - 2021-12-11 14:22:11 --> Form Validation Class Initialized
DEBUG - 2021-12-11 14:22:11 --> Encrypt Class Initialized
DEBUG - 2021-12-11 14:22:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-11 14:22:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-11 14:22:11 --> Email Class Initialized
INFO - 2021-12-11 14:22:11 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-11 14:22:11 --> Calendar Class Initialized
INFO - 2021-12-11 14:22:11 --> Model "Login_model" initialized
INFO - 2021-12-11 14:22:11 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-11 14:22:11 --> Final output sent to browser
DEBUG - 2021-12-11 14:22:11 --> Total execution time: 0.0226
ERROR - 2021-12-11 14:22:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-11 14:22:12 --> Config Class Initialized
INFO - 2021-12-11 14:22:12 --> Hooks Class Initialized
DEBUG - 2021-12-11 14:22:12 --> UTF-8 Support Enabled
INFO - 2021-12-11 14:22:12 --> Utf8 Class Initialized
INFO - 2021-12-11 14:22:12 --> URI Class Initialized
INFO - 2021-12-11 14:22:12 --> Router Class Initialized
INFO - 2021-12-11 14:22:12 --> Output Class Initialized
INFO - 2021-12-11 14:22:12 --> Security Class Initialized
DEBUG - 2021-12-11 14:22:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 14:22:12 --> Input Class Initialized
INFO - 2021-12-11 14:22:12 --> Language Class Initialized
INFO - 2021-12-11 14:22:12 --> Loader Class Initialized
INFO - 2021-12-11 14:22:12 --> Helper loaded: url_helper
INFO - 2021-12-11 14:22:12 --> Helper loaded: form_helper
INFO - 2021-12-11 14:22:12 --> Helper loaded: common_helper
INFO - 2021-12-11 14:22:12 --> Database Driver Class Initialized
DEBUG - 2021-12-11 14:22:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 14:22:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 14:22:12 --> Controller Class Initialized
INFO - 2021-12-11 14:22:12 --> Form Validation Class Initialized
DEBUG - 2021-12-11 14:22:12 --> Encrypt Class Initialized
DEBUG - 2021-12-11 14:22:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-11 14:22:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-11 14:22:12 --> Email Class Initialized
INFO - 2021-12-11 14:22:12 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-11 14:22:12 --> Calendar Class Initialized
INFO - 2021-12-11 14:22:12 --> Model "Login_model" initialized
ERROR - 2021-12-11 14:22:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-11 14:22:12 --> Config Class Initialized
INFO - 2021-12-11 14:22:12 --> Hooks Class Initialized
DEBUG - 2021-12-11 14:22:12 --> UTF-8 Support Enabled
INFO - 2021-12-11 14:22:12 --> Utf8 Class Initialized
INFO - 2021-12-11 14:22:13 --> URI Class Initialized
INFO - 2021-12-11 14:22:13 --> Router Class Initialized
INFO - 2021-12-11 14:22:13 --> Output Class Initialized
INFO - 2021-12-11 14:22:13 --> Security Class Initialized
DEBUG - 2021-12-11 14:22:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 14:22:13 --> Input Class Initialized
INFO - 2021-12-11 14:22:13 --> Language Class Initialized
INFO - 2021-12-11 14:22:13 --> Loader Class Initialized
INFO - 2021-12-11 14:22:13 --> Helper loaded: url_helper
INFO - 2021-12-11 14:22:13 --> Helper loaded: form_helper
INFO - 2021-12-11 14:22:13 --> Helper loaded: common_helper
INFO - 2021-12-11 14:22:13 --> Database Driver Class Initialized
DEBUG - 2021-12-11 14:22:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 14:22:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 14:22:13 --> Controller Class Initialized
INFO - 2021-12-11 14:22:13 --> Form Validation Class Initialized
DEBUG - 2021-12-11 14:22:13 --> Encrypt Class Initialized
DEBUG - 2021-12-11 14:22:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-11 14:22:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-11 14:22:13 --> Email Class Initialized
INFO - 2021-12-11 14:22:13 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-11 14:22:13 --> Calendar Class Initialized
INFO - 2021-12-11 14:22:13 --> Model "Login_model" initialized
ERROR - 2021-12-11 14:22:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-11 14:22:13 --> Config Class Initialized
INFO - 2021-12-11 14:22:13 --> Hooks Class Initialized
DEBUG - 2021-12-11 14:22:13 --> UTF-8 Support Enabled
INFO - 2021-12-11 14:22:13 --> Utf8 Class Initialized
INFO - 2021-12-11 14:22:13 --> URI Class Initialized
INFO - 2021-12-11 14:22:13 --> Router Class Initialized
INFO - 2021-12-11 14:22:13 --> Output Class Initialized
INFO - 2021-12-11 14:22:13 --> Security Class Initialized
DEBUG - 2021-12-11 14:22:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 14:22:13 --> Input Class Initialized
INFO - 2021-12-11 14:22:13 --> Language Class Initialized
INFO - 2021-12-11 14:22:13 --> Loader Class Initialized
INFO - 2021-12-11 14:22:13 --> Helper loaded: url_helper
INFO - 2021-12-11 14:22:13 --> Helper loaded: form_helper
INFO - 2021-12-11 14:22:13 --> Helper loaded: common_helper
INFO - 2021-12-11 14:22:13 --> Database Driver Class Initialized
DEBUG - 2021-12-11 14:22:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 14:22:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 14:22:13 --> Controller Class Initialized
INFO - 2021-12-11 14:22:13 --> Form Validation Class Initialized
DEBUG - 2021-12-11 14:22:13 --> Encrypt Class Initialized
DEBUG - 2021-12-11 14:22:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-11 14:22:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-11 14:22:13 --> Email Class Initialized
INFO - 2021-12-11 14:22:13 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-11 14:22:13 --> Calendar Class Initialized
INFO - 2021-12-11 14:22:13 --> Model "Login_model" initialized
INFO - 2021-12-11 14:22:13 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-11 14:22:13 --> Final output sent to browser
DEBUG - 2021-12-11 14:22:13 --> Total execution time: 0.0244
ERROR - 2021-12-11 14:22:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-11 14:22:40 --> Config Class Initialized
INFO - 2021-12-11 14:22:40 --> Hooks Class Initialized
DEBUG - 2021-12-11 14:22:40 --> UTF-8 Support Enabled
INFO - 2021-12-11 14:22:40 --> Utf8 Class Initialized
INFO - 2021-12-11 14:22:40 --> URI Class Initialized
DEBUG - 2021-12-11 14:22:40 --> No URI present. Default controller set.
INFO - 2021-12-11 14:22:40 --> Router Class Initialized
INFO - 2021-12-11 14:22:40 --> Output Class Initialized
INFO - 2021-12-11 14:22:40 --> Security Class Initialized
DEBUG - 2021-12-11 14:22:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 14:22:40 --> Input Class Initialized
INFO - 2021-12-11 14:22:40 --> Language Class Initialized
INFO - 2021-12-11 14:22:40 --> Loader Class Initialized
INFO - 2021-12-11 14:22:40 --> Helper loaded: url_helper
INFO - 2021-12-11 14:22:40 --> Helper loaded: form_helper
INFO - 2021-12-11 14:22:40 --> Helper loaded: common_helper
INFO - 2021-12-11 14:22:40 --> Database Driver Class Initialized
DEBUG - 2021-12-11 14:22:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 14:22:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 14:22:40 --> Controller Class Initialized
INFO - 2021-12-11 14:22:40 --> Form Validation Class Initialized
DEBUG - 2021-12-11 14:22:40 --> Encrypt Class Initialized
DEBUG - 2021-12-11 14:22:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-11 14:22:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-11 14:22:40 --> Email Class Initialized
INFO - 2021-12-11 14:22:40 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-11 14:22:40 --> Calendar Class Initialized
INFO - 2021-12-11 14:22:40 --> Model "Login_model" initialized
INFO - 2021-12-11 14:22:40 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-11 14:22:40 --> Final output sent to browser
DEBUG - 2021-12-11 14:22:40 --> Total execution time: 0.0216
ERROR - 2021-12-11 15:50:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-11 15:50:01 --> Config Class Initialized
INFO - 2021-12-11 15:50:01 --> Hooks Class Initialized
DEBUG - 2021-12-11 15:50:01 --> UTF-8 Support Enabled
INFO - 2021-12-11 15:50:01 --> Utf8 Class Initialized
INFO - 2021-12-11 15:50:01 --> URI Class Initialized
DEBUG - 2021-12-11 15:50:01 --> No URI present. Default controller set.
INFO - 2021-12-11 15:50:01 --> Router Class Initialized
INFO - 2021-12-11 15:50:01 --> Output Class Initialized
INFO - 2021-12-11 15:50:01 --> Security Class Initialized
DEBUG - 2021-12-11 15:50:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 15:50:01 --> Input Class Initialized
INFO - 2021-12-11 15:50:01 --> Language Class Initialized
INFO - 2021-12-11 15:50:01 --> Loader Class Initialized
INFO - 2021-12-11 15:50:01 --> Helper loaded: url_helper
INFO - 2021-12-11 15:50:01 --> Helper loaded: form_helper
INFO - 2021-12-11 15:50:01 --> Helper loaded: common_helper
INFO - 2021-12-11 15:50:01 --> Database Driver Class Initialized
DEBUG - 2021-12-11 15:50:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 15:50:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 15:50:01 --> Controller Class Initialized
INFO - 2021-12-11 15:50:01 --> Form Validation Class Initialized
DEBUG - 2021-12-11 15:50:01 --> Encrypt Class Initialized
DEBUG - 2021-12-11 15:50:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-11 15:50:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-11 15:50:01 --> Email Class Initialized
INFO - 2021-12-11 15:50:01 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-11 15:50:01 --> Calendar Class Initialized
INFO - 2021-12-11 15:50:01 --> Model "Login_model" initialized
INFO - 2021-12-11 15:50:01 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-11 15:50:01 --> Final output sent to browser
DEBUG - 2021-12-11 15:50:01 --> Total execution time: 0.0271
ERROR - 2021-12-11 17:29:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-11 17:29:54 --> Config Class Initialized
INFO - 2021-12-11 17:29:54 --> Hooks Class Initialized
DEBUG - 2021-12-11 17:29:54 --> UTF-8 Support Enabled
INFO - 2021-12-11 17:29:54 --> Utf8 Class Initialized
INFO - 2021-12-11 17:29:54 --> URI Class Initialized
DEBUG - 2021-12-11 17:29:54 --> No URI present. Default controller set.
INFO - 2021-12-11 17:29:54 --> Router Class Initialized
INFO - 2021-12-11 17:29:54 --> Output Class Initialized
INFO - 2021-12-11 17:29:54 --> Security Class Initialized
DEBUG - 2021-12-11 17:29:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 17:29:54 --> Input Class Initialized
INFO - 2021-12-11 17:29:54 --> Language Class Initialized
INFO - 2021-12-11 17:29:54 --> Loader Class Initialized
INFO - 2021-12-11 17:29:54 --> Helper loaded: url_helper
INFO - 2021-12-11 17:29:54 --> Helper loaded: form_helper
INFO - 2021-12-11 17:29:54 --> Helper loaded: common_helper
INFO - 2021-12-11 17:29:54 --> Database Driver Class Initialized
DEBUG - 2021-12-11 17:29:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 17:29:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 17:29:54 --> Controller Class Initialized
INFO - 2021-12-11 17:29:54 --> Form Validation Class Initialized
DEBUG - 2021-12-11 17:29:54 --> Encrypt Class Initialized
DEBUG - 2021-12-11 17:29:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-11 17:29:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-11 17:29:54 --> Email Class Initialized
INFO - 2021-12-11 17:29:54 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-11 17:29:54 --> Calendar Class Initialized
INFO - 2021-12-11 17:29:54 --> Model "Login_model" initialized
INFO - 2021-12-11 17:29:54 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-11 17:29:54 --> Final output sent to browser
DEBUG - 2021-12-11 17:29:54 --> Total execution time: 0.0237
ERROR - 2021-12-11 18:00:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-11 18:00:34 --> Config Class Initialized
INFO - 2021-12-11 18:00:34 --> Hooks Class Initialized
DEBUG - 2021-12-11 18:00:34 --> UTF-8 Support Enabled
INFO - 2021-12-11 18:00:34 --> Utf8 Class Initialized
INFO - 2021-12-11 18:00:34 --> URI Class Initialized
DEBUG - 2021-12-11 18:00:34 --> No URI present. Default controller set.
INFO - 2021-12-11 18:00:34 --> Router Class Initialized
INFO - 2021-12-11 18:00:34 --> Output Class Initialized
INFO - 2021-12-11 18:00:34 --> Security Class Initialized
DEBUG - 2021-12-11 18:00:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 18:00:34 --> Input Class Initialized
INFO - 2021-12-11 18:00:34 --> Language Class Initialized
INFO - 2021-12-11 18:00:34 --> Loader Class Initialized
INFO - 2021-12-11 18:00:34 --> Helper loaded: url_helper
INFO - 2021-12-11 18:00:34 --> Helper loaded: form_helper
INFO - 2021-12-11 18:00:34 --> Helper loaded: common_helper
INFO - 2021-12-11 18:00:34 --> Database Driver Class Initialized
DEBUG - 2021-12-11 18:00:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 18:00:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 18:00:34 --> Controller Class Initialized
INFO - 2021-12-11 18:00:34 --> Form Validation Class Initialized
DEBUG - 2021-12-11 18:00:34 --> Encrypt Class Initialized
DEBUG - 2021-12-11 18:00:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-11 18:00:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-11 18:00:34 --> Email Class Initialized
INFO - 2021-12-11 18:00:34 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-11 18:00:34 --> Calendar Class Initialized
INFO - 2021-12-11 18:00:34 --> Model "Login_model" initialized
INFO - 2021-12-11 18:00:34 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-11 18:00:34 --> Final output sent to browser
DEBUG - 2021-12-11 18:00:34 --> Total execution time: 0.0321
ERROR - 2021-12-11 20:14:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-11 20:14:51 --> Config Class Initialized
INFO - 2021-12-11 20:14:51 --> Hooks Class Initialized
DEBUG - 2021-12-11 20:14:51 --> UTF-8 Support Enabled
INFO - 2021-12-11 20:14:51 --> Utf8 Class Initialized
INFO - 2021-12-11 20:14:51 --> URI Class Initialized
DEBUG - 2021-12-11 20:14:51 --> No URI present. Default controller set.
INFO - 2021-12-11 20:14:51 --> Router Class Initialized
INFO - 2021-12-11 20:14:51 --> Output Class Initialized
INFO - 2021-12-11 20:14:51 --> Security Class Initialized
DEBUG - 2021-12-11 20:14:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-11 20:14:51 --> Input Class Initialized
INFO - 2021-12-11 20:14:51 --> Language Class Initialized
INFO - 2021-12-11 20:14:51 --> Loader Class Initialized
INFO - 2021-12-11 20:14:51 --> Helper loaded: url_helper
INFO - 2021-12-11 20:14:51 --> Helper loaded: form_helper
INFO - 2021-12-11 20:14:51 --> Helper loaded: common_helper
INFO - 2021-12-11 20:14:51 --> Database Driver Class Initialized
DEBUG - 2021-12-11 20:14:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-11 20:14:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-11 20:14:51 --> Controller Class Initialized
INFO - 2021-12-11 20:14:51 --> Form Validation Class Initialized
DEBUG - 2021-12-11 20:14:51 --> Encrypt Class Initialized
DEBUG - 2021-12-11 20:14:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-11 20:14:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-11 20:14:51 --> Email Class Initialized
INFO - 2021-12-11 20:14:51 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-11 20:14:51 --> Calendar Class Initialized
INFO - 2021-12-11 20:14:51 --> Model "Login_model" initialized
INFO - 2021-12-11 20:14:51 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-11 20:14:51 --> Final output sent to browser
DEBUG - 2021-12-11 20:14:51 --> Total execution time: 0.0302
