<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-09-23 03:02:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-23 03:02:57 --> Config Class Initialized
INFO - 2021-09-23 03:02:57 --> Hooks Class Initialized
DEBUG - 2021-09-23 03:02:57 --> UTF-8 Support Enabled
INFO - 2021-09-23 03:02:57 --> Utf8 Class Initialized
INFO - 2021-09-23 03:02:57 --> URI Class Initialized
INFO - 2021-09-23 03:02:57 --> Router Class Initialized
INFO - 2021-09-23 03:02:57 --> Output Class Initialized
INFO - 2021-09-23 03:02:57 --> Security Class Initialized
DEBUG - 2021-09-23 03:02:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 03:02:57 --> Input Class Initialized
INFO - 2021-09-23 03:02:57 --> Language Class Initialized
ERROR - 2021-09-23 03:02:57 --> 404 Page Not Found: Wp-content/index
ERROR - 2021-09-23 04:35:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-23 04:35:19 --> Config Class Initialized
INFO - 2021-09-23 04:35:19 --> Hooks Class Initialized
DEBUG - 2021-09-23 04:35:19 --> UTF-8 Support Enabled
INFO - 2021-09-23 04:35:19 --> Utf8 Class Initialized
INFO - 2021-09-23 04:35:19 --> URI Class Initialized
INFO - 2021-09-23 04:35:19 --> Router Class Initialized
INFO - 2021-09-23 04:35:19 --> Output Class Initialized
INFO - 2021-09-23 04:35:19 --> Security Class Initialized
DEBUG - 2021-09-23 04:35:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 04:35:19 --> Input Class Initialized
INFO - 2021-09-23 04:35:19 --> Language Class Initialized
ERROR - 2021-09-23 04:35:19 --> 404 Page Not Found: Wp-admin/css
ERROR - 2021-09-23 13:26:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-23 13:26:42 --> Config Class Initialized
INFO - 2021-09-23 13:26:42 --> Hooks Class Initialized
DEBUG - 2021-09-23 13:26:42 --> UTF-8 Support Enabled
INFO - 2021-09-23 13:26:42 --> Utf8 Class Initialized
INFO - 2021-09-23 13:26:42 --> URI Class Initialized
INFO - 2021-09-23 13:26:42 --> Router Class Initialized
INFO - 2021-09-23 13:26:42 --> Output Class Initialized
INFO - 2021-09-23 13:26:42 --> Security Class Initialized
DEBUG - 2021-09-23 13:26:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 13:26:42 --> Input Class Initialized
INFO - 2021-09-23 13:26:42 --> Language Class Initialized
ERROR - 2021-09-23 13:26:42 --> 404 Page Not Found: Wp-content/index
ERROR - 2021-09-23 19:35:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-23 19:35:43 --> Config Class Initialized
INFO - 2021-09-23 19:35:43 --> Hooks Class Initialized
DEBUG - 2021-09-23 19:35:43 --> UTF-8 Support Enabled
INFO - 2021-09-23 19:35:43 --> Utf8 Class Initialized
INFO - 2021-09-23 19:35:43 --> URI Class Initialized
DEBUG - 2021-09-23 19:35:43 --> No URI present. Default controller set.
INFO - 2021-09-23 19:35:43 --> Router Class Initialized
INFO - 2021-09-23 19:35:43 --> Output Class Initialized
INFO - 2021-09-23 19:35:43 --> Security Class Initialized
DEBUG - 2021-09-23 19:35:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 19:35:43 --> Input Class Initialized
INFO - 2021-09-23 19:35:43 --> Language Class Initialized
INFO - 2021-09-23 19:35:43 --> Loader Class Initialized
INFO - 2021-09-23 19:35:43 --> Helper loaded: url_helper
INFO - 2021-09-23 19:35:43 --> Helper loaded: form_helper
INFO - 2021-09-23 19:35:43 --> Helper loaded: common_helper
INFO - 2021-09-23 19:35:43 --> Database Driver Class Initialized
DEBUG - 2021-09-23 19:35:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-23 19:35:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-23 19:35:43 --> Controller Class Initialized
INFO - 2021-09-23 19:35:43 --> Form Validation Class Initialized
DEBUG - 2021-09-23 19:35:43 --> Encrypt Class Initialized
DEBUG - 2021-09-23 19:35:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-09-23 19:35:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-09-23 19:35:43 --> Email Class Initialized
INFO - 2021-09-23 19:35:43 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-09-23 19:35:43 --> Calendar Class Initialized
INFO - 2021-09-23 19:35:43 --> Model "Login_model" initialized
INFO - 2021-09-23 19:35:43 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-09-23 19:35:43 --> Final output sent to browser
DEBUG - 2021-09-23 19:35:43 --> Total execution time: 0.0830
ERROR - 2021-09-23 19:35:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-23 19:35:43 --> Config Class Initialized
INFO - 2021-09-23 19:35:43 --> Hooks Class Initialized
DEBUG - 2021-09-23 19:35:43 --> UTF-8 Support Enabled
INFO - 2021-09-23 19:35:43 --> Utf8 Class Initialized
INFO - 2021-09-23 19:35:43 --> URI Class Initialized
DEBUG - 2021-09-23 19:35:43 --> No URI present. Default controller set.
INFO - 2021-09-23 19:35:43 --> Router Class Initialized
INFO - 2021-09-23 19:35:43 --> Output Class Initialized
INFO - 2021-09-23 19:35:43 --> Security Class Initialized
DEBUG - 2021-09-23 19:35:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 19:35:43 --> Input Class Initialized
INFO - 2021-09-23 19:35:43 --> Language Class Initialized
INFO - 2021-09-23 19:35:43 --> Loader Class Initialized
INFO - 2021-09-23 19:35:43 --> Helper loaded: url_helper
INFO - 2021-09-23 19:35:43 --> Helper loaded: form_helper
INFO - 2021-09-23 19:35:43 --> Helper loaded: common_helper
INFO - 2021-09-23 19:35:43 --> Database Driver Class Initialized
DEBUG - 2021-09-23 19:35:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-23 19:35:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-23 19:35:44 --> Controller Class Initialized
INFO - 2021-09-23 19:35:44 --> Form Validation Class Initialized
DEBUG - 2021-09-23 19:35:44 --> Encrypt Class Initialized
DEBUG - 2021-09-23 19:35:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-09-23 19:35:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-09-23 19:35:44 --> Email Class Initialized
INFO - 2021-09-23 19:35:44 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-09-23 19:35:44 --> Calendar Class Initialized
INFO - 2021-09-23 19:35:44 --> Model "Login_model" initialized
INFO - 2021-09-23 19:35:44 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-09-23 19:35:44 --> Final output sent to browser
DEBUG - 2021-09-23 19:35:44 --> Total execution time: 0.0561
ERROR - 2021-09-23 19:35:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-23 19:35:44 --> Config Class Initialized
INFO - 2021-09-23 19:35:44 --> Hooks Class Initialized
DEBUG - 2021-09-23 19:35:44 --> UTF-8 Support Enabled
INFO - 2021-09-23 19:35:44 --> Utf8 Class Initialized
INFO - 2021-09-23 19:35:44 --> URI Class Initialized
INFO - 2021-09-23 19:35:44 --> Router Class Initialized
INFO - 2021-09-23 19:35:44 --> Output Class Initialized
INFO - 2021-09-23 19:35:44 --> Security Class Initialized
DEBUG - 2021-09-23 19:35:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 19:35:44 --> Input Class Initialized
INFO - 2021-09-23 19:35:44 --> Language Class Initialized
ERROR - 2021-09-23 19:35:44 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
ERROR - 2021-09-23 19:35:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-23 19:35:45 --> Config Class Initialized
INFO - 2021-09-23 19:35:45 --> Hooks Class Initialized
DEBUG - 2021-09-23 19:35:45 --> UTF-8 Support Enabled
INFO - 2021-09-23 19:35:45 --> Utf8 Class Initialized
INFO - 2021-09-23 19:35:45 --> URI Class Initialized
DEBUG - 2021-09-23 19:35:45 --> No URI present. Default controller set.
INFO - 2021-09-23 19:35:45 --> Router Class Initialized
INFO - 2021-09-23 19:35:45 --> Output Class Initialized
INFO - 2021-09-23 19:35:45 --> Security Class Initialized
DEBUG - 2021-09-23 19:35:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 19:35:45 --> Input Class Initialized
INFO - 2021-09-23 19:35:45 --> Language Class Initialized
INFO - 2021-09-23 19:35:45 --> Loader Class Initialized
INFO - 2021-09-23 19:35:45 --> Helper loaded: url_helper
INFO - 2021-09-23 19:35:45 --> Helper loaded: form_helper
INFO - 2021-09-23 19:35:45 --> Helper loaded: common_helper
INFO - 2021-09-23 19:35:45 --> Database Driver Class Initialized
DEBUG - 2021-09-23 19:35:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-23 19:35:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-23 19:35:45 --> Controller Class Initialized
INFO - 2021-09-23 19:35:45 --> Form Validation Class Initialized
DEBUG - 2021-09-23 19:35:45 --> Encrypt Class Initialized
DEBUG - 2021-09-23 19:35:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-09-23 19:35:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-09-23 19:35:45 --> Email Class Initialized
INFO - 2021-09-23 19:35:45 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-09-23 19:35:45 --> Calendar Class Initialized
INFO - 2021-09-23 19:35:45 --> Model "Login_model" initialized
INFO - 2021-09-23 19:35:45 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-09-23 19:35:45 --> Final output sent to browser
DEBUG - 2021-09-23 19:35:45 --> Total execution time: 0.0583
ERROR - 2021-09-23 19:35:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-23 19:35:45 --> Config Class Initialized
INFO - 2021-09-23 19:35:45 --> Hooks Class Initialized
DEBUG - 2021-09-23 19:35:45 --> UTF-8 Support Enabled
INFO - 2021-09-23 19:35:45 --> Utf8 Class Initialized
INFO - 2021-09-23 19:35:45 --> URI Class Initialized
INFO - 2021-09-23 19:35:45 --> Router Class Initialized
INFO - 2021-09-23 19:35:45 --> Output Class Initialized
INFO - 2021-09-23 19:35:45 --> Security Class Initialized
DEBUG - 2021-09-23 19:35:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 19:35:45 --> Input Class Initialized
INFO - 2021-09-23 19:35:45 --> Language Class Initialized
ERROR - 2021-09-23 19:35:45 --> 404 Page Not Found: Blog/wp-includes
ERROR - 2021-09-23 19:35:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-23 19:35:46 --> Config Class Initialized
INFO - 2021-09-23 19:35:46 --> Hooks Class Initialized
DEBUG - 2021-09-23 19:35:46 --> UTF-8 Support Enabled
INFO - 2021-09-23 19:35:46 --> Utf8 Class Initialized
INFO - 2021-09-23 19:35:46 --> URI Class Initialized
INFO - 2021-09-23 19:35:46 --> Router Class Initialized
INFO - 2021-09-23 19:35:46 --> Output Class Initialized
INFO - 2021-09-23 19:35:46 --> Security Class Initialized
DEBUG - 2021-09-23 19:35:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 19:35:46 --> Input Class Initialized
INFO - 2021-09-23 19:35:46 --> Language Class Initialized
ERROR - 2021-09-23 19:35:46 --> 404 Page Not Found: Web/wp-includes
ERROR - 2021-09-23 19:35:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-23 19:35:46 --> Config Class Initialized
INFO - 2021-09-23 19:35:46 --> Hooks Class Initialized
DEBUG - 2021-09-23 19:35:46 --> UTF-8 Support Enabled
INFO - 2021-09-23 19:35:46 --> Utf8 Class Initialized
INFO - 2021-09-23 19:35:46 --> URI Class Initialized
INFO - 2021-09-23 19:35:46 --> Router Class Initialized
INFO - 2021-09-23 19:35:46 --> Output Class Initialized
INFO - 2021-09-23 19:35:46 --> Security Class Initialized
DEBUG - 2021-09-23 19:35:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 19:35:46 --> Input Class Initialized
INFO - 2021-09-23 19:35:46 --> Language Class Initialized
ERROR - 2021-09-23 19:35:46 --> 404 Page Not Found: Wordpress/wp-includes
ERROR - 2021-09-23 19:35:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-23 19:35:46 --> Config Class Initialized
INFO - 2021-09-23 19:35:46 --> Hooks Class Initialized
DEBUG - 2021-09-23 19:35:46 --> UTF-8 Support Enabled
INFO - 2021-09-23 19:35:46 --> Utf8 Class Initialized
INFO - 2021-09-23 19:35:46 --> URI Class Initialized
INFO - 2021-09-23 19:35:46 --> Router Class Initialized
INFO - 2021-09-23 19:35:46 --> Output Class Initialized
INFO - 2021-09-23 19:35:46 --> Security Class Initialized
DEBUG - 2021-09-23 19:35:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 19:35:46 --> Input Class Initialized
INFO - 2021-09-23 19:35:46 --> Language Class Initialized
ERROR - 2021-09-23 19:35:46 --> 404 Page Not Found: Website/wp-includes
ERROR - 2021-09-23 19:35:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-23 19:35:47 --> Config Class Initialized
INFO - 2021-09-23 19:35:47 --> Hooks Class Initialized
DEBUG - 2021-09-23 19:35:47 --> UTF-8 Support Enabled
INFO - 2021-09-23 19:35:47 --> Utf8 Class Initialized
INFO - 2021-09-23 19:35:47 --> URI Class Initialized
INFO - 2021-09-23 19:35:47 --> Router Class Initialized
INFO - 2021-09-23 19:35:47 --> Output Class Initialized
INFO - 2021-09-23 19:35:47 --> Security Class Initialized
DEBUG - 2021-09-23 19:35:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 19:35:47 --> Input Class Initialized
INFO - 2021-09-23 19:35:47 --> Language Class Initialized
ERROR - 2021-09-23 19:35:47 --> 404 Page Not Found: Wp/wp-includes
ERROR - 2021-09-23 19:35:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-23 19:35:47 --> Config Class Initialized
INFO - 2021-09-23 19:35:47 --> Hooks Class Initialized
DEBUG - 2021-09-23 19:35:47 --> UTF-8 Support Enabled
INFO - 2021-09-23 19:35:47 --> Utf8 Class Initialized
INFO - 2021-09-23 19:35:47 --> URI Class Initialized
INFO - 2021-09-23 19:35:47 --> Router Class Initialized
INFO - 2021-09-23 19:35:47 --> Output Class Initialized
INFO - 2021-09-23 19:35:47 --> Security Class Initialized
DEBUG - 2021-09-23 19:35:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 19:35:47 --> Input Class Initialized
INFO - 2021-09-23 19:35:47 --> Language Class Initialized
ERROR - 2021-09-23 19:35:47 --> 404 Page Not Found: News/wp-includes
ERROR - 2021-09-23 19:35:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-23 19:35:48 --> Config Class Initialized
INFO - 2021-09-23 19:35:48 --> Hooks Class Initialized
DEBUG - 2021-09-23 19:35:48 --> UTF-8 Support Enabled
INFO - 2021-09-23 19:35:48 --> Utf8 Class Initialized
INFO - 2021-09-23 19:35:48 --> URI Class Initialized
INFO - 2021-09-23 19:35:48 --> Router Class Initialized
INFO - 2021-09-23 19:35:48 --> Output Class Initialized
INFO - 2021-09-23 19:35:48 --> Security Class Initialized
DEBUG - 2021-09-23 19:35:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 19:35:48 --> Input Class Initialized
INFO - 2021-09-23 19:35:48 --> Language Class Initialized
ERROR - 2021-09-23 19:35:48 --> 404 Page Not Found: 2018/wp-includes
ERROR - 2021-09-23 19:35:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-23 19:35:48 --> Config Class Initialized
INFO - 2021-09-23 19:35:48 --> Hooks Class Initialized
DEBUG - 2021-09-23 19:35:48 --> UTF-8 Support Enabled
INFO - 2021-09-23 19:35:48 --> Utf8 Class Initialized
INFO - 2021-09-23 19:35:48 --> URI Class Initialized
INFO - 2021-09-23 19:35:48 --> Router Class Initialized
INFO - 2021-09-23 19:35:48 --> Output Class Initialized
INFO - 2021-09-23 19:35:48 --> Security Class Initialized
DEBUG - 2021-09-23 19:35:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 19:35:48 --> Input Class Initialized
INFO - 2021-09-23 19:35:48 --> Language Class Initialized
ERROR - 2021-09-23 19:35:48 --> 404 Page Not Found: 2019/wp-includes
ERROR - 2021-09-23 19:35:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-23 19:35:49 --> Config Class Initialized
INFO - 2021-09-23 19:35:49 --> Hooks Class Initialized
DEBUG - 2021-09-23 19:35:49 --> UTF-8 Support Enabled
INFO - 2021-09-23 19:35:49 --> Utf8 Class Initialized
INFO - 2021-09-23 19:35:49 --> URI Class Initialized
INFO - 2021-09-23 19:35:49 --> Router Class Initialized
INFO - 2021-09-23 19:35:49 --> Output Class Initialized
INFO - 2021-09-23 19:35:49 --> Security Class Initialized
DEBUG - 2021-09-23 19:35:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 19:35:49 --> Input Class Initialized
INFO - 2021-09-23 19:35:49 --> Language Class Initialized
ERROR - 2021-09-23 19:35:49 --> 404 Page Not Found: Shop/wp-includes
ERROR - 2021-09-23 19:35:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-23 19:35:49 --> Config Class Initialized
INFO - 2021-09-23 19:35:49 --> Hooks Class Initialized
DEBUG - 2021-09-23 19:35:49 --> UTF-8 Support Enabled
INFO - 2021-09-23 19:35:49 --> Utf8 Class Initialized
INFO - 2021-09-23 19:35:49 --> URI Class Initialized
INFO - 2021-09-23 19:35:49 --> Router Class Initialized
INFO - 2021-09-23 19:35:49 --> Output Class Initialized
INFO - 2021-09-23 19:35:49 --> Security Class Initialized
DEBUG - 2021-09-23 19:35:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 19:35:49 --> Input Class Initialized
INFO - 2021-09-23 19:35:49 --> Language Class Initialized
ERROR - 2021-09-23 19:35:49 --> 404 Page Not Found: Wp1/wp-includes
ERROR - 2021-09-23 19:35:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-23 19:35:49 --> Config Class Initialized
INFO - 2021-09-23 19:35:49 --> Hooks Class Initialized
DEBUG - 2021-09-23 19:35:49 --> UTF-8 Support Enabled
INFO - 2021-09-23 19:35:49 --> Utf8 Class Initialized
INFO - 2021-09-23 19:35:49 --> URI Class Initialized
INFO - 2021-09-23 19:35:49 --> Router Class Initialized
INFO - 2021-09-23 19:35:50 --> Output Class Initialized
INFO - 2021-09-23 19:35:50 --> Security Class Initialized
DEBUG - 2021-09-23 19:35:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 19:35:50 --> Input Class Initialized
INFO - 2021-09-23 19:35:50 --> Language Class Initialized
ERROR - 2021-09-23 19:35:50 --> 404 Page Not Found: Test/wp-includes
ERROR - 2021-09-23 19:35:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-23 19:35:50 --> Config Class Initialized
INFO - 2021-09-23 19:35:50 --> Hooks Class Initialized
DEBUG - 2021-09-23 19:35:50 --> UTF-8 Support Enabled
INFO - 2021-09-23 19:35:50 --> Utf8 Class Initialized
INFO - 2021-09-23 19:35:50 --> URI Class Initialized
INFO - 2021-09-23 19:35:50 --> Router Class Initialized
INFO - 2021-09-23 19:35:50 --> Output Class Initialized
INFO - 2021-09-23 19:35:50 --> Security Class Initialized
DEBUG - 2021-09-23 19:35:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 19:35:50 --> Input Class Initialized
INFO - 2021-09-23 19:35:50 --> Language Class Initialized
ERROR - 2021-09-23 19:35:50 --> 404 Page Not Found: Media/wp-includes
ERROR - 2021-09-23 19:35:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-23 19:35:50 --> Config Class Initialized
INFO - 2021-09-23 19:35:50 --> Hooks Class Initialized
DEBUG - 2021-09-23 19:35:50 --> UTF-8 Support Enabled
INFO - 2021-09-23 19:35:50 --> Utf8 Class Initialized
INFO - 2021-09-23 19:35:50 --> URI Class Initialized
INFO - 2021-09-23 19:35:50 --> Router Class Initialized
INFO - 2021-09-23 19:35:50 --> Output Class Initialized
INFO - 2021-09-23 19:35:50 --> Security Class Initialized
DEBUG - 2021-09-23 19:35:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 19:35:50 --> Input Class Initialized
INFO - 2021-09-23 19:35:50 --> Language Class Initialized
ERROR - 2021-09-23 19:35:50 --> 404 Page Not Found: Wp2/wp-includes
ERROR - 2021-09-23 19:35:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-23 19:35:51 --> Config Class Initialized
INFO - 2021-09-23 19:35:51 --> Hooks Class Initialized
DEBUG - 2021-09-23 19:35:51 --> UTF-8 Support Enabled
INFO - 2021-09-23 19:35:51 --> Utf8 Class Initialized
INFO - 2021-09-23 19:35:51 --> URI Class Initialized
INFO - 2021-09-23 19:35:51 --> Router Class Initialized
INFO - 2021-09-23 19:35:51 --> Output Class Initialized
INFO - 2021-09-23 19:35:51 --> Security Class Initialized
DEBUG - 2021-09-23 19:35:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 19:35:51 --> Input Class Initialized
INFO - 2021-09-23 19:35:51 --> Language Class Initialized
ERROR - 2021-09-23 19:35:51 --> 404 Page Not Found: Site/wp-includes
ERROR - 2021-09-23 19:35:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-23 19:35:52 --> Config Class Initialized
INFO - 2021-09-23 19:35:52 --> Hooks Class Initialized
DEBUG - 2021-09-23 19:35:52 --> UTF-8 Support Enabled
INFO - 2021-09-23 19:35:52 --> Utf8 Class Initialized
INFO - 2021-09-23 19:35:52 --> URI Class Initialized
INFO - 2021-09-23 19:35:52 --> Router Class Initialized
INFO - 2021-09-23 19:35:52 --> Output Class Initialized
INFO - 2021-09-23 19:35:52 --> Security Class Initialized
DEBUG - 2021-09-23 19:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 19:35:52 --> Input Class Initialized
INFO - 2021-09-23 19:35:52 --> Language Class Initialized
ERROR - 2021-09-23 19:35:52 --> 404 Page Not Found: Cms/wp-includes
ERROR - 2021-09-23 19:35:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-23 19:35:52 --> Config Class Initialized
INFO - 2021-09-23 19:35:52 --> Hooks Class Initialized
DEBUG - 2021-09-23 19:35:52 --> UTF-8 Support Enabled
INFO - 2021-09-23 19:35:52 --> Utf8 Class Initialized
INFO - 2021-09-23 19:35:52 --> URI Class Initialized
INFO - 2021-09-23 19:35:52 --> Router Class Initialized
INFO - 2021-09-23 19:35:53 --> Output Class Initialized
INFO - 2021-09-23 19:35:53 --> Security Class Initialized
DEBUG - 2021-09-23 19:35:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 19:35:53 --> Input Class Initialized
INFO - 2021-09-23 19:35:53 --> Language Class Initialized
ERROR - 2021-09-23 19:35:53 --> 404 Page Not Found: Sito/wp-includes
