<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-07-21 06:36:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-21 06:36:02 --> Config Class Initialized
INFO - 2021-07-21 06:36:02 --> Hooks Class Initialized
DEBUG - 2021-07-21 06:36:02 --> UTF-8 Support Enabled
INFO - 2021-07-21 06:36:02 --> Utf8 Class Initialized
INFO - 2021-07-21 06:36:02 --> URI Class Initialized
DEBUG - 2021-07-21 06:36:02 --> No URI present. Default controller set.
INFO - 2021-07-21 06:36:02 --> Router Class Initialized
INFO - 2021-07-21 06:36:02 --> Output Class Initialized
INFO - 2021-07-21 06:36:02 --> Security Class Initialized
DEBUG - 2021-07-21 06:36:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-21 06:36:02 --> Input Class Initialized
INFO - 2021-07-21 06:36:02 --> Language Class Initialized
INFO - 2021-07-21 06:36:02 --> Loader Class Initialized
INFO - 2021-07-21 06:36:02 --> Helper loaded: url_helper
INFO - 2021-07-21 06:36:02 --> Helper loaded: form_helper
INFO - 2021-07-21 06:36:02 --> Helper loaded: common_helper
INFO - 2021-07-21 06:36:02 --> Database Driver Class Initialized
DEBUG - 2021-07-21 06:36:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-21 06:36:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-21 06:36:02 --> Controller Class Initialized
INFO - 2021-07-21 06:36:02 --> Form Validation Class Initialized
DEBUG - 2021-07-21 06:36:02 --> Encrypt Class Initialized
DEBUG - 2021-07-21 06:36:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-07-21 06:36:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-07-21 06:36:02 --> Email Class Initialized
INFO - 2021-07-21 06:36:02 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-07-21 06:36:02 --> Calendar Class Initialized
INFO - 2021-07-21 06:36:02 --> Model "Login_model" initialized
INFO - 2021-07-21 06:36:02 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-07-21 06:36:02 --> Final output sent to browser
DEBUG - 2021-07-21 06:36:02 --> Total execution time: 0.0420
ERROR - 2021-07-21 13:49:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-21 13:49:07 --> Config Class Initialized
INFO - 2021-07-21 13:49:07 --> Hooks Class Initialized
DEBUG - 2021-07-21 13:49:07 --> UTF-8 Support Enabled
INFO - 2021-07-21 13:49:07 --> Utf8 Class Initialized
INFO - 2021-07-21 13:49:07 --> URI Class Initialized
DEBUG - 2021-07-21 13:49:07 --> No URI present. Default controller set.
INFO - 2021-07-21 13:49:07 --> Router Class Initialized
INFO - 2021-07-21 13:49:07 --> Output Class Initialized
INFO - 2021-07-21 13:49:07 --> Security Class Initialized
DEBUG - 2021-07-21 13:49:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-21 13:49:07 --> Input Class Initialized
INFO - 2021-07-21 13:49:07 --> Language Class Initialized
INFO - 2021-07-21 13:49:07 --> Loader Class Initialized
INFO - 2021-07-21 13:49:07 --> Helper loaded: url_helper
INFO - 2021-07-21 13:49:07 --> Helper loaded: form_helper
INFO - 2021-07-21 13:49:07 --> Helper loaded: common_helper
INFO - 2021-07-21 13:49:07 --> Database Driver Class Initialized
DEBUG - 2021-07-21 13:49:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-21 13:49:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-21 13:49:07 --> Controller Class Initialized
INFO - 2021-07-21 13:49:07 --> Form Validation Class Initialized
DEBUG - 2021-07-21 13:49:07 --> Encrypt Class Initialized
DEBUG - 2021-07-21 13:49:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-07-21 13:49:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-07-21 13:49:07 --> Email Class Initialized
INFO - 2021-07-21 13:49:07 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-07-21 13:49:07 --> Calendar Class Initialized
INFO - 2021-07-21 13:49:07 --> Model "Login_model" initialized
INFO - 2021-07-21 13:49:07 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-07-21 13:49:07 --> Final output sent to browser
DEBUG - 2021-07-21 13:49:07 --> Total execution time: 0.0464
