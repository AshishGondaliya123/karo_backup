<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-02-08 03:18:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-08 03:18:40 --> Config Class Initialized
INFO - 2022-02-08 03:18:40 --> Hooks Class Initialized
DEBUG - 2022-02-08 03:18:40 --> UTF-8 Support Enabled
INFO - 2022-02-08 03:18:40 --> Utf8 Class Initialized
INFO - 2022-02-08 03:18:40 --> URI Class Initialized
DEBUG - 2022-02-08 03:18:40 --> No URI present. Default controller set.
INFO - 2022-02-08 03:18:40 --> Router Class Initialized
INFO - 2022-02-08 03:18:40 --> Output Class Initialized
INFO - 2022-02-08 03:18:40 --> Security Class Initialized
DEBUG - 2022-02-08 03:18:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-08 03:18:40 --> Input Class Initialized
INFO - 2022-02-08 03:18:40 --> Language Class Initialized
INFO - 2022-02-08 03:18:40 --> Loader Class Initialized
INFO - 2022-02-08 03:18:40 --> Helper loaded: url_helper
INFO - 2022-02-08 03:18:40 --> Helper loaded: form_helper
INFO - 2022-02-08 03:18:40 --> Helper loaded: common_helper
INFO - 2022-02-08 03:18:40 --> Database Driver Class Initialized
DEBUG - 2022-02-08 03:18:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-08 03:18:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-08 03:18:40 --> Controller Class Initialized
INFO - 2022-02-08 03:18:40 --> Form Validation Class Initialized
DEBUG - 2022-02-08 03:18:40 --> Encrypt Class Initialized
DEBUG - 2022-02-08 03:18:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 03:18:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-08 03:18:40 --> Email Class Initialized
INFO - 2022-02-08 03:18:40 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-08 03:18:40 --> Calendar Class Initialized
INFO - 2022-02-08 03:18:40 --> Model "Login_model" initialized
INFO - 2022-02-08 03:18:40 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-08 03:18:40 --> Final output sent to browser
DEBUG - 2022-02-08 03:18:40 --> Total execution time: 0.0246
ERROR - 2022-02-08 04:09:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-08 04:09:03 --> Config Class Initialized
INFO - 2022-02-08 04:09:03 --> Hooks Class Initialized
DEBUG - 2022-02-08 04:09:03 --> UTF-8 Support Enabled
INFO - 2022-02-08 04:09:03 --> Utf8 Class Initialized
INFO - 2022-02-08 04:09:03 --> URI Class Initialized
DEBUG - 2022-02-08 04:09:03 --> No URI present. Default controller set.
INFO - 2022-02-08 04:09:03 --> Router Class Initialized
INFO - 2022-02-08 04:09:03 --> Output Class Initialized
INFO - 2022-02-08 04:09:03 --> Security Class Initialized
DEBUG - 2022-02-08 04:09:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-08 04:09:03 --> Input Class Initialized
INFO - 2022-02-08 04:09:03 --> Language Class Initialized
INFO - 2022-02-08 04:09:03 --> Loader Class Initialized
INFO - 2022-02-08 04:09:03 --> Helper loaded: url_helper
INFO - 2022-02-08 04:09:03 --> Helper loaded: form_helper
INFO - 2022-02-08 04:09:03 --> Helper loaded: common_helper
INFO - 2022-02-08 04:09:03 --> Database Driver Class Initialized
DEBUG - 2022-02-08 04:09:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-08 04:09:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-08 04:09:03 --> Controller Class Initialized
INFO - 2022-02-08 04:09:03 --> Form Validation Class Initialized
DEBUG - 2022-02-08 04:09:03 --> Encrypt Class Initialized
DEBUG - 2022-02-08 04:09:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 04:09:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-08 04:09:03 --> Email Class Initialized
INFO - 2022-02-08 04:09:03 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-08 04:09:03 --> Calendar Class Initialized
INFO - 2022-02-08 04:09:03 --> Model "Login_model" initialized
INFO - 2022-02-08 04:09:03 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-08 04:09:03 --> Final output sent to browser
DEBUG - 2022-02-08 04:09:03 --> Total execution time: 0.0272
ERROR - 2022-02-08 08:28:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-08 08:28:47 --> Config Class Initialized
INFO - 2022-02-08 08:28:47 --> Hooks Class Initialized
DEBUG - 2022-02-08 08:28:47 --> UTF-8 Support Enabled
INFO - 2022-02-08 08:28:47 --> Utf8 Class Initialized
INFO - 2022-02-08 08:28:47 --> URI Class Initialized
DEBUG - 2022-02-08 08:28:47 --> No URI present. Default controller set.
INFO - 2022-02-08 08:28:47 --> Router Class Initialized
INFO - 2022-02-08 08:28:47 --> Output Class Initialized
INFO - 2022-02-08 08:28:47 --> Security Class Initialized
DEBUG - 2022-02-08 08:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-08 08:28:47 --> Input Class Initialized
INFO - 2022-02-08 08:28:47 --> Language Class Initialized
INFO - 2022-02-08 08:28:47 --> Loader Class Initialized
INFO - 2022-02-08 08:28:47 --> Helper loaded: url_helper
INFO - 2022-02-08 08:28:47 --> Helper loaded: form_helper
INFO - 2022-02-08 08:28:47 --> Helper loaded: common_helper
INFO - 2022-02-08 08:28:47 --> Database Driver Class Initialized
DEBUG - 2022-02-08 08:28:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-08 08:28:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-08 08:28:47 --> Controller Class Initialized
INFO - 2022-02-08 08:28:47 --> Form Validation Class Initialized
DEBUG - 2022-02-08 08:28:47 --> Encrypt Class Initialized
DEBUG - 2022-02-08 08:28:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 08:28:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-08 08:28:47 --> Email Class Initialized
INFO - 2022-02-08 08:28:47 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-08 08:28:47 --> Calendar Class Initialized
INFO - 2022-02-08 08:28:47 --> Model "Login_model" initialized
INFO - 2022-02-08 08:28:47 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-08 08:28:47 --> Final output sent to browser
DEBUG - 2022-02-08 08:28:47 --> Total execution time: 0.0236
ERROR - 2022-02-08 08:40:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-08 08:40:44 --> Config Class Initialized
INFO - 2022-02-08 08:40:44 --> Hooks Class Initialized
DEBUG - 2022-02-08 08:40:44 --> UTF-8 Support Enabled
INFO - 2022-02-08 08:40:44 --> Utf8 Class Initialized
INFO - 2022-02-08 08:40:44 --> URI Class Initialized
DEBUG - 2022-02-08 08:40:44 --> No URI present. Default controller set.
INFO - 2022-02-08 08:40:44 --> Router Class Initialized
INFO - 2022-02-08 08:40:44 --> Output Class Initialized
INFO - 2022-02-08 08:40:44 --> Security Class Initialized
DEBUG - 2022-02-08 08:40:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-08 08:40:44 --> Input Class Initialized
INFO - 2022-02-08 08:40:44 --> Language Class Initialized
INFO - 2022-02-08 08:40:44 --> Loader Class Initialized
INFO - 2022-02-08 08:40:44 --> Helper loaded: url_helper
INFO - 2022-02-08 08:40:44 --> Helper loaded: form_helper
INFO - 2022-02-08 08:40:44 --> Helper loaded: common_helper
INFO - 2022-02-08 08:40:44 --> Database Driver Class Initialized
DEBUG - 2022-02-08 08:40:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-08 08:40:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-08 08:40:45 --> Controller Class Initialized
INFO - 2022-02-08 08:40:45 --> Form Validation Class Initialized
DEBUG - 2022-02-08 08:40:45 --> Encrypt Class Initialized
DEBUG - 2022-02-08 08:40:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 08:40:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-08 08:40:45 --> Email Class Initialized
INFO - 2022-02-08 08:40:45 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-08 08:40:45 --> Calendar Class Initialized
INFO - 2022-02-08 08:40:45 --> Model "Login_model" initialized
INFO - 2022-02-08 08:40:45 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-08 08:40:45 --> Final output sent to browser
DEBUG - 2022-02-08 08:40:45 --> Total execution time: 0.0321
ERROR - 2022-02-08 09:22:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-08 09:22:09 --> Config Class Initialized
INFO - 2022-02-08 09:22:09 --> Hooks Class Initialized
DEBUG - 2022-02-08 09:22:09 --> UTF-8 Support Enabled
INFO - 2022-02-08 09:22:09 --> Utf8 Class Initialized
INFO - 2022-02-08 09:22:09 --> URI Class Initialized
DEBUG - 2022-02-08 09:22:09 --> No URI present. Default controller set.
INFO - 2022-02-08 09:22:09 --> Router Class Initialized
INFO - 2022-02-08 09:22:09 --> Output Class Initialized
INFO - 2022-02-08 09:22:09 --> Security Class Initialized
DEBUG - 2022-02-08 09:22:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-08 09:22:09 --> Input Class Initialized
INFO - 2022-02-08 09:22:09 --> Language Class Initialized
INFO - 2022-02-08 09:22:09 --> Loader Class Initialized
INFO - 2022-02-08 09:22:09 --> Helper loaded: url_helper
INFO - 2022-02-08 09:22:09 --> Helper loaded: form_helper
INFO - 2022-02-08 09:22:09 --> Helper loaded: common_helper
INFO - 2022-02-08 09:22:09 --> Database Driver Class Initialized
DEBUG - 2022-02-08 09:22:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-08 09:22:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-08 09:22:09 --> Controller Class Initialized
INFO - 2022-02-08 09:22:09 --> Form Validation Class Initialized
DEBUG - 2022-02-08 09:22:09 --> Encrypt Class Initialized
DEBUG - 2022-02-08 09:22:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 09:22:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-08 09:22:09 --> Email Class Initialized
INFO - 2022-02-08 09:22:09 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-08 09:22:09 --> Calendar Class Initialized
INFO - 2022-02-08 09:22:09 --> Model "Login_model" initialized
INFO - 2022-02-08 09:22:09 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-08 09:22:09 --> Final output sent to browser
DEBUG - 2022-02-08 09:22:09 --> Total execution time: 0.0271
ERROR - 2022-02-08 11:20:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-08 11:20:06 --> Config Class Initialized
INFO - 2022-02-08 11:20:06 --> Hooks Class Initialized
DEBUG - 2022-02-08 11:20:06 --> UTF-8 Support Enabled
INFO - 2022-02-08 11:20:06 --> Utf8 Class Initialized
INFO - 2022-02-08 11:20:06 --> URI Class Initialized
DEBUG - 2022-02-08 11:20:06 --> No URI present. Default controller set.
INFO - 2022-02-08 11:20:06 --> Router Class Initialized
INFO - 2022-02-08 11:20:06 --> Output Class Initialized
INFO - 2022-02-08 11:20:06 --> Security Class Initialized
DEBUG - 2022-02-08 11:20:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-08 11:20:06 --> Input Class Initialized
INFO - 2022-02-08 11:20:06 --> Language Class Initialized
INFO - 2022-02-08 11:20:06 --> Loader Class Initialized
INFO - 2022-02-08 11:20:06 --> Helper loaded: url_helper
INFO - 2022-02-08 11:20:06 --> Helper loaded: form_helper
INFO - 2022-02-08 11:20:06 --> Helper loaded: common_helper
INFO - 2022-02-08 11:20:06 --> Database Driver Class Initialized
DEBUG - 2022-02-08 11:20:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-08 11:20:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-08 11:20:06 --> Controller Class Initialized
INFO - 2022-02-08 11:20:06 --> Form Validation Class Initialized
DEBUG - 2022-02-08 11:20:06 --> Encrypt Class Initialized
DEBUG - 2022-02-08 11:20:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 11:20:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-08 11:20:06 --> Email Class Initialized
INFO - 2022-02-08 11:20:06 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-08 11:20:06 --> Calendar Class Initialized
INFO - 2022-02-08 11:20:06 --> Model "Login_model" initialized
INFO - 2022-02-08 11:20:06 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-08 11:20:06 --> Final output sent to browser
DEBUG - 2022-02-08 11:20:06 --> Total execution time: 0.0359
ERROR - 2022-02-08 11:24:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-08 11:24:06 --> Config Class Initialized
INFO - 2022-02-08 11:24:06 --> Hooks Class Initialized
DEBUG - 2022-02-08 11:24:06 --> UTF-8 Support Enabled
INFO - 2022-02-08 11:24:06 --> Utf8 Class Initialized
INFO - 2022-02-08 11:24:06 --> URI Class Initialized
DEBUG - 2022-02-08 11:24:06 --> No URI present. Default controller set.
INFO - 2022-02-08 11:24:06 --> Router Class Initialized
INFO - 2022-02-08 11:24:06 --> Output Class Initialized
INFO - 2022-02-08 11:24:06 --> Security Class Initialized
DEBUG - 2022-02-08 11:24:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-08 11:24:06 --> Input Class Initialized
INFO - 2022-02-08 11:24:06 --> Language Class Initialized
INFO - 2022-02-08 11:24:06 --> Loader Class Initialized
INFO - 2022-02-08 11:24:06 --> Helper loaded: url_helper
INFO - 2022-02-08 11:24:06 --> Helper loaded: form_helper
INFO - 2022-02-08 11:24:06 --> Helper loaded: common_helper
INFO - 2022-02-08 11:24:06 --> Database Driver Class Initialized
DEBUG - 2022-02-08 11:24:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-08 11:24:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-08 11:24:06 --> Controller Class Initialized
INFO - 2022-02-08 11:24:06 --> Form Validation Class Initialized
DEBUG - 2022-02-08 11:24:06 --> Encrypt Class Initialized
DEBUG - 2022-02-08 11:24:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 11:24:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-08 11:24:06 --> Email Class Initialized
INFO - 2022-02-08 11:24:06 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-08 11:24:06 --> Calendar Class Initialized
INFO - 2022-02-08 11:24:06 --> Model "Login_model" initialized
INFO - 2022-02-08 11:24:06 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-08 11:24:06 --> Final output sent to browser
DEBUG - 2022-02-08 11:24:06 --> Total execution time: 0.0258
ERROR - 2022-02-08 11:24:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-08 11:24:07 --> Config Class Initialized
INFO - 2022-02-08 11:24:07 --> Hooks Class Initialized
DEBUG - 2022-02-08 11:24:07 --> UTF-8 Support Enabled
INFO - 2022-02-08 11:24:07 --> Utf8 Class Initialized
INFO - 2022-02-08 11:24:07 --> URI Class Initialized
DEBUG - 2022-02-08 11:24:07 --> No URI present. Default controller set.
INFO - 2022-02-08 11:24:07 --> Router Class Initialized
INFO - 2022-02-08 11:24:07 --> Output Class Initialized
INFO - 2022-02-08 11:24:07 --> Security Class Initialized
DEBUG - 2022-02-08 11:24:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-08 11:24:07 --> Input Class Initialized
INFO - 2022-02-08 11:24:07 --> Language Class Initialized
INFO - 2022-02-08 11:24:07 --> Loader Class Initialized
INFO - 2022-02-08 11:24:07 --> Helper loaded: url_helper
INFO - 2022-02-08 11:24:07 --> Helper loaded: form_helper
INFO - 2022-02-08 11:24:07 --> Helper loaded: common_helper
INFO - 2022-02-08 11:24:07 --> Database Driver Class Initialized
DEBUG - 2022-02-08 11:24:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-08 11:24:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-08 11:24:07 --> Controller Class Initialized
INFO - 2022-02-08 11:24:07 --> Form Validation Class Initialized
DEBUG - 2022-02-08 11:24:07 --> Encrypt Class Initialized
DEBUG - 2022-02-08 11:24:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 11:24:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-08 11:24:07 --> Email Class Initialized
INFO - 2022-02-08 11:24:07 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-08 11:24:07 --> Calendar Class Initialized
INFO - 2022-02-08 11:24:07 --> Model "Login_model" initialized
INFO - 2022-02-08 11:24:07 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-08 11:24:07 --> Final output sent to browser
DEBUG - 2022-02-08 11:24:07 --> Total execution time: 0.0264
ERROR - 2022-02-08 14:19:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-08 14:19:42 --> Config Class Initialized
INFO - 2022-02-08 14:19:42 --> Hooks Class Initialized
DEBUG - 2022-02-08 14:19:42 --> UTF-8 Support Enabled
INFO - 2022-02-08 14:19:42 --> Utf8 Class Initialized
INFO - 2022-02-08 14:19:42 --> URI Class Initialized
DEBUG - 2022-02-08 14:19:42 --> No URI present. Default controller set.
INFO - 2022-02-08 14:19:42 --> Router Class Initialized
INFO - 2022-02-08 14:19:42 --> Output Class Initialized
INFO - 2022-02-08 14:19:42 --> Security Class Initialized
DEBUG - 2022-02-08 14:19:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-08 14:19:42 --> Input Class Initialized
INFO - 2022-02-08 14:19:42 --> Language Class Initialized
INFO - 2022-02-08 14:19:42 --> Loader Class Initialized
INFO - 2022-02-08 14:19:42 --> Helper loaded: url_helper
INFO - 2022-02-08 14:19:42 --> Helper loaded: form_helper
INFO - 2022-02-08 14:19:42 --> Helper loaded: common_helper
INFO - 2022-02-08 14:19:42 --> Database Driver Class Initialized
DEBUG - 2022-02-08 14:19:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-08 14:19:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-08 14:19:42 --> Controller Class Initialized
INFO - 2022-02-08 14:19:42 --> Form Validation Class Initialized
DEBUG - 2022-02-08 14:19:42 --> Encrypt Class Initialized
DEBUG - 2022-02-08 14:19:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 14:19:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-08 14:19:42 --> Email Class Initialized
INFO - 2022-02-08 14:19:42 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-08 14:19:42 --> Calendar Class Initialized
INFO - 2022-02-08 14:19:42 --> Model "Login_model" initialized
INFO - 2022-02-08 14:19:42 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-08 14:19:42 --> Final output sent to browser
DEBUG - 2022-02-08 14:19:42 --> Total execution time: 0.0269
ERROR - 2022-02-08 14:19:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-08 14:19:43 --> Config Class Initialized
INFO - 2022-02-08 14:19:43 --> Hooks Class Initialized
DEBUG - 2022-02-08 14:19:43 --> UTF-8 Support Enabled
INFO - 2022-02-08 14:19:43 --> Utf8 Class Initialized
INFO - 2022-02-08 14:19:43 --> URI Class Initialized
INFO - 2022-02-08 14:19:43 --> Router Class Initialized
INFO - 2022-02-08 14:19:43 --> Output Class Initialized
INFO - 2022-02-08 14:19:43 --> Security Class Initialized
DEBUG - 2022-02-08 14:19:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-08 14:19:43 --> Input Class Initialized
INFO - 2022-02-08 14:19:43 --> Language Class Initialized
ERROR - 2022-02-08 14:19:43 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2022-02-08 14:20:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-08 14:20:09 --> Config Class Initialized
INFO - 2022-02-08 14:20:09 --> Hooks Class Initialized
DEBUG - 2022-02-08 14:20:09 --> UTF-8 Support Enabled
INFO - 2022-02-08 14:20:09 --> Utf8 Class Initialized
INFO - 2022-02-08 14:20:09 --> URI Class Initialized
INFO - 2022-02-08 14:20:09 --> Router Class Initialized
INFO - 2022-02-08 14:20:09 --> Output Class Initialized
INFO - 2022-02-08 14:20:09 --> Security Class Initialized
DEBUG - 2022-02-08 14:20:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-08 14:20:09 --> Input Class Initialized
INFO - 2022-02-08 14:20:09 --> Language Class Initialized
INFO - 2022-02-08 14:20:09 --> Loader Class Initialized
INFO - 2022-02-08 14:20:09 --> Helper loaded: url_helper
INFO - 2022-02-08 14:20:09 --> Helper loaded: form_helper
INFO - 2022-02-08 14:20:09 --> Helper loaded: common_helper
INFO - 2022-02-08 14:20:09 --> Database Driver Class Initialized
DEBUG - 2022-02-08 14:20:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-08 14:20:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-08 14:20:09 --> Controller Class Initialized
INFO - 2022-02-08 14:20:09 --> Form Validation Class Initialized
DEBUG - 2022-02-08 14:20:09 --> Encrypt Class Initialized
DEBUG - 2022-02-08 14:20:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 14:20:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-08 14:20:09 --> Email Class Initialized
INFO - 2022-02-08 14:20:09 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-08 14:20:09 --> Calendar Class Initialized
INFO - 2022-02-08 14:20:09 --> Model "Login_model" initialized
ERROR - 2022-02-08 14:20:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-08 14:20:10 --> Config Class Initialized
INFO - 2022-02-08 14:20:10 --> Hooks Class Initialized
DEBUG - 2022-02-08 14:20:10 --> UTF-8 Support Enabled
INFO - 2022-02-08 14:20:10 --> Utf8 Class Initialized
INFO - 2022-02-08 14:20:10 --> URI Class Initialized
INFO - 2022-02-08 14:20:10 --> Router Class Initialized
INFO - 2022-02-08 14:20:10 --> Output Class Initialized
INFO - 2022-02-08 14:20:10 --> Security Class Initialized
DEBUG - 2022-02-08 14:20:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-08 14:20:10 --> Input Class Initialized
INFO - 2022-02-08 14:20:10 --> Language Class Initialized
INFO - 2022-02-08 14:20:10 --> Loader Class Initialized
INFO - 2022-02-08 14:20:10 --> Helper loaded: url_helper
INFO - 2022-02-08 14:20:10 --> Helper loaded: form_helper
INFO - 2022-02-08 14:20:10 --> Helper loaded: common_helper
INFO - 2022-02-08 14:20:10 --> Database Driver Class Initialized
DEBUG - 2022-02-08 14:20:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-08 14:20:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-08 14:20:10 --> Controller Class Initialized
INFO - 2022-02-08 14:20:10 --> Form Validation Class Initialized
DEBUG - 2022-02-08 14:20:10 --> Encrypt Class Initialized
DEBUG - 2022-02-08 14:20:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 14:20:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-08 14:20:10 --> Email Class Initialized
INFO - 2022-02-08 14:20:10 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-08 14:20:10 --> Calendar Class Initialized
INFO - 2022-02-08 14:20:10 --> Model "Login_model" initialized
ERROR - 2022-02-08 14:20:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-08 14:20:10 --> Config Class Initialized
INFO - 2022-02-08 14:20:10 --> Hooks Class Initialized
DEBUG - 2022-02-08 14:20:10 --> UTF-8 Support Enabled
INFO - 2022-02-08 14:20:10 --> Utf8 Class Initialized
INFO - 2022-02-08 14:20:10 --> URI Class Initialized
INFO - 2022-02-08 14:20:10 --> Router Class Initialized
INFO - 2022-02-08 14:20:10 --> Output Class Initialized
INFO - 2022-02-08 14:20:10 --> Security Class Initialized
DEBUG - 2022-02-08 14:20:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-08 14:20:10 --> Input Class Initialized
INFO - 2022-02-08 14:20:10 --> Language Class Initialized
INFO - 2022-02-08 14:20:10 --> Loader Class Initialized
INFO - 2022-02-08 14:20:10 --> Helper loaded: url_helper
INFO - 2022-02-08 14:20:10 --> Helper loaded: form_helper
INFO - 2022-02-08 14:20:10 --> Helper loaded: common_helper
INFO - 2022-02-08 14:20:10 --> Database Driver Class Initialized
DEBUG - 2022-02-08 14:20:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-08 14:20:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-08 14:20:10 --> Controller Class Initialized
INFO - 2022-02-08 14:20:10 --> Form Validation Class Initialized
DEBUG - 2022-02-08 14:20:10 --> Encrypt Class Initialized
DEBUG - 2022-02-08 14:20:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 14:20:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-08 14:20:10 --> Email Class Initialized
INFO - 2022-02-08 14:20:10 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-08 14:20:10 --> Calendar Class Initialized
INFO - 2022-02-08 14:20:10 --> Model "Login_model" initialized
INFO - 2022-02-08 14:20:10 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-08 14:20:10 --> Final output sent to browser
DEBUG - 2022-02-08 14:20:10 --> Total execution time: 0.0244
ERROR - 2022-02-08 14:20:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-08 14:20:11 --> Config Class Initialized
INFO - 2022-02-08 14:20:11 --> Hooks Class Initialized
DEBUG - 2022-02-08 14:20:11 --> UTF-8 Support Enabled
INFO - 2022-02-08 14:20:11 --> Utf8 Class Initialized
INFO - 2022-02-08 14:20:11 --> URI Class Initialized
DEBUG - 2022-02-08 14:20:11 --> No URI present. Default controller set.
INFO - 2022-02-08 14:20:11 --> Router Class Initialized
INFO - 2022-02-08 14:20:11 --> Output Class Initialized
INFO - 2022-02-08 14:20:11 --> Security Class Initialized
DEBUG - 2022-02-08 14:20:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-08 14:20:11 --> Input Class Initialized
INFO - 2022-02-08 14:20:11 --> Language Class Initialized
INFO - 2022-02-08 14:20:11 --> Loader Class Initialized
INFO - 2022-02-08 14:20:11 --> Helper loaded: url_helper
INFO - 2022-02-08 14:20:11 --> Helper loaded: form_helper
INFO - 2022-02-08 14:20:11 --> Helper loaded: common_helper
INFO - 2022-02-08 14:20:11 --> Database Driver Class Initialized
DEBUG - 2022-02-08 14:20:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-08 14:20:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-08 14:20:11 --> Controller Class Initialized
INFO - 2022-02-08 14:20:11 --> Form Validation Class Initialized
DEBUG - 2022-02-08 14:20:11 --> Encrypt Class Initialized
DEBUG - 2022-02-08 14:20:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 14:20:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-08 14:20:11 --> Email Class Initialized
INFO - 2022-02-08 14:20:11 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-08 14:20:11 --> Calendar Class Initialized
INFO - 2022-02-08 14:20:11 --> Model "Login_model" initialized
INFO - 2022-02-08 14:20:11 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-08 14:20:11 --> Final output sent to browser
DEBUG - 2022-02-08 14:20:11 --> Total execution time: 0.0323
ERROR - 2022-02-08 15:39:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-08 15:39:42 --> Config Class Initialized
INFO - 2022-02-08 15:39:42 --> Hooks Class Initialized
DEBUG - 2022-02-08 15:39:42 --> UTF-8 Support Enabled
INFO - 2022-02-08 15:39:42 --> Utf8 Class Initialized
INFO - 2022-02-08 15:39:42 --> URI Class Initialized
DEBUG - 2022-02-08 15:39:42 --> No URI present. Default controller set.
INFO - 2022-02-08 15:39:42 --> Router Class Initialized
INFO - 2022-02-08 15:39:42 --> Output Class Initialized
INFO - 2022-02-08 15:39:42 --> Security Class Initialized
DEBUG - 2022-02-08 15:39:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-08 15:39:42 --> Input Class Initialized
INFO - 2022-02-08 15:39:42 --> Language Class Initialized
INFO - 2022-02-08 15:39:42 --> Loader Class Initialized
INFO - 2022-02-08 15:39:42 --> Helper loaded: url_helper
INFO - 2022-02-08 15:39:42 --> Helper loaded: form_helper
INFO - 2022-02-08 15:39:42 --> Helper loaded: common_helper
INFO - 2022-02-08 15:39:42 --> Database Driver Class Initialized
DEBUG - 2022-02-08 15:39:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-08 15:39:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-08 15:39:42 --> Controller Class Initialized
INFO - 2022-02-08 15:39:42 --> Form Validation Class Initialized
DEBUG - 2022-02-08 15:39:42 --> Encrypt Class Initialized
DEBUG - 2022-02-08 15:39:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 15:39:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-08 15:39:42 --> Email Class Initialized
INFO - 2022-02-08 15:39:42 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-08 15:39:42 --> Calendar Class Initialized
INFO - 2022-02-08 15:39:42 --> Model "Login_model" initialized
INFO - 2022-02-08 15:39:42 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-08 15:39:42 --> Final output sent to browser
DEBUG - 2022-02-08 15:39:42 --> Total execution time: 0.0318
ERROR - 2022-02-08 23:45:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-08 23:45:00 --> Config Class Initialized
INFO - 2022-02-08 23:45:00 --> Hooks Class Initialized
DEBUG - 2022-02-08 23:45:00 --> UTF-8 Support Enabled
INFO - 2022-02-08 23:45:00 --> Utf8 Class Initialized
INFO - 2022-02-08 23:45:00 --> URI Class Initialized
DEBUG - 2022-02-08 23:45:00 --> No URI present. Default controller set.
INFO - 2022-02-08 23:45:00 --> Router Class Initialized
INFO - 2022-02-08 23:45:00 --> Output Class Initialized
INFO - 2022-02-08 23:45:00 --> Security Class Initialized
DEBUG - 2022-02-08 23:45:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-08 23:45:00 --> Input Class Initialized
INFO - 2022-02-08 23:45:00 --> Language Class Initialized
INFO - 2022-02-08 23:45:00 --> Loader Class Initialized
INFO - 2022-02-08 23:45:00 --> Helper loaded: url_helper
INFO - 2022-02-08 23:45:00 --> Helper loaded: form_helper
INFO - 2022-02-08 23:45:00 --> Helper loaded: common_helper
INFO - 2022-02-08 23:45:00 --> Database Driver Class Initialized
DEBUG - 2022-02-08 23:45:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-08 23:45:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-08 23:45:00 --> Controller Class Initialized
INFO - 2022-02-08 23:45:00 --> Form Validation Class Initialized
DEBUG - 2022-02-08 23:45:00 --> Encrypt Class Initialized
DEBUG - 2022-02-08 23:45:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 23:45:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-08 23:45:00 --> Email Class Initialized
INFO - 2022-02-08 23:45:00 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-08 23:45:00 --> Calendar Class Initialized
INFO - 2022-02-08 23:45:00 --> Model "Login_model" initialized
INFO - 2022-02-08 23:45:00 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-08 23:45:00 --> Final output sent to browser
DEBUG - 2022-02-08 23:45:00 --> Total execution time: 0.0214
ERROR - 2022-02-08 23:46:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-08 23:46:38 --> Config Class Initialized
INFO - 2022-02-08 23:46:38 --> Hooks Class Initialized
DEBUG - 2022-02-08 23:46:38 --> UTF-8 Support Enabled
INFO - 2022-02-08 23:46:38 --> Utf8 Class Initialized
INFO - 2022-02-08 23:46:38 --> URI Class Initialized
DEBUG - 2022-02-08 23:46:38 --> No URI present. Default controller set.
INFO - 2022-02-08 23:46:38 --> Router Class Initialized
INFO - 2022-02-08 23:46:38 --> Output Class Initialized
INFO - 2022-02-08 23:46:38 --> Security Class Initialized
DEBUG - 2022-02-08 23:46:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-08 23:46:38 --> Input Class Initialized
INFO - 2022-02-08 23:46:38 --> Language Class Initialized
INFO - 2022-02-08 23:46:38 --> Loader Class Initialized
INFO - 2022-02-08 23:46:38 --> Helper loaded: url_helper
INFO - 2022-02-08 23:46:38 --> Helper loaded: form_helper
INFO - 2022-02-08 23:46:38 --> Helper loaded: common_helper
INFO - 2022-02-08 23:46:38 --> Database Driver Class Initialized
DEBUG - 2022-02-08 23:46:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-08 23:46:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-08 23:46:38 --> Controller Class Initialized
INFO - 2022-02-08 23:46:38 --> Form Validation Class Initialized
DEBUG - 2022-02-08 23:46:38 --> Encrypt Class Initialized
DEBUG - 2022-02-08 23:46:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 23:46:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-08 23:46:38 --> Email Class Initialized
INFO - 2022-02-08 23:46:38 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-08 23:46:38 --> Calendar Class Initialized
INFO - 2022-02-08 23:46:38 --> Model "Login_model" initialized
INFO - 2022-02-08 23:46:38 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-08 23:46:38 --> Final output sent to browser
DEBUG - 2022-02-08 23:46:38 --> Total execution time: 0.0233
