<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-01-24 03:11:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-24 03:11:42 --> Config Class Initialized
INFO - 2022-01-24 03:11:42 --> Hooks Class Initialized
DEBUG - 2022-01-24 03:11:42 --> UTF-8 Support Enabled
INFO - 2022-01-24 03:11:42 --> Utf8 Class Initialized
INFO - 2022-01-24 03:11:42 --> URI Class Initialized
DEBUG - 2022-01-24 03:11:42 --> No URI present. Default controller set.
INFO - 2022-01-24 03:11:42 --> Router Class Initialized
INFO - 2022-01-24 03:11:42 --> Output Class Initialized
INFO - 2022-01-24 03:11:42 --> Security Class Initialized
DEBUG - 2022-01-24 03:11:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-24 03:11:42 --> Input Class Initialized
INFO - 2022-01-24 03:11:42 --> Language Class Initialized
INFO - 2022-01-24 03:11:42 --> Loader Class Initialized
INFO - 2022-01-24 03:11:42 --> Helper loaded: url_helper
INFO - 2022-01-24 03:11:42 --> Helper loaded: form_helper
INFO - 2022-01-24 03:11:42 --> Helper loaded: common_helper
INFO - 2022-01-24 03:11:42 --> Database Driver Class Initialized
DEBUG - 2022-01-24 03:11:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-24 03:11:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-24 03:11:42 --> Controller Class Initialized
INFO - 2022-01-24 03:11:42 --> Form Validation Class Initialized
DEBUG - 2022-01-24 03:11:42 --> Encrypt Class Initialized
DEBUG - 2022-01-24 03:11:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-24 03:11:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-24 03:11:42 --> Email Class Initialized
INFO - 2022-01-24 03:11:42 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-24 03:11:42 --> Calendar Class Initialized
INFO - 2022-01-24 03:11:42 --> Model "Login_model" initialized
INFO - 2022-01-24 03:11:42 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-24 03:11:42 --> Final output sent to browser
DEBUG - 2022-01-24 03:11:42 --> Total execution time: 0.0235
ERROR - 2022-01-24 03:14:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-24 03:14:38 --> Config Class Initialized
INFO - 2022-01-24 03:14:38 --> Hooks Class Initialized
DEBUG - 2022-01-24 03:14:38 --> UTF-8 Support Enabled
INFO - 2022-01-24 03:14:38 --> Utf8 Class Initialized
INFO - 2022-01-24 03:14:38 --> URI Class Initialized
DEBUG - 2022-01-24 03:14:38 --> No URI present. Default controller set.
INFO - 2022-01-24 03:14:38 --> Router Class Initialized
INFO - 2022-01-24 03:14:38 --> Output Class Initialized
INFO - 2022-01-24 03:14:38 --> Security Class Initialized
DEBUG - 2022-01-24 03:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-24 03:14:38 --> Input Class Initialized
INFO - 2022-01-24 03:14:38 --> Language Class Initialized
INFO - 2022-01-24 03:14:38 --> Loader Class Initialized
INFO - 2022-01-24 03:14:38 --> Helper loaded: url_helper
INFO - 2022-01-24 03:14:38 --> Helper loaded: form_helper
INFO - 2022-01-24 03:14:38 --> Helper loaded: common_helper
INFO - 2022-01-24 03:14:38 --> Database Driver Class Initialized
DEBUG - 2022-01-24 03:14:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-24 03:14:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-24 03:14:38 --> Controller Class Initialized
INFO - 2022-01-24 03:14:38 --> Form Validation Class Initialized
DEBUG - 2022-01-24 03:14:38 --> Encrypt Class Initialized
DEBUG - 2022-01-24 03:14:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-24 03:14:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-24 03:14:38 --> Email Class Initialized
INFO - 2022-01-24 03:14:38 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-24 03:14:38 --> Calendar Class Initialized
INFO - 2022-01-24 03:14:38 --> Model "Login_model" initialized
INFO - 2022-01-24 03:14:38 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-24 03:14:38 --> Final output sent to browser
DEBUG - 2022-01-24 03:14:38 --> Total execution time: 0.0289
ERROR - 2022-01-24 08:25:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-24 08:25:43 --> Config Class Initialized
INFO - 2022-01-24 08:25:43 --> Hooks Class Initialized
DEBUG - 2022-01-24 08:25:43 --> UTF-8 Support Enabled
INFO - 2022-01-24 08:25:43 --> Utf8 Class Initialized
INFO - 2022-01-24 08:25:43 --> URI Class Initialized
DEBUG - 2022-01-24 08:25:43 --> No URI present. Default controller set.
INFO - 2022-01-24 08:25:43 --> Router Class Initialized
INFO - 2022-01-24 08:25:43 --> Output Class Initialized
INFO - 2022-01-24 08:25:43 --> Security Class Initialized
DEBUG - 2022-01-24 08:25:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-24 08:25:43 --> Input Class Initialized
INFO - 2022-01-24 08:25:43 --> Language Class Initialized
INFO - 2022-01-24 08:25:43 --> Loader Class Initialized
INFO - 2022-01-24 08:25:43 --> Helper loaded: url_helper
INFO - 2022-01-24 08:25:43 --> Helper loaded: form_helper
INFO - 2022-01-24 08:25:43 --> Helper loaded: common_helper
INFO - 2022-01-24 08:25:43 --> Database Driver Class Initialized
DEBUG - 2022-01-24 08:25:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-24 08:25:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-24 08:25:43 --> Controller Class Initialized
INFO - 2022-01-24 08:25:43 --> Form Validation Class Initialized
DEBUG - 2022-01-24 08:25:43 --> Encrypt Class Initialized
DEBUG - 2022-01-24 08:25:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-24 08:25:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-24 08:25:43 --> Email Class Initialized
INFO - 2022-01-24 08:25:43 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-24 08:25:43 --> Calendar Class Initialized
INFO - 2022-01-24 08:25:43 --> Model "Login_model" initialized
INFO - 2022-01-24 08:25:43 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-24 08:25:43 --> Final output sent to browser
DEBUG - 2022-01-24 08:25:43 --> Total execution time: 0.0292
ERROR - 2022-01-24 14:20:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-24 14:20:04 --> Config Class Initialized
INFO - 2022-01-24 14:20:04 --> Hooks Class Initialized
DEBUG - 2022-01-24 14:20:04 --> UTF-8 Support Enabled
INFO - 2022-01-24 14:20:04 --> Utf8 Class Initialized
INFO - 2022-01-24 14:20:04 --> URI Class Initialized
DEBUG - 2022-01-24 14:20:04 --> No URI present. Default controller set.
INFO - 2022-01-24 14:20:04 --> Router Class Initialized
INFO - 2022-01-24 14:20:04 --> Output Class Initialized
INFO - 2022-01-24 14:20:04 --> Security Class Initialized
DEBUG - 2022-01-24 14:20:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-24 14:20:04 --> Input Class Initialized
INFO - 2022-01-24 14:20:04 --> Language Class Initialized
INFO - 2022-01-24 14:20:04 --> Loader Class Initialized
INFO - 2022-01-24 14:20:04 --> Helper loaded: url_helper
INFO - 2022-01-24 14:20:04 --> Helper loaded: form_helper
INFO - 2022-01-24 14:20:04 --> Helper loaded: common_helper
INFO - 2022-01-24 14:20:04 --> Database Driver Class Initialized
DEBUG - 2022-01-24 14:20:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-24 14:20:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-24 14:20:04 --> Controller Class Initialized
INFO - 2022-01-24 14:20:04 --> Form Validation Class Initialized
DEBUG - 2022-01-24 14:20:04 --> Encrypt Class Initialized
DEBUG - 2022-01-24 14:20:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-24 14:20:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-24 14:20:04 --> Email Class Initialized
INFO - 2022-01-24 14:20:04 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-24 14:20:04 --> Calendar Class Initialized
INFO - 2022-01-24 14:20:04 --> Model "Login_model" initialized
INFO - 2022-01-24 14:20:04 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-24 14:20:04 --> Final output sent to browser
DEBUG - 2022-01-24 14:20:04 --> Total execution time: 0.0389
ERROR - 2022-01-24 14:20:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-24 14:20:05 --> Config Class Initialized
INFO - 2022-01-24 14:20:05 --> Hooks Class Initialized
DEBUG - 2022-01-24 14:20:05 --> UTF-8 Support Enabled
INFO - 2022-01-24 14:20:05 --> Utf8 Class Initialized
INFO - 2022-01-24 14:20:05 --> URI Class Initialized
INFO - 2022-01-24 14:20:05 --> Router Class Initialized
INFO - 2022-01-24 14:20:05 --> Output Class Initialized
INFO - 2022-01-24 14:20:05 --> Security Class Initialized
DEBUG - 2022-01-24 14:20:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-24 14:20:05 --> Input Class Initialized
INFO - 2022-01-24 14:20:05 --> Language Class Initialized
ERROR - 2022-01-24 14:20:05 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2022-01-24 14:20:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-24 14:20:13 --> Config Class Initialized
INFO - 2022-01-24 14:20:13 --> Hooks Class Initialized
DEBUG - 2022-01-24 14:20:13 --> UTF-8 Support Enabled
INFO - 2022-01-24 14:20:13 --> Utf8 Class Initialized
INFO - 2022-01-24 14:20:13 --> URI Class Initialized
INFO - 2022-01-24 14:20:13 --> Router Class Initialized
INFO - 2022-01-24 14:20:13 --> Output Class Initialized
INFO - 2022-01-24 14:20:13 --> Security Class Initialized
DEBUG - 2022-01-24 14:20:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-24 14:20:13 --> Input Class Initialized
INFO - 2022-01-24 14:20:13 --> Language Class Initialized
INFO - 2022-01-24 14:20:13 --> Loader Class Initialized
INFO - 2022-01-24 14:20:13 --> Helper loaded: url_helper
INFO - 2022-01-24 14:20:13 --> Helper loaded: form_helper
INFO - 2022-01-24 14:20:13 --> Helper loaded: common_helper
INFO - 2022-01-24 14:20:13 --> Database Driver Class Initialized
DEBUG - 2022-01-24 14:20:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-24 14:20:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-24 14:20:13 --> Controller Class Initialized
INFO - 2022-01-24 14:20:13 --> Form Validation Class Initialized
DEBUG - 2022-01-24 14:20:13 --> Encrypt Class Initialized
DEBUG - 2022-01-24 14:20:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-24 14:20:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-24 14:20:13 --> Email Class Initialized
INFO - 2022-01-24 14:20:13 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-24 14:20:13 --> Calendar Class Initialized
INFO - 2022-01-24 14:20:13 --> Model "Login_model" initialized
INFO - 2022-01-24 14:20:13 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-24 14:20:13 --> Final output sent to browser
DEBUG - 2022-01-24 14:20:13 --> Total execution time: 0.0289
ERROR - 2022-01-24 14:20:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-24 14:20:13 --> Config Class Initialized
INFO - 2022-01-24 14:20:13 --> Hooks Class Initialized
DEBUG - 2022-01-24 14:20:13 --> UTF-8 Support Enabled
INFO - 2022-01-24 14:20:13 --> Utf8 Class Initialized
INFO - 2022-01-24 14:20:13 --> URI Class Initialized
DEBUG - 2022-01-24 14:20:13 --> No URI present. Default controller set.
INFO - 2022-01-24 14:20:13 --> Router Class Initialized
INFO - 2022-01-24 14:20:13 --> Output Class Initialized
INFO - 2022-01-24 14:20:13 --> Security Class Initialized
DEBUG - 2022-01-24 14:20:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-24 14:20:13 --> Input Class Initialized
INFO - 2022-01-24 14:20:13 --> Language Class Initialized
INFO - 2022-01-24 14:20:13 --> Loader Class Initialized
INFO - 2022-01-24 14:20:13 --> Helper loaded: url_helper
INFO - 2022-01-24 14:20:13 --> Helper loaded: form_helper
INFO - 2022-01-24 14:20:13 --> Helper loaded: common_helper
INFO - 2022-01-24 14:20:13 --> Database Driver Class Initialized
DEBUG - 2022-01-24 14:20:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-24 14:20:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-24 14:20:13 --> Controller Class Initialized
INFO - 2022-01-24 14:20:13 --> Form Validation Class Initialized
DEBUG - 2022-01-24 14:20:13 --> Encrypt Class Initialized
DEBUG - 2022-01-24 14:20:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-24 14:20:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-24 14:20:14 --> Email Class Initialized
INFO - 2022-01-24 14:20:14 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-24 14:20:14 --> Calendar Class Initialized
INFO - 2022-01-24 14:20:14 --> Model "Login_model" initialized
INFO - 2022-01-24 14:20:14 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-24 14:20:14 --> Final output sent to browser
DEBUG - 2022-01-24 14:20:14 --> Total execution time: 0.0297
ERROR - 2022-01-24 14:20:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-24 14:20:14 --> Config Class Initialized
INFO - 2022-01-24 14:20:14 --> Hooks Class Initialized
DEBUG - 2022-01-24 14:20:14 --> UTF-8 Support Enabled
INFO - 2022-01-24 14:20:14 --> Utf8 Class Initialized
INFO - 2022-01-24 14:20:14 --> URI Class Initialized
INFO - 2022-01-24 14:20:14 --> Router Class Initialized
INFO - 2022-01-24 14:20:14 --> Output Class Initialized
INFO - 2022-01-24 14:20:14 --> Security Class Initialized
DEBUG - 2022-01-24 14:20:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-24 14:20:14 --> Input Class Initialized
INFO - 2022-01-24 14:20:14 --> Language Class Initialized
INFO - 2022-01-24 14:20:14 --> Loader Class Initialized
INFO - 2022-01-24 14:20:14 --> Helper loaded: url_helper
INFO - 2022-01-24 14:20:14 --> Helper loaded: form_helper
INFO - 2022-01-24 14:20:14 --> Helper loaded: common_helper
INFO - 2022-01-24 14:20:14 --> Database Driver Class Initialized
DEBUG - 2022-01-24 14:20:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-24 14:20:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-24 14:20:14 --> Controller Class Initialized
INFO - 2022-01-24 14:20:14 --> Form Validation Class Initialized
DEBUG - 2022-01-24 14:20:14 --> Encrypt Class Initialized
DEBUG - 2022-01-24 14:20:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-24 14:20:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-24 14:20:14 --> Email Class Initialized
INFO - 2022-01-24 14:20:14 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-24 14:20:14 --> Calendar Class Initialized
INFO - 2022-01-24 14:20:14 --> Model "Login_model" initialized
ERROR - 2022-01-24 14:20:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-24 14:20:15 --> Config Class Initialized
INFO - 2022-01-24 14:20:15 --> Hooks Class Initialized
DEBUG - 2022-01-24 14:20:15 --> UTF-8 Support Enabled
INFO - 2022-01-24 14:20:15 --> Utf8 Class Initialized
INFO - 2022-01-24 14:20:15 --> URI Class Initialized
INFO - 2022-01-24 14:20:15 --> Router Class Initialized
INFO - 2022-01-24 14:20:15 --> Output Class Initialized
INFO - 2022-01-24 14:20:15 --> Security Class Initialized
DEBUG - 2022-01-24 14:20:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-24 14:20:15 --> Input Class Initialized
INFO - 2022-01-24 14:20:15 --> Language Class Initialized
INFO - 2022-01-24 14:20:15 --> Loader Class Initialized
INFO - 2022-01-24 14:20:15 --> Helper loaded: url_helper
INFO - 2022-01-24 14:20:15 --> Helper loaded: form_helper
INFO - 2022-01-24 14:20:15 --> Helper loaded: common_helper
INFO - 2022-01-24 14:20:15 --> Database Driver Class Initialized
DEBUG - 2022-01-24 14:20:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-24 14:20:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-24 14:20:15 --> Controller Class Initialized
INFO - 2022-01-24 14:20:15 --> Form Validation Class Initialized
DEBUG - 2022-01-24 14:20:15 --> Encrypt Class Initialized
DEBUG - 2022-01-24 14:20:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-24 14:20:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-24 14:20:15 --> Email Class Initialized
INFO - 2022-01-24 14:20:15 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-24 14:20:15 --> Calendar Class Initialized
INFO - 2022-01-24 14:20:15 --> Model "Login_model" initialized
ERROR - 2022-01-24 14:24:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-24 14:24:43 --> Config Class Initialized
INFO - 2022-01-24 14:24:43 --> Hooks Class Initialized
DEBUG - 2022-01-24 14:24:43 --> UTF-8 Support Enabled
INFO - 2022-01-24 14:24:43 --> Utf8 Class Initialized
INFO - 2022-01-24 14:24:43 --> URI Class Initialized
DEBUG - 2022-01-24 14:24:43 --> No URI present. Default controller set.
INFO - 2022-01-24 14:24:43 --> Router Class Initialized
INFO - 2022-01-24 14:24:43 --> Output Class Initialized
INFO - 2022-01-24 14:24:43 --> Security Class Initialized
DEBUG - 2022-01-24 14:24:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-24 14:24:43 --> Input Class Initialized
INFO - 2022-01-24 14:24:43 --> Language Class Initialized
INFO - 2022-01-24 14:24:43 --> Loader Class Initialized
INFO - 2022-01-24 14:24:43 --> Helper loaded: url_helper
INFO - 2022-01-24 14:24:43 --> Helper loaded: form_helper
INFO - 2022-01-24 14:24:43 --> Helper loaded: common_helper
INFO - 2022-01-24 14:24:43 --> Database Driver Class Initialized
DEBUG - 2022-01-24 14:24:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-24 14:24:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-24 14:24:43 --> Controller Class Initialized
INFO - 2022-01-24 14:24:43 --> Form Validation Class Initialized
DEBUG - 2022-01-24 14:24:43 --> Encrypt Class Initialized
DEBUG - 2022-01-24 14:24:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-24 14:24:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-24 14:24:43 --> Email Class Initialized
INFO - 2022-01-24 14:24:43 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-24 14:24:43 --> Calendar Class Initialized
INFO - 2022-01-24 14:24:43 --> Model "Login_model" initialized
INFO - 2022-01-24 14:24:43 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-24 14:24:43 --> Final output sent to browser
DEBUG - 2022-01-24 14:24:43 --> Total execution time: 0.0535
ERROR - 2022-01-24 14:25:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-24 14:25:09 --> Config Class Initialized
INFO - 2022-01-24 14:25:09 --> Hooks Class Initialized
DEBUG - 2022-01-24 14:25:09 --> UTF-8 Support Enabled
INFO - 2022-01-24 14:25:09 --> Utf8 Class Initialized
INFO - 2022-01-24 14:25:09 --> URI Class Initialized
DEBUG - 2022-01-24 14:25:09 --> No URI present. Default controller set.
INFO - 2022-01-24 14:25:09 --> Router Class Initialized
INFO - 2022-01-24 14:25:09 --> Output Class Initialized
INFO - 2022-01-24 14:25:09 --> Security Class Initialized
DEBUG - 2022-01-24 14:25:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-24 14:25:09 --> Input Class Initialized
INFO - 2022-01-24 14:25:09 --> Language Class Initialized
INFO - 2022-01-24 14:25:09 --> Loader Class Initialized
INFO - 2022-01-24 14:25:09 --> Helper loaded: url_helper
INFO - 2022-01-24 14:25:09 --> Helper loaded: form_helper
INFO - 2022-01-24 14:25:09 --> Helper loaded: common_helper
INFO - 2022-01-24 14:25:09 --> Database Driver Class Initialized
DEBUG - 2022-01-24 14:25:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-24 14:25:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-24 14:25:09 --> Controller Class Initialized
INFO - 2022-01-24 14:25:09 --> Form Validation Class Initialized
DEBUG - 2022-01-24 14:25:09 --> Encrypt Class Initialized
DEBUG - 2022-01-24 14:25:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-24 14:25:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-24 14:25:09 --> Email Class Initialized
INFO - 2022-01-24 14:25:09 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-24 14:25:09 --> Calendar Class Initialized
INFO - 2022-01-24 14:25:09 --> Model "Login_model" initialized
INFO - 2022-01-24 14:25:09 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-24 14:25:09 --> Final output sent to browser
DEBUG - 2022-01-24 14:25:09 --> Total execution time: 0.0234
ERROR - 2022-01-24 14:25:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-24 14:25:10 --> Config Class Initialized
INFO - 2022-01-24 14:25:10 --> Hooks Class Initialized
DEBUG - 2022-01-24 14:25:10 --> UTF-8 Support Enabled
INFO - 2022-01-24 14:25:10 --> Utf8 Class Initialized
INFO - 2022-01-24 14:25:10 --> URI Class Initialized
DEBUG - 2022-01-24 14:25:10 --> No URI present. Default controller set.
INFO - 2022-01-24 14:25:10 --> Router Class Initialized
INFO - 2022-01-24 14:25:10 --> Output Class Initialized
INFO - 2022-01-24 14:25:10 --> Security Class Initialized
DEBUG - 2022-01-24 14:25:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-24 14:25:10 --> Input Class Initialized
INFO - 2022-01-24 14:25:10 --> Language Class Initialized
INFO - 2022-01-24 14:25:10 --> Loader Class Initialized
INFO - 2022-01-24 14:25:10 --> Helper loaded: url_helper
INFO - 2022-01-24 14:25:10 --> Helper loaded: form_helper
INFO - 2022-01-24 14:25:10 --> Helper loaded: common_helper
INFO - 2022-01-24 14:25:10 --> Database Driver Class Initialized
DEBUG - 2022-01-24 14:25:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-24 14:25:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-24 14:25:10 --> Controller Class Initialized
INFO - 2022-01-24 14:25:10 --> Form Validation Class Initialized
DEBUG - 2022-01-24 14:25:10 --> Encrypt Class Initialized
DEBUG - 2022-01-24 14:25:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-24 14:25:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-24 14:25:10 --> Email Class Initialized
INFO - 2022-01-24 14:25:10 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-24 14:25:10 --> Calendar Class Initialized
INFO - 2022-01-24 14:25:10 --> Model "Login_model" initialized
INFO - 2022-01-24 14:25:10 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-24 14:25:10 --> Final output sent to browser
DEBUG - 2022-01-24 14:25:10 --> Total execution time: 0.0242
ERROR - 2022-01-24 14:25:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-24 14:25:32 --> Config Class Initialized
INFO - 2022-01-24 14:25:32 --> Hooks Class Initialized
DEBUG - 2022-01-24 14:25:32 --> UTF-8 Support Enabled
INFO - 2022-01-24 14:25:32 --> Utf8 Class Initialized
INFO - 2022-01-24 14:25:32 --> URI Class Initialized
DEBUG - 2022-01-24 14:25:32 --> No URI present. Default controller set.
INFO - 2022-01-24 14:25:32 --> Router Class Initialized
INFO - 2022-01-24 14:25:32 --> Output Class Initialized
INFO - 2022-01-24 14:25:32 --> Security Class Initialized
DEBUG - 2022-01-24 14:25:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-24 14:25:32 --> Input Class Initialized
INFO - 2022-01-24 14:25:32 --> Language Class Initialized
INFO - 2022-01-24 14:25:32 --> Loader Class Initialized
INFO - 2022-01-24 14:25:32 --> Helper loaded: url_helper
INFO - 2022-01-24 14:25:32 --> Helper loaded: form_helper
INFO - 2022-01-24 14:25:32 --> Helper loaded: common_helper
INFO - 2022-01-24 14:25:32 --> Database Driver Class Initialized
DEBUG - 2022-01-24 14:25:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-24 14:25:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-24 14:25:32 --> Controller Class Initialized
INFO - 2022-01-24 14:25:32 --> Form Validation Class Initialized
DEBUG - 2022-01-24 14:25:32 --> Encrypt Class Initialized
DEBUG - 2022-01-24 14:25:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-24 14:25:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-24 14:25:32 --> Email Class Initialized
INFO - 2022-01-24 14:25:32 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-24 14:25:32 --> Calendar Class Initialized
INFO - 2022-01-24 14:25:32 --> Model "Login_model" initialized
INFO - 2022-01-24 14:25:32 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-24 14:25:32 --> Final output sent to browser
DEBUG - 2022-01-24 14:25:32 --> Total execution time: 0.0231
ERROR - 2022-01-24 15:46:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-24 15:46:44 --> Config Class Initialized
INFO - 2022-01-24 15:46:44 --> Hooks Class Initialized
DEBUG - 2022-01-24 15:46:44 --> UTF-8 Support Enabled
INFO - 2022-01-24 15:46:44 --> Utf8 Class Initialized
INFO - 2022-01-24 15:46:44 --> URI Class Initialized
DEBUG - 2022-01-24 15:46:44 --> No URI present. Default controller set.
INFO - 2022-01-24 15:46:44 --> Router Class Initialized
INFO - 2022-01-24 15:46:44 --> Output Class Initialized
INFO - 2022-01-24 15:46:44 --> Security Class Initialized
DEBUG - 2022-01-24 15:46:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-24 15:46:44 --> Input Class Initialized
INFO - 2022-01-24 15:46:44 --> Language Class Initialized
INFO - 2022-01-24 15:46:44 --> Loader Class Initialized
INFO - 2022-01-24 15:46:44 --> Helper loaded: url_helper
INFO - 2022-01-24 15:46:44 --> Helper loaded: form_helper
INFO - 2022-01-24 15:46:44 --> Helper loaded: common_helper
INFO - 2022-01-24 15:46:44 --> Database Driver Class Initialized
DEBUG - 2022-01-24 15:46:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-24 15:46:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-24 15:46:44 --> Controller Class Initialized
INFO - 2022-01-24 15:46:44 --> Form Validation Class Initialized
DEBUG - 2022-01-24 15:46:44 --> Encrypt Class Initialized
DEBUG - 2022-01-24 15:46:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-24 15:46:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-24 15:46:44 --> Email Class Initialized
INFO - 2022-01-24 15:46:44 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-24 15:46:44 --> Calendar Class Initialized
INFO - 2022-01-24 15:46:44 --> Model "Login_model" initialized
INFO - 2022-01-24 15:46:44 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-24 15:46:44 --> Final output sent to browser
DEBUG - 2022-01-24 15:46:44 --> Total execution time: 0.0396
ERROR - 2022-01-24 16:18:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-24 16:18:45 --> Config Class Initialized
INFO - 2022-01-24 16:18:45 --> Hooks Class Initialized
DEBUG - 2022-01-24 16:18:45 --> UTF-8 Support Enabled
INFO - 2022-01-24 16:18:45 --> Utf8 Class Initialized
INFO - 2022-01-24 16:18:45 --> URI Class Initialized
DEBUG - 2022-01-24 16:18:45 --> No URI present. Default controller set.
INFO - 2022-01-24 16:18:45 --> Router Class Initialized
INFO - 2022-01-24 16:18:45 --> Output Class Initialized
INFO - 2022-01-24 16:18:45 --> Security Class Initialized
DEBUG - 2022-01-24 16:18:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-24 16:18:45 --> Input Class Initialized
INFO - 2022-01-24 16:18:45 --> Language Class Initialized
INFO - 2022-01-24 16:18:45 --> Loader Class Initialized
INFO - 2022-01-24 16:18:45 --> Helper loaded: url_helper
INFO - 2022-01-24 16:18:45 --> Helper loaded: form_helper
INFO - 2022-01-24 16:18:45 --> Helper loaded: common_helper
INFO - 2022-01-24 16:18:45 --> Database Driver Class Initialized
DEBUG - 2022-01-24 16:18:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-24 16:18:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-24 16:18:45 --> Controller Class Initialized
INFO - 2022-01-24 16:18:45 --> Form Validation Class Initialized
DEBUG - 2022-01-24 16:18:45 --> Encrypt Class Initialized
DEBUG - 2022-01-24 16:18:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-24 16:18:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-24 16:18:45 --> Email Class Initialized
INFO - 2022-01-24 16:18:45 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-24 16:18:45 --> Calendar Class Initialized
INFO - 2022-01-24 16:18:45 --> Model "Login_model" initialized
INFO - 2022-01-24 16:18:45 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-24 16:18:45 --> Final output sent to browser
DEBUG - 2022-01-24 16:18:45 --> Total execution time: 0.0415
