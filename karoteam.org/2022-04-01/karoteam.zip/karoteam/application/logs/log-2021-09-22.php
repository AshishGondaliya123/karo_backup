<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-09-22 10:53:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-22 10:53:07 --> Config Class Initialized
INFO - 2021-09-22 10:53:07 --> Hooks Class Initialized
DEBUG - 2021-09-22 10:53:07 --> UTF-8 Support Enabled
INFO - 2021-09-22 10:53:07 --> Utf8 Class Initialized
INFO - 2021-09-22 10:53:07 --> URI Class Initialized
DEBUG - 2021-09-22 10:53:07 --> No URI present. Default controller set.
INFO - 2021-09-22 10:53:07 --> Router Class Initialized
INFO - 2021-09-22 10:53:07 --> Output Class Initialized
INFO - 2021-09-22 10:53:07 --> Security Class Initialized
DEBUG - 2021-09-22 10:53:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-22 10:53:07 --> Input Class Initialized
INFO - 2021-09-22 10:53:07 --> Language Class Initialized
INFO - 2021-09-22 10:53:07 --> Loader Class Initialized
INFO - 2021-09-22 10:53:07 --> Helper loaded: url_helper
INFO - 2021-09-22 10:53:07 --> Helper loaded: form_helper
INFO - 2021-09-22 10:53:07 --> Helper loaded: common_helper
INFO - 2021-09-22 10:53:07 --> Database Driver Class Initialized
DEBUG - 2021-09-22 10:53:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-22 10:53:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-22 10:53:07 --> Controller Class Initialized
INFO - 2021-09-22 10:53:07 --> Form Validation Class Initialized
DEBUG - 2021-09-22 10:53:07 --> Encrypt Class Initialized
DEBUG - 2021-09-22 10:53:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-09-22 10:53:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-09-22 10:53:07 --> Email Class Initialized
INFO - 2021-09-22 10:53:07 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-09-22 10:53:07 --> Calendar Class Initialized
INFO - 2021-09-22 10:53:07 --> Model "Login_model" initialized
INFO - 2021-09-22 10:53:07 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-09-22 10:53:07 --> Final output sent to browser
DEBUG - 2021-09-22 10:53:07 --> Total execution time: 0.0503
ERROR - 2021-09-22 10:53:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-22 10:53:09 --> Config Class Initialized
INFO - 2021-09-22 10:53:09 --> Hooks Class Initialized
DEBUG - 2021-09-22 10:53:09 --> UTF-8 Support Enabled
INFO - 2021-09-22 10:53:09 --> Utf8 Class Initialized
INFO - 2021-09-22 10:53:09 --> URI Class Initialized
DEBUG - 2021-09-22 10:53:09 --> No URI present. Default controller set.
INFO - 2021-09-22 10:53:09 --> Router Class Initialized
INFO - 2021-09-22 10:53:09 --> Output Class Initialized
INFO - 2021-09-22 10:53:09 --> Security Class Initialized
DEBUG - 2021-09-22 10:53:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-22 10:53:09 --> Input Class Initialized
INFO - 2021-09-22 10:53:09 --> Language Class Initialized
INFO - 2021-09-22 10:53:09 --> Loader Class Initialized
INFO - 2021-09-22 10:53:09 --> Helper loaded: url_helper
INFO - 2021-09-22 10:53:09 --> Helper loaded: form_helper
INFO - 2021-09-22 10:53:09 --> Helper loaded: common_helper
INFO - 2021-09-22 10:53:09 --> Database Driver Class Initialized
DEBUG - 2021-09-22 10:53:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-22 10:53:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-22 10:53:09 --> Controller Class Initialized
INFO - 2021-09-22 10:53:09 --> Form Validation Class Initialized
DEBUG - 2021-09-22 10:53:09 --> Encrypt Class Initialized
DEBUG - 2021-09-22 10:53:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-09-22 10:53:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-09-22 10:53:09 --> Email Class Initialized
INFO - 2021-09-22 10:53:09 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-09-22 10:53:09 --> Calendar Class Initialized
INFO - 2021-09-22 10:53:09 --> Model "Login_model" initialized
INFO - 2021-09-22 10:53:09 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-09-22 10:53:09 --> Final output sent to browser
DEBUG - 2021-09-22 10:53:09 --> Total execution time: 0.0189
ERROR - 2021-09-22 14:01:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-22 14:01:50 --> Config Class Initialized
INFO - 2021-09-22 14:01:50 --> Hooks Class Initialized
DEBUG - 2021-09-22 14:01:50 --> UTF-8 Support Enabled
INFO - 2021-09-22 14:01:50 --> Utf8 Class Initialized
INFO - 2021-09-22 14:01:50 --> URI Class Initialized
DEBUG - 2021-09-22 14:01:50 --> No URI present. Default controller set.
INFO - 2021-09-22 14:01:50 --> Router Class Initialized
INFO - 2021-09-22 14:01:50 --> Output Class Initialized
INFO - 2021-09-22 14:01:50 --> Security Class Initialized
DEBUG - 2021-09-22 14:01:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-22 14:01:50 --> Input Class Initialized
INFO - 2021-09-22 14:01:50 --> Language Class Initialized
INFO - 2021-09-22 14:01:50 --> Loader Class Initialized
INFO - 2021-09-22 14:01:50 --> Helper loaded: url_helper
INFO - 2021-09-22 14:01:50 --> Helper loaded: form_helper
INFO - 2021-09-22 14:01:50 --> Helper loaded: common_helper
INFO - 2021-09-22 14:01:50 --> Database Driver Class Initialized
DEBUG - 2021-09-22 14:01:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-22 14:01:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-22 14:01:50 --> Controller Class Initialized
INFO - 2021-09-22 14:01:50 --> Form Validation Class Initialized
DEBUG - 2021-09-22 14:01:50 --> Encrypt Class Initialized
DEBUG - 2021-09-22 14:01:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-09-22 14:01:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-09-22 14:01:50 --> Email Class Initialized
INFO - 2021-09-22 14:01:50 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-09-22 14:01:50 --> Calendar Class Initialized
INFO - 2021-09-22 14:01:50 --> Model "Login_model" initialized
INFO - 2021-09-22 14:01:50 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-09-22 14:01:50 --> Final output sent to browser
DEBUG - 2021-09-22 14:01:50 --> Total execution time: 0.0600
ERROR - 2021-09-22 14:01:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-22 14:01:50 --> Config Class Initialized
INFO - 2021-09-22 14:01:50 --> Hooks Class Initialized
DEBUG - 2021-09-22 14:01:50 --> UTF-8 Support Enabled
INFO - 2021-09-22 14:01:50 --> Utf8 Class Initialized
INFO - 2021-09-22 14:01:50 --> URI Class Initialized
DEBUG - 2021-09-22 14:01:50 --> No URI present. Default controller set.
INFO - 2021-09-22 14:01:50 --> Router Class Initialized
INFO - 2021-09-22 14:01:50 --> Output Class Initialized
INFO - 2021-09-22 14:01:50 --> Security Class Initialized
DEBUG - 2021-09-22 14:01:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-22 14:01:50 --> Input Class Initialized
INFO - 2021-09-22 14:01:50 --> Language Class Initialized
INFO - 2021-09-22 14:01:50 --> Loader Class Initialized
INFO - 2021-09-22 14:01:50 --> Helper loaded: url_helper
INFO - 2021-09-22 14:01:50 --> Helper loaded: form_helper
INFO - 2021-09-22 14:01:50 --> Helper loaded: common_helper
INFO - 2021-09-22 14:01:50 --> Database Driver Class Initialized
DEBUG - 2021-09-22 14:01:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-22 14:01:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-22 14:01:50 --> Controller Class Initialized
INFO - 2021-09-22 14:01:50 --> Form Validation Class Initialized
DEBUG - 2021-09-22 14:01:50 --> Encrypt Class Initialized
DEBUG - 2021-09-22 14:01:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-09-22 14:01:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-09-22 14:01:50 --> Email Class Initialized
INFO - 2021-09-22 14:01:50 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-09-22 14:01:50 --> Calendar Class Initialized
INFO - 2021-09-22 14:01:50 --> Model "Login_model" initialized
INFO - 2021-09-22 14:01:50 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-09-22 14:01:50 --> Final output sent to browser
DEBUG - 2021-09-22 14:01:50 --> Total execution time: 0.0349
ERROR - 2021-09-22 14:01:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-22 14:01:51 --> Config Class Initialized
INFO - 2021-09-22 14:01:51 --> Hooks Class Initialized
DEBUG - 2021-09-22 14:01:51 --> UTF-8 Support Enabled
INFO - 2021-09-22 14:01:51 --> Utf8 Class Initialized
INFO - 2021-09-22 14:01:51 --> URI Class Initialized
INFO - 2021-09-22 14:01:51 --> Router Class Initialized
INFO - 2021-09-22 14:01:51 --> Output Class Initialized
INFO - 2021-09-22 14:01:51 --> Security Class Initialized
DEBUG - 2021-09-22 14:01:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-22 14:01:51 --> Input Class Initialized
INFO - 2021-09-22 14:01:51 --> Language Class Initialized
ERROR - 2021-09-22 14:01:51 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
ERROR - 2021-09-22 14:01:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-22 14:01:51 --> Config Class Initialized
INFO - 2021-09-22 14:01:51 --> Hooks Class Initialized
DEBUG - 2021-09-22 14:01:51 --> UTF-8 Support Enabled
INFO - 2021-09-22 14:01:51 --> Utf8 Class Initialized
INFO - 2021-09-22 14:01:51 --> URI Class Initialized
DEBUG - 2021-09-22 14:01:51 --> No URI present. Default controller set.
INFO - 2021-09-22 14:01:51 --> Router Class Initialized
INFO - 2021-09-22 14:01:51 --> Output Class Initialized
INFO - 2021-09-22 14:01:51 --> Security Class Initialized
DEBUG - 2021-09-22 14:01:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-22 14:01:51 --> Input Class Initialized
INFO - 2021-09-22 14:01:51 --> Language Class Initialized
INFO - 2021-09-22 14:01:51 --> Loader Class Initialized
INFO - 2021-09-22 14:01:51 --> Helper loaded: url_helper
INFO - 2021-09-22 14:01:51 --> Helper loaded: form_helper
INFO - 2021-09-22 14:01:51 --> Helper loaded: common_helper
INFO - 2021-09-22 14:01:51 --> Database Driver Class Initialized
DEBUG - 2021-09-22 14:01:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-22 14:01:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-22 14:01:51 --> Controller Class Initialized
INFO - 2021-09-22 14:01:51 --> Form Validation Class Initialized
DEBUG - 2021-09-22 14:01:51 --> Encrypt Class Initialized
DEBUG - 2021-09-22 14:01:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-09-22 14:01:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-09-22 14:01:51 --> Email Class Initialized
INFO - 2021-09-22 14:01:51 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-09-22 14:01:51 --> Calendar Class Initialized
INFO - 2021-09-22 14:01:51 --> Model "Login_model" initialized
INFO - 2021-09-22 14:01:51 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-09-22 14:01:51 --> Final output sent to browser
DEBUG - 2021-09-22 14:01:51 --> Total execution time: 0.0224
ERROR - 2021-09-22 14:01:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-22 14:01:51 --> Config Class Initialized
INFO - 2021-09-22 14:01:51 --> Hooks Class Initialized
DEBUG - 2021-09-22 14:01:51 --> UTF-8 Support Enabled
INFO - 2021-09-22 14:01:51 --> Utf8 Class Initialized
INFO - 2021-09-22 14:01:51 --> URI Class Initialized
INFO - 2021-09-22 14:01:51 --> Router Class Initialized
INFO - 2021-09-22 14:01:51 --> Output Class Initialized
INFO - 2021-09-22 14:01:51 --> Security Class Initialized
DEBUG - 2021-09-22 14:01:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-22 14:01:51 --> Input Class Initialized
INFO - 2021-09-22 14:01:51 --> Language Class Initialized
ERROR - 2021-09-22 14:01:51 --> 404 Page Not Found: Blog/wp-includes
ERROR - 2021-09-22 14:01:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-22 14:01:52 --> Config Class Initialized
INFO - 2021-09-22 14:01:52 --> Hooks Class Initialized
DEBUG - 2021-09-22 14:01:52 --> UTF-8 Support Enabled
INFO - 2021-09-22 14:01:52 --> Utf8 Class Initialized
INFO - 2021-09-22 14:01:52 --> URI Class Initialized
INFO - 2021-09-22 14:01:52 --> Router Class Initialized
INFO - 2021-09-22 14:01:52 --> Output Class Initialized
INFO - 2021-09-22 14:01:52 --> Security Class Initialized
DEBUG - 2021-09-22 14:01:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-22 14:01:52 --> Input Class Initialized
INFO - 2021-09-22 14:01:52 --> Language Class Initialized
ERROR - 2021-09-22 14:01:52 --> 404 Page Not Found: Web/wp-includes
ERROR - 2021-09-22 14:01:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-22 14:01:52 --> Config Class Initialized
INFO - 2021-09-22 14:01:52 --> Hooks Class Initialized
DEBUG - 2021-09-22 14:01:52 --> UTF-8 Support Enabled
INFO - 2021-09-22 14:01:52 --> Utf8 Class Initialized
INFO - 2021-09-22 14:01:52 --> URI Class Initialized
INFO - 2021-09-22 14:01:52 --> Router Class Initialized
INFO - 2021-09-22 14:01:52 --> Output Class Initialized
INFO - 2021-09-22 14:01:52 --> Security Class Initialized
DEBUG - 2021-09-22 14:01:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-22 14:01:52 --> Input Class Initialized
INFO - 2021-09-22 14:01:52 --> Language Class Initialized
ERROR - 2021-09-22 14:01:52 --> 404 Page Not Found: Wordpress/wp-includes
ERROR - 2021-09-22 14:01:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-22 14:01:52 --> Config Class Initialized
INFO - 2021-09-22 14:01:52 --> Hooks Class Initialized
DEBUG - 2021-09-22 14:01:52 --> UTF-8 Support Enabled
INFO - 2021-09-22 14:01:52 --> Utf8 Class Initialized
INFO - 2021-09-22 14:01:52 --> URI Class Initialized
INFO - 2021-09-22 14:01:52 --> Router Class Initialized
INFO - 2021-09-22 14:01:52 --> Output Class Initialized
INFO - 2021-09-22 14:01:52 --> Security Class Initialized
DEBUG - 2021-09-22 14:01:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-22 14:01:52 --> Input Class Initialized
INFO - 2021-09-22 14:01:52 --> Language Class Initialized
ERROR - 2021-09-22 14:01:52 --> 404 Page Not Found: Website/wp-includes
ERROR - 2021-09-22 14:01:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-22 14:01:53 --> Config Class Initialized
INFO - 2021-09-22 14:01:53 --> Hooks Class Initialized
DEBUG - 2021-09-22 14:01:53 --> UTF-8 Support Enabled
INFO - 2021-09-22 14:01:53 --> Utf8 Class Initialized
INFO - 2021-09-22 14:01:53 --> URI Class Initialized
INFO - 2021-09-22 14:01:53 --> Router Class Initialized
INFO - 2021-09-22 14:01:53 --> Output Class Initialized
INFO - 2021-09-22 14:01:53 --> Security Class Initialized
DEBUG - 2021-09-22 14:01:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-22 14:01:53 --> Input Class Initialized
INFO - 2021-09-22 14:01:53 --> Language Class Initialized
ERROR - 2021-09-22 14:01:53 --> 404 Page Not Found: Wp/wp-includes
ERROR - 2021-09-22 14:01:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-22 14:01:53 --> Config Class Initialized
INFO - 2021-09-22 14:01:53 --> Hooks Class Initialized
DEBUG - 2021-09-22 14:01:53 --> UTF-8 Support Enabled
INFO - 2021-09-22 14:01:53 --> Utf8 Class Initialized
INFO - 2021-09-22 14:01:53 --> URI Class Initialized
INFO - 2021-09-22 14:01:53 --> Router Class Initialized
INFO - 2021-09-22 14:01:53 --> Output Class Initialized
INFO - 2021-09-22 14:01:53 --> Security Class Initialized
DEBUG - 2021-09-22 14:01:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-22 14:01:53 --> Input Class Initialized
INFO - 2021-09-22 14:01:53 --> Language Class Initialized
ERROR - 2021-09-22 14:01:53 --> 404 Page Not Found: News/wp-includes
ERROR - 2021-09-22 14:01:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-22 14:01:53 --> Config Class Initialized
INFO - 2021-09-22 14:01:53 --> Hooks Class Initialized
DEBUG - 2021-09-22 14:01:53 --> UTF-8 Support Enabled
INFO - 2021-09-22 14:01:53 --> Utf8 Class Initialized
INFO - 2021-09-22 14:01:53 --> URI Class Initialized
INFO - 2021-09-22 14:01:53 --> Router Class Initialized
INFO - 2021-09-22 14:01:53 --> Output Class Initialized
INFO - 2021-09-22 14:01:53 --> Security Class Initialized
DEBUG - 2021-09-22 14:01:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-22 14:01:53 --> Input Class Initialized
INFO - 2021-09-22 14:01:53 --> Language Class Initialized
ERROR - 2021-09-22 14:01:53 --> 404 Page Not Found: 2020/wp-includes
ERROR - 2021-09-22 14:01:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-22 14:01:54 --> Config Class Initialized
INFO - 2021-09-22 14:01:54 --> Hooks Class Initialized
DEBUG - 2021-09-22 14:01:54 --> UTF-8 Support Enabled
INFO - 2021-09-22 14:01:54 --> Utf8 Class Initialized
INFO - 2021-09-22 14:01:54 --> URI Class Initialized
INFO - 2021-09-22 14:01:54 --> Router Class Initialized
INFO - 2021-09-22 14:01:54 --> Output Class Initialized
INFO - 2021-09-22 14:01:54 --> Security Class Initialized
DEBUG - 2021-09-22 14:01:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-22 14:01:54 --> Input Class Initialized
INFO - 2021-09-22 14:01:54 --> Language Class Initialized
ERROR - 2021-09-22 14:01:54 --> 404 Page Not Found: 2019/wp-includes
ERROR - 2021-09-22 14:01:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-22 14:01:54 --> Config Class Initialized
INFO - 2021-09-22 14:01:54 --> Hooks Class Initialized
DEBUG - 2021-09-22 14:01:54 --> UTF-8 Support Enabled
INFO - 2021-09-22 14:01:54 --> Utf8 Class Initialized
INFO - 2021-09-22 14:01:54 --> URI Class Initialized
INFO - 2021-09-22 14:01:54 --> Router Class Initialized
INFO - 2021-09-22 14:01:54 --> Output Class Initialized
INFO - 2021-09-22 14:01:54 --> Security Class Initialized
DEBUG - 2021-09-22 14:01:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-22 14:01:54 --> Input Class Initialized
INFO - 2021-09-22 14:01:54 --> Language Class Initialized
ERROR - 2021-09-22 14:01:54 --> 404 Page Not Found: Shop/wp-includes
ERROR - 2021-09-22 14:01:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-22 14:01:55 --> Config Class Initialized
INFO - 2021-09-22 14:01:55 --> Hooks Class Initialized
DEBUG - 2021-09-22 14:01:55 --> UTF-8 Support Enabled
INFO - 2021-09-22 14:01:55 --> Utf8 Class Initialized
INFO - 2021-09-22 14:01:55 --> URI Class Initialized
INFO - 2021-09-22 14:01:55 --> Router Class Initialized
INFO - 2021-09-22 14:01:55 --> Output Class Initialized
INFO - 2021-09-22 14:01:55 --> Security Class Initialized
DEBUG - 2021-09-22 14:01:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-22 14:01:55 --> Input Class Initialized
INFO - 2021-09-22 14:01:55 --> Language Class Initialized
ERROR - 2021-09-22 14:01:55 --> 404 Page Not Found: Wp1/wp-includes
ERROR - 2021-09-22 14:01:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-22 14:01:55 --> Config Class Initialized
INFO - 2021-09-22 14:01:55 --> Hooks Class Initialized
DEBUG - 2021-09-22 14:01:55 --> UTF-8 Support Enabled
INFO - 2021-09-22 14:01:55 --> Utf8 Class Initialized
INFO - 2021-09-22 14:01:55 --> URI Class Initialized
INFO - 2021-09-22 14:01:55 --> Router Class Initialized
INFO - 2021-09-22 14:01:55 --> Output Class Initialized
INFO - 2021-09-22 14:01:55 --> Security Class Initialized
DEBUG - 2021-09-22 14:01:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-22 14:01:55 --> Input Class Initialized
INFO - 2021-09-22 14:01:55 --> Language Class Initialized
ERROR - 2021-09-22 14:01:55 --> 404 Page Not Found: Test/wp-includes
ERROR - 2021-09-22 14:01:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-22 14:01:55 --> Config Class Initialized
INFO - 2021-09-22 14:01:55 --> Hooks Class Initialized
DEBUG - 2021-09-22 14:01:55 --> UTF-8 Support Enabled
INFO - 2021-09-22 14:01:55 --> Utf8 Class Initialized
INFO - 2021-09-22 14:01:55 --> URI Class Initialized
INFO - 2021-09-22 14:01:55 --> Router Class Initialized
INFO - 2021-09-22 14:01:55 --> Output Class Initialized
INFO - 2021-09-22 14:01:55 --> Security Class Initialized
DEBUG - 2021-09-22 14:01:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-22 14:01:55 --> Input Class Initialized
INFO - 2021-09-22 14:01:55 --> Language Class Initialized
ERROR - 2021-09-22 14:01:55 --> 404 Page Not Found: Wp2/wp-includes
ERROR - 2021-09-22 14:01:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-22 14:01:56 --> Config Class Initialized
INFO - 2021-09-22 14:01:56 --> Hooks Class Initialized
DEBUG - 2021-09-22 14:01:56 --> UTF-8 Support Enabled
INFO - 2021-09-22 14:01:56 --> Utf8 Class Initialized
INFO - 2021-09-22 14:01:56 --> URI Class Initialized
INFO - 2021-09-22 14:01:56 --> Router Class Initialized
INFO - 2021-09-22 14:01:56 --> Output Class Initialized
INFO - 2021-09-22 14:01:56 --> Security Class Initialized
DEBUG - 2021-09-22 14:01:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-22 14:01:56 --> Input Class Initialized
INFO - 2021-09-22 14:01:56 --> Language Class Initialized
ERROR - 2021-09-22 14:01:56 --> 404 Page Not Found: Site/wp-includes
ERROR - 2021-09-22 14:01:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-22 14:01:56 --> Config Class Initialized
INFO - 2021-09-22 14:01:56 --> Hooks Class Initialized
DEBUG - 2021-09-22 14:01:56 --> UTF-8 Support Enabled
INFO - 2021-09-22 14:01:56 --> Utf8 Class Initialized
INFO - 2021-09-22 14:01:56 --> URI Class Initialized
INFO - 2021-09-22 14:01:56 --> Router Class Initialized
INFO - 2021-09-22 14:01:56 --> Output Class Initialized
INFO - 2021-09-22 14:01:56 --> Security Class Initialized
DEBUG - 2021-09-22 14:01:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-22 14:01:56 --> Input Class Initialized
INFO - 2021-09-22 14:01:56 --> Language Class Initialized
ERROR - 2021-09-22 14:01:56 --> 404 Page Not Found: Cms/wp-includes
ERROR - 2021-09-22 14:01:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-22 14:01:56 --> Config Class Initialized
INFO - 2021-09-22 14:01:56 --> Hooks Class Initialized
DEBUG - 2021-09-22 14:01:56 --> UTF-8 Support Enabled
INFO - 2021-09-22 14:01:56 --> Utf8 Class Initialized
INFO - 2021-09-22 14:01:56 --> URI Class Initialized
INFO - 2021-09-22 14:01:56 --> Router Class Initialized
INFO - 2021-09-22 14:01:56 --> Output Class Initialized
INFO - 2021-09-22 14:01:56 --> Security Class Initialized
DEBUG - 2021-09-22 14:01:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-22 14:01:56 --> Input Class Initialized
INFO - 2021-09-22 14:01:56 --> Language Class Initialized
ERROR - 2021-09-22 14:01:56 --> 404 Page Not Found: Sito/wp-includes
ERROR - 2021-09-22 20:42:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-22 20:42:51 --> Config Class Initialized
INFO - 2021-09-22 20:42:51 --> Hooks Class Initialized
DEBUG - 2021-09-22 20:42:51 --> UTF-8 Support Enabled
INFO - 2021-09-22 20:42:51 --> Utf8 Class Initialized
INFO - 2021-09-22 20:42:51 --> URI Class Initialized
INFO - 2021-09-22 20:42:51 --> Router Class Initialized
INFO - 2021-09-22 20:42:51 --> Output Class Initialized
INFO - 2021-09-22 20:42:51 --> Security Class Initialized
DEBUG - 2021-09-22 20:42:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-22 20:42:51 --> Input Class Initialized
INFO - 2021-09-22 20:42:51 --> Language Class Initialized
ERROR - 2021-09-22 20:42:51 --> 404 Page Not Found: Wp-admin/css
