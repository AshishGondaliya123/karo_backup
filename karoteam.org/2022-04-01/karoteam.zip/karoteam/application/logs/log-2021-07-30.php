<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-07-30 04:09:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-30 04:09:55 --> Config Class Initialized
INFO - 2021-07-30 04:09:55 --> Hooks Class Initialized
DEBUG - 2021-07-30 04:09:55 --> UTF-8 Support Enabled
INFO - 2021-07-30 04:09:55 --> Utf8 Class Initialized
INFO - 2021-07-30 04:09:55 --> URI Class Initialized
DEBUG - 2021-07-30 04:09:55 --> No URI present. Default controller set.
INFO - 2021-07-30 04:09:55 --> Router Class Initialized
INFO - 2021-07-30 04:09:55 --> Output Class Initialized
INFO - 2021-07-30 04:09:55 --> Security Class Initialized
DEBUG - 2021-07-30 04:09:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-30 04:09:55 --> Input Class Initialized
INFO - 2021-07-30 04:09:55 --> Language Class Initialized
INFO - 2021-07-30 04:09:55 --> Loader Class Initialized
INFO - 2021-07-30 04:09:55 --> Helper loaded: url_helper
INFO - 2021-07-30 04:09:55 --> Helper loaded: form_helper
INFO - 2021-07-30 04:09:55 --> Helper loaded: common_helper
INFO - 2021-07-30 04:09:55 --> Database Driver Class Initialized
DEBUG - 2021-07-30 04:09:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-30 04:09:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-30 04:09:55 --> Controller Class Initialized
INFO - 2021-07-30 04:09:55 --> Form Validation Class Initialized
DEBUG - 2021-07-30 04:09:55 --> Encrypt Class Initialized
DEBUG - 2021-07-30 04:09:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-07-30 04:09:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-07-30 04:09:55 --> Email Class Initialized
INFO - 2021-07-30 04:09:55 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-07-30 04:09:55 --> Calendar Class Initialized
INFO - 2021-07-30 04:09:55 --> Model "Login_model" initialized
INFO - 2021-07-30 04:09:55 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-07-30 04:09:55 --> Final output sent to browser
DEBUG - 2021-07-30 04:09:55 --> Total execution time: 0.0936
ERROR - 2021-07-30 04:52:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-30 04:52:40 --> Config Class Initialized
INFO - 2021-07-30 04:52:40 --> Hooks Class Initialized
DEBUG - 2021-07-30 04:52:40 --> UTF-8 Support Enabled
INFO - 2021-07-30 04:52:40 --> Utf8 Class Initialized
INFO - 2021-07-30 04:52:40 --> URI Class Initialized
DEBUG - 2021-07-30 04:52:40 --> No URI present. Default controller set.
INFO - 2021-07-30 04:52:40 --> Router Class Initialized
INFO - 2021-07-30 04:52:40 --> Output Class Initialized
INFO - 2021-07-30 04:52:40 --> Security Class Initialized
DEBUG - 2021-07-30 04:52:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-30 04:52:40 --> Input Class Initialized
INFO - 2021-07-30 04:52:40 --> Language Class Initialized
INFO - 2021-07-30 04:52:40 --> Loader Class Initialized
INFO - 2021-07-30 04:52:40 --> Helper loaded: url_helper
INFO - 2021-07-30 04:52:40 --> Helper loaded: form_helper
INFO - 2021-07-30 04:52:40 --> Helper loaded: common_helper
INFO - 2021-07-30 04:52:40 --> Database Driver Class Initialized
DEBUG - 2021-07-30 04:52:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-30 04:52:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-30 04:52:40 --> Controller Class Initialized
INFO - 2021-07-30 04:52:40 --> Form Validation Class Initialized
DEBUG - 2021-07-30 04:52:40 --> Encrypt Class Initialized
DEBUG - 2021-07-30 04:52:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-07-30 04:52:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-07-30 04:52:40 --> Email Class Initialized
INFO - 2021-07-30 04:52:40 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-07-30 04:52:40 --> Calendar Class Initialized
INFO - 2021-07-30 04:52:40 --> Model "Login_model" initialized
INFO - 2021-07-30 04:52:40 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-07-30 04:52:40 --> Final output sent to browser
DEBUG - 2021-07-30 04:52:40 --> Total execution time: 0.0520
ERROR - 2021-07-30 17:53:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-30 17:53:34 --> Config Class Initialized
INFO - 2021-07-30 17:53:34 --> Hooks Class Initialized
DEBUG - 2021-07-30 17:53:34 --> UTF-8 Support Enabled
INFO - 2021-07-30 17:53:34 --> Utf8 Class Initialized
INFO - 2021-07-30 17:53:34 --> URI Class Initialized
DEBUG - 2021-07-30 17:53:34 --> No URI present. Default controller set.
INFO - 2021-07-30 17:53:34 --> Router Class Initialized
INFO - 2021-07-30 17:53:34 --> Output Class Initialized
INFO - 2021-07-30 17:53:34 --> Security Class Initialized
DEBUG - 2021-07-30 17:53:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-30 17:53:34 --> Input Class Initialized
INFO - 2021-07-30 17:53:34 --> Language Class Initialized
INFO - 2021-07-30 17:53:34 --> Loader Class Initialized
INFO - 2021-07-30 17:53:34 --> Helper loaded: url_helper
INFO - 2021-07-30 17:53:34 --> Helper loaded: form_helper
INFO - 2021-07-30 17:53:34 --> Helper loaded: common_helper
INFO - 2021-07-30 17:53:34 --> Database Driver Class Initialized
DEBUG - 2021-07-30 17:53:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-30 17:53:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-30 17:53:34 --> Controller Class Initialized
INFO - 2021-07-30 17:53:34 --> Form Validation Class Initialized
DEBUG - 2021-07-30 17:53:34 --> Encrypt Class Initialized
DEBUG - 2021-07-30 17:53:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-07-30 17:53:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-07-30 17:53:34 --> Email Class Initialized
INFO - 2021-07-30 17:53:34 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-07-30 17:53:34 --> Calendar Class Initialized
INFO - 2021-07-30 17:53:34 --> Model "Login_model" initialized
INFO - 2021-07-30 17:53:34 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-07-30 17:53:34 --> Final output sent to browser
DEBUG - 2021-07-30 17:53:34 --> Total execution time: 0.0476
ERROR - 2021-07-30 19:37:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-30 19:37:28 --> Config Class Initialized
INFO - 2021-07-30 19:37:28 --> Hooks Class Initialized
DEBUG - 2021-07-30 19:37:28 --> UTF-8 Support Enabled
INFO - 2021-07-30 19:37:28 --> Utf8 Class Initialized
INFO - 2021-07-30 19:37:28 --> URI Class Initialized
DEBUG - 2021-07-30 19:37:28 --> No URI present. Default controller set.
INFO - 2021-07-30 19:37:28 --> Router Class Initialized
INFO - 2021-07-30 19:37:28 --> Output Class Initialized
INFO - 2021-07-30 19:37:28 --> Security Class Initialized
DEBUG - 2021-07-30 19:37:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-30 19:37:28 --> Input Class Initialized
INFO - 2021-07-30 19:37:28 --> Language Class Initialized
INFO - 2021-07-30 19:37:28 --> Loader Class Initialized
INFO - 2021-07-30 19:37:28 --> Helper loaded: url_helper
INFO - 2021-07-30 19:37:28 --> Helper loaded: form_helper
INFO - 2021-07-30 19:37:28 --> Helper loaded: common_helper
INFO - 2021-07-30 19:37:28 --> Database Driver Class Initialized
DEBUG - 2021-07-30 19:37:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-30 19:37:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-30 19:37:28 --> Controller Class Initialized
INFO - 2021-07-30 19:37:28 --> Form Validation Class Initialized
DEBUG - 2021-07-30 19:37:28 --> Encrypt Class Initialized
DEBUG - 2021-07-30 19:37:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-07-30 19:37:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-07-30 19:37:28 --> Email Class Initialized
INFO - 2021-07-30 19:37:28 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-07-30 19:37:28 --> Calendar Class Initialized
INFO - 2021-07-30 19:37:28 --> Model "Login_model" initialized
INFO - 2021-07-30 19:37:28 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-07-30 19:37:28 --> Final output sent to browser
DEBUG - 2021-07-30 19:37:28 --> Total execution time: 0.0675
