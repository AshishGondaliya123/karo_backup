<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-08-03 02:51:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-03 02:51:10 --> Config Class Initialized
INFO - 2021-08-03 02:51:10 --> Hooks Class Initialized
DEBUG - 2021-08-03 02:51:10 --> UTF-8 Support Enabled
INFO - 2021-08-03 02:51:10 --> Utf8 Class Initialized
INFO - 2021-08-03 02:51:10 --> URI Class Initialized
DEBUG - 2021-08-03 02:51:10 --> No URI present. Default controller set.
INFO - 2021-08-03 02:51:10 --> Router Class Initialized
INFO - 2021-08-03 02:51:10 --> Output Class Initialized
INFO - 2021-08-03 02:51:10 --> Security Class Initialized
DEBUG - 2021-08-03 02:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 02:51:10 --> Input Class Initialized
INFO - 2021-08-03 02:51:10 --> Language Class Initialized
INFO - 2021-08-03 02:51:10 --> Loader Class Initialized
INFO - 2021-08-03 02:51:10 --> Helper loaded: url_helper
INFO - 2021-08-03 02:51:10 --> Helper loaded: form_helper
INFO - 2021-08-03 02:51:10 --> Helper loaded: common_helper
INFO - 2021-08-03 02:51:10 --> Database Driver Class Initialized
DEBUG - 2021-08-03 02:51:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-03 02:51:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-03 02:51:10 --> Controller Class Initialized
INFO - 2021-08-03 02:51:10 --> Form Validation Class Initialized
DEBUG - 2021-08-03 02:51:10 --> Encrypt Class Initialized
DEBUG - 2021-08-03 02:51:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-08-03 02:51:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-08-03 02:51:10 --> Email Class Initialized
INFO - 2021-08-03 02:51:10 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-08-03 02:51:10 --> Calendar Class Initialized
INFO - 2021-08-03 02:51:10 --> Model "Login_model" initialized
INFO - 2021-08-03 02:51:10 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-08-03 02:51:10 --> Final output sent to browser
DEBUG - 2021-08-03 02:51:10 --> Total execution time: 0.0629
ERROR - 2021-08-03 03:41:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-03 03:41:04 --> Config Class Initialized
INFO - 2021-08-03 03:41:04 --> Hooks Class Initialized
DEBUG - 2021-08-03 03:41:04 --> UTF-8 Support Enabled
INFO - 2021-08-03 03:41:04 --> Utf8 Class Initialized
INFO - 2021-08-03 03:41:04 --> URI Class Initialized
DEBUG - 2021-08-03 03:41:04 --> No URI present. Default controller set.
INFO - 2021-08-03 03:41:04 --> Router Class Initialized
INFO - 2021-08-03 03:41:04 --> Output Class Initialized
INFO - 2021-08-03 03:41:04 --> Security Class Initialized
DEBUG - 2021-08-03 03:41:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 03:41:04 --> Input Class Initialized
INFO - 2021-08-03 03:41:04 --> Language Class Initialized
INFO - 2021-08-03 03:41:04 --> Loader Class Initialized
INFO - 2021-08-03 03:41:04 --> Helper loaded: url_helper
INFO - 2021-08-03 03:41:04 --> Helper loaded: form_helper
INFO - 2021-08-03 03:41:04 --> Helper loaded: common_helper
INFO - 2021-08-03 03:41:04 --> Database Driver Class Initialized
DEBUG - 2021-08-03 03:41:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-03 03:41:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-03 03:41:04 --> Controller Class Initialized
INFO - 2021-08-03 03:41:04 --> Form Validation Class Initialized
DEBUG - 2021-08-03 03:41:04 --> Encrypt Class Initialized
DEBUG - 2021-08-03 03:41:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-08-03 03:41:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-08-03 03:41:04 --> Email Class Initialized
INFO - 2021-08-03 03:41:04 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-08-03 03:41:04 --> Calendar Class Initialized
INFO - 2021-08-03 03:41:04 --> Model "Login_model" initialized
INFO - 2021-08-03 03:41:04 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-08-03 03:41:04 --> Final output sent to browser
DEBUG - 2021-08-03 03:41:04 --> Total execution time: 0.0667
ERROR - 2021-08-03 07:34:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-03 07:34:09 --> Config Class Initialized
INFO - 2021-08-03 07:34:09 --> Hooks Class Initialized
DEBUG - 2021-08-03 07:34:09 --> UTF-8 Support Enabled
INFO - 2021-08-03 07:34:09 --> Utf8 Class Initialized
INFO - 2021-08-03 07:34:09 --> URI Class Initialized
DEBUG - 2021-08-03 07:34:09 --> No URI present. Default controller set.
INFO - 2021-08-03 07:34:09 --> Router Class Initialized
INFO - 2021-08-03 07:34:09 --> Output Class Initialized
INFO - 2021-08-03 07:34:09 --> Security Class Initialized
DEBUG - 2021-08-03 07:34:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 07:34:09 --> Input Class Initialized
INFO - 2021-08-03 07:34:09 --> Language Class Initialized
INFO - 2021-08-03 07:34:09 --> Loader Class Initialized
INFO - 2021-08-03 07:34:09 --> Helper loaded: url_helper
INFO - 2021-08-03 07:34:09 --> Helper loaded: form_helper
INFO - 2021-08-03 07:34:09 --> Helper loaded: common_helper
INFO - 2021-08-03 07:34:09 --> Database Driver Class Initialized
DEBUG - 2021-08-03 07:34:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-03 07:34:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-03 07:34:09 --> Controller Class Initialized
INFO - 2021-08-03 07:34:09 --> Form Validation Class Initialized
DEBUG - 2021-08-03 07:34:09 --> Encrypt Class Initialized
DEBUG - 2021-08-03 07:34:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-08-03 07:34:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-08-03 07:34:09 --> Email Class Initialized
INFO - 2021-08-03 07:34:09 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-08-03 07:34:09 --> Calendar Class Initialized
INFO - 2021-08-03 07:34:09 --> Model "Login_model" initialized
INFO - 2021-08-03 07:34:09 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-08-03 07:34:09 --> Final output sent to browser
DEBUG - 2021-08-03 07:34:09 --> Total execution time: 0.0385
ERROR - 2021-08-03 18:15:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-03 18:15:43 --> Config Class Initialized
INFO - 2021-08-03 18:15:43 --> Hooks Class Initialized
DEBUG - 2021-08-03 18:15:43 --> UTF-8 Support Enabled
INFO - 2021-08-03 18:15:43 --> Utf8 Class Initialized
INFO - 2021-08-03 18:15:43 --> URI Class Initialized
DEBUG - 2021-08-03 18:15:43 --> No URI present. Default controller set.
INFO - 2021-08-03 18:15:43 --> Router Class Initialized
INFO - 2021-08-03 18:15:43 --> Output Class Initialized
INFO - 2021-08-03 18:15:43 --> Security Class Initialized
DEBUG - 2021-08-03 18:15:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 18:15:43 --> Input Class Initialized
INFO - 2021-08-03 18:15:43 --> Language Class Initialized
INFO - 2021-08-03 18:15:43 --> Loader Class Initialized
INFO - 2021-08-03 18:15:43 --> Helper loaded: url_helper
INFO - 2021-08-03 18:15:43 --> Helper loaded: form_helper
INFO - 2021-08-03 18:15:43 --> Helper loaded: common_helper
INFO - 2021-08-03 18:15:43 --> Database Driver Class Initialized
DEBUG - 2021-08-03 18:15:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-03 18:15:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-03 18:15:43 --> Controller Class Initialized
INFO - 2021-08-03 18:15:43 --> Form Validation Class Initialized
DEBUG - 2021-08-03 18:15:43 --> Encrypt Class Initialized
DEBUG - 2021-08-03 18:15:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-08-03 18:15:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-08-03 18:15:43 --> Email Class Initialized
INFO - 2021-08-03 18:15:43 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-08-03 18:15:43 --> Calendar Class Initialized
INFO - 2021-08-03 18:15:43 --> Model "Login_model" initialized
INFO - 2021-08-03 18:15:43 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-08-03 18:15:43 --> Final output sent to browser
DEBUG - 2021-08-03 18:15:43 --> Total execution time: 0.0793
ERROR - 2021-08-03 18:15:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-03 18:15:50 --> Config Class Initialized
INFO - 2021-08-03 18:15:50 --> Hooks Class Initialized
DEBUG - 2021-08-03 18:15:50 --> UTF-8 Support Enabled
INFO - 2021-08-03 18:15:50 --> Utf8 Class Initialized
INFO - 2021-08-03 18:15:50 --> URI Class Initialized
DEBUG - 2021-08-03 18:15:50 --> No URI present. Default controller set.
INFO - 2021-08-03 18:15:50 --> Router Class Initialized
INFO - 2021-08-03 18:15:50 --> Output Class Initialized
INFO - 2021-08-03 18:15:50 --> Security Class Initialized
DEBUG - 2021-08-03 18:15:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 18:15:50 --> Input Class Initialized
INFO - 2021-08-03 18:15:50 --> Language Class Initialized
INFO - 2021-08-03 18:15:50 --> Loader Class Initialized
INFO - 2021-08-03 18:15:50 --> Helper loaded: url_helper
INFO - 2021-08-03 18:15:50 --> Helper loaded: form_helper
INFO - 2021-08-03 18:15:50 --> Helper loaded: common_helper
INFO - 2021-08-03 18:15:50 --> Database Driver Class Initialized
DEBUG - 2021-08-03 18:15:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-03 18:15:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-03 18:15:50 --> Controller Class Initialized
INFO - 2021-08-03 18:15:50 --> Form Validation Class Initialized
DEBUG - 2021-08-03 18:15:50 --> Encrypt Class Initialized
DEBUG - 2021-08-03 18:15:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-08-03 18:15:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-08-03 18:15:50 --> Email Class Initialized
INFO - 2021-08-03 18:15:50 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-08-03 18:15:50 --> Calendar Class Initialized
INFO - 2021-08-03 18:15:50 --> Model "Login_model" initialized
INFO - 2021-08-03 18:15:50 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-08-03 18:15:50 --> Final output sent to browser
DEBUG - 2021-08-03 18:15:50 --> Total execution time: 0.0269
