<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-09-21 02:53:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-21 02:53:52 --> Config Class Initialized
INFO - 2021-09-21 02:53:52 --> Hooks Class Initialized
DEBUG - 2021-09-21 02:53:52 --> UTF-8 Support Enabled
INFO - 2021-09-21 02:53:52 --> Utf8 Class Initialized
INFO - 2021-09-21 02:53:52 --> URI Class Initialized
DEBUG - 2021-09-21 02:53:52 --> No URI present. Default controller set.
INFO - 2021-09-21 02:53:52 --> Router Class Initialized
INFO - 2021-09-21 02:53:52 --> Output Class Initialized
INFO - 2021-09-21 02:53:52 --> Security Class Initialized
DEBUG - 2021-09-21 02:53:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-21 02:53:52 --> Input Class Initialized
INFO - 2021-09-21 02:53:52 --> Language Class Initialized
INFO - 2021-09-21 02:53:52 --> Loader Class Initialized
INFO - 2021-09-21 02:53:52 --> Helper loaded: url_helper
INFO - 2021-09-21 02:53:52 --> Helper loaded: form_helper
INFO - 2021-09-21 02:53:52 --> Helper loaded: common_helper
INFO - 2021-09-21 02:53:52 --> Database Driver Class Initialized
DEBUG - 2021-09-21 02:53:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-21 02:53:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-21 02:53:52 --> Controller Class Initialized
INFO - 2021-09-21 02:53:52 --> Form Validation Class Initialized
DEBUG - 2021-09-21 02:53:52 --> Encrypt Class Initialized
DEBUG - 2021-09-21 02:53:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-09-21 02:53:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-09-21 02:53:52 --> Email Class Initialized
INFO - 2021-09-21 02:53:52 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-09-21 02:53:52 --> Calendar Class Initialized
INFO - 2021-09-21 02:53:52 --> Model "Login_model" initialized
INFO - 2021-09-21 02:53:52 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-09-21 02:53:52 --> Final output sent to browser
DEBUG - 2021-09-21 02:53:52 --> Total execution time: 0.0395
ERROR - 2021-09-21 05:18:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-21 05:18:13 --> Config Class Initialized
INFO - 2021-09-21 05:18:13 --> Hooks Class Initialized
DEBUG - 2021-09-21 05:18:13 --> UTF-8 Support Enabled
INFO - 2021-09-21 05:18:13 --> Utf8 Class Initialized
INFO - 2021-09-21 05:18:13 --> URI Class Initialized
DEBUG - 2021-09-21 05:18:13 --> No URI present. Default controller set.
INFO - 2021-09-21 05:18:13 --> Router Class Initialized
INFO - 2021-09-21 05:18:13 --> Output Class Initialized
INFO - 2021-09-21 05:18:13 --> Security Class Initialized
DEBUG - 2021-09-21 05:18:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-21 05:18:13 --> Input Class Initialized
INFO - 2021-09-21 05:18:13 --> Language Class Initialized
INFO - 2021-09-21 05:18:13 --> Loader Class Initialized
INFO - 2021-09-21 05:18:13 --> Helper loaded: url_helper
INFO - 2021-09-21 05:18:13 --> Helper loaded: form_helper
INFO - 2021-09-21 05:18:13 --> Helper loaded: common_helper
INFO - 2021-09-21 05:18:13 --> Database Driver Class Initialized
DEBUG - 2021-09-21 05:18:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-21 05:18:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-21 05:18:13 --> Controller Class Initialized
INFO - 2021-09-21 05:18:13 --> Form Validation Class Initialized
DEBUG - 2021-09-21 05:18:13 --> Encrypt Class Initialized
DEBUG - 2021-09-21 05:18:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-09-21 05:18:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-09-21 05:18:13 --> Email Class Initialized
INFO - 2021-09-21 05:18:13 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-09-21 05:18:13 --> Calendar Class Initialized
INFO - 2021-09-21 05:18:13 --> Model "Login_model" initialized
INFO - 2021-09-21 05:18:13 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-09-21 05:18:13 --> Final output sent to browser
DEBUG - 2021-09-21 05:18:13 --> Total execution time: 0.0404
ERROR - 2021-09-21 20:29:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-21 20:29:57 --> Config Class Initialized
INFO - 2021-09-21 20:29:57 --> Hooks Class Initialized
DEBUG - 2021-09-21 20:29:57 --> UTF-8 Support Enabled
INFO - 2021-09-21 20:29:57 --> Utf8 Class Initialized
INFO - 2021-09-21 20:29:57 --> URI Class Initialized
INFO - 2021-09-21 20:29:57 --> Router Class Initialized
INFO - 2021-09-21 20:29:57 --> Output Class Initialized
INFO - 2021-09-21 20:29:57 --> Security Class Initialized
DEBUG - 2021-09-21 20:29:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-21 20:29:57 --> Input Class Initialized
INFO - 2021-09-21 20:29:57 --> Language Class Initialized
ERROR - 2021-09-21 20:29:57 --> 404 Page Not Found: Wp-content/index
