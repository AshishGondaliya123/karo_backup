<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-02-13 00:03:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-13 00:03:13 --> Config Class Initialized
INFO - 2022-02-13 00:03:13 --> Hooks Class Initialized
DEBUG - 2022-02-13 00:03:13 --> UTF-8 Support Enabled
INFO - 2022-02-13 00:03:13 --> Utf8 Class Initialized
INFO - 2022-02-13 00:03:13 --> URI Class Initialized
DEBUG - 2022-02-13 00:03:13 --> No URI present. Default controller set.
INFO - 2022-02-13 00:03:13 --> Router Class Initialized
INFO - 2022-02-13 00:03:13 --> Output Class Initialized
INFO - 2022-02-13 00:03:13 --> Security Class Initialized
DEBUG - 2022-02-13 00:03:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-13 00:03:13 --> Input Class Initialized
INFO - 2022-02-13 00:03:13 --> Language Class Initialized
INFO - 2022-02-13 00:03:13 --> Loader Class Initialized
INFO - 2022-02-13 00:03:13 --> Helper loaded: url_helper
INFO - 2022-02-13 00:03:13 --> Helper loaded: form_helper
INFO - 2022-02-13 00:03:13 --> Helper loaded: common_helper
INFO - 2022-02-13 00:03:13 --> Database Driver Class Initialized
DEBUG - 2022-02-13 00:03:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-13 00:03:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-13 00:03:13 --> Controller Class Initialized
INFO - 2022-02-13 00:03:13 --> Form Validation Class Initialized
DEBUG - 2022-02-13 00:03:13 --> Encrypt Class Initialized
DEBUG - 2022-02-13 00:03:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-13 00:03:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-13 00:03:13 --> Email Class Initialized
INFO - 2022-02-13 00:03:13 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-13 00:03:13 --> Calendar Class Initialized
INFO - 2022-02-13 00:03:13 --> Model "Login_model" initialized
INFO - 2022-02-13 00:03:13 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-13 00:03:13 --> Final output sent to browser
DEBUG - 2022-02-13 00:03:13 --> Total execution time: 0.0237
ERROR - 2022-02-13 04:38:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-13 04:38:47 --> Config Class Initialized
INFO - 2022-02-13 04:38:47 --> Hooks Class Initialized
DEBUG - 2022-02-13 04:38:47 --> UTF-8 Support Enabled
INFO - 2022-02-13 04:38:47 --> Utf8 Class Initialized
INFO - 2022-02-13 04:38:47 --> URI Class Initialized
DEBUG - 2022-02-13 04:38:47 --> No URI present. Default controller set.
INFO - 2022-02-13 04:38:47 --> Router Class Initialized
INFO - 2022-02-13 04:38:47 --> Output Class Initialized
INFO - 2022-02-13 04:38:47 --> Security Class Initialized
DEBUG - 2022-02-13 04:38:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-13 04:38:47 --> Input Class Initialized
INFO - 2022-02-13 04:38:47 --> Language Class Initialized
INFO - 2022-02-13 04:38:47 --> Loader Class Initialized
INFO - 2022-02-13 04:38:47 --> Helper loaded: url_helper
INFO - 2022-02-13 04:38:47 --> Helper loaded: form_helper
INFO - 2022-02-13 04:38:47 --> Helper loaded: common_helper
INFO - 2022-02-13 04:38:47 --> Database Driver Class Initialized
DEBUG - 2022-02-13 04:38:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-13 04:38:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-13 04:38:47 --> Controller Class Initialized
INFO - 2022-02-13 04:38:47 --> Form Validation Class Initialized
DEBUG - 2022-02-13 04:38:47 --> Encrypt Class Initialized
DEBUG - 2022-02-13 04:38:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-13 04:38:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-13 04:38:47 --> Email Class Initialized
INFO - 2022-02-13 04:38:47 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-13 04:38:47 --> Calendar Class Initialized
INFO - 2022-02-13 04:38:47 --> Model "Login_model" initialized
INFO - 2022-02-13 04:38:47 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-13 04:38:47 --> Final output sent to browser
DEBUG - 2022-02-13 04:38:47 --> Total execution time: 0.0215
ERROR - 2022-02-13 13:43:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-13 13:43:14 --> Config Class Initialized
INFO - 2022-02-13 13:43:14 --> Hooks Class Initialized
DEBUG - 2022-02-13 13:43:14 --> UTF-8 Support Enabled
INFO - 2022-02-13 13:43:14 --> Utf8 Class Initialized
INFO - 2022-02-13 13:43:14 --> URI Class Initialized
DEBUG - 2022-02-13 13:43:14 --> No URI present. Default controller set.
INFO - 2022-02-13 13:43:14 --> Router Class Initialized
INFO - 2022-02-13 13:43:14 --> Output Class Initialized
INFO - 2022-02-13 13:43:14 --> Security Class Initialized
DEBUG - 2022-02-13 13:43:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-13 13:43:14 --> Input Class Initialized
INFO - 2022-02-13 13:43:14 --> Language Class Initialized
INFO - 2022-02-13 13:43:14 --> Loader Class Initialized
INFO - 2022-02-13 13:43:14 --> Helper loaded: url_helper
INFO - 2022-02-13 13:43:14 --> Helper loaded: form_helper
INFO - 2022-02-13 13:43:14 --> Helper loaded: common_helper
INFO - 2022-02-13 13:43:14 --> Database Driver Class Initialized
DEBUG - 2022-02-13 13:43:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-13 13:43:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-13 13:43:14 --> Controller Class Initialized
INFO - 2022-02-13 13:43:14 --> Form Validation Class Initialized
DEBUG - 2022-02-13 13:43:14 --> Encrypt Class Initialized
DEBUG - 2022-02-13 13:43:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-13 13:43:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-13 13:43:14 --> Email Class Initialized
INFO - 2022-02-13 13:43:14 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-13 13:43:14 --> Calendar Class Initialized
INFO - 2022-02-13 13:43:14 --> Model "Login_model" initialized
INFO - 2022-02-13 13:43:14 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-13 13:43:14 --> Final output sent to browser
DEBUG - 2022-02-13 13:43:14 --> Total execution time: 0.0339
ERROR - 2022-02-13 14:15:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-13 14:15:41 --> Config Class Initialized
INFO - 2022-02-13 14:15:41 --> Hooks Class Initialized
DEBUG - 2022-02-13 14:15:41 --> UTF-8 Support Enabled
INFO - 2022-02-13 14:15:41 --> Utf8 Class Initialized
INFO - 2022-02-13 14:15:41 --> URI Class Initialized
DEBUG - 2022-02-13 14:15:41 --> No URI present. Default controller set.
INFO - 2022-02-13 14:15:41 --> Router Class Initialized
INFO - 2022-02-13 14:15:41 --> Output Class Initialized
INFO - 2022-02-13 14:15:41 --> Security Class Initialized
DEBUG - 2022-02-13 14:15:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-13 14:15:41 --> Input Class Initialized
INFO - 2022-02-13 14:15:41 --> Language Class Initialized
INFO - 2022-02-13 14:15:41 --> Loader Class Initialized
INFO - 2022-02-13 14:15:41 --> Helper loaded: url_helper
INFO - 2022-02-13 14:15:41 --> Helper loaded: form_helper
INFO - 2022-02-13 14:15:41 --> Helper loaded: common_helper
INFO - 2022-02-13 14:15:41 --> Database Driver Class Initialized
DEBUG - 2022-02-13 14:15:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-13 14:15:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-13 14:15:41 --> Controller Class Initialized
INFO - 2022-02-13 14:15:41 --> Form Validation Class Initialized
DEBUG - 2022-02-13 14:15:41 --> Encrypt Class Initialized
DEBUG - 2022-02-13 14:15:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-13 14:15:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-13 14:15:41 --> Email Class Initialized
INFO - 2022-02-13 14:15:41 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-13 14:15:41 --> Calendar Class Initialized
INFO - 2022-02-13 14:15:41 --> Model "Login_model" initialized
INFO - 2022-02-13 14:15:41 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-13 14:15:41 --> Final output sent to browser
DEBUG - 2022-02-13 14:15:41 --> Total execution time: 0.0217
ERROR - 2022-02-13 14:15:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-13 14:15:42 --> Config Class Initialized
INFO - 2022-02-13 14:15:42 --> Hooks Class Initialized
DEBUG - 2022-02-13 14:15:42 --> UTF-8 Support Enabled
INFO - 2022-02-13 14:15:42 --> Utf8 Class Initialized
INFO - 2022-02-13 14:15:42 --> URI Class Initialized
INFO - 2022-02-13 14:15:42 --> Router Class Initialized
INFO - 2022-02-13 14:15:42 --> Output Class Initialized
INFO - 2022-02-13 14:15:42 --> Security Class Initialized
DEBUG - 2022-02-13 14:15:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-13 14:15:42 --> Input Class Initialized
INFO - 2022-02-13 14:15:42 --> Language Class Initialized
ERROR - 2022-02-13 14:15:42 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2022-02-13 14:15:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-13 14:15:55 --> Config Class Initialized
INFO - 2022-02-13 14:15:55 --> Hooks Class Initialized
DEBUG - 2022-02-13 14:15:55 --> UTF-8 Support Enabled
INFO - 2022-02-13 14:15:55 --> Utf8 Class Initialized
INFO - 2022-02-13 14:15:55 --> URI Class Initialized
INFO - 2022-02-13 14:15:55 --> Router Class Initialized
INFO - 2022-02-13 14:15:55 --> Output Class Initialized
INFO - 2022-02-13 14:15:55 --> Security Class Initialized
DEBUG - 2022-02-13 14:15:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-13 14:15:55 --> Input Class Initialized
INFO - 2022-02-13 14:15:55 --> Language Class Initialized
INFO - 2022-02-13 14:15:55 --> Loader Class Initialized
INFO - 2022-02-13 14:15:55 --> Helper loaded: url_helper
INFO - 2022-02-13 14:15:55 --> Helper loaded: form_helper
INFO - 2022-02-13 14:15:55 --> Helper loaded: common_helper
INFO - 2022-02-13 14:15:55 --> Database Driver Class Initialized
DEBUG - 2022-02-13 14:15:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-13 14:15:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-13 14:15:55 --> Controller Class Initialized
INFO - 2022-02-13 14:15:55 --> Form Validation Class Initialized
DEBUG - 2022-02-13 14:15:55 --> Encrypt Class Initialized
DEBUG - 2022-02-13 14:15:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-13 14:15:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-13 14:15:55 --> Email Class Initialized
INFO - 2022-02-13 14:15:55 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-13 14:15:55 --> Calendar Class Initialized
INFO - 2022-02-13 14:15:55 --> Model "Login_model" initialized
INFO - 2022-02-13 14:15:55 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-13 14:15:55 --> Final output sent to browser
DEBUG - 2022-02-13 14:15:55 --> Total execution time: 0.0285
ERROR - 2022-02-13 14:15:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-13 14:15:56 --> Config Class Initialized
INFO - 2022-02-13 14:15:56 --> Hooks Class Initialized
DEBUG - 2022-02-13 14:15:56 --> UTF-8 Support Enabled
INFO - 2022-02-13 14:15:56 --> Utf8 Class Initialized
INFO - 2022-02-13 14:15:56 --> URI Class Initialized
DEBUG - 2022-02-13 14:15:56 --> No URI present. Default controller set.
INFO - 2022-02-13 14:15:56 --> Router Class Initialized
INFO - 2022-02-13 14:15:56 --> Output Class Initialized
INFO - 2022-02-13 14:15:56 --> Security Class Initialized
DEBUG - 2022-02-13 14:15:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-13 14:15:56 --> Input Class Initialized
INFO - 2022-02-13 14:15:56 --> Language Class Initialized
INFO - 2022-02-13 14:15:56 --> Loader Class Initialized
INFO - 2022-02-13 14:15:56 --> Helper loaded: url_helper
INFO - 2022-02-13 14:15:56 --> Helper loaded: form_helper
INFO - 2022-02-13 14:15:56 --> Helper loaded: common_helper
INFO - 2022-02-13 14:15:56 --> Database Driver Class Initialized
DEBUG - 2022-02-13 14:15:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-13 14:15:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-13 14:15:56 --> Controller Class Initialized
INFO - 2022-02-13 14:15:56 --> Form Validation Class Initialized
DEBUG - 2022-02-13 14:15:56 --> Encrypt Class Initialized
DEBUG - 2022-02-13 14:15:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-13 14:15:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-13 14:15:56 --> Email Class Initialized
INFO - 2022-02-13 14:15:56 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-13 14:15:56 --> Calendar Class Initialized
INFO - 2022-02-13 14:15:56 --> Model "Login_model" initialized
INFO - 2022-02-13 14:15:56 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-13 14:15:56 --> Final output sent to browser
DEBUG - 2022-02-13 14:15:56 --> Total execution time: 0.0244
ERROR - 2022-02-13 14:15:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-13 14:15:56 --> Config Class Initialized
INFO - 2022-02-13 14:15:56 --> Hooks Class Initialized
DEBUG - 2022-02-13 14:15:56 --> UTF-8 Support Enabled
INFO - 2022-02-13 14:15:56 --> Utf8 Class Initialized
INFO - 2022-02-13 14:15:56 --> URI Class Initialized
INFO - 2022-02-13 14:15:56 --> Router Class Initialized
INFO - 2022-02-13 14:15:56 --> Output Class Initialized
INFO - 2022-02-13 14:15:56 --> Security Class Initialized
DEBUG - 2022-02-13 14:15:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-13 14:15:56 --> Input Class Initialized
INFO - 2022-02-13 14:15:56 --> Language Class Initialized
INFO - 2022-02-13 14:15:56 --> Loader Class Initialized
INFO - 2022-02-13 14:15:56 --> Helper loaded: url_helper
INFO - 2022-02-13 14:15:56 --> Helper loaded: form_helper
INFO - 2022-02-13 14:15:56 --> Helper loaded: common_helper
INFO - 2022-02-13 14:15:56 --> Database Driver Class Initialized
DEBUG - 2022-02-13 14:15:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-13 14:15:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-13 14:15:56 --> Controller Class Initialized
INFO - 2022-02-13 14:15:56 --> Form Validation Class Initialized
DEBUG - 2022-02-13 14:15:56 --> Encrypt Class Initialized
DEBUG - 2022-02-13 14:15:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-13 14:15:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-13 14:15:56 --> Email Class Initialized
INFO - 2022-02-13 14:15:56 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-13 14:15:56 --> Calendar Class Initialized
INFO - 2022-02-13 14:15:56 --> Model "Login_model" initialized
ERROR - 2022-02-13 14:15:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-13 14:15:57 --> Config Class Initialized
INFO - 2022-02-13 14:15:57 --> Hooks Class Initialized
DEBUG - 2022-02-13 14:15:57 --> UTF-8 Support Enabled
INFO - 2022-02-13 14:15:57 --> Utf8 Class Initialized
INFO - 2022-02-13 14:15:57 --> URI Class Initialized
INFO - 2022-02-13 14:15:57 --> Router Class Initialized
INFO - 2022-02-13 14:15:57 --> Output Class Initialized
INFO - 2022-02-13 14:15:57 --> Security Class Initialized
DEBUG - 2022-02-13 14:15:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-13 14:15:57 --> Input Class Initialized
INFO - 2022-02-13 14:15:57 --> Language Class Initialized
INFO - 2022-02-13 14:15:57 --> Loader Class Initialized
INFO - 2022-02-13 14:15:57 --> Helper loaded: url_helper
INFO - 2022-02-13 14:15:57 --> Helper loaded: form_helper
INFO - 2022-02-13 14:15:57 --> Helper loaded: common_helper
INFO - 2022-02-13 14:15:57 --> Database Driver Class Initialized
DEBUG - 2022-02-13 14:15:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-13 14:15:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-13 14:15:57 --> Controller Class Initialized
INFO - 2022-02-13 14:15:57 --> Form Validation Class Initialized
DEBUG - 2022-02-13 14:15:57 --> Encrypt Class Initialized
DEBUG - 2022-02-13 14:15:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-13 14:15:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-13 14:15:57 --> Email Class Initialized
INFO - 2022-02-13 14:15:57 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-13 14:15:57 --> Calendar Class Initialized
INFO - 2022-02-13 14:15:57 --> Model "Login_model" initialized
ERROR - 2022-02-13 18:23:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-13 18:23:09 --> Config Class Initialized
INFO - 2022-02-13 18:23:09 --> Hooks Class Initialized
DEBUG - 2022-02-13 18:23:09 --> UTF-8 Support Enabled
INFO - 2022-02-13 18:23:09 --> Utf8 Class Initialized
INFO - 2022-02-13 18:23:09 --> URI Class Initialized
DEBUG - 2022-02-13 18:23:09 --> No URI present. Default controller set.
INFO - 2022-02-13 18:23:09 --> Router Class Initialized
INFO - 2022-02-13 18:23:09 --> Output Class Initialized
INFO - 2022-02-13 18:23:09 --> Security Class Initialized
DEBUG - 2022-02-13 18:23:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-13 18:23:09 --> Input Class Initialized
INFO - 2022-02-13 18:23:09 --> Language Class Initialized
INFO - 2022-02-13 18:23:09 --> Loader Class Initialized
INFO - 2022-02-13 18:23:09 --> Helper loaded: url_helper
INFO - 2022-02-13 18:23:09 --> Helper loaded: form_helper
INFO - 2022-02-13 18:23:09 --> Helper loaded: common_helper
INFO - 2022-02-13 18:23:09 --> Database Driver Class Initialized
DEBUG - 2022-02-13 18:23:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-13 18:23:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-13 18:23:09 --> Controller Class Initialized
INFO - 2022-02-13 18:23:09 --> Form Validation Class Initialized
DEBUG - 2022-02-13 18:23:09 --> Encrypt Class Initialized
DEBUG - 2022-02-13 18:23:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-13 18:23:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-13 18:23:09 --> Email Class Initialized
INFO - 2022-02-13 18:23:09 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-13 18:23:09 --> Calendar Class Initialized
INFO - 2022-02-13 18:23:09 --> Model "Login_model" initialized
INFO - 2022-02-13 18:23:09 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-13 18:23:09 --> Final output sent to browser
DEBUG - 2022-02-13 18:23:09 --> Total execution time: 0.0238
ERROR - 2022-02-13 18:57:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-13 18:57:58 --> Config Class Initialized
INFO - 2022-02-13 18:57:58 --> Hooks Class Initialized
DEBUG - 2022-02-13 18:57:58 --> UTF-8 Support Enabled
INFO - 2022-02-13 18:57:58 --> Utf8 Class Initialized
INFO - 2022-02-13 18:57:58 --> URI Class Initialized
DEBUG - 2022-02-13 18:57:58 --> No URI present. Default controller set.
INFO - 2022-02-13 18:57:58 --> Router Class Initialized
INFO - 2022-02-13 18:57:58 --> Output Class Initialized
INFO - 2022-02-13 18:57:58 --> Security Class Initialized
DEBUG - 2022-02-13 18:57:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-13 18:57:58 --> Input Class Initialized
INFO - 2022-02-13 18:57:58 --> Language Class Initialized
INFO - 2022-02-13 18:57:58 --> Loader Class Initialized
INFO - 2022-02-13 18:57:58 --> Helper loaded: url_helper
INFO - 2022-02-13 18:57:58 --> Helper loaded: form_helper
INFO - 2022-02-13 18:57:58 --> Helper loaded: common_helper
INFO - 2022-02-13 18:57:58 --> Database Driver Class Initialized
DEBUG - 2022-02-13 18:57:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-13 18:57:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-13 18:57:58 --> Controller Class Initialized
INFO - 2022-02-13 18:57:58 --> Form Validation Class Initialized
DEBUG - 2022-02-13 18:57:58 --> Encrypt Class Initialized
DEBUG - 2022-02-13 18:57:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-13 18:57:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-13 18:57:58 --> Email Class Initialized
INFO - 2022-02-13 18:57:58 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-13 18:57:58 --> Calendar Class Initialized
INFO - 2022-02-13 18:57:58 --> Model "Login_model" initialized
INFO - 2022-02-13 18:57:58 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-13 18:57:58 --> Final output sent to browser
DEBUG - 2022-02-13 18:57:58 --> Total execution time: 0.0285
ERROR - 2022-02-13 21:42:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-13 21:42:36 --> Config Class Initialized
INFO - 2022-02-13 21:42:36 --> Hooks Class Initialized
DEBUG - 2022-02-13 21:42:36 --> UTF-8 Support Enabled
INFO - 2022-02-13 21:42:36 --> Utf8 Class Initialized
INFO - 2022-02-13 21:42:36 --> URI Class Initialized
DEBUG - 2022-02-13 21:42:36 --> No URI present. Default controller set.
INFO - 2022-02-13 21:42:36 --> Router Class Initialized
INFO - 2022-02-13 21:42:36 --> Output Class Initialized
INFO - 2022-02-13 21:42:36 --> Security Class Initialized
DEBUG - 2022-02-13 21:42:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-13 21:42:36 --> Input Class Initialized
INFO - 2022-02-13 21:42:36 --> Language Class Initialized
INFO - 2022-02-13 21:42:36 --> Loader Class Initialized
INFO - 2022-02-13 21:42:36 --> Helper loaded: url_helper
INFO - 2022-02-13 21:42:36 --> Helper loaded: form_helper
INFO - 2022-02-13 21:42:36 --> Helper loaded: common_helper
INFO - 2022-02-13 21:42:36 --> Database Driver Class Initialized
DEBUG - 2022-02-13 21:42:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-13 21:42:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-13 21:42:36 --> Controller Class Initialized
INFO - 2022-02-13 21:42:36 --> Form Validation Class Initialized
DEBUG - 2022-02-13 21:42:36 --> Encrypt Class Initialized
DEBUG - 2022-02-13 21:42:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-13 21:42:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-13 21:42:36 --> Email Class Initialized
INFO - 2022-02-13 21:42:36 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-13 21:42:36 --> Calendar Class Initialized
INFO - 2022-02-13 21:42:36 --> Model "Login_model" initialized
INFO - 2022-02-13 21:42:36 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-13 21:42:36 --> Final output sent to browser
DEBUG - 2022-02-13 21:42:36 --> Total execution time: 0.0236
ERROR - 2022-02-13 22:47:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-13 22:47:49 --> Config Class Initialized
INFO - 2022-02-13 22:47:49 --> Hooks Class Initialized
DEBUG - 2022-02-13 22:47:49 --> UTF-8 Support Enabled
INFO - 2022-02-13 22:47:49 --> Utf8 Class Initialized
INFO - 2022-02-13 22:47:49 --> URI Class Initialized
DEBUG - 2022-02-13 22:47:49 --> No URI present. Default controller set.
INFO - 2022-02-13 22:47:49 --> Router Class Initialized
INFO - 2022-02-13 22:47:49 --> Output Class Initialized
INFO - 2022-02-13 22:47:49 --> Security Class Initialized
DEBUG - 2022-02-13 22:47:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-13 22:47:49 --> Input Class Initialized
INFO - 2022-02-13 22:47:49 --> Language Class Initialized
INFO - 2022-02-13 22:47:49 --> Loader Class Initialized
INFO - 2022-02-13 22:47:49 --> Helper loaded: url_helper
INFO - 2022-02-13 22:47:49 --> Helper loaded: form_helper
INFO - 2022-02-13 22:47:49 --> Helper loaded: common_helper
INFO - 2022-02-13 22:47:49 --> Database Driver Class Initialized
DEBUG - 2022-02-13 22:47:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-13 22:47:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-13 22:47:49 --> Controller Class Initialized
INFO - 2022-02-13 22:47:49 --> Form Validation Class Initialized
DEBUG - 2022-02-13 22:47:49 --> Encrypt Class Initialized
DEBUG - 2022-02-13 22:47:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-13 22:47:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-13 22:47:49 --> Email Class Initialized
INFO - 2022-02-13 22:47:49 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-13 22:47:49 --> Calendar Class Initialized
INFO - 2022-02-13 22:47:49 --> Model "Login_model" initialized
INFO - 2022-02-13 22:47:49 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-13 22:47:49 --> Final output sent to browser
DEBUG - 2022-02-13 22:47:49 --> Total execution time: 0.0256
