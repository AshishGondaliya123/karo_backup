<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-03-09 00:03:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 00:03:55 --> Config Class Initialized
INFO - 2022-03-09 00:03:55 --> Hooks Class Initialized
DEBUG - 2022-03-09 00:03:55 --> UTF-8 Support Enabled
INFO - 2022-03-09 00:03:55 --> Utf8 Class Initialized
INFO - 2022-03-09 00:03:55 --> URI Class Initialized
INFO - 2022-03-09 00:03:55 --> Router Class Initialized
INFO - 2022-03-09 00:03:55 --> Output Class Initialized
INFO - 2022-03-09 00:03:55 --> Security Class Initialized
DEBUG - 2022-03-09 00:03:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 00:03:55 --> Input Class Initialized
INFO - 2022-03-09 00:03:55 --> Language Class Initialized
INFO - 2022-03-09 00:03:55 --> Loader Class Initialized
INFO - 2022-03-09 00:03:55 --> Helper loaded: url_helper
INFO - 2022-03-09 00:03:55 --> Helper loaded: form_helper
INFO - 2022-03-09 00:03:55 --> Helper loaded: common_helper
INFO - 2022-03-09 00:03:55 --> Database Driver Class Initialized
DEBUG - 2022-03-09 00:03:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 00:03:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 00:03:55 --> Controller Class Initialized
INFO - 2022-03-09 00:03:55 --> Form Validation Class Initialized
DEBUG - 2022-03-09 00:03:55 --> Encrypt Class Initialized
DEBUG - 2022-03-09 00:03:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-09 00:03:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-09 00:03:55 --> Email Class Initialized
INFO - 2022-03-09 00:03:55 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-09 00:03:55 --> Calendar Class Initialized
INFO - 2022-03-09 00:03:55 --> Model "Login_model" initialized
ERROR - 2022-03-09 00:03:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 00:03:59 --> Config Class Initialized
INFO - 2022-03-09 00:03:59 --> Hooks Class Initialized
DEBUG - 2022-03-09 00:03:59 --> UTF-8 Support Enabled
INFO - 2022-03-09 00:03:59 --> Utf8 Class Initialized
INFO - 2022-03-09 00:03:59 --> URI Class Initialized
INFO - 2022-03-09 00:03:59 --> Router Class Initialized
INFO - 2022-03-09 00:03:59 --> Output Class Initialized
INFO - 2022-03-09 00:03:59 --> Security Class Initialized
DEBUG - 2022-03-09 00:03:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 00:03:59 --> Input Class Initialized
INFO - 2022-03-09 00:03:59 --> Language Class Initialized
INFO - 2022-03-09 00:03:59 --> Loader Class Initialized
INFO - 2022-03-09 00:03:59 --> Helper loaded: url_helper
INFO - 2022-03-09 00:03:59 --> Helper loaded: form_helper
INFO - 2022-03-09 00:03:59 --> Helper loaded: common_helper
INFO - 2022-03-09 00:03:59 --> Database Driver Class Initialized
DEBUG - 2022-03-09 00:03:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 00:03:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 00:03:59 --> Controller Class Initialized
INFO - 2022-03-09 00:03:59 --> Form Validation Class Initialized
DEBUG - 2022-03-09 00:03:59 --> Encrypt Class Initialized
INFO - 2022-03-09 00:03:59 --> Model "Patient_model" initialized
INFO - 2022-03-09 00:03:59 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 00:03:59 --> Model "Prefix_master" initialized
INFO - 2022-03-09 00:03:59 --> Model "Users_model" initialized
INFO - 2022-03-09 00:03:59 --> Model "Hospital_model" initialized
INFO - 2022-03-09 00:03:59 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 00:03:59 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-09 00:03:59 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 00:03:59 --> Final output sent to browser
DEBUG - 2022-03-09 00:03:59 --> Total execution time: 0.0830
ERROR - 2022-03-09 00:03:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 00:03:59 --> Config Class Initialized
INFO - 2022-03-09 00:03:59 --> Hooks Class Initialized
DEBUG - 2022-03-09 00:03:59 --> UTF-8 Support Enabled
INFO - 2022-03-09 00:03:59 --> Utf8 Class Initialized
INFO - 2022-03-09 00:03:59 --> URI Class Initialized
INFO - 2022-03-09 00:03:59 --> Router Class Initialized
INFO - 2022-03-09 00:03:59 --> Output Class Initialized
INFO - 2022-03-09 00:03:59 --> Security Class Initialized
DEBUG - 2022-03-09 00:03:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 00:03:59 --> Input Class Initialized
INFO - 2022-03-09 00:03:59 --> Language Class Initialized
ERROR - 2022-03-09 00:03:59 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-09 00:05:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 00:05:19 --> Config Class Initialized
INFO - 2022-03-09 00:05:19 --> Hooks Class Initialized
DEBUG - 2022-03-09 00:05:19 --> UTF-8 Support Enabled
INFO - 2022-03-09 00:05:19 --> Utf8 Class Initialized
INFO - 2022-03-09 00:05:19 --> URI Class Initialized
INFO - 2022-03-09 00:05:19 --> Router Class Initialized
INFO - 2022-03-09 00:05:19 --> Output Class Initialized
INFO - 2022-03-09 00:05:19 --> Security Class Initialized
DEBUG - 2022-03-09 00:05:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 00:05:19 --> Input Class Initialized
INFO - 2022-03-09 00:05:19 --> Language Class Initialized
INFO - 2022-03-09 00:05:19 --> Loader Class Initialized
INFO - 2022-03-09 00:05:19 --> Helper loaded: url_helper
INFO - 2022-03-09 00:05:19 --> Helper loaded: form_helper
INFO - 2022-03-09 00:05:19 --> Helper loaded: common_helper
INFO - 2022-03-09 00:05:19 --> Database Driver Class Initialized
DEBUG - 2022-03-09 00:05:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 00:05:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 00:05:19 --> Controller Class Initialized
INFO - 2022-03-09 00:05:19 --> Form Validation Class Initialized
DEBUG - 2022-03-09 00:05:19 --> Encrypt Class Initialized
DEBUG - 2022-03-09 00:05:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-09 00:05:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-09 00:05:19 --> Email Class Initialized
INFO - 2022-03-09 00:05:19 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-09 00:05:19 --> Calendar Class Initialized
INFO - 2022-03-09 00:05:19 --> Model "Login_model" initialized
ERROR - 2022-03-09 00:05:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 00:05:20 --> Config Class Initialized
INFO - 2022-03-09 00:05:20 --> Hooks Class Initialized
DEBUG - 2022-03-09 00:05:20 --> UTF-8 Support Enabled
INFO - 2022-03-09 00:05:20 --> Utf8 Class Initialized
INFO - 2022-03-09 00:05:20 --> URI Class Initialized
INFO - 2022-03-09 00:05:20 --> Router Class Initialized
INFO - 2022-03-09 00:05:20 --> Output Class Initialized
INFO - 2022-03-09 00:05:20 --> Security Class Initialized
DEBUG - 2022-03-09 00:05:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 00:05:20 --> Input Class Initialized
INFO - 2022-03-09 00:05:20 --> Language Class Initialized
INFO - 2022-03-09 00:05:20 --> Loader Class Initialized
INFO - 2022-03-09 00:05:20 --> Helper loaded: url_helper
INFO - 2022-03-09 00:05:20 --> Helper loaded: form_helper
INFO - 2022-03-09 00:05:20 --> Helper loaded: common_helper
INFO - 2022-03-09 00:05:20 --> Database Driver Class Initialized
DEBUG - 2022-03-09 00:05:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 00:05:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 00:05:20 --> Controller Class Initialized
INFO - 2022-03-09 00:05:20 --> Form Validation Class Initialized
DEBUG - 2022-03-09 00:05:20 --> Encrypt Class Initialized
INFO - 2022-03-09 00:05:20 --> Model "Diseases_model" initialized
INFO - 2022-03-09 00:05:20 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 00:05:20 --> File loaded: /home3/karoteam/public_html/application/views/diseases/index.php
INFO - 2022-03-09 00:05:20 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 00:05:20 --> Final output sent to browser
DEBUG - 2022-03-09 00:05:20 --> Total execution time: 0.0898
ERROR - 2022-03-09 00:08:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 00:08:09 --> Config Class Initialized
INFO - 2022-03-09 00:08:09 --> Hooks Class Initialized
DEBUG - 2022-03-09 00:08:09 --> UTF-8 Support Enabled
INFO - 2022-03-09 00:08:09 --> Utf8 Class Initialized
INFO - 2022-03-09 00:08:09 --> URI Class Initialized
INFO - 2022-03-09 00:08:09 --> Router Class Initialized
INFO - 2022-03-09 00:08:09 --> Output Class Initialized
INFO - 2022-03-09 00:08:09 --> Security Class Initialized
DEBUG - 2022-03-09 00:08:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 00:08:09 --> Input Class Initialized
INFO - 2022-03-09 00:08:09 --> Language Class Initialized
INFO - 2022-03-09 00:08:09 --> Loader Class Initialized
INFO - 2022-03-09 00:08:09 --> Helper loaded: url_helper
INFO - 2022-03-09 00:08:09 --> Helper loaded: form_helper
INFO - 2022-03-09 00:08:09 --> Helper loaded: common_helper
INFO - 2022-03-09 00:08:09 --> Database Driver Class Initialized
DEBUG - 2022-03-09 00:08:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 00:08:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 00:08:09 --> Controller Class Initialized
INFO - 2022-03-09 00:08:09 --> Form Validation Class Initialized
DEBUG - 2022-03-09 00:08:09 --> Encrypt Class Initialized
INFO - 2022-03-09 00:08:09 --> Model "Patient_model" initialized
INFO - 2022-03-09 00:08:09 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 00:08:09 --> Model "Referredby_model" initialized
INFO - 2022-03-09 00:08:09 --> Model "Prefix_master" initialized
INFO - 2022-03-09 00:08:09 --> Model "Hospital_model" initialized
INFO - 2022-03-09 00:08:09 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 00:08:09 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-09 00:08:09 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 00:08:09 --> Final output sent to browser
DEBUG - 2022-03-09 00:08:09 --> Total execution time: 0.0689
ERROR - 2022-03-09 00:08:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 00:08:16 --> Config Class Initialized
INFO - 2022-03-09 00:08:16 --> Hooks Class Initialized
DEBUG - 2022-03-09 00:08:16 --> UTF-8 Support Enabled
INFO - 2022-03-09 00:08:16 --> Utf8 Class Initialized
INFO - 2022-03-09 00:08:16 --> URI Class Initialized
INFO - 2022-03-09 00:08:16 --> Router Class Initialized
INFO - 2022-03-09 00:08:16 --> Output Class Initialized
INFO - 2022-03-09 00:08:16 --> Security Class Initialized
DEBUG - 2022-03-09 00:08:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 00:08:16 --> Input Class Initialized
INFO - 2022-03-09 00:08:16 --> Language Class Initialized
INFO - 2022-03-09 00:08:16 --> Loader Class Initialized
INFO - 2022-03-09 00:08:16 --> Helper loaded: url_helper
INFO - 2022-03-09 00:08:16 --> Helper loaded: form_helper
INFO - 2022-03-09 00:08:16 --> Helper loaded: common_helper
INFO - 2022-03-09 00:08:16 --> Database Driver Class Initialized
DEBUG - 2022-03-09 00:08:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 00:08:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 00:08:16 --> Controller Class Initialized
INFO - 2022-03-09 00:08:16 --> Form Validation Class Initialized
DEBUG - 2022-03-09 00:08:16 --> Encrypt Class Initialized
INFO - 2022-03-09 00:08:16 --> Model "Patient_model" initialized
INFO - 2022-03-09 00:08:16 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 00:08:16 --> Model "Referredby_model" initialized
INFO - 2022-03-09 00:08:16 --> Model "Prefix_master" initialized
INFO - 2022-03-09 00:08:16 --> Model "Hospital_model" initialized
INFO - 2022-03-09 00:08:16 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 00:08:16 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-09 00:08:16 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 00:08:16 --> Final output sent to browser
DEBUG - 2022-03-09 00:08:16 --> Total execution time: 0.0389
ERROR - 2022-03-09 00:08:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 00:08:51 --> Config Class Initialized
INFO - 2022-03-09 00:08:51 --> Hooks Class Initialized
DEBUG - 2022-03-09 00:08:51 --> UTF-8 Support Enabled
INFO - 2022-03-09 00:08:51 --> Utf8 Class Initialized
INFO - 2022-03-09 00:08:51 --> URI Class Initialized
INFO - 2022-03-09 00:08:51 --> Router Class Initialized
INFO - 2022-03-09 00:08:51 --> Output Class Initialized
INFO - 2022-03-09 00:08:51 --> Security Class Initialized
DEBUG - 2022-03-09 00:08:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 00:08:51 --> Input Class Initialized
INFO - 2022-03-09 00:08:51 --> Language Class Initialized
INFO - 2022-03-09 00:08:51 --> Loader Class Initialized
INFO - 2022-03-09 00:08:51 --> Helper loaded: url_helper
INFO - 2022-03-09 00:08:51 --> Helper loaded: form_helper
INFO - 2022-03-09 00:08:51 --> Helper loaded: common_helper
INFO - 2022-03-09 00:08:51 --> Database Driver Class Initialized
DEBUG - 2022-03-09 00:08:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 00:08:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 00:08:51 --> Controller Class Initialized
INFO - 2022-03-09 00:08:51 --> Form Validation Class Initialized
DEBUG - 2022-03-09 00:08:51 --> Encrypt Class Initialized
INFO - 2022-03-09 00:08:51 --> Model "Patient_model" initialized
INFO - 2022-03-09 00:08:51 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 00:08:51 --> Model "Referredby_model" initialized
INFO - 2022-03-09 00:08:51 --> Model "Prefix_master" initialized
INFO - 2022-03-09 00:08:51 --> Model "Hospital_model" initialized
ERROR - 2022-03-09 00:08:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 00:08:51 --> Config Class Initialized
INFO - 2022-03-09 00:08:51 --> Hooks Class Initialized
DEBUG - 2022-03-09 00:08:51 --> UTF-8 Support Enabled
INFO - 2022-03-09 00:08:51 --> Utf8 Class Initialized
INFO - 2022-03-09 00:08:51 --> URI Class Initialized
INFO - 2022-03-09 00:08:51 --> Router Class Initialized
INFO - 2022-03-09 00:08:52 --> Output Class Initialized
INFO - 2022-03-09 00:08:52 --> Security Class Initialized
DEBUG - 2022-03-09 00:08:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 00:08:52 --> Input Class Initialized
INFO - 2022-03-09 00:08:52 --> Language Class Initialized
INFO - 2022-03-09 00:08:52 --> Loader Class Initialized
INFO - 2022-03-09 00:08:52 --> Helper loaded: url_helper
INFO - 2022-03-09 00:08:52 --> Helper loaded: form_helper
INFO - 2022-03-09 00:08:52 --> Helper loaded: common_helper
INFO - 2022-03-09 00:08:52 --> Database Driver Class Initialized
DEBUG - 2022-03-09 00:08:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 00:08:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 00:08:52 --> Controller Class Initialized
INFO - 2022-03-09 00:08:52 --> Form Validation Class Initialized
DEBUG - 2022-03-09 00:08:52 --> Encrypt Class Initialized
INFO - 2022-03-09 00:08:52 --> Model "Patient_model" initialized
INFO - 2022-03-09 00:08:52 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 00:08:52 --> Model "Referredby_model" initialized
INFO - 2022-03-09 00:08:52 --> Model "Prefix_master" initialized
INFO - 2022-03-09 00:08:52 --> Model "Hospital_model" initialized
INFO - 2022-03-09 00:08:52 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 00:08:52 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-09 00:08:52 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 00:08:52 --> Final output sent to browser
DEBUG - 2022-03-09 00:08:52 --> Total execution time: 0.0899
ERROR - 2022-03-09 00:08:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 00:08:53 --> Config Class Initialized
INFO - 2022-03-09 00:08:53 --> Hooks Class Initialized
DEBUG - 2022-03-09 00:08:53 --> UTF-8 Support Enabled
INFO - 2022-03-09 00:08:53 --> Utf8 Class Initialized
INFO - 2022-03-09 00:08:53 --> URI Class Initialized
INFO - 2022-03-09 00:08:53 --> Router Class Initialized
INFO - 2022-03-09 00:08:53 --> Output Class Initialized
INFO - 2022-03-09 00:08:53 --> Security Class Initialized
DEBUG - 2022-03-09 00:08:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 00:08:53 --> Input Class Initialized
INFO - 2022-03-09 00:08:53 --> Language Class Initialized
INFO - 2022-03-09 00:08:53 --> Loader Class Initialized
INFO - 2022-03-09 00:08:53 --> Helper loaded: url_helper
INFO - 2022-03-09 00:08:53 --> Helper loaded: form_helper
INFO - 2022-03-09 00:08:53 --> Helper loaded: common_helper
INFO - 2022-03-09 00:08:53 --> Database Driver Class Initialized
DEBUG - 2022-03-09 00:08:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 00:08:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 00:08:53 --> Controller Class Initialized
INFO - 2022-03-09 00:08:53 --> Form Validation Class Initialized
DEBUG - 2022-03-09 00:08:53 --> Encrypt Class Initialized
INFO - 2022-03-09 00:08:53 --> Model "Patient_model" initialized
INFO - 2022-03-09 00:08:53 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 00:08:53 --> Model "Prefix_master" initialized
INFO - 2022-03-09 00:08:53 --> Model "Users_model" initialized
INFO - 2022-03-09 00:08:53 --> Model "Hospital_model" initialized
INFO - 2022-03-09 00:08:53 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 00:08:53 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-09 00:08:53 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 00:08:53 --> Final output sent to browser
DEBUG - 2022-03-09 00:08:53 --> Total execution time: 0.0999
ERROR - 2022-03-09 00:09:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 00:09:14 --> Config Class Initialized
INFO - 2022-03-09 00:09:14 --> Hooks Class Initialized
DEBUG - 2022-03-09 00:09:14 --> UTF-8 Support Enabled
INFO - 2022-03-09 00:09:14 --> Utf8 Class Initialized
INFO - 2022-03-09 00:09:14 --> URI Class Initialized
INFO - 2022-03-09 00:09:14 --> Router Class Initialized
INFO - 2022-03-09 00:09:14 --> Output Class Initialized
INFO - 2022-03-09 00:09:14 --> Security Class Initialized
DEBUG - 2022-03-09 00:09:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 00:09:14 --> Input Class Initialized
INFO - 2022-03-09 00:09:14 --> Language Class Initialized
INFO - 2022-03-09 00:09:14 --> Loader Class Initialized
INFO - 2022-03-09 00:09:14 --> Helper loaded: url_helper
INFO - 2022-03-09 00:09:14 --> Helper loaded: form_helper
INFO - 2022-03-09 00:09:14 --> Helper loaded: common_helper
INFO - 2022-03-09 00:09:14 --> Database Driver Class Initialized
DEBUG - 2022-03-09 00:09:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 00:09:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 00:09:14 --> Controller Class Initialized
INFO - 2022-03-09 00:09:14 --> Form Validation Class Initialized
DEBUG - 2022-03-09 00:09:14 --> Encrypt Class Initialized
INFO - 2022-03-09 00:09:14 --> Model "Patient_model" initialized
INFO - 2022-03-09 00:09:14 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 00:09:14 --> Model "Prefix_master" initialized
INFO - 2022-03-09 00:09:14 --> Model "Users_model" initialized
INFO - 2022-03-09 00:09:14 --> Model "Hospital_model" initialized
ERROR - 2022-03-09 00:09:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 00:09:14 --> Config Class Initialized
INFO - 2022-03-09 00:09:14 --> Hooks Class Initialized
DEBUG - 2022-03-09 00:09:14 --> UTF-8 Support Enabled
INFO - 2022-03-09 00:09:14 --> Utf8 Class Initialized
INFO - 2022-03-09 00:09:14 --> URI Class Initialized
INFO - 2022-03-09 00:09:14 --> Router Class Initialized
INFO - 2022-03-09 00:09:14 --> Output Class Initialized
INFO - 2022-03-09 00:09:14 --> Security Class Initialized
DEBUG - 2022-03-09 00:09:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 00:09:14 --> Input Class Initialized
INFO - 2022-03-09 00:09:14 --> Language Class Initialized
INFO - 2022-03-09 00:09:14 --> Loader Class Initialized
INFO - 2022-03-09 00:09:14 --> Helper loaded: url_helper
INFO - 2022-03-09 00:09:14 --> Helper loaded: form_helper
INFO - 2022-03-09 00:09:15 --> Helper loaded: common_helper
INFO - 2022-03-09 00:09:15 --> Database Driver Class Initialized
DEBUG - 2022-03-09 00:09:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 00:09:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 00:09:15 --> Controller Class Initialized
INFO - 2022-03-09 00:09:15 --> Form Validation Class Initialized
DEBUG - 2022-03-09 00:09:15 --> Encrypt Class Initialized
INFO - 2022-03-09 00:09:15 --> Model "Patient_model" initialized
INFO - 2022-03-09 00:09:15 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 00:09:15 --> Model "Prefix_master" initialized
INFO - 2022-03-09 00:09:15 --> Model "Users_model" initialized
INFO - 2022-03-09 00:09:15 --> Model "Hospital_model" initialized
INFO - 2022-03-09 00:09:15 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 00:09:15 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-09 00:09:15 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 00:09:15 --> Final output sent to browser
DEBUG - 2022-03-09 00:09:15 --> Total execution time: 0.1375
ERROR - 2022-03-09 00:09:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 00:09:46 --> Config Class Initialized
INFO - 2022-03-09 00:09:46 --> Hooks Class Initialized
DEBUG - 2022-03-09 00:09:46 --> UTF-8 Support Enabled
INFO - 2022-03-09 00:09:46 --> Utf8 Class Initialized
INFO - 2022-03-09 00:09:46 --> URI Class Initialized
INFO - 2022-03-09 00:09:46 --> Router Class Initialized
INFO - 2022-03-09 00:09:46 --> Output Class Initialized
INFO - 2022-03-09 00:09:46 --> Security Class Initialized
DEBUG - 2022-03-09 00:09:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 00:09:46 --> Input Class Initialized
INFO - 2022-03-09 00:09:46 --> Language Class Initialized
INFO - 2022-03-09 00:09:46 --> Loader Class Initialized
INFO - 2022-03-09 00:09:46 --> Helper loaded: url_helper
INFO - 2022-03-09 00:09:46 --> Helper loaded: form_helper
INFO - 2022-03-09 00:09:46 --> Helper loaded: common_helper
INFO - 2022-03-09 00:09:46 --> Database Driver Class Initialized
DEBUG - 2022-03-09 00:09:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 00:09:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 00:09:46 --> Controller Class Initialized
INFO - 2022-03-09 00:09:46 --> Form Validation Class Initialized
DEBUG - 2022-03-09 00:09:46 --> Encrypt Class Initialized
INFO - 2022-03-09 00:09:46 --> Model "Patient_model" initialized
INFO - 2022-03-09 00:09:46 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 00:09:46 --> Model "Prefix_master" initialized
INFO - 2022-03-09 00:09:46 --> Model "Users_model" initialized
INFO - 2022-03-09 00:09:46 --> Model "Hospital_model" initialized
ERROR - 2022-03-09 00:09:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 00:09:47 --> Config Class Initialized
INFO - 2022-03-09 00:09:47 --> Hooks Class Initialized
DEBUG - 2022-03-09 00:09:47 --> UTF-8 Support Enabled
INFO - 2022-03-09 00:09:47 --> Utf8 Class Initialized
INFO - 2022-03-09 00:09:47 --> URI Class Initialized
INFO - 2022-03-09 00:09:47 --> Router Class Initialized
INFO - 2022-03-09 00:09:47 --> Output Class Initialized
INFO - 2022-03-09 00:09:47 --> Security Class Initialized
DEBUG - 2022-03-09 00:09:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 00:09:47 --> Input Class Initialized
INFO - 2022-03-09 00:09:47 --> Language Class Initialized
INFO - 2022-03-09 00:09:47 --> Loader Class Initialized
INFO - 2022-03-09 00:09:47 --> Helper loaded: url_helper
INFO - 2022-03-09 00:09:47 --> Helper loaded: form_helper
INFO - 2022-03-09 00:09:47 --> Helper loaded: common_helper
INFO - 2022-03-09 00:09:47 --> Database Driver Class Initialized
DEBUG - 2022-03-09 00:09:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 00:09:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 00:09:47 --> Controller Class Initialized
INFO - 2022-03-09 00:09:47 --> Form Validation Class Initialized
DEBUG - 2022-03-09 00:09:47 --> Encrypt Class Initialized
INFO - 2022-03-09 00:09:47 --> Model "Patient_model" initialized
INFO - 2022-03-09 00:09:47 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 00:09:47 --> Model "Prefix_master" initialized
INFO - 2022-03-09 00:09:47 --> Model "Users_model" initialized
INFO - 2022-03-09 00:09:47 --> Model "Hospital_model" initialized
INFO - 2022-03-09 00:09:47 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 00:09:47 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-09 00:09:47 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 00:09:47 --> Final output sent to browser
DEBUG - 2022-03-09 00:09:47 --> Total execution time: 0.0829
ERROR - 2022-03-09 00:09:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 00:09:56 --> Config Class Initialized
INFO - 2022-03-09 00:09:56 --> Hooks Class Initialized
DEBUG - 2022-03-09 00:09:56 --> UTF-8 Support Enabled
INFO - 2022-03-09 00:09:56 --> Utf8 Class Initialized
INFO - 2022-03-09 00:09:56 --> URI Class Initialized
INFO - 2022-03-09 00:09:56 --> Router Class Initialized
INFO - 2022-03-09 00:09:56 --> Output Class Initialized
INFO - 2022-03-09 00:09:56 --> Security Class Initialized
DEBUG - 2022-03-09 00:09:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 00:09:56 --> Input Class Initialized
INFO - 2022-03-09 00:09:56 --> Language Class Initialized
INFO - 2022-03-09 00:09:56 --> Loader Class Initialized
INFO - 2022-03-09 00:09:56 --> Helper loaded: url_helper
INFO - 2022-03-09 00:09:56 --> Helper loaded: form_helper
INFO - 2022-03-09 00:09:56 --> Helper loaded: common_helper
INFO - 2022-03-09 00:09:56 --> Database Driver Class Initialized
DEBUG - 2022-03-09 00:09:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 00:09:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 00:09:56 --> Controller Class Initialized
INFO - 2022-03-09 00:09:56 --> Form Validation Class Initialized
DEBUG - 2022-03-09 00:09:56 --> Encrypt Class Initialized
INFO - 2022-03-09 00:09:56 --> Model "Patient_model" initialized
INFO - 2022-03-09 00:09:56 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 00:09:56 --> Model "Prefix_master" initialized
INFO - 2022-03-09 00:09:56 --> Model "Users_model" initialized
INFO - 2022-03-09 00:09:56 --> Model "Hospital_model" initialized
ERROR - 2022-03-09 00:09:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 00:09:56 --> Config Class Initialized
INFO - 2022-03-09 00:09:56 --> Hooks Class Initialized
DEBUG - 2022-03-09 00:09:56 --> UTF-8 Support Enabled
INFO - 2022-03-09 00:09:56 --> Utf8 Class Initialized
INFO - 2022-03-09 00:09:56 --> URI Class Initialized
INFO - 2022-03-09 00:09:56 --> Router Class Initialized
INFO - 2022-03-09 00:09:56 --> Output Class Initialized
INFO - 2022-03-09 00:09:56 --> Security Class Initialized
DEBUG - 2022-03-09 00:09:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 00:09:56 --> Input Class Initialized
INFO - 2022-03-09 00:09:56 --> Language Class Initialized
INFO - 2022-03-09 00:09:56 --> Loader Class Initialized
INFO - 2022-03-09 00:09:56 --> Helper loaded: url_helper
INFO - 2022-03-09 00:09:56 --> Helper loaded: form_helper
INFO - 2022-03-09 00:09:56 --> Helper loaded: common_helper
INFO - 2022-03-09 00:09:56 --> Database Driver Class Initialized
DEBUG - 2022-03-09 00:09:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 00:09:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 00:09:56 --> Controller Class Initialized
INFO - 2022-03-09 00:09:56 --> Form Validation Class Initialized
DEBUG - 2022-03-09 00:09:56 --> Encrypt Class Initialized
INFO - 2022-03-09 00:09:56 --> Model "Patient_model" initialized
INFO - 2022-03-09 00:09:56 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 00:09:56 --> Model "Prefix_master" initialized
INFO - 2022-03-09 00:09:56 --> Model "Users_model" initialized
INFO - 2022-03-09 00:09:56 --> Model "Hospital_model" initialized
INFO - 2022-03-09 00:09:56 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 00:09:56 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-09 00:09:56 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 00:09:56 --> Final output sent to browser
DEBUG - 2022-03-09 00:09:56 --> Total execution time: 0.0577
ERROR - 2022-03-09 00:10:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 00:10:22 --> Config Class Initialized
INFO - 2022-03-09 00:10:22 --> Hooks Class Initialized
DEBUG - 2022-03-09 00:10:22 --> UTF-8 Support Enabled
INFO - 2022-03-09 00:10:22 --> Utf8 Class Initialized
INFO - 2022-03-09 00:10:22 --> URI Class Initialized
INFO - 2022-03-09 00:10:22 --> Router Class Initialized
INFO - 2022-03-09 00:10:22 --> Output Class Initialized
INFO - 2022-03-09 00:10:22 --> Security Class Initialized
DEBUG - 2022-03-09 00:10:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 00:10:22 --> Input Class Initialized
INFO - 2022-03-09 00:10:22 --> Language Class Initialized
INFO - 2022-03-09 00:10:22 --> Loader Class Initialized
INFO - 2022-03-09 00:10:22 --> Helper loaded: url_helper
INFO - 2022-03-09 00:10:22 --> Helper loaded: form_helper
INFO - 2022-03-09 00:10:22 --> Helper loaded: common_helper
INFO - 2022-03-09 00:10:22 --> Database Driver Class Initialized
DEBUG - 2022-03-09 00:10:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 00:10:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 00:10:22 --> Controller Class Initialized
INFO - 2022-03-09 00:10:22 --> Form Validation Class Initialized
DEBUG - 2022-03-09 00:10:22 --> Encrypt Class Initialized
INFO - 2022-03-09 00:10:22 --> Model "Patient_model" initialized
INFO - 2022-03-09 00:10:22 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 00:10:22 --> Model "Referredby_model" initialized
INFO - 2022-03-09 00:10:22 --> Model "Prefix_master" initialized
INFO - 2022-03-09 00:10:22 --> Model "Hospital_model" initialized
INFO - 2022-03-09 00:10:22 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 00:10:22 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-09 00:10:22 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 00:10:22 --> Final output sent to browser
DEBUG - 2022-03-09 00:10:22 --> Total execution time: 0.0644
ERROR - 2022-03-09 00:10:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 00:10:24 --> Config Class Initialized
INFO - 2022-03-09 00:10:24 --> Hooks Class Initialized
DEBUG - 2022-03-09 00:10:24 --> UTF-8 Support Enabled
INFO - 2022-03-09 00:10:24 --> Utf8 Class Initialized
INFO - 2022-03-09 00:10:24 --> URI Class Initialized
INFO - 2022-03-09 00:10:24 --> Router Class Initialized
INFO - 2022-03-09 00:10:24 --> Output Class Initialized
INFO - 2022-03-09 00:10:24 --> Security Class Initialized
DEBUG - 2022-03-09 00:10:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 00:10:24 --> Input Class Initialized
INFO - 2022-03-09 00:10:24 --> Language Class Initialized
INFO - 2022-03-09 00:10:24 --> Loader Class Initialized
INFO - 2022-03-09 00:10:24 --> Helper loaded: url_helper
INFO - 2022-03-09 00:10:24 --> Helper loaded: form_helper
INFO - 2022-03-09 00:10:24 --> Helper loaded: common_helper
INFO - 2022-03-09 00:10:24 --> Database Driver Class Initialized
DEBUG - 2022-03-09 00:10:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 00:10:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 00:10:24 --> Controller Class Initialized
INFO - 2022-03-09 00:10:24 --> Form Validation Class Initialized
DEBUG - 2022-03-09 00:10:24 --> Encrypt Class Initialized
INFO - 2022-03-09 00:10:24 --> Model "Patient_model" initialized
INFO - 2022-03-09 00:10:24 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 00:10:24 --> Model "Referredby_model" initialized
INFO - 2022-03-09 00:10:24 --> Model "Prefix_master" initialized
INFO - 2022-03-09 00:10:24 --> Model "Hospital_model" initialized
INFO - 2022-03-09 00:10:24 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 00:10:24 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-09 00:10:24 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 00:10:24 --> Final output sent to browser
DEBUG - 2022-03-09 00:10:24 --> Total execution time: 0.0489
ERROR - 2022-03-09 00:10:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 00:10:36 --> Config Class Initialized
INFO - 2022-03-09 00:10:36 --> Hooks Class Initialized
DEBUG - 2022-03-09 00:10:36 --> UTF-8 Support Enabled
INFO - 2022-03-09 00:10:36 --> Utf8 Class Initialized
INFO - 2022-03-09 00:10:36 --> URI Class Initialized
INFO - 2022-03-09 00:10:36 --> Router Class Initialized
INFO - 2022-03-09 00:10:36 --> Output Class Initialized
INFO - 2022-03-09 00:10:36 --> Security Class Initialized
DEBUG - 2022-03-09 00:10:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 00:10:36 --> Input Class Initialized
INFO - 2022-03-09 00:10:36 --> Language Class Initialized
INFO - 2022-03-09 00:10:36 --> Loader Class Initialized
INFO - 2022-03-09 00:10:36 --> Helper loaded: url_helper
INFO - 2022-03-09 00:10:36 --> Helper loaded: form_helper
INFO - 2022-03-09 00:10:36 --> Helper loaded: common_helper
INFO - 2022-03-09 00:10:36 --> Database Driver Class Initialized
DEBUG - 2022-03-09 00:10:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 00:10:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 00:10:36 --> Controller Class Initialized
INFO - 2022-03-09 00:10:36 --> Form Validation Class Initialized
DEBUG - 2022-03-09 00:10:36 --> Encrypt Class Initialized
INFO - 2022-03-09 00:10:36 --> Model "Patient_model" initialized
INFO - 2022-03-09 00:10:36 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 00:10:36 --> Model "Prefix_master" initialized
INFO - 2022-03-09 00:10:36 --> Model "Users_model" initialized
INFO - 2022-03-09 00:10:36 --> Model "Hospital_model" initialized
INFO - 2022-03-09 00:10:36 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-09 00:10:37 --> Final output sent to browser
DEBUG - 2022-03-09 00:10:37 --> Total execution time: 0.8911
ERROR - 2022-03-09 00:11:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 00:11:09 --> Config Class Initialized
INFO - 2022-03-09 00:11:09 --> Hooks Class Initialized
DEBUG - 2022-03-09 00:11:09 --> UTF-8 Support Enabled
INFO - 2022-03-09 00:11:09 --> Utf8 Class Initialized
INFO - 2022-03-09 00:11:09 --> URI Class Initialized
INFO - 2022-03-09 00:11:09 --> Router Class Initialized
INFO - 2022-03-09 00:11:09 --> Output Class Initialized
INFO - 2022-03-09 00:11:09 --> Security Class Initialized
DEBUG - 2022-03-09 00:11:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 00:11:09 --> Input Class Initialized
INFO - 2022-03-09 00:11:09 --> Language Class Initialized
INFO - 2022-03-09 00:11:09 --> Loader Class Initialized
INFO - 2022-03-09 00:11:09 --> Helper loaded: url_helper
INFO - 2022-03-09 00:11:09 --> Helper loaded: form_helper
INFO - 2022-03-09 00:11:09 --> Helper loaded: common_helper
INFO - 2022-03-09 00:11:09 --> Database Driver Class Initialized
DEBUG - 2022-03-09 00:11:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 00:11:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 00:11:09 --> Controller Class Initialized
INFO - 2022-03-09 00:11:09 --> Form Validation Class Initialized
DEBUG - 2022-03-09 00:11:09 --> Encrypt Class Initialized
INFO - 2022-03-09 00:11:09 --> Model "Patient_model" initialized
INFO - 2022-03-09 00:11:09 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 00:11:09 --> Model "Referredby_model" initialized
INFO - 2022-03-09 00:11:09 --> Model "Prefix_master" initialized
INFO - 2022-03-09 00:11:09 --> Model "Hospital_model" initialized
INFO - 2022-03-09 00:11:09 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 00:11:09 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-09 00:11:09 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 00:11:09 --> Final output sent to browser
DEBUG - 2022-03-09 00:11:09 --> Total execution time: 0.0460
ERROR - 2022-03-09 00:11:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 00:11:10 --> Config Class Initialized
INFO - 2022-03-09 00:11:10 --> Hooks Class Initialized
DEBUG - 2022-03-09 00:11:10 --> UTF-8 Support Enabled
INFO - 2022-03-09 00:11:10 --> Utf8 Class Initialized
INFO - 2022-03-09 00:11:10 --> URI Class Initialized
INFO - 2022-03-09 00:11:10 --> Router Class Initialized
INFO - 2022-03-09 00:11:10 --> Output Class Initialized
INFO - 2022-03-09 00:11:10 --> Security Class Initialized
DEBUG - 2022-03-09 00:11:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 00:11:10 --> Input Class Initialized
INFO - 2022-03-09 00:11:10 --> Language Class Initialized
ERROR - 2022-03-09 00:11:10 --> 404 Page Not Found: Karoclient/images
ERROR - 2022-03-09 00:12:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 00:12:49 --> Config Class Initialized
INFO - 2022-03-09 00:12:49 --> Hooks Class Initialized
DEBUG - 2022-03-09 00:12:49 --> UTF-8 Support Enabled
INFO - 2022-03-09 00:12:49 --> Utf8 Class Initialized
INFO - 2022-03-09 00:12:49 --> URI Class Initialized
INFO - 2022-03-09 00:12:49 --> Router Class Initialized
INFO - 2022-03-09 00:12:49 --> Output Class Initialized
INFO - 2022-03-09 00:12:49 --> Security Class Initialized
DEBUG - 2022-03-09 00:12:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 00:12:49 --> Input Class Initialized
INFO - 2022-03-09 00:12:49 --> Language Class Initialized
INFO - 2022-03-09 00:12:49 --> Loader Class Initialized
INFO - 2022-03-09 00:12:49 --> Helper loaded: url_helper
INFO - 2022-03-09 00:12:49 --> Helper loaded: form_helper
INFO - 2022-03-09 00:12:49 --> Helper loaded: common_helper
INFO - 2022-03-09 00:12:49 --> Database Driver Class Initialized
DEBUG - 2022-03-09 00:12:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 00:12:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 00:12:49 --> Controller Class Initialized
INFO - 2022-03-09 00:12:49 --> Form Validation Class Initialized
DEBUG - 2022-03-09 00:12:49 --> Encrypt Class Initialized
INFO - 2022-03-09 00:12:49 --> Model "Patient_model" initialized
INFO - 2022-03-09 00:12:49 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 00:12:49 --> Model "Referredby_model" initialized
INFO - 2022-03-09 00:12:49 --> Model "Prefix_master" initialized
INFO - 2022-03-09 00:12:49 --> Model "Hospital_model" initialized
INFO - 2022-03-09 00:12:49 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 00:12:49 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-09 00:12:49 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 00:12:49 --> Final output sent to browser
DEBUG - 2022-03-09 00:12:49 --> Total execution time: 0.0426
ERROR - 2022-03-09 00:14:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 00:14:38 --> Config Class Initialized
INFO - 2022-03-09 00:14:38 --> Hooks Class Initialized
DEBUG - 2022-03-09 00:14:38 --> UTF-8 Support Enabled
INFO - 2022-03-09 00:14:38 --> Utf8 Class Initialized
INFO - 2022-03-09 00:14:38 --> URI Class Initialized
INFO - 2022-03-09 00:14:38 --> Router Class Initialized
INFO - 2022-03-09 00:14:38 --> Output Class Initialized
INFO - 2022-03-09 00:14:38 --> Security Class Initialized
DEBUG - 2022-03-09 00:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 00:14:38 --> Input Class Initialized
INFO - 2022-03-09 00:14:38 --> Language Class Initialized
INFO - 2022-03-09 00:14:38 --> Loader Class Initialized
INFO - 2022-03-09 00:14:38 --> Helper loaded: url_helper
INFO - 2022-03-09 00:14:38 --> Helper loaded: form_helper
INFO - 2022-03-09 00:14:38 --> Helper loaded: common_helper
INFO - 2022-03-09 00:14:38 --> Database Driver Class Initialized
DEBUG - 2022-03-09 00:14:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 00:14:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 00:14:38 --> Controller Class Initialized
INFO - 2022-03-09 00:14:38 --> Form Validation Class Initialized
DEBUG - 2022-03-09 00:14:38 --> Encrypt Class Initialized
INFO - 2022-03-09 00:14:38 --> Model "Patient_model" initialized
INFO - 2022-03-09 00:14:38 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 00:14:38 --> Model "Prefix_master" initialized
INFO - 2022-03-09 00:14:38 --> Model "Users_model" initialized
INFO - 2022-03-09 00:14:38 --> Model "Hospital_model" initialized
ERROR - 2022-03-09 00:14:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 00:14:38 --> Config Class Initialized
INFO - 2022-03-09 00:14:38 --> Hooks Class Initialized
DEBUG - 2022-03-09 00:14:38 --> UTF-8 Support Enabled
INFO - 2022-03-09 00:14:38 --> Utf8 Class Initialized
INFO - 2022-03-09 00:14:38 --> URI Class Initialized
INFO - 2022-03-09 00:14:38 --> Router Class Initialized
INFO - 2022-03-09 00:14:38 --> Output Class Initialized
INFO - 2022-03-09 00:14:38 --> Security Class Initialized
DEBUG - 2022-03-09 00:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 00:14:38 --> Input Class Initialized
INFO - 2022-03-09 00:14:38 --> Language Class Initialized
INFO - 2022-03-09 00:14:38 --> Loader Class Initialized
INFO - 2022-03-09 00:14:38 --> Helper loaded: url_helper
INFO - 2022-03-09 00:14:38 --> Helper loaded: form_helper
INFO - 2022-03-09 00:14:38 --> Helper loaded: common_helper
INFO - 2022-03-09 00:14:38 --> Database Driver Class Initialized
DEBUG - 2022-03-09 00:14:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 00:14:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 00:14:38 --> Controller Class Initialized
INFO - 2022-03-09 00:14:38 --> Form Validation Class Initialized
DEBUG - 2022-03-09 00:14:38 --> Encrypt Class Initialized
INFO - 2022-03-09 00:14:38 --> Model "Patient_model" initialized
INFO - 2022-03-09 00:14:38 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 00:14:38 --> Model "Prefix_master" initialized
INFO - 2022-03-09 00:14:38 --> Model "Users_model" initialized
INFO - 2022-03-09 00:14:38 --> Model "Hospital_model" initialized
INFO - 2022-03-09 00:14:38 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 00:14:38 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-09 00:14:38 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 00:14:38 --> Final output sent to browser
DEBUG - 2022-03-09 00:14:38 --> Total execution time: 0.0547
ERROR - 2022-03-09 00:18:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 00:18:38 --> Config Class Initialized
INFO - 2022-03-09 00:18:38 --> Hooks Class Initialized
DEBUG - 2022-03-09 00:18:38 --> UTF-8 Support Enabled
INFO - 2022-03-09 00:18:38 --> Utf8 Class Initialized
INFO - 2022-03-09 00:18:38 --> URI Class Initialized
INFO - 2022-03-09 00:18:38 --> Router Class Initialized
INFO - 2022-03-09 00:18:38 --> Output Class Initialized
INFO - 2022-03-09 00:18:38 --> Security Class Initialized
DEBUG - 2022-03-09 00:18:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 00:18:38 --> Input Class Initialized
INFO - 2022-03-09 00:18:38 --> Language Class Initialized
INFO - 2022-03-09 00:18:38 --> Loader Class Initialized
INFO - 2022-03-09 00:18:38 --> Helper loaded: url_helper
INFO - 2022-03-09 00:18:38 --> Helper loaded: form_helper
INFO - 2022-03-09 00:18:38 --> Helper loaded: common_helper
INFO - 2022-03-09 00:18:38 --> Database Driver Class Initialized
DEBUG - 2022-03-09 00:18:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 00:18:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 00:18:38 --> Controller Class Initialized
INFO - 2022-03-09 00:18:38 --> Form Validation Class Initialized
DEBUG - 2022-03-09 00:18:38 --> Encrypt Class Initialized
INFO - 2022-03-09 00:18:38 --> Model "Patient_model" initialized
INFO - 2022-03-09 00:18:38 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 00:18:38 --> Model "Referredby_model" initialized
INFO - 2022-03-09 00:18:38 --> Model "Prefix_master" initialized
INFO - 2022-03-09 00:18:38 --> Model "Hospital_model" initialized
ERROR - 2022-03-09 00:18:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 00:18:39 --> Config Class Initialized
INFO - 2022-03-09 00:18:39 --> Hooks Class Initialized
DEBUG - 2022-03-09 00:18:39 --> UTF-8 Support Enabled
INFO - 2022-03-09 00:18:39 --> Utf8 Class Initialized
INFO - 2022-03-09 00:18:39 --> URI Class Initialized
INFO - 2022-03-09 00:18:39 --> Router Class Initialized
INFO - 2022-03-09 00:18:39 --> Output Class Initialized
INFO - 2022-03-09 00:18:39 --> Security Class Initialized
DEBUG - 2022-03-09 00:18:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 00:18:39 --> Input Class Initialized
INFO - 2022-03-09 00:18:39 --> Language Class Initialized
INFO - 2022-03-09 00:18:39 --> Loader Class Initialized
INFO - 2022-03-09 00:18:39 --> Helper loaded: url_helper
INFO - 2022-03-09 00:18:39 --> Helper loaded: form_helper
INFO - 2022-03-09 00:18:39 --> Helper loaded: common_helper
INFO - 2022-03-09 00:18:39 --> Database Driver Class Initialized
DEBUG - 2022-03-09 00:18:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 00:18:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 00:18:39 --> Controller Class Initialized
INFO - 2022-03-09 00:18:39 --> Form Validation Class Initialized
DEBUG - 2022-03-09 00:18:39 --> Encrypt Class Initialized
INFO - 2022-03-09 00:18:39 --> Model "Patient_model" initialized
INFO - 2022-03-09 00:18:39 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 00:18:39 --> Model "Referredby_model" initialized
INFO - 2022-03-09 00:18:39 --> Model "Prefix_master" initialized
INFO - 2022-03-09 00:18:39 --> Model "Hospital_model" initialized
INFO - 2022-03-09 00:18:39 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 00:18:39 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-09 00:18:39 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 00:18:39 --> Final output sent to browser
DEBUG - 2022-03-09 00:18:39 --> Total execution time: 0.0530
ERROR - 2022-03-09 00:18:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 00:18:40 --> Config Class Initialized
INFO - 2022-03-09 00:18:40 --> Hooks Class Initialized
DEBUG - 2022-03-09 00:18:40 --> UTF-8 Support Enabled
INFO - 2022-03-09 00:18:40 --> Utf8 Class Initialized
INFO - 2022-03-09 00:18:40 --> URI Class Initialized
INFO - 2022-03-09 00:18:40 --> Router Class Initialized
INFO - 2022-03-09 00:18:40 --> Output Class Initialized
INFO - 2022-03-09 00:18:40 --> Security Class Initialized
DEBUG - 2022-03-09 00:18:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 00:18:40 --> Input Class Initialized
INFO - 2022-03-09 00:18:40 --> Language Class Initialized
INFO - 2022-03-09 00:18:40 --> Loader Class Initialized
INFO - 2022-03-09 00:18:40 --> Helper loaded: url_helper
INFO - 2022-03-09 00:18:40 --> Helper loaded: form_helper
INFO - 2022-03-09 00:18:40 --> Helper loaded: common_helper
INFO - 2022-03-09 00:18:40 --> Database Driver Class Initialized
DEBUG - 2022-03-09 00:18:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 00:18:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 00:18:40 --> Controller Class Initialized
INFO - 2022-03-09 00:18:40 --> Form Validation Class Initialized
DEBUG - 2022-03-09 00:18:40 --> Encrypt Class Initialized
INFO - 2022-03-09 00:18:40 --> Model "Patient_model" initialized
INFO - 2022-03-09 00:18:40 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 00:18:40 --> Model "Prefix_master" initialized
INFO - 2022-03-09 00:18:40 --> Model "Users_model" initialized
INFO - 2022-03-09 00:18:40 --> Model "Hospital_model" initialized
INFO - 2022-03-09 00:18:40 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 00:18:40 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-09 00:18:40 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 00:18:40 --> Final output sent to browser
DEBUG - 2022-03-09 00:18:40 --> Total execution time: 0.0631
ERROR - 2022-03-09 00:19:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 00:19:16 --> Config Class Initialized
INFO - 2022-03-09 00:19:16 --> Hooks Class Initialized
DEBUG - 2022-03-09 00:19:16 --> UTF-8 Support Enabled
INFO - 2022-03-09 00:19:16 --> Utf8 Class Initialized
INFO - 2022-03-09 00:19:16 --> URI Class Initialized
INFO - 2022-03-09 00:19:16 --> Router Class Initialized
INFO - 2022-03-09 00:19:16 --> Output Class Initialized
INFO - 2022-03-09 00:19:16 --> Security Class Initialized
DEBUG - 2022-03-09 00:19:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 00:19:16 --> Input Class Initialized
INFO - 2022-03-09 00:19:16 --> Language Class Initialized
INFO - 2022-03-09 00:19:16 --> Loader Class Initialized
INFO - 2022-03-09 00:19:16 --> Helper loaded: url_helper
INFO - 2022-03-09 00:19:16 --> Helper loaded: form_helper
INFO - 2022-03-09 00:19:16 --> Helper loaded: common_helper
INFO - 2022-03-09 00:19:16 --> Database Driver Class Initialized
DEBUG - 2022-03-09 00:19:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 00:19:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 00:19:16 --> Controller Class Initialized
INFO - 2022-03-09 00:19:16 --> Form Validation Class Initialized
DEBUG - 2022-03-09 00:19:16 --> Encrypt Class Initialized
INFO - 2022-03-09 00:19:16 --> Model "Patient_model" initialized
INFO - 2022-03-09 00:19:16 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 00:19:16 --> Model "Prefix_master" initialized
INFO - 2022-03-09 00:19:16 --> Model "Users_model" initialized
INFO - 2022-03-09 00:19:16 --> Model "Hospital_model" initialized
ERROR - 2022-03-09 00:19:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 00:19:16 --> Config Class Initialized
INFO - 2022-03-09 00:19:16 --> Hooks Class Initialized
DEBUG - 2022-03-09 00:19:16 --> UTF-8 Support Enabled
INFO - 2022-03-09 00:19:16 --> Utf8 Class Initialized
INFO - 2022-03-09 00:19:16 --> URI Class Initialized
INFO - 2022-03-09 00:19:16 --> Router Class Initialized
INFO - 2022-03-09 00:19:16 --> Output Class Initialized
INFO - 2022-03-09 00:19:16 --> Security Class Initialized
DEBUG - 2022-03-09 00:19:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 00:19:16 --> Input Class Initialized
INFO - 2022-03-09 00:19:16 --> Language Class Initialized
INFO - 2022-03-09 00:19:16 --> Loader Class Initialized
INFO - 2022-03-09 00:19:16 --> Helper loaded: url_helper
INFO - 2022-03-09 00:19:16 --> Helper loaded: form_helper
INFO - 2022-03-09 00:19:16 --> Helper loaded: common_helper
INFO - 2022-03-09 00:19:16 --> Database Driver Class Initialized
DEBUG - 2022-03-09 00:19:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 00:19:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 00:19:16 --> Controller Class Initialized
INFO - 2022-03-09 00:19:16 --> Form Validation Class Initialized
DEBUG - 2022-03-09 00:19:16 --> Encrypt Class Initialized
INFO - 2022-03-09 00:19:16 --> Model "Patient_model" initialized
INFO - 2022-03-09 00:19:16 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 00:19:16 --> Model "Prefix_master" initialized
INFO - 2022-03-09 00:19:16 --> Model "Users_model" initialized
INFO - 2022-03-09 00:19:16 --> Model "Hospital_model" initialized
INFO - 2022-03-09 00:19:17 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 00:19:17 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-09 00:19:17 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 00:19:17 --> Final output sent to browser
DEBUG - 2022-03-09 00:19:17 --> Total execution time: 0.0697
ERROR - 2022-03-09 00:19:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 00:19:27 --> Config Class Initialized
INFO - 2022-03-09 00:19:27 --> Hooks Class Initialized
DEBUG - 2022-03-09 00:19:27 --> UTF-8 Support Enabled
INFO - 2022-03-09 00:19:27 --> Utf8 Class Initialized
INFO - 2022-03-09 00:19:27 --> URI Class Initialized
INFO - 2022-03-09 00:19:27 --> Router Class Initialized
INFO - 2022-03-09 00:19:27 --> Output Class Initialized
INFO - 2022-03-09 00:19:27 --> Security Class Initialized
DEBUG - 2022-03-09 00:19:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 00:19:27 --> Input Class Initialized
INFO - 2022-03-09 00:19:27 --> Language Class Initialized
INFO - 2022-03-09 00:19:27 --> Loader Class Initialized
INFO - 2022-03-09 00:19:27 --> Helper loaded: url_helper
INFO - 2022-03-09 00:19:27 --> Helper loaded: form_helper
INFO - 2022-03-09 00:19:27 --> Helper loaded: common_helper
INFO - 2022-03-09 00:19:27 --> Database Driver Class Initialized
DEBUG - 2022-03-09 00:19:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 00:19:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 00:19:27 --> Controller Class Initialized
INFO - 2022-03-09 00:19:27 --> Form Validation Class Initialized
DEBUG - 2022-03-09 00:19:27 --> Encrypt Class Initialized
INFO - 2022-03-09 00:19:27 --> Model "Patient_model" initialized
INFO - 2022-03-09 00:19:27 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 00:19:27 --> Model "Prefix_master" initialized
INFO - 2022-03-09 00:19:27 --> Model "Users_model" initialized
INFO - 2022-03-09 00:19:27 --> Model "Hospital_model" initialized
ERROR - 2022-03-09 00:19:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 00:19:28 --> Config Class Initialized
INFO - 2022-03-09 00:19:28 --> Hooks Class Initialized
DEBUG - 2022-03-09 00:19:28 --> UTF-8 Support Enabled
INFO - 2022-03-09 00:19:28 --> Utf8 Class Initialized
INFO - 2022-03-09 00:19:28 --> URI Class Initialized
INFO - 2022-03-09 00:19:28 --> Router Class Initialized
INFO - 2022-03-09 00:19:28 --> Output Class Initialized
INFO - 2022-03-09 00:19:28 --> Security Class Initialized
DEBUG - 2022-03-09 00:19:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 00:19:28 --> Input Class Initialized
INFO - 2022-03-09 00:19:28 --> Language Class Initialized
INFO - 2022-03-09 00:19:28 --> Loader Class Initialized
INFO - 2022-03-09 00:19:28 --> Helper loaded: url_helper
INFO - 2022-03-09 00:19:28 --> Helper loaded: form_helper
INFO - 2022-03-09 00:19:28 --> Helper loaded: common_helper
INFO - 2022-03-09 00:19:28 --> Database Driver Class Initialized
DEBUG - 2022-03-09 00:19:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 00:19:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 00:19:28 --> Controller Class Initialized
INFO - 2022-03-09 00:19:28 --> Form Validation Class Initialized
DEBUG - 2022-03-09 00:19:28 --> Encrypt Class Initialized
INFO - 2022-03-09 00:19:28 --> Model "Patient_model" initialized
INFO - 2022-03-09 00:19:28 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 00:19:28 --> Model "Prefix_master" initialized
INFO - 2022-03-09 00:19:28 --> Model "Users_model" initialized
INFO - 2022-03-09 00:19:28 --> Model "Hospital_model" initialized
INFO - 2022-03-09 00:19:28 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 00:19:28 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-09 00:19:28 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 00:19:28 --> Final output sent to browser
DEBUG - 2022-03-09 00:19:28 --> Total execution time: 0.0521
ERROR - 2022-03-09 00:39:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 00:39:37 --> Config Class Initialized
INFO - 2022-03-09 00:39:37 --> Hooks Class Initialized
DEBUG - 2022-03-09 00:39:37 --> UTF-8 Support Enabled
INFO - 2022-03-09 00:39:37 --> Utf8 Class Initialized
INFO - 2022-03-09 00:39:37 --> URI Class Initialized
INFO - 2022-03-09 00:39:37 --> Router Class Initialized
INFO - 2022-03-09 00:39:37 --> Output Class Initialized
INFO - 2022-03-09 00:39:37 --> Security Class Initialized
DEBUG - 2022-03-09 00:39:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 00:39:37 --> Input Class Initialized
INFO - 2022-03-09 00:39:37 --> Language Class Initialized
INFO - 2022-03-09 00:39:37 --> Loader Class Initialized
INFO - 2022-03-09 00:39:37 --> Helper loaded: url_helper
INFO - 2022-03-09 00:39:37 --> Helper loaded: form_helper
INFO - 2022-03-09 00:39:37 --> Helper loaded: common_helper
INFO - 2022-03-09 00:39:37 --> Database Driver Class Initialized
DEBUG - 2022-03-09 00:39:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 00:39:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 00:39:37 --> Controller Class Initialized
INFO - 2022-03-09 00:39:37 --> Form Validation Class Initialized
DEBUG - 2022-03-09 00:39:37 --> Encrypt Class Initialized
INFO - 2022-03-09 00:39:37 --> Model "Patient_model" initialized
INFO - 2022-03-09 00:39:37 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 00:39:37 --> Model "Referredby_model" initialized
INFO - 2022-03-09 00:39:37 --> Model "Prefix_master" initialized
INFO - 2022-03-09 00:39:37 --> Model "Hospital_model" initialized
INFO - 2022-03-09 00:39:37 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 00:39:43 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-09 00:39:43 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 00:39:44 --> Final output sent to browser
DEBUG - 2022-03-09 00:39:44 --> Total execution time: 5.7638
ERROR - 2022-03-09 00:40:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 00:40:14 --> Config Class Initialized
INFO - 2022-03-09 00:40:14 --> Hooks Class Initialized
DEBUG - 2022-03-09 00:40:14 --> UTF-8 Support Enabled
INFO - 2022-03-09 00:40:14 --> Utf8 Class Initialized
INFO - 2022-03-09 00:40:14 --> URI Class Initialized
INFO - 2022-03-09 00:40:14 --> Router Class Initialized
INFO - 2022-03-09 00:40:14 --> Output Class Initialized
INFO - 2022-03-09 00:40:14 --> Security Class Initialized
DEBUG - 2022-03-09 00:40:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 00:40:14 --> Input Class Initialized
INFO - 2022-03-09 00:40:14 --> Language Class Initialized
INFO - 2022-03-09 00:40:14 --> Loader Class Initialized
INFO - 2022-03-09 00:40:14 --> Helper loaded: url_helper
INFO - 2022-03-09 00:40:14 --> Helper loaded: form_helper
INFO - 2022-03-09 00:40:14 --> Helper loaded: common_helper
INFO - 2022-03-09 00:40:14 --> Database Driver Class Initialized
DEBUG - 2022-03-09 00:40:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 00:40:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 00:40:14 --> Controller Class Initialized
INFO - 2022-03-09 00:40:14 --> Form Validation Class Initialized
DEBUG - 2022-03-09 00:40:14 --> Encrypt Class Initialized
INFO - 2022-03-09 00:40:14 --> Model "Patient_model" initialized
INFO - 2022-03-09 00:40:14 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 00:40:14 --> Model "Referredby_model" initialized
INFO - 2022-03-09 00:40:14 --> Model "Prefix_master" initialized
INFO - 2022-03-09 00:40:14 --> Model "Hospital_model" initialized
INFO - 2022-03-09 00:40:14 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 00:40:14 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-09 00:40:14 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 00:40:14 --> Final output sent to browser
DEBUG - 2022-03-09 00:40:14 --> Total execution time: 0.0431
ERROR - 2022-03-09 00:42:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 00:42:43 --> Config Class Initialized
INFO - 2022-03-09 00:42:43 --> Hooks Class Initialized
DEBUG - 2022-03-09 00:42:43 --> UTF-8 Support Enabled
INFO - 2022-03-09 00:42:43 --> Utf8 Class Initialized
INFO - 2022-03-09 00:42:43 --> URI Class Initialized
INFO - 2022-03-09 00:42:43 --> Router Class Initialized
INFO - 2022-03-09 00:42:43 --> Output Class Initialized
INFO - 2022-03-09 00:42:43 --> Security Class Initialized
DEBUG - 2022-03-09 00:42:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 00:42:43 --> Input Class Initialized
INFO - 2022-03-09 00:42:43 --> Language Class Initialized
INFO - 2022-03-09 00:42:43 --> Loader Class Initialized
INFO - 2022-03-09 00:42:43 --> Helper loaded: url_helper
INFO - 2022-03-09 00:42:43 --> Helper loaded: form_helper
INFO - 2022-03-09 00:42:43 --> Helper loaded: common_helper
INFO - 2022-03-09 00:42:43 --> Database Driver Class Initialized
DEBUG - 2022-03-09 00:42:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 00:42:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 00:42:43 --> Controller Class Initialized
INFO - 2022-03-09 00:42:43 --> Form Validation Class Initialized
DEBUG - 2022-03-09 00:42:43 --> Encrypt Class Initialized
INFO - 2022-03-09 00:42:43 --> Model "Patient_model" initialized
INFO - 2022-03-09 00:42:43 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 00:42:43 --> Model "Referredby_model" initialized
INFO - 2022-03-09 00:42:43 --> Model "Prefix_master" initialized
INFO - 2022-03-09 00:42:43 --> Model "Hospital_model" initialized
ERROR - 2022-03-09 00:42:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 00:42:43 --> Config Class Initialized
INFO - 2022-03-09 00:42:43 --> Hooks Class Initialized
DEBUG - 2022-03-09 00:42:43 --> UTF-8 Support Enabled
INFO - 2022-03-09 00:42:43 --> Utf8 Class Initialized
INFO - 2022-03-09 00:42:43 --> URI Class Initialized
INFO - 2022-03-09 00:42:43 --> Router Class Initialized
INFO - 2022-03-09 00:42:43 --> Output Class Initialized
INFO - 2022-03-09 00:42:43 --> Security Class Initialized
DEBUG - 2022-03-09 00:42:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 00:42:43 --> Input Class Initialized
INFO - 2022-03-09 00:42:43 --> Language Class Initialized
INFO - 2022-03-09 00:42:43 --> Loader Class Initialized
INFO - 2022-03-09 00:42:43 --> Helper loaded: url_helper
INFO - 2022-03-09 00:42:43 --> Helper loaded: form_helper
INFO - 2022-03-09 00:42:43 --> Helper loaded: common_helper
INFO - 2022-03-09 00:42:43 --> Database Driver Class Initialized
DEBUG - 2022-03-09 00:42:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 00:42:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 00:42:43 --> Controller Class Initialized
INFO - 2022-03-09 00:42:43 --> Form Validation Class Initialized
DEBUG - 2022-03-09 00:42:43 --> Encrypt Class Initialized
INFO - 2022-03-09 00:42:43 --> Model "Patient_model" initialized
INFO - 2022-03-09 00:42:43 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 00:42:43 --> Model "Referredby_model" initialized
INFO - 2022-03-09 00:42:43 --> Model "Prefix_master" initialized
INFO - 2022-03-09 00:42:43 --> Model "Hospital_model" initialized
INFO - 2022-03-09 00:42:43 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 00:42:43 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-09 00:42:43 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 00:42:43 --> Final output sent to browser
DEBUG - 2022-03-09 00:42:43 --> Total execution time: 0.0654
ERROR - 2022-03-09 00:42:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 00:42:44 --> Config Class Initialized
INFO - 2022-03-09 00:42:44 --> Hooks Class Initialized
DEBUG - 2022-03-09 00:42:44 --> UTF-8 Support Enabled
INFO - 2022-03-09 00:42:44 --> Utf8 Class Initialized
INFO - 2022-03-09 00:42:44 --> URI Class Initialized
INFO - 2022-03-09 00:42:44 --> Router Class Initialized
INFO - 2022-03-09 00:42:44 --> Output Class Initialized
INFO - 2022-03-09 00:42:44 --> Security Class Initialized
DEBUG - 2022-03-09 00:42:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 00:42:44 --> Input Class Initialized
INFO - 2022-03-09 00:42:44 --> Language Class Initialized
INFO - 2022-03-09 00:42:44 --> Loader Class Initialized
INFO - 2022-03-09 00:42:44 --> Helper loaded: url_helper
INFO - 2022-03-09 00:42:44 --> Helper loaded: form_helper
INFO - 2022-03-09 00:42:44 --> Helper loaded: common_helper
INFO - 2022-03-09 00:42:44 --> Database Driver Class Initialized
DEBUG - 2022-03-09 00:42:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 00:42:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 00:42:44 --> Controller Class Initialized
INFO - 2022-03-09 00:42:44 --> Form Validation Class Initialized
DEBUG - 2022-03-09 00:42:44 --> Encrypt Class Initialized
INFO - 2022-03-09 00:42:44 --> Model "Patient_model" initialized
INFO - 2022-03-09 00:42:44 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 00:42:44 --> Model "Prefix_master" initialized
INFO - 2022-03-09 00:42:44 --> Model "Users_model" initialized
INFO - 2022-03-09 00:42:44 --> Model "Hospital_model" initialized
INFO - 2022-03-09 00:42:45 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 00:42:45 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-09 00:42:45 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 00:42:45 --> Final output sent to browser
DEBUG - 2022-03-09 00:42:45 --> Total execution time: 0.0958
ERROR - 2022-03-09 00:43:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 00:43:48 --> Config Class Initialized
INFO - 2022-03-09 00:43:48 --> Hooks Class Initialized
DEBUG - 2022-03-09 00:43:48 --> UTF-8 Support Enabled
INFO - 2022-03-09 00:43:48 --> Utf8 Class Initialized
INFO - 2022-03-09 00:43:48 --> URI Class Initialized
INFO - 2022-03-09 00:43:48 --> Router Class Initialized
INFO - 2022-03-09 00:43:48 --> Output Class Initialized
INFO - 2022-03-09 00:43:48 --> Security Class Initialized
DEBUG - 2022-03-09 00:43:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 00:43:48 --> Input Class Initialized
INFO - 2022-03-09 00:43:48 --> Language Class Initialized
INFO - 2022-03-09 00:43:48 --> Loader Class Initialized
INFO - 2022-03-09 00:43:48 --> Helper loaded: url_helper
INFO - 2022-03-09 00:43:48 --> Helper loaded: form_helper
INFO - 2022-03-09 00:43:48 --> Helper loaded: common_helper
INFO - 2022-03-09 00:43:48 --> Database Driver Class Initialized
DEBUG - 2022-03-09 00:43:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 00:43:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 00:43:48 --> Controller Class Initialized
INFO - 2022-03-09 00:43:48 --> Form Validation Class Initialized
DEBUG - 2022-03-09 00:43:48 --> Encrypt Class Initialized
INFO - 2022-03-09 00:43:48 --> Model "Patient_model" initialized
INFO - 2022-03-09 00:43:48 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 00:43:48 --> Model "Prefix_master" initialized
INFO - 2022-03-09 00:43:48 --> Model "Users_model" initialized
INFO - 2022-03-09 00:43:48 --> Model "Hospital_model" initialized
ERROR - 2022-03-09 00:43:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 00:43:48 --> Config Class Initialized
INFO - 2022-03-09 00:43:48 --> Hooks Class Initialized
DEBUG - 2022-03-09 00:43:48 --> UTF-8 Support Enabled
INFO - 2022-03-09 00:43:48 --> Utf8 Class Initialized
INFO - 2022-03-09 00:43:48 --> URI Class Initialized
INFO - 2022-03-09 00:43:48 --> Router Class Initialized
INFO - 2022-03-09 00:43:48 --> Output Class Initialized
INFO - 2022-03-09 00:43:48 --> Security Class Initialized
DEBUG - 2022-03-09 00:43:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 00:43:48 --> Input Class Initialized
INFO - 2022-03-09 00:43:48 --> Language Class Initialized
INFO - 2022-03-09 00:43:48 --> Loader Class Initialized
INFO - 2022-03-09 00:43:48 --> Helper loaded: url_helper
INFO - 2022-03-09 00:43:48 --> Helper loaded: form_helper
INFO - 2022-03-09 00:43:48 --> Helper loaded: common_helper
INFO - 2022-03-09 00:43:48 --> Database Driver Class Initialized
DEBUG - 2022-03-09 00:43:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 00:43:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 00:43:48 --> Controller Class Initialized
INFO - 2022-03-09 00:43:48 --> Form Validation Class Initialized
DEBUG - 2022-03-09 00:43:48 --> Encrypt Class Initialized
INFO - 2022-03-09 00:43:48 --> Model "Patient_model" initialized
INFO - 2022-03-09 00:43:48 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 00:43:48 --> Model "Prefix_master" initialized
INFO - 2022-03-09 00:43:48 --> Model "Users_model" initialized
INFO - 2022-03-09 00:43:48 --> Model "Hospital_model" initialized
INFO - 2022-03-09 00:43:48 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 00:43:48 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-09 00:43:48 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 00:43:48 --> Final output sent to browser
DEBUG - 2022-03-09 00:43:48 --> Total execution time: 0.0530
ERROR - 2022-03-09 00:46:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 00:46:18 --> Config Class Initialized
INFO - 2022-03-09 00:46:18 --> Hooks Class Initialized
DEBUG - 2022-03-09 00:46:18 --> UTF-8 Support Enabled
INFO - 2022-03-09 00:46:18 --> Utf8 Class Initialized
INFO - 2022-03-09 00:46:18 --> URI Class Initialized
INFO - 2022-03-09 00:46:18 --> Router Class Initialized
INFO - 2022-03-09 00:46:18 --> Output Class Initialized
INFO - 2022-03-09 00:46:18 --> Security Class Initialized
DEBUG - 2022-03-09 00:46:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 00:46:18 --> Input Class Initialized
INFO - 2022-03-09 00:46:18 --> Language Class Initialized
INFO - 2022-03-09 00:46:18 --> Loader Class Initialized
INFO - 2022-03-09 00:46:18 --> Helper loaded: url_helper
INFO - 2022-03-09 00:46:18 --> Helper loaded: form_helper
INFO - 2022-03-09 00:46:18 --> Helper loaded: common_helper
INFO - 2022-03-09 00:46:18 --> Database Driver Class Initialized
DEBUG - 2022-03-09 00:46:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 00:46:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 00:46:18 --> Controller Class Initialized
INFO - 2022-03-09 00:46:18 --> Form Validation Class Initialized
DEBUG - 2022-03-09 00:46:18 --> Encrypt Class Initialized
INFO - 2022-03-09 00:46:18 --> Model "Patient_model" initialized
INFO - 2022-03-09 00:46:18 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 00:46:18 --> Model "Prefix_master" initialized
INFO - 2022-03-09 00:46:18 --> Model "Users_model" initialized
INFO - 2022-03-09 00:46:18 --> Model "Hospital_model" initialized
ERROR - 2022-03-09 00:46:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 00:46:18 --> Config Class Initialized
INFO - 2022-03-09 00:46:18 --> Hooks Class Initialized
DEBUG - 2022-03-09 00:46:18 --> UTF-8 Support Enabled
INFO - 2022-03-09 00:46:18 --> Utf8 Class Initialized
INFO - 2022-03-09 00:46:18 --> URI Class Initialized
INFO - 2022-03-09 00:46:18 --> Router Class Initialized
INFO - 2022-03-09 00:46:18 --> Output Class Initialized
INFO - 2022-03-09 00:46:18 --> Security Class Initialized
DEBUG - 2022-03-09 00:46:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 00:46:18 --> Input Class Initialized
INFO - 2022-03-09 00:46:18 --> Language Class Initialized
INFO - 2022-03-09 00:46:18 --> Loader Class Initialized
INFO - 2022-03-09 00:46:18 --> Helper loaded: url_helper
INFO - 2022-03-09 00:46:18 --> Helper loaded: form_helper
INFO - 2022-03-09 00:46:18 --> Helper loaded: common_helper
INFO - 2022-03-09 00:46:18 --> Database Driver Class Initialized
DEBUG - 2022-03-09 00:46:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 00:46:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 00:46:18 --> Controller Class Initialized
INFO - 2022-03-09 00:46:18 --> Form Validation Class Initialized
DEBUG - 2022-03-09 00:46:18 --> Encrypt Class Initialized
INFO - 2022-03-09 00:46:18 --> Model "Patient_model" initialized
INFO - 2022-03-09 00:46:18 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 00:46:18 --> Model "Prefix_master" initialized
INFO - 2022-03-09 00:46:18 --> Model "Users_model" initialized
INFO - 2022-03-09 00:46:18 --> Model "Hospital_model" initialized
INFO - 2022-03-09 00:46:18 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 00:46:18 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-09 00:46:18 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 00:46:18 --> Final output sent to browser
DEBUG - 2022-03-09 00:46:18 --> Total execution time: 0.0601
ERROR - 2022-03-09 00:47:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 00:47:04 --> Config Class Initialized
INFO - 2022-03-09 00:47:04 --> Hooks Class Initialized
DEBUG - 2022-03-09 00:47:04 --> UTF-8 Support Enabled
INFO - 2022-03-09 00:47:04 --> Utf8 Class Initialized
INFO - 2022-03-09 00:47:04 --> URI Class Initialized
INFO - 2022-03-09 00:47:04 --> Router Class Initialized
INFO - 2022-03-09 00:47:04 --> Output Class Initialized
INFO - 2022-03-09 00:47:04 --> Security Class Initialized
DEBUG - 2022-03-09 00:47:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 00:47:04 --> Input Class Initialized
INFO - 2022-03-09 00:47:04 --> Language Class Initialized
INFO - 2022-03-09 00:47:04 --> Loader Class Initialized
INFO - 2022-03-09 00:47:04 --> Helper loaded: url_helper
INFO - 2022-03-09 00:47:04 --> Helper loaded: form_helper
INFO - 2022-03-09 00:47:04 --> Helper loaded: common_helper
INFO - 2022-03-09 00:47:04 --> Database Driver Class Initialized
DEBUG - 2022-03-09 00:47:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 00:47:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 00:47:04 --> Controller Class Initialized
INFO - 2022-03-09 00:47:04 --> Form Validation Class Initialized
DEBUG - 2022-03-09 00:47:04 --> Encrypt Class Initialized
INFO - 2022-03-09 00:47:04 --> Model "Patient_model" initialized
INFO - 2022-03-09 00:47:04 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 00:47:04 --> Model "Prefix_master" initialized
INFO - 2022-03-09 00:47:04 --> Model "Users_model" initialized
INFO - 2022-03-09 00:47:04 --> Model "Hospital_model" initialized
ERROR - 2022-03-09 00:47:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 00:47:04 --> Config Class Initialized
INFO - 2022-03-09 00:47:04 --> Hooks Class Initialized
DEBUG - 2022-03-09 00:47:04 --> UTF-8 Support Enabled
INFO - 2022-03-09 00:47:04 --> Utf8 Class Initialized
INFO - 2022-03-09 00:47:04 --> URI Class Initialized
INFO - 2022-03-09 00:47:04 --> Router Class Initialized
INFO - 2022-03-09 00:47:04 --> Output Class Initialized
INFO - 2022-03-09 00:47:04 --> Security Class Initialized
DEBUG - 2022-03-09 00:47:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 00:47:04 --> Input Class Initialized
INFO - 2022-03-09 00:47:04 --> Language Class Initialized
INFO - 2022-03-09 00:47:04 --> Loader Class Initialized
INFO - 2022-03-09 00:47:04 --> Helper loaded: url_helper
INFO - 2022-03-09 00:47:04 --> Helper loaded: form_helper
INFO - 2022-03-09 00:47:04 --> Helper loaded: common_helper
INFO - 2022-03-09 00:47:05 --> Database Driver Class Initialized
DEBUG - 2022-03-09 00:47:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 00:47:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 00:47:05 --> Controller Class Initialized
INFO - 2022-03-09 00:47:05 --> Form Validation Class Initialized
DEBUG - 2022-03-09 00:47:05 --> Encrypt Class Initialized
INFO - 2022-03-09 00:47:05 --> Model "Patient_model" initialized
INFO - 2022-03-09 00:47:05 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 00:47:05 --> Model "Prefix_master" initialized
INFO - 2022-03-09 00:47:05 --> Model "Users_model" initialized
INFO - 2022-03-09 00:47:05 --> Model "Hospital_model" initialized
INFO - 2022-03-09 00:47:05 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 00:47:05 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-09 00:47:05 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 00:47:05 --> Final output sent to browser
DEBUG - 2022-03-09 00:47:05 --> Total execution time: 0.0631
ERROR - 2022-03-09 00:48:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 00:48:53 --> Config Class Initialized
INFO - 2022-03-09 00:48:53 --> Hooks Class Initialized
DEBUG - 2022-03-09 00:48:53 --> UTF-8 Support Enabled
INFO - 2022-03-09 00:48:53 --> Utf8 Class Initialized
INFO - 2022-03-09 00:48:53 --> URI Class Initialized
INFO - 2022-03-09 00:48:53 --> Router Class Initialized
INFO - 2022-03-09 00:48:53 --> Output Class Initialized
INFO - 2022-03-09 00:48:53 --> Security Class Initialized
DEBUG - 2022-03-09 00:48:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 00:48:53 --> Input Class Initialized
INFO - 2022-03-09 00:48:53 --> Language Class Initialized
INFO - 2022-03-09 00:48:53 --> Loader Class Initialized
INFO - 2022-03-09 00:48:53 --> Helper loaded: url_helper
INFO - 2022-03-09 00:48:53 --> Helper loaded: form_helper
INFO - 2022-03-09 00:48:53 --> Helper loaded: common_helper
INFO - 2022-03-09 00:48:53 --> Database Driver Class Initialized
DEBUG - 2022-03-09 00:48:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 00:48:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 00:48:53 --> Controller Class Initialized
INFO - 2022-03-09 00:48:53 --> Form Validation Class Initialized
DEBUG - 2022-03-09 00:48:53 --> Encrypt Class Initialized
INFO - 2022-03-09 00:48:53 --> Model "Patient_model" initialized
INFO - 2022-03-09 00:48:53 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 00:48:53 --> Model "Prefix_master" initialized
INFO - 2022-03-09 00:48:53 --> Model "Users_model" initialized
INFO - 2022-03-09 00:48:53 --> Model "Hospital_model" initialized
ERROR - 2022-03-09 00:48:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 00:48:53 --> Config Class Initialized
INFO - 2022-03-09 00:48:53 --> Hooks Class Initialized
DEBUG - 2022-03-09 00:48:53 --> UTF-8 Support Enabled
INFO - 2022-03-09 00:48:53 --> Utf8 Class Initialized
INFO - 2022-03-09 00:48:53 --> URI Class Initialized
INFO - 2022-03-09 00:48:53 --> Router Class Initialized
INFO - 2022-03-09 00:48:53 --> Output Class Initialized
INFO - 2022-03-09 00:48:53 --> Security Class Initialized
DEBUG - 2022-03-09 00:48:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 00:48:53 --> Input Class Initialized
INFO - 2022-03-09 00:48:53 --> Language Class Initialized
INFO - 2022-03-09 00:48:53 --> Loader Class Initialized
INFO - 2022-03-09 00:48:53 --> Helper loaded: url_helper
INFO - 2022-03-09 00:48:53 --> Helper loaded: form_helper
INFO - 2022-03-09 00:48:53 --> Helper loaded: common_helper
INFO - 2022-03-09 00:48:53 --> Database Driver Class Initialized
DEBUG - 2022-03-09 00:48:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 00:48:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 00:48:53 --> Controller Class Initialized
INFO - 2022-03-09 00:48:53 --> Form Validation Class Initialized
DEBUG - 2022-03-09 00:48:53 --> Encrypt Class Initialized
INFO - 2022-03-09 00:48:53 --> Model "Patient_model" initialized
INFO - 2022-03-09 00:48:53 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 00:48:53 --> Model "Prefix_master" initialized
INFO - 2022-03-09 00:48:53 --> Model "Users_model" initialized
INFO - 2022-03-09 00:48:53 --> Model "Hospital_model" initialized
INFO - 2022-03-09 00:48:54 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 00:48:54 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-09 00:48:54 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 00:48:54 --> Final output sent to browser
DEBUG - 2022-03-09 00:48:54 --> Total execution time: 0.0684
ERROR - 2022-03-09 00:48:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 00:48:57 --> Config Class Initialized
INFO - 2022-03-09 00:48:57 --> Hooks Class Initialized
DEBUG - 2022-03-09 00:48:57 --> UTF-8 Support Enabled
INFO - 2022-03-09 00:48:57 --> Utf8 Class Initialized
INFO - 2022-03-09 00:48:57 --> URI Class Initialized
INFO - 2022-03-09 00:48:57 --> Router Class Initialized
INFO - 2022-03-09 00:48:57 --> Output Class Initialized
INFO - 2022-03-09 00:48:57 --> Security Class Initialized
DEBUG - 2022-03-09 00:48:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 00:48:57 --> Input Class Initialized
INFO - 2022-03-09 00:48:57 --> Language Class Initialized
INFO - 2022-03-09 00:48:57 --> Loader Class Initialized
INFO - 2022-03-09 00:48:57 --> Helper loaded: url_helper
INFO - 2022-03-09 00:48:57 --> Helper loaded: form_helper
INFO - 2022-03-09 00:48:57 --> Helper loaded: common_helper
INFO - 2022-03-09 00:48:57 --> Database Driver Class Initialized
DEBUG - 2022-03-09 00:48:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 00:48:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 00:48:57 --> Controller Class Initialized
INFO - 2022-03-09 00:48:57 --> Form Validation Class Initialized
DEBUG - 2022-03-09 00:48:57 --> Encrypt Class Initialized
INFO - 2022-03-09 00:48:57 --> Model "Patient_model" initialized
INFO - 2022-03-09 00:48:57 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 00:48:57 --> Model "Referredby_model" initialized
INFO - 2022-03-09 00:48:57 --> Model "Prefix_master" initialized
INFO - 2022-03-09 00:48:57 --> Model "Hospital_model" initialized
INFO - 2022-03-09 00:48:57 --> File loaded: /home3/karoteam/public_html/application/views/header.php
ERROR - 2022-03-09 00:49:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 00:49:02 --> Config Class Initialized
INFO - 2022-03-09 00:49:02 --> Hooks Class Initialized
DEBUG - 2022-03-09 00:49:02 --> UTF-8 Support Enabled
INFO - 2022-03-09 00:49:02 --> Utf8 Class Initialized
INFO - 2022-03-09 00:49:02 --> URI Class Initialized
INFO - 2022-03-09 00:49:02 --> Router Class Initialized
INFO - 2022-03-09 00:49:02 --> Output Class Initialized
INFO - 2022-03-09 00:49:02 --> Security Class Initialized
DEBUG - 2022-03-09 00:49:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 00:49:02 --> Input Class Initialized
INFO - 2022-03-09 00:49:02 --> Language Class Initialized
INFO - 2022-03-09 00:49:02 --> Loader Class Initialized
INFO - 2022-03-09 00:49:02 --> Helper loaded: url_helper
INFO - 2022-03-09 00:49:02 --> Helper loaded: form_helper
INFO - 2022-03-09 00:49:02 --> Helper loaded: common_helper
INFO - 2022-03-09 00:49:02 --> Database Driver Class Initialized
DEBUG - 2022-03-09 00:49:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 00:49:06 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-09 00:49:06 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 00:49:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 00:49:06 --> Controller Class Initialized
INFO - 2022-03-09 00:49:06 --> Form Validation Class Initialized
DEBUG - 2022-03-09 00:49:06 --> Encrypt Class Initialized
INFO - 2022-03-09 00:49:06 --> Model "Patient_model" initialized
INFO - 2022-03-09 00:49:06 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 00:49:06 --> Model "Referredby_model" initialized
INFO - 2022-03-09 00:49:06 --> Model "Prefix_master" initialized
INFO - 2022-03-09 00:49:06 --> Model "Hospital_model" initialized
INFO - 2022-03-09 00:49:06 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 00:49:14 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-09 00:49:14 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 00:49:16 --> Final output sent to browser
DEBUG - 2022-03-09 00:49:16 --> Total execution time: 12.3627
ERROR - 2022-03-09 00:50:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 00:50:37 --> Config Class Initialized
INFO - 2022-03-09 00:50:37 --> Hooks Class Initialized
DEBUG - 2022-03-09 00:50:38 --> UTF-8 Support Enabled
INFO - 2022-03-09 00:50:38 --> Utf8 Class Initialized
INFO - 2022-03-09 00:50:38 --> URI Class Initialized
INFO - 2022-03-09 00:50:38 --> Router Class Initialized
INFO - 2022-03-09 00:50:38 --> Output Class Initialized
INFO - 2022-03-09 00:50:38 --> Security Class Initialized
DEBUG - 2022-03-09 00:50:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 00:50:38 --> Input Class Initialized
INFO - 2022-03-09 00:50:38 --> Language Class Initialized
INFO - 2022-03-09 00:50:38 --> Loader Class Initialized
INFO - 2022-03-09 00:50:38 --> Helper loaded: url_helper
INFO - 2022-03-09 00:50:38 --> Helper loaded: form_helper
INFO - 2022-03-09 00:50:38 --> Helper loaded: common_helper
INFO - 2022-03-09 00:50:38 --> Database Driver Class Initialized
DEBUG - 2022-03-09 00:50:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 00:50:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 00:50:38 --> Controller Class Initialized
INFO - 2022-03-09 00:50:38 --> Form Validation Class Initialized
DEBUG - 2022-03-09 00:50:38 --> Encrypt Class Initialized
INFO - 2022-03-09 00:50:38 --> Model "Patient_model" initialized
INFO - 2022-03-09 00:50:38 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 00:50:38 --> Model "Referredby_model" initialized
INFO - 2022-03-09 00:50:38 --> Model "Prefix_master" initialized
INFO - 2022-03-09 00:50:38 --> Model "Hospital_model" initialized
INFO - 2022-03-09 00:50:38 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 00:50:38 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-09 00:50:38 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 00:50:38 --> Final output sent to browser
DEBUG - 2022-03-09 00:50:38 --> Total execution time: 0.0596
ERROR - 2022-03-09 00:51:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 00:51:44 --> Config Class Initialized
INFO - 2022-03-09 00:51:44 --> Hooks Class Initialized
DEBUG - 2022-03-09 00:51:44 --> UTF-8 Support Enabled
INFO - 2022-03-09 00:51:44 --> Utf8 Class Initialized
INFO - 2022-03-09 00:51:44 --> URI Class Initialized
INFO - 2022-03-09 00:51:44 --> Router Class Initialized
INFO - 2022-03-09 00:51:44 --> Output Class Initialized
INFO - 2022-03-09 00:51:44 --> Security Class Initialized
DEBUG - 2022-03-09 00:51:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 00:51:44 --> Input Class Initialized
INFO - 2022-03-09 00:51:44 --> Language Class Initialized
INFO - 2022-03-09 00:51:44 --> Loader Class Initialized
INFO - 2022-03-09 00:51:44 --> Helper loaded: url_helper
INFO - 2022-03-09 00:51:44 --> Helper loaded: form_helper
INFO - 2022-03-09 00:51:44 --> Helper loaded: common_helper
INFO - 2022-03-09 00:51:44 --> Database Driver Class Initialized
DEBUG - 2022-03-09 00:51:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 00:51:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 00:51:44 --> Controller Class Initialized
INFO - 2022-03-09 00:51:44 --> Form Validation Class Initialized
DEBUG - 2022-03-09 00:51:44 --> Encrypt Class Initialized
INFO - 2022-03-09 00:51:44 --> Model "Patient_model" initialized
INFO - 2022-03-09 00:51:44 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 00:51:44 --> Model "Referredby_model" initialized
INFO - 2022-03-09 00:51:44 --> Model "Prefix_master" initialized
INFO - 2022-03-09 00:51:44 --> Model "Hospital_model" initialized
ERROR - 2022-03-09 00:51:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 00:51:45 --> Config Class Initialized
INFO - 2022-03-09 00:51:45 --> Hooks Class Initialized
DEBUG - 2022-03-09 00:51:45 --> UTF-8 Support Enabled
INFO - 2022-03-09 00:51:45 --> Utf8 Class Initialized
INFO - 2022-03-09 00:51:45 --> URI Class Initialized
INFO - 2022-03-09 00:51:45 --> Router Class Initialized
INFO - 2022-03-09 00:51:45 --> Output Class Initialized
INFO - 2022-03-09 00:51:45 --> Security Class Initialized
DEBUG - 2022-03-09 00:51:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 00:51:45 --> Input Class Initialized
INFO - 2022-03-09 00:51:45 --> Language Class Initialized
INFO - 2022-03-09 00:51:45 --> Loader Class Initialized
INFO - 2022-03-09 00:51:45 --> Helper loaded: url_helper
INFO - 2022-03-09 00:51:45 --> Helper loaded: form_helper
INFO - 2022-03-09 00:51:45 --> Helper loaded: common_helper
INFO - 2022-03-09 00:51:45 --> Database Driver Class Initialized
DEBUG - 2022-03-09 00:51:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 00:51:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 00:51:45 --> Controller Class Initialized
INFO - 2022-03-09 00:51:45 --> Form Validation Class Initialized
DEBUG - 2022-03-09 00:51:45 --> Encrypt Class Initialized
INFO - 2022-03-09 00:51:45 --> Model "Patient_model" initialized
INFO - 2022-03-09 00:51:45 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 00:51:45 --> Model "Referredby_model" initialized
INFO - 2022-03-09 00:51:45 --> Model "Prefix_master" initialized
INFO - 2022-03-09 00:51:45 --> Model "Hospital_model" initialized
INFO - 2022-03-09 00:51:45 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 00:51:45 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-09 00:51:45 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 00:51:45 --> Final output sent to browser
DEBUG - 2022-03-09 00:51:45 --> Total execution time: 0.0510
ERROR - 2022-03-09 00:51:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 00:51:46 --> Config Class Initialized
INFO - 2022-03-09 00:51:46 --> Hooks Class Initialized
DEBUG - 2022-03-09 00:51:46 --> UTF-8 Support Enabled
INFO - 2022-03-09 00:51:46 --> Utf8 Class Initialized
INFO - 2022-03-09 00:51:46 --> URI Class Initialized
INFO - 2022-03-09 00:51:46 --> Router Class Initialized
INFO - 2022-03-09 00:51:46 --> Output Class Initialized
INFO - 2022-03-09 00:51:46 --> Security Class Initialized
DEBUG - 2022-03-09 00:51:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 00:51:46 --> Input Class Initialized
INFO - 2022-03-09 00:51:46 --> Language Class Initialized
INFO - 2022-03-09 00:51:46 --> Loader Class Initialized
INFO - 2022-03-09 00:51:46 --> Helper loaded: url_helper
INFO - 2022-03-09 00:51:46 --> Helper loaded: form_helper
INFO - 2022-03-09 00:51:46 --> Helper loaded: common_helper
INFO - 2022-03-09 00:51:46 --> Database Driver Class Initialized
DEBUG - 2022-03-09 00:51:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 00:51:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 00:51:46 --> Controller Class Initialized
INFO - 2022-03-09 00:51:46 --> Form Validation Class Initialized
DEBUG - 2022-03-09 00:51:46 --> Encrypt Class Initialized
INFO - 2022-03-09 00:51:46 --> Model "Patient_model" initialized
INFO - 2022-03-09 00:51:46 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 00:51:46 --> Model "Prefix_master" initialized
INFO - 2022-03-09 00:51:46 --> Model "Users_model" initialized
INFO - 2022-03-09 00:51:46 --> Model "Hospital_model" initialized
INFO - 2022-03-09 00:51:46 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 00:51:46 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-09 00:51:46 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 00:51:46 --> Final output sent to browser
DEBUG - 2022-03-09 00:51:46 --> Total execution time: 0.0786
ERROR - 2022-03-09 00:52:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 00:52:24 --> Config Class Initialized
INFO - 2022-03-09 00:52:24 --> Hooks Class Initialized
DEBUG - 2022-03-09 00:52:24 --> UTF-8 Support Enabled
INFO - 2022-03-09 00:52:24 --> Utf8 Class Initialized
INFO - 2022-03-09 00:52:24 --> URI Class Initialized
INFO - 2022-03-09 00:52:24 --> Router Class Initialized
INFO - 2022-03-09 00:52:24 --> Output Class Initialized
INFO - 2022-03-09 00:52:24 --> Security Class Initialized
DEBUG - 2022-03-09 00:52:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 00:52:24 --> Input Class Initialized
INFO - 2022-03-09 00:52:24 --> Language Class Initialized
INFO - 2022-03-09 00:52:24 --> Loader Class Initialized
INFO - 2022-03-09 00:52:24 --> Helper loaded: url_helper
INFO - 2022-03-09 00:52:24 --> Helper loaded: form_helper
INFO - 2022-03-09 00:52:24 --> Helper loaded: common_helper
INFO - 2022-03-09 00:52:24 --> Database Driver Class Initialized
DEBUG - 2022-03-09 00:52:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 00:52:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 00:52:24 --> Controller Class Initialized
INFO - 2022-03-09 00:52:24 --> Form Validation Class Initialized
DEBUG - 2022-03-09 00:52:24 --> Encrypt Class Initialized
INFO - 2022-03-09 00:52:24 --> Model "Patient_model" initialized
INFO - 2022-03-09 00:52:24 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 00:52:24 --> Model "Prefix_master" initialized
INFO - 2022-03-09 00:52:24 --> Model "Users_model" initialized
INFO - 2022-03-09 00:52:24 --> Model "Hospital_model" initialized
ERROR - 2022-03-09 00:52:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 00:52:24 --> Config Class Initialized
INFO - 2022-03-09 00:52:24 --> Hooks Class Initialized
DEBUG - 2022-03-09 00:52:24 --> UTF-8 Support Enabled
INFO - 2022-03-09 00:52:24 --> Utf8 Class Initialized
INFO - 2022-03-09 00:52:24 --> URI Class Initialized
INFO - 2022-03-09 00:52:24 --> Router Class Initialized
INFO - 2022-03-09 00:52:24 --> Output Class Initialized
INFO - 2022-03-09 00:52:24 --> Security Class Initialized
DEBUG - 2022-03-09 00:52:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 00:52:24 --> Input Class Initialized
INFO - 2022-03-09 00:52:24 --> Language Class Initialized
INFO - 2022-03-09 00:52:24 --> Loader Class Initialized
INFO - 2022-03-09 00:52:24 --> Helper loaded: url_helper
INFO - 2022-03-09 00:52:24 --> Helper loaded: form_helper
INFO - 2022-03-09 00:52:24 --> Helper loaded: common_helper
INFO - 2022-03-09 00:52:24 --> Database Driver Class Initialized
DEBUG - 2022-03-09 00:52:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 00:52:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 00:52:24 --> Controller Class Initialized
INFO - 2022-03-09 00:52:24 --> Form Validation Class Initialized
DEBUG - 2022-03-09 00:52:24 --> Encrypt Class Initialized
INFO - 2022-03-09 00:52:24 --> Model "Patient_model" initialized
INFO - 2022-03-09 00:52:24 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 00:52:24 --> Model "Prefix_master" initialized
INFO - 2022-03-09 00:52:24 --> Model "Users_model" initialized
INFO - 2022-03-09 00:52:24 --> Model "Hospital_model" initialized
INFO - 2022-03-09 00:52:24 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 00:52:24 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-09 00:52:24 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 00:52:24 --> Final output sent to browser
DEBUG - 2022-03-09 00:52:24 --> Total execution time: 0.0674
ERROR - 2022-03-09 00:53:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 00:53:01 --> Config Class Initialized
INFO - 2022-03-09 00:53:01 --> Hooks Class Initialized
DEBUG - 2022-03-09 00:53:01 --> UTF-8 Support Enabled
INFO - 2022-03-09 00:53:01 --> Utf8 Class Initialized
INFO - 2022-03-09 00:53:01 --> URI Class Initialized
INFO - 2022-03-09 00:53:01 --> Router Class Initialized
INFO - 2022-03-09 00:53:01 --> Output Class Initialized
INFO - 2022-03-09 00:53:01 --> Security Class Initialized
DEBUG - 2022-03-09 00:53:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 00:53:01 --> Input Class Initialized
INFO - 2022-03-09 00:53:01 --> Language Class Initialized
INFO - 2022-03-09 00:53:01 --> Loader Class Initialized
INFO - 2022-03-09 00:53:01 --> Helper loaded: url_helper
INFO - 2022-03-09 00:53:01 --> Helper loaded: form_helper
INFO - 2022-03-09 00:53:01 --> Helper loaded: common_helper
INFO - 2022-03-09 00:53:01 --> Database Driver Class Initialized
DEBUG - 2022-03-09 00:53:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 00:53:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 00:53:01 --> Controller Class Initialized
INFO - 2022-03-09 00:53:01 --> Form Validation Class Initialized
DEBUG - 2022-03-09 00:53:01 --> Encrypt Class Initialized
INFO - 2022-03-09 00:53:01 --> Model "Patient_model" initialized
INFO - 2022-03-09 00:53:01 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 00:53:01 --> Model "Prefix_master" initialized
INFO - 2022-03-09 00:53:01 --> Model "Users_model" initialized
INFO - 2022-03-09 00:53:01 --> Model "Hospital_model" initialized
ERROR - 2022-03-09 00:53:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 00:53:01 --> Config Class Initialized
INFO - 2022-03-09 00:53:01 --> Hooks Class Initialized
DEBUG - 2022-03-09 00:53:01 --> UTF-8 Support Enabled
INFO - 2022-03-09 00:53:01 --> Utf8 Class Initialized
INFO - 2022-03-09 00:53:01 --> URI Class Initialized
INFO - 2022-03-09 00:53:01 --> Router Class Initialized
INFO - 2022-03-09 00:53:01 --> Output Class Initialized
INFO - 2022-03-09 00:53:01 --> Security Class Initialized
DEBUG - 2022-03-09 00:53:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 00:53:01 --> Input Class Initialized
INFO - 2022-03-09 00:53:01 --> Language Class Initialized
INFO - 2022-03-09 00:53:01 --> Loader Class Initialized
INFO - 2022-03-09 00:53:01 --> Helper loaded: url_helper
INFO - 2022-03-09 00:53:01 --> Helper loaded: form_helper
INFO - 2022-03-09 00:53:01 --> Helper loaded: common_helper
INFO - 2022-03-09 00:53:01 --> Database Driver Class Initialized
DEBUG - 2022-03-09 00:53:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 00:53:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 00:53:01 --> Controller Class Initialized
INFO - 2022-03-09 00:53:01 --> Form Validation Class Initialized
DEBUG - 2022-03-09 00:53:01 --> Encrypt Class Initialized
INFO - 2022-03-09 00:53:01 --> Model "Patient_model" initialized
INFO - 2022-03-09 00:53:01 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 00:53:01 --> Model "Prefix_master" initialized
INFO - 2022-03-09 00:53:01 --> Model "Users_model" initialized
INFO - 2022-03-09 00:53:01 --> Model "Hospital_model" initialized
INFO - 2022-03-09 00:53:01 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 00:53:01 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-09 00:53:01 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 00:53:01 --> Final output sent to browser
DEBUG - 2022-03-09 00:53:01 --> Total execution time: 0.0652
ERROR - 2022-03-09 00:53:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 00:53:27 --> Config Class Initialized
INFO - 2022-03-09 00:53:27 --> Hooks Class Initialized
DEBUG - 2022-03-09 00:53:27 --> UTF-8 Support Enabled
INFO - 2022-03-09 00:53:27 --> Utf8 Class Initialized
INFO - 2022-03-09 00:53:27 --> URI Class Initialized
INFO - 2022-03-09 00:53:27 --> Router Class Initialized
INFO - 2022-03-09 00:53:27 --> Output Class Initialized
INFO - 2022-03-09 00:53:27 --> Security Class Initialized
DEBUG - 2022-03-09 00:53:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 00:53:27 --> Input Class Initialized
INFO - 2022-03-09 00:53:27 --> Language Class Initialized
INFO - 2022-03-09 00:53:27 --> Loader Class Initialized
INFO - 2022-03-09 00:53:27 --> Helper loaded: url_helper
INFO - 2022-03-09 00:53:27 --> Helper loaded: form_helper
INFO - 2022-03-09 00:53:27 --> Helper loaded: common_helper
INFO - 2022-03-09 00:53:27 --> Database Driver Class Initialized
DEBUG - 2022-03-09 00:53:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 00:53:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 00:53:27 --> Controller Class Initialized
INFO - 2022-03-09 00:53:27 --> Form Validation Class Initialized
DEBUG - 2022-03-09 00:53:27 --> Encrypt Class Initialized
INFO - 2022-03-09 00:53:27 --> Model "Patient_model" initialized
INFO - 2022-03-09 00:53:27 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 00:53:27 --> Model "Prefix_master" initialized
INFO - 2022-03-09 00:53:27 --> Model "Users_model" initialized
INFO - 2022-03-09 00:53:27 --> Model "Hospital_model" initialized
ERROR - 2022-03-09 00:53:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 00:53:28 --> Config Class Initialized
INFO - 2022-03-09 00:53:28 --> Hooks Class Initialized
DEBUG - 2022-03-09 00:53:28 --> UTF-8 Support Enabled
INFO - 2022-03-09 00:53:28 --> Utf8 Class Initialized
INFO - 2022-03-09 00:53:28 --> URI Class Initialized
INFO - 2022-03-09 00:53:28 --> Router Class Initialized
INFO - 2022-03-09 00:53:28 --> Output Class Initialized
INFO - 2022-03-09 00:53:28 --> Security Class Initialized
DEBUG - 2022-03-09 00:53:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 00:53:28 --> Input Class Initialized
INFO - 2022-03-09 00:53:28 --> Language Class Initialized
INFO - 2022-03-09 00:53:28 --> Loader Class Initialized
INFO - 2022-03-09 00:53:28 --> Helper loaded: url_helper
INFO - 2022-03-09 00:53:28 --> Helper loaded: form_helper
INFO - 2022-03-09 00:53:28 --> Helper loaded: common_helper
INFO - 2022-03-09 00:53:28 --> Database Driver Class Initialized
DEBUG - 2022-03-09 00:53:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 00:53:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 00:53:28 --> Controller Class Initialized
INFO - 2022-03-09 00:53:28 --> Form Validation Class Initialized
DEBUG - 2022-03-09 00:53:28 --> Encrypt Class Initialized
INFO - 2022-03-09 00:53:28 --> Model "Patient_model" initialized
INFO - 2022-03-09 00:53:28 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 00:53:28 --> Model "Prefix_master" initialized
INFO - 2022-03-09 00:53:28 --> Model "Users_model" initialized
INFO - 2022-03-09 00:53:28 --> Model "Hospital_model" initialized
INFO - 2022-03-09 00:53:28 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 00:53:28 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-09 00:53:28 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 00:53:28 --> Final output sent to browser
DEBUG - 2022-03-09 00:53:28 --> Total execution time: 0.0871
ERROR - 2022-03-09 00:53:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 00:53:59 --> Config Class Initialized
INFO - 2022-03-09 00:53:59 --> Hooks Class Initialized
DEBUG - 2022-03-09 00:53:59 --> UTF-8 Support Enabled
INFO - 2022-03-09 00:53:59 --> Utf8 Class Initialized
INFO - 2022-03-09 00:53:59 --> URI Class Initialized
INFO - 2022-03-09 00:53:59 --> Router Class Initialized
INFO - 2022-03-09 00:53:59 --> Output Class Initialized
INFO - 2022-03-09 00:53:59 --> Security Class Initialized
DEBUG - 2022-03-09 00:53:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 00:53:59 --> Input Class Initialized
INFO - 2022-03-09 00:53:59 --> Language Class Initialized
INFO - 2022-03-09 00:53:59 --> Loader Class Initialized
INFO - 2022-03-09 00:53:59 --> Helper loaded: url_helper
INFO - 2022-03-09 00:53:59 --> Helper loaded: form_helper
INFO - 2022-03-09 00:53:59 --> Helper loaded: common_helper
INFO - 2022-03-09 00:53:59 --> Database Driver Class Initialized
DEBUG - 2022-03-09 00:53:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 00:53:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 00:53:59 --> Controller Class Initialized
INFO - 2022-03-09 00:53:59 --> Form Validation Class Initialized
DEBUG - 2022-03-09 00:53:59 --> Encrypt Class Initialized
INFO - 2022-03-09 00:53:59 --> Model "Patient_model" initialized
INFO - 2022-03-09 00:53:59 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 00:53:59 --> Model "Prefix_master" initialized
INFO - 2022-03-09 00:53:59 --> Model "Users_model" initialized
INFO - 2022-03-09 00:53:59 --> Model "Hospital_model" initialized
ERROR - 2022-03-09 00:54:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 00:54:00 --> Config Class Initialized
INFO - 2022-03-09 00:54:00 --> Hooks Class Initialized
DEBUG - 2022-03-09 00:54:00 --> UTF-8 Support Enabled
INFO - 2022-03-09 00:54:00 --> Utf8 Class Initialized
INFO - 2022-03-09 00:54:00 --> URI Class Initialized
INFO - 2022-03-09 00:54:00 --> Router Class Initialized
INFO - 2022-03-09 00:54:00 --> Output Class Initialized
INFO - 2022-03-09 00:54:00 --> Security Class Initialized
DEBUG - 2022-03-09 00:54:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 00:54:00 --> Input Class Initialized
INFO - 2022-03-09 00:54:00 --> Language Class Initialized
INFO - 2022-03-09 00:54:00 --> Loader Class Initialized
INFO - 2022-03-09 00:54:00 --> Helper loaded: url_helper
INFO - 2022-03-09 00:54:00 --> Helper loaded: form_helper
INFO - 2022-03-09 00:54:00 --> Helper loaded: common_helper
INFO - 2022-03-09 00:54:00 --> Database Driver Class Initialized
DEBUG - 2022-03-09 00:54:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 00:54:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 00:54:00 --> Controller Class Initialized
INFO - 2022-03-09 00:54:00 --> Form Validation Class Initialized
DEBUG - 2022-03-09 00:54:00 --> Encrypt Class Initialized
INFO - 2022-03-09 00:54:00 --> Model "Patient_model" initialized
INFO - 2022-03-09 00:54:00 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 00:54:00 --> Model "Prefix_master" initialized
INFO - 2022-03-09 00:54:00 --> Model "Users_model" initialized
INFO - 2022-03-09 00:54:00 --> Model "Hospital_model" initialized
INFO - 2022-03-09 00:54:00 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 00:54:00 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-09 00:54:00 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 00:54:00 --> Final output sent to browser
DEBUG - 2022-03-09 00:54:00 --> Total execution time: 0.0545
ERROR - 2022-03-09 00:54:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 00:54:53 --> Config Class Initialized
INFO - 2022-03-09 00:54:53 --> Hooks Class Initialized
DEBUG - 2022-03-09 00:54:53 --> UTF-8 Support Enabled
INFO - 2022-03-09 00:54:53 --> Utf8 Class Initialized
INFO - 2022-03-09 00:54:53 --> URI Class Initialized
INFO - 2022-03-09 00:54:53 --> Router Class Initialized
INFO - 2022-03-09 00:54:53 --> Output Class Initialized
INFO - 2022-03-09 00:54:53 --> Security Class Initialized
DEBUG - 2022-03-09 00:54:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 00:54:53 --> Input Class Initialized
INFO - 2022-03-09 00:54:53 --> Language Class Initialized
INFO - 2022-03-09 00:54:53 --> Loader Class Initialized
INFO - 2022-03-09 00:54:53 --> Helper loaded: url_helper
INFO - 2022-03-09 00:54:53 --> Helper loaded: form_helper
INFO - 2022-03-09 00:54:53 --> Helper loaded: common_helper
INFO - 2022-03-09 00:54:53 --> Database Driver Class Initialized
DEBUG - 2022-03-09 00:54:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 00:54:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 00:54:53 --> Controller Class Initialized
INFO - 2022-03-09 00:54:53 --> Form Validation Class Initialized
DEBUG - 2022-03-09 00:54:53 --> Encrypt Class Initialized
INFO - 2022-03-09 00:54:53 --> Model "Patient_model" initialized
INFO - 2022-03-09 00:54:53 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 00:54:53 --> Model "Referredby_model" initialized
INFO - 2022-03-09 00:54:53 --> Model "Prefix_master" initialized
INFO - 2022-03-09 00:54:53 --> Model "Hospital_model" initialized
INFO - 2022-03-09 00:54:53 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 00:54:53 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-09 00:54:53 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 00:54:53 --> Final output sent to browser
DEBUG - 2022-03-09 00:54:53 --> Total execution time: 0.0476
ERROR - 2022-03-09 00:54:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 00:54:59 --> Config Class Initialized
INFO - 2022-03-09 00:54:59 --> Hooks Class Initialized
DEBUG - 2022-03-09 00:54:59 --> UTF-8 Support Enabled
INFO - 2022-03-09 00:54:59 --> Utf8 Class Initialized
INFO - 2022-03-09 00:54:59 --> URI Class Initialized
INFO - 2022-03-09 00:54:59 --> Router Class Initialized
INFO - 2022-03-09 00:54:59 --> Output Class Initialized
INFO - 2022-03-09 00:54:59 --> Security Class Initialized
DEBUG - 2022-03-09 00:54:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 00:54:59 --> Input Class Initialized
INFO - 2022-03-09 00:54:59 --> Language Class Initialized
INFO - 2022-03-09 00:54:59 --> Loader Class Initialized
INFO - 2022-03-09 00:54:59 --> Helper loaded: url_helper
INFO - 2022-03-09 00:54:59 --> Helper loaded: form_helper
INFO - 2022-03-09 00:54:59 --> Helper loaded: common_helper
INFO - 2022-03-09 00:54:59 --> Database Driver Class Initialized
DEBUG - 2022-03-09 00:54:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 00:54:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 00:54:59 --> Controller Class Initialized
INFO - 2022-03-09 00:54:59 --> Form Validation Class Initialized
DEBUG - 2022-03-09 00:54:59 --> Encrypt Class Initialized
INFO - 2022-03-09 00:54:59 --> Model "Patient_model" initialized
INFO - 2022-03-09 00:54:59 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 00:54:59 --> Model "Prefix_master" initialized
INFO - 2022-03-09 00:54:59 --> Model "Users_model" initialized
INFO - 2022-03-09 00:54:59 --> Model "Hospital_model" initialized
INFO - 2022-03-09 00:54:59 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 00:54:59 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-09 00:54:59 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 00:54:59 --> Final output sent to browser
DEBUG - 2022-03-09 00:54:59 --> Total execution time: 0.0553
ERROR - 2022-03-09 00:55:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 00:55:04 --> Config Class Initialized
INFO - 2022-03-09 00:55:04 --> Hooks Class Initialized
DEBUG - 2022-03-09 00:55:04 --> UTF-8 Support Enabled
INFO - 2022-03-09 00:55:04 --> Utf8 Class Initialized
INFO - 2022-03-09 00:55:04 --> URI Class Initialized
INFO - 2022-03-09 00:55:04 --> Router Class Initialized
INFO - 2022-03-09 00:55:04 --> Output Class Initialized
INFO - 2022-03-09 00:55:04 --> Security Class Initialized
DEBUG - 2022-03-09 00:55:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 00:55:04 --> Input Class Initialized
INFO - 2022-03-09 00:55:04 --> Language Class Initialized
INFO - 2022-03-09 00:55:04 --> Loader Class Initialized
INFO - 2022-03-09 00:55:04 --> Helper loaded: url_helper
INFO - 2022-03-09 00:55:04 --> Helper loaded: form_helper
INFO - 2022-03-09 00:55:04 --> Helper loaded: common_helper
INFO - 2022-03-09 00:55:04 --> Database Driver Class Initialized
DEBUG - 2022-03-09 00:55:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 00:55:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 00:55:04 --> Controller Class Initialized
INFO - 2022-03-09 00:55:04 --> Form Validation Class Initialized
DEBUG - 2022-03-09 00:55:04 --> Encrypt Class Initialized
INFO - 2022-03-09 00:55:04 --> Model "Patient_model" initialized
INFO - 2022-03-09 00:55:04 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 00:55:04 --> Model "Referredby_model" initialized
INFO - 2022-03-09 00:55:04 --> Model "Prefix_master" initialized
INFO - 2022-03-09 00:55:04 --> Model "Hospital_model" initialized
INFO - 2022-03-09 00:55:04 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 00:55:04 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-09 00:55:04 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 00:55:04 --> Final output sent to browser
DEBUG - 2022-03-09 00:55:04 --> Total execution time: 0.0445
ERROR - 2022-03-09 00:56:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 00:56:17 --> Config Class Initialized
INFO - 2022-03-09 00:56:17 --> Hooks Class Initialized
DEBUG - 2022-03-09 00:56:17 --> UTF-8 Support Enabled
INFO - 2022-03-09 00:56:17 --> Utf8 Class Initialized
INFO - 2022-03-09 00:56:17 --> URI Class Initialized
INFO - 2022-03-09 00:56:17 --> Router Class Initialized
INFO - 2022-03-09 00:56:17 --> Output Class Initialized
INFO - 2022-03-09 00:56:17 --> Security Class Initialized
DEBUG - 2022-03-09 00:56:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 00:56:17 --> Input Class Initialized
INFO - 2022-03-09 00:56:17 --> Language Class Initialized
INFO - 2022-03-09 00:56:17 --> Loader Class Initialized
INFO - 2022-03-09 00:56:17 --> Helper loaded: url_helper
INFO - 2022-03-09 00:56:17 --> Helper loaded: form_helper
INFO - 2022-03-09 00:56:17 --> Helper loaded: common_helper
INFO - 2022-03-09 00:56:17 --> Database Driver Class Initialized
DEBUG - 2022-03-09 00:56:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 00:56:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 00:56:17 --> Controller Class Initialized
INFO - 2022-03-09 00:56:17 --> Form Validation Class Initialized
DEBUG - 2022-03-09 00:56:17 --> Encrypt Class Initialized
INFO - 2022-03-09 00:56:17 --> Model "Patient_model" initialized
INFO - 2022-03-09 00:56:17 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 00:56:17 --> Model "Referredby_model" initialized
INFO - 2022-03-09 00:56:17 --> Model "Prefix_master" initialized
INFO - 2022-03-09 00:56:17 --> Model "Hospital_model" initialized
ERROR - 2022-03-09 00:56:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 00:56:17 --> Config Class Initialized
INFO - 2022-03-09 00:56:17 --> Hooks Class Initialized
DEBUG - 2022-03-09 00:56:17 --> UTF-8 Support Enabled
INFO - 2022-03-09 00:56:17 --> Utf8 Class Initialized
INFO - 2022-03-09 00:56:17 --> URI Class Initialized
INFO - 2022-03-09 00:56:17 --> Router Class Initialized
INFO - 2022-03-09 00:56:17 --> Output Class Initialized
INFO - 2022-03-09 00:56:17 --> Security Class Initialized
DEBUG - 2022-03-09 00:56:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 00:56:17 --> Input Class Initialized
INFO - 2022-03-09 00:56:17 --> Language Class Initialized
INFO - 2022-03-09 00:56:17 --> Loader Class Initialized
INFO - 2022-03-09 00:56:17 --> Helper loaded: url_helper
INFO - 2022-03-09 00:56:17 --> Helper loaded: form_helper
INFO - 2022-03-09 00:56:17 --> Helper loaded: common_helper
INFO - 2022-03-09 00:56:17 --> Database Driver Class Initialized
DEBUG - 2022-03-09 00:56:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 00:56:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 00:56:17 --> Controller Class Initialized
INFO - 2022-03-09 00:56:17 --> Form Validation Class Initialized
DEBUG - 2022-03-09 00:56:17 --> Encrypt Class Initialized
INFO - 2022-03-09 00:56:17 --> Model "Patient_model" initialized
INFO - 2022-03-09 00:56:17 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 00:56:17 --> Model "Referredby_model" initialized
INFO - 2022-03-09 00:56:17 --> Model "Prefix_master" initialized
INFO - 2022-03-09 00:56:17 --> Model "Hospital_model" initialized
INFO - 2022-03-09 00:56:17 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 00:56:17 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-09 00:56:17 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 00:56:17 --> Final output sent to browser
DEBUG - 2022-03-09 00:56:17 --> Total execution time: 0.0419
ERROR - 2022-03-09 00:56:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 00:56:18 --> Config Class Initialized
INFO - 2022-03-09 00:56:18 --> Hooks Class Initialized
DEBUG - 2022-03-09 00:56:18 --> UTF-8 Support Enabled
INFO - 2022-03-09 00:56:18 --> Utf8 Class Initialized
INFO - 2022-03-09 00:56:18 --> URI Class Initialized
INFO - 2022-03-09 00:56:18 --> Router Class Initialized
INFO - 2022-03-09 00:56:18 --> Output Class Initialized
INFO - 2022-03-09 00:56:18 --> Security Class Initialized
DEBUG - 2022-03-09 00:56:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 00:56:18 --> Input Class Initialized
INFO - 2022-03-09 00:56:18 --> Language Class Initialized
INFO - 2022-03-09 00:56:18 --> Loader Class Initialized
INFO - 2022-03-09 00:56:18 --> Helper loaded: url_helper
INFO - 2022-03-09 00:56:18 --> Helper loaded: form_helper
INFO - 2022-03-09 00:56:18 --> Helper loaded: common_helper
INFO - 2022-03-09 00:56:18 --> Database Driver Class Initialized
DEBUG - 2022-03-09 00:56:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 00:56:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 00:56:18 --> Controller Class Initialized
INFO - 2022-03-09 00:56:18 --> Form Validation Class Initialized
DEBUG - 2022-03-09 00:56:18 --> Encrypt Class Initialized
INFO - 2022-03-09 00:56:18 --> Model "Patient_model" initialized
INFO - 2022-03-09 00:56:18 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 00:56:18 --> Model "Prefix_master" initialized
INFO - 2022-03-09 00:56:18 --> Model "Users_model" initialized
INFO - 2022-03-09 00:56:18 --> Model "Hospital_model" initialized
INFO - 2022-03-09 00:56:18 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 00:56:18 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-09 00:56:18 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 00:56:18 --> Final output sent to browser
DEBUG - 2022-03-09 00:56:18 --> Total execution time: 0.0561
ERROR - 2022-03-09 00:58:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 00:58:01 --> Config Class Initialized
INFO - 2022-03-09 00:58:01 --> Hooks Class Initialized
DEBUG - 2022-03-09 00:58:01 --> UTF-8 Support Enabled
INFO - 2022-03-09 00:58:01 --> Utf8 Class Initialized
INFO - 2022-03-09 00:58:01 --> URI Class Initialized
INFO - 2022-03-09 00:58:01 --> Router Class Initialized
INFO - 2022-03-09 00:58:01 --> Output Class Initialized
INFO - 2022-03-09 00:58:01 --> Security Class Initialized
DEBUG - 2022-03-09 00:58:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 00:58:01 --> Input Class Initialized
INFO - 2022-03-09 00:58:01 --> Language Class Initialized
INFO - 2022-03-09 00:58:01 --> Loader Class Initialized
INFO - 2022-03-09 00:58:01 --> Helper loaded: url_helper
INFO - 2022-03-09 00:58:01 --> Helper loaded: form_helper
INFO - 2022-03-09 00:58:01 --> Helper loaded: common_helper
INFO - 2022-03-09 00:58:01 --> Database Driver Class Initialized
DEBUG - 2022-03-09 00:58:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 00:58:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 00:58:01 --> Controller Class Initialized
INFO - 2022-03-09 00:58:01 --> Form Validation Class Initialized
DEBUG - 2022-03-09 00:58:01 --> Encrypt Class Initialized
INFO - 2022-03-09 00:58:01 --> Model "Patient_model" initialized
INFO - 2022-03-09 00:58:01 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 00:58:01 --> Model "Prefix_master" initialized
INFO - 2022-03-09 00:58:01 --> Model "Users_model" initialized
INFO - 2022-03-09 00:58:01 --> Model "Hospital_model" initialized
ERROR - 2022-03-09 00:58:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 00:58:02 --> Config Class Initialized
INFO - 2022-03-09 00:58:02 --> Hooks Class Initialized
DEBUG - 2022-03-09 00:58:02 --> UTF-8 Support Enabled
INFO - 2022-03-09 00:58:02 --> Utf8 Class Initialized
INFO - 2022-03-09 00:58:02 --> URI Class Initialized
INFO - 2022-03-09 00:58:02 --> Router Class Initialized
INFO - 2022-03-09 00:58:02 --> Output Class Initialized
INFO - 2022-03-09 00:58:02 --> Security Class Initialized
DEBUG - 2022-03-09 00:58:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 00:58:02 --> Input Class Initialized
INFO - 2022-03-09 00:58:02 --> Language Class Initialized
INFO - 2022-03-09 00:58:02 --> Loader Class Initialized
INFO - 2022-03-09 00:58:02 --> Helper loaded: url_helper
INFO - 2022-03-09 00:58:02 --> Helper loaded: form_helper
INFO - 2022-03-09 00:58:02 --> Helper loaded: common_helper
INFO - 2022-03-09 00:58:02 --> Database Driver Class Initialized
DEBUG - 2022-03-09 00:58:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 00:58:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 00:58:02 --> Controller Class Initialized
INFO - 2022-03-09 00:58:02 --> Form Validation Class Initialized
DEBUG - 2022-03-09 00:58:02 --> Encrypt Class Initialized
INFO - 2022-03-09 00:58:02 --> Model "Patient_model" initialized
INFO - 2022-03-09 00:58:02 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 00:58:02 --> Model "Prefix_master" initialized
INFO - 2022-03-09 00:58:02 --> Model "Users_model" initialized
INFO - 2022-03-09 00:58:02 --> Model "Hospital_model" initialized
INFO - 2022-03-09 00:58:02 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 00:58:02 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-09 00:58:02 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 00:58:02 --> Final output sent to browser
DEBUG - 2022-03-09 00:58:02 --> Total execution time: 0.0535
ERROR - 2022-03-09 00:59:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 00:59:34 --> Config Class Initialized
INFO - 2022-03-09 00:59:34 --> Hooks Class Initialized
DEBUG - 2022-03-09 00:59:34 --> UTF-8 Support Enabled
INFO - 2022-03-09 00:59:34 --> Utf8 Class Initialized
INFO - 2022-03-09 00:59:34 --> URI Class Initialized
INFO - 2022-03-09 00:59:34 --> Router Class Initialized
INFO - 2022-03-09 00:59:34 --> Output Class Initialized
INFO - 2022-03-09 00:59:34 --> Security Class Initialized
DEBUG - 2022-03-09 00:59:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 00:59:34 --> Input Class Initialized
INFO - 2022-03-09 00:59:34 --> Language Class Initialized
INFO - 2022-03-09 00:59:34 --> Loader Class Initialized
INFO - 2022-03-09 00:59:34 --> Helper loaded: url_helper
INFO - 2022-03-09 00:59:34 --> Helper loaded: form_helper
INFO - 2022-03-09 00:59:34 --> Helper loaded: common_helper
INFO - 2022-03-09 00:59:34 --> Database Driver Class Initialized
DEBUG - 2022-03-09 00:59:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 00:59:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 00:59:34 --> Controller Class Initialized
INFO - 2022-03-09 00:59:34 --> Form Validation Class Initialized
DEBUG - 2022-03-09 00:59:34 --> Encrypt Class Initialized
INFO - 2022-03-09 00:59:34 --> Model "Patient_model" initialized
INFO - 2022-03-09 00:59:34 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 00:59:34 --> Model "Prefix_master" initialized
INFO - 2022-03-09 00:59:34 --> Model "Users_model" initialized
INFO - 2022-03-09 00:59:34 --> Model "Hospital_model" initialized
ERROR - 2022-03-09 00:59:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 00:59:35 --> Config Class Initialized
INFO - 2022-03-09 00:59:35 --> Hooks Class Initialized
DEBUG - 2022-03-09 00:59:35 --> UTF-8 Support Enabled
INFO - 2022-03-09 00:59:35 --> Utf8 Class Initialized
INFO - 2022-03-09 00:59:35 --> URI Class Initialized
INFO - 2022-03-09 00:59:35 --> Router Class Initialized
INFO - 2022-03-09 00:59:35 --> Output Class Initialized
INFO - 2022-03-09 00:59:35 --> Security Class Initialized
DEBUG - 2022-03-09 00:59:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 00:59:35 --> Input Class Initialized
INFO - 2022-03-09 00:59:35 --> Language Class Initialized
INFO - 2022-03-09 00:59:35 --> Loader Class Initialized
INFO - 2022-03-09 00:59:35 --> Helper loaded: url_helper
INFO - 2022-03-09 00:59:35 --> Helper loaded: form_helper
INFO - 2022-03-09 00:59:35 --> Helper loaded: common_helper
INFO - 2022-03-09 00:59:35 --> Database Driver Class Initialized
DEBUG - 2022-03-09 00:59:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 00:59:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 00:59:35 --> Controller Class Initialized
INFO - 2022-03-09 00:59:35 --> Form Validation Class Initialized
DEBUG - 2022-03-09 00:59:35 --> Encrypt Class Initialized
INFO - 2022-03-09 00:59:35 --> Model "Patient_model" initialized
INFO - 2022-03-09 00:59:35 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 00:59:35 --> Model "Prefix_master" initialized
INFO - 2022-03-09 00:59:35 --> Model "Users_model" initialized
INFO - 2022-03-09 00:59:35 --> Model "Hospital_model" initialized
INFO - 2022-03-09 00:59:35 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 00:59:35 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-09 00:59:35 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 00:59:35 --> Final output sent to browser
DEBUG - 2022-03-09 00:59:35 --> Total execution time: 0.0812
ERROR - 2022-03-09 01:05:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 01:05:16 --> Config Class Initialized
INFO - 2022-03-09 01:05:16 --> Hooks Class Initialized
DEBUG - 2022-03-09 01:05:16 --> UTF-8 Support Enabled
INFO - 2022-03-09 01:05:16 --> Utf8 Class Initialized
INFO - 2022-03-09 01:05:16 --> URI Class Initialized
INFO - 2022-03-09 01:05:16 --> Router Class Initialized
INFO - 2022-03-09 01:05:16 --> Output Class Initialized
INFO - 2022-03-09 01:05:16 --> Security Class Initialized
DEBUG - 2022-03-09 01:05:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 01:05:16 --> Input Class Initialized
INFO - 2022-03-09 01:05:16 --> Language Class Initialized
INFO - 2022-03-09 01:05:16 --> Loader Class Initialized
INFO - 2022-03-09 01:05:16 --> Helper loaded: url_helper
INFO - 2022-03-09 01:05:16 --> Helper loaded: form_helper
INFO - 2022-03-09 01:05:16 --> Helper loaded: common_helper
INFO - 2022-03-09 01:05:16 --> Database Driver Class Initialized
DEBUG - 2022-03-09 01:05:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 01:05:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 01:05:16 --> Controller Class Initialized
INFO - 2022-03-09 01:05:16 --> Form Validation Class Initialized
DEBUG - 2022-03-09 01:05:16 --> Encrypt Class Initialized
INFO - 2022-03-09 01:05:16 --> Model "Patient_model" initialized
INFO - 2022-03-09 01:05:16 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 01:05:16 --> Model "Prefix_master" initialized
INFO - 2022-03-09 01:05:16 --> Model "Users_model" initialized
INFO - 2022-03-09 01:05:16 --> Model "Hospital_model" initialized
ERROR - 2022-03-09 01:05:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 01:05:17 --> Config Class Initialized
INFO - 2022-03-09 01:05:17 --> Hooks Class Initialized
DEBUG - 2022-03-09 01:05:17 --> UTF-8 Support Enabled
INFO - 2022-03-09 01:05:17 --> Utf8 Class Initialized
INFO - 2022-03-09 01:05:17 --> URI Class Initialized
INFO - 2022-03-09 01:05:17 --> Router Class Initialized
INFO - 2022-03-09 01:05:17 --> Output Class Initialized
INFO - 2022-03-09 01:05:17 --> Security Class Initialized
DEBUG - 2022-03-09 01:05:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 01:05:17 --> Input Class Initialized
INFO - 2022-03-09 01:05:17 --> Language Class Initialized
INFO - 2022-03-09 01:05:17 --> Loader Class Initialized
INFO - 2022-03-09 01:05:17 --> Helper loaded: url_helper
INFO - 2022-03-09 01:05:17 --> Helper loaded: form_helper
INFO - 2022-03-09 01:05:17 --> Helper loaded: common_helper
INFO - 2022-03-09 01:05:17 --> Database Driver Class Initialized
DEBUG - 2022-03-09 01:05:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 01:05:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 01:05:17 --> Controller Class Initialized
INFO - 2022-03-09 01:05:17 --> Form Validation Class Initialized
DEBUG - 2022-03-09 01:05:17 --> Encrypt Class Initialized
INFO - 2022-03-09 01:05:17 --> Model "Patient_model" initialized
INFO - 2022-03-09 01:05:17 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 01:05:17 --> Model "Prefix_master" initialized
INFO - 2022-03-09 01:05:17 --> Model "Users_model" initialized
INFO - 2022-03-09 01:05:17 --> Model "Hospital_model" initialized
INFO - 2022-03-09 01:05:17 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 01:05:17 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-09 01:05:17 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 01:05:17 --> Final output sent to browser
DEBUG - 2022-03-09 01:05:17 --> Total execution time: 0.0525
ERROR - 2022-03-09 01:05:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 01:05:55 --> Config Class Initialized
INFO - 2022-03-09 01:05:55 --> Hooks Class Initialized
DEBUG - 2022-03-09 01:05:55 --> UTF-8 Support Enabled
INFO - 2022-03-09 01:05:55 --> Utf8 Class Initialized
INFO - 2022-03-09 01:05:55 --> URI Class Initialized
INFO - 2022-03-09 01:05:55 --> Router Class Initialized
INFO - 2022-03-09 01:05:55 --> Output Class Initialized
INFO - 2022-03-09 01:05:55 --> Security Class Initialized
DEBUG - 2022-03-09 01:05:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 01:05:55 --> Input Class Initialized
INFO - 2022-03-09 01:05:55 --> Language Class Initialized
INFO - 2022-03-09 01:05:55 --> Loader Class Initialized
INFO - 2022-03-09 01:05:55 --> Helper loaded: url_helper
INFO - 2022-03-09 01:05:55 --> Helper loaded: form_helper
INFO - 2022-03-09 01:05:55 --> Helper loaded: common_helper
INFO - 2022-03-09 01:05:55 --> Database Driver Class Initialized
DEBUG - 2022-03-09 01:05:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 01:05:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 01:05:55 --> Controller Class Initialized
INFO - 2022-03-09 01:05:55 --> Form Validation Class Initialized
DEBUG - 2022-03-09 01:05:55 --> Encrypt Class Initialized
INFO - 2022-03-09 01:05:55 --> Model "Patient_model" initialized
INFO - 2022-03-09 01:05:55 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 01:05:55 --> Model "Referredby_model" initialized
INFO - 2022-03-09 01:05:55 --> Model "Prefix_master" initialized
INFO - 2022-03-09 01:05:55 --> Model "Hospital_model" initialized
INFO - 2022-03-09 01:05:55 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 01:05:55 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-09 01:05:55 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 01:05:55 --> Final output sent to browser
DEBUG - 2022-03-09 01:05:55 --> Total execution time: 0.0587
ERROR - 2022-03-09 01:06:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 01:06:02 --> Config Class Initialized
INFO - 2022-03-09 01:06:02 --> Hooks Class Initialized
DEBUG - 2022-03-09 01:06:02 --> UTF-8 Support Enabled
INFO - 2022-03-09 01:06:02 --> Utf8 Class Initialized
INFO - 2022-03-09 01:06:02 --> URI Class Initialized
INFO - 2022-03-09 01:06:02 --> Router Class Initialized
INFO - 2022-03-09 01:06:02 --> Output Class Initialized
INFO - 2022-03-09 01:06:02 --> Security Class Initialized
DEBUG - 2022-03-09 01:06:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 01:06:02 --> Input Class Initialized
INFO - 2022-03-09 01:06:02 --> Language Class Initialized
INFO - 2022-03-09 01:06:02 --> Loader Class Initialized
INFO - 2022-03-09 01:06:02 --> Helper loaded: url_helper
INFO - 2022-03-09 01:06:02 --> Helper loaded: form_helper
INFO - 2022-03-09 01:06:02 --> Helper loaded: common_helper
INFO - 2022-03-09 01:06:02 --> Database Driver Class Initialized
DEBUG - 2022-03-09 01:06:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 01:06:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 01:06:02 --> Controller Class Initialized
INFO - 2022-03-09 01:06:02 --> Form Validation Class Initialized
DEBUG - 2022-03-09 01:06:02 --> Encrypt Class Initialized
INFO - 2022-03-09 01:06:02 --> Model "Patient_model" initialized
INFO - 2022-03-09 01:06:02 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 01:06:02 --> Model "Prefix_master" initialized
INFO - 2022-03-09 01:06:02 --> Model "Users_model" initialized
INFO - 2022-03-09 01:06:02 --> Model "Hospital_model" initialized
INFO - 2022-03-09 01:06:02 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 01:06:02 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-09 01:06:02 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 01:06:02 --> Final output sent to browser
DEBUG - 2022-03-09 01:06:02 --> Total execution time: 0.0644
ERROR - 2022-03-09 01:06:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 01:06:14 --> Config Class Initialized
INFO - 2022-03-09 01:06:14 --> Hooks Class Initialized
DEBUG - 2022-03-09 01:06:14 --> UTF-8 Support Enabled
INFO - 2022-03-09 01:06:14 --> Utf8 Class Initialized
INFO - 2022-03-09 01:06:14 --> URI Class Initialized
INFO - 2022-03-09 01:06:14 --> Router Class Initialized
INFO - 2022-03-09 01:06:14 --> Output Class Initialized
INFO - 2022-03-09 01:06:14 --> Security Class Initialized
DEBUG - 2022-03-09 01:06:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 01:06:14 --> Input Class Initialized
INFO - 2022-03-09 01:06:14 --> Language Class Initialized
INFO - 2022-03-09 01:06:14 --> Loader Class Initialized
INFO - 2022-03-09 01:06:14 --> Helper loaded: url_helper
INFO - 2022-03-09 01:06:14 --> Helper loaded: form_helper
INFO - 2022-03-09 01:06:14 --> Helper loaded: common_helper
INFO - 2022-03-09 01:06:14 --> Database Driver Class Initialized
DEBUG - 2022-03-09 01:06:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 01:06:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 01:06:14 --> Controller Class Initialized
INFO - 2022-03-09 01:06:14 --> Form Validation Class Initialized
DEBUG - 2022-03-09 01:06:14 --> Encrypt Class Initialized
INFO - 2022-03-09 01:06:14 --> Model "Patient_model" initialized
INFO - 2022-03-09 01:06:14 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 01:06:14 --> Model "Referredby_model" initialized
INFO - 2022-03-09 01:06:14 --> Model "Prefix_master" initialized
INFO - 2022-03-09 01:06:14 --> Model "Hospital_model" initialized
INFO - 2022-03-09 01:06:14 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 01:06:14 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-09 01:06:14 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 01:06:14 --> Final output sent to browser
DEBUG - 2022-03-09 01:06:14 --> Total execution time: 0.0575
ERROR - 2022-03-09 01:07:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 01:07:25 --> Config Class Initialized
INFO - 2022-03-09 01:07:25 --> Hooks Class Initialized
DEBUG - 2022-03-09 01:07:25 --> UTF-8 Support Enabled
INFO - 2022-03-09 01:07:25 --> Utf8 Class Initialized
INFO - 2022-03-09 01:07:25 --> URI Class Initialized
INFO - 2022-03-09 01:07:25 --> Router Class Initialized
INFO - 2022-03-09 01:07:25 --> Output Class Initialized
INFO - 2022-03-09 01:07:25 --> Security Class Initialized
DEBUG - 2022-03-09 01:07:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 01:07:25 --> Input Class Initialized
INFO - 2022-03-09 01:07:25 --> Language Class Initialized
INFO - 2022-03-09 01:07:25 --> Loader Class Initialized
INFO - 2022-03-09 01:07:25 --> Helper loaded: url_helper
INFO - 2022-03-09 01:07:25 --> Helper loaded: form_helper
INFO - 2022-03-09 01:07:25 --> Helper loaded: common_helper
INFO - 2022-03-09 01:07:25 --> Database Driver Class Initialized
DEBUG - 2022-03-09 01:07:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 01:07:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 01:07:25 --> Controller Class Initialized
INFO - 2022-03-09 01:07:25 --> Form Validation Class Initialized
DEBUG - 2022-03-09 01:07:25 --> Encrypt Class Initialized
INFO - 2022-03-09 01:07:25 --> Model "Patient_model" initialized
INFO - 2022-03-09 01:07:25 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 01:07:25 --> Model "Referredby_model" initialized
INFO - 2022-03-09 01:07:25 --> Model "Prefix_master" initialized
INFO - 2022-03-09 01:07:25 --> Model "Hospital_model" initialized
ERROR - 2022-03-09 01:07:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 01:07:26 --> Config Class Initialized
INFO - 2022-03-09 01:07:26 --> Hooks Class Initialized
DEBUG - 2022-03-09 01:07:26 --> UTF-8 Support Enabled
INFO - 2022-03-09 01:07:26 --> Utf8 Class Initialized
INFO - 2022-03-09 01:07:26 --> URI Class Initialized
INFO - 2022-03-09 01:07:26 --> Router Class Initialized
INFO - 2022-03-09 01:07:26 --> Output Class Initialized
INFO - 2022-03-09 01:07:26 --> Security Class Initialized
DEBUG - 2022-03-09 01:07:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 01:07:26 --> Input Class Initialized
INFO - 2022-03-09 01:07:26 --> Language Class Initialized
INFO - 2022-03-09 01:07:26 --> Loader Class Initialized
INFO - 2022-03-09 01:07:26 --> Helper loaded: url_helper
INFO - 2022-03-09 01:07:26 --> Helper loaded: form_helper
INFO - 2022-03-09 01:07:26 --> Helper loaded: common_helper
INFO - 2022-03-09 01:07:26 --> Database Driver Class Initialized
DEBUG - 2022-03-09 01:07:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 01:07:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 01:07:26 --> Controller Class Initialized
INFO - 2022-03-09 01:07:26 --> Form Validation Class Initialized
DEBUG - 2022-03-09 01:07:26 --> Encrypt Class Initialized
INFO - 2022-03-09 01:07:26 --> Model "Patient_model" initialized
INFO - 2022-03-09 01:07:26 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 01:07:26 --> Model "Referredby_model" initialized
INFO - 2022-03-09 01:07:26 --> Model "Prefix_master" initialized
INFO - 2022-03-09 01:07:26 --> Model "Hospital_model" initialized
INFO - 2022-03-09 01:07:26 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 01:07:26 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-09 01:07:26 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 01:07:26 --> Final output sent to browser
DEBUG - 2022-03-09 01:07:26 --> Total execution time: 0.0748
ERROR - 2022-03-09 01:07:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 01:07:27 --> Config Class Initialized
INFO - 2022-03-09 01:07:27 --> Hooks Class Initialized
DEBUG - 2022-03-09 01:07:27 --> UTF-8 Support Enabled
INFO - 2022-03-09 01:07:27 --> Utf8 Class Initialized
INFO - 2022-03-09 01:07:27 --> URI Class Initialized
INFO - 2022-03-09 01:07:27 --> Router Class Initialized
INFO - 2022-03-09 01:07:27 --> Output Class Initialized
INFO - 2022-03-09 01:07:27 --> Security Class Initialized
DEBUG - 2022-03-09 01:07:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 01:07:27 --> Input Class Initialized
INFO - 2022-03-09 01:07:27 --> Language Class Initialized
INFO - 2022-03-09 01:07:27 --> Loader Class Initialized
INFO - 2022-03-09 01:07:27 --> Helper loaded: url_helper
INFO - 2022-03-09 01:07:27 --> Helper loaded: form_helper
INFO - 2022-03-09 01:07:27 --> Helper loaded: common_helper
INFO - 2022-03-09 01:07:27 --> Database Driver Class Initialized
DEBUG - 2022-03-09 01:07:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 01:07:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 01:07:27 --> Controller Class Initialized
INFO - 2022-03-09 01:07:27 --> Form Validation Class Initialized
DEBUG - 2022-03-09 01:07:27 --> Encrypt Class Initialized
INFO - 2022-03-09 01:07:27 --> Model "Patient_model" initialized
INFO - 2022-03-09 01:07:27 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 01:07:27 --> Model "Prefix_master" initialized
INFO - 2022-03-09 01:07:27 --> Model "Users_model" initialized
INFO - 2022-03-09 01:07:27 --> Model "Hospital_model" initialized
INFO - 2022-03-09 01:07:27 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 01:07:27 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-09 01:07:27 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 01:07:27 --> Final output sent to browser
DEBUG - 2022-03-09 01:07:27 --> Total execution time: 0.0874
ERROR - 2022-03-09 01:31:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 01:31:15 --> Config Class Initialized
INFO - 2022-03-09 01:31:15 --> Hooks Class Initialized
DEBUG - 2022-03-09 01:31:15 --> UTF-8 Support Enabled
INFO - 2022-03-09 01:31:15 --> Utf8 Class Initialized
INFO - 2022-03-09 01:31:15 --> URI Class Initialized
INFO - 2022-03-09 01:31:15 --> Router Class Initialized
INFO - 2022-03-09 01:31:15 --> Output Class Initialized
INFO - 2022-03-09 01:31:15 --> Security Class Initialized
DEBUG - 2022-03-09 01:31:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 01:31:15 --> Input Class Initialized
INFO - 2022-03-09 01:31:15 --> Language Class Initialized
INFO - 2022-03-09 01:31:15 --> Loader Class Initialized
INFO - 2022-03-09 01:31:15 --> Helper loaded: url_helper
INFO - 2022-03-09 01:31:15 --> Helper loaded: form_helper
INFO - 2022-03-09 01:31:15 --> Helper loaded: common_helper
INFO - 2022-03-09 01:31:15 --> Database Driver Class Initialized
DEBUG - 2022-03-09 01:31:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 01:31:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 01:31:15 --> Controller Class Initialized
INFO - 2022-03-09 01:31:16 --> Form Validation Class Initialized
DEBUG - 2022-03-09 01:31:16 --> Encrypt Class Initialized
INFO - 2022-03-09 01:31:16 --> Model "Patient_model" initialized
INFO - 2022-03-09 01:31:16 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 01:31:16 --> Model "Prefix_master" initialized
INFO - 2022-03-09 01:31:16 --> Model "Users_model" initialized
INFO - 2022-03-09 01:31:16 --> Model "Hospital_model" initialized
INFO - 2022-03-09 01:31:16 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 01:31:16 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-09 01:31:16 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 01:31:16 --> Final output sent to browser
DEBUG - 2022-03-09 01:31:16 --> Total execution time: 0.2860
ERROR - 2022-03-09 01:31:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 01:31:53 --> Config Class Initialized
INFO - 2022-03-09 01:31:53 --> Hooks Class Initialized
DEBUG - 2022-03-09 01:31:53 --> UTF-8 Support Enabled
INFO - 2022-03-09 01:31:53 --> Utf8 Class Initialized
INFO - 2022-03-09 01:31:53 --> URI Class Initialized
INFO - 2022-03-09 01:31:53 --> Router Class Initialized
INFO - 2022-03-09 01:31:53 --> Output Class Initialized
INFO - 2022-03-09 01:31:53 --> Security Class Initialized
DEBUG - 2022-03-09 01:31:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 01:31:53 --> Input Class Initialized
INFO - 2022-03-09 01:31:53 --> Language Class Initialized
INFO - 2022-03-09 01:31:53 --> Loader Class Initialized
INFO - 2022-03-09 01:31:53 --> Helper loaded: url_helper
INFO - 2022-03-09 01:31:53 --> Helper loaded: form_helper
INFO - 2022-03-09 01:31:53 --> Helper loaded: common_helper
INFO - 2022-03-09 01:31:53 --> Database Driver Class Initialized
DEBUG - 2022-03-09 01:31:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 01:31:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 01:31:53 --> Controller Class Initialized
INFO - 2022-03-09 01:31:53 --> Form Validation Class Initialized
DEBUG - 2022-03-09 01:31:53 --> Encrypt Class Initialized
INFO - 2022-03-09 01:31:53 --> Model "Patient_model" initialized
INFO - 2022-03-09 01:31:53 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 01:31:53 --> Model "Referredby_model" initialized
INFO - 2022-03-09 01:31:53 --> Model "Prefix_master" initialized
INFO - 2022-03-09 01:31:53 --> Model "Hospital_model" initialized
INFO - 2022-03-09 01:31:53 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 01:31:53 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-09 01:31:53 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 01:31:53 --> Final output sent to browser
DEBUG - 2022-03-09 01:31:53 --> Total execution time: 0.0972
ERROR - 2022-03-09 01:32:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 01:32:06 --> Config Class Initialized
INFO - 2022-03-09 01:32:06 --> Hooks Class Initialized
DEBUG - 2022-03-09 01:32:06 --> UTF-8 Support Enabled
INFO - 2022-03-09 01:32:06 --> Utf8 Class Initialized
INFO - 2022-03-09 01:32:06 --> URI Class Initialized
INFO - 2022-03-09 01:32:06 --> Router Class Initialized
INFO - 2022-03-09 01:32:06 --> Output Class Initialized
INFO - 2022-03-09 01:32:06 --> Security Class Initialized
DEBUG - 2022-03-09 01:32:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 01:32:06 --> Input Class Initialized
INFO - 2022-03-09 01:32:06 --> Language Class Initialized
INFO - 2022-03-09 01:32:06 --> Loader Class Initialized
INFO - 2022-03-09 01:32:06 --> Helper loaded: url_helper
INFO - 2022-03-09 01:32:06 --> Helper loaded: form_helper
INFO - 2022-03-09 01:32:06 --> Helper loaded: common_helper
INFO - 2022-03-09 01:32:06 --> Database Driver Class Initialized
DEBUG - 2022-03-09 01:32:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 01:32:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 01:32:06 --> Controller Class Initialized
INFO - 2022-03-09 01:32:06 --> Form Validation Class Initialized
DEBUG - 2022-03-09 01:32:06 --> Encrypt Class Initialized
INFO - 2022-03-09 01:32:06 --> Model "Patient_model" initialized
INFO - 2022-03-09 01:32:06 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 01:32:06 --> Model "Prefix_master" initialized
INFO - 2022-03-09 01:32:06 --> Model "Users_model" initialized
INFO - 2022-03-09 01:32:06 --> Model "Hospital_model" initialized
INFO - 2022-03-09 01:32:06 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-09 01:32:08 --> Final output sent to browser
DEBUG - 2022-03-09 01:32:08 --> Total execution time: 2.0278
ERROR - 2022-03-09 01:43:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 01:43:04 --> Config Class Initialized
INFO - 2022-03-09 01:43:04 --> Hooks Class Initialized
DEBUG - 2022-03-09 01:43:04 --> UTF-8 Support Enabled
INFO - 2022-03-09 01:43:04 --> Utf8 Class Initialized
INFO - 2022-03-09 01:43:04 --> URI Class Initialized
INFO - 2022-03-09 01:43:04 --> Router Class Initialized
INFO - 2022-03-09 01:43:04 --> Output Class Initialized
INFO - 2022-03-09 01:43:04 --> Security Class Initialized
DEBUG - 2022-03-09 01:43:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 01:43:04 --> Input Class Initialized
INFO - 2022-03-09 01:43:04 --> Language Class Initialized
INFO - 2022-03-09 01:43:04 --> Loader Class Initialized
INFO - 2022-03-09 01:43:04 --> Helper loaded: url_helper
INFO - 2022-03-09 01:43:04 --> Helper loaded: form_helper
INFO - 2022-03-09 01:43:04 --> Helper loaded: common_helper
INFO - 2022-03-09 01:43:04 --> Database Driver Class Initialized
DEBUG - 2022-03-09 01:43:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 01:43:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 01:43:04 --> Controller Class Initialized
INFO - 2022-03-09 01:43:04 --> Form Validation Class Initialized
DEBUG - 2022-03-09 01:43:04 --> Encrypt Class Initialized
INFO - 2022-03-09 01:43:04 --> Model "Patient_model" initialized
INFO - 2022-03-09 01:43:04 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 01:43:04 --> Model "Prefix_master" initialized
INFO - 2022-03-09 01:43:04 --> Model "Users_model" initialized
INFO - 2022-03-09 01:43:04 --> Model "Hospital_model" initialized
INFO - 2022-03-09 01:43:04 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 01:43:04 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-09 01:43:04 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 01:43:04 --> Final output sent to browser
DEBUG - 2022-03-09 01:43:04 --> Total execution time: 0.0793
ERROR - 2022-03-09 01:43:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 01:43:11 --> Config Class Initialized
INFO - 2022-03-09 01:43:11 --> Hooks Class Initialized
DEBUG - 2022-03-09 01:43:11 --> UTF-8 Support Enabled
INFO - 2022-03-09 01:43:11 --> Utf8 Class Initialized
INFO - 2022-03-09 01:43:11 --> URI Class Initialized
INFO - 2022-03-09 01:43:11 --> Router Class Initialized
INFO - 2022-03-09 01:43:11 --> Output Class Initialized
INFO - 2022-03-09 01:43:11 --> Security Class Initialized
DEBUG - 2022-03-09 01:43:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 01:43:11 --> Input Class Initialized
INFO - 2022-03-09 01:43:11 --> Language Class Initialized
INFO - 2022-03-09 01:43:11 --> Loader Class Initialized
INFO - 2022-03-09 01:43:11 --> Helper loaded: url_helper
INFO - 2022-03-09 01:43:11 --> Helper loaded: form_helper
INFO - 2022-03-09 01:43:11 --> Helper loaded: common_helper
INFO - 2022-03-09 01:43:11 --> Database Driver Class Initialized
DEBUG - 2022-03-09 01:43:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 01:43:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 01:43:11 --> Controller Class Initialized
INFO - 2022-03-09 01:43:11 --> Form Validation Class Initialized
DEBUG - 2022-03-09 01:43:11 --> Encrypt Class Initialized
INFO - 2022-03-09 01:43:11 --> Model "Patient_model" initialized
INFO - 2022-03-09 01:43:11 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 01:43:11 --> Model "Referredby_model" initialized
INFO - 2022-03-09 01:43:11 --> Model "Prefix_master" initialized
INFO - 2022-03-09 01:43:11 --> Model "Hospital_model" initialized
INFO - 2022-03-09 01:43:11 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 01:43:19 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-09 01:43:19 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 01:43:21 --> Final output sent to browser
DEBUG - 2022-03-09 01:43:21 --> Total execution time: 7.8873
ERROR - 2022-03-09 01:43:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 01:43:50 --> Config Class Initialized
INFO - 2022-03-09 01:43:50 --> Hooks Class Initialized
DEBUG - 2022-03-09 01:43:50 --> UTF-8 Support Enabled
INFO - 2022-03-09 01:43:50 --> Utf8 Class Initialized
INFO - 2022-03-09 01:43:50 --> URI Class Initialized
INFO - 2022-03-09 01:43:50 --> Router Class Initialized
INFO - 2022-03-09 01:43:50 --> Output Class Initialized
INFO - 2022-03-09 01:43:50 --> Security Class Initialized
DEBUG - 2022-03-09 01:43:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 01:43:50 --> Input Class Initialized
INFO - 2022-03-09 01:43:50 --> Language Class Initialized
INFO - 2022-03-09 01:43:50 --> Loader Class Initialized
INFO - 2022-03-09 01:43:50 --> Helper loaded: url_helper
INFO - 2022-03-09 01:43:50 --> Helper loaded: form_helper
INFO - 2022-03-09 01:43:50 --> Helper loaded: common_helper
INFO - 2022-03-09 01:43:50 --> Database Driver Class Initialized
DEBUG - 2022-03-09 01:43:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 01:43:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 01:43:50 --> Controller Class Initialized
INFO - 2022-03-09 01:43:50 --> Form Validation Class Initialized
DEBUG - 2022-03-09 01:43:50 --> Encrypt Class Initialized
INFO - 2022-03-09 01:43:50 --> Model "Patient_model" initialized
INFO - 2022-03-09 01:43:50 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 01:43:50 --> Model "Referredby_model" initialized
INFO - 2022-03-09 01:43:50 --> Model "Prefix_master" initialized
INFO - 2022-03-09 01:43:50 --> Model "Hospital_model" initialized
INFO - 2022-03-09 01:43:50 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 01:43:50 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-09 01:43:50 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 01:43:50 --> Final output sent to browser
DEBUG - 2022-03-09 01:43:50 --> Total execution time: 0.0898
ERROR - 2022-03-09 01:43:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 01:43:51 --> Config Class Initialized
INFO - 2022-03-09 01:43:51 --> Hooks Class Initialized
DEBUG - 2022-03-09 01:43:51 --> UTF-8 Support Enabled
INFO - 2022-03-09 01:43:51 --> Utf8 Class Initialized
INFO - 2022-03-09 01:43:51 --> URI Class Initialized
INFO - 2022-03-09 01:43:51 --> Router Class Initialized
INFO - 2022-03-09 01:43:51 --> Output Class Initialized
INFO - 2022-03-09 01:43:51 --> Security Class Initialized
DEBUG - 2022-03-09 01:43:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 01:43:51 --> Input Class Initialized
INFO - 2022-03-09 01:43:51 --> Language Class Initialized
ERROR - 2022-03-09 01:43:51 --> 404 Page Not Found: Karoclient/images
ERROR - 2022-03-09 02:10:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 02:10:53 --> Config Class Initialized
INFO - 2022-03-09 02:10:53 --> Hooks Class Initialized
DEBUG - 2022-03-09 02:10:53 --> UTF-8 Support Enabled
INFO - 2022-03-09 02:10:53 --> Utf8 Class Initialized
INFO - 2022-03-09 02:10:53 --> URI Class Initialized
DEBUG - 2022-03-09 02:10:53 --> No URI present. Default controller set.
INFO - 2022-03-09 02:10:53 --> Router Class Initialized
INFO - 2022-03-09 02:10:53 --> Output Class Initialized
INFO - 2022-03-09 02:10:53 --> Security Class Initialized
DEBUG - 2022-03-09 02:10:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 02:10:53 --> Input Class Initialized
INFO - 2022-03-09 02:10:53 --> Language Class Initialized
INFO - 2022-03-09 02:10:53 --> Loader Class Initialized
INFO - 2022-03-09 02:10:53 --> Helper loaded: url_helper
INFO - 2022-03-09 02:10:53 --> Helper loaded: form_helper
INFO - 2022-03-09 02:10:53 --> Helper loaded: common_helper
INFO - 2022-03-09 02:10:53 --> Database Driver Class Initialized
DEBUG - 2022-03-09 02:10:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 02:10:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 02:10:53 --> Controller Class Initialized
INFO - 2022-03-09 02:10:53 --> Form Validation Class Initialized
DEBUG - 2022-03-09 02:10:53 --> Encrypt Class Initialized
DEBUG - 2022-03-09 02:10:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-09 02:10:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-09 02:10:53 --> Email Class Initialized
INFO - 2022-03-09 02:10:53 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-09 02:10:53 --> Calendar Class Initialized
INFO - 2022-03-09 02:10:53 --> Model "Login_model" initialized
INFO - 2022-03-09 02:10:53 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-09 02:10:53 --> Final output sent to browser
DEBUG - 2022-03-09 02:10:53 --> Total execution time: 0.0263
ERROR - 2022-03-09 02:11:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 02:11:12 --> Config Class Initialized
INFO - 2022-03-09 02:11:12 --> Hooks Class Initialized
DEBUG - 2022-03-09 02:11:12 --> UTF-8 Support Enabled
INFO - 2022-03-09 02:11:12 --> Utf8 Class Initialized
INFO - 2022-03-09 02:11:12 --> URI Class Initialized
INFO - 2022-03-09 02:11:12 --> Router Class Initialized
INFO - 2022-03-09 02:11:12 --> Output Class Initialized
INFO - 2022-03-09 02:11:12 --> Security Class Initialized
DEBUG - 2022-03-09 02:11:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 02:11:12 --> Input Class Initialized
INFO - 2022-03-09 02:11:12 --> Language Class Initialized
INFO - 2022-03-09 02:11:12 --> Loader Class Initialized
INFO - 2022-03-09 02:11:12 --> Helper loaded: url_helper
INFO - 2022-03-09 02:11:12 --> Helper loaded: form_helper
INFO - 2022-03-09 02:11:12 --> Helper loaded: common_helper
INFO - 2022-03-09 02:11:12 --> Database Driver Class Initialized
DEBUG - 2022-03-09 02:11:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 02:11:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 02:11:12 --> Controller Class Initialized
INFO - 2022-03-09 02:11:12 --> Form Validation Class Initialized
DEBUG - 2022-03-09 02:11:12 --> Encrypt Class Initialized
DEBUG - 2022-03-09 02:11:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-09 02:11:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-09 02:11:12 --> Email Class Initialized
INFO - 2022-03-09 02:11:12 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-09 02:11:12 --> Calendar Class Initialized
INFO - 2022-03-09 02:11:12 --> Model "Login_model" initialized
INFO - 2022-03-09 02:11:12 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-03-09 02:11:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 02:11:13 --> Config Class Initialized
INFO - 2022-03-09 02:11:13 --> Hooks Class Initialized
DEBUG - 2022-03-09 02:11:13 --> UTF-8 Support Enabled
INFO - 2022-03-09 02:11:13 --> Utf8 Class Initialized
INFO - 2022-03-09 02:11:13 --> URI Class Initialized
INFO - 2022-03-09 02:11:13 --> Router Class Initialized
INFO - 2022-03-09 02:11:13 --> Output Class Initialized
INFO - 2022-03-09 02:11:13 --> Security Class Initialized
DEBUG - 2022-03-09 02:11:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 02:11:13 --> Input Class Initialized
INFO - 2022-03-09 02:11:13 --> Language Class Initialized
INFO - 2022-03-09 02:11:13 --> Loader Class Initialized
INFO - 2022-03-09 02:11:13 --> Helper loaded: url_helper
INFO - 2022-03-09 02:11:13 --> Helper loaded: form_helper
INFO - 2022-03-09 02:11:13 --> Helper loaded: common_helper
INFO - 2022-03-09 02:11:13 --> Database Driver Class Initialized
DEBUG - 2022-03-09 02:11:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 02:11:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 02:11:13 --> Controller Class Initialized
INFO - 2022-03-09 02:11:13 --> Form Validation Class Initialized
DEBUG - 2022-03-09 02:11:13 --> Encrypt Class Initialized
INFO - 2022-03-09 02:11:13 --> Model "Login_model" initialized
INFO - 2022-03-09 02:11:13 --> Model "Dashboard_model" initialized
INFO - 2022-03-09 02:11:13 --> Model "Case_model" initialized
INFO - 2022-03-09 02:11:21 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 02:11:31 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2022-03-09 02:11:31 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 02:11:31 --> Final output sent to browser
DEBUG - 2022-03-09 02:11:31 --> Total execution time: 18.9749
ERROR - 2022-03-09 02:11:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 02:11:33 --> Config Class Initialized
INFO - 2022-03-09 02:11:33 --> Hooks Class Initialized
DEBUG - 2022-03-09 02:11:33 --> UTF-8 Support Enabled
INFO - 2022-03-09 02:11:33 --> Utf8 Class Initialized
INFO - 2022-03-09 02:11:33 --> URI Class Initialized
INFO - 2022-03-09 02:11:33 --> Router Class Initialized
INFO - 2022-03-09 02:11:33 --> Output Class Initialized
INFO - 2022-03-09 02:11:33 --> Security Class Initialized
DEBUG - 2022-03-09 02:11:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 02:11:33 --> Input Class Initialized
INFO - 2022-03-09 02:11:33 --> Language Class Initialized
ERROR - 2022-03-09 02:11:33 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-09 02:12:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 02:12:04 --> Config Class Initialized
INFO - 2022-03-09 02:12:04 --> Hooks Class Initialized
DEBUG - 2022-03-09 02:12:04 --> UTF-8 Support Enabled
INFO - 2022-03-09 02:12:04 --> Utf8 Class Initialized
INFO - 2022-03-09 02:12:04 --> URI Class Initialized
INFO - 2022-03-09 02:12:04 --> Router Class Initialized
INFO - 2022-03-09 02:12:04 --> Output Class Initialized
INFO - 2022-03-09 02:12:04 --> Security Class Initialized
DEBUG - 2022-03-09 02:12:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 02:12:04 --> Input Class Initialized
INFO - 2022-03-09 02:12:04 --> Language Class Initialized
INFO - 2022-03-09 02:12:04 --> Loader Class Initialized
INFO - 2022-03-09 02:12:04 --> Helper loaded: url_helper
INFO - 2022-03-09 02:12:04 --> Helper loaded: form_helper
INFO - 2022-03-09 02:12:04 --> Helper loaded: common_helper
INFO - 2022-03-09 02:12:04 --> Database Driver Class Initialized
DEBUG - 2022-03-09 02:12:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 02:12:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 02:12:04 --> Controller Class Initialized
INFO - 2022-03-09 02:12:04 --> Form Validation Class Initialized
DEBUG - 2022-03-09 02:12:04 --> Encrypt Class Initialized
INFO - 2022-03-09 02:12:04 --> Model "Patient_model" initialized
INFO - 2022-03-09 02:12:04 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 02:12:04 --> Model "Referredby_model" initialized
INFO - 2022-03-09 02:12:04 --> Model "Prefix_master" initialized
INFO - 2022-03-09 02:12:04 --> Model "Hospital_model" initialized
INFO - 2022-03-09 02:12:04 --> File loaded: /home3/karoteam/public_html/application/views/header.php
ERROR - 2022-03-09 02:12:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 02:12:08 --> Config Class Initialized
INFO - 2022-03-09 02:12:08 --> Hooks Class Initialized
DEBUG - 2022-03-09 02:12:08 --> UTF-8 Support Enabled
INFO - 2022-03-09 02:12:08 --> Utf8 Class Initialized
INFO - 2022-03-09 02:12:08 --> URI Class Initialized
INFO - 2022-03-09 02:12:08 --> Router Class Initialized
INFO - 2022-03-09 02:12:08 --> Output Class Initialized
INFO - 2022-03-09 02:12:08 --> Security Class Initialized
DEBUG - 2022-03-09 02:12:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 02:12:08 --> Input Class Initialized
INFO - 2022-03-09 02:12:08 --> Language Class Initialized
INFO - 2022-03-09 02:12:08 --> Loader Class Initialized
INFO - 2022-03-09 02:12:08 --> Helper loaded: url_helper
INFO - 2022-03-09 02:12:08 --> Helper loaded: form_helper
INFO - 2022-03-09 02:12:08 --> Helper loaded: common_helper
INFO - 2022-03-09 02:12:08 --> Database Driver Class Initialized
DEBUG - 2022-03-09 02:12:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 02:12:10 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-09 02:12:10 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 02:12:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 02:12:10 --> Controller Class Initialized
INFO - 2022-03-09 02:12:10 --> Form Validation Class Initialized
DEBUG - 2022-03-09 02:12:10 --> Encrypt Class Initialized
INFO - 2022-03-09 02:12:10 --> Model "Patient_model" initialized
INFO - 2022-03-09 02:12:10 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 02:12:10 --> Model "Referredby_model" initialized
INFO - 2022-03-09 02:12:10 --> Model "Prefix_master" initialized
INFO - 2022-03-09 02:12:10 --> Model "Hospital_model" initialized
INFO - 2022-03-09 02:12:10 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 02:12:17 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-09 02:12:17 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
ERROR - 2022-03-09 02:12:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 02:12:18 --> Config Class Initialized
INFO - 2022-03-09 02:12:18 --> Hooks Class Initialized
DEBUG - 2022-03-09 02:12:18 --> UTF-8 Support Enabled
INFO - 2022-03-09 02:12:18 --> Utf8 Class Initialized
INFO - 2022-03-09 02:12:18 --> URI Class Initialized
INFO - 2022-03-09 02:12:18 --> Router Class Initialized
INFO - 2022-03-09 02:12:18 --> Output Class Initialized
INFO - 2022-03-09 02:12:18 --> Security Class Initialized
DEBUG - 2022-03-09 02:12:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 02:12:18 --> Input Class Initialized
INFO - 2022-03-09 02:12:18 --> Language Class Initialized
ERROR - 2022-03-09 02:12:18 --> 404 Page Not Found: Karoclient/usersprofile
INFO - 2022-03-09 02:12:18 --> Final output sent to browser
DEBUG - 2022-03-09 02:12:18 --> Total execution time: 8.5072
ERROR - 2022-03-09 02:20:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 02:20:27 --> Config Class Initialized
INFO - 2022-03-09 02:20:27 --> Hooks Class Initialized
DEBUG - 2022-03-09 02:20:27 --> UTF-8 Support Enabled
INFO - 2022-03-09 02:20:27 --> Utf8 Class Initialized
INFO - 2022-03-09 02:20:27 --> URI Class Initialized
DEBUG - 2022-03-09 02:20:27 --> No URI present. Default controller set.
INFO - 2022-03-09 02:20:27 --> Router Class Initialized
INFO - 2022-03-09 02:20:27 --> Output Class Initialized
INFO - 2022-03-09 02:20:27 --> Security Class Initialized
DEBUG - 2022-03-09 02:20:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 02:20:27 --> Input Class Initialized
INFO - 2022-03-09 02:20:27 --> Language Class Initialized
INFO - 2022-03-09 02:20:27 --> Loader Class Initialized
INFO - 2022-03-09 02:20:27 --> Helper loaded: url_helper
INFO - 2022-03-09 02:20:27 --> Helper loaded: form_helper
INFO - 2022-03-09 02:20:27 --> Helper loaded: common_helper
INFO - 2022-03-09 02:20:27 --> Database Driver Class Initialized
DEBUG - 2022-03-09 02:20:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 02:20:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 02:20:27 --> Controller Class Initialized
INFO - 2022-03-09 02:20:27 --> Form Validation Class Initialized
DEBUG - 2022-03-09 02:20:27 --> Encrypt Class Initialized
DEBUG - 2022-03-09 02:20:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-09 02:20:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-09 02:20:27 --> Email Class Initialized
INFO - 2022-03-09 02:20:27 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-09 02:20:27 --> Calendar Class Initialized
INFO - 2022-03-09 02:20:27 --> Model "Login_model" initialized
ERROR - 2022-03-09 02:20:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 02:20:27 --> Config Class Initialized
INFO - 2022-03-09 02:20:27 --> Hooks Class Initialized
DEBUG - 2022-03-09 02:20:27 --> UTF-8 Support Enabled
INFO - 2022-03-09 02:20:27 --> Utf8 Class Initialized
INFO - 2022-03-09 02:20:27 --> URI Class Initialized
INFO - 2022-03-09 02:20:27 --> Router Class Initialized
INFO - 2022-03-09 02:20:27 --> Output Class Initialized
INFO - 2022-03-09 02:20:27 --> Security Class Initialized
DEBUG - 2022-03-09 02:20:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 02:20:27 --> Input Class Initialized
INFO - 2022-03-09 02:20:27 --> Language Class Initialized
INFO - 2022-03-09 02:20:27 --> Loader Class Initialized
INFO - 2022-03-09 02:20:27 --> Helper loaded: url_helper
INFO - 2022-03-09 02:20:27 --> Helper loaded: form_helper
INFO - 2022-03-09 02:20:27 --> Helper loaded: common_helper
INFO - 2022-03-09 02:20:27 --> Database Driver Class Initialized
DEBUG - 2022-03-09 02:20:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 02:20:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 02:20:27 --> Controller Class Initialized
INFO - 2022-03-09 02:20:27 --> Form Validation Class Initialized
DEBUG - 2022-03-09 02:20:27 --> Encrypt Class Initialized
INFO - 2022-03-09 02:20:27 --> Model "Diseases_model" initialized
INFO - 2022-03-09 02:20:27 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 02:20:27 --> File loaded: /home3/karoteam/public_html/application/views/diseases/index.php
INFO - 2022-03-09 02:20:27 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 02:20:27 --> Final output sent to browser
DEBUG - 2022-03-09 02:20:27 --> Total execution time: 0.0268
ERROR - 2022-03-09 02:20:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 02:20:34 --> Config Class Initialized
INFO - 2022-03-09 02:20:34 --> Hooks Class Initialized
DEBUG - 2022-03-09 02:20:34 --> UTF-8 Support Enabled
INFO - 2022-03-09 02:20:34 --> Utf8 Class Initialized
INFO - 2022-03-09 02:20:34 --> URI Class Initialized
INFO - 2022-03-09 02:20:34 --> Router Class Initialized
INFO - 2022-03-09 02:20:34 --> Output Class Initialized
INFO - 2022-03-09 02:20:34 --> Security Class Initialized
DEBUG - 2022-03-09 02:20:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 02:20:34 --> Input Class Initialized
INFO - 2022-03-09 02:20:34 --> Language Class Initialized
INFO - 2022-03-09 02:20:34 --> Loader Class Initialized
INFO - 2022-03-09 02:20:34 --> Helper loaded: url_helper
INFO - 2022-03-09 02:20:34 --> Helper loaded: form_helper
INFO - 2022-03-09 02:20:34 --> Helper loaded: common_helper
INFO - 2022-03-09 02:20:34 --> Database Driver Class Initialized
DEBUG - 2022-03-09 02:20:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 02:20:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 02:20:34 --> Controller Class Initialized
INFO - 2022-03-09 02:20:34 --> Form Validation Class Initialized
DEBUG - 2022-03-09 02:20:34 --> Encrypt Class Initialized
INFO - 2022-03-09 02:20:34 --> Model "Patient_model" initialized
INFO - 2022-03-09 02:20:34 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 02:20:34 --> Model "Referredby_model" initialized
INFO - 2022-03-09 02:20:34 --> Model "Prefix_master" initialized
INFO - 2022-03-09 02:20:34 --> Model "Hospital_model" initialized
INFO - 2022-03-09 02:20:34 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 02:20:34 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-09 02:20:34 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 02:20:34 --> Final output sent to browser
DEBUG - 2022-03-09 02:20:34 --> Total execution time: 0.0540
ERROR - 2022-03-09 02:20:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 02:20:43 --> Config Class Initialized
INFO - 2022-03-09 02:20:43 --> Hooks Class Initialized
DEBUG - 2022-03-09 02:20:43 --> UTF-8 Support Enabled
INFO - 2022-03-09 02:20:43 --> Utf8 Class Initialized
INFO - 2022-03-09 02:20:43 --> URI Class Initialized
INFO - 2022-03-09 02:20:43 --> Router Class Initialized
INFO - 2022-03-09 02:20:43 --> Output Class Initialized
INFO - 2022-03-09 02:20:43 --> Security Class Initialized
DEBUG - 2022-03-09 02:20:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 02:20:43 --> Input Class Initialized
INFO - 2022-03-09 02:20:43 --> Language Class Initialized
INFO - 2022-03-09 02:20:43 --> Loader Class Initialized
INFO - 2022-03-09 02:20:43 --> Helper loaded: url_helper
INFO - 2022-03-09 02:20:43 --> Helper loaded: form_helper
INFO - 2022-03-09 02:20:43 --> Helper loaded: common_helper
INFO - 2022-03-09 02:20:43 --> Database Driver Class Initialized
DEBUG - 2022-03-09 02:20:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 02:20:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 02:20:43 --> Controller Class Initialized
INFO - 2022-03-09 02:20:43 --> Form Validation Class Initialized
DEBUG - 2022-03-09 02:20:43 --> Encrypt Class Initialized
INFO - 2022-03-09 02:20:43 --> Model "Patient_model" initialized
INFO - 2022-03-09 02:20:43 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 02:20:43 --> Model "Prefix_master" initialized
INFO - 2022-03-09 02:20:43 --> Model "Users_model" initialized
INFO - 2022-03-09 02:20:43 --> Model "Hospital_model" initialized
INFO - 2022-03-09 02:20:43 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 02:20:43 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-09 02:20:43 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 02:20:43 --> Final output sent to browser
DEBUG - 2022-03-09 02:20:43 --> Total execution time: 0.0666
ERROR - 2022-03-09 02:47:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 02:47:09 --> Config Class Initialized
INFO - 2022-03-09 02:47:09 --> Hooks Class Initialized
DEBUG - 2022-03-09 02:47:09 --> UTF-8 Support Enabled
INFO - 2022-03-09 02:47:09 --> Utf8 Class Initialized
INFO - 2022-03-09 02:47:09 --> URI Class Initialized
INFO - 2022-03-09 02:47:09 --> Router Class Initialized
INFO - 2022-03-09 02:47:09 --> Output Class Initialized
INFO - 2022-03-09 02:47:09 --> Security Class Initialized
DEBUG - 2022-03-09 02:47:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 02:47:09 --> Input Class Initialized
INFO - 2022-03-09 02:47:09 --> Language Class Initialized
INFO - 2022-03-09 02:47:09 --> Loader Class Initialized
INFO - 2022-03-09 02:47:09 --> Helper loaded: url_helper
INFO - 2022-03-09 02:47:09 --> Helper loaded: form_helper
INFO - 2022-03-09 02:47:09 --> Helper loaded: common_helper
INFO - 2022-03-09 02:47:09 --> Database Driver Class Initialized
DEBUG - 2022-03-09 02:47:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 02:47:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 02:47:09 --> Controller Class Initialized
INFO - 2022-03-09 02:47:09 --> Form Validation Class Initialized
DEBUG - 2022-03-09 02:47:09 --> Encrypt Class Initialized
INFO - 2022-03-09 02:47:09 --> Model "Patient_model" initialized
INFO - 2022-03-09 02:47:09 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 02:47:09 --> Model "Prefix_master" initialized
INFO - 2022-03-09 02:47:09 --> Model "Users_model" initialized
INFO - 2022-03-09 02:47:09 --> Model "Hospital_model" initialized
ERROR - 2022-03-09 02:47:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 02:47:09 --> Config Class Initialized
INFO - 2022-03-09 02:47:09 --> Hooks Class Initialized
DEBUG - 2022-03-09 02:47:09 --> UTF-8 Support Enabled
INFO - 2022-03-09 02:47:09 --> Utf8 Class Initialized
INFO - 2022-03-09 02:47:09 --> URI Class Initialized
INFO - 2022-03-09 02:47:09 --> Router Class Initialized
INFO - 2022-03-09 02:47:09 --> Output Class Initialized
INFO - 2022-03-09 02:47:09 --> Security Class Initialized
DEBUG - 2022-03-09 02:47:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 02:47:09 --> Input Class Initialized
INFO - 2022-03-09 02:47:09 --> Language Class Initialized
INFO - 2022-03-09 02:47:09 --> Loader Class Initialized
INFO - 2022-03-09 02:47:09 --> Helper loaded: url_helper
INFO - 2022-03-09 02:47:09 --> Helper loaded: form_helper
INFO - 2022-03-09 02:47:09 --> Helper loaded: common_helper
INFO - 2022-03-09 02:47:09 --> Database Driver Class Initialized
DEBUG - 2022-03-09 02:47:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 02:47:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 02:47:09 --> Controller Class Initialized
INFO - 2022-03-09 02:47:09 --> Form Validation Class Initialized
DEBUG - 2022-03-09 02:47:09 --> Encrypt Class Initialized
INFO - 2022-03-09 02:47:09 --> Model "Patient_model" initialized
INFO - 2022-03-09 02:47:09 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 02:47:09 --> Model "Prefix_master" initialized
INFO - 2022-03-09 02:47:09 --> Model "Users_model" initialized
INFO - 2022-03-09 02:47:09 --> Model "Hospital_model" initialized
INFO - 2022-03-09 02:47:09 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 02:47:09 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-09 02:47:09 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 02:47:09 --> Final output sent to browser
DEBUG - 2022-03-09 02:47:09 --> Total execution time: 0.0813
ERROR - 2022-03-09 02:48:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 02:48:06 --> Config Class Initialized
INFO - 2022-03-09 02:48:06 --> Hooks Class Initialized
DEBUG - 2022-03-09 02:48:06 --> UTF-8 Support Enabled
INFO - 2022-03-09 02:48:06 --> Utf8 Class Initialized
INFO - 2022-03-09 02:48:06 --> URI Class Initialized
DEBUG - 2022-03-09 02:48:06 --> No URI present. Default controller set.
INFO - 2022-03-09 02:48:06 --> Router Class Initialized
INFO - 2022-03-09 02:48:06 --> Output Class Initialized
INFO - 2022-03-09 02:48:06 --> Security Class Initialized
DEBUG - 2022-03-09 02:48:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 02:48:06 --> Input Class Initialized
INFO - 2022-03-09 02:48:06 --> Language Class Initialized
INFO - 2022-03-09 02:48:06 --> Loader Class Initialized
INFO - 2022-03-09 02:48:06 --> Helper loaded: url_helper
INFO - 2022-03-09 02:48:06 --> Helper loaded: form_helper
INFO - 2022-03-09 02:48:06 --> Helper loaded: common_helper
INFO - 2022-03-09 02:48:06 --> Database Driver Class Initialized
DEBUG - 2022-03-09 02:48:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 02:48:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 02:48:06 --> Controller Class Initialized
INFO - 2022-03-09 02:48:06 --> Form Validation Class Initialized
DEBUG - 2022-03-09 02:48:06 --> Encrypt Class Initialized
DEBUG - 2022-03-09 02:48:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-09 02:48:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-09 02:48:06 --> Email Class Initialized
INFO - 2022-03-09 02:48:06 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-09 02:48:06 --> Calendar Class Initialized
INFO - 2022-03-09 02:48:06 --> Model "Login_model" initialized
INFO - 2022-03-09 02:48:06 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-09 02:48:06 --> Final output sent to browser
DEBUG - 2022-03-09 02:48:06 --> Total execution time: 0.0219
ERROR - 2022-03-09 02:48:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 02:48:10 --> Config Class Initialized
INFO - 2022-03-09 02:48:10 --> Hooks Class Initialized
DEBUG - 2022-03-09 02:48:10 --> UTF-8 Support Enabled
INFO - 2022-03-09 02:48:10 --> Utf8 Class Initialized
INFO - 2022-03-09 02:48:10 --> URI Class Initialized
INFO - 2022-03-09 02:48:10 --> Router Class Initialized
INFO - 2022-03-09 02:48:10 --> Output Class Initialized
INFO - 2022-03-09 02:48:10 --> Security Class Initialized
DEBUG - 2022-03-09 02:48:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 02:48:10 --> Input Class Initialized
INFO - 2022-03-09 02:48:10 --> Language Class Initialized
INFO - 2022-03-09 02:48:10 --> Loader Class Initialized
INFO - 2022-03-09 02:48:10 --> Helper loaded: url_helper
INFO - 2022-03-09 02:48:10 --> Helper loaded: form_helper
INFO - 2022-03-09 02:48:10 --> Helper loaded: common_helper
INFO - 2022-03-09 02:48:10 --> Database Driver Class Initialized
DEBUG - 2022-03-09 02:48:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 02:48:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 02:48:10 --> Controller Class Initialized
INFO - 2022-03-09 02:48:10 --> Form Validation Class Initialized
DEBUG - 2022-03-09 02:48:10 --> Encrypt Class Initialized
INFO - 2022-03-09 02:48:10 --> Model "Patient_model" initialized
INFO - 2022-03-09 02:48:10 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 02:48:10 --> Model "Referredby_model" initialized
INFO - 2022-03-09 02:48:10 --> Model "Prefix_master" initialized
INFO - 2022-03-09 02:48:10 --> Model "Hospital_model" initialized
INFO - 2022-03-09 02:48:10 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 02:48:10 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-09 02:48:10 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 02:48:10 --> Final output sent to browser
DEBUG - 2022-03-09 02:48:10 --> Total execution time: 0.1025
ERROR - 2022-03-09 02:48:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 02:48:40 --> Config Class Initialized
INFO - 2022-03-09 02:48:40 --> Hooks Class Initialized
DEBUG - 2022-03-09 02:48:40 --> UTF-8 Support Enabled
INFO - 2022-03-09 02:48:40 --> Utf8 Class Initialized
INFO - 2022-03-09 02:48:40 --> URI Class Initialized
INFO - 2022-03-09 02:48:40 --> Router Class Initialized
INFO - 2022-03-09 02:48:40 --> Output Class Initialized
INFO - 2022-03-09 02:48:40 --> Security Class Initialized
DEBUG - 2022-03-09 02:48:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 02:48:40 --> Input Class Initialized
INFO - 2022-03-09 02:48:40 --> Language Class Initialized
INFO - 2022-03-09 02:48:40 --> Loader Class Initialized
INFO - 2022-03-09 02:48:40 --> Helper loaded: url_helper
INFO - 2022-03-09 02:48:40 --> Helper loaded: form_helper
INFO - 2022-03-09 02:48:40 --> Helper loaded: common_helper
INFO - 2022-03-09 02:48:40 --> Database Driver Class Initialized
DEBUG - 2022-03-09 02:48:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 02:48:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 02:48:40 --> Controller Class Initialized
ERROR - 2022-03-09 02:48:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 02:48:40 --> Config Class Initialized
INFO - 2022-03-09 02:48:40 --> Hooks Class Initialized
DEBUG - 2022-03-09 02:48:40 --> UTF-8 Support Enabled
INFO - 2022-03-09 02:48:40 --> Utf8 Class Initialized
INFO - 2022-03-09 02:48:40 --> URI Class Initialized
INFO - 2022-03-09 02:48:40 --> Router Class Initialized
INFO - 2022-03-09 02:48:40 --> Output Class Initialized
INFO - 2022-03-09 02:48:40 --> Security Class Initialized
DEBUG - 2022-03-09 02:48:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 02:48:40 --> Input Class Initialized
INFO - 2022-03-09 02:48:40 --> Language Class Initialized
INFO - 2022-03-09 02:48:40 --> Loader Class Initialized
INFO - 2022-03-09 02:48:40 --> Helper loaded: url_helper
INFO - 2022-03-09 02:48:40 --> Helper loaded: form_helper
INFO - 2022-03-09 02:48:40 --> Helper loaded: common_helper
INFO - 2022-03-09 02:48:40 --> Database Driver Class Initialized
DEBUG - 2022-03-09 02:48:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 02:48:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 02:48:40 --> Controller Class Initialized
INFO - 2022-03-09 02:48:40 --> Form Validation Class Initialized
DEBUG - 2022-03-09 02:48:40 --> Encrypt Class Initialized
DEBUG - 2022-03-09 02:48:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-09 02:48:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-09 02:48:40 --> Email Class Initialized
INFO - 2022-03-09 02:48:40 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-09 02:48:40 --> Calendar Class Initialized
INFO - 2022-03-09 02:48:40 --> Model "Login_model" initialized
INFO - 2022-03-09 02:48:40 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-09 02:48:40 --> Final output sent to browser
DEBUG - 2022-03-09 02:48:40 --> Total execution time: 0.0274
ERROR - 2022-03-09 02:48:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 02:48:54 --> Config Class Initialized
INFO - 2022-03-09 02:48:54 --> Hooks Class Initialized
DEBUG - 2022-03-09 02:48:54 --> UTF-8 Support Enabled
INFO - 2022-03-09 02:48:54 --> Utf8 Class Initialized
INFO - 2022-03-09 02:48:54 --> URI Class Initialized
INFO - 2022-03-09 02:48:54 --> Router Class Initialized
INFO - 2022-03-09 02:48:54 --> Output Class Initialized
INFO - 2022-03-09 02:48:54 --> Security Class Initialized
DEBUG - 2022-03-09 02:48:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 02:48:54 --> Input Class Initialized
INFO - 2022-03-09 02:48:54 --> Language Class Initialized
INFO - 2022-03-09 02:48:54 --> Loader Class Initialized
INFO - 2022-03-09 02:48:54 --> Helper loaded: url_helper
INFO - 2022-03-09 02:48:54 --> Helper loaded: form_helper
INFO - 2022-03-09 02:48:54 --> Helper loaded: common_helper
INFO - 2022-03-09 02:48:54 --> Database Driver Class Initialized
DEBUG - 2022-03-09 02:48:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 02:48:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 02:48:54 --> Controller Class Initialized
INFO - 2022-03-09 02:48:54 --> Form Validation Class Initialized
DEBUG - 2022-03-09 02:48:54 --> Encrypt Class Initialized
DEBUG - 2022-03-09 02:48:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-09 02:48:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-09 02:48:54 --> Email Class Initialized
INFO - 2022-03-09 02:48:54 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-09 02:48:54 --> Calendar Class Initialized
INFO - 2022-03-09 02:48:54 --> Model "Login_model" initialized
INFO - 2022-03-09 02:48:54 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-03-09 02:48:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 02:48:55 --> Config Class Initialized
INFO - 2022-03-09 02:48:55 --> Hooks Class Initialized
DEBUG - 2022-03-09 02:48:55 --> UTF-8 Support Enabled
INFO - 2022-03-09 02:48:55 --> Utf8 Class Initialized
INFO - 2022-03-09 02:48:55 --> URI Class Initialized
INFO - 2022-03-09 02:48:55 --> Router Class Initialized
INFO - 2022-03-09 02:48:55 --> Output Class Initialized
INFO - 2022-03-09 02:48:55 --> Security Class Initialized
DEBUG - 2022-03-09 02:48:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 02:48:55 --> Input Class Initialized
INFO - 2022-03-09 02:48:55 --> Language Class Initialized
INFO - 2022-03-09 02:48:55 --> Loader Class Initialized
INFO - 2022-03-09 02:48:55 --> Helper loaded: url_helper
INFO - 2022-03-09 02:48:55 --> Helper loaded: form_helper
INFO - 2022-03-09 02:48:55 --> Helper loaded: common_helper
INFO - 2022-03-09 02:48:55 --> Database Driver Class Initialized
DEBUG - 2022-03-09 02:48:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 02:48:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 02:48:55 --> Controller Class Initialized
INFO - 2022-03-09 02:48:55 --> Form Validation Class Initialized
DEBUG - 2022-03-09 02:48:55 --> Encrypt Class Initialized
INFO - 2022-03-09 02:48:55 --> Model "Login_model" initialized
INFO - 2022-03-09 02:48:55 --> Model "Dashboard_model" initialized
INFO - 2022-03-09 02:48:55 --> Model "Case_model" initialized
INFO - 2022-03-09 02:48:55 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 02:48:55 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2022-03-09 02:48:55 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 02:48:55 --> Final output sent to browser
DEBUG - 2022-03-09 02:48:55 --> Total execution time: 0.2152
ERROR - 2022-03-09 02:49:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 02:49:08 --> Config Class Initialized
INFO - 2022-03-09 02:49:08 --> Hooks Class Initialized
DEBUG - 2022-03-09 02:49:08 --> UTF-8 Support Enabled
INFO - 2022-03-09 02:49:08 --> Utf8 Class Initialized
INFO - 2022-03-09 02:49:08 --> URI Class Initialized
INFO - 2022-03-09 02:49:08 --> Router Class Initialized
INFO - 2022-03-09 02:49:08 --> Output Class Initialized
INFO - 2022-03-09 02:49:08 --> Security Class Initialized
DEBUG - 2022-03-09 02:49:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 02:49:08 --> Input Class Initialized
INFO - 2022-03-09 02:49:08 --> Language Class Initialized
INFO - 2022-03-09 02:49:08 --> Loader Class Initialized
INFO - 2022-03-09 02:49:08 --> Helper loaded: url_helper
INFO - 2022-03-09 02:49:08 --> Helper loaded: form_helper
INFO - 2022-03-09 02:49:08 --> Helper loaded: common_helper
INFO - 2022-03-09 02:49:08 --> Database Driver Class Initialized
DEBUG - 2022-03-09 02:49:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 02:49:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 02:49:08 --> Controller Class Initialized
INFO - 2022-03-09 02:49:08 --> Form Validation Class Initialized
DEBUG - 2022-03-09 02:49:08 --> Encrypt Class Initialized
INFO - 2022-03-09 02:49:08 --> Model "Patient_model" initialized
INFO - 2022-03-09 02:49:08 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 02:49:08 --> Model "Referredby_model" initialized
INFO - 2022-03-09 02:49:08 --> Model "Prefix_master" initialized
INFO - 2022-03-09 02:49:08 --> Model "Hospital_model" initialized
INFO - 2022-03-09 02:49:08 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 02:49:08 --> File loaded: /home3/karoteam/public_html/application/views/patient/patient_by_category.php
INFO - 2022-03-09 02:49:08 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 02:49:08 --> Final output sent to browser
DEBUG - 2022-03-09 02:49:08 --> Total execution time: 0.0494
ERROR - 2022-03-09 02:49:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 02:49:11 --> Config Class Initialized
INFO - 2022-03-09 02:49:11 --> Hooks Class Initialized
DEBUG - 2022-03-09 02:49:11 --> UTF-8 Support Enabled
INFO - 2022-03-09 02:49:11 --> Utf8 Class Initialized
INFO - 2022-03-09 02:49:11 --> URI Class Initialized
INFO - 2022-03-09 02:49:11 --> Router Class Initialized
INFO - 2022-03-09 02:49:11 --> Output Class Initialized
INFO - 2022-03-09 02:49:11 --> Security Class Initialized
DEBUG - 2022-03-09 02:49:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 02:49:11 --> Input Class Initialized
INFO - 2022-03-09 02:49:11 --> Language Class Initialized
INFO - 2022-03-09 02:49:11 --> Loader Class Initialized
INFO - 2022-03-09 02:49:11 --> Helper loaded: url_helper
INFO - 2022-03-09 02:49:11 --> Helper loaded: form_helper
INFO - 2022-03-09 02:49:11 --> Helper loaded: common_helper
INFO - 2022-03-09 02:49:11 --> Database Driver Class Initialized
DEBUG - 2022-03-09 02:49:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 02:49:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 02:49:11 --> Controller Class Initialized
INFO - 2022-03-09 02:49:11 --> Form Validation Class Initialized
DEBUG - 2022-03-09 02:49:11 --> Encrypt Class Initialized
INFO - 2022-03-09 02:49:11 --> Model "Patient_model" initialized
INFO - 2022-03-09 02:49:11 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 02:49:11 --> Model "Referredby_model" initialized
INFO - 2022-03-09 02:49:11 --> Model "Prefix_master" initialized
INFO - 2022-03-09 02:49:11 --> Model "Hospital_model" initialized
INFO - 2022-03-09 02:49:11 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 02:49:11 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-09 02:49:11 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 02:49:12 --> Final output sent to browser
DEBUG - 2022-03-09 02:49:12 --> Total execution time: 0.0919
ERROR - 2022-03-09 02:49:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 02:49:26 --> Config Class Initialized
INFO - 2022-03-09 02:49:26 --> Hooks Class Initialized
DEBUG - 2022-03-09 02:49:26 --> UTF-8 Support Enabled
INFO - 2022-03-09 02:49:26 --> Utf8 Class Initialized
INFO - 2022-03-09 02:49:26 --> URI Class Initialized
INFO - 2022-03-09 02:49:26 --> Router Class Initialized
INFO - 2022-03-09 02:49:26 --> Output Class Initialized
INFO - 2022-03-09 02:49:26 --> Security Class Initialized
DEBUG - 2022-03-09 02:49:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 02:49:26 --> Input Class Initialized
INFO - 2022-03-09 02:49:26 --> Language Class Initialized
INFO - 2022-03-09 02:49:26 --> Loader Class Initialized
INFO - 2022-03-09 02:49:26 --> Helper loaded: url_helper
INFO - 2022-03-09 02:49:26 --> Helper loaded: form_helper
INFO - 2022-03-09 02:49:26 --> Helper loaded: common_helper
INFO - 2022-03-09 02:49:27 --> Database Driver Class Initialized
DEBUG - 2022-03-09 02:49:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 02:49:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 02:49:27 --> Controller Class Initialized
INFO - 2022-03-09 02:49:27 --> Form Validation Class Initialized
DEBUG - 2022-03-09 02:49:27 --> Encrypt Class Initialized
INFO - 2022-03-09 02:49:27 --> Model "Patient_model" initialized
INFO - 2022-03-09 02:49:27 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 02:49:27 --> Model "Referredby_model" initialized
INFO - 2022-03-09 02:49:27 --> Model "Prefix_master" initialized
INFO - 2022-03-09 02:49:27 --> Model "Hospital_model" initialized
ERROR - 2022-03-09 02:49:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 02:49:27 --> Config Class Initialized
INFO - 2022-03-09 02:49:27 --> Hooks Class Initialized
DEBUG - 2022-03-09 02:49:27 --> UTF-8 Support Enabled
INFO - 2022-03-09 02:49:27 --> Utf8 Class Initialized
INFO - 2022-03-09 02:49:27 --> URI Class Initialized
INFO - 2022-03-09 02:49:27 --> Router Class Initialized
INFO - 2022-03-09 02:49:27 --> Output Class Initialized
INFO - 2022-03-09 02:49:27 --> Security Class Initialized
DEBUG - 2022-03-09 02:49:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 02:49:27 --> Input Class Initialized
INFO - 2022-03-09 02:49:27 --> Language Class Initialized
INFO - 2022-03-09 02:49:27 --> Loader Class Initialized
INFO - 2022-03-09 02:49:27 --> Helper loaded: url_helper
INFO - 2022-03-09 02:49:27 --> Helper loaded: form_helper
INFO - 2022-03-09 02:49:27 --> Helper loaded: common_helper
INFO - 2022-03-09 02:49:27 --> Database Driver Class Initialized
DEBUG - 2022-03-09 02:49:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 02:49:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 02:49:27 --> Controller Class Initialized
INFO - 2022-03-09 02:49:27 --> Form Validation Class Initialized
DEBUG - 2022-03-09 02:49:27 --> Encrypt Class Initialized
INFO - 2022-03-09 02:49:27 --> Model "Patient_model" initialized
INFO - 2022-03-09 02:49:27 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 02:49:27 --> Model "Referredby_model" initialized
INFO - 2022-03-09 02:49:27 --> Model "Prefix_master" initialized
INFO - 2022-03-09 02:49:27 --> Model "Hospital_model" initialized
INFO - 2022-03-09 02:49:27 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 02:49:27 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-09 02:49:27 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 02:49:27 --> Final output sent to browser
DEBUG - 2022-03-09 02:49:27 --> Total execution time: 0.0569
ERROR - 2022-03-09 02:49:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 02:49:28 --> Config Class Initialized
INFO - 2022-03-09 02:49:28 --> Hooks Class Initialized
DEBUG - 2022-03-09 02:49:28 --> UTF-8 Support Enabled
INFO - 2022-03-09 02:49:28 --> Utf8 Class Initialized
INFO - 2022-03-09 02:49:28 --> URI Class Initialized
INFO - 2022-03-09 02:49:28 --> Router Class Initialized
INFO - 2022-03-09 02:49:28 --> Output Class Initialized
INFO - 2022-03-09 02:49:28 --> Security Class Initialized
DEBUG - 2022-03-09 02:49:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 02:49:28 --> Input Class Initialized
INFO - 2022-03-09 02:49:28 --> Language Class Initialized
INFO - 2022-03-09 02:49:28 --> Loader Class Initialized
INFO - 2022-03-09 02:49:28 --> Helper loaded: url_helper
INFO - 2022-03-09 02:49:28 --> Helper loaded: form_helper
INFO - 2022-03-09 02:49:28 --> Helper loaded: common_helper
INFO - 2022-03-09 02:49:28 --> Database Driver Class Initialized
DEBUG - 2022-03-09 02:49:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 02:49:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 02:49:28 --> Controller Class Initialized
INFO - 2022-03-09 02:49:28 --> Form Validation Class Initialized
DEBUG - 2022-03-09 02:49:28 --> Encrypt Class Initialized
INFO - 2022-03-09 02:49:28 --> Model "Patient_model" initialized
INFO - 2022-03-09 02:49:28 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 02:49:28 --> Model "Prefix_master" initialized
INFO - 2022-03-09 02:49:28 --> Model "Users_model" initialized
INFO - 2022-03-09 02:49:28 --> Model "Hospital_model" initialized
INFO - 2022-03-09 02:49:28 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 02:49:28 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-09 02:49:28 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 02:49:28 --> Final output sent to browser
DEBUG - 2022-03-09 02:49:28 --> Total execution time: 0.0796
ERROR - 2022-03-09 02:49:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 02:49:34 --> Config Class Initialized
INFO - 2022-03-09 02:49:34 --> Hooks Class Initialized
DEBUG - 2022-03-09 02:49:34 --> UTF-8 Support Enabled
INFO - 2022-03-09 02:49:34 --> Utf8 Class Initialized
INFO - 2022-03-09 02:49:34 --> URI Class Initialized
INFO - 2022-03-09 02:49:34 --> Router Class Initialized
INFO - 2022-03-09 02:49:34 --> Output Class Initialized
INFO - 2022-03-09 02:49:34 --> Security Class Initialized
DEBUG - 2022-03-09 02:49:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 02:49:34 --> Input Class Initialized
INFO - 2022-03-09 02:49:34 --> Language Class Initialized
INFO - 2022-03-09 02:49:34 --> Loader Class Initialized
INFO - 2022-03-09 02:49:34 --> Helper loaded: url_helper
INFO - 2022-03-09 02:49:34 --> Helper loaded: form_helper
INFO - 2022-03-09 02:49:34 --> Helper loaded: common_helper
INFO - 2022-03-09 02:49:34 --> Database Driver Class Initialized
DEBUG - 2022-03-09 02:49:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 02:49:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 02:49:34 --> Controller Class Initialized
INFO - 2022-03-09 02:49:34 --> Form Validation Class Initialized
DEBUG - 2022-03-09 02:49:34 --> Encrypt Class Initialized
INFO - 2022-03-09 02:49:34 --> Model "Patient_model" initialized
INFO - 2022-03-09 02:49:34 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 02:49:34 --> Model "Referredby_model" initialized
INFO - 2022-03-09 02:49:34 --> Model "Prefix_master" initialized
INFO - 2022-03-09 02:49:34 --> Model "Hospital_model" initialized
INFO - 2022-03-09 02:49:34 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 02:49:34 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-09 02:49:34 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 02:49:34 --> Final output sent to browser
DEBUG - 2022-03-09 02:49:34 --> Total execution time: 0.0901
ERROR - 2022-03-09 02:49:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 02:49:47 --> Config Class Initialized
INFO - 2022-03-09 02:49:47 --> Hooks Class Initialized
DEBUG - 2022-03-09 02:49:47 --> UTF-8 Support Enabled
INFO - 2022-03-09 02:49:47 --> Utf8 Class Initialized
INFO - 2022-03-09 02:49:47 --> URI Class Initialized
INFO - 2022-03-09 02:49:47 --> Router Class Initialized
INFO - 2022-03-09 02:49:47 --> Output Class Initialized
INFO - 2022-03-09 02:49:47 --> Security Class Initialized
DEBUG - 2022-03-09 02:49:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 02:49:47 --> Input Class Initialized
INFO - 2022-03-09 02:49:47 --> Language Class Initialized
INFO - 2022-03-09 02:49:47 --> Loader Class Initialized
INFO - 2022-03-09 02:49:47 --> Helper loaded: url_helper
INFO - 2022-03-09 02:49:47 --> Helper loaded: form_helper
INFO - 2022-03-09 02:49:47 --> Helper loaded: common_helper
INFO - 2022-03-09 02:49:47 --> Database Driver Class Initialized
DEBUG - 2022-03-09 02:49:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 02:49:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 02:49:47 --> Controller Class Initialized
INFO - 2022-03-09 02:49:47 --> Form Validation Class Initialized
DEBUG - 2022-03-09 02:49:47 --> Encrypt Class Initialized
INFO - 2022-03-09 02:49:47 --> Model "Patient_model" initialized
INFO - 2022-03-09 02:49:47 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 02:49:47 --> Model "Prefix_master" initialized
INFO - 2022-03-09 02:49:47 --> Model "Users_model" initialized
INFO - 2022-03-09 02:49:47 --> Model "Hospital_model" initialized
INFO - 2022-03-09 02:49:47 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-09 02:49:49 --> Final output sent to browser
DEBUG - 2022-03-09 02:49:49 --> Total execution time: 1.5780
ERROR - 2022-03-09 02:50:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 02:50:21 --> Config Class Initialized
INFO - 2022-03-09 02:50:21 --> Hooks Class Initialized
DEBUG - 2022-03-09 02:50:21 --> UTF-8 Support Enabled
INFO - 2022-03-09 02:50:21 --> Utf8 Class Initialized
INFO - 2022-03-09 02:50:21 --> URI Class Initialized
INFO - 2022-03-09 02:50:21 --> Router Class Initialized
INFO - 2022-03-09 02:50:21 --> Output Class Initialized
INFO - 2022-03-09 02:50:21 --> Security Class Initialized
DEBUG - 2022-03-09 02:50:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 02:50:21 --> Input Class Initialized
INFO - 2022-03-09 02:50:21 --> Language Class Initialized
INFO - 2022-03-09 02:50:21 --> Loader Class Initialized
INFO - 2022-03-09 02:50:21 --> Helper loaded: url_helper
INFO - 2022-03-09 02:50:21 --> Helper loaded: form_helper
INFO - 2022-03-09 02:50:21 --> Helper loaded: common_helper
INFO - 2022-03-09 02:50:21 --> Database Driver Class Initialized
DEBUG - 2022-03-09 02:50:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 02:50:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 02:50:21 --> Controller Class Initialized
INFO - 2022-03-09 02:50:21 --> Form Validation Class Initialized
DEBUG - 2022-03-09 02:50:21 --> Encrypt Class Initialized
INFO - 2022-03-09 02:50:21 --> Model "Patient_model" initialized
INFO - 2022-03-09 02:50:21 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 02:50:21 --> Model "Referredby_model" initialized
INFO - 2022-03-09 02:50:21 --> Model "Prefix_master" initialized
INFO - 2022-03-09 02:50:21 --> Model "Hospital_model" initialized
INFO - 2022-03-09 02:50:21 --> Final output sent to browser
DEBUG - 2022-03-09 02:50:21 --> Total execution time: 0.0365
ERROR - 2022-03-09 02:50:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 02:50:21 --> Config Class Initialized
INFO - 2022-03-09 02:50:21 --> Hooks Class Initialized
DEBUG - 2022-03-09 02:50:21 --> UTF-8 Support Enabled
INFO - 2022-03-09 02:50:21 --> Utf8 Class Initialized
INFO - 2022-03-09 02:50:21 --> URI Class Initialized
INFO - 2022-03-09 02:50:21 --> Router Class Initialized
INFO - 2022-03-09 02:50:21 --> Output Class Initialized
INFO - 2022-03-09 02:50:21 --> Security Class Initialized
DEBUG - 2022-03-09 02:50:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 02:50:21 --> Input Class Initialized
INFO - 2022-03-09 02:50:21 --> Language Class Initialized
INFO - 2022-03-09 02:50:21 --> Loader Class Initialized
INFO - 2022-03-09 02:50:21 --> Helper loaded: url_helper
INFO - 2022-03-09 02:50:21 --> Helper loaded: form_helper
INFO - 2022-03-09 02:50:21 --> Helper loaded: common_helper
INFO - 2022-03-09 02:50:21 --> Database Driver Class Initialized
DEBUG - 2022-03-09 02:50:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 02:50:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 02:50:21 --> Controller Class Initialized
INFO - 2022-03-09 02:50:21 --> Form Validation Class Initialized
DEBUG - 2022-03-09 02:50:21 --> Encrypt Class Initialized
INFO - 2022-03-09 02:50:21 --> Model "Patient_model" initialized
INFO - 2022-03-09 02:50:21 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 02:50:21 --> Model "Referredby_model" initialized
INFO - 2022-03-09 02:50:21 --> Model "Prefix_master" initialized
INFO - 2022-03-09 02:50:21 --> Model "Hospital_model" initialized
ERROR - 2022-03-09 02:50:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 02:50:22 --> Config Class Initialized
INFO - 2022-03-09 02:50:22 --> Hooks Class Initialized
DEBUG - 2022-03-09 02:50:22 --> UTF-8 Support Enabled
INFO - 2022-03-09 02:50:22 --> Utf8 Class Initialized
INFO - 2022-03-09 02:50:22 --> URI Class Initialized
INFO - 2022-03-09 02:50:22 --> Router Class Initialized
INFO - 2022-03-09 02:50:22 --> Output Class Initialized
INFO - 2022-03-09 02:50:22 --> Security Class Initialized
DEBUG - 2022-03-09 02:50:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 02:50:22 --> Input Class Initialized
INFO - 2022-03-09 02:50:22 --> Language Class Initialized
INFO - 2022-03-09 02:50:22 --> Loader Class Initialized
INFO - 2022-03-09 02:50:22 --> Helper loaded: url_helper
INFO - 2022-03-09 02:50:22 --> Helper loaded: form_helper
INFO - 2022-03-09 02:50:22 --> Helper loaded: common_helper
INFO - 2022-03-09 02:50:22 --> Database Driver Class Initialized
DEBUG - 2022-03-09 02:50:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 02:50:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 02:50:22 --> Controller Class Initialized
INFO - 2022-03-09 02:50:22 --> Form Validation Class Initialized
DEBUG - 2022-03-09 02:50:22 --> Encrypt Class Initialized
INFO - 2022-03-09 02:50:22 --> Model "Patient_model" initialized
INFO - 2022-03-09 02:50:22 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 02:50:22 --> Model "Referredby_model" initialized
INFO - 2022-03-09 02:50:22 --> Model "Prefix_master" initialized
INFO - 2022-03-09 02:50:22 --> Model "Hospital_model" initialized
INFO - 2022-03-09 02:50:22 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 02:50:22 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-09 02:50:22 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 02:50:22 --> Final output sent to browser
DEBUG - 2022-03-09 02:50:22 --> Total execution time: 0.0491
ERROR - 2022-03-09 02:50:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 02:50:23 --> Config Class Initialized
INFO - 2022-03-09 02:50:23 --> Hooks Class Initialized
DEBUG - 2022-03-09 02:50:23 --> UTF-8 Support Enabled
INFO - 2022-03-09 02:50:23 --> Utf8 Class Initialized
INFO - 2022-03-09 02:50:23 --> URI Class Initialized
INFO - 2022-03-09 02:50:23 --> Router Class Initialized
INFO - 2022-03-09 02:50:23 --> Output Class Initialized
INFO - 2022-03-09 02:50:23 --> Security Class Initialized
DEBUG - 2022-03-09 02:50:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 02:50:23 --> Input Class Initialized
INFO - 2022-03-09 02:50:23 --> Language Class Initialized
INFO - 2022-03-09 02:50:23 --> Loader Class Initialized
INFO - 2022-03-09 02:50:23 --> Helper loaded: url_helper
INFO - 2022-03-09 02:50:23 --> Helper loaded: form_helper
INFO - 2022-03-09 02:50:23 --> Helper loaded: common_helper
INFO - 2022-03-09 02:50:23 --> Database Driver Class Initialized
DEBUG - 2022-03-09 02:50:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 02:50:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 02:50:23 --> Controller Class Initialized
INFO - 2022-03-09 02:50:23 --> Form Validation Class Initialized
DEBUG - 2022-03-09 02:50:23 --> Encrypt Class Initialized
INFO - 2022-03-09 02:50:23 --> Model "Patient_model" initialized
INFO - 2022-03-09 02:50:23 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 02:50:23 --> Model "Prefix_master" initialized
INFO - 2022-03-09 02:50:23 --> Model "Users_model" initialized
INFO - 2022-03-09 02:50:23 --> Model "Hospital_model" initialized
INFO - 2022-03-09 02:50:23 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 02:50:23 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-09 02:50:23 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 02:50:23 --> Final output sent to browser
DEBUG - 2022-03-09 02:50:23 --> Total execution time: 0.0612
ERROR - 2022-03-09 02:50:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 02:50:27 --> Config Class Initialized
INFO - 2022-03-09 02:50:27 --> Hooks Class Initialized
DEBUG - 2022-03-09 02:50:27 --> UTF-8 Support Enabled
INFO - 2022-03-09 02:50:27 --> Utf8 Class Initialized
INFO - 2022-03-09 02:50:27 --> URI Class Initialized
INFO - 2022-03-09 02:50:27 --> Router Class Initialized
INFO - 2022-03-09 02:50:27 --> Output Class Initialized
INFO - 2022-03-09 02:50:27 --> Security Class Initialized
DEBUG - 2022-03-09 02:50:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 02:50:27 --> Input Class Initialized
INFO - 2022-03-09 02:50:27 --> Language Class Initialized
INFO - 2022-03-09 02:50:27 --> Loader Class Initialized
INFO - 2022-03-09 02:50:27 --> Helper loaded: url_helper
INFO - 2022-03-09 02:50:27 --> Helper loaded: form_helper
INFO - 2022-03-09 02:50:27 --> Helper loaded: common_helper
INFO - 2022-03-09 02:50:27 --> Database Driver Class Initialized
DEBUG - 2022-03-09 02:50:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 02:50:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 02:50:27 --> Controller Class Initialized
INFO - 2022-03-09 02:50:27 --> Form Validation Class Initialized
DEBUG - 2022-03-09 02:50:27 --> Encrypt Class Initialized
INFO - 2022-03-09 02:50:27 --> Model "Patient_model" initialized
INFO - 2022-03-09 02:50:27 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 02:50:27 --> Model "Referredby_model" initialized
INFO - 2022-03-09 02:50:27 --> Model "Prefix_master" initialized
INFO - 2022-03-09 02:50:28 --> Model "Hospital_model" initialized
INFO - 2022-03-09 02:50:28 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 02:50:28 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-09 02:50:28 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 02:50:28 --> Final output sent to browser
DEBUG - 2022-03-09 02:50:28 --> Total execution time: 0.0455
ERROR - 2022-03-09 02:50:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 02:50:57 --> Config Class Initialized
INFO - 2022-03-09 02:50:57 --> Hooks Class Initialized
DEBUG - 2022-03-09 02:50:57 --> UTF-8 Support Enabled
INFO - 2022-03-09 02:50:57 --> Utf8 Class Initialized
INFO - 2022-03-09 02:50:57 --> URI Class Initialized
INFO - 2022-03-09 02:50:57 --> Router Class Initialized
INFO - 2022-03-09 02:50:57 --> Output Class Initialized
INFO - 2022-03-09 02:50:57 --> Security Class Initialized
DEBUG - 2022-03-09 02:50:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 02:50:57 --> Input Class Initialized
INFO - 2022-03-09 02:50:57 --> Language Class Initialized
INFO - 2022-03-09 02:50:57 --> Loader Class Initialized
INFO - 2022-03-09 02:50:57 --> Helper loaded: url_helper
INFO - 2022-03-09 02:50:57 --> Helper loaded: form_helper
INFO - 2022-03-09 02:50:57 --> Helper loaded: common_helper
INFO - 2022-03-09 02:50:57 --> Database Driver Class Initialized
DEBUG - 2022-03-09 02:50:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 02:50:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 02:50:57 --> Controller Class Initialized
INFO - 2022-03-09 02:50:57 --> Form Validation Class Initialized
DEBUG - 2022-03-09 02:50:57 --> Encrypt Class Initialized
INFO - 2022-03-09 02:50:57 --> Model "Patient_model" initialized
INFO - 2022-03-09 02:50:57 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 02:50:57 --> Model "Referredby_model" initialized
INFO - 2022-03-09 02:50:57 --> Model "Prefix_master" initialized
INFO - 2022-03-09 02:50:57 --> Model "Hospital_model" initialized
ERROR - 2022-03-09 02:50:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 02:50:58 --> Config Class Initialized
INFO - 2022-03-09 02:50:58 --> Hooks Class Initialized
DEBUG - 2022-03-09 02:50:58 --> UTF-8 Support Enabled
INFO - 2022-03-09 02:50:58 --> Utf8 Class Initialized
INFO - 2022-03-09 02:50:58 --> URI Class Initialized
INFO - 2022-03-09 02:50:58 --> Router Class Initialized
INFO - 2022-03-09 02:50:58 --> Output Class Initialized
INFO - 2022-03-09 02:50:58 --> Security Class Initialized
DEBUG - 2022-03-09 02:50:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 02:50:58 --> Input Class Initialized
INFO - 2022-03-09 02:50:58 --> Language Class Initialized
INFO - 2022-03-09 02:50:58 --> Loader Class Initialized
INFO - 2022-03-09 02:50:58 --> Helper loaded: url_helper
INFO - 2022-03-09 02:50:58 --> Helper loaded: form_helper
INFO - 2022-03-09 02:50:58 --> Helper loaded: common_helper
INFO - 2022-03-09 02:50:58 --> Database Driver Class Initialized
DEBUG - 2022-03-09 02:50:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 02:50:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 02:50:58 --> Controller Class Initialized
INFO - 2022-03-09 02:50:58 --> Form Validation Class Initialized
DEBUG - 2022-03-09 02:50:58 --> Encrypt Class Initialized
INFO - 2022-03-09 02:50:58 --> Model "Patient_model" initialized
INFO - 2022-03-09 02:50:58 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 02:50:58 --> Model "Referredby_model" initialized
INFO - 2022-03-09 02:50:58 --> Model "Prefix_master" initialized
INFO - 2022-03-09 02:50:58 --> Model "Hospital_model" initialized
INFO - 2022-03-09 02:50:58 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 02:50:58 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-09 02:50:58 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 02:50:58 --> Final output sent to browser
DEBUG - 2022-03-09 02:50:58 --> Total execution time: 0.0432
ERROR - 2022-03-09 02:50:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 02:50:59 --> Config Class Initialized
INFO - 2022-03-09 02:50:59 --> Hooks Class Initialized
DEBUG - 2022-03-09 02:50:59 --> UTF-8 Support Enabled
INFO - 2022-03-09 02:50:59 --> Utf8 Class Initialized
INFO - 2022-03-09 02:50:59 --> URI Class Initialized
INFO - 2022-03-09 02:50:59 --> Router Class Initialized
INFO - 2022-03-09 02:50:59 --> Output Class Initialized
INFO - 2022-03-09 02:50:59 --> Security Class Initialized
DEBUG - 2022-03-09 02:50:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 02:50:59 --> Input Class Initialized
INFO - 2022-03-09 02:50:59 --> Language Class Initialized
INFO - 2022-03-09 02:50:59 --> Loader Class Initialized
INFO - 2022-03-09 02:50:59 --> Helper loaded: url_helper
INFO - 2022-03-09 02:50:59 --> Helper loaded: form_helper
INFO - 2022-03-09 02:50:59 --> Helper loaded: common_helper
INFO - 2022-03-09 02:50:59 --> Database Driver Class Initialized
DEBUG - 2022-03-09 02:50:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 02:50:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 02:50:59 --> Controller Class Initialized
INFO - 2022-03-09 02:50:59 --> Form Validation Class Initialized
DEBUG - 2022-03-09 02:50:59 --> Encrypt Class Initialized
INFO - 2022-03-09 02:50:59 --> Model "Patient_model" initialized
INFO - 2022-03-09 02:50:59 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 02:50:59 --> Model "Prefix_master" initialized
INFO - 2022-03-09 02:50:59 --> Model "Users_model" initialized
INFO - 2022-03-09 02:50:59 --> Model "Hospital_model" initialized
INFO - 2022-03-09 02:50:59 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 02:50:59 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-09 02:50:59 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 02:50:59 --> Final output sent to browser
DEBUG - 2022-03-09 02:50:59 --> Total execution time: 0.0782
ERROR - 2022-03-09 02:51:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 02:51:03 --> Config Class Initialized
INFO - 2022-03-09 02:51:03 --> Hooks Class Initialized
DEBUG - 2022-03-09 02:51:03 --> UTF-8 Support Enabled
INFO - 2022-03-09 02:51:03 --> Utf8 Class Initialized
INFO - 2022-03-09 02:51:03 --> URI Class Initialized
INFO - 2022-03-09 02:51:03 --> Router Class Initialized
INFO - 2022-03-09 02:51:03 --> Output Class Initialized
INFO - 2022-03-09 02:51:03 --> Security Class Initialized
DEBUG - 2022-03-09 02:51:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 02:51:03 --> Input Class Initialized
INFO - 2022-03-09 02:51:03 --> Language Class Initialized
INFO - 2022-03-09 02:51:03 --> Loader Class Initialized
INFO - 2022-03-09 02:51:03 --> Helper loaded: url_helper
INFO - 2022-03-09 02:51:03 --> Helper loaded: form_helper
INFO - 2022-03-09 02:51:03 --> Helper loaded: common_helper
INFO - 2022-03-09 02:51:03 --> Database Driver Class Initialized
DEBUG - 2022-03-09 02:51:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 02:51:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 02:51:03 --> Controller Class Initialized
INFO - 2022-03-09 02:51:03 --> Form Validation Class Initialized
DEBUG - 2022-03-09 02:51:03 --> Encrypt Class Initialized
INFO - 2022-03-09 02:51:03 --> Model "Patient_model" initialized
INFO - 2022-03-09 02:51:03 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 02:51:03 --> Model "Referredby_model" initialized
INFO - 2022-03-09 02:51:03 --> Model "Prefix_master" initialized
INFO - 2022-03-09 02:51:03 --> Model "Hospital_model" initialized
INFO - 2022-03-09 02:51:03 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 02:51:03 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-09 02:51:03 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 02:51:03 --> Final output sent to browser
DEBUG - 2022-03-09 02:51:03 --> Total execution time: 0.0695
ERROR - 2022-03-09 02:51:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 02:51:12 --> Config Class Initialized
INFO - 2022-03-09 02:51:12 --> Hooks Class Initialized
DEBUG - 2022-03-09 02:51:12 --> UTF-8 Support Enabled
INFO - 2022-03-09 02:51:12 --> Utf8 Class Initialized
INFO - 2022-03-09 02:51:12 --> URI Class Initialized
INFO - 2022-03-09 02:51:12 --> Router Class Initialized
INFO - 2022-03-09 02:51:12 --> Output Class Initialized
INFO - 2022-03-09 02:51:12 --> Security Class Initialized
DEBUG - 2022-03-09 02:51:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 02:51:12 --> Input Class Initialized
INFO - 2022-03-09 02:51:12 --> Language Class Initialized
INFO - 2022-03-09 02:51:12 --> Loader Class Initialized
INFO - 2022-03-09 02:51:12 --> Helper loaded: url_helper
INFO - 2022-03-09 02:51:12 --> Helper loaded: form_helper
INFO - 2022-03-09 02:51:12 --> Helper loaded: common_helper
INFO - 2022-03-09 02:51:12 --> Database Driver Class Initialized
DEBUG - 2022-03-09 02:51:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 02:51:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 02:51:12 --> Controller Class Initialized
INFO - 2022-03-09 02:51:12 --> Form Validation Class Initialized
DEBUG - 2022-03-09 02:51:12 --> Encrypt Class Initialized
INFO - 2022-03-09 02:51:12 --> Model "Patient_model" initialized
INFO - 2022-03-09 02:51:12 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 02:51:12 --> Model "Prefix_master" initialized
INFO - 2022-03-09 02:51:12 --> Model "Users_model" initialized
INFO - 2022-03-09 02:51:12 --> Model "Hospital_model" initialized
INFO - 2022-03-09 02:51:12 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-09 02:51:13 --> Final output sent to browser
DEBUG - 2022-03-09 02:51:13 --> Total execution time: 0.9966
ERROR - 2022-03-09 03:01:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 03:01:28 --> Config Class Initialized
INFO - 2022-03-09 03:01:28 --> Hooks Class Initialized
DEBUG - 2022-03-09 03:01:28 --> UTF-8 Support Enabled
INFO - 2022-03-09 03:01:28 --> Utf8 Class Initialized
INFO - 2022-03-09 03:01:28 --> URI Class Initialized
INFO - 2022-03-09 03:01:28 --> Router Class Initialized
INFO - 2022-03-09 03:01:28 --> Output Class Initialized
INFO - 2022-03-09 03:01:28 --> Security Class Initialized
DEBUG - 2022-03-09 03:01:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 03:01:28 --> Input Class Initialized
INFO - 2022-03-09 03:01:28 --> Language Class Initialized
INFO - 2022-03-09 03:01:28 --> Loader Class Initialized
INFO - 2022-03-09 03:01:28 --> Helper loaded: url_helper
INFO - 2022-03-09 03:01:28 --> Helper loaded: form_helper
INFO - 2022-03-09 03:01:28 --> Helper loaded: common_helper
INFO - 2022-03-09 03:01:28 --> Database Driver Class Initialized
DEBUG - 2022-03-09 03:01:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 03:01:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 03:01:28 --> Controller Class Initialized
INFO - 2022-03-09 03:01:28 --> Form Validation Class Initialized
DEBUG - 2022-03-09 03:01:28 --> Encrypt Class Initialized
INFO - 2022-03-09 03:01:28 --> Model "Patient_model" initialized
INFO - 2022-03-09 03:01:28 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 03:01:28 --> Model "Referredby_model" initialized
INFO - 2022-03-09 03:01:28 --> Model "Prefix_master" initialized
INFO - 2022-03-09 03:01:28 --> Model "Hospital_model" initialized
INFO - 2022-03-09 03:01:28 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 03:01:28 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-09 03:01:28 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 03:01:28 --> Final output sent to browser
DEBUG - 2022-03-09 03:01:28 --> Total execution time: 0.1193
ERROR - 2022-03-09 03:03:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 03:03:42 --> Config Class Initialized
INFO - 2022-03-09 03:03:42 --> Hooks Class Initialized
DEBUG - 2022-03-09 03:03:42 --> UTF-8 Support Enabled
INFO - 2022-03-09 03:03:42 --> Utf8 Class Initialized
INFO - 2022-03-09 03:03:42 --> URI Class Initialized
INFO - 2022-03-09 03:03:42 --> Router Class Initialized
INFO - 2022-03-09 03:03:42 --> Output Class Initialized
INFO - 2022-03-09 03:03:42 --> Security Class Initialized
DEBUG - 2022-03-09 03:03:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 03:03:42 --> Input Class Initialized
INFO - 2022-03-09 03:03:42 --> Language Class Initialized
INFO - 2022-03-09 03:03:42 --> Loader Class Initialized
INFO - 2022-03-09 03:03:42 --> Helper loaded: url_helper
INFO - 2022-03-09 03:03:42 --> Helper loaded: form_helper
INFO - 2022-03-09 03:03:42 --> Helper loaded: common_helper
INFO - 2022-03-09 03:03:42 --> Database Driver Class Initialized
DEBUG - 2022-03-09 03:03:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 03:03:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 03:03:42 --> Controller Class Initialized
INFO - 2022-03-09 03:03:42 --> Form Validation Class Initialized
DEBUG - 2022-03-09 03:03:42 --> Encrypt Class Initialized
INFO - 2022-03-09 03:03:42 --> Model "Patient_model" initialized
INFO - 2022-03-09 03:03:42 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 03:03:42 --> Model "Prefix_master" initialized
INFO - 2022-03-09 03:03:42 --> Model "Users_model" initialized
INFO - 2022-03-09 03:03:42 --> Model "Hospital_model" initialized
INFO - 2022-03-09 03:03:42 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 03:03:42 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-09 03:03:42 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 03:03:42 --> Final output sent to browser
DEBUG - 2022-03-09 03:03:42 --> Total execution time: 0.7872
ERROR - 2022-03-09 03:03:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 03:03:43 --> Config Class Initialized
INFO - 2022-03-09 03:03:43 --> Hooks Class Initialized
DEBUG - 2022-03-09 03:03:43 --> UTF-8 Support Enabled
INFO - 2022-03-09 03:03:43 --> Utf8 Class Initialized
INFO - 2022-03-09 03:03:43 --> URI Class Initialized
INFO - 2022-03-09 03:03:43 --> Router Class Initialized
INFO - 2022-03-09 03:03:43 --> Output Class Initialized
INFO - 2022-03-09 03:03:43 --> Security Class Initialized
DEBUG - 2022-03-09 03:03:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 03:03:43 --> Input Class Initialized
INFO - 2022-03-09 03:03:43 --> Language Class Initialized
ERROR - 2022-03-09 03:03:43 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-09 03:08:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 03:08:51 --> Config Class Initialized
INFO - 2022-03-09 03:08:51 --> Hooks Class Initialized
DEBUG - 2022-03-09 03:08:51 --> UTF-8 Support Enabled
INFO - 2022-03-09 03:08:51 --> Utf8 Class Initialized
INFO - 2022-03-09 03:08:51 --> URI Class Initialized
INFO - 2022-03-09 03:08:51 --> Router Class Initialized
INFO - 2022-03-09 03:08:51 --> Output Class Initialized
INFO - 2022-03-09 03:08:51 --> Security Class Initialized
DEBUG - 2022-03-09 03:08:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 03:08:51 --> Input Class Initialized
INFO - 2022-03-09 03:08:51 --> Language Class Initialized
INFO - 2022-03-09 03:08:51 --> Loader Class Initialized
INFO - 2022-03-09 03:08:51 --> Helper loaded: url_helper
INFO - 2022-03-09 03:08:51 --> Helper loaded: form_helper
INFO - 2022-03-09 03:08:51 --> Helper loaded: common_helper
INFO - 2022-03-09 03:08:51 --> Database Driver Class Initialized
DEBUG - 2022-03-09 03:08:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 03:08:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 03:08:51 --> Controller Class Initialized
INFO - 2022-03-09 03:08:51 --> Form Validation Class Initialized
DEBUG - 2022-03-09 03:08:51 --> Encrypt Class Initialized
INFO - 2022-03-09 03:08:51 --> Model "Patient_model" initialized
INFO - 2022-03-09 03:08:51 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 03:08:51 --> Model "Referredby_model" initialized
INFO - 2022-03-09 03:08:51 --> Model "Prefix_master" initialized
INFO - 2022-03-09 03:08:51 --> Model "Hospital_model" initialized
INFO - 2022-03-09 03:08:51 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 03:08:51 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-09 03:08:51 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 03:08:51 --> Final output sent to browser
DEBUG - 2022-03-09 03:08:51 --> Total execution time: 0.0450
ERROR - 2022-03-09 03:08:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 03:08:52 --> Config Class Initialized
INFO - 2022-03-09 03:08:52 --> Hooks Class Initialized
DEBUG - 2022-03-09 03:08:52 --> UTF-8 Support Enabled
INFO - 2022-03-09 03:08:52 --> Utf8 Class Initialized
INFO - 2022-03-09 03:08:52 --> URI Class Initialized
INFO - 2022-03-09 03:08:52 --> Router Class Initialized
INFO - 2022-03-09 03:08:52 --> Output Class Initialized
INFO - 2022-03-09 03:08:52 --> Security Class Initialized
DEBUG - 2022-03-09 03:08:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 03:08:52 --> Input Class Initialized
INFO - 2022-03-09 03:08:52 --> Language Class Initialized
ERROR - 2022-03-09 03:08:52 --> 404 Page Not Found: Karoclient/images
ERROR - 2022-03-09 03:14:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 03:14:48 --> Config Class Initialized
INFO - 2022-03-09 03:14:48 --> Hooks Class Initialized
DEBUG - 2022-03-09 03:14:48 --> UTF-8 Support Enabled
INFO - 2022-03-09 03:14:48 --> Utf8 Class Initialized
INFO - 2022-03-09 03:14:48 --> URI Class Initialized
DEBUG - 2022-03-09 03:14:48 --> No URI present. Default controller set.
INFO - 2022-03-09 03:14:48 --> Router Class Initialized
INFO - 2022-03-09 03:14:48 --> Output Class Initialized
INFO - 2022-03-09 03:14:48 --> Security Class Initialized
DEBUG - 2022-03-09 03:14:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 03:14:48 --> Input Class Initialized
INFO - 2022-03-09 03:14:48 --> Language Class Initialized
INFO - 2022-03-09 03:14:48 --> Loader Class Initialized
INFO - 2022-03-09 03:14:48 --> Helper loaded: url_helper
INFO - 2022-03-09 03:14:48 --> Helper loaded: form_helper
INFO - 2022-03-09 03:14:48 --> Helper loaded: common_helper
INFO - 2022-03-09 03:14:48 --> Database Driver Class Initialized
DEBUG - 2022-03-09 03:14:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 03:14:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 03:14:48 --> Controller Class Initialized
INFO - 2022-03-09 03:14:48 --> Form Validation Class Initialized
DEBUG - 2022-03-09 03:14:48 --> Encrypt Class Initialized
DEBUG - 2022-03-09 03:14:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-09 03:14:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-09 03:14:48 --> Email Class Initialized
INFO - 2022-03-09 03:14:48 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-09 03:14:48 --> Calendar Class Initialized
INFO - 2022-03-09 03:14:48 --> Model "Login_model" initialized
ERROR - 2022-03-09 03:14:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 03:14:48 --> Config Class Initialized
INFO - 2022-03-09 03:14:48 --> Hooks Class Initialized
DEBUG - 2022-03-09 03:14:48 --> UTF-8 Support Enabled
INFO - 2022-03-09 03:14:48 --> Utf8 Class Initialized
INFO - 2022-03-09 03:14:48 --> URI Class Initialized
INFO - 2022-03-09 03:14:48 --> Router Class Initialized
INFO - 2022-03-09 03:14:48 --> Output Class Initialized
INFO - 2022-03-09 03:14:48 --> Security Class Initialized
DEBUG - 2022-03-09 03:14:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 03:14:48 --> Input Class Initialized
INFO - 2022-03-09 03:14:48 --> Language Class Initialized
INFO - 2022-03-09 03:14:48 --> Loader Class Initialized
INFO - 2022-03-09 03:14:48 --> Helper loaded: url_helper
INFO - 2022-03-09 03:14:48 --> Helper loaded: form_helper
INFO - 2022-03-09 03:14:48 --> Helper loaded: common_helper
INFO - 2022-03-09 03:14:49 --> Database Driver Class Initialized
DEBUG - 2022-03-09 03:14:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 03:14:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 03:14:49 --> Controller Class Initialized
INFO - 2022-03-09 03:14:49 --> Form Validation Class Initialized
DEBUG - 2022-03-09 03:14:49 --> Encrypt Class Initialized
INFO - 2022-03-09 03:14:49 --> Model "Diseases_model" initialized
INFO - 2022-03-09 03:14:49 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 03:14:49 --> File loaded: /home3/karoteam/public_html/application/views/diseases/index.php
INFO - 2022-03-09 03:14:49 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 03:14:49 --> Final output sent to browser
DEBUG - 2022-03-09 03:14:49 --> Total execution time: 0.0254
ERROR - 2022-03-09 03:14:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 03:14:49 --> Config Class Initialized
INFO - 2022-03-09 03:14:49 --> Hooks Class Initialized
DEBUG - 2022-03-09 03:14:49 --> UTF-8 Support Enabled
INFO - 2022-03-09 03:14:49 --> Utf8 Class Initialized
INFO - 2022-03-09 03:14:49 --> URI Class Initialized
DEBUG - 2022-03-09 03:14:49 --> No URI present. Default controller set.
INFO - 2022-03-09 03:14:49 --> Router Class Initialized
INFO - 2022-03-09 03:14:49 --> Output Class Initialized
INFO - 2022-03-09 03:14:49 --> Security Class Initialized
DEBUG - 2022-03-09 03:14:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 03:14:49 --> Input Class Initialized
INFO - 2022-03-09 03:14:49 --> Language Class Initialized
INFO - 2022-03-09 03:14:49 --> Loader Class Initialized
INFO - 2022-03-09 03:14:49 --> Helper loaded: url_helper
INFO - 2022-03-09 03:14:49 --> Helper loaded: form_helper
INFO - 2022-03-09 03:14:49 --> Helper loaded: common_helper
INFO - 2022-03-09 03:14:49 --> Database Driver Class Initialized
DEBUG - 2022-03-09 03:14:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 03:14:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 03:14:49 --> Controller Class Initialized
INFO - 2022-03-09 03:14:49 --> Form Validation Class Initialized
DEBUG - 2022-03-09 03:14:49 --> Encrypt Class Initialized
DEBUG - 2022-03-09 03:14:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-09 03:14:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-09 03:14:49 --> Email Class Initialized
INFO - 2022-03-09 03:14:49 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-09 03:14:49 --> Calendar Class Initialized
INFO - 2022-03-09 03:14:49 --> Model "Login_model" initialized
ERROR - 2022-03-09 03:14:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 03:14:50 --> Config Class Initialized
INFO - 2022-03-09 03:14:50 --> Hooks Class Initialized
DEBUG - 2022-03-09 03:14:50 --> UTF-8 Support Enabled
INFO - 2022-03-09 03:14:50 --> Utf8 Class Initialized
INFO - 2022-03-09 03:14:50 --> URI Class Initialized
INFO - 2022-03-09 03:14:50 --> Router Class Initialized
INFO - 2022-03-09 03:14:50 --> Output Class Initialized
INFO - 2022-03-09 03:14:50 --> Security Class Initialized
DEBUG - 2022-03-09 03:14:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 03:14:50 --> Input Class Initialized
INFO - 2022-03-09 03:14:50 --> Language Class Initialized
INFO - 2022-03-09 03:14:50 --> Loader Class Initialized
INFO - 2022-03-09 03:14:50 --> Helper loaded: url_helper
INFO - 2022-03-09 03:14:50 --> Helper loaded: form_helper
INFO - 2022-03-09 03:14:50 --> Helper loaded: common_helper
INFO - 2022-03-09 03:14:50 --> Database Driver Class Initialized
DEBUG - 2022-03-09 03:14:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 03:14:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 03:14:50 --> Controller Class Initialized
INFO - 2022-03-09 03:14:50 --> Form Validation Class Initialized
DEBUG - 2022-03-09 03:14:50 --> Encrypt Class Initialized
INFO - 2022-03-09 03:14:50 --> Model "Diseases_model" initialized
INFO - 2022-03-09 03:14:50 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 03:14:50 --> File loaded: /home3/karoteam/public_html/application/views/diseases/index.php
INFO - 2022-03-09 03:14:50 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 03:14:50 --> Final output sent to browser
DEBUG - 2022-03-09 03:14:50 --> Total execution time: 0.0290
ERROR - 2022-03-09 03:15:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 03:15:27 --> Config Class Initialized
INFO - 2022-03-09 03:15:27 --> Hooks Class Initialized
DEBUG - 2022-03-09 03:15:27 --> UTF-8 Support Enabled
INFO - 2022-03-09 03:15:27 --> Utf8 Class Initialized
INFO - 2022-03-09 03:15:27 --> URI Class Initialized
INFO - 2022-03-09 03:15:27 --> Router Class Initialized
INFO - 2022-03-09 03:15:27 --> Output Class Initialized
INFO - 2022-03-09 03:15:27 --> Security Class Initialized
DEBUG - 2022-03-09 03:15:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 03:15:27 --> Input Class Initialized
INFO - 2022-03-09 03:15:27 --> Language Class Initialized
INFO - 2022-03-09 03:15:27 --> Loader Class Initialized
INFO - 2022-03-09 03:15:27 --> Helper loaded: url_helper
INFO - 2022-03-09 03:15:27 --> Helper loaded: form_helper
INFO - 2022-03-09 03:15:27 --> Helper loaded: common_helper
INFO - 2022-03-09 03:15:27 --> Database Driver Class Initialized
DEBUG - 2022-03-09 03:15:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 03:15:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 03:15:27 --> Controller Class Initialized
INFO - 2022-03-09 03:15:27 --> Form Validation Class Initialized
DEBUG - 2022-03-09 03:15:27 --> Encrypt Class Initialized
INFO - 2022-03-09 03:15:27 --> Model "Patient_model" initialized
INFO - 2022-03-09 03:15:27 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 03:15:27 --> Model "Referredby_model" initialized
INFO - 2022-03-09 03:15:27 --> Model "Prefix_master" initialized
INFO - 2022-03-09 03:15:27 --> Model "Hospital_model" initialized
INFO - 2022-03-09 03:15:27 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 03:15:27 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-09 03:15:27 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 03:15:27 --> Final output sent to browser
DEBUG - 2022-03-09 03:15:27 --> Total execution time: 0.0498
ERROR - 2022-03-09 03:27:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 03:27:15 --> Config Class Initialized
INFO - 2022-03-09 03:27:15 --> Hooks Class Initialized
DEBUG - 2022-03-09 03:27:15 --> UTF-8 Support Enabled
INFO - 2022-03-09 03:27:15 --> Utf8 Class Initialized
INFO - 2022-03-09 03:27:15 --> URI Class Initialized
INFO - 2022-03-09 03:27:15 --> Router Class Initialized
INFO - 2022-03-09 03:27:15 --> Output Class Initialized
INFO - 2022-03-09 03:27:15 --> Security Class Initialized
DEBUG - 2022-03-09 03:27:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 03:27:15 --> Input Class Initialized
INFO - 2022-03-09 03:27:15 --> Language Class Initialized
INFO - 2022-03-09 03:27:15 --> Loader Class Initialized
INFO - 2022-03-09 03:27:15 --> Helper loaded: url_helper
INFO - 2022-03-09 03:27:15 --> Helper loaded: form_helper
INFO - 2022-03-09 03:27:15 --> Helper loaded: common_helper
INFO - 2022-03-09 03:27:15 --> Database Driver Class Initialized
DEBUG - 2022-03-09 03:27:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 03:27:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 03:27:15 --> Controller Class Initialized
INFO - 2022-03-09 03:27:15 --> Form Validation Class Initialized
DEBUG - 2022-03-09 03:27:15 --> Encrypt Class Initialized
INFO - 2022-03-09 03:27:15 --> Model "Patient_model" initialized
INFO - 2022-03-09 03:27:15 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 03:27:15 --> Model "Referredby_model" initialized
INFO - 2022-03-09 03:27:15 --> Model "Prefix_master" initialized
INFO - 2022-03-09 03:27:15 --> Model "Hospital_model" initialized
INFO - 2022-03-09 03:27:15 --> Final output sent to browser
DEBUG - 2022-03-09 03:27:15 --> Total execution time: 0.0435
ERROR - 2022-03-09 03:29:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 03:29:55 --> Config Class Initialized
INFO - 2022-03-09 03:29:55 --> Hooks Class Initialized
DEBUG - 2022-03-09 03:29:55 --> UTF-8 Support Enabled
INFO - 2022-03-09 03:29:55 --> Utf8 Class Initialized
INFO - 2022-03-09 03:29:55 --> URI Class Initialized
INFO - 2022-03-09 03:29:55 --> Router Class Initialized
INFO - 2022-03-09 03:29:55 --> Output Class Initialized
INFO - 2022-03-09 03:29:55 --> Security Class Initialized
DEBUG - 2022-03-09 03:29:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 03:29:55 --> Input Class Initialized
INFO - 2022-03-09 03:29:55 --> Language Class Initialized
INFO - 2022-03-09 03:29:55 --> Loader Class Initialized
INFO - 2022-03-09 03:29:55 --> Helper loaded: url_helper
INFO - 2022-03-09 03:29:55 --> Helper loaded: form_helper
INFO - 2022-03-09 03:29:55 --> Helper loaded: common_helper
INFO - 2022-03-09 03:29:55 --> Database Driver Class Initialized
DEBUG - 2022-03-09 03:29:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 03:29:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 03:29:55 --> Controller Class Initialized
INFO - 2022-03-09 03:29:55 --> Model "Referredby_model" initialized
INFO - 2022-03-09 03:29:55 --> Final output sent to browser
DEBUG - 2022-03-09 03:29:55 --> Total execution time: 0.0236
ERROR - 2022-03-09 03:30:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 03:30:33 --> Config Class Initialized
INFO - 2022-03-09 03:30:33 --> Hooks Class Initialized
DEBUG - 2022-03-09 03:30:33 --> UTF-8 Support Enabled
INFO - 2022-03-09 03:30:33 --> Utf8 Class Initialized
INFO - 2022-03-09 03:30:33 --> URI Class Initialized
INFO - 2022-03-09 03:30:33 --> Router Class Initialized
INFO - 2022-03-09 03:30:33 --> Output Class Initialized
INFO - 2022-03-09 03:30:33 --> Security Class Initialized
DEBUG - 2022-03-09 03:30:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 03:30:33 --> Input Class Initialized
INFO - 2022-03-09 03:30:33 --> Language Class Initialized
INFO - 2022-03-09 03:30:33 --> Loader Class Initialized
INFO - 2022-03-09 03:30:33 --> Helper loaded: url_helper
INFO - 2022-03-09 03:30:33 --> Helper loaded: form_helper
INFO - 2022-03-09 03:30:33 --> Helper loaded: common_helper
INFO - 2022-03-09 03:30:33 --> Database Driver Class Initialized
DEBUG - 2022-03-09 03:30:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 03:30:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 03:30:33 --> Controller Class Initialized
INFO - 2022-03-09 03:30:33 --> Model "Referredby_model" initialized
INFO - 2022-03-09 03:30:33 --> Final output sent to browser
DEBUG - 2022-03-09 03:30:33 --> Total execution time: 0.0212
ERROR - 2022-03-09 03:31:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 03:31:08 --> Config Class Initialized
INFO - 2022-03-09 03:31:08 --> Hooks Class Initialized
DEBUG - 2022-03-09 03:31:08 --> UTF-8 Support Enabled
INFO - 2022-03-09 03:31:08 --> Utf8 Class Initialized
INFO - 2022-03-09 03:31:08 --> URI Class Initialized
INFO - 2022-03-09 03:31:08 --> Router Class Initialized
INFO - 2022-03-09 03:31:08 --> Output Class Initialized
INFO - 2022-03-09 03:31:08 --> Security Class Initialized
DEBUG - 2022-03-09 03:31:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 03:31:08 --> Input Class Initialized
INFO - 2022-03-09 03:31:08 --> Language Class Initialized
INFO - 2022-03-09 03:31:08 --> Loader Class Initialized
INFO - 2022-03-09 03:31:08 --> Helper loaded: url_helper
INFO - 2022-03-09 03:31:08 --> Helper loaded: form_helper
INFO - 2022-03-09 03:31:08 --> Helper loaded: common_helper
INFO - 2022-03-09 03:31:08 --> Database Driver Class Initialized
DEBUG - 2022-03-09 03:31:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 03:31:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 03:31:08 --> Controller Class Initialized
INFO - 2022-03-09 03:31:08 --> Form Validation Class Initialized
DEBUG - 2022-03-09 03:31:08 --> Encrypt Class Initialized
INFO - 2022-03-09 03:31:08 --> Model "Patient_model" initialized
INFO - 2022-03-09 03:31:08 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 03:31:08 --> Model "Referredby_model" initialized
INFO - 2022-03-09 03:31:08 --> Model "Prefix_master" initialized
INFO - 2022-03-09 03:31:08 --> Model "Hospital_model" initialized
INFO - 2022-03-09 03:31:08 --> Final output sent to browser
DEBUG - 2022-03-09 03:31:08 --> Total execution time: 0.0297
ERROR - 2022-03-09 03:31:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 03:31:42 --> Config Class Initialized
INFO - 2022-03-09 03:31:42 --> Hooks Class Initialized
DEBUG - 2022-03-09 03:31:42 --> UTF-8 Support Enabled
INFO - 2022-03-09 03:31:42 --> Utf8 Class Initialized
INFO - 2022-03-09 03:31:42 --> URI Class Initialized
INFO - 2022-03-09 03:31:42 --> Router Class Initialized
INFO - 2022-03-09 03:31:42 --> Output Class Initialized
INFO - 2022-03-09 03:31:42 --> Security Class Initialized
DEBUG - 2022-03-09 03:31:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 03:31:42 --> Input Class Initialized
INFO - 2022-03-09 03:31:42 --> Language Class Initialized
INFO - 2022-03-09 03:31:42 --> Loader Class Initialized
INFO - 2022-03-09 03:31:42 --> Helper loaded: url_helper
INFO - 2022-03-09 03:31:42 --> Helper loaded: form_helper
INFO - 2022-03-09 03:31:42 --> Helper loaded: common_helper
INFO - 2022-03-09 03:31:42 --> Database Driver Class Initialized
DEBUG - 2022-03-09 03:31:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 03:31:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 03:31:42 --> Controller Class Initialized
INFO - 2022-03-09 03:31:42 --> Form Validation Class Initialized
DEBUG - 2022-03-09 03:31:42 --> Encrypt Class Initialized
INFO - 2022-03-09 03:31:42 --> Model "Patient_model" initialized
INFO - 2022-03-09 03:31:42 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 03:31:42 --> Model "Referredby_model" initialized
INFO - 2022-03-09 03:31:42 --> Model "Prefix_master" initialized
INFO - 2022-03-09 03:31:42 --> Model "Hospital_model" initialized
INFO - 2022-03-09 03:31:42 --> File loaded: /home3/karoteam/public_html/application/views/header.php
ERROR - 2022-03-09 03:31:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 03:31:48 --> Config Class Initialized
INFO - 2022-03-09 03:31:48 --> Hooks Class Initialized
DEBUG - 2022-03-09 03:31:48 --> UTF-8 Support Enabled
INFO - 2022-03-09 03:31:48 --> Utf8 Class Initialized
INFO - 2022-03-09 03:31:48 --> URI Class Initialized
INFO - 2022-03-09 03:31:48 --> Router Class Initialized
INFO - 2022-03-09 03:31:48 --> Output Class Initialized
INFO - 2022-03-09 03:31:48 --> Security Class Initialized
DEBUG - 2022-03-09 03:31:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 03:31:48 --> Input Class Initialized
INFO - 2022-03-09 03:31:48 --> Language Class Initialized
INFO - 2022-03-09 03:31:48 --> Loader Class Initialized
INFO - 2022-03-09 03:31:48 --> Helper loaded: url_helper
INFO - 2022-03-09 03:31:48 --> Helper loaded: form_helper
INFO - 2022-03-09 03:31:48 --> Helper loaded: common_helper
INFO - 2022-03-09 03:31:48 --> Database Driver Class Initialized
DEBUG - 2022-03-09 03:31:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 03:31:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 03:31:48 --> Controller Class Initialized
INFO - 2022-03-09 03:31:48 --> Form Validation Class Initialized
DEBUG - 2022-03-09 03:31:48 --> Encrypt Class Initialized
INFO - 2022-03-09 03:31:48 --> Model "Patient_model" initialized
INFO - 2022-03-09 03:31:48 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 03:31:48 --> Model "Referredby_model" initialized
INFO - 2022-03-09 03:31:48 --> Model "Prefix_master" initialized
INFO - 2022-03-09 03:31:48 --> Model "Hospital_model" initialized
INFO - 2022-03-09 03:31:48 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 03:31:48 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-09 03:31:48 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
ERROR - 2022-03-09 03:31:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 03:31:49 --> Config Class Initialized
INFO - 2022-03-09 03:31:49 --> Hooks Class Initialized
DEBUG - 2022-03-09 03:31:49 --> UTF-8 Support Enabled
INFO - 2022-03-09 03:31:49 --> Utf8 Class Initialized
INFO - 2022-03-09 03:31:49 --> URI Class Initialized
INFO - 2022-03-09 03:31:49 --> Router Class Initialized
INFO - 2022-03-09 03:31:49 --> Output Class Initialized
INFO - 2022-03-09 03:31:49 --> Security Class Initialized
DEBUG - 2022-03-09 03:31:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 03:31:49 --> Input Class Initialized
INFO - 2022-03-09 03:31:49 --> Language Class Initialized
INFO - 2022-03-09 03:31:49 --> Loader Class Initialized
INFO - 2022-03-09 03:31:49 --> Helper loaded: url_helper
INFO - 2022-03-09 03:31:49 --> Helper loaded: form_helper
INFO - 2022-03-09 03:31:49 --> Helper loaded: common_helper
INFO - 2022-03-09 03:31:49 --> Database Driver Class Initialized
DEBUG - 2022-03-09 03:31:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 03:31:54 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-09 03:31:54 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 03:31:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 03:31:54 --> Controller Class Initialized
INFO - 2022-03-09 03:31:54 --> Form Validation Class Initialized
DEBUG - 2022-03-09 03:31:54 --> Encrypt Class Initialized
INFO - 2022-03-09 03:31:54 --> Model "Patient_model" initialized
INFO - 2022-03-09 03:31:54 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 03:31:54 --> Model "Referredby_model" initialized
INFO - 2022-03-09 03:31:54 --> Model "Prefix_master" initialized
INFO - 2022-03-09 03:31:54 --> Model "Hospital_model" initialized
INFO - 2022-03-09 03:31:54 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 03:32:00 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-09 03:32:00 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 03:32:01 --> Final output sent to browser
DEBUG - 2022-03-09 03:32:01 --> Total execution time: 10.8390
ERROR - 2022-03-09 03:32:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 03:32:25 --> Config Class Initialized
INFO - 2022-03-09 03:32:25 --> Hooks Class Initialized
DEBUG - 2022-03-09 03:32:25 --> UTF-8 Support Enabled
INFO - 2022-03-09 03:32:25 --> Utf8 Class Initialized
INFO - 2022-03-09 03:32:25 --> URI Class Initialized
INFO - 2022-03-09 03:32:25 --> Router Class Initialized
INFO - 2022-03-09 03:32:25 --> Output Class Initialized
INFO - 2022-03-09 03:32:25 --> Security Class Initialized
DEBUG - 2022-03-09 03:32:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 03:32:25 --> Input Class Initialized
INFO - 2022-03-09 03:32:25 --> Language Class Initialized
INFO - 2022-03-09 03:32:25 --> Loader Class Initialized
INFO - 2022-03-09 03:32:25 --> Helper loaded: url_helper
INFO - 2022-03-09 03:32:25 --> Helper loaded: form_helper
INFO - 2022-03-09 03:32:25 --> Helper loaded: common_helper
INFO - 2022-03-09 03:32:25 --> Database Driver Class Initialized
DEBUG - 2022-03-09 03:32:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 03:32:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 03:32:25 --> Controller Class Initialized
INFO - 2022-03-09 03:32:25 --> Form Validation Class Initialized
DEBUG - 2022-03-09 03:32:25 --> Encrypt Class Initialized
INFO - 2022-03-09 03:32:25 --> Model "Patient_model" initialized
INFO - 2022-03-09 03:32:25 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 03:32:25 --> Model "Prefix_master" initialized
INFO - 2022-03-09 03:32:25 --> Model "Users_model" initialized
INFO - 2022-03-09 03:32:25 --> Model "Hospital_model" initialized
INFO - 2022-03-09 03:32:25 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 03:32:25 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-09 03:32:25 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 03:32:25 --> Final output sent to browser
DEBUG - 2022-03-09 03:32:25 --> Total execution time: 0.0994
ERROR - 2022-03-09 03:32:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 03:32:54 --> Config Class Initialized
INFO - 2022-03-09 03:32:54 --> Hooks Class Initialized
DEBUG - 2022-03-09 03:32:54 --> UTF-8 Support Enabled
INFO - 2022-03-09 03:32:54 --> Utf8 Class Initialized
INFO - 2022-03-09 03:32:54 --> URI Class Initialized
INFO - 2022-03-09 03:32:54 --> Router Class Initialized
INFO - 2022-03-09 03:32:54 --> Output Class Initialized
INFO - 2022-03-09 03:32:54 --> Security Class Initialized
DEBUG - 2022-03-09 03:32:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 03:32:54 --> Input Class Initialized
INFO - 2022-03-09 03:32:54 --> Language Class Initialized
INFO - 2022-03-09 03:32:54 --> Loader Class Initialized
INFO - 2022-03-09 03:32:54 --> Helper loaded: url_helper
INFO - 2022-03-09 03:32:54 --> Helper loaded: form_helper
INFO - 2022-03-09 03:32:54 --> Helper loaded: common_helper
INFO - 2022-03-09 03:32:54 --> Database Driver Class Initialized
DEBUG - 2022-03-09 03:32:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 03:32:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 03:32:54 --> Controller Class Initialized
INFO - 2022-03-09 03:32:54 --> Form Validation Class Initialized
DEBUG - 2022-03-09 03:32:54 --> Encrypt Class Initialized
INFO - 2022-03-09 03:32:54 --> Model "Patient_model" initialized
INFO - 2022-03-09 03:32:54 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 03:32:54 --> Model "Referredby_model" initialized
INFO - 2022-03-09 03:32:54 --> Model "Prefix_master" initialized
INFO - 2022-03-09 03:32:54 --> Model "Hospital_model" initialized
INFO - 2022-03-09 03:32:54 --> Final output sent to browser
DEBUG - 2022-03-09 03:32:54 --> Total execution time: 0.0248
ERROR - 2022-03-09 03:32:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 03:32:57 --> Config Class Initialized
INFO - 2022-03-09 03:32:57 --> Hooks Class Initialized
DEBUG - 2022-03-09 03:32:57 --> UTF-8 Support Enabled
INFO - 2022-03-09 03:32:57 --> Utf8 Class Initialized
INFO - 2022-03-09 03:32:57 --> URI Class Initialized
INFO - 2022-03-09 03:32:57 --> Router Class Initialized
INFO - 2022-03-09 03:32:57 --> Output Class Initialized
INFO - 2022-03-09 03:32:57 --> Security Class Initialized
DEBUG - 2022-03-09 03:32:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 03:32:57 --> Input Class Initialized
INFO - 2022-03-09 03:32:57 --> Language Class Initialized
INFO - 2022-03-09 03:32:57 --> Loader Class Initialized
INFO - 2022-03-09 03:32:57 --> Helper loaded: url_helper
INFO - 2022-03-09 03:32:57 --> Helper loaded: form_helper
INFO - 2022-03-09 03:32:57 --> Helper loaded: common_helper
INFO - 2022-03-09 03:32:57 --> Database Driver Class Initialized
DEBUG - 2022-03-09 03:32:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 03:32:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 03:32:57 --> Controller Class Initialized
INFO - 2022-03-09 03:32:57 --> Form Validation Class Initialized
DEBUG - 2022-03-09 03:32:57 --> Encrypt Class Initialized
INFO - 2022-03-09 03:32:57 --> Model "Patient_model" initialized
INFO - 2022-03-09 03:32:57 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 03:32:57 --> Model "Referredby_model" initialized
INFO - 2022-03-09 03:32:57 --> Model "Prefix_master" initialized
INFO - 2022-03-09 03:32:57 --> Model "Hospital_model" initialized
INFO - 2022-03-09 03:32:57 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 03:33:03 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-09 03:33:03 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 03:33:05 --> Final output sent to browser
DEBUG - 2022-03-09 03:33:05 --> Total execution time: 6.6675
ERROR - 2022-03-09 03:33:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 03:33:29 --> Config Class Initialized
INFO - 2022-03-09 03:33:29 --> Hooks Class Initialized
DEBUG - 2022-03-09 03:33:29 --> UTF-8 Support Enabled
INFO - 2022-03-09 03:33:29 --> Utf8 Class Initialized
INFO - 2022-03-09 03:33:29 --> URI Class Initialized
INFO - 2022-03-09 03:33:29 --> Router Class Initialized
INFO - 2022-03-09 03:33:29 --> Output Class Initialized
INFO - 2022-03-09 03:33:29 --> Security Class Initialized
DEBUG - 2022-03-09 03:33:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 03:33:29 --> Input Class Initialized
INFO - 2022-03-09 03:33:29 --> Language Class Initialized
INFO - 2022-03-09 03:33:29 --> Loader Class Initialized
INFO - 2022-03-09 03:33:29 --> Helper loaded: url_helper
INFO - 2022-03-09 03:33:29 --> Helper loaded: form_helper
INFO - 2022-03-09 03:33:29 --> Helper loaded: common_helper
INFO - 2022-03-09 03:33:29 --> Database Driver Class Initialized
DEBUG - 2022-03-09 03:33:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 03:33:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 03:33:29 --> Controller Class Initialized
INFO - 2022-03-09 03:33:29 --> Form Validation Class Initialized
DEBUG - 2022-03-09 03:33:29 --> Encrypt Class Initialized
INFO - 2022-03-09 03:33:29 --> Model "Patient_model" initialized
INFO - 2022-03-09 03:33:29 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 03:33:29 --> Model "Prefix_master" initialized
INFO - 2022-03-09 03:33:29 --> Model "Users_model" initialized
INFO - 2022-03-09 03:33:29 --> Model "Hospital_model" initialized
INFO - 2022-03-09 03:33:29 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 03:33:29 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-09 03:33:29 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 03:33:29 --> Final output sent to browser
DEBUG - 2022-03-09 03:33:29 --> Total execution time: 0.0613
ERROR - 2022-03-09 03:33:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 03:33:45 --> Config Class Initialized
INFO - 2022-03-09 03:33:45 --> Hooks Class Initialized
DEBUG - 2022-03-09 03:33:45 --> UTF-8 Support Enabled
INFO - 2022-03-09 03:33:45 --> Utf8 Class Initialized
INFO - 2022-03-09 03:33:45 --> URI Class Initialized
INFO - 2022-03-09 03:33:45 --> Router Class Initialized
INFO - 2022-03-09 03:33:45 --> Output Class Initialized
INFO - 2022-03-09 03:33:45 --> Security Class Initialized
DEBUG - 2022-03-09 03:33:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 03:33:45 --> Input Class Initialized
INFO - 2022-03-09 03:33:45 --> Language Class Initialized
INFO - 2022-03-09 03:33:45 --> Loader Class Initialized
INFO - 2022-03-09 03:33:45 --> Helper loaded: url_helper
INFO - 2022-03-09 03:33:45 --> Helper loaded: form_helper
INFO - 2022-03-09 03:33:45 --> Helper loaded: common_helper
INFO - 2022-03-09 03:33:45 --> Database Driver Class Initialized
DEBUG - 2022-03-09 03:33:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 03:33:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 03:33:45 --> Controller Class Initialized
INFO - 2022-03-09 03:33:45 --> Form Validation Class Initialized
DEBUG - 2022-03-09 03:33:45 --> Encrypt Class Initialized
INFO - 2022-03-09 03:33:45 --> Model "Patient_model" initialized
INFO - 2022-03-09 03:33:45 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 03:33:45 --> Model "Referredby_model" initialized
INFO - 2022-03-09 03:33:45 --> Model "Prefix_master" initialized
INFO - 2022-03-09 03:33:45 --> Model "Hospital_model" initialized
INFO - 2022-03-09 03:33:46 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 03:33:52 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-09 03:33:52 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 03:33:54 --> Final output sent to browser
DEBUG - 2022-03-09 03:33:54 --> Total execution time: 6.4673
ERROR - 2022-03-09 03:34:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 03:34:18 --> Config Class Initialized
INFO - 2022-03-09 03:34:18 --> Hooks Class Initialized
DEBUG - 2022-03-09 03:34:18 --> UTF-8 Support Enabled
INFO - 2022-03-09 03:34:18 --> Utf8 Class Initialized
INFO - 2022-03-09 03:34:18 --> URI Class Initialized
INFO - 2022-03-09 03:34:18 --> Router Class Initialized
INFO - 2022-03-09 03:34:18 --> Output Class Initialized
INFO - 2022-03-09 03:34:18 --> Security Class Initialized
DEBUG - 2022-03-09 03:34:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 03:34:18 --> Input Class Initialized
INFO - 2022-03-09 03:34:18 --> Language Class Initialized
INFO - 2022-03-09 03:34:18 --> Loader Class Initialized
INFO - 2022-03-09 03:34:18 --> Helper loaded: url_helper
INFO - 2022-03-09 03:34:18 --> Helper loaded: form_helper
INFO - 2022-03-09 03:34:18 --> Helper loaded: common_helper
INFO - 2022-03-09 03:34:18 --> Database Driver Class Initialized
DEBUG - 2022-03-09 03:34:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 03:34:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 03:34:18 --> Controller Class Initialized
INFO - 2022-03-09 03:34:18 --> Form Validation Class Initialized
DEBUG - 2022-03-09 03:34:18 --> Encrypt Class Initialized
INFO - 2022-03-09 03:34:18 --> Model "Patient_model" initialized
INFO - 2022-03-09 03:34:18 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 03:34:18 --> Model "Prefix_master" initialized
INFO - 2022-03-09 03:34:18 --> Model "Users_model" initialized
INFO - 2022-03-09 03:34:18 --> Model "Hospital_model" initialized
INFO - 2022-03-09 03:34:18 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 03:34:18 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-09 03:34:18 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 03:34:18 --> Final output sent to browser
DEBUG - 2022-03-09 03:34:18 --> Total execution time: 0.0534
ERROR - 2022-03-09 03:34:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 03:34:31 --> Config Class Initialized
INFO - 2022-03-09 03:34:31 --> Hooks Class Initialized
DEBUG - 2022-03-09 03:34:31 --> UTF-8 Support Enabled
INFO - 2022-03-09 03:34:31 --> Utf8 Class Initialized
INFO - 2022-03-09 03:34:31 --> URI Class Initialized
INFO - 2022-03-09 03:34:31 --> Router Class Initialized
INFO - 2022-03-09 03:34:31 --> Output Class Initialized
INFO - 2022-03-09 03:34:31 --> Security Class Initialized
DEBUG - 2022-03-09 03:34:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 03:34:31 --> Input Class Initialized
INFO - 2022-03-09 03:34:31 --> Language Class Initialized
INFO - 2022-03-09 03:34:31 --> Loader Class Initialized
INFO - 2022-03-09 03:34:31 --> Helper loaded: url_helper
INFO - 2022-03-09 03:34:31 --> Helper loaded: form_helper
INFO - 2022-03-09 03:34:31 --> Helper loaded: common_helper
INFO - 2022-03-09 03:34:31 --> Database Driver Class Initialized
DEBUG - 2022-03-09 03:34:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 03:34:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 03:34:31 --> Controller Class Initialized
INFO - 2022-03-09 03:34:31 --> Form Validation Class Initialized
DEBUG - 2022-03-09 03:34:31 --> Encrypt Class Initialized
INFO - 2022-03-09 03:34:31 --> Model "Patient_model" initialized
INFO - 2022-03-09 03:34:31 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 03:34:31 --> Model "Referredby_model" initialized
INFO - 2022-03-09 03:34:31 --> Model "Prefix_master" initialized
INFO - 2022-03-09 03:34:31 --> Model "Hospital_model" initialized
INFO - 2022-03-09 03:34:31 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 03:34:37 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-09 03:34:37 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 03:34:39 --> Final output sent to browser
DEBUG - 2022-03-09 03:34:39 --> Total execution time: 6.2688
ERROR - 2022-03-09 03:35:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 03:35:05 --> Config Class Initialized
INFO - 2022-03-09 03:35:05 --> Hooks Class Initialized
DEBUG - 2022-03-09 03:35:05 --> UTF-8 Support Enabled
INFO - 2022-03-09 03:35:05 --> Utf8 Class Initialized
INFO - 2022-03-09 03:35:05 --> URI Class Initialized
INFO - 2022-03-09 03:35:05 --> Router Class Initialized
INFO - 2022-03-09 03:35:05 --> Output Class Initialized
INFO - 2022-03-09 03:35:05 --> Security Class Initialized
DEBUG - 2022-03-09 03:35:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 03:35:05 --> Input Class Initialized
INFO - 2022-03-09 03:35:05 --> Language Class Initialized
INFO - 2022-03-09 03:35:05 --> Loader Class Initialized
INFO - 2022-03-09 03:35:05 --> Helper loaded: url_helper
INFO - 2022-03-09 03:35:05 --> Helper loaded: form_helper
INFO - 2022-03-09 03:35:05 --> Helper loaded: common_helper
INFO - 2022-03-09 03:35:05 --> Database Driver Class Initialized
DEBUG - 2022-03-09 03:35:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 03:35:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 03:35:05 --> Controller Class Initialized
INFO - 2022-03-09 03:35:05 --> Form Validation Class Initialized
DEBUG - 2022-03-09 03:35:05 --> Encrypt Class Initialized
INFO - 2022-03-09 03:35:05 --> Model "Patient_model" initialized
INFO - 2022-03-09 03:35:05 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 03:35:05 --> Model "Prefix_master" initialized
INFO - 2022-03-09 03:35:05 --> Model "Users_model" initialized
INFO - 2022-03-09 03:35:05 --> Model "Hospital_model" initialized
INFO - 2022-03-09 03:35:05 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 03:35:05 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-09 03:35:05 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 03:35:05 --> Final output sent to browser
DEBUG - 2022-03-09 03:35:05 --> Total execution time: 0.0634
ERROR - 2022-03-09 03:35:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 03:35:24 --> Config Class Initialized
INFO - 2022-03-09 03:35:24 --> Hooks Class Initialized
DEBUG - 2022-03-09 03:35:24 --> UTF-8 Support Enabled
INFO - 2022-03-09 03:35:24 --> Utf8 Class Initialized
INFO - 2022-03-09 03:35:24 --> URI Class Initialized
INFO - 2022-03-09 03:35:24 --> Router Class Initialized
INFO - 2022-03-09 03:35:24 --> Output Class Initialized
INFO - 2022-03-09 03:35:24 --> Security Class Initialized
DEBUG - 2022-03-09 03:35:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 03:35:24 --> Input Class Initialized
INFO - 2022-03-09 03:35:24 --> Language Class Initialized
INFO - 2022-03-09 03:35:24 --> Loader Class Initialized
INFO - 2022-03-09 03:35:24 --> Helper loaded: url_helper
INFO - 2022-03-09 03:35:24 --> Helper loaded: form_helper
INFO - 2022-03-09 03:35:24 --> Helper loaded: common_helper
INFO - 2022-03-09 03:35:24 --> Database Driver Class Initialized
DEBUG - 2022-03-09 03:35:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 03:35:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 03:35:24 --> Controller Class Initialized
INFO - 2022-03-09 03:35:24 --> Form Validation Class Initialized
DEBUG - 2022-03-09 03:35:24 --> Encrypt Class Initialized
INFO - 2022-03-09 03:35:24 --> Model "Patient_model" initialized
INFO - 2022-03-09 03:35:24 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 03:35:24 --> Model "Referredby_model" initialized
INFO - 2022-03-09 03:35:24 --> Model "Prefix_master" initialized
INFO - 2022-03-09 03:35:24 --> Model "Hospital_model" initialized
INFO - 2022-03-09 03:35:24 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 03:35:32 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-09 03:35:32 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 03:35:34 --> Final output sent to browser
DEBUG - 2022-03-09 03:35:34 --> Total execution time: 8.1299
ERROR - 2022-03-09 03:36:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 03:36:00 --> Config Class Initialized
INFO - 2022-03-09 03:36:00 --> Hooks Class Initialized
DEBUG - 2022-03-09 03:36:00 --> UTF-8 Support Enabled
INFO - 2022-03-09 03:36:00 --> Utf8 Class Initialized
INFO - 2022-03-09 03:36:00 --> URI Class Initialized
INFO - 2022-03-09 03:36:00 --> Router Class Initialized
INFO - 2022-03-09 03:36:00 --> Output Class Initialized
INFO - 2022-03-09 03:36:00 --> Security Class Initialized
DEBUG - 2022-03-09 03:36:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 03:36:00 --> Input Class Initialized
INFO - 2022-03-09 03:36:00 --> Language Class Initialized
INFO - 2022-03-09 03:36:00 --> Loader Class Initialized
INFO - 2022-03-09 03:36:00 --> Helper loaded: url_helper
INFO - 2022-03-09 03:36:00 --> Helper loaded: form_helper
INFO - 2022-03-09 03:36:00 --> Helper loaded: common_helper
INFO - 2022-03-09 03:36:00 --> Database Driver Class Initialized
DEBUG - 2022-03-09 03:36:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 03:36:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 03:36:00 --> Controller Class Initialized
INFO - 2022-03-09 03:36:00 --> Form Validation Class Initialized
DEBUG - 2022-03-09 03:36:00 --> Encrypt Class Initialized
INFO - 2022-03-09 03:36:00 --> Model "Patient_model" initialized
INFO - 2022-03-09 03:36:00 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 03:36:00 --> Model "Prefix_master" initialized
INFO - 2022-03-09 03:36:00 --> Model "Users_model" initialized
INFO - 2022-03-09 03:36:00 --> Model "Hospital_model" initialized
INFO - 2022-03-09 03:36:00 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 03:36:00 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-09 03:36:00 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 03:36:00 --> Final output sent to browser
DEBUG - 2022-03-09 03:36:00 --> Total execution time: 0.0723
ERROR - 2022-03-09 03:36:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 03:36:13 --> Config Class Initialized
INFO - 2022-03-09 03:36:13 --> Hooks Class Initialized
DEBUG - 2022-03-09 03:36:13 --> UTF-8 Support Enabled
INFO - 2022-03-09 03:36:13 --> Utf8 Class Initialized
INFO - 2022-03-09 03:36:13 --> URI Class Initialized
INFO - 2022-03-09 03:36:13 --> Router Class Initialized
INFO - 2022-03-09 03:36:13 --> Output Class Initialized
INFO - 2022-03-09 03:36:13 --> Security Class Initialized
DEBUG - 2022-03-09 03:36:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 03:36:13 --> Input Class Initialized
INFO - 2022-03-09 03:36:13 --> Language Class Initialized
INFO - 2022-03-09 03:36:13 --> Loader Class Initialized
INFO - 2022-03-09 03:36:13 --> Helper loaded: url_helper
INFO - 2022-03-09 03:36:13 --> Helper loaded: form_helper
INFO - 2022-03-09 03:36:13 --> Helper loaded: common_helper
INFO - 2022-03-09 03:36:13 --> Database Driver Class Initialized
DEBUG - 2022-03-09 03:36:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 03:36:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 03:36:13 --> Controller Class Initialized
INFO - 2022-03-09 03:36:13 --> Form Validation Class Initialized
DEBUG - 2022-03-09 03:36:13 --> Encrypt Class Initialized
INFO - 2022-03-09 03:36:13 --> Model "Patient_model" initialized
INFO - 2022-03-09 03:36:13 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 03:36:13 --> Model "Referredby_model" initialized
INFO - 2022-03-09 03:36:13 --> Model "Prefix_master" initialized
INFO - 2022-03-09 03:36:13 --> Model "Hospital_model" initialized
INFO - 2022-03-09 03:36:13 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 03:36:19 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-09 03:36:19 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 03:36:21 --> Final output sent to browser
DEBUG - 2022-03-09 03:36:21 --> Total execution time: 6.3070
ERROR - 2022-03-09 03:36:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 03:36:25 --> Config Class Initialized
INFO - 2022-03-09 03:36:25 --> Hooks Class Initialized
DEBUG - 2022-03-09 03:36:25 --> UTF-8 Support Enabled
INFO - 2022-03-09 03:36:25 --> Utf8 Class Initialized
INFO - 2022-03-09 03:36:25 --> URI Class Initialized
INFO - 2022-03-09 03:36:25 --> Router Class Initialized
INFO - 2022-03-09 03:36:25 --> Output Class Initialized
INFO - 2022-03-09 03:36:25 --> Security Class Initialized
DEBUG - 2022-03-09 03:36:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 03:36:25 --> Input Class Initialized
INFO - 2022-03-09 03:36:25 --> Language Class Initialized
INFO - 2022-03-09 03:36:25 --> Loader Class Initialized
INFO - 2022-03-09 03:36:25 --> Helper loaded: url_helper
INFO - 2022-03-09 03:36:25 --> Helper loaded: form_helper
INFO - 2022-03-09 03:36:25 --> Helper loaded: common_helper
INFO - 2022-03-09 03:36:25 --> Database Driver Class Initialized
DEBUG - 2022-03-09 03:36:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 03:36:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 03:36:25 --> Controller Class Initialized
INFO - 2022-03-09 03:36:25 --> Form Validation Class Initialized
DEBUG - 2022-03-09 03:36:25 --> Encrypt Class Initialized
INFO - 2022-03-09 03:36:25 --> Model "Patient_model" initialized
INFO - 2022-03-09 03:36:25 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 03:36:25 --> Model "Referredby_model" initialized
INFO - 2022-03-09 03:36:25 --> Model "Prefix_master" initialized
INFO - 2022-03-09 03:36:25 --> Model "Hospital_model" initialized
INFO - 2022-03-09 03:36:25 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 03:36:31 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-09 03:36:31 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
ERROR - 2022-03-09 03:36:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 03:36:32 --> Config Class Initialized
INFO - 2022-03-09 03:36:32 --> Hooks Class Initialized
DEBUG - 2022-03-09 03:36:32 --> UTF-8 Support Enabled
INFO - 2022-03-09 03:36:32 --> Utf8 Class Initialized
INFO - 2022-03-09 03:36:32 --> URI Class Initialized
INFO - 2022-03-09 03:36:32 --> Router Class Initialized
INFO - 2022-03-09 03:36:32 --> Output Class Initialized
INFO - 2022-03-09 03:36:32 --> Security Class Initialized
DEBUG - 2022-03-09 03:36:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 03:36:32 --> Input Class Initialized
INFO - 2022-03-09 03:36:32 --> Language Class Initialized
ERROR - 2022-03-09 03:36:32 --> 404 Page Not Found: Karoclient/usersprofile
INFO - 2022-03-09 03:36:33 --> Final output sent to browser
DEBUG - 2022-03-09 03:36:33 --> Total execution time: 5.8672
ERROR - 2022-03-09 03:37:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 03:37:13 --> Config Class Initialized
INFO - 2022-03-09 03:37:13 --> Hooks Class Initialized
DEBUG - 2022-03-09 03:37:13 --> UTF-8 Support Enabled
INFO - 2022-03-09 03:37:13 --> Utf8 Class Initialized
INFO - 2022-03-09 03:37:13 --> URI Class Initialized
INFO - 2022-03-09 03:37:13 --> Router Class Initialized
INFO - 2022-03-09 03:37:13 --> Output Class Initialized
INFO - 2022-03-09 03:37:13 --> Security Class Initialized
DEBUG - 2022-03-09 03:37:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 03:37:13 --> Input Class Initialized
INFO - 2022-03-09 03:37:13 --> Language Class Initialized
INFO - 2022-03-09 03:37:13 --> Loader Class Initialized
INFO - 2022-03-09 03:37:13 --> Helper loaded: url_helper
INFO - 2022-03-09 03:37:13 --> Helper loaded: form_helper
INFO - 2022-03-09 03:37:13 --> Helper loaded: common_helper
INFO - 2022-03-09 03:37:13 --> Database Driver Class Initialized
DEBUG - 2022-03-09 03:37:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 03:37:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 03:37:13 --> Controller Class Initialized
INFO - 2022-03-09 03:37:13 --> Form Validation Class Initialized
DEBUG - 2022-03-09 03:37:13 --> Encrypt Class Initialized
INFO - 2022-03-09 03:37:13 --> Model "Patient_model" initialized
INFO - 2022-03-09 03:37:13 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 03:37:13 --> Model "Prefix_master" initialized
INFO - 2022-03-09 03:37:13 --> Model "Users_model" initialized
INFO - 2022-03-09 03:37:13 --> Model "Hospital_model" initialized
INFO - 2022-03-09 03:37:13 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 03:37:13 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-09 03:37:13 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 03:37:13 --> Final output sent to browser
DEBUG - 2022-03-09 03:37:13 --> Total execution time: 0.0743
ERROR - 2022-03-09 03:37:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 03:37:14 --> Config Class Initialized
INFO - 2022-03-09 03:37:14 --> Hooks Class Initialized
DEBUG - 2022-03-09 03:37:14 --> UTF-8 Support Enabled
INFO - 2022-03-09 03:37:14 --> Utf8 Class Initialized
INFO - 2022-03-09 03:37:14 --> URI Class Initialized
INFO - 2022-03-09 03:37:14 --> Router Class Initialized
INFO - 2022-03-09 03:37:14 --> Output Class Initialized
INFO - 2022-03-09 03:37:14 --> Security Class Initialized
DEBUG - 2022-03-09 03:37:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 03:37:14 --> Input Class Initialized
INFO - 2022-03-09 03:37:14 --> Language Class Initialized
ERROR - 2022-03-09 03:37:14 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-09 03:37:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 03:37:16 --> Config Class Initialized
INFO - 2022-03-09 03:37:16 --> Hooks Class Initialized
DEBUG - 2022-03-09 03:37:16 --> UTF-8 Support Enabled
INFO - 2022-03-09 03:37:16 --> Utf8 Class Initialized
INFO - 2022-03-09 03:37:16 --> URI Class Initialized
INFO - 2022-03-09 03:37:16 --> Router Class Initialized
INFO - 2022-03-09 03:37:16 --> Output Class Initialized
INFO - 2022-03-09 03:37:16 --> Security Class Initialized
DEBUG - 2022-03-09 03:37:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 03:37:16 --> Input Class Initialized
INFO - 2022-03-09 03:37:16 --> Language Class Initialized
INFO - 2022-03-09 03:37:16 --> Loader Class Initialized
INFO - 2022-03-09 03:37:16 --> Helper loaded: url_helper
INFO - 2022-03-09 03:37:16 --> Helper loaded: form_helper
INFO - 2022-03-09 03:37:16 --> Helper loaded: common_helper
INFO - 2022-03-09 03:37:16 --> Database Driver Class Initialized
DEBUG - 2022-03-09 03:37:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 03:37:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 03:37:16 --> Controller Class Initialized
INFO - 2022-03-09 03:37:16 --> Form Validation Class Initialized
DEBUG - 2022-03-09 03:37:16 --> Encrypt Class Initialized
INFO - 2022-03-09 03:37:16 --> Model "Patient_model" initialized
INFO - 2022-03-09 03:37:16 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 03:37:16 --> Model "Referredby_model" initialized
INFO - 2022-03-09 03:37:16 --> Model "Prefix_master" initialized
INFO - 2022-03-09 03:37:16 --> Model "Hospital_model" initialized
INFO - 2022-03-09 03:37:16 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 03:37:16 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-09 03:37:16 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 03:37:16 --> Final output sent to browser
DEBUG - 2022-03-09 03:37:16 --> Total execution time: 0.0605
ERROR - 2022-03-09 03:37:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 03:37:17 --> Config Class Initialized
INFO - 2022-03-09 03:37:17 --> Hooks Class Initialized
DEBUG - 2022-03-09 03:37:17 --> UTF-8 Support Enabled
INFO - 2022-03-09 03:37:17 --> Utf8 Class Initialized
INFO - 2022-03-09 03:37:17 --> URI Class Initialized
INFO - 2022-03-09 03:37:17 --> Router Class Initialized
INFO - 2022-03-09 03:37:17 --> Output Class Initialized
INFO - 2022-03-09 03:37:17 --> Security Class Initialized
DEBUG - 2022-03-09 03:37:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 03:37:17 --> Input Class Initialized
INFO - 2022-03-09 03:37:17 --> Language Class Initialized
ERROR - 2022-03-09 03:37:17 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-09 03:37:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 03:37:23 --> Config Class Initialized
INFO - 2022-03-09 03:37:23 --> Hooks Class Initialized
DEBUG - 2022-03-09 03:37:23 --> UTF-8 Support Enabled
INFO - 2022-03-09 03:37:23 --> Utf8 Class Initialized
INFO - 2022-03-09 03:37:23 --> URI Class Initialized
INFO - 2022-03-09 03:37:23 --> Router Class Initialized
INFO - 2022-03-09 03:37:23 --> Output Class Initialized
INFO - 2022-03-09 03:37:23 --> Security Class Initialized
DEBUG - 2022-03-09 03:37:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 03:37:23 --> Input Class Initialized
INFO - 2022-03-09 03:37:23 --> Language Class Initialized
INFO - 2022-03-09 03:37:23 --> Loader Class Initialized
INFO - 2022-03-09 03:37:23 --> Helper loaded: url_helper
INFO - 2022-03-09 03:37:23 --> Helper loaded: form_helper
INFO - 2022-03-09 03:37:23 --> Helper loaded: common_helper
INFO - 2022-03-09 03:37:23 --> Database Driver Class Initialized
DEBUG - 2022-03-09 03:37:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 03:37:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 03:37:23 --> Controller Class Initialized
INFO - 2022-03-09 03:37:23 --> Form Validation Class Initialized
DEBUG - 2022-03-09 03:37:23 --> Encrypt Class Initialized
INFO - 2022-03-09 03:37:23 --> Model "Patient_model" initialized
INFO - 2022-03-09 03:37:23 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 03:37:23 --> Model "Referredby_model" initialized
INFO - 2022-03-09 03:37:23 --> Model "Prefix_master" initialized
INFO - 2022-03-09 03:37:23 --> Model "Hospital_model" initialized
ERROR - 2022-03-09 03:37:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 03:37:24 --> Config Class Initialized
INFO - 2022-03-09 03:37:24 --> Hooks Class Initialized
DEBUG - 2022-03-09 03:37:24 --> UTF-8 Support Enabled
INFO - 2022-03-09 03:37:24 --> Utf8 Class Initialized
INFO - 2022-03-09 03:37:24 --> URI Class Initialized
INFO - 2022-03-09 03:37:24 --> Router Class Initialized
INFO - 2022-03-09 03:37:24 --> Output Class Initialized
INFO - 2022-03-09 03:37:24 --> Security Class Initialized
DEBUG - 2022-03-09 03:37:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 03:37:24 --> Input Class Initialized
INFO - 2022-03-09 03:37:24 --> Language Class Initialized
INFO - 2022-03-09 03:37:24 --> Loader Class Initialized
INFO - 2022-03-09 03:37:24 --> Helper loaded: url_helper
INFO - 2022-03-09 03:37:24 --> Helper loaded: form_helper
INFO - 2022-03-09 03:37:24 --> Helper loaded: common_helper
INFO - 2022-03-09 03:37:24 --> Database Driver Class Initialized
DEBUG - 2022-03-09 03:37:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 03:37:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 03:37:24 --> Controller Class Initialized
INFO - 2022-03-09 03:37:24 --> Form Validation Class Initialized
DEBUG - 2022-03-09 03:37:24 --> Encrypt Class Initialized
INFO - 2022-03-09 03:37:24 --> Model "Patient_model" initialized
INFO - 2022-03-09 03:37:24 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 03:37:24 --> Model "Referredby_model" initialized
INFO - 2022-03-09 03:37:24 --> Model "Prefix_master" initialized
INFO - 2022-03-09 03:37:24 --> Model "Hospital_model" initialized
INFO - 2022-03-09 03:37:24 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 03:37:24 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-09 03:37:24 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 03:37:24 --> Final output sent to browser
DEBUG - 2022-03-09 03:37:24 --> Total execution time: 0.0472
ERROR - 2022-03-09 03:37:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 03:37:25 --> Config Class Initialized
INFO - 2022-03-09 03:37:25 --> Hooks Class Initialized
DEBUG - 2022-03-09 03:37:25 --> UTF-8 Support Enabled
INFO - 2022-03-09 03:37:25 --> Utf8 Class Initialized
INFO - 2022-03-09 03:37:25 --> URI Class Initialized
INFO - 2022-03-09 03:37:25 --> Router Class Initialized
INFO - 2022-03-09 03:37:25 --> Output Class Initialized
INFO - 2022-03-09 03:37:25 --> Security Class Initialized
DEBUG - 2022-03-09 03:37:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 03:37:25 --> Input Class Initialized
INFO - 2022-03-09 03:37:25 --> Language Class Initialized
ERROR - 2022-03-09 03:37:25 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-09 03:37:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 03:37:25 --> Config Class Initialized
INFO - 2022-03-09 03:37:25 --> Hooks Class Initialized
DEBUG - 2022-03-09 03:37:25 --> UTF-8 Support Enabled
INFO - 2022-03-09 03:37:25 --> Utf8 Class Initialized
INFO - 2022-03-09 03:37:25 --> URI Class Initialized
INFO - 2022-03-09 03:37:25 --> Router Class Initialized
INFO - 2022-03-09 03:37:25 --> Output Class Initialized
INFO - 2022-03-09 03:37:25 --> Security Class Initialized
DEBUG - 2022-03-09 03:37:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 03:37:25 --> Input Class Initialized
INFO - 2022-03-09 03:37:25 --> Language Class Initialized
INFO - 2022-03-09 03:37:25 --> Loader Class Initialized
INFO - 2022-03-09 03:37:25 --> Helper loaded: url_helper
INFO - 2022-03-09 03:37:25 --> Helper loaded: form_helper
INFO - 2022-03-09 03:37:25 --> Helper loaded: common_helper
INFO - 2022-03-09 03:37:25 --> Database Driver Class Initialized
DEBUG - 2022-03-09 03:37:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 03:37:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 03:37:25 --> Controller Class Initialized
INFO - 2022-03-09 03:37:25 --> Form Validation Class Initialized
DEBUG - 2022-03-09 03:37:25 --> Encrypt Class Initialized
INFO - 2022-03-09 03:37:25 --> Model "Patient_model" initialized
INFO - 2022-03-09 03:37:25 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 03:37:25 --> Model "Prefix_master" initialized
INFO - 2022-03-09 03:37:25 --> Model "Users_model" initialized
INFO - 2022-03-09 03:37:25 --> Model "Hospital_model" initialized
INFO - 2022-03-09 03:37:25 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 03:37:25 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-09 03:37:25 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 03:37:25 --> Final output sent to browser
DEBUG - 2022-03-09 03:37:25 --> Total execution time: 0.0564
ERROR - 2022-03-09 03:37:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 03:37:26 --> Config Class Initialized
INFO - 2022-03-09 03:37:26 --> Hooks Class Initialized
DEBUG - 2022-03-09 03:37:26 --> UTF-8 Support Enabled
INFO - 2022-03-09 03:37:26 --> Utf8 Class Initialized
INFO - 2022-03-09 03:37:26 --> URI Class Initialized
INFO - 2022-03-09 03:37:26 --> Router Class Initialized
INFO - 2022-03-09 03:37:26 --> Output Class Initialized
INFO - 2022-03-09 03:37:26 --> Security Class Initialized
DEBUG - 2022-03-09 03:37:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 03:37:26 --> Input Class Initialized
INFO - 2022-03-09 03:37:26 --> Language Class Initialized
ERROR - 2022-03-09 03:37:26 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-09 03:37:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 03:37:54 --> Config Class Initialized
INFO - 2022-03-09 03:37:54 --> Hooks Class Initialized
DEBUG - 2022-03-09 03:37:54 --> UTF-8 Support Enabled
INFO - 2022-03-09 03:37:54 --> Utf8 Class Initialized
INFO - 2022-03-09 03:37:54 --> URI Class Initialized
INFO - 2022-03-09 03:37:54 --> Router Class Initialized
INFO - 2022-03-09 03:37:54 --> Output Class Initialized
INFO - 2022-03-09 03:37:54 --> Security Class Initialized
DEBUG - 2022-03-09 03:37:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 03:37:54 --> Input Class Initialized
INFO - 2022-03-09 03:37:54 --> Language Class Initialized
INFO - 2022-03-09 03:37:54 --> Loader Class Initialized
INFO - 2022-03-09 03:37:54 --> Helper loaded: url_helper
INFO - 2022-03-09 03:37:54 --> Helper loaded: form_helper
INFO - 2022-03-09 03:37:54 --> Helper loaded: common_helper
INFO - 2022-03-09 03:37:54 --> Database Driver Class Initialized
DEBUG - 2022-03-09 03:37:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 03:37:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 03:37:54 --> Controller Class Initialized
INFO - 2022-03-09 03:37:54 --> Form Validation Class Initialized
DEBUG - 2022-03-09 03:37:54 --> Encrypt Class Initialized
INFO - 2022-03-09 03:37:54 --> Model "Patient_model" initialized
INFO - 2022-03-09 03:37:54 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 03:37:54 --> Model "Prefix_master" initialized
INFO - 2022-03-09 03:37:54 --> Model "Users_model" initialized
INFO - 2022-03-09 03:37:54 --> Model "Hospital_model" initialized
INFO - 2022-03-09 03:37:54 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 03:37:54 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-09 03:37:54 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 03:37:54 --> Final output sent to browser
DEBUG - 2022-03-09 03:37:54 --> Total execution time: 0.0757
ERROR - 2022-03-09 03:38:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 03:38:15 --> Config Class Initialized
INFO - 2022-03-09 03:38:15 --> Hooks Class Initialized
DEBUG - 2022-03-09 03:38:15 --> UTF-8 Support Enabled
INFO - 2022-03-09 03:38:15 --> Utf8 Class Initialized
INFO - 2022-03-09 03:38:15 --> URI Class Initialized
INFO - 2022-03-09 03:38:15 --> Router Class Initialized
INFO - 2022-03-09 03:38:15 --> Output Class Initialized
INFO - 2022-03-09 03:38:15 --> Security Class Initialized
DEBUG - 2022-03-09 03:38:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 03:38:15 --> Input Class Initialized
INFO - 2022-03-09 03:38:15 --> Language Class Initialized
INFO - 2022-03-09 03:38:15 --> Loader Class Initialized
INFO - 2022-03-09 03:38:15 --> Helper loaded: url_helper
INFO - 2022-03-09 03:38:15 --> Helper loaded: form_helper
INFO - 2022-03-09 03:38:15 --> Helper loaded: common_helper
INFO - 2022-03-09 03:38:15 --> Database Driver Class Initialized
DEBUG - 2022-03-09 03:38:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 03:38:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 03:38:15 --> Controller Class Initialized
INFO - 2022-03-09 03:38:15 --> Form Validation Class Initialized
DEBUG - 2022-03-09 03:38:15 --> Encrypt Class Initialized
INFO - 2022-03-09 03:38:15 --> Model "Patient_model" initialized
INFO - 2022-03-09 03:38:15 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 03:38:15 --> Model "Referredby_model" initialized
INFO - 2022-03-09 03:38:15 --> Model "Prefix_master" initialized
INFO - 2022-03-09 03:38:15 --> Model "Hospital_model" initialized
INFO - 2022-03-09 03:38:15 --> File loaded: /home3/karoteam/public_html/application/views/header.php
ERROR - 2022-03-09 03:38:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 03:38:23 --> Config Class Initialized
INFO - 2022-03-09 03:38:23 --> Hooks Class Initialized
DEBUG - 2022-03-09 03:38:23 --> UTF-8 Support Enabled
INFO - 2022-03-09 03:38:23 --> Utf8 Class Initialized
INFO - 2022-03-09 03:38:23 --> URI Class Initialized
INFO - 2022-03-09 03:38:23 --> Router Class Initialized
INFO - 2022-03-09 03:38:23 --> Output Class Initialized
INFO - 2022-03-09 03:38:23 --> Security Class Initialized
DEBUG - 2022-03-09 03:38:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 03:38:23 --> Input Class Initialized
INFO - 2022-03-09 03:38:23 --> Language Class Initialized
INFO - 2022-03-09 03:38:23 --> Loader Class Initialized
INFO - 2022-03-09 03:38:23 --> Helper loaded: url_helper
INFO - 2022-03-09 03:38:23 --> Helper loaded: form_helper
INFO - 2022-03-09 03:38:23 --> Helper loaded: common_helper
INFO - 2022-03-09 03:38:23 --> Database Driver Class Initialized
DEBUG - 2022-03-09 03:38:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 03:38:24 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-09 03:38:24 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 03:38:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 03:38:24 --> Controller Class Initialized
INFO - 2022-03-09 03:38:24 --> Form Validation Class Initialized
DEBUG - 2022-03-09 03:38:24 --> Encrypt Class Initialized
INFO - 2022-03-09 03:38:24 --> Model "Patient_model" initialized
INFO - 2022-03-09 03:38:24 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 03:38:24 --> Model "Referredby_model" initialized
INFO - 2022-03-09 03:38:24 --> Model "Prefix_master" initialized
INFO - 2022-03-09 03:38:24 --> Model "Hospital_model" initialized
INFO - 2022-03-09 03:38:24 --> File loaded: /home3/karoteam/public_html/application/views/header.php
ERROR - 2022-03-09 03:38:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 03:38:24 --> Config Class Initialized
INFO - 2022-03-09 03:38:24 --> Hooks Class Initialized
DEBUG - 2022-03-09 03:38:24 --> UTF-8 Support Enabled
INFO - 2022-03-09 03:38:24 --> Utf8 Class Initialized
INFO - 2022-03-09 03:38:24 --> URI Class Initialized
INFO - 2022-03-09 03:38:24 --> Router Class Initialized
INFO - 2022-03-09 03:38:24 --> Output Class Initialized
INFO - 2022-03-09 03:38:24 --> Security Class Initialized
DEBUG - 2022-03-09 03:38:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 03:38:24 --> Input Class Initialized
INFO - 2022-03-09 03:38:24 --> Language Class Initialized
INFO - 2022-03-09 03:38:24 --> Loader Class Initialized
INFO - 2022-03-09 03:38:24 --> Helper loaded: url_helper
INFO - 2022-03-09 03:38:24 --> Helper loaded: form_helper
INFO - 2022-03-09 03:38:24 --> Helper loaded: common_helper
INFO - 2022-03-09 03:38:24 --> Database Driver Class Initialized
DEBUG - 2022-03-09 03:38:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 03:38:30 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-09 03:38:30 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 03:38:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 03:38:30 --> Controller Class Initialized
INFO - 2022-03-09 03:38:30 --> Form Validation Class Initialized
DEBUG - 2022-03-09 03:38:30 --> Encrypt Class Initialized
INFO - 2022-03-09 03:38:30 --> Model "Patient_model" initialized
INFO - 2022-03-09 03:38:30 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 03:38:30 --> Model "Referredby_model" initialized
INFO - 2022-03-09 03:38:30 --> Model "Prefix_master" initialized
INFO - 2022-03-09 03:38:30 --> Model "Hospital_model" initialized
INFO - 2022-03-09 03:38:30 --> File loaded: /home3/karoteam/public_html/application/views/header.php
ERROR - 2022-03-09 03:38:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 03:38:30 --> Config Class Initialized
INFO - 2022-03-09 03:38:30 --> Hooks Class Initialized
DEBUG - 2022-03-09 03:38:30 --> UTF-8 Support Enabled
INFO - 2022-03-09 03:38:30 --> Utf8 Class Initialized
INFO - 2022-03-09 03:38:30 --> URI Class Initialized
INFO - 2022-03-09 03:38:30 --> Router Class Initialized
INFO - 2022-03-09 03:38:30 --> Output Class Initialized
INFO - 2022-03-09 03:38:30 --> Security Class Initialized
DEBUG - 2022-03-09 03:38:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 03:38:30 --> Input Class Initialized
INFO - 2022-03-09 03:38:30 --> Language Class Initialized
INFO - 2022-03-09 03:38:30 --> Loader Class Initialized
INFO - 2022-03-09 03:38:30 --> Helper loaded: url_helper
INFO - 2022-03-09 03:38:30 --> Helper loaded: form_helper
INFO - 2022-03-09 03:38:30 --> Helper loaded: common_helper
INFO - 2022-03-09 03:38:30 --> Database Driver Class Initialized
DEBUG - 2022-03-09 03:38:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-03-09 03:38:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 03:38:33 --> Config Class Initialized
INFO - 2022-03-09 03:38:33 --> Hooks Class Initialized
DEBUG - 2022-03-09 03:38:33 --> UTF-8 Support Enabled
INFO - 2022-03-09 03:38:33 --> Utf8 Class Initialized
INFO - 2022-03-09 03:38:33 --> URI Class Initialized
INFO - 2022-03-09 03:38:33 --> Router Class Initialized
INFO - 2022-03-09 03:38:33 --> Output Class Initialized
INFO - 2022-03-09 03:38:33 --> Security Class Initialized
DEBUG - 2022-03-09 03:38:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 03:38:33 --> Input Class Initialized
INFO - 2022-03-09 03:38:33 --> Language Class Initialized
INFO - 2022-03-09 03:38:33 --> Loader Class Initialized
INFO - 2022-03-09 03:38:33 --> Helper loaded: url_helper
INFO - 2022-03-09 03:38:33 --> Helper loaded: form_helper
INFO - 2022-03-09 03:38:33 --> Helper loaded: common_helper
INFO - 2022-03-09 03:38:33 --> Database Driver Class Initialized
DEBUG - 2022-03-09 03:38:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 03:38:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 03:38:33 --> Controller Class Initialized
INFO - 2022-03-09 03:38:33 --> Form Validation Class Initialized
DEBUG - 2022-03-09 03:38:33 --> Encrypt Class Initialized
INFO - 2022-03-09 03:38:33 --> Model "Patient_model" initialized
INFO - 2022-03-09 03:38:33 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 03:38:33 --> Model "Referredby_model" initialized
INFO - 2022-03-09 03:38:33 --> Model "Prefix_master" initialized
INFO - 2022-03-09 03:38:33 --> Model "Hospital_model" initialized
INFO - 2022-03-09 03:38:33 --> Final output sent to browser
DEBUG - 2022-03-09 03:38:33 --> Total execution time: 0.0252
ERROR - 2022-03-09 03:38:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 03:38:34 --> Config Class Initialized
INFO - 2022-03-09 03:38:34 --> Hooks Class Initialized
DEBUG - 2022-03-09 03:38:34 --> UTF-8 Support Enabled
INFO - 2022-03-09 03:38:34 --> Utf8 Class Initialized
INFO - 2022-03-09 03:38:34 --> URI Class Initialized
INFO - 2022-03-09 03:38:34 --> Router Class Initialized
INFO - 2022-03-09 03:38:34 --> Output Class Initialized
INFO - 2022-03-09 03:38:34 --> Security Class Initialized
DEBUG - 2022-03-09 03:38:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 03:38:34 --> Input Class Initialized
INFO - 2022-03-09 03:38:34 --> Language Class Initialized
INFO - 2022-03-09 03:38:34 --> Loader Class Initialized
INFO - 2022-03-09 03:38:34 --> Helper loaded: url_helper
INFO - 2022-03-09 03:38:34 --> Helper loaded: form_helper
INFO - 2022-03-09 03:38:34 --> Helper loaded: common_helper
INFO - 2022-03-09 03:38:34 --> Database Driver Class Initialized
DEBUG - 2022-03-09 03:38:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 03:38:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 03:38:34 --> Controller Class Initialized
INFO - 2022-03-09 03:38:34 --> Form Validation Class Initialized
DEBUG - 2022-03-09 03:38:34 --> Encrypt Class Initialized
INFO - 2022-03-09 03:38:34 --> Model "Patient_model" initialized
INFO - 2022-03-09 03:38:34 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 03:38:34 --> Model "Referredby_model" initialized
INFO - 2022-03-09 03:38:34 --> Model "Prefix_master" initialized
INFO - 2022-03-09 03:38:34 --> Model "Hospital_model" initialized
ERROR - 2022-03-09 03:38:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 03:38:35 --> Config Class Initialized
INFO - 2022-03-09 03:38:35 --> Hooks Class Initialized
DEBUG - 2022-03-09 03:38:35 --> UTF-8 Support Enabled
INFO - 2022-03-09 03:38:35 --> Utf8 Class Initialized
INFO - 2022-03-09 03:38:35 --> URI Class Initialized
INFO - 2022-03-09 03:38:35 --> Router Class Initialized
INFO - 2022-03-09 03:38:35 --> Output Class Initialized
INFO - 2022-03-09 03:38:35 --> Security Class Initialized
DEBUG - 2022-03-09 03:38:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 03:38:35 --> Input Class Initialized
INFO - 2022-03-09 03:38:35 --> Language Class Initialized
INFO - 2022-03-09 03:38:35 --> Loader Class Initialized
INFO - 2022-03-09 03:38:35 --> Helper loaded: url_helper
INFO - 2022-03-09 03:38:35 --> Helper loaded: form_helper
INFO - 2022-03-09 03:38:35 --> Helper loaded: common_helper
INFO - 2022-03-09 03:38:35 --> Database Driver Class Initialized
DEBUG - 2022-03-09 03:38:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 03:38:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 03:38:35 --> Controller Class Initialized
INFO - 2022-03-09 03:38:35 --> Form Validation Class Initialized
DEBUG - 2022-03-09 03:38:35 --> Encrypt Class Initialized
INFO - 2022-03-09 03:38:35 --> Model "Patient_model" initialized
INFO - 2022-03-09 03:38:35 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 03:38:35 --> Model "Referredby_model" initialized
INFO - 2022-03-09 03:38:35 --> Model "Prefix_master" initialized
INFO - 2022-03-09 03:38:35 --> Model "Hospital_model" initialized
INFO - 2022-03-09 03:38:35 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 03:38:35 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-09 03:38:35 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 03:38:35 --> Final output sent to browser
DEBUG - 2022-03-09 03:38:35 --> Total execution time: 0.0564
ERROR - 2022-03-09 03:38:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 03:38:35 --> Config Class Initialized
INFO - 2022-03-09 03:38:35 --> Hooks Class Initialized
DEBUG - 2022-03-09 03:38:35 --> UTF-8 Support Enabled
INFO - 2022-03-09 03:38:35 --> Utf8 Class Initialized
INFO - 2022-03-09 03:38:35 --> URI Class Initialized
INFO - 2022-03-09 03:38:35 --> Router Class Initialized
INFO - 2022-03-09 03:38:35 --> Output Class Initialized
INFO - 2022-03-09 03:38:35 --> Security Class Initialized
DEBUG - 2022-03-09 03:38:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 03:38:35 --> Input Class Initialized
INFO - 2022-03-09 03:38:35 --> Language Class Initialized
INFO - 2022-03-09 03:38:35 --> Loader Class Initialized
INFO - 2022-03-09 03:38:35 --> Helper loaded: url_helper
INFO - 2022-03-09 03:38:35 --> Helper loaded: form_helper
INFO - 2022-03-09 03:38:35 --> Helper loaded: common_helper
INFO - 2022-03-09 03:38:35 --> Database Driver Class Initialized
DEBUG - 2022-03-09 03:38:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 03:38:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 03:38:35 --> Controller Class Initialized
INFO - 2022-03-09 03:38:35 --> Form Validation Class Initialized
DEBUG - 2022-03-09 03:38:35 --> Encrypt Class Initialized
INFO - 2022-03-09 03:38:35 --> Model "Patient_model" initialized
INFO - 2022-03-09 03:38:35 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 03:38:35 --> Model "Prefix_master" initialized
INFO - 2022-03-09 03:38:35 --> Model "Users_model" initialized
INFO - 2022-03-09 03:38:35 --> Model "Hospital_model" initialized
INFO - 2022-03-09 03:38:35 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 03:38:36 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-09 03:38:36 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 03:38:36 --> Final output sent to browser
DEBUG - 2022-03-09 03:38:36 --> Total execution time: 0.0643
INFO - 2022-03-09 03:38:37 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-09 03:38:37 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 03:38:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 03:38:37 --> Controller Class Initialized
INFO - 2022-03-09 03:38:37 --> Form Validation Class Initialized
DEBUG - 2022-03-09 03:38:37 --> Encrypt Class Initialized
INFO - 2022-03-09 03:38:37 --> Model "Patient_model" initialized
INFO - 2022-03-09 03:38:37 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 03:38:37 --> Model "Referredby_model" initialized
INFO - 2022-03-09 03:38:37 --> Model "Prefix_master" initialized
INFO - 2022-03-09 03:38:37 --> Model "Hospital_model" initialized
INFO - 2022-03-09 03:38:37 --> File loaded: /home3/karoteam/public_html/application/views/header.php
ERROR - 2022-03-09 03:38:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 03:38:39 --> Config Class Initialized
INFO - 2022-03-09 03:38:39 --> Hooks Class Initialized
DEBUG - 2022-03-09 03:38:39 --> UTF-8 Support Enabled
INFO - 2022-03-09 03:38:39 --> Utf8 Class Initialized
INFO - 2022-03-09 03:38:39 --> URI Class Initialized
INFO - 2022-03-09 03:38:39 --> Router Class Initialized
INFO - 2022-03-09 03:38:39 --> Output Class Initialized
INFO - 2022-03-09 03:38:39 --> Security Class Initialized
DEBUG - 2022-03-09 03:38:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 03:38:39 --> Input Class Initialized
INFO - 2022-03-09 03:38:39 --> Language Class Initialized
INFO - 2022-03-09 03:38:39 --> Loader Class Initialized
INFO - 2022-03-09 03:38:39 --> Helper loaded: url_helper
INFO - 2022-03-09 03:38:39 --> Helper loaded: form_helper
INFO - 2022-03-09 03:38:39 --> Helper loaded: common_helper
INFO - 2022-03-09 03:38:39 --> Database Driver Class Initialized
DEBUG - 2022-03-09 03:38:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 03:38:44 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-09 03:38:44 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 03:38:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 03:38:44 --> Controller Class Initialized
INFO - 2022-03-09 03:38:44 --> Form Validation Class Initialized
DEBUG - 2022-03-09 03:38:44 --> Encrypt Class Initialized
INFO - 2022-03-09 03:38:44 --> Model "Patient_model" initialized
INFO - 2022-03-09 03:38:44 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 03:38:44 --> Model "Referredby_model" initialized
INFO - 2022-03-09 03:38:44 --> Model "Prefix_master" initialized
INFO - 2022-03-09 03:38:44 --> Model "Hospital_model" initialized
INFO - 2022-03-09 03:38:44 --> File loaded: /home3/karoteam/public_html/application/views/header.php
ERROR - 2022-03-09 03:38:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 03:38:44 --> Config Class Initialized
INFO - 2022-03-09 03:38:44 --> Hooks Class Initialized
DEBUG - 2022-03-09 03:38:44 --> UTF-8 Support Enabled
INFO - 2022-03-09 03:38:44 --> Utf8 Class Initialized
INFO - 2022-03-09 03:38:44 --> URI Class Initialized
INFO - 2022-03-09 03:38:44 --> Router Class Initialized
INFO - 2022-03-09 03:38:44 --> Output Class Initialized
INFO - 2022-03-09 03:38:44 --> Security Class Initialized
DEBUG - 2022-03-09 03:38:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 03:38:44 --> Input Class Initialized
INFO - 2022-03-09 03:38:44 --> Language Class Initialized
INFO - 2022-03-09 03:38:44 --> Loader Class Initialized
INFO - 2022-03-09 03:38:44 --> Helper loaded: url_helper
INFO - 2022-03-09 03:38:44 --> Helper loaded: form_helper
INFO - 2022-03-09 03:38:44 --> Helper loaded: common_helper
INFO - 2022-03-09 03:38:44 --> Database Driver Class Initialized
DEBUG - 2022-03-09 03:38:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 03:38:50 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-09 03:38:50 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 03:38:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 03:38:51 --> Controller Class Initialized
INFO - 2022-03-09 03:38:51 --> Form Validation Class Initialized
DEBUG - 2022-03-09 03:38:51 --> Encrypt Class Initialized
INFO - 2022-03-09 03:38:51 --> Model "Patient_model" initialized
INFO - 2022-03-09 03:38:51 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 03:38:51 --> Model "Referredby_model" initialized
INFO - 2022-03-09 03:38:51 --> Model "Prefix_master" initialized
INFO - 2022-03-09 03:38:51 --> Model "Hospital_model" initialized
INFO - 2022-03-09 03:38:51 --> File loaded: /home3/karoteam/public_html/application/views/header.php
ERROR - 2022-03-09 03:38:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 03:38:53 --> Config Class Initialized
INFO - 2022-03-09 03:38:53 --> Hooks Class Initialized
DEBUG - 2022-03-09 03:38:53 --> UTF-8 Support Enabled
INFO - 2022-03-09 03:38:53 --> Utf8 Class Initialized
INFO - 2022-03-09 03:38:53 --> URI Class Initialized
INFO - 2022-03-09 03:38:53 --> Router Class Initialized
INFO - 2022-03-09 03:38:53 --> Output Class Initialized
INFO - 2022-03-09 03:38:53 --> Security Class Initialized
DEBUG - 2022-03-09 03:38:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 03:38:53 --> Input Class Initialized
INFO - 2022-03-09 03:38:53 --> Language Class Initialized
INFO - 2022-03-09 03:38:53 --> Loader Class Initialized
INFO - 2022-03-09 03:38:53 --> Helper loaded: url_helper
INFO - 2022-03-09 03:38:53 --> Helper loaded: form_helper
INFO - 2022-03-09 03:38:53 --> Helper loaded: common_helper
INFO - 2022-03-09 03:38:53 --> Database Driver Class Initialized
DEBUG - 2022-03-09 03:38:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 03:38:57 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-09 03:38:57 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 03:38:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 03:38:57 --> Controller Class Initialized
INFO - 2022-03-09 03:38:57 --> Form Validation Class Initialized
DEBUG - 2022-03-09 03:38:57 --> Encrypt Class Initialized
INFO - 2022-03-09 03:38:57 --> Model "Patient_model" initialized
INFO - 2022-03-09 03:38:57 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 03:38:57 --> Model "Referredby_model" initialized
INFO - 2022-03-09 03:38:57 --> Model "Prefix_master" initialized
INFO - 2022-03-09 03:38:57 --> Model "Hospital_model" initialized
INFO - 2022-03-09 03:38:57 --> File loaded: /home3/karoteam/public_html/application/views/header.php
ERROR - 2022-03-09 03:38:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 03:38:57 --> Config Class Initialized
INFO - 2022-03-09 03:38:57 --> Hooks Class Initialized
DEBUG - 2022-03-09 03:38:57 --> UTF-8 Support Enabled
INFO - 2022-03-09 03:38:57 --> Utf8 Class Initialized
INFO - 2022-03-09 03:38:57 --> URI Class Initialized
INFO - 2022-03-09 03:38:57 --> Router Class Initialized
INFO - 2022-03-09 03:38:57 --> Output Class Initialized
INFO - 2022-03-09 03:38:57 --> Security Class Initialized
DEBUG - 2022-03-09 03:38:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 03:38:57 --> Input Class Initialized
INFO - 2022-03-09 03:38:57 --> Language Class Initialized
INFO - 2022-03-09 03:38:57 --> Loader Class Initialized
INFO - 2022-03-09 03:38:57 --> Helper loaded: url_helper
INFO - 2022-03-09 03:38:57 --> Helper loaded: form_helper
INFO - 2022-03-09 03:38:57 --> Helper loaded: common_helper
INFO - 2022-03-09 03:38:57 --> Database Driver Class Initialized
DEBUG - 2022-03-09 03:38:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 03:39:04 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-09 03:39:04 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 03:39:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 03:39:04 --> Controller Class Initialized
INFO - 2022-03-09 03:39:04 --> Form Validation Class Initialized
DEBUG - 2022-03-09 03:39:04 --> Encrypt Class Initialized
INFO - 2022-03-09 03:39:04 --> Model "Patient_model" initialized
INFO - 2022-03-09 03:39:04 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 03:39:04 --> Model "Referredby_model" initialized
INFO - 2022-03-09 03:39:04 --> Model "Prefix_master" initialized
INFO - 2022-03-09 03:39:04 --> Model "Hospital_model" initialized
INFO - 2022-03-09 03:39:04 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 03:39:10 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-09 03:39:10 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 03:39:12 --> Final output sent to browser
DEBUG - 2022-03-09 03:39:12 --> Total execution time: 13.0731
ERROR - 2022-03-09 03:39:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 03:39:41 --> Config Class Initialized
INFO - 2022-03-09 03:39:41 --> Hooks Class Initialized
DEBUG - 2022-03-09 03:39:41 --> UTF-8 Support Enabled
INFO - 2022-03-09 03:39:41 --> Utf8 Class Initialized
INFO - 2022-03-09 03:39:41 --> URI Class Initialized
INFO - 2022-03-09 03:39:41 --> Router Class Initialized
INFO - 2022-03-09 03:39:41 --> Output Class Initialized
INFO - 2022-03-09 03:39:41 --> Security Class Initialized
DEBUG - 2022-03-09 03:39:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 03:39:41 --> Input Class Initialized
INFO - 2022-03-09 03:39:41 --> Language Class Initialized
INFO - 2022-03-09 03:39:41 --> Loader Class Initialized
INFO - 2022-03-09 03:39:41 --> Helper loaded: url_helper
INFO - 2022-03-09 03:39:41 --> Helper loaded: form_helper
INFO - 2022-03-09 03:39:41 --> Helper loaded: common_helper
INFO - 2022-03-09 03:39:41 --> Database Driver Class Initialized
DEBUG - 2022-03-09 03:39:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 03:39:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 03:39:41 --> Controller Class Initialized
INFO - 2022-03-09 03:39:41 --> Form Validation Class Initialized
DEBUG - 2022-03-09 03:39:41 --> Encrypt Class Initialized
INFO - 2022-03-09 03:39:41 --> Model "Patient_model" initialized
INFO - 2022-03-09 03:39:41 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 03:39:41 --> Model "Prefix_master" initialized
INFO - 2022-03-09 03:39:41 --> Model "Users_model" initialized
INFO - 2022-03-09 03:39:41 --> Model "Hospital_model" initialized
INFO - 2022-03-09 03:39:41 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 03:39:41 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-09 03:39:41 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 03:39:41 --> Final output sent to browser
DEBUG - 2022-03-09 03:39:41 --> Total execution time: 0.0919
ERROR - 2022-03-09 03:40:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 03:40:01 --> Config Class Initialized
INFO - 2022-03-09 03:40:01 --> Hooks Class Initialized
DEBUG - 2022-03-09 03:40:01 --> UTF-8 Support Enabled
INFO - 2022-03-09 03:40:01 --> Utf8 Class Initialized
INFO - 2022-03-09 03:40:01 --> URI Class Initialized
INFO - 2022-03-09 03:40:01 --> Router Class Initialized
INFO - 2022-03-09 03:40:01 --> Output Class Initialized
INFO - 2022-03-09 03:40:01 --> Security Class Initialized
DEBUG - 2022-03-09 03:40:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 03:40:01 --> Input Class Initialized
INFO - 2022-03-09 03:40:01 --> Language Class Initialized
INFO - 2022-03-09 03:40:01 --> Loader Class Initialized
INFO - 2022-03-09 03:40:01 --> Helper loaded: url_helper
INFO - 2022-03-09 03:40:01 --> Helper loaded: form_helper
INFO - 2022-03-09 03:40:01 --> Helper loaded: common_helper
INFO - 2022-03-09 03:40:01 --> Database Driver Class Initialized
DEBUG - 2022-03-09 03:40:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 03:40:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 03:40:01 --> Controller Class Initialized
INFO - 2022-03-09 03:40:01 --> Form Validation Class Initialized
DEBUG - 2022-03-09 03:40:01 --> Encrypt Class Initialized
INFO - 2022-03-09 03:40:01 --> Model "Patient_model" initialized
INFO - 2022-03-09 03:40:01 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 03:40:01 --> Model "Referredby_model" initialized
INFO - 2022-03-09 03:40:01 --> Model "Prefix_master" initialized
INFO - 2022-03-09 03:40:01 --> Model "Hospital_model" initialized
INFO - 2022-03-09 03:40:01 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 03:40:07 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-09 03:40:07 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 03:40:09 --> Final output sent to browser
DEBUG - 2022-03-09 03:40:09 --> Total execution time: 6.7772
ERROR - 2022-03-09 03:40:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 03:40:35 --> Config Class Initialized
INFO - 2022-03-09 03:40:35 --> Hooks Class Initialized
DEBUG - 2022-03-09 03:40:35 --> UTF-8 Support Enabled
INFO - 2022-03-09 03:40:35 --> Utf8 Class Initialized
INFO - 2022-03-09 03:40:35 --> URI Class Initialized
INFO - 2022-03-09 03:40:35 --> Router Class Initialized
INFO - 2022-03-09 03:40:35 --> Output Class Initialized
INFO - 2022-03-09 03:40:35 --> Security Class Initialized
DEBUG - 2022-03-09 03:40:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 03:40:35 --> Input Class Initialized
INFO - 2022-03-09 03:40:35 --> Language Class Initialized
INFO - 2022-03-09 03:40:35 --> Loader Class Initialized
INFO - 2022-03-09 03:40:35 --> Helper loaded: url_helper
INFO - 2022-03-09 03:40:35 --> Helper loaded: form_helper
INFO - 2022-03-09 03:40:35 --> Helper loaded: common_helper
INFO - 2022-03-09 03:40:35 --> Database Driver Class Initialized
DEBUG - 2022-03-09 03:40:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 03:40:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 03:40:35 --> Controller Class Initialized
INFO - 2022-03-09 03:40:35 --> Form Validation Class Initialized
DEBUG - 2022-03-09 03:40:35 --> Encrypt Class Initialized
INFO - 2022-03-09 03:40:35 --> Model "Patient_model" initialized
INFO - 2022-03-09 03:40:35 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 03:40:35 --> Model "Prefix_master" initialized
INFO - 2022-03-09 03:40:35 --> Model "Users_model" initialized
INFO - 2022-03-09 03:40:35 --> Model "Hospital_model" initialized
INFO - 2022-03-09 03:40:36 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 03:40:36 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-09 03:40:36 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 03:40:36 --> Final output sent to browser
DEBUG - 2022-03-09 03:40:36 --> Total execution time: 0.0966
ERROR - 2022-03-09 03:40:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 03:40:56 --> Config Class Initialized
INFO - 2022-03-09 03:40:56 --> Hooks Class Initialized
DEBUG - 2022-03-09 03:40:56 --> UTF-8 Support Enabled
INFO - 2022-03-09 03:40:56 --> Utf8 Class Initialized
INFO - 2022-03-09 03:40:56 --> URI Class Initialized
INFO - 2022-03-09 03:40:56 --> Router Class Initialized
INFO - 2022-03-09 03:40:56 --> Output Class Initialized
INFO - 2022-03-09 03:40:56 --> Security Class Initialized
DEBUG - 2022-03-09 03:40:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 03:40:56 --> Input Class Initialized
INFO - 2022-03-09 03:40:56 --> Language Class Initialized
INFO - 2022-03-09 03:40:56 --> Loader Class Initialized
INFO - 2022-03-09 03:40:56 --> Helper loaded: url_helper
INFO - 2022-03-09 03:40:56 --> Helper loaded: form_helper
INFO - 2022-03-09 03:40:56 --> Helper loaded: common_helper
INFO - 2022-03-09 03:40:56 --> Database Driver Class Initialized
DEBUG - 2022-03-09 03:40:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 03:40:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 03:40:56 --> Controller Class Initialized
INFO - 2022-03-09 03:40:56 --> Form Validation Class Initialized
DEBUG - 2022-03-09 03:40:56 --> Encrypt Class Initialized
INFO - 2022-03-09 03:40:56 --> Model "Patient_model" initialized
INFO - 2022-03-09 03:40:56 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 03:40:56 --> Model "Referredby_model" initialized
INFO - 2022-03-09 03:40:56 --> Model "Prefix_master" initialized
INFO - 2022-03-09 03:40:56 --> Model "Hospital_model" initialized
INFO - 2022-03-09 03:40:56 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 03:41:02 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-09 03:41:02 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 03:41:04 --> Final output sent to browser
DEBUG - 2022-03-09 03:41:04 --> Total execution time: 6.0191
ERROR - 2022-03-09 03:42:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 03:42:43 --> Config Class Initialized
INFO - 2022-03-09 03:42:43 --> Hooks Class Initialized
DEBUG - 2022-03-09 03:42:43 --> UTF-8 Support Enabled
INFO - 2022-03-09 03:42:43 --> Utf8 Class Initialized
INFO - 2022-03-09 03:42:43 --> URI Class Initialized
INFO - 2022-03-09 03:42:43 --> Router Class Initialized
INFO - 2022-03-09 03:42:43 --> Output Class Initialized
INFO - 2022-03-09 03:42:43 --> Security Class Initialized
DEBUG - 2022-03-09 03:42:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 03:42:43 --> Input Class Initialized
INFO - 2022-03-09 03:42:43 --> Language Class Initialized
INFO - 2022-03-09 03:42:43 --> Loader Class Initialized
INFO - 2022-03-09 03:42:43 --> Helper loaded: url_helper
INFO - 2022-03-09 03:42:43 --> Helper loaded: form_helper
INFO - 2022-03-09 03:42:43 --> Helper loaded: common_helper
INFO - 2022-03-09 03:42:43 --> Database Driver Class Initialized
DEBUG - 2022-03-09 03:42:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 03:42:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 03:42:43 --> Controller Class Initialized
INFO - 2022-03-09 03:42:43 --> Form Validation Class Initialized
DEBUG - 2022-03-09 03:42:43 --> Encrypt Class Initialized
INFO - 2022-03-09 03:42:43 --> Model "Patient_model" initialized
INFO - 2022-03-09 03:42:43 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 03:42:43 --> Model "Prefix_master" initialized
INFO - 2022-03-09 03:42:43 --> Model "Users_model" initialized
INFO - 2022-03-09 03:42:43 --> Model "Hospital_model" initialized
INFO - 2022-03-09 03:42:43 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 03:42:43 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-09 03:42:43 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 03:42:43 --> Final output sent to browser
DEBUG - 2022-03-09 03:42:43 --> Total execution time: 0.0746
ERROR - 2022-03-09 03:45:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 03:45:11 --> Config Class Initialized
INFO - 2022-03-09 03:45:11 --> Hooks Class Initialized
DEBUG - 2022-03-09 03:45:11 --> UTF-8 Support Enabled
INFO - 2022-03-09 03:45:11 --> Utf8 Class Initialized
INFO - 2022-03-09 03:45:11 --> URI Class Initialized
INFO - 2022-03-09 03:45:11 --> Router Class Initialized
INFO - 2022-03-09 03:45:11 --> Output Class Initialized
INFO - 2022-03-09 03:45:11 --> Security Class Initialized
DEBUG - 2022-03-09 03:45:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 03:45:11 --> Input Class Initialized
INFO - 2022-03-09 03:45:11 --> Language Class Initialized
INFO - 2022-03-09 03:45:11 --> Loader Class Initialized
INFO - 2022-03-09 03:45:11 --> Helper loaded: url_helper
INFO - 2022-03-09 03:45:11 --> Helper loaded: form_helper
INFO - 2022-03-09 03:45:11 --> Helper loaded: common_helper
INFO - 2022-03-09 03:45:11 --> Database Driver Class Initialized
DEBUG - 2022-03-09 03:45:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 03:45:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 03:45:11 --> Controller Class Initialized
INFO - 2022-03-09 03:45:11 --> Form Validation Class Initialized
DEBUG - 2022-03-09 03:45:11 --> Encrypt Class Initialized
INFO - 2022-03-09 03:45:11 --> Model "Patient_model" initialized
INFO - 2022-03-09 03:45:11 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 03:45:11 --> Model "Prefix_master" initialized
INFO - 2022-03-09 03:45:11 --> Model "Users_model" initialized
INFO - 2022-03-09 03:45:11 --> Model "Hospital_model" initialized
ERROR - 2022-03-09 03:45:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 03:45:12 --> Config Class Initialized
INFO - 2022-03-09 03:45:12 --> Hooks Class Initialized
DEBUG - 2022-03-09 03:45:12 --> UTF-8 Support Enabled
INFO - 2022-03-09 03:45:12 --> Utf8 Class Initialized
INFO - 2022-03-09 03:45:12 --> URI Class Initialized
INFO - 2022-03-09 03:45:12 --> Router Class Initialized
INFO - 2022-03-09 03:45:12 --> Output Class Initialized
INFO - 2022-03-09 03:45:12 --> Security Class Initialized
DEBUG - 2022-03-09 03:45:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 03:45:12 --> Input Class Initialized
INFO - 2022-03-09 03:45:12 --> Language Class Initialized
INFO - 2022-03-09 03:45:12 --> Loader Class Initialized
INFO - 2022-03-09 03:45:12 --> Helper loaded: url_helper
INFO - 2022-03-09 03:45:12 --> Helper loaded: form_helper
INFO - 2022-03-09 03:45:12 --> Helper loaded: common_helper
INFO - 2022-03-09 03:45:12 --> Database Driver Class Initialized
DEBUG - 2022-03-09 03:45:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 03:45:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 03:45:12 --> Controller Class Initialized
INFO - 2022-03-09 03:45:12 --> Form Validation Class Initialized
DEBUG - 2022-03-09 03:45:12 --> Encrypt Class Initialized
INFO - 2022-03-09 03:45:12 --> Model "Patient_model" initialized
INFO - 2022-03-09 03:45:12 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 03:45:12 --> Model "Prefix_master" initialized
INFO - 2022-03-09 03:45:12 --> Model "Users_model" initialized
INFO - 2022-03-09 03:45:12 --> Model "Hospital_model" initialized
INFO - 2022-03-09 03:45:12 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 03:45:12 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-09 03:45:12 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 03:45:12 --> Final output sent to browser
DEBUG - 2022-03-09 03:45:12 --> Total execution time: 0.0966
ERROR - 2022-03-09 03:47:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 03:47:03 --> Config Class Initialized
INFO - 2022-03-09 03:47:03 --> Hooks Class Initialized
DEBUG - 2022-03-09 03:47:03 --> UTF-8 Support Enabled
INFO - 2022-03-09 03:47:03 --> Utf8 Class Initialized
INFO - 2022-03-09 03:47:03 --> URI Class Initialized
INFO - 2022-03-09 03:47:03 --> Router Class Initialized
INFO - 2022-03-09 03:47:03 --> Output Class Initialized
INFO - 2022-03-09 03:47:03 --> Security Class Initialized
DEBUG - 2022-03-09 03:47:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 03:47:03 --> Input Class Initialized
INFO - 2022-03-09 03:47:03 --> Language Class Initialized
INFO - 2022-03-09 03:47:03 --> Loader Class Initialized
INFO - 2022-03-09 03:47:03 --> Helper loaded: url_helper
INFO - 2022-03-09 03:47:03 --> Helper loaded: form_helper
INFO - 2022-03-09 03:47:03 --> Helper loaded: common_helper
INFO - 2022-03-09 03:47:03 --> Database Driver Class Initialized
DEBUG - 2022-03-09 03:47:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 03:47:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 03:47:03 --> Controller Class Initialized
INFO - 2022-03-09 03:47:03 --> Form Validation Class Initialized
DEBUG - 2022-03-09 03:47:03 --> Encrypt Class Initialized
INFO - 2022-03-09 03:47:03 --> Model "Patient_model" initialized
INFO - 2022-03-09 03:47:03 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 03:47:03 --> Model "Prefix_master" initialized
INFO - 2022-03-09 03:47:03 --> Model "Users_model" initialized
INFO - 2022-03-09 03:47:03 --> Model "Hospital_model" initialized
ERROR - 2022-03-09 03:47:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 03:47:04 --> Config Class Initialized
INFO - 2022-03-09 03:47:04 --> Hooks Class Initialized
DEBUG - 2022-03-09 03:47:04 --> UTF-8 Support Enabled
INFO - 2022-03-09 03:47:04 --> Utf8 Class Initialized
INFO - 2022-03-09 03:47:04 --> URI Class Initialized
INFO - 2022-03-09 03:47:04 --> Router Class Initialized
INFO - 2022-03-09 03:47:04 --> Output Class Initialized
INFO - 2022-03-09 03:47:04 --> Security Class Initialized
DEBUG - 2022-03-09 03:47:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 03:47:04 --> Input Class Initialized
INFO - 2022-03-09 03:47:04 --> Language Class Initialized
INFO - 2022-03-09 03:47:04 --> Loader Class Initialized
INFO - 2022-03-09 03:47:04 --> Helper loaded: url_helper
INFO - 2022-03-09 03:47:04 --> Helper loaded: form_helper
INFO - 2022-03-09 03:47:04 --> Helper loaded: common_helper
INFO - 2022-03-09 03:47:04 --> Database Driver Class Initialized
DEBUG - 2022-03-09 03:47:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 03:47:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 03:47:04 --> Controller Class Initialized
INFO - 2022-03-09 03:47:04 --> Form Validation Class Initialized
DEBUG - 2022-03-09 03:47:04 --> Encrypt Class Initialized
INFO - 2022-03-09 03:47:04 --> Model "Patient_model" initialized
INFO - 2022-03-09 03:47:04 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 03:47:04 --> Model "Prefix_master" initialized
INFO - 2022-03-09 03:47:04 --> Model "Users_model" initialized
INFO - 2022-03-09 03:47:04 --> Model "Hospital_model" initialized
INFO - 2022-03-09 03:47:04 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 03:47:04 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-09 03:47:04 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 03:47:04 --> Final output sent to browser
DEBUG - 2022-03-09 03:47:04 --> Total execution time: 0.0710
ERROR - 2022-03-09 03:47:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 03:47:27 --> Config Class Initialized
INFO - 2022-03-09 03:47:27 --> Hooks Class Initialized
DEBUG - 2022-03-09 03:47:27 --> UTF-8 Support Enabled
INFO - 2022-03-09 03:47:27 --> Utf8 Class Initialized
INFO - 2022-03-09 03:47:27 --> URI Class Initialized
INFO - 2022-03-09 03:47:27 --> Router Class Initialized
INFO - 2022-03-09 03:47:27 --> Output Class Initialized
INFO - 2022-03-09 03:47:27 --> Security Class Initialized
DEBUG - 2022-03-09 03:47:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 03:47:27 --> Input Class Initialized
INFO - 2022-03-09 03:47:27 --> Language Class Initialized
INFO - 2022-03-09 03:47:27 --> Loader Class Initialized
INFO - 2022-03-09 03:47:27 --> Helper loaded: url_helper
INFO - 2022-03-09 03:47:27 --> Helper loaded: form_helper
INFO - 2022-03-09 03:47:27 --> Helper loaded: common_helper
INFO - 2022-03-09 03:47:27 --> Database Driver Class Initialized
DEBUG - 2022-03-09 03:47:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 03:47:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 03:47:27 --> Controller Class Initialized
INFO - 2022-03-09 03:47:27 --> Form Validation Class Initialized
DEBUG - 2022-03-09 03:47:27 --> Encrypt Class Initialized
INFO - 2022-03-09 03:47:27 --> Model "Patient_model" initialized
INFO - 2022-03-09 03:47:27 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 03:47:27 --> Model "Prefix_master" initialized
INFO - 2022-03-09 03:47:27 --> Model "Users_model" initialized
INFO - 2022-03-09 03:47:27 --> Model "Hospital_model" initialized
ERROR - 2022-03-09 03:47:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 03:47:27 --> Config Class Initialized
INFO - 2022-03-09 03:47:27 --> Hooks Class Initialized
DEBUG - 2022-03-09 03:47:27 --> UTF-8 Support Enabled
INFO - 2022-03-09 03:47:27 --> Utf8 Class Initialized
INFO - 2022-03-09 03:47:27 --> URI Class Initialized
INFO - 2022-03-09 03:47:27 --> Router Class Initialized
INFO - 2022-03-09 03:47:27 --> Output Class Initialized
INFO - 2022-03-09 03:47:27 --> Security Class Initialized
DEBUG - 2022-03-09 03:47:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 03:47:27 --> Input Class Initialized
INFO - 2022-03-09 03:47:27 --> Language Class Initialized
INFO - 2022-03-09 03:47:27 --> Loader Class Initialized
INFO - 2022-03-09 03:47:27 --> Helper loaded: url_helper
INFO - 2022-03-09 03:47:27 --> Helper loaded: form_helper
INFO - 2022-03-09 03:47:27 --> Helper loaded: common_helper
INFO - 2022-03-09 03:47:27 --> Database Driver Class Initialized
DEBUG - 2022-03-09 03:47:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 03:47:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 03:47:27 --> Controller Class Initialized
INFO - 2022-03-09 03:47:27 --> Form Validation Class Initialized
DEBUG - 2022-03-09 03:47:27 --> Encrypt Class Initialized
INFO - 2022-03-09 03:47:27 --> Model "Patient_model" initialized
INFO - 2022-03-09 03:47:27 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 03:47:27 --> Model "Prefix_master" initialized
INFO - 2022-03-09 03:47:27 --> Model "Users_model" initialized
INFO - 2022-03-09 03:47:27 --> Model "Hospital_model" initialized
INFO - 2022-03-09 03:47:27 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 03:47:27 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-09 03:47:27 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 03:47:27 --> Final output sent to browser
DEBUG - 2022-03-09 03:47:27 --> Total execution time: 0.0534
ERROR - 2022-03-09 03:48:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 03:48:09 --> Config Class Initialized
INFO - 2022-03-09 03:48:09 --> Hooks Class Initialized
DEBUG - 2022-03-09 03:48:09 --> UTF-8 Support Enabled
INFO - 2022-03-09 03:48:09 --> Utf8 Class Initialized
INFO - 2022-03-09 03:48:09 --> URI Class Initialized
INFO - 2022-03-09 03:48:09 --> Router Class Initialized
INFO - 2022-03-09 03:48:09 --> Output Class Initialized
INFO - 2022-03-09 03:48:09 --> Security Class Initialized
DEBUG - 2022-03-09 03:48:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 03:48:09 --> Input Class Initialized
INFO - 2022-03-09 03:48:09 --> Language Class Initialized
INFO - 2022-03-09 03:48:09 --> Loader Class Initialized
INFO - 2022-03-09 03:48:09 --> Helper loaded: url_helper
INFO - 2022-03-09 03:48:09 --> Helper loaded: form_helper
INFO - 2022-03-09 03:48:09 --> Helper loaded: common_helper
INFO - 2022-03-09 03:48:09 --> Database Driver Class Initialized
DEBUG - 2022-03-09 03:48:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 03:48:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 03:48:09 --> Controller Class Initialized
INFO - 2022-03-09 03:48:09 --> Form Validation Class Initialized
DEBUG - 2022-03-09 03:48:09 --> Encrypt Class Initialized
INFO - 2022-03-09 03:48:09 --> Model "Patient_model" initialized
INFO - 2022-03-09 03:48:09 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 03:48:09 --> Model "Referredby_model" initialized
INFO - 2022-03-09 03:48:09 --> Model "Prefix_master" initialized
INFO - 2022-03-09 03:48:09 --> Model "Hospital_model" initialized
INFO - 2022-03-09 03:48:09 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 03:48:15 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-09 03:48:15 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
ERROR - 2022-03-09 03:48:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 03:48:17 --> Config Class Initialized
INFO - 2022-03-09 03:48:17 --> Hooks Class Initialized
DEBUG - 2022-03-09 03:48:17 --> UTF-8 Support Enabled
INFO - 2022-03-09 03:48:17 --> Utf8 Class Initialized
INFO - 2022-03-09 03:48:17 --> URI Class Initialized
INFO - 2022-03-09 03:48:17 --> Router Class Initialized
INFO - 2022-03-09 03:48:17 --> Output Class Initialized
INFO - 2022-03-09 03:48:17 --> Security Class Initialized
DEBUG - 2022-03-09 03:48:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 03:48:17 --> Input Class Initialized
INFO - 2022-03-09 03:48:17 --> Language Class Initialized
ERROR - 2022-03-09 03:48:17 --> 404 Page Not Found: Karoclient/usersprofile
INFO - 2022-03-09 03:48:17 --> Final output sent to browser
DEBUG - 2022-03-09 03:48:17 --> Total execution time: 6.3723
ERROR - 2022-03-09 03:48:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 03:48:22 --> Config Class Initialized
INFO - 2022-03-09 03:48:22 --> Hooks Class Initialized
DEBUG - 2022-03-09 03:48:22 --> UTF-8 Support Enabled
INFO - 2022-03-09 03:48:22 --> Utf8 Class Initialized
INFO - 2022-03-09 03:48:22 --> URI Class Initialized
INFO - 2022-03-09 03:48:22 --> Router Class Initialized
INFO - 2022-03-09 03:48:22 --> Output Class Initialized
INFO - 2022-03-09 03:48:22 --> Security Class Initialized
DEBUG - 2022-03-09 03:48:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 03:48:22 --> Input Class Initialized
INFO - 2022-03-09 03:48:22 --> Language Class Initialized
INFO - 2022-03-09 03:48:22 --> Loader Class Initialized
INFO - 2022-03-09 03:48:22 --> Helper loaded: url_helper
INFO - 2022-03-09 03:48:22 --> Helper loaded: form_helper
INFO - 2022-03-09 03:48:22 --> Helper loaded: common_helper
INFO - 2022-03-09 03:48:22 --> Database Driver Class Initialized
DEBUG - 2022-03-09 03:48:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 03:48:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 03:48:22 --> Controller Class Initialized
INFO - 2022-03-09 03:48:22 --> Form Validation Class Initialized
DEBUG - 2022-03-09 03:48:22 --> Encrypt Class Initialized
INFO - 2022-03-09 03:48:22 --> Model "Patient_model" initialized
INFO - 2022-03-09 03:48:22 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 03:48:22 --> Model "Referredby_model" initialized
INFO - 2022-03-09 03:48:22 --> Model "Prefix_master" initialized
INFO - 2022-03-09 03:48:22 --> Model "Hospital_model" initialized
INFO - 2022-03-09 03:48:22 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 03:48:22 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-09 03:48:22 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 03:48:22 --> Final output sent to browser
DEBUG - 2022-03-09 03:48:22 --> Total execution time: 0.0731
ERROR - 2022-03-09 03:48:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 03:48:35 --> Config Class Initialized
INFO - 2022-03-09 03:48:35 --> Hooks Class Initialized
DEBUG - 2022-03-09 03:48:35 --> UTF-8 Support Enabled
INFO - 2022-03-09 03:48:35 --> Utf8 Class Initialized
INFO - 2022-03-09 03:48:35 --> URI Class Initialized
INFO - 2022-03-09 03:48:35 --> Router Class Initialized
INFO - 2022-03-09 03:48:35 --> Output Class Initialized
INFO - 2022-03-09 03:48:35 --> Security Class Initialized
DEBUG - 2022-03-09 03:48:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 03:48:35 --> Input Class Initialized
INFO - 2022-03-09 03:48:35 --> Language Class Initialized
INFO - 2022-03-09 03:48:35 --> Loader Class Initialized
INFO - 2022-03-09 03:48:35 --> Helper loaded: url_helper
INFO - 2022-03-09 03:48:35 --> Helper loaded: form_helper
INFO - 2022-03-09 03:48:35 --> Helper loaded: common_helper
INFO - 2022-03-09 03:48:35 --> Database Driver Class Initialized
DEBUG - 2022-03-09 03:48:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 03:48:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 03:48:35 --> Controller Class Initialized
INFO - 2022-03-09 03:48:35 --> Form Validation Class Initialized
DEBUG - 2022-03-09 03:48:35 --> Encrypt Class Initialized
INFO - 2022-03-09 03:48:35 --> Model "Patient_model" initialized
INFO - 2022-03-09 03:48:35 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 03:48:35 --> Model "Prefix_master" initialized
INFO - 2022-03-09 03:48:35 --> Model "Users_model" initialized
INFO - 2022-03-09 03:48:35 --> Model "Hospital_model" initialized
INFO - 2022-03-09 03:48:35 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 03:48:35 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-09 03:48:35 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 03:48:35 --> Final output sent to browser
DEBUG - 2022-03-09 03:48:35 --> Total execution time: 0.0595
ERROR - 2022-03-09 03:48:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 03:48:54 --> Config Class Initialized
INFO - 2022-03-09 03:48:54 --> Hooks Class Initialized
DEBUG - 2022-03-09 03:48:54 --> UTF-8 Support Enabled
INFO - 2022-03-09 03:48:54 --> Utf8 Class Initialized
INFO - 2022-03-09 03:48:54 --> URI Class Initialized
INFO - 2022-03-09 03:48:54 --> Router Class Initialized
INFO - 2022-03-09 03:48:54 --> Output Class Initialized
INFO - 2022-03-09 03:48:54 --> Security Class Initialized
DEBUG - 2022-03-09 03:48:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 03:48:54 --> Input Class Initialized
INFO - 2022-03-09 03:48:54 --> Language Class Initialized
INFO - 2022-03-09 03:48:54 --> Loader Class Initialized
INFO - 2022-03-09 03:48:54 --> Helper loaded: url_helper
INFO - 2022-03-09 03:48:54 --> Helper loaded: form_helper
INFO - 2022-03-09 03:48:54 --> Helper loaded: common_helper
INFO - 2022-03-09 03:48:54 --> Database Driver Class Initialized
DEBUG - 2022-03-09 03:48:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 03:48:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 03:48:54 --> Controller Class Initialized
INFO - 2022-03-09 03:48:54 --> Form Validation Class Initialized
DEBUG - 2022-03-09 03:48:54 --> Encrypt Class Initialized
INFO - 2022-03-09 03:48:54 --> Model "Patient_model" initialized
INFO - 2022-03-09 03:48:54 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 03:48:54 --> Model "Prefix_master" initialized
INFO - 2022-03-09 03:48:54 --> Model "Users_model" initialized
INFO - 2022-03-09 03:48:54 --> Model "Hospital_model" initialized
INFO - 2022-03-09 03:48:54 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 03:48:54 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-09 03:48:54 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 03:48:54 --> Final output sent to browser
DEBUG - 2022-03-09 03:48:54 --> Total execution time: 0.0699
ERROR - 2022-03-09 03:48:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 03:48:55 --> Config Class Initialized
INFO - 2022-03-09 03:48:55 --> Hooks Class Initialized
DEBUG - 2022-03-09 03:48:55 --> UTF-8 Support Enabled
INFO - 2022-03-09 03:48:55 --> Utf8 Class Initialized
INFO - 2022-03-09 03:48:55 --> URI Class Initialized
INFO - 2022-03-09 03:48:55 --> Router Class Initialized
INFO - 2022-03-09 03:48:55 --> Output Class Initialized
INFO - 2022-03-09 03:48:55 --> Security Class Initialized
DEBUG - 2022-03-09 03:48:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 03:48:55 --> Input Class Initialized
INFO - 2022-03-09 03:48:55 --> Language Class Initialized
ERROR - 2022-03-09 03:48:55 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-09 03:59:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 03:59:29 --> Config Class Initialized
INFO - 2022-03-09 03:59:29 --> Hooks Class Initialized
DEBUG - 2022-03-09 03:59:29 --> UTF-8 Support Enabled
INFO - 2022-03-09 03:59:29 --> Utf8 Class Initialized
INFO - 2022-03-09 03:59:29 --> URI Class Initialized
INFO - 2022-03-09 03:59:29 --> Router Class Initialized
INFO - 2022-03-09 03:59:29 --> Output Class Initialized
INFO - 2022-03-09 03:59:29 --> Security Class Initialized
DEBUG - 2022-03-09 03:59:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 03:59:29 --> Input Class Initialized
INFO - 2022-03-09 03:59:29 --> Language Class Initialized
INFO - 2022-03-09 03:59:29 --> Loader Class Initialized
INFO - 2022-03-09 03:59:29 --> Helper loaded: url_helper
INFO - 2022-03-09 03:59:29 --> Helper loaded: form_helper
INFO - 2022-03-09 03:59:29 --> Helper loaded: common_helper
INFO - 2022-03-09 03:59:29 --> Database Driver Class Initialized
DEBUG - 2022-03-09 03:59:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 03:59:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 03:59:29 --> Controller Class Initialized
INFO - 2022-03-09 03:59:29 --> Form Validation Class Initialized
DEBUG - 2022-03-09 03:59:29 --> Encrypt Class Initialized
INFO - 2022-03-09 03:59:29 --> Model "Patient_model" initialized
INFO - 2022-03-09 03:59:29 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 03:59:29 --> Model "Prefix_master" initialized
INFO - 2022-03-09 03:59:29 --> Model "Users_model" initialized
INFO - 2022-03-09 03:59:29 --> Model "Hospital_model" initialized
ERROR - 2022-03-09 03:59:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 03:59:30 --> Config Class Initialized
INFO - 2022-03-09 03:59:30 --> Hooks Class Initialized
DEBUG - 2022-03-09 03:59:30 --> UTF-8 Support Enabled
INFO - 2022-03-09 03:59:30 --> Utf8 Class Initialized
INFO - 2022-03-09 03:59:30 --> URI Class Initialized
INFO - 2022-03-09 03:59:30 --> Router Class Initialized
INFO - 2022-03-09 03:59:30 --> Output Class Initialized
INFO - 2022-03-09 03:59:30 --> Security Class Initialized
DEBUG - 2022-03-09 03:59:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 03:59:30 --> Input Class Initialized
INFO - 2022-03-09 03:59:30 --> Language Class Initialized
INFO - 2022-03-09 03:59:30 --> Loader Class Initialized
INFO - 2022-03-09 03:59:30 --> Helper loaded: url_helper
INFO - 2022-03-09 03:59:30 --> Helper loaded: form_helper
INFO - 2022-03-09 03:59:30 --> Helper loaded: common_helper
INFO - 2022-03-09 03:59:30 --> Database Driver Class Initialized
DEBUG - 2022-03-09 03:59:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 03:59:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 03:59:30 --> Controller Class Initialized
INFO - 2022-03-09 03:59:30 --> Form Validation Class Initialized
DEBUG - 2022-03-09 03:59:30 --> Encrypt Class Initialized
INFO - 2022-03-09 03:59:30 --> Model "Patient_model" initialized
INFO - 2022-03-09 03:59:30 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 03:59:30 --> Model "Prefix_master" initialized
INFO - 2022-03-09 03:59:30 --> Model "Users_model" initialized
INFO - 2022-03-09 03:59:30 --> Model "Hospital_model" initialized
INFO - 2022-03-09 03:59:30 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 03:59:30 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-09 03:59:30 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 03:59:30 --> Final output sent to browser
DEBUG - 2022-03-09 03:59:30 --> Total execution time: 0.0818
ERROR - 2022-03-09 04:00:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 04:00:55 --> Config Class Initialized
INFO - 2022-03-09 04:00:55 --> Hooks Class Initialized
DEBUG - 2022-03-09 04:00:55 --> UTF-8 Support Enabled
INFO - 2022-03-09 04:00:55 --> Utf8 Class Initialized
INFO - 2022-03-09 04:00:55 --> URI Class Initialized
INFO - 2022-03-09 04:00:55 --> Router Class Initialized
INFO - 2022-03-09 04:00:55 --> Output Class Initialized
INFO - 2022-03-09 04:00:55 --> Security Class Initialized
DEBUG - 2022-03-09 04:00:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 04:00:55 --> Input Class Initialized
INFO - 2022-03-09 04:00:55 --> Language Class Initialized
INFO - 2022-03-09 04:00:55 --> Loader Class Initialized
INFO - 2022-03-09 04:00:55 --> Helper loaded: url_helper
INFO - 2022-03-09 04:00:55 --> Helper loaded: form_helper
INFO - 2022-03-09 04:00:55 --> Helper loaded: common_helper
INFO - 2022-03-09 04:00:55 --> Database Driver Class Initialized
DEBUG - 2022-03-09 04:00:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 04:00:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 04:00:55 --> Controller Class Initialized
INFO - 2022-03-09 04:00:55 --> Form Validation Class Initialized
DEBUG - 2022-03-09 04:00:55 --> Encrypt Class Initialized
INFO - 2022-03-09 04:00:55 --> Model "Patient_model" initialized
INFO - 2022-03-09 04:00:55 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 04:00:55 --> Model "Referredby_model" initialized
INFO - 2022-03-09 04:00:55 --> Model "Prefix_master" initialized
INFO - 2022-03-09 04:00:55 --> Model "Hospital_model" initialized
INFO - 2022-03-09 04:00:55 --> File loaded: /home3/karoteam/public_html/application/views/header.php
ERROR - 2022-03-09 04:00:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 04:00:59 --> Config Class Initialized
INFO - 2022-03-09 04:00:59 --> Hooks Class Initialized
DEBUG - 2022-03-09 04:00:59 --> UTF-8 Support Enabled
INFO - 2022-03-09 04:00:59 --> Utf8 Class Initialized
INFO - 2022-03-09 04:00:59 --> URI Class Initialized
INFO - 2022-03-09 04:00:59 --> Router Class Initialized
INFO - 2022-03-09 04:00:59 --> Output Class Initialized
INFO - 2022-03-09 04:00:59 --> Security Class Initialized
DEBUG - 2022-03-09 04:00:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 04:00:59 --> Input Class Initialized
INFO - 2022-03-09 04:00:59 --> Language Class Initialized
INFO - 2022-03-09 04:00:59 --> Loader Class Initialized
INFO - 2022-03-09 04:00:59 --> Helper loaded: url_helper
INFO - 2022-03-09 04:00:59 --> Helper loaded: form_helper
INFO - 2022-03-09 04:00:59 --> Helper loaded: common_helper
INFO - 2022-03-09 04:00:59 --> Database Driver Class Initialized
DEBUG - 2022-03-09 04:00:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 04:00:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 04:00:59 --> Controller Class Initialized
INFO - 2022-03-09 04:00:59 --> Form Validation Class Initialized
DEBUG - 2022-03-09 04:00:59 --> Encrypt Class Initialized
INFO - 2022-03-09 04:00:59 --> Model "Patient_model" initialized
INFO - 2022-03-09 04:00:59 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 04:00:59 --> Model "Referredby_model" initialized
INFO - 2022-03-09 04:00:59 --> Model "Prefix_master" initialized
INFO - 2022-03-09 04:00:59 --> Model "Hospital_model" initialized
INFO - 2022-03-09 04:00:59 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 04:01:05 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-09 04:01:05 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 04:01:08 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-09 04:01:08 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 04:01:10 --> Final output sent to browser
DEBUG - 2022-03-09 04:01:10 --> Total execution time: 8.4826
ERROR - 2022-03-09 04:01:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 04:01:18 --> Config Class Initialized
INFO - 2022-03-09 04:01:18 --> Hooks Class Initialized
DEBUG - 2022-03-09 04:01:18 --> UTF-8 Support Enabled
INFO - 2022-03-09 04:01:18 --> Utf8 Class Initialized
INFO - 2022-03-09 04:01:18 --> URI Class Initialized
INFO - 2022-03-09 04:01:18 --> Router Class Initialized
INFO - 2022-03-09 04:01:18 --> Output Class Initialized
INFO - 2022-03-09 04:01:18 --> Security Class Initialized
DEBUG - 2022-03-09 04:01:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 04:01:18 --> Input Class Initialized
INFO - 2022-03-09 04:01:18 --> Language Class Initialized
ERROR - 2022-03-09 04:01:18 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-09 04:02:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 04:02:35 --> Config Class Initialized
INFO - 2022-03-09 04:02:35 --> Hooks Class Initialized
DEBUG - 2022-03-09 04:02:35 --> UTF-8 Support Enabled
INFO - 2022-03-09 04:02:35 --> Utf8 Class Initialized
INFO - 2022-03-09 04:02:35 --> URI Class Initialized
INFO - 2022-03-09 04:02:35 --> Router Class Initialized
INFO - 2022-03-09 04:02:35 --> Output Class Initialized
INFO - 2022-03-09 04:02:35 --> Security Class Initialized
DEBUG - 2022-03-09 04:02:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 04:02:35 --> Input Class Initialized
INFO - 2022-03-09 04:02:35 --> Language Class Initialized
INFO - 2022-03-09 04:02:35 --> Loader Class Initialized
INFO - 2022-03-09 04:02:35 --> Helper loaded: url_helper
INFO - 2022-03-09 04:02:35 --> Helper loaded: form_helper
INFO - 2022-03-09 04:02:35 --> Helper loaded: common_helper
INFO - 2022-03-09 04:02:35 --> Database Driver Class Initialized
DEBUG - 2022-03-09 04:02:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 04:02:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 04:02:35 --> Controller Class Initialized
INFO - 2022-03-09 04:02:35 --> Form Validation Class Initialized
DEBUG - 2022-03-09 04:02:35 --> Encrypt Class Initialized
INFO - 2022-03-09 04:02:35 --> Model "Patient_model" initialized
INFO - 2022-03-09 04:02:35 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 04:02:35 --> Model "Referredby_model" initialized
INFO - 2022-03-09 04:02:35 --> Model "Prefix_master" initialized
INFO - 2022-03-09 04:02:35 --> Model "Hospital_model" initialized
INFO - 2022-03-09 04:02:35 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 04:02:41 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-09 04:02:41 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
ERROR - 2022-03-09 04:02:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 04:02:43 --> Config Class Initialized
INFO - 2022-03-09 04:02:43 --> Hooks Class Initialized
DEBUG - 2022-03-09 04:02:43 --> UTF-8 Support Enabled
INFO - 2022-03-09 04:02:43 --> Utf8 Class Initialized
INFO - 2022-03-09 04:02:43 --> URI Class Initialized
INFO - 2022-03-09 04:02:43 --> Router Class Initialized
INFO - 2022-03-09 04:02:43 --> Output Class Initialized
INFO - 2022-03-09 04:02:43 --> Security Class Initialized
DEBUG - 2022-03-09 04:02:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 04:02:43 --> Input Class Initialized
INFO - 2022-03-09 04:02:43 --> Language Class Initialized
ERROR - 2022-03-09 04:02:43 --> 404 Page Not Found: Karoclient/usersprofile
INFO - 2022-03-09 04:02:48 --> Final output sent to browser
DEBUG - 2022-03-09 04:02:48 --> Total execution time: 6.5895
ERROR - 2022-03-09 04:03:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 04:03:43 --> Config Class Initialized
INFO - 2022-03-09 04:03:43 --> Hooks Class Initialized
DEBUG - 2022-03-09 04:03:43 --> UTF-8 Support Enabled
INFO - 2022-03-09 04:03:43 --> Utf8 Class Initialized
INFO - 2022-03-09 04:03:43 --> URI Class Initialized
INFO - 2022-03-09 04:03:43 --> Router Class Initialized
INFO - 2022-03-09 04:03:43 --> Output Class Initialized
INFO - 2022-03-09 04:03:43 --> Security Class Initialized
DEBUG - 2022-03-09 04:03:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 04:03:43 --> Input Class Initialized
INFO - 2022-03-09 04:03:43 --> Language Class Initialized
INFO - 2022-03-09 04:03:43 --> Loader Class Initialized
INFO - 2022-03-09 04:03:43 --> Helper loaded: url_helper
INFO - 2022-03-09 04:03:43 --> Helper loaded: form_helper
INFO - 2022-03-09 04:03:43 --> Helper loaded: common_helper
INFO - 2022-03-09 04:03:43 --> Database Driver Class Initialized
DEBUG - 2022-03-09 04:03:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 04:03:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 04:03:43 --> Controller Class Initialized
INFO - 2022-03-09 04:03:43 --> Form Validation Class Initialized
DEBUG - 2022-03-09 04:03:43 --> Encrypt Class Initialized
INFO - 2022-03-09 04:03:43 --> Model "Patient_model" initialized
INFO - 2022-03-09 04:03:43 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 04:03:43 --> Model "Prefix_master" initialized
INFO - 2022-03-09 04:03:43 --> Model "Users_model" initialized
INFO - 2022-03-09 04:03:43 --> Model "Hospital_model" initialized
INFO - 2022-03-09 04:03:43 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 04:03:43 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-09 04:03:43 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 04:03:43 --> Final output sent to browser
DEBUG - 2022-03-09 04:03:43 --> Total execution time: 0.1218
ERROR - 2022-03-09 04:03:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 04:03:44 --> Config Class Initialized
INFO - 2022-03-09 04:03:44 --> Hooks Class Initialized
DEBUG - 2022-03-09 04:03:44 --> UTF-8 Support Enabled
INFO - 2022-03-09 04:03:44 --> Utf8 Class Initialized
INFO - 2022-03-09 04:03:44 --> URI Class Initialized
INFO - 2022-03-09 04:03:44 --> Router Class Initialized
INFO - 2022-03-09 04:03:44 --> Output Class Initialized
INFO - 2022-03-09 04:03:44 --> Security Class Initialized
DEBUG - 2022-03-09 04:03:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 04:03:44 --> Input Class Initialized
INFO - 2022-03-09 04:03:44 --> Language Class Initialized
ERROR - 2022-03-09 04:03:44 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-09 04:04:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 04:04:02 --> Config Class Initialized
INFO - 2022-03-09 04:04:02 --> Hooks Class Initialized
DEBUG - 2022-03-09 04:04:02 --> UTF-8 Support Enabled
INFO - 2022-03-09 04:04:02 --> Utf8 Class Initialized
INFO - 2022-03-09 04:04:02 --> URI Class Initialized
INFO - 2022-03-09 04:04:02 --> Router Class Initialized
INFO - 2022-03-09 04:04:02 --> Output Class Initialized
INFO - 2022-03-09 04:04:02 --> Security Class Initialized
DEBUG - 2022-03-09 04:04:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 04:04:02 --> Input Class Initialized
INFO - 2022-03-09 04:04:02 --> Language Class Initialized
INFO - 2022-03-09 04:04:02 --> Loader Class Initialized
INFO - 2022-03-09 04:04:02 --> Helper loaded: url_helper
INFO - 2022-03-09 04:04:02 --> Helper loaded: form_helper
INFO - 2022-03-09 04:04:02 --> Helper loaded: common_helper
INFO - 2022-03-09 04:04:02 --> Database Driver Class Initialized
DEBUG - 2022-03-09 04:04:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 04:04:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 04:04:02 --> Controller Class Initialized
INFO - 2022-03-09 04:04:02 --> Form Validation Class Initialized
DEBUG - 2022-03-09 04:04:02 --> Encrypt Class Initialized
INFO - 2022-03-09 04:04:02 --> Model "Patient_model" initialized
INFO - 2022-03-09 04:04:02 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 04:04:02 --> Model "Referredby_model" initialized
INFO - 2022-03-09 04:04:02 --> Model "Prefix_master" initialized
INFO - 2022-03-09 04:04:02 --> Model "Hospital_model" initialized
INFO - 2022-03-09 04:04:02 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 04:04:11 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-09 04:04:11 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
ERROR - 2022-03-09 04:04:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 04:04:12 --> Config Class Initialized
INFO - 2022-03-09 04:04:12 --> Hooks Class Initialized
DEBUG - 2022-03-09 04:04:12 --> UTF-8 Support Enabled
INFO - 2022-03-09 04:04:12 --> Utf8 Class Initialized
INFO - 2022-03-09 04:04:12 --> URI Class Initialized
INFO - 2022-03-09 04:04:12 --> Router Class Initialized
INFO - 2022-03-09 04:04:12 --> Output Class Initialized
INFO - 2022-03-09 04:04:12 --> Security Class Initialized
DEBUG - 2022-03-09 04:04:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 04:04:12 --> Input Class Initialized
INFO - 2022-03-09 04:04:12 --> Language Class Initialized
ERROR - 2022-03-09 04:04:12 --> 404 Page Not Found: Karoclient/usersprofile
INFO - 2022-03-09 04:04:19 --> Final output sent to browser
DEBUG - 2022-03-09 04:04:19 --> Total execution time: 8.4127
ERROR - 2022-03-09 04:05:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 04:05:10 --> Config Class Initialized
INFO - 2022-03-09 04:05:10 --> Hooks Class Initialized
DEBUG - 2022-03-09 04:05:10 --> UTF-8 Support Enabled
INFO - 2022-03-09 04:05:10 --> Utf8 Class Initialized
INFO - 2022-03-09 04:05:10 --> URI Class Initialized
INFO - 2022-03-09 04:05:10 --> Router Class Initialized
INFO - 2022-03-09 04:05:10 --> Output Class Initialized
INFO - 2022-03-09 04:05:10 --> Security Class Initialized
DEBUG - 2022-03-09 04:05:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 04:05:10 --> Input Class Initialized
INFO - 2022-03-09 04:05:10 --> Language Class Initialized
INFO - 2022-03-09 04:05:10 --> Loader Class Initialized
INFO - 2022-03-09 04:05:10 --> Helper loaded: url_helper
INFO - 2022-03-09 04:05:10 --> Helper loaded: form_helper
INFO - 2022-03-09 04:05:10 --> Helper loaded: common_helper
INFO - 2022-03-09 04:05:10 --> Database Driver Class Initialized
DEBUG - 2022-03-09 04:05:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 04:05:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 04:05:10 --> Controller Class Initialized
INFO - 2022-03-09 04:05:10 --> Form Validation Class Initialized
DEBUG - 2022-03-09 04:05:10 --> Encrypt Class Initialized
INFO - 2022-03-09 04:05:10 --> Model "Patient_model" initialized
INFO - 2022-03-09 04:05:10 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 04:05:10 --> Model "Referredby_model" initialized
INFO - 2022-03-09 04:05:10 --> Model "Prefix_master" initialized
INFO - 2022-03-09 04:05:10 --> Model "Hospital_model" initialized
INFO - 2022-03-09 04:05:10 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 04:05:10 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-09 04:05:10 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 04:05:10 --> Final output sent to browser
DEBUG - 2022-03-09 04:05:10 --> Total execution time: 0.0683
ERROR - 2022-03-09 04:05:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 04:05:11 --> Config Class Initialized
INFO - 2022-03-09 04:05:11 --> Hooks Class Initialized
DEBUG - 2022-03-09 04:05:11 --> UTF-8 Support Enabled
INFO - 2022-03-09 04:05:11 --> Utf8 Class Initialized
INFO - 2022-03-09 04:05:11 --> URI Class Initialized
INFO - 2022-03-09 04:05:11 --> Router Class Initialized
INFO - 2022-03-09 04:05:11 --> Output Class Initialized
INFO - 2022-03-09 04:05:11 --> Security Class Initialized
DEBUG - 2022-03-09 04:05:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 04:05:11 --> Input Class Initialized
INFO - 2022-03-09 04:05:11 --> Language Class Initialized
ERROR - 2022-03-09 04:05:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-03-09 04:05:11 --> 404 Page Not Found: Karoclient/usersprofile
INFO - 2022-03-09 04:05:11 --> Config Class Initialized
INFO - 2022-03-09 04:05:11 --> Hooks Class Initialized
DEBUG - 2022-03-09 04:05:11 --> UTF-8 Support Enabled
INFO - 2022-03-09 04:05:11 --> Utf8 Class Initialized
INFO - 2022-03-09 04:05:11 --> URI Class Initialized
INFO - 2022-03-09 04:05:11 --> Router Class Initialized
INFO - 2022-03-09 04:05:11 --> Output Class Initialized
INFO - 2022-03-09 04:05:11 --> Security Class Initialized
DEBUG - 2022-03-09 04:05:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 04:05:11 --> Input Class Initialized
INFO - 2022-03-09 04:05:11 --> Language Class Initialized
ERROR - 2022-03-09 04:05:11 --> 404 Page Not Found: Karoclient/images
ERROR - 2022-03-09 04:05:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 04:05:28 --> Config Class Initialized
INFO - 2022-03-09 04:05:28 --> Hooks Class Initialized
DEBUG - 2022-03-09 04:05:28 --> UTF-8 Support Enabled
INFO - 2022-03-09 04:05:28 --> Utf8 Class Initialized
INFO - 2022-03-09 04:05:28 --> URI Class Initialized
INFO - 2022-03-09 04:05:28 --> Router Class Initialized
INFO - 2022-03-09 04:05:28 --> Output Class Initialized
INFO - 2022-03-09 04:05:28 --> Security Class Initialized
DEBUG - 2022-03-09 04:05:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 04:05:28 --> Input Class Initialized
INFO - 2022-03-09 04:05:28 --> Language Class Initialized
INFO - 2022-03-09 04:05:28 --> Loader Class Initialized
INFO - 2022-03-09 04:05:28 --> Helper loaded: url_helper
INFO - 2022-03-09 04:05:28 --> Helper loaded: form_helper
INFO - 2022-03-09 04:05:28 --> Helper loaded: common_helper
INFO - 2022-03-09 04:05:28 --> Database Driver Class Initialized
DEBUG - 2022-03-09 04:05:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 04:05:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 04:05:28 --> Controller Class Initialized
INFO - 2022-03-09 04:05:28 --> Form Validation Class Initialized
DEBUG - 2022-03-09 04:05:28 --> Encrypt Class Initialized
INFO - 2022-03-09 04:05:28 --> Model "Patient_model" initialized
INFO - 2022-03-09 04:05:28 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 04:05:28 --> Model "Referredby_model" initialized
INFO - 2022-03-09 04:05:28 --> Model "Prefix_master" initialized
INFO - 2022-03-09 04:05:28 --> Model "Hospital_model" initialized
ERROR - 2022-03-09 04:05:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 04:05:28 --> Config Class Initialized
INFO - 2022-03-09 04:05:28 --> Hooks Class Initialized
DEBUG - 2022-03-09 04:05:28 --> UTF-8 Support Enabled
INFO - 2022-03-09 04:05:28 --> Utf8 Class Initialized
INFO - 2022-03-09 04:05:28 --> URI Class Initialized
INFO - 2022-03-09 04:05:28 --> Router Class Initialized
INFO - 2022-03-09 04:05:28 --> Output Class Initialized
INFO - 2022-03-09 04:05:28 --> Security Class Initialized
DEBUG - 2022-03-09 04:05:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 04:05:28 --> Input Class Initialized
INFO - 2022-03-09 04:05:28 --> Language Class Initialized
INFO - 2022-03-09 04:05:28 --> Loader Class Initialized
INFO - 2022-03-09 04:05:28 --> Helper loaded: url_helper
INFO - 2022-03-09 04:05:28 --> Helper loaded: form_helper
INFO - 2022-03-09 04:05:28 --> Helper loaded: common_helper
INFO - 2022-03-09 04:05:28 --> Database Driver Class Initialized
DEBUG - 2022-03-09 04:05:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 04:05:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 04:05:28 --> Controller Class Initialized
INFO - 2022-03-09 04:05:28 --> Form Validation Class Initialized
DEBUG - 2022-03-09 04:05:28 --> Encrypt Class Initialized
INFO - 2022-03-09 04:05:28 --> Model "Patient_model" initialized
INFO - 2022-03-09 04:05:28 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 04:05:28 --> Model "Referredby_model" initialized
INFO - 2022-03-09 04:05:28 --> Model "Prefix_master" initialized
INFO - 2022-03-09 04:05:28 --> Model "Hospital_model" initialized
INFO - 2022-03-09 04:05:28 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 04:05:28 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-09 04:05:28 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 04:05:28 --> Final output sent to browser
DEBUG - 2022-03-09 04:05:28 --> Total execution time: 0.0527
ERROR - 2022-03-09 04:05:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 04:05:29 --> Config Class Initialized
INFO - 2022-03-09 04:05:29 --> Hooks Class Initialized
DEBUG - 2022-03-09 04:05:29 --> UTF-8 Support Enabled
INFO - 2022-03-09 04:05:29 --> Utf8 Class Initialized
ERROR - 2022-03-09 04:05:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 04:05:29 --> URI Class Initialized
INFO - 2022-03-09 04:05:29 --> Config Class Initialized
INFO - 2022-03-09 04:05:29 --> Hooks Class Initialized
INFO - 2022-03-09 04:05:29 --> Router Class Initialized
INFO - 2022-03-09 04:05:29 --> Output Class Initialized
DEBUG - 2022-03-09 04:05:29 --> UTF-8 Support Enabled
INFO - 2022-03-09 04:05:29 --> Utf8 Class Initialized
INFO - 2022-03-09 04:05:29 --> Security Class Initialized
INFO - 2022-03-09 04:05:29 --> URI Class Initialized
DEBUG - 2022-03-09 04:05:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 04:05:29 --> Input Class Initialized
INFO - 2022-03-09 04:05:29 --> Router Class Initialized
INFO - 2022-03-09 04:05:29 --> Language Class Initialized
ERROR - 2022-03-09 04:05:29 --> 404 Page Not Found: Karoclient/usersprofile
INFO - 2022-03-09 04:05:29 --> Output Class Initialized
INFO - 2022-03-09 04:05:29 --> Security Class Initialized
DEBUG - 2022-03-09 04:05:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 04:05:29 --> Input Class Initialized
INFO - 2022-03-09 04:05:29 --> Language Class Initialized
ERROR - 2022-03-09 04:05:29 --> 404 Page Not Found: Karoclient/images
ERROR - 2022-03-09 04:05:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 04:05:29 --> Config Class Initialized
INFO - 2022-03-09 04:05:29 --> Hooks Class Initialized
DEBUG - 2022-03-09 04:05:29 --> UTF-8 Support Enabled
INFO - 2022-03-09 04:05:29 --> Utf8 Class Initialized
INFO - 2022-03-09 04:05:29 --> URI Class Initialized
INFO - 2022-03-09 04:05:29 --> Router Class Initialized
INFO - 2022-03-09 04:05:29 --> Output Class Initialized
INFO - 2022-03-09 04:05:29 --> Security Class Initialized
DEBUG - 2022-03-09 04:05:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 04:05:29 --> Input Class Initialized
INFO - 2022-03-09 04:05:29 --> Language Class Initialized
INFO - 2022-03-09 04:05:29 --> Loader Class Initialized
INFO - 2022-03-09 04:05:29 --> Helper loaded: url_helper
INFO - 2022-03-09 04:05:29 --> Helper loaded: form_helper
INFO - 2022-03-09 04:05:29 --> Helper loaded: common_helper
INFO - 2022-03-09 04:05:29 --> Database Driver Class Initialized
DEBUG - 2022-03-09 04:05:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 04:05:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 04:05:29 --> Controller Class Initialized
INFO - 2022-03-09 04:05:29 --> Form Validation Class Initialized
DEBUG - 2022-03-09 04:05:29 --> Encrypt Class Initialized
INFO - 2022-03-09 04:05:29 --> Model "Patient_model" initialized
INFO - 2022-03-09 04:05:29 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 04:05:29 --> Model "Prefix_master" initialized
INFO - 2022-03-09 04:05:29 --> Model "Users_model" initialized
INFO - 2022-03-09 04:05:29 --> Model "Hospital_model" initialized
INFO - 2022-03-09 04:05:29 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 04:05:29 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-09 04:05:29 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 04:05:29 --> Final output sent to browser
DEBUG - 2022-03-09 04:05:29 --> Total execution time: 0.0611
ERROR - 2022-03-09 04:05:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 04:05:30 --> Config Class Initialized
INFO - 2022-03-09 04:05:30 --> Hooks Class Initialized
DEBUG - 2022-03-09 04:05:30 --> UTF-8 Support Enabled
INFO - 2022-03-09 04:05:30 --> Utf8 Class Initialized
INFO - 2022-03-09 04:05:30 --> URI Class Initialized
INFO - 2022-03-09 04:05:30 --> Router Class Initialized
INFO - 2022-03-09 04:05:30 --> Output Class Initialized
INFO - 2022-03-09 04:05:30 --> Security Class Initialized
DEBUG - 2022-03-09 04:05:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 04:05:30 --> Input Class Initialized
INFO - 2022-03-09 04:05:30 --> Language Class Initialized
ERROR - 2022-03-09 04:05:30 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-09 04:06:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 04:06:00 --> Config Class Initialized
INFO - 2022-03-09 04:06:00 --> Hooks Class Initialized
DEBUG - 2022-03-09 04:06:00 --> UTF-8 Support Enabled
INFO - 2022-03-09 04:06:00 --> Utf8 Class Initialized
INFO - 2022-03-09 04:06:00 --> URI Class Initialized
INFO - 2022-03-09 04:06:00 --> Router Class Initialized
INFO - 2022-03-09 04:06:00 --> Output Class Initialized
INFO - 2022-03-09 04:06:00 --> Security Class Initialized
DEBUG - 2022-03-09 04:06:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 04:06:00 --> Input Class Initialized
INFO - 2022-03-09 04:06:00 --> Language Class Initialized
INFO - 2022-03-09 04:06:00 --> Loader Class Initialized
INFO - 2022-03-09 04:06:00 --> Helper loaded: url_helper
INFO - 2022-03-09 04:06:00 --> Helper loaded: form_helper
INFO - 2022-03-09 04:06:00 --> Helper loaded: common_helper
INFO - 2022-03-09 04:06:00 --> Database Driver Class Initialized
DEBUG - 2022-03-09 04:06:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 04:06:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 04:06:00 --> Controller Class Initialized
INFO - 2022-03-09 04:06:00 --> Form Validation Class Initialized
DEBUG - 2022-03-09 04:06:00 --> Encrypt Class Initialized
INFO - 2022-03-09 04:06:00 --> Model "Patient_model" initialized
INFO - 2022-03-09 04:06:00 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 04:06:00 --> Model "Referredby_model" initialized
INFO - 2022-03-09 04:06:00 --> Model "Prefix_master" initialized
INFO - 2022-03-09 04:06:00 --> Model "Hospital_model" initialized
INFO - 2022-03-09 04:06:00 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 04:06:07 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-09 04:06:07 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
ERROR - 2022-03-09 04:06:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 04:06:09 --> Config Class Initialized
INFO - 2022-03-09 04:06:09 --> Hooks Class Initialized
DEBUG - 2022-03-09 04:06:09 --> UTF-8 Support Enabled
INFO - 2022-03-09 04:06:09 --> Utf8 Class Initialized
INFO - 2022-03-09 04:06:09 --> URI Class Initialized
INFO - 2022-03-09 04:06:09 --> Router Class Initialized
INFO - 2022-03-09 04:06:09 --> Output Class Initialized
INFO - 2022-03-09 04:06:09 --> Security Class Initialized
DEBUG - 2022-03-09 04:06:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 04:06:09 --> Input Class Initialized
INFO - 2022-03-09 04:06:09 --> Language Class Initialized
ERROR - 2022-03-09 04:06:09 --> 404 Page Not Found: Karoclient/usersprofile
INFO - 2022-03-09 04:06:14 --> Final output sent to browser
DEBUG - 2022-03-09 04:06:14 --> Total execution time: 6.7707
ERROR - 2022-03-09 04:07:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 04:07:21 --> Config Class Initialized
INFO - 2022-03-09 04:07:21 --> Hooks Class Initialized
DEBUG - 2022-03-09 04:07:21 --> UTF-8 Support Enabled
INFO - 2022-03-09 04:07:21 --> Utf8 Class Initialized
INFO - 2022-03-09 04:07:21 --> URI Class Initialized
INFO - 2022-03-09 04:07:21 --> Router Class Initialized
INFO - 2022-03-09 04:07:21 --> Output Class Initialized
INFO - 2022-03-09 04:07:21 --> Security Class Initialized
DEBUG - 2022-03-09 04:07:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 04:07:21 --> Input Class Initialized
INFO - 2022-03-09 04:07:21 --> Language Class Initialized
INFO - 2022-03-09 04:07:21 --> Loader Class Initialized
INFO - 2022-03-09 04:07:21 --> Helper loaded: url_helper
INFO - 2022-03-09 04:07:21 --> Helper loaded: form_helper
INFO - 2022-03-09 04:07:21 --> Helper loaded: common_helper
INFO - 2022-03-09 04:07:21 --> Database Driver Class Initialized
DEBUG - 2022-03-09 04:07:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 04:07:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 04:07:21 --> Controller Class Initialized
INFO - 2022-03-09 04:07:21 --> Form Validation Class Initialized
DEBUG - 2022-03-09 04:07:21 --> Encrypt Class Initialized
INFO - 2022-03-09 04:07:21 --> Model "Patient_model" initialized
INFO - 2022-03-09 04:07:21 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 04:07:21 --> Model "Prefix_master" initialized
INFO - 2022-03-09 04:07:21 --> Model "Users_model" initialized
INFO - 2022-03-09 04:07:21 --> Model "Hospital_model" initialized
INFO - 2022-03-09 04:07:21 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 04:07:21 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-09 04:07:21 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 04:07:21 --> Final output sent to browser
DEBUG - 2022-03-09 04:07:21 --> Total execution time: 0.1036
ERROR - 2022-03-09 04:07:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 04:07:22 --> Config Class Initialized
INFO - 2022-03-09 04:07:22 --> Hooks Class Initialized
DEBUG - 2022-03-09 04:07:22 --> UTF-8 Support Enabled
INFO - 2022-03-09 04:07:22 --> Utf8 Class Initialized
INFO - 2022-03-09 04:07:22 --> URI Class Initialized
INFO - 2022-03-09 04:07:22 --> Router Class Initialized
INFO - 2022-03-09 04:07:22 --> Output Class Initialized
INFO - 2022-03-09 04:07:22 --> Security Class Initialized
DEBUG - 2022-03-09 04:07:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 04:07:22 --> Input Class Initialized
INFO - 2022-03-09 04:07:22 --> Language Class Initialized
ERROR - 2022-03-09 04:07:22 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-09 04:17:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 04:17:07 --> Config Class Initialized
INFO - 2022-03-09 04:17:07 --> Hooks Class Initialized
DEBUG - 2022-03-09 04:17:07 --> UTF-8 Support Enabled
INFO - 2022-03-09 04:17:07 --> Utf8 Class Initialized
INFO - 2022-03-09 04:17:07 --> URI Class Initialized
INFO - 2022-03-09 04:17:07 --> Router Class Initialized
INFO - 2022-03-09 04:17:07 --> Output Class Initialized
INFO - 2022-03-09 04:17:07 --> Security Class Initialized
DEBUG - 2022-03-09 04:17:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 04:17:07 --> Input Class Initialized
INFO - 2022-03-09 04:17:07 --> Language Class Initialized
INFO - 2022-03-09 04:17:07 --> Loader Class Initialized
INFO - 2022-03-09 04:17:07 --> Helper loaded: url_helper
INFO - 2022-03-09 04:17:07 --> Helper loaded: form_helper
INFO - 2022-03-09 04:17:07 --> Helper loaded: common_helper
INFO - 2022-03-09 04:17:07 --> Database Driver Class Initialized
DEBUG - 2022-03-09 04:17:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 04:17:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 04:17:07 --> Controller Class Initialized
INFO - 2022-03-09 04:17:07 --> Form Validation Class Initialized
DEBUG - 2022-03-09 04:17:07 --> Encrypt Class Initialized
INFO - 2022-03-09 04:17:07 --> Model "Patient_model" initialized
INFO - 2022-03-09 04:17:07 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 04:17:07 --> Model "Prefix_master" initialized
INFO - 2022-03-09 04:17:07 --> Model "Users_model" initialized
INFO - 2022-03-09 04:17:07 --> Model "Hospital_model" initialized
INFO - 2022-03-09 04:17:07 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 04:17:07 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-09 04:17:07 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 04:17:07 --> Final output sent to browser
DEBUG - 2022-03-09 04:17:07 --> Total execution time: 0.0557
ERROR - 2022-03-09 04:23:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 04:23:15 --> Config Class Initialized
INFO - 2022-03-09 04:23:15 --> Hooks Class Initialized
DEBUG - 2022-03-09 04:23:15 --> UTF-8 Support Enabled
INFO - 2022-03-09 04:23:15 --> Utf8 Class Initialized
INFO - 2022-03-09 04:23:15 --> URI Class Initialized
INFO - 2022-03-09 04:23:15 --> Router Class Initialized
INFO - 2022-03-09 04:23:15 --> Output Class Initialized
INFO - 2022-03-09 04:23:15 --> Security Class Initialized
DEBUG - 2022-03-09 04:23:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 04:23:15 --> Input Class Initialized
INFO - 2022-03-09 04:23:15 --> Language Class Initialized
INFO - 2022-03-09 04:23:15 --> Loader Class Initialized
INFO - 2022-03-09 04:23:15 --> Helper loaded: url_helper
INFO - 2022-03-09 04:23:15 --> Helper loaded: form_helper
INFO - 2022-03-09 04:23:15 --> Helper loaded: common_helper
INFO - 2022-03-09 04:23:15 --> Database Driver Class Initialized
DEBUG - 2022-03-09 04:23:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 04:23:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 04:23:15 --> Controller Class Initialized
INFO - 2022-03-09 04:23:15 --> Form Validation Class Initialized
DEBUG - 2022-03-09 04:23:15 --> Encrypt Class Initialized
INFO - 2022-03-09 04:23:15 --> Model "Patient_model" initialized
INFO - 2022-03-09 04:23:15 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 04:23:15 --> Model "Referredby_model" initialized
INFO - 2022-03-09 04:23:15 --> Model "Prefix_master" initialized
INFO - 2022-03-09 04:23:15 --> Model "Hospital_model" initialized
INFO - 2022-03-09 04:23:15 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 04:23:24 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-09 04:23:24 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
ERROR - 2022-03-09 04:23:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 04:23:26 --> Config Class Initialized
INFO - 2022-03-09 04:23:26 --> Hooks Class Initialized
DEBUG - 2022-03-09 04:23:26 --> UTF-8 Support Enabled
INFO - 2022-03-09 04:23:26 --> Utf8 Class Initialized
INFO - 2022-03-09 04:23:26 --> URI Class Initialized
INFO - 2022-03-09 04:23:26 --> Router Class Initialized
INFO - 2022-03-09 04:23:26 --> Output Class Initialized
INFO - 2022-03-09 04:23:26 --> Security Class Initialized
DEBUG - 2022-03-09 04:23:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 04:23:26 --> Input Class Initialized
INFO - 2022-03-09 04:23:26 --> Language Class Initialized
ERROR - 2022-03-09 04:23:26 --> 404 Page Not Found: Karoclient/usersprofile
INFO - 2022-03-09 04:23:33 --> Final output sent to browser
DEBUG - 2022-03-09 04:23:33 --> Total execution time: 9.1933
ERROR - 2022-03-09 04:25:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 04:25:59 --> Config Class Initialized
INFO - 2022-03-09 04:25:59 --> Hooks Class Initialized
DEBUG - 2022-03-09 04:25:59 --> UTF-8 Support Enabled
INFO - 2022-03-09 04:25:59 --> Utf8 Class Initialized
INFO - 2022-03-09 04:25:59 --> URI Class Initialized
INFO - 2022-03-09 04:25:59 --> Router Class Initialized
INFO - 2022-03-09 04:25:59 --> Output Class Initialized
INFO - 2022-03-09 04:25:59 --> Security Class Initialized
DEBUG - 2022-03-09 04:25:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 04:25:59 --> Input Class Initialized
INFO - 2022-03-09 04:25:59 --> Language Class Initialized
INFO - 2022-03-09 04:25:59 --> Loader Class Initialized
INFO - 2022-03-09 04:25:59 --> Helper loaded: url_helper
INFO - 2022-03-09 04:25:59 --> Helper loaded: form_helper
INFO - 2022-03-09 04:25:59 --> Helper loaded: common_helper
INFO - 2022-03-09 04:25:59 --> Database Driver Class Initialized
DEBUG - 2022-03-09 04:25:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 04:25:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 04:25:59 --> Controller Class Initialized
INFO - 2022-03-09 04:25:59 --> Form Validation Class Initialized
DEBUG - 2022-03-09 04:25:59 --> Encrypt Class Initialized
INFO - 2022-03-09 04:25:59 --> Model "Patient_model" initialized
INFO - 2022-03-09 04:25:59 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 04:25:59 --> Model "Referredby_model" initialized
INFO - 2022-03-09 04:25:59 --> Model "Prefix_master" initialized
INFO - 2022-03-09 04:25:59 --> Model "Hospital_model" initialized
INFO - 2022-03-09 04:25:59 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 04:25:59 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-09 04:25:59 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 04:25:59 --> Final output sent to browser
DEBUG - 2022-03-09 04:25:59 --> Total execution time: 0.0645
ERROR - 2022-03-09 04:26:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 04:26:09 --> Config Class Initialized
INFO - 2022-03-09 04:26:09 --> Hooks Class Initialized
DEBUG - 2022-03-09 04:26:09 --> UTF-8 Support Enabled
INFO - 2022-03-09 04:26:09 --> Utf8 Class Initialized
INFO - 2022-03-09 04:26:09 --> URI Class Initialized
INFO - 2022-03-09 04:26:09 --> Router Class Initialized
INFO - 2022-03-09 04:26:09 --> Output Class Initialized
INFO - 2022-03-09 04:26:09 --> Security Class Initialized
DEBUG - 2022-03-09 04:26:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 04:26:09 --> Input Class Initialized
INFO - 2022-03-09 04:26:09 --> Language Class Initialized
INFO - 2022-03-09 04:26:09 --> Loader Class Initialized
INFO - 2022-03-09 04:26:09 --> Helper loaded: url_helper
INFO - 2022-03-09 04:26:09 --> Helper loaded: form_helper
INFO - 2022-03-09 04:26:09 --> Helper loaded: common_helper
INFO - 2022-03-09 04:26:09 --> Database Driver Class Initialized
DEBUG - 2022-03-09 04:26:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 04:26:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 04:26:09 --> Controller Class Initialized
INFO - 2022-03-09 04:26:09 --> Form Validation Class Initialized
DEBUG - 2022-03-09 04:26:09 --> Encrypt Class Initialized
INFO - 2022-03-09 04:26:09 --> Model "Patient_model" initialized
INFO - 2022-03-09 04:26:09 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 04:26:09 --> Model "Referredby_model" initialized
INFO - 2022-03-09 04:26:09 --> Model "Prefix_master" initialized
INFO - 2022-03-09 04:26:09 --> Model "Hospital_model" initialized
INFO - 2022-03-09 04:26:09 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 04:26:09 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-09 04:26:09 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 04:26:09 --> Final output sent to browser
DEBUG - 2022-03-09 04:26:09 --> Total execution time: 0.0573
ERROR - 2022-03-09 04:26:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 04:26:21 --> Config Class Initialized
INFO - 2022-03-09 04:26:21 --> Hooks Class Initialized
DEBUG - 2022-03-09 04:26:21 --> UTF-8 Support Enabled
INFO - 2022-03-09 04:26:21 --> Utf8 Class Initialized
INFO - 2022-03-09 04:26:21 --> URI Class Initialized
INFO - 2022-03-09 04:26:21 --> Router Class Initialized
INFO - 2022-03-09 04:26:21 --> Output Class Initialized
INFO - 2022-03-09 04:26:21 --> Security Class Initialized
DEBUG - 2022-03-09 04:26:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 04:26:21 --> Input Class Initialized
INFO - 2022-03-09 04:26:21 --> Language Class Initialized
INFO - 2022-03-09 04:26:21 --> Loader Class Initialized
INFO - 2022-03-09 04:26:21 --> Helper loaded: url_helper
INFO - 2022-03-09 04:26:21 --> Helper loaded: form_helper
INFO - 2022-03-09 04:26:21 --> Helper loaded: common_helper
INFO - 2022-03-09 04:26:21 --> Database Driver Class Initialized
DEBUG - 2022-03-09 04:26:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 04:26:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 04:26:21 --> Controller Class Initialized
INFO - 2022-03-09 04:26:21 --> Form Validation Class Initialized
DEBUG - 2022-03-09 04:26:21 --> Encrypt Class Initialized
INFO - 2022-03-09 04:26:21 --> Model "Patient_model" initialized
INFO - 2022-03-09 04:26:21 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 04:26:21 --> Model "Prefix_master" initialized
INFO - 2022-03-09 04:26:21 --> Model "Users_model" initialized
INFO - 2022-03-09 04:26:21 --> Model "Hospital_model" initialized
INFO - 2022-03-09 04:26:21 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 04:26:21 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-09 04:26:21 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 04:26:21 --> Final output sent to browser
DEBUG - 2022-03-09 04:26:21 --> Total execution time: 0.0639
ERROR - 2022-03-09 04:26:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 04:26:33 --> Config Class Initialized
INFO - 2022-03-09 04:26:33 --> Hooks Class Initialized
DEBUG - 2022-03-09 04:26:33 --> UTF-8 Support Enabled
INFO - 2022-03-09 04:26:33 --> Utf8 Class Initialized
INFO - 2022-03-09 04:26:33 --> URI Class Initialized
INFO - 2022-03-09 04:26:33 --> Router Class Initialized
INFO - 2022-03-09 04:26:33 --> Output Class Initialized
INFO - 2022-03-09 04:26:33 --> Security Class Initialized
DEBUG - 2022-03-09 04:26:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 04:26:33 --> Input Class Initialized
INFO - 2022-03-09 04:26:33 --> Language Class Initialized
INFO - 2022-03-09 04:26:33 --> Loader Class Initialized
INFO - 2022-03-09 04:26:33 --> Helper loaded: url_helper
INFO - 2022-03-09 04:26:33 --> Helper loaded: form_helper
INFO - 2022-03-09 04:26:33 --> Helper loaded: common_helper
INFO - 2022-03-09 04:26:33 --> Database Driver Class Initialized
DEBUG - 2022-03-09 04:26:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 04:26:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 04:26:33 --> Controller Class Initialized
INFO - 2022-03-09 04:26:33 --> Form Validation Class Initialized
DEBUG - 2022-03-09 04:26:33 --> Encrypt Class Initialized
INFO - 2022-03-09 04:26:33 --> Model "Patient_model" initialized
INFO - 2022-03-09 04:26:33 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 04:26:33 --> Model "Referredby_model" initialized
INFO - 2022-03-09 04:26:33 --> Model "Prefix_master" initialized
INFO - 2022-03-09 04:26:33 --> Model "Hospital_model" initialized
INFO - 2022-03-09 04:26:33 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 04:26:33 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-09 04:26:33 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 04:26:33 --> Final output sent to browser
DEBUG - 2022-03-09 04:26:33 --> Total execution time: 0.0741
ERROR - 2022-03-09 04:26:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 04:26:53 --> Config Class Initialized
INFO - 2022-03-09 04:26:53 --> Hooks Class Initialized
DEBUG - 2022-03-09 04:26:53 --> UTF-8 Support Enabled
INFO - 2022-03-09 04:26:53 --> Utf8 Class Initialized
INFO - 2022-03-09 04:26:53 --> URI Class Initialized
INFO - 2022-03-09 04:26:53 --> Router Class Initialized
INFO - 2022-03-09 04:26:53 --> Output Class Initialized
INFO - 2022-03-09 04:26:53 --> Security Class Initialized
DEBUG - 2022-03-09 04:26:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 04:26:53 --> Input Class Initialized
INFO - 2022-03-09 04:26:53 --> Language Class Initialized
INFO - 2022-03-09 04:26:53 --> Loader Class Initialized
INFO - 2022-03-09 04:26:53 --> Helper loaded: url_helper
INFO - 2022-03-09 04:26:53 --> Helper loaded: form_helper
INFO - 2022-03-09 04:26:53 --> Helper loaded: common_helper
INFO - 2022-03-09 04:26:53 --> Database Driver Class Initialized
DEBUG - 2022-03-09 04:26:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 04:26:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 04:26:53 --> Controller Class Initialized
INFO - 2022-03-09 04:26:53 --> Model "Referredby_model" initialized
INFO - 2022-03-09 04:26:53 --> Final output sent to browser
DEBUG - 2022-03-09 04:26:53 --> Total execution time: 0.0214
ERROR - 2022-03-09 04:27:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 04:27:04 --> Config Class Initialized
INFO - 2022-03-09 04:27:04 --> Hooks Class Initialized
DEBUG - 2022-03-09 04:27:04 --> UTF-8 Support Enabled
INFO - 2022-03-09 04:27:04 --> Utf8 Class Initialized
INFO - 2022-03-09 04:27:04 --> URI Class Initialized
INFO - 2022-03-09 04:27:04 --> Router Class Initialized
INFO - 2022-03-09 04:27:04 --> Output Class Initialized
INFO - 2022-03-09 04:27:04 --> Security Class Initialized
DEBUG - 2022-03-09 04:27:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 04:27:04 --> Input Class Initialized
INFO - 2022-03-09 04:27:04 --> Language Class Initialized
INFO - 2022-03-09 04:27:04 --> Loader Class Initialized
INFO - 2022-03-09 04:27:04 --> Helper loaded: url_helper
INFO - 2022-03-09 04:27:04 --> Helper loaded: form_helper
INFO - 2022-03-09 04:27:04 --> Helper loaded: common_helper
INFO - 2022-03-09 04:27:04 --> Database Driver Class Initialized
DEBUG - 2022-03-09 04:27:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 04:27:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 04:27:04 --> Controller Class Initialized
INFO - 2022-03-09 04:27:04 --> Model "Referredby_model" initialized
INFO - 2022-03-09 04:27:04 --> Final output sent to browser
DEBUG - 2022-03-09 04:27:04 --> Total execution time: 0.0310
ERROR - 2022-03-09 04:28:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 04:28:11 --> Config Class Initialized
INFO - 2022-03-09 04:28:11 --> Hooks Class Initialized
DEBUG - 2022-03-09 04:28:11 --> UTF-8 Support Enabled
INFO - 2022-03-09 04:28:11 --> Utf8 Class Initialized
INFO - 2022-03-09 04:28:11 --> URI Class Initialized
INFO - 2022-03-09 04:28:11 --> Router Class Initialized
INFO - 2022-03-09 04:28:11 --> Output Class Initialized
INFO - 2022-03-09 04:28:11 --> Security Class Initialized
DEBUG - 2022-03-09 04:28:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 04:28:11 --> Input Class Initialized
INFO - 2022-03-09 04:28:11 --> Language Class Initialized
INFO - 2022-03-09 04:28:11 --> Loader Class Initialized
INFO - 2022-03-09 04:28:11 --> Helper loaded: url_helper
INFO - 2022-03-09 04:28:11 --> Helper loaded: form_helper
INFO - 2022-03-09 04:28:11 --> Helper loaded: common_helper
INFO - 2022-03-09 04:28:11 --> Database Driver Class Initialized
DEBUG - 2022-03-09 04:28:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 04:28:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 04:28:11 --> Controller Class Initialized
INFO - 2022-03-09 04:28:11 --> Form Validation Class Initialized
DEBUG - 2022-03-09 04:28:11 --> Encrypt Class Initialized
INFO - 2022-03-09 04:28:11 --> Model "Patient_model" initialized
INFO - 2022-03-09 04:28:11 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 04:28:11 --> Model "Referredby_model" initialized
INFO - 2022-03-09 04:28:11 --> Model "Prefix_master" initialized
INFO - 2022-03-09 04:28:11 --> Model "Hospital_model" initialized
INFO - 2022-03-09 04:28:12 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 04:28:12 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-09 04:28:12 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 04:28:12 --> Final output sent to browser
DEBUG - 2022-03-09 04:28:12 --> Total execution time: 0.0656
ERROR - 2022-03-09 04:28:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 04:28:12 --> Config Class Initialized
INFO - 2022-03-09 04:28:12 --> Hooks Class Initialized
DEBUG - 2022-03-09 04:28:12 --> UTF-8 Support Enabled
INFO - 2022-03-09 04:28:12 --> Utf8 Class Initialized
INFO - 2022-03-09 04:28:12 --> URI Class Initialized
INFO - 2022-03-09 04:28:12 --> Router Class Initialized
INFO - 2022-03-09 04:28:12 --> Output Class Initialized
INFO - 2022-03-09 04:28:12 --> Security Class Initialized
DEBUG - 2022-03-09 04:28:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 04:28:12 --> Input Class Initialized
INFO - 2022-03-09 04:28:12 --> Language Class Initialized
ERROR - 2022-03-09 04:28:12 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-09 04:28:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 04:28:12 --> Config Class Initialized
INFO - 2022-03-09 04:28:12 --> Hooks Class Initialized
DEBUG - 2022-03-09 04:28:12 --> UTF-8 Support Enabled
INFO - 2022-03-09 04:28:12 --> Utf8 Class Initialized
ERROR - 2022-03-09 04:31:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 04:31:12 --> Config Class Initialized
INFO - 2022-03-09 04:31:12 --> Hooks Class Initialized
DEBUG - 2022-03-09 04:31:12 --> UTF-8 Support Enabled
INFO - 2022-03-09 04:31:12 --> Utf8 Class Initialized
INFO - 2022-03-09 04:31:12 --> URI Class Initialized
INFO - 2022-03-09 04:31:12 --> Router Class Initialized
INFO - 2022-03-09 04:31:12 --> Output Class Initialized
INFO - 2022-03-09 04:31:12 --> Security Class Initialized
DEBUG - 2022-03-09 04:31:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 04:31:12 --> Input Class Initialized
INFO - 2022-03-09 04:31:12 --> Language Class Initialized
INFO - 2022-03-09 04:31:12 --> Loader Class Initialized
INFO - 2022-03-09 04:31:12 --> Helper loaded: url_helper
INFO - 2022-03-09 04:31:12 --> Helper loaded: form_helper
INFO - 2022-03-09 04:31:12 --> Helper loaded: common_helper
INFO - 2022-03-09 04:31:12 --> Database Driver Class Initialized
DEBUG - 2022-03-09 04:31:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 04:31:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 04:31:12 --> Controller Class Initialized
INFO - 2022-03-09 04:31:12 --> Form Validation Class Initialized
DEBUG - 2022-03-09 04:31:12 --> Encrypt Class Initialized
INFO - 2022-03-09 04:31:12 --> Model "Patient_model" initialized
INFO - 2022-03-09 04:31:12 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 04:31:12 --> Model "Referredby_model" initialized
INFO - 2022-03-09 04:31:12 --> Model "Prefix_master" initialized
INFO - 2022-03-09 04:31:12 --> Model "Hospital_model" initialized
INFO - 2022-03-09 04:31:12 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 04:31:20 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-09 04:31:20 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
ERROR - 2022-03-09 04:31:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 04:31:20 --> Config Class Initialized
INFO - 2022-03-09 04:31:20 --> Hooks Class Initialized
DEBUG - 2022-03-09 04:31:20 --> UTF-8 Support Enabled
INFO - 2022-03-09 04:31:20 --> Utf8 Class Initialized
INFO - 2022-03-09 04:31:20 --> URI Class Initialized
INFO - 2022-03-09 04:31:20 --> Router Class Initialized
INFO - 2022-03-09 04:31:20 --> Output Class Initialized
INFO - 2022-03-09 04:31:20 --> Security Class Initialized
DEBUG - 2022-03-09 04:31:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 04:31:20 --> Input Class Initialized
INFO - 2022-03-09 04:31:20 --> Language Class Initialized
INFO - 2022-03-09 04:31:20 --> Loader Class Initialized
INFO - 2022-03-09 04:31:20 --> Helper loaded: url_helper
INFO - 2022-03-09 04:31:20 --> Helper loaded: form_helper
INFO - 2022-03-09 04:31:20 --> Helper loaded: common_helper
INFO - 2022-03-09 04:31:20 --> Database Driver Class Initialized
DEBUG - 2022-03-09 04:31:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 04:31:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 04:31:20 --> Controller Class Initialized
INFO - 2022-03-09 04:31:20 --> Form Validation Class Initialized
DEBUG - 2022-03-09 04:31:20 --> Encrypt Class Initialized
INFO - 2022-03-09 04:31:20 --> Model "Patient_model" initialized
INFO - 2022-03-09 04:31:20 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 04:31:20 --> Model "Referredby_model" initialized
INFO - 2022-03-09 04:31:20 --> Model "Prefix_master" initialized
INFO - 2022-03-09 04:31:20 --> Model "Hospital_model" initialized
INFO - 2022-03-09 04:31:21 --> File loaded: /home3/karoteam/public_html/application/views/header.php
ERROR - 2022-03-09 04:31:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 04:31:25 --> Config Class Initialized
INFO - 2022-03-09 04:31:25 --> Hooks Class Initialized
DEBUG - 2022-03-09 04:31:25 --> UTF-8 Support Enabled
INFO - 2022-03-09 04:31:25 --> Utf8 Class Initialized
INFO - 2022-03-09 04:31:25 --> URI Class Initialized
INFO - 2022-03-09 04:31:25 --> Router Class Initialized
INFO - 2022-03-09 04:31:25 --> Output Class Initialized
INFO - 2022-03-09 04:31:25 --> Security Class Initialized
DEBUG - 2022-03-09 04:31:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 04:31:25 --> Input Class Initialized
INFO - 2022-03-09 04:31:25 --> Language Class Initialized
INFO - 2022-03-09 04:31:25 --> Loader Class Initialized
INFO - 2022-03-09 04:31:25 --> Helper loaded: url_helper
INFO - 2022-03-09 04:31:25 --> Helper loaded: form_helper
INFO - 2022-03-09 04:31:25 --> Helper loaded: common_helper
INFO - 2022-03-09 04:31:25 --> Database Driver Class Initialized
DEBUG - 2022-03-09 04:31:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 04:31:27 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-09 04:31:27 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 04:31:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 04:31:27 --> Controller Class Initialized
INFO - 2022-03-09 04:31:27 --> Form Validation Class Initialized
DEBUG - 2022-03-09 04:31:27 --> Encrypt Class Initialized
INFO - 2022-03-09 04:31:27 --> Model "Patient_model" initialized
INFO - 2022-03-09 04:31:27 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 04:31:27 --> Model "Referredby_model" initialized
INFO - 2022-03-09 04:31:27 --> Model "Prefix_master" initialized
INFO - 2022-03-09 04:31:27 --> Model "Hospital_model" initialized
INFO - 2022-03-09 04:31:27 --> File loaded: /home3/karoteam/public_html/application/views/header.php
ERROR - 2022-03-09 04:31:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 04:31:33 --> Config Class Initialized
INFO - 2022-03-09 04:31:33 --> Hooks Class Initialized
DEBUG - 2022-03-09 04:31:33 --> UTF-8 Support Enabled
INFO - 2022-03-09 04:31:33 --> Utf8 Class Initialized
INFO - 2022-03-09 04:31:33 --> URI Class Initialized
INFO - 2022-03-09 04:31:33 --> Router Class Initialized
INFO - 2022-03-09 04:31:33 --> Output Class Initialized
INFO - 2022-03-09 04:31:33 --> Security Class Initialized
DEBUG - 2022-03-09 04:31:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 04:31:33 --> Input Class Initialized
INFO - 2022-03-09 04:31:33 --> Language Class Initialized
INFO - 2022-03-09 04:31:33 --> Loader Class Initialized
INFO - 2022-03-09 04:31:33 --> Helper loaded: url_helper
INFO - 2022-03-09 04:31:33 --> Helper loaded: form_helper
INFO - 2022-03-09 04:31:33 --> Helper loaded: common_helper
INFO - 2022-03-09 04:31:33 --> Database Driver Class Initialized
DEBUG - 2022-03-09 04:31:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 04:31:34 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-09 04:31:34 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 04:31:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 04:31:34 --> Controller Class Initialized
INFO - 2022-03-09 04:31:34 --> Form Validation Class Initialized
DEBUG - 2022-03-09 04:31:34 --> Encrypt Class Initialized
INFO - 2022-03-09 04:31:34 --> Model "Patient_model" initialized
INFO - 2022-03-09 04:31:34 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 04:31:34 --> Model "Referredby_model" initialized
INFO - 2022-03-09 04:31:34 --> Model "Prefix_master" initialized
INFO - 2022-03-09 04:31:34 --> Model "Hospital_model" initialized
INFO - 2022-03-09 04:31:34 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 04:31:40 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-09 04:31:40 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
ERROR - 2022-03-09 04:31:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 04:31:42 --> Config Class Initialized
INFO - 2022-03-09 04:31:42 --> Hooks Class Initialized
DEBUG - 2022-03-09 04:31:42 --> UTF-8 Support Enabled
INFO - 2022-03-09 04:31:42 --> Utf8 Class Initialized
INFO - 2022-03-09 04:31:42 --> URI Class Initialized
INFO - 2022-03-09 04:31:42 --> Router Class Initialized
INFO - 2022-03-09 04:31:42 --> Output Class Initialized
INFO - 2022-03-09 04:31:42 --> Security Class Initialized
DEBUG - 2022-03-09 04:31:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 04:31:42 --> Input Class Initialized
INFO - 2022-03-09 04:31:42 --> Language Class Initialized
ERROR - 2022-03-09 04:31:42 --> 404 Page Not Found: Karoclient/usersprofile
INFO - 2022-03-09 04:31:48 --> Final output sent to browser
DEBUG - 2022-03-09 04:31:48 --> Total execution time: 7.0389
ERROR - 2022-03-09 04:32:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 04:32:08 --> Config Class Initialized
INFO - 2022-03-09 04:32:08 --> Hooks Class Initialized
DEBUG - 2022-03-09 04:32:08 --> UTF-8 Support Enabled
INFO - 2022-03-09 04:32:08 --> Utf8 Class Initialized
INFO - 2022-03-09 04:32:08 --> URI Class Initialized
INFO - 2022-03-09 04:32:08 --> Router Class Initialized
INFO - 2022-03-09 04:32:08 --> Output Class Initialized
INFO - 2022-03-09 04:32:08 --> Security Class Initialized
DEBUG - 2022-03-09 04:32:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 04:32:08 --> Input Class Initialized
INFO - 2022-03-09 04:32:08 --> Language Class Initialized
INFO - 2022-03-09 04:32:08 --> Loader Class Initialized
INFO - 2022-03-09 04:32:08 --> Helper loaded: url_helper
INFO - 2022-03-09 04:32:08 --> Helper loaded: form_helper
INFO - 2022-03-09 04:32:08 --> Helper loaded: common_helper
INFO - 2022-03-09 04:32:08 --> Database Driver Class Initialized
DEBUG - 2022-03-09 04:32:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 04:32:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 04:32:08 --> Controller Class Initialized
INFO - 2022-03-09 04:32:08 --> Form Validation Class Initialized
DEBUG - 2022-03-09 04:32:08 --> Encrypt Class Initialized
INFO - 2022-03-09 04:32:08 --> Model "Patient_model" initialized
INFO - 2022-03-09 04:32:08 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 04:32:08 --> Model "Referredby_model" initialized
INFO - 2022-03-09 04:32:08 --> Model "Prefix_master" initialized
INFO - 2022-03-09 04:32:08 --> Model "Hospital_model" initialized
INFO - 2022-03-09 04:32:08 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 04:32:08 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-09 04:32:08 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 04:32:08 --> Final output sent to browser
DEBUG - 2022-03-09 04:32:08 --> Total execution time: 0.0431
ERROR - 2022-03-09 04:32:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 04:32:09 --> Config Class Initialized
INFO - 2022-03-09 04:32:09 --> Hooks Class Initialized
DEBUG - 2022-03-09 04:32:09 --> UTF-8 Support Enabled
INFO - 2022-03-09 04:32:09 --> Utf8 Class Initialized
INFO - 2022-03-09 04:32:09 --> URI Class Initialized
INFO - 2022-03-09 04:32:09 --> Router Class Initialized
INFO - 2022-03-09 04:32:09 --> Output Class Initialized
INFO - 2022-03-09 04:32:09 --> Security Class Initialized
DEBUG - 2022-03-09 04:32:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 04:32:09 --> Input Class Initialized
INFO - 2022-03-09 04:32:09 --> Language Class Initialized
ERROR - 2022-03-09 04:32:09 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-09 04:36:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 04:36:57 --> Config Class Initialized
INFO - 2022-03-09 04:36:57 --> Hooks Class Initialized
DEBUG - 2022-03-09 04:36:57 --> UTF-8 Support Enabled
INFO - 2022-03-09 04:36:57 --> Utf8 Class Initialized
INFO - 2022-03-09 04:36:57 --> URI Class Initialized
INFO - 2022-03-09 04:36:57 --> Router Class Initialized
INFO - 2022-03-09 04:36:57 --> Output Class Initialized
INFO - 2022-03-09 04:36:57 --> Security Class Initialized
DEBUG - 2022-03-09 04:36:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 04:36:57 --> Input Class Initialized
INFO - 2022-03-09 04:36:57 --> Language Class Initialized
INFO - 2022-03-09 04:36:57 --> Loader Class Initialized
INFO - 2022-03-09 04:36:57 --> Helper loaded: url_helper
INFO - 2022-03-09 04:36:57 --> Helper loaded: form_helper
INFO - 2022-03-09 04:36:57 --> Helper loaded: common_helper
INFO - 2022-03-09 04:36:57 --> Database Driver Class Initialized
DEBUG - 2022-03-09 04:36:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 04:36:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 04:36:57 --> Controller Class Initialized
INFO - 2022-03-09 04:36:57 --> Form Validation Class Initialized
DEBUG - 2022-03-09 04:36:57 --> Encrypt Class Initialized
INFO - 2022-03-09 04:36:57 --> Model "Patient_model" initialized
INFO - 2022-03-09 04:36:57 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 04:36:57 --> Model "Referredby_model" initialized
INFO - 2022-03-09 04:36:57 --> Model "Prefix_master" initialized
INFO - 2022-03-09 04:36:57 --> Model "Hospital_model" initialized
ERROR - 2022-03-09 04:36:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 04:36:57 --> Config Class Initialized
INFO - 2022-03-09 04:36:57 --> Hooks Class Initialized
DEBUG - 2022-03-09 04:36:57 --> UTF-8 Support Enabled
INFO - 2022-03-09 04:36:57 --> Utf8 Class Initialized
INFO - 2022-03-09 04:36:57 --> URI Class Initialized
INFO - 2022-03-09 04:36:57 --> Router Class Initialized
INFO - 2022-03-09 04:36:57 --> Output Class Initialized
INFO - 2022-03-09 04:36:57 --> Security Class Initialized
DEBUG - 2022-03-09 04:36:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 04:36:57 --> Input Class Initialized
INFO - 2022-03-09 04:36:57 --> Language Class Initialized
INFO - 2022-03-09 04:36:57 --> Loader Class Initialized
INFO - 2022-03-09 04:36:57 --> Helper loaded: url_helper
INFO - 2022-03-09 04:36:57 --> Helper loaded: form_helper
INFO - 2022-03-09 04:36:57 --> Helper loaded: common_helper
INFO - 2022-03-09 04:36:57 --> Database Driver Class Initialized
DEBUG - 2022-03-09 04:36:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 04:36:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 04:36:57 --> Controller Class Initialized
INFO - 2022-03-09 04:36:57 --> Form Validation Class Initialized
DEBUG - 2022-03-09 04:36:57 --> Encrypt Class Initialized
INFO - 2022-03-09 04:36:57 --> Model "Patient_model" initialized
INFO - 2022-03-09 04:36:57 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 04:36:57 --> Model "Referredby_model" initialized
INFO - 2022-03-09 04:36:57 --> Model "Prefix_master" initialized
INFO - 2022-03-09 04:36:57 --> Model "Hospital_model" initialized
INFO - 2022-03-09 04:36:57 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 04:36:57 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-09 04:36:57 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 04:36:57 --> Final output sent to browser
DEBUG - 2022-03-09 04:36:57 --> Total execution time: 0.0437
ERROR - 2022-03-09 04:36:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 04:36:58 --> Config Class Initialized
INFO - 2022-03-09 04:36:58 --> Hooks Class Initialized
DEBUG - 2022-03-09 04:36:58 --> UTF-8 Support Enabled
INFO - 2022-03-09 04:36:58 --> Utf8 Class Initialized
INFO - 2022-03-09 04:36:58 --> URI Class Initialized
INFO - 2022-03-09 04:36:58 --> Router Class Initialized
INFO - 2022-03-09 04:36:58 --> Output Class Initialized
INFO - 2022-03-09 04:36:58 --> Security Class Initialized
DEBUG - 2022-03-09 04:36:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 04:36:58 --> Input Class Initialized
INFO - 2022-03-09 04:36:58 --> Language Class Initialized
ERROR - 2022-03-09 04:36:58 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-09 04:36:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 04:36:58 --> Config Class Initialized
INFO - 2022-03-09 04:36:58 --> Hooks Class Initialized
DEBUG - 2022-03-09 04:36:58 --> UTF-8 Support Enabled
INFO - 2022-03-09 04:36:58 --> Utf8 Class Initialized
INFO - 2022-03-09 04:36:58 --> URI Class Initialized
INFO - 2022-03-09 04:36:58 --> Router Class Initialized
INFO - 2022-03-09 04:36:58 --> Output Class Initialized
INFO - 2022-03-09 04:36:58 --> Security Class Initialized
DEBUG - 2022-03-09 04:36:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 04:36:58 --> Input Class Initialized
INFO - 2022-03-09 04:36:58 --> Language Class Initialized
INFO - 2022-03-09 04:36:58 --> Loader Class Initialized
INFO - 2022-03-09 04:36:58 --> Helper loaded: url_helper
INFO - 2022-03-09 04:36:58 --> Helper loaded: form_helper
INFO - 2022-03-09 04:36:58 --> Helper loaded: common_helper
INFO - 2022-03-09 04:36:58 --> Database Driver Class Initialized
DEBUG - 2022-03-09 04:36:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 04:36:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 04:36:58 --> Controller Class Initialized
INFO - 2022-03-09 04:36:58 --> Form Validation Class Initialized
DEBUG - 2022-03-09 04:36:58 --> Encrypt Class Initialized
INFO - 2022-03-09 04:36:58 --> Model "Patient_model" initialized
INFO - 2022-03-09 04:36:58 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 04:36:58 --> Model "Prefix_master" initialized
INFO - 2022-03-09 04:36:58 --> Model "Users_model" initialized
INFO - 2022-03-09 04:36:58 --> Model "Hospital_model" initialized
INFO - 2022-03-09 04:36:58 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 04:36:58 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-09 04:36:58 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 04:36:58 --> Final output sent to browser
DEBUG - 2022-03-09 04:36:58 --> Total execution time: 0.0576
ERROR - 2022-03-09 04:36:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 04:36:59 --> Config Class Initialized
INFO - 2022-03-09 04:36:59 --> Hooks Class Initialized
DEBUG - 2022-03-09 04:36:59 --> UTF-8 Support Enabled
INFO - 2022-03-09 04:36:59 --> Utf8 Class Initialized
INFO - 2022-03-09 04:36:59 --> URI Class Initialized
INFO - 2022-03-09 04:36:59 --> Router Class Initialized
INFO - 2022-03-09 04:36:59 --> Output Class Initialized
INFO - 2022-03-09 04:36:59 --> Security Class Initialized
DEBUG - 2022-03-09 04:36:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 04:36:59 --> Input Class Initialized
INFO - 2022-03-09 04:36:59 --> Language Class Initialized
ERROR - 2022-03-09 04:36:59 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-09 04:37:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 04:37:10 --> Config Class Initialized
INFO - 2022-03-09 04:37:10 --> Hooks Class Initialized
DEBUG - 2022-03-09 04:37:10 --> UTF-8 Support Enabled
INFO - 2022-03-09 04:37:10 --> Utf8 Class Initialized
INFO - 2022-03-09 04:37:10 --> URI Class Initialized
INFO - 2022-03-09 04:37:10 --> Router Class Initialized
INFO - 2022-03-09 04:37:10 --> Output Class Initialized
INFO - 2022-03-09 04:37:10 --> Security Class Initialized
DEBUG - 2022-03-09 04:37:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 04:37:10 --> Input Class Initialized
INFO - 2022-03-09 04:37:10 --> Language Class Initialized
INFO - 2022-03-09 04:37:10 --> Loader Class Initialized
INFO - 2022-03-09 04:37:10 --> Helper loaded: url_helper
INFO - 2022-03-09 04:37:10 --> Helper loaded: form_helper
INFO - 2022-03-09 04:37:10 --> Helper loaded: common_helper
INFO - 2022-03-09 04:37:10 --> Database Driver Class Initialized
DEBUG - 2022-03-09 04:37:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 04:37:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 04:37:10 --> Controller Class Initialized
INFO - 2022-03-09 04:37:10 --> Form Validation Class Initialized
DEBUG - 2022-03-09 04:37:10 --> Encrypt Class Initialized
INFO - 2022-03-09 04:37:10 --> Model "Patient_model" initialized
INFO - 2022-03-09 04:37:10 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 04:37:10 --> Model "Referredby_model" initialized
INFO - 2022-03-09 04:37:10 --> Model "Prefix_master" initialized
INFO - 2022-03-09 04:37:10 --> Model "Hospital_model" initialized
INFO - 2022-03-09 04:37:10 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 04:37:10 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-09 04:37:10 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 04:37:10 --> Final output sent to browser
DEBUG - 2022-03-09 04:37:10 --> Total execution time: 0.0409
ERROR - 2022-03-09 04:37:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 04:37:10 --> Config Class Initialized
INFO - 2022-03-09 04:37:10 --> Hooks Class Initialized
DEBUG - 2022-03-09 04:37:10 --> UTF-8 Support Enabled
INFO - 2022-03-09 04:37:10 --> Utf8 Class Initialized
INFO - 2022-03-09 04:37:10 --> URI Class Initialized
INFO - 2022-03-09 04:37:10 --> Router Class Initialized
INFO - 2022-03-09 04:37:10 --> Output Class Initialized
INFO - 2022-03-09 04:37:10 --> Security Class Initialized
DEBUG - 2022-03-09 04:37:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 04:37:10 --> Input Class Initialized
INFO - 2022-03-09 04:37:10 --> Language Class Initialized
ERROR - 2022-03-09 04:37:10 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-09 04:37:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 04:37:19 --> Config Class Initialized
INFO - 2022-03-09 04:37:19 --> Hooks Class Initialized
DEBUG - 2022-03-09 04:37:19 --> UTF-8 Support Enabled
INFO - 2022-03-09 04:37:19 --> Utf8 Class Initialized
INFO - 2022-03-09 04:37:19 --> URI Class Initialized
INFO - 2022-03-09 04:37:19 --> Router Class Initialized
INFO - 2022-03-09 04:37:19 --> Output Class Initialized
INFO - 2022-03-09 04:37:19 --> Security Class Initialized
DEBUG - 2022-03-09 04:37:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 04:37:19 --> Input Class Initialized
INFO - 2022-03-09 04:37:19 --> Language Class Initialized
INFO - 2022-03-09 04:37:19 --> Loader Class Initialized
INFO - 2022-03-09 04:37:19 --> Helper loaded: url_helper
INFO - 2022-03-09 04:37:19 --> Helper loaded: form_helper
INFO - 2022-03-09 04:37:19 --> Helper loaded: common_helper
INFO - 2022-03-09 04:37:19 --> Database Driver Class Initialized
DEBUG - 2022-03-09 04:37:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 04:37:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 04:37:19 --> Controller Class Initialized
INFO - 2022-03-09 04:37:19 --> Form Validation Class Initialized
DEBUG - 2022-03-09 04:37:19 --> Encrypt Class Initialized
INFO - 2022-03-09 04:37:19 --> Model "Patient_model" initialized
INFO - 2022-03-09 04:37:19 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 04:37:19 --> Model "Referredby_model" initialized
INFO - 2022-03-09 04:37:19 --> Model "Prefix_master" initialized
INFO - 2022-03-09 04:37:19 --> Model "Hospital_model" initialized
ERROR - 2022-03-09 04:37:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 04:37:20 --> Config Class Initialized
INFO - 2022-03-09 04:37:20 --> Hooks Class Initialized
DEBUG - 2022-03-09 04:37:20 --> UTF-8 Support Enabled
INFO - 2022-03-09 04:37:20 --> Utf8 Class Initialized
INFO - 2022-03-09 04:37:20 --> URI Class Initialized
INFO - 2022-03-09 04:37:20 --> Router Class Initialized
INFO - 2022-03-09 04:37:20 --> Output Class Initialized
INFO - 2022-03-09 04:37:20 --> Security Class Initialized
DEBUG - 2022-03-09 04:37:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 04:37:20 --> Input Class Initialized
INFO - 2022-03-09 04:37:20 --> Language Class Initialized
INFO - 2022-03-09 04:37:20 --> Loader Class Initialized
INFO - 2022-03-09 04:37:20 --> Helper loaded: url_helper
INFO - 2022-03-09 04:37:20 --> Helper loaded: form_helper
INFO - 2022-03-09 04:37:20 --> Helper loaded: common_helper
INFO - 2022-03-09 04:37:20 --> Database Driver Class Initialized
DEBUG - 2022-03-09 04:37:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 04:37:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 04:37:20 --> Controller Class Initialized
INFO - 2022-03-09 04:37:20 --> Form Validation Class Initialized
DEBUG - 2022-03-09 04:37:20 --> Encrypt Class Initialized
INFO - 2022-03-09 04:37:20 --> Model "Patient_model" initialized
INFO - 2022-03-09 04:37:20 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 04:37:20 --> Model "Referredby_model" initialized
INFO - 2022-03-09 04:37:20 --> Model "Prefix_master" initialized
INFO - 2022-03-09 04:37:20 --> Model "Hospital_model" initialized
INFO - 2022-03-09 04:37:20 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 04:37:20 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-09 04:37:20 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 04:37:20 --> Final output sent to browser
DEBUG - 2022-03-09 04:37:20 --> Total execution time: 0.0632
ERROR - 2022-03-09 04:37:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 04:37:21 --> Config Class Initialized
INFO - 2022-03-09 04:37:21 --> Hooks Class Initialized
DEBUG - 2022-03-09 04:37:21 --> UTF-8 Support Enabled
INFO - 2022-03-09 04:37:21 --> Utf8 Class Initialized
INFO - 2022-03-09 04:37:21 --> URI Class Initialized
INFO - 2022-03-09 04:37:21 --> Router Class Initialized
INFO - 2022-03-09 04:37:21 --> Output Class Initialized
INFO - 2022-03-09 04:37:21 --> Security Class Initialized
DEBUG - 2022-03-09 04:37:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 04:37:21 --> Input Class Initialized
INFO - 2022-03-09 04:37:21 --> Language Class Initialized
ERROR - 2022-03-09 04:37:21 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-09 04:37:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 04:37:21 --> Config Class Initialized
INFO - 2022-03-09 04:37:21 --> Hooks Class Initialized
DEBUG - 2022-03-09 04:37:21 --> UTF-8 Support Enabled
INFO - 2022-03-09 04:37:21 --> Utf8 Class Initialized
INFO - 2022-03-09 04:37:21 --> URI Class Initialized
INFO - 2022-03-09 04:37:21 --> Router Class Initialized
INFO - 2022-03-09 04:37:21 --> Output Class Initialized
INFO - 2022-03-09 04:37:21 --> Security Class Initialized
DEBUG - 2022-03-09 04:37:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 04:37:21 --> Input Class Initialized
INFO - 2022-03-09 04:37:21 --> Language Class Initialized
INFO - 2022-03-09 04:37:21 --> Loader Class Initialized
INFO - 2022-03-09 04:37:21 --> Helper loaded: url_helper
INFO - 2022-03-09 04:37:21 --> Helper loaded: form_helper
INFO - 2022-03-09 04:37:21 --> Helper loaded: common_helper
INFO - 2022-03-09 04:37:21 --> Database Driver Class Initialized
DEBUG - 2022-03-09 04:37:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 04:37:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 04:37:21 --> Controller Class Initialized
INFO - 2022-03-09 04:37:21 --> Form Validation Class Initialized
DEBUG - 2022-03-09 04:37:21 --> Encrypt Class Initialized
INFO - 2022-03-09 04:37:21 --> Model "Patient_model" initialized
INFO - 2022-03-09 04:37:21 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 04:37:21 --> Model "Prefix_master" initialized
INFO - 2022-03-09 04:37:21 --> Model "Users_model" initialized
INFO - 2022-03-09 04:37:21 --> Model "Hospital_model" initialized
INFO - 2022-03-09 04:37:21 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 04:37:21 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-09 04:37:21 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 04:37:21 --> Final output sent to browser
DEBUG - 2022-03-09 04:37:21 --> Total execution time: 0.0561
ERROR - 2022-03-09 04:37:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 04:37:22 --> Config Class Initialized
INFO - 2022-03-09 04:37:22 --> Hooks Class Initialized
DEBUG - 2022-03-09 04:37:22 --> UTF-8 Support Enabled
INFO - 2022-03-09 04:37:22 --> Utf8 Class Initialized
INFO - 2022-03-09 04:37:22 --> URI Class Initialized
INFO - 2022-03-09 04:37:22 --> Router Class Initialized
INFO - 2022-03-09 04:37:22 --> Output Class Initialized
INFO - 2022-03-09 04:37:22 --> Security Class Initialized
DEBUG - 2022-03-09 04:37:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 04:37:22 --> Input Class Initialized
INFO - 2022-03-09 04:37:22 --> Language Class Initialized
ERROR - 2022-03-09 04:37:22 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-09 04:38:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 04:38:03 --> Config Class Initialized
INFO - 2022-03-09 04:38:03 --> Hooks Class Initialized
DEBUG - 2022-03-09 04:38:03 --> UTF-8 Support Enabled
INFO - 2022-03-09 04:38:03 --> Utf8 Class Initialized
INFO - 2022-03-09 04:38:03 --> URI Class Initialized
INFO - 2022-03-09 04:38:03 --> Router Class Initialized
INFO - 2022-03-09 04:38:03 --> Output Class Initialized
INFO - 2022-03-09 04:38:03 --> Security Class Initialized
DEBUG - 2022-03-09 04:38:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 04:38:03 --> Input Class Initialized
INFO - 2022-03-09 04:38:03 --> Language Class Initialized
INFO - 2022-03-09 04:38:03 --> Loader Class Initialized
INFO - 2022-03-09 04:38:03 --> Helper loaded: url_helper
INFO - 2022-03-09 04:38:03 --> Helper loaded: form_helper
INFO - 2022-03-09 04:38:03 --> Helper loaded: common_helper
INFO - 2022-03-09 04:38:03 --> Database Driver Class Initialized
DEBUG - 2022-03-09 04:38:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 04:38:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 04:38:03 --> Controller Class Initialized
INFO - 2022-03-09 04:38:03 --> Form Validation Class Initialized
DEBUG - 2022-03-09 04:38:03 --> Encrypt Class Initialized
INFO - 2022-03-09 04:38:03 --> Model "Patient_model" initialized
INFO - 2022-03-09 04:38:03 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 04:38:03 --> Model "Referredby_model" initialized
INFO - 2022-03-09 04:38:03 --> Model "Prefix_master" initialized
INFO - 2022-03-09 04:38:03 --> Model "Hospital_model" initialized
ERROR - 2022-03-09 04:38:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 04:38:04 --> Config Class Initialized
INFO - 2022-03-09 04:38:04 --> Hooks Class Initialized
DEBUG - 2022-03-09 04:38:04 --> UTF-8 Support Enabled
INFO - 2022-03-09 04:38:04 --> Utf8 Class Initialized
INFO - 2022-03-09 04:38:04 --> URI Class Initialized
INFO - 2022-03-09 04:38:04 --> Router Class Initialized
INFO - 2022-03-09 04:38:04 --> Output Class Initialized
INFO - 2022-03-09 04:38:04 --> Security Class Initialized
DEBUG - 2022-03-09 04:38:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 04:38:04 --> Input Class Initialized
INFO - 2022-03-09 04:38:04 --> Language Class Initialized
INFO - 2022-03-09 04:38:04 --> Loader Class Initialized
INFO - 2022-03-09 04:38:04 --> Helper loaded: url_helper
INFO - 2022-03-09 04:38:04 --> Helper loaded: form_helper
INFO - 2022-03-09 04:38:04 --> Helper loaded: common_helper
INFO - 2022-03-09 04:38:04 --> Database Driver Class Initialized
DEBUG - 2022-03-09 04:38:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 04:38:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 04:38:04 --> Controller Class Initialized
INFO - 2022-03-09 04:38:04 --> Form Validation Class Initialized
DEBUG - 2022-03-09 04:38:04 --> Encrypt Class Initialized
INFO - 2022-03-09 04:38:04 --> Model "Patient_model" initialized
INFO - 2022-03-09 04:38:04 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 04:38:04 --> Model "Referredby_model" initialized
INFO - 2022-03-09 04:38:04 --> Model "Prefix_master" initialized
INFO - 2022-03-09 04:38:04 --> Model "Hospital_model" initialized
INFO - 2022-03-09 04:38:04 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 04:38:04 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-09 04:38:04 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 04:38:04 --> Final output sent to browser
DEBUG - 2022-03-09 04:38:04 --> Total execution time: 0.0517
ERROR - 2022-03-09 04:38:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 04:38:05 --> Config Class Initialized
INFO - 2022-03-09 04:38:05 --> Hooks Class Initialized
DEBUG - 2022-03-09 04:38:05 --> UTF-8 Support Enabled
INFO - 2022-03-09 04:38:05 --> Utf8 Class Initialized
INFO - 2022-03-09 04:38:05 --> URI Class Initialized
INFO - 2022-03-09 04:38:05 --> Router Class Initialized
INFO - 2022-03-09 04:38:05 --> Output Class Initialized
INFO - 2022-03-09 04:38:05 --> Security Class Initialized
DEBUG - 2022-03-09 04:38:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 04:38:05 --> Input Class Initialized
INFO - 2022-03-09 04:38:05 --> Language Class Initialized
INFO - 2022-03-09 04:38:05 --> Loader Class Initialized
INFO - 2022-03-09 04:38:05 --> Helper loaded: url_helper
INFO - 2022-03-09 04:38:05 --> Helper loaded: form_helper
INFO - 2022-03-09 04:38:05 --> Helper loaded: common_helper
INFO - 2022-03-09 04:38:05 --> Database Driver Class Initialized
DEBUG - 2022-03-09 04:38:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 04:38:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 04:38:05 --> Controller Class Initialized
INFO - 2022-03-09 04:38:05 --> Form Validation Class Initialized
DEBUG - 2022-03-09 04:38:05 --> Encrypt Class Initialized
INFO - 2022-03-09 04:38:05 --> Model "Patient_model" initialized
INFO - 2022-03-09 04:38:05 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 04:38:05 --> Model "Prefix_master" initialized
INFO - 2022-03-09 04:38:05 --> Model "Users_model" initialized
INFO - 2022-03-09 04:38:05 --> Model "Hospital_model" initialized
INFO - 2022-03-09 04:38:05 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 04:38:05 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-09 04:38:05 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 04:38:05 --> Final output sent to browser
DEBUG - 2022-03-09 04:38:05 --> Total execution time: 0.0555
ERROR - 2022-03-09 04:38:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 04:38:58 --> Config Class Initialized
INFO - 2022-03-09 04:38:58 --> Hooks Class Initialized
DEBUG - 2022-03-09 04:38:58 --> UTF-8 Support Enabled
INFO - 2022-03-09 04:38:58 --> Utf8 Class Initialized
INFO - 2022-03-09 04:38:58 --> URI Class Initialized
INFO - 2022-03-09 04:38:58 --> Router Class Initialized
INFO - 2022-03-09 04:38:58 --> Output Class Initialized
INFO - 2022-03-09 04:38:58 --> Security Class Initialized
DEBUG - 2022-03-09 04:38:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 04:38:58 --> Input Class Initialized
INFO - 2022-03-09 04:38:58 --> Language Class Initialized
INFO - 2022-03-09 04:38:58 --> Loader Class Initialized
INFO - 2022-03-09 04:38:58 --> Helper loaded: url_helper
INFO - 2022-03-09 04:38:58 --> Helper loaded: form_helper
INFO - 2022-03-09 04:38:58 --> Helper loaded: common_helper
INFO - 2022-03-09 04:38:58 --> Database Driver Class Initialized
DEBUG - 2022-03-09 04:38:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 04:38:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 04:38:58 --> Controller Class Initialized
INFO - 2022-03-09 04:38:58 --> Form Validation Class Initialized
DEBUG - 2022-03-09 04:38:58 --> Encrypt Class Initialized
INFO - 2022-03-09 04:38:58 --> Model "Patient_model" initialized
INFO - 2022-03-09 04:38:58 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 04:38:58 --> Model "Referredby_model" initialized
INFO - 2022-03-09 04:38:58 --> Model "Prefix_master" initialized
INFO - 2022-03-09 04:38:58 --> Model "Hospital_model" initialized
INFO - 2022-03-09 04:38:58 --> File loaded: /home3/karoteam/public_html/application/views/header.php
ERROR - 2022-03-09 04:38:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 04:38:59 --> Config Class Initialized
INFO - 2022-03-09 04:38:59 --> Hooks Class Initialized
DEBUG - 2022-03-09 04:38:59 --> UTF-8 Support Enabled
INFO - 2022-03-09 04:38:59 --> Utf8 Class Initialized
INFO - 2022-03-09 04:38:59 --> URI Class Initialized
INFO - 2022-03-09 04:38:59 --> Router Class Initialized
INFO - 2022-03-09 04:38:59 --> Output Class Initialized
INFO - 2022-03-09 04:38:59 --> Security Class Initialized
DEBUG - 2022-03-09 04:38:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 04:38:59 --> Input Class Initialized
INFO - 2022-03-09 04:38:59 --> Language Class Initialized
INFO - 2022-03-09 04:38:59 --> Loader Class Initialized
INFO - 2022-03-09 04:38:59 --> Helper loaded: url_helper
INFO - 2022-03-09 04:38:59 --> Helper loaded: form_helper
INFO - 2022-03-09 04:38:59 --> Helper loaded: common_helper
INFO - 2022-03-09 04:38:59 --> Database Driver Class Initialized
DEBUG - 2022-03-09 04:38:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 04:38:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 04:38:59 --> Controller Class Initialized
INFO - 2022-03-09 04:38:59 --> Form Validation Class Initialized
DEBUG - 2022-03-09 04:38:59 --> Encrypt Class Initialized
INFO - 2022-03-09 04:38:59 --> Model "Patient_model" initialized
INFO - 2022-03-09 04:38:59 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 04:38:59 --> Model "Prefix_master" initialized
INFO - 2022-03-09 04:38:59 --> Model "Users_model" initialized
INFO - 2022-03-09 04:38:59 --> Model "Hospital_model" initialized
ERROR - 2022-03-09 04:38:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 04:38:59 --> Config Class Initialized
INFO - 2022-03-09 04:38:59 --> Hooks Class Initialized
DEBUG - 2022-03-09 04:38:59 --> UTF-8 Support Enabled
INFO - 2022-03-09 04:38:59 --> Utf8 Class Initialized
INFO - 2022-03-09 04:38:59 --> URI Class Initialized
INFO - 2022-03-09 04:38:59 --> Router Class Initialized
INFO - 2022-03-09 04:38:59 --> Output Class Initialized
INFO - 2022-03-09 04:38:59 --> Security Class Initialized
DEBUG - 2022-03-09 04:38:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 04:38:59 --> Input Class Initialized
INFO - 2022-03-09 04:38:59 --> Language Class Initialized
INFO - 2022-03-09 04:38:59 --> Loader Class Initialized
INFO - 2022-03-09 04:38:59 --> Helper loaded: url_helper
INFO - 2022-03-09 04:38:59 --> Helper loaded: form_helper
INFO - 2022-03-09 04:38:59 --> Helper loaded: common_helper
INFO - 2022-03-09 04:38:59 --> Database Driver Class Initialized
DEBUG - 2022-03-09 04:38:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 04:38:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 04:38:59 --> Controller Class Initialized
INFO - 2022-03-09 04:38:59 --> Form Validation Class Initialized
DEBUG - 2022-03-09 04:38:59 --> Encrypt Class Initialized
INFO - 2022-03-09 04:38:59 --> Model "Patient_model" initialized
INFO - 2022-03-09 04:38:59 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 04:38:59 --> Model "Prefix_master" initialized
INFO - 2022-03-09 04:38:59 --> Model "Users_model" initialized
INFO - 2022-03-09 04:38:59 --> Model "Hospital_model" initialized
INFO - 2022-03-09 04:38:59 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 04:38:59 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-09 04:38:59 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 04:38:59 --> Final output sent to browser
DEBUG - 2022-03-09 04:38:59 --> Total execution time: 0.0540
INFO - 2022-03-09 04:39:03 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-09 04:39:03 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
ERROR - 2022-03-09 04:39:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 04:39:05 --> Config Class Initialized
INFO - 2022-03-09 04:39:05 --> Hooks Class Initialized
DEBUG - 2022-03-09 04:39:05 --> UTF-8 Support Enabled
INFO - 2022-03-09 04:39:05 --> Utf8 Class Initialized
INFO - 2022-03-09 04:39:05 --> URI Class Initialized
INFO - 2022-03-09 04:39:05 --> Router Class Initialized
INFO - 2022-03-09 04:39:05 --> Output Class Initialized
INFO - 2022-03-09 04:39:05 --> Security Class Initialized
DEBUG - 2022-03-09 04:39:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 04:39:05 --> Input Class Initialized
INFO - 2022-03-09 04:39:05 --> Language Class Initialized
ERROR - 2022-03-09 04:39:05 --> 404 Page Not Found: Karoclient/usersprofile
INFO - 2022-03-09 04:39:10 --> Final output sent to browser
DEBUG - 2022-03-09 04:39:10 --> Total execution time: 5.3551
ERROR - 2022-03-09 04:39:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 04:39:30 --> Config Class Initialized
INFO - 2022-03-09 04:39:30 --> Hooks Class Initialized
DEBUG - 2022-03-09 04:39:30 --> UTF-8 Support Enabled
INFO - 2022-03-09 04:39:30 --> Utf8 Class Initialized
INFO - 2022-03-09 04:39:30 --> URI Class Initialized
INFO - 2022-03-09 04:39:30 --> Router Class Initialized
INFO - 2022-03-09 04:39:30 --> Output Class Initialized
INFO - 2022-03-09 04:39:30 --> Security Class Initialized
DEBUG - 2022-03-09 04:39:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 04:39:30 --> Input Class Initialized
INFO - 2022-03-09 04:39:30 --> Language Class Initialized
INFO - 2022-03-09 04:39:30 --> Loader Class Initialized
INFO - 2022-03-09 04:39:30 --> Helper loaded: url_helper
INFO - 2022-03-09 04:39:30 --> Helper loaded: form_helper
INFO - 2022-03-09 04:39:30 --> Helper loaded: common_helper
INFO - 2022-03-09 04:39:30 --> Database Driver Class Initialized
DEBUG - 2022-03-09 04:39:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 04:39:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 04:39:30 --> Controller Class Initialized
INFO - 2022-03-09 04:39:30 --> Form Validation Class Initialized
DEBUG - 2022-03-09 04:39:30 --> Encrypt Class Initialized
INFO - 2022-03-09 04:39:30 --> Model "Patient_model" initialized
INFO - 2022-03-09 04:39:30 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 04:39:30 --> Model "Referredby_model" initialized
INFO - 2022-03-09 04:39:30 --> Model "Prefix_master" initialized
INFO - 2022-03-09 04:39:30 --> Model "Hospital_model" initialized
INFO - 2022-03-09 04:39:30 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 04:39:30 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-09 04:39:30 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 04:39:30 --> Final output sent to browser
DEBUG - 2022-03-09 04:39:30 --> Total execution time: 0.0648
ERROR - 2022-03-09 04:39:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 04:39:31 --> Config Class Initialized
INFO - 2022-03-09 04:39:31 --> Hooks Class Initialized
DEBUG - 2022-03-09 04:39:31 --> UTF-8 Support Enabled
INFO - 2022-03-09 04:39:31 --> Utf8 Class Initialized
INFO - 2022-03-09 04:39:31 --> URI Class Initialized
INFO - 2022-03-09 04:39:31 --> Router Class Initialized
INFO - 2022-03-09 04:39:31 --> Output Class Initialized
INFO - 2022-03-09 04:39:31 --> Security Class Initialized
DEBUG - 2022-03-09 04:39:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 04:39:31 --> Input Class Initialized
INFO - 2022-03-09 04:39:31 --> Language Class Initialized
ERROR - 2022-03-09 04:39:31 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-09 04:39:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 04:39:31 --> Config Class Initialized
INFO - 2022-03-09 04:39:31 --> Hooks Class Initialized
DEBUG - 2022-03-09 04:39:31 --> UTF-8 Support Enabled
INFO - 2022-03-09 04:39:31 --> Utf8 Class Initialized
INFO - 2022-03-09 04:39:31 --> URI Class Initialized
INFO - 2022-03-09 04:39:31 --> Router Class Initialized
INFO - 2022-03-09 04:39:31 --> Output Class Initialized
INFO - 2022-03-09 04:39:31 --> Security Class Initialized
DEBUG - 2022-03-09 04:39:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 04:39:31 --> Input Class Initialized
INFO - 2022-03-09 04:39:31 --> Language Class Initialized
ERROR - 2022-03-09 04:39:31 --> 404 Page Not Found: Karoclient/images
ERROR - 2022-03-09 04:49:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 04:49:25 --> Config Class Initialized
INFO - 2022-03-09 04:49:25 --> Hooks Class Initialized
DEBUG - 2022-03-09 04:49:25 --> UTF-8 Support Enabled
INFO - 2022-03-09 04:49:25 --> Utf8 Class Initialized
INFO - 2022-03-09 04:49:25 --> URI Class Initialized
INFO - 2022-03-09 04:49:25 --> Router Class Initialized
INFO - 2022-03-09 04:49:25 --> Output Class Initialized
INFO - 2022-03-09 04:49:25 --> Security Class Initialized
DEBUG - 2022-03-09 04:49:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 04:49:25 --> Input Class Initialized
INFO - 2022-03-09 04:49:25 --> Language Class Initialized
INFO - 2022-03-09 04:49:25 --> Loader Class Initialized
INFO - 2022-03-09 04:49:25 --> Helper loaded: url_helper
INFO - 2022-03-09 04:49:25 --> Helper loaded: form_helper
INFO - 2022-03-09 04:49:25 --> Helper loaded: common_helper
INFO - 2022-03-09 04:49:25 --> Database Driver Class Initialized
DEBUG - 2022-03-09 04:49:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 04:49:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 04:49:25 --> Controller Class Initialized
INFO - 2022-03-09 04:49:25 --> Form Validation Class Initialized
DEBUG - 2022-03-09 04:49:25 --> Encrypt Class Initialized
INFO - 2022-03-09 04:49:25 --> Model "Patient_model" initialized
INFO - 2022-03-09 04:49:25 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 04:49:25 --> Model "Prefix_master" initialized
INFO - 2022-03-09 04:49:25 --> Model "Users_model" initialized
INFO - 2022-03-09 04:49:25 --> Model "Hospital_model" initialized
ERROR - 2022-03-09 04:49:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 04:49:26 --> Config Class Initialized
INFO - 2022-03-09 04:49:26 --> Hooks Class Initialized
DEBUG - 2022-03-09 04:49:26 --> UTF-8 Support Enabled
INFO - 2022-03-09 04:49:26 --> Utf8 Class Initialized
INFO - 2022-03-09 04:49:26 --> URI Class Initialized
INFO - 2022-03-09 04:49:26 --> Router Class Initialized
INFO - 2022-03-09 04:49:26 --> Output Class Initialized
INFO - 2022-03-09 04:49:26 --> Security Class Initialized
DEBUG - 2022-03-09 04:49:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 04:49:26 --> Input Class Initialized
INFO - 2022-03-09 04:49:26 --> Language Class Initialized
INFO - 2022-03-09 04:49:26 --> Loader Class Initialized
INFO - 2022-03-09 04:49:26 --> Helper loaded: url_helper
INFO - 2022-03-09 04:49:26 --> Helper loaded: form_helper
INFO - 2022-03-09 04:49:26 --> Helper loaded: common_helper
INFO - 2022-03-09 04:49:26 --> Database Driver Class Initialized
DEBUG - 2022-03-09 04:49:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 04:49:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 04:49:26 --> Controller Class Initialized
INFO - 2022-03-09 04:49:26 --> Form Validation Class Initialized
DEBUG - 2022-03-09 04:49:26 --> Encrypt Class Initialized
INFO - 2022-03-09 04:49:26 --> Model "Patient_model" initialized
INFO - 2022-03-09 04:49:26 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 04:49:26 --> Model "Prefix_master" initialized
INFO - 2022-03-09 04:49:26 --> Model "Users_model" initialized
INFO - 2022-03-09 04:49:26 --> Model "Hospital_model" initialized
INFO - 2022-03-09 04:49:26 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 04:49:26 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-09 04:49:26 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 04:49:26 --> Final output sent to browser
DEBUG - 2022-03-09 04:49:26 --> Total execution time: 0.0750
ERROR - 2022-03-09 05:00:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 05:00:40 --> Config Class Initialized
INFO - 2022-03-09 05:00:40 --> Hooks Class Initialized
DEBUG - 2022-03-09 05:00:40 --> UTF-8 Support Enabled
INFO - 2022-03-09 05:00:40 --> Utf8 Class Initialized
INFO - 2022-03-09 05:00:40 --> URI Class Initialized
INFO - 2022-03-09 05:00:40 --> Router Class Initialized
INFO - 2022-03-09 05:00:40 --> Output Class Initialized
INFO - 2022-03-09 05:00:40 --> Security Class Initialized
DEBUG - 2022-03-09 05:00:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 05:00:40 --> Input Class Initialized
INFO - 2022-03-09 05:00:40 --> Language Class Initialized
INFO - 2022-03-09 05:00:40 --> Loader Class Initialized
INFO - 2022-03-09 05:00:40 --> Helper loaded: url_helper
INFO - 2022-03-09 05:00:40 --> Helper loaded: form_helper
INFO - 2022-03-09 05:00:40 --> Helper loaded: common_helper
INFO - 2022-03-09 05:00:40 --> Database Driver Class Initialized
DEBUG - 2022-03-09 05:00:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 05:00:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 05:00:40 --> Controller Class Initialized
INFO - 2022-03-09 05:00:40 --> Form Validation Class Initialized
DEBUG - 2022-03-09 05:00:40 --> Encrypt Class Initialized
INFO - 2022-03-09 05:00:40 --> Model "Patient_model" initialized
INFO - 2022-03-09 05:00:40 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 05:00:40 --> Model "Prefix_master" initialized
INFO - 2022-03-09 05:00:40 --> Model "Users_model" initialized
INFO - 2022-03-09 05:00:40 --> Model "Hospital_model" initialized
INFO - 2022-03-09 05:00:40 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 05:00:40 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-09 05:00:40 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 05:00:40 --> Final output sent to browser
DEBUG - 2022-03-09 05:00:40 --> Total execution time: 0.0879
ERROR - 2022-03-09 05:01:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 05:01:23 --> Config Class Initialized
INFO - 2022-03-09 05:01:23 --> Hooks Class Initialized
DEBUG - 2022-03-09 05:01:23 --> UTF-8 Support Enabled
INFO - 2022-03-09 05:01:23 --> Utf8 Class Initialized
INFO - 2022-03-09 05:01:23 --> URI Class Initialized
INFO - 2022-03-09 05:01:23 --> Router Class Initialized
INFO - 2022-03-09 05:01:23 --> Output Class Initialized
INFO - 2022-03-09 05:01:23 --> Security Class Initialized
DEBUG - 2022-03-09 05:01:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 05:01:23 --> Input Class Initialized
INFO - 2022-03-09 05:01:23 --> Language Class Initialized
INFO - 2022-03-09 05:01:23 --> Loader Class Initialized
INFO - 2022-03-09 05:01:23 --> Helper loaded: url_helper
INFO - 2022-03-09 05:01:23 --> Helper loaded: form_helper
INFO - 2022-03-09 05:01:23 --> Helper loaded: common_helper
INFO - 2022-03-09 05:01:23 --> Database Driver Class Initialized
DEBUG - 2022-03-09 05:01:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 05:01:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 05:01:23 --> Controller Class Initialized
INFO - 2022-03-09 05:01:23 --> Form Validation Class Initialized
DEBUG - 2022-03-09 05:01:23 --> Encrypt Class Initialized
INFO - 2022-03-09 05:01:23 --> Model "Patient_model" initialized
INFO - 2022-03-09 05:01:23 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 05:01:23 --> Model "Prefix_master" initialized
INFO - 2022-03-09 05:01:23 --> Model "Users_model" initialized
INFO - 2022-03-09 05:01:23 --> Model "Hospital_model" initialized
ERROR - 2022-03-09 05:01:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 05:01:24 --> Config Class Initialized
INFO - 2022-03-09 05:01:24 --> Hooks Class Initialized
DEBUG - 2022-03-09 05:01:24 --> UTF-8 Support Enabled
INFO - 2022-03-09 05:01:24 --> Utf8 Class Initialized
INFO - 2022-03-09 05:01:24 --> URI Class Initialized
INFO - 2022-03-09 05:01:24 --> Router Class Initialized
INFO - 2022-03-09 05:01:24 --> Output Class Initialized
INFO - 2022-03-09 05:01:24 --> Security Class Initialized
DEBUG - 2022-03-09 05:01:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 05:01:24 --> Input Class Initialized
INFO - 2022-03-09 05:01:24 --> Language Class Initialized
INFO - 2022-03-09 05:01:24 --> Loader Class Initialized
INFO - 2022-03-09 05:01:24 --> Helper loaded: url_helper
INFO - 2022-03-09 05:01:24 --> Helper loaded: form_helper
INFO - 2022-03-09 05:01:24 --> Helper loaded: common_helper
INFO - 2022-03-09 05:01:24 --> Database Driver Class Initialized
DEBUG - 2022-03-09 05:01:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 05:01:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 05:01:24 --> Controller Class Initialized
INFO - 2022-03-09 05:01:24 --> Form Validation Class Initialized
DEBUG - 2022-03-09 05:01:24 --> Encrypt Class Initialized
INFO - 2022-03-09 05:01:24 --> Model "Patient_model" initialized
INFO - 2022-03-09 05:01:24 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 05:01:24 --> Model "Prefix_master" initialized
INFO - 2022-03-09 05:01:24 --> Model "Users_model" initialized
INFO - 2022-03-09 05:01:24 --> Model "Hospital_model" initialized
INFO - 2022-03-09 05:01:24 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 05:01:24 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-09 05:01:24 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 05:01:24 --> Final output sent to browser
DEBUG - 2022-03-09 05:01:24 --> Total execution time: 0.0644
ERROR - 2022-03-09 05:51:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 05:51:53 --> Config Class Initialized
INFO - 2022-03-09 05:51:53 --> Hooks Class Initialized
DEBUG - 2022-03-09 05:51:53 --> UTF-8 Support Enabled
INFO - 2022-03-09 05:51:53 --> Utf8 Class Initialized
INFO - 2022-03-09 05:51:53 --> URI Class Initialized
INFO - 2022-03-09 05:51:53 --> Router Class Initialized
INFO - 2022-03-09 05:51:53 --> Output Class Initialized
INFO - 2022-03-09 05:51:53 --> Security Class Initialized
DEBUG - 2022-03-09 05:51:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 05:51:53 --> Input Class Initialized
INFO - 2022-03-09 05:51:53 --> Language Class Initialized
INFO - 2022-03-09 05:51:53 --> Loader Class Initialized
INFO - 2022-03-09 05:51:53 --> Helper loaded: url_helper
INFO - 2022-03-09 05:51:53 --> Helper loaded: form_helper
INFO - 2022-03-09 05:51:53 --> Helper loaded: common_helper
INFO - 2022-03-09 05:51:53 --> Database Driver Class Initialized
DEBUG - 2022-03-09 05:51:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 05:51:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 05:51:53 --> Controller Class Initialized
INFO - 2022-03-09 05:51:53 --> Form Validation Class Initialized
DEBUG - 2022-03-09 05:51:53 --> Encrypt Class Initialized
INFO - 2022-03-09 05:51:53 --> Model "Patient_model" initialized
INFO - 2022-03-09 05:51:53 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 05:51:53 --> Model "Referredby_model" initialized
INFO - 2022-03-09 05:51:53 --> Model "Prefix_master" initialized
INFO - 2022-03-09 05:51:53 --> Model "Hospital_model" initialized
INFO - 2022-03-09 05:51:54 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 05:51:54 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-09 05:51:54 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 05:51:54 --> Final output sent to browser
DEBUG - 2022-03-09 05:51:54 --> Total execution time: 0.0743
ERROR - 2022-03-09 05:52:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 05:52:44 --> Config Class Initialized
INFO - 2022-03-09 05:52:44 --> Hooks Class Initialized
DEBUG - 2022-03-09 05:52:44 --> UTF-8 Support Enabled
INFO - 2022-03-09 05:52:44 --> Utf8 Class Initialized
INFO - 2022-03-09 05:52:44 --> URI Class Initialized
INFO - 2022-03-09 05:52:44 --> Router Class Initialized
INFO - 2022-03-09 05:52:44 --> Output Class Initialized
INFO - 2022-03-09 05:52:44 --> Security Class Initialized
DEBUG - 2022-03-09 05:52:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 05:52:44 --> Input Class Initialized
INFO - 2022-03-09 05:52:44 --> Language Class Initialized
INFO - 2022-03-09 05:52:44 --> Loader Class Initialized
INFO - 2022-03-09 05:52:44 --> Helper loaded: url_helper
INFO - 2022-03-09 05:52:44 --> Helper loaded: form_helper
INFO - 2022-03-09 05:52:44 --> Helper loaded: common_helper
INFO - 2022-03-09 05:52:44 --> Database Driver Class Initialized
DEBUG - 2022-03-09 05:52:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 05:52:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 05:52:44 --> Controller Class Initialized
INFO - 2022-03-09 05:52:44 --> Form Validation Class Initialized
DEBUG - 2022-03-09 05:52:44 --> Encrypt Class Initialized
INFO - 2022-03-09 05:52:44 --> Model "Patient_model" initialized
INFO - 2022-03-09 05:52:44 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 05:52:44 --> Model "Prefix_master" initialized
INFO - 2022-03-09 05:52:44 --> Model "Users_model" initialized
INFO - 2022-03-09 05:52:44 --> Model "Hospital_model" initialized
INFO - 2022-03-09 05:52:44 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 05:52:44 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-09 05:52:44 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 05:52:44 --> Final output sent to browser
DEBUG - 2022-03-09 05:52:44 --> Total execution time: 0.0899
ERROR - 2022-03-09 05:52:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 05:52:55 --> Config Class Initialized
INFO - 2022-03-09 05:52:55 --> Hooks Class Initialized
DEBUG - 2022-03-09 05:52:55 --> UTF-8 Support Enabled
INFO - 2022-03-09 05:52:55 --> Utf8 Class Initialized
INFO - 2022-03-09 05:52:55 --> URI Class Initialized
INFO - 2022-03-09 05:52:55 --> Router Class Initialized
INFO - 2022-03-09 05:52:55 --> Output Class Initialized
INFO - 2022-03-09 05:52:55 --> Security Class Initialized
DEBUG - 2022-03-09 05:52:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 05:52:55 --> Input Class Initialized
INFO - 2022-03-09 05:52:55 --> Language Class Initialized
INFO - 2022-03-09 05:52:55 --> Loader Class Initialized
INFO - 2022-03-09 05:52:55 --> Helper loaded: url_helper
INFO - 2022-03-09 05:52:55 --> Helper loaded: form_helper
INFO - 2022-03-09 05:52:55 --> Helper loaded: common_helper
INFO - 2022-03-09 05:52:55 --> Database Driver Class Initialized
DEBUG - 2022-03-09 05:52:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 05:52:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 05:52:55 --> Controller Class Initialized
INFO - 2022-03-09 05:52:55 --> Form Validation Class Initialized
DEBUG - 2022-03-09 05:52:55 --> Encrypt Class Initialized
INFO - 2022-03-09 05:52:55 --> Model "Patient_model" initialized
INFO - 2022-03-09 05:52:55 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 05:52:55 --> Model "Referredby_model" initialized
INFO - 2022-03-09 05:52:55 --> Model "Prefix_master" initialized
INFO - 2022-03-09 05:52:55 --> Model "Hospital_model" initialized
INFO - 2022-03-09 05:52:55 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 05:52:55 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-09 05:52:55 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 05:52:55 --> Final output sent to browser
DEBUG - 2022-03-09 05:52:55 --> Total execution time: 0.0672
ERROR - 2022-03-09 05:53:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 05:53:04 --> Config Class Initialized
INFO - 2022-03-09 05:53:04 --> Hooks Class Initialized
DEBUG - 2022-03-09 05:53:04 --> UTF-8 Support Enabled
INFO - 2022-03-09 05:53:04 --> Utf8 Class Initialized
INFO - 2022-03-09 05:53:04 --> URI Class Initialized
INFO - 2022-03-09 05:53:04 --> Router Class Initialized
INFO - 2022-03-09 05:53:04 --> Output Class Initialized
INFO - 2022-03-09 05:53:04 --> Security Class Initialized
DEBUG - 2022-03-09 05:53:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 05:53:04 --> Input Class Initialized
INFO - 2022-03-09 05:53:04 --> Language Class Initialized
INFO - 2022-03-09 05:53:04 --> Loader Class Initialized
INFO - 2022-03-09 05:53:04 --> Helper loaded: url_helper
INFO - 2022-03-09 05:53:04 --> Helper loaded: form_helper
INFO - 2022-03-09 05:53:04 --> Helper loaded: common_helper
INFO - 2022-03-09 05:53:04 --> Database Driver Class Initialized
DEBUG - 2022-03-09 05:53:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 05:53:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 05:53:04 --> Controller Class Initialized
INFO - 2022-03-09 05:53:04 --> Form Validation Class Initialized
DEBUG - 2022-03-09 05:53:04 --> Encrypt Class Initialized
INFO - 2022-03-09 05:53:04 --> Model "Patient_model" initialized
INFO - 2022-03-09 05:53:04 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 05:53:04 --> Model "Prefix_master" initialized
INFO - 2022-03-09 05:53:04 --> Model "Users_model" initialized
INFO - 2022-03-09 05:53:04 --> Model "Hospital_model" initialized
INFO - 2022-03-09 05:53:04 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 05:53:04 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-09 05:53:04 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 05:53:04 --> Final output sent to browser
DEBUG - 2022-03-09 05:53:04 --> Total execution time: 0.0786
ERROR - 2022-03-09 05:53:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 05:53:10 --> Config Class Initialized
INFO - 2022-03-09 05:53:10 --> Hooks Class Initialized
DEBUG - 2022-03-09 05:53:10 --> UTF-8 Support Enabled
INFO - 2022-03-09 05:53:10 --> Utf8 Class Initialized
INFO - 2022-03-09 05:53:10 --> URI Class Initialized
INFO - 2022-03-09 05:53:10 --> Router Class Initialized
INFO - 2022-03-09 05:53:10 --> Output Class Initialized
INFO - 2022-03-09 05:53:10 --> Security Class Initialized
DEBUG - 2022-03-09 05:53:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 05:53:10 --> Input Class Initialized
INFO - 2022-03-09 05:53:10 --> Language Class Initialized
INFO - 2022-03-09 05:53:10 --> Loader Class Initialized
INFO - 2022-03-09 05:53:10 --> Helper loaded: url_helper
INFO - 2022-03-09 05:53:10 --> Helper loaded: form_helper
INFO - 2022-03-09 05:53:10 --> Helper loaded: common_helper
INFO - 2022-03-09 05:53:10 --> Database Driver Class Initialized
DEBUG - 2022-03-09 05:53:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 05:53:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 05:53:10 --> Controller Class Initialized
INFO - 2022-03-09 05:53:10 --> Form Validation Class Initialized
DEBUG - 2022-03-09 05:53:10 --> Encrypt Class Initialized
INFO - 2022-03-09 05:53:10 --> Model "Patient_model" initialized
INFO - 2022-03-09 05:53:10 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 05:53:10 --> Model "Referredby_model" initialized
INFO - 2022-03-09 05:53:10 --> Model "Prefix_master" initialized
INFO - 2022-03-09 05:53:10 --> Model "Hospital_model" initialized
ERROR - 2022-03-09 05:53:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 05:53:10 --> Config Class Initialized
INFO - 2022-03-09 05:53:10 --> Hooks Class Initialized
DEBUG - 2022-03-09 05:53:10 --> UTF-8 Support Enabled
INFO - 2022-03-09 05:53:10 --> Utf8 Class Initialized
INFO - 2022-03-09 05:53:10 --> URI Class Initialized
INFO - 2022-03-09 05:53:10 --> Router Class Initialized
INFO - 2022-03-09 05:53:10 --> Output Class Initialized
INFO - 2022-03-09 05:53:10 --> Security Class Initialized
DEBUG - 2022-03-09 05:53:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 05:53:10 --> Input Class Initialized
INFO - 2022-03-09 05:53:10 --> Language Class Initialized
INFO - 2022-03-09 05:53:10 --> Loader Class Initialized
INFO - 2022-03-09 05:53:10 --> Helper loaded: url_helper
INFO - 2022-03-09 05:53:10 --> Helper loaded: form_helper
INFO - 2022-03-09 05:53:10 --> Helper loaded: common_helper
INFO - 2022-03-09 05:53:10 --> Database Driver Class Initialized
DEBUG - 2022-03-09 05:53:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 05:53:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 05:53:10 --> Controller Class Initialized
INFO - 2022-03-09 05:53:10 --> Form Validation Class Initialized
DEBUG - 2022-03-09 05:53:10 --> Encrypt Class Initialized
INFO - 2022-03-09 05:53:10 --> Model "Patient_model" initialized
INFO - 2022-03-09 05:53:10 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 05:53:10 --> Model "Referredby_model" initialized
INFO - 2022-03-09 05:53:10 --> Model "Prefix_master" initialized
INFO - 2022-03-09 05:53:10 --> Model "Hospital_model" initialized
INFO - 2022-03-09 05:53:10 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 05:53:10 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-09 05:53:10 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 05:53:10 --> Final output sent to browser
DEBUG - 2022-03-09 05:53:10 --> Total execution time: 0.0533
ERROR - 2022-03-09 05:53:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 05:53:11 --> Config Class Initialized
INFO - 2022-03-09 05:53:11 --> Hooks Class Initialized
DEBUG - 2022-03-09 05:53:11 --> UTF-8 Support Enabled
INFO - 2022-03-09 05:53:11 --> Utf8 Class Initialized
INFO - 2022-03-09 05:53:11 --> URI Class Initialized
INFO - 2022-03-09 05:53:11 --> Router Class Initialized
INFO - 2022-03-09 05:53:11 --> Output Class Initialized
INFO - 2022-03-09 05:53:11 --> Security Class Initialized
DEBUG - 2022-03-09 05:53:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 05:53:11 --> Input Class Initialized
INFO - 2022-03-09 05:53:11 --> Language Class Initialized
INFO - 2022-03-09 05:53:11 --> Loader Class Initialized
INFO - 2022-03-09 05:53:11 --> Helper loaded: url_helper
INFO - 2022-03-09 05:53:11 --> Helper loaded: form_helper
INFO - 2022-03-09 05:53:11 --> Helper loaded: common_helper
INFO - 2022-03-09 05:53:11 --> Database Driver Class Initialized
DEBUG - 2022-03-09 05:53:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 05:53:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 05:53:11 --> Controller Class Initialized
INFO - 2022-03-09 05:53:11 --> Form Validation Class Initialized
DEBUG - 2022-03-09 05:53:11 --> Encrypt Class Initialized
INFO - 2022-03-09 05:53:11 --> Model "Patient_model" initialized
INFO - 2022-03-09 05:53:11 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 05:53:11 --> Model "Prefix_master" initialized
INFO - 2022-03-09 05:53:11 --> Model "Users_model" initialized
INFO - 2022-03-09 05:53:11 --> Model "Hospital_model" initialized
INFO - 2022-03-09 05:53:11 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 05:53:11 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-09 05:53:11 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 05:53:11 --> Final output sent to browser
DEBUG - 2022-03-09 05:53:11 --> Total execution time: 0.0776
ERROR - 2022-03-09 05:54:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 05:54:27 --> Config Class Initialized
INFO - 2022-03-09 05:54:27 --> Hooks Class Initialized
DEBUG - 2022-03-09 05:54:27 --> UTF-8 Support Enabled
INFO - 2022-03-09 05:54:27 --> Utf8 Class Initialized
INFO - 2022-03-09 05:54:27 --> URI Class Initialized
INFO - 2022-03-09 05:54:27 --> Router Class Initialized
INFO - 2022-03-09 05:54:27 --> Output Class Initialized
INFO - 2022-03-09 05:54:27 --> Security Class Initialized
DEBUG - 2022-03-09 05:54:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 05:54:27 --> Input Class Initialized
INFO - 2022-03-09 05:54:27 --> Language Class Initialized
INFO - 2022-03-09 05:54:27 --> Loader Class Initialized
INFO - 2022-03-09 05:54:27 --> Helper loaded: url_helper
INFO - 2022-03-09 05:54:27 --> Helper loaded: form_helper
INFO - 2022-03-09 05:54:27 --> Helper loaded: common_helper
INFO - 2022-03-09 05:54:27 --> Database Driver Class Initialized
DEBUG - 2022-03-09 05:54:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 05:54:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 05:54:27 --> Controller Class Initialized
INFO - 2022-03-09 05:54:27 --> Form Validation Class Initialized
DEBUG - 2022-03-09 05:54:27 --> Encrypt Class Initialized
INFO - 2022-03-09 05:54:27 --> Model "Patient_model" initialized
INFO - 2022-03-09 05:54:27 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 05:54:27 --> Model "Prefix_master" initialized
INFO - 2022-03-09 05:54:27 --> Model "Users_model" initialized
INFO - 2022-03-09 05:54:27 --> Model "Hospital_model" initialized
ERROR - 2022-03-09 05:54:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 05:54:28 --> Config Class Initialized
INFO - 2022-03-09 05:54:28 --> Hooks Class Initialized
DEBUG - 2022-03-09 05:54:28 --> UTF-8 Support Enabled
INFO - 2022-03-09 05:54:28 --> Utf8 Class Initialized
INFO - 2022-03-09 05:54:28 --> URI Class Initialized
INFO - 2022-03-09 05:54:28 --> Router Class Initialized
INFO - 2022-03-09 05:54:28 --> Output Class Initialized
INFO - 2022-03-09 05:54:28 --> Security Class Initialized
DEBUG - 2022-03-09 05:54:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 05:54:28 --> Input Class Initialized
INFO - 2022-03-09 05:54:28 --> Language Class Initialized
INFO - 2022-03-09 05:54:28 --> Loader Class Initialized
INFO - 2022-03-09 05:54:28 --> Helper loaded: url_helper
INFO - 2022-03-09 05:54:28 --> Helper loaded: form_helper
INFO - 2022-03-09 05:54:28 --> Helper loaded: common_helper
INFO - 2022-03-09 05:54:28 --> Database Driver Class Initialized
DEBUG - 2022-03-09 05:54:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 05:54:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 05:54:28 --> Controller Class Initialized
INFO - 2022-03-09 05:54:28 --> Form Validation Class Initialized
DEBUG - 2022-03-09 05:54:28 --> Encrypt Class Initialized
INFO - 2022-03-09 05:54:28 --> Model "Patient_model" initialized
INFO - 2022-03-09 05:54:28 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 05:54:28 --> Model "Prefix_master" initialized
INFO - 2022-03-09 05:54:28 --> Model "Users_model" initialized
INFO - 2022-03-09 05:54:28 --> Model "Hospital_model" initialized
INFO - 2022-03-09 05:54:28 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 05:54:28 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-09 05:54:28 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 05:54:28 --> Final output sent to browser
DEBUG - 2022-03-09 05:54:28 --> Total execution time: 0.0678
ERROR - 2022-03-09 05:54:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 05:54:38 --> Config Class Initialized
INFO - 2022-03-09 05:54:38 --> Hooks Class Initialized
DEBUG - 2022-03-09 05:54:38 --> UTF-8 Support Enabled
INFO - 2022-03-09 05:54:38 --> Utf8 Class Initialized
INFO - 2022-03-09 05:54:38 --> URI Class Initialized
INFO - 2022-03-09 05:54:38 --> Router Class Initialized
INFO - 2022-03-09 05:54:38 --> Output Class Initialized
INFO - 2022-03-09 05:54:38 --> Security Class Initialized
DEBUG - 2022-03-09 05:54:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 05:54:38 --> Input Class Initialized
INFO - 2022-03-09 05:54:38 --> Language Class Initialized
INFO - 2022-03-09 05:54:38 --> Loader Class Initialized
INFO - 2022-03-09 05:54:38 --> Helper loaded: url_helper
INFO - 2022-03-09 05:54:38 --> Helper loaded: form_helper
INFO - 2022-03-09 05:54:38 --> Helper loaded: common_helper
INFO - 2022-03-09 05:54:38 --> Database Driver Class Initialized
DEBUG - 2022-03-09 05:54:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 05:54:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 05:54:38 --> Controller Class Initialized
INFO - 2022-03-09 05:54:38 --> Form Validation Class Initialized
DEBUG - 2022-03-09 05:54:38 --> Encrypt Class Initialized
INFO - 2022-03-09 05:54:38 --> Model "Patient_model" initialized
INFO - 2022-03-09 05:54:38 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 05:54:38 --> Model "Prefix_master" initialized
INFO - 2022-03-09 05:54:38 --> Model "Users_model" initialized
INFO - 2022-03-09 05:54:38 --> Model "Hospital_model" initialized
INFO - 2022-03-09 05:54:38 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 05:54:38 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-09 05:54:38 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 05:54:38 --> Final output sent to browser
DEBUG - 2022-03-09 05:54:38 --> Total execution time: 0.0569
ERROR - 2022-03-09 05:54:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 05:54:53 --> Config Class Initialized
INFO - 2022-03-09 05:54:53 --> Hooks Class Initialized
DEBUG - 2022-03-09 05:54:53 --> UTF-8 Support Enabled
INFO - 2022-03-09 05:54:53 --> Utf8 Class Initialized
INFO - 2022-03-09 05:54:53 --> URI Class Initialized
INFO - 2022-03-09 05:54:53 --> Router Class Initialized
INFO - 2022-03-09 05:54:53 --> Output Class Initialized
INFO - 2022-03-09 05:54:53 --> Security Class Initialized
DEBUG - 2022-03-09 05:54:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 05:54:53 --> Input Class Initialized
INFO - 2022-03-09 05:54:53 --> Language Class Initialized
INFO - 2022-03-09 05:54:53 --> Loader Class Initialized
INFO - 2022-03-09 05:54:53 --> Helper loaded: url_helper
INFO - 2022-03-09 05:54:53 --> Helper loaded: form_helper
INFO - 2022-03-09 05:54:53 --> Helper loaded: common_helper
INFO - 2022-03-09 05:54:53 --> Database Driver Class Initialized
DEBUG - 2022-03-09 05:54:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 05:54:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 05:54:53 --> Controller Class Initialized
INFO - 2022-03-09 05:54:53 --> Form Validation Class Initialized
DEBUG - 2022-03-09 05:54:53 --> Encrypt Class Initialized
INFO - 2022-03-09 05:54:53 --> Model "Patient_model" initialized
INFO - 2022-03-09 05:54:53 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 05:54:53 --> Model "Referredby_model" initialized
INFO - 2022-03-09 05:54:53 --> Model "Prefix_master" initialized
INFO - 2022-03-09 05:54:53 --> Model "Hospital_model" initialized
INFO - 2022-03-09 05:54:53 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 05:54:53 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-09 05:54:53 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 05:54:53 --> Final output sent to browser
DEBUG - 2022-03-09 05:54:53 --> Total execution time: 0.0561
ERROR - 2022-03-09 05:55:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 05:55:58 --> Config Class Initialized
INFO - 2022-03-09 05:55:58 --> Hooks Class Initialized
DEBUG - 2022-03-09 05:55:58 --> UTF-8 Support Enabled
INFO - 2022-03-09 05:55:58 --> Utf8 Class Initialized
INFO - 2022-03-09 05:55:58 --> URI Class Initialized
INFO - 2022-03-09 05:55:58 --> Router Class Initialized
INFO - 2022-03-09 05:55:58 --> Output Class Initialized
INFO - 2022-03-09 05:55:58 --> Security Class Initialized
DEBUG - 2022-03-09 05:55:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 05:55:58 --> Input Class Initialized
INFO - 2022-03-09 05:55:58 --> Language Class Initialized
INFO - 2022-03-09 05:55:58 --> Loader Class Initialized
INFO - 2022-03-09 05:55:58 --> Helper loaded: url_helper
INFO - 2022-03-09 05:55:58 --> Helper loaded: form_helper
INFO - 2022-03-09 05:55:58 --> Helper loaded: common_helper
INFO - 2022-03-09 05:55:58 --> Database Driver Class Initialized
DEBUG - 2022-03-09 05:55:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 05:55:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 05:55:58 --> Controller Class Initialized
INFO - 2022-03-09 05:55:58 --> Form Validation Class Initialized
DEBUG - 2022-03-09 05:55:58 --> Encrypt Class Initialized
INFO - 2022-03-09 05:55:58 --> Model "Patient_model" initialized
INFO - 2022-03-09 05:55:58 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 05:55:58 --> Model "Referredby_model" initialized
INFO - 2022-03-09 05:55:58 --> Model "Prefix_master" initialized
INFO - 2022-03-09 05:55:58 --> Model "Hospital_model" initialized
ERROR - 2022-03-09 05:55:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 05:55:58 --> Config Class Initialized
INFO - 2022-03-09 05:55:58 --> Hooks Class Initialized
DEBUG - 2022-03-09 05:55:58 --> UTF-8 Support Enabled
INFO - 2022-03-09 05:55:58 --> Utf8 Class Initialized
INFO - 2022-03-09 05:55:58 --> URI Class Initialized
INFO - 2022-03-09 05:55:58 --> Router Class Initialized
INFO - 2022-03-09 05:55:58 --> Output Class Initialized
INFO - 2022-03-09 05:55:58 --> Security Class Initialized
DEBUG - 2022-03-09 05:55:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 05:55:58 --> Input Class Initialized
INFO - 2022-03-09 05:55:58 --> Language Class Initialized
INFO - 2022-03-09 05:55:58 --> Loader Class Initialized
INFO - 2022-03-09 05:55:58 --> Helper loaded: url_helper
INFO - 2022-03-09 05:55:58 --> Helper loaded: form_helper
INFO - 2022-03-09 05:55:58 --> Helper loaded: common_helper
INFO - 2022-03-09 05:55:58 --> Database Driver Class Initialized
DEBUG - 2022-03-09 05:55:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 05:55:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 05:55:58 --> Controller Class Initialized
INFO - 2022-03-09 05:55:58 --> Form Validation Class Initialized
DEBUG - 2022-03-09 05:55:58 --> Encrypt Class Initialized
INFO - 2022-03-09 05:55:58 --> Model "Patient_model" initialized
INFO - 2022-03-09 05:55:58 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 05:55:58 --> Model "Referredby_model" initialized
INFO - 2022-03-09 05:55:58 --> Model "Prefix_master" initialized
INFO - 2022-03-09 05:55:58 --> Model "Hospital_model" initialized
INFO - 2022-03-09 05:55:58 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 05:55:58 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-09 05:55:58 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 05:55:58 --> Final output sent to browser
DEBUG - 2022-03-09 05:55:58 --> Total execution time: 0.0442
ERROR - 2022-03-09 05:55:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 05:55:59 --> Config Class Initialized
INFO - 2022-03-09 05:55:59 --> Hooks Class Initialized
DEBUG - 2022-03-09 05:55:59 --> UTF-8 Support Enabled
INFO - 2022-03-09 05:55:59 --> Utf8 Class Initialized
INFO - 2022-03-09 05:55:59 --> URI Class Initialized
INFO - 2022-03-09 05:55:59 --> Router Class Initialized
INFO - 2022-03-09 05:55:59 --> Output Class Initialized
INFO - 2022-03-09 05:55:59 --> Security Class Initialized
DEBUG - 2022-03-09 05:55:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 05:55:59 --> Input Class Initialized
INFO - 2022-03-09 05:55:59 --> Language Class Initialized
INFO - 2022-03-09 05:55:59 --> Loader Class Initialized
INFO - 2022-03-09 05:55:59 --> Helper loaded: url_helper
INFO - 2022-03-09 05:55:59 --> Helper loaded: form_helper
INFO - 2022-03-09 05:55:59 --> Helper loaded: common_helper
INFO - 2022-03-09 05:55:59 --> Database Driver Class Initialized
DEBUG - 2022-03-09 05:55:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 05:55:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 05:55:59 --> Controller Class Initialized
INFO - 2022-03-09 05:55:59 --> Form Validation Class Initialized
DEBUG - 2022-03-09 05:55:59 --> Encrypt Class Initialized
INFO - 2022-03-09 05:55:59 --> Model "Patient_model" initialized
INFO - 2022-03-09 05:55:59 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 05:55:59 --> Model "Prefix_master" initialized
INFO - 2022-03-09 05:55:59 --> Model "Users_model" initialized
INFO - 2022-03-09 05:55:59 --> Model "Hospital_model" initialized
INFO - 2022-03-09 05:55:59 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 05:55:59 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-09 05:55:59 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 05:55:59 --> Final output sent to browser
DEBUG - 2022-03-09 05:55:59 --> Total execution time: 0.0599
ERROR - 2022-03-09 05:58:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 05:58:39 --> Config Class Initialized
INFO - 2022-03-09 05:58:39 --> Hooks Class Initialized
DEBUG - 2022-03-09 05:58:39 --> UTF-8 Support Enabled
INFO - 2022-03-09 05:58:39 --> Utf8 Class Initialized
INFO - 2022-03-09 05:58:39 --> URI Class Initialized
INFO - 2022-03-09 05:58:39 --> Router Class Initialized
INFO - 2022-03-09 05:58:39 --> Output Class Initialized
INFO - 2022-03-09 05:58:39 --> Security Class Initialized
DEBUG - 2022-03-09 05:58:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 05:58:39 --> Input Class Initialized
INFO - 2022-03-09 05:58:39 --> Language Class Initialized
INFO - 2022-03-09 05:58:39 --> Loader Class Initialized
INFO - 2022-03-09 05:58:39 --> Helper loaded: url_helper
INFO - 2022-03-09 05:58:39 --> Helper loaded: form_helper
INFO - 2022-03-09 05:58:39 --> Helper loaded: common_helper
INFO - 2022-03-09 05:58:39 --> Database Driver Class Initialized
DEBUG - 2022-03-09 05:58:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 05:58:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 05:58:39 --> Controller Class Initialized
INFO - 2022-03-09 05:58:39 --> Form Validation Class Initialized
DEBUG - 2022-03-09 05:58:39 --> Encrypt Class Initialized
INFO - 2022-03-09 05:58:39 --> Model "Patient_model" initialized
INFO - 2022-03-09 05:58:39 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 05:58:39 --> Model "Prefix_master" initialized
INFO - 2022-03-09 05:58:39 --> Model "Users_model" initialized
INFO - 2022-03-09 05:58:39 --> Model "Hospital_model" initialized
ERROR - 2022-03-09 05:58:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 05:58:39 --> Config Class Initialized
INFO - 2022-03-09 05:58:39 --> Hooks Class Initialized
DEBUG - 2022-03-09 05:58:39 --> UTF-8 Support Enabled
INFO - 2022-03-09 05:58:39 --> Utf8 Class Initialized
INFO - 2022-03-09 05:58:39 --> URI Class Initialized
INFO - 2022-03-09 05:58:39 --> Router Class Initialized
INFO - 2022-03-09 05:58:39 --> Output Class Initialized
INFO - 2022-03-09 05:58:39 --> Security Class Initialized
DEBUG - 2022-03-09 05:58:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 05:58:39 --> Input Class Initialized
INFO - 2022-03-09 05:58:39 --> Language Class Initialized
INFO - 2022-03-09 05:58:39 --> Loader Class Initialized
INFO - 2022-03-09 05:58:39 --> Helper loaded: url_helper
INFO - 2022-03-09 05:58:39 --> Helper loaded: form_helper
INFO - 2022-03-09 05:58:39 --> Helper loaded: common_helper
INFO - 2022-03-09 05:58:39 --> Database Driver Class Initialized
DEBUG - 2022-03-09 05:58:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 05:58:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 05:58:39 --> Controller Class Initialized
INFO - 2022-03-09 05:58:39 --> Form Validation Class Initialized
DEBUG - 2022-03-09 05:58:39 --> Encrypt Class Initialized
INFO - 2022-03-09 05:58:39 --> Model "Patient_model" initialized
INFO - 2022-03-09 05:58:39 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 05:58:39 --> Model "Prefix_master" initialized
INFO - 2022-03-09 05:58:39 --> Model "Users_model" initialized
INFO - 2022-03-09 05:58:39 --> Model "Hospital_model" initialized
INFO - 2022-03-09 05:58:39 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 05:58:39 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-09 05:58:39 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 05:58:39 --> Final output sent to browser
DEBUG - 2022-03-09 05:58:39 --> Total execution time: 0.0542
ERROR - 2022-03-09 06:00:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 06:00:34 --> Config Class Initialized
INFO - 2022-03-09 06:00:34 --> Hooks Class Initialized
DEBUG - 2022-03-09 06:00:34 --> UTF-8 Support Enabled
INFO - 2022-03-09 06:00:34 --> Utf8 Class Initialized
INFO - 2022-03-09 06:00:34 --> URI Class Initialized
INFO - 2022-03-09 06:00:34 --> Router Class Initialized
INFO - 2022-03-09 06:00:34 --> Output Class Initialized
INFO - 2022-03-09 06:00:34 --> Security Class Initialized
DEBUG - 2022-03-09 06:00:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 06:00:34 --> Input Class Initialized
INFO - 2022-03-09 06:00:34 --> Language Class Initialized
INFO - 2022-03-09 06:00:34 --> Loader Class Initialized
INFO - 2022-03-09 06:00:34 --> Helper loaded: url_helper
INFO - 2022-03-09 06:00:34 --> Helper loaded: form_helper
INFO - 2022-03-09 06:00:34 --> Helper loaded: common_helper
INFO - 2022-03-09 06:00:34 --> Database Driver Class Initialized
DEBUG - 2022-03-09 06:00:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 06:00:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 06:00:34 --> Controller Class Initialized
INFO - 2022-03-09 06:00:34 --> Form Validation Class Initialized
DEBUG - 2022-03-09 06:00:34 --> Encrypt Class Initialized
INFO - 2022-03-09 06:00:34 --> Model "Patient_model" initialized
INFO - 2022-03-09 06:00:34 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 06:00:34 --> Model "Prefix_master" initialized
INFO - 2022-03-09 06:00:34 --> Model "Users_model" initialized
INFO - 2022-03-09 06:00:34 --> Model "Hospital_model" initialized
ERROR - 2022-03-09 06:00:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 06:00:35 --> Config Class Initialized
INFO - 2022-03-09 06:00:35 --> Hooks Class Initialized
DEBUG - 2022-03-09 06:00:35 --> UTF-8 Support Enabled
INFO - 2022-03-09 06:00:35 --> Utf8 Class Initialized
INFO - 2022-03-09 06:00:35 --> URI Class Initialized
INFO - 2022-03-09 06:00:35 --> Router Class Initialized
INFO - 2022-03-09 06:00:35 --> Output Class Initialized
INFO - 2022-03-09 06:00:35 --> Security Class Initialized
DEBUG - 2022-03-09 06:00:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 06:00:35 --> Input Class Initialized
INFO - 2022-03-09 06:00:35 --> Language Class Initialized
INFO - 2022-03-09 06:00:35 --> Loader Class Initialized
INFO - 2022-03-09 06:00:35 --> Helper loaded: url_helper
INFO - 2022-03-09 06:00:35 --> Helper loaded: form_helper
INFO - 2022-03-09 06:00:35 --> Helper loaded: common_helper
INFO - 2022-03-09 06:00:35 --> Database Driver Class Initialized
DEBUG - 2022-03-09 06:00:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 06:00:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 06:00:35 --> Controller Class Initialized
INFO - 2022-03-09 06:00:35 --> Form Validation Class Initialized
DEBUG - 2022-03-09 06:00:35 --> Encrypt Class Initialized
INFO - 2022-03-09 06:00:35 --> Model "Patient_model" initialized
INFO - 2022-03-09 06:00:35 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 06:00:35 --> Model "Prefix_master" initialized
INFO - 2022-03-09 06:00:35 --> Model "Users_model" initialized
INFO - 2022-03-09 06:00:35 --> Model "Hospital_model" initialized
INFO - 2022-03-09 06:00:35 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 06:00:35 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-09 06:00:35 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 06:00:35 --> Final output sent to browser
DEBUG - 2022-03-09 06:00:35 --> Total execution time: 0.0598
ERROR - 2022-03-09 06:01:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 06:01:12 --> Config Class Initialized
INFO - 2022-03-09 06:01:12 --> Hooks Class Initialized
DEBUG - 2022-03-09 06:01:12 --> UTF-8 Support Enabled
INFO - 2022-03-09 06:01:12 --> Utf8 Class Initialized
INFO - 2022-03-09 06:01:12 --> URI Class Initialized
INFO - 2022-03-09 06:01:12 --> Router Class Initialized
INFO - 2022-03-09 06:01:12 --> Output Class Initialized
INFO - 2022-03-09 06:01:12 --> Security Class Initialized
DEBUG - 2022-03-09 06:01:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 06:01:12 --> Input Class Initialized
INFO - 2022-03-09 06:01:12 --> Language Class Initialized
INFO - 2022-03-09 06:01:12 --> Loader Class Initialized
INFO - 2022-03-09 06:01:12 --> Helper loaded: url_helper
INFO - 2022-03-09 06:01:12 --> Helper loaded: form_helper
INFO - 2022-03-09 06:01:12 --> Helper loaded: common_helper
INFO - 2022-03-09 06:01:12 --> Database Driver Class Initialized
DEBUG - 2022-03-09 06:01:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 06:01:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 06:01:12 --> Controller Class Initialized
INFO - 2022-03-09 06:01:12 --> Form Validation Class Initialized
DEBUG - 2022-03-09 06:01:12 --> Encrypt Class Initialized
INFO - 2022-03-09 06:01:12 --> Model "Patient_model" initialized
INFO - 2022-03-09 06:01:12 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 06:01:12 --> Model "Prefix_master" initialized
INFO - 2022-03-09 06:01:12 --> Model "Users_model" initialized
INFO - 2022-03-09 06:01:12 --> Model "Hospital_model" initialized
ERROR - 2022-03-09 06:01:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 06:01:13 --> Config Class Initialized
INFO - 2022-03-09 06:01:13 --> Hooks Class Initialized
DEBUG - 2022-03-09 06:01:13 --> UTF-8 Support Enabled
INFO - 2022-03-09 06:01:13 --> Utf8 Class Initialized
INFO - 2022-03-09 06:01:13 --> URI Class Initialized
INFO - 2022-03-09 06:01:13 --> Router Class Initialized
INFO - 2022-03-09 06:01:13 --> Output Class Initialized
INFO - 2022-03-09 06:01:13 --> Security Class Initialized
DEBUG - 2022-03-09 06:01:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 06:01:13 --> Input Class Initialized
INFO - 2022-03-09 06:01:13 --> Language Class Initialized
INFO - 2022-03-09 06:01:13 --> Loader Class Initialized
INFO - 2022-03-09 06:01:13 --> Helper loaded: url_helper
INFO - 2022-03-09 06:01:13 --> Helper loaded: form_helper
INFO - 2022-03-09 06:01:13 --> Helper loaded: common_helper
INFO - 2022-03-09 06:01:13 --> Database Driver Class Initialized
DEBUG - 2022-03-09 06:01:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 06:01:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 06:01:13 --> Controller Class Initialized
INFO - 2022-03-09 06:01:13 --> Form Validation Class Initialized
DEBUG - 2022-03-09 06:01:13 --> Encrypt Class Initialized
INFO - 2022-03-09 06:01:13 --> Model "Patient_model" initialized
INFO - 2022-03-09 06:01:13 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 06:01:13 --> Model "Prefix_master" initialized
INFO - 2022-03-09 06:01:13 --> Model "Users_model" initialized
INFO - 2022-03-09 06:01:13 --> Model "Hospital_model" initialized
INFO - 2022-03-09 06:01:13 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 06:01:13 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-09 06:01:13 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 06:01:13 --> Final output sent to browser
DEBUG - 2022-03-09 06:01:13 --> Total execution time: 0.1023
ERROR - 2022-03-09 06:09:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 06:09:41 --> Config Class Initialized
INFO - 2022-03-09 06:09:41 --> Hooks Class Initialized
DEBUG - 2022-03-09 06:09:41 --> UTF-8 Support Enabled
INFO - 2022-03-09 06:09:41 --> Utf8 Class Initialized
INFO - 2022-03-09 06:09:41 --> URI Class Initialized
INFO - 2022-03-09 06:09:41 --> Router Class Initialized
INFO - 2022-03-09 06:09:41 --> Output Class Initialized
INFO - 2022-03-09 06:09:41 --> Security Class Initialized
DEBUG - 2022-03-09 06:09:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 06:09:41 --> Input Class Initialized
INFO - 2022-03-09 06:09:41 --> Language Class Initialized
INFO - 2022-03-09 06:09:41 --> Loader Class Initialized
INFO - 2022-03-09 06:09:41 --> Helper loaded: url_helper
INFO - 2022-03-09 06:09:41 --> Helper loaded: form_helper
INFO - 2022-03-09 06:09:41 --> Helper loaded: common_helper
INFO - 2022-03-09 06:09:41 --> Database Driver Class Initialized
DEBUG - 2022-03-09 06:09:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 06:09:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 06:09:41 --> Controller Class Initialized
ERROR - 2022-03-09 06:09:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 06:09:42 --> Config Class Initialized
INFO - 2022-03-09 06:09:42 --> Hooks Class Initialized
DEBUG - 2022-03-09 06:09:42 --> UTF-8 Support Enabled
INFO - 2022-03-09 06:09:42 --> Utf8 Class Initialized
INFO - 2022-03-09 06:09:42 --> URI Class Initialized
INFO - 2022-03-09 06:09:42 --> Router Class Initialized
INFO - 2022-03-09 06:09:42 --> Output Class Initialized
INFO - 2022-03-09 06:09:42 --> Security Class Initialized
DEBUG - 2022-03-09 06:09:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 06:09:42 --> Input Class Initialized
INFO - 2022-03-09 06:09:42 --> Language Class Initialized
INFO - 2022-03-09 06:09:42 --> Loader Class Initialized
INFO - 2022-03-09 06:09:42 --> Helper loaded: url_helper
INFO - 2022-03-09 06:09:42 --> Helper loaded: form_helper
INFO - 2022-03-09 06:09:42 --> Helper loaded: common_helper
INFO - 2022-03-09 06:09:42 --> Database Driver Class Initialized
DEBUG - 2022-03-09 06:09:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 06:09:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 06:09:42 --> Controller Class Initialized
INFO - 2022-03-09 06:09:42 --> Form Validation Class Initialized
DEBUG - 2022-03-09 06:09:42 --> Encrypt Class Initialized
DEBUG - 2022-03-09 06:09:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-09 06:09:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-09 06:09:42 --> Email Class Initialized
INFO - 2022-03-09 06:09:42 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-09 06:09:42 --> Calendar Class Initialized
INFO - 2022-03-09 06:09:42 --> Model "Login_model" initialized
INFO - 2022-03-09 06:09:42 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-09 06:09:42 --> Final output sent to browser
DEBUG - 2022-03-09 06:09:42 --> Total execution time: 0.0233
ERROR - 2022-03-09 06:09:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 06:09:56 --> Config Class Initialized
INFO - 2022-03-09 06:09:56 --> Hooks Class Initialized
DEBUG - 2022-03-09 06:09:56 --> UTF-8 Support Enabled
INFO - 2022-03-09 06:09:56 --> Utf8 Class Initialized
INFO - 2022-03-09 06:09:56 --> URI Class Initialized
INFO - 2022-03-09 06:09:56 --> Router Class Initialized
INFO - 2022-03-09 06:09:56 --> Output Class Initialized
INFO - 2022-03-09 06:09:56 --> Security Class Initialized
DEBUG - 2022-03-09 06:09:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 06:09:56 --> Input Class Initialized
INFO - 2022-03-09 06:09:56 --> Language Class Initialized
INFO - 2022-03-09 06:09:56 --> Loader Class Initialized
INFO - 2022-03-09 06:09:56 --> Helper loaded: url_helper
INFO - 2022-03-09 06:09:56 --> Helper loaded: form_helper
INFO - 2022-03-09 06:09:56 --> Helper loaded: common_helper
INFO - 2022-03-09 06:09:56 --> Database Driver Class Initialized
DEBUG - 2022-03-09 06:09:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 06:09:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 06:09:56 --> Controller Class Initialized
INFO - 2022-03-09 06:09:56 --> Form Validation Class Initialized
DEBUG - 2022-03-09 06:09:56 --> Encrypt Class Initialized
DEBUG - 2022-03-09 06:09:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-09 06:09:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-09 06:09:56 --> Email Class Initialized
INFO - 2022-03-09 06:09:56 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-09 06:09:56 --> Calendar Class Initialized
INFO - 2022-03-09 06:09:56 --> Model "Login_model" initialized
INFO - 2022-03-09 06:09:56 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-03-09 06:09:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 06:09:57 --> Config Class Initialized
INFO - 2022-03-09 06:09:57 --> Hooks Class Initialized
DEBUG - 2022-03-09 06:09:57 --> UTF-8 Support Enabled
INFO - 2022-03-09 06:09:57 --> Utf8 Class Initialized
INFO - 2022-03-09 06:09:57 --> URI Class Initialized
INFO - 2022-03-09 06:09:57 --> Router Class Initialized
INFO - 2022-03-09 06:09:57 --> Output Class Initialized
INFO - 2022-03-09 06:09:57 --> Security Class Initialized
DEBUG - 2022-03-09 06:09:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 06:09:57 --> Input Class Initialized
INFO - 2022-03-09 06:09:57 --> Language Class Initialized
INFO - 2022-03-09 06:09:57 --> Loader Class Initialized
INFO - 2022-03-09 06:09:57 --> Helper loaded: url_helper
INFO - 2022-03-09 06:09:57 --> Helper loaded: form_helper
INFO - 2022-03-09 06:09:57 --> Helper loaded: common_helper
INFO - 2022-03-09 06:09:57 --> Database Driver Class Initialized
DEBUG - 2022-03-09 06:09:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 06:09:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 06:09:57 --> Controller Class Initialized
INFO - 2022-03-09 06:09:57 --> Form Validation Class Initialized
DEBUG - 2022-03-09 06:09:57 --> Encrypt Class Initialized
INFO - 2022-03-09 06:09:57 --> Model "Login_model" initialized
INFO - 2022-03-09 06:09:57 --> Model "Dashboard_model" initialized
INFO - 2022-03-09 06:09:57 --> Model "Case_model" initialized
INFO - 2022-03-09 06:09:57 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 06:09:57 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2022-03-09 06:09:57 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 06:09:57 --> Final output sent to browser
DEBUG - 2022-03-09 06:09:57 --> Total execution time: 0.2967
ERROR - 2022-03-09 06:10:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 06:10:06 --> Config Class Initialized
INFO - 2022-03-09 06:10:06 --> Hooks Class Initialized
DEBUG - 2022-03-09 06:10:06 --> UTF-8 Support Enabled
INFO - 2022-03-09 06:10:06 --> Utf8 Class Initialized
INFO - 2022-03-09 06:10:06 --> URI Class Initialized
INFO - 2022-03-09 06:10:06 --> Router Class Initialized
INFO - 2022-03-09 06:10:06 --> Output Class Initialized
INFO - 2022-03-09 06:10:06 --> Security Class Initialized
DEBUG - 2022-03-09 06:10:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 06:10:06 --> Input Class Initialized
INFO - 2022-03-09 06:10:06 --> Language Class Initialized
INFO - 2022-03-09 06:10:06 --> Loader Class Initialized
INFO - 2022-03-09 06:10:06 --> Helper loaded: url_helper
INFO - 2022-03-09 06:10:06 --> Helper loaded: form_helper
INFO - 2022-03-09 06:10:06 --> Helper loaded: common_helper
INFO - 2022-03-09 06:10:06 --> Database Driver Class Initialized
DEBUG - 2022-03-09 06:10:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 06:10:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 06:10:06 --> Controller Class Initialized
INFO - 2022-03-09 06:10:06 --> Form Validation Class Initialized
DEBUG - 2022-03-09 06:10:06 --> Encrypt Class Initialized
INFO - 2022-03-09 06:10:06 --> Model "Patient_model" initialized
INFO - 2022-03-09 06:10:06 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 06:10:06 --> Model "Referredby_model" initialized
INFO - 2022-03-09 06:10:06 --> Model "Prefix_master" initialized
INFO - 2022-03-09 06:10:06 --> Model "Hospital_model" initialized
INFO - 2022-03-09 06:10:06 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 06:10:06 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-09 06:10:06 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 06:10:06 --> Final output sent to browser
DEBUG - 2022-03-09 06:10:06 --> Total execution time: 0.0345
ERROR - 2022-03-09 06:21:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 06:21:14 --> Config Class Initialized
INFO - 2022-03-09 06:21:14 --> Hooks Class Initialized
DEBUG - 2022-03-09 06:21:14 --> UTF-8 Support Enabled
INFO - 2022-03-09 06:21:14 --> Utf8 Class Initialized
INFO - 2022-03-09 06:21:14 --> URI Class Initialized
INFO - 2022-03-09 06:21:14 --> Router Class Initialized
INFO - 2022-03-09 06:21:14 --> Output Class Initialized
INFO - 2022-03-09 06:21:14 --> Security Class Initialized
DEBUG - 2022-03-09 06:21:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 06:21:14 --> Input Class Initialized
INFO - 2022-03-09 06:21:14 --> Language Class Initialized
INFO - 2022-03-09 06:21:14 --> Loader Class Initialized
INFO - 2022-03-09 06:21:14 --> Helper loaded: url_helper
INFO - 2022-03-09 06:21:14 --> Helper loaded: form_helper
INFO - 2022-03-09 06:21:14 --> Helper loaded: common_helper
INFO - 2022-03-09 06:21:14 --> Database Driver Class Initialized
DEBUG - 2022-03-09 06:21:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 06:21:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 06:21:14 --> Controller Class Initialized
INFO - 2022-03-09 06:21:14 --> Model "Referredby_model" initialized
INFO - 2022-03-09 06:21:14 --> Final output sent to browser
DEBUG - 2022-03-09 06:21:14 --> Total execution time: 0.0298
ERROR - 2022-03-09 06:22:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 06:22:53 --> Config Class Initialized
INFO - 2022-03-09 06:22:53 --> Hooks Class Initialized
DEBUG - 2022-03-09 06:22:53 --> UTF-8 Support Enabled
INFO - 2022-03-09 06:22:53 --> Utf8 Class Initialized
INFO - 2022-03-09 06:22:53 --> URI Class Initialized
INFO - 2022-03-09 06:22:53 --> Router Class Initialized
INFO - 2022-03-09 06:22:53 --> Output Class Initialized
INFO - 2022-03-09 06:22:53 --> Security Class Initialized
DEBUG - 2022-03-09 06:22:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 06:22:53 --> Input Class Initialized
INFO - 2022-03-09 06:22:53 --> Language Class Initialized
INFO - 2022-03-09 06:22:53 --> Loader Class Initialized
INFO - 2022-03-09 06:22:53 --> Helper loaded: url_helper
INFO - 2022-03-09 06:22:53 --> Helper loaded: form_helper
INFO - 2022-03-09 06:22:53 --> Helper loaded: common_helper
INFO - 2022-03-09 06:22:53 --> Database Driver Class Initialized
DEBUG - 2022-03-09 06:22:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 06:22:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 06:22:53 --> Controller Class Initialized
INFO - 2022-03-09 06:22:53 --> Model "Referredby_model" initialized
INFO - 2022-03-09 06:22:53 --> Final output sent to browser
DEBUG - 2022-03-09 06:22:53 --> Total execution time: 0.0200
ERROR - 2022-03-09 06:24:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 06:24:21 --> Config Class Initialized
INFO - 2022-03-09 06:24:21 --> Hooks Class Initialized
DEBUG - 2022-03-09 06:24:21 --> UTF-8 Support Enabled
INFO - 2022-03-09 06:24:21 --> Utf8 Class Initialized
INFO - 2022-03-09 06:24:21 --> URI Class Initialized
INFO - 2022-03-09 06:24:21 --> Router Class Initialized
INFO - 2022-03-09 06:24:21 --> Output Class Initialized
INFO - 2022-03-09 06:24:21 --> Security Class Initialized
DEBUG - 2022-03-09 06:24:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 06:24:21 --> Input Class Initialized
INFO - 2022-03-09 06:24:21 --> Language Class Initialized
INFO - 2022-03-09 06:24:21 --> Loader Class Initialized
INFO - 2022-03-09 06:24:21 --> Helper loaded: url_helper
INFO - 2022-03-09 06:24:21 --> Helper loaded: form_helper
INFO - 2022-03-09 06:24:21 --> Helper loaded: common_helper
INFO - 2022-03-09 06:24:21 --> Database Driver Class Initialized
DEBUG - 2022-03-09 06:24:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 06:24:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 06:24:21 --> Controller Class Initialized
INFO - 2022-03-09 06:24:21 --> Form Validation Class Initialized
DEBUG - 2022-03-09 06:24:21 --> Encrypt Class Initialized
INFO - 2022-03-09 06:24:21 --> Model "Patient_model" initialized
INFO - 2022-03-09 06:24:21 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 06:24:21 --> Model "Referredby_model" initialized
INFO - 2022-03-09 06:24:21 --> Model "Prefix_master" initialized
INFO - 2022-03-09 06:24:21 --> Model "Hospital_model" initialized
INFO - 2022-03-09 06:24:21 --> Final output sent to browser
DEBUG - 2022-03-09 06:24:21 --> Total execution time: 0.0390
ERROR - 2022-03-09 06:24:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 06:24:32 --> Config Class Initialized
INFO - 2022-03-09 06:24:32 --> Hooks Class Initialized
DEBUG - 2022-03-09 06:24:32 --> UTF-8 Support Enabled
INFO - 2022-03-09 06:24:32 --> Utf8 Class Initialized
INFO - 2022-03-09 06:24:32 --> URI Class Initialized
INFO - 2022-03-09 06:24:32 --> Router Class Initialized
INFO - 2022-03-09 06:24:32 --> Output Class Initialized
INFO - 2022-03-09 06:24:32 --> Security Class Initialized
DEBUG - 2022-03-09 06:24:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 06:24:32 --> Input Class Initialized
INFO - 2022-03-09 06:24:32 --> Language Class Initialized
INFO - 2022-03-09 06:24:32 --> Loader Class Initialized
INFO - 2022-03-09 06:24:32 --> Helper loaded: url_helper
INFO - 2022-03-09 06:24:32 --> Helper loaded: form_helper
INFO - 2022-03-09 06:24:32 --> Helper loaded: common_helper
INFO - 2022-03-09 06:24:32 --> Database Driver Class Initialized
DEBUG - 2022-03-09 06:24:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 06:24:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 06:24:32 --> Controller Class Initialized
INFO - 2022-03-09 06:24:32 --> Form Validation Class Initialized
DEBUG - 2022-03-09 06:24:32 --> Encrypt Class Initialized
INFO - 2022-03-09 06:24:32 --> Model "Patient_model" initialized
INFO - 2022-03-09 06:24:32 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 06:24:32 --> Model "Referredby_model" initialized
INFO - 2022-03-09 06:24:32 --> Model "Prefix_master" initialized
INFO - 2022-03-09 06:24:32 --> Model "Hospital_model" initialized
INFO - 2022-03-09 06:24:32 --> Final output sent to browser
DEBUG - 2022-03-09 06:24:32 --> Total execution time: 0.0370
ERROR - 2022-03-09 06:24:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 06:24:38 --> Config Class Initialized
INFO - 2022-03-09 06:24:38 --> Hooks Class Initialized
DEBUG - 2022-03-09 06:24:38 --> UTF-8 Support Enabled
INFO - 2022-03-09 06:24:38 --> Utf8 Class Initialized
INFO - 2022-03-09 06:24:38 --> URI Class Initialized
INFO - 2022-03-09 06:24:38 --> Router Class Initialized
INFO - 2022-03-09 06:24:38 --> Output Class Initialized
INFO - 2022-03-09 06:24:38 --> Security Class Initialized
DEBUG - 2022-03-09 06:24:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 06:24:38 --> Input Class Initialized
INFO - 2022-03-09 06:24:38 --> Language Class Initialized
INFO - 2022-03-09 06:24:38 --> Loader Class Initialized
INFO - 2022-03-09 06:24:38 --> Helper loaded: url_helper
INFO - 2022-03-09 06:24:38 --> Helper loaded: form_helper
INFO - 2022-03-09 06:24:38 --> Helper loaded: common_helper
INFO - 2022-03-09 06:24:38 --> Database Driver Class Initialized
DEBUG - 2022-03-09 06:24:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 06:24:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 06:24:38 --> Controller Class Initialized
INFO - 2022-03-09 06:24:38 --> Form Validation Class Initialized
DEBUG - 2022-03-09 06:24:38 --> Encrypt Class Initialized
INFO - 2022-03-09 06:24:38 --> Model "Patient_model" initialized
INFO - 2022-03-09 06:24:38 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 06:24:38 --> Model "Referredby_model" initialized
INFO - 2022-03-09 06:24:38 --> Model "Prefix_master" initialized
INFO - 2022-03-09 06:24:38 --> Model "Hospital_model" initialized
INFO - 2022-03-09 06:24:38 --> Final output sent to browser
DEBUG - 2022-03-09 06:24:38 --> Total execution time: 0.0261
ERROR - 2022-03-09 06:25:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 06:25:01 --> Config Class Initialized
INFO - 2022-03-09 06:25:01 --> Hooks Class Initialized
DEBUG - 2022-03-09 06:25:01 --> UTF-8 Support Enabled
INFO - 2022-03-09 06:25:01 --> Utf8 Class Initialized
INFO - 2022-03-09 06:25:01 --> URI Class Initialized
INFO - 2022-03-09 06:25:01 --> Router Class Initialized
INFO - 2022-03-09 06:25:01 --> Output Class Initialized
INFO - 2022-03-09 06:25:01 --> Security Class Initialized
DEBUG - 2022-03-09 06:25:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 06:25:01 --> Input Class Initialized
INFO - 2022-03-09 06:25:01 --> Language Class Initialized
INFO - 2022-03-09 06:25:01 --> Loader Class Initialized
INFO - 2022-03-09 06:25:01 --> Helper loaded: url_helper
INFO - 2022-03-09 06:25:01 --> Helper loaded: form_helper
INFO - 2022-03-09 06:25:01 --> Helper loaded: common_helper
INFO - 2022-03-09 06:25:01 --> Database Driver Class Initialized
DEBUG - 2022-03-09 06:25:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 06:25:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 06:25:02 --> Controller Class Initialized
INFO - 2022-03-09 06:25:02 --> Form Validation Class Initialized
DEBUG - 2022-03-09 06:25:02 --> Encrypt Class Initialized
INFO - 2022-03-09 06:25:02 --> Model "Patient_model" initialized
INFO - 2022-03-09 06:25:02 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 06:25:02 --> Model "Prefix_master" initialized
INFO - 2022-03-09 06:25:02 --> Model "Users_model" initialized
INFO - 2022-03-09 06:25:02 --> Model "Hospital_model" initialized
ERROR - 2022-03-09 06:25:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 06:25:02 --> Config Class Initialized
INFO - 2022-03-09 06:25:02 --> Hooks Class Initialized
DEBUG - 2022-03-09 06:25:02 --> UTF-8 Support Enabled
INFO - 2022-03-09 06:25:02 --> Utf8 Class Initialized
INFO - 2022-03-09 06:25:02 --> URI Class Initialized
INFO - 2022-03-09 06:25:02 --> Router Class Initialized
INFO - 2022-03-09 06:25:02 --> Output Class Initialized
INFO - 2022-03-09 06:25:02 --> Security Class Initialized
DEBUG - 2022-03-09 06:25:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 06:25:02 --> Input Class Initialized
INFO - 2022-03-09 06:25:02 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 06:25:02 --> Language Class Initialized
INFO - 2022-03-09 06:25:02 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-09 06:25:02 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 06:25:02 --> Loader Class Initialized
INFO - 2022-03-09 06:25:02 --> Helper loaded: url_helper
INFO - 2022-03-09 06:25:02 --> Helper loaded: form_helper
INFO - 2022-03-09 06:25:02 --> Helper loaded: common_helper
INFO - 2022-03-09 06:25:02 --> Database Driver Class Initialized
INFO - 2022-03-09 06:25:02 --> Final output sent to browser
DEBUG - 2022-03-09 06:25:02 --> Total execution time: 0.1088
DEBUG - 2022-03-09 06:25:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 06:25:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 06:25:02 --> Controller Class Initialized
INFO - 2022-03-09 06:25:02 --> Form Validation Class Initialized
DEBUG - 2022-03-09 06:25:02 --> Encrypt Class Initialized
INFO - 2022-03-09 06:25:02 --> Model "Patient_model" initialized
INFO - 2022-03-09 06:25:02 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 06:25:02 --> Model "Prefix_master" initialized
INFO - 2022-03-09 06:25:02 --> Model "Users_model" initialized
INFO - 2022-03-09 06:25:02 --> Model "Hospital_model" initialized
INFO - 2022-03-09 06:25:02 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 06:25:02 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-09 06:25:02 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 06:25:02 --> Final output sent to browser
DEBUG - 2022-03-09 06:25:02 --> Total execution time: 0.0918
ERROR - 2022-03-09 06:25:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 06:25:02 --> Config Class Initialized
INFO - 2022-03-09 06:25:02 --> Hooks Class Initialized
DEBUG - 2022-03-09 06:25:02 --> UTF-8 Support Enabled
INFO - 2022-03-09 06:25:02 --> Utf8 Class Initialized
INFO - 2022-03-09 06:25:03 --> URI Class Initialized
INFO - 2022-03-09 06:25:03 --> Router Class Initialized
INFO - 2022-03-09 06:25:03 --> Output Class Initialized
INFO - 2022-03-09 06:25:03 --> Security Class Initialized
DEBUG - 2022-03-09 06:25:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 06:25:03 --> Input Class Initialized
INFO - 2022-03-09 06:25:03 --> Language Class Initialized
ERROR - 2022-03-09 06:25:03 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-09 06:25:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 06:25:11 --> Config Class Initialized
INFO - 2022-03-09 06:25:11 --> Hooks Class Initialized
DEBUG - 2022-03-09 06:25:11 --> UTF-8 Support Enabled
INFO - 2022-03-09 06:25:11 --> Utf8 Class Initialized
INFO - 2022-03-09 06:25:11 --> URI Class Initialized
INFO - 2022-03-09 06:25:11 --> Router Class Initialized
INFO - 2022-03-09 06:25:11 --> Output Class Initialized
INFO - 2022-03-09 06:25:11 --> Security Class Initialized
DEBUG - 2022-03-09 06:25:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 06:25:11 --> Input Class Initialized
INFO - 2022-03-09 06:25:11 --> Language Class Initialized
INFO - 2022-03-09 06:25:11 --> Loader Class Initialized
INFO - 2022-03-09 06:25:11 --> Helper loaded: url_helper
INFO - 2022-03-09 06:25:11 --> Helper loaded: form_helper
INFO - 2022-03-09 06:25:11 --> Helper loaded: common_helper
INFO - 2022-03-09 06:25:11 --> Database Driver Class Initialized
DEBUG - 2022-03-09 06:25:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 06:25:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 06:25:11 --> Controller Class Initialized
INFO - 2022-03-09 06:25:11 --> Form Validation Class Initialized
DEBUG - 2022-03-09 06:25:11 --> Encrypt Class Initialized
INFO - 2022-03-09 06:25:11 --> Model "Patient_model" initialized
INFO - 2022-03-09 06:25:11 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 06:25:11 --> Model "Referredby_model" initialized
INFO - 2022-03-09 06:25:11 --> Model "Prefix_master" initialized
INFO - 2022-03-09 06:25:11 --> Model "Hospital_model" initialized
ERROR - 2022-03-09 06:25:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 06:25:12 --> Config Class Initialized
INFO - 2022-03-09 06:25:12 --> Hooks Class Initialized
DEBUG - 2022-03-09 06:25:12 --> UTF-8 Support Enabled
INFO - 2022-03-09 06:25:12 --> Utf8 Class Initialized
INFO - 2022-03-09 06:25:12 --> URI Class Initialized
INFO - 2022-03-09 06:25:12 --> Router Class Initialized
INFO - 2022-03-09 06:25:12 --> Output Class Initialized
INFO - 2022-03-09 06:25:12 --> Security Class Initialized
DEBUG - 2022-03-09 06:25:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 06:25:12 --> Input Class Initialized
INFO - 2022-03-09 06:25:12 --> Language Class Initialized
INFO - 2022-03-09 06:25:12 --> Loader Class Initialized
INFO - 2022-03-09 06:25:12 --> Helper loaded: url_helper
INFO - 2022-03-09 06:25:12 --> Helper loaded: form_helper
INFO - 2022-03-09 06:25:12 --> Helper loaded: common_helper
INFO - 2022-03-09 06:25:12 --> Database Driver Class Initialized
DEBUG - 2022-03-09 06:25:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 06:25:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 06:25:12 --> Controller Class Initialized
INFO - 2022-03-09 06:25:12 --> Form Validation Class Initialized
DEBUG - 2022-03-09 06:25:12 --> Encrypt Class Initialized
INFO - 2022-03-09 06:25:12 --> Model "Patient_model" initialized
INFO - 2022-03-09 06:25:12 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 06:25:12 --> Model "Referredby_model" initialized
INFO - 2022-03-09 06:25:12 --> Model "Prefix_master" initialized
INFO - 2022-03-09 06:25:12 --> Model "Hospital_model" initialized
INFO - 2022-03-09 06:25:12 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 06:25:12 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-09 06:25:12 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 06:25:12 --> Final output sent to browser
DEBUG - 2022-03-09 06:25:12 --> Total execution time: 0.0465
ERROR - 2022-03-09 06:25:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 06:25:13 --> Config Class Initialized
INFO - 2022-03-09 06:25:13 --> Hooks Class Initialized
DEBUG - 2022-03-09 06:25:13 --> UTF-8 Support Enabled
INFO - 2022-03-09 06:25:13 --> Utf8 Class Initialized
INFO - 2022-03-09 06:25:13 --> URI Class Initialized
INFO - 2022-03-09 06:25:13 --> Router Class Initialized
INFO - 2022-03-09 06:25:13 --> Output Class Initialized
INFO - 2022-03-09 06:25:13 --> Security Class Initialized
DEBUG - 2022-03-09 06:25:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 06:25:13 --> Input Class Initialized
INFO - 2022-03-09 06:25:13 --> Language Class Initialized
INFO - 2022-03-09 06:25:13 --> Loader Class Initialized
INFO - 2022-03-09 06:25:13 --> Helper loaded: url_helper
INFO - 2022-03-09 06:25:13 --> Helper loaded: form_helper
INFO - 2022-03-09 06:25:13 --> Helper loaded: common_helper
INFO - 2022-03-09 06:25:13 --> Database Driver Class Initialized
DEBUG - 2022-03-09 06:25:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 06:25:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 06:25:13 --> Controller Class Initialized
INFO - 2022-03-09 06:25:13 --> Form Validation Class Initialized
DEBUG - 2022-03-09 06:25:13 --> Encrypt Class Initialized
INFO - 2022-03-09 06:25:13 --> Model "Patient_model" initialized
INFO - 2022-03-09 06:25:13 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 06:25:13 --> Model "Prefix_master" initialized
INFO - 2022-03-09 06:25:13 --> Model "Users_model" initialized
INFO - 2022-03-09 06:25:13 --> Model "Hospital_model" initialized
INFO - 2022-03-09 06:25:13 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 06:25:13 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-09 06:25:13 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 06:25:13 --> Final output sent to browser
DEBUG - 2022-03-09 06:25:13 --> Total execution time: 0.0984
ERROR - 2022-03-09 06:25:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 06:25:19 --> Config Class Initialized
INFO - 2022-03-09 06:25:19 --> Hooks Class Initialized
DEBUG - 2022-03-09 06:25:19 --> UTF-8 Support Enabled
INFO - 2022-03-09 06:25:19 --> Utf8 Class Initialized
INFO - 2022-03-09 06:25:19 --> URI Class Initialized
INFO - 2022-03-09 06:25:19 --> Router Class Initialized
INFO - 2022-03-09 06:25:19 --> Output Class Initialized
INFO - 2022-03-09 06:25:19 --> Security Class Initialized
DEBUG - 2022-03-09 06:25:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 06:25:19 --> Input Class Initialized
INFO - 2022-03-09 06:25:20 --> Language Class Initialized
INFO - 2022-03-09 06:25:20 --> Loader Class Initialized
INFO - 2022-03-09 06:25:20 --> Helper loaded: url_helper
INFO - 2022-03-09 06:25:20 --> Helper loaded: form_helper
INFO - 2022-03-09 06:25:20 --> Helper loaded: common_helper
INFO - 2022-03-09 06:25:20 --> Database Driver Class Initialized
DEBUG - 2022-03-09 06:25:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 06:25:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 06:25:20 --> Controller Class Initialized
INFO - 2022-03-09 06:25:20 --> Form Validation Class Initialized
DEBUG - 2022-03-09 06:25:20 --> Encrypt Class Initialized
DEBUG - 2022-03-09 06:25:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-09 06:25:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-09 06:25:20 --> Email Class Initialized
INFO - 2022-03-09 06:25:20 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-09 06:25:20 --> Calendar Class Initialized
INFO - 2022-03-09 06:25:20 --> Model "Login_model" initialized
ERROR - 2022-03-09 06:25:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 06:25:20 --> Config Class Initialized
INFO - 2022-03-09 06:25:20 --> Hooks Class Initialized
DEBUG - 2022-03-09 06:25:20 --> UTF-8 Support Enabled
INFO - 2022-03-09 06:25:20 --> Utf8 Class Initialized
INFO - 2022-03-09 06:25:20 --> URI Class Initialized
INFO - 2022-03-09 06:25:20 --> Router Class Initialized
INFO - 2022-03-09 06:25:20 --> Output Class Initialized
INFO - 2022-03-09 06:25:20 --> Security Class Initialized
DEBUG - 2022-03-09 06:25:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 06:25:20 --> Input Class Initialized
INFO - 2022-03-09 06:25:20 --> Language Class Initialized
INFO - 2022-03-09 06:25:20 --> Loader Class Initialized
INFO - 2022-03-09 06:25:20 --> Helper loaded: url_helper
INFO - 2022-03-09 06:25:20 --> Helper loaded: form_helper
INFO - 2022-03-09 06:25:20 --> Helper loaded: common_helper
INFO - 2022-03-09 06:25:20 --> Database Driver Class Initialized
DEBUG - 2022-03-09 06:25:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 06:25:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 06:25:20 --> Controller Class Initialized
INFO - 2022-03-09 06:25:20 --> Form Validation Class Initialized
DEBUG - 2022-03-09 06:25:20 --> Encrypt Class Initialized
DEBUG - 2022-03-09 06:25:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-09 06:25:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-09 06:25:20 --> Email Class Initialized
INFO - 2022-03-09 06:25:20 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-09 06:25:20 --> Calendar Class Initialized
INFO - 2022-03-09 06:25:20 --> Model "Login_model" initialized
INFO - 2022-03-09 06:25:20 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-09 06:25:20 --> Final output sent to browser
DEBUG - 2022-03-09 06:25:20 --> Total execution time: 0.0333
ERROR - 2022-03-09 06:26:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 06:26:17 --> Config Class Initialized
INFO - 2022-03-09 06:26:17 --> Hooks Class Initialized
DEBUG - 2022-03-09 06:26:17 --> UTF-8 Support Enabled
INFO - 2022-03-09 06:26:17 --> Utf8 Class Initialized
INFO - 2022-03-09 06:26:17 --> URI Class Initialized
INFO - 2022-03-09 06:26:17 --> Router Class Initialized
INFO - 2022-03-09 06:26:17 --> Output Class Initialized
INFO - 2022-03-09 06:26:17 --> Security Class Initialized
DEBUG - 2022-03-09 06:26:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 06:26:17 --> Input Class Initialized
INFO - 2022-03-09 06:26:17 --> Language Class Initialized
INFO - 2022-03-09 06:26:17 --> Loader Class Initialized
INFO - 2022-03-09 06:26:17 --> Helper loaded: url_helper
INFO - 2022-03-09 06:26:17 --> Helper loaded: form_helper
INFO - 2022-03-09 06:26:17 --> Helper loaded: common_helper
INFO - 2022-03-09 06:26:17 --> Database Driver Class Initialized
DEBUG - 2022-03-09 06:26:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 06:26:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 06:26:17 --> Controller Class Initialized
INFO - 2022-03-09 06:26:17 --> Form Validation Class Initialized
DEBUG - 2022-03-09 06:26:17 --> Encrypt Class Initialized
INFO - 2022-03-09 06:26:17 --> Model "Patient_model" initialized
INFO - 2022-03-09 06:26:17 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 06:26:17 --> Model "Prefix_master" initialized
INFO - 2022-03-09 06:26:17 --> Model "Users_model" initialized
INFO - 2022-03-09 06:26:17 --> Model "Hospital_model" initialized
ERROR - 2022-03-09 06:26:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 06:26:17 --> Config Class Initialized
INFO - 2022-03-09 06:26:17 --> Hooks Class Initialized
DEBUG - 2022-03-09 06:26:17 --> UTF-8 Support Enabled
INFO - 2022-03-09 06:26:17 --> Utf8 Class Initialized
INFO - 2022-03-09 06:26:17 --> URI Class Initialized
INFO - 2022-03-09 06:26:17 --> Router Class Initialized
INFO - 2022-03-09 06:26:17 --> Output Class Initialized
INFO - 2022-03-09 06:26:17 --> Security Class Initialized
DEBUG - 2022-03-09 06:26:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 06:26:17 --> Input Class Initialized
INFO - 2022-03-09 06:26:17 --> Language Class Initialized
INFO - 2022-03-09 06:26:17 --> Loader Class Initialized
INFO - 2022-03-09 06:26:17 --> Helper loaded: url_helper
INFO - 2022-03-09 06:26:17 --> Helper loaded: form_helper
INFO - 2022-03-09 06:26:17 --> Helper loaded: common_helper
INFO - 2022-03-09 06:26:17 --> Database Driver Class Initialized
DEBUG - 2022-03-09 06:26:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 06:26:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 06:26:17 --> Controller Class Initialized
INFO - 2022-03-09 06:26:17 --> Form Validation Class Initialized
DEBUG - 2022-03-09 06:26:17 --> Encrypt Class Initialized
INFO - 2022-03-09 06:26:17 --> Model "Patient_model" initialized
INFO - 2022-03-09 06:26:17 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 06:26:17 --> Model "Prefix_master" initialized
INFO - 2022-03-09 06:26:17 --> Model "Users_model" initialized
INFO - 2022-03-09 06:26:17 --> Model "Hospital_model" initialized
INFO - 2022-03-09 06:26:17 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 06:26:17 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-09 06:26:17 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 06:26:17 --> Final output sent to browser
DEBUG - 2022-03-09 06:26:17 --> Total execution time: 0.0802
ERROR - 2022-03-09 06:26:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 06:26:31 --> Config Class Initialized
INFO - 2022-03-09 06:26:31 --> Hooks Class Initialized
DEBUG - 2022-03-09 06:26:31 --> UTF-8 Support Enabled
INFO - 2022-03-09 06:26:31 --> Utf8 Class Initialized
INFO - 2022-03-09 06:26:31 --> URI Class Initialized
INFO - 2022-03-09 06:26:31 --> Router Class Initialized
INFO - 2022-03-09 06:26:31 --> Output Class Initialized
INFO - 2022-03-09 06:26:31 --> Security Class Initialized
DEBUG - 2022-03-09 06:26:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 06:26:31 --> Input Class Initialized
INFO - 2022-03-09 06:26:31 --> Language Class Initialized
INFO - 2022-03-09 06:26:31 --> Loader Class Initialized
INFO - 2022-03-09 06:26:31 --> Helper loaded: url_helper
INFO - 2022-03-09 06:26:31 --> Helper loaded: form_helper
INFO - 2022-03-09 06:26:31 --> Helper loaded: common_helper
INFO - 2022-03-09 06:26:31 --> Database Driver Class Initialized
DEBUG - 2022-03-09 06:26:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 06:26:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 06:26:31 --> Controller Class Initialized
INFO - 2022-03-09 06:26:31 --> Form Validation Class Initialized
DEBUG - 2022-03-09 06:26:31 --> Encrypt Class Initialized
DEBUG - 2022-03-09 06:26:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-09 06:26:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-09 06:26:31 --> Email Class Initialized
INFO - 2022-03-09 06:26:31 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-09 06:26:31 --> Calendar Class Initialized
INFO - 2022-03-09 06:26:31 --> Model "Login_model" initialized
ERROR - 2022-03-09 06:26:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 06:26:31 --> Config Class Initialized
INFO - 2022-03-09 06:26:31 --> Hooks Class Initialized
DEBUG - 2022-03-09 06:26:31 --> UTF-8 Support Enabled
INFO - 2022-03-09 06:26:31 --> Utf8 Class Initialized
INFO - 2022-03-09 06:26:31 --> URI Class Initialized
INFO - 2022-03-09 06:26:31 --> Router Class Initialized
INFO - 2022-03-09 06:26:31 --> Output Class Initialized
INFO - 2022-03-09 06:26:31 --> Security Class Initialized
DEBUG - 2022-03-09 06:26:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 06:26:31 --> Input Class Initialized
INFO - 2022-03-09 06:26:31 --> Language Class Initialized
INFO - 2022-03-09 06:26:31 --> Loader Class Initialized
INFO - 2022-03-09 06:26:31 --> Helper loaded: url_helper
INFO - 2022-03-09 06:26:31 --> Helper loaded: form_helper
INFO - 2022-03-09 06:26:31 --> Helper loaded: common_helper
INFO - 2022-03-09 06:26:31 --> Database Driver Class Initialized
DEBUG - 2022-03-09 06:26:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 06:26:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 06:26:31 --> Controller Class Initialized
INFO - 2022-03-09 06:26:31 --> Form Validation Class Initialized
DEBUG - 2022-03-09 06:26:31 --> Encrypt Class Initialized
DEBUG - 2022-03-09 06:26:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-09 06:26:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-09 06:26:31 --> Email Class Initialized
INFO - 2022-03-09 06:26:31 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-09 06:26:31 --> Calendar Class Initialized
INFO - 2022-03-09 06:26:31 --> Model "Login_model" initialized
INFO - 2022-03-09 06:26:31 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-09 06:26:31 --> Final output sent to browser
DEBUG - 2022-03-09 06:26:31 --> Total execution time: 0.0369
ERROR - 2022-03-09 06:26:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 06:26:33 --> Config Class Initialized
INFO - 2022-03-09 06:26:33 --> Hooks Class Initialized
DEBUG - 2022-03-09 06:26:33 --> UTF-8 Support Enabled
INFO - 2022-03-09 06:26:33 --> Utf8 Class Initialized
INFO - 2022-03-09 06:26:33 --> URI Class Initialized
INFO - 2022-03-09 06:26:33 --> Router Class Initialized
INFO - 2022-03-09 06:26:33 --> Output Class Initialized
INFO - 2022-03-09 06:26:33 --> Security Class Initialized
DEBUG - 2022-03-09 06:26:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 06:26:33 --> Input Class Initialized
INFO - 2022-03-09 06:26:33 --> Language Class Initialized
INFO - 2022-03-09 06:26:33 --> Loader Class Initialized
INFO - 2022-03-09 06:26:33 --> Helper loaded: url_helper
INFO - 2022-03-09 06:26:33 --> Helper loaded: form_helper
INFO - 2022-03-09 06:26:33 --> Helper loaded: common_helper
INFO - 2022-03-09 06:26:33 --> Database Driver Class Initialized
DEBUG - 2022-03-09 06:26:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 06:26:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 06:26:33 --> Controller Class Initialized
ERROR - 2022-03-09 06:26:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 06:26:34 --> Config Class Initialized
INFO - 2022-03-09 06:26:34 --> Hooks Class Initialized
DEBUG - 2022-03-09 06:26:34 --> UTF-8 Support Enabled
INFO - 2022-03-09 06:26:34 --> Utf8 Class Initialized
INFO - 2022-03-09 06:26:34 --> URI Class Initialized
INFO - 2022-03-09 06:26:34 --> Router Class Initialized
INFO - 2022-03-09 06:26:34 --> Output Class Initialized
INFO - 2022-03-09 06:26:34 --> Security Class Initialized
DEBUG - 2022-03-09 06:26:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 06:26:34 --> Input Class Initialized
INFO - 2022-03-09 06:26:34 --> Language Class Initialized
INFO - 2022-03-09 06:26:34 --> Loader Class Initialized
INFO - 2022-03-09 06:26:34 --> Helper loaded: url_helper
INFO - 2022-03-09 06:26:34 --> Helper loaded: form_helper
INFO - 2022-03-09 06:26:34 --> Helper loaded: common_helper
INFO - 2022-03-09 06:26:34 --> Database Driver Class Initialized
DEBUG - 2022-03-09 06:26:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 06:26:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 06:26:34 --> Controller Class Initialized
INFO - 2022-03-09 06:26:34 --> Form Validation Class Initialized
DEBUG - 2022-03-09 06:26:34 --> Encrypt Class Initialized
DEBUG - 2022-03-09 06:26:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-09 06:26:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-09 06:26:34 --> Email Class Initialized
INFO - 2022-03-09 06:26:34 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-09 06:26:34 --> Calendar Class Initialized
INFO - 2022-03-09 06:26:34 --> Model "Login_model" initialized
INFO - 2022-03-09 06:26:34 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-09 06:26:34 --> Final output sent to browser
DEBUG - 2022-03-09 06:26:34 --> Total execution time: 0.0419
ERROR - 2022-03-09 06:27:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 06:27:03 --> Config Class Initialized
INFO - 2022-03-09 06:27:03 --> Hooks Class Initialized
DEBUG - 2022-03-09 06:27:03 --> UTF-8 Support Enabled
INFO - 2022-03-09 06:27:03 --> Utf8 Class Initialized
INFO - 2022-03-09 06:27:03 --> URI Class Initialized
INFO - 2022-03-09 06:27:03 --> Router Class Initialized
INFO - 2022-03-09 06:27:03 --> Output Class Initialized
INFO - 2022-03-09 06:27:03 --> Security Class Initialized
DEBUG - 2022-03-09 06:27:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 06:27:03 --> Input Class Initialized
INFO - 2022-03-09 06:27:03 --> Language Class Initialized
INFO - 2022-03-09 06:27:03 --> Loader Class Initialized
INFO - 2022-03-09 06:27:03 --> Helper loaded: url_helper
INFO - 2022-03-09 06:27:03 --> Helper loaded: form_helper
INFO - 2022-03-09 06:27:03 --> Helper loaded: common_helper
INFO - 2022-03-09 06:27:03 --> Database Driver Class Initialized
DEBUG - 2022-03-09 06:27:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 06:27:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 06:27:03 --> Controller Class Initialized
INFO - 2022-03-09 06:27:03 --> Form Validation Class Initialized
DEBUG - 2022-03-09 06:27:03 --> Encrypt Class Initialized
DEBUG - 2022-03-09 06:27:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-09 06:27:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-09 06:27:03 --> Email Class Initialized
INFO - 2022-03-09 06:27:03 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-09 06:27:03 --> Calendar Class Initialized
INFO - 2022-03-09 06:27:03 --> Model "Login_model" initialized
INFO - 2022-03-09 06:27:03 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-03-09 06:27:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 06:27:04 --> Config Class Initialized
INFO - 2022-03-09 06:27:04 --> Hooks Class Initialized
DEBUG - 2022-03-09 06:27:04 --> UTF-8 Support Enabled
INFO - 2022-03-09 06:27:04 --> Utf8 Class Initialized
INFO - 2022-03-09 06:27:04 --> URI Class Initialized
INFO - 2022-03-09 06:27:04 --> Router Class Initialized
INFO - 2022-03-09 06:27:04 --> Output Class Initialized
INFO - 2022-03-09 06:27:04 --> Security Class Initialized
DEBUG - 2022-03-09 06:27:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 06:27:04 --> Input Class Initialized
INFO - 2022-03-09 06:27:04 --> Language Class Initialized
INFO - 2022-03-09 06:27:04 --> Loader Class Initialized
INFO - 2022-03-09 06:27:04 --> Helper loaded: url_helper
INFO - 2022-03-09 06:27:04 --> Helper loaded: form_helper
INFO - 2022-03-09 06:27:04 --> Helper loaded: common_helper
INFO - 2022-03-09 06:27:04 --> Database Driver Class Initialized
DEBUG - 2022-03-09 06:27:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 06:27:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 06:27:04 --> Controller Class Initialized
INFO - 2022-03-09 06:27:04 --> Form Validation Class Initialized
DEBUG - 2022-03-09 06:27:04 --> Encrypt Class Initialized
INFO - 2022-03-09 06:27:04 --> Model "Login_model" initialized
INFO - 2022-03-09 06:27:04 --> Model "Dashboard_model" initialized
INFO - 2022-03-09 06:27:04 --> Model "Case_model" initialized
INFO - 2022-03-09 06:27:05 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 06:27:05 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2022-03-09 06:27:05 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 06:27:05 --> Final output sent to browser
DEBUG - 2022-03-09 06:27:05 --> Total execution time: 0.2527
ERROR - 2022-03-09 06:27:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 06:27:36 --> Config Class Initialized
INFO - 2022-03-09 06:27:36 --> Hooks Class Initialized
DEBUG - 2022-03-09 06:27:36 --> UTF-8 Support Enabled
INFO - 2022-03-09 06:27:36 --> Utf8 Class Initialized
INFO - 2022-03-09 06:27:36 --> URI Class Initialized
INFO - 2022-03-09 06:27:36 --> Router Class Initialized
INFO - 2022-03-09 06:27:36 --> Output Class Initialized
INFO - 2022-03-09 06:27:36 --> Security Class Initialized
DEBUG - 2022-03-09 06:27:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 06:27:36 --> Input Class Initialized
INFO - 2022-03-09 06:27:36 --> Language Class Initialized
INFO - 2022-03-09 06:27:36 --> Loader Class Initialized
INFO - 2022-03-09 06:27:36 --> Helper loaded: url_helper
INFO - 2022-03-09 06:27:36 --> Helper loaded: form_helper
INFO - 2022-03-09 06:27:36 --> Helper loaded: common_helper
INFO - 2022-03-09 06:27:36 --> Database Driver Class Initialized
DEBUG - 2022-03-09 06:27:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 06:27:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 06:27:36 --> Controller Class Initialized
INFO - 2022-03-09 06:27:36 --> Form Validation Class Initialized
DEBUG - 2022-03-09 06:27:36 --> Encrypt Class Initialized
INFO - 2022-03-09 06:27:36 --> Model "Patient_model" initialized
INFO - 2022-03-09 06:27:36 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 06:27:36 --> Model "Referredby_model" initialized
INFO - 2022-03-09 06:27:36 --> Model "Prefix_master" initialized
INFO - 2022-03-09 06:27:36 --> Model "Hospital_model" initialized
INFO - 2022-03-09 06:27:36 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 06:27:36 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-09 06:27:36 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 06:27:36 --> Final output sent to browser
DEBUG - 2022-03-09 06:27:36 --> Total execution time: 0.1039
ERROR - 2022-03-09 07:37:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 07:37:57 --> Config Class Initialized
INFO - 2022-03-09 07:37:57 --> Hooks Class Initialized
DEBUG - 2022-03-09 07:37:57 --> UTF-8 Support Enabled
INFO - 2022-03-09 07:37:57 --> Utf8 Class Initialized
INFO - 2022-03-09 07:37:57 --> URI Class Initialized
DEBUG - 2022-03-09 07:37:57 --> No URI present. Default controller set.
INFO - 2022-03-09 07:37:57 --> Router Class Initialized
INFO - 2022-03-09 07:37:57 --> Output Class Initialized
INFO - 2022-03-09 07:37:57 --> Security Class Initialized
DEBUG - 2022-03-09 07:37:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 07:37:57 --> Input Class Initialized
INFO - 2022-03-09 07:37:57 --> Language Class Initialized
INFO - 2022-03-09 07:37:57 --> Loader Class Initialized
INFO - 2022-03-09 07:37:57 --> Helper loaded: url_helper
INFO - 2022-03-09 07:37:57 --> Helper loaded: form_helper
INFO - 2022-03-09 07:37:57 --> Helper loaded: common_helper
INFO - 2022-03-09 07:37:57 --> Database Driver Class Initialized
DEBUG - 2022-03-09 07:37:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 07:37:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 07:37:57 --> Controller Class Initialized
INFO - 2022-03-09 07:37:57 --> Form Validation Class Initialized
DEBUG - 2022-03-09 07:37:57 --> Encrypt Class Initialized
DEBUG - 2022-03-09 07:37:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-09 07:37:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-09 07:37:57 --> Email Class Initialized
INFO - 2022-03-09 07:37:57 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-09 07:37:57 --> Calendar Class Initialized
INFO - 2022-03-09 07:37:57 --> Model "Login_model" initialized
INFO - 2022-03-09 07:37:57 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-09 07:37:57 --> Final output sent to browser
DEBUG - 2022-03-09 07:37:57 --> Total execution time: 0.0398
ERROR - 2022-03-09 08:41:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 08:41:15 --> Config Class Initialized
INFO - 2022-03-09 08:41:15 --> Hooks Class Initialized
DEBUG - 2022-03-09 08:41:15 --> UTF-8 Support Enabled
INFO - 2022-03-09 08:41:15 --> Utf8 Class Initialized
INFO - 2022-03-09 08:41:15 --> URI Class Initialized
DEBUG - 2022-03-09 08:41:15 --> No URI present. Default controller set.
INFO - 2022-03-09 08:41:15 --> Router Class Initialized
INFO - 2022-03-09 08:41:15 --> Output Class Initialized
INFO - 2022-03-09 08:41:15 --> Security Class Initialized
DEBUG - 2022-03-09 08:41:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 08:41:15 --> Input Class Initialized
INFO - 2022-03-09 08:41:15 --> Language Class Initialized
INFO - 2022-03-09 08:41:15 --> Loader Class Initialized
INFO - 2022-03-09 08:41:15 --> Helper loaded: url_helper
INFO - 2022-03-09 08:41:15 --> Helper loaded: form_helper
INFO - 2022-03-09 08:41:15 --> Helper loaded: common_helper
INFO - 2022-03-09 08:41:15 --> Database Driver Class Initialized
DEBUG - 2022-03-09 08:41:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 08:41:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 08:41:15 --> Controller Class Initialized
INFO - 2022-03-09 08:41:15 --> Form Validation Class Initialized
DEBUG - 2022-03-09 08:41:15 --> Encrypt Class Initialized
DEBUG - 2022-03-09 08:41:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-09 08:41:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-09 08:41:15 --> Email Class Initialized
INFO - 2022-03-09 08:41:15 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-09 08:41:15 --> Calendar Class Initialized
INFO - 2022-03-09 08:41:15 --> Model "Login_model" initialized
INFO - 2022-03-09 08:41:15 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-09 08:41:15 --> Final output sent to browser
DEBUG - 2022-03-09 08:41:15 --> Total execution time: 0.0214
ERROR - 2022-03-09 10:49:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 10:49:50 --> Config Class Initialized
INFO - 2022-03-09 10:49:50 --> Hooks Class Initialized
DEBUG - 2022-03-09 10:49:50 --> UTF-8 Support Enabled
INFO - 2022-03-09 10:49:50 --> Utf8 Class Initialized
INFO - 2022-03-09 10:49:50 --> URI Class Initialized
DEBUG - 2022-03-09 10:49:50 --> No URI present. Default controller set.
INFO - 2022-03-09 10:49:50 --> Router Class Initialized
INFO - 2022-03-09 10:49:50 --> Output Class Initialized
INFO - 2022-03-09 10:49:50 --> Security Class Initialized
DEBUG - 2022-03-09 10:49:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 10:49:50 --> Input Class Initialized
INFO - 2022-03-09 10:49:50 --> Language Class Initialized
INFO - 2022-03-09 10:49:50 --> Loader Class Initialized
INFO - 2022-03-09 10:49:50 --> Helper loaded: url_helper
INFO - 2022-03-09 10:49:50 --> Helper loaded: form_helper
INFO - 2022-03-09 10:49:50 --> Helper loaded: common_helper
INFO - 2022-03-09 10:49:50 --> Database Driver Class Initialized
DEBUG - 2022-03-09 10:49:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 10:49:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 10:49:50 --> Controller Class Initialized
INFO - 2022-03-09 10:49:50 --> Form Validation Class Initialized
DEBUG - 2022-03-09 10:49:50 --> Encrypt Class Initialized
DEBUG - 2022-03-09 10:49:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-09 10:49:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-09 10:49:50 --> Email Class Initialized
INFO - 2022-03-09 10:49:50 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-09 10:49:50 --> Calendar Class Initialized
INFO - 2022-03-09 10:49:50 --> Model "Login_model" initialized
INFO - 2022-03-09 10:49:50 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-09 10:49:50 --> Final output sent to browser
DEBUG - 2022-03-09 10:49:50 --> Total execution time: 0.0279
ERROR - 2022-03-09 10:55:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 10:55:06 --> Config Class Initialized
INFO - 2022-03-09 10:55:06 --> Hooks Class Initialized
DEBUG - 2022-03-09 10:55:06 --> UTF-8 Support Enabled
INFO - 2022-03-09 10:55:06 --> Utf8 Class Initialized
INFO - 2022-03-09 10:55:06 --> URI Class Initialized
DEBUG - 2022-03-09 10:55:06 --> No URI present. Default controller set.
INFO - 2022-03-09 10:55:06 --> Router Class Initialized
INFO - 2022-03-09 10:55:06 --> Output Class Initialized
INFO - 2022-03-09 10:55:06 --> Security Class Initialized
DEBUG - 2022-03-09 10:55:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 10:55:06 --> Input Class Initialized
INFO - 2022-03-09 10:55:06 --> Language Class Initialized
INFO - 2022-03-09 10:55:06 --> Loader Class Initialized
INFO - 2022-03-09 10:55:06 --> Helper loaded: url_helper
INFO - 2022-03-09 10:55:06 --> Helper loaded: form_helper
INFO - 2022-03-09 10:55:06 --> Helper loaded: common_helper
INFO - 2022-03-09 10:55:06 --> Database Driver Class Initialized
DEBUG - 2022-03-09 10:55:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 10:55:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 10:55:06 --> Controller Class Initialized
INFO - 2022-03-09 10:55:06 --> Form Validation Class Initialized
DEBUG - 2022-03-09 10:55:06 --> Encrypt Class Initialized
DEBUG - 2022-03-09 10:55:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-09 10:55:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-09 10:55:06 --> Email Class Initialized
INFO - 2022-03-09 10:55:06 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-09 10:55:06 --> Calendar Class Initialized
INFO - 2022-03-09 10:55:06 --> Model "Login_model" initialized
INFO - 2022-03-09 10:55:06 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-09 10:55:06 --> Final output sent to browser
DEBUG - 2022-03-09 10:55:06 --> Total execution time: 0.0210
ERROR - 2022-03-09 13:34:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 13:34:57 --> Config Class Initialized
INFO - 2022-03-09 13:34:57 --> Hooks Class Initialized
DEBUG - 2022-03-09 13:34:57 --> UTF-8 Support Enabled
INFO - 2022-03-09 13:34:57 --> Utf8 Class Initialized
INFO - 2022-03-09 13:34:57 --> URI Class Initialized
INFO - 2022-03-09 13:34:57 --> Router Class Initialized
INFO - 2022-03-09 13:34:57 --> Output Class Initialized
INFO - 2022-03-09 13:34:57 --> Security Class Initialized
DEBUG - 2022-03-09 13:34:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 13:34:57 --> Input Class Initialized
INFO - 2022-03-09 13:34:57 --> Language Class Initialized
ERROR - 2022-03-09 13:34:57 --> 404 Page Not Found: Wp-admin/includes
ERROR - 2022-03-09 13:35:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 13:35:02 --> Config Class Initialized
INFO - 2022-03-09 13:35:02 --> Hooks Class Initialized
DEBUG - 2022-03-09 13:35:02 --> UTF-8 Support Enabled
INFO - 2022-03-09 13:35:02 --> Utf8 Class Initialized
INFO - 2022-03-09 13:35:02 --> URI Class Initialized
INFO - 2022-03-09 13:35:02 --> Router Class Initialized
INFO - 2022-03-09 13:35:02 --> Output Class Initialized
INFO - 2022-03-09 13:35:02 --> Security Class Initialized
DEBUG - 2022-03-09 13:35:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 13:35:02 --> Input Class Initialized
INFO - 2022-03-09 13:35:02 --> Language Class Initialized
ERROR - 2022-03-09 13:35:02 --> 404 Page Not Found: Wp/wp-admin
ERROR - 2022-03-09 13:35:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 13:35:09 --> Config Class Initialized
INFO - 2022-03-09 13:35:09 --> Hooks Class Initialized
DEBUG - 2022-03-09 13:35:09 --> UTF-8 Support Enabled
INFO - 2022-03-09 13:35:09 --> Utf8 Class Initialized
INFO - 2022-03-09 13:35:09 --> URI Class Initialized
INFO - 2022-03-09 13:35:09 --> Router Class Initialized
INFO - 2022-03-09 13:35:09 --> Output Class Initialized
INFO - 2022-03-09 13:35:09 --> Security Class Initialized
DEBUG - 2022-03-09 13:35:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 13:35:09 --> Input Class Initialized
INFO - 2022-03-09 13:35:09 --> Language Class Initialized
ERROR - 2022-03-09 13:35:09 --> 404 Page Not Found: Wordpress/wp-admin
ERROR - 2022-03-09 13:35:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 13:35:13 --> Config Class Initialized
INFO - 2022-03-09 13:35:13 --> Hooks Class Initialized
DEBUG - 2022-03-09 13:35:13 --> UTF-8 Support Enabled
INFO - 2022-03-09 13:35:13 --> Utf8 Class Initialized
INFO - 2022-03-09 13:35:13 --> URI Class Initialized
INFO - 2022-03-09 13:35:13 --> Router Class Initialized
INFO - 2022-03-09 13:35:13 --> Output Class Initialized
INFO - 2022-03-09 13:35:13 --> Security Class Initialized
DEBUG - 2022-03-09 13:35:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 13:35:13 --> Input Class Initialized
INFO - 2022-03-09 13:35:13 --> Language Class Initialized
ERROR - 2022-03-09 13:35:13 --> 404 Page Not Found: Site/wp-admin
ERROR - 2022-03-09 13:35:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 13:35:23 --> Config Class Initialized
INFO - 2022-03-09 13:35:23 --> Hooks Class Initialized
DEBUG - 2022-03-09 13:35:23 --> UTF-8 Support Enabled
INFO - 2022-03-09 13:35:23 --> Utf8 Class Initialized
INFO - 2022-03-09 13:35:23 --> URI Class Initialized
INFO - 2022-03-09 13:35:23 --> Router Class Initialized
INFO - 2022-03-09 13:35:23 --> Output Class Initialized
INFO - 2022-03-09 13:35:23 --> Security Class Initialized
DEBUG - 2022-03-09 13:35:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 13:35:23 --> Input Class Initialized
INFO - 2022-03-09 13:35:23 --> Language Class Initialized
ERROR - 2022-03-09 13:35:23 --> 404 Page Not Found: Blog/wp-admin
ERROR - 2022-03-09 14:17:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 14:17:25 --> Config Class Initialized
INFO - 2022-03-09 14:17:25 --> Hooks Class Initialized
DEBUG - 2022-03-09 14:17:25 --> UTF-8 Support Enabled
INFO - 2022-03-09 14:17:25 --> Utf8 Class Initialized
INFO - 2022-03-09 14:17:25 --> URI Class Initialized
DEBUG - 2022-03-09 14:17:25 --> No URI present. Default controller set.
INFO - 2022-03-09 14:17:25 --> Router Class Initialized
INFO - 2022-03-09 14:17:25 --> Output Class Initialized
INFO - 2022-03-09 14:17:25 --> Security Class Initialized
DEBUG - 2022-03-09 14:17:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 14:17:25 --> Input Class Initialized
INFO - 2022-03-09 14:17:25 --> Language Class Initialized
INFO - 2022-03-09 14:17:25 --> Loader Class Initialized
INFO - 2022-03-09 14:17:25 --> Helper loaded: url_helper
INFO - 2022-03-09 14:17:25 --> Helper loaded: form_helper
INFO - 2022-03-09 14:17:25 --> Helper loaded: common_helper
INFO - 2022-03-09 14:17:25 --> Database Driver Class Initialized
DEBUG - 2022-03-09 14:17:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 14:17:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 14:17:25 --> Controller Class Initialized
INFO - 2022-03-09 14:17:25 --> Form Validation Class Initialized
DEBUG - 2022-03-09 14:17:25 --> Encrypt Class Initialized
DEBUG - 2022-03-09 14:17:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-09 14:17:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-09 14:17:25 --> Email Class Initialized
INFO - 2022-03-09 14:17:25 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-09 14:17:25 --> Calendar Class Initialized
INFO - 2022-03-09 14:17:25 --> Model "Login_model" initialized
INFO - 2022-03-09 14:17:25 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-09 14:17:25 --> Final output sent to browser
DEBUG - 2022-03-09 14:17:25 --> Total execution time: 0.0235
ERROR - 2022-03-09 14:17:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 14:17:27 --> Config Class Initialized
INFO - 2022-03-09 14:17:27 --> Hooks Class Initialized
DEBUG - 2022-03-09 14:17:27 --> UTF-8 Support Enabled
INFO - 2022-03-09 14:17:27 --> Utf8 Class Initialized
INFO - 2022-03-09 14:17:27 --> URI Class Initialized
INFO - 2022-03-09 14:17:27 --> Router Class Initialized
INFO - 2022-03-09 14:17:27 --> Output Class Initialized
INFO - 2022-03-09 14:17:27 --> Security Class Initialized
DEBUG - 2022-03-09 14:17:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 14:17:27 --> Input Class Initialized
INFO - 2022-03-09 14:17:27 --> Language Class Initialized
ERROR - 2022-03-09 14:17:27 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2022-03-09 14:17:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 14:17:43 --> Config Class Initialized
INFO - 2022-03-09 14:17:43 --> Hooks Class Initialized
DEBUG - 2022-03-09 14:17:43 --> UTF-8 Support Enabled
INFO - 2022-03-09 14:17:43 --> Utf8 Class Initialized
INFO - 2022-03-09 14:17:43 --> URI Class Initialized
INFO - 2022-03-09 14:17:43 --> Router Class Initialized
INFO - 2022-03-09 14:17:43 --> Output Class Initialized
INFO - 2022-03-09 14:17:43 --> Security Class Initialized
DEBUG - 2022-03-09 14:17:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 14:17:43 --> Input Class Initialized
INFO - 2022-03-09 14:17:43 --> Language Class Initialized
INFO - 2022-03-09 14:17:43 --> Loader Class Initialized
INFO - 2022-03-09 14:17:43 --> Helper loaded: url_helper
INFO - 2022-03-09 14:17:43 --> Helper loaded: form_helper
INFO - 2022-03-09 14:17:43 --> Helper loaded: common_helper
INFO - 2022-03-09 14:17:43 --> Database Driver Class Initialized
DEBUG - 2022-03-09 14:17:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 14:17:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 14:17:43 --> Controller Class Initialized
INFO - 2022-03-09 14:17:43 --> Form Validation Class Initialized
DEBUG - 2022-03-09 14:17:43 --> Encrypt Class Initialized
DEBUG - 2022-03-09 14:17:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-09 14:17:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-09 14:17:43 --> Email Class Initialized
INFO - 2022-03-09 14:17:43 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-09 14:17:43 --> Calendar Class Initialized
INFO - 2022-03-09 14:17:43 --> Model "Login_model" initialized
ERROR - 2022-03-09 14:17:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 14:17:44 --> Config Class Initialized
INFO - 2022-03-09 14:17:44 --> Hooks Class Initialized
DEBUG - 2022-03-09 14:17:44 --> UTF-8 Support Enabled
INFO - 2022-03-09 14:17:44 --> Utf8 Class Initialized
INFO - 2022-03-09 14:17:44 --> URI Class Initialized
INFO - 2022-03-09 14:17:44 --> Router Class Initialized
INFO - 2022-03-09 14:17:44 --> Output Class Initialized
INFO - 2022-03-09 14:17:44 --> Security Class Initialized
DEBUG - 2022-03-09 14:17:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 14:17:44 --> Input Class Initialized
INFO - 2022-03-09 14:17:44 --> Language Class Initialized
INFO - 2022-03-09 14:17:44 --> Loader Class Initialized
INFO - 2022-03-09 14:17:44 --> Helper loaded: url_helper
INFO - 2022-03-09 14:17:44 --> Helper loaded: form_helper
INFO - 2022-03-09 14:17:44 --> Helper loaded: common_helper
INFO - 2022-03-09 14:17:44 --> Database Driver Class Initialized
DEBUG - 2022-03-09 14:17:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 14:17:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 14:17:44 --> Controller Class Initialized
INFO - 2022-03-09 14:17:44 --> Form Validation Class Initialized
DEBUG - 2022-03-09 14:17:44 --> Encrypt Class Initialized
DEBUG - 2022-03-09 14:17:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-09 14:17:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-09 14:17:44 --> Email Class Initialized
INFO - 2022-03-09 14:17:44 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-09 14:17:44 --> Calendar Class Initialized
INFO - 2022-03-09 14:17:44 --> Model "Login_model" initialized
ERROR - 2022-03-09 14:17:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 14:17:44 --> Config Class Initialized
INFO - 2022-03-09 14:17:44 --> Hooks Class Initialized
DEBUG - 2022-03-09 14:17:44 --> UTF-8 Support Enabled
INFO - 2022-03-09 14:17:44 --> Utf8 Class Initialized
INFO - 2022-03-09 14:17:44 --> URI Class Initialized
DEBUG - 2022-03-09 14:17:44 --> No URI present. Default controller set.
INFO - 2022-03-09 14:17:44 --> Router Class Initialized
INFO - 2022-03-09 14:17:44 --> Output Class Initialized
INFO - 2022-03-09 14:17:44 --> Security Class Initialized
DEBUG - 2022-03-09 14:17:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 14:17:44 --> Input Class Initialized
INFO - 2022-03-09 14:17:44 --> Language Class Initialized
INFO - 2022-03-09 14:17:44 --> Loader Class Initialized
INFO - 2022-03-09 14:17:44 --> Helper loaded: url_helper
INFO - 2022-03-09 14:17:44 --> Helper loaded: form_helper
INFO - 2022-03-09 14:17:44 --> Helper loaded: common_helper
INFO - 2022-03-09 14:17:44 --> Database Driver Class Initialized
DEBUG - 2022-03-09 14:17:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 14:17:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 14:17:44 --> Controller Class Initialized
INFO - 2022-03-09 14:17:44 --> Form Validation Class Initialized
DEBUG - 2022-03-09 14:17:44 --> Encrypt Class Initialized
DEBUG - 2022-03-09 14:17:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-09 14:17:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-09 14:17:44 --> Email Class Initialized
INFO - 2022-03-09 14:17:44 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-09 14:17:44 --> Calendar Class Initialized
INFO - 2022-03-09 14:17:44 --> Model "Login_model" initialized
INFO - 2022-03-09 14:17:44 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-09 14:17:44 --> Final output sent to browser
DEBUG - 2022-03-09 14:17:44 --> Total execution time: 0.0294
ERROR - 2022-03-09 14:17:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 14:17:45 --> Config Class Initialized
INFO - 2022-03-09 14:17:45 --> Hooks Class Initialized
DEBUG - 2022-03-09 14:17:45 --> UTF-8 Support Enabled
INFO - 2022-03-09 14:17:45 --> Utf8 Class Initialized
INFO - 2022-03-09 14:17:45 --> URI Class Initialized
INFO - 2022-03-09 14:17:45 --> Router Class Initialized
INFO - 2022-03-09 14:17:45 --> Output Class Initialized
INFO - 2022-03-09 14:17:45 --> Security Class Initialized
DEBUG - 2022-03-09 14:17:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 14:17:45 --> Input Class Initialized
INFO - 2022-03-09 14:17:45 --> Language Class Initialized
INFO - 2022-03-09 14:17:45 --> Loader Class Initialized
INFO - 2022-03-09 14:17:45 --> Helper loaded: url_helper
INFO - 2022-03-09 14:17:45 --> Helper loaded: form_helper
INFO - 2022-03-09 14:17:45 --> Helper loaded: common_helper
INFO - 2022-03-09 14:17:45 --> Database Driver Class Initialized
DEBUG - 2022-03-09 14:17:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 14:17:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 14:17:45 --> Controller Class Initialized
INFO - 2022-03-09 14:17:45 --> Form Validation Class Initialized
DEBUG - 2022-03-09 14:17:45 --> Encrypt Class Initialized
DEBUG - 2022-03-09 14:17:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-09 14:17:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-09 14:17:45 --> Email Class Initialized
INFO - 2022-03-09 14:17:45 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-09 14:17:45 --> Calendar Class Initialized
INFO - 2022-03-09 14:17:45 --> Model "Login_model" initialized
INFO - 2022-03-09 14:17:45 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-09 14:17:45 --> Final output sent to browser
DEBUG - 2022-03-09 14:17:45 --> Total execution time: 0.0265
ERROR - 2022-03-09 15:12:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 15:12:25 --> Config Class Initialized
INFO - 2022-03-09 15:12:25 --> Hooks Class Initialized
DEBUG - 2022-03-09 15:12:25 --> UTF-8 Support Enabled
INFO - 2022-03-09 15:12:25 --> Utf8 Class Initialized
INFO - 2022-03-09 15:12:25 --> URI Class Initialized
DEBUG - 2022-03-09 15:12:25 --> No URI present. Default controller set.
INFO - 2022-03-09 15:12:25 --> Router Class Initialized
INFO - 2022-03-09 15:12:25 --> Output Class Initialized
INFO - 2022-03-09 15:12:25 --> Security Class Initialized
DEBUG - 2022-03-09 15:12:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 15:12:25 --> Input Class Initialized
INFO - 2022-03-09 15:12:25 --> Language Class Initialized
INFO - 2022-03-09 15:12:25 --> Loader Class Initialized
INFO - 2022-03-09 15:12:25 --> Helper loaded: url_helper
INFO - 2022-03-09 15:12:25 --> Helper loaded: form_helper
INFO - 2022-03-09 15:12:25 --> Helper loaded: common_helper
INFO - 2022-03-09 15:12:25 --> Database Driver Class Initialized
DEBUG - 2022-03-09 15:12:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 15:12:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 15:12:25 --> Controller Class Initialized
INFO - 2022-03-09 15:12:25 --> Form Validation Class Initialized
DEBUG - 2022-03-09 15:12:25 --> Encrypt Class Initialized
DEBUG - 2022-03-09 15:12:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-09 15:12:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-09 15:12:25 --> Email Class Initialized
INFO - 2022-03-09 15:12:25 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-09 15:12:25 --> Calendar Class Initialized
INFO - 2022-03-09 15:12:25 --> Model "Login_model" initialized
INFO - 2022-03-09 15:12:25 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-09 15:12:25 --> Final output sent to browser
DEBUG - 2022-03-09 15:12:25 --> Total execution time: 0.0222
ERROR - 2022-03-09 15:43:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 15:43:19 --> Config Class Initialized
INFO - 2022-03-09 15:43:19 --> Hooks Class Initialized
DEBUG - 2022-03-09 15:43:19 --> UTF-8 Support Enabled
INFO - 2022-03-09 15:43:19 --> Utf8 Class Initialized
INFO - 2022-03-09 15:43:19 --> URI Class Initialized
DEBUG - 2022-03-09 15:43:19 --> No URI present. Default controller set.
INFO - 2022-03-09 15:43:19 --> Router Class Initialized
INFO - 2022-03-09 15:43:19 --> Output Class Initialized
INFO - 2022-03-09 15:43:19 --> Security Class Initialized
DEBUG - 2022-03-09 15:43:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 15:43:19 --> Input Class Initialized
INFO - 2022-03-09 15:43:19 --> Language Class Initialized
INFO - 2022-03-09 15:43:19 --> Loader Class Initialized
INFO - 2022-03-09 15:43:19 --> Helper loaded: url_helper
INFO - 2022-03-09 15:43:19 --> Helper loaded: form_helper
INFO - 2022-03-09 15:43:19 --> Helper loaded: common_helper
INFO - 2022-03-09 15:43:19 --> Database Driver Class Initialized
DEBUG - 2022-03-09 15:43:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 15:43:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 15:43:19 --> Controller Class Initialized
INFO - 2022-03-09 15:43:19 --> Form Validation Class Initialized
DEBUG - 2022-03-09 15:43:19 --> Encrypt Class Initialized
DEBUG - 2022-03-09 15:43:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-09 15:43:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-09 15:43:19 --> Email Class Initialized
INFO - 2022-03-09 15:43:19 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-09 15:43:19 --> Calendar Class Initialized
INFO - 2022-03-09 15:43:19 --> Model "Login_model" initialized
INFO - 2022-03-09 15:43:19 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-09 15:43:19 --> Final output sent to browser
DEBUG - 2022-03-09 15:43:19 --> Total execution time: 0.0234
ERROR - 2022-03-09 22:23:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 22:23:37 --> Config Class Initialized
INFO - 2022-03-09 22:23:37 --> Hooks Class Initialized
DEBUG - 2022-03-09 22:23:37 --> UTF-8 Support Enabled
INFO - 2022-03-09 22:23:37 --> Utf8 Class Initialized
INFO - 2022-03-09 22:23:37 --> URI Class Initialized
INFO - 2022-03-09 22:23:37 --> Router Class Initialized
INFO - 2022-03-09 22:23:37 --> Output Class Initialized
INFO - 2022-03-09 22:23:37 --> Security Class Initialized
DEBUG - 2022-03-09 22:23:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 22:23:37 --> Input Class Initialized
INFO - 2022-03-09 22:23:37 --> Language Class Initialized
INFO - 2022-03-09 22:23:37 --> Loader Class Initialized
INFO - 2022-03-09 22:23:37 --> Helper loaded: url_helper
INFO - 2022-03-09 22:23:37 --> Helper loaded: form_helper
INFO - 2022-03-09 22:23:37 --> Helper loaded: common_helper
INFO - 2022-03-09 22:23:37 --> Database Driver Class Initialized
DEBUG - 2022-03-09 22:23:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 22:23:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 22:23:37 --> Controller Class Initialized
INFO - 2022-03-09 22:23:37 --> Form Validation Class Initialized
DEBUG - 2022-03-09 22:23:37 --> Encrypt Class Initialized
DEBUG - 2022-03-09 22:23:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-09 22:23:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-09 22:23:37 --> Email Class Initialized
INFO - 2022-03-09 22:23:37 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-09 22:23:37 --> Calendar Class Initialized
INFO - 2022-03-09 22:23:37 --> Model "Login_model" initialized
INFO - 2022-03-09 22:23:37 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-09 22:23:37 --> Final output sent to browser
DEBUG - 2022-03-09 22:23:37 --> Total execution time: 0.0218
ERROR - 2022-03-09 22:24:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 22:24:59 --> Config Class Initialized
INFO - 2022-03-09 22:24:59 --> Hooks Class Initialized
DEBUG - 2022-03-09 22:24:59 --> UTF-8 Support Enabled
INFO - 2022-03-09 22:24:59 --> Utf8 Class Initialized
INFO - 2022-03-09 22:24:59 --> URI Class Initialized
INFO - 2022-03-09 22:24:59 --> Router Class Initialized
INFO - 2022-03-09 22:24:59 --> Output Class Initialized
INFO - 2022-03-09 22:24:59 --> Security Class Initialized
DEBUG - 2022-03-09 22:24:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 22:24:59 --> Input Class Initialized
INFO - 2022-03-09 22:24:59 --> Language Class Initialized
INFO - 2022-03-09 22:24:59 --> Loader Class Initialized
INFO - 2022-03-09 22:24:59 --> Helper loaded: url_helper
INFO - 2022-03-09 22:24:59 --> Helper loaded: form_helper
INFO - 2022-03-09 22:24:59 --> Helper loaded: common_helper
INFO - 2022-03-09 22:24:59 --> Database Driver Class Initialized
DEBUG - 2022-03-09 22:24:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 22:24:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 22:24:59 --> Controller Class Initialized
INFO - 2022-03-09 22:24:59 --> Form Validation Class Initialized
DEBUG - 2022-03-09 22:24:59 --> Encrypt Class Initialized
DEBUG - 2022-03-09 22:24:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-09 22:24:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-09 22:24:59 --> Email Class Initialized
INFO - 2022-03-09 22:24:59 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-09 22:24:59 --> Calendar Class Initialized
INFO - 2022-03-09 22:24:59 --> Model "Login_model" initialized
INFO - 2022-03-09 22:24:59 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-03-09 22:24:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 22:24:59 --> Config Class Initialized
INFO - 2022-03-09 22:24:59 --> Hooks Class Initialized
DEBUG - 2022-03-09 22:24:59 --> UTF-8 Support Enabled
INFO - 2022-03-09 22:24:59 --> Utf8 Class Initialized
INFO - 2022-03-09 22:24:59 --> URI Class Initialized
INFO - 2022-03-09 22:24:59 --> Router Class Initialized
INFO - 2022-03-09 22:24:59 --> Output Class Initialized
INFO - 2022-03-09 22:24:59 --> Security Class Initialized
DEBUG - 2022-03-09 22:24:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 22:24:59 --> Input Class Initialized
INFO - 2022-03-09 22:24:59 --> Language Class Initialized
INFO - 2022-03-09 22:24:59 --> Loader Class Initialized
INFO - 2022-03-09 22:24:59 --> Helper loaded: url_helper
INFO - 2022-03-09 22:24:59 --> Helper loaded: form_helper
INFO - 2022-03-09 22:24:59 --> Helper loaded: common_helper
INFO - 2022-03-09 22:24:59 --> Database Driver Class Initialized
DEBUG - 2022-03-09 22:24:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 22:24:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 22:24:59 --> Controller Class Initialized
INFO - 2022-03-09 22:24:59 --> Form Validation Class Initialized
DEBUG - 2022-03-09 22:24:59 --> Encrypt Class Initialized
INFO - 2022-03-09 22:24:59 --> Model "Login_model" initialized
INFO - 2022-03-09 22:24:59 --> Model "Dashboard_model" initialized
INFO - 2022-03-09 22:24:59 --> Model "Case_model" initialized
INFO - 2022-03-09 22:25:00 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 22:25:00 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2022-03-09 22:25:00 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 22:25:00 --> Final output sent to browser
DEBUG - 2022-03-09 22:25:00 --> Total execution time: 0.3232
ERROR - 2022-03-09 22:25:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 22:25:14 --> Config Class Initialized
INFO - 2022-03-09 22:25:14 --> Hooks Class Initialized
DEBUG - 2022-03-09 22:25:14 --> UTF-8 Support Enabled
INFO - 2022-03-09 22:25:14 --> Utf8 Class Initialized
INFO - 2022-03-09 22:25:14 --> URI Class Initialized
INFO - 2022-03-09 22:25:14 --> Router Class Initialized
INFO - 2022-03-09 22:25:14 --> Output Class Initialized
INFO - 2022-03-09 22:25:14 --> Security Class Initialized
DEBUG - 2022-03-09 22:25:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 22:25:14 --> Input Class Initialized
INFO - 2022-03-09 22:25:14 --> Language Class Initialized
INFO - 2022-03-09 22:25:14 --> Loader Class Initialized
INFO - 2022-03-09 22:25:14 --> Helper loaded: url_helper
INFO - 2022-03-09 22:25:14 --> Helper loaded: form_helper
INFO - 2022-03-09 22:25:14 --> Helper loaded: common_helper
INFO - 2022-03-09 22:25:14 --> Database Driver Class Initialized
DEBUG - 2022-03-09 22:25:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 22:25:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 22:25:14 --> Controller Class Initialized
INFO - 2022-03-09 22:25:14 --> Form Validation Class Initialized
INFO - 2022-03-09 22:25:14 --> Model "Case_model" initialized
INFO - 2022-03-09 22:25:14 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 22:25:14 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 22:25:14 --> File loaded: /home3/karoteam/public_html/application/views/cases/new_case.php
INFO - 2022-03-09 22:25:14 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 22:25:14 --> Final output sent to browser
DEBUG - 2022-03-09 22:25:14 --> Total execution time: 0.0538
ERROR - 2022-03-09 22:25:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 22:25:36 --> Config Class Initialized
INFO - 2022-03-09 22:25:36 --> Hooks Class Initialized
DEBUG - 2022-03-09 22:25:36 --> UTF-8 Support Enabled
INFO - 2022-03-09 22:25:36 --> Utf8 Class Initialized
INFO - 2022-03-09 22:25:36 --> URI Class Initialized
INFO - 2022-03-09 22:25:36 --> Router Class Initialized
INFO - 2022-03-09 22:25:36 --> Output Class Initialized
INFO - 2022-03-09 22:25:36 --> Security Class Initialized
DEBUG - 2022-03-09 22:25:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 22:25:36 --> Input Class Initialized
INFO - 2022-03-09 22:25:36 --> Language Class Initialized
INFO - 2022-03-09 22:25:36 --> Loader Class Initialized
INFO - 2022-03-09 22:25:36 --> Helper loaded: url_helper
INFO - 2022-03-09 22:25:37 --> Helper loaded: form_helper
INFO - 2022-03-09 22:25:37 --> Helper loaded: common_helper
INFO - 2022-03-09 22:25:37 --> Database Driver Class Initialized
DEBUG - 2022-03-09 22:25:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 22:25:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 22:25:37 --> Controller Class Initialized
INFO - 2022-03-09 22:25:37 --> Form Validation Class Initialized
DEBUG - 2022-03-09 22:25:37 --> Encrypt Class Initialized
INFO - 2022-03-09 22:25:37 --> Model "Patient_model" initialized
INFO - 2022-03-09 22:25:37 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 22:25:37 --> Model "Prefix_master" initialized
INFO - 2022-03-09 22:25:37 --> Model "Users_model" initialized
INFO - 2022-03-09 22:25:37 --> Model "Hospital_model" initialized
INFO - 2022-03-09 22:25:37 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 22:25:37 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-09 22:25:37 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 22:25:37 --> Final output sent to browser
DEBUG - 2022-03-09 22:25:37 --> Total execution time: 0.2675
ERROR - 2022-03-09 22:25:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 22:25:47 --> Config Class Initialized
INFO - 2022-03-09 22:25:47 --> Hooks Class Initialized
DEBUG - 2022-03-09 22:25:47 --> UTF-8 Support Enabled
INFO - 2022-03-09 22:25:47 --> Utf8 Class Initialized
INFO - 2022-03-09 22:25:47 --> URI Class Initialized
INFO - 2022-03-09 22:25:47 --> Router Class Initialized
INFO - 2022-03-09 22:25:47 --> Output Class Initialized
INFO - 2022-03-09 22:25:47 --> Security Class Initialized
DEBUG - 2022-03-09 22:25:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 22:25:47 --> Input Class Initialized
INFO - 2022-03-09 22:25:47 --> Language Class Initialized
INFO - 2022-03-09 22:25:47 --> Loader Class Initialized
INFO - 2022-03-09 22:25:47 --> Helper loaded: url_helper
INFO - 2022-03-09 22:25:47 --> Helper loaded: form_helper
INFO - 2022-03-09 22:25:47 --> Helper loaded: common_helper
INFO - 2022-03-09 22:25:47 --> Database Driver Class Initialized
DEBUG - 2022-03-09 22:25:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 22:25:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 22:25:47 --> Controller Class Initialized
INFO - 2022-03-09 22:25:47 --> Form Validation Class Initialized
DEBUG - 2022-03-09 22:25:47 --> Encrypt Class Initialized
INFO - 2022-03-09 22:25:47 --> Model "Patient_model" initialized
INFO - 2022-03-09 22:25:47 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 22:25:47 --> Model "Referredby_model" initialized
INFO - 2022-03-09 22:25:47 --> Model "Prefix_master" initialized
INFO - 2022-03-09 22:25:47 --> Model "Hospital_model" initialized
INFO - 2022-03-09 22:25:47 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 22:25:47 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-09 22:25:47 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 22:25:47 --> Final output sent to browser
DEBUG - 2022-03-09 22:25:47 --> Total execution time: 0.1419
ERROR - 2022-03-09 22:42:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 22:42:59 --> Config Class Initialized
INFO - 2022-03-09 22:42:59 --> Hooks Class Initialized
DEBUG - 2022-03-09 22:42:59 --> UTF-8 Support Enabled
INFO - 2022-03-09 22:42:59 --> Utf8 Class Initialized
INFO - 2022-03-09 22:42:59 --> URI Class Initialized
DEBUG - 2022-03-09 22:42:59 --> No URI present. Default controller set.
INFO - 2022-03-09 22:42:59 --> Router Class Initialized
INFO - 2022-03-09 22:42:59 --> Output Class Initialized
INFO - 2022-03-09 22:42:59 --> Security Class Initialized
DEBUG - 2022-03-09 22:42:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 22:42:59 --> Input Class Initialized
INFO - 2022-03-09 22:42:59 --> Language Class Initialized
INFO - 2022-03-09 22:42:59 --> Loader Class Initialized
INFO - 2022-03-09 22:42:59 --> Helper loaded: url_helper
INFO - 2022-03-09 22:42:59 --> Helper loaded: form_helper
INFO - 2022-03-09 22:42:59 --> Helper loaded: common_helper
INFO - 2022-03-09 22:42:59 --> Database Driver Class Initialized
DEBUG - 2022-03-09 22:42:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 22:42:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 22:42:59 --> Controller Class Initialized
INFO - 2022-03-09 22:42:59 --> Form Validation Class Initialized
DEBUG - 2022-03-09 22:42:59 --> Encrypt Class Initialized
DEBUG - 2022-03-09 22:42:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-09 22:42:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-09 22:42:59 --> Email Class Initialized
INFO - 2022-03-09 22:42:59 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-09 22:42:59 --> Calendar Class Initialized
INFO - 2022-03-09 22:42:59 --> Model "Login_model" initialized
INFO - 2022-03-09 22:42:59 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-09 22:42:59 --> Final output sent to browser
DEBUG - 2022-03-09 22:42:59 --> Total execution time: 0.0246
ERROR - 2022-03-09 22:52:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 22:52:23 --> Config Class Initialized
INFO - 2022-03-09 22:52:23 --> Hooks Class Initialized
DEBUG - 2022-03-09 22:52:23 --> UTF-8 Support Enabled
INFO - 2022-03-09 22:52:23 --> Utf8 Class Initialized
INFO - 2022-03-09 22:52:23 --> URI Class Initialized
DEBUG - 2022-03-09 22:52:23 --> No URI present. Default controller set.
INFO - 2022-03-09 22:52:23 --> Router Class Initialized
INFO - 2022-03-09 22:52:23 --> Output Class Initialized
INFO - 2022-03-09 22:52:23 --> Security Class Initialized
DEBUG - 2022-03-09 22:52:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 22:52:23 --> Input Class Initialized
INFO - 2022-03-09 22:52:23 --> Language Class Initialized
INFO - 2022-03-09 22:52:23 --> Loader Class Initialized
INFO - 2022-03-09 22:52:23 --> Helper loaded: url_helper
INFO - 2022-03-09 22:52:23 --> Helper loaded: form_helper
INFO - 2022-03-09 22:52:23 --> Helper loaded: common_helper
INFO - 2022-03-09 22:52:23 --> Database Driver Class Initialized
DEBUG - 2022-03-09 22:52:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 22:52:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 22:52:23 --> Controller Class Initialized
INFO - 2022-03-09 22:52:23 --> Form Validation Class Initialized
DEBUG - 2022-03-09 22:52:23 --> Encrypt Class Initialized
DEBUG - 2022-03-09 22:52:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-09 22:52:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-09 22:52:23 --> Email Class Initialized
INFO - 2022-03-09 22:52:23 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-09 22:52:23 --> Calendar Class Initialized
INFO - 2022-03-09 22:52:23 --> Model "Login_model" initialized
INFO - 2022-03-09 22:52:23 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-09 22:52:23 --> Final output sent to browser
DEBUG - 2022-03-09 22:52:23 --> Total execution time: 0.3717
ERROR - 2022-03-09 22:52:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 22:52:25 --> Config Class Initialized
INFO - 2022-03-09 22:52:25 --> Hooks Class Initialized
DEBUG - 2022-03-09 22:52:25 --> UTF-8 Support Enabled
INFO - 2022-03-09 22:52:25 --> Utf8 Class Initialized
INFO - 2022-03-09 22:52:25 --> URI Class Initialized
DEBUG - 2022-03-09 22:52:25 --> No URI present. Default controller set.
INFO - 2022-03-09 22:52:25 --> Router Class Initialized
INFO - 2022-03-09 22:52:25 --> Output Class Initialized
INFO - 2022-03-09 22:52:25 --> Security Class Initialized
DEBUG - 2022-03-09 22:52:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 22:52:25 --> Input Class Initialized
INFO - 2022-03-09 22:52:25 --> Language Class Initialized
INFO - 2022-03-09 22:52:25 --> Loader Class Initialized
INFO - 2022-03-09 22:52:25 --> Helper loaded: url_helper
INFO - 2022-03-09 22:52:25 --> Helper loaded: form_helper
INFO - 2022-03-09 22:52:25 --> Helper loaded: common_helper
INFO - 2022-03-09 22:52:25 --> Database Driver Class Initialized
DEBUG - 2022-03-09 22:52:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 22:52:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 22:52:25 --> Controller Class Initialized
INFO - 2022-03-09 22:52:25 --> Form Validation Class Initialized
DEBUG - 2022-03-09 22:52:25 --> Encrypt Class Initialized
DEBUG - 2022-03-09 22:52:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-09 22:52:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-09 22:52:25 --> Email Class Initialized
INFO - 2022-03-09 22:52:25 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-09 22:52:25 --> Calendar Class Initialized
INFO - 2022-03-09 22:52:25 --> Model "Login_model" initialized
INFO - 2022-03-09 22:52:25 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-09 22:52:25 --> Final output sent to browser
DEBUG - 2022-03-09 22:52:25 --> Total execution time: 0.0259
ERROR - 2022-03-09 22:52:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 22:52:50 --> Config Class Initialized
INFO - 2022-03-09 22:52:50 --> Hooks Class Initialized
DEBUG - 2022-03-09 22:52:50 --> UTF-8 Support Enabled
INFO - 2022-03-09 22:52:50 --> Utf8 Class Initialized
INFO - 2022-03-09 22:52:50 --> URI Class Initialized
INFO - 2022-03-09 22:52:50 --> Router Class Initialized
INFO - 2022-03-09 22:52:50 --> Output Class Initialized
INFO - 2022-03-09 22:52:50 --> Security Class Initialized
DEBUG - 2022-03-09 22:52:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 22:52:50 --> Input Class Initialized
INFO - 2022-03-09 22:52:50 --> Language Class Initialized
INFO - 2022-03-09 22:52:50 --> Loader Class Initialized
INFO - 2022-03-09 22:52:50 --> Helper loaded: url_helper
INFO - 2022-03-09 22:52:50 --> Helper loaded: form_helper
INFO - 2022-03-09 22:52:50 --> Helper loaded: common_helper
INFO - 2022-03-09 22:52:50 --> Database Driver Class Initialized
DEBUG - 2022-03-09 22:52:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 22:52:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 22:52:50 --> Controller Class Initialized
INFO - 2022-03-09 22:52:50 --> Form Validation Class Initialized
DEBUG - 2022-03-09 22:52:50 --> Encrypt Class Initialized
DEBUG - 2022-03-09 22:52:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-09 22:52:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-09 22:52:50 --> Email Class Initialized
INFO - 2022-03-09 22:52:50 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-09 22:52:50 --> Calendar Class Initialized
INFO - 2022-03-09 22:52:50 --> Model "Login_model" initialized
INFO - 2022-03-09 22:52:50 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-03-09 22:52:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 22:52:51 --> Config Class Initialized
INFO - 2022-03-09 22:52:51 --> Hooks Class Initialized
DEBUG - 2022-03-09 22:52:51 --> UTF-8 Support Enabled
INFO - 2022-03-09 22:52:51 --> Utf8 Class Initialized
INFO - 2022-03-09 22:52:51 --> URI Class Initialized
INFO - 2022-03-09 22:52:51 --> Router Class Initialized
INFO - 2022-03-09 22:52:51 --> Output Class Initialized
INFO - 2022-03-09 22:52:51 --> Security Class Initialized
DEBUG - 2022-03-09 22:52:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 22:52:51 --> Input Class Initialized
INFO - 2022-03-09 22:52:51 --> Language Class Initialized
INFO - 2022-03-09 22:52:51 --> Loader Class Initialized
INFO - 2022-03-09 22:52:51 --> Helper loaded: url_helper
INFO - 2022-03-09 22:52:51 --> Helper loaded: form_helper
INFO - 2022-03-09 22:52:51 --> Helper loaded: common_helper
INFO - 2022-03-09 22:52:51 --> Database Driver Class Initialized
DEBUG - 2022-03-09 22:52:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 22:52:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 22:52:51 --> Controller Class Initialized
INFO - 2022-03-09 22:52:51 --> Form Validation Class Initialized
DEBUG - 2022-03-09 22:52:51 --> Encrypt Class Initialized
DEBUG - 2022-03-09 22:52:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-09 22:52:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-09 22:52:51 --> Email Class Initialized
INFO - 2022-03-09 22:52:51 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-09 22:52:51 --> Calendar Class Initialized
INFO - 2022-03-09 22:52:51 --> Model "Login_model" initialized
INFO - 2022-03-09 22:52:51 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-09 22:52:51 --> Final output sent to browser
DEBUG - 2022-03-09 22:52:51 --> Total execution time: 0.0243
ERROR - 2022-03-09 22:53:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 22:53:20 --> Config Class Initialized
INFO - 2022-03-09 22:53:20 --> Hooks Class Initialized
DEBUG - 2022-03-09 22:53:20 --> UTF-8 Support Enabled
INFO - 2022-03-09 22:53:20 --> Utf8 Class Initialized
INFO - 2022-03-09 22:53:20 --> URI Class Initialized
INFO - 2022-03-09 22:53:20 --> Router Class Initialized
INFO - 2022-03-09 22:53:20 --> Output Class Initialized
INFO - 2022-03-09 22:53:20 --> Security Class Initialized
DEBUG - 2022-03-09 22:53:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 22:53:20 --> Input Class Initialized
INFO - 2022-03-09 22:53:20 --> Language Class Initialized
INFO - 2022-03-09 22:53:20 --> Loader Class Initialized
INFO - 2022-03-09 22:53:20 --> Helper loaded: url_helper
INFO - 2022-03-09 22:53:20 --> Helper loaded: form_helper
INFO - 2022-03-09 22:53:20 --> Helper loaded: common_helper
INFO - 2022-03-09 22:53:20 --> Database Driver Class Initialized
DEBUG - 2022-03-09 22:53:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 22:53:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 22:53:20 --> Controller Class Initialized
INFO - 2022-03-09 22:53:20 --> Form Validation Class Initialized
DEBUG - 2022-03-09 22:53:20 --> Encrypt Class Initialized
DEBUG - 2022-03-09 22:53:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-09 22:53:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-09 22:53:20 --> Email Class Initialized
INFO - 2022-03-09 22:53:20 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-09 22:53:20 --> Calendar Class Initialized
INFO - 2022-03-09 22:53:20 --> Model "Login_model" initialized
INFO - 2022-03-09 22:53:20 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-03-09 22:53:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 22:53:20 --> Config Class Initialized
INFO - 2022-03-09 22:53:20 --> Hooks Class Initialized
DEBUG - 2022-03-09 22:53:20 --> UTF-8 Support Enabled
INFO - 2022-03-09 22:53:20 --> Utf8 Class Initialized
INFO - 2022-03-09 22:53:20 --> URI Class Initialized
INFO - 2022-03-09 22:53:20 --> Router Class Initialized
INFO - 2022-03-09 22:53:20 --> Output Class Initialized
INFO - 2022-03-09 22:53:20 --> Security Class Initialized
DEBUG - 2022-03-09 22:53:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 22:53:20 --> Input Class Initialized
INFO - 2022-03-09 22:53:20 --> Language Class Initialized
INFO - 2022-03-09 22:53:20 --> Loader Class Initialized
INFO - 2022-03-09 22:53:20 --> Helper loaded: url_helper
INFO - 2022-03-09 22:53:20 --> Helper loaded: form_helper
INFO - 2022-03-09 22:53:20 --> Helper loaded: common_helper
INFO - 2022-03-09 22:53:20 --> Database Driver Class Initialized
DEBUG - 2022-03-09 22:53:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 22:53:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 22:53:21 --> Controller Class Initialized
INFO - 2022-03-09 22:53:21 --> Form Validation Class Initialized
DEBUG - 2022-03-09 22:53:21 --> Encrypt Class Initialized
INFO - 2022-03-09 22:53:21 --> Model "Login_model" initialized
INFO - 2022-03-09 22:53:21 --> Model "Dashboard_model" initialized
INFO - 2022-03-09 22:53:21 --> Model "Case_model" initialized
INFO - 2022-03-09 22:53:21 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 22:53:21 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2022-03-09 22:53:21 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 22:53:21 --> Final output sent to browser
DEBUG - 2022-03-09 22:53:21 --> Total execution time: 0.1295
ERROR - 2022-03-09 22:53:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 22:53:43 --> Config Class Initialized
INFO - 2022-03-09 22:53:43 --> Hooks Class Initialized
DEBUG - 2022-03-09 22:53:43 --> UTF-8 Support Enabled
INFO - 2022-03-09 22:53:43 --> Utf8 Class Initialized
INFO - 2022-03-09 22:53:43 --> URI Class Initialized
INFO - 2022-03-09 22:53:43 --> Router Class Initialized
INFO - 2022-03-09 22:53:43 --> Output Class Initialized
INFO - 2022-03-09 22:53:43 --> Security Class Initialized
DEBUG - 2022-03-09 22:53:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 22:53:43 --> Input Class Initialized
INFO - 2022-03-09 22:53:43 --> Language Class Initialized
INFO - 2022-03-09 22:53:43 --> Loader Class Initialized
INFO - 2022-03-09 22:53:43 --> Helper loaded: url_helper
INFO - 2022-03-09 22:53:43 --> Helper loaded: form_helper
INFO - 2022-03-09 22:53:43 --> Helper loaded: common_helper
INFO - 2022-03-09 22:53:43 --> Database Driver Class Initialized
DEBUG - 2022-03-09 22:53:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 22:53:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 22:53:43 --> Controller Class Initialized
INFO - 2022-03-09 22:53:43 --> Form Validation Class Initialized
DEBUG - 2022-03-09 22:53:43 --> Encrypt Class Initialized
INFO - 2022-03-09 22:53:43 --> Model "Patient_model" initialized
INFO - 2022-03-09 22:53:43 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 22:53:43 --> Model "Referredby_model" initialized
INFO - 2022-03-09 22:53:43 --> Model "Prefix_master" initialized
INFO - 2022-03-09 22:53:43 --> Model "Hospital_model" initialized
INFO - 2022-03-09 22:53:43 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 22:53:43 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-09 22:53:43 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 22:53:43 --> Final output sent to browser
DEBUG - 2022-03-09 22:53:43 --> Total execution time: 0.0592
ERROR - 2022-03-09 22:55:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 22:55:48 --> Config Class Initialized
INFO - 2022-03-09 22:55:48 --> Hooks Class Initialized
DEBUG - 2022-03-09 22:55:48 --> UTF-8 Support Enabled
INFO - 2022-03-09 22:55:48 --> Utf8 Class Initialized
INFO - 2022-03-09 22:55:48 --> URI Class Initialized
INFO - 2022-03-09 22:55:48 --> Router Class Initialized
INFO - 2022-03-09 22:55:48 --> Output Class Initialized
INFO - 2022-03-09 22:55:48 --> Security Class Initialized
DEBUG - 2022-03-09 22:55:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 22:55:48 --> Input Class Initialized
INFO - 2022-03-09 22:55:48 --> Language Class Initialized
INFO - 2022-03-09 22:55:48 --> Loader Class Initialized
INFO - 2022-03-09 22:55:48 --> Helper loaded: url_helper
INFO - 2022-03-09 22:55:48 --> Helper loaded: form_helper
INFO - 2022-03-09 22:55:48 --> Helper loaded: common_helper
INFO - 2022-03-09 22:55:48 --> Database Driver Class Initialized
DEBUG - 2022-03-09 22:55:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 22:55:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 22:55:48 --> Controller Class Initialized
INFO - 2022-03-09 22:55:48 --> Form Validation Class Initialized
DEBUG - 2022-03-09 22:55:48 --> Encrypt Class Initialized
INFO - 2022-03-09 22:55:48 --> Model "Patient_model" initialized
INFO - 2022-03-09 22:55:48 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 22:55:48 --> Model "Prefix_master" initialized
INFO - 2022-03-09 22:55:48 --> Model "Users_model" initialized
INFO - 2022-03-09 22:55:48 --> Model "Hospital_model" initialized
INFO - 2022-03-09 22:55:48 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 22:55:48 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-09 22:55:48 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 22:55:48 --> Final output sent to browser
DEBUG - 2022-03-09 22:55:48 --> Total execution time: 0.0714
ERROR - 2022-03-09 22:55:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 22:55:53 --> Config Class Initialized
INFO - 2022-03-09 22:55:53 --> Hooks Class Initialized
DEBUG - 2022-03-09 22:55:53 --> UTF-8 Support Enabled
INFO - 2022-03-09 22:55:53 --> Utf8 Class Initialized
INFO - 2022-03-09 22:55:53 --> URI Class Initialized
INFO - 2022-03-09 22:55:53 --> Router Class Initialized
INFO - 2022-03-09 22:55:53 --> Output Class Initialized
INFO - 2022-03-09 22:55:53 --> Security Class Initialized
DEBUG - 2022-03-09 22:55:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 22:55:53 --> Input Class Initialized
INFO - 2022-03-09 22:55:53 --> Language Class Initialized
INFO - 2022-03-09 22:55:53 --> Loader Class Initialized
INFO - 2022-03-09 22:55:53 --> Helper loaded: url_helper
INFO - 2022-03-09 22:55:53 --> Helper loaded: form_helper
INFO - 2022-03-09 22:55:53 --> Helper loaded: common_helper
INFO - 2022-03-09 22:55:53 --> Database Driver Class Initialized
DEBUG - 2022-03-09 22:55:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 22:55:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 22:55:53 --> Controller Class Initialized
INFO - 2022-03-09 22:55:53 --> Form Validation Class Initialized
DEBUG - 2022-03-09 22:55:53 --> Encrypt Class Initialized
INFO - 2022-03-09 22:55:53 --> Model "Patient_model" initialized
INFO - 2022-03-09 22:55:53 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 22:55:53 --> Model "Referredby_model" initialized
INFO - 2022-03-09 22:55:53 --> Model "Prefix_master" initialized
INFO - 2022-03-09 22:55:53 --> Model "Hospital_model" initialized
INFO - 2022-03-09 22:55:53 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 22:55:53 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-09 22:55:53 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 22:55:53 --> Final output sent to browser
DEBUG - 2022-03-09 22:55:53 --> Total execution time: 0.0576
ERROR - 2022-03-09 22:56:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 22:56:49 --> Config Class Initialized
INFO - 2022-03-09 22:56:49 --> Hooks Class Initialized
DEBUG - 2022-03-09 22:56:49 --> UTF-8 Support Enabled
INFO - 2022-03-09 22:56:49 --> Utf8 Class Initialized
INFO - 2022-03-09 22:56:49 --> URI Class Initialized
INFO - 2022-03-09 22:56:49 --> Router Class Initialized
INFO - 2022-03-09 22:56:49 --> Output Class Initialized
INFO - 2022-03-09 22:56:49 --> Security Class Initialized
DEBUG - 2022-03-09 22:56:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 22:56:49 --> Input Class Initialized
INFO - 2022-03-09 22:56:49 --> Language Class Initialized
INFO - 2022-03-09 22:56:49 --> Loader Class Initialized
INFO - 2022-03-09 22:56:49 --> Helper loaded: url_helper
INFO - 2022-03-09 22:56:49 --> Helper loaded: form_helper
INFO - 2022-03-09 22:56:49 --> Helper loaded: common_helper
INFO - 2022-03-09 22:56:49 --> Database Driver Class Initialized
DEBUG - 2022-03-09 22:56:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 22:56:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 22:56:49 --> Controller Class Initialized
INFO - 2022-03-09 22:56:49 --> Form Validation Class Initialized
DEBUG - 2022-03-09 22:56:49 --> Encrypt Class Initialized
INFO - 2022-03-09 22:56:49 --> Model "Patient_model" initialized
INFO - 2022-03-09 22:56:49 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 22:56:49 --> Model "Prefix_master" initialized
INFO - 2022-03-09 22:56:49 --> Model "Users_model" initialized
INFO - 2022-03-09 22:56:49 --> Model "Hospital_model" initialized
INFO - 2022-03-09 22:56:49 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 22:56:49 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-09 22:56:49 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 22:56:49 --> Final output sent to browser
DEBUG - 2022-03-09 22:56:49 --> Total execution time: 0.0757
ERROR - 2022-03-09 22:57:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 22:57:58 --> Config Class Initialized
INFO - 2022-03-09 22:57:58 --> Hooks Class Initialized
DEBUG - 2022-03-09 22:57:58 --> UTF-8 Support Enabled
INFO - 2022-03-09 22:57:58 --> Utf8 Class Initialized
INFO - 2022-03-09 22:57:58 --> URI Class Initialized
INFO - 2022-03-09 22:57:58 --> Router Class Initialized
INFO - 2022-03-09 22:57:58 --> Output Class Initialized
INFO - 2022-03-09 22:57:58 --> Security Class Initialized
DEBUG - 2022-03-09 22:57:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 22:57:58 --> Input Class Initialized
INFO - 2022-03-09 22:57:58 --> Language Class Initialized
INFO - 2022-03-09 22:57:58 --> Loader Class Initialized
INFO - 2022-03-09 22:57:58 --> Helper loaded: url_helper
INFO - 2022-03-09 22:57:58 --> Helper loaded: form_helper
INFO - 2022-03-09 22:57:58 --> Helper loaded: common_helper
INFO - 2022-03-09 22:57:58 --> Database Driver Class Initialized
DEBUG - 2022-03-09 22:57:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 22:57:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 22:57:58 --> Controller Class Initialized
INFO - 2022-03-09 22:57:58 --> Form Validation Class Initialized
DEBUG - 2022-03-09 22:57:58 --> Encrypt Class Initialized
INFO - 2022-03-09 22:57:58 --> Model "Patient_model" initialized
INFO - 2022-03-09 22:57:58 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 22:57:58 --> Model "Prefix_master" initialized
INFO - 2022-03-09 22:57:58 --> Model "Users_model" initialized
INFO - 2022-03-09 22:57:58 --> Model "Hospital_model" initialized
INFO - 2022-03-09 22:57:58 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 22:57:58 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-09 22:57:58 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 22:57:58 --> Final output sent to browser
DEBUG - 2022-03-09 22:57:58 --> Total execution time: 0.0696
ERROR - 2022-03-09 22:58:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 22:58:06 --> Config Class Initialized
INFO - 2022-03-09 22:58:06 --> Hooks Class Initialized
DEBUG - 2022-03-09 22:58:06 --> UTF-8 Support Enabled
INFO - 2022-03-09 22:58:06 --> Utf8 Class Initialized
INFO - 2022-03-09 22:58:06 --> URI Class Initialized
INFO - 2022-03-09 22:58:06 --> Router Class Initialized
INFO - 2022-03-09 22:58:06 --> Output Class Initialized
INFO - 2022-03-09 22:58:06 --> Security Class Initialized
DEBUG - 2022-03-09 22:58:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 22:58:06 --> Input Class Initialized
INFO - 2022-03-09 22:58:06 --> Language Class Initialized
INFO - 2022-03-09 22:58:06 --> Loader Class Initialized
INFO - 2022-03-09 22:58:06 --> Helper loaded: url_helper
INFO - 2022-03-09 22:58:06 --> Helper loaded: form_helper
INFO - 2022-03-09 22:58:06 --> Helper loaded: common_helper
INFO - 2022-03-09 22:58:06 --> Database Driver Class Initialized
DEBUG - 2022-03-09 22:58:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 22:58:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 22:58:06 --> Controller Class Initialized
INFO - 2022-03-09 22:58:06 --> Form Validation Class Initialized
DEBUG - 2022-03-09 22:58:06 --> Encrypt Class Initialized
INFO - 2022-03-09 22:58:06 --> Model "Patient_model" initialized
INFO - 2022-03-09 22:58:06 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 22:58:06 --> Model "Referredby_model" initialized
INFO - 2022-03-09 22:58:06 --> Model "Prefix_master" initialized
INFO - 2022-03-09 22:58:06 --> Model "Hospital_model" initialized
INFO - 2022-03-09 22:58:06 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 22:58:06 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-09 22:58:06 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 22:58:06 --> Final output sent to browser
DEBUG - 2022-03-09 22:58:06 --> Total execution time: 0.0514
ERROR - 2022-03-09 22:58:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 22:58:53 --> Config Class Initialized
INFO - 2022-03-09 22:58:53 --> Hooks Class Initialized
DEBUG - 2022-03-09 22:58:53 --> UTF-8 Support Enabled
INFO - 2022-03-09 22:58:53 --> Utf8 Class Initialized
INFO - 2022-03-09 22:58:53 --> URI Class Initialized
INFO - 2022-03-09 22:58:53 --> Router Class Initialized
INFO - 2022-03-09 22:58:53 --> Output Class Initialized
INFO - 2022-03-09 22:58:53 --> Security Class Initialized
DEBUG - 2022-03-09 22:58:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 22:58:53 --> Input Class Initialized
INFO - 2022-03-09 22:58:53 --> Language Class Initialized
INFO - 2022-03-09 22:58:53 --> Loader Class Initialized
INFO - 2022-03-09 22:58:53 --> Helper loaded: url_helper
INFO - 2022-03-09 22:58:53 --> Helper loaded: form_helper
INFO - 2022-03-09 22:58:53 --> Helper loaded: common_helper
INFO - 2022-03-09 22:58:53 --> Database Driver Class Initialized
DEBUG - 2022-03-09 22:58:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 22:58:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 22:58:53 --> Controller Class Initialized
INFO - 2022-03-09 22:58:53 --> Form Validation Class Initialized
DEBUG - 2022-03-09 22:58:53 --> Encrypt Class Initialized
INFO - 2022-03-09 22:58:53 --> Model "Patient_model" initialized
INFO - 2022-03-09 22:58:53 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 22:58:53 --> Model "Prefix_master" initialized
INFO - 2022-03-09 22:58:53 --> Model "Users_model" initialized
INFO - 2022-03-09 22:58:53 --> Model "Hospital_model" initialized
INFO - 2022-03-09 22:58:54 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 22:58:54 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-09 22:58:54 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 22:58:54 --> Final output sent to browser
DEBUG - 2022-03-09 22:58:54 --> Total execution time: 0.0693
ERROR - 2022-03-09 22:59:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 22:59:03 --> Config Class Initialized
INFO - 2022-03-09 22:59:03 --> Hooks Class Initialized
DEBUG - 2022-03-09 22:59:03 --> UTF-8 Support Enabled
INFO - 2022-03-09 22:59:03 --> Utf8 Class Initialized
INFO - 2022-03-09 22:59:03 --> URI Class Initialized
INFO - 2022-03-09 22:59:03 --> Router Class Initialized
INFO - 2022-03-09 22:59:03 --> Output Class Initialized
INFO - 2022-03-09 22:59:03 --> Security Class Initialized
DEBUG - 2022-03-09 22:59:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 22:59:03 --> Input Class Initialized
INFO - 2022-03-09 22:59:03 --> Language Class Initialized
INFO - 2022-03-09 22:59:03 --> Loader Class Initialized
INFO - 2022-03-09 22:59:03 --> Helper loaded: url_helper
INFO - 2022-03-09 22:59:03 --> Helper loaded: form_helper
INFO - 2022-03-09 22:59:03 --> Helper loaded: common_helper
INFO - 2022-03-09 22:59:03 --> Database Driver Class Initialized
DEBUG - 2022-03-09 22:59:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 22:59:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 22:59:03 --> Controller Class Initialized
INFO - 2022-03-09 22:59:03 --> Form Validation Class Initialized
DEBUG - 2022-03-09 22:59:03 --> Encrypt Class Initialized
INFO - 2022-03-09 22:59:03 --> Model "Patient_model" initialized
INFO - 2022-03-09 22:59:03 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 22:59:03 --> Model "Referredby_model" initialized
INFO - 2022-03-09 22:59:03 --> Model "Prefix_master" initialized
INFO - 2022-03-09 22:59:03 --> Model "Hospital_model" initialized
INFO - 2022-03-09 22:59:03 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 22:59:03 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-09 22:59:03 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 22:59:03 --> Final output sent to browser
DEBUG - 2022-03-09 22:59:03 --> Total execution time: 0.0569
ERROR - 2022-03-09 22:59:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 22:59:33 --> Config Class Initialized
INFO - 2022-03-09 22:59:33 --> Hooks Class Initialized
DEBUG - 2022-03-09 22:59:33 --> UTF-8 Support Enabled
INFO - 2022-03-09 22:59:33 --> Utf8 Class Initialized
INFO - 2022-03-09 22:59:33 --> URI Class Initialized
INFO - 2022-03-09 22:59:33 --> Router Class Initialized
INFO - 2022-03-09 22:59:33 --> Output Class Initialized
INFO - 2022-03-09 22:59:33 --> Security Class Initialized
DEBUG - 2022-03-09 22:59:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 22:59:33 --> Input Class Initialized
INFO - 2022-03-09 22:59:33 --> Language Class Initialized
INFO - 2022-03-09 22:59:33 --> Loader Class Initialized
INFO - 2022-03-09 22:59:33 --> Helper loaded: url_helper
INFO - 2022-03-09 22:59:33 --> Helper loaded: form_helper
INFO - 2022-03-09 22:59:33 --> Helper loaded: common_helper
INFO - 2022-03-09 22:59:33 --> Database Driver Class Initialized
DEBUG - 2022-03-09 22:59:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 22:59:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 22:59:33 --> Controller Class Initialized
INFO - 2022-03-09 22:59:33 --> Form Validation Class Initialized
DEBUG - 2022-03-09 22:59:33 --> Encrypt Class Initialized
INFO - 2022-03-09 22:59:33 --> Model "Patient_model" initialized
INFO - 2022-03-09 22:59:33 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 22:59:33 --> Model "Referredby_model" initialized
INFO - 2022-03-09 22:59:33 --> Model "Prefix_master" initialized
INFO - 2022-03-09 22:59:33 --> Model "Hospital_model" initialized
ERROR - 2022-03-09 22:59:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 22:59:34 --> Config Class Initialized
INFO - 2022-03-09 22:59:34 --> Hooks Class Initialized
DEBUG - 2022-03-09 22:59:34 --> UTF-8 Support Enabled
INFO - 2022-03-09 22:59:34 --> Utf8 Class Initialized
INFO - 2022-03-09 22:59:34 --> URI Class Initialized
INFO - 2022-03-09 22:59:34 --> Router Class Initialized
INFO - 2022-03-09 22:59:34 --> Output Class Initialized
INFO - 2022-03-09 22:59:34 --> Security Class Initialized
DEBUG - 2022-03-09 22:59:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 22:59:34 --> Input Class Initialized
INFO - 2022-03-09 22:59:34 --> Language Class Initialized
INFO - 2022-03-09 22:59:34 --> Loader Class Initialized
INFO - 2022-03-09 22:59:34 --> Helper loaded: url_helper
INFO - 2022-03-09 22:59:34 --> Helper loaded: form_helper
INFO - 2022-03-09 22:59:34 --> Helper loaded: common_helper
INFO - 2022-03-09 22:59:34 --> Database Driver Class Initialized
DEBUG - 2022-03-09 22:59:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 22:59:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 22:59:34 --> Controller Class Initialized
INFO - 2022-03-09 22:59:34 --> Form Validation Class Initialized
DEBUG - 2022-03-09 22:59:34 --> Encrypt Class Initialized
INFO - 2022-03-09 22:59:34 --> Model "Patient_model" initialized
INFO - 2022-03-09 22:59:34 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 22:59:34 --> Model "Referredby_model" initialized
INFO - 2022-03-09 22:59:34 --> Model "Prefix_master" initialized
INFO - 2022-03-09 22:59:34 --> Model "Hospital_model" initialized
INFO - 2022-03-09 22:59:34 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 22:59:34 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-09 22:59:34 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 22:59:34 --> Final output sent to browser
DEBUG - 2022-03-09 22:59:34 --> Total execution time: 0.0531
ERROR - 2022-03-09 22:59:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 22:59:35 --> Config Class Initialized
INFO - 2022-03-09 22:59:35 --> Hooks Class Initialized
DEBUG - 2022-03-09 22:59:35 --> UTF-8 Support Enabled
INFO - 2022-03-09 22:59:35 --> Utf8 Class Initialized
INFO - 2022-03-09 22:59:35 --> URI Class Initialized
INFO - 2022-03-09 22:59:35 --> Router Class Initialized
INFO - 2022-03-09 22:59:35 --> Output Class Initialized
INFO - 2022-03-09 22:59:35 --> Security Class Initialized
DEBUG - 2022-03-09 22:59:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 22:59:35 --> Input Class Initialized
INFO - 2022-03-09 22:59:35 --> Language Class Initialized
INFO - 2022-03-09 22:59:35 --> Loader Class Initialized
INFO - 2022-03-09 22:59:35 --> Helper loaded: url_helper
INFO - 2022-03-09 22:59:35 --> Helper loaded: form_helper
INFO - 2022-03-09 22:59:35 --> Helper loaded: common_helper
INFO - 2022-03-09 22:59:35 --> Database Driver Class Initialized
DEBUG - 2022-03-09 22:59:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 22:59:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 22:59:35 --> Controller Class Initialized
INFO - 2022-03-09 22:59:35 --> Form Validation Class Initialized
DEBUG - 2022-03-09 22:59:35 --> Encrypt Class Initialized
INFO - 2022-03-09 22:59:35 --> Model "Patient_model" initialized
INFO - 2022-03-09 22:59:35 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 22:59:35 --> Model "Prefix_master" initialized
INFO - 2022-03-09 22:59:35 --> Model "Users_model" initialized
INFO - 2022-03-09 22:59:35 --> Model "Hospital_model" initialized
INFO - 2022-03-09 22:59:35 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 22:59:35 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-09 22:59:35 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 22:59:35 --> Final output sent to browser
DEBUG - 2022-03-09 22:59:35 --> Total execution time: 0.0605
ERROR - 2022-03-09 23:01:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 23:01:36 --> Config Class Initialized
INFO - 2022-03-09 23:01:36 --> Hooks Class Initialized
DEBUG - 2022-03-09 23:01:36 --> UTF-8 Support Enabled
INFO - 2022-03-09 23:01:36 --> Utf8 Class Initialized
INFO - 2022-03-09 23:01:36 --> URI Class Initialized
INFO - 2022-03-09 23:01:36 --> Router Class Initialized
INFO - 2022-03-09 23:01:36 --> Output Class Initialized
INFO - 2022-03-09 23:01:36 --> Security Class Initialized
DEBUG - 2022-03-09 23:01:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 23:01:36 --> Input Class Initialized
INFO - 2022-03-09 23:01:36 --> Language Class Initialized
INFO - 2022-03-09 23:01:36 --> Loader Class Initialized
INFO - 2022-03-09 23:01:36 --> Helper loaded: url_helper
INFO - 2022-03-09 23:01:36 --> Helper loaded: form_helper
INFO - 2022-03-09 23:01:36 --> Helper loaded: common_helper
INFO - 2022-03-09 23:01:36 --> Database Driver Class Initialized
DEBUG - 2022-03-09 23:01:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 23:01:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 23:01:36 --> Controller Class Initialized
INFO - 2022-03-09 23:01:36 --> Form Validation Class Initialized
DEBUG - 2022-03-09 23:01:36 --> Encrypt Class Initialized
INFO - 2022-03-09 23:01:36 --> Model "Patient_model" initialized
INFO - 2022-03-09 23:01:36 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 23:01:36 --> Model "Referredby_model" initialized
INFO - 2022-03-09 23:01:36 --> Model "Prefix_master" initialized
INFO - 2022-03-09 23:01:36 --> Model "Hospital_model" initialized
ERROR - 2022-03-09 23:01:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 23:01:37 --> Config Class Initialized
INFO - 2022-03-09 23:01:37 --> Hooks Class Initialized
DEBUG - 2022-03-09 23:01:37 --> UTF-8 Support Enabled
INFO - 2022-03-09 23:01:37 --> Utf8 Class Initialized
INFO - 2022-03-09 23:01:37 --> URI Class Initialized
INFO - 2022-03-09 23:01:37 --> Router Class Initialized
INFO - 2022-03-09 23:01:37 --> Output Class Initialized
INFO - 2022-03-09 23:01:37 --> Security Class Initialized
DEBUG - 2022-03-09 23:01:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 23:01:37 --> Input Class Initialized
INFO - 2022-03-09 23:01:37 --> Language Class Initialized
INFO - 2022-03-09 23:01:37 --> Loader Class Initialized
INFO - 2022-03-09 23:01:37 --> Helper loaded: url_helper
INFO - 2022-03-09 23:01:37 --> Helper loaded: form_helper
INFO - 2022-03-09 23:01:37 --> Helper loaded: common_helper
INFO - 2022-03-09 23:01:37 --> Database Driver Class Initialized
DEBUG - 2022-03-09 23:01:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 23:01:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 23:01:37 --> Controller Class Initialized
INFO - 2022-03-09 23:01:37 --> Form Validation Class Initialized
DEBUG - 2022-03-09 23:01:37 --> Encrypt Class Initialized
INFO - 2022-03-09 23:01:37 --> Model "Patient_model" initialized
INFO - 2022-03-09 23:01:37 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 23:01:37 --> Model "Referredby_model" initialized
INFO - 2022-03-09 23:01:37 --> Model "Prefix_master" initialized
INFO - 2022-03-09 23:01:37 --> Model "Hospital_model" initialized
INFO - 2022-03-09 23:01:37 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 23:01:37 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-09 23:01:37 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 23:01:37 --> Final output sent to browser
DEBUG - 2022-03-09 23:01:37 --> Total execution time: 0.0751
ERROR - 2022-03-09 23:01:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 23:01:38 --> Config Class Initialized
INFO - 2022-03-09 23:01:38 --> Hooks Class Initialized
DEBUG - 2022-03-09 23:01:38 --> UTF-8 Support Enabled
INFO - 2022-03-09 23:01:38 --> Utf8 Class Initialized
INFO - 2022-03-09 23:01:38 --> URI Class Initialized
INFO - 2022-03-09 23:01:38 --> Router Class Initialized
INFO - 2022-03-09 23:01:38 --> Output Class Initialized
INFO - 2022-03-09 23:01:38 --> Security Class Initialized
DEBUG - 2022-03-09 23:01:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 23:01:38 --> Input Class Initialized
INFO - 2022-03-09 23:01:38 --> Language Class Initialized
INFO - 2022-03-09 23:01:38 --> Loader Class Initialized
INFO - 2022-03-09 23:01:38 --> Helper loaded: url_helper
INFO - 2022-03-09 23:01:38 --> Helper loaded: form_helper
INFO - 2022-03-09 23:01:38 --> Helper loaded: common_helper
INFO - 2022-03-09 23:01:38 --> Database Driver Class Initialized
DEBUG - 2022-03-09 23:01:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 23:01:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 23:01:38 --> Controller Class Initialized
INFO - 2022-03-09 23:01:38 --> Form Validation Class Initialized
DEBUG - 2022-03-09 23:01:38 --> Encrypt Class Initialized
INFO - 2022-03-09 23:01:38 --> Model "Patient_model" initialized
INFO - 2022-03-09 23:01:38 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 23:01:38 --> Model "Prefix_master" initialized
INFO - 2022-03-09 23:01:38 --> Model "Users_model" initialized
INFO - 2022-03-09 23:01:38 --> Model "Hospital_model" initialized
INFO - 2022-03-09 23:01:38 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 23:01:38 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-09 23:01:38 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 23:01:38 --> Final output sent to browser
DEBUG - 2022-03-09 23:01:38 --> Total execution time: 0.0729
ERROR - 2022-03-09 23:01:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 23:01:56 --> Config Class Initialized
INFO - 2022-03-09 23:01:56 --> Hooks Class Initialized
DEBUG - 2022-03-09 23:01:56 --> UTF-8 Support Enabled
INFO - 2022-03-09 23:01:56 --> Utf8 Class Initialized
INFO - 2022-03-09 23:01:56 --> URI Class Initialized
INFO - 2022-03-09 23:01:56 --> Router Class Initialized
INFO - 2022-03-09 23:01:56 --> Output Class Initialized
INFO - 2022-03-09 23:01:56 --> Security Class Initialized
DEBUG - 2022-03-09 23:01:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 23:01:56 --> Input Class Initialized
INFO - 2022-03-09 23:01:56 --> Language Class Initialized
INFO - 2022-03-09 23:01:56 --> Loader Class Initialized
INFO - 2022-03-09 23:01:56 --> Helper loaded: url_helper
INFO - 2022-03-09 23:01:56 --> Helper loaded: form_helper
INFO - 2022-03-09 23:01:56 --> Helper loaded: common_helper
INFO - 2022-03-09 23:01:56 --> Database Driver Class Initialized
DEBUG - 2022-03-09 23:01:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 23:01:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 23:01:56 --> Controller Class Initialized
INFO - 2022-03-09 23:01:56 --> Form Validation Class Initialized
DEBUG - 2022-03-09 23:01:56 --> Encrypt Class Initialized
INFO - 2022-03-09 23:01:56 --> Model "Patient_model" initialized
INFO - 2022-03-09 23:01:56 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 23:01:56 --> Model "Prefix_master" initialized
INFO - 2022-03-09 23:01:56 --> Model "Users_model" initialized
INFO - 2022-03-09 23:01:56 --> Model "Hospital_model" initialized
INFO - 2022-03-09 23:01:56 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 23:01:56 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-09 23:01:56 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 23:01:56 --> Final output sent to browser
DEBUG - 2022-03-09 23:01:56 --> Total execution time: 0.0647
ERROR - 2022-03-09 23:02:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 23:02:27 --> Config Class Initialized
INFO - 2022-03-09 23:02:27 --> Hooks Class Initialized
DEBUG - 2022-03-09 23:02:27 --> UTF-8 Support Enabled
INFO - 2022-03-09 23:02:27 --> Utf8 Class Initialized
INFO - 2022-03-09 23:02:27 --> URI Class Initialized
INFO - 2022-03-09 23:02:27 --> Router Class Initialized
INFO - 2022-03-09 23:02:27 --> Output Class Initialized
INFO - 2022-03-09 23:02:27 --> Security Class Initialized
DEBUG - 2022-03-09 23:02:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 23:02:27 --> Input Class Initialized
INFO - 2022-03-09 23:02:27 --> Language Class Initialized
INFO - 2022-03-09 23:02:27 --> Loader Class Initialized
INFO - 2022-03-09 23:02:27 --> Helper loaded: url_helper
INFO - 2022-03-09 23:02:27 --> Helper loaded: form_helper
INFO - 2022-03-09 23:02:27 --> Helper loaded: common_helper
INFO - 2022-03-09 23:02:27 --> Database Driver Class Initialized
DEBUG - 2022-03-09 23:02:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 23:02:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 23:02:27 --> Controller Class Initialized
INFO - 2022-03-09 23:02:27 --> Form Validation Class Initialized
DEBUG - 2022-03-09 23:02:27 --> Encrypt Class Initialized
INFO - 2022-03-09 23:02:27 --> Model "Patient_model" initialized
INFO - 2022-03-09 23:02:27 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 23:02:27 --> Model "Referredby_model" initialized
INFO - 2022-03-09 23:02:27 --> Model "Prefix_master" initialized
INFO - 2022-03-09 23:02:27 --> Model "Hospital_model" initialized
INFO - 2022-03-09 23:02:27 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 23:02:27 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-09 23:02:27 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 23:02:27 --> Final output sent to browser
DEBUG - 2022-03-09 23:02:27 --> Total execution time: 0.0458
ERROR - 2022-03-09 23:05:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 23:05:00 --> Config Class Initialized
INFO - 2022-03-09 23:05:00 --> Hooks Class Initialized
DEBUG - 2022-03-09 23:05:00 --> UTF-8 Support Enabled
INFO - 2022-03-09 23:05:00 --> Utf8 Class Initialized
INFO - 2022-03-09 23:05:00 --> URI Class Initialized
INFO - 2022-03-09 23:05:00 --> Router Class Initialized
INFO - 2022-03-09 23:05:00 --> Output Class Initialized
INFO - 2022-03-09 23:05:00 --> Security Class Initialized
DEBUG - 2022-03-09 23:05:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 23:05:00 --> Input Class Initialized
INFO - 2022-03-09 23:05:00 --> Language Class Initialized
INFO - 2022-03-09 23:05:00 --> Loader Class Initialized
INFO - 2022-03-09 23:05:00 --> Helper loaded: url_helper
INFO - 2022-03-09 23:05:00 --> Helper loaded: form_helper
INFO - 2022-03-09 23:05:00 --> Helper loaded: common_helper
INFO - 2022-03-09 23:05:00 --> Database Driver Class Initialized
DEBUG - 2022-03-09 23:05:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 23:05:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 23:05:00 --> Controller Class Initialized
INFO - 2022-03-09 23:05:00 --> Form Validation Class Initialized
DEBUG - 2022-03-09 23:05:00 --> Encrypt Class Initialized
INFO - 2022-03-09 23:05:00 --> Model "Patient_model" initialized
INFO - 2022-03-09 23:05:00 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 23:05:00 --> Model "Referredby_model" initialized
INFO - 2022-03-09 23:05:00 --> Model "Prefix_master" initialized
INFO - 2022-03-09 23:05:00 --> Model "Hospital_model" initialized
ERROR - 2022-03-09 23:05:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 23:05:01 --> Config Class Initialized
INFO - 2022-03-09 23:05:01 --> Hooks Class Initialized
DEBUG - 2022-03-09 23:05:01 --> UTF-8 Support Enabled
INFO - 2022-03-09 23:05:01 --> Utf8 Class Initialized
INFO - 2022-03-09 23:05:01 --> URI Class Initialized
INFO - 2022-03-09 23:05:01 --> Router Class Initialized
INFO - 2022-03-09 23:05:01 --> Output Class Initialized
INFO - 2022-03-09 23:05:01 --> Security Class Initialized
DEBUG - 2022-03-09 23:05:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 23:05:01 --> Input Class Initialized
INFO - 2022-03-09 23:05:01 --> Language Class Initialized
INFO - 2022-03-09 23:05:01 --> Loader Class Initialized
INFO - 2022-03-09 23:05:01 --> Helper loaded: url_helper
INFO - 2022-03-09 23:05:01 --> Helper loaded: form_helper
INFO - 2022-03-09 23:05:01 --> Helper loaded: common_helper
INFO - 2022-03-09 23:05:01 --> Database Driver Class Initialized
DEBUG - 2022-03-09 23:05:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 23:05:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 23:05:01 --> Controller Class Initialized
INFO - 2022-03-09 23:05:01 --> Form Validation Class Initialized
DEBUG - 2022-03-09 23:05:01 --> Encrypt Class Initialized
INFO - 2022-03-09 23:05:01 --> Model "Patient_model" initialized
INFO - 2022-03-09 23:05:01 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 23:05:01 --> Model "Referredby_model" initialized
INFO - 2022-03-09 23:05:01 --> Model "Prefix_master" initialized
INFO - 2022-03-09 23:05:01 --> Model "Hospital_model" initialized
INFO - 2022-03-09 23:05:01 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 23:05:01 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-09 23:05:01 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 23:05:01 --> Final output sent to browser
DEBUG - 2022-03-09 23:05:01 --> Total execution time: 0.0656
ERROR - 2022-03-09 23:05:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 23:05:02 --> Config Class Initialized
INFO - 2022-03-09 23:05:02 --> Hooks Class Initialized
DEBUG - 2022-03-09 23:05:02 --> UTF-8 Support Enabled
INFO - 2022-03-09 23:05:02 --> Utf8 Class Initialized
INFO - 2022-03-09 23:05:02 --> URI Class Initialized
INFO - 2022-03-09 23:05:02 --> Router Class Initialized
INFO - 2022-03-09 23:05:02 --> Output Class Initialized
INFO - 2022-03-09 23:05:02 --> Security Class Initialized
DEBUG - 2022-03-09 23:05:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 23:05:02 --> Input Class Initialized
INFO - 2022-03-09 23:05:02 --> Language Class Initialized
INFO - 2022-03-09 23:05:02 --> Loader Class Initialized
INFO - 2022-03-09 23:05:02 --> Helper loaded: url_helper
INFO - 2022-03-09 23:05:02 --> Helper loaded: form_helper
INFO - 2022-03-09 23:05:02 --> Helper loaded: common_helper
INFO - 2022-03-09 23:05:02 --> Database Driver Class Initialized
DEBUG - 2022-03-09 23:05:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 23:05:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 23:05:02 --> Controller Class Initialized
INFO - 2022-03-09 23:05:02 --> Form Validation Class Initialized
DEBUG - 2022-03-09 23:05:02 --> Encrypt Class Initialized
INFO - 2022-03-09 23:05:02 --> Model "Patient_model" initialized
INFO - 2022-03-09 23:05:02 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 23:05:02 --> Model "Prefix_master" initialized
INFO - 2022-03-09 23:05:02 --> Model "Users_model" initialized
INFO - 2022-03-09 23:05:02 --> Model "Hospital_model" initialized
INFO - 2022-03-09 23:05:02 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 23:05:02 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-09 23:05:02 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 23:05:02 --> Final output sent to browser
DEBUG - 2022-03-09 23:05:02 --> Total execution time: 0.0840
ERROR - 2022-03-09 23:08:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 23:08:00 --> Config Class Initialized
INFO - 2022-03-09 23:08:00 --> Hooks Class Initialized
DEBUG - 2022-03-09 23:08:00 --> UTF-8 Support Enabled
INFO - 2022-03-09 23:08:00 --> Utf8 Class Initialized
INFO - 2022-03-09 23:08:00 --> URI Class Initialized
INFO - 2022-03-09 23:08:00 --> Router Class Initialized
INFO - 2022-03-09 23:08:00 --> Output Class Initialized
INFO - 2022-03-09 23:08:00 --> Security Class Initialized
DEBUG - 2022-03-09 23:08:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 23:08:00 --> Input Class Initialized
INFO - 2022-03-09 23:08:00 --> Language Class Initialized
INFO - 2022-03-09 23:08:00 --> Loader Class Initialized
INFO - 2022-03-09 23:08:00 --> Helper loaded: url_helper
INFO - 2022-03-09 23:08:00 --> Helper loaded: form_helper
INFO - 2022-03-09 23:08:00 --> Helper loaded: common_helper
INFO - 2022-03-09 23:08:00 --> Database Driver Class Initialized
DEBUG - 2022-03-09 23:08:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 23:08:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 23:08:00 --> Controller Class Initialized
INFO - 2022-03-09 23:08:00 --> Form Validation Class Initialized
DEBUG - 2022-03-09 23:08:00 --> Encrypt Class Initialized
INFO - 2022-03-09 23:08:00 --> Model "Patient_model" initialized
INFO - 2022-03-09 23:08:00 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 23:08:00 --> Model "Prefix_master" initialized
INFO - 2022-03-09 23:08:00 --> Model "Users_model" initialized
INFO - 2022-03-09 23:08:00 --> Model "Hospital_model" initialized
INFO - 2022-03-09 23:08:00 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 23:08:00 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-09 23:08:00 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 23:08:00 --> Final output sent to browser
DEBUG - 2022-03-09 23:08:00 --> Total execution time: 0.0671
ERROR - 2022-03-09 23:08:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 23:08:04 --> Config Class Initialized
INFO - 2022-03-09 23:08:04 --> Hooks Class Initialized
DEBUG - 2022-03-09 23:08:04 --> UTF-8 Support Enabled
INFO - 2022-03-09 23:08:04 --> Utf8 Class Initialized
INFO - 2022-03-09 23:08:04 --> URI Class Initialized
INFO - 2022-03-09 23:08:04 --> Router Class Initialized
INFO - 2022-03-09 23:08:04 --> Output Class Initialized
INFO - 2022-03-09 23:08:04 --> Security Class Initialized
DEBUG - 2022-03-09 23:08:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 23:08:04 --> Input Class Initialized
INFO - 2022-03-09 23:08:04 --> Language Class Initialized
INFO - 2022-03-09 23:08:04 --> Loader Class Initialized
INFO - 2022-03-09 23:08:04 --> Helper loaded: url_helper
INFO - 2022-03-09 23:08:04 --> Helper loaded: form_helper
INFO - 2022-03-09 23:08:04 --> Helper loaded: common_helper
INFO - 2022-03-09 23:08:04 --> Database Driver Class Initialized
DEBUG - 2022-03-09 23:08:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 23:08:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 23:08:04 --> Controller Class Initialized
INFO - 2022-03-09 23:08:04 --> Form Validation Class Initialized
DEBUG - 2022-03-09 23:08:04 --> Encrypt Class Initialized
INFO - 2022-03-09 23:08:04 --> Model "Patient_model" initialized
INFO - 2022-03-09 23:08:04 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 23:08:04 --> Model "Referredby_model" initialized
INFO - 2022-03-09 23:08:04 --> Model "Prefix_master" initialized
INFO - 2022-03-09 23:08:04 --> Model "Hospital_model" initialized
INFO - 2022-03-09 23:08:04 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 23:08:04 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-09 23:08:04 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 23:08:04 --> Final output sent to browser
DEBUG - 2022-03-09 23:08:04 --> Total execution time: 0.0466
ERROR - 2022-03-09 23:08:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 23:08:17 --> Config Class Initialized
INFO - 2022-03-09 23:08:17 --> Hooks Class Initialized
DEBUG - 2022-03-09 23:08:17 --> UTF-8 Support Enabled
INFO - 2022-03-09 23:08:17 --> Utf8 Class Initialized
INFO - 2022-03-09 23:08:17 --> URI Class Initialized
INFO - 2022-03-09 23:08:17 --> Router Class Initialized
INFO - 2022-03-09 23:08:17 --> Output Class Initialized
INFO - 2022-03-09 23:08:17 --> Security Class Initialized
DEBUG - 2022-03-09 23:08:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 23:08:17 --> Input Class Initialized
INFO - 2022-03-09 23:08:17 --> Language Class Initialized
INFO - 2022-03-09 23:08:17 --> Loader Class Initialized
INFO - 2022-03-09 23:08:17 --> Helper loaded: url_helper
INFO - 2022-03-09 23:08:17 --> Helper loaded: form_helper
INFO - 2022-03-09 23:08:17 --> Helper loaded: common_helper
INFO - 2022-03-09 23:08:17 --> Database Driver Class Initialized
DEBUG - 2022-03-09 23:08:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 23:08:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 23:08:17 --> Controller Class Initialized
INFO - 2022-03-09 23:08:17 --> Form Validation Class Initialized
DEBUG - 2022-03-09 23:08:17 --> Encrypt Class Initialized
INFO - 2022-03-09 23:08:17 --> Model "Patient_model" initialized
INFO - 2022-03-09 23:08:17 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 23:08:17 --> Model "Referredby_model" initialized
INFO - 2022-03-09 23:08:17 --> Model "Prefix_master" initialized
INFO - 2022-03-09 23:08:17 --> Model "Hospital_model" initialized
ERROR - 2022-03-09 23:08:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 23:08:17 --> Config Class Initialized
INFO - 2022-03-09 23:08:17 --> Hooks Class Initialized
DEBUG - 2022-03-09 23:08:17 --> UTF-8 Support Enabled
INFO - 2022-03-09 23:08:17 --> Utf8 Class Initialized
INFO - 2022-03-09 23:08:17 --> URI Class Initialized
INFO - 2022-03-09 23:08:17 --> Router Class Initialized
INFO - 2022-03-09 23:08:17 --> Output Class Initialized
INFO - 2022-03-09 23:08:17 --> Security Class Initialized
DEBUG - 2022-03-09 23:08:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 23:08:17 --> Input Class Initialized
INFO - 2022-03-09 23:08:17 --> Language Class Initialized
INFO - 2022-03-09 23:08:17 --> Loader Class Initialized
INFO - 2022-03-09 23:08:17 --> Helper loaded: url_helper
INFO - 2022-03-09 23:08:17 --> Helper loaded: form_helper
INFO - 2022-03-09 23:08:17 --> Helper loaded: common_helper
INFO - 2022-03-09 23:08:17 --> Database Driver Class Initialized
DEBUG - 2022-03-09 23:08:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 23:08:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 23:08:17 --> Controller Class Initialized
INFO - 2022-03-09 23:08:17 --> Form Validation Class Initialized
DEBUG - 2022-03-09 23:08:17 --> Encrypt Class Initialized
INFO - 2022-03-09 23:08:17 --> Model "Patient_model" initialized
INFO - 2022-03-09 23:08:17 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 23:08:17 --> Model "Referredby_model" initialized
INFO - 2022-03-09 23:08:17 --> Model "Prefix_master" initialized
INFO - 2022-03-09 23:08:17 --> Model "Hospital_model" initialized
INFO - 2022-03-09 23:08:17 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 23:08:17 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-09 23:08:17 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 23:08:17 --> Final output sent to browser
DEBUG - 2022-03-09 23:08:17 --> Total execution time: 0.0522
ERROR - 2022-03-09 23:08:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 23:08:18 --> Config Class Initialized
INFO - 2022-03-09 23:08:18 --> Hooks Class Initialized
DEBUG - 2022-03-09 23:08:18 --> UTF-8 Support Enabled
INFO - 2022-03-09 23:08:18 --> Utf8 Class Initialized
INFO - 2022-03-09 23:08:18 --> URI Class Initialized
INFO - 2022-03-09 23:08:18 --> Router Class Initialized
INFO - 2022-03-09 23:08:18 --> Output Class Initialized
INFO - 2022-03-09 23:08:18 --> Security Class Initialized
DEBUG - 2022-03-09 23:08:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 23:08:18 --> Input Class Initialized
INFO - 2022-03-09 23:08:18 --> Language Class Initialized
INFO - 2022-03-09 23:08:18 --> Loader Class Initialized
INFO - 2022-03-09 23:08:18 --> Helper loaded: url_helper
INFO - 2022-03-09 23:08:18 --> Helper loaded: form_helper
INFO - 2022-03-09 23:08:18 --> Helper loaded: common_helper
INFO - 2022-03-09 23:08:18 --> Database Driver Class Initialized
DEBUG - 2022-03-09 23:08:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 23:08:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 23:08:18 --> Controller Class Initialized
INFO - 2022-03-09 23:08:18 --> Form Validation Class Initialized
DEBUG - 2022-03-09 23:08:18 --> Encrypt Class Initialized
INFO - 2022-03-09 23:08:18 --> Model "Patient_model" initialized
INFO - 2022-03-09 23:08:18 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 23:08:18 --> Model "Prefix_master" initialized
INFO - 2022-03-09 23:08:18 --> Model "Users_model" initialized
INFO - 2022-03-09 23:08:18 --> Model "Hospital_model" initialized
INFO - 2022-03-09 23:08:18 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 23:08:18 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-09 23:08:18 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 23:08:18 --> Final output sent to browser
DEBUG - 2022-03-09 23:08:18 --> Total execution time: 0.0611
ERROR - 2022-03-09 23:19:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 23:19:40 --> Config Class Initialized
INFO - 2022-03-09 23:19:40 --> Hooks Class Initialized
DEBUG - 2022-03-09 23:19:40 --> UTF-8 Support Enabled
INFO - 2022-03-09 23:19:40 --> Utf8 Class Initialized
INFO - 2022-03-09 23:19:40 --> URI Class Initialized
INFO - 2022-03-09 23:19:40 --> Router Class Initialized
INFO - 2022-03-09 23:19:40 --> Output Class Initialized
INFO - 2022-03-09 23:19:40 --> Security Class Initialized
DEBUG - 2022-03-09 23:19:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 23:19:40 --> Input Class Initialized
INFO - 2022-03-09 23:19:40 --> Language Class Initialized
INFO - 2022-03-09 23:19:40 --> Loader Class Initialized
INFO - 2022-03-09 23:19:40 --> Helper loaded: url_helper
INFO - 2022-03-09 23:19:40 --> Helper loaded: form_helper
INFO - 2022-03-09 23:19:40 --> Helper loaded: common_helper
INFO - 2022-03-09 23:19:40 --> Database Driver Class Initialized
DEBUG - 2022-03-09 23:19:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 23:19:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 23:19:40 --> Controller Class Initialized
INFO - 2022-03-09 23:19:40 --> Form Validation Class Initialized
DEBUG - 2022-03-09 23:19:40 --> Encrypt Class Initialized
INFO - 2022-03-09 23:19:40 --> Model "Patient_model" initialized
INFO - 2022-03-09 23:19:40 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 23:19:40 --> Model "Prefix_master" initialized
INFO - 2022-03-09 23:19:40 --> Model "Users_model" initialized
INFO - 2022-03-09 23:19:40 --> Model "Hospital_model" initialized
ERROR - 2022-03-09 23:19:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 23:19:41 --> Config Class Initialized
INFO - 2022-03-09 23:19:41 --> Hooks Class Initialized
DEBUG - 2022-03-09 23:19:41 --> UTF-8 Support Enabled
INFO - 2022-03-09 23:19:41 --> Utf8 Class Initialized
INFO - 2022-03-09 23:19:41 --> URI Class Initialized
INFO - 2022-03-09 23:19:41 --> Router Class Initialized
INFO - 2022-03-09 23:19:41 --> Output Class Initialized
INFO - 2022-03-09 23:19:41 --> Security Class Initialized
DEBUG - 2022-03-09 23:19:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 23:19:41 --> Input Class Initialized
INFO - 2022-03-09 23:19:41 --> Language Class Initialized
INFO - 2022-03-09 23:19:41 --> Loader Class Initialized
INFO - 2022-03-09 23:19:41 --> Helper loaded: url_helper
INFO - 2022-03-09 23:19:41 --> Helper loaded: form_helper
INFO - 2022-03-09 23:19:41 --> Helper loaded: common_helper
INFO - 2022-03-09 23:19:41 --> Database Driver Class Initialized
DEBUG - 2022-03-09 23:19:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 23:19:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 23:19:41 --> Controller Class Initialized
INFO - 2022-03-09 23:19:41 --> Form Validation Class Initialized
DEBUG - 2022-03-09 23:19:41 --> Encrypt Class Initialized
INFO - 2022-03-09 23:19:41 --> Model "Patient_model" initialized
INFO - 2022-03-09 23:19:41 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 23:19:41 --> Model "Prefix_master" initialized
INFO - 2022-03-09 23:19:41 --> Model "Users_model" initialized
INFO - 2022-03-09 23:19:41 --> Model "Hospital_model" initialized
INFO - 2022-03-09 23:19:41 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 23:19:41 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-09 23:19:41 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 23:19:41 --> Final output sent to browser
DEBUG - 2022-03-09 23:19:41 --> Total execution time: 0.0646
ERROR - 2022-03-09 23:19:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 23:19:45 --> Config Class Initialized
INFO - 2022-03-09 23:19:45 --> Hooks Class Initialized
DEBUG - 2022-03-09 23:19:45 --> UTF-8 Support Enabled
INFO - 2022-03-09 23:19:45 --> Utf8 Class Initialized
INFO - 2022-03-09 23:19:45 --> URI Class Initialized
INFO - 2022-03-09 23:19:45 --> Router Class Initialized
INFO - 2022-03-09 23:19:45 --> Output Class Initialized
INFO - 2022-03-09 23:19:45 --> Security Class Initialized
DEBUG - 2022-03-09 23:19:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 23:19:45 --> Input Class Initialized
INFO - 2022-03-09 23:19:45 --> Language Class Initialized
INFO - 2022-03-09 23:19:45 --> Loader Class Initialized
INFO - 2022-03-09 23:19:45 --> Helper loaded: url_helper
INFO - 2022-03-09 23:19:45 --> Helper loaded: form_helper
INFO - 2022-03-09 23:19:45 --> Helper loaded: common_helper
INFO - 2022-03-09 23:19:45 --> Database Driver Class Initialized
DEBUG - 2022-03-09 23:19:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 23:19:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 23:19:45 --> Controller Class Initialized
INFO - 2022-03-09 23:19:45 --> Form Validation Class Initialized
DEBUG - 2022-03-09 23:19:45 --> Encrypt Class Initialized
INFO - 2022-03-09 23:19:45 --> Model "Patient_model" initialized
INFO - 2022-03-09 23:19:45 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 23:19:45 --> Model "Prefix_master" initialized
INFO - 2022-03-09 23:19:45 --> Model "Users_model" initialized
INFO - 2022-03-09 23:19:45 --> Model "Hospital_model" initialized
ERROR - 2022-03-09 23:19:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 23:19:46 --> Config Class Initialized
INFO - 2022-03-09 23:19:46 --> Hooks Class Initialized
DEBUG - 2022-03-09 23:19:46 --> UTF-8 Support Enabled
INFO - 2022-03-09 23:19:46 --> Utf8 Class Initialized
INFO - 2022-03-09 23:19:46 --> URI Class Initialized
INFO - 2022-03-09 23:19:46 --> Router Class Initialized
INFO - 2022-03-09 23:19:46 --> Output Class Initialized
INFO - 2022-03-09 23:19:46 --> Security Class Initialized
DEBUG - 2022-03-09 23:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 23:19:46 --> Input Class Initialized
INFO - 2022-03-09 23:19:46 --> Language Class Initialized
INFO - 2022-03-09 23:19:46 --> Loader Class Initialized
INFO - 2022-03-09 23:19:46 --> Helper loaded: url_helper
INFO - 2022-03-09 23:19:46 --> Helper loaded: form_helper
INFO - 2022-03-09 23:19:46 --> Helper loaded: common_helper
INFO - 2022-03-09 23:19:46 --> Database Driver Class Initialized
DEBUG - 2022-03-09 23:19:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 23:19:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 23:19:46 --> Controller Class Initialized
INFO - 2022-03-09 23:19:46 --> Form Validation Class Initialized
DEBUG - 2022-03-09 23:19:46 --> Encrypt Class Initialized
INFO - 2022-03-09 23:19:46 --> Model "Patient_model" initialized
INFO - 2022-03-09 23:19:46 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 23:19:46 --> Model "Prefix_master" initialized
INFO - 2022-03-09 23:19:46 --> Model "Users_model" initialized
INFO - 2022-03-09 23:19:46 --> Model "Hospital_model" initialized
INFO - 2022-03-09 23:19:46 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 23:19:46 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-09 23:19:46 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 23:19:46 --> Final output sent to browser
DEBUG - 2022-03-09 23:19:46 --> Total execution time: 0.0649
ERROR - 2022-03-09 23:19:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 23:19:57 --> Config Class Initialized
INFO - 2022-03-09 23:19:57 --> Hooks Class Initialized
DEBUG - 2022-03-09 23:19:57 --> UTF-8 Support Enabled
INFO - 2022-03-09 23:19:57 --> Utf8 Class Initialized
INFO - 2022-03-09 23:19:57 --> URI Class Initialized
INFO - 2022-03-09 23:19:57 --> Router Class Initialized
INFO - 2022-03-09 23:19:57 --> Output Class Initialized
INFO - 2022-03-09 23:19:57 --> Security Class Initialized
DEBUG - 2022-03-09 23:19:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 23:19:57 --> Input Class Initialized
INFO - 2022-03-09 23:19:57 --> Language Class Initialized
INFO - 2022-03-09 23:19:57 --> Loader Class Initialized
INFO - 2022-03-09 23:19:57 --> Helper loaded: url_helper
INFO - 2022-03-09 23:19:57 --> Helper loaded: form_helper
INFO - 2022-03-09 23:19:57 --> Helper loaded: common_helper
INFO - 2022-03-09 23:19:57 --> Database Driver Class Initialized
DEBUG - 2022-03-09 23:19:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 23:19:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 23:19:57 --> Controller Class Initialized
INFO - 2022-03-09 23:19:57 --> Form Validation Class Initialized
DEBUG - 2022-03-09 23:19:57 --> Encrypt Class Initialized
INFO - 2022-03-09 23:19:57 --> Model "Patient_model" initialized
INFO - 2022-03-09 23:19:57 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 23:19:57 --> Model "Prefix_master" initialized
INFO - 2022-03-09 23:19:57 --> Model "Users_model" initialized
INFO - 2022-03-09 23:19:57 --> Model "Hospital_model" initialized
INFO - 2022-03-09 23:19:57 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 23:19:57 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-09 23:19:57 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 23:19:57 --> Final output sent to browser
DEBUG - 2022-03-09 23:19:57 --> Total execution time: 0.1512
ERROR - 2022-03-09 23:20:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 23:20:10 --> Config Class Initialized
INFO - 2022-03-09 23:20:10 --> Hooks Class Initialized
DEBUG - 2022-03-09 23:20:10 --> UTF-8 Support Enabled
INFO - 2022-03-09 23:20:10 --> Utf8 Class Initialized
INFO - 2022-03-09 23:20:10 --> URI Class Initialized
INFO - 2022-03-09 23:20:10 --> Router Class Initialized
INFO - 2022-03-09 23:20:10 --> Output Class Initialized
INFO - 2022-03-09 23:20:10 --> Security Class Initialized
DEBUG - 2022-03-09 23:20:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 23:20:10 --> Input Class Initialized
INFO - 2022-03-09 23:20:10 --> Language Class Initialized
INFO - 2022-03-09 23:20:10 --> Loader Class Initialized
INFO - 2022-03-09 23:20:10 --> Helper loaded: url_helper
INFO - 2022-03-09 23:20:10 --> Helper loaded: form_helper
INFO - 2022-03-09 23:20:10 --> Helper loaded: common_helper
INFO - 2022-03-09 23:20:10 --> Database Driver Class Initialized
DEBUG - 2022-03-09 23:20:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 23:20:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 23:20:10 --> Controller Class Initialized
INFO - 2022-03-09 23:20:10 --> Form Validation Class Initialized
DEBUG - 2022-03-09 23:20:10 --> Encrypt Class Initialized
INFO - 2022-03-09 23:20:10 --> Model "Patient_model" initialized
INFO - 2022-03-09 23:20:10 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 23:20:10 --> Model "Referredby_model" initialized
INFO - 2022-03-09 23:20:10 --> Model "Prefix_master" initialized
INFO - 2022-03-09 23:20:10 --> Model "Hospital_model" initialized
INFO - 2022-03-09 23:20:10 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 23:20:10 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-09 23:20:10 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 23:20:10 --> Final output sent to browser
DEBUG - 2022-03-09 23:20:10 --> Total execution time: 0.0599
ERROR - 2022-03-09 23:21:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 23:21:05 --> Config Class Initialized
INFO - 2022-03-09 23:21:05 --> Hooks Class Initialized
DEBUG - 2022-03-09 23:21:05 --> UTF-8 Support Enabled
INFO - 2022-03-09 23:21:05 --> Utf8 Class Initialized
INFO - 2022-03-09 23:21:05 --> URI Class Initialized
INFO - 2022-03-09 23:21:05 --> Router Class Initialized
INFO - 2022-03-09 23:21:05 --> Output Class Initialized
INFO - 2022-03-09 23:21:05 --> Security Class Initialized
DEBUG - 2022-03-09 23:21:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 23:21:05 --> Input Class Initialized
INFO - 2022-03-09 23:21:05 --> Language Class Initialized
INFO - 2022-03-09 23:21:05 --> Loader Class Initialized
INFO - 2022-03-09 23:21:05 --> Helper loaded: url_helper
INFO - 2022-03-09 23:21:05 --> Helper loaded: form_helper
INFO - 2022-03-09 23:21:05 --> Helper loaded: common_helper
INFO - 2022-03-09 23:21:05 --> Database Driver Class Initialized
DEBUG - 2022-03-09 23:21:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 23:21:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 23:21:05 --> Controller Class Initialized
INFO - 2022-03-09 23:21:05 --> Form Validation Class Initialized
DEBUG - 2022-03-09 23:21:05 --> Encrypt Class Initialized
INFO - 2022-03-09 23:21:05 --> Model "Patient_model" initialized
INFO - 2022-03-09 23:21:05 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 23:21:05 --> Model "Referredby_model" initialized
INFO - 2022-03-09 23:21:05 --> Model "Prefix_master" initialized
INFO - 2022-03-09 23:21:05 --> Model "Hospital_model" initialized
ERROR - 2022-03-09 23:21:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 23:21:05 --> Config Class Initialized
INFO - 2022-03-09 23:21:05 --> Hooks Class Initialized
DEBUG - 2022-03-09 23:21:05 --> UTF-8 Support Enabled
INFO - 2022-03-09 23:21:05 --> Utf8 Class Initialized
INFO - 2022-03-09 23:21:05 --> URI Class Initialized
INFO - 2022-03-09 23:21:05 --> Router Class Initialized
INFO - 2022-03-09 23:21:05 --> Output Class Initialized
INFO - 2022-03-09 23:21:05 --> Security Class Initialized
DEBUG - 2022-03-09 23:21:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 23:21:05 --> Input Class Initialized
INFO - 2022-03-09 23:21:05 --> Language Class Initialized
INFO - 2022-03-09 23:21:05 --> Loader Class Initialized
INFO - 2022-03-09 23:21:05 --> Helper loaded: url_helper
INFO - 2022-03-09 23:21:05 --> Helper loaded: form_helper
INFO - 2022-03-09 23:21:05 --> Helper loaded: common_helper
INFO - 2022-03-09 23:21:05 --> Database Driver Class Initialized
DEBUG - 2022-03-09 23:21:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 23:21:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 23:21:05 --> Controller Class Initialized
INFO - 2022-03-09 23:21:05 --> Form Validation Class Initialized
DEBUG - 2022-03-09 23:21:05 --> Encrypt Class Initialized
INFO - 2022-03-09 23:21:05 --> Model "Patient_model" initialized
INFO - 2022-03-09 23:21:05 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 23:21:05 --> Model "Referredby_model" initialized
INFO - 2022-03-09 23:21:05 --> Model "Prefix_master" initialized
INFO - 2022-03-09 23:21:05 --> Model "Hospital_model" initialized
INFO - 2022-03-09 23:21:05 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 23:21:05 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-09 23:21:05 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 23:21:05 --> Final output sent to browser
DEBUG - 2022-03-09 23:21:05 --> Total execution time: 0.0541
ERROR - 2022-03-09 23:21:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 23:21:06 --> Config Class Initialized
INFO - 2022-03-09 23:21:06 --> Hooks Class Initialized
DEBUG - 2022-03-09 23:21:06 --> UTF-8 Support Enabled
INFO - 2022-03-09 23:21:06 --> Utf8 Class Initialized
INFO - 2022-03-09 23:21:06 --> URI Class Initialized
INFO - 2022-03-09 23:21:06 --> Router Class Initialized
INFO - 2022-03-09 23:21:06 --> Output Class Initialized
INFO - 2022-03-09 23:21:06 --> Security Class Initialized
DEBUG - 2022-03-09 23:21:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 23:21:06 --> Input Class Initialized
INFO - 2022-03-09 23:21:06 --> Language Class Initialized
INFO - 2022-03-09 23:21:06 --> Loader Class Initialized
INFO - 2022-03-09 23:21:06 --> Helper loaded: url_helper
INFO - 2022-03-09 23:21:06 --> Helper loaded: form_helper
INFO - 2022-03-09 23:21:06 --> Helper loaded: common_helper
INFO - 2022-03-09 23:21:06 --> Database Driver Class Initialized
DEBUG - 2022-03-09 23:21:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 23:21:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 23:21:06 --> Controller Class Initialized
INFO - 2022-03-09 23:21:06 --> Form Validation Class Initialized
DEBUG - 2022-03-09 23:21:06 --> Encrypt Class Initialized
INFO - 2022-03-09 23:21:06 --> Model "Patient_model" initialized
INFO - 2022-03-09 23:21:06 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 23:21:06 --> Model "Prefix_master" initialized
INFO - 2022-03-09 23:21:06 --> Model "Users_model" initialized
INFO - 2022-03-09 23:21:06 --> Model "Hospital_model" initialized
INFO - 2022-03-09 23:21:06 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 23:21:06 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-09 23:21:06 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 23:21:07 --> Final output sent to browser
DEBUG - 2022-03-09 23:21:07 --> Total execution time: 0.0706
ERROR - 2022-03-09 23:26:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 23:26:10 --> Config Class Initialized
INFO - 2022-03-09 23:26:10 --> Hooks Class Initialized
DEBUG - 2022-03-09 23:26:10 --> UTF-8 Support Enabled
INFO - 2022-03-09 23:26:10 --> Utf8 Class Initialized
INFO - 2022-03-09 23:26:10 --> URI Class Initialized
INFO - 2022-03-09 23:26:10 --> Router Class Initialized
INFO - 2022-03-09 23:26:10 --> Output Class Initialized
INFO - 2022-03-09 23:26:10 --> Security Class Initialized
DEBUG - 2022-03-09 23:26:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 23:26:10 --> Input Class Initialized
INFO - 2022-03-09 23:26:10 --> Language Class Initialized
INFO - 2022-03-09 23:26:10 --> Loader Class Initialized
INFO - 2022-03-09 23:26:10 --> Helper loaded: url_helper
INFO - 2022-03-09 23:26:10 --> Helper loaded: form_helper
INFO - 2022-03-09 23:26:10 --> Helper loaded: common_helper
INFO - 2022-03-09 23:26:10 --> Database Driver Class Initialized
DEBUG - 2022-03-09 23:26:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 23:26:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 23:26:10 --> Controller Class Initialized
INFO - 2022-03-09 23:26:10 --> Form Validation Class Initialized
DEBUG - 2022-03-09 23:26:10 --> Encrypt Class Initialized
INFO - 2022-03-09 23:26:10 --> Model "Patient_model" initialized
INFO - 2022-03-09 23:26:10 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 23:26:10 --> Model "Prefix_master" initialized
INFO - 2022-03-09 23:26:10 --> Model "Users_model" initialized
INFO - 2022-03-09 23:26:10 --> Model "Hospital_model" initialized
ERROR - 2022-03-09 23:26:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 23:26:10 --> Config Class Initialized
INFO - 2022-03-09 23:26:10 --> Hooks Class Initialized
DEBUG - 2022-03-09 23:26:10 --> UTF-8 Support Enabled
INFO - 2022-03-09 23:26:10 --> Utf8 Class Initialized
INFO - 2022-03-09 23:26:10 --> URI Class Initialized
INFO - 2022-03-09 23:26:10 --> Router Class Initialized
INFO - 2022-03-09 23:26:10 --> Output Class Initialized
INFO - 2022-03-09 23:26:10 --> Security Class Initialized
DEBUG - 2022-03-09 23:26:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 23:26:10 --> Input Class Initialized
INFO - 2022-03-09 23:26:10 --> Language Class Initialized
INFO - 2022-03-09 23:26:10 --> Loader Class Initialized
INFO - 2022-03-09 23:26:10 --> Helper loaded: url_helper
INFO - 2022-03-09 23:26:10 --> Helper loaded: form_helper
INFO - 2022-03-09 23:26:10 --> Helper loaded: common_helper
INFO - 2022-03-09 23:26:10 --> Database Driver Class Initialized
DEBUG - 2022-03-09 23:26:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 23:26:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 23:26:10 --> Controller Class Initialized
INFO - 2022-03-09 23:26:10 --> Form Validation Class Initialized
DEBUG - 2022-03-09 23:26:10 --> Encrypt Class Initialized
INFO - 2022-03-09 23:26:10 --> Model "Patient_model" initialized
INFO - 2022-03-09 23:26:10 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 23:26:10 --> Model "Prefix_master" initialized
INFO - 2022-03-09 23:26:10 --> Model "Users_model" initialized
INFO - 2022-03-09 23:26:10 --> Model "Hospital_model" initialized
INFO - 2022-03-09 23:26:10 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 23:26:10 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-09 23:26:10 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 23:26:10 --> Final output sent to browser
DEBUG - 2022-03-09 23:26:10 --> Total execution time: 0.0570
ERROR - 2022-03-09 23:27:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 23:27:04 --> Config Class Initialized
INFO - 2022-03-09 23:27:04 --> Hooks Class Initialized
DEBUG - 2022-03-09 23:27:04 --> UTF-8 Support Enabled
INFO - 2022-03-09 23:27:04 --> Utf8 Class Initialized
INFO - 2022-03-09 23:27:04 --> URI Class Initialized
INFO - 2022-03-09 23:27:04 --> Router Class Initialized
INFO - 2022-03-09 23:27:04 --> Output Class Initialized
INFO - 2022-03-09 23:27:04 --> Security Class Initialized
DEBUG - 2022-03-09 23:27:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 23:27:04 --> Input Class Initialized
INFO - 2022-03-09 23:27:04 --> Language Class Initialized
INFO - 2022-03-09 23:27:04 --> Loader Class Initialized
INFO - 2022-03-09 23:27:04 --> Helper loaded: url_helper
INFO - 2022-03-09 23:27:04 --> Helper loaded: form_helper
INFO - 2022-03-09 23:27:04 --> Helper loaded: common_helper
INFO - 2022-03-09 23:27:04 --> Database Driver Class Initialized
DEBUG - 2022-03-09 23:27:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 23:27:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 23:27:04 --> Controller Class Initialized
INFO - 2022-03-09 23:27:04 --> Form Validation Class Initialized
DEBUG - 2022-03-09 23:27:04 --> Encrypt Class Initialized
INFO - 2022-03-09 23:27:04 --> Model "Patient_model" initialized
INFO - 2022-03-09 23:27:04 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 23:27:04 --> Model "Prefix_master" initialized
INFO - 2022-03-09 23:27:04 --> Model "Users_model" initialized
INFO - 2022-03-09 23:27:04 --> Model "Hospital_model" initialized
INFO - 2022-03-09 23:27:04 --> Upload Class Initialized
INFO - 2022-03-09 23:27:04 --> Final output sent to browser
DEBUG - 2022-03-09 23:27:04 --> Total execution time: 0.0439
ERROR - 2022-03-09 23:27:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 23:27:15 --> Config Class Initialized
INFO - 2022-03-09 23:27:15 --> Hooks Class Initialized
DEBUG - 2022-03-09 23:27:15 --> UTF-8 Support Enabled
INFO - 2022-03-09 23:27:15 --> Utf8 Class Initialized
INFO - 2022-03-09 23:27:15 --> URI Class Initialized
INFO - 2022-03-09 23:27:15 --> Router Class Initialized
INFO - 2022-03-09 23:27:15 --> Output Class Initialized
INFO - 2022-03-09 23:27:15 --> Security Class Initialized
DEBUG - 2022-03-09 23:27:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 23:27:15 --> Input Class Initialized
INFO - 2022-03-09 23:27:15 --> Language Class Initialized
INFO - 2022-03-09 23:27:15 --> Loader Class Initialized
INFO - 2022-03-09 23:27:15 --> Helper loaded: url_helper
INFO - 2022-03-09 23:27:15 --> Helper loaded: form_helper
INFO - 2022-03-09 23:27:15 --> Helper loaded: common_helper
INFO - 2022-03-09 23:27:15 --> Database Driver Class Initialized
DEBUG - 2022-03-09 23:27:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 23:27:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 23:27:15 --> Controller Class Initialized
INFO - 2022-03-09 23:27:15 --> Form Validation Class Initialized
DEBUG - 2022-03-09 23:27:15 --> Encrypt Class Initialized
INFO - 2022-03-09 23:27:15 --> Model "Patient_model" initialized
INFO - 2022-03-09 23:27:15 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 23:27:15 --> Model "Prefix_master" initialized
INFO - 2022-03-09 23:27:15 --> Model "Users_model" initialized
INFO - 2022-03-09 23:27:15 --> Model "Hospital_model" initialized
ERROR - 2022-03-09 23:27:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 23:27:15 --> Config Class Initialized
INFO - 2022-03-09 23:27:15 --> Hooks Class Initialized
DEBUG - 2022-03-09 23:27:15 --> UTF-8 Support Enabled
INFO - 2022-03-09 23:27:15 --> Utf8 Class Initialized
INFO - 2022-03-09 23:27:15 --> URI Class Initialized
INFO - 2022-03-09 23:27:15 --> Router Class Initialized
INFO - 2022-03-09 23:27:15 --> Output Class Initialized
INFO - 2022-03-09 23:27:15 --> Security Class Initialized
DEBUG - 2022-03-09 23:27:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 23:27:15 --> Input Class Initialized
INFO - 2022-03-09 23:27:15 --> Language Class Initialized
INFO - 2022-03-09 23:27:15 --> Loader Class Initialized
INFO - 2022-03-09 23:27:15 --> Helper loaded: url_helper
INFO - 2022-03-09 23:27:15 --> Helper loaded: form_helper
INFO - 2022-03-09 23:27:15 --> Helper loaded: common_helper
INFO - 2022-03-09 23:27:15 --> Database Driver Class Initialized
DEBUG - 2022-03-09 23:27:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 23:27:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 23:27:15 --> Controller Class Initialized
INFO - 2022-03-09 23:27:15 --> Form Validation Class Initialized
DEBUG - 2022-03-09 23:27:15 --> Encrypt Class Initialized
INFO - 2022-03-09 23:27:15 --> Model "Patient_model" initialized
INFO - 2022-03-09 23:27:15 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 23:27:15 --> Model "Prefix_master" initialized
INFO - 2022-03-09 23:27:15 --> Model "Users_model" initialized
INFO - 2022-03-09 23:27:15 --> Model "Hospital_model" initialized
INFO - 2022-03-09 23:27:16 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 23:27:16 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-09 23:27:16 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 23:27:16 --> Final output sent to browser
DEBUG - 2022-03-09 23:27:16 --> Total execution time: 0.0734
ERROR - 2022-03-09 23:40:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 23:40:37 --> Config Class Initialized
INFO - 2022-03-09 23:40:37 --> Hooks Class Initialized
DEBUG - 2022-03-09 23:40:37 --> UTF-8 Support Enabled
INFO - 2022-03-09 23:40:37 --> Utf8 Class Initialized
INFO - 2022-03-09 23:40:37 --> URI Class Initialized
DEBUG - 2022-03-09 23:40:37 --> No URI present. Default controller set.
INFO - 2022-03-09 23:40:37 --> Router Class Initialized
INFO - 2022-03-09 23:40:37 --> Output Class Initialized
INFO - 2022-03-09 23:40:37 --> Security Class Initialized
DEBUG - 2022-03-09 23:40:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 23:40:37 --> Input Class Initialized
INFO - 2022-03-09 23:40:37 --> Language Class Initialized
INFO - 2022-03-09 23:40:37 --> Loader Class Initialized
INFO - 2022-03-09 23:40:37 --> Helper loaded: url_helper
INFO - 2022-03-09 23:40:37 --> Helper loaded: form_helper
INFO - 2022-03-09 23:40:37 --> Helper loaded: common_helper
INFO - 2022-03-09 23:40:37 --> Database Driver Class Initialized
DEBUG - 2022-03-09 23:40:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 23:40:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 23:40:37 --> Controller Class Initialized
INFO - 2022-03-09 23:40:37 --> Form Validation Class Initialized
DEBUG - 2022-03-09 23:40:37 --> Encrypt Class Initialized
DEBUG - 2022-03-09 23:40:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-09 23:40:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-09 23:40:37 --> Email Class Initialized
INFO - 2022-03-09 23:40:37 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-09 23:40:37 --> Calendar Class Initialized
INFO - 2022-03-09 23:40:37 --> Model "Login_model" initialized
INFO - 2022-03-09 23:40:37 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-09 23:40:37 --> Final output sent to browser
DEBUG - 2022-03-09 23:40:37 --> Total execution time: 0.0282
ERROR - 2022-03-09 23:41:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 23:41:04 --> Config Class Initialized
INFO - 2022-03-09 23:41:04 --> Hooks Class Initialized
DEBUG - 2022-03-09 23:41:04 --> UTF-8 Support Enabled
INFO - 2022-03-09 23:41:04 --> Utf8 Class Initialized
INFO - 2022-03-09 23:41:04 --> URI Class Initialized
INFO - 2022-03-09 23:41:04 --> Router Class Initialized
INFO - 2022-03-09 23:41:04 --> Output Class Initialized
INFO - 2022-03-09 23:41:04 --> Security Class Initialized
DEBUG - 2022-03-09 23:41:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 23:41:04 --> Input Class Initialized
INFO - 2022-03-09 23:41:04 --> Language Class Initialized
INFO - 2022-03-09 23:41:04 --> Loader Class Initialized
INFO - 2022-03-09 23:41:04 --> Helper loaded: url_helper
INFO - 2022-03-09 23:41:04 --> Helper loaded: form_helper
INFO - 2022-03-09 23:41:04 --> Helper loaded: common_helper
INFO - 2022-03-09 23:41:04 --> Database Driver Class Initialized
DEBUG - 2022-03-09 23:41:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 23:41:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 23:41:04 --> Controller Class Initialized
INFO - 2022-03-09 23:41:04 --> Form Validation Class Initialized
DEBUG - 2022-03-09 23:41:04 --> Encrypt Class Initialized
DEBUG - 2022-03-09 23:41:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-09 23:41:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-09 23:41:04 --> Email Class Initialized
INFO - 2022-03-09 23:41:04 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-09 23:41:04 --> Calendar Class Initialized
INFO - 2022-03-09 23:41:04 --> Model "Login_model" initialized
INFO - 2022-03-09 23:41:04 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-03-09 23:41:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 23:41:04 --> Config Class Initialized
INFO - 2022-03-09 23:41:04 --> Hooks Class Initialized
DEBUG - 2022-03-09 23:41:04 --> UTF-8 Support Enabled
INFO - 2022-03-09 23:41:04 --> Utf8 Class Initialized
INFO - 2022-03-09 23:41:04 --> URI Class Initialized
INFO - 2022-03-09 23:41:04 --> Router Class Initialized
INFO - 2022-03-09 23:41:04 --> Output Class Initialized
INFO - 2022-03-09 23:41:04 --> Security Class Initialized
DEBUG - 2022-03-09 23:41:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 23:41:04 --> Input Class Initialized
INFO - 2022-03-09 23:41:04 --> Language Class Initialized
INFO - 2022-03-09 23:41:04 --> Loader Class Initialized
INFO - 2022-03-09 23:41:04 --> Helper loaded: url_helper
INFO - 2022-03-09 23:41:04 --> Helper loaded: form_helper
INFO - 2022-03-09 23:41:04 --> Helper loaded: common_helper
INFO - 2022-03-09 23:41:04 --> Database Driver Class Initialized
DEBUG - 2022-03-09 23:41:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 23:41:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 23:41:04 --> Controller Class Initialized
INFO - 2022-03-09 23:41:04 --> Form Validation Class Initialized
DEBUG - 2022-03-09 23:41:04 --> Encrypt Class Initialized
INFO - 2022-03-09 23:41:04 --> Model "Login_model" initialized
INFO - 2022-03-09 23:41:04 --> Model "Dashboard_model" initialized
INFO - 2022-03-09 23:41:04 --> Model "Case_model" initialized
ERROR - 2022-03-09 23:41:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 23:41:10 --> Config Class Initialized
INFO - 2022-03-09 23:41:10 --> Hooks Class Initialized
DEBUG - 2022-03-09 23:41:10 --> UTF-8 Support Enabled
INFO - 2022-03-09 23:41:10 --> Utf8 Class Initialized
INFO - 2022-03-09 23:41:10 --> URI Class Initialized
INFO - 2022-03-09 23:41:10 --> Router Class Initialized
INFO - 2022-03-09 23:41:10 --> Output Class Initialized
INFO - 2022-03-09 23:41:10 --> Security Class Initialized
DEBUG - 2022-03-09 23:41:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 23:41:10 --> Input Class Initialized
INFO - 2022-03-09 23:41:10 --> Language Class Initialized
INFO - 2022-03-09 23:41:10 --> Loader Class Initialized
INFO - 2022-03-09 23:41:10 --> Helper loaded: url_helper
INFO - 2022-03-09 23:41:10 --> Helper loaded: form_helper
INFO - 2022-03-09 23:41:10 --> Helper loaded: common_helper
INFO - 2022-03-09 23:41:10 --> Database Driver Class Initialized
DEBUG - 2022-03-09 23:41:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 23:41:13 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 23:41:24 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2022-03-09 23:41:24 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 23:41:24 --> Final output sent to browser
DEBUG - 2022-03-09 23:41:24 --> Total execution time: 19.9775
INFO - 2022-03-09 23:41:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 23:41:24 --> Controller Class Initialized
INFO - 2022-03-09 23:41:24 --> Form Validation Class Initialized
DEBUG - 2022-03-09 23:41:24 --> Encrypt Class Initialized
DEBUG - 2022-03-09 23:41:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-09 23:41:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-09 23:41:24 --> Email Class Initialized
INFO - 2022-03-09 23:41:24 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-09 23:41:24 --> Calendar Class Initialized
INFO - 2022-03-09 23:41:24 --> Model "Login_model" initialized
INFO - 2022-03-09 23:41:24 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-03-09 23:41:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 23:41:25 --> Config Class Initialized
INFO - 2022-03-09 23:41:25 --> Hooks Class Initialized
DEBUG - 2022-03-09 23:41:25 --> UTF-8 Support Enabled
INFO - 2022-03-09 23:41:25 --> Utf8 Class Initialized
INFO - 2022-03-09 23:41:25 --> URI Class Initialized
INFO - 2022-03-09 23:41:25 --> Router Class Initialized
INFO - 2022-03-09 23:41:25 --> Output Class Initialized
INFO - 2022-03-09 23:41:25 --> Security Class Initialized
DEBUG - 2022-03-09 23:41:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 23:41:25 --> Input Class Initialized
INFO - 2022-03-09 23:41:25 --> Language Class Initialized
INFO - 2022-03-09 23:41:25 --> Loader Class Initialized
INFO - 2022-03-09 23:41:25 --> Helper loaded: url_helper
INFO - 2022-03-09 23:41:25 --> Helper loaded: form_helper
INFO - 2022-03-09 23:41:25 --> Helper loaded: common_helper
INFO - 2022-03-09 23:41:25 --> Database Driver Class Initialized
DEBUG - 2022-03-09 23:41:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 23:41:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 23:41:25 --> Controller Class Initialized
INFO - 2022-03-09 23:41:25 --> Form Validation Class Initialized
DEBUG - 2022-03-09 23:41:25 --> Encrypt Class Initialized
INFO - 2022-03-09 23:41:25 --> Model "Login_model" initialized
INFO - 2022-03-09 23:41:25 --> Model "Dashboard_model" initialized
INFO - 2022-03-09 23:41:25 --> Model "Case_model" initialized
INFO - 2022-03-09 23:41:37 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 23:41:49 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2022-03-09 23:41:49 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 23:41:49 --> Final output sent to browser
DEBUG - 2022-03-09 23:41:49 --> Total execution time: 23.8136
ERROR - 2022-03-09 23:41:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 23:41:50 --> Config Class Initialized
INFO - 2022-03-09 23:41:50 --> Hooks Class Initialized
DEBUG - 2022-03-09 23:41:50 --> UTF-8 Support Enabled
INFO - 2022-03-09 23:41:50 --> Utf8 Class Initialized
INFO - 2022-03-09 23:41:50 --> URI Class Initialized
INFO - 2022-03-09 23:41:50 --> Router Class Initialized
INFO - 2022-03-09 23:41:50 --> Output Class Initialized
INFO - 2022-03-09 23:41:50 --> Security Class Initialized
DEBUG - 2022-03-09 23:41:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 23:41:50 --> Input Class Initialized
INFO - 2022-03-09 23:41:50 --> Language Class Initialized
ERROR - 2022-03-09 23:41:50 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-09 23:42:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 23:42:31 --> Config Class Initialized
INFO - 2022-03-09 23:42:31 --> Hooks Class Initialized
DEBUG - 2022-03-09 23:42:31 --> UTF-8 Support Enabled
INFO - 2022-03-09 23:42:31 --> Utf8 Class Initialized
INFO - 2022-03-09 23:42:31 --> URI Class Initialized
INFO - 2022-03-09 23:42:31 --> Router Class Initialized
INFO - 2022-03-09 23:42:31 --> Output Class Initialized
INFO - 2022-03-09 23:42:31 --> Security Class Initialized
DEBUG - 2022-03-09 23:42:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 23:42:31 --> Input Class Initialized
INFO - 2022-03-09 23:42:31 --> Language Class Initialized
INFO - 2022-03-09 23:42:31 --> Loader Class Initialized
INFO - 2022-03-09 23:42:31 --> Helper loaded: url_helper
INFO - 2022-03-09 23:42:31 --> Helper loaded: form_helper
INFO - 2022-03-09 23:42:31 --> Helper loaded: common_helper
INFO - 2022-03-09 23:42:31 --> Database Driver Class Initialized
DEBUG - 2022-03-09 23:42:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 23:42:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 23:42:31 --> Controller Class Initialized
INFO - 2022-03-09 23:42:31 --> Form Validation Class Initialized
DEBUG - 2022-03-09 23:42:31 --> Encrypt Class Initialized
INFO - 2022-03-09 23:42:31 --> Model "Patient_model" initialized
INFO - 2022-03-09 23:42:31 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 23:42:31 --> Model "Referredby_model" initialized
INFO - 2022-03-09 23:42:31 --> Model "Prefix_master" initialized
INFO - 2022-03-09 23:42:31 --> Model "Hospital_model" initialized
INFO - 2022-03-09 23:42:31 --> File loaded: /home3/karoteam/public_html/application/views/header.php
ERROR - 2022-03-09 23:42:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 23:42:32 --> Config Class Initialized
INFO - 2022-03-09 23:42:32 --> Hooks Class Initialized
DEBUG - 2022-03-09 23:42:32 --> UTF-8 Support Enabled
INFO - 2022-03-09 23:42:32 --> Utf8 Class Initialized
INFO - 2022-03-09 23:42:32 --> URI Class Initialized
DEBUG - 2022-03-09 23:42:32 --> No URI present. Default controller set.
INFO - 2022-03-09 23:42:32 --> Router Class Initialized
INFO - 2022-03-09 23:42:32 --> Output Class Initialized
INFO - 2022-03-09 23:42:32 --> Security Class Initialized
DEBUG - 2022-03-09 23:42:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 23:42:32 --> Input Class Initialized
INFO - 2022-03-09 23:42:32 --> Language Class Initialized
INFO - 2022-03-09 23:42:32 --> Loader Class Initialized
INFO - 2022-03-09 23:42:32 --> Helper loaded: url_helper
INFO - 2022-03-09 23:42:32 --> Helper loaded: form_helper
INFO - 2022-03-09 23:42:32 --> Helper loaded: common_helper
INFO - 2022-03-09 23:42:32 --> Database Driver Class Initialized
DEBUG - 2022-03-09 23:42:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 23:42:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 23:42:32 --> Controller Class Initialized
INFO - 2022-03-09 23:42:32 --> Form Validation Class Initialized
DEBUG - 2022-03-09 23:42:32 --> Encrypt Class Initialized
DEBUG - 2022-03-09 23:42:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-09 23:42:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-09 23:42:32 --> Email Class Initialized
INFO - 2022-03-09 23:42:32 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-09 23:42:32 --> Calendar Class Initialized
INFO - 2022-03-09 23:42:32 --> Model "Login_model" initialized
INFO - 2022-03-09 23:42:32 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-09 23:42:32 --> Final output sent to browser
DEBUG - 2022-03-09 23:42:32 --> Total execution time: 0.0262
ERROR - 2022-03-09 23:42:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 23:42:37 --> Config Class Initialized
INFO - 2022-03-09 23:42:37 --> Hooks Class Initialized
INFO - 2022-03-09 23:42:37 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
DEBUG - 2022-03-09 23:42:37 --> UTF-8 Support Enabled
INFO - 2022-03-09 23:42:37 --> Utf8 Class Initialized
INFO - 2022-03-09 23:42:37 --> URI Class Initialized
INFO - 2022-03-09 23:42:37 --> Router Class Initialized
INFO - 2022-03-09 23:42:37 --> Output Class Initialized
INFO - 2022-03-09 23:42:37 --> Security Class Initialized
DEBUG - 2022-03-09 23:42:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 23:42:37 --> Input Class Initialized
INFO - 2022-03-09 23:42:37 --> Language Class Initialized
INFO - 2022-03-09 23:42:37 --> Loader Class Initialized
INFO - 2022-03-09 23:42:37 --> Helper loaded: url_helper
INFO - 2022-03-09 23:42:37 --> Helper loaded: form_helper
INFO - 2022-03-09 23:42:37 --> Helper loaded: common_helper
INFO - 2022-03-09 23:42:37 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 23:42:37 --> Database Driver Class Initialized
DEBUG - 2022-03-09 23:42:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 23:42:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 23:42:37 --> Controller Class Initialized
INFO - 2022-03-09 23:42:37 --> Form Validation Class Initialized
DEBUG - 2022-03-09 23:42:37 --> Encrypt Class Initialized
DEBUG - 2022-03-09 23:42:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-09 23:42:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-09 23:42:37 --> Email Class Initialized
INFO - 2022-03-09 23:42:37 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-09 23:42:37 --> Calendar Class Initialized
INFO - 2022-03-09 23:42:37 --> Model "Login_model" initialized
INFO - 2022-03-09 23:42:37 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-03-09 23:42:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 23:42:38 --> Config Class Initialized
INFO - 2022-03-09 23:42:38 --> Hooks Class Initialized
DEBUG - 2022-03-09 23:42:38 --> UTF-8 Support Enabled
INFO - 2022-03-09 23:42:38 --> Utf8 Class Initialized
INFO - 2022-03-09 23:42:38 --> URI Class Initialized
INFO - 2022-03-09 23:42:38 --> Router Class Initialized
INFO - 2022-03-09 23:42:38 --> Output Class Initialized
INFO - 2022-03-09 23:42:38 --> Security Class Initialized
DEBUG - 2022-03-09 23:42:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 23:42:38 --> Input Class Initialized
INFO - 2022-03-09 23:42:38 --> Language Class Initialized
INFO - 2022-03-09 23:42:38 --> Loader Class Initialized
INFO - 2022-03-09 23:42:38 --> Helper loaded: url_helper
INFO - 2022-03-09 23:42:38 --> Helper loaded: form_helper
INFO - 2022-03-09 23:42:38 --> Helper loaded: common_helper
INFO - 2022-03-09 23:42:38 --> Database Driver Class Initialized
DEBUG - 2022-03-09 23:42:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 23:42:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 23:42:38 --> Controller Class Initialized
INFO - 2022-03-09 23:42:38 --> Form Validation Class Initialized
DEBUG - 2022-03-09 23:42:38 --> Encrypt Class Initialized
INFO - 2022-03-09 23:42:38 --> Model "Login_model" initialized
INFO - 2022-03-09 23:42:38 --> Model "Dashboard_model" initialized
INFO - 2022-03-09 23:42:38 --> Model "Case_model" initialized
ERROR - 2022-03-09 23:42:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 23:42:38 --> Config Class Initialized
INFO - 2022-03-09 23:42:38 --> Hooks Class Initialized
DEBUG - 2022-03-09 23:42:38 --> UTF-8 Support Enabled
INFO - 2022-03-09 23:42:38 --> Utf8 Class Initialized
INFO - 2022-03-09 23:42:38 --> URI Class Initialized
INFO - 2022-03-09 23:42:38 --> Router Class Initialized
INFO - 2022-03-09 23:42:38 --> Output Class Initialized
INFO - 2022-03-09 23:42:38 --> Security Class Initialized
DEBUG - 2022-03-09 23:42:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 23:42:38 --> Input Class Initialized
INFO - 2022-03-09 23:42:38 --> Language Class Initialized
ERROR - 2022-03-09 23:42:38 --> 404 Page Not Found: Karoclient/usersprofile
INFO - 2022-03-09 23:42:39 --> Final output sent to browser
DEBUG - 2022-03-09 23:42:39 --> Total execution time: 6.2928
INFO - 2022-03-09 23:42:46 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 23:42:57 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2022-03-09 23:42:57 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 23:42:57 --> Final output sent to browser
DEBUG - 2022-03-09 23:42:57 --> Total execution time: 19.5537
ERROR - 2022-03-09 23:43:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 23:43:18 --> Config Class Initialized
INFO - 2022-03-09 23:43:18 --> Hooks Class Initialized
DEBUG - 2022-03-09 23:43:18 --> UTF-8 Support Enabled
INFO - 2022-03-09 23:43:18 --> Utf8 Class Initialized
INFO - 2022-03-09 23:43:18 --> URI Class Initialized
INFO - 2022-03-09 23:43:18 --> Router Class Initialized
INFO - 2022-03-09 23:43:18 --> Output Class Initialized
INFO - 2022-03-09 23:43:18 --> Security Class Initialized
DEBUG - 2022-03-09 23:43:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 23:43:18 --> Input Class Initialized
INFO - 2022-03-09 23:43:18 --> Language Class Initialized
INFO - 2022-03-09 23:43:18 --> Loader Class Initialized
INFO - 2022-03-09 23:43:18 --> Helper loaded: url_helper
INFO - 2022-03-09 23:43:18 --> Helper loaded: form_helper
INFO - 2022-03-09 23:43:18 --> Helper loaded: common_helper
INFO - 2022-03-09 23:43:18 --> Database Driver Class Initialized
DEBUG - 2022-03-09 23:43:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 23:43:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 23:43:18 --> Controller Class Initialized
INFO - 2022-03-09 23:43:18 --> Form Validation Class Initialized
DEBUG - 2022-03-09 23:43:18 --> Encrypt Class Initialized
INFO - 2022-03-09 23:43:18 --> Model "Patient_model" initialized
INFO - 2022-03-09 23:43:18 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 23:43:18 --> Model "Referredby_model" initialized
INFO - 2022-03-09 23:43:18 --> Model "Prefix_master" initialized
INFO - 2022-03-09 23:43:18 --> Model "Hospital_model" initialized
INFO - 2022-03-09 23:43:18 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 23:43:23 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-09 23:43:24 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 23:43:26 --> Final output sent to browser
DEBUG - 2022-03-09 23:43:26 --> Total execution time: 5.9286
ERROR - 2022-03-09 23:43:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 23:43:26 --> Config Class Initialized
INFO - 2022-03-09 23:43:26 --> Hooks Class Initialized
DEBUG - 2022-03-09 23:43:26 --> UTF-8 Support Enabled
INFO - 2022-03-09 23:43:26 --> Utf8 Class Initialized
INFO - 2022-03-09 23:43:26 --> URI Class Initialized
INFO - 2022-03-09 23:43:26 --> Router Class Initialized
INFO - 2022-03-09 23:43:26 --> Output Class Initialized
INFO - 2022-03-09 23:43:26 --> Security Class Initialized
DEBUG - 2022-03-09 23:43:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 23:43:26 --> Input Class Initialized
INFO - 2022-03-09 23:43:26 --> Language Class Initialized
INFO - 2022-03-09 23:43:26 --> Loader Class Initialized
INFO - 2022-03-09 23:43:26 --> Helper loaded: url_helper
INFO - 2022-03-09 23:43:26 --> Helper loaded: form_helper
INFO - 2022-03-09 23:43:26 --> Helper loaded: common_helper
INFO - 2022-03-09 23:43:26 --> Database Driver Class Initialized
DEBUG - 2022-03-09 23:43:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 23:43:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 23:43:26 --> Controller Class Initialized
INFO - 2022-03-09 23:43:26 --> Form Validation Class Initialized
DEBUG - 2022-03-09 23:43:26 --> Encrypt Class Initialized
INFO - 2022-03-09 23:43:26 --> Model "Patient_model" initialized
INFO - 2022-03-09 23:43:26 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 23:43:26 --> Model "Referredby_model" initialized
INFO - 2022-03-09 23:43:26 --> Model "Prefix_master" initialized
INFO - 2022-03-09 23:43:26 --> Model "Hospital_model" initialized
INFO - 2022-03-09 23:43:26 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 23:43:26 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-09 23:43:26 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 23:43:26 --> Final output sent to browser
DEBUG - 2022-03-09 23:43:26 --> Total execution time: 0.0539
ERROR - 2022-03-09 23:43:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 23:43:27 --> Config Class Initialized
INFO - 2022-03-09 23:43:27 --> Hooks Class Initialized
DEBUG - 2022-03-09 23:43:27 --> UTF-8 Support Enabled
INFO - 2022-03-09 23:43:27 --> Utf8 Class Initialized
INFO - 2022-03-09 23:43:27 --> URI Class Initialized
INFO - 2022-03-09 23:43:27 --> Router Class Initialized
INFO - 2022-03-09 23:43:27 --> Output Class Initialized
INFO - 2022-03-09 23:43:27 --> Security Class Initialized
DEBUG - 2022-03-09 23:43:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 23:43:27 --> Input Class Initialized
INFO - 2022-03-09 23:43:27 --> Language Class Initialized
ERROR - 2022-03-09 23:43:27 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-09 23:43:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 23:43:27 --> Config Class Initialized
INFO - 2022-03-09 23:43:27 --> Hooks Class Initialized
DEBUG - 2022-03-09 23:43:27 --> UTF-8 Support Enabled
INFO - 2022-03-09 23:43:27 --> Utf8 Class Initialized
INFO - 2022-03-09 23:43:27 --> URI Class Initialized
INFO - 2022-03-09 23:43:27 --> Router Class Initialized
INFO - 2022-03-09 23:43:27 --> Output Class Initialized
INFO - 2022-03-09 23:43:27 --> Security Class Initialized
DEBUG - 2022-03-09 23:43:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 23:43:27 --> Input Class Initialized
INFO - 2022-03-09 23:43:27 --> Language Class Initialized
ERROR - 2022-03-09 23:43:27 --> 404 Page Not Found: Karoclient/images
ERROR - 2022-03-09 23:43:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 23:43:45 --> Config Class Initialized
INFO - 2022-03-09 23:43:45 --> Hooks Class Initialized
DEBUG - 2022-03-09 23:43:45 --> UTF-8 Support Enabled
INFO - 2022-03-09 23:43:45 --> Utf8 Class Initialized
INFO - 2022-03-09 23:43:45 --> URI Class Initialized
INFO - 2022-03-09 23:43:45 --> Router Class Initialized
INFO - 2022-03-09 23:43:45 --> Output Class Initialized
INFO - 2022-03-09 23:43:45 --> Security Class Initialized
DEBUG - 2022-03-09 23:43:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 23:43:45 --> Input Class Initialized
INFO - 2022-03-09 23:43:45 --> Language Class Initialized
INFO - 2022-03-09 23:43:45 --> Loader Class Initialized
INFO - 2022-03-09 23:43:45 --> Helper loaded: url_helper
INFO - 2022-03-09 23:43:45 --> Helper loaded: form_helper
INFO - 2022-03-09 23:43:45 --> Helper loaded: common_helper
INFO - 2022-03-09 23:43:45 --> Database Driver Class Initialized
DEBUG - 2022-03-09 23:43:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 23:43:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 23:43:45 --> Controller Class Initialized
INFO - 2022-03-09 23:43:45 --> Form Validation Class Initialized
DEBUG - 2022-03-09 23:43:45 --> Encrypt Class Initialized
INFO - 2022-03-09 23:43:45 --> Model "Patient_model" initialized
INFO - 2022-03-09 23:43:45 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 23:43:45 --> Model "Referredby_model" initialized
INFO - 2022-03-09 23:43:45 --> Model "Prefix_master" initialized
INFO - 2022-03-09 23:43:45 --> Model "Hospital_model" initialized
ERROR - 2022-03-09 23:43:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 23:43:46 --> Config Class Initialized
INFO - 2022-03-09 23:43:46 --> Hooks Class Initialized
DEBUG - 2022-03-09 23:43:46 --> UTF-8 Support Enabled
INFO - 2022-03-09 23:43:46 --> Utf8 Class Initialized
INFO - 2022-03-09 23:43:46 --> URI Class Initialized
INFO - 2022-03-09 23:43:46 --> Router Class Initialized
INFO - 2022-03-09 23:43:46 --> Output Class Initialized
INFO - 2022-03-09 23:43:46 --> Security Class Initialized
DEBUG - 2022-03-09 23:43:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 23:43:46 --> Input Class Initialized
INFO - 2022-03-09 23:43:46 --> Language Class Initialized
INFO - 2022-03-09 23:43:46 --> Loader Class Initialized
INFO - 2022-03-09 23:43:46 --> Helper loaded: url_helper
INFO - 2022-03-09 23:43:46 --> Helper loaded: form_helper
INFO - 2022-03-09 23:43:46 --> Helper loaded: common_helper
INFO - 2022-03-09 23:43:46 --> Database Driver Class Initialized
DEBUG - 2022-03-09 23:43:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 23:43:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 23:43:46 --> Controller Class Initialized
INFO - 2022-03-09 23:43:46 --> Form Validation Class Initialized
DEBUG - 2022-03-09 23:43:46 --> Encrypt Class Initialized
INFO - 2022-03-09 23:43:46 --> Model "Patient_model" initialized
INFO - 2022-03-09 23:43:46 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 23:43:46 --> Model "Referredby_model" initialized
INFO - 2022-03-09 23:43:46 --> Model "Prefix_master" initialized
INFO - 2022-03-09 23:43:46 --> Model "Hospital_model" initialized
INFO - 2022-03-09 23:43:46 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 23:43:46 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-09 23:43:46 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 23:43:46 --> Final output sent to browser
DEBUG - 2022-03-09 23:43:46 --> Total execution time: 0.0624
ERROR - 2022-03-09 23:43:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 23:43:46 --> Config Class Initialized
INFO - 2022-03-09 23:43:46 --> Hooks Class Initialized
DEBUG - 2022-03-09 23:43:46 --> UTF-8 Support Enabled
INFO - 2022-03-09 23:43:46 --> Utf8 Class Initialized
INFO - 2022-03-09 23:43:46 --> URI Class Initialized
INFO - 2022-03-09 23:43:46 --> Router Class Initialized
INFO - 2022-03-09 23:43:46 --> Output Class Initialized
INFO - 2022-03-09 23:43:46 --> Security Class Initialized
DEBUG - 2022-03-09 23:43:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 23:43:46 --> Input Class Initialized
INFO - 2022-03-09 23:43:46 --> Language Class Initialized
ERROR - 2022-03-09 23:43:46 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-09 23:43:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 23:43:46 --> Config Class Initialized
INFO - 2022-03-09 23:43:46 --> Hooks Class Initialized
DEBUG - 2022-03-09 23:43:46 --> UTF-8 Support Enabled
INFO - 2022-03-09 23:43:46 --> Utf8 Class Initialized
INFO - 2022-03-09 23:43:46 --> URI Class Initialized
INFO - 2022-03-09 23:43:46 --> Router Class Initialized
INFO - 2022-03-09 23:43:46 --> Output Class Initialized
INFO - 2022-03-09 23:43:46 --> Security Class Initialized
DEBUG - 2022-03-09 23:43:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 23:43:46 --> Input Class Initialized
INFO - 2022-03-09 23:43:46 --> Language Class Initialized
ERROR - 2022-03-09 23:43:46 --> 404 Page Not Found: Karoclient/images
ERROR - 2022-03-09 23:43:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 23:43:47 --> Config Class Initialized
INFO - 2022-03-09 23:43:47 --> Hooks Class Initialized
DEBUG - 2022-03-09 23:43:47 --> UTF-8 Support Enabled
INFO - 2022-03-09 23:43:47 --> Utf8 Class Initialized
INFO - 2022-03-09 23:43:47 --> URI Class Initialized
INFO - 2022-03-09 23:43:47 --> Router Class Initialized
INFO - 2022-03-09 23:43:47 --> Output Class Initialized
INFO - 2022-03-09 23:43:47 --> Security Class Initialized
DEBUG - 2022-03-09 23:43:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 23:43:47 --> Input Class Initialized
INFO - 2022-03-09 23:43:47 --> Language Class Initialized
INFO - 2022-03-09 23:43:47 --> Loader Class Initialized
INFO - 2022-03-09 23:43:47 --> Helper loaded: url_helper
INFO - 2022-03-09 23:43:47 --> Helper loaded: form_helper
INFO - 2022-03-09 23:43:47 --> Helper loaded: common_helper
INFO - 2022-03-09 23:43:47 --> Database Driver Class Initialized
DEBUG - 2022-03-09 23:43:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 23:43:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 23:43:47 --> Controller Class Initialized
INFO - 2022-03-09 23:43:47 --> Form Validation Class Initialized
DEBUG - 2022-03-09 23:43:47 --> Encrypt Class Initialized
INFO - 2022-03-09 23:43:47 --> Model "Patient_model" initialized
INFO - 2022-03-09 23:43:47 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 23:43:47 --> Model "Prefix_master" initialized
INFO - 2022-03-09 23:43:47 --> Model "Users_model" initialized
INFO - 2022-03-09 23:43:47 --> Model "Hospital_model" initialized
INFO - 2022-03-09 23:43:47 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 23:43:47 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-09 23:43:47 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 23:43:47 --> Final output sent to browser
DEBUG - 2022-03-09 23:43:47 --> Total execution time: 0.0793
ERROR - 2022-03-09 23:43:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 23:43:47 --> Config Class Initialized
INFO - 2022-03-09 23:43:47 --> Hooks Class Initialized
DEBUG - 2022-03-09 23:43:47 --> UTF-8 Support Enabled
INFO - 2022-03-09 23:43:47 --> Utf8 Class Initialized
INFO - 2022-03-09 23:43:47 --> URI Class Initialized
INFO - 2022-03-09 23:43:47 --> Router Class Initialized
INFO - 2022-03-09 23:43:47 --> Output Class Initialized
INFO - 2022-03-09 23:43:47 --> Security Class Initialized
DEBUG - 2022-03-09 23:43:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 23:43:47 --> Input Class Initialized
INFO - 2022-03-09 23:43:47 --> Language Class Initialized
ERROR - 2022-03-09 23:43:47 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-09 23:43:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 23:43:59 --> Config Class Initialized
INFO - 2022-03-09 23:43:59 --> Hooks Class Initialized
DEBUG - 2022-03-09 23:43:59 --> UTF-8 Support Enabled
INFO - 2022-03-09 23:43:59 --> Utf8 Class Initialized
INFO - 2022-03-09 23:43:59 --> URI Class Initialized
INFO - 2022-03-09 23:43:59 --> Router Class Initialized
INFO - 2022-03-09 23:43:59 --> Output Class Initialized
INFO - 2022-03-09 23:43:59 --> Security Class Initialized
DEBUG - 2022-03-09 23:43:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 23:43:59 --> Input Class Initialized
INFO - 2022-03-09 23:43:59 --> Language Class Initialized
INFO - 2022-03-09 23:43:59 --> Loader Class Initialized
INFO - 2022-03-09 23:43:59 --> Helper loaded: url_helper
INFO - 2022-03-09 23:43:59 --> Helper loaded: form_helper
INFO - 2022-03-09 23:43:59 --> Helper loaded: common_helper
INFO - 2022-03-09 23:43:59 --> Database Driver Class Initialized
DEBUG - 2022-03-09 23:43:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 23:43:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 23:43:59 --> Controller Class Initialized
INFO - 2022-03-09 23:43:59 --> Form Validation Class Initialized
DEBUG - 2022-03-09 23:43:59 --> Encrypt Class Initialized
INFO - 2022-03-09 23:43:59 --> Model "Patient_model" initialized
INFO - 2022-03-09 23:43:59 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 23:43:59 --> Model "Prefix_master" initialized
INFO - 2022-03-09 23:43:59 --> Model "Users_model" initialized
INFO - 2022-03-09 23:43:59 --> Model "Hospital_model" initialized
INFO - 2022-03-09 23:43:59 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 23:43:59 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-09 23:43:59 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 23:43:59 --> Final output sent to browser
DEBUG - 2022-03-09 23:43:59 --> Total execution time: 0.0686
ERROR - 2022-03-09 23:47:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 23:47:32 --> Config Class Initialized
INFO - 2022-03-09 23:47:32 --> Hooks Class Initialized
DEBUG - 2022-03-09 23:47:32 --> UTF-8 Support Enabled
INFO - 2022-03-09 23:47:32 --> Utf8 Class Initialized
INFO - 2022-03-09 23:47:32 --> URI Class Initialized
INFO - 2022-03-09 23:47:32 --> Router Class Initialized
INFO - 2022-03-09 23:47:32 --> Output Class Initialized
INFO - 2022-03-09 23:47:32 --> Security Class Initialized
DEBUG - 2022-03-09 23:47:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 23:47:32 --> Input Class Initialized
INFO - 2022-03-09 23:47:32 --> Language Class Initialized
INFO - 2022-03-09 23:47:32 --> Loader Class Initialized
INFO - 2022-03-09 23:47:32 --> Helper loaded: url_helper
INFO - 2022-03-09 23:47:32 --> Helper loaded: form_helper
INFO - 2022-03-09 23:47:32 --> Helper loaded: common_helper
INFO - 2022-03-09 23:47:32 --> Database Driver Class Initialized
DEBUG - 2022-03-09 23:47:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 23:47:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 23:47:32 --> Controller Class Initialized
INFO - 2022-03-09 23:47:32 --> Form Validation Class Initialized
DEBUG - 2022-03-09 23:47:32 --> Encrypt Class Initialized
INFO - 2022-03-09 23:47:32 --> Model "Patient_model" initialized
INFO - 2022-03-09 23:47:32 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 23:47:32 --> Model "Prefix_master" initialized
INFO - 2022-03-09 23:47:32 --> Model "Users_model" initialized
INFO - 2022-03-09 23:47:32 --> Model "Hospital_model" initialized
ERROR - 2022-03-09 23:47:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 23:47:33 --> Config Class Initialized
INFO - 2022-03-09 23:47:33 --> Hooks Class Initialized
DEBUG - 2022-03-09 23:47:33 --> UTF-8 Support Enabled
INFO - 2022-03-09 23:47:33 --> Utf8 Class Initialized
INFO - 2022-03-09 23:47:33 --> URI Class Initialized
INFO - 2022-03-09 23:47:33 --> Router Class Initialized
INFO - 2022-03-09 23:47:33 --> Output Class Initialized
INFO - 2022-03-09 23:47:33 --> Security Class Initialized
DEBUG - 2022-03-09 23:47:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 23:47:33 --> Input Class Initialized
INFO - 2022-03-09 23:47:33 --> Language Class Initialized
INFO - 2022-03-09 23:47:33 --> Loader Class Initialized
INFO - 2022-03-09 23:47:33 --> Helper loaded: url_helper
INFO - 2022-03-09 23:47:33 --> Helper loaded: form_helper
INFO - 2022-03-09 23:47:33 --> Helper loaded: common_helper
INFO - 2022-03-09 23:47:33 --> Database Driver Class Initialized
DEBUG - 2022-03-09 23:47:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 23:47:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 23:47:33 --> Controller Class Initialized
INFO - 2022-03-09 23:47:33 --> Form Validation Class Initialized
DEBUG - 2022-03-09 23:47:33 --> Encrypt Class Initialized
INFO - 2022-03-09 23:47:33 --> Model "Patient_model" initialized
INFO - 2022-03-09 23:47:33 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 23:47:33 --> Model "Prefix_master" initialized
INFO - 2022-03-09 23:47:33 --> Model "Users_model" initialized
INFO - 2022-03-09 23:47:33 --> Model "Hospital_model" initialized
INFO - 2022-03-09 23:47:33 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 23:47:33 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-09 23:47:33 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 23:47:33 --> Final output sent to browser
DEBUG - 2022-03-09 23:47:33 --> Total execution time: 0.0600
ERROR - 2022-03-09 23:47:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 23:47:39 --> Config Class Initialized
INFO - 2022-03-09 23:47:39 --> Hooks Class Initialized
DEBUG - 2022-03-09 23:47:39 --> UTF-8 Support Enabled
INFO - 2022-03-09 23:47:39 --> Utf8 Class Initialized
INFO - 2022-03-09 23:47:39 --> URI Class Initialized
INFO - 2022-03-09 23:47:39 --> Router Class Initialized
INFO - 2022-03-09 23:47:39 --> Output Class Initialized
INFO - 2022-03-09 23:47:39 --> Security Class Initialized
DEBUG - 2022-03-09 23:47:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 23:47:39 --> Input Class Initialized
INFO - 2022-03-09 23:47:39 --> Language Class Initialized
INFO - 2022-03-09 23:47:39 --> Loader Class Initialized
INFO - 2022-03-09 23:47:39 --> Helper loaded: url_helper
INFO - 2022-03-09 23:47:39 --> Helper loaded: form_helper
INFO - 2022-03-09 23:47:39 --> Helper loaded: common_helper
INFO - 2022-03-09 23:47:39 --> Database Driver Class Initialized
DEBUG - 2022-03-09 23:47:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 23:47:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 23:47:39 --> Controller Class Initialized
INFO - 2022-03-09 23:47:39 --> Form Validation Class Initialized
DEBUG - 2022-03-09 23:47:39 --> Encrypt Class Initialized
INFO - 2022-03-09 23:47:39 --> Model "Patient_model" initialized
INFO - 2022-03-09 23:47:39 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 23:47:39 --> Model "Prefix_master" initialized
INFO - 2022-03-09 23:47:39 --> Model "Users_model" initialized
INFO - 2022-03-09 23:47:39 --> Model "Hospital_model" initialized
INFO - 2022-03-09 23:47:39 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 23:47:39 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-09 23:47:39 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 23:47:39 --> Final output sent to browser
DEBUG - 2022-03-09 23:47:39 --> Total execution time: 0.0532
ERROR - 2022-03-09 23:47:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 23:47:42 --> Config Class Initialized
INFO - 2022-03-09 23:47:42 --> Hooks Class Initialized
DEBUG - 2022-03-09 23:47:42 --> UTF-8 Support Enabled
INFO - 2022-03-09 23:47:42 --> Utf8 Class Initialized
INFO - 2022-03-09 23:47:42 --> URI Class Initialized
INFO - 2022-03-09 23:47:42 --> Router Class Initialized
INFO - 2022-03-09 23:47:42 --> Output Class Initialized
INFO - 2022-03-09 23:47:42 --> Security Class Initialized
DEBUG - 2022-03-09 23:47:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 23:47:42 --> Input Class Initialized
INFO - 2022-03-09 23:47:42 --> Language Class Initialized
INFO - 2022-03-09 23:47:42 --> Loader Class Initialized
INFO - 2022-03-09 23:47:42 --> Helper loaded: url_helper
INFO - 2022-03-09 23:47:42 --> Helper loaded: form_helper
INFO - 2022-03-09 23:47:42 --> Helper loaded: common_helper
INFO - 2022-03-09 23:47:42 --> Database Driver Class Initialized
DEBUG - 2022-03-09 23:47:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 23:47:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 23:47:42 --> Controller Class Initialized
INFO - 2022-03-09 23:47:42 --> Form Validation Class Initialized
DEBUG - 2022-03-09 23:47:42 --> Encrypt Class Initialized
INFO - 2022-03-09 23:47:42 --> Model "Patient_model" initialized
INFO - 2022-03-09 23:47:42 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 23:47:42 --> Model "Referredby_model" initialized
INFO - 2022-03-09 23:47:42 --> Model "Prefix_master" initialized
INFO - 2022-03-09 23:47:42 --> Model "Hospital_model" initialized
INFO - 2022-03-09 23:47:42 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 23:47:42 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-09 23:47:42 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 23:47:42 --> Final output sent to browser
DEBUG - 2022-03-09 23:47:42 --> Total execution time: 0.0499
ERROR - 2022-03-09 23:49:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 23:49:51 --> Config Class Initialized
INFO - 2022-03-09 23:49:51 --> Hooks Class Initialized
DEBUG - 2022-03-09 23:49:51 --> UTF-8 Support Enabled
INFO - 2022-03-09 23:49:51 --> Utf8 Class Initialized
INFO - 2022-03-09 23:49:51 --> URI Class Initialized
INFO - 2022-03-09 23:49:51 --> Router Class Initialized
INFO - 2022-03-09 23:49:51 --> Output Class Initialized
INFO - 2022-03-09 23:49:51 --> Security Class Initialized
DEBUG - 2022-03-09 23:49:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 23:49:51 --> Input Class Initialized
INFO - 2022-03-09 23:49:51 --> Language Class Initialized
INFO - 2022-03-09 23:49:51 --> Loader Class Initialized
INFO - 2022-03-09 23:49:51 --> Helper loaded: url_helper
INFO - 2022-03-09 23:49:51 --> Helper loaded: form_helper
INFO - 2022-03-09 23:49:51 --> Helper loaded: common_helper
INFO - 2022-03-09 23:49:51 --> Database Driver Class Initialized
DEBUG - 2022-03-09 23:49:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 23:49:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 23:49:51 --> Controller Class Initialized
INFO - 2022-03-09 23:49:51 --> Model "Referredby_model" initialized
INFO - 2022-03-09 23:49:51 --> Final output sent to browser
DEBUG - 2022-03-09 23:49:51 --> Total execution time: 0.0196
ERROR - 2022-03-09 23:53:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 23:53:29 --> Config Class Initialized
INFO - 2022-03-09 23:53:29 --> Hooks Class Initialized
DEBUG - 2022-03-09 23:53:29 --> UTF-8 Support Enabled
INFO - 2022-03-09 23:53:29 --> Utf8 Class Initialized
INFO - 2022-03-09 23:53:29 --> URI Class Initialized
INFO - 2022-03-09 23:53:29 --> Router Class Initialized
INFO - 2022-03-09 23:53:29 --> Output Class Initialized
INFO - 2022-03-09 23:53:29 --> Security Class Initialized
DEBUG - 2022-03-09 23:53:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 23:53:29 --> Input Class Initialized
INFO - 2022-03-09 23:53:29 --> Language Class Initialized
INFO - 2022-03-09 23:53:29 --> Loader Class Initialized
INFO - 2022-03-09 23:53:29 --> Helper loaded: url_helper
INFO - 2022-03-09 23:53:29 --> Helper loaded: form_helper
INFO - 2022-03-09 23:53:29 --> Helper loaded: common_helper
INFO - 2022-03-09 23:53:29 --> Database Driver Class Initialized
DEBUG - 2022-03-09 23:53:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 23:53:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 23:53:29 --> Controller Class Initialized
INFO - 2022-03-09 23:53:29 --> Form Validation Class Initialized
DEBUG - 2022-03-09 23:53:29 --> Encrypt Class Initialized
INFO - 2022-03-09 23:53:29 --> Model "Patient_model" initialized
INFO - 2022-03-09 23:53:29 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 23:53:29 --> Model "Prefix_master" initialized
INFO - 2022-03-09 23:53:29 --> Model "Users_model" initialized
INFO - 2022-03-09 23:53:29 --> Model "Hospital_model" initialized
ERROR - 2022-03-09 23:53:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 23:53:30 --> Config Class Initialized
INFO - 2022-03-09 23:53:30 --> Hooks Class Initialized
DEBUG - 2022-03-09 23:53:30 --> UTF-8 Support Enabled
INFO - 2022-03-09 23:53:30 --> Utf8 Class Initialized
INFO - 2022-03-09 23:53:30 --> URI Class Initialized
INFO - 2022-03-09 23:53:30 --> Router Class Initialized
INFO - 2022-03-09 23:53:30 --> Output Class Initialized
INFO - 2022-03-09 23:53:30 --> Security Class Initialized
DEBUG - 2022-03-09 23:53:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 23:53:30 --> Input Class Initialized
INFO - 2022-03-09 23:53:30 --> Language Class Initialized
INFO - 2022-03-09 23:53:30 --> Loader Class Initialized
INFO - 2022-03-09 23:53:30 --> Helper loaded: url_helper
INFO - 2022-03-09 23:53:30 --> Helper loaded: form_helper
INFO - 2022-03-09 23:53:30 --> Helper loaded: common_helper
INFO - 2022-03-09 23:53:30 --> Database Driver Class Initialized
DEBUG - 2022-03-09 23:53:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 23:53:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 23:53:30 --> Controller Class Initialized
INFO - 2022-03-09 23:53:30 --> Form Validation Class Initialized
DEBUG - 2022-03-09 23:53:30 --> Encrypt Class Initialized
INFO - 2022-03-09 23:53:30 --> Model "Patient_model" initialized
INFO - 2022-03-09 23:53:30 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 23:53:30 --> Model "Prefix_master" initialized
INFO - 2022-03-09 23:53:30 --> Model "Users_model" initialized
INFO - 2022-03-09 23:53:30 --> Model "Hospital_model" initialized
INFO - 2022-03-09 23:53:30 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 23:53:30 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-09 23:53:30 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 23:53:30 --> Final output sent to browser
DEBUG - 2022-03-09 23:53:30 --> Total execution time: 0.0562
ERROR - 2022-03-09 23:53:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 23:53:39 --> Config Class Initialized
INFO - 2022-03-09 23:53:39 --> Hooks Class Initialized
DEBUG - 2022-03-09 23:53:39 --> UTF-8 Support Enabled
INFO - 2022-03-09 23:53:39 --> Utf8 Class Initialized
INFO - 2022-03-09 23:53:39 --> URI Class Initialized
INFO - 2022-03-09 23:53:39 --> Router Class Initialized
INFO - 2022-03-09 23:53:39 --> Output Class Initialized
INFO - 2022-03-09 23:53:39 --> Security Class Initialized
DEBUG - 2022-03-09 23:53:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 23:53:39 --> Input Class Initialized
INFO - 2022-03-09 23:53:39 --> Language Class Initialized
INFO - 2022-03-09 23:53:39 --> Loader Class Initialized
INFO - 2022-03-09 23:53:39 --> Helper loaded: url_helper
INFO - 2022-03-09 23:53:39 --> Helper loaded: form_helper
INFO - 2022-03-09 23:53:39 --> Helper loaded: common_helper
INFO - 2022-03-09 23:53:39 --> Database Driver Class Initialized
DEBUG - 2022-03-09 23:53:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 23:53:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 23:53:39 --> Controller Class Initialized
INFO - 2022-03-09 23:53:39 --> Model "Referredby_model" initialized
INFO - 2022-03-09 23:53:39 --> Final output sent to browser
DEBUG - 2022-03-09 23:53:39 --> Total execution time: 0.0203
ERROR - 2022-03-09 23:53:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 23:53:45 --> Config Class Initialized
INFO - 2022-03-09 23:53:45 --> Hooks Class Initialized
DEBUG - 2022-03-09 23:53:45 --> UTF-8 Support Enabled
INFO - 2022-03-09 23:53:45 --> Utf8 Class Initialized
INFO - 2022-03-09 23:53:45 --> URI Class Initialized
INFO - 2022-03-09 23:53:45 --> Router Class Initialized
INFO - 2022-03-09 23:53:45 --> Output Class Initialized
INFO - 2022-03-09 23:53:45 --> Security Class Initialized
DEBUG - 2022-03-09 23:53:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 23:53:45 --> Input Class Initialized
INFO - 2022-03-09 23:53:45 --> Language Class Initialized
INFO - 2022-03-09 23:53:45 --> Loader Class Initialized
INFO - 2022-03-09 23:53:45 --> Helper loaded: url_helper
INFO - 2022-03-09 23:53:45 --> Helper loaded: form_helper
INFO - 2022-03-09 23:53:45 --> Helper loaded: common_helper
INFO - 2022-03-09 23:53:45 --> Database Driver Class Initialized
DEBUG - 2022-03-09 23:53:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 23:53:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 23:53:45 --> Controller Class Initialized
INFO - 2022-03-09 23:53:45 --> Form Validation Class Initialized
DEBUG - 2022-03-09 23:53:45 --> Encrypt Class Initialized
INFO - 2022-03-09 23:53:45 --> Model "Patient_model" initialized
INFO - 2022-03-09 23:53:45 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 23:53:45 --> Model "Referredby_model" initialized
INFO - 2022-03-09 23:53:45 --> Model "Prefix_master" initialized
INFO - 2022-03-09 23:53:45 --> Model "Hospital_model" initialized
INFO - 2022-03-09 23:53:45 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 23:53:46 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-09 23:53:46 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 23:53:46 --> Final output sent to browser
DEBUG - 2022-03-09 23:53:46 --> Total execution time: 0.0587
ERROR - 2022-03-09 23:53:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 23:53:54 --> Config Class Initialized
INFO - 2022-03-09 23:53:54 --> Hooks Class Initialized
DEBUG - 2022-03-09 23:53:54 --> UTF-8 Support Enabled
INFO - 2022-03-09 23:53:54 --> Utf8 Class Initialized
INFO - 2022-03-09 23:53:54 --> URI Class Initialized
INFO - 2022-03-09 23:53:54 --> Router Class Initialized
INFO - 2022-03-09 23:53:54 --> Output Class Initialized
INFO - 2022-03-09 23:53:54 --> Security Class Initialized
DEBUG - 2022-03-09 23:53:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 23:53:54 --> Input Class Initialized
INFO - 2022-03-09 23:53:54 --> Language Class Initialized
INFO - 2022-03-09 23:53:54 --> Loader Class Initialized
INFO - 2022-03-09 23:53:54 --> Helper loaded: url_helper
INFO - 2022-03-09 23:53:54 --> Helper loaded: form_helper
INFO - 2022-03-09 23:53:54 --> Helper loaded: common_helper
INFO - 2022-03-09 23:53:54 --> Database Driver Class Initialized
DEBUG - 2022-03-09 23:53:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 23:53:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 23:53:54 --> Controller Class Initialized
INFO - 2022-03-09 23:53:54 --> Form Validation Class Initialized
DEBUG - 2022-03-09 23:53:54 --> Encrypt Class Initialized
INFO - 2022-03-09 23:53:54 --> Model "Patient_model" initialized
INFO - 2022-03-09 23:53:54 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 23:53:54 --> Model "Prefix_master" initialized
INFO - 2022-03-09 23:53:54 --> Model "Users_model" initialized
INFO - 2022-03-09 23:53:54 --> Model "Hospital_model" initialized
INFO - 2022-03-09 23:53:55 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-09 23:53:56 --> Final output sent to browser
DEBUG - 2022-03-09 23:53:56 --> Total execution time: 1.6304
ERROR - 2022-03-09 23:54:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 23:54:07 --> Config Class Initialized
INFO - 2022-03-09 23:54:07 --> Hooks Class Initialized
DEBUG - 2022-03-09 23:54:07 --> UTF-8 Support Enabled
INFO - 2022-03-09 23:54:07 --> Utf8 Class Initialized
INFO - 2022-03-09 23:54:07 --> URI Class Initialized
INFO - 2022-03-09 23:54:07 --> Router Class Initialized
INFO - 2022-03-09 23:54:07 --> Output Class Initialized
INFO - 2022-03-09 23:54:07 --> Security Class Initialized
DEBUG - 2022-03-09 23:54:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 23:54:07 --> Input Class Initialized
INFO - 2022-03-09 23:54:07 --> Language Class Initialized
INFO - 2022-03-09 23:54:07 --> Loader Class Initialized
INFO - 2022-03-09 23:54:07 --> Helper loaded: url_helper
INFO - 2022-03-09 23:54:07 --> Helper loaded: form_helper
INFO - 2022-03-09 23:54:07 --> Helper loaded: common_helper
INFO - 2022-03-09 23:54:07 --> Database Driver Class Initialized
DEBUG - 2022-03-09 23:54:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 23:54:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 23:54:07 --> Controller Class Initialized
INFO - 2022-03-09 23:54:07 --> Form Validation Class Initialized
DEBUG - 2022-03-09 23:54:07 --> Encrypt Class Initialized
INFO - 2022-03-09 23:54:07 --> Model "Patient_model" initialized
INFO - 2022-03-09 23:54:07 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 23:54:07 --> Model "Referredby_model" initialized
INFO - 2022-03-09 23:54:07 --> Model "Prefix_master" initialized
INFO - 2022-03-09 23:54:07 --> Model "Hospital_model" initialized
ERROR - 2022-03-09 23:54:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 23:54:07 --> Config Class Initialized
INFO - 2022-03-09 23:54:07 --> Hooks Class Initialized
DEBUG - 2022-03-09 23:54:07 --> UTF-8 Support Enabled
INFO - 2022-03-09 23:54:07 --> Utf8 Class Initialized
INFO - 2022-03-09 23:54:07 --> URI Class Initialized
INFO - 2022-03-09 23:54:07 --> Router Class Initialized
INFO - 2022-03-09 23:54:07 --> Output Class Initialized
INFO - 2022-03-09 23:54:07 --> Security Class Initialized
DEBUG - 2022-03-09 23:54:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 23:54:07 --> Input Class Initialized
INFO - 2022-03-09 23:54:07 --> Language Class Initialized
INFO - 2022-03-09 23:54:07 --> Loader Class Initialized
INFO - 2022-03-09 23:54:07 --> Helper loaded: url_helper
INFO - 2022-03-09 23:54:07 --> Helper loaded: form_helper
INFO - 2022-03-09 23:54:07 --> Helper loaded: common_helper
INFO - 2022-03-09 23:54:07 --> Database Driver Class Initialized
DEBUG - 2022-03-09 23:54:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 23:54:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 23:54:07 --> Controller Class Initialized
INFO - 2022-03-09 23:54:07 --> Form Validation Class Initialized
DEBUG - 2022-03-09 23:54:07 --> Encrypt Class Initialized
INFO - 2022-03-09 23:54:07 --> Model "Patient_model" initialized
INFO - 2022-03-09 23:54:07 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 23:54:07 --> Model "Referredby_model" initialized
INFO - 2022-03-09 23:54:07 --> Model "Prefix_master" initialized
INFO - 2022-03-09 23:54:07 --> Model "Hospital_model" initialized
INFO - 2022-03-09 23:54:07 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 23:54:07 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-09 23:54:07 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 23:54:07 --> Final output sent to browser
DEBUG - 2022-03-09 23:54:07 --> Total execution time: 0.0722
ERROR - 2022-03-09 23:54:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 23:54:08 --> Config Class Initialized
INFO - 2022-03-09 23:54:08 --> Hooks Class Initialized
DEBUG - 2022-03-09 23:54:08 --> UTF-8 Support Enabled
INFO - 2022-03-09 23:54:08 --> Utf8 Class Initialized
INFO - 2022-03-09 23:54:08 --> URI Class Initialized
INFO - 2022-03-09 23:54:08 --> Router Class Initialized
INFO - 2022-03-09 23:54:08 --> Output Class Initialized
INFO - 2022-03-09 23:54:08 --> Security Class Initialized
DEBUG - 2022-03-09 23:54:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 23:54:08 --> Input Class Initialized
INFO - 2022-03-09 23:54:08 --> Language Class Initialized
INFO - 2022-03-09 23:54:08 --> Loader Class Initialized
INFO - 2022-03-09 23:54:08 --> Helper loaded: url_helper
INFO - 2022-03-09 23:54:08 --> Helper loaded: form_helper
INFO - 2022-03-09 23:54:08 --> Helper loaded: common_helper
INFO - 2022-03-09 23:54:08 --> Database Driver Class Initialized
DEBUG - 2022-03-09 23:54:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 23:54:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 23:54:08 --> Controller Class Initialized
INFO - 2022-03-09 23:54:08 --> Form Validation Class Initialized
DEBUG - 2022-03-09 23:54:08 --> Encrypt Class Initialized
INFO - 2022-03-09 23:54:08 --> Model "Patient_model" initialized
INFO - 2022-03-09 23:54:08 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 23:54:08 --> Model "Prefix_master" initialized
INFO - 2022-03-09 23:54:08 --> Model "Users_model" initialized
INFO - 2022-03-09 23:54:08 --> Model "Hospital_model" initialized
INFO - 2022-03-09 23:54:08 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 23:54:08 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-09 23:54:08 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 23:54:08 --> Final output sent to browser
DEBUG - 2022-03-09 23:54:08 --> Total execution time: 0.0807
ERROR - 2022-03-09 23:54:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 23:54:53 --> Config Class Initialized
INFO - 2022-03-09 23:54:53 --> Hooks Class Initialized
DEBUG - 2022-03-09 23:54:53 --> UTF-8 Support Enabled
INFO - 2022-03-09 23:54:53 --> Utf8 Class Initialized
INFO - 2022-03-09 23:54:53 --> URI Class Initialized
INFO - 2022-03-09 23:54:53 --> Router Class Initialized
INFO - 2022-03-09 23:54:53 --> Output Class Initialized
INFO - 2022-03-09 23:54:53 --> Security Class Initialized
DEBUG - 2022-03-09 23:54:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 23:54:53 --> Input Class Initialized
INFO - 2022-03-09 23:54:53 --> Language Class Initialized
INFO - 2022-03-09 23:54:53 --> Loader Class Initialized
INFO - 2022-03-09 23:54:53 --> Helper loaded: url_helper
INFO - 2022-03-09 23:54:53 --> Helper loaded: form_helper
INFO - 2022-03-09 23:54:53 --> Helper loaded: common_helper
INFO - 2022-03-09 23:54:53 --> Database Driver Class Initialized
DEBUG - 2022-03-09 23:54:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 23:54:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 23:54:53 --> Controller Class Initialized
INFO - 2022-03-09 23:54:53 --> Form Validation Class Initialized
DEBUG - 2022-03-09 23:54:53 --> Encrypt Class Initialized
INFO - 2022-03-09 23:54:53 --> Model "Patient_model" initialized
INFO - 2022-03-09 23:54:53 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 23:54:53 --> Model "Prefix_master" initialized
INFO - 2022-03-09 23:54:53 --> Model "Users_model" initialized
INFO - 2022-03-09 23:54:53 --> Model "Hospital_model" initialized
ERROR - 2022-03-09 23:54:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 23:54:53 --> Config Class Initialized
INFO - 2022-03-09 23:54:53 --> Hooks Class Initialized
DEBUG - 2022-03-09 23:54:53 --> UTF-8 Support Enabled
INFO - 2022-03-09 23:54:53 --> Utf8 Class Initialized
INFO - 2022-03-09 23:54:53 --> URI Class Initialized
INFO - 2022-03-09 23:54:53 --> Router Class Initialized
INFO - 2022-03-09 23:54:53 --> Output Class Initialized
INFO - 2022-03-09 23:54:53 --> Security Class Initialized
DEBUG - 2022-03-09 23:54:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 23:54:53 --> Input Class Initialized
INFO - 2022-03-09 23:54:53 --> Language Class Initialized
INFO - 2022-03-09 23:54:53 --> Loader Class Initialized
INFO - 2022-03-09 23:54:53 --> Helper loaded: url_helper
INFO - 2022-03-09 23:54:53 --> Helper loaded: form_helper
INFO - 2022-03-09 23:54:53 --> Helper loaded: common_helper
INFO - 2022-03-09 23:54:53 --> Database Driver Class Initialized
DEBUG - 2022-03-09 23:54:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 23:54:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 23:54:53 --> Controller Class Initialized
INFO - 2022-03-09 23:54:53 --> Form Validation Class Initialized
DEBUG - 2022-03-09 23:54:53 --> Encrypt Class Initialized
INFO - 2022-03-09 23:54:53 --> Model "Patient_model" initialized
INFO - 2022-03-09 23:54:53 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 23:54:53 --> Model "Prefix_master" initialized
INFO - 2022-03-09 23:54:53 --> Model "Users_model" initialized
INFO - 2022-03-09 23:54:53 --> Model "Hospital_model" initialized
INFO - 2022-03-09 23:54:53 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 23:54:53 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-09 23:54:53 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 23:54:53 --> Final output sent to browser
DEBUG - 2022-03-09 23:54:53 --> Total execution time: 0.0625
ERROR - 2022-03-09 23:55:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 23:55:18 --> Config Class Initialized
INFO - 2022-03-09 23:55:18 --> Hooks Class Initialized
DEBUG - 2022-03-09 23:55:18 --> UTF-8 Support Enabled
INFO - 2022-03-09 23:55:18 --> Utf8 Class Initialized
INFO - 2022-03-09 23:55:18 --> URI Class Initialized
INFO - 2022-03-09 23:55:18 --> Router Class Initialized
INFO - 2022-03-09 23:55:18 --> Output Class Initialized
INFO - 2022-03-09 23:55:18 --> Security Class Initialized
DEBUG - 2022-03-09 23:55:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 23:55:18 --> Input Class Initialized
INFO - 2022-03-09 23:55:18 --> Language Class Initialized
INFO - 2022-03-09 23:55:18 --> Loader Class Initialized
INFO - 2022-03-09 23:55:18 --> Helper loaded: url_helper
INFO - 2022-03-09 23:55:19 --> Helper loaded: form_helper
INFO - 2022-03-09 23:55:19 --> Helper loaded: common_helper
INFO - 2022-03-09 23:55:19 --> Database Driver Class Initialized
DEBUG - 2022-03-09 23:55:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 23:55:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 23:55:19 --> Controller Class Initialized
INFO - 2022-03-09 23:55:19 --> Form Validation Class Initialized
DEBUG - 2022-03-09 23:55:19 --> Encrypt Class Initialized
INFO - 2022-03-09 23:55:19 --> Model "Patient_model" initialized
INFO - 2022-03-09 23:55:19 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 23:55:19 --> Model "Prefix_master" initialized
INFO - 2022-03-09 23:55:19 --> Model "Users_model" initialized
INFO - 2022-03-09 23:55:19 --> Model "Hospital_model" initialized
ERROR - 2022-03-09 23:55:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 23:55:19 --> Config Class Initialized
INFO - 2022-03-09 23:55:19 --> Hooks Class Initialized
DEBUG - 2022-03-09 23:55:19 --> UTF-8 Support Enabled
INFO - 2022-03-09 23:55:19 --> Utf8 Class Initialized
INFO - 2022-03-09 23:55:19 --> URI Class Initialized
INFO - 2022-03-09 23:55:19 --> Router Class Initialized
INFO - 2022-03-09 23:55:19 --> Output Class Initialized
INFO - 2022-03-09 23:55:19 --> Security Class Initialized
DEBUG - 2022-03-09 23:55:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 23:55:19 --> Input Class Initialized
INFO - 2022-03-09 23:55:19 --> Language Class Initialized
INFO - 2022-03-09 23:55:19 --> Loader Class Initialized
INFO - 2022-03-09 23:55:19 --> Helper loaded: url_helper
INFO - 2022-03-09 23:55:19 --> Helper loaded: form_helper
INFO - 2022-03-09 23:55:19 --> Helper loaded: common_helper
INFO - 2022-03-09 23:55:19 --> Database Driver Class Initialized
DEBUG - 2022-03-09 23:55:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 23:55:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 23:55:19 --> Controller Class Initialized
INFO - 2022-03-09 23:55:19 --> Form Validation Class Initialized
DEBUG - 2022-03-09 23:55:19 --> Encrypt Class Initialized
INFO - 2022-03-09 23:55:19 --> Model "Patient_model" initialized
INFO - 2022-03-09 23:55:19 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 23:55:19 --> Model "Prefix_master" initialized
INFO - 2022-03-09 23:55:19 --> Model "Users_model" initialized
INFO - 2022-03-09 23:55:19 --> Model "Hospital_model" initialized
INFO - 2022-03-09 23:55:19 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 23:55:19 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-09 23:55:19 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 23:55:19 --> Final output sent to browser
DEBUG - 2022-03-09 23:55:19 --> Total execution time: 0.0652
ERROR - 2022-03-09 23:55:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 23:55:39 --> Config Class Initialized
INFO - 2022-03-09 23:55:39 --> Hooks Class Initialized
DEBUG - 2022-03-09 23:55:39 --> UTF-8 Support Enabled
INFO - 2022-03-09 23:55:39 --> Utf8 Class Initialized
INFO - 2022-03-09 23:55:39 --> URI Class Initialized
INFO - 2022-03-09 23:55:39 --> Router Class Initialized
INFO - 2022-03-09 23:55:39 --> Output Class Initialized
INFO - 2022-03-09 23:55:39 --> Security Class Initialized
DEBUG - 2022-03-09 23:55:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 23:55:39 --> Input Class Initialized
INFO - 2022-03-09 23:55:39 --> Language Class Initialized
INFO - 2022-03-09 23:55:39 --> Loader Class Initialized
INFO - 2022-03-09 23:55:39 --> Helper loaded: url_helper
INFO - 2022-03-09 23:55:39 --> Helper loaded: form_helper
INFO - 2022-03-09 23:55:39 --> Helper loaded: common_helper
INFO - 2022-03-09 23:55:39 --> Database Driver Class Initialized
DEBUG - 2022-03-09 23:55:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 23:55:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 23:55:39 --> Controller Class Initialized
INFO - 2022-03-09 23:55:39 --> Form Validation Class Initialized
DEBUG - 2022-03-09 23:55:39 --> Encrypt Class Initialized
INFO - 2022-03-09 23:55:39 --> Model "Patient_model" initialized
INFO - 2022-03-09 23:55:39 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 23:55:39 --> Model "Prefix_master" initialized
INFO - 2022-03-09 23:55:39 --> Model "Users_model" initialized
INFO - 2022-03-09 23:55:39 --> Model "Hospital_model" initialized
ERROR - 2022-03-09 23:55:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 23:55:40 --> Config Class Initialized
INFO - 2022-03-09 23:55:40 --> Hooks Class Initialized
DEBUG - 2022-03-09 23:55:40 --> UTF-8 Support Enabled
INFO - 2022-03-09 23:55:40 --> Utf8 Class Initialized
INFO - 2022-03-09 23:55:40 --> URI Class Initialized
INFO - 2022-03-09 23:55:40 --> Router Class Initialized
INFO - 2022-03-09 23:55:40 --> Output Class Initialized
INFO - 2022-03-09 23:55:40 --> Security Class Initialized
DEBUG - 2022-03-09 23:55:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 23:55:40 --> Input Class Initialized
INFO - 2022-03-09 23:55:40 --> Language Class Initialized
INFO - 2022-03-09 23:55:40 --> Loader Class Initialized
INFO - 2022-03-09 23:55:40 --> Helper loaded: url_helper
INFO - 2022-03-09 23:55:40 --> Helper loaded: form_helper
INFO - 2022-03-09 23:55:40 --> Helper loaded: common_helper
INFO - 2022-03-09 23:55:40 --> Database Driver Class Initialized
DEBUG - 2022-03-09 23:55:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 23:55:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 23:55:40 --> Controller Class Initialized
INFO - 2022-03-09 23:55:40 --> Form Validation Class Initialized
DEBUG - 2022-03-09 23:55:40 --> Encrypt Class Initialized
INFO - 2022-03-09 23:55:40 --> Model "Patient_model" initialized
INFO - 2022-03-09 23:55:40 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 23:55:40 --> Model "Prefix_master" initialized
INFO - 2022-03-09 23:55:40 --> Model "Users_model" initialized
INFO - 2022-03-09 23:55:40 --> Model "Hospital_model" initialized
INFO - 2022-03-09 23:55:40 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 23:55:40 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-09 23:55:40 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 23:55:40 --> Final output sent to browser
DEBUG - 2022-03-09 23:55:40 --> Total execution time: 0.0641
ERROR - 2022-03-09 23:55:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 23:55:46 --> Config Class Initialized
INFO - 2022-03-09 23:55:46 --> Hooks Class Initialized
DEBUG - 2022-03-09 23:55:46 --> UTF-8 Support Enabled
INFO - 2022-03-09 23:55:46 --> Utf8 Class Initialized
INFO - 2022-03-09 23:55:46 --> URI Class Initialized
INFO - 2022-03-09 23:55:46 --> Router Class Initialized
INFO - 2022-03-09 23:55:46 --> Output Class Initialized
INFO - 2022-03-09 23:55:46 --> Security Class Initialized
DEBUG - 2022-03-09 23:55:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 23:55:46 --> Input Class Initialized
INFO - 2022-03-09 23:55:46 --> Language Class Initialized
INFO - 2022-03-09 23:55:46 --> Loader Class Initialized
INFO - 2022-03-09 23:55:46 --> Helper loaded: url_helper
INFO - 2022-03-09 23:55:46 --> Helper loaded: form_helper
INFO - 2022-03-09 23:55:46 --> Helper loaded: common_helper
INFO - 2022-03-09 23:55:46 --> Database Driver Class Initialized
DEBUG - 2022-03-09 23:55:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 23:55:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 23:55:46 --> Controller Class Initialized
INFO - 2022-03-09 23:55:46 --> Form Validation Class Initialized
DEBUG - 2022-03-09 23:55:46 --> Encrypt Class Initialized
INFO - 2022-03-09 23:55:46 --> Model "Patient_model" initialized
INFO - 2022-03-09 23:55:46 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 23:55:46 --> Model "Referredby_model" initialized
INFO - 2022-03-09 23:55:46 --> Model "Prefix_master" initialized
INFO - 2022-03-09 23:55:46 --> Model "Hospital_model" initialized
INFO - 2022-03-09 23:55:46 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 23:55:51 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-09 23:55:51 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 23:55:53 --> Final output sent to browser
DEBUG - 2022-03-09 23:55:53 --> Total execution time: 5.8145
ERROR - 2022-03-09 23:56:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 23:56:06 --> Config Class Initialized
INFO - 2022-03-09 23:56:06 --> Hooks Class Initialized
DEBUG - 2022-03-09 23:56:06 --> UTF-8 Support Enabled
INFO - 2022-03-09 23:56:06 --> Utf8 Class Initialized
INFO - 2022-03-09 23:56:06 --> URI Class Initialized
INFO - 2022-03-09 23:56:06 --> Router Class Initialized
INFO - 2022-03-09 23:56:06 --> Output Class Initialized
INFO - 2022-03-09 23:56:06 --> Security Class Initialized
DEBUG - 2022-03-09 23:56:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 23:56:06 --> Input Class Initialized
INFO - 2022-03-09 23:56:06 --> Language Class Initialized
INFO - 2022-03-09 23:56:06 --> Loader Class Initialized
INFO - 2022-03-09 23:56:06 --> Helper loaded: url_helper
INFO - 2022-03-09 23:56:06 --> Helper loaded: form_helper
INFO - 2022-03-09 23:56:06 --> Helper loaded: common_helper
INFO - 2022-03-09 23:56:06 --> Database Driver Class Initialized
DEBUG - 2022-03-09 23:56:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 23:56:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 23:56:06 --> Controller Class Initialized
INFO - 2022-03-09 23:56:06 --> Form Validation Class Initialized
DEBUG - 2022-03-09 23:56:06 --> Encrypt Class Initialized
INFO - 2022-03-09 23:56:06 --> Model "Patient_model" initialized
INFO - 2022-03-09 23:56:06 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 23:56:06 --> Model "Prefix_master" initialized
INFO - 2022-03-09 23:56:06 --> Model "Users_model" initialized
INFO - 2022-03-09 23:56:06 --> Model "Hospital_model" initialized
ERROR - 2022-03-09 23:56:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-09 23:56:07 --> Config Class Initialized
INFO - 2022-03-09 23:56:07 --> Hooks Class Initialized
DEBUG - 2022-03-09 23:56:07 --> UTF-8 Support Enabled
INFO - 2022-03-09 23:56:07 --> Utf8 Class Initialized
INFO - 2022-03-09 23:56:07 --> URI Class Initialized
INFO - 2022-03-09 23:56:07 --> Router Class Initialized
INFO - 2022-03-09 23:56:07 --> Output Class Initialized
INFO - 2022-03-09 23:56:07 --> Security Class Initialized
DEBUG - 2022-03-09 23:56:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-09 23:56:07 --> Input Class Initialized
INFO - 2022-03-09 23:56:07 --> Language Class Initialized
INFO - 2022-03-09 23:56:07 --> Loader Class Initialized
INFO - 2022-03-09 23:56:07 --> Helper loaded: url_helper
INFO - 2022-03-09 23:56:07 --> Helper loaded: form_helper
INFO - 2022-03-09 23:56:07 --> Helper loaded: common_helper
INFO - 2022-03-09 23:56:07 --> Database Driver Class Initialized
DEBUG - 2022-03-09 23:56:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-09 23:56:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-09 23:56:07 --> Controller Class Initialized
INFO - 2022-03-09 23:56:07 --> Form Validation Class Initialized
DEBUG - 2022-03-09 23:56:07 --> Encrypt Class Initialized
INFO - 2022-03-09 23:56:07 --> Model "Patient_model" initialized
INFO - 2022-03-09 23:56:07 --> Model "Patientcase_model" initialized
INFO - 2022-03-09 23:56:07 --> Model "Prefix_master" initialized
INFO - 2022-03-09 23:56:07 --> Model "Users_model" initialized
INFO - 2022-03-09 23:56:07 --> Model "Hospital_model" initialized
INFO - 2022-03-09 23:56:07 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-09 23:56:07 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-09 23:56:07 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-09 23:56:07 --> Final output sent to browser
DEBUG - 2022-03-09 23:56:07 --> Total execution time: 0.0556
