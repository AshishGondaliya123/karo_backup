<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-07-12 16:22:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-12 16:22:53 --> Config Class Initialized
INFO - 2021-07-12 16:22:53 --> Hooks Class Initialized
DEBUG - 2021-07-12 16:22:53 --> UTF-8 Support Enabled
INFO - 2021-07-12 16:22:53 --> Utf8 Class Initialized
INFO - 2021-07-12 16:22:53 --> URI Class Initialized
DEBUG - 2021-07-12 16:22:53 --> No URI present. Default controller set.
INFO - 2021-07-12 16:22:53 --> Router Class Initialized
INFO - 2021-07-12 16:22:53 --> Output Class Initialized
INFO - 2021-07-12 16:22:53 --> Security Class Initialized
DEBUG - 2021-07-12 16:22:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 16:22:53 --> Input Class Initialized
INFO - 2021-07-12 16:22:53 --> Language Class Initialized
INFO - 2021-07-12 16:22:53 --> Loader Class Initialized
INFO - 2021-07-12 16:22:53 --> Helper loaded: url_helper
INFO - 2021-07-12 16:22:53 --> Helper loaded: form_helper
INFO - 2021-07-12 16:22:53 --> Helper loaded: common_helper
INFO - 2021-07-12 16:22:53 --> Database Driver Class Initialized
DEBUG - 2021-07-12 16:22:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 16:22:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 16:22:53 --> Controller Class Initialized
INFO - 2021-07-12 16:22:53 --> Form Validation Class Initialized
DEBUG - 2021-07-12 16:22:53 --> Encrypt Class Initialized
DEBUG - 2021-07-12 16:22:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-07-12 16:22:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-07-12 16:22:53 --> Email Class Initialized
INFO - 2021-07-12 16:22:53 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-07-12 16:22:53 --> Calendar Class Initialized
INFO - 2021-07-12 16:22:53 --> Model "Login_model" initialized
INFO - 2021-07-12 16:22:53 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-07-12 16:22:53 --> Final output sent to browser
DEBUG - 2021-07-12 16:22:53 --> Total execution time: 0.0380
