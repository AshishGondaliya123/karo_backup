<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-10-03 09:22:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-03 09:22:30 --> Config Class Initialized
INFO - 2021-10-03 09:22:30 --> Hooks Class Initialized
DEBUG - 2021-10-03 09:22:30 --> UTF-8 Support Enabled
INFO - 2021-10-03 09:22:30 --> Utf8 Class Initialized
INFO - 2021-10-03 09:22:30 --> URI Class Initialized
DEBUG - 2021-10-03 09:22:30 --> No URI present. Default controller set.
INFO - 2021-10-03 09:22:30 --> Router Class Initialized
INFO - 2021-10-03 09:22:30 --> Output Class Initialized
INFO - 2021-10-03 09:22:30 --> Security Class Initialized
DEBUG - 2021-10-03 09:22:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-03 09:22:30 --> Input Class Initialized
INFO - 2021-10-03 09:22:30 --> Language Class Initialized
INFO - 2021-10-03 09:22:30 --> Loader Class Initialized
INFO - 2021-10-03 09:22:30 --> Helper loaded: url_helper
INFO - 2021-10-03 09:22:30 --> Helper loaded: form_helper
INFO - 2021-10-03 09:22:30 --> Helper loaded: common_helper
INFO - 2021-10-03 09:22:30 --> Database Driver Class Initialized
DEBUG - 2021-10-03 09:22:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-03 09:22:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-03 09:22:30 --> Controller Class Initialized
INFO - 2021-10-03 09:22:30 --> Form Validation Class Initialized
DEBUG - 2021-10-03 09:22:30 --> Encrypt Class Initialized
DEBUG - 2021-10-03 09:22:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-10-03 09:22:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-10-03 09:22:30 --> Email Class Initialized
INFO - 2021-10-03 09:22:30 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-10-03 09:22:30 --> Calendar Class Initialized
INFO - 2021-10-03 09:22:30 --> Model "Login_model" initialized
INFO - 2021-10-03 09:22:30 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-10-03 09:22:30 --> Final output sent to browser
DEBUG - 2021-10-03 09:22:30 --> Total execution time: 0.0494
ERROR - 2021-10-03 09:22:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-03 09:22:30 --> Config Class Initialized
INFO - 2021-10-03 09:22:30 --> Hooks Class Initialized
DEBUG - 2021-10-03 09:22:30 --> UTF-8 Support Enabled
INFO - 2021-10-03 09:22:30 --> Utf8 Class Initialized
INFO - 2021-10-03 09:22:30 --> URI Class Initialized
DEBUG - 2021-10-03 09:22:30 --> No URI present. Default controller set.
INFO - 2021-10-03 09:22:30 --> Router Class Initialized
INFO - 2021-10-03 09:22:30 --> Output Class Initialized
INFO - 2021-10-03 09:22:30 --> Security Class Initialized
DEBUG - 2021-10-03 09:22:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-03 09:22:30 --> Input Class Initialized
INFO - 2021-10-03 09:22:30 --> Language Class Initialized
INFO - 2021-10-03 09:22:30 --> Loader Class Initialized
INFO - 2021-10-03 09:22:30 --> Helper loaded: url_helper
INFO - 2021-10-03 09:22:30 --> Helper loaded: form_helper
INFO - 2021-10-03 09:22:30 --> Helper loaded: common_helper
INFO - 2021-10-03 09:22:30 --> Database Driver Class Initialized
DEBUG - 2021-10-03 09:22:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-03 09:22:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-03 09:22:30 --> Controller Class Initialized
INFO - 2021-10-03 09:22:30 --> Form Validation Class Initialized
DEBUG - 2021-10-03 09:22:30 --> Encrypt Class Initialized
DEBUG - 2021-10-03 09:22:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-10-03 09:22:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-10-03 09:22:30 --> Email Class Initialized
INFO - 2021-10-03 09:22:30 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-10-03 09:22:30 --> Calendar Class Initialized
INFO - 2021-10-03 09:22:30 --> Model "Login_model" initialized
INFO - 2021-10-03 09:22:30 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-10-03 09:22:30 --> Final output sent to browser
DEBUG - 2021-10-03 09:22:30 --> Total execution time: 0.0226
ERROR - 2021-10-03 09:22:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-03 09:22:31 --> Config Class Initialized
INFO - 2021-10-03 09:22:31 --> Hooks Class Initialized
DEBUG - 2021-10-03 09:22:31 --> UTF-8 Support Enabled
INFO - 2021-10-03 09:22:31 --> Utf8 Class Initialized
INFO - 2021-10-03 09:22:31 --> URI Class Initialized
INFO - 2021-10-03 09:22:31 --> Router Class Initialized
INFO - 2021-10-03 09:22:31 --> Output Class Initialized
INFO - 2021-10-03 09:22:31 --> Security Class Initialized
DEBUG - 2021-10-03 09:22:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-03 09:22:31 --> Input Class Initialized
INFO - 2021-10-03 09:22:31 --> Language Class Initialized
ERROR - 2021-10-03 09:22:31 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
ERROR - 2021-10-03 09:22:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-03 09:22:31 --> Config Class Initialized
INFO - 2021-10-03 09:22:31 --> Hooks Class Initialized
DEBUG - 2021-10-03 09:22:31 --> UTF-8 Support Enabled
INFO - 2021-10-03 09:22:31 --> Utf8 Class Initialized
INFO - 2021-10-03 09:22:31 --> URI Class Initialized
DEBUG - 2021-10-03 09:22:31 --> No URI present. Default controller set.
INFO - 2021-10-03 09:22:31 --> Router Class Initialized
INFO - 2021-10-03 09:22:31 --> Output Class Initialized
INFO - 2021-10-03 09:22:31 --> Security Class Initialized
DEBUG - 2021-10-03 09:22:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-03 09:22:31 --> Input Class Initialized
INFO - 2021-10-03 09:22:31 --> Language Class Initialized
INFO - 2021-10-03 09:22:31 --> Loader Class Initialized
INFO - 2021-10-03 09:22:31 --> Helper loaded: url_helper
INFO - 2021-10-03 09:22:31 --> Helper loaded: form_helper
INFO - 2021-10-03 09:22:31 --> Helper loaded: common_helper
INFO - 2021-10-03 09:22:31 --> Database Driver Class Initialized
DEBUG - 2021-10-03 09:22:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-03 09:22:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-03 09:22:31 --> Controller Class Initialized
INFO - 2021-10-03 09:22:31 --> Form Validation Class Initialized
DEBUG - 2021-10-03 09:22:31 --> Encrypt Class Initialized
DEBUG - 2021-10-03 09:22:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-10-03 09:22:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-10-03 09:22:31 --> Email Class Initialized
INFO - 2021-10-03 09:22:31 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-10-03 09:22:31 --> Calendar Class Initialized
INFO - 2021-10-03 09:22:31 --> Model "Login_model" initialized
INFO - 2021-10-03 09:22:31 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-10-03 09:22:31 --> Final output sent to browser
DEBUG - 2021-10-03 09:22:31 --> Total execution time: 0.0193
ERROR - 2021-10-03 09:22:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-03 09:22:31 --> Config Class Initialized
INFO - 2021-10-03 09:22:31 --> Hooks Class Initialized
DEBUG - 2021-10-03 09:22:31 --> UTF-8 Support Enabled
INFO - 2021-10-03 09:22:31 --> Utf8 Class Initialized
INFO - 2021-10-03 09:22:31 --> URI Class Initialized
INFO - 2021-10-03 09:22:31 --> Router Class Initialized
INFO - 2021-10-03 09:22:31 --> Output Class Initialized
INFO - 2021-10-03 09:22:31 --> Security Class Initialized
DEBUG - 2021-10-03 09:22:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-03 09:22:31 --> Input Class Initialized
INFO - 2021-10-03 09:22:31 --> Language Class Initialized
ERROR - 2021-10-03 09:22:31 --> 404 Page Not Found: Blog/wp-includes
ERROR - 2021-10-03 09:22:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-03 09:22:32 --> Config Class Initialized
INFO - 2021-10-03 09:22:32 --> Hooks Class Initialized
DEBUG - 2021-10-03 09:22:32 --> UTF-8 Support Enabled
INFO - 2021-10-03 09:22:32 --> Utf8 Class Initialized
INFO - 2021-10-03 09:22:32 --> URI Class Initialized
INFO - 2021-10-03 09:22:32 --> Router Class Initialized
INFO - 2021-10-03 09:22:32 --> Output Class Initialized
INFO - 2021-10-03 09:22:32 --> Security Class Initialized
DEBUG - 2021-10-03 09:22:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-03 09:22:32 --> Input Class Initialized
INFO - 2021-10-03 09:22:32 --> Language Class Initialized
ERROR - 2021-10-03 09:22:32 --> 404 Page Not Found: Web/wp-includes
ERROR - 2021-10-03 09:22:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-03 09:22:32 --> Config Class Initialized
INFO - 2021-10-03 09:22:32 --> Hooks Class Initialized
DEBUG - 2021-10-03 09:22:32 --> UTF-8 Support Enabled
INFO - 2021-10-03 09:22:32 --> Utf8 Class Initialized
INFO - 2021-10-03 09:22:32 --> URI Class Initialized
INFO - 2021-10-03 09:22:32 --> Router Class Initialized
INFO - 2021-10-03 09:22:32 --> Output Class Initialized
INFO - 2021-10-03 09:22:32 --> Security Class Initialized
DEBUG - 2021-10-03 09:22:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-03 09:22:32 --> Input Class Initialized
INFO - 2021-10-03 09:22:32 --> Language Class Initialized
ERROR - 2021-10-03 09:22:32 --> 404 Page Not Found: Wordpress/wp-includes
ERROR - 2021-10-03 09:22:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-03 09:22:32 --> Config Class Initialized
INFO - 2021-10-03 09:22:32 --> Hooks Class Initialized
DEBUG - 2021-10-03 09:22:32 --> UTF-8 Support Enabled
INFO - 2021-10-03 09:22:32 --> Utf8 Class Initialized
INFO - 2021-10-03 09:22:32 --> URI Class Initialized
INFO - 2021-10-03 09:22:32 --> Router Class Initialized
INFO - 2021-10-03 09:22:32 --> Output Class Initialized
INFO - 2021-10-03 09:22:32 --> Security Class Initialized
DEBUG - 2021-10-03 09:22:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-03 09:22:32 --> Input Class Initialized
INFO - 2021-10-03 09:22:32 --> Language Class Initialized
ERROR - 2021-10-03 09:22:32 --> 404 Page Not Found: Website/wp-includes
ERROR - 2021-10-03 09:22:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-03 09:22:33 --> Config Class Initialized
INFO - 2021-10-03 09:22:33 --> Hooks Class Initialized
DEBUG - 2021-10-03 09:22:33 --> UTF-8 Support Enabled
INFO - 2021-10-03 09:22:33 --> Utf8 Class Initialized
INFO - 2021-10-03 09:22:33 --> URI Class Initialized
INFO - 2021-10-03 09:22:33 --> Router Class Initialized
INFO - 2021-10-03 09:22:33 --> Output Class Initialized
INFO - 2021-10-03 09:22:33 --> Security Class Initialized
DEBUG - 2021-10-03 09:22:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-03 09:22:33 --> Input Class Initialized
INFO - 2021-10-03 09:22:33 --> Language Class Initialized
ERROR - 2021-10-03 09:22:33 --> 404 Page Not Found: Wp/wp-includes
ERROR - 2021-10-03 09:22:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-03 09:22:33 --> Config Class Initialized
INFO - 2021-10-03 09:22:33 --> Hooks Class Initialized
DEBUG - 2021-10-03 09:22:33 --> UTF-8 Support Enabled
INFO - 2021-10-03 09:22:33 --> Utf8 Class Initialized
INFO - 2021-10-03 09:22:33 --> URI Class Initialized
INFO - 2021-10-03 09:22:33 --> Router Class Initialized
INFO - 2021-10-03 09:22:33 --> Output Class Initialized
INFO - 2021-10-03 09:22:33 --> Security Class Initialized
DEBUG - 2021-10-03 09:22:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-03 09:22:33 --> Input Class Initialized
INFO - 2021-10-03 09:22:33 --> Language Class Initialized
ERROR - 2021-10-03 09:22:33 --> 404 Page Not Found: News/wp-includes
ERROR - 2021-10-03 09:22:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-03 09:22:33 --> Config Class Initialized
INFO - 2021-10-03 09:22:33 --> Hooks Class Initialized
DEBUG - 2021-10-03 09:22:33 --> UTF-8 Support Enabled
INFO - 2021-10-03 09:22:33 --> Utf8 Class Initialized
INFO - 2021-10-03 09:22:33 --> URI Class Initialized
INFO - 2021-10-03 09:22:33 --> Router Class Initialized
INFO - 2021-10-03 09:22:33 --> Output Class Initialized
INFO - 2021-10-03 09:22:33 --> Security Class Initialized
DEBUG - 2021-10-03 09:22:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-03 09:22:33 --> Input Class Initialized
INFO - 2021-10-03 09:22:33 --> Language Class Initialized
ERROR - 2021-10-03 09:22:33 --> 404 Page Not Found: 2018/wp-includes
ERROR - 2021-10-03 09:22:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-03 09:22:33 --> Config Class Initialized
INFO - 2021-10-03 09:22:33 --> Hooks Class Initialized
DEBUG - 2021-10-03 09:22:33 --> UTF-8 Support Enabled
INFO - 2021-10-03 09:22:33 --> Utf8 Class Initialized
INFO - 2021-10-03 09:22:33 --> URI Class Initialized
INFO - 2021-10-03 09:22:33 --> Router Class Initialized
INFO - 2021-10-03 09:22:33 --> Output Class Initialized
INFO - 2021-10-03 09:22:33 --> Security Class Initialized
DEBUG - 2021-10-03 09:22:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-03 09:22:33 --> Input Class Initialized
INFO - 2021-10-03 09:22:33 --> Language Class Initialized
ERROR - 2021-10-03 09:22:33 --> 404 Page Not Found: 2019/wp-includes
ERROR - 2021-10-03 09:22:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-03 09:22:34 --> Config Class Initialized
INFO - 2021-10-03 09:22:34 --> Hooks Class Initialized
DEBUG - 2021-10-03 09:22:34 --> UTF-8 Support Enabled
INFO - 2021-10-03 09:22:34 --> Utf8 Class Initialized
INFO - 2021-10-03 09:22:34 --> URI Class Initialized
INFO - 2021-10-03 09:22:34 --> Router Class Initialized
INFO - 2021-10-03 09:22:34 --> Output Class Initialized
INFO - 2021-10-03 09:22:34 --> Security Class Initialized
DEBUG - 2021-10-03 09:22:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-03 09:22:34 --> Input Class Initialized
INFO - 2021-10-03 09:22:34 --> Language Class Initialized
ERROR - 2021-10-03 09:22:34 --> 404 Page Not Found: Shop/wp-includes
ERROR - 2021-10-03 09:22:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-03 09:22:34 --> Config Class Initialized
INFO - 2021-10-03 09:22:34 --> Hooks Class Initialized
DEBUG - 2021-10-03 09:22:34 --> UTF-8 Support Enabled
INFO - 2021-10-03 09:22:34 --> Utf8 Class Initialized
INFO - 2021-10-03 09:22:34 --> URI Class Initialized
INFO - 2021-10-03 09:22:34 --> Router Class Initialized
INFO - 2021-10-03 09:22:34 --> Output Class Initialized
INFO - 2021-10-03 09:22:34 --> Security Class Initialized
DEBUG - 2021-10-03 09:22:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-03 09:22:34 --> Input Class Initialized
INFO - 2021-10-03 09:22:34 --> Language Class Initialized
ERROR - 2021-10-03 09:22:34 --> 404 Page Not Found: Wp1/wp-includes
ERROR - 2021-10-03 09:22:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-03 09:22:34 --> Config Class Initialized
INFO - 2021-10-03 09:22:34 --> Hooks Class Initialized
DEBUG - 2021-10-03 09:22:34 --> UTF-8 Support Enabled
INFO - 2021-10-03 09:22:34 --> Utf8 Class Initialized
INFO - 2021-10-03 09:22:34 --> URI Class Initialized
INFO - 2021-10-03 09:22:34 --> Router Class Initialized
INFO - 2021-10-03 09:22:34 --> Output Class Initialized
INFO - 2021-10-03 09:22:34 --> Security Class Initialized
DEBUG - 2021-10-03 09:22:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-03 09:22:34 --> Input Class Initialized
INFO - 2021-10-03 09:22:34 --> Language Class Initialized
ERROR - 2021-10-03 09:22:34 --> 404 Page Not Found: Test/wp-includes
ERROR - 2021-10-03 09:22:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-03 09:22:35 --> Config Class Initialized
INFO - 2021-10-03 09:22:35 --> Hooks Class Initialized
DEBUG - 2021-10-03 09:22:35 --> UTF-8 Support Enabled
INFO - 2021-10-03 09:22:35 --> Utf8 Class Initialized
INFO - 2021-10-03 09:22:35 --> URI Class Initialized
INFO - 2021-10-03 09:22:35 --> Router Class Initialized
INFO - 2021-10-03 09:22:35 --> Output Class Initialized
INFO - 2021-10-03 09:22:35 --> Security Class Initialized
DEBUG - 2021-10-03 09:22:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-03 09:22:35 --> Input Class Initialized
INFO - 2021-10-03 09:22:35 --> Language Class Initialized
ERROR - 2021-10-03 09:22:35 --> 404 Page Not Found: Media/wp-includes
ERROR - 2021-10-03 09:22:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-03 09:22:35 --> Config Class Initialized
INFO - 2021-10-03 09:22:35 --> Hooks Class Initialized
DEBUG - 2021-10-03 09:22:35 --> UTF-8 Support Enabled
INFO - 2021-10-03 09:22:35 --> Utf8 Class Initialized
INFO - 2021-10-03 09:22:35 --> URI Class Initialized
INFO - 2021-10-03 09:22:35 --> Router Class Initialized
INFO - 2021-10-03 09:22:35 --> Output Class Initialized
INFO - 2021-10-03 09:22:35 --> Security Class Initialized
DEBUG - 2021-10-03 09:22:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-03 09:22:35 --> Input Class Initialized
INFO - 2021-10-03 09:22:35 --> Language Class Initialized
ERROR - 2021-10-03 09:22:35 --> 404 Page Not Found: Wp2/wp-includes
ERROR - 2021-10-03 09:22:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-03 09:22:35 --> Config Class Initialized
INFO - 2021-10-03 09:22:35 --> Hooks Class Initialized
DEBUG - 2021-10-03 09:22:35 --> UTF-8 Support Enabled
INFO - 2021-10-03 09:22:35 --> Utf8 Class Initialized
INFO - 2021-10-03 09:22:35 --> URI Class Initialized
INFO - 2021-10-03 09:22:35 --> Router Class Initialized
INFO - 2021-10-03 09:22:35 --> Output Class Initialized
INFO - 2021-10-03 09:22:35 --> Security Class Initialized
DEBUG - 2021-10-03 09:22:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-03 09:22:35 --> Input Class Initialized
INFO - 2021-10-03 09:22:35 --> Language Class Initialized
ERROR - 2021-10-03 09:22:35 --> 404 Page Not Found: Site/wp-includes
ERROR - 2021-10-03 09:22:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-03 09:22:35 --> Config Class Initialized
INFO - 2021-10-03 09:22:35 --> Hooks Class Initialized
DEBUG - 2021-10-03 09:22:35 --> UTF-8 Support Enabled
INFO - 2021-10-03 09:22:35 --> Utf8 Class Initialized
INFO - 2021-10-03 09:22:35 --> URI Class Initialized
INFO - 2021-10-03 09:22:35 --> Router Class Initialized
INFO - 2021-10-03 09:22:35 --> Output Class Initialized
INFO - 2021-10-03 09:22:35 --> Security Class Initialized
DEBUG - 2021-10-03 09:22:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-03 09:22:35 --> Input Class Initialized
INFO - 2021-10-03 09:22:35 --> Language Class Initialized
ERROR - 2021-10-03 09:22:35 --> 404 Page Not Found: Cms/wp-includes
ERROR - 2021-10-03 09:22:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-03 09:22:36 --> Config Class Initialized
INFO - 2021-10-03 09:22:36 --> Hooks Class Initialized
DEBUG - 2021-10-03 09:22:36 --> UTF-8 Support Enabled
INFO - 2021-10-03 09:22:36 --> Utf8 Class Initialized
INFO - 2021-10-03 09:22:36 --> URI Class Initialized
INFO - 2021-10-03 09:22:36 --> Router Class Initialized
INFO - 2021-10-03 09:22:36 --> Output Class Initialized
INFO - 2021-10-03 09:22:36 --> Security Class Initialized
DEBUG - 2021-10-03 09:22:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-03 09:22:36 --> Input Class Initialized
INFO - 2021-10-03 09:22:36 --> Language Class Initialized
ERROR - 2021-10-03 09:22:36 --> 404 Page Not Found: Sito/wp-includes
ERROR - 2021-10-03 12:59:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-03 12:59:07 --> Config Class Initialized
INFO - 2021-10-03 12:59:07 --> Hooks Class Initialized
DEBUG - 2021-10-03 12:59:07 --> UTF-8 Support Enabled
INFO - 2021-10-03 12:59:07 --> Utf8 Class Initialized
INFO - 2021-10-03 12:59:07 --> URI Class Initialized
DEBUG - 2021-10-03 12:59:07 --> No URI present. Default controller set.
INFO - 2021-10-03 12:59:07 --> Router Class Initialized
INFO - 2021-10-03 12:59:07 --> Output Class Initialized
INFO - 2021-10-03 12:59:07 --> Security Class Initialized
DEBUG - 2021-10-03 12:59:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-03 12:59:07 --> Input Class Initialized
INFO - 2021-10-03 12:59:07 --> Language Class Initialized
INFO - 2021-10-03 12:59:07 --> Loader Class Initialized
INFO - 2021-10-03 12:59:07 --> Helper loaded: url_helper
INFO - 2021-10-03 12:59:07 --> Helper loaded: form_helper
INFO - 2021-10-03 12:59:07 --> Helper loaded: common_helper
INFO - 2021-10-03 12:59:07 --> Database Driver Class Initialized
DEBUG - 2021-10-03 12:59:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-03 12:59:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-03 12:59:07 --> Controller Class Initialized
INFO - 2021-10-03 12:59:07 --> Form Validation Class Initialized
DEBUG - 2021-10-03 12:59:07 --> Encrypt Class Initialized
DEBUG - 2021-10-03 12:59:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-10-03 12:59:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-10-03 12:59:07 --> Email Class Initialized
INFO - 2021-10-03 12:59:07 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-10-03 12:59:07 --> Calendar Class Initialized
INFO - 2021-10-03 12:59:07 --> Model "Login_model" initialized
INFO - 2021-10-03 12:59:07 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-10-03 12:59:07 --> Final output sent to browser
DEBUG - 2021-10-03 12:59:07 --> Total execution time: 0.1231
ERROR - 2021-10-03 13:27:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-03 13:27:47 --> Config Class Initialized
INFO - 2021-10-03 13:27:47 --> Hooks Class Initialized
DEBUG - 2021-10-03 13:27:47 --> UTF-8 Support Enabled
INFO - 2021-10-03 13:27:47 --> Utf8 Class Initialized
INFO - 2021-10-03 13:27:47 --> URI Class Initialized
DEBUG - 2021-10-03 13:27:47 --> No URI present. Default controller set.
INFO - 2021-10-03 13:27:47 --> Router Class Initialized
INFO - 2021-10-03 13:27:47 --> Output Class Initialized
INFO - 2021-10-03 13:27:47 --> Security Class Initialized
DEBUG - 2021-10-03 13:27:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-03 13:27:47 --> Input Class Initialized
INFO - 2021-10-03 13:27:47 --> Language Class Initialized
INFO - 2021-10-03 13:27:47 --> Loader Class Initialized
INFO - 2021-10-03 13:27:47 --> Helper loaded: url_helper
INFO - 2021-10-03 13:27:47 --> Helper loaded: form_helper
INFO - 2021-10-03 13:27:47 --> Helper loaded: common_helper
INFO - 2021-10-03 13:27:47 --> Database Driver Class Initialized
DEBUG - 2021-10-03 13:27:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-03 13:27:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-03 13:27:47 --> Controller Class Initialized
INFO - 2021-10-03 13:27:47 --> Form Validation Class Initialized
DEBUG - 2021-10-03 13:27:47 --> Encrypt Class Initialized
DEBUG - 2021-10-03 13:27:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-10-03 13:27:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-10-03 13:27:47 --> Email Class Initialized
INFO - 2021-10-03 13:27:47 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-10-03 13:27:47 --> Calendar Class Initialized
INFO - 2021-10-03 13:27:47 --> Model "Login_model" initialized
INFO - 2021-10-03 13:27:47 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-10-03 13:27:47 --> Final output sent to browser
DEBUG - 2021-10-03 13:27:47 --> Total execution time: 0.0376
ERROR - 2021-10-03 13:27:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-03 13:27:48 --> Config Class Initialized
INFO - 2021-10-03 13:27:48 --> Hooks Class Initialized
DEBUG - 2021-10-03 13:27:48 --> UTF-8 Support Enabled
INFO - 2021-10-03 13:27:48 --> Utf8 Class Initialized
INFO - 2021-10-03 13:27:48 --> URI Class Initialized
DEBUG - 2021-10-03 13:27:48 --> No URI present. Default controller set.
INFO - 2021-10-03 13:27:48 --> Router Class Initialized
INFO - 2021-10-03 13:27:48 --> Output Class Initialized
INFO - 2021-10-03 13:27:48 --> Security Class Initialized
DEBUG - 2021-10-03 13:27:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-03 13:27:48 --> Input Class Initialized
INFO - 2021-10-03 13:27:48 --> Language Class Initialized
INFO - 2021-10-03 13:27:48 --> Loader Class Initialized
INFO - 2021-10-03 13:27:48 --> Helper loaded: url_helper
INFO - 2021-10-03 13:27:48 --> Helper loaded: form_helper
INFO - 2021-10-03 13:27:48 --> Helper loaded: common_helper
INFO - 2021-10-03 13:27:48 --> Database Driver Class Initialized
DEBUG - 2021-10-03 13:27:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-03 13:27:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-03 13:27:48 --> Controller Class Initialized
INFO - 2021-10-03 13:27:48 --> Form Validation Class Initialized
DEBUG - 2021-10-03 13:27:48 --> Encrypt Class Initialized
DEBUG - 2021-10-03 13:27:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-10-03 13:27:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-10-03 13:27:48 --> Email Class Initialized
INFO - 2021-10-03 13:27:48 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-10-03 13:27:48 --> Calendar Class Initialized
INFO - 2021-10-03 13:27:48 --> Model "Login_model" initialized
INFO - 2021-10-03 13:27:48 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-10-03 13:27:48 --> Final output sent to browser
DEBUG - 2021-10-03 13:27:48 --> Total execution time: 0.0188
ERROR - 2021-10-03 13:27:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-03 13:27:48 --> Config Class Initialized
INFO - 2021-10-03 13:27:48 --> Hooks Class Initialized
DEBUG - 2021-10-03 13:27:48 --> UTF-8 Support Enabled
INFO - 2021-10-03 13:27:48 --> Utf8 Class Initialized
INFO - 2021-10-03 13:27:48 --> URI Class Initialized
INFO - 2021-10-03 13:27:48 --> Router Class Initialized
INFO - 2021-10-03 13:27:48 --> Output Class Initialized
INFO - 2021-10-03 13:27:48 --> Security Class Initialized
DEBUG - 2021-10-03 13:27:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-03 13:27:48 --> Input Class Initialized
INFO - 2021-10-03 13:27:48 --> Language Class Initialized
ERROR - 2021-10-03 13:27:48 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
ERROR - 2021-10-03 13:27:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-03 13:27:49 --> Config Class Initialized
INFO - 2021-10-03 13:27:49 --> Hooks Class Initialized
DEBUG - 2021-10-03 13:27:49 --> UTF-8 Support Enabled
INFO - 2021-10-03 13:27:49 --> Utf8 Class Initialized
INFO - 2021-10-03 13:27:49 --> URI Class Initialized
DEBUG - 2021-10-03 13:27:49 --> No URI present. Default controller set.
INFO - 2021-10-03 13:27:49 --> Router Class Initialized
INFO - 2021-10-03 13:27:49 --> Output Class Initialized
INFO - 2021-10-03 13:27:49 --> Security Class Initialized
DEBUG - 2021-10-03 13:27:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-03 13:27:49 --> Input Class Initialized
INFO - 2021-10-03 13:27:49 --> Language Class Initialized
INFO - 2021-10-03 13:27:49 --> Loader Class Initialized
INFO - 2021-10-03 13:27:49 --> Helper loaded: url_helper
INFO - 2021-10-03 13:27:49 --> Helper loaded: form_helper
INFO - 2021-10-03 13:27:49 --> Helper loaded: common_helper
INFO - 2021-10-03 13:27:49 --> Database Driver Class Initialized
DEBUG - 2021-10-03 13:27:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-03 13:27:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-03 13:27:49 --> Controller Class Initialized
INFO - 2021-10-03 13:27:49 --> Form Validation Class Initialized
DEBUG - 2021-10-03 13:27:49 --> Encrypt Class Initialized
DEBUG - 2021-10-03 13:27:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-10-03 13:27:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-10-03 13:27:49 --> Email Class Initialized
INFO - 2021-10-03 13:27:49 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-10-03 13:27:49 --> Calendar Class Initialized
INFO - 2021-10-03 13:27:49 --> Model "Login_model" initialized
INFO - 2021-10-03 13:27:49 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-10-03 13:27:49 --> Final output sent to browser
DEBUG - 2021-10-03 13:27:49 --> Total execution time: 0.0329
ERROR - 2021-10-03 13:27:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-03 13:27:49 --> Config Class Initialized
INFO - 2021-10-03 13:27:49 --> Hooks Class Initialized
DEBUG - 2021-10-03 13:27:49 --> UTF-8 Support Enabled
INFO - 2021-10-03 13:27:49 --> Utf8 Class Initialized
INFO - 2021-10-03 13:27:49 --> URI Class Initialized
INFO - 2021-10-03 13:27:49 --> Router Class Initialized
INFO - 2021-10-03 13:27:49 --> Output Class Initialized
INFO - 2021-10-03 13:27:49 --> Security Class Initialized
DEBUG - 2021-10-03 13:27:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-03 13:27:49 --> Input Class Initialized
INFO - 2021-10-03 13:27:49 --> Language Class Initialized
ERROR - 2021-10-03 13:27:49 --> 404 Page Not Found: Blog/wp-includes
ERROR - 2021-10-03 13:27:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-03 13:27:50 --> Config Class Initialized
INFO - 2021-10-03 13:27:50 --> Hooks Class Initialized
DEBUG - 2021-10-03 13:27:50 --> UTF-8 Support Enabled
INFO - 2021-10-03 13:27:50 --> Utf8 Class Initialized
INFO - 2021-10-03 13:27:50 --> URI Class Initialized
INFO - 2021-10-03 13:27:50 --> Router Class Initialized
INFO - 2021-10-03 13:27:50 --> Output Class Initialized
INFO - 2021-10-03 13:27:50 --> Security Class Initialized
DEBUG - 2021-10-03 13:27:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-03 13:27:50 --> Input Class Initialized
INFO - 2021-10-03 13:27:50 --> Language Class Initialized
ERROR - 2021-10-03 13:27:50 --> 404 Page Not Found: Web/wp-includes
ERROR - 2021-10-03 13:27:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-03 13:27:51 --> Config Class Initialized
INFO - 2021-10-03 13:27:51 --> Hooks Class Initialized
DEBUG - 2021-10-03 13:27:51 --> UTF-8 Support Enabled
INFO - 2021-10-03 13:27:51 --> Utf8 Class Initialized
INFO - 2021-10-03 13:27:51 --> URI Class Initialized
INFO - 2021-10-03 13:27:51 --> Router Class Initialized
INFO - 2021-10-03 13:27:51 --> Output Class Initialized
INFO - 2021-10-03 13:27:51 --> Security Class Initialized
DEBUG - 2021-10-03 13:27:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-03 13:27:51 --> Input Class Initialized
INFO - 2021-10-03 13:27:51 --> Language Class Initialized
ERROR - 2021-10-03 13:27:51 --> 404 Page Not Found: Wordpress/wp-includes
ERROR - 2021-10-03 13:27:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-03 13:27:51 --> Config Class Initialized
INFO - 2021-10-03 13:27:51 --> Hooks Class Initialized
DEBUG - 2021-10-03 13:27:51 --> UTF-8 Support Enabled
INFO - 2021-10-03 13:27:51 --> Utf8 Class Initialized
INFO - 2021-10-03 13:27:51 --> URI Class Initialized
INFO - 2021-10-03 13:27:51 --> Router Class Initialized
INFO - 2021-10-03 13:27:51 --> Output Class Initialized
INFO - 2021-10-03 13:27:51 --> Security Class Initialized
DEBUG - 2021-10-03 13:27:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-03 13:27:51 --> Input Class Initialized
INFO - 2021-10-03 13:27:51 --> Language Class Initialized
ERROR - 2021-10-03 13:27:51 --> 404 Page Not Found: Website/wp-includes
ERROR - 2021-10-03 13:27:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-03 13:27:51 --> Config Class Initialized
INFO - 2021-10-03 13:27:51 --> Hooks Class Initialized
DEBUG - 2021-10-03 13:27:51 --> UTF-8 Support Enabled
INFO - 2021-10-03 13:27:51 --> Utf8 Class Initialized
INFO - 2021-10-03 13:27:51 --> URI Class Initialized
INFO - 2021-10-03 13:27:51 --> Router Class Initialized
INFO - 2021-10-03 13:27:51 --> Output Class Initialized
INFO - 2021-10-03 13:27:51 --> Security Class Initialized
DEBUG - 2021-10-03 13:27:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-03 13:27:51 --> Input Class Initialized
INFO - 2021-10-03 13:27:51 --> Language Class Initialized
ERROR - 2021-10-03 13:27:51 --> 404 Page Not Found: Wp/wp-includes
ERROR - 2021-10-03 13:27:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-03 13:27:52 --> Config Class Initialized
INFO - 2021-10-03 13:27:52 --> Hooks Class Initialized
DEBUG - 2021-10-03 13:27:52 --> UTF-8 Support Enabled
INFO - 2021-10-03 13:27:52 --> Utf8 Class Initialized
INFO - 2021-10-03 13:27:52 --> URI Class Initialized
INFO - 2021-10-03 13:27:52 --> Router Class Initialized
INFO - 2021-10-03 13:27:52 --> Output Class Initialized
INFO - 2021-10-03 13:27:52 --> Security Class Initialized
DEBUG - 2021-10-03 13:27:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-03 13:27:52 --> Input Class Initialized
INFO - 2021-10-03 13:27:52 --> Language Class Initialized
ERROR - 2021-10-03 13:27:52 --> 404 Page Not Found: News/wp-includes
ERROR - 2021-10-03 13:27:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-03 13:27:52 --> Config Class Initialized
INFO - 2021-10-03 13:27:52 --> Hooks Class Initialized
DEBUG - 2021-10-03 13:27:52 --> UTF-8 Support Enabled
INFO - 2021-10-03 13:27:52 --> Utf8 Class Initialized
INFO - 2021-10-03 13:27:52 --> URI Class Initialized
INFO - 2021-10-03 13:27:52 --> Router Class Initialized
INFO - 2021-10-03 13:27:52 --> Output Class Initialized
INFO - 2021-10-03 13:27:52 --> Security Class Initialized
DEBUG - 2021-10-03 13:27:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-03 13:27:52 --> Input Class Initialized
INFO - 2021-10-03 13:27:52 --> Language Class Initialized
ERROR - 2021-10-03 13:27:52 --> 404 Page Not Found: 2018/wp-includes
ERROR - 2021-10-03 13:27:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-03 13:27:53 --> Config Class Initialized
INFO - 2021-10-03 13:27:53 --> Hooks Class Initialized
DEBUG - 2021-10-03 13:27:53 --> UTF-8 Support Enabled
INFO - 2021-10-03 13:27:53 --> Utf8 Class Initialized
INFO - 2021-10-03 13:27:53 --> URI Class Initialized
INFO - 2021-10-03 13:27:53 --> Router Class Initialized
INFO - 2021-10-03 13:27:53 --> Output Class Initialized
INFO - 2021-10-03 13:27:53 --> Security Class Initialized
DEBUG - 2021-10-03 13:27:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-03 13:27:53 --> Input Class Initialized
INFO - 2021-10-03 13:27:53 --> Language Class Initialized
ERROR - 2021-10-03 13:27:53 --> 404 Page Not Found: 2019/wp-includes
ERROR - 2021-10-03 13:27:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-03 13:27:53 --> Config Class Initialized
INFO - 2021-10-03 13:27:53 --> Hooks Class Initialized
DEBUG - 2021-10-03 13:27:53 --> UTF-8 Support Enabled
INFO - 2021-10-03 13:27:53 --> Utf8 Class Initialized
INFO - 2021-10-03 13:27:53 --> URI Class Initialized
INFO - 2021-10-03 13:27:53 --> Router Class Initialized
INFO - 2021-10-03 13:27:53 --> Output Class Initialized
INFO - 2021-10-03 13:27:53 --> Security Class Initialized
DEBUG - 2021-10-03 13:27:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-03 13:27:53 --> Input Class Initialized
INFO - 2021-10-03 13:27:53 --> Language Class Initialized
ERROR - 2021-10-03 13:27:53 --> 404 Page Not Found: Shop/wp-includes
ERROR - 2021-10-03 13:27:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-03 13:27:53 --> Config Class Initialized
INFO - 2021-10-03 13:27:53 --> Hooks Class Initialized
DEBUG - 2021-10-03 13:27:53 --> UTF-8 Support Enabled
INFO - 2021-10-03 13:27:53 --> Utf8 Class Initialized
INFO - 2021-10-03 13:27:53 --> URI Class Initialized
INFO - 2021-10-03 13:27:53 --> Router Class Initialized
INFO - 2021-10-03 13:27:53 --> Output Class Initialized
INFO - 2021-10-03 13:27:53 --> Security Class Initialized
DEBUG - 2021-10-03 13:27:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-03 13:27:53 --> Input Class Initialized
INFO - 2021-10-03 13:27:53 --> Language Class Initialized
ERROR - 2021-10-03 13:27:53 --> 404 Page Not Found: Wp1/wp-includes
ERROR - 2021-10-03 13:27:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-03 13:27:54 --> Config Class Initialized
INFO - 2021-10-03 13:27:54 --> Hooks Class Initialized
DEBUG - 2021-10-03 13:27:54 --> UTF-8 Support Enabled
INFO - 2021-10-03 13:27:54 --> Utf8 Class Initialized
INFO - 2021-10-03 13:27:54 --> URI Class Initialized
INFO - 2021-10-03 13:27:54 --> Router Class Initialized
INFO - 2021-10-03 13:27:54 --> Output Class Initialized
INFO - 2021-10-03 13:27:54 --> Security Class Initialized
DEBUG - 2021-10-03 13:27:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-03 13:27:54 --> Input Class Initialized
INFO - 2021-10-03 13:27:54 --> Language Class Initialized
ERROR - 2021-10-03 13:27:54 --> 404 Page Not Found: Test/wp-includes
ERROR - 2021-10-03 13:27:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-03 13:27:54 --> Config Class Initialized
INFO - 2021-10-03 13:27:54 --> Hooks Class Initialized
DEBUG - 2021-10-03 13:27:54 --> UTF-8 Support Enabled
INFO - 2021-10-03 13:27:54 --> Utf8 Class Initialized
INFO - 2021-10-03 13:27:54 --> URI Class Initialized
INFO - 2021-10-03 13:27:54 --> Router Class Initialized
INFO - 2021-10-03 13:27:54 --> Output Class Initialized
INFO - 2021-10-03 13:27:54 --> Security Class Initialized
DEBUG - 2021-10-03 13:27:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-03 13:27:54 --> Input Class Initialized
INFO - 2021-10-03 13:27:54 --> Language Class Initialized
ERROR - 2021-10-03 13:27:54 --> 404 Page Not Found: Media/wp-includes
ERROR - 2021-10-03 13:27:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-03 13:27:55 --> Config Class Initialized
INFO - 2021-10-03 13:27:55 --> Hooks Class Initialized
DEBUG - 2021-10-03 13:27:55 --> UTF-8 Support Enabled
INFO - 2021-10-03 13:27:55 --> Utf8 Class Initialized
INFO - 2021-10-03 13:27:55 --> URI Class Initialized
INFO - 2021-10-03 13:27:55 --> Router Class Initialized
INFO - 2021-10-03 13:27:55 --> Output Class Initialized
INFO - 2021-10-03 13:27:55 --> Security Class Initialized
DEBUG - 2021-10-03 13:27:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-03 13:27:55 --> Input Class Initialized
INFO - 2021-10-03 13:27:55 --> Language Class Initialized
ERROR - 2021-10-03 13:27:55 --> 404 Page Not Found: Wp2/wp-includes
ERROR - 2021-10-03 13:27:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-03 13:27:55 --> Config Class Initialized
INFO - 2021-10-03 13:27:55 --> Hooks Class Initialized
DEBUG - 2021-10-03 13:27:55 --> UTF-8 Support Enabled
INFO - 2021-10-03 13:27:55 --> Utf8 Class Initialized
INFO - 2021-10-03 13:27:55 --> URI Class Initialized
INFO - 2021-10-03 13:27:55 --> Router Class Initialized
INFO - 2021-10-03 13:27:55 --> Output Class Initialized
INFO - 2021-10-03 13:27:55 --> Security Class Initialized
DEBUG - 2021-10-03 13:27:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-03 13:27:55 --> Input Class Initialized
INFO - 2021-10-03 13:27:55 --> Language Class Initialized
ERROR - 2021-10-03 13:27:55 --> 404 Page Not Found: Site/wp-includes
ERROR - 2021-10-03 13:27:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-03 13:27:56 --> Config Class Initialized
INFO - 2021-10-03 13:27:56 --> Hooks Class Initialized
DEBUG - 2021-10-03 13:27:56 --> UTF-8 Support Enabled
INFO - 2021-10-03 13:27:56 --> Utf8 Class Initialized
INFO - 2021-10-03 13:27:56 --> URI Class Initialized
INFO - 2021-10-03 13:27:56 --> Router Class Initialized
INFO - 2021-10-03 13:27:56 --> Output Class Initialized
INFO - 2021-10-03 13:27:56 --> Security Class Initialized
DEBUG - 2021-10-03 13:27:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-03 13:27:56 --> Input Class Initialized
INFO - 2021-10-03 13:27:56 --> Language Class Initialized
ERROR - 2021-10-03 13:27:56 --> 404 Page Not Found: Cms/wp-includes
ERROR - 2021-10-03 13:27:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-03 13:27:56 --> Config Class Initialized
INFO - 2021-10-03 13:27:56 --> Hooks Class Initialized
DEBUG - 2021-10-03 13:27:56 --> UTF-8 Support Enabled
INFO - 2021-10-03 13:27:56 --> Utf8 Class Initialized
INFO - 2021-10-03 13:27:56 --> URI Class Initialized
INFO - 2021-10-03 13:27:56 --> Router Class Initialized
INFO - 2021-10-03 13:27:56 --> Output Class Initialized
INFO - 2021-10-03 13:27:56 --> Security Class Initialized
DEBUG - 2021-10-03 13:27:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-03 13:27:56 --> Input Class Initialized
INFO - 2021-10-03 13:27:56 --> Language Class Initialized
ERROR - 2021-10-03 13:27:56 --> 404 Page Not Found: Sito/wp-includes
