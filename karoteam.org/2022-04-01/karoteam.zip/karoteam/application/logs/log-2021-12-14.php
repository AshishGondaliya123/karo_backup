<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-12-14 00:28:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 00:28:41 --> Config Class Initialized
INFO - 2021-12-14 00:28:41 --> Hooks Class Initialized
DEBUG - 2021-12-14 00:28:41 --> UTF-8 Support Enabled
INFO - 2021-12-14 00:28:41 --> Utf8 Class Initialized
INFO - 2021-12-14 00:28:41 --> URI Class Initialized
INFO - 2021-12-14 00:28:41 --> Router Class Initialized
INFO - 2021-12-14 00:28:41 --> Output Class Initialized
INFO - 2021-12-14 00:28:41 --> Security Class Initialized
DEBUG - 2021-12-14 00:28:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 00:28:41 --> Input Class Initialized
INFO - 2021-12-14 00:28:41 --> Language Class Initialized
INFO - 2021-12-14 00:28:41 --> Loader Class Initialized
INFO - 2021-12-14 00:28:41 --> Helper loaded: url_helper
INFO - 2021-12-14 00:28:41 --> Helper loaded: form_helper
INFO - 2021-12-14 00:28:41 --> Helper loaded: common_helper
INFO - 2021-12-14 00:28:41 --> Database Driver Class Initialized
DEBUG - 2021-12-14 00:28:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-14 00:28:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-14 00:28:41 --> Controller Class Initialized
INFO - 2021-12-14 00:28:41 --> Form Validation Class Initialized
DEBUG - 2021-12-14 00:28:41 --> Encrypt Class Initialized
DEBUG - 2021-12-14 00:28:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-14 00:28:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-14 00:28:41 --> Email Class Initialized
INFO - 2021-12-14 00:28:41 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-14 00:28:41 --> Calendar Class Initialized
INFO - 2021-12-14 00:28:41 --> Model "Login_model" initialized
INFO - 2021-12-14 00:28:41 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-14 00:28:41 --> Final output sent to browser
DEBUG - 2021-12-14 00:28:41 --> Total execution time: 0.0231
ERROR - 2021-12-14 00:28:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 00:28:57 --> Config Class Initialized
INFO - 2021-12-14 00:28:57 --> Hooks Class Initialized
DEBUG - 2021-12-14 00:28:57 --> UTF-8 Support Enabled
INFO - 2021-12-14 00:28:57 --> Utf8 Class Initialized
INFO - 2021-12-14 00:28:57 --> URI Class Initialized
INFO - 2021-12-14 00:28:57 --> Router Class Initialized
INFO - 2021-12-14 00:28:57 --> Output Class Initialized
INFO - 2021-12-14 00:28:57 --> Security Class Initialized
DEBUG - 2021-12-14 00:28:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 00:28:57 --> Input Class Initialized
INFO - 2021-12-14 00:28:57 --> Language Class Initialized
INFO - 2021-12-14 00:28:57 --> Loader Class Initialized
INFO - 2021-12-14 00:28:57 --> Helper loaded: url_helper
INFO - 2021-12-14 00:28:57 --> Helper loaded: form_helper
INFO - 2021-12-14 00:28:57 --> Helper loaded: common_helper
INFO - 2021-12-14 00:28:57 --> Database Driver Class Initialized
DEBUG - 2021-12-14 00:28:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-14 00:28:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-14 00:28:57 --> Controller Class Initialized
INFO - 2021-12-14 00:28:57 --> Form Validation Class Initialized
DEBUG - 2021-12-14 00:28:57 --> Encrypt Class Initialized
DEBUG - 2021-12-14 00:28:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-14 00:28:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-14 00:28:57 --> Email Class Initialized
INFO - 2021-12-14 00:28:57 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-14 00:28:57 --> Calendar Class Initialized
INFO - 2021-12-14 00:28:57 --> Model "Login_model" initialized
INFO - 2021-12-14 00:28:57 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2021-12-14 00:28:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 00:28:58 --> Config Class Initialized
INFO - 2021-12-14 00:28:58 --> Hooks Class Initialized
DEBUG - 2021-12-14 00:28:58 --> UTF-8 Support Enabled
INFO - 2021-12-14 00:28:58 --> Utf8 Class Initialized
INFO - 2021-12-14 00:28:58 --> URI Class Initialized
INFO - 2021-12-14 00:28:58 --> Router Class Initialized
INFO - 2021-12-14 00:28:58 --> Output Class Initialized
INFO - 2021-12-14 00:28:58 --> Security Class Initialized
DEBUG - 2021-12-14 00:28:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 00:28:58 --> Input Class Initialized
INFO - 2021-12-14 00:28:58 --> Language Class Initialized
INFO - 2021-12-14 00:28:58 --> Loader Class Initialized
INFO - 2021-12-14 00:28:58 --> Helper loaded: url_helper
INFO - 2021-12-14 00:28:58 --> Helper loaded: form_helper
INFO - 2021-12-14 00:28:58 --> Helper loaded: common_helper
INFO - 2021-12-14 00:28:58 --> Database Driver Class Initialized
DEBUG - 2021-12-14 00:28:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-14 00:28:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-14 00:28:58 --> Controller Class Initialized
INFO - 2021-12-14 00:28:58 --> Form Validation Class Initialized
DEBUG - 2021-12-14 00:28:58 --> Encrypt Class Initialized
INFO - 2021-12-14 00:28:58 --> Model "Login_model" initialized
INFO - 2021-12-14 00:28:58 --> Model "Dashboard_model" initialized
INFO - 2021-12-14 00:28:58 --> Model "Case_model" initialized
ERROR - 2021-12-14 00:29:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 00:29:00 --> Config Class Initialized
INFO - 2021-12-14 00:29:00 --> Hooks Class Initialized
DEBUG - 2021-12-14 00:29:00 --> UTF-8 Support Enabled
INFO - 2021-12-14 00:29:00 --> Utf8 Class Initialized
INFO - 2021-12-14 00:29:00 --> URI Class Initialized
INFO - 2021-12-14 00:29:00 --> Router Class Initialized
INFO - 2021-12-14 00:29:00 --> Output Class Initialized
INFO - 2021-12-14 00:29:00 --> Security Class Initialized
DEBUG - 2021-12-14 00:29:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 00:29:00 --> Input Class Initialized
INFO - 2021-12-14 00:29:00 --> Language Class Initialized
INFO - 2021-12-14 00:29:00 --> Loader Class Initialized
INFO - 2021-12-14 00:29:00 --> Helper loaded: url_helper
INFO - 2021-12-14 00:29:00 --> Helper loaded: form_helper
INFO - 2021-12-14 00:29:00 --> Helper loaded: common_helper
INFO - 2021-12-14 00:29:00 --> Database Driver Class Initialized
DEBUG - 2021-12-14 00:29:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-14 00:29:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-14 00:29:00 --> Controller Class Initialized
INFO - 2021-12-14 00:29:00 --> Form Validation Class Initialized
DEBUG - 2021-12-14 00:29:00 --> Encrypt Class Initialized
DEBUG - 2021-12-14 00:29:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-14 00:29:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-14 00:29:00 --> Email Class Initialized
INFO - 2021-12-14 00:29:00 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-14 00:29:00 --> Calendar Class Initialized
INFO - 2021-12-14 00:29:00 --> Model "Login_model" initialized
INFO - 2021-12-14 00:29:00 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-14 00:29:00 --> Final output sent to browser
DEBUG - 2021-12-14 00:29:00 --> Total execution time: 0.0234
INFO - 2021-12-14 00:29:06 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-14 00:29:16 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2021-12-14 00:29:16 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-14 00:29:16 --> Final output sent to browser
DEBUG - 2021-12-14 00:29:16 --> Total execution time: 17.9141
ERROR - 2021-12-14 00:29:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 00:29:17 --> Config Class Initialized
INFO - 2021-12-14 00:29:17 --> Hooks Class Initialized
DEBUG - 2021-12-14 00:29:17 --> UTF-8 Support Enabled
INFO - 2021-12-14 00:29:17 --> Utf8 Class Initialized
INFO - 2021-12-14 00:29:17 --> URI Class Initialized
INFO - 2021-12-14 00:29:17 --> Router Class Initialized
INFO - 2021-12-14 00:29:17 --> Output Class Initialized
INFO - 2021-12-14 00:29:17 --> Security Class Initialized
DEBUG - 2021-12-14 00:29:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 00:29:17 --> Input Class Initialized
INFO - 2021-12-14 00:29:17 --> Language Class Initialized
ERROR - 2021-12-14 00:29:17 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-12-14 00:30:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 00:30:11 --> Config Class Initialized
INFO - 2021-12-14 00:30:11 --> Hooks Class Initialized
DEBUG - 2021-12-14 00:30:11 --> UTF-8 Support Enabled
INFO - 2021-12-14 00:30:11 --> Utf8 Class Initialized
INFO - 2021-12-14 00:30:11 --> URI Class Initialized
DEBUG - 2021-12-14 00:30:11 --> No URI present. Default controller set.
INFO - 2021-12-14 00:30:11 --> Router Class Initialized
INFO - 2021-12-14 00:30:11 --> Output Class Initialized
INFO - 2021-12-14 00:30:11 --> Security Class Initialized
DEBUG - 2021-12-14 00:30:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 00:30:11 --> Input Class Initialized
INFO - 2021-12-14 00:30:11 --> Language Class Initialized
INFO - 2021-12-14 00:30:11 --> Loader Class Initialized
INFO - 2021-12-14 00:30:11 --> Helper loaded: url_helper
INFO - 2021-12-14 00:30:11 --> Helper loaded: form_helper
INFO - 2021-12-14 00:30:11 --> Helper loaded: common_helper
INFO - 2021-12-14 00:30:11 --> Database Driver Class Initialized
DEBUG - 2021-12-14 00:30:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-14 00:30:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-14 00:30:11 --> Controller Class Initialized
INFO - 2021-12-14 00:30:11 --> Form Validation Class Initialized
DEBUG - 2021-12-14 00:30:11 --> Encrypt Class Initialized
DEBUG - 2021-12-14 00:30:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-14 00:30:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-14 00:30:11 --> Email Class Initialized
INFO - 2021-12-14 00:30:11 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-14 00:30:11 --> Calendar Class Initialized
INFO - 2021-12-14 00:30:11 --> Model "Login_model" initialized
INFO - 2021-12-14 00:30:11 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-14 00:30:11 --> Final output sent to browser
DEBUG - 2021-12-14 00:30:11 --> Total execution time: 0.0233
ERROR - 2021-12-14 01:05:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 01:05:37 --> Config Class Initialized
INFO - 2021-12-14 01:05:37 --> Hooks Class Initialized
DEBUG - 2021-12-14 01:05:37 --> UTF-8 Support Enabled
INFO - 2021-12-14 01:05:37 --> Utf8 Class Initialized
INFO - 2021-12-14 01:05:37 --> URI Class Initialized
DEBUG - 2021-12-14 01:05:37 --> No URI present. Default controller set.
INFO - 2021-12-14 01:05:37 --> Router Class Initialized
INFO - 2021-12-14 01:05:37 --> Output Class Initialized
INFO - 2021-12-14 01:05:37 --> Security Class Initialized
DEBUG - 2021-12-14 01:05:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 01:05:37 --> Input Class Initialized
INFO - 2021-12-14 01:05:37 --> Language Class Initialized
INFO - 2021-12-14 01:05:37 --> Loader Class Initialized
INFO - 2021-12-14 01:05:37 --> Helper loaded: url_helper
INFO - 2021-12-14 01:05:37 --> Helper loaded: form_helper
INFO - 2021-12-14 01:05:37 --> Helper loaded: common_helper
INFO - 2021-12-14 01:05:37 --> Database Driver Class Initialized
DEBUG - 2021-12-14 01:05:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-14 01:05:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-14 01:05:37 --> Controller Class Initialized
INFO - 2021-12-14 01:05:37 --> Form Validation Class Initialized
DEBUG - 2021-12-14 01:05:37 --> Encrypt Class Initialized
DEBUG - 2021-12-14 01:05:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-14 01:05:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-14 01:05:37 --> Email Class Initialized
INFO - 2021-12-14 01:05:37 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-14 01:05:37 --> Calendar Class Initialized
INFO - 2021-12-14 01:05:37 --> Model "Login_model" initialized
INFO - 2021-12-14 01:05:37 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-14 01:05:37 --> Final output sent to browser
DEBUG - 2021-12-14 01:05:37 --> Total execution time: 0.0252
ERROR - 2021-12-14 06:41:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 06:41:12 --> Config Class Initialized
INFO - 2021-12-14 06:41:12 --> Hooks Class Initialized
DEBUG - 2021-12-14 06:41:12 --> UTF-8 Support Enabled
INFO - 2021-12-14 06:41:12 --> Utf8 Class Initialized
INFO - 2021-12-14 06:41:12 --> URI Class Initialized
DEBUG - 2021-12-14 06:41:12 --> No URI present. Default controller set.
INFO - 2021-12-14 06:41:12 --> Router Class Initialized
INFO - 2021-12-14 06:41:12 --> Output Class Initialized
INFO - 2021-12-14 06:41:12 --> Security Class Initialized
DEBUG - 2021-12-14 06:41:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 06:41:12 --> Input Class Initialized
INFO - 2021-12-14 06:41:12 --> Language Class Initialized
INFO - 2021-12-14 06:41:12 --> Loader Class Initialized
INFO - 2021-12-14 06:41:12 --> Helper loaded: url_helper
INFO - 2021-12-14 06:41:12 --> Helper loaded: form_helper
INFO - 2021-12-14 06:41:12 --> Helper loaded: common_helper
INFO - 2021-12-14 06:41:12 --> Database Driver Class Initialized
DEBUG - 2021-12-14 06:41:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-14 06:41:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-14 06:41:12 --> Controller Class Initialized
INFO - 2021-12-14 06:41:12 --> Form Validation Class Initialized
DEBUG - 2021-12-14 06:41:12 --> Encrypt Class Initialized
DEBUG - 2021-12-14 06:41:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-14 06:41:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-14 06:41:12 --> Email Class Initialized
INFO - 2021-12-14 06:41:12 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-14 06:41:12 --> Calendar Class Initialized
INFO - 2021-12-14 06:41:12 --> Model "Login_model" initialized
INFO - 2021-12-14 06:41:12 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-14 06:41:12 --> Final output sent to browser
DEBUG - 2021-12-14 06:41:12 --> Total execution time: 0.0301
ERROR - 2021-12-14 08:57:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 08:57:16 --> Config Class Initialized
INFO - 2021-12-14 08:57:16 --> Hooks Class Initialized
DEBUG - 2021-12-14 08:57:16 --> UTF-8 Support Enabled
INFO - 2021-12-14 08:57:16 --> Utf8 Class Initialized
INFO - 2021-12-14 08:57:16 --> URI Class Initialized
DEBUG - 2021-12-14 08:57:16 --> No URI present. Default controller set.
INFO - 2021-12-14 08:57:16 --> Router Class Initialized
INFO - 2021-12-14 08:57:16 --> Output Class Initialized
INFO - 2021-12-14 08:57:16 --> Security Class Initialized
DEBUG - 2021-12-14 08:57:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 08:57:16 --> Input Class Initialized
INFO - 2021-12-14 08:57:16 --> Language Class Initialized
INFO - 2021-12-14 08:57:16 --> Loader Class Initialized
INFO - 2021-12-14 08:57:16 --> Helper loaded: url_helper
INFO - 2021-12-14 08:57:16 --> Helper loaded: form_helper
INFO - 2021-12-14 08:57:16 --> Helper loaded: common_helper
INFO - 2021-12-14 08:57:16 --> Database Driver Class Initialized
DEBUG - 2021-12-14 08:57:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-14 08:57:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-14 08:57:16 --> Controller Class Initialized
INFO - 2021-12-14 08:57:16 --> Form Validation Class Initialized
DEBUG - 2021-12-14 08:57:16 --> Encrypt Class Initialized
DEBUG - 2021-12-14 08:57:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-14 08:57:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-14 08:57:16 --> Email Class Initialized
INFO - 2021-12-14 08:57:16 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-14 08:57:16 --> Calendar Class Initialized
INFO - 2021-12-14 08:57:16 --> Model "Login_model" initialized
INFO - 2021-12-14 08:57:16 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-14 08:57:16 --> Final output sent to browser
DEBUG - 2021-12-14 08:57:16 --> Total execution time: 0.0244
ERROR - 2021-12-14 14:23:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 14:23:19 --> Config Class Initialized
INFO - 2021-12-14 14:23:19 --> Hooks Class Initialized
DEBUG - 2021-12-14 14:23:19 --> UTF-8 Support Enabled
INFO - 2021-12-14 14:23:19 --> Utf8 Class Initialized
INFO - 2021-12-14 14:23:19 --> URI Class Initialized
DEBUG - 2021-12-14 14:23:19 --> No URI present. Default controller set.
INFO - 2021-12-14 14:23:19 --> Router Class Initialized
INFO - 2021-12-14 14:23:19 --> Output Class Initialized
INFO - 2021-12-14 14:23:19 --> Security Class Initialized
DEBUG - 2021-12-14 14:23:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 14:23:19 --> Input Class Initialized
INFO - 2021-12-14 14:23:19 --> Language Class Initialized
INFO - 2021-12-14 14:23:19 --> Loader Class Initialized
INFO - 2021-12-14 14:23:19 --> Helper loaded: url_helper
INFO - 2021-12-14 14:23:19 --> Helper loaded: form_helper
INFO - 2021-12-14 14:23:19 --> Helper loaded: common_helper
INFO - 2021-12-14 14:23:19 --> Database Driver Class Initialized
DEBUG - 2021-12-14 14:23:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-14 14:23:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-14 14:23:19 --> Controller Class Initialized
INFO - 2021-12-14 14:23:19 --> Form Validation Class Initialized
DEBUG - 2021-12-14 14:23:19 --> Encrypt Class Initialized
DEBUG - 2021-12-14 14:23:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-14 14:23:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-14 14:23:19 --> Email Class Initialized
INFO - 2021-12-14 14:23:19 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-14 14:23:19 --> Calendar Class Initialized
INFO - 2021-12-14 14:23:19 --> Model "Login_model" initialized
INFO - 2021-12-14 14:23:19 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-14 14:23:19 --> Final output sent to browser
DEBUG - 2021-12-14 14:23:19 --> Total execution time: 0.0318
ERROR - 2021-12-14 14:23:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 14:23:21 --> Config Class Initialized
INFO - 2021-12-14 14:23:21 --> Hooks Class Initialized
DEBUG - 2021-12-14 14:23:21 --> UTF-8 Support Enabled
INFO - 2021-12-14 14:23:21 --> Utf8 Class Initialized
INFO - 2021-12-14 14:23:21 --> URI Class Initialized
INFO - 2021-12-14 14:23:21 --> Router Class Initialized
INFO - 2021-12-14 14:23:21 --> Output Class Initialized
INFO - 2021-12-14 14:23:21 --> Security Class Initialized
DEBUG - 2021-12-14 14:23:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 14:23:21 --> Input Class Initialized
INFO - 2021-12-14 14:23:21 --> Language Class Initialized
ERROR - 2021-12-14 14:23:21 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2021-12-14 14:23:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 14:23:29 --> Config Class Initialized
INFO - 2021-12-14 14:23:29 --> Hooks Class Initialized
DEBUG - 2021-12-14 14:23:29 --> UTF-8 Support Enabled
INFO - 2021-12-14 14:23:29 --> Utf8 Class Initialized
INFO - 2021-12-14 14:23:29 --> URI Class Initialized
INFO - 2021-12-14 14:23:29 --> Router Class Initialized
INFO - 2021-12-14 14:23:29 --> Output Class Initialized
INFO - 2021-12-14 14:23:29 --> Security Class Initialized
DEBUG - 2021-12-14 14:23:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 14:23:29 --> Input Class Initialized
INFO - 2021-12-14 14:23:29 --> Language Class Initialized
INFO - 2021-12-14 14:23:29 --> Loader Class Initialized
INFO - 2021-12-14 14:23:29 --> Helper loaded: url_helper
INFO - 2021-12-14 14:23:29 --> Helper loaded: form_helper
INFO - 2021-12-14 14:23:29 --> Helper loaded: common_helper
INFO - 2021-12-14 14:23:29 --> Database Driver Class Initialized
DEBUG - 2021-12-14 14:23:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-14 14:23:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-14 14:23:29 --> Controller Class Initialized
INFO - 2021-12-14 14:23:29 --> Form Validation Class Initialized
DEBUG - 2021-12-14 14:23:29 --> Encrypt Class Initialized
DEBUG - 2021-12-14 14:23:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-14 14:23:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-14 14:23:29 --> Email Class Initialized
INFO - 2021-12-14 14:23:29 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-14 14:23:29 --> Calendar Class Initialized
INFO - 2021-12-14 14:23:29 --> Model "Login_model" initialized
INFO - 2021-12-14 14:23:29 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-14 14:23:29 --> Final output sent to browser
DEBUG - 2021-12-14 14:23:29 --> Total execution time: 0.0237
ERROR - 2021-12-14 14:23:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 14:23:29 --> Config Class Initialized
INFO - 2021-12-14 14:23:29 --> Hooks Class Initialized
DEBUG - 2021-12-14 14:23:29 --> UTF-8 Support Enabled
INFO - 2021-12-14 14:23:29 --> Utf8 Class Initialized
INFO - 2021-12-14 14:23:29 --> URI Class Initialized
INFO - 2021-12-14 14:23:29 --> Router Class Initialized
INFO - 2021-12-14 14:23:29 --> Output Class Initialized
INFO - 2021-12-14 14:23:29 --> Security Class Initialized
DEBUG - 2021-12-14 14:23:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 14:23:29 --> Input Class Initialized
INFO - 2021-12-14 14:23:29 --> Language Class Initialized
INFO - 2021-12-14 14:23:29 --> Loader Class Initialized
INFO - 2021-12-14 14:23:29 --> Helper loaded: url_helper
INFO - 2021-12-14 14:23:29 --> Helper loaded: form_helper
INFO - 2021-12-14 14:23:29 --> Helper loaded: common_helper
INFO - 2021-12-14 14:23:29 --> Database Driver Class Initialized
DEBUG - 2021-12-14 14:23:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-14 14:23:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-14 14:23:29 --> Controller Class Initialized
INFO - 2021-12-14 14:23:29 --> Form Validation Class Initialized
DEBUG - 2021-12-14 14:23:29 --> Encrypt Class Initialized
DEBUG - 2021-12-14 14:23:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-14 14:23:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-14 14:23:29 --> Email Class Initialized
INFO - 2021-12-14 14:23:29 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-14 14:23:29 --> Calendar Class Initialized
INFO - 2021-12-14 14:23:29 --> Model "Login_model" initialized
ERROR - 2021-12-14 14:23:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 14:23:30 --> Config Class Initialized
INFO - 2021-12-14 14:23:30 --> Hooks Class Initialized
DEBUG - 2021-12-14 14:23:30 --> UTF-8 Support Enabled
INFO - 2021-12-14 14:23:30 --> Utf8 Class Initialized
INFO - 2021-12-14 14:23:30 --> URI Class Initialized
INFO - 2021-12-14 14:23:30 --> Router Class Initialized
INFO - 2021-12-14 14:23:30 --> Output Class Initialized
INFO - 2021-12-14 14:23:30 --> Security Class Initialized
DEBUG - 2021-12-14 14:23:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 14:23:30 --> Input Class Initialized
INFO - 2021-12-14 14:23:30 --> Language Class Initialized
INFO - 2021-12-14 14:23:30 --> Loader Class Initialized
INFO - 2021-12-14 14:23:30 --> Helper loaded: url_helper
INFO - 2021-12-14 14:23:30 --> Helper loaded: form_helper
INFO - 2021-12-14 14:23:30 --> Helper loaded: common_helper
INFO - 2021-12-14 14:23:30 --> Database Driver Class Initialized
DEBUG - 2021-12-14 14:23:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-14 14:23:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-14 14:23:30 --> Controller Class Initialized
INFO - 2021-12-14 14:23:30 --> Form Validation Class Initialized
DEBUG - 2021-12-14 14:23:30 --> Encrypt Class Initialized
DEBUG - 2021-12-14 14:23:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-14 14:23:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-14 14:23:30 --> Email Class Initialized
INFO - 2021-12-14 14:23:30 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-14 14:23:30 --> Calendar Class Initialized
INFO - 2021-12-14 14:23:30 --> Model "Login_model" initialized
ERROR - 2021-12-14 14:23:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 14:23:30 --> Config Class Initialized
INFO - 2021-12-14 14:23:30 --> Hooks Class Initialized
DEBUG - 2021-12-14 14:23:30 --> UTF-8 Support Enabled
INFO - 2021-12-14 14:23:30 --> Utf8 Class Initialized
INFO - 2021-12-14 14:23:30 --> URI Class Initialized
DEBUG - 2021-12-14 14:23:30 --> No URI present. Default controller set.
INFO - 2021-12-14 14:23:30 --> Router Class Initialized
INFO - 2021-12-14 14:23:30 --> Output Class Initialized
INFO - 2021-12-14 14:23:30 --> Security Class Initialized
DEBUG - 2021-12-14 14:23:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 14:23:30 --> Input Class Initialized
INFO - 2021-12-14 14:23:30 --> Language Class Initialized
INFO - 2021-12-14 14:23:30 --> Loader Class Initialized
INFO - 2021-12-14 14:23:30 --> Helper loaded: url_helper
INFO - 2021-12-14 14:23:30 --> Helper loaded: form_helper
INFO - 2021-12-14 14:23:30 --> Helper loaded: common_helper
INFO - 2021-12-14 14:23:30 --> Database Driver Class Initialized
DEBUG - 2021-12-14 14:23:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-14 14:23:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-14 14:23:30 --> Controller Class Initialized
INFO - 2021-12-14 14:23:30 --> Form Validation Class Initialized
DEBUG - 2021-12-14 14:23:30 --> Encrypt Class Initialized
DEBUG - 2021-12-14 14:23:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-14 14:23:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-14 14:23:30 --> Email Class Initialized
INFO - 2021-12-14 14:23:30 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-14 14:23:30 --> Calendar Class Initialized
INFO - 2021-12-14 14:23:30 --> Model "Login_model" initialized
INFO - 2021-12-14 14:23:30 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-14 14:23:30 --> Final output sent to browser
DEBUG - 2021-12-14 14:23:30 --> Total execution time: 0.0231
ERROR - 2021-12-14 15:05:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 15:05:27 --> Config Class Initialized
INFO - 2021-12-14 15:05:27 --> Hooks Class Initialized
DEBUG - 2021-12-14 15:05:27 --> UTF-8 Support Enabled
INFO - 2021-12-14 15:05:27 --> Utf8 Class Initialized
INFO - 2021-12-14 15:05:27 --> URI Class Initialized
DEBUG - 2021-12-14 15:05:27 --> No URI present. Default controller set.
INFO - 2021-12-14 15:05:27 --> Router Class Initialized
INFO - 2021-12-14 15:05:27 --> Output Class Initialized
INFO - 2021-12-14 15:05:27 --> Security Class Initialized
DEBUG - 2021-12-14 15:05:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 15:05:27 --> Input Class Initialized
INFO - 2021-12-14 15:05:27 --> Language Class Initialized
INFO - 2021-12-14 15:05:27 --> Loader Class Initialized
INFO - 2021-12-14 15:05:27 --> Helper loaded: url_helper
INFO - 2021-12-14 15:05:27 --> Helper loaded: form_helper
INFO - 2021-12-14 15:05:27 --> Helper loaded: common_helper
INFO - 2021-12-14 15:05:27 --> Database Driver Class Initialized
DEBUG - 2021-12-14 15:05:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-14 15:05:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-14 15:05:27 --> Controller Class Initialized
INFO - 2021-12-14 15:05:27 --> Form Validation Class Initialized
DEBUG - 2021-12-14 15:05:27 --> Encrypt Class Initialized
DEBUG - 2021-12-14 15:05:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-14 15:05:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-14 15:05:27 --> Email Class Initialized
INFO - 2021-12-14 15:05:27 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-14 15:05:27 --> Calendar Class Initialized
INFO - 2021-12-14 15:05:27 --> Model "Login_model" initialized
INFO - 2021-12-14 15:05:27 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-14 15:05:27 --> Final output sent to browser
DEBUG - 2021-12-14 15:05:27 --> Total execution time: 0.0324
ERROR - 2021-12-14 15:25:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 15:25:38 --> Config Class Initialized
INFO - 2021-12-14 15:25:38 --> Hooks Class Initialized
DEBUG - 2021-12-14 15:25:38 --> UTF-8 Support Enabled
INFO - 2021-12-14 15:25:38 --> Utf8 Class Initialized
INFO - 2021-12-14 15:25:38 --> URI Class Initialized
DEBUG - 2021-12-14 15:25:38 --> No URI present. Default controller set.
INFO - 2021-12-14 15:25:38 --> Router Class Initialized
INFO - 2021-12-14 15:25:38 --> Output Class Initialized
INFO - 2021-12-14 15:25:38 --> Security Class Initialized
DEBUG - 2021-12-14 15:25:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 15:25:38 --> Input Class Initialized
INFO - 2021-12-14 15:25:38 --> Language Class Initialized
INFO - 2021-12-14 15:25:38 --> Loader Class Initialized
INFO - 2021-12-14 15:25:38 --> Helper loaded: url_helper
INFO - 2021-12-14 15:25:38 --> Helper loaded: form_helper
INFO - 2021-12-14 15:25:38 --> Helper loaded: common_helper
INFO - 2021-12-14 15:25:38 --> Database Driver Class Initialized
DEBUG - 2021-12-14 15:25:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-14 15:25:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-14 15:25:38 --> Controller Class Initialized
INFO - 2021-12-14 15:25:38 --> Form Validation Class Initialized
DEBUG - 2021-12-14 15:25:38 --> Encrypt Class Initialized
DEBUG - 2021-12-14 15:25:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-14 15:25:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-14 15:25:38 --> Email Class Initialized
INFO - 2021-12-14 15:25:38 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-14 15:25:38 --> Calendar Class Initialized
INFO - 2021-12-14 15:25:38 --> Model "Login_model" initialized
INFO - 2021-12-14 15:25:38 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-14 15:25:38 --> Final output sent to browser
DEBUG - 2021-12-14 15:25:38 --> Total execution time: 0.0301
ERROR - 2021-12-14 16:20:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 16:20:36 --> Config Class Initialized
INFO - 2021-12-14 16:20:36 --> Hooks Class Initialized
DEBUG - 2021-12-14 16:20:36 --> UTF-8 Support Enabled
INFO - 2021-12-14 16:20:36 --> Utf8 Class Initialized
INFO - 2021-12-14 16:20:36 --> URI Class Initialized
INFO - 2021-12-14 16:20:36 --> Router Class Initialized
INFO - 2021-12-14 16:20:36 --> Output Class Initialized
INFO - 2021-12-14 16:20:36 --> Security Class Initialized
DEBUG - 2021-12-14 16:20:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 16:20:36 --> Input Class Initialized
INFO - 2021-12-14 16:20:36 --> Language Class Initialized
ERROR - 2021-12-14 16:20:36 --> 404 Page Not Found: Blog/wp-includes
ERROR - 2021-12-14 16:20:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 16:20:37 --> Config Class Initialized
INFO - 2021-12-14 16:20:37 --> Hooks Class Initialized
DEBUG - 2021-12-14 16:20:37 --> UTF-8 Support Enabled
INFO - 2021-12-14 16:20:37 --> Utf8 Class Initialized
INFO - 2021-12-14 16:20:37 --> URI Class Initialized
INFO - 2021-12-14 16:20:37 --> Router Class Initialized
INFO - 2021-12-14 16:20:37 --> Output Class Initialized
INFO - 2021-12-14 16:20:37 --> Security Class Initialized
DEBUG - 2021-12-14 16:20:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 16:20:37 --> Input Class Initialized
INFO - 2021-12-14 16:20:37 --> Language Class Initialized
ERROR - 2021-12-14 16:20:37 --> 404 Page Not Found: Web/wp-includes
ERROR - 2021-12-14 16:20:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 16:20:37 --> Config Class Initialized
INFO - 2021-12-14 16:20:37 --> Hooks Class Initialized
DEBUG - 2021-12-14 16:20:37 --> UTF-8 Support Enabled
INFO - 2021-12-14 16:20:37 --> Utf8 Class Initialized
INFO - 2021-12-14 16:20:37 --> URI Class Initialized
INFO - 2021-12-14 16:20:37 --> Router Class Initialized
INFO - 2021-12-14 16:20:37 --> Output Class Initialized
INFO - 2021-12-14 16:20:37 --> Security Class Initialized
DEBUG - 2021-12-14 16:20:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 16:20:37 --> Input Class Initialized
INFO - 2021-12-14 16:20:37 --> Language Class Initialized
ERROR - 2021-12-14 16:20:37 --> 404 Page Not Found: Wordpress/wp-includes
ERROR - 2021-12-14 16:20:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 16:20:38 --> Config Class Initialized
INFO - 2021-12-14 16:20:38 --> Hooks Class Initialized
DEBUG - 2021-12-14 16:20:38 --> UTF-8 Support Enabled
INFO - 2021-12-14 16:20:38 --> Utf8 Class Initialized
INFO - 2021-12-14 16:20:38 --> URI Class Initialized
INFO - 2021-12-14 16:20:38 --> Router Class Initialized
INFO - 2021-12-14 16:20:38 --> Output Class Initialized
INFO - 2021-12-14 16:20:38 --> Security Class Initialized
DEBUG - 2021-12-14 16:20:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 16:20:38 --> Input Class Initialized
INFO - 2021-12-14 16:20:38 --> Language Class Initialized
ERROR - 2021-12-14 16:20:38 --> 404 Page Not Found: Website/wp-includes
ERROR - 2021-12-14 16:20:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 16:20:39 --> Config Class Initialized
INFO - 2021-12-14 16:20:39 --> Hooks Class Initialized
DEBUG - 2021-12-14 16:20:39 --> UTF-8 Support Enabled
INFO - 2021-12-14 16:20:39 --> Utf8 Class Initialized
INFO - 2021-12-14 16:20:39 --> URI Class Initialized
INFO - 2021-12-14 16:20:39 --> Router Class Initialized
INFO - 2021-12-14 16:20:39 --> Output Class Initialized
INFO - 2021-12-14 16:20:39 --> Security Class Initialized
DEBUG - 2021-12-14 16:20:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 16:20:39 --> Input Class Initialized
INFO - 2021-12-14 16:20:39 --> Language Class Initialized
ERROR - 2021-12-14 16:20:39 --> 404 Page Not Found: Wp/wp-includes
ERROR - 2021-12-14 16:20:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 16:20:39 --> Config Class Initialized
INFO - 2021-12-14 16:20:39 --> Hooks Class Initialized
DEBUG - 2021-12-14 16:20:39 --> UTF-8 Support Enabled
INFO - 2021-12-14 16:20:39 --> Utf8 Class Initialized
INFO - 2021-12-14 16:20:39 --> URI Class Initialized
INFO - 2021-12-14 16:20:39 --> Router Class Initialized
INFO - 2021-12-14 16:20:39 --> Output Class Initialized
INFO - 2021-12-14 16:20:39 --> Security Class Initialized
DEBUG - 2021-12-14 16:20:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 16:20:39 --> Input Class Initialized
INFO - 2021-12-14 16:20:39 --> Language Class Initialized
ERROR - 2021-12-14 16:20:39 --> 404 Page Not Found: News/wp-includes
ERROR - 2021-12-14 16:20:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 16:20:40 --> Config Class Initialized
INFO - 2021-12-14 16:20:40 --> Hooks Class Initialized
DEBUG - 2021-12-14 16:20:40 --> UTF-8 Support Enabled
INFO - 2021-12-14 16:20:40 --> Utf8 Class Initialized
INFO - 2021-12-14 16:20:40 --> URI Class Initialized
INFO - 2021-12-14 16:20:40 --> Router Class Initialized
INFO - 2021-12-14 16:20:40 --> Output Class Initialized
INFO - 2021-12-14 16:20:40 --> Security Class Initialized
DEBUG - 2021-12-14 16:20:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 16:20:40 --> Input Class Initialized
INFO - 2021-12-14 16:20:40 --> Language Class Initialized
ERROR - 2021-12-14 16:20:40 --> 404 Page Not Found: 2018/wp-includes
ERROR - 2021-12-14 16:20:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 16:20:40 --> Config Class Initialized
INFO - 2021-12-14 16:20:40 --> Hooks Class Initialized
DEBUG - 2021-12-14 16:20:40 --> UTF-8 Support Enabled
INFO - 2021-12-14 16:20:40 --> Utf8 Class Initialized
INFO - 2021-12-14 16:20:40 --> URI Class Initialized
INFO - 2021-12-14 16:20:40 --> Router Class Initialized
INFO - 2021-12-14 16:20:40 --> Output Class Initialized
INFO - 2021-12-14 16:20:40 --> Security Class Initialized
DEBUG - 2021-12-14 16:20:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 16:20:40 --> Input Class Initialized
INFO - 2021-12-14 16:20:40 --> Language Class Initialized
ERROR - 2021-12-14 16:20:40 --> 404 Page Not Found: 2019/wp-includes
ERROR - 2021-12-14 16:20:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 16:20:41 --> Config Class Initialized
INFO - 2021-12-14 16:20:41 --> Hooks Class Initialized
DEBUG - 2021-12-14 16:20:41 --> UTF-8 Support Enabled
INFO - 2021-12-14 16:20:41 --> Utf8 Class Initialized
INFO - 2021-12-14 16:20:41 --> URI Class Initialized
INFO - 2021-12-14 16:20:41 --> Router Class Initialized
INFO - 2021-12-14 16:20:41 --> Output Class Initialized
INFO - 2021-12-14 16:20:41 --> Security Class Initialized
DEBUG - 2021-12-14 16:20:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 16:20:41 --> Input Class Initialized
INFO - 2021-12-14 16:20:41 --> Language Class Initialized
ERROR - 2021-12-14 16:20:41 --> 404 Page Not Found: Shop/wp-includes
ERROR - 2021-12-14 16:20:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 16:20:41 --> Config Class Initialized
INFO - 2021-12-14 16:20:41 --> Hooks Class Initialized
DEBUG - 2021-12-14 16:20:41 --> UTF-8 Support Enabled
INFO - 2021-12-14 16:20:41 --> Utf8 Class Initialized
INFO - 2021-12-14 16:20:41 --> URI Class Initialized
INFO - 2021-12-14 16:20:41 --> Router Class Initialized
INFO - 2021-12-14 16:20:41 --> Output Class Initialized
INFO - 2021-12-14 16:20:41 --> Security Class Initialized
DEBUG - 2021-12-14 16:20:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 16:20:41 --> Input Class Initialized
INFO - 2021-12-14 16:20:41 --> Language Class Initialized
ERROR - 2021-12-14 16:20:41 --> 404 Page Not Found: Wp1/wp-includes
ERROR - 2021-12-14 16:20:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 16:20:42 --> Config Class Initialized
INFO - 2021-12-14 16:20:42 --> Hooks Class Initialized
DEBUG - 2021-12-14 16:20:42 --> UTF-8 Support Enabled
INFO - 2021-12-14 16:20:42 --> Utf8 Class Initialized
INFO - 2021-12-14 16:20:42 --> URI Class Initialized
INFO - 2021-12-14 16:20:42 --> Router Class Initialized
INFO - 2021-12-14 16:20:42 --> Output Class Initialized
INFO - 2021-12-14 16:20:42 --> Security Class Initialized
DEBUG - 2021-12-14 16:20:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 16:20:42 --> Input Class Initialized
INFO - 2021-12-14 16:20:42 --> Language Class Initialized
ERROR - 2021-12-14 16:20:42 --> 404 Page Not Found: Test/wp-includes
ERROR - 2021-12-14 16:20:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 16:20:43 --> Config Class Initialized
INFO - 2021-12-14 16:20:43 --> Hooks Class Initialized
DEBUG - 2021-12-14 16:20:43 --> UTF-8 Support Enabled
INFO - 2021-12-14 16:20:43 --> Utf8 Class Initialized
INFO - 2021-12-14 16:20:43 --> URI Class Initialized
INFO - 2021-12-14 16:20:43 --> Router Class Initialized
INFO - 2021-12-14 16:20:43 --> Output Class Initialized
INFO - 2021-12-14 16:20:43 --> Security Class Initialized
DEBUG - 2021-12-14 16:20:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 16:20:43 --> Input Class Initialized
INFO - 2021-12-14 16:20:43 --> Language Class Initialized
ERROR - 2021-12-14 16:20:43 --> 404 Page Not Found: Media/wp-includes
ERROR - 2021-12-14 16:20:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 16:20:43 --> Config Class Initialized
INFO - 2021-12-14 16:20:43 --> Hooks Class Initialized
DEBUG - 2021-12-14 16:20:43 --> UTF-8 Support Enabled
INFO - 2021-12-14 16:20:43 --> Utf8 Class Initialized
INFO - 2021-12-14 16:20:43 --> URI Class Initialized
INFO - 2021-12-14 16:20:43 --> Router Class Initialized
INFO - 2021-12-14 16:20:43 --> Output Class Initialized
INFO - 2021-12-14 16:20:43 --> Security Class Initialized
DEBUG - 2021-12-14 16:20:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 16:20:43 --> Input Class Initialized
INFO - 2021-12-14 16:20:43 --> Language Class Initialized
ERROR - 2021-12-14 16:20:43 --> 404 Page Not Found: Wp2/wp-includes
ERROR - 2021-12-14 16:20:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 16:20:44 --> Config Class Initialized
INFO - 2021-12-14 16:20:44 --> Hooks Class Initialized
DEBUG - 2021-12-14 16:20:44 --> UTF-8 Support Enabled
INFO - 2021-12-14 16:20:44 --> Utf8 Class Initialized
INFO - 2021-12-14 16:20:44 --> URI Class Initialized
INFO - 2021-12-14 16:20:44 --> Router Class Initialized
INFO - 2021-12-14 16:20:44 --> Output Class Initialized
INFO - 2021-12-14 16:20:44 --> Security Class Initialized
DEBUG - 2021-12-14 16:20:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 16:20:44 --> Input Class Initialized
INFO - 2021-12-14 16:20:44 --> Language Class Initialized
ERROR - 2021-12-14 16:20:44 --> 404 Page Not Found: Site/wp-includes
ERROR - 2021-12-14 16:20:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 16:20:44 --> Config Class Initialized
INFO - 2021-12-14 16:20:44 --> Hooks Class Initialized
DEBUG - 2021-12-14 16:20:44 --> UTF-8 Support Enabled
INFO - 2021-12-14 16:20:44 --> Utf8 Class Initialized
INFO - 2021-12-14 16:20:44 --> URI Class Initialized
INFO - 2021-12-14 16:20:44 --> Router Class Initialized
INFO - 2021-12-14 16:20:44 --> Output Class Initialized
INFO - 2021-12-14 16:20:44 --> Security Class Initialized
DEBUG - 2021-12-14 16:20:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 16:20:44 --> Input Class Initialized
INFO - 2021-12-14 16:20:44 --> Language Class Initialized
ERROR - 2021-12-14 16:20:44 --> 404 Page Not Found: Cms/wp-includes
ERROR - 2021-12-14 16:20:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 16:20:45 --> Config Class Initialized
INFO - 2021-12-14 16:20:45 --> Hooks Class Initialized
DEBUG - 2021-12-14 16:20:45 --> UTF-8 Support Enabled
INFO - 2021-12-14 16:20:45 --> Utf8 Class Initialized
INFO - 2021-12-14 16:20:45 --> URI Class Initialized
INFO - 2021-12-14 16:20:45 --> Router Class Initialized
INFO - 2021-12-14 16:20:45 --> Output Class Initialized
INFO - 2021-12-14 16:20:45 --> Security Class Initialized
DEBUG - 2021-12-14 16:20:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 16:20:45 --> Input Class Initialized
INFO - 2021-12-14 16:20:45 --> Language Class Initialized
ERROR - 2021-12-14 16:20:45 --> 404 Page Not Found: Sito/wp-includes
ERROR - 2021-12-14 18:54:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 18:54:35 --> Config Class Initialized
INFO - 2021-12-14 18:54:35 --> Hooks Class Initialized
DEBUG - 2021-12-14 18:54:35 --> UTF-8 Support Enabled
INFO - 2021-12-14 18:54:35 --> Utf8 Class Initialized
INFO - 2021-12-14 18:54:35 --> URI Class Initialized
DEBUG - 2021-12-14 18:54:35 --> No URI present. Default controller set.
INFO - 2021-12-14 18:54:35 --> Router Class Initialized
INFO - 2021-12-14 18:54:35 --> Output Class Initialized
INFO - 2021-12-14 18:54:35 --> Security Class Initialized
DEBUG - 2021-12-14 18:54:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 18:54:35 --> Input Class Initialized
INFO - 2021-12-14 18:54:35 --> Language Class Initialized
INFO - 2021-12-14 18:54:35 --> Loader Class Initialized
INFO - 2021-12-14 18:54:35 --> Helper loaded: url_helper
INFO - 2021-12-14 18:54:35 --> Helper loaded: form_helper
INFO - 2021-12-14 18:54:35 --> Helper loaded: common_helper
INFO - 2021-12-14 18:54:35 --> Database Driver Class Initialized
DEBUG - 2021-12-14 18:54:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-14 18:54:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-14 18:54:35 --> Controller Class Initialized
INFO - 2021-12-14 18:54:35 --> Form Validation Class Initialized
DEBUG - 2021-12-14 18:54:35 --> Encrypt Class Initialized
DEBUG - 2021-12-14 18:54:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-14 18:54:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-14 18:54:35 --> Email Class Initialized
INFO - 2021-12-14 18:54:35 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-14 18:54:35 --> Calendar Class Initialized
INFO - 2021-12-14 18:54:35 --> Model "Login_model" initialized
INFO - 2021-12-14 18:54:35 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-14 18:54:35 --> Final output sent to browser
DEBUG - 2021-12-14 18:54:35 --> Total execution time: 0.0349
ERROR - 2021-12-14 19:09:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:09:16 --> Config Class Initialized
INFO - 2021-12-14 19:09:16 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:09:16 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:09:16 --> Utf8 Class Initialized
INFO - 2021-12-14 19:09:16 --> URI Class Initialized
DEBUG - 2021-12-14 19:09:16 --> No URI present. Default controller set.
INFO - 2021-12-14 19:09:16 --> Router Class Initialized
INFO - 2021-12-14 19:09:16 --> Output Class Initialized
INFO - 2021-12-14 19:09:16 --> Security Class Initialized
DEBUG - 2021-12-14 19:09:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:09:16 --> Input Class Initialized
INFO - 2021-12-14 19:09:16 --> Language Class Initialized
INFO - 2021-12-14 19:09:16 --> Loader Class Initialized
INFO - 2021-12-14 19:09:16 --> Helper loaded: url_helper
INFO - 2021-12-14 19:09:16 --> Helper loaded: form_helper
INFO - 2021-12-14 19:09:16 --> Helper loaded: common_helper
INFO - 2021-12-14 19:09:16 --> Database Driver Class Initialized
DEBUG - 2021-12-14 19:09:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-14 19:09:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-14 19:09:16 --> Controller Class Initialized
INFO - 2021-12-14 19:09:16 --> Form Validation Class Initialized
DEBUG - 2021-12-14 19:09:16 --> Encrypt Class Initialized
DEBUG - 2021-12-14 19:09:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-14 19:09:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-14 19:09:16 --> Email Class Initialized
INFO - 2021-12-14 19:09:16 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-14 19:09:16 --> Calendar Class Initialized
INFO - 2021-12-14 19:09:16 --> Model "Login_model" initialized
INFO - 2021-12-14 19:09:16 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-14 19:09:16 --> Final output sent to browser
DEBUG - 2021-12-14 19:09:16 --> Total execution time: 0.0257
ERROR - 2021-12-14 19:09:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:09:17 --> Config Class Initialized
INFO - 2021-12-14 19:09:17 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:09:17 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:09:17 --> Utf8 Class Initialized
INFO - 2021-12-14 19:09:17 --> URI Class Initialized
INFO - 2021-12-14 19:09:17 --> Router Class Initialized
INFO - 2021-12-14 19:09:17 --> Output Class Initialized
INFO - 2021-12-14 19:09:17 --> Security Class Initialized
DEBUG - 2021-12-14 19:09:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:09:17 --> Input Class Initialized
INFO - 2021-12-14 19:09:17 --> Language Class Initialized
ERROR - 2021-12-14 19:09:17 --> 404 Page Not Found: Test_404_page/index
ERROR - 2021-12-14 19:09:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:09:17 --> Config Class Initialized
INFO - 2021-12-14 19:09:17 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:09:17 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:09:17 --> Utf8 Class Initialized
INFO - 2021-12-14 19:09:17 --> URI Class Initialized
INFO - 2021-12-14 19:09:17 --> Router Class Initialized
INFO - 2021-12-14 19:09:17 --> Output Class Initialized
INFO - 2021-12-14 19:09:17 --> Security Class Initialized
DEBUG - 2021-12-14 19:09:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:09:17 --> Input Class Initialized
INFO - 2021-12-14 19:09:17 --> Language Class Initialized
ERROR - 2021-12-14 19:09:17 --> 404 Page Not Found: Issmall/index
ERROR - 2021-12-14 19:09:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:09:18 --> Config Class Initialized
INFO - 2021-12-14 19:09:18 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:09:18 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:09:18 --> Utf8 Class Initialized
INFO - 2021-12-14 19:09:18 --> URI Class Initialized
INFO - 2021-12-14 19:09:18 --> Router Class Initialized
INFO - 2021-12-14 19:09:18 --> Output Class Initialized
INFO - 2021-12-14 19:09:18 --> Security Class Initialized
DEBUG - 2021-12-14 19:09:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:09:18 --> Input Class Initialized
INFO - 2021-12-14 19:09:18 --> Language Class Initialized
ERROR - 2021-12-14 19:09:18 --> 404 Page Not Found: Ckeditor/ckeditor.js
ERROR - 2021-12-14 19:09:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:09:19 --> Config Class Initialized
INFO - 2021-12-14 19:09:19 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:09:19 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:09:19 --> Utf8 Class Initialized
INFO - 2021-12-14 19:09:19 --> URI Class Initialized
INFO - 2021-12-14 19:09:19 --> Router Class Initialized
INFO - 2021-12-14 19:09:19 --> Output Class Initialized
INFO - 2021-12-14 19:09:19 --> Security Class Initialized
DEBUG - 2021-12-14 19:09:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:09:19 --> Input Class Initialized
INFO - 2021-12-14 19:09:19 --> Language Class Initialized
ERROR - 2021-12-14 19:09:19 --> 404 Page Not Found: New_gb/help
ERROR - 2021-12-14 19:09:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:09:19 --> Config Class Initialized
INFO - 2021-12-14 19:09:19 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:09:19 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:09:19 --> Utf8 Class Initialized
INFO - 2021-12-14 19:09:19 --> URI Class Initialized
INFO - 2021-12-14 19:09:19 --> Router Class Initialized
INFO - 2021-12-14 19:09:19 --> Output Class Initialized
INFO - 2021-12-14 19:09:19 --> Security Class Initialized
DEBUG - 2021-12-14 19:09:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:09:19 --> Input Class Initialized
INFO - 2021-12-14 19:09:19 --> Language Class Initialized
ERROR - 2021-12-14 19:09:19 --> 404 Page Not Found: Web2/login_template
ERROR - 2021-12-14 19:09:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:09:20 --> Config Class Initialized
INFO - 2021-12-14 19:09:20 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:09:20 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:09:20 --> Utf8 Class Initialized
INFO - 2021-12-14 19:09:20 --> URI Class Initialized
INFO - 2021-12-14 19:09:20 --> Router Class Initialized
INFO - 2021-12-14 19:09:20 --> Output Class Initialized
INFO - 2021-12-14 19:09:20 --> Security Class Initialized
DEBUG - 2021-12-14 19:09:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:09:20 --> Input Class Initialized
INFO - 2021-12-14 19:09:20 --> Language Class Initialized
ERROR - 2021-12-14 19:09:20 --> 404 Page Not Found: Docs/index
ERROR - 2021-12-14 19:09:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:09:20 --> Config Class Initialized
INFO - 2021-12-14 19:09:20 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:09:20 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:09:20 --> Utf8 Class Initialized
INFO - 2021-12-14 19:09:20 --> URI Class Initialized
INFO - 2021-12-14 19:09:20 --> Router Class Initialized
INFO - 2021-12-14 19:09:20 --> Output Class Initialized
INFO - 2021-12-14 19:09:20 --> Security Class Initialized
DEBUG - 2021-12-14 19:09:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:09:20 --> Input Class Initialized
INFO - 2021-12-14 19:09:20 --> Language Class Initialized
ERROR - 2021-12-14 19:09:20 --> 404 Page Not Found: Fckeditor/fckconfig.js
ERROR - 2021-12-14 19:09:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:09:21 --> Config Class Initialized
INFO - 2021-12-14 19:09:21 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:09:21 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:09:21 --> Utf8 Class Initialized
INFO - 2021-12-14 19:09:21 --> URI Class Initialized
INFO - 2021-12-14 19:09:21 --> Router Class Initialized
INFO - 2021-12-14 19:09:21 --> Output Class Initialized
INFO - 2021-12-14 19:09:21 --> Security Class Initialized
DEBUG - 2021-12-14 19:09:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:09:21 --> Input Class Initialized
INFO - 2021-12-14 19:09:21 --> Language Class Initialized
ERROR - 2021-12-14 19:09:21 --> 404 Page Not Found: Fckeditor/editor
ERROR - 2021-12-14 19:09:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:09:21 --> Config Class Initialized
INFO - 2021-12-14 19:09:21 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:09:21 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:09:21 --> Utf8 Class Initialized
INFO - 2021-12-14 19:09:21 --> URI Class Initialized
INFO - 2021-12-14 19:09:21 --> Router Class Initialized
INFO - 2021-12-14 19:09:21 --> Output Class Initialized
INFO - 2021-12-14 19:09:21 --> Security Class Initialized
DEBUG - 2021-12-14 19:09:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:09:21 --> Input Class Initialized
INFO - 2021-12-14 19:09:21 --> Language Class Initialized
ERROR - 2021-12-14 19:09:21 --> 404 Page Not Found: Fckeditor/license.txt
ERROR - 2021-12-14 19:09:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:09:21 --> Config Class Initialized
INFO - 2021-12-14 19:09:21 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:09:21 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:09:21 --> Utf8 Class Initialized
INFO - 2021-12-14 19:09:21 --> URI Class Initialized
INFO - 2021-12-14 19:09:21 --> Router Class Initialized
INFO - 2021-12-14 19:09:21 --> Output Class Initialized
INFO - 2021-12-14 19:09:21 --> Security Class Initialized
DEBUG - 2021-12-14 19:09:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:09:21 --> Input Class Initialized
INFO - 2021-12-14 19:09:21 --> Language Class Initialized
ERROR - 2021-12-14 19:09:21 --> 404 Page Not Found: Fckeditor/editor
ERROR - 2021-12-14 19:09:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:09:22 --> Config Class Initialized
INFO - 2021-12-14 19:09:22 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:09:22 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:09:22 --> Utf8 Class Initialized
INFO - 2021-12-14 19:09:22 --> URI Class Initialized
INFO - 2021-12-14 19:09:22 --> Router Class Initialized
INFO - 2021-12-14 19:09:22 --> Output Class Initialized
INFO - 2021-12-14 19:09:22 --> Security Class Initialized
DEBUG - 2021-12-14 19:09:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:09:22 --> Input Class Initialized
INFO - 2021-12-14 19:09:22 --> Language Class Initialized
ERROR - 2021-12-14 19:09:22 --> 404 Page Not Found: Fckeditor/fckeditor.js
ERROR - 2021-12-14 19:09:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:09:22 --> Config Class Initialized
INFO - 2021-12-14 19:09:22 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:09:22 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:09:22 --> Utf8 Class Initialized
INFO - 2021-12-14 19:09:22 --> URI Class Initialized
INFO - 2021-12-14 19:09:22 --> Router Class Initialized
INFO - 2021-12-14 19:09:22 --> Output Class Initialized
INFO - 2021-12-14 19:09:22 --> Security Class Initialized
DEBUG - 2021-12-14 19:09:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:09:22 --> Input Class Initialized
INFO - 2021-12-14 19:09:22 --> Language Class Initialized
ERROR - 2021-12-14 19:09:22 --> 404 Page Not Found: FCK/editor
ERROR - 2021-12-14 19:09:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:09:22 --> Config Class Initialized
INFO - 2021-12-14 19:09:22 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:09:22 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:09:22 --> Utf8 Class Initialized
INFO - 2021-12-14 19:09:22 --> URI Class Initialized
INFO - 2021-12-14 19:09:22 --> Router Class Initialized
INFO - 2021-12-14 19:09:22 --> Output Class Initialized
INFO - 2021-12-14 19:09:22 --> Security Class Initialized
DEBUG - 2021-12-14 19:09:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:09:22 --> Input Class Initialized
INFO - 2021-12-14 19:09:22 --> Language Class Initialized
ERROR - 2021-12-14 19:09:22 --> 404 Page Not Found: FCK/fckeditor.js
ERROR - 2021-12-14 19:09:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:09:23 --> Config Class Initialized
INFO - 2021-12-14 19:09:23 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:09:23 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:09:23 --> Utf8 Class Initialized
INFO - 2021-12-14 19:09:23 --> URI Class Initialized
INFO - 2021-12-14 19:09:23 --> Router Class Initialized
INFO - 2021-12-14 19:09:23 --> Output Class Initialized
INFO - 2021-12-14 19:09:23 --> Security Class Initialized
DEBUG - 2021-12-14 19:09:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:09:23 --> Input Class Initialized
INFO - 2021-12-14 19:09:23 --> Language Class Initialized
ERROR - 2021-12-14 19:09:23 --> 404 Page Not Found: Fckeditorjs/index
ERROR - 2021-12-14 19:09:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:09:23 --> Config Class Initialized
INFO - 2021-12-14 19:09:23 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:09:23 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:09:23 --> Utf8 Class Initialized
INFO - 2021-12-14 19:09:23 --> URI Class Initialized
INFO - 2021-12-14 19:09:23 --> Router Class Initialized
INFO - 2021-12-14 19:09:23 --> Output Class Initialized
INFO - 2021-12-14 19:09:23 --> Security Class Initialized
DEBUG - 2021-12-14 19:09:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:09:23 --> Input Class Initialized
INFO - 2021-12-14 19:09:23 --> Language Class Initialized
ERROR - 2021-12-14 19:09:23 --> 404 Page Not Found: Editor/fckeditor.js
ERROR - 2021-12-14 19:09:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:09:23 --> Config Class Initialized
INFO - 2021-12-14 19:09:23 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:09:23 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:09:23 --> Utf8 Class Initialized
INFO - 2021-12-14 19:09:23 --> URI Class Initialized
INFO - 2021-12-14 19:09:23 --> Router Class Initialized
INFO - 2021-12-14 19:09:23 --> Output Class Initialized
INFO - 2021-12-14 19:09:23 --> Security Class Initialized
DEBUG - 2021-12-14 19:09:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:09:23 --> Input Class Initialized
INFO - 2021-12-14 19:09:23 --> Language Class Initialized
ERROR - 2021-12-14 19:09:23 --> 404 Page Not Found: Editor/js
ERROR - 2021-12-14 19:09:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:09:24 --> Config Class Initialized
INFO - 2021-12-14 19:09:24 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:09:24 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:09:24 --> Utf8 Class Initialized
INFO - 2021-12-14 19:09:24 --> URI Class Initialized
INFO - 2021-12-14 19:09:24 --> Router Class Initialized
INFO - 2021-12-14 19:09:24 --> Output Class Initialized
INFO - 2021-12-14 19:09:24 --> Security Class Initialized
DEBUG - 2021-12-14 19:09:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:09:24 --> Input Class Initialized
INFO - 2021-12-14 19:09:24 --> Language Class Initialized
ERROR - 2021-12-14 19:09:24 --> 404 Page Not Found: Docscss/index
ERROR - 2021-12-14 19:09:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:09:24 --> Config Class Initialized
INFO - 2021-12-14 19:09:24 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:09:24 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:09:24 --> Utf8 Class Initialized
INFO - 2021-12-14 19:09:24 --> URI Class Initialized
INFO - 2021-12-14 19:09:24 --> Router Class Initialized
INFO - 2021-12-14 19:09:24 --> Output Class Initialized
INFO - 2021-12-14 19:09:24 --> Security Class Initialized
DEBUG - 2021-12-14 19:09:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:09:24 --> Input Class Initialized
INFO - 2021-12-14 19:09:24 --> Language Class Initialized
ERROR - 2021-12-14 19:09:24 --> 404 Page Not Found: Phpmyadmin/themes
ERROR - 2021-12-14 19:09:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:09:24 --> Config Class Initialized
INFO - 2021-12-14 19:09:24 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:09:24 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:09:24 --> Utf8 Class Initialized
INFO - 2021-12-14 19:09:24 --> URI Class Initialized
INFO - 2021-12-14 19:09:24 --> Router Class Initialized
INFO - 2021-12-14 19:09:24 --> Output Class Initialized
INFO - 2021-12-14 19:09:24 --> Security Class Initialized
DEBUG - 2021-12-14 19:09:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:09:24 --> Input Class Initialized
INFO - 2021-12-14 19:09:24 --> Language Class Initialized
ERROR - 2021-12-14 19:09:24 --> 404 Page Not Found: Phpmyadmin/favicon.ico
ERROR - 2021-12-14 19:09:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:09:25 --> Config Class Initialized
INFO - 2021-12-14 19:09:25 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:09:25 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:09:25 --> Utf8 Class Initialized
INFO - 2021-12-14 19:09:25 --> URI Class Initialized
INFO - 2021-12-14 19:09:25 --> Router Class Initialized
INFO - 2021-12-14 19:09:25 --> Output Class Initialized
INFO - 2021-12-14 19:09:25 --> Security Class Initialized
DEBUG - 2021-12-14 19:09:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:09:25 --> Input Class Initialized
INFO - 2021-12-14 19:09:25 --> Language Class Initialized
ERROR - 2021-12-14 19:09:25 --> 404 Page Not Found: Phpmyadmin/docs.css
ERROR - 2021-12-14 19:09:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:09:25 --> Config Class Initialized
INFO - 2021-12-14 19:09:25 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:09:25 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:09:25 --> Utf8 Class Initialized
INFO - 2021-12-14 19:09:25 --> URI Class Initialized
DEBUG - 2021-12-14 19:09:25 --> No URI present. Default controller set.
INFO - 2021-12-14 19:09:25 --> Router Class Initialized
INFO - 2021-12-14 19:09:25 --> Output Class Initialized
INFO - 2021-12-14 19:09:25 --> Security Class Initialized
DEBUG - 2021-12-14 19:09:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:09:25 --> Input Class Initialized
INFO - 2021-12-14 19:09:25 --> Language Class Initialized
INFO - 2021-12-14 19:09:25 --> Loader Class Initialized
INFO - 2021-12-14 19:09:25 --> Helper loaded: url_helper
INFO - 2021-12-14 19:09:25 --> Helper loaded: form_helper
INFO - 2021-12-14 19:09:25 --> Helper loaded: common_helper
INFO - 2021-12-14 19:09:25 --> Database Driver Class Initialized
DEBUG - 2021-12-14 19:09:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-14 19:09:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-14 19:09:25 --> Controller Class Initialized
INFO - 2021-12-14 19:09:25 --> Form Validation Class Initialized
DEBUG - 2021-12-14 19:09:25 --> Encrypt Class Initialized
DEBUG - 2021-12-14 19:09:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-14 19:09:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-14 19:09:25 --> Email Class Initialized
INFO - 2021-12-14 19:09:25 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-14 19:09:25 --> Calendar Class Initialized
INFO - 2021-12-14 19:09:25 --> Model "Login_model" initialized
INFO - 2021-12-14 19:09:25 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-14 19:09:25 --> Final output sent to browser
DEBUG - 2021-12-14 19:09:25 --> Total execution time: 0.1576
ERROR - 2021-12-14 19:09:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:09:26 --> Config Class Initialized
INFO - 2021-12-14 19:09:26 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:09:26 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:09:26 --> Utf8 Class Initialized
INFO - 2021-12-14 19:09:26 --> URI Class Initialized
INFO - 2021-12-14 19:09:26 --> Router Class Initialized
INFO - 2021-12-14 19:09:26 --> Output Class Initialized
INFO - 2021-12-14 19:09:26 --> Security Class Initialized
DEBUG - 2021-12-14 19:09:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:09:26 --> Input Class Initialized
INFO - 2021-12-14 19:09:26 --> Language Class Initialized
ERROR - 2021-12-14 19:09:26 --> 404 Page Not Found: Tpl/user
ERROR - 2021-12-14 19:09:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:09:26 --> Config Class Initialized
INFO - 2021-12-14 19:09:26 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:09:26 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:09:26 --> Utf8 Class Initialized
INFO - 2021-12-14 19:09:26 --> URI Class Initialized
INFO - 2021-12-14 19:09:26 --> Router Class Initialized
INFO - 2021-12-14 19:09:26 --> Output Class Initialized
INFO - 2021-12-14 19:09:26 --> Security Class Initialized
DEBUG - 2021-12-14 19:09:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:09:26 --> Input Class Initialized
INFO - 2021-12-14 19:09:26 --> Language Class Initialized
ERROR - 2021-12-14 19:09:26 --> 404 Page Not Found: Tpl/login
ERROR - 2021-12-14 19:09:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:09:27 --> Config Class Initialized
INFO - 2021-12-14 19:09:27 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:09:27 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:09:27 --> Utf8 Class Initialized
INFO - 2021-12-14 19:09:27 --> URI Class Initialized
INFO - 2021-12-14 19:09:27 --> Router Class Initialized
INFO - 2021-12-14 19:09:27 --> Output Class Initialized
INFO - 2021-12-14 19:09:27 --> Security Class Initialized
DEBUG - 2021-12-14 19:09:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:09:27 --> Input Class Initialized
INFO - 2021-12-14 19:09:27 --> Language Class Initialized
ERROR - 2021-12-14 19:09:27 --> 404 Page Not Found: Auth/login
ERROR - 2021-12-14 19:09:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:09:27 --> Config Class Initialized
INFO - 2021-12-14 19:09:27 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:09:27 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:09:27 --> Utf8 Class Initialized
INFO - 2021-12-14 19:09:27 --> URI Class Initialized
INFO - 2021-12-14 19:09:27 --> Router Class Initialized
INFO - 2021-12-14 19:09:27 --> Output Class Initialized
INFO - 2021-12-14 19:09:27 --> Security Class Initialized
DEBUG - 2021-12-14 19:09:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:09:27 --> Input Class Initialized
INFO - 2021-12-14 19:09:27 --> Language Class Initialized
ERROR - 2021-12-14 19:09:27 --> 404 Page Not Found: E/master
ERROR - 2021-12-14 19:09:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:09:28 --> Config Class Initialized
INFO - 2021-12-14 19:09:28 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:09:28 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:09:28 --> Utf8 Class Initialized
INFO - 2021-12-14 19:09:28 --> URI Class Initialized
INFO - 2021-12-14 19:09:28 --> Router Class Initialized
INFO - 2021-12-14 19:09:28 --> Output Class Initialized
INFO - 2021-12-14 19:09:28 --> Security Class Initialized
DEBUG - 2021-12-14 19:09:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:09:28 --> Input Class Initialized
INFO - 2021-12-14 19:09:28 --> Language Class Initialized
ERROR - 2021-12-14 19:09:28 --> 404 Page Not Found: Master/login.aspx
ERROR - 2021-12-14 19:09:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:09:28 --> Config Class Initialized
INFO - 2021-12-14 19:09:28 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:09:28 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:09:28 --> Utf8 Class Initialized
INFO - 2021-12-14 19:09:28 --> URI Class Initialized
INFO - 2021-12-14 19:09:28 --> Router Class Initialized
INFO - 2021-12-14 19:09:28 --> Output Class Initialized
INFO - 2021-12-14 19:09:28 --> Security Class Initialized
DEBUG - 2021-12-14 19:09:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:09:28 --> Input Class Initialized
INFO - 2021-12-14 19:09:28 --> Language Class Initialized
ERROR - 2021-12-14 19:09:28 --> 404 Page Not Found: Licensetxt/index
ERROR - 2021-12-14 19:09:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:09:28 --> Config Class Initialized
INFO - 2021-12-14 19:09:28 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:09:28 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:09:28 --> Utf8 Class Initialized
INFO - 2021-12-14 19:09:28 --> URI Class Initialized
INFO - 2021-12-14 19:09:28 --> Router Class Initialized
INFO - 2021-12-14 19:09:28 --> Output Class Initialized
INFO - 2021-12-14 19:09:28 --> Security Class Initialized
DEBUG - 2021-12-14 19:09:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:09:28 --> Input Class Initialized
INFO - 2021-12-14 19:09:28 --> Language Class Initialized
ERROR - 2021-12-14 19:09:28 --> 404 Page Not Found: Admin/index
ERROR - 2021-12-14 19:09:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:09:29 --> Config Class Initialized
INFO - 2021-12-14 19:09:29 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:09:29 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:09:29 --> Utf8 Class Initialized
INFO - 2021-12-14 19:09:29 --> URI Class Initialized
INFO - 2021-12-14 19:09:29 --> Router Class Initialized
INFO - 2021-12-14 19:09:29 --> Output Class Initialized
INFO - 2021-12-14 19:09:29 --> Security Class Initialized
DEBUG - 2021-12-14 19:09:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:09:29 --> Input Class Initialized
INFO - 2021-12-14 19:09:29 --> Language Class Initialized
ERROR - 2021-12-14 19:09:29 --> 404 Page Not Found: Listphp/index
ERROR - 2021-12-14 19:09:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:09:29 --> Config Class Initialized
INFO - 2021-12-14 19:09:29 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:09:29 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:09:29 --> Utf8 Class Initialized
INFO - 2021-12-14 19:09:29 --> URI Class Initialized
INFO - 2021-12-14 19:09:29 --> Router Class Initialized
INFO - 2021-12-14 19:09:29 --> Output Class Initialized
INFO - 2021-12-14 19:09:29 --> Security Class Initialized
DEBUG - 2021-12-14 19:09:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:09:29 --> Input Class Initialized
INFO - 2021-12-14 19:09:29 --> Language Class Initialized
ERROR - 2021-12-14 19:09:29 --> 404 Page Not Found: Admin/template
ERROR - 2021-12-14 19:09:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:09:29 --> Config Class Initialized
INFO - 2021-12-14 19:09:29 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:09:29 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:09:29 --> Utf8 Class Initialized
INFO - 2021-12-14 19:09:29 --> URI Class Initialized
INFO - 2021-12-14 19:09:29 --> Router Class Initialized
INFO - 2021-12-14 19:09:29 --> Output Class Initialized
INFO - 2021-12-14 19:09:29 --> Security Class Initialized
DEBUG - 2021-12-14 19:09:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:09:29 --> Input Class Initialized
INFO - 2021-12-14 19:09:29 --> Language Class Initialized
ERROR - 2021-12-14 19:09:29 --> 404 Page Not Found: Ckfinder/ckfinder.html
ERROR - 2021-12-14 19:09:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:09:30 --> Config Class Initialized
INFO - 2021-12-14 19:09:30 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:09:30 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:09:30 --> Utf8 Class Initialized
INFO - 2021-12-14 19:09:30 --> URI Class Initialized
INFO - 2021-12-14 19:09:30 --> Router Class Initialized
INFO - 2021-12-14 19:09:30 --> Output Class Initialized
INFO - 2021-12-14 19:09:30 --> Security Class Initialized
DEBUG - 2021-12-14 19:09:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:09:30 --> Input Class Initialized
INFO - 2021-12-14 19:09:30 --> Language Class Initialized
ERROR - 2021-12-14 19:09:30 --> 404 Page Not Found: Ckfinder/install.txt
ERROR - 2021-12-14 19:09:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:09:30 --> Config Class Initialized
INFO - 2021-12-14 19:09:30 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:09:30 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:09:30 --> Utf8 Class Initialized
INFO - 2021-12-14 19:09:30 --> URI Class Initialized
INFO - 2021-12-14 19:09:30 --> Router Class Initialized
INFO - 2021-12-14 19:09:30 --> Output Class Initialized
INFO - 2021-12-14 19:09:30 --> Security Class Initialized
DEBUG - 2021-12-14 19:09:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:09:30 --> Input Class Initialized
INFO - 2021-12-14 19:09:30 --> Language Class Initialized
ERROR - 2021-12-14 19:09:30 --> 404 Page Not Found: Ckeditor/ckfinder
ERROR - 2021-12-14 19:09:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:09:31 --> Config Class Initialized
INFO - 2021-12-14 19:09:31 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:09:31 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:09:31 --> Utf8 Class Initialized
INFO - 2021-12-14 19:09:31 --> URI Class Initialized
INFO - 2021-12-14 19:09:31 --> Router Class Initialized
INFO - 2021-12-14 19:09:31 --> Output Class Initialized
INFO - 2021-12-14 19:09:31 --> Security Class Initialized
DEBUG - 2021-12-14 19:09:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:09:31 --> Input Class Initialized
INFO - 2021-12-14 19:09:31 --> Language Class Initialized
ERROR - 2021-12-14 19:09:31 --> 404 Page Not Found: Ckeditor/ckfinder
ERROR - 2021-12-14 19:09:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:09:31 --> Config Class Initialized
INFO - 2021-12-14 19:09:31 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:09:31 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:09:31 --> Utf8 Class Initialized
INFO - 2021-12-14 19:09:31 --> URI Class Initialized
INFO - 2021-12-14 19:09:31 --> Router Class Initialized
INFO - 2021-12-14 19:09:31 --> Output Class Initialized
INFO - 2021-12-14 19:09:31 --> Security Class Initialized
DEBUG - 2021-12-14 19:09:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:09:31 --> Input Class Initialized
INFO - 2021-12-14 19:09:31 --> Language Class Initialized
ERROR - 2021-12-14 19:09:31 --> 404 Page Not Found: Common/help
ERROR - 2021-12-14 19:09:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:09:32 --> Config Class Initialized
INFO - 2021-12-14 19:09:32 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:09:32 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:09:32 --> Utf8 Class Initialized
INFO - 2021-12-14 19:09:32 --> URI Class Initialized
INFO - 2021-12-14 19:09:32 --> Router Class Initialized
INFO - 2021-12-14 19:09:32 --> Output Class Initialized
INFO - 2021-12-14 19:09:32 --> Security Class Initialized
DEBUG - 2021-12-14 19:09:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:09:32 --> Input Class Initialized
INFO - 2021-12-14 19:09:32 --> Language Class Initialized
ERROR - 2021-12-14 19:09:32 --> 404 Page Not Found: Common/help
ERROR - 2021-12-14 19:09:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:09:32 --> Config Class Initialized
INFO - 2021-12-14 19:09:32 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:09:32 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:09:32 --> Utf8 Class Initialized
INFO - 2021-12-14 19:09:32 --> URI Class Initialized
INFO - 2021-12-14 19:09:32 --> Router Class Initialized
INFO - 2021-12-14 19:09:32 --> Output Class Initialized
INFO - 2021-12-14 19:09:32 --> Security Class Initialized
DEBUG - 2021-12-14 19:09:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:09:32 --> Input Class Initialized
INFO - 2021-12-14 19:09:32 --> Language Class Initialized
ERROR - 2021-12-14 19:09:32 --> 404 Page Not Found: Coremail/common
ERROR - 2021-12-14 19:09:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:09:33 --> Config Class Initialized
INFO - 2021-12-14 19:09:33 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:09:33 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:09:33 --> Utf8 Class Initialized
INFO - 2021-12-14 19:09:33 --> URI Class Initialized
INFO - 2021-12-14 19:09:33 --> Router Class Initialized
INFO - 2021-12-14 19:09:33 --> Output Class Initialized
INFO - 2021-12-14 19:09:33 --> Security Class Initialized
DEBUG - 2021-12-14 19:09:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:09:33 --> Input Class Initialized
INFO - 2021-12-14 19:09:33 --> Language Class Initialized
ERROR - 2021-12-14 19:09:33 --> 404 Page Not Found: Coremail/common
ERROR - 2021-12-14 19:09:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:09:33 --> Config Class Initialized
INFO - 2021-12-14 19:09:33 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:09:33 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:09:33 --> Utf8 Class Initialized
INFO - 2021-12-14 19:09:33 --> URI Class Initialized
INFO - 2021-12-14 19:09:33 --> Router Class Initialized
INFO - 2021-12-14 19:09:33 --> Output Class Initialized
INFO - 2021-12-14 19:09:33 --> Security Class Initialized
DEBUG - 2021-12-14 19:09:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:09:33 --> Input Class Initialized
INFO - 2021-12-14 19:09:33 --> Language Class Initialized
ERROR - 2021-12-14 19:09:33 --> 404 Page Not Found: Images/login
ERROR - 2021-12-14 19:09:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:09:33 --> Config Class Initialized
INFO - 2021-12-14 19:09:33 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:09:33 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:09:33 --> Utf8 Class Initialized
INFO - 2021-12-14 19:09:33 --> URI Class Initialized
INFO - 2021-12-14 19:09:33 --> Router Class Initialized
INFO - 2021-12-14 19:09:33 --> Output Class Initialized
INFO - 2021-12-14 19:09:33 --> Security Class Initialized
DEBUG - 2021-12-14 19:09:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:09:33 --> Input Class Initialized
INFO - 2021-12-14 19:09:33 --> Language Class Initialized
ERROR - 2021-12-14 19:09:33 --> 404 Page Not Found: Images/login
ERROR - 2021-12-14 19:09:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:09:34 --> Config Class Initialized
INFO - 2021-12-14 19:09:34 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:09:34 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:09:34 --> Utf8 Class Initialized
INFO - 2021-12-14 19:09:34 --> URI Class Initialized
INFO - 2021-12-14 19:09:34 --> Router Class Initialized
INFO - 2021-12-14 19:09:34 --> Output Class Initialized
INFO - 2021-12-14 19:09:34 --> Security Class Initialized
DEBUG - 2021-12-14 19:09:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:09:34 --> Input Class Initialized
INFO - 2021-12-14 19:09:34 --> Language Class Initialized
ERROR - 2021-12-14 19:09:34 --> 404 Page Not Found: Images/login
ERROR - 2021-12-14 19:09:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:09:34 --> Config Class Initialized
INFO - 2021-12-14 19:09:34 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:09:34 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:09:34 --> Utf8 Class Initialized
INFO - 2021-12-14 19:09:34 --> URI Class Initialized
INFO - 2021-12-14 19:09:34 --> Router Class Initialized
INFO - 2021-12-14 19:09:34 --> Output Class Initialized
INFO - 2021-12-14 19:09:34 --> Security Class Initialized
DEBUG - 2021-12-14 19:09:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:09:34 --> Input Class Initialized
INFO - 2021-12-14 19:09:34 --> Language Class Initialized
ERROR - 2021-12-14 19:09:34 --> 404 Page Not Found: Next/img
ERROR - 2021-12-14 19:09:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:09:34 --> Config Class Initialized
INFO - 2021-12-14 19:09:34 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:09:34 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:09:34 --> Utf8 Class Initialized
INFO - 2021-12-14 19:09:34 --> URI Class Initialized
INFO - 2021-12-14 19:09:34 --> Router Class Initialized
INFO - 2021-12-14 19:09:34 --> Output Class Initialized
INFO - 2021-12-14 19:09:34 --> Security Class Initialized
DEBUG - 2021-12-14 19:09:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:09:34 --> Input Class Initialized
INFO - 2021-12-14 19:09:34 --> Language Class Initialized
ERROR - 2021-12-14 19:09:34 --> 404 Page Not Found: Maintloginjsp/index
ERROR - 2021-12-14 19:09:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:09:35 --> Config Class Initialized
INFO - 2021-12-14 19:09:35 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:09:35 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:09:35 --> Utf8 Class Initialized
INFO - 2021-12-14 19:09:35 --> URI Class Initialized
INFO - 2021-12-14 19:09:35 --> Router Class Initialized
INFO - 2021-12-14 19:09:35 --> Output Class Initialized
INFO - 2021-12-14 19:09:35 --> Security Class Initialized
DEBUG - 2021-12-14 19:09:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:09:35 --> Input Class Initialized
INFO - 2021-12-14 19:09:35 --> Language Class Initialized
ERROR - 2021-12-14 19:09:35 --> 404 Page Not Found: Dialog/dialog.js
ERROR - 2021-12-14 19:09:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:09:35 --> Config Class Initialized
INFO - 2021-12-14 19:09:35 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:09:35 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:09:35 --> Utf8 Class Initialized
INFO - 2021-12-14 19:09:35 --> URI Class Initialized
INFO - 2021-12-14 19:09:35 --> Router Class Initialized
INFO - 2021-12-14 19:09:35 --> Output Class Initialized
INFO - 2021-12-14 19:09:35 --> Security Class Initialized
DEBUG - 2021-12-14 19:09:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:09:35 --> Input Class Initialized
INFO - 2021-12-14 19:09:35 --> Language Class Initialized
ERROR - 2021-12-14 19:09:35 --> 404 Page Not Found: Editorjs/index
ERROR - 2021-12-14 19:09:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:09:36 --> Config Class Initialized
INFO - 2021-12-14 19:09:36 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:09:36 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:09:36 --> Utf8 Class Initialized
INFO - 2021-12-14 19:09:36 --> URI Class Initialized
INFO - 2021-12-14 19:09:36 --> Router Class Initialized
INFO - 2021-12-14 19:09:36 --> Output Class Initialized
INFO - 2021-12-14 19:09:36 --> Security Class Initialized
DEBUG - 2021-12-14 19:09:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:09:36 --> Input Class Initialized
INFO - 2021-12-14 19:09:36 --> Language Class Initialized
ERROR - 2021-12-14 19:09:36 --> 404 Page Not Found: Indexcgi/index
ERROR - 2021-12-14 19:09:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:09:36 --> Config Class Initialized
INFO - 2021-12-14 19:09:36 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:09:36 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:09:36 --> Utf8 Class Initialized
INFO - 2021-12-14 19:09:36 --> URI Class Initialized
INFO - 2021-12-14 19:09:36 --> Router Class Initialized
INFO - 2021-12-14 19:09:36 --> Output Class Initialized
INFO - 2021-12-14 19:09:36 --> Security Class Initialized
DEBUG - 2021-12-14 19:09:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:09:36 --> Input Class Initialized
INFO - 2021-12-14 19:09:36 --> Language Class Initialized
ERROR - 2021-12-14 19:09:36 --> 404 Page Not Found: Cgi/index.cgi
ERROR - 2021-12-14 19:09:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:09:36 --> Config Class Initialized
INFO - 2021-12-14 19:09:36 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:09:36 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:09:36 --> Utf8 Class Initialized
INFO - 2021-12-14 19:09:36 --> URI Class Initialized
INFO - 2021-12-14 19:09:36 --> Router Class Initialized
INFO - 2021-12-14 19:09:36 --> Output Class Initialized
INFO - 2021-12-14 19:09:36 --> Security Class Initialized
DEBUG - 2021-12-14 19:09:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:09:36 --> Input Class Initialized
INFO - 2021-12-14 19:09:36 --> Language Class Initialized
ERROR - 2021-12-14 19:09:36 --> 404 Page Not Found: Default/images
ERROR - 2021-12-14 19:09:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:09:37 --> Config Class Initialized
INFO - 2021-12-14 19:09:37 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:09:37 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:09:37 --> Utf8 Class Initialized
INFO - 2021-12-14 19:09:37 --> URI Class Initialized
INFO - 2021-12-14 19:09:37 --> Router Class Initialized
INFO - 2021-12-14 19:09:37 --> Output Class Initialized
INFO - 2021-12-14 19:09:37 --> Security Class Initialized
DEBUG - 2021-12-14 19:09:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:09:37 --> Input Class Initialized
INFO - 2021-12-14 19:09:37 --> Language Class Initialized
ERROR - 2021-12-14 19:09:37 --> 404 Page Not Found: Extman/default
ERROR - 2021-12-14 19:09:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:09:37 --> Config Class Initialized
INFO - 2021-12-14 19:09:37 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:09:37 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:09:37 --> Utf8 Class Initialized
INFO - 2021-12-14 19:09:37 --> URI Class Initialized
INFO - 2021-12-14 19:09:37 --> Router Class Initialized
INFO - 2021-12-14 19:09:37 --> Output Class Initialized
INFO - 2021-12-14 19:09:37 --> Security Class Initialized
DEBUG - 2021-12-14 19:09:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:09:37 --> Input Class Initialized
INFO - 2021-12-14 19:09:37 --> Language Class Initialized
ERROR - 2021-12-14 19:09:37 --> 404 Page Not Found: Help/ch_gb
ERROR - 2021-12-14 19:09:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:09:38 --> Config Class Initialized
INFO - 2021-12-14 19:09:38 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:09:38 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:09:38 --> Utf8 Class Initialized
INFO - 2021-12-14 19:09:38 --> URI Class Initialized
INFO - 2021-12-14 19:09:38 --> Router Class Initialized
INFO - 2021-12-14 19:09:38 --> Output Class Initialized
INFO - 2021-12-14 19:09:38 --> Security Class Initialized
DEBUG - 2021-12-14 19:09:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:09:38 --> Input Class Initialized
INFO - 2021-12-14 19:09:38 --> Language Class Initialized
ERROR - 2021-12-14 19:09:38 --> 404 Page Not Found: Admin/index.php
ERROR - 2021-12-14 19:09:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:09:38 --> Config Class Initialized
INFO - 2021-12-14 19:09:38 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:09:38 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:09:38 --> Utf8 Class Initialized
INFO - 2021-12-14 19:09:38 --> URI Class Initialized
INFO - 2021-12-14 19:09:38 --> Router Class Initialized
INFO - 2021-12-14 19:09:38 --> Output Class Initialized
INFO - 2021-12-14 19:09:38 --> Security Class Initialized
DEBUG - 2021-12-14 19:09:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:09:38 --> Input Class Initialized
INFO - 2021-12-14 19:09:38 --> Language Class Initialized
ERROR - 2021-12-14 19:09:38 --> 404 Page Not Found: Admin/js
ERROR - 2021-12-14 19:09:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:09:38 --> Config Class Initialized
INFO - 2021-12-14 19:09:38 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:09:38 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:09:38 --> Utf8 Class Initialized
INFO - 2021-12-14 19:09:38 --> URI Class Initialized
INFO - 2021-12-14 19:09:38 --> Router Class Initialized
INFO - 2021-12-14 19:09:38 --> Output Class Initialized
INFO - 2021-12-14 19:09:38 --> Security Class Initialized
DEBUG - 2021-12-14 19:09:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:09:38 --> Input Class Initialized
INFO - 2021-12-14 19:09:38 --> Language Class Initialized
ERROR - 2021-12-14 19:09:38 --> 404 Page Not Found: Ids/admin
ERROR - 2021-12-14 19:09:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:09:39 --> Config Class Initialized
INFO - 2021-12-14 19:09:39 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:09:39 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:09:39 --> Utf8 Class Initialized
INFO - 2021-12-14 19:09:39 --> URI Class Initialized
INFO - 2021-12-14 19:09:39 --> Router Class Initialized
INFO - 2021-12-14 19:09:39 --> Output Class Initialized
INFO - 2021-12-14 19:09:39 --> Security Class Initialized
DEBUG - 2021-12-14 19:09:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:09:39 --> Input Class Initialized
INFO - 2021-12-14 19:09:39 --> Language Class Initialized
ERROR - 2021-12-14 19:09:39 --> 404 Page Not Found: Ids/admin
ERROR - 2021-12-14 19:09:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:09:39 --> Config Class Initialized
INFO - 2021-12-14 19:09:39 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:09:39 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:09:39 --> Utf8 Class Initialized
INFO - 2021-12-14 19:09:39 --> URI Class Initialized
INFO - 2021-12-14 19:09:39 --> Router Class Initialized
INFO - 2021-12-14 19:09:39 --> Output Class Initialized
INFO - 2021-12-14 19:09:39 --> Security Class Initialized
DEBUG - 2021-12-14 19:09:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:09:39 --> Input Class Initialized
INFO - 2021-12-14 19:09:39 --> Language Class Initialized
ERROR - 2021-12-14 19:09:39 --> 404 Page Not Found: Bencandyphp/index
ERROR - 2021-12-14 19:09:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:09:40 --> Config Class Initialized
INFO - 2021-12-14 19:09:40 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:09:40 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:09:40 --> Utf8 Class Initialized
INFO - 2021-12-14 19:09:40 --> URI Class Initialized
INFO - 2021-12-14 19:09:40 --> Router Class Initialized
INFO - 2021-12-14 19:09:40 --> Output Class Initialized
INFO - 2021-12-14 19:09:40 --> Security Class Initialized
DEBUG - 2021-12-14 19:09:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:09:40 --> Input Class Initialized
INFO - 2021-12-14 19:09:40 --> Language Class Initialized
ERROR - 2021-12-14 19:09:40 --> 404 Page Not Found: Siteserver/upgrade
ERROR - 2021-12-14 19:09:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:09:41 --> Config Class Initialized
INFO - 2021-12-14 19:09:41 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:09:41 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:09:41 --> Utf8 Class Initialized
INFO - 2021-12-14 19:09:41 --> URI Class Initialized
INFO - 2021-12-14 19:09:41 --> Router Class Initialized
INFO - 2021-12-14 19:09:41 --> Output Class Initialized
INFO - 2021-12-14 19:09:41 --> Security Class Initialized
DEBUG - 2021-12-14 19:09:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:09:41 --> Input Class Initialized
INFO - 2021-12-14 19:09:41 --> Language Class Initialized
ERROR - 2021-12-14 19:09:41 --> 404 Page Not Found: Siteserver/login.aspx
ERROR - 2021-12-14 19:09:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:09:41 --> Config Class Initialized
INFO - 2021-12-14 19:09:41 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:09:41 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:09:41 --> Utf8 Class Initialized
INFO - 2021-12-14 19:09:41 --> URI Class Initialized
INFO - 2021-12-14 19:09:41 --> Router Class Initialized
INFO - 2021-12-14 19:09:41 --> Output Class Initialized
INFO - 2021-12-14 19:09:41 --> Security Class Initialized
DEBUG - 2021-12-14 19:09:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:09:41 --> Input Class Initialized
INFO - 2021-12-14 19:09:41 --> Language Class Initialized
ERROR - 2021-12-14 19:09:41 --> 404 Page Not Found: UserCenter/css
ERROR - 2021-12-14 19:09:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:09:42 --> Config Class Initialized
INFO - 2021-12-14 19:09:42 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:09:42 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:09:42 --> Utf8 Class Initialized
INFO - 2021-12-14 19:09:42 --> URI Class Initialized
INFO - 2021-12-14 19:09:42 --> Router Class Initialized
INFO - 2021-12-14 19:09:42 --> Output Class Initialized
INFO - 2021-12-14 19:09:42 --> Security Class Initialized
DEBUG - 2021-12-14 19:09:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:09:42 --> Input Class Initialized
INFO - 2021-12-14 19:09:42 --> Language Class Initialized
ERROR - 2021-12-14 19:09:42 --> 404 Page Not Found: Admin/inc
ERROR - 2021-12-14 19:09:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:09:42 --> Config Class Initialized
INFO - 2021-12-14 19:09:42 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:09:42 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:09:42 --> Utf8 Class Initialized
INFO - 2021-12-14 19:09:42 --> URI Class Initialized
INFO - 2021-12-14 19:09:42 --> Router Class Initialized
INFO - 2021-12-14 19:09:42 --> Output Class Initialized
INFO - 2021-12-14 19:09:42 --> Security Class Initialized
DEBUG - 2021-12-14 19:09:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:09:42 --> Input Class Initialized
INFO - 2021-12-14 19:09:42 --> Language Class Initialized
ERROR - 2021-12-14 19:09:42 --> 404 Page Not Found: CuteSoft_Client/CuteEditor
ERROR - 2021-12-14 19:09:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:09:42 --> Config Class Initialized
INFO - 2021-12-14 19:09:42 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:09:42 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:09:42 --> Utf8 Class Initialized
INFO - 2021-12-14 19:09:42 --> URI Class Initialized
INFO - 2021-12-14 19:09:42 --> Router Class Initialized
INFO - 2021-12-14 19:09:42 --> Output Class Initialized
INFO - 2021-12-14 19:09:42 --> Security Class Initialized
DEBUG - 2021-12-14 19:09:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:09:42 --> Input Class Initialized
INFO - 2021-12-14 19:09:42 --> Language Class Initialized
ERROR - 2021-12-14 19:09:42 --> 404 Page Not Found: CuteSoft_Client/CuteEditor
ERROR - 2021-12-14 19:09:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:09:43 --> Config Class Initialized
INFO - 2021-12-14 19:09:43 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:09:43 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:09:43 --> Utf8 Class Initialized
INFO - 2021-12-14 19:09:43 --> URI Class Initialized
INFO - 2021-12-14 19:09:43 --> Router Class Initialized
INFO - 2021-12-14 19:09:43 --> Output Class Initialized
INFO - 2021-12-14 19:09:43 --> Security Class Initialized
DEBUG - 2021-12-14 19:09:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:09:43 --> Input Class Initialized
INFO - 2021-12-14 19:09:43 --> Language Class Initialized
ERROR - 2021-12-14 19:09:43 --> 404 Page Not Found: CuteSoft_Client/CuteEditor
ERROR - 2021-12-14 19:09:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:09:43 --> Config Class Initialized
INFO - 2021-12-14 19:09:43 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:09:43 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:09:43 --> Utf8 Class Initialized
INFO - 2021-12-14 19:09:43 --> URI Class Initialized
INFO - 2021-12-14 19:09:43 --> Router Class Initialized
INFO - 2021-12-14 19:09:43 --> Output Class Initialized
INFO - 2021-12-14 19:09:43 --> Security Class Initialized
DEBUG - 2021-12-14 19:09:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:09:43 --> Input Class Initialized
INFO - 2021-12-14 19:09:43 --> Language Class Initialized
ERROR - 2021-12-14 19:09:43 --> 404 Page Not Found: CuteSoft_Client/CuteEditor
ERROR - 2021-12-14 19:09:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:09:44 --> Config Class Initialized
INFO - 2021-12-14 19:09:44 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:09:44 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:09:44 --> Utf8 Class Initialized
INFO - 2021-12-14 19:09:44 --> URI Class Initialized
DEBUG - 2021-12-14 19:09:44 --> No URI present. Default controller set.
INFO - 2021-12-14 19:09:44 --> Router Class Initialized
INFO - 2021-12-14 19:09:44 --> Output Class Initialized
INFO - 2021-12-14 19:09:44 --> Security Class Initialized
DEBUG - 2021-12-14 19:09:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:09:44 --> Input Class Initialized
INFO - 2021-12-14 19:09:44 --> Language Class Initialized
INFO - 2021-12-14 19:09:44 --> Loader Class Initialized
INFO - 2021-12-14 19:09:44 --> Helper loaded: url_helper
INFO - 2021-12-14 19:09:44 --> Helper loaded: form_helper
INFO - 2021-12-14 19:09:44 --> Helper loaded: common_helper
INFO - 2021-12-14 19:09:44 --> Database Driver Class Initialized
DEBUG - 2021-12-14 19:09:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-14 19:09:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-14 19:09:44 --> Controller Class Initialized
INFO - 2021-12-14 19:09:44 --> Form Validation Class Initialized
DEBUG - 2021-12-14 19:09:44 --> Encrypt Class Initialized
DEBUG - 2021-12-14 19:09:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-14 19:09:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-14 19:09:44 --> Email Class Initialized
INFO - 2021-12-14 19:09:44 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-14 19:09:44 --> Calendar Class Initialized
INFO - 2021-12-14 19:09:44 --> Model "Login_model" initialized
INFO - 2021-12-14 19:09:44 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-14 19:09:44 --> Final output sent to browser
DEBUG - 2021-12-14 19:09:44 --> Total execution time: 0.0226
ERROR - 2021-12-14 19:09:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:09:44 --> Config Class Initialized
INFO - 2021-12-14 19:09:44 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:09:44 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:09:44 --> Utf8 Class Initialized
INFO - 2021-12-14 19:09:44 --> URI Class Initialized
DEBUG - 2021-12-14 19:09:44 --> No URI present. Default controller set.
INFO - 2021-12-14 19:09:44 --> Router Class Initialized
INFO - 2021-12-14 19:09:44 --> Output Class Initialized
INFO - 2021-12-14 19:09:44 --> Security Class Initialized
DEBUG - 2021-12-14 19:09:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:09:44 --> Input Class Initialized
INFO - 2021-12-14 19:09:44 --> Language Class Initialized
INFO - 2021-12-14 19:09:44 --> Loader Class Initialized
INFO - 2021-12-14 19:09:44 --> Helper loaded: url_helper
INFO - 2021-12-14 19:09:44 --> Helper loaded: form_helper
INFO - 2021-12-14 19:09:44 --> Helper loaded: common_helper
INFO - 2021-12-14 19:09:44 --> Database Driver Class Initialized
DEBUG - 2021-12-14 19:09:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-14 19:09:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-14 19:09:44 --> Controller Class Initialized
INFO - 2021-12-14 19:09:44 --> Form Validation Class Initialized
DEBUG - 2021-12-14 19:09:44 --> Encrypt Class Initialized
DEBUG - 2021-12-14 19:09:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-14 19:09:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-14 19:09:44 --> Email Class Initialized
INFO - 2021-12-14 19:09:44 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-14 19:09:44 --> Calendar Class Initialized
INFO - 2021-12-14 19:09:44 --> Model "Login_model" initialized
INFO - 2021-12-14 19:09:44 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-14 19:09:44 --> Final output sent to browser
DEBUG - 2021-12-14 19:09:44 --> Total execution time: 0.0223
ERROR - 2021-12-14 19:09:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:09:44 --> Config Class Initialized
INFO - 2021-12-14 19:09:44 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:09:44 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:09:44 --> Utf8 Class Initialized
INFO - 2021-12-14 19:09:44 --> URI Class Initialized
DEBUG - 2021-12-14 19:09:44 --> No URI present. Default controller set.
INFO - 2021-12-14 19:09:44 --> Router Class Initialized
INFO - 2021-12-14 19:09:44 --> Output Class Initialized
INFO - 2021-12-14 19:09:44 --> Security Class Initialized
DEBUG - 2021-12-14 19:09:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:09:44 --> Input Class Initialized
INFO - 2021-12-14 19:09:44 --> Language Class Initialized
INFO - 2021-12-14 19:09:44 --> Loader Class Initialized
INFO - 2021-12-14 19:09:44 --> Helper loaded: url_helper
INFO - 2021-12-14 19:09:44 --> Helper loaded: form_helper
INFO - 2021-12-14 19:09:44 --> Helper loaded: common_helper
INFO - 2021-12-14 19:09:44 --> Database Driver Class Initialized
DEBUG - 2021-12-14 19:09:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-14 19:09:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-14 19:09:44 --> Controller Class Initialized
INFO - 2021-12-14 19:09:44 --> Form Validation Class Initialized
DEBUG - 2021-12-14 19:09:44 --> Encrypt Class Initialized
DEBUG - 2021-12-14 19:09:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-14 19:09:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-14 19:09:44 --> Email Class Initialized
INFO - 2021-12-14 19:09:44 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-14 19:09:44 --> Calendar Class Initialized
INFO - 2021-12-14 19:09:44 --> Model "Login_model" initialized
INFO - 2021-12-14 19:09:44 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-14 19:09:44 --> Final output sent to browser
DEBUG - 2021-12-14 19:09:44 --> Total execution time: 0.0226
ERROR - 2021-12-14 19:09:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:09:45 --> Config Class Initialized
INFO - 2021-12-14 19:09:45 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:09:45 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:09:45 --> Utf8 Class Initialized
INFO - 2021-12-14 19:09:45 --> URI Class Initialized
DEBUG - 2021-12-14 19:09:45 --> No URI present. Default controller set.
INFO - 2021-12-14 19:09:45 --> Router Class Initialized
INFO - 2021-12-14 19:09:45 --> Output Class Initialized
INFO - 2021-12-14 19:09:45 --> Security Class Initialized
DEBUG - 2021-12-14 19:09:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:09:45 --> Input Class Initialized
INFO - 2021-12-14 19:09:45 --> Language Class Initialized
INFO - 2021-12-14 19:09:45 --> Loader Class Initialized
INFO - 2021-12-14 19:09:45 --> Helper loaded: url_helper
INFO - 2021-12-14 19:09:45 --> Helper loaded: form_helper
INFO - 2021-12-14 19:09:45 --> Helper loaded: common_helper
INFO - 2021-12-14 19:09:45 --> Database Driver Class Initialized
DEBUG - 2021-12-14 19:09:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-14 19:09:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-14 19:09:45 --> Controller Class Initialized
INFO - 2021-12-14 19:09:45 --> Form Validation Class Initialized
DEBUG - 2021-12-14 19:09:45 --> Encrypt Class Initialized
DEBUG - 2021-12-14 19:09:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-14 19:09:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-14 19:09:45 --> Email Class Initialized
INFO - 2021-12-14 19:09:45 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-14 19:09:45 --> Calendar Class Initialized
INFO - 2021-12-14 19:09:45 --> Model "Login_model" initialized
INFO - 2021-12-14 19:09:45 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-14 19:09:45 --> Final output sent to browser
DEBUG - 2021-12-14 19:09:45 --> Total execution time: 0.0216
ERROR - 2021-12-14 19:09:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:09:45 --> Config Class Initialized
INFO - 2021-12-14 19:09:45 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:09:45 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:09:45 --> Utf8 Class Initialized
INFO - 2021-12-14 19:09:45 --> URI Class Initialized
INFO - 2021-12-14 19:09:45 --> Router Class Initialized
INFO - 2021-12-14 19:09:45 --> Output Class Initialized
INFO - 2021-12-14 19:09:45 --> Security Class Initialized
DEBUG - 2021-12-14 19:09:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:09:45 --> Input Class Initialized
INFO - 2021-12-14 19:09:45 --> Language Class Initialized
ERROR - 2021-12-14 19:09:45 --> 404 Page Not Found: Addons/theme
ERROR - 2021-12-14 19:09:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:09:45 --> Config Class Initialized
INFO - 2021-12-14 19:09:45 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:09:45 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:09:45 --> Utf8 Class Initialized
INFO - 2021-12-14 19:09:45 --> URI Class Initialized
INFO - 2021-12-14 19:09:45 --> Router Class Initialized
INFO - 2021-12-14 19:09:45 --> Output Class Initialized
INFO - 2021-12-14 19:09:45 --> Security Class Initialized
DEBUG - 2021-12-14 19:09:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:09:45 --> Input Class Initialized
INFO - 2021-12-14 19:09:45 --> Language Class Initialized
ERROR - 2021-12-14 19:09:45 --> 404 Page Not Found: Apps/admin
ERROR - 2021-12-14 19:09:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:09:46 --> Config Class Initialized
INFO - 2021-12-14 19:09:46 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:09:46 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:09:46 --> Utf8 Class Initialized
INFO - 2021-12-14 19:09:46 --> URI Class Initialized
INFO - 2021-12-14 19:09:46 --> Router Class Initialized
INFO - 2021-12-14 19:09:46 --> Output Class Initialized
INFO - 2021-12-14 19:09:46 --> Security Class Initialized
DEBUG - 2021-12-14 19:09:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:09:46 --> Input Class Initialized
INFO - 2021-12-14 19:09:46 --> Language Class Initialized
ERROR - 2021-12-14 19:09:46 --> 404 Page Not Found: Addons/theme
ERROR - 2021-12-14 19:09:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:09:46 --> Config Class Initialized
INFO - 2021-12-14 19:09:46 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:09:46 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:09:46 --> Utf8 Class Initialized
INFO - 2021-12-14 19:09:46 --> URI Class Initialized
INFO - 2021-12-14 19:09:46 --> Router Class Initialized
INFO - 2021-12-14 19:09:46 --> Output Class Initialized
INFO - 2021-12-14 19:09:46 --> Security Class Initialized
DEBUG - 2021-12-14 19:09:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:09:46 --> Input Class Initialized
INFO - 2021-12-14 19:09:46 --> Language Class Initialized
ERROR - 2021-12-14 19:09:46 --> 404 Page Not Found: Addons/theme
ERROR - 2021-12-14 19:09:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:09:47 --> Config Class Initialized
INFO - 2021-12-14 19:09:47 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:09:47 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:09:47 --> Utf8 Class Initialized
INFO - 2021-12-14 19:09:47 --> URI Class Initialized
INFO - 2021-12-14 19:09:47 --> Router Class Initialized
INFO - 2021-12-14 19:09:47 --> Output Class Initialized
INFO - 2021-12-14 19:09:47 --> Security Class Initialized
DEBUG - 2021-12-14 19:09:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:09:47 --> Input Class Initialized
INFO - 2021-12-14 19:09:47 --> Language Class Initialized
ERROR - 2021-12-14 19:09:47 --> 404 Page Not Found: App/login.jsp
ERROR - 2021-12-14 19:09:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:09:47 --> Config Class Initialized
INFO - 2021-12-14 19:09:47 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:09:47 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:09:47 --> Utf8 Class Initialized
INFO - 2021-12-14 19:09:47 --> URI Class Initialized
INFO - 2021-12-14 19:09:47 --> Router Class Initialized
INFO - 2021-12-14 19:09:47 --> Output Class Initialized
INFO - 2021-12-14 19:09:47 --> Security Class Initialized
DEBUG - 2021-12-14 19:09:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:09:47 --> Input Class Initialized
INFO - 2021-12-14 19:09:47 --> Language Class Initialized
ERROR - 2021-12-14 19:09:47 --> 404 Page Not Found: App/js
ERROR - 2021-12-14 19:09:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:09:47 --> Config Class Initialized
INFO - 2021-12-14 19:09:47 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:09:47 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:09:47 --> Utf8 Class Initialized
INFO - 2021-12-14 19:09:47 --> URI Class Initialized
INFO - 2021-12-14 19:09:47 --> Router Class Initialized
INFO - 2021-12-14 19:09:47 --> Output Class Initialized
INFO - 2021-12-14 19:09:47 --> Security Class Initialized
DEBUG - 2021-12-14 19:09:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:09:47 --> Input Class Initialized
INFO - 2021-12-14 19:09:47 --> Language Class Initialized
ERROR - 2021-12-14 19:09:47 --> 404 Page Not Found: Console/js
ERROR - 2021-12-14 19:09:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:09:48 --> Config Class Initialized
INFO - 2021-12-14 19:09:48 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:09:48 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:09:48 --> Utf8 Class Initialized
INFO - 2021-12-14 19:09:48 --> URI Class Initialized
INFO - 2021-12-14 19:09:48 --> Router Class Initialized
INFO - 2021-12-14 19:09:48 --> Output Class Initialized
INFO - 2021-12-14 19:09:48 --> Security Class Initialized
DEBUG - 2021-12-14 19:09:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:09:48 --> Input Class Initialized
INFO - 2021-12-14 19:09:48 --> Language Class Initialized
ERROR - 2021-12-14 19:09:48 --> 404 Page Not Found: Console/include
ERROR - 2021-12-14 19:09:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:09:48 --> Config Class Initialized
INFO - 2021-12-14 19:09:48 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:09:48 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:09:48 --> Utf8 Class Initialized
INFO - 2021-12-14 19:09:48 --> URI Class Initialized
INFO - 2021-12-14 19:09:48 --> Router Class Initialized
INFO - 2021-12-14 19:09:48 --> Output Class Initialized
INFO - 2021-12-14 19:09:48 --> Security Class Initialized
DEBUG - 2021-12-14 19:09:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:09:48 --> Input Class Initialized
INFO - 2021-12-14 19:09:48 --> Language Class Initialized
ERROR - 2021-12-14 19:09:48 --> 404 Page Not Found: Console/auth
ERROR - 2021-12-14 19:09:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:09:48 --> Config Class Initialized
INFO - 2021-12-14 19:09:48 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:09:48 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:09:48 --> Utf8 Class Initialized
INFO - 2021-12-14 19:09:48 --> URI Class Initialized
INFO - 2021-12-14 19:09:48 --> Router Class Initialized
INFO - 2021-12-14 19:09:48 --> Output Class Initialized
INFO - 2021-12-14 19:09:48 --> Security Class Initialized
DEBUG - 2021-12-14 19:09:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:09:48 --> Input Class Initialized
INFO - 2021-12-14 19:09:48 --> Language Class Initialized
ERROR - 2021-12-14 19:09:48 --> 404 Page Not Found: Console/js
ERROR - 2021-12-14 19:09:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:09:49 --> Config Class Initialized
INFO - 2021-12-14 19:09:49 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:09:49 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:09:49 --> Utf8 Class Initialized
INFO - 2021-12-14 19:09:49 --> URI Class Initialized
INFO - 2021-12-14 19:09:49 --> Router Class Initialized
INFO - 2021-12-14 19:09:49 --> Output Class Initialized
INFO - 2021-12-14 19:09:49 --> Security Class Initialized
DEBUG - 2021-12-14 19:09:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:09:49 --> Input Class Initialized
INFO - 2021-12-14 19:09:49 --> Language Class Initialized
ERROR - 2021-12-14 19:09:49 --> 404 Page Not Found: App/images
ERROR - 2021-12-14 19:09:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:09:49 --> Config Class Initialized
INFO - 2021-12-14 19:09:49 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:09:49 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:09:49 --> Utf8 Class Initialized
INFO - 2021-12-14 19:09:49 --> URI Class Initialized
INFO - 2021-12-14 19:09:49 --> Router Class Initialized
INFO - 2021-12-14 19:09:49 --> Output Class Initialized
INFO - 2021-12-14 19:09:49 --> Security Class Initialized
DEBUG - 2021-12-14 19:09:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:09:49 --> Input Class Initialized
INFO - 2021-12-14 19:09:49 --> Language Class Initialized
ERROR - 2021-12-14 19:09:49 --> 404 Page Not Found: App/images
ERROR - 2021-12-14 19:09:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:09:49 --> Config Class Initialized
INFO - 2021-12-14 19:09:49 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:09:49 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:09:49 --> Utf8 Class Initialized
INFO - 2021-12-14 19:09:49 --> URI Class Initialized
INFO - 2021-12-14 19:09:49 --> Router Class Initialized
INFO - 2021-12-14 19:09:49 --> Output Class Initialized
INFO - 2021-12-14 19:09:49 --> Security Class Initialized
DEBUG - 2021-12-14 19:09:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:09:49 --> Input Class Initialized
INFO - 2021-12-14 19:09:49 --> Language Class Initialized
ERROR - 2021-12-14 19:09:49 --> 404 Page Not Found: Admin/SouthidcEditor
ERROR - 2021-12-14 19:09:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:09:50 --> Config Class Initialized
INFO - 2021-12-14 19:09:50 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:09:50 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:09:50 --> Utf8 Class Initialized
INFO - 2021-12-14 19:09:50 --> URI Class Initialized
INFO - 2021-12-14 19:09:50 --> Router Class Initialized
INFO - 2021-12-14 19:09:50 --> Output Class Initialized
INFO - 2021-12-14 19:09:50 --> Security Class Initialized
DEBUG - 2021-12-14 19:09:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:09:50 --> Input Class Initialized
INFO - 2021-12-14 19:09:50 --> Language Class Initialized
ERROR - 2021-12-14 19:09:50 --> 404 Page Not Found: Admin/SouthidcEditor
ERROR - 2021-12-14 19:09:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:09:50 --> Config Class Initialized
INFO - 2021-12-14 19:09:50 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:09:50 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:09:50 --> Utf8 Class Initialized
INFO - 2021-12-14 19:09:50 --> URI Class Initialized
INFO - 2021-12-14 19:09:50 --> Router Class Initialized
INFO - 2021-12-14 19:09:50 --> Output Class Initialized
INFO - 2021-12-14 19:09:50 --> Security Class Initialized
DEBUG - 2021-12-14 19:09:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:09:50 --> Input Class Initialized
INFO - 2021-12-14 19:09:50 --> Language Class Initialized
ERROR - 2021-12-14 19:09:50 --> 404 Page Not Found: Admin/SouthidcEditor
ERROR - 2021-12-14 19:09:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:09:51 --> Config Class Initialized
INFO - 2021-12-14 19:09:51 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:09:51 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:09:51 --> Utf8 Class Initialized
INFO - 2021-12-14 19:09:51 --> URI Class Initialized
INFO - 2021-12-14 19:09:51 --> Router Class Initialized
INFO - 2021-12-14 19:09:51 --> Output Class Initialized
INFO - 2021-12-14 19:09:51 --> Security Class Initialized
DEBUG - 2021-12-14 19:09:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:09:51 --> Input Class Initialized
INFO - 2021-12-14 19:09:51 --> Language Class Initialized
ERROR - 2021-12-14 19:09:51 --> 404 Page Not Found: Default/css
ERROR - 2021-12-14 19:09:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:09:51 --> Config Class Initialized
INFO - 2021-12-14 19:09:51 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:09:51 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:09:51 --> Utf8 Class Initialized
INFO - 2021-12-14 19:09:51 --> URI Class Initialized
INFO - 2021-12-14 19:09:51 --> Router Class Initialized
INFO - 2021-12-14 19:09:51 --> Output Class Initialized
INFO - 2021-12-14 19:09:51 --> Security Class Initialized
DEBUG - 2021-12-14 19:09:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:09:51 --> Input Class Initialized
INFO - 2021-12-14 19:09:51 --> Language Class Initialized
ERROR - 2021-12-14 19:09:51 --> 404 Page Not Found: App/home
ERROR - 2021-12-14 19:09:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:09:51 --> Config Class Initialized
INFO - 2021-12-14 19:09:51 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:09:51 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:09:51 --> Utf8 Class Initialized
INFO - 2021-12-14 19:09:51 --> URI Class Initialized
INFO - 2021-12-14 19:09:51 --> Router Class Initialized
INFO - 2021-12-14 19:09:51 --> Output Class Initialized
INFO - 2021-12-14 19:09:51 --> Security Class Initialized
DEBUG - 2021-12-14 19:09:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:09:51 --> Input Class Initialized
INFO - 2021-12-14 19:09:51 --> Language Class Initialized
ERROR - 2021-12-14 19:09:51 --> 404 Page Not Found: Skin/frontend
ERROR - 2021-12-14 19:09:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:09:52 --> Config Class Initialized
INFO - 2021-12-14 19:09:52 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:09:52 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:09:52 --> Utf8 Class Initialized
INFO - 2021-12-14 19:09:52 --> URI Class Initialized
INFO - 2021-12-14 19:09:52 --> Router Class Initialized
INFO - 2021-12-14 19:09:52 --> Output Class Initialized
INFO - 2021-12-14 19:09:52 --> Security Class Initialized
DEBUG - 2021-12-14 19:09:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:09:52 --> Input Class Initialized
INFO - 2021-12-14 19:09:52 --> Language Class Initialized
ERROR - 2021-12-14 19:09:52 --> 404 Page Not Found: Helpnew/faq
ERROR - 2021-12-14 19:09:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:09:52 --> Config Class Initialized
INFO - 2021-12-14 19:09:52 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:09:52 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:09:52 --> Utf8 Class Initialized
INFO - 2021-12-14 19:09:52 --> URI Class Initialized
INFO - 2021-12-14 19:09:52 --> Router Class Initialized
INFO - 2021-12-14 19:09:52 --> Output Class Initialized
INFO - 2021-12-14 19:09:52 --> Security Class Initialized
DEBUG - 2021-12-14 19:09:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:09:52 --> Input Class Initialized
INFO - 2021-12-14 19:09:52 --> Language Class Initialized
ERROR - 2021-12-14 19:09:52 --> 404 Page Not Found: Ymail/images
ERROR - 2021-12-14 19:09:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:09:52 --> Config Class Initialized
INFO - 2021-12-14 19:09:52 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:09:52 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:09:52 --> Utf8 Class Initialized
INFO - 2021-12-14 19:09:52 --> URI Class Initialized
INFO - 2021-12-14 19:09:52 --> Router Class Initialized
INFO - 2021-12-14 19:09:52 --> Output Class Initialized
INFO - 2021-12-14 19:09:52 --> Security Class Initialized
DEBUG - 2021-12-14 19:09:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:09:52 --> Input Class Initialized
INFO - 2021-12-14 19:09:52 --> Language Class Initialized
ERROR - 2021-12-14 19:09:52 --> 404 Page Not Found: Advfile/ad12.js
ERROR - 2021-12-14 19:09:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:09:53 --> Config Class Initialized
INFO - 2021-12-14 19:09:53 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:09:53 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:09:53 --> Utf8 Class Initialized
INFO - 2021-12-14 19:09:53 --> URI Class Initialized
INFO - 2021-12-14 19:09:53 --> Router Class Initialized
INFO - 2021-12-14 19:09:53 --> Output Class Initialized
INFO - 2021-12-14 19:09:53 --> Security Class Initialized
DEBUG - 2021-12-14 19:09:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:09:53 --> Input Class Initialized
INFO - 2021-12-14 19:09:53 --> Language Class Initialized
ERROR - 2021-12-14 19:09:53 --> 404 Page Not Found: READMEtxt/index
ERROR - 2021-12-14 19:09:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:09:53 --> Config Class Initialized
INFO - 2021-12-14 19:09:53 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:09:53 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:09:53 --> Utf8 Class Initialized
INFO - 2021-12-14 19:09:53 --> URI Class Initialized
INFO - 2021-12-14 19:09:53 --> Router Class Initialized
INFO - 2021-12-14 19:09:53 --> Output Class Initialized
INFO - 2021-12-14 19:09:53 --> Security Class Initialized
DEBUG - 2021-12-14 19:09:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:09:53 --> Input Class Initialized
INFO - 2021-12-14 19:09:53 --> Language Class Initialized
ERROR - 2021-12-14 19:09:53 --> 404 Page Not Found: Pub/guiedit
ERROR - 2021-12-14 19:09:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:09:53 --> Config Class Initialized
INFO - 2021-12-14 19:09:53 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:09:53 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:09:53 --> Utf8 Class Initialized
INFO - 2021-12-14 19:09:53 --> URI Class Initialized
INFO - 2021-12-14 19:09:53 --> Router Class Initialized
INFO - 2021-12-14 19:09:53 --> Output Class Initialized
INFO - 2021-12-14 19:09:53 --> Security Class Initialized
DEBUG - 2021-12-14 19:09:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:09:53 --> Input Class Initialized
INFO - 2021-12-14 19:09:53 --> Language Class Initialized
ERROR - 2021-12-14 19:09:53 --> 404 Page Not Found: Pub/skins
ERROR - 2021-12-14 19:09:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:09:54 --> Config Class Initialized
INFO - 2021-12-14 19:09:54 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:09:54 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:09:54 --> Utf8 Class Initialized
INFO - 2021-12-14 19:09:54 --> URI Class Initialized
INFO - 2021-12-14 19:09:54 --> Router Class Initialized
INFO - 2021-12-14 19:09:54 --> Output Class Initialized
INFO - 2021-12-14 19:09:54 --> Security Class Initialized
DEBUG - 2021-12-14 19:09:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:09:54 --> Input Class Initialized
INFO - 2021-12-14 19:09:54 --> Language Class Initialized
ERROR - 2021-12-14 19:09:54 --> 404 Page Not Found: Docs/DOCUMENTATION.txt
ERROR - 2021-12-14 19:09:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:09:54 --> Config Class Initialized
INFO - 2021-12-14 19:09:54 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:09:54 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:09:54 --> Utf8 Class Initialized
INFO - 2021-12-14 19:09:54 --> URI Class Initialized
INFO - 2021-12-14 19:09:54 --> Router Class Initialized
INFO - 2021-12-14 19:09:54 --> Output Class Initialized
INFO - 2021-12-14 19:09:54 --> Security Class Initialized
DEBUG - 2021-12-14 19:09:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:09:54 --> Input Class Initialized
INFO - 2021-12-14 19:09:54 --> Language Class Initialized
ERROR - 2021-12-14 19:09:54 --> 404 Page Not Found: Install/index
ERROR - 2021-12-14 19:09:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:09:54 --> Config Class Initialized
INFO - 2021-12-14 19:09:54 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:09:54 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:09:54 --> Utf8 Class Initialized
INFO - 2021-12-14 19:09:54 --> URI Class Initialized
INFO - 2021-12-14 19:09:54 --> Router Class Initialized
INFO - 2021-12-14 19:09:54 --> Output Class Initialized
INFO - 2021-12-14 19:09:54 --> Security Class Initialized
DEBUG - 2021-12-14 19:09:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:09:54 --> Input Class Initialized
INFO - 2021-12-14 19:09:54 --> Language Class Initialized
ERROR - 2021-12-14 19:09:54 --> 404 Page Not Found: Template/1
ERROR - 2021-12-14 19:09:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:09:55 --> Config Class Initialized
INFO - 2021-12-14 19:09:55 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:09:55 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:09:55 --> Utf8 Class Initialized
INFO - 2021-12-14 19:09:55 --> URI Class Initialized
INFO - 2021-12-14 19:09:55 --> Router Class Initialized
INFO - 2021-12-14 19:09:55 --> Output Class Initialized
INFO - 2021-12-14 19:09:55 --> Security Class Initialized
DEBUG - 2021-12-14 19:09:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:09:55 --> Input Class Initialized
INFO - 2021-12-14 19:09:55 --> Language Class Initialized
ERROR - 2021-12-14 19:09:55 --> 404 Page Not Found: Back/scripts
ERROR - 2021-12-14 19:09:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:09:55 --> Config Class Initialized
INFO - 2021-12-14 19:09:55 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:09:55 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:09:55 --> Utf8 Class Initialized
INFO - 2021-12-14 19:09:55 --> URI Class Initialized
INFO - 2021-12-14 19:09:55 --> Router Class Initialized
INFO - 2021-12-14 19:09:55 --> Output Class Initialized
INFO - 2021-12-14 19:09:55 --> Security Class Initialized
DEBUG - 2021-12-14 19:09:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:09:55 --> Input Class Initialized
INFO - 2021-12-14 19:09:55 --> Language Class Initialized
ERROR - 2021-12-14 19:09:55 --> 404 Page Not Found: Inc/playerKinds.xml
ERROR - 2021-12-14 19:09:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:09:55 --> Config Class Initialized
INFO - 2021-12-14 19:09:56 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:09:56 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:09:56 --> Utf8 Class Initialized
INFO - 2021-12-14 19:09:56 --> URI Class Initialized
INFO - 2021-12-14 19:09:56 --> Router Class Initialized
INFO - 2021-12-14 19:09:56 --> Output Class Initialized
INFO - 2021-12-14 19:09:56 --> Security Class Initialized
DEBUG - 2021-12-14 19:09:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:09:56 --> Input Class Initialized
INFO - 2021-12-14 19:09:56 --> Language Class Initialized
ERROR - 2021-12-14 19:09:56 --> 404 Page Not Found: Wq_StranJFjs/index
ERROR - 2021-12-14 19:09:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:09:56 --> Config Class Initialized
INFO - 2021-12-14 19:09:56 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:09:56 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:09:56 --> Utf8 Class Initialized
INFO - 2021-12-14 19:09:56 --> URI Class Initialized
INFO - 2021-12-14 19:09:56 --> Router Class Initialized
INFO - 2021-12-14 19:09:56 --> Output Class Initialized
INFO - 2021-12-14 19:09:56 --> Security Class Initialized
DEBUG - 2021-12-14 19:09:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:09:56 --> Input Class Initialized
INFO - 2021-12-14 19:09:56 --> Language Class Initialized
ERROR - 2021-12-14 19:09:56 --> 404 Page Not Found: Admin/login.asp
ERROR - 2021-12-14 19:09:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:09:56 --> Config Class Initialized
INFO - 2021-12-14 19:09:56 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:09:56 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:09:56 --> Utf8 Class Initialized
INFO - 2021-12-14 19:09:56 --> URI Class Initialized
INFO - 2021-12-14 19:09:56 --> Router Class Initialized
INFO - 2021-12-14 19:09:56 --> Output Class Initialized
INFO - 2021-12-14 19:09:56 --> Security Class Initialized
DEBUG - 2021-12-14 19:09:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:09:56 --> Input Class Initialized
INFO - 2021-12-14 19:09:56 --> Language Class Initialized
ERROR - 2021-12-14 19:09:56 --> 404 Page Not Found: Pluginphp/index
ERROR - 2021-12-14 19:09:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:09:57 --> Config Class Initialized
INFO - 2021-12-14 19:09:57 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:09:57 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:09:57 --> Utf8 Class Initialized
INFO - 2021-12-14 19:09:57 --> URI Class Initialized
INFO - 2021-12-14 19:09:57 --> Router Class Initialized
INFO - 2021-12-14 19:09:57 --> Output Class Initialized
INFO - 2021-12-14 19:09:57 --> Security Class Initialized
DEBUG - 2021-12-14 19:09:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:09:57 --> Input Class Initialized
INFO - 2021-12-14 19:09:57 --> Language Class Initialized
ERROR - 2021-12-14 19:09:57 --> 404 Page Not Found: Admin/login.aspx
ERROR - 2021-12-14 19:09:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:09:57 --> Config Class Initialized
INFO - 2021-12-14 19:09:57 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:09:57 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:09:57 --> Utf8 Class Initialized
INFO - 2021-12-14 19:09:57 --> URI Class Initialized
INFO - 2021-12-14 19:09:57 --> Router Class Initialized
INFO - 2021-12-14 19:09:57 --> Output Class Initialized
INFO - 2021-12-14 19:09:57 --> Security Class Initialized
DEBUG - 2021-12-14 19:09:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:09:57 --> Input Class Initialized
INFO - 2021-12-14 19:09:57 --> Language Class Initialized
ERROR - 2021-12-14 19:09:57 --> 404 Page Not Found: Erroraspx/index
ERROR - 2021-12-14 19:09:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:09:57 --> Config Class Initialized
INFO - 2021-12-14 19:09:57 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:09:57 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:09:57 --> Utf8 Class Initialized
INFO - 2021-12-14 19:09:57 --> URI Class Initialized
INFO - 2021-12-14 19:09:57 --> Router Class Initialized
INFO - 2021-12-14 19:09:57 --> Output Class Initialized
INFO - 2021-12-14 19:09:57 --> Security Class Initialized
DEBUG - 2021-12-14 19:09:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:09:57 --> Input Class Initialized
INFO - 2021-12-14 19:09:57 --> Language Class Initialized
ERROR - 2021-12-14 19:09:57 --> 404 Page Not Found: Style/default
ERROR - 2021-12-14 19:09:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:09:58 --> Config Class Initialized
INFO - 2021-12-14 19:09:58 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:09:58 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:09:58 --> Utf8 Class Initialized
INFO - 2021-12-14 19:09:58 --> URI Class Initialized
INFO - 2021-12-14 19:09:58 --> Router Class Initialized
INFO - 2021-12-14 19:09:58 --> Output Class Initialized
INFO - 2021-12-14 19:09:58 --> Security Class Initialized
DEBUG - 2021-12-14 19:09:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:09:58 --> Input Class Initialized
INFO - 2021-12-14 19:09:58 --> Language Class Initialized
ERROR - 2021-12-14 19:09:58 --> 404 Page Not Found: Kindeditor-minjs/index
ERROR - 2021-12-14 19:09:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:09:58 --> Config Class Initialized
INFO - 2021-12-14 19:09:58 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:09:58 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:09:58 --> Utf8 Class Initialized
INFO - 2021-12-14 19:09:58 --> URI Class Initialized
INFO - 2021-12-14 19:09:58 --> Router Class Initialized
INFO - 2021-12-14 19:09:58 --> Output Class Initialized
INFO - 2021-12-14 19:09:58 --> Security Class Initialized
DEBUG - 2021-12-14 19:09:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:09:58 --> Input Class Initialized
INFO - 2021-12-14 19:09:58 --> Language Class Initialized
ERROR - 2021-12-14 19:09:58 --> 404 Page Not Found: Kindeditorjs/index
ERROR - 2021-12-14 19:09:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:09:59 --> Config Class Initialized
INFO - 2021-12-14 19:09:59 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:09:59 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:09:59 --> Utf8 Class Initialized
INFO - 2021-12-14 19:09:59 --> URI Class Initialized
INFO - 2021-12-14 19:09:59 --> Router Class Initialized
INFO - 2021-12-14 19:09:59 --> Output Class Initialized
INFO - 2021-12-14 19:09:59 --> Security Class Initialized
DEBUG - 2021-12-14 19:09:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:09:59 --> Input Class Initialized
INFO - 2021-12-14 19:09:59 --> Language Class Initialized
ERROR - 2021-12-14 19:09:59 --> 404 Page Not Found: Lang/en.js
ERROR - 2021-12-14 19:09:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:09:59 --> Config Class Initialized
INFO - 2021-12-14 19:09:59 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:09:59 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:09:59 --> Utf8 Class Initialized
INFO - 2021-12-14 19:09:59 --> URI Class Initialized
INFO - 2021-12-14 19:09:59 --> Router Class Initialized
INFO - 2021-12-14 19:09:59 --> Output Class Initialized
INFO - 2021-12-14 19:09:59 --> Security Class Initialized
DEBUG - 2021-12-14 19:09:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:09:59 --> Input Class Initialized
INFO - 2021-12-14 19:09:59 --> Language Class Initialized
ERROR - 2021-12-14 19:09:59 --> 404 Page Not Found: Themes/default
ERROR - 2021-12-14 19:09:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:09:59 --> Config Class Initialized
INFO - 2021-12-14 19:09:59 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:09:59 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:09:59 --> Utf8 Class Initialized
INFO - 2021-12-14 19:09:59 --> URI Class Initialized
INFO - 2021-12-14 19:09:59 --> Router Class Initialized
INFO - 2021-12-14 19:09:59 --> Output Class Initialized
INFO - 2021-12-14 19:09:59 --> Security Class Initialized
DEBUG - 2021-12-14 19:09:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:09:59 --> Input Class Initialized
INFO - 2021-12-14 19:09:59 --> Language Class Initialized
ERROR - 2021-12-14 19:09:59 --> 404 Page Not Found: Examples/index.html
ERROR - 2021-12-14 19:10:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:10:00 --> Config Class Initialized
INFO - 2021-12-14 19:10:00 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:10:00 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:10:00 --> Utf8 Class Initialized
INFO - 2021-12-14 19:10:00 --> URI Class Initialized
INFO - 2021-12-14 19:10:00 --> Router Class Initialized
INFO - 2021-12-14 19:10:00 --> Output Class Initialized
INFO - 2021-12-14 19:10:00 --> Security Class Initialized
DEBUG - 2021-12-14 19:10:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:10:00 --> Input Class Initialized
INFO - 2021-12-14 19:10:00 --> Language Class Initialized
ERROR - 2021-12-14 19:10:00 --> 404 Page Not Found: Examples/file-manager.html
ERROR - 2021-12-14 19:10:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:10:00 --> Config Class Initialized
INFO - 2021-12-14 19:10:00 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:10:00 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:10:00 --> Utf8 Class Initialized
INFO - 2021-12-14 19:10:00 --> URI Class Initialized
INFO - 2021-12-14 19:10:00 --> Router Class Initialized
INFO - 2021-12-14 19:10:00 --> Output Class Initialized
INFO - 2021-12-14 19:10:00 --> Security Class Initialized
DEBUG - 2021-12-14 19:10:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:10:00 --> Input Class Initialized
INFO - 2021-12-14 19:10:00 --> Language Class Initialized
ERROR - 2021-12-14 19:10:00 --> 404 Page Not Found: Plugins/filemanager
ERROR - 2021-12-14 19:10:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:10:00 --> Config Class Initialized
INFO - 2021-12-14 19:10:00 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:10:00 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:10:00 --> Utf8 Class Initialized
INFO - 2021-12-14 19:10:00 --> URI Class Initialized
INFO - 2021-12-14 19:10:00 --> Router Class Initialized
INFO - 2021-12-14 19:10:00 --> Output Class Initialized
INFO - 2021-12-14 19:10:00 --> Security Class Initialized
DEBUG - 2021-12-14 19:10:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:10:00 --> Input Class Initialized
INFO - 2021-12-14 19:10:00 --> Language Class Initialized
ERROR - 2021-12-14 19:10:00 --> 404 Page Not Found: Plugins/anchor
ERROR - 2021-12-14 19:10:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:10:01 --> Config Class Initialized
INFO - 2021-12-14 19:10:01 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:10:01 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:10:01 --> Utf8 Class Initialized
INFO - 2021-12-14 19:10:01 --> URI Class Initialized
INFO - 2021-12-14 19:10:01 --> Router Class Initialized
INFO - 2021-12-14 19:10:01 --> Output Class Initialized
INFO - 2021-12-14 19:10:01 --> Security Class Initialized
DEBUG - 2021-12-14 19:10:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:10:01 --> Input Class Initialized
INFO - 2021-12-14 19:10:01 --> Language Class Initialized
ERROR - 2021-12-14 19:10:01 --> 404 Page Not Found: Aspnet/README.txt
ERROR - 2021-12-14 19:10:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:10:01 --> Config Class Initialized
INFO - 2021-12-14 19:10:01 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:10:01 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:10:01 --> Utf8 Class Initialized
INFO - 2021-12-14 19:10:01 --> URI Class Initialized
INFO - 2021-12-14 19:10:01 --> Router Class Initialized
INFO - 2021-12-14 19:10:01 --> Output Class Initialized
INFO - 2021-12-14 19:10:01 --> Security Class Initialized
DEBUG - 2021-12-14 19:10:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:10:01 --> Input Class Initialized
INFO - 2021-12-14 19:10:01 --> Language Class Initialized
ERROR - 2021-12-14 19:10:01 --> 404 Page Not Found: Examples/readonly.html
ERROR - 2021-12-14 19:10:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:10:02 --> Config Class Initialized
INFO - 2021-12-14 19:10:02 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:10:02 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:10:02 --> Utf8 Class Initialized
INFO - 2021-12-14 19:10:02 --> URI Class Initialized
INFO - 2021-12-14 19:10:02 --> Router Class Initialized
INFO - 2021-12-14 19:10:02 --> Output Class Initialized
INFO - 2021-12-14 19:10:02 --> Security Class Initialized
DEBUG - 2021-12-14 19:10:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:10:02 --> Input Class Initialized
INFO - 2021-12-14 19:10:02 --> Language Class Initialized
ERROR - 2021-12-14 19:10:02 --> 404 Page Not Found: Dokuphp/index
ERROR - 2021-12-14 19:10:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:10:02 --> Config Class Initialized
INFO - 2021-12-14 19:10:02 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:10:02 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:10:02 --> Utf8 Class Initialized
INFO - 2021-12-14 19:10:02 --> URI Class Initialized
INFO - 2021-12-14 19:10:02 --> Router Class Initialized
INFO - 2021-12-14 19:10:02 --> Output Class Initialized
INFO - 2021-12-14 19:10:02 --> Security Class Initialized
DEBUG - 2021-12-14 19:10:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:10:02 --> Input Class Initialized
INFO - 2021-12-14 19:10:02 --> Language Class Initialized
ERROR - 2021-12-14 19:10:02 --> 404 Page Not Found: Help/user
ERROR - 2021-12-14 19:10:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:10:02 --> Config Class Initialized
INFO - 2021-12-14 19:10:02 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:10:02 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:10:02 --> Utf8 Class Initialized
INFO - 2021-12-14 19:10:02 --> URI Class Initialized
INFO - 2021-12-14 19:10:02 --> Router Class Initialized
INFO - 2021-12-14 19:10:02 --> Output Class Initialized
INFO - 2021-12-14 19:10:02 --> Security Class Initialized
DEBUG - 2021-12-14 19:10:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:10:02 --> Input Class Initialized
INFO - 2021-12-14 19:10:02 --> Language Class Initialized
ERROR - 2021-12-14 19:10:02 --> 404 Page Not Found: Media/com_hikashop
ERROR - 2021-12-14 19:10:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:10:03 --> Config Class Initialized
INFO - 2021-12-14 19:10:03 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:10:03 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:10:03 --> Utf8 Class Initialized
INFO - 2021-12-14 19:10:03 --> URI Class Initialized
INFO - 2021-12-14 19:10:03 --> Router Class Initialized
INFO - 2021-12-14 19:10:03 --> Output Class Initialized
INFO - 2021-12-14 19:10:03 --> Security Class Initialized
DEBUG - 2021-12-14 19:10:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:10:03 --> Input Class Initialized
INFO - 2021-12-14 19:10:03 --> Language Class Initialized
ERROR - 2021-12-14 19:10:03 --> 404 Page Not Found: Templates/jsn_glass_pro
ERROR - 2021-12-14 19:10:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:10:03 --> Config Class Initialized
INFO - 2021-12-14 19:10:03 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:10:03 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:10:03 --> Utf8 Class Initialized
INFO - 2021-12-14 19:10:03 --> URI Class Initialized
INFO - 2021-12-14 19:10:03 --> Router Class Initialized
INFO - 2021-12-14 19:10:03 --> Output Class Initialized
INFO - 2021-12-14 19:10:03 --> Security Class Initialized
DEBUG - 2021-12-14 19:10:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:10:03 --> Input Class Initialized
INFO - 2021-12-14 19:10:03 --> Language Class Initialized
ERROR - 2021-12-14 19:10:03 --> 404 Page Not Found: Whir_system/login.aspx
ERROR - 2021-12-14 19:10:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:10:03 --> Config Class Initialized
INFO - 2021-12-14 19:10:03 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:10:03 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:10:03 --> Utf8 Class Initialized
INFO - 2021-12-14 19:10:03 --> URI Class Initialized
INFO - 2021-12-14 19:10:03 --> Router Class Initialized
INFO - 2021-12-14 19:10:03 --> Output Class Initialized
INFO - 2021-12-14 19:10:03 --> Security Class Initialized
DEBUG - 2021-12-14 19:10:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:10:03 --> Input Class Initialized
INFO - 2021-12-14 19:10:03 --> Language Class Initialized
ERROR - 2021-12-14 19:10:03 --> 404 Page Not Found: Whir_system/module
ERROR - 2021-12-14 19:10:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:10:04 --> Config Class Initialized
INFO - 2021-12-14 19:10:04 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:10:04 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:10:04 --> Utf8 Class Initialized
INFO - 2021-12-14 19:10:04 --> URI Class Initialized
INFO - 2021-12-14 19:10:04 --> Router Class Initialized
INFO - 2021-12-14 19:10:04 --> Output Class Initialized
INFO - 2021-12-14 19:10:04 --> Security Class Initialized
DEBUG - 2021-12-14 19:10:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:10:04 --> Input Class Initialized
INFO - 2021-12-14 19:10:04 --> Language Class Initialized
ERROR - 2021-12-14 19:10:04 --> 404 Page Not Found: System/Login.aspx
ERROR - 2021-12-14 19:10:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:10:04 --> Config Class Initialized
INFO - 2021-12-14 19:10:04 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:10:04 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:10:04 --> Utf8 Class Initialized
INFO - 2021-12-14 19:10:04 --> URI Class Initialized
INFO - 2021-12-14 19:10:04 --> Router Class Initialized
INFO - 2021-12-14 19:10:04 --> Output Class Initialized
INFO - 2021-12-14 19:10:04 --> Security Class Initialized
DEBUG - 2021-12-14 19:10:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:10:04 --> Input Class Initialized
INFO - 2021-12-14 19:10:04 --> Language Class Initialized
ERROR - 2021-12-14 19:10:04 --> 404 Page Not Found: App/Tpl
ERROR - 2021-12-14 19:10:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:10:04 --> Config Class Initialized
INFO - 2021-12-14 19:10:04 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:10:04 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:10:04 --> Utf8 Class Initialized
INFO - 2021-12-14 19:10:04 --> URI Class Initialized
INFO - 2021-12-14 19:10:04 --> Router Class Initialized
INFO - 2021-12-14 19:10:04 --> Output Class Initialized
INFO - 2021-12-14 19:10:04 --> Security Class Initialized
DEBUG - 2021-12-14 19:10:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:10:04 --> Input Class Initialized
INFO - 2021-12-14 19:10:04 --> Language Class Initialized
ERROR - 2021-12-14 19:10:04 --> 404 Page Not Found: Public/js
ERROR - 2021-12-14 19:10:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:10:05 --> Config Class Initialized
INFO - 2021-12-14 19:10:05 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:10:05 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:10:05 --> Utf8 Class Initialized
INFO - 2021-12-14 19:10:05 --> URI Class Initialized
INFO - 2021-12-14 19:10:05 --> Router Class Initialized
INFO - 2021-12-14 19:10:05 --> Output Class Initialized
INFO - 2021-12-14 19:10:05 --> Security Class Initialized
DEBUG - 2021-12-14 19:10:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:10:05 --> Input Class Initialized
INFO - 2021-12-14 19:10:05 --> Language Class Initialized
ERROR - 2021-12-14 19:10:05 --> 404 Page Not Found: User/Login.aspx
ERROR - 2021-12-14 19:10:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:10:05 --> Config Class Initialized
INFO - 2021-12-14 19:10:05 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:10:05 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:10:05 --> Utf8 Class Initialized
INFO - 2021-12-14 19:10:05 --> URI Class Initialized
INFO - 2021-12-14 19:10:05 --> Router Class Initialized
INFO - 2021-12-14 19:10:05 --> Output Class Initialized
INFO - 2021-12-14 19:10:05 --> Security Class Initialized
DEBUG - 2021-12-14 19:10:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:10:05 --> Input Class Initialized
INFO - 2021-12-14 19:10:05 --> Language Class Initialized
ERROR - 2021-12-14 19:10:05 --> 404 Page Not Found: API/DW
ERROR - 2021-12-14 19:10:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:10:06 --> Config Class Initialized
INFO - 2021-12-14 19:10:06 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:10:06 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:10:06 --> Utf8 Class Initialized
INFO - 2021-12-14 19:10:06 --> URI Class Initialized
INFO - 2021-12-14 19:10:06 --> Router Class Initialized
INFO - 2021-12-14 19:10:06 --> Output Class Initialized
INFO - 2021-12-14 19:10:06 --> Security Class Initialized
DEBUG - 2021-12-14 19:10:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:10:06 --> Input Class Initialized
INFO - 2021-12-14 19:10:06 --> Language Class Initialized
ERROR - 2021-12-14 19:10:06 --> 404 Page Not Found: API/DW
ERROR - 2021-12-14 19:10:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:10:06 --> Config Class Initialized
INFO - 2021-12-14 19:10:06 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:10:06 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:10:06 --> Utf8 Class Initialized
INFO - 2021-12-14 19:10:06 --> URI Class Initialized
INFO - 2021-12-14 19:10:06 --> Router Class Initialized
INFO - 2021-12-14 19:10:06 --> Output Class Initialized
INFO - 2021-12-14 19:10:06 --> Security Class Initialized
DEBUG - 2021-12-14 19:10:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:10:06 --> Input Class Initialized
INFO - 2021-12-14 19:10:06 --> Language Class Initialized
ERROR - 2021-12-14 19:10:06 --> 404 Page Not Found: API/DW
ERROR - 2021-12-14 19:10:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:10:06 --> Config Class Initialized
INFO - 2021-12-14 19:10:06 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:10:06 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:10:06 --> Utf8 Class Initialized
INFO - 2021-12-14 19:10:06 --> URI Class Initialized
INFO - 2021-12-14 19:10:06 --> Router Class Initialized
INFO - 2021-12-14 19:10:06 --> Output Class Initialized
INFO - 2021-12-14 19:10:06 --> Security Class Initialized
DEBUG - 2021-12-14 19:10:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:10:06 --> Input Class Initialized
INFO - 2021-12-14 19:10:06 --> Language Class Initialized
ERROR - 2021-12-14 19:10:06 --> 404 Page Not Found: Admin/Common
ERROR - 2021-12-14 19:10:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:10:07 --> Config Class Initialized
INFO - 2021-12-14 19:10:07 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:10:07 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:10:07 --> Utf8 Class Initialized
INFO - 2021-12-14 19:10:07 --> URI Class Initialized
INFO - 2021-12-14 19:10:07 --> Router Class Initialized
INFO - 2021-12-14 19:10:07 --> Output Class Initialized
INFO - 2021-12-14 19:10:07 --> Security Class Initialized
DEBUG - 2021-12-14 19:10:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:10:07 --> Input Class Initialized
INFO - 2021-12-14 19:10:07 --> Language Class Initialized
ERROR - 2021-12-14 19:10:07 --> 404 Page Not Found: API/DW
ERROR - 2021-12-14 19:10:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:10:07 --> Config Class Initialized
INFO - 2021-12-14 19:10:07 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:10:07 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:10:07 --> Utf8 Class Initialized
INFO - 2021-12-14 19:10:07 --> URI Class Initialized
INFO - 2021-12-14 19:10:07 --> Router Class Initialized
INFO - 2021-12-14 19:10:07 --> Output Class Initialized
INFO - 2021-12-14 19:10:07 --> Security Class Initialized
DEBUG - 2021-12-14 19:10:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:10:07 --> Input Class Initialized
INFO - 2021-12-14 19:10:07 --> Language Class Initialized
ERROR - 2021-12-14 19:10:07 --> 404 Page Not Found: API/DW
ERROR - 2021-12-14 19:10:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:10:08 --> Config Class Initialized
INFO - 2021-12-14 19:10:08 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:10:08 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:10:08 --> Utf8 Class Initialized
INFO - 2021-12-14 19:10:08 --> URI Class Initialized
INFO - 2021-12-14 19:10:08 --> Router Class Initialized
INFO - 2021-12-14 19:10:08 --> Output Class Initialized
INFO - 2021-12-14 19:10:08 --> Security Class Initialized
DEBUG - 2021-12-14 19:10:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:10:08 --> Input Class Initialized
INFO - 2021-12-14 19:10:08 --> Language Class Initialized
ERROR - 2021-12-14 19:10:08 --> 404 Page Not Found: Admin/Login.aspx
ERROR - 2021-12-14 19:10:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:10:08 --> Config Class Initialized
INFO - 2021-12-14 19:10:08 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:10:08 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:10:08 --> Utf8 Class Initialized
INFO - 2021-12-14 19:10:08 --> URI Class Initialized
INFO - 2021-12-14 19:10:08 --> Router Class Initialized
INFO - 2021-12-14 19:10:08 --> Output Class Initialized
INFO - 2021-12-14 19:10:08 --> Security Class Initialized
DEBUG - 2021-12-14 19:10:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:10:08 --> Input Class Initialized
INFO - 2021-12-14 19:10:08 --> Language Class Initialized
ERROR - 2021-12-14 19:10:08 --> 404 Page Not Found: Admin/Images
ERROR - 2021-12-14 19:10:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:10:09 --> Config Class Initialized
INFO - 2021-12-14 19:10:09 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:10:09 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:10:09 --> Utf8 Class Initialized
INFO - 2021-12-14 19:10:09 --> URI Class Initialized
INFO - 2021-12-14 19:10:09 --> Router Class Initialized
INFO - 2021-12-14 19:10:09 --> Output Class Initialized
INFO - 2021-12-14 19:10:09 --> Security Class Initialized
DEBUG - 2021-12-14 19:10:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:10:09 --> Input Class Initialized
INFO - 2021-12-14 19:10:09 --> Language Class Initialized
ERROR - 2021-12-14 19:10:09 --> 404 Page Not Found: Template/Default
ERROR - 2021-12-14 19:10:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:10:09 --> Config Class Initialized
INFO - 2021-12-14 19:10:09 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:10:09 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:10:09 --> Utf8 Class Initialized
INFO - 2021-12-14 19:10:09 --> URI Class Initialized
INFO - 2021-12-14 19:10:09 --> Router Class Initialized
INFO - 2021-12-14 19:10:09 --> Output Class Initialized
INFO - 2021-12-14 19:10:09 --> Security Class Initialized
DEBUG - 2021-12-14 19:10:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:10:09 --> Input Class Initialized
INFO - 2021-12-14 19:10:09 --> Language Class Initialized
ERROR - 2021-12-14 19:10:09 --> 404 Page Not Found: Prompt/images
ERROR - 2021-12-14 19:10:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:10:09 --> Config Class Initialized
INFO - 2021-12-14 19:10:09 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:10:09 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:10:09 --> Utf8 Class Initialized
INFO - 2021-12-14 19:10:09 --> URI Class Initialized
INFO - 2021-12-14 19:10:09 --> Router Class Initialized
INFO - 2021-12-14 19:10:09 --> Output Class Initialized
INFO - 2021-12-14 19:10:09 --> Security Class Initialized
DEBUG - 2021-12-14 19:10:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:10:09 --> Input Class Initialized
INFO - 2021-12-14 19:10:09 --> Language Class Initialized
ERROR - 2021-12-14 19:10:09 --> 404 Page Not Found: Admin/Images
ERROR - 2021-12-14 19:10:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:10:10 --> Config Class Initialized
INFO - 2021-12-14 19:10:10 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:10:10 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:10:10 --> Utf8 Class Initialized
INFO - 2021-12-14 19:10:10 --> URI Class Initialized
INFO - 2021-12-14 19:10:10 --> Router Class Initialized
INFO - 2021-12-14 19:10:10 --> Output Class Initialized
INFO - 2021-12-14 19:10:10 --> Security Class Initialized
DEBUG - 2021-12-14 19:10:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:10:10 --> Input Class Initialized
INFO - 2021-12-14 19:10:10 --> Language Class Initialized
ERROR - 2021-12-14 19:10:10 --> 404 Page Not Found: Scripts/jquery
ERROR - 2021-12-14 19:10:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:10:10 --> Config Class Initialized
INFO - 2021-12-14 19:10:10 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:10:10 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:10:10 --> Utf8 Class Initialized
INFO - 2021-12-14 19:10:10 --> URI Class Initialized
INFO - 2021-12-14 19:10:10 --> Router Class Initialized
INFO - 2021-12-14 19:10:10 --> Output Class Initialized
INFO - 2021-12-14 19:10:10 --> Security Class Initialized
DEBUG - 2021-12-14 19:10:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:10:10 --> Input Class Initialized
INFO - 2021-12-14 19:10:10 --> Language Class Initialized
ERROR - 2021-12-14 19:10:10 --> 404 Page Not Found: DeptWebsiteActiondo/index
ERROR - 2021-12-14 19:10:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:10:11 --> Config Class Initialized
INFO - 2021-12-14 19:10:11 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:10:11 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:10:11 --> Utf8 Class Initialized
INFO - 2021-12-14 19:10:11 --> URI Class Initialized
INFO - 2021-12-14 19:10:11 --> Router Class Initialized
INFO - 2021-12-14 19:10:11 --> Output Class Initialized
INFO - 2021-12-14 19:10:11 --> Security Class Initialized
DEBUG - 2021-12-14 19:10:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:10:11 --> Input Class Initialized
INFO - 2021-12-14 19:10:11 --> Language Class Initialized
ERROR - 2021-12-14 19:10:11 --> 404 Page Not Found: Admin/start
ERROR - 2021-12-14 19:10:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:10:11 --> Config Class Initialized
INFO - 2021-12-14 19:10:11 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:10:11 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:10:11 --> Utf8 Class Initialized
INFO - 2021-12-14 19:10:11 --> URI Class Initialized
INFO - 2021-12-14 19:10:11 --> Router Class Initialized
INFO - 2021-12-14 19:10:11 --> Output Class Initialized
INFO - 2021-12-14 19:10:11 --> Security Class Initialized
DEBUG - 2021-12-14 19:10:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:10:11 --> Input Class Initialized
INFO - 2021-12-14 19:10:11 --> Language Class Initialized
ERROR - 2021-12-14 19:10:11 --> 404 Page Not Found: Themes/graphics
ERROR - 2021-12-14 19:10:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:10:12 --> Config Class Initialized
INFO - 2021-12-14 19:10:12 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:10:12 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:10:12 --> Utf8 Class Initialized
INFO - 2021-12-14 19:10:12 --> URI Class Initialized
INFO - 2021-12-14 19:10:12 --> Router Class Initialized
INFO - 2021-12-14 19:10:12 --> Output Class Initialized
INFO - 2021-12-14 19:10:12 --> Security Class Initialized
DEBUG - 2021-12-14 19:10:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:10:12 --> Input Class Initialized
INFO - 2021-12-14 19:10:12 --> Language Class Initialized
ERROR - 2021-12-14 19:10:12 --> 404 Page Not Found: Themes/default
ERROR - 2021-12-14 19:10:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:10:12 --> Config Class Initialized
INFO - 2021-12-14 19:10:12 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:10:12 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:10:12 --> Utf8 Class Initialized
INFO - 2021-12-14 19:10:12 --> URI Class Initialized
INFO - 2021-12-14 19:10:12 --> Router Class Initialized
INFO - 2021-12-14 19:10:12 --> Output Class Initialized
INFO - 2021-12-14 19:10:12 --> Security Class Initialized
DEBUG - 2021-12-14 19:10:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:10:12 --> Input Class Initialized
INFO - 2021-12-14 19:10:12 --> Language Class Initialized
ERROR - 2021-12-14 19:10:12 --> 404 Page Not Found: Themes/default
ERROR - 2021-12-14 19:10:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:10:12 --> Config Class Initialized
INFO - 2021-12-14 19:10:12 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:10:12 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:10:12 --> Utf8 Class Initialized
INFO - 2021-12-14 19:10:12 --> URI Class Initialized
INFO - 2021-12-14 19:10:12 --> Router Class Initialized
INFO - 2021-12-14 19:10:12 --> Output Class Initialized
INFO - 2021-12-14 19:10:12 --> Security Class Initialized
DEBUG - 2021-12-14 19:10:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:10:12 --> Input Class Initialized
INFO - 2021-12-14 19:10:12 --> Language Class Initialized
ERROR - 2021-12-14 19:10:12 --> 404 Page Not Found: Forums/list.page
ERROR - 2021-12-14 19:10:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:10:13 --> Config Class Initialized
INFO - 2021-12-14 19:10:13 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:10:13 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:10:13 --> Utf8 Class Initialized
INFO - 2021-12-14 19:10:13 --> URI Class Initialized
INFO - 2021-12-14 19:10:13 --> Router Class Initialized
INFO - 2021-12-14 19:10:13 --> Output Class Initialized
INFO - 2021-12-14 19:10:13 --> Security Class Initialized
DEBUG - 2021-12-14 19:10:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:10:13 --> Input Class Initialized
INFO - 2021-12-14 19:10:13 --> Language Class Initialized
ERROR - 2021-12-14 19:10:13 --> 404 Page Not Found: Script/valid_formdata.js
ERROR - 2021-12-14 19:10:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:10:13 --> Config Class Initialized
INFO - 2021-12-14 19:10:13 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:10:13 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:10:13 --> Utf8 Class Initialized
INFO - 2021-12-14 19:10:13 --> URI Class Initialized
INFO - 2021-12-14 19:10:13 --> Router Class Initialized
INFO - 2021-12-14 19:10:13 --> Output Class Initialized
INFO - 2021-12-14 19:10:13 --> Security Class Initialized
DEBUG - 2021-12-14 19:10:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:10:13 --> Input Class Initialized
INFO - 2021-12-14 19:10:13 --> Language Class Initialized
ERROR - 2021-12-14 19:10:13 --> 404 Page Not Found: Stylesheetcss/index
ERROR - 2021-12-14 19:10:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:10:13 --> Config Class Initialized
INFO - 2021-12-14 19:10:13 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:10:13 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:10:13 --> Utf8 Class Initialized
INFO - 2021-12-14 19:10:13 --> URI Class Initialized
INFO - 2021-12-14 19:10:13 --> Router Class Initialized
INFO - 2021-12-14 19:10:13 --> Output Class Initialized
INFO - 2021-12-14 19:10:13 --> Security Class Initialized
DEBUG - 2021-12-14 19:10:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:10:13 --> Input Class Initialized
INFO - 2021-12-14 19:10:13 --> Language Class Initialized
ERROR - 2021-12-14 19:10:13 --> 404 Page Not Found: Includes/general.js
ERROR - 2021-12-14 19:10:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:10:14 --> Config Class Initialized
INFO - 2021-12-14 19:10:14 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:10:14 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:10:14 --> Utf8 Class Initialized
INFO - 2021-12-14 19:10:14 --> URI Class Initialized
INFO - 2021-12-14 19:10:14 --> Router Class Initialized
INFO - 2021-12-14 19:10:14 --> Output Class Initialized
INFO - 2021-12-14 19:10:14 --> Security Class Initialized
DEBUG - 2021-12-14 19:10:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:10:14 --> Input Class Initialized
INFO - 2021-12-14 19:10:14 --> Language Class Initialized
ERROR - 2021-12-14 19:10:14 --> 404 Page Not Found: Inc/rsd.php
ERROR - 2021-12-14 19:10:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:10:14 --> Config Class Initialized
INFO - 2021-12-14 19:10:14 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:10:14 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:10:14 --> Utf8 Class Initialized
INFO - 2021-12-14 19:10:14 --> URI Class Initialized
INFO - 2021-12-14 19:10:14 --> Router Class Initialized
INFO - 2021-12-14 19:10:14 --> Output Class Initialized
INFO - 2021-12-14 19:10:14 --> Security Class Initialized
DEBUG - 2021-12-14 19:10:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:10:14 --> Input Class Initialized
INFO - 2021-12-14 19:10:14 --> Language Class Initialized
ERROR - 2021-12-14 19:10:14 --> 404 Page Not Found: Archiver/index
ERROR - 2021-12-14 19:10:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:10:14 --> Config Class Initialized
INFO - 2021-12-14 19:10:14 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:10:14 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:10:14 --> Utf8 Class Initialized
INFO - 2021-12-14 19:10:14 --> URI Class Initialized
INFO - 2021-12-14 19:10:14 --> Router Class Initialized
INFO - 2021-12-14 19:10:14 --> Output Class Initialized
INFO - 2021-12-14 19:10:14 --> Security Class Initialized
DEBUG - 2021-12-14 19:10:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:10:14 --> Input Class Initialized
INFO - 2021-12-14 19:10:14 --> Language Class Initialized
ERROR - 2021-12-14 19:10:14 --> 404 Page Not Found: Tools/rss.aspx
ERROR - 2021-12-14 19:10:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:10:15 --> Config Class Initialized
INFO - 2021-12-14 19:10:15 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:10:15 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:10:15 --> Utf8 Class Initialized
INFO - 2021-12-14 19:10:15 --> URI Class Initialized
INFO - 2021-12-14 19:10:15 --> Router Class Initialized
INFO - 2021-12-14 19:10:15 --> Output Class Initialized
INFO - 2021-12-14 19:10:15 --> Security Class Initialized
DEBUG - 2021-12-14 19:10:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:10:15 --> Input Class Initialized
INFO - 2021-12-14 19:10:15 --> Language Class Initialized
ERROR - 2021-12-14 19:10:15 --> 404 Page Not Found: Rssphp/index
ERROR - 2021-12-14 19:10:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:10:15 --> Config Class Initialized
INFO - 2021-12-14 19:10:15 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:10:15 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:10:15 --> Utf8 Class Initialized
INFO - 2021-12-14 19:10:15 --> URI Class Initialized
INFO - 2021-12-14 19:10:15 --> Router Class Initialized
INFO - 2021-12-14 19:10:15 --> Output Class Initialized
INFO - 2021-12-14 19:10:15 --> Security Class Initialized
DEBUG - 2021-12-14 19:10:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:10:15 --> Input Class Initialized
INFO - 2021-12-14 19:10:15 --> Language Class Initialized
ERROR - 2021-12-14 19:10:15 --> 404 Page Not Found: Adminsoft/templates
ERROR - 2021-12-14 19:10:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:10:16 --> Config Class Initialized
INFO - 2021-12-14 19:10:16 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:10:16 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:10:16 --> Utf8 Class Initialized
INFO - 2021-12-14 19:10:16 --> URI Class Initialized
INFO - 2021-12-14 19:10:16 --> Router Class Initialized
INFO - 2021-12-14 19:10:16 --> Output Class Initialized
INFO - 2021-12-14 19:10:16 --> Security Class Initialized
DEBUG - 2021-12-14 19:10:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:10:16 --> Input Class Initialized
INFO - 2021-12-14 19:10:16 --> Language Class Initialized
ERROR - 2021-12-14 19:10:16 --> 404 Page Not Found: Archive/archive.css
ERROR - 2021-12-14 19:10:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:10:16 --> Config Class Initialized
INFO - 2021-12-14 19:10:16 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:10:16 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:10:16 --> Utf8 Class Initialized
INFO - 2021-12-14 19:10:16 --> URI Class Initialized
INFO - 2021-12-14 19:10:16 --> Router Class Initialized
INFO - 2021-12-14 19:10:16 --> Output Class Initialized
INFO - 2021-12-14 19:10:16 --> Security Class Initialized
DEBUG - 2021-12-14 19:10:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:10:16 --> Input Class Initialized
INFO - 2021-12-14 19:10:16 --> Language Class Initialized
ERROR - 2021-12-14 19:10:16 --> 404 Page Not Found: Clientscript/vbulletin_ajax_htmlloader.js
ERROR - 2021-12-14 19:10:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:10:16 --> Config Class Initialized
INFO - 2021-12-14 19:10:16 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:10:16 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:10:16 --> Utf8 Class Initialized
INFO - 2021-12-14 19:10:16 --> URI Class Initialized
INFO - 2021-12-14 19:10:16 --> Router Class Initialized
INFO - 2021-12-14 19:10:16 --> Output Class Initialized
INFO - 2021-12-14 19:10:16 --> Security Class Initialized
DEBUG - 2021-12-14 19:10:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:10:16 --> Input Class Initialized
INFO - 2021-12-14 19:10:16 --> Language Class Initialized
ERROR - 2021-12-14 19:10:16 --> 404 Page Not Found: Feedasp/index
ERROR - 2021-12-14 19:10:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:10:17 --> Config Class Initialized
INFO - 2021-12-14 19:10:17 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:10:17 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:10:17 --> Utf8 Class Initialized
INFO - 2021-12-14 19:10:17 --> URI Class Initialized
INFO - 2021-12-14 19:10:17 --> Router Class Initialized
INFO - 2021-12-14 19:10:17 --> Output Class Initialized
INFO - 2021-12-14 19:10:17 --> Security Class Initialized
DEBUG - 2021-12-14 19:10:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:10:17 --> Input Class Initialized
INFO - 2021-12-14 19:10:17 --> Language Class Initialized
ERROR - 2021-12-14 19:10:17 --> 404 Page Not Found: Ntalker/lawfirm.aspx
ERROR - 2021-12-14 19:10:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:10:17 --> Config Class Initialized
INFO - 2021-12-14 19:10:17 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:10:17 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:10:17 --> Utf8 Class Initialized
INFO - 2021-12-14 19:10:17 --> URI Class Initialized
INFO - 2021-12-14 19:10:17 --> Router Class Initialized
INFO - 2021-12-14 19:10:17 --> Output Class Initialized
INFO - 2021-12-14 19:10:17 --> Security Class Initialized
DEBUG - 2021-12-14 19:10:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:10:17 --> Input Class Initialized
INFO - 2021-12-14 19:10:17 --> Language Class Initialized
ERROR - 2021-12-14 19:10:17 --> 404 Page Not Found: Searchhtml/index
ERROR - 2021-12-14 19:10:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:10:18 --> Config Class Initialized
INFO - 2021-12-14 19:10:18 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:10:18 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:10:18 --> Utf8 Class Initialized
INFO - 2021-12-14 19:10:18 --> URI Class Initialized
INFO - 2021-12-14 19:10:18 --> Router Class Initialized
INFO - 2021-12-14 19:10:18 --> Output Class Initialized
INFO - 2021-12-14 19:10:18 --> Security Class Initialized
DEBUG - 2021-12-14 19:10:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:10:18 --> Input Class Initialized
INFO - 2021-12-14 19:10:18 --> Language Class Initialized
ERROR - 2021-12-14 19:10:18 --> 404 Page Not Found: Externphp/index
ERROR - 2021-12-14 19:10:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:10:18 --> Config Class Initialized
INFO - 2021-12-14 19:10:18 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:10:18 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:10:18 --> Utf8 Class Initialized
INFO - 2021-12-14 19:10:18 --> URI Class Initialized
INFO - 2021-12-14 19:10:18 --> Router Class Initialized
INFO - 2021-12-14 19:10:18 --> Output Class Initialized
INFO - 2021-12-14 19:10:18 --> Security Class Initialized
DEBUG - 2021-12-14 19:10:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:10:18 --> Input Class Initialized
INFO - 2021-12-14 19:10:18 --> Language Class Initialized
ERROR - 2021-12-14 19:10:18 --> 404 Page Not Found: 404jpg/index
ERROR - 2021-12-14 19:10:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:10:18 --> Config Class Initialized
INFO - 2021-12-14 19:10:18 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:10:18 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:10:18 --> Utf8 Class Initialized
INFO - 2021-12-14 19:10:18 --> URI Class Initialized
INFO - 2021-12-14 19:10:18 --> Router Class Initialized
INFO - 2021-12-14 19:10:18 --> Output Class Initialized
INFO - 2021-12-14 19:10:18 --> Security Class Initialized
DEBUG - 2021-12-14 19:10:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:10:18 --> Input Class Initialized
INFO - 2021-12-14 19:10:18 --> Language Class Initialized
ERROR - 2021-12-14 19:10:18 --> 404 Page Not Found: Jcms/index.jsp
ERROR - 2021-12-14 19:10:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:10:19 --> Config Class Initialized
INFO - 2021-12-14 19:10:19 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:10:19 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:10:19 --> Utf8 Class Initialized
INFO - 2021-12-14 19:10:19 --> URI Class Initialized
INFO - 2021-12-14 19:10:19 --> Router Class Initialized
INFO - 2021-12-14 19:10:19 --> Output Class Initialized
INFO - 2021-12-14 19:10:19 --> Security Class Initialized
DEBUG - 2021-12-14 19:10:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:10:19 --> Input Class Initialized
INFO - 2021-12-14 19:10:19 --> Language Class Initialized
ERROR - 2021-12-14 19:10:19 --> 404 Page Not Found: Jcms/index_jcms.jsp
ERROR - 2021-12-14 19:10:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:10:19 --> Config Class Initialized
INFO - 2021-12-14 19:10:19 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:10:19 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:10:19 --> Utf8 Class Initialized
INFO - 2021-12-14 19:10:19 --> URI Class Initialized
INFO - 2021-12-14 19:10:19 --> Router Class Initialized
INFO - 2021-12-14 19:10:19 --> Output Class Initialized
INFO - 2021-12-14 19:10:19 --> Security Class Initialized
DEBUG - 2021-12-14 19:10:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:10:19 --> Input Class Initialized
INFO - 2021-12-14 19:10:19 --> Language Class Initialized
ERROR - 2021-12-14 19:10:19 --> 404 Page Not Found: Historytxt/index
ERROR - 2021-12-14 19:10:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:10:20 --> Config Class Initialized
INFO - 2021-12-14 19:10:20 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:10:20 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:10:20 --> Utf8 Class Initialized
INFO - 2021-12-14 19:10:20 --> URI Class Initialized
INFO - 2021-12-14 19:10:20 --> Router Class Initialized
INFO - 2021-12-14 19:10:20 --> Output Class Initialized
INFO - 2021-12-14 19:10:20 --> Security Class Initialized
DEBUG - 2021-12-14 19:10:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:10:20 --> Input Class Initialized
INFO - 2021-12-14 19:10:20 --> Language Class Initialized
ERROR - 2021-12-14 19:10:20 --> 404 Page Not Found: Common/common.js
ERROR - 2021-12-14 19:10:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:10:20 --> Config Class Initialized
INFO - 2021-12-14 19:10:20 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:10:20 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:10:20 --> Utf8 Class Initialized
INFO - 2021-12-14 19:10:20 --> URI Class Initialized
INFO - 2021-12-14 19:10:20 --> Router Class Initialized
INFO - 2021-12-14 19:10:20 --> Output Class Initialized
INFO - 2021-12-14 19:10:20 --> Security Class Initialized
DEBUG - 2021-12-14 19:10:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:10:20 --> Input Class Initialized
INFO - 2021-12-14 19:10:20 --> Language Class Initialized
ERROR - 2021-12-14 19:10:20 --> 404 Page Not Found: Inc/Templates
ERROR - 2021-12-14 19:10:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:10:20 --> Config Class Initialized
INFO - 2021-12-14 19:10:20 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:10:20 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:10:20 --> Utf8 Class Initialized
INFO - 2021-12-14 19:10:20 --> URI Class Initialized
INFO - 2021-12-14 19:10:20 --> Router Class Initialized
INFO - 2021-12-14 19:10:20 --> Output Class Initialized
INFO - 2021-12-14 19:10:20 --> Security Class Initialized
DEBUG - 2021-12-14 19:10:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:10:20 --> Input Class Initialized
INFO - 2021-12-14 19:10:20 --> Language Class Initialized
ERROR - 2021-12-14 19:10:20 --> 404 Page Not Found: Ks_inc/ajax.js
ERROR - 2021-12-14 19:10:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:10:21 --> Config Class Initialized
INFO - 2021-12-14 19:10:21 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:10:21 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:10:21 --> Utf8 Class Initialized
INFO - 2021-12-14 19:10:21 --> URI Class Initialized
INFO - 2021-12-14 19:10:21 --> Router Class Initialized
INFO - 2021-12-14 19:10:21 --> Output Class Initialized
INFO - 2021-12-14 19:10:21 --> Security Class Initialized
DEBUG - 2021-12-14 19:10:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:10:21 --> Input Class Initialized
INFO - 2021-12-14 19:10:21 --> Language Class Initialized
ERROR - 2021-12-14 19:10:21 --> 404 Page Not Found: Api/api_user.xml
ERROR - 2021-12-14 19:10:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:10:21 --> Config Class Initialized
INFO - 2021-12-14 19:10:21 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:10:21 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:10:21 --> Utf8 Class Initialized
INFO - 2021-12-14 19:10:21 --> URI Class Initialized
INFO - 2021-12-14 19:10:21 --> Router Class Initialized
INFO - 2021-12-14 19:10:21 --> Output Class Initialized
INFO - 2021-12-14 19:10:21 --> Security Class Initialized
DEBUG - 2021-12-14 19:10:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:10:21 --> Input Class Initialized
INFO - 2021-12-14 19:10:21 --> Language Class Initialized
ERROR - 2021-12-14 19:10:21 --> 404 Page Not Found: Base/login
ERROR - 2021-12-14 19:10:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:10:22 --> Config Class Initialized
INFO - 2021-12-14 19:10:22 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:10:22 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:10:22 --> Utf8 Class Initialized
INFO - 2021-12-14 19:10:22 --> URI Class Initialized
INFO - 2021-12-14 19:10:22 --> Router Class Initialized
INFO - 2021-12-14 19:10:22 --> Output Class Initialized
INFO - 2021-12-14 19:10:22 --> Security Class Initialized
DEBUG - 2021-12-14 19:10:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:10:22 --> Input Class Initialized
INFO - 2021-12-14 19:10:22 --> Language Class Initialized
ERROR - 2021-12-14 19:10:22 --> 404 Page Not Found: Template/home.htm
ERROR - 2021-12-14 19:10:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:10:22 --> Config Class Initialized
INFO - 2021-12-14 19:10:22 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:10:22 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:10:22 --> Utf8 Class Initialized
INFO - 2021-12-14 19:10:22 --> URI Class Initialized
INFO - 2021-12-14 19:10:22 --> Router Class Initialized
INFO - 2021-12-14 19:10:22 --> Output Class Initialized
INFO - 2021-12-14 19:10:22 --> Security Class Initialized
DEBUG - 2021-12-14 19:10:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:10:22 --> Input Class Initialized
INFO - 2021-12-14 19:10:22 --> Language Class Initialized
ERROR - 2021-12-14 19:10:22 --> 404 Page Not Found: System/skins
ERROR - 2021-12-14 19:10:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:10:22 --> Config Class Initialized
INFO - 2021-12-14 19:10:22 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:10:22 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:10:22 --> Utf8 Class Initialized
INFO - 2021-12-14 19:10:22 --> URI Class Initialized
INFO - 2021-12-14 19:10:22 --> Router Class Initialized
INFO - 2021-12-14 19:10:22 --> Output Class Initialized
INFO - 2021-12-14 19:10:22 --> Security Class Initialized
DEBUG - 2021-12-14 19:10:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:10:22 --> Input Class Initialized
INFO - 2021-12-14 19:10:22 --> Language Class Initialized
ERROR - 2021-12-14 19:10:22 --> 404 Page Not Found: System/language
ERROR - 2021-12-14 19:10:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:10:23 --> Config Class Initialized
INFO - 2021-12-14 19:10:23 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:10:23 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:10:23 --> Utf8 Class Initialized
INFO - 2021-12-14 19:10:23 --> URI Class Initialized
INFO - 2021-12-14 19:10:23 --> Router Class Initialized
INFO - 2021-12-14 19:10:23 --> Output Class Initialized
INFO - 2021-12-14 19:10:23 --> Security Class Initialized
DEBUG - 2021-12-14 19:10:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:10:23 --> Input Class Initialized
INFO - 2021-12-14 19:10:23 --> Language Class Initialized
ERROR - 2021-12-14 19:10:23 --> 404 Page Not Found: Static/hgicon.png
ERROR - 2021-12-14 19:10:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:10:23 --> Config Class Initialized
INFO - 2021-12-14 19:10:23 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:10:23 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:10:23 --> Utf8 Class Initialized
INFO - 2021-12-14 19:10:23 --> URI Class Initialized
INFO - 2021-12-14 19:10:23 --> Router Class Initialized
INFO - 2021-12-14 19:10:23 --> Output Class Initialized
INFO - 2021-12-14 19:10:23 --> Security Class Initialized
DEBUG - 2021-12-14 19:10:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:10:23 --> Input Class Initialized
INFO - 2021-12-14 19:10:23 --> Language Class Initialized
ERROR - 2021-12-14 19:10:23 --> 404 Page Not Found: Licencetxt/index
ERROR - 2021-12-14 19:10:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:10:24 --> Config Class Initialized
INFO - 2021-12-14 19:10:24 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:10:24 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:10:24 --> Utf8 Class Initialized
INFO - 2021-12-14 19:10:24 --> URI Class Initialized
INFO - 2021-12-14 19:10:24 --> Router Class Initialized
INFO - 2021-12-14 19:10:24 --> Output Class Initialized
INFO - 2021-12-14 19:10:24 --> Security Class Initialized
DEBUG - 2021-12-14 19:10:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:10:24 --> Input Class Initialized
INFO - 2021-12-14 19:10:24 --> Language Class Initialized
ERROR - 2021-12-14 19:10:24 --> 404 Page Not Found: Rssaspx/index
ERROR - 2021-12-14 19:10:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:10:24 --> Config Class Initialized
INFO - 2021-12-14 19:10:24 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:10:24 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:10:24 --> Utf8 Class Initialized
INFO - 2021-12-14 19:10:24 --> URI Class Initialized
INFO - 2021-12-14 19:10:24 --> Router Class Initialized
INFO - 2021-12-14 19:10:24 --> Output Class Initialized
INFO - 2021-12-14 19:10:24 --> Security Class Initialized
DEBUG - 2021-12-14 19:10:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:10:24 --> Input Class Initialized
INFO - 2021-12-14 19:10:24 --> Language Class Initialized
ERROR - 2021-12-14 19:10:24 --> 404 Page Not Found: Max-templates/classic
ERROR - 2021-12-14 19:10:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:10:25 --> Config Class Initialized
INFO - 2021-12-14 19:10:25 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:10:25 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:10:25 --> Utf8 Class Initialized
INFO - 2021-12-14 19:10:25 --> URI Class Initialized
INFO - 2021-12-14 19:10:25 --> Router Class Initialized
INFO - 2021-12-14 19:10:25 --> Output Class Initialized
INFO - 2021-12-14 19:10:25 --> Security Class Initialized
DEBUG - 2021-12-14 19:10:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:10:25 --> Input Class Initialized
INFO - 2021-12-14 19:10:25 --> Language Class Initialized
ERROR - 2021-12-14 19:10:25 --> 404 Page Not Found: Adminphp/index
ERROR - 2021-12-14 19:10:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:10:25 --> Config Class Initialized
INFO - 2021-12-14 19:10:25 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:10:25 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:10:25 --> Utf8 Class Initialized
INFO - 2021-12-14 19:10:25 --> URI Class Initialized
DEBUG - 2021-12-14 19:10:25 --> No URI present. Default controller set.
INFO - 2021-12-14 19:10:25 --> Router Class Initialized
INFO - 2021-12-14 19:10:25 --> Output Class Initialized
INFO - 2021-12-14 19:10:25 --> Security Class Initialized
DEBUG - 2021-12-14 19:10:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:10:25 --> Input Class Initialized
INFO - 2021-12-14 19:10:25 --> Language Class Initialized
INFO - 2021-12-14 19:10:25 --> Loader Class Initialized
INFO - 2021-12-14 19:10:25 --> Helper loaded: url_helper
INFO - 2021-12-14 19:10:25 --> Helper loaded: form_helper
INFO - 2021-12-14 19:10:25 --> Helper loaded: common_helper
INFO - 2021-12-14 19:10:25 --> Database Driver Class Initialized
DEBUG - 2021-12-14 19:10:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-14 19:10:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-14 19:10:25 --> Controller Class Initialized
INFO - 2021-12-14 19:10:25 --> Form Validation Class Initialized
DEBUG - 2021-12-14 19:10:25 --> Encrypt Class Initialized
DEBUG - 2021-12-14 19:10:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-14 19:10:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-14 19:10:25 --> Email Class Initialized
INFO - 2021-12-14 19:10:25 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-14 19:10:25 --> Calendar Class Initialized
INFO - 2021-12-14 19:10:25 --> Model "Login_model" initialized
INFO - 2021-12-14 19:10:25 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-14 19:10:25 --> Final output sent to browser
DEBUG - 2021-12-14 19:10:25 --> Total execution time: 0.0293
ERROR - 2021-12-14 19:10:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:10:26 --> Config Class Initialized
INFO - 2021-12-14 19:10:26 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:10:26 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:10:26 --> Utf8 Class Initialized
INFO - 2021-12-14 19:10:26 --> URI Class Initialized
INFO - 2021-12-14 19:10:26 --> Router Class Initialized
INFO - 2021-12-14 19:10:26 --> Output Class Initialized
INFO - 2021-12-14 19:10:26 --> Security Class Initialized
DEBUG - 2021-12-14 19:10:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:10:26 --> Input Class Initialized
INFO - 2021-12-14 19:10:26 --> Language Class Initialized
ERROR - 2021-12-14 19:10:26 --> 404 Page Not Found: Admin/login.php
ERROR - 2021-12-14 19:10:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:10:27 --> Config Class Initialized
INFO - 2021-12-14 19:10:27 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:10:27 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:10:27 --> Utf8 Class Initialized
INFO - 2021-12-14 19:10:27 --> URI Class Initialized
INFO - 2021-12-14 19:10:27 --> Router Class Initialized
INFO - 2021-12-14 19:10:27 --> Output Class Initialized
INFO - 2021-12-14 19:10:27 --> Security Class Initialized
DEBUG - 2021-12-14 19:10:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:10:27 --> Input Class Initialized
INFO - 2021-12-14 19:10:27 --> Language Class Initialized
ERROR - 2021-12-14 19:10:27 --> 404 Page Not Found: Admin/index
ERROR - 2021-12-14 19:10:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:10:27 --> Config Class Initialized
INFO - 2021-12-14 19:10:27 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:10:27 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:10:27 --> Utf8 Class Initialized
INFO - 2021-12-14 19:10:27 --> URI Class Initialized
INFO - 2021-12-14 19:10:27 --> Router Class Initialized
INFO - 2021-12-14 19:10:27 --> Output Class Initialized
INFO - 2021-12-14 19:10:27 --> Security Class Initialized
DEBUG - 2021-12-14 19:10:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:10:27 --> Input Class Initialized
INFO - 2021-12-14 19:10:27 --> Language Class Initialized
ERROR - 2021-12-14 19:10:27 --> 404 Page Not Found: Plug/publish
ERROR - 2021-12-14 19:10:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:10:27 --> Config Class Initialized
INFO - 2021-12-14 19:10:27 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:10:27 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:10:27 --> Utf8 Class Initialized
INFO - 2021-12-14 19:10:27 --> URI Class Initialized
INFO - 2021-12-14 19:10:27 --> Router Class Initialized
INFO - 2021-12-14 19:10:27 --> Output Class Initialized
INFO - 2021-12-14 19:10:27 --> Security Class Initialized
DEBUG - 2021-12-14 19:10:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:10:27 --> Input Class Initialized
INFO - 2021-12-14 19:10:27 --> Language Class Initialized
ERROR - 2021-12-14 19:10:27 --> 404 Page Not Found: Script/login.js
ERROR - 2021-12-14 19:10:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:10:28 --> Config Class Initialized
INFO - 2021-12-14 19:10:28 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:10:28 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:10:28 --> Utf8 Class Initialized
INFO - 2021-12-14 19:10:28 --> URI Class Initialized
INFO - 2021-12-14 19:10:28 --> Router Class Initialized
INFO - 2021-12-14 19:10:28 --> Output Class Initialized
INFO - 2021-12-14 19:10:28 --> Security Class Initialized
DEBUG - 2021-12-14 19:10:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:10:28 --> Input Class Initialized
INFO - 2021-12-14 19:10:28 --> Language Class Initialized
ERROR - 2021-12-14 19:10:28 --> 404 Page Not Found: Public/about.html
ERROR - 2021-12-14 19:10:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:10:28 --> Config Class Initialized
INFO - 2021-12-14 19:10:28 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:10:28 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:10:28 --> Utf8 Class Initialized
INFO - 2021-12-14 19:10:28 --> URI Class Initialized
INFO - 2021-12-14 19:10:28 --> Router Class Initialized
INFO - 2021-12-14 19:10:28 --> Output Class Initialized
INFO - 2021-12-14 19:10:28 --> Security Class Initialized
DEBUG - 2021-12-14 19:10:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:10:28 --> Input Class Initialized
INFO - 2021-12-14 19:10:28 --> Language Class Initialized
ERROR - 2021-12-14 19:10:28 --> 404 Page Not Found: Help/en
ERROR - 2021-12-14 19:10:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:10:29 --> Config Class Initialized
INFO - 2021-12-14 19:10:29 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:10:29 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:10:29 --> Utf8 Class Initialized
INFO - 2021-12-14 19:10:29 --> URI Class Initialized
INFO - 2021-12-14 19:10:29 --> Router Class Initialized
INFO - 2021-12-14 19:10:29 --> Output Class Initialized
INFO - 2021-12-14 19:10:29 --> Security Class Initialized
DEBUG - 2021-12-14 19:10:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:10:29 --> Input Class Initialized
INFO - 2021-12-14 19:10:29 --> Language Class Initialized
ERROR - 2021-12-14 19:10:29 --> 404 Page Not Found: Public/Admin
ERROR - 2021-12-14 19:10:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:10:29 --> Config Class Initialized
INFO - 2021-12-14 19:10:29 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:10:29 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:10:29 --> Utf8 Class Initialized
INFO - 2021-12-14 19:10:29 --> URI Class Initialized
INFO - 2021-12-14 19:10:29 --> Router Class Initialized
INFO - 2021-12-14 19:10:29 --> Output Class Initialized
INFO - 2021-12-14 19:10:29 --> Security Class Initialized
DEBUG - 2021-12-14 19:10:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:10:29 --> Input Class Initialized
INFO - 2021-12-14 19:10:29 --> Language Class Initialized
ERROR - 2021-12-14 19:10:29 --> 404 Page Not Found: Customdir/images
ERROR - 2021-12-14 19:10:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:10:30 --> Config Class Initialized
INFO - 2021-12-14 19:10:30 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:10:30 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:10:30 --> Utf8 Class Initialized
INFO - 2021-12-14 19:10:30 --> URI Class Initialized
INFO - 2021-12-14 19:10:30 --> Router Class Initialized
INFO - 2021-12-14 19:10:30 --> Output Class Initialized
INFO - 2021-12-14 19:10:30 --> Security Class Initialized
DEBUG - 2021-12-14 19:10:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:10:30 --> Input Class Initialized
INFO - 2021-12-14 19:10:30 --> Language Class Initialized
ERROR - 2021-12-14 19:10:30 --> 404 Page Not Found: Include/dedeajax2.js
ERROR - 2021-12-14 19:10:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:10:30 --> Config Class Initialized
INFO - 2021-12-14 19:10:30 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:10:30 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:10:30 --> Utf8 Class Initialized
INFO - 2021-12-14 19:10:30 --> URI Class Initialized
INFO - 2021-12-14 19:10:30 --> Router Class Initialized
INFO - 2021-12-14 19:10:30 --> Output Class Initialized
INFO - 2021-12-14 19:10:30 --> Security Class Initialized
DEBUG - 2021-12-14 19:10:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:10:30 --> Input Class Initialized
INFO - 2021-12-14 19:10:30 --> Language Class Initialized
ERROR - 2021-12-14 19:10:30 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-14 19:10:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:10:31 --> Config Class Initialized
INFO - 2021-12-14 19:10:31 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:10:31 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:10:31 --> Utf8 Class Initialized
INFO - 2021-12-14 19:10:31 --> URI Class Initialized
INFO - 2021-12-14 19:10:31 --> Router Class Initialized
INFO - 2021-12-14 19:10:31 --> Output Class Initialized
INFO - 2021-12-14 19:10:31 --> Security Class Initialized
DEBUG - 2021-12-14 19:10:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:10:31 --> Input Class Initialized
INFO - 2021-12-14 19:10:31 --> Language Class Initialized
ERROR - 2021-12-14 19:10:31 --> 404 Page Not Found: Include/dialog
ERROR - 2021-12-14 19:10:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:10:31 --> Config Class Initialized
INFO - 2021-12-14 19:10:31 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:10:31 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:10:31 --> Utf8 Class Initialized
INFO - 2021-12-14 19:10:31 --> URI Class Initialized
INFO - 2021-12-14 19:10:31 --> Router Class Initialized
INFO - 2021-12-14 19:10:31 --> Output Class Initialized
INFO - 2021-12-14 19:10:31 --> Security Class Initialized
DEBUG - 2021-12-14 19:10:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:10:31 --> Input Class Initialized
INFO - 2021-12-14 19:10:31 --> Language Class Initialized
ERROR - 2021-12-14 19:10:31 --> 404 Page Not Found: Plus/download.php
ERROR - 2021-12-14 19:10:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:10:31 --> Config Class Initialized
INFO - 2021-12-14 19:10:31 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:10:31 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:10:31 --> Utf8 Class Initialized
INFO - 2021-12-14 19:10:31 --> URI Class Initialized
INFO - 2021-12-14 19:10:31 --> Router Class Initialized
INFO - 2021-12-14 19:10:31 --> Output Class Initialized
INFO - 2021-12-14 19:10:31 --> Security Class Initialized
DEBUG - 2021-12-14 19:10:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:10:31 --> Input Class Initialized
INFO - 2021-12-14 19:10:31 --> Language Class Initialized
ERROR - 2021-12-14 19:10:31 --> 404 Page Not Found: Diggphp/index
ERROR - 2021-12-14 19:10:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:10:32 --> Config Class Initialized
INFO - 2021-12-14 19:10:32 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:10:32 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:10:32 --> Utf8 Class Initialized
INFO - 2021-12-14 19:10:32 --> URI Class Initialized
INFO - 2021-12-14 19:10:32 --> Router Class Initialized
INFO - 2021-12-14 19:10:32 --> Output Class Initialized
INFO - 2021-12-14 19:10:32 --> Security Class Initialized
DEBUG - 2021-12-14 19:10:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:10:32 --> Input Class Initialized
INFO - 2021-12-14 19:10:32 --> Language Class Initialized
ERROR - 2021-12-14 19:10:32 --> 404 Page Not Found: Plus/sitemap.html
ERROR - 2021-12-14 19:10:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:10:32 --> Config Class Initialized
INFO - 2021-12-14 19:10:32 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:10:32 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:10:32 --> Utf8 Class Initialized
INFO - 2021-12-14 19:10:32 --> URI Class Initialized
INFO - 2021-12-14 19:10:32 --> Router Class Initialized
INFO - 2021-12-14 19:10:32 --> Output Class Initialized
INFO - 2021-12-14 19:10:32 --> Security Class Initialized
DEBUG - 2021-12-14 19:10:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:10:32 --> Input Class Initialized
INFO - 2021-12-14 19:10:32 --> Language Class Initialized
ERROR - 2021-12-14 19:10:32 --> 404 Page Not Found: Plus/rssmap.html
ERROR - 2021-12-14 19:10:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:10:32 --> Config Class Initialized
INFO - 2021-12-14 19:10:32 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:10:32 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:10:32 --> Utf8 Class Initialized
INFO - 2021-12-14 19:10:32 --> URI Class Initialized
INFO - 2021-12-14 19:10:32 --> Router Class Initialized
INFO - 2021-12-14 19:10:32 --> Output Class Initialized
INFO - 2021-12-14 19:10:32 --> Security Class Initialized
DEBUG - 2021-12-14 19:10:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:10:32 --> Input Class Initialized
INFO - 2021-12-14 19:10:32 --> Language Class Initialized
ERROR - 2021-12-14 19:10:32 --> 404 Page Not Found: Plus/heightsearch.php
ERROR - 2021-12-14 19:10:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:10:33 --> Config Class Initialized
INFO - 2021-12-14 19:10:33 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:10:33 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:10:33 --> Utf8 Class Initialized
INFO - 2021-12-14 19:10:33 --> URI Class Initialized
INFO - 2021-12-14 19:10:33 --> Router Class Initialized
INFO - 2021-12-14 19:10:33 --> Output Class Initialized
INFO - 2021-12-14 19:10:33 --> Security Class Initialized
DEBUG - 2021-12-14 19:10:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:10:33 --> Input Class Initialized
INFO - 2021-12-14 19:10:33 --> Language Class Initialized
ERROR - 2021-12-14 19:10:33 --> 404 Page Not Found: Member/space
ERROR - 2021-12-14 19:10:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:10:34 --> Config Class Initialized
INFO - 2021-12-14 19:10:34 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:10:34 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:10:34 --> Utf8 Class Initialized
INFO - 2021-12-14 19:10:34 --> URI Class Initialized
INFO - 2021-12-14 19:10:34 --> Router Class Initialized
INFO - 2021-12-14 19:10:34 --> Output Class Initialized
INFO - 2021-12-14 19:10:34 --> Security Class Initialized
DEBUG - 2021-12-14 19:10:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:10:34 --> Input Class Initialized
INFO - 2021-12-14 19:10:34 --> Language Class Initialized
ERROR - 2021-12-14 19:10:34 --> 404 Page Not Found: Help/index
ERROR - 2021-12-14 19:10:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:10:34 --> Config Class Initialized
INFO - 2021-12-14 19:10:34 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:10:34 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:10:34 --> Utf8 Class Initialized
INFO - 2021-12-14 19:10:34 --> URI Class Initialized
INFO - 2021-12-14 19:10:34 --> Router Class Initialized
INFO - 2021-12-14 19:10:34 --> Output Class Initialized
INFO - 2021-12-14 19:10:34 --> Security Class Initialized
DEBUG - 2021-12-14 19:10:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:10:34 --> Input Class Initialized
INFO - 2021-12-14 19:10:34 --> Language Class Initialized
ERROR - 2021-12-14 19:10:34 --> 404 Page Not Found: Install/logo.gif
ERROR - 2021-12-14 19:10:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:10:34 --> Config Class Initialized
INFO - 2021-12-14 19:10:34 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:10:34 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:10:34 --> Utf8 Class Initialized
INFO - 2021-12-14 19:10:34 --> URI Class Initialized
INFO - 2021-12-14 19:10:34 --> Router Class Initialized
INFO - 2021-12-14 19:10:34 --> Output Class Initialized
INFO - 2021-12-14 19:10:34 --> Security Class Initialized
DEBUG - 2021-12-14 19:10:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:10:34 --> Input Class Initialized
INFO - 2021-12-14 19:10:34 --> Language Class Initialized
ERROR - 2021-12-14 19:10:34 --> 404 Page Not Found: CHANGELOGtxt/index
ERROR - 2021-12-14 19:10:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:10:35 --> Config Class Initialized
INFO - 2021-12-14 19:10:35 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:10:35 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:10:35 --> Utf8 Class Initialized
INFO - 2021-12-14 19:10:35 --> URI Class Initialized
INFO - 2021-12-14 19:10:35 --> Router Class Initialized
INFO - 2021-12-14 19:10:35 --> Output Class Initialized
INFO - 2021-12-14 19:10:35 --> Security Class Initialized
DEBUG - 2021-12-14 19:10:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:10:35 --> Input Class Initialized
INFO - 2021-12-14 19:10:35 --> Language Class Initialized
ERROR - 2021-12-14 19:10:35 --> 404 Page Not Found: Changelogtxt/index
ERROR - 2021-12-14 19:10:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:10:35 --> Config Class Initialized
INFO - 2021-12-14 19:10:35 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:10:35 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:10:35 --> Utf8 Class Initialized
INFO - 2021-12-14 19:10:35 --> URI Class Initialized
INFO - 2021-12-14 19:10:35 --> Router Class Initialized
INFO - 2021-12-14 19:10:35 --> Output Class Initialized
INFO - 2021-12-14 19:10:35 --> Security Class Initialized
DEBUG - 2021-12-14 19:10:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:10:35 --> Input Class Initialized
INFO - 2021-12-14 19:10:35 --> Language Class Initialized
ERROR - 2021-12-14 19:10:35 --> 404 Page Not Found: M/index
ERROR - 2021-12-14 19:10:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:10:36 --> Config Class Initialized
INFO - 2021-12-14 19:10:36 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:10:36 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:10:36 --> Utf8 Class Initialized
INFO - 2021-12-14 19:10:36 --> URI Class Initialized
INFO - 2021-12-14 19:10:36 --> Router Class Initialized
INFO - 2021-12-14 19:10:36 --> Output Class Initialized
INFO - 2021-12-14 19:10:36 --> Security Class Initialized
DEBUG - 2021-12-14 19:10:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:10:36 --> Input Class Initialized
INFO - 2021-12-14 19:10:36 --> Language Class Initialized
ERROR - 2021-12-14 19:10:36 --> 404 Page Not Found: Adminphp/index
ERROR - 2021-12-14 19:10:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:10:36 --> Config Class Initialized
INFO - 2021-12-14 19:10:36 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:10:36 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:10:36 --> Utf8 Class Initialized
INFO - 2021-12-14 19:10:36 --> URI Class Initialized
INFO - 2021-12-14 19:10:36 --> Router Class Initialized
INFO - 2021-12-14 19:10:36 --> Output Class Initialized
INFO - 2021-12-14 19:10:36 --> Security Class Initialized
DEBUG - 2021-12-14 19:10:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:10:36 --> Input Class Initialized
INFO - 2021-12-14 19:10:36 --> Language Class Initialized
ERROR - 2021-12-14 19:10:36 --> 404 Page Not Found: Ycportal/js
ERROR - 2021-12-14 19:10:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:10:37 --> Config Class Initialized
INFO - 2021-12-14 19:10:37 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:10:37 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:10:37 --> Utf8 Class Initialized
INFO - 2021-12-14 19:10:37 --> URI Class Initialized
INFO - 2021-12-14 19:10:37 --> Router Class Initialized
INFO - 2021-12-14 19:10:37 --> Output Class Initialized
INFO - 2021-12-14 19:10:37 --> Security Class Initialized
DEBUG - 2021-12-14 19:10:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:10:37 --> Input Class Initialized
INFO - 2021-12-14 19:10:37 --> Language Class Initialized
ERROR - 2021-12-14 19:10:37 --> 404 Page Not Found: Webbuilder/script
ERROR - 2021-12-14 19:10:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:10:37 --> Config Class Initialized
INFO - 2021-12-14 19:10:37 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:10:37 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:10:37 --> Utf8 Class Initialized
INFO - 2021-12-14 19:10:37 --> URI Class Initialized
INFO - 2021-12-14 19:10:37 --> Router Class Initialized
INFO - 2021-12-14 19:10:37 --> Output Class Initialized
INFO - 2021-12-14 19:10:37 --> Security Class Initialized
DEBUG - 2021-12-14 19:10:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:10:37 --> Input Class Initialized
INFO - 2021-12-14 19:10:37 --> Language Class Initialized
ERROR - 2021-12-14 19:10:37 --> 404 Page Not Found: Login/Jeecms.do
ERROR - 2021-12-14 19:10:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:10:38 --> Config Class Initialized
INFO - 2021-12-14 19:10:38 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:10:38 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:10:38 --> Utf8 Class Initialized
INFO - 2021-12-14 19:10:38 --> URI Class Initialized
INFO - 2021-12-14 19:10:38 --> Router Class Initialized
INFO - 2021-12-14 19:10:38 --> Output Class Initialized
INFO - 2021-12-14 19:10:38 --> Security Class Initialized
DEBUG - 2021-12-14 19:10:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:10:38 --> Input Class Initialized
INFO - 2021-12-14 19:10:38 --> Language Class Initialized
ERROR - 2021-12-14 19:10:38 --> 404 Page Not Found: Datacenter/downloadApp
ERROR - 2021-12-14 19:10:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:10:38 --> Config Class Initialized
INFO - 2021-12-14 19:10:38 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:10:38 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:10:38 --> Utf8 Class Initialized
INFO - 2021-12-14 19:10:38 --> URI Class Initialized
INFO - 2021-12-14 19:10:38 --> Router Class Initialized
INFO - 2021-12-14 19:10:38 --> Output Class Initialized
INFO - 2021-12-14 19:10:38 --> Security Class Initialized
DEBUG - 2021-12-14 19:10:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:10:38 --> Input Class Initialized
INFO - 2021-12-14 19:10:38 --> Language Class Initialized
ERROR - 2021-12-14 19:10:38 --> 404 Page Not Found: Include/install_ocx.aspx
ERROR - 2021-12-14 19:10:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:10:39 --> Config Class Initialized
INFO - 2021-12-14 19:10:39 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:10:39 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:10:39 --> Utf8 Class Initialized
INFO - 2021-12-14 19:10:39 --> URI Class Initialized
INFO - 2021-12-14 19:10:39 --> Router Class Initialized
INFO - 2021-12-14 19:10:39 --> Output Class Initialized
INFO - 2021-12-14 19:10:39 --> Security Class Initialized
DEBUG - 2021-12-14 19:10:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:10:39 --> Input Class Initialized
INFO - 2021-12-14 19:10:39 --> Language Class Initialized
ERROR - 2021-12-14 19:10:39 --> 404 Page Not Found: Site/Pages
ERROR - 2021-12-14 19:10:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:10:39 --> Config Class Initialized
INFO - 2021-12-14 19:10:39 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:10:39 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:10:39 --> Utf8 Class Initialized
INFO - 2021-12-14 19:10:39 --> URI Class Initialized
INFO - 2021-12-14 19:10:39 --> Router Class Initialized
INFO - 2021-12-14 19:10:39 --> Output Class Initialized
INFO - 2021-12-14 19:10:39 --> Security Class Initialized
DEBUG - 2021-12-14 19:10:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:10:39 --> Input Class Initialized
INFO - 2021-12-14 19:10:39 --> Language Class Initialized
ERROR - 2021-12-14 19:10:39 --> 404 Page Not Found: Site/SystemThemes
ERROR - 2021-12-14 19:10:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:10:39 --> Config Class Initialized
INFO - 2021-12-14 19:10:39 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:10:39 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:10:39 --> Utf8 Class Initialized
INFO - 2021-12-14 19:10:39 --> URI Class Initialized
INFO - 2021-12-14 19:10:39 --> Router Class Initialized
INFO - 2021-12-14 19:10:39 --> Output Class Initialized
INFO - 2021-12-14 19:10:39 --> Security Class Initialized
DEBUG - 2021-12-14 19:10:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:10:39 --> Input Class Initialized
INFO - 2021-12-14 19:10:39 --> Language Class Initialized
ERROR - 2021-12-14 19:10:39 --> 404 Page Not Found: System/Update.aspx
ERROR - 2021-12-14 19:10:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:10:40 --> Config Class Initialized
INFO - 2021-12-14 19:10:40 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:10:40 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:10:40 --> Utf8 Class Initialized
INFO - 2021-12-14 19:10:40 --> URI Class Initialized
INFO - 2021-12-14 19:10:40 --> Router Class Initialized
INFO - 2021-12-14 19:10:40 --> Output Class Initialized
INFO - 2021-12-14 19:10:40 --> Security Class Initialized
DEBUG - 2021-12-14 19:10:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:10:40 --> Input Class Initialized
INFO - 2021-12-14 19:10:40 --> Language Class Initialized
ERROR - 2021-12-14 19:10:40 --> 404 Page Not Found: Nobody/mobile.htm
ERROR - 2021-12-14 19:10:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:10:40 --> Config Class Initialized
INFO - 2021-12-14 19:10:40 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:10:40 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:10:40 --> Utf8 Class Initialized
INFO - 2021-12-14 19:10:40 --> URI Class Initialized
INFO - 2021-12-14 19:10:40 --> Router Class Initialized
INFO - 2021-12-14 19:10:40 --> Output Class Initialized
INFO - 2021-12-14 19:10:40 --> Security Class Initialized
DEBUG - 2021-12-14 19:10:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:10:40 --> Input Class Initialized
INFO - 2021-12-14 19:10:40 --> Language Class Initialized
ERROR - 2021-12-14 19:10:40 --> 404 Page Not Found: Forumphp/index
ERROR - 2021-12-14 19:10:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:10:41 --> Config Class Initialized
INFO - 2021-12-14 19:10:41 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:10:41 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:10:41 --> Utf8 Class Initialized
INFO - 2021-12-14 19:10:41 --> URI Class Initialized
INFO - 2021-12-14 19:10:41 --> Router Class Initialized
INFO - 2021-12-14 19:10:41 --> Output Class Initialized
INFO - 2021-12-14 19:10:41 --> Security Class Initialized
DEBUG - 2021-12-14 19:10:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:10:41 --> Input Class Initialized
INFO - 2021-12-14 19:10:41 --> Language Class Initialized
ERROR - 2021-12-14 19:10:41 --> 404 Page Not Found: Archiver/index
ERROR - 2021-12-14 19:10:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:10:41 --> Config Class Initialized
INFO - 2021-12-14 19:10:41 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:10:41 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:10:41 --> Utf8 Class Initialized
INFO - 2021-12-14 19:10:41 --> URI Class Initialized
INFO - 2021-12-14 19:10:41 --> Router Class Initialized
INFO - 2021-12-14 19:10:41 --> Output Class Initialized
INFO - 2021-12-14 19:10:41 --> Security Class Initialized
DEBUG - 2021-12-14 19:10:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:10:41 --> Input Class Initialized
INFO - 2021-12-14 19:10:41 --> Language Class Initialized
ERROR - 2021-12-14 19:10:41 --> 404 Page Not Found: Uc_server/control
ERROR - 2021-12-14 19:10:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:10:41 --> Config Class Initialized
INFO - 2021-12-14 19:10:41 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:10:41 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:10:41 --> Utf8 Class Initialized
INFO - 2021-12-14 19:10:41 --> URI Class Initialized
INFO - 2021-12-14 19:10:41 --> Router Class Initialized
INFO - 2021-12-14 19:10:41 --> Output Class Initialized
INFO - 2021-12-14 19:10:41 --> Security Class Initialized
DEBUG - 2021-12-14 19:10:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:10:41 --> Input Class Initialized
INFO - 2021-12-14 19:10:41 --> Language Class Initialized
ERROR - 2021-12-14 19:10:41 --> 404 Page Not Found: Img/pic
ERROR - 2021-12-14 19:10:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:10:42 --> Config Class Initialized
INFO - 2021-12-14 19:10:42 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:10:42 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:10:42 --> Utf8 Class Initialized
INFO - 2021-12-14 19:10:42 --> URI Class Initialized
INFO - 2021-12-14 19:10:42 --> Router Class Initialized
INFO - 2021-12-14 19:10:42 --> Output Class Initialized
INFO - 2021-12-14 19:10:42 --> Security Class Initialized
DEBUG - 2021-12-14 19:10:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:10:42 --> Input Class Initialized
INFO - 2021-12-14 19:10:42 --> Language Class Initialized
ERROR - 2021-12-14 19:10:42 --> 404 Page Not Found: Business/images
ERROR - 2021-12-14 19:10:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:10:42 --> Config Class Initialized
INFO - 2021-12-14 19:10:42 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:10:42 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:10:42 --> Utf8 Class Initialized
INFO - 2021-12-14 19:10:42 --> URI Class Initialized
INFO - 2021-12-14 19:10:42 --> Router Class Initialized
INFO - 2021-12-14 19:10:42 --> Output Class Initialized
INFO - 2021-12-14 19:10:42 --> Security Class Initialized
DEBUG - 2021-12-14 19:10:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:10:42 --> Input Class Initialized
INFO - 2021-12-14 19:10:42 --> Language Class Initialized
ERROR - 2021-12-14 19:10:42 --> 404 Page Not Found: Include/EcsServerApi.js
ERROR - 2021-12-14 19:10:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:10:43 --> Config Class Initialized
INFO - 2021-12-14 19:10:43 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:10:43 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:10:43 --> Utf8 Class Initialized
INFO - 2021-12-14 19:10:43 --> URI Class Initialized
INFO - 2021-12-14 19:10:43 --> Router Class Initialized
INFO - 2021-12-14 19:10:43 --> Output Class Initialized
INFO - 2021-12-14 19:10:43 --> Security Class Initialized
DEBUG - 2021-12-14 19:10:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:10:43 --> Input Class Initialized
INFO - 2021-12-14 19:10:43 --> Language Class Initialized
ERROR - 2021-12-14 19:10:43 --> 404 Page Not Found: Custom/SkinTemplate
ERROR - 2021-12-14 19:10:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:10:43 --> Config Class Initialized
INFO - 2021-12-14 19:10:43 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:10:43 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:10:43 --> Utf8 Class Initialized
INFO - 2021-12-14 19:10:43 --> URI Class Initialized
INFO - 2021-12-14 19:10:43 --> Router Class Initialized
INFO - 2021-12-14 19:10:43 --> Output Class Initialized
INFO - 2021-12-14 19:10:43 --> Security Class Initialized
DEBUG - 2021-12-14 19:10:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:10:43 --> Input Class Initialized
INFO - 2021-12-14 19:10:43 --> Language Class Initialized
ERROR - 2021-12-14 19:10:43 --> 404 Page Not Found: Eams/static
ERROR - 2021-12-14 19:10:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:10:43 --> Config Class Initialized
INFO - 2021-12-14 19:10:43 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:10:43 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:10:43 --> Utf8 Class Initialized
INFO - 2021-12-14 19:10:43 --> URI Class Initialized
INFO - 2021-12-14 19:10:43 --> Router Class Initialized
INFO - 2021-12-14 19:10:43 --> Output Class Initialized
INFO - 2021-12-14 19:10:44 --> Security Class Initialized
DEBUG - 2021-12-14 19:10:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:10:44 --> Input Class Initialized
INFO - 2021-12-14 19:10:44 --> Language Class Initialized
ERROR - 2021-12-14 19:10:44 --> 404 Page Not Found: Static/images
ERROR - 2021-12-14 19:10:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:10:44 --> Config Class Initialized
INFO - 2021-12-14 19:10:44 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:10:44 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:10:44 --> Utf8 Class Initialized
INFO - 2021-12-14 19:10:44 --> URI Class Initialized
INFO - 2021-12-14 19:10:44 --> Router Class Initialized
INFO - 2021-12-14 19:10:44 --> Output Class Initialized
INFO - 2021-12-14 19:10:44 --> Security Class Initialized
DEBUG - 2021-12-14 19:10:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:10:44 --> Input Class Initialized
INFO - 2021-12-14 19:10:44 --> Language Class Initialized
ERROR - 2021-12-14 19:10:44 --> 404 Page Not Found: Admin/admin_login.php
ERROR - 2021-12-14 19:10:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:10:44 --> Config Class Initialized
INFO - 2021-12-14 19:10:44 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:10:44 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:10:44 --> Utf8 Class Initialized
INFO - 2021-12-14 19:10:44 --> URI Class Initialized
INFO - 2021-12-14 19:10:44 --> Router Class Initialized
INFO - 2021-12-14 19:10:44 --> Output Class Initialized
INFO - 2021-12-14 19:10:44 --> Security Class Initialized
DEBUG - 2021-12-14 19:10:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:10:44 --> Input Class Initialized
INFO - 2021-12-14 19:10:44 --> Language Class Initialized
ERROR - 2021-12-14 19:10:44 --> 404 Page Not Found: Data/images
ERROR - 2021-12-14 19:10:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:10:45 --> Config Class Initialized
INFO - 2021-12-14 19:10:45 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:10:45 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:10:45 --> Utf8 Class Initialized
INFO - 2021-12-14 19:10:45 --> URI Class Initialized
INFO - 2021-12-14 19:10:45 --> Router Class Initialized
INFO - 2021-12-14 19:10:45 --> Output Class Initialized
INFO - 2021-12-14 19:10:45 --> Security Class Initialized
DEBUG - 2021-12-14 19:10:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:10:45 --> Input Class Initialized
INFO - 2021-12-14 19:10:45 --> Language Class Initialized
ERROR - 2021-12-14 19:10:45 --> 404 Page Not Found: Wp-cronphp/index
ERROR - 2021-12-14 19:10:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:10:45 --> Config Class Initialized
INFO - 2021-12-14 19:10:45 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:10:45 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:10:45 --> Utf8 Class Initialized
INFO - 2021-12-14 19:10:45 --> URI Class Initialized
INFO - 2021-12-14 19:10:45 --> Router Class Initialized
INFO - 2021-12-14 19:10:45 --> Output Class Initialized
INFO - 2021-12-14 19:10:45 --> Security Class Initialized
DEBUG - 2021-12-14 19:10:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:10:45 --> Input Class Initialized
INFO - 2021-12-14 19:10:45 --> Language Class Initialized
ERROR - 2021-12-14 19:10:45 --> 404 Page Not Found: Wp-content/index
ERROR - 2021-12-14 19:10:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:10:46 --> Config Class Initialized
INFO - 2021-12-14 19:10:46 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:10:46 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:10:46 --> Utf8 Class Initialized
INFO - 2021-12-14 19:10:46 --> URI Class Initialized
INFO - 2021-12-14 19:10:46 --> Router Class Initialized
INFO - 2021-12-14 19:10:46 --> Output Class Initialized
INFO - 2021-12-14 19:10:46 --> Security Class Initialized
DEBUG - 2021-12-14 19:10:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:10:46 --> Input Class Initialized
INFO - 2021-12-14 19:10:46 --> Language Class Initialized
ERROR - 2021-12-14 19:10:46 --> 404 Page Not Found: Licensetxt/index
ERROR - 2021-12-14 19:10:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:10:46 --> Config Class Initialized
INFO - 2021-12-14 19:10:46 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:10:46 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:10:46 --> Utf8 Class Initialized
INFO - 2021-12-14 19:10:46 --> URI Class Initialized
INFO - 2021-12-14 19:10:46 --> Router Class Initialized
INFO - 2021-12-14 19:10:46 --> Output Class Initialized
INFO - 2021-12-14 19:10:46 --> Security Class Initialized
DEBUG - 2021-12-14 19:10:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:10:46 --> Input Class Initialized
INFO - 2021-12-14 19:10:46 --> Language Class Initialized
ERROR - 2021-12-14 19:10:46 --> 404 Page Not Found: Readmehtml/index
ERROR - 2021-12-14 19:10:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:10:47 --> Config Class Initialized
INFO - 2021-12-14 19:10:47 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:10:47 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:10:47 --> Utf8 Class Initialized
INFO - 2021-12-14 19:10:47 --> URI Class Initialized
INFO - 2021-12-14 19:10:47 --> Router Class Initialized
INFO - 2021-12-14 19:10:47 --> Output Class Initialized
INFO - 2021-12-14 19:10:47 --> Security Class Initialized
DEBUG - 2021-12-14 19:10:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:10:47 --> Input Class Initialized
INFO - 2021-12-14 19:10:47 --> Language Class Initialized
ERROR - 2021-12-14 19:10:47 --> 404 Page Not Found: Was/help.jsp
ERROR - 2021-12-14 19:10:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:10:47 --> Config Class Initialized
INFO - 2021-12-14 19:10:47 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:10:47 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:10:47 --> Utf8 Class Initialized
INFO - 2021-12-14 19:10:47 --> URI Class Initialized
INFO - 2021-12-14 19:10:47 --> Router Class Initialized
INFO - 2021-12-14 19:10:47 --> Output Class Initialized
INFO - 2021-12-14 19:10:47 --> Security Class Initialized
DEBUG - 2021-12-14 19:10:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:10:47 --> Input Class Initialized
INFO - 2021-12-14 19:10:47 --> Language Class Initialized
ERROR - 2021-12-14 19:10:47 --> 404 Page Not Found: Was5/web
ERROR - 2021-12-14 19:10:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:10:48 --> Config Class Initialized
INFO - 2021-12-14 19:10:48 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:10:48 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:10:48 --> Utf8 Class Initialized
INFO - 2021-12-14 19:10:48 --> URI Class Initialized
INFO - 2021-12-14 19:10:48 --> Router Class Initialized
INFO - 2021-12-14 19:10:48 --> Output Class Initialized
INFO - 2021-12-14 19:10:48 --> Security Class Initialized
DEBUG - 2021-12-14 19:10:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:10:48 --> Input Class Initialized
INFO - 2021-12-14 19:10:48 --> Language Class Initialized
ERROR - 2021-12-14 19:10:48 --> 404 Page Not Found: Was/main.html
ERROR - 2021-12-14 19:10:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:10:48 --> Config Class Initialized
INFO - 2021-12-14 19:10:48 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:10:48 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:10:48 --> Utf8 Class Initialized
INFO - 2021-12-14 19:10:48 --> URI Class Initialized
INFO - 2021-12-14 19:10:48 --> Router Class Initialized
INFO - 2021-12-14 19:10:48 --> Output Class Initialized
INFO - 2021-12-14 19:10:48 --> Security Class Initialized
DEBUG - 2021-12-14 19:10:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:10:48 --> Input Class Initialized
INFO - 2021-12-14 19:10:48 --> Language Class Initialized
ERROR - 2021-12-14 19:10:48 --> 404 Page Not Found: Logo/logo_jw.png
ERROR - 2021-12-14 19:10:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:10:49 --> Config Class Initialized
INFO - 2021-12-14 19:10:49 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:10:49 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:10:49 --> Utf8 Class Initialized
INFO - 2021-12-14 19:10:49 --> URI Class Initialized
INFO - 2021-12-14 19:10:49 --> Router Class Initialized
INFO - 2021-12-14 19:10:49 --> Output Class Initialized
INFO - 2021-12-14 19:10:49 --> Security Class Initialized
DEBUG - 2021-12-14 19:10:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:10:49 --> Input Class Initialized
INFO - 2021-12-14 19:10:49 --> Language Class Initialized
ERROR - 2021-12-14 19:10:49 --> 404 Page Not Found: Phpmyadmin/index
ERROR - 2021-12-14 19:10:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:10:49 --> Config Class Initialized
INFO - 2021-12-14 19:10:49 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:10:49 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:10:49 --> Utf8 Class Initialized
INFO - 2021-12-14 19:10:49 --> URI Class Initialized
INFO - 2021-12-14 19:10:49 --> Router Class Initialized
INFO - 2021-12-14 19:10:49 --> Output Class Initialized
INFO - 2021-12-14 19:10:49 --> Security Class Initialized
DEBUG - 2021-12-14 19:10:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:10:49 --> Input Class Initialized
INFO - 2021-12-14 19:10:49 --> Language Class Initialized
ERROR - 2021-12-14 19:10:49 --> 404 Page Not Found: Weblog/index
ERROR - 2021-12-14 19:10:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:10:50 --> Config Class Initialized
INFO - 2021-12-14 19:10:50 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:10:50 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:10:50 --> Utf8 Class Initialized
INFO - 2021-12-14 19:10:50 --> URI Class Initialized
INFO - 2021-12-14 19:10:50 --> Router Class Initialized
INFO - 2021-12-14 19:10:50 --> Output Class Initialized
INFO - 2021-12-14 19:10:50 --> Security Class Initialized
DEBUG - 2021-12-14 19:10:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:10:50 --> Input Class Initialized
INFO - 2021-12-14 19:10:50 --> Language Class Initialized
ERROR - 2021-12-14 19:10:50 --> 404 Page Not Found: Blog/index
ERROR - 2021-12-14 19:10:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:10:50 --> Config Class Initialized
INFO - 2021-12-14 19:10:50 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:10:50 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:10:50 --> Utf8 Class Initialized
INFO - 2021-12-14 19:10:50 --> URI Class Initialized
INFO - 2021-12-14 19:10:50 --> Router Class Initialized
INFO - 2021-12-14 19:10:50 --> Output Class Initialized
INFO - 2021-12-14 19:10:50 --> Security Class Initialized
DEBUG - 2021-12-14 19:10:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:10:50 --> Input Class Initialized
INFO - 2021-12-14 19:10:50 --> Language Class Initialized
ERROR - 2021-12-14 19:10:50 --> 404 Page Not Found: Forum/index
ERROR - 2021-12-14 19:10:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:10:50 --> Config Class Initialized
INFO - 2021-12-14 19:10:50 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:10:50 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:10:50 --> Utf8 Class Initialized
INFO - 2021-12-14 19:10:50 --> URI Class Initialized
INFO - 2021-12-14 19:10:50 --> Router Class Initialized
INFO - 2021-12-14 19:10:50 --> Output Class Initialized
INFO - 2021-12-14 19:10:50 --> Security Class Initialized
DEBUG - 2021-12-14 19:10:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:10:50 --> Input Class Initialized
INFO - 2021-12-14 19:10:50 --> Language Class Initialized
ERROR - 2021-12-14 19:10:50 --> 404 Page Not Found: Bbs/index
ERROR - 2021-12-14 19:10:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:10:51 --> Config Class Initialized
INFO - 2021-12-14 19:10:51 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:10:51 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:10:51 --> Utf8 Class Initialized
INFO - 2021-12-14 19:10:51 --> URI Class Initialized
INFO - 2021-12-14 19:10:51 --> Router Class Initialized
INFO - 2021-12-14 19:10:51 --> Output Class Initialized
INFO - 2021-12-14 19:10:51 --> Security Class Initialized
DEBUG - 2021-12-14 19:10:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:10:51 --> Input Class Initialized
INFO - 2021-12-14 19:10:51 --> Language Class Initialized
ERROR - 2021-12-14 19:10:51 --> 404 Page Not Found: Wcm/index
ERROR - 2021-12-14 19:10:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 19:10:51 --> Config Class Initialized
INFO - 2021-12-14 19:10:51 --> Hooks Class Initialized
DEBUG - 2021-12-14 19:10:51 --> UTF-8 Support Enabled
INFO - 2021-12-14 19:10:51 --> Utf8 Class Initialized
INFO - 2021-12-14 19:10:51 --> URI Class Initialized
INFO - 2021-12-14 19:10:51 --> Router Class Initialized
INFO - 2021-12-14 19:10:51 --> Output Class Initialized
INFO - 2021-12-14 19:10:51 --> Security Class Initialized
DEBUG - 2021-12-14 19:10:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 19:10:51 --> Input Class Initialized
INFO - 2021-12-14 19:10:51 --> Language Class Initialized
ERROR - 2021-12-14 19:10:51 --> 404 Page Not Found: Admin/editor
ERROR - 2021-12-14 23:42:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 23:42:42 --> Config Class Initialized
INFO - 2021-12-14 23:42:42 --> Hooks Class Initialized
DEBUG - 2021-12-14 23:42:42 --> UTF-8 Support Enabled
INFO - 2021-12-14 23:42:42 --> Utf8 Class Initialized
INFO - 2021-12-14 23:42:42 --> URI Class Initialized
DEBUG - 2021-12-14 23:42:42 --> No URI present. Default controller set.
INFO - 2021-12-14 23:42:42 --> Router Class Initialized
INFO - 2021-12-14 23:42:42 --> Output Class Initialized
INFO - 2021-12-14 23:42:42 --> Security Class Initialized
DEBUG - 2021-12-14 23:42:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 23:42:42 --> Input Class Initialized
INFO - 2021-12-14 23:42:42 --> Language Class Initialized
INFO - 2021-12-14 23:42:42 --> Loader Class Initialized
INFO - 2021-12-14 23:42:42 --> Helper loaded: url_helper
INFO - 2021-12-14 23:42:42 --> Helper loaded: form_helper
INFO - 2021-12-14 23:42:42 --> Helper loaded: common_helper
INFO - 2021-12-14 23:42:42 --> Database Driver Class Initialized
DEBUG - 2021-12-14 23:42:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-14 23:42:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-14 23:42:42 --> Controller Class Initialized
INFO - 2021-12-14 23:42:42 --> Form Validation Class Initialized
DEBUG - 2021-12-14 23:42:42 --> Encrypt Class Initialized
DEBUG - 2021-12-14 23:42:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-14 23:42:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-14 23:42:42 --> Email Class Initialized
INFO - 2021-12-14 23:42:42 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-14 23:42:42 --> Calendar Class Initialized
INFO - 2021-12-14 23:42:42 --> Model "Login_model" initialized
INFO - 2021-12-14 23:42:42 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-14 23:42:42 --> Final output sent to browser
DEBUG - 2021-12-14 23:42:42 --> Total execution time: 0.1303
ERROR - 2021-12-14 23:43:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 23:43:04 --> Config Class Initialized
INFO - 2021-12-14 23:43:04 --> Hooks Class Initialized
DEBUG - 2021-12-14 23:43:04 --> UTF-8 Support Enabled
INFO - 2021-12-14 23:43:04 --> Utf8 Class Initialized
INFO - 2021-12-14 23:43:04 --> URI Class Initialized
INFO - 2021-12-14 23:43:04 --> Router Class Initialized
INFO - 2021-12-14 23:43:04 --> Output Class Initialized
INFO - 2021-12-14 23:43:04 --> Security Class Initialized
DEBUG - 2021-12-14 23:43:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 23:43:04 --> Input Class Initialized
INFO - 2021-12-14 23:43:04 --> Language Class Initialized
INFO - 2021-12-14 23:43:04 --> Loader Class Initialized
INFO - 2021-12-14 23:43:04 --> Helper loaded: url_helper
INFO - 2021-12-14 23:43:04 --> Helper loaded: form_helper
INFO - 2021-12-14 23:43:04 --> Helper loaded: common_helper
INFO - 2021-12-14 23:43:04 --> Database Driver Class Initialized
DEBUG - 2021-12-14 23:43:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-14 23:43:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-14 23:43:04 --> Controller Class Initialized
INFO - 2021-12-14 23:43:04 --> Form Validation Class Initialized
DEBUG - 2021-12-14 23:43:04 --> Encrypt Class Initialized
DEBUG - 2021-12-14 23:43:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-14 23:43:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-14 23:43:04 --> Email Class Initialized
INFO - 2021-12-14 23:43:04 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-14 23:43:04 --> Calendar Class Initialized
INFO - 2021-12-14 23:43:04 --> Model "Login_model" initialized
INFO - 2021-12-14 23:43:04 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2021-12-14 23:43:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 23:43:05 --> Config Class Initialized
INFO - 2021-12-14 23:43:05 --> Hooks Class Initialized
DEBUG - 2021-12-14 23:43:05 --> UTF-8 Support Enabled
INFO - 2021-12-14 23:43:05 --> Utf8 Class Initialized
INFO - 2021-12-14 23:43:05 --> URI Class Initialized
INFO - 2021-12-14 23:43:05 --> Router Class Initialized
INFO - 2021-12-14 23:43:05 --> Output Class Initialized
INFO - 2021-12-14 23:43:05 --> Security Class Initialized
DEBUG - 2021-12-14 23:43:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 23:43:05 --> Input Class Initialized
INFO - 2021-12-14 23:43:05 --> Language Class Initialized
INFO - 2021-12-14 23:43:05 --> Loader Class Initialized
INFO - 2021-12-14 23:43:05 --> Helper loaded: url_helper
INFO - 2021-12-14 23:43:05 --> Helper loaded: form_helper
INFO - 2021-12-14 23:43:05 --> Helper loaded: common_helper
INFO - 2021-12-14 23:43:05 --> Database Driver Class Initialized
DEBUG - 2021-12-14 23:43:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-14 23:43:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-14 23:43:05 --> Controller Class Initialized
INFO - 2021-12-14 23:43:05 --> Form Validation Class Initialized
DEBUG - 2021-12-14 23:43:05 --> Encrypt Class Initialized
INFO - 2021-12-14 23:43:05 --> Model "Login_model" initialized
INFO - 2021-12-14 23:43:05 --> Model "Dashboard_model" initialized
INFO - 2021-12-14 23:43:05 --> Model "Case_model" initialized
INFO - 2021-12-14 23:43:13 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-14 23:43:23 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2021-12-14 23:43:23 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-14 23:43:23 --> Final output sent to browser
DEBUG - 2021-12-14 23:43:23 --> Total execution time: 17.4955
ERROR - 2021-12-14 23:43:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 23:43:24 --> Config Class Initialized
INFO - 2021-12-14 23:43:24 --> Hooks Class Initialized
DEBUG - 2021-12-14 23:43:24 --> UTF-8 Support Enabled
INFO - 2021-12-14 23:43:24 --> Utf8 Class Initialized
INFO - 2021-12-14 23:43:24 --> URI Class Initialized
INFO - 2021-12-14 23:43:24 --> Router Class Initialized
INFO - 2021-12-14 23:43:24 --> Output Class Initialized
INFO - 2021-12-14 23:43:24 --> Security Class Initialized
DEBUG - 2021-12-14 23:43:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 23:43:24 --> Input Class Initialized
INFO - 2021-12-14 23:43:24 --> Language Class Initialized
ERROR - 2021-12-14 23:43:24 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-12-14 23:44:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 23:44:22 --> Config Class Initialized
INFO - 2021-12-14 23:44:22 --> Hooks Class Initialized
DEBUG - 2021-12-14 23:44:22 --> UTF-8 Support Enabled
INFO - 2021-12-14 23:44:22 --> Utf8 Class Initialized
INFO - 2021-12-14 23:44:22 --> URI Class Initialized
INFO - 2021-12-14 23:44:22 --> Router Class Initialized
INFO - 2021-12-14 23:44:22 --> Output Class Initialized
INFO - 2021-12-14 23:44:22 --> Security Class Initialized
DEBUG - 2021-12-14 23:44:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 23:44:22 --> Input Class Initialized
INFO - 2021-12-14 23:44:22 --> Language Class Initialized
INFO - 2021-12-14 23:44:22 --> Loader Class Initialized
INFO - 2021-12-14 23:44:22 --> Helper loaded: url_helper
INFO - 2021-12-14 23:44:22 --> Helper loaded: form_helper
INFO - 2021-12-14 23:44:22 --> Helper loaded: common_helper
INFO - 2021-12-14 23:44:22 --> Database Driver Class Initialized
DEBUG - 2021-12-14 23:44:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-14 23:44:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-14 23:44:22 --> Controller Class Initialized
INFO - 2021-12-14 23:44:22 --> Form Validation Class Initialized
DEBUG - 2021-12-14 23:44:22 --> Encrypt Class Initialized
INFO - 2021-12-14 23:44:22 --> Model "Login_model" initialized
INFO - 2021-12-14 23:44:22 --> Model "Dashboard_model" initialized
INFO - 2021-12-14 23:44:22 --> Model "Case_model" initialized
INFO - 2021-12-14 23:44:32 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-14 23:44:42 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2021-12-14 23:44:42 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-14 23:44:42 --> Final output sent to browser
DEBUG - 2021-12-14 23:44:42 --> Total execution time: 20.0038
ERROR - 2021-12-14 23:44:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 23:44:43 --> Config Class Initialized
INFO - 2021-12-14 23:44:43 --> Hooks Class Initialized
DEBUG - 2021-12-14 23:44:43 --> UTF-8 Support Enabled
INFO - 2021-12-14 23:44:43 --> Utf8 Class Initialized
INFO - 2021-12-14 23:44:43 --> URI Class Initialized
INFO - 2021-12-14 23:44:43 --> Router Class Initialized
INFO - 2021-12-14 23:44:43 --> Output Class Initialized
INFO - 2021-12-14 23:44:43 --> Security Class Initialized
DEBUG - 2021-12-14 23:44:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 23:44:43 --> Input Class Initialized
INFO - 2021-12-14 23:44:43 --> Language Class Initialized
ERROR - 2021-12-14 23:44:43 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-12-14 23:46:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 23:46:12 --> Config Class Initialized
INFO - 2021-12-14 23:46:12 --> Hooks Class Initialized
DEBUG - 2021-12-14 23:46:12 --> UTF-8 Support Enabled
INFO - 2021-12-14 23:46:12 --> Utf8 Class Initialized
INFO - 2021-12-14 23:46:12 --> URI Class Initialized
DEBUG - 2021-12-14 23:46:12 --> No URI present. Default controller set.
INFO - 2021-12-14 23:46:12 --> Router Class Initialized
INFO - 2021-12-14 23:46:12 --> Output Class Initialized
INFO - 2021-12-14 23:46:12 --> Security Class Initialized
DEBUG - 2021-12-14 23:46:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 23:46:12 --> Input Class Initialized
INFO - 2021-12-14 23:46:12 --> Language Class Initialized
INFO - 2021-12-14 23:46:12 --> Loader Class Initialized
INFO - 2021-12-14 23:46:12 --> Helper loaded: url_helper
INFO - 2021-12-14 23:46:12 --> Helper loaded: form_helper
INFO - 2021-12-14 23:46:12 --> Helper loaded: common_helper
INFO - 2021-12-14 23:46:12 --> Database Driver Class Initialized
DEBUG - 2021-12-14 23:46:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-14 23:46:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-14 23:46:12 --> Controller Class Initialized
INFO - 2021-12-14 23:46:12 --> Form Validation Class Initialized
DEBUG - 2021-12-14 23:46:12 --> Encrypt Class Initialized
DEBUG - 2021-12-14 23:46:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-14 23:46:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-14 23:46:12 --> Email Class Initialized
INFO - 2021-12-14 23:46:12 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-14 23:46:12 --> Calendar Class Initialized
INFO - 2021-12-14 23:46:12 --> Model "Login_model" initialized
INFO - 2021-12-14 23:46:12 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-14 23:46:12 --> Final output sent to browser
DEBUG - 2021-12-14 23:46:12 --> Total execution time: 0.0224
ERROR - 2021-12-14 23:46:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 23:46:46 --> Config Class Initialized
INFO - 2021-12-14 23:46:46 --> Hooks Class Initialized
DEBUG - 2021-12-14 23:46:46 --> UTF-8 Support Enabled
INFO - 2021-12-14 23:46:46 --> Utf8 Class Initialized
INFO - 2021-12-14 23:46:46 --> URI Class Initialized
INFO - 2021-12-14 23:46:46 --> Router Class Initialized
INFO - 2021-12-14 23:46:46 --> Output Class Initialized
INFO - 2021-12-14 23:46:46 --> Security Class Initialized
DEBUG - 2021-12-14 23:46:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 23:46:46 --> Input Class Initialized
INFO - 2021-12-14 23:46:46 --> Language Class Initialized
INFO - 2021-12-14 23:46:46 --> Loader Class Initialized
INFO - 2021-12-14 23:46:46 --> Helper loaded: url_helper
INFO - 2021-12-14 23:46:46 --> Helper loaded: form_helper
INFO - 2021-12-14 23:46:46 --> Helper loaded: common_helper
INFO - 2021-12-14 23:46:46 --> Database Driver Class Initialized
DEBUG - 2021-12-14 23:46:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-14 23:46:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-14 23:46:46 --> Controller Class Initialized
INFO - 2021-12-14 23:46:46 --> Form Validation Class Initialized
INFO - 2021-12-14 23:46:46 --> Model "Case_model" initialized
INFO - 2021-12-14 23:46:46 --> Model "Patientcase_model" initialized
INFO - 2021-12-14 23:46:47 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-14 23:46:47 --> File loaded: /home3/karoteam/public_html/application/views/cases/new_case.php
INFO - 2021-12-14 23:46:47 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-14 23:46:47 --> Final output sent to browser
DEBUG - 2021-12-14 23:46:47 --> Total execution time: 0.5479
ERROR - 2021-12-14 23:46:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 23:46:48 --> Config Class Initialized
INFO - 2021-12-14 23:46:48 --> Hooks Class Initialized
DEBUG - 2021-12-14 23:46:48 --> UTF-8 Support Enabled
INFO - 2021-12-14 23:46:48 --> Utf8 Class Initialized
INFO - 2021-12-14 23:46:48 --> URI Class Initialized
INFO - 2021-12-14 23:46:48 --> Router Class Initialized
INFO - 2021-12-14 23:46:48 --> Output Class Initialized
INFO - 2021-12-14 23:46:48 --> Security Class Initialized
DEBUG - 2021-12-14 23:46:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 23:46:48 --> Input Class Initialized
INFO - 2021-12-14 23:46:48 --> Language Class Initialized
ERROR - 2021-12-14 23:46:48 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-12-14 23:57:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 23:57:00 --> Config Class Initialized
INFO - 2021-12-14 23:57:00 --> Hooks Class Initialized
DEBUG - 2021-12-14 23:57:00 --> UTF-8 Support Enabled
INFO - 2021-12-14 23:57:00 --> Utf8 Class Initialized
INFO - 2021-12-14 23:57:00 --> URI Class Initialized
INFO - 2021-12-14 23:57:00 --> Router Class Initialized
INFO - 2021-12-14 23:57:00 --> Output Class Initialized
INFO - 2021-12-14 23:57:00 --> Security Class Initialized
DEBUG - 2021-12-14 23:57:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 23:57:00 --> Input Class Initialized
INFO - 2021-12-14 23:57:00 --> Language Class Initialized
INFO - 2021-12-14 23:57:00 --> Loader Class Initialized
INFO - 2021-12-14 23:57:00 --> Helper loaded: url_helper
INFO - 2021-12-14 23:57:00 --> Helper loaded: form_helper
INFO - 2021-12-14 23:57:00 --> Helper loaded: common_helper
INFO - 2021-12-14 23:57:00 --> Database Driver Class Initialized
DEBUG - 2021-12-14 23:57:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-14 23:57:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-14 23:57:00 --> Controller Class Initialized
INFO - 2021-12-14 23:57:00 --> Form Validation Class Initialized
DEBUG - 2021-12-14 23:57:00 --> Encrypt Class Initialized
INFO - 2021-12-14 23:57:00 --> Model "Login_model" initialized
INFO - 2021-12-14 23:57:00 --> Model "Dashboard_model" initialized
INFO - 2021-12-14 23:57:00 --> Model "Case_model" initialized
ERROR - 2021-12-14 23:57:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 23:57:10 --> Config Class Initialized
INFO - 2021-12-14 23:57:10 --> Hooks Class Initialized
DEBUG - 2021-12-14 23:57:10 --> UTF-8 Support Enabled
INFO - 2021-12-14 23:57:10 --> Utf8 Class Initialized
INFO - 2021-12-14 23:57:10 --> URI Class Initialized
INFO - 2021-12-14 23:57:10 --> Router Class Initialized
INFO - 2021-12-14 23:57:10 --> Output Class Initialized
INFO - 2021-12-14 23:57:10 --> Security Class Initialized
DEBUG - 2021-12-14 23:57:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 23:57:10 --> Input Class Initialized
INFO - 2021-12-14 23:57:10 --> Language Class Initialized
INFO - 2021-12-14 23:57:10 --> Loader Class Initialized
INFO - 2021-12-14 23:57:10 --> Helper loaded: url_helper
INFO - 2021-12-14 23:57:10 --> Helper loaded: form_helper
INFO - 2021-12-14 23:57:10 --> Helper loaded: common_helper
INFO - 2021-12-14 23:57:10 --> Database Driver Class Initialized
DEBUG - 2021-12-14 23:57:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-14 23:57:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-14 23:57:10 --> Controller Class Initialized
INFO - 2021-12-14 23:57:10 --> Form Validation Class Initialized
DEBUG - 2021-12-14 23:57:10 --> Encrypt Class Initialized
INFO - 2021-12-14 23:57:10 --> Model "Patient_model" initialized
INFO - 2021-12-14 23:57:10 --> Model "Patientcase_model" initialized
INFO - 2021-12-14 23:57:10 --> Model "Referredby_model" initialized
INFO - 2021-12-14 23:57:10 --> Model "Prefix_master" initialized
INFO - 2021-12-14 23:57:10 --> Model "Hospital_model" initialized
INFO - 2021-12-14 23:57:10 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-14 23:57:13 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-14 23:57:18 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2021-12-14 23:57:18 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
ERROR - 2021-12-14 23:57:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 23:57:19 --> Config Class Initialized
INFO - 2021-12-14 23:57:19 --> Hooks Class Initialized
DEBUG - 2021-12-14 23:57:19 --> UTF-8 Support Enabled
INFO - 2021-12-14 23:57:19 --> Utf8 Class Initialized
INFO - 2021-12-14 23:57:19 --> URI Class Initialized
INFO - 2021-12-14 23:57:19 --> Router Class Initialized
INFO - 2021-12-14 23:57:19 --> Output Class Initialized
INFO - 2021-12-14 23:57:19 --> Security Class Initialized
DEBUG - 2021-12-14 23:57:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 23:57:19 --> Input Class Initialized
INFO - 2021-12-14 23:57:19 --> Language Class Initialized
ERROR - 2021-12-14 23:57:19 --> 404 Page Not Found: Karoclient/usersprofile
INFO - 2021-12-14 23:57:20 --> Final output sent to browser
DEBUG - 2021-12-14 23:57:20 --> Total execution time: 7.8315
INFO - 2021-12-14 23:57:23 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2021-12-14 23:57:23 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-14 23:57:23 --> Final output sent to browser
DEBUG - 2021-12-14 23:57:23 --> Total execution time: 23.1932
ERROR - 2021-12-14 23:57:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 23:57:45 --> Config Class Initialized
INFO - 2021-12-14 23:57:45 --> Hooks Class Initialized
DEBUG - 2021-12-14 23:57:45 --> UTF-8 Support Enabled
INFO - 2021-12-14 23:57:45 --> Utf8 Class Initialized
INFO - 2021-12-14 23:57:45 --> URI Class Initialized
INFO - 2021-12-14 23:57:45 --> Router Class Initialized
INFO - 2021-12-14 23:57:45 --> Output Class Initialized
INFO - 2021-12-14 23:57:45 --> Security Class Initialized
DEBUG - 2021-12-14 23:57:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 23:57:45 --> Input Class Initialized
INFO - 2021-12-14 23:57:45 --> Language Class Initialized
INFO - 2021-12-14 23:57:45 --> Loader Class Initialized
INFO - 2021-12-14 23:57:45 --> Helper loaded: url_helper
INFO - 2021-12-14 23:57:45 --> Helper loaded: form_helper
INFO - 2021-12-14 23:57:45 --> Helper loaded: common_helper
INFO - 2021-12-14 23:57:45 --> Database Driver Class Initialized
DEBUG - 2021-12-14 23:57:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-14 23:57:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-14 23:57:45 --> Controller Class Initialized
INFO - 2021-12-14 23:57:45 --> Form Validation Class Initialized
DEBUG - 2021-12-14 23:57:45 --> Encrypt Class Initialized
INFO - 2021-12-14 23:57:45 --> Model "Login_model" initialized
INFO - 2021-12-14 23:57:45 --> Model "Dashboard_model" initialized
INFO - 2021-12-14 23:57:45 --> Model "Case_model" initialized
INFO - 2021-12-14 23:57:53 --> File loaded: /home3/karoteam/public_html/application/views/header.php
ERROR - 2021-12-14 23:57:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 23:57:57 --> Config Class Initialized
INFO - 2021-12-14 23:57:57 --> Hooks Class Initialized
DEBUG - 2021-12-14 23:57:57 --> UTF-8 Support Enabled
INFO - 2021-12-14 23:57:57 --> Utf8 Class Initialized
INFO - 2021-12-14 23:57:57 --> URI Class Initialized
DEBUG - 2021-12-14 23:57:57 --> No URI present. Default controller set.
INFO - 2021-12-14 23:57:57 --> Router Class Initialized
INFO - 2021-12-14 23:57:57 --> Output Class Initialized
INFO - 2021-12-14 23:57:57 --> Security Class Initialized
DEBUG - 2021-12-14 23:57:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 23:57:57 --> Input Class Initialized
INFO - 2021-12-14 23:57:57 --> Language Class Initialized
INFO - 2021-12-14 23:57:57 --> Loader Class Initialized
INFO - 2021-12-14 23:57:57 --> Helper loaded: url_helper
INFO - 2021-12-14 23:57:57 --> Helper loaded: form_helper
INFO - 2021-12-14 23:57:57 --> Helper loaded: common_helper
INFO - 2021-12-14 23:57:57 --> Database Driver Class Initialized
DEBUG - 2021-12-14 23:57:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-14 23:58:02 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2021-12-14 23:58:02 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-14 23:58:02 --> Final output sent to browser
DEBUG - 2021-12-14 23:58:02 --> Total execution time: 17.0405
INFO - 2021-12-14 23:58:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-14 23:58:02 --> Controller Class Initialized
INFO - 2021-12-14 23:58:02 --> Form Validation Class Initialized
DEBUG - 2021-12-14 23:58:02 --> Encrypt Class Initialized
DEBUG - 2021-12-14 23:58:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-14 23:58:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-14 23:58:02 --> Email Class Initialized
INFO - 2021-12-14 23:58:02 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-14 23:58:02 --> Calendar Class Initialized
INFO - 2021-12-14 23:58:02 --> Model "Login_model" initialized
ERROR - 2021-12-14 23:58:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 23:58:03 --> Config Class Initialized
INFO - 2021-12-14 23:58:03 --> Hooks Class Initialized
DEBUG - 2021-12-14 23:58:03 --> UTF-8 Support Enabled
INFO - 2021-12-14 23:58:03 --> Utf8 Class Initialized
INFO - 2021-12-14 23:58:03 --> URI Class Initialized
INFO - 2021-12-14 23:58:03 --> Router Class Initialized
INFO - 2021-12-14 23:58:03 --> Output Class Initialized
INFO - 2021-12-14 23:58:03 --> Security Class Initialized
DEBUG - 2021-12-14 23:58:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 23:58:03 --> Input Class Initialized
INFO - 2021-12-14 23:58:03 --> Language Class Initialized
INFO - 2021-12-14 23:58:03 --> Loader Class Initialized
INFO - 2021-12-14 23:58:03 --> Helper loaded: url_helper
INFO - 2021-12-14 23:58:03 --> Helper loaded: form_helper
INFO - 2021-12-14 23:58:03 --> Helper loaded: common_helper
INFO - 2021-12-14 23:58:03 --> Database Driver Class Initialized
DEBUG - 2021-12-14 23:58:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-14 23:58:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-14 23:58:03 --> Controller Class Initialized
INFO - 2021-12-14 23:58:03 --> Form Validation Class Initialized
DEBUG - 2021-12-14 23:58:03 --> Encrypt Class Initialized
INFO - 2021-12-14 23:58:03 --> Model "Diseases_model" initialized
INFO - 2021-12-14 23:58:03 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-14 23:58:03 --> File loaded: /home3/karoteam/public_html/application/views/diseases/index.php
INFO - 2021-12-14 23:58:03 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-14 23:58:03 --> Final output sent to browser
DEBUG - 2021-12-14 23:58:03 --> Total execution time: 0.0274
ERROR - 2021-12-14 23:58:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-14 23:58:04 --> Config Class Initialized
INFO - 2021-12-14 23:58:04 --> Hooks Class Initialized
DEBUG - 2021-12-14 23:58:04 --> UTF-8 Support Enabled
INFO - 2021-12-14 23:58:04 --> Utf8 Class Initialized
INFO - 2021-12-14 23:58:04 --> URI Class Initialized
INFO - 2021-12-14 23:58:04 --> Router Class Initialized
INFO - 2021-12-14 23:58:04 --> Output Class Initialized
INFO - 2021-12-14 23:58:04 --> Security Class Initialized
DEBUG - 2021-12-14 23:58:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-14 23:58:04 --> Input Class Initialized
INFO - 2021-12-14 23:58:04 --> Language Class Initialized
ERROR - 2021-12-14 23:58:04 --> 404 Page Not Found: Karoclient/usersprofile
