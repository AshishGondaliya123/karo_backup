<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-01-21 02:15:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-21 02:15:37 --> Config Class Initialized
INFO - 2022-01-21 02:15:37 --> Hooks Class Initialized
DEBUG - 2022-01-21 02:15:37 --> UTF-8 Support Enabled
INFO - 2022-01-21 02:15:37 --> Utf8 Class Initialized
INFO - 2022-01-21 02:15:37 --> URI Class Initialized
DEBUG - 2022-01-21 02:15:37 --> No URI present. Default controller set.
INFO - 2022-01-21 02:15:37 --> Router Class Initialized
INFO - 2022-01-21 02:15:37 --> Output Class Initialized
INFO - 2022-01-21 02:15:37 --> Security Class Initialized
DEBUG - 2022-01-21 02:15:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-21 02:15:37 --> Input Class Initialized
INFO - 2022-01-21 02:15:37 --> Language Class Initialized
INFO - 2022-01-21 02:15:37 --> Loader Class Initialized
INFO - 2022-01-21 02:15:37 --> Helper loaded: url_helper
INFO - 2022-01-21 02:15:37 --> Helper loaded: form_helper
INFO - 2022-01-21 02:15:37 --> Helper loaded: common_helper
INFO - 2022-01-21 02:15:37 --> Database Driver Class Initialized
DEBUG - 2022-01-21 02:15:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-21 02:15:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-21 02:15:37 --> Controller Class Initialized
INFO - 2022-01-21 02:15:37 --> Form Validation Class Initialized
DEBUG - 2022-01-21 02:15:37 --> Encrypt Class Initialized
DEBUG - 2022-01-21 02:15:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-21 02:15:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-21 02:15:37 --> Email Class Initialized
INFO - 2022-01-21 02:15:37 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-21 02:15:37 --> Calendar Class Initialized
INFO - 2022-01-21 02:15:37 --> Model "Login_model" initialized
INFO - 2022-01-21 02:15:37 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-21 02:15:37 --> Final output sent to browser
DEBUG - 2022-01-21 02:15:37 --> Total execution time: 0.0225
ERROR - 2022-01-21 13:08:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-21 13:08:42 --> Config Class Initialized
INFO - 2022-01-21 13:08:42 --> Hooks Class Initialized
DEBUG - 2022-01-21 13:08:42 --> UTF-8 Support Enabled
INFO - 2022-01-21 13:08:42 --> Utf8 Class Initialized
INFO - 2022-01-21 13:08:42 --> URI Class Initialized
DEBUG - 2022-01-21 13:08:42 --> No URI present. Default controller set.
INFO - 2022-01-21 13:08:42 --> Router Class Initialized
INFO - 2022-01-21 13:08:42 --> Output Class Initialized
INFO - 2022-01-21 13:08:42 --> Security Class Initialized
DEBUG - 2022-01-21 13:08:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-21 13:08:42 --> Input Class Initialized
INFO - 2022-01-21 13:08:42 --> Language Class Initialized
INFO - 2022-01-21 13:08:42 --> Loader Class Initialized
INFO - 2022-01-21 13:08:42 --> Helper loaded: url_helper
INFO - 2022-01-21 13:08:42 --> Helper loaded: form_helper
INFO - 2022-01-21 13:08:42 --> Helper loaded: common_helper
INFO - 2022-01-21 13:08:42 --> Database Driver Class Initialized
DEBUG - 2022-01-21 13:08:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-21 13:08:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-21 13:08:42 --> Controller Class Initialized
INFO - 2022-01-21 13:08:42 --> Form Validation Class Initialized
DEBUG - 2022-01-21 13:08:42 --> Encrypt Class Initialized
DEBUG - 2022-01-21 13:08:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-21 13:08:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-21 13:08:42 --> Email Class Initialized
INFO - 2022-01-21 13:08:42 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-21 13:08:42 --> Calendar Class Initialized
INFO - 2022-01-21 13:08:42 --> Model "Login_model" initialized
INFO - 2022-01-21 13:08:42 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-21 13:08:42 --> Final output sent to browser
DEBUG - 2022-01-21 13:08:42 --> Total execution time: 0.0294
ERROR - 2022-01-21 14:02:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-21 14:02:06 --> Config Class Initialized
INFO - 2022-01-21 14:02:06 --> Hooks Class Initialized
DEBUG - 2022-01-21 14:02:06 --> UTF-8 Support Enabled
INFO - 2022-01-21 14:02:06 --> Utf8 Class Initialized
INFO - 2022-01-21 14:02:06 --> URI Class Initialized
DEBUG - 2022-01-21 14:02:06 --> No URI present. Default controller set.
INFO - 2022-01-21 14:02:06 --> Router Class Initialized
INFO - 2022-01-21 14:02:06 --> Output Class Initialized
INFO - 2022-01-21 14:02:06 --> Security Class Initialized
DEBUG - 2022-01-21 14:02:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-21 14:02:06 --> Input Class Initialized
INFO - 2022-01-21 14:02:06 --> Language Class Initialized
INFO - 2022-01-21 14:02:06 --> Loader Class Initialized
INFO - 2022-01-21 14:02:06 --> Helper loaded: url_helper
INFO - 2022-01-21 14:02:06 --> Helper loaded: form_helper
INFO - 2022-01-21 14:02:06 --> Helper loaded: common_helper
INFO - 2022-01-21 14:02:06 --> Database Driver Class Initialized
DEBUG - 2022-01-21 14:02:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-21 14:02:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-21 14:02:06 --> Controller Class Initialized
INFO - 2022-01-21 14:02:06 --> Form Validation Class Initialized
DEBUG - 2022-01-21 14:02:06 --> Encrypt Class Initialized
DEBUG - 2022-01-21 14:02:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-21 14:02:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-21 14:02:06 --> Email Class Initialized
INFO - 2022-01-21 14:02:06 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-21 14:02:06 --> Calendar Class Initialized
INFO - 2022-01-21 14:02:06 --> Model "Login_model" initialized
INFO - 2022-01-21 14:02:06 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-21 14:02:06 --> Final output sent to browser
DEBUG - 2022-01-21 14:02:06 --> Total execution time: 0.0328
ERROR - 2022-01-21 14:21:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-21 14:21:28 --> Config Class Initialized
INFO - 2022-01-21 14:21:28 --> Hooks Class Initialized
DEBUG - 2022-01-21 14:21:28 --> UTF-8 Support Enabled
INFO - 2022-01-21 14:21:28 --> Utf8 Class Initialized
INFO - 2022-01-21 14:21:28 --> URI Class Initialized
DEBUG - 2022-01-21 14:21:28 --> No URI present. Default controller set.
INFO - 2022-01-21 14:21:28 --> Router Class Initialized
INFO - 2022-01-21 14:21:28 --> Output Class Initialized
INFO - 2022-01-21 14:21:28 --> Security Class Initialized
DEBUG - 2022-01-21 14:21:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-21 14:21:28 --> Input Class Initialized
INFO - 2022-01-21 14:21:28 --> Language Class Initialized
INFO - 2022-01-21 14:21:28 --> Loader Class Initialized
INFO - 2022-01-21 14:21:28 --> Helper loaded: url_helper
INFO - 2022-01-21 14:21:28 --> Helper loaded: form_helper
INFO - 2022-01-21 14:21:28 --> Helper loaded: common_helper
INFO - 2022-01-21 14:21:28 --> Database Driver Class Initialized
DEBUG - 2022-01-21 14:21:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-21 14:21:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-21 14:21:28 --> Controller Class Initialized
INFO - 2022-01-21 14:21:28 --> Form Validation Class Initialized
DEBUG - 2022-01-21 14:21:28 --> Encrypt Class Initialized
DEBUG - 2022-01-21 14:21:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-21 14:21:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-21 14:21:28 --> Email Class Initialized
INFO - 2022-01-21 14:21:28 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-21 14:21:28 --> Calendar Class Initialized
INFO - 2022-01-21 14:21:28 --> Model "Login_model" initialized
INFO - 2022-01-21 14:21:28 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-21 14:21:28 --> Final output sent to browser
DEBUG - 2022-01-21 14:21:28 --> Total execution time: 0.0286
ERROR - 2022-01-21 14:21:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-21 14:21:29 --> Config Class Initialized
INFO - 2022-01-21 14:21:29 --> Hooks Class Initialized
DEBUG - 2022-01-21 14:21:29 --> UTF-8 Support Enabled
INFO - 2022-01-21 14:21:29 --> Utf8 Class Initialized
INFO - 2022-01-21 14:21:29 --> URI Class Initialized
INFO - 2022-01-21 14:21:29 --> Router Class Initialized
INFO - 2022-01-21 14:21:29 --> Output Class Initialized
INFO - 2022-01-21 14:21:29 --> Security Class Initialized
DEBUG - 2022-01-21 14:21:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-21 14:21:29 --> Input Class Initialized
INFO - 2022-01-21 14:21:29 --> Language Class Initialized
ERROR - 2022-01-21 14:21:29 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2022-01-21 14:21:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-21 14:21:54 --> Config Class Initialized
INFO - 2022-01-21 14:21:54 --> Hooks Class Initialized
DEBUG - 2022-01-21 14:21:54 --> UTF-8 Support Enabled
INFO - 2022-01-21 14:21:54 --> Utf8 Class Initialized
INFO - 2022-01-21 14:21:54 --> URI Class Initialized
INFO - 2022-01-21 14:21:54 --> Router Class Initialized
INFO - 2022-01-21 14:21:54 --> Output Class Initialized
INFO - 2022-01-21 14:21:54 --> Security Class Initialized
DEBUG - 2022-01-21 14:21:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-21 14:21:54 --> Input Class Initialized
INFO - 2022-01-21 14:21:54 --> Language Class Initialized
INFO - 2022-01-21 14:21:54 --> Loader Class Initialized
INFO - 2022-01-21 14:21:54 --> Helper loaded: url_helper
INFO - 2022-01-21 14:21:54 --> Helper loaded: form_helper
INFO - 2022-01-21 14:21:54 --> Helper loaded: common_helper
INFO - 2022-01-21 14:21:54 --> Database Driver Class Initialized
DEBUG - 2022-01-21 14:21:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-21 14:21:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-21 14:21:55 --> Controller Class Initialized
INFO - 2022-01-21 14:21:55 --> Form Validation Class Initialized
DEBUG - 2022-01-21 14:21:55 --> Encrypt Class Initialized
DEBUG - 2022-01-21 14:21:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-21 14:21:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-21 14:21:55 --> Email Class Initialized
INFO - 2022-01-21 14:21:55 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-21 14:21:55 --> Calendar Class Initialized
INFO - 2022-01-21 14:21:55 --> Model "Login_model" initialized
INFO - 2022-01-21 14:21:55 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-21 14:21:55 --> Final output sent to browser
DEBUG - 2022-01-21 14:21:55 --> Total execution time: 1.1026
ERROR - 2022-01-21 14:21:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-21 14:21:56 --> Config Class Initialized
INFO - 2022-01-21 14:21:56 --> Hooks Class Initialized
DEBUG - 2022-01-21 14:21:56 --> UTF-8 Support Enabled
INFO - 2022-01-21 14:21:56 --> Utf8 Class Initialized
INFO - 2022-01-21 14:21:56 --> URI Class Initialized
DEBUG - 2022-01-21 14:21:56 --> No URI present. Default controller set.
INFO - 2022-01-21 14:21:56 --> Router Class Initialized
INFO - 2022-01-21 14:21:56 --> Output Class Initialized
INFO - 2022-01-21 14:21:56 --> Security Class Initialized
DEBUG - 2022-01-21 14:21:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-21 14:21:56 --> Input Class Initialized
INFO - 2022-01-21 14:21:56 --> Language Class Initialized
INFO - 2022-01-21 14:21:56 --> Loader Class Initialized
INFO - 2022-01-21 14:21:56 --> Helper loaded: url_helper
INFO - 2022-01-21 14:21:56 --> Helper loaded: form_helper
INFO - 2022-01-21 14:21:56 --> Helper loaded: common_helper
INFO - 2022-01-21 14:21:56 --> Database Driver Class Initialized
DEBUG - 2022-01-21 14:21:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-21 14:21:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-21 14:21:59 --> Controller Class Initialized
INFO - 2022-01-21 14:21:59 --> Form Validation Class Initialized
DEBUG - 2022-01-21 14:21:59 --> Encrypt Class Initialized
DEBUG - 2022-01-21 14:21:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-21 14:21:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-21 14:21:59 --> Email Class Initialized
INFO - 2022-01-21 14:21:59 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-21 14:21:59 --> Calendar Class Initialized
INFO - 2022-01-21 14:21:59 --> Model "Login_model" initialized
INFO - 2022-01-21 14:21:59 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-21 14:21:59 --> Final output sent to browser
DEBUG - 2022-01-21 14:21:59 --> Total execution time: 2.9539
ERROR - 2022-01-21 14:21:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-21 14:21:59 --> Config Class Initialized
INFO - 2022-01-21 14:21:59 --> Hooks Class Initialized
DEBUG - 2022-01-21 14:21:59 --> UTF-8 Support Enabled
INFO - 2022-01-21 14:21:59 --> Utf8 Class Initialized
INFO - 2022-01-21 14:21:59 --> URI Class Initialized
INFO - 2022-01-21 14:21:59 --> Router Class Initialized
INFO - 2022-01-21 14:21:59 --> Output Class Initialized
INFO - 2022-01-21 14:21:59 --> Security Class Initialized
DEBUG - 2022-01-21 14:21:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-21 14:21:59 --> Input Class Initialized
INFO - 2022-01-21 14:21:59 --> Language Class Initialized
INFO - 2022-01-21 14:21:59 --> Loader Class Initialized
INFO - 2022-01-21 14:21:59 --> Helper loaded: url_helper
INFO - 2022-01-21 14:21:59 --> Helper loaded: form_helper
INFO - 2022-01-21 14:21:59 --> Helper loaded: common_helper
INFO - 2022-01-21 14:21:59 --> Database Driver Class Initialized
DEBUG - 2022-01-21 14:21:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-21 14:21:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-21 14:21:59 --> Controller Class Initialized
INFO - 2022-01-21 14:21:59 --> Form Validation Class Initialized
DEBUG - 2022-01-21 14:21:59 --> Encrypt Class Initialized
DEBUG - 2022-01-21 14:21:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-21 14:21:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-21 14:21:59 --> Email Class Initialized
INFO - 2022-01-21 14:21:59 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-21 14:21:59 --> Calendar Class Initialized
INFO - 2022-01-21 14:21:59 --> Model "Login_model" initialized
ERROR - 2022-01-21 14:22:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-21 14:22:00 --> Config Class Initialized
INFO - 2022-01-21 14:22:00 --> Hooks Class Initialized
DEBUG - 2022-01-21 14:22:00 --> UTF-8 Support Enabled
INFO - 2022-01-21 14:22:00 --> Utf8 Class Initialized
INFO - 2022-01-21 14:22:00 --> URI Class Initialized
INFO - 2022-01-21 14:22:00 --> Router Class Initialized
INFO - 2022-01-21 14:22:00 --> Output Class Initialized
INFO - 2022-01-21 14:22:00 --> Security Class Initialized
DEBUG - 2022-01-21 14:22:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-21 14:22:00 --> Input Class Initialized
INFO - 2022-01-21 14:22:00 --> Language Class Initialized
INFO - 2022-01-21 14:22:00 --> Loader Class Initialized
INFO - 2022-01-21 14:22:00 --> Helper loaded: url_helper
INFO - 2022-01-21 14:22:00 --> Helper loaded: form_helper
INFO - 2022-01-21 14:22:00 --> Helper loaded: common_helper
INFO - 2022-01-21 14:22:00 --> Database Driver Class Initialized
DEBUG - 2022-01-21 14:22:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-21 14:22:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-21 14:22:09 --> Controller Class Initialized
INFO - 2022-01-21 14:22:09 --> Form Validation Class Initialized
DEBUG - 2022-01-21 14:22:09 --> Encrypt Class Initialized
DEBUG - 2022-01-21 14:22:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-21 14:22:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-21 14:22:09 --> Email Class Initialized
INFO - 2022-01-21 14:22:09 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-21 14:22:09 --> Calendar Class Initialized
INFO - 2022-01-21 14:22:09 --> Model "Login_model" initialized
ERROR - 2022-01-21 14:55:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-21 14:55:53 --> Config Class Initialized
INFO - 2022-01-21 14:55:53 --> Hooks Class Initialized
DEBUG - 2022-01-21 14:55:53 --> UTF-8 Support Enabled
INFO - 2022-01-21 14:55:53 --> Utf8 Class Initialized
INFO - 2022-01-21 14:55:53 --> URI Class Initialized
DEBUG - 2022-01-21 14:55:53 --> No URI present. Default controller set.
INFO - 2022-01-21 14:55:53 --> Router Class Initialized
INFO - 2022-01-21 14:55:53 --> Output Class Initialized
INFO - 2022-01-21 14:55:53 --> Security Class Initialized
DEBUG - 2022-01-21 14:55:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-21 14:55:53 --> Input Class Initialized
INFO - 2022-01-21 14:55:53 --> Language Class Initialized
INFO - 2022-01-21 14:55:53 --> Loader Class Initialized
INFO - 2022-01-21 14:55:53 --> Helper loaded: url_helper
INFO - 2022-01-21 14:55:53 --> Helper loaded: form_helper
INFO - 2022-01-21 14:55:53 --> Helper loaded: common_helper
INFO - 2022-01-21 14:55:53 --> Database Driver Class Initialized
DEBUG - 2022-01-21 14:55:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-21 14:55:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-21 14:55:53 --> Controller Class Initialized
INFO - 2022-01-21 14:55:53 --> Form Validation Class Initialized
DEBUG - 2022-01-21 14:55:53 --> Encrypt Class Initialized
DEBUG - 2022-01-21 14:55:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-21 14:55:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-21 14:55:53 --> Email Class Initialized
INFO - 2022-01-21 14:55:53 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-21 14:55:53 --> Calendar Class Initialized
INFO - 2022-01-21 14:55:53 --> Model "Login_model" initialized
INFO - 2022-01-21 14:55:53 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-21 14:55:53 --> Final output sent to browser
DEBUG - 2022-01-21 14:55:53 --> Total execution time: 0.0336
ERROR - 2022-01-21 18:21:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-21 18:21:15 --> Config Class Initialized
INFO - 2022-01-21 18:21:15 --> Hooks Class Initialized
DEBUG - 2022-01-21 18:21:15 --> UTF-8 Support Enabled
INFO - 2022-01-21 18:21:15 --> Utf8 Class Initialized
INFO - 2022-01-21 18:21:15 --> URI Class Initialized
DEBUG - 2022-01-21 18:21:15 --> No URI present. Default controller set.
INFO - 2022-01-21 18:21:15 --> Router Class Initialized
INFO - 2022-01-21 18:21:15 --> Output Class Initialized
INFO - 2022-01-21 18:21:15 --> Security Class Initialized
DEBUG - 2022-01-21 18:21:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-21 18:21:15 --> Input Class Initialized
INFO - 2022-01-21 18:21:15 --> Language Class Initialized
INFO - 2022-01-21 18:21:15 --> Loader Class Initialized
INFO - 2022-01-21 18:21:15 --> Helper loaded: url_helper
INFO - 2022-01-21 18:21:15 --> Helper loaded: form_helper
INFO - 2022-01-21 18:21:15 --> Helper loaded: common_helper
INFO - 2022-01-21 18:21:15 --> Database Driver Class Initialized
DEBUG - 2022-01-21 18:21:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-21 18:21:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-21 18:21:15 --> Controller Class Initialized
INFO - 2022-01-21 18:21:15 --> Form Validation Class Initialized
DEBUG - 2022-01-21 18:21:15 --> Encrypt Class Initialized
DEBUG - 2022-01-21 18:21:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-21 18:21:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-21 18:21:15 --> Email Class Initialized
INFO - 2022-01-21 18:21:15 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-21 18:21:15 --> Calendar Class Initialized
INFO - 2022-01-21 18:21:15 --> Model "Login_model" initialized
INFO - 2022-01-21 18:21:15 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-21 18:21:15 --> Final output sent to browser
DEBUG - 2022-01-21 18:21:15 --> Total execution time: 0.0259
ERROR - 2022-01-21 20:19:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-21 20:19:53 --> Config Class Initialized
INFO - 2022-01-21 20:19:53 --> Hooks Class Initialized
DEBUG - 2022-01-21 20:19:53 --> UTF-8 Support Enabled
INFO - 2022-01-21 20:19:53 --> Utf8 Class Initialized
INFO - 2022-01-21 20:19:53 --> URI Class Initialized
INFO - 2022-01-21 20:19:53 --> Router Class Initialized
INFO - 2022-01-21 20:19:53 --> Output Class Initialized
INFO - 2022-01-21 20:19:53 --> Security Class Initialized
DEBUG - 2022-01-21 20:19:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-21 20:19:53 --> Input Class Initialized
INFO - 2022-01-21 20:19:53 --> Language Class Initialized
ERROR - 2022-01-21 20:19:53 --> 404 Page Not Found: Git/config
