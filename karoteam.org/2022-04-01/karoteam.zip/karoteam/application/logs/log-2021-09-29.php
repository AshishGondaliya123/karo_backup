<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-09-29 00:03:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-29 00:03:59 --> Config Class Initialized
INFO - 2021-09-29 00:03:59 --> Hooks Class Initialized
DEBUG - 2021-09-29 00:03:59 --> UTF-8 Support Enabled
INFO - 2021-09-29 00:03:59 --> Utf8 Class Initialized
INFO - 2021-09-29 00:03:59 --> URI Class Initialized
DEBUG - 2021-09-29 00:03:59 --> No URI present. Default controller set.
INFO - 2021-09-29 00:03:59 --> Router Class Initialized
INFO - 2021-09-29 00:03:59 --> Output Class Initialized
INFO - 2021-09-29 00:03:59 --> Security Class Initialized
DEBUG - 2021-09-29 00:03:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-29 00:03:59 --> Input Class Initialized
INFO - 2021-09-29 00:03:59 --> Language Class Initialized
INFO - 2021-09-29 00:03:59 --> Loader Class Initialized
INFO - 2021-09-29 00:03:59 --> Helper loaded: url_helper
INFO - 2021-09-29 00:03:59 --> Helper loaded: form_helper
INFO - 2021-09-29 00:03:59 --> Helper loaded: common_helper
INFO - 2021-09-29 00:03:59 --> Database Driver Class Initialized
DEBUG - 2021-09-29 00:03:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-29 00:03:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-29 00:03:59 --> Controller Class Initialized
INFO - 2021-09-29 00:03:59 --> Form Validation Class Initialized
DEBUG - 2021-09-29 00:03:59 --> Encrypt Class Initialized
DEBUG - 2021-09-29 00:03:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-09-29 00:03:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-09-29 00:03:59 --> Email Class Initialized
INFO - 2021-09-29 00:03:59 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-09-29 00:03:59 --> Calendar Class Initialized
INFO - 2021-09-29 00:03:59 --> Model "Login_model" initialized
INFO - 2021-09-29 00:03:59 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-09-29 00:03:59 --> Final output sent to browser
DEBUG - 2021-09-29 00:03:59 --> Total execution time: 0.1866
ERROR - 2021-09-29 16:57:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-29 16:57:38 --> Config Class Initialized
INFO - 2021-09-29 16:57:38 --> Hooks Class Initialized
DEBUG - 2021-09-29 16:57:38 --> UTF-8 Support Enabled
INFO - 2021-09-29 16:57:38 --> Utf8 Class Initialized
INFO - 2021-09-29 16:57:38 --> URI Class Initialized
DEBUG - 2021-09-29 16:57:38 --> No URI present. Default controller set.
INFO - 2021-09-29 16:57:38 --> Router Class Initialized
INFO - 2021-09-29 16:57:38 --> Output Class Initialized
INFO - 2021-09-29 16:57:38 --> Security Class Initialized
DEBUG - 2021-09-29 16:57:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-29 16:57:38 --> Input Class Initialized
INFO - 2021-09-29 16:57:38 --> Language Class Initialized
INFO - 2021-09-29 16:57:38 --> Loader Class Initialized
INFO - 2021-09-29 16:57:38 --> Helper loaded: url_helper
INFO - 2021-09-29 16:57:38 --> Helper loaded: form_helper
INFO - 2021-09-29 16:57:38 --> Helper loaded: common_helper
INFO - 2021-09-29 16:57:38 --> Database Driver Class Initialized
DEBUG - 2021-09-29 16:57:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-29 16:57:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-29 16:57:38 --> Controller Class Initialized
INFO - 2021-09-29 16:57:38 --> Form Validation Class Initialized
DEBUG - 2021-09-29 16:57:38 --> Encrypt Class Initialized
DEBUG - 2021-09-29 16:57:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-09-29 16:57:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-09-29 16:57:38 --> Email Class Initialized
INFO - 2021-09-29 16:57:38 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-09-29 16:57:38 --> Calendar Class Initialized
INFO - 2021-09-29 16:57:38 --> Model "Login_model" initialized
INFO - 2021-09-29 16:57:38 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-09-29 16:57:38 --> Final output sent to browser
DEBUG - 2021-09-29 16:57:38 --> Total execution time: 0.0436
ERROR - 2021-09-29 16:57:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-29 16:57:39 --> Config Class Initialized
INFO - 2021-09-29 16:57:39 --> Hooks Class Initialized
DEBUG - 2021-09-29 16:57:39 --> UTF-8 Support Enabled
INFO - 2021-09-29 16:57:39 --> Utf8 Class Initialized
INFO - 2021-09-29 16:57:39 --> URI Class Initialized
DEBUG - 2021-09-29 16:57:39 --> No URI present. Default controller set.
INFO - 2021-09-29 16:57:39 --> Router Class Initialized
INFO - 2021-09-29 16:57:39 --> Output Class Initialized
INFO - 2021-09-29 16:57:39 --> Security Class Initialized
DEBUG - 2021-09-29 16:57:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-29 16:57:39 --> Input Class Initialized
INFO - 2021-09-29 16:57:39 --> Language Class Initialized
INFO - 2021-09-29 16:57:39 --> Loader Class Initialized
INFO - 2021-09-29 16:57:39 --> Helper loaded: url_helper
INFO - 2021-09-29 16:57:39 --> Helper loaded: form_helper
INFO - 2021-09-29 16:57:39 --> Helper loaded: common_helper
INFO - 2021-09-29 16:57:39 --> Database Driver Class Initialized
DEBUG - 2021-09-29 16:57:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-29 16:57:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-29 16:57:39 --> Controller Class Initialized
INFO - 2021-09-29 16:57:39 --> Form Validation Class Initialized
DEBUG - 2021-09-29 16:57:39 --> Encrypt Class Initialized
DEBUG - 2021-09-29 16:57:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-09-29 16:57:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-09-29 16:57:39 --> Email Class Initialized
INFO - 2021-09-29 16:57:39 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-09-29 16:57:39 --> Calendar Class Initialized
INFO - 2021-09-29 16:57:39 --> Model "Login_model" initialized
INFO - 2021-09-29 16:57:39 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-09-29 16:57:39 --> Final output sent to browser
DEBUG - 2021-09-29 16:57:39 --> Total execution time: 0.0205
ERROR - 2021-09-29 16:57:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-29 16:57:40 --> Config Class Initialized
INFO - 2021-09-29 16:57:40 --> Hooks Class Initialized
DEBUG - 2021-09-29 16:57:40 --> UTF-8 Support Enabled
INFO - 2021-09-29 16:57:40 --> Utf8 Class Initialized
INFO - 2021-09-29 16:57:40 --> URI Class Initialized
INFO - 2021-09-29 16:57:40 --> Router Class Initialized
INFO - 2021-09-29 16:57:40 --> Output Class Initialized
INFO - 2021-09-29 16:57:40 --> Security Class Initialized
DEBUG - 2021-09-29 16:57:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-29 16:57:40 --> Input Class Initialized
INFO - 2021-09-29 16:57:40 --> Language Class Initialized
ERROR - 2021-09-29 16:57:40 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
ERROR - 2021-09-29 16:57:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-29 16:57:41 --> Config Class Initialized
INFO - 2021-09-29 16:57:41 --> Hooks Class Initialized
DEBUG - 2021-09-29 16:57:41 --> UTF-8 Support Enabled
INFO - 2021-09-29 16:57:41 --> Utf8 Class Initialized
INFO - 2021-09-29 16:57:41 --> URI Class Initialized
DEBUG - 2021-09-29 16:57:41 --> No URI present. Default controller set.
INFO - 2021-09-29 16:57:41 --> Router Class Initialized
INFO - 2021-09-29 16:57:41 --> Output Class Initialized
INFO - 2021-09-29 16:57:41 --> Security Class Initialized
DEBUG - 2021-09-29 16:57:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-29 16:57:41 --> Input Class Initialized
INFO - 2021-09-29 16:57:41 --> Language Class Initialized
INFO - 2021-09-29 16:57:41 --> Loader Class Initialized
INFO - 2021-09-29 16:57:41 --> Helper loaded: url_helper
INFO - 2021-09-29 16:57:41 --> Helper loaded: form_helper
INFO - 2021-09-29 16:57:41 --> Helper loaded: common_helper
INFO - 2021-09-29 16:57:41 --> Database Driver Class Initialized
DEBUG - 2021-09-29 16:57:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-29 16:57:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-29 16:57:41 --> Controller Class Initialized
INFO - 2021-09-29 16:57:41 --> Form Validation Class Initialized
DEBUG - 2021-09-29 16:57:41 --> Encrypt Class Initialized
DEBUG - 2021-09-29 16:57:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-09-29 16:57:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-09-29 16:57:41 --> Email Class Initialized
INFO - 2021-09-29 16:57:41 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-09-29 16:57:41 --> Calendar Class Initialized
INFO - 2021-09-29 16:57:41 --> Model "Login_model" initialized
INFO - 2021-09-29 16:57:41 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-09-29 16:57:41 --> Final output sent to browser
DEBUG - 2021-09-29 16:57:41 --> Total execution time: 0.0346
ERROR - 2021-09-29 16:57:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-29 16:57:41 --> Config Class Initialized
INFO - 2021-09-29 16:57:41 --> Hooks Class Initialized
DEBUG - 2021-09-29 16:57:41 --> UTF-8 Support Enabled
INFO - 2021-09-29 16:57:41 --> Utf8 Class Initialized
INFO - 2021-09-29 16:57:41 --> URI Class Initialized
INFO - 2021-09-29 16:57:41 --> Router Class Initialized
INFO - 2021-09-29 16:57:41 --> Output Class Initialized
INFO - 2021-09-29 16:57:41 --> Security Class Initialized
DEBUG - 2021-09-29 16:57:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-29 16:57:41 --> Input Class Initialized
INFO - 2021-09-29 16:57:41 --> Language Class Initialized
ERROR - 2021-09-29 16:57:41 --> 404 Page Not Found: Blog/wp-includes
ERROR - 2021-09-29 16:57:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-29 16:57:42 --> Config Class Initialized
INFO - 2021-09-29 16:57:42 --> Hooks Class Initialized
DEBUG - 2021-09-29 16:57:42 --> UTF-8 Support Enabled
INFO - 2021-09-29 16:57:42 --> Utf8 Class Initialized
INFO - 2021-09-29 16:57:42 --> URI Class Initialized
INFO - 2021-09-29 16:57:42 --> Router Class Initialized
INFO - 2021-09-29 16:57:42 --> Output Class Initialized
INFO - 2021-09-29 16:57:42 --> Security Class Initialized
DEBUG - 2021-09-29 16:57:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-29 16:57:42 --> Input Class Initialized
INFO - 2021-09-29 16:57:42 --> Language Class Initialized
ERROR - 2021-09-29 16:57:42 --> 404 Page Not Found: Web/wp-includes
ERROR - 2021-09-29 16:57:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-29 16:57:42 --> Config Class Initialized
INFO - 2021-09-29 16:57:42 --> Hooks Class Initialized
DEBUG - 2021-09-29 16:57:42 --> UTF-8 Support Enabled
INFO - 2021-09-29 16:57:42 --> Utf8 Class Initialized
INFO - 2021-09-29 16:57:42 --> URI Class Initialized
INFO - 2021-09-29 16:57:42 --> Router Class Initialized
INFO - 2021-09-29 16:57:42 --> Output Class Initialized
INFO - 2021-09-29 16:57:42 --> Security Class Initialized
DEBUG - 2021-09-29 16:57:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-29 16:57:42 --> Input Class Initialized
INFO - 2021-09-29 16:57:42 --> Language Class Initialized
ERROR - 2021-09-29 16:57:42 --> 404 Page Not Found: Wordpress/wp-includes
ERROR - 2021-09-29 16:57:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-29 16:57:43 --> Config Class Initialized
INFO - 2021-09-29 16:57:43 --> Hooks Class Initialized
DEBUG - 2021-09-29 16:57:43 --> UTF-8 Support Enabled
INFO - 2021-09-29 16:57:43 --> Utf8 Class Initialized
INFO - 2021-09-29 16:57:43 --> URI Class Initialized
INFO - 2021-09-29 16:57:43 --> Router Class Initialized
INFO - 2021-09-29 16:57:43 --> Output Class Initialized
INFO - 2021-09-29 16:57:43 --> Security Class Initialized
DEBUG - 2021-09-29 16:57:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-29 16:57:43 --> Input Class Initialized
INFO - 2021-09-29 16:57:43 --> Language Class Initialized
ERROR - 2021-09-29 16:57:43 --> 404 Page Not Found: Website/wp-includes
ERROR - 2021-09-29 16:57:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-29 16:57:43 --> Config Class Initialized
INFO - 2021-09-29 16:57:43 --> Hooks Class Initialized
DEBUG - 2021-09-29 16:57:43 --> UTF-8 Support Enabled
INFO - 2021-09-29 16:57:43 --> Utf8 Class Initialized
INFO - 2021-09-29 16:57:43 --> URI Class Initialized
INFO - 2021-09-29 16:57:43 --> Router Class Initialized
INFO - 2021-09-29 16:57:43 --> Output Class Initialized
INFO - 2021-09-29 16:57:43 --> Security Class Initialized
DEBUG - 2021-09-29 16:57:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-29 16:57:43 --> Input Class Initialized
INFO - 2021-09-29 16:57:43 --> Language Class Initialized
ERROR - 2021-09-29 16:57:43 --> 404 Page Not Found: Wp/wp-includes
ERROR - 2021-09-29 16:57:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-29 16:57:44 --> Config Class Initialized
INFO - 2021-09-29 16:57:44 --> Hooks Class Initialized
DEBUG - 2021-09-29 16:57:44 --> UTF-8 Support Enabled
INFO - 2021-09-29 16:57:44 --> Utf8 Class Initialized
INFO - 2021-09-29 16:57:44 --> URI Class Initialized
INFO - 2021-09-29 16:57:44 --> Router Class Initialized
INFO - 2021-09-29 16:57:44 --> Output Class Initialized
INFO - 2021-09-29 16:57:44 --> Security Class Initialized
DEBUG - 2021-09-29 16:57:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-29 16:57:44 --> Input Class Initialized
INFO - 2021-09-29 16:57:44 --> Language Class Initialized
ERROR - 2021-09-29 16:57:44 --> 404 Page Not Found: News/wp-includes
ERROR - 2021-09-29 16:57:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-29 16:57:44 --> Config Class Initialized
INFO - 2021-09-29 16:57:44 --> Hooks Class Initialized
DEBUG - 2021-09-29 16:57:44 --> UTF-8 Support Enabled
INFO - 2021-09-29 16:57:44 --> Utf8 Class Initialized
INFO - 2021-09-29 16:57:44 --> URI Class Initialized
INFO - 2021-09-29 16:57:44 --> Router Class Initialized
INFO - 2021-09-29 16:57:44 --> Output Class Initialized
INFO - 2021-09-29 16:57:44 --> Security Class Initialized
DEBUG - 2021-09-29 16:57:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-29 16:57:44 --> Input Class Initialized
INFO - 2021-09-29 16:57:44 --> Language Class Initialized
ERROR - 2021-09-29 16:57:44 --> 404 Page Not Found: 2018/wp-includes
ERROR - 2021-09-29 16:57:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-29 16:57:45 --> Config Class Initialized
INFO - 2021-09-29 16:57:45 --> Hooks Class Initialized
DEBUG - 2021-09-29 16:57:45 --> UTF-8 Support Enabled
INFO - 2021-09-29 16:57:45 --> Utf8 Class Initialized
INFO - 2021-09-29 16:57:45 --> URI Class Initialized
INFO - 2021-09-29 16:57:45 --> Router Class Initialized
INFO - 2021-09-29 16:57:45 --> Output Class Initialized
INFO - 2021-09-29 16:57:45 --> Security Class Initialized
DEBUG - 2021-09-29 16:57:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-29 16:57:45 --> Input Class Initialized
INFO - 2021-09-29 16:57:45 --> Language Class Initialized
ERROR - 2021-09-29 16:57:45 --> 404 Page Not Found: 2019/wp-includes
ERROR - 2021-09-29 16:57:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-29 16:57:46 --> Config Class Initialized
INFO - 2021-09-29 16:57:46 --> Hooks Class Initialized
DEBUG - 2021-09-29 16:57:46 --> UTF-8 Support Enabled
INFO - 2021-09-29 16:57:46 --> Utf8 Class Initialized
INFO - 2021-09-29 16:57:46 --> URI Class Initialized
INFO - 2021-09-29 16:57:46 --> Router Class Initialized
INFO - 2021-09-29 16:57:46 --> Output Class Initialized
INFO - 2021-09-29 16:57:46 --> Security Class Initialized
DEBUG - 2021-09-29 16:57:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-29 16:57:46 --> Input Class Initialized
INFO - 2021-09-29 16:57:46 --> Language Class Initialized
ERROR - 2021-09-29 16:57:46 --> 404 Page Not Found: Shop/wp-includes
ERROR - 2021-09-29 16:57:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-29 16:57:47 --> Config Class Initialized
INFO - 2021-09-29 16:57:47 --> Hooks Class Initialized
DEBUG - 2021-09-29 16:57:47 --> UTF-8 Support Enabled
INFO - 2021-09-29 16:57:47 --> Utf8 Class Initialized
INFO - 2021-09-29 16:57:47 --> URI Class Initialized
INFO - 2021-09-29 16:57:47 --> Router Class Initialized
INFO - 2021-09-29 16:57:47 --> Output Class Initialized
INFO - 2021-09-29 16:57:47 --> Security Class Initialized
DEBUG - 2021-09-29 16:57:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-29 16:57:47 --> Input Class Initialized
INFO - 2021-09-29 16:57:47 --> Language Class Initialized
ERROR - 2021-09-29 16:57:47 --> 404 Page Not Found: Wp1/wp-includes
ERROR - 2021-09-29 16:57:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-29 16:57:47 --> Config Class Initialized
INFO - 2021-09-29 16:57:47 --> Hooks Class Initialized
DEBUG - 2021-09-29 16:57:47 --> UTF-8 Support Enabled
INFO - 2021-09-29 16:57:47 --> Utf8 Class Initialized
INFO - 2021-09-29 16:57:47 --> URI Class Initialized
INFO - 2021-09-29 16:57:47 --> Router Class Initialized
INFO - 2021-09-29 16:57:47 --> Output Class Initialized
INFO - 2021-09-29 16:57:47 --> Security Class Initialized
DEBUG - 2021-09-29 16:57:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-29 16:57:47 --> Input Class Initialized
INFO - 2021-09-29 16:57:47 --> Language Class Initialized
ERROR - 2021-09-29 16:57:47 --> 404 Page Not Found: Test/wp-includes
ERROR - 2021-09-29 16:57:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-29 16:57:48 --> Config Class Initialized
INFO - 2021-09-29 16:57:48 --> Hooks Class Initialized
DEBUG - 2021-09-29 16:57:48 --> UTF-8 Support Enabled
INFO - 2021-09-29 16:57:48 --> Utf8 Class Initialized
INFO - 2021-09-29 16:57:48 --> URI Class Initialized
INFO - 2021-09-29 16:57:48 --> Router Class Initialized
INFO - 2021-09-29 16:57:48 --> Output Class Initialized
INFO - 2021-09-29 16:57:48 --> Security Class Initialized
DEBUG - 2021-09-29 16:57:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-29 16:57:48 --> Input Class Initialized
INFO - 2021-09-29 16:57:48 --> Language Class Initialized
ERROR - 2021-09-29 16:57:48 --> 404 Page Not Found: Media/wp-includes
ERROR - 2021-09-29 16:57:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-29 16:57:48 --> Config Class Initialized
INFO - 2021-09-29 16:57:48 --> Hooks Class Initialized
DEBUG - 2021-09-29 16:57:48 --> UTF-8 Support Enabled
INFO - 2021-09-29 16:57:48 --> Utf8 Class Initialized
INFO - 2021-09-29 16:57:48 --> URI Class Initialized
INFO - 2021-09-29 16:57:48 --> Router Class Initialized
INFO - 2021-09-29 16:57:48 --> Output Class Initialized
INFO - 2021-09-29 16:57:48 --> Security Class Initialized
DEBUG - 2021-09-29 16:57:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-29 16:57:48 --> Input Class Initialized
INFO - 2021-09-29 16:57:48 --> Language Class Initialized
ERROR - 2021-09-29 16:57:48 --> 404 Page Not Found: Wp2/wp-includes
ERROR - 2021-09-29 16:57:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-29 16:57:49 --> Config Class Initialized
INFO - 2021-09-29 16:57:49 --> Hooks Class Initialized
DEBUG - 2021-09-29 16:57:49 --> UTF-8 Support Enabled
INFO - 2021-09-29 16:57:49 --> Utf8 Class Initialized
INFO - 2021-09-29 16:57:49 --> URI Class Initialized
INFO - 2021-09-29 16:57:49 --> Router Class Initialized
INFO - 2021-09-29 16:57:49 --> Output Class Initialized
INFO - 2021-09-29 16:57:49 --> Security Class Initialized
DEBUG - 2021-09-29 16:57:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-29 16:57:49 --> Input Class Initialized
INFO - 2021-09-29 16:57:49 --> Language Class Initialized
ERROR - 2021-09-29 16:57:49 --> 404 Page Not Found: Site/wp-includes
ERROR - 2021-09-29 16:57:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-29 16:57:49 --> Config Class Initialized
INFO - 2021-09-29 16:57:49 --> Hooks Class Initialized
DEBUG - 2021-09-29 16:57:49 --> UTF-8 Support Enabled
INFO - 2021-09-29 16:57:49 --> Utf8 Class Initialized
INFO - 2021-09-29 16:57:49 --> URI Class Initialized
INFO - 2021-09-29 16:57:49 --> Router Class Initialized
INFO - 2021-09-29 16:57:49 --> Output Class Initialized
INFO - 2021-09-29 16:57:49 --> Security Class Initialized
DEBUG - 2021-09-29 16:57:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-29 16:57:49 --> Input Class Initialized
INFO - 2021-09-29 16:57:49 --> Language Class Initialized
ERROR - 2021-09-29 16:57:49 --> 404 Page Not Found: Cms/wp-includes
ERROR - 2021-09-29 16:57:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-29 16:57:50 --> Config Class Initialized
INFO - 2021-09-29 16:57:50 --> Hooks Class Initialized
DEBUG - 2021-09-29 16:57:50 --> UTF-8 Support Enabled
INFO - 2021-09-29 16:57:50 --> Utf8 Class Initialized
INFO - 2021-09-29 16:57:50 --> URI Class Initialized
INFO - 2021-09-29 16:57:50 --> Router Class Initialized
INFO - 2021-09-29 16:57:50 --> Output Class Initialized
INFO - 2021-09-29 16:57:50 --> Security Class Initialized
DEBUG - 2021-09-29 16:57:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-29 16:57:50 --> Input Class Initialized
INFO - 2021-09-29 16:57:50 --> Language Class Initialized
ERROR - 2021-09-29 16:57:50 --> 404 Page Not Found: Sito/wp-includes
ERROR - 2021-09-29 22:21:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-29 22:21:50 --> Config Class Initialized
INFO - 2021-09-29 22:21:50 --> Hooks Class Initialized
DEBUG - 2021-09-29 22:21:50 --> UTF-8 Support Enabled
INFO - 2021-09-29 22:21:50 --> Utf8 Class Initialized
INFO - 2021-09-29 22:21:50 --> URI Class Initialized
INFO - 2021-09-29 22:21:50 --> Router Class Initialized
INFO - 2021-09-29 22:21:50 --> Output Class Initialized
INFO - 2021-09-29 22:21:50 --> Security Class Initialized
DEBUG - 2021-09-29 22:21:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-29 22:21:50 --> Input Class Initialized
INFO - 2021-09-29 22:21:50 --> Language Class Initialized
ERROR - 2021-09-29 22:21:50 --> 404 Page Not Found: Wp-admin/css
