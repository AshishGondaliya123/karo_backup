<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-11-30 00:27:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-30 00:27:18 --> Config Class Initialized
INFO - 2021-11-30 00:27:18 --> Hooks Class Initialized
DEBUG - 2021-11-30 00:27:18 --> UTF-8 Support Enabled
INFO - 2021-11-30 00:27:18 --> Utf8 Class Initialized
INFO - 2021-11-30 00:27:18 --> URI Class Initialized
DEBUG - 2021-11-30 00:27:18 --> No URI present. Default controller set.
INFO - 2021-11-30 00:27:18 --> Router Class Initialized
INFO - 2021-11-30 00:27:18 --> Output Class Initialized
INFO - 2021-11-30 00:27:18 --> Security Class Initialized
DEBUG - 2021-11-30 00:27:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-30 00:27:18 --> Input Class Initialized
INFO - 2021-11-30 00:27:18 --> Language Class Initialized
INFO - 2021-11-30 00:27:18 --> Loader Class Initialized
INFO - 2021-11-30 00:27:18 --> Helper loaded: url_helper
INFO - 2021-11-30 00:27:18 --> Helper loaded: form_helper
INFO - 2021-11-30 00:27:18 --> Helper loaded: common_helper
INFO - 2021-11-30 00:27:18 --> Database Driver Class Initialized
DEBUG - 2021-11-30 00:27:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-30 00:27:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-30 00:27:18 --> Controller Class Initialized
INFO - 2021-11-30 00:27:18 --> Form Validation Class Initialized
DEBUG - 2021-11-30 00:27:18 --> Encrypt Class Initialized
DEBUG - 2021-11-30 00:27:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-30 00:27:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-30 00:27:18 --> Email Class Initialized
INFO - 2021-11-30 00:27:18 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-30 00:27:18 --> Calendar Class Initialized
INFO - 2021-11-30 00:27:18 --> Model "Login_model" initialized
INFO - 2021-11-30 00:27:18 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-11-30 00:27:18 --> Final output sent to browser
DEBUG - 2021-11-30 00:27:18 --> Total execution time: 0.0228
ERROR - 2021-11-30 00:28:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-30 00:28:26 --> Config Class Initialized
INFO - 2021-11-30 00:28:26 --> Hooks Class Initialized
DEBUG - 2021-11-30 00:28:26 --> UTF-8 Support Enabled
INFO - 2021-11-30 00:28:26 --> Utf8 Class Initialized
INFO - 2021-11-30 00:28:26 --> URI Class Initialized
DEBUG - 2021-11-30 00:28:26 --> No URI present. Default controller set.
INFO - 2021-11-30 00:28:26 --> Router Class Initialized
INFO - 2021-11-30 00:28:26 --> Output Class Initialized
INFO - 2021-11-30 00:28:26 --> Security Class Initialized
DEBUG - 2021-11-30 00:28:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-30 00:28:26 --> Input Class Initialized
INFO - 2021-11-30 00:28:26 --> Language Class Initialized
INFO - 2021-11-30 00:28:26 --> Loader Class Initialized
INFO - 2021-11-30 00:28:26 --> Helper loaded: url_helper
INFO - 2021-11-30 00:28:26 --> Helper loaded: form_helper
INFO - 2021-11-30 00:28:26 --> Helper loaded: common_helper
INFO - 2021-11-30 00:28:26 --> Database Driver Class Initialized
DEBUG - 2021-11-30 00:28:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-30 00:28:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-30 00:28:26 --> Controller Class Initialized
INFO - 2021-11-30 00:28:26 --> Form Validation Class Initialized
DEBUG - 2021-11-30 00:28:26 --> Encrypt Class Initialized
DEBUG - 2021-11-30 00:28:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-30 00:28:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-30 00:28:26 --> Email Class Initialized
INFO - 2021-11-30 00:28:26 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-30 00:28:26 --> Calendar Class Initialized
INFO - 2021-11-30 00:28:26 --> Model "Login_model" initialized
INFO - 2021-11-30 00:28:26 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-11-30 00:28:26 --> Final output sent to browser
DEBUG - 2021-11-30 00:28:26 --> Total execution time: 0.0330
ERROR - 2021-11-30 03:00:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-30 03:00:20 --> Config Class Initialized
INFO - 2021-11-30 03:00:20 --> Hooks Class Initialized
DEBUG - 2021-11-30 03:00:20 --> UTF-8 Support Enabled
INFO - 2021-11-30 03:00:20 --> Utf8 Class Initialized
INFO - 2021-11-30 03:00:20 --> URI Class Initialized
DEBUG - 2021-11-30 03:00:20 --> No URI present. Default controller set.
INFO - 2021-11-30 03:00:20 --> Router Class Initialized
INFO - 2021-11-30 03:00:20 --> Output Class Initialized
INFO - 2021-11-30 03:00:20 --> Security Class Initialized
DEBUG - 2021-11-30 03:00:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-30 03:00:20 --> Input Class Initialized
INFO - 2021-11-30 03:00:20 --> Language Class Initialized
INFO - 2021-11-30 03:00:20 --> Loader Class Initialized
INFO - 2021-11-30 03:00:20 --> Helper loaded: url_helper
INFO - 2021-11-30 03:00:20 --> Helper loaded: form_helper
INFO - 2021-11-30 03:00:20 --> Helper loaded: common_helper
INFO - 2021-11-30 03:00:20 --> Database Driver Class Initialized
DEBUG - 2021-11-30 03:00:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-30 03:00:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-30 03:00:20 --> Controller Class Initialized
INFO - 2021-11-30 03:00:20 --> Form Validation Class Initialized
DEBUG - 2021-11-30 03:00:20 --> Encrypt Class Initialized
DEBUG - 2021-11-30 03:00:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-30 03:00:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-30 03:00:20 --> Email Class Initialized
INFO - 2021-11-30 03:00:20 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-30 03:00:20 --> Calendar Class Initialized
INFO - 2021-11-30 03:00:20 --> Model "Login_model" initialized
INFO - 2021-11-30 03:00:20 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-11-30 03:00:20 --> Final output sent to browser
DEBUG - 2021-11-30 03:00:20 --> Total execution time: 0.0228
ERROR - 2021-11-30 03:49:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-30 03:49:05 --> Config Class Initialized
INFO - 2021-11-30 03:49:05 --> Hooks Class Initialized
DEBUG - 2021-11-30 03:49:05 --> UTF-8 Support Enabled
INFO - 2021-11-30 03:49:05 --> Utf8 Class Initialized
INFO - 2021-11-30 03:49:05 --> URI Class Initialized
DEBUG - 2021-11-30 03:49:05 --> No URI present. Default controller set.
INFO - 2021-11-30 03:49:05 --> Router Class Initialized
INFO - 2021-11-30 03:49:05 --> Output Class Initialized
INFO - 2021-11-30 03:49:05 --> Security Class Initialized
DEBUG - 2021-11-30 03:49:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-30 03:49:05 --> Input Class Initialized
INFO - 2021-11-30 03:49:05 --> Language Class Initialized
INFO - 2021-11-30 03:49:05 --> Loader Class Initialized
INFO - 2021-11-30 03:49:05 --> Helper loaded: url_helper
INFO - 2021-11-30 03:49:05 --> Helper loaded: form_helper
INFO - 2021-11-30 03:49:05 --> Helper loaded: common_helper
INFO - 2021-11-30 03:49:05 --> Database Driver Class Initialized
DEBUG - 2021-11-30 03:49:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-30 03:49:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-30 03:49:05 --> Controller Class Initialized
INFO - 2021-11-30 03:49:05 --> Form Validation Class Initialized
DEBUG - 2021-11-30 03:49:05 --> Encrypt Class Initialized
DEBUG - 2021-11-30 03:49:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-30 03:49:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-30 03:49:05 --> Email Class Initialized
INFO - 2021-11-30 03:49:05 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-30 03:49:05 --> Calendar Class Initialized
INFO - 2021-11-30 03:49:05 --> Model "Login_model" initialized
INFO - 2021-11-30 03:49:05 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-11-30 03:49:05 --> Final output sent to browser
DEBUG - 2021-11-30 03:49:05 --> Total execution time: 0.0470
ERROR - 2021-11-30 05:02:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-30 05:02:23 --> Config Class Initialized
INFO - 2021-11-30 05:02:23 --> Hooks Class Initialized
DEBUG - 2021-11-30 05:02:23 --> UTF-8 Support Enabled
INFO - 2021-11-30 05:02:23 --> Utf8 Class Initialized
INFO - 2021-11-30 05:02:23 --> URI Class Initialized
DEBUG - 2021-11-30 05:02:23 --> No URI present. Default controller set.
INFO - 2021-11-30 05:02:23 --> Router Class Initialized
INFO - 2021-11-30 05:02:23 --> Output Class Initialized
INFO - 2021-11-30 05:02:23 --> Security Class Initialized
DEBUG - 2021-11-30 05:02:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-30 05:02:23 --> Input Class Initialized
INFO - 2021-11-30 05:02:23 --> Language Class Initialized
INFO - 2021-11-30 05:02:23 --> Loader Class Initialized
INFO - 2021-11-30 05:02:23 --> Helper loaded: url_helper
INFO - 2021-11-30 05:02:23 --> Helper loaded: form_helper
INFO - 2021-11-30 05:02:23 --> Helper loaded: common_helper
INFO - 2021-11-30 05:02:23 --> Database Driver Class Initialized
DEBUG - 2021-11-30 05:02:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-30 05:02:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-30 05:02:23 --> Controller Class Initialized
INFO - 2021-11-30 05:02:23 --> Form Validation Class Initialized
DEBUG - 2021-11-30 05:02:23 --> Encrypt Class Initialized
DEBUG - 2021-11-30 05:02:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-30 05:02:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-30 05:02:23 --> Email Class Initialized
INFO - 2021-11-30 05:02:23 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-30 05:02:23 --> Calendar Class Initialized
INFO - 2021-11-30 05:02:23 --> Model "Login_model" initialized
INFO - 2021-11-30 05:02:23 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-11-30 05:02:23 --> Final output sent to browser
DEBUG - 2021-11-30 05:02:23 --> Total execution time: 0.0278
ERROR - 2021-11-30 05:03:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-30 05:03:47 --> Config Class Initialized
INFO - 2021-11-30 05:03:47 --> Hooks Class Initialized
DEBUG - 2021-11-30 05:03:47 --> UTF-8 Support Enabled
INFO - 2021-11-30 05:03:47 --> Utf8 Class Initialized
INFO - 2021-11-30 05:03:47 --> URI Class Initialized
DEBUG - 2021-11-30 05:03:47 --> No URI present. Default controller set.
INFO - 2021-11-30 05:03:47 --> Router Class Initialized
INFO - 2021-11-30 05:03:47 --> Output Class Initialized
INFO - 2021-11-30 05:03:47 --> Security Class Initialized
DEBUG - 2021-11-30 05:03:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-30 05:03:47 --> Input Class Initialized
INFO - 2021-11-30 05:03:47 --> Language Class Initialized
INFO - 2021-11-30 05:03:47 --> Loader Class Initialized
INFO - 2021-11-30 05:03:47 --> Helper loaded: url_helper
INFO - 2021-11-30 05:03:47 --> Helper loaded: form_helper
INFO - 2021-11-30 05:03:47 --> Helper loaded: common_helper
INFO - 2021-11-30 05:03:47 --> Database Driver Class Initialized
DEBUG - 2021-11-30 05:03:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-30 05:03:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-30 05:03:47 --> Controller Class Initialized
INFO - 2021-11-30 05:03:47 --> Form Validation Class Initialized
DEBUG - 2021-11-30 05:03:47 --> Encrypt Class Initialized
DEBUG - 2021-11-30 05:03:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-30 05:03:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-30 05:03:47 --> Email Class Initialized
INFO - 2021-11-30 05:03:47 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-30 05:03:47 --> Calendar Class Initialized
INFO - 2021-11-30 05:03:47 --> Model "Login_model" initialized
INFO - 2021-11-30 05:03:47 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-11-30 05:03:47 --> Final output sent to browser
DEBUG - 2021-11-30 05:03:47 --> Total execution time: 0.0335
ERROR - 2021-11-30 05:11:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-30 05:11:30 --> Config Class Initialized
INFO - 2021-11-30 05:11:30 --> Hooks Class Initialized
DEBUG - 2021-11-30 05:11:30 --> UTF-8 Support Enabled
INFO - 2021-11-30 05:11:30 --> Utf8 Class Initialized
INFO - 2021-11-30 05:11:30 --> URI Class Initialized
DEBUG - 2021-11-30 05:11:30 --> No URI present. Default controller set.
INFO - 2021-11-30 05:11:30 --> Router Class Initialized
INFO - 2021-11-30 05:11:30 --> Output Class Initialized
INFO - 2021-11-30 05:11:30 --> Security Class Initialized
DEBUG - 2021-11-30 05:11:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-30 05:11:30 --> Input Class Initialized
INFO - 2021-11-30 05:11:30 --> Language Class Initialized
INFO - 2021-11-30 05:11:30 --> Loader Class Initialized
INFO - 2021-11-30 05:11:30 --> Helper loaded: url_helper
INFO - 2021-11-30 05:11:30 --> Helper loaded: form_helper
INFO - 2021-11-30 05:11:30 --> Helper loaded: common_helper
INFO - 2021-11-30 05:11:30 --> Database Driver Class Initialized
DEBUG - 2021-11-30 05:11:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-30 05:11:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-30 05:11:30 --> Controller Class Initialized
ERROR - 2021-11-30 05:11:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-30 05:11:44 --> Config Class Initialized
INFO - 2021-11-30 05:11:44 --> Hooks Class Initialized
DEBUG - 2021-11-30 05:11:44 --> UTF-8 Support Enabled
INFO - 2021-11-30 05:11:44 --> Utf8 Class Initialized
INFO - 2021-11-30 05:11:44 --> URI Class Initialized
DEBUG - 2021-11-30 05:11:44 --> No URI present. Default controller set.
INFO - 2021-11-30 05:11:44 --> Router Class Initialized
INFO - 2021-11-30 05:11:44 --> Output Class Initialized
INFO - 2021-11-30 05:11:44 --> Security Class Initialized
DEBUG - 2021-11-30 05:11:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-30 05:11:44 --> Input Class Initialized
INFO - 2021-11-30 05:11:44 --> Language Class Initialized
INFO - 2021-11-30 05:11:44 --> Loader Class Initialized
INFO - 2021-11-30 05:11:44 --> Helper loaded: url_helper
INFO - 2021-11-30 05:11:44 --> Helper loaded: form_helper
INFO - 2021-11-30 05:11:44 --> Helper loaded: common_helper
INFO - 2021-11-30 05:11:44 --> Database Driver Class Initialized
DEBUG - 2021-11-30 05:11:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-30 05:11:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-30 05:11:44 --> Controller Class Initialized
INFO - 2021-11-30 05:11:44 --> Form Validation Class Initialized
DEBUG - 2021-11-30 05:11:44 --> Encrypt Class Initialized
DEBUG - 2021-11-30 05:11:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-30 05:11:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-30 05:11:44 --> Email Class Initialized
INFO - 2021-11-30 05:11:44 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-30 05:11:44 --> Calendar Class Initialized
INFO - 2021-11-30 05:11:44 --> Model "Login_model" initialized
INFO - 2021-11-30 05:11:44 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-11-30 05:11:44 --> Final output sent to browser
DEBUG - 2021-11-30 05:11:44 --> Total execution time: 0.0293
ERROR - 2021-11-30 05:29:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-30 05:29:57 --> Config Class Initialized
INFO - 2021-11-30 05:29:57 --> Hooks Class Initialized
DEBUG - 2021-11-30 05:29:57 --> UTF-8 Support Enabled
INFO - 2021-11-30 05:29:57 --> Utf8 Class Initialized
INFO - 2021-11-30 05:29:57 --> URI Class Initialized
DEBUG - 2021-11-30 05:29:57 --> No URI present. Default controller set.
INFO - 2021-11-30 05:29:57 --> Router Class Initialized
INFO - 2021-11-30 05:29:57 --> Output Class Initialized
INFO - 2021-11-30 05:29:57 --> Security Class Initialized
DEBUG - 2021-11-30 05:29:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-30 05:29:57 --> Input Class Initialized
INFO - 2021-11-30 05:29:57 --> Language Class Initialized
INFO - 2021-11-30 05:29:57 --> Loader Class Initialized
INFO - 2021-11-30 05:29:57 --> Helper loaded: url_helper
INFO - 2021-11-30 05:29:57 --> Helper loaded: form_helper
INFO - 2021-11-30 05:29:57 --> Helper loaded: common_helper
INFO - 2021-11-30 05:29:57 --> Database Driver Class Initialized
DEBUG - 2021-11-30 05:29:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-30 05:29:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-30 05:29:57 --> Controller Class Initialized
ERROR - 2021-11-30 05:30:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-30 05:30:54 --> Config Class Initialized
INFO - 2021-11-30 05:30:54 --> Hooks Class Initialized
DEBUG - 2021-11-30 05:30:54 --> UTF-8 Support Enabled
INFO - 2021-11-30 05:30:54 --> Utf8 Class Initialized
INFO - 2021-11-30 05:30:54 --> URI Class Initialized
DEBUG - 2021-11-30 05:30:54 --> No URI present. Default controller set.
INFO - 2021-11-30 05:30:54 --> Router Class Initialized
INFO - 2021-11-30 05:30:54 --> Output Class Initialized
INFO - 2021-11-30 05:30:54 --> Security Class Initialized
DEBUG - 2021-11-30 05:30:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-30 05:30:54 --> Input Class Initialized
INFO - 2021-11-30 05:30:54 --> Language Class Initialized
INFO - 2021-11-30 05:30:54 --> Loader Class Initialized
INFO - 2021-11-30 05:30:54 --> Helper loaded: url_helper
INFO - 2021-11-30 05:30:54 --> Helper loaded: form_helper
INFO - 2021-11-30 05:30:54 --> Helper loaded: common_helper
INFO - 2021-11-30 05:30:54 --> Database Driver Class Initialized
DEBUG - 2021-11-30 05:30:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-30 05:30:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-30 05:30:54 --> Controller Class Initialized
INFO - 2021-11-30 05:30:54 --> Form Validation Class Initialized
DEBUG - 2021-11-30 05:30:54 --> Encrypt Class Initialized
DEBUG - 2021-11-30 05:30:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-30 05:30:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-30 05:30:54 --> Email Class Initialized
INFO - 2021-11-30 05:30:54 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-30 05:30:54 --> Calendar Class Initialized
INFO - 2021-11-30 05:30:54 --> Model "Login_model" initialized
INFO - 2021-11-30 05:30:54 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-11-30 05:30:54 --> Final output sent to browser
DEBUG - 2021-11-30 05:30:54 --> Total execution time: 0.0265
ERROR - 2021-11-30 05:35:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-30 05:35:57 --> Config Class Initialized
INFO - 2021-11-30 05:35:57 --> Hooks Class Initialized
DEBUG - 2021-11-30 05:35:57 --> UTF-8 Support Enabled
INFO - 2021-11-30 05:35:57 --> Utf8 Class Initialized
INFO - 2021-11-30 05:35:57 --> URI Class Initialized
DEBUG - 2021-11-30 05:35:57 --> No URI present. Default controller set.
INFO - 2021-11-30 05:35:57 --> Router Class Initialized
INFO - 2021-11-30 05:35:57 --> Output Class Initialized
INFO - 2021-11-30 05:35:57 --> Security Class Initialized
DEBUG - 2021-11-30 05:35:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-30 05:35:57 --> Input Class Initialized
INFO - 2021-11-30 05:35:57 --> Language Class Initialized
INFO - 2021-11-30 05:35:57 --> Loader Class Initialized
INFO - 2021-11-30 05:35:57 --> Helper loaded: url_helper
INFO - 2021-11-30 05:35:57 --> Helper loaded: form_helper
INFO - 2021-11-30 05:35:57 --> Helper loaded: common_helper
INFO - 2021-11-30 05:35:57 --> Database Driver Class Initialized
DEBUG - 2021-11-30 05:35:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-30 05:35:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-30 05:35:57 --> Controller Class Initialized
ERROR - 2021-11-30 05:53:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-30 05:53:08 --> Config Class Initialized
INFO - 2021-11-30 05:53:08 --> Hooks Class Initialized
DEBUG - 2021-11-30 05:53:08 --> UTF-8 Support Enabled
INFO - 2021-11-30 05:53:08 --> Utf8 Class Initialized
INFO - 2021-11-30 05:53:08 --> URI Class Initialized
DEBUG - 2021-11-30 05:53:08 --> No URI present. Default controller set.
INFO - 2021-11-30 05:53:08 --> Router Class Initialized
INFO - 2021-11-30 05:53:08 --> Output Class Initialized
INFO - 2021-11-30 05:53:08 --> Security Class Initialized
DEBUG - 2021-11-30 05:53:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-30 05:53:08 --> Input Class Initialized
INFO - 2021-11-30 05:53:08 --> Language Class Initialized
INFO - 2021-11-30 05:53:08 --> Loader Class Initialized
INFO - 2021-11-30 05:53:08 --> Helper loaded: url_helper
INFO - 2021-11-30 05:53:08 --> Helper loaded: form_helper
INFO - 2021-11-30 05:53:08 --> Helper loaded: common_helper
INFO - 2021-11-30 05:53:08 --> Database Driver Class Initialized
DEBUG - 2021-11-30 05:53:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-30 05:53:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-30 05:53:08 --> Controller Class Initialized
INFO - 2021-11-30 05:53:08 --> Form Validation Class Initialized
DEBUG - 2021-11-30 05:53:08 --> Encrypt Class Initialized
DEBUG - 2021-11-30 05:53:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-30 05:53:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-30 05:53:08 --> Email Class Initialized
INFO - 2021-11-30 05:53:08 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-30 05:53:08 --> Calendar Class Initialized
INFO - 2021-11-30 05:53:08 --> Model "Login_model" initialized
INFO - 2021-11-30 05:53:08 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-11-30 05:53:08 --> Final output sent to browser
DEBUG - 2021-11-30 05:53:08 --> Total execution time: 0.0452
ERROR - 2021-11-30 05:53:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-30 05:53:44 --> Config Class Initialized
INFO - 2021-11-30 05:53:44 --> Hooks Class Initialized
DEBUG - 2021-11-30 05:53:44 --> UTF-8 Support Enabled
INFO - 2021-11-30 05:53:44 --> Utf8 Class Initialized
INFO - 2021-11-30 05:53:44 --> URI Class Initialized
DEBUG - 2021-11-30 05:53:44 --> No URI present. Default controller set.
INFO - 2021-11-30 05:53:44 --> Router Class Initialized
INFO - 2021-11-30 05:53:44 --> Output Class Initialized
INFO - 2021-11-30 05:53:44 --> Security Class Initialized
DEBUG - 2021-11-30 05:53:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-30 05:53:44 --> Input Class Initialized
INFO - 2021-11-30 05:53:44 --> Language Class Initialized
INFO - 2021-11-30 05:53:44 --> Loader Class Initialized
INFO - 2021-11-30 05:53:44 --> Helper loaded: url_helper
INFO - 2021-11-30 05:53:44 --> Helper loaded: form_helper
INFO - 2021-11-30 05:53:44 --> Helper loaded: common_helper
INFO - 2021-11-30 05:53:44 --> Database Driver Class Initialized
DEBUG - 2021-11-30 05:53:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-30 05:53:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-30 05:53:44 --> Controller Class Initialized
INFO - 2021-11-30 05:53:44 --> Form Validation Class Initialized
DEBUG - 2021-11-30 05:53:44 --> Encrypt Class Initialized
DEBUG - 2021-11-30 05:53:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-30 05:53:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-30 05:53:44 --> Email Class Initialized
INFO - 2021-11-30 05:53:44 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-30 05:53:44 --> Calendar Class Initialized
INFO - 2021-11-30 05:53:44 --> Model "Login_model" initialized
INFO - 2021-11-30 05:53:44 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-11-30 05:53:44 --> Final output sent to browser
DEBUG - 2021-11-30 05:53:44 --> Total execution time: 0.0230
ERROR - 2021-11-30 06:22:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-30 06:22:33 --> Config Class Initialized
INFO - 2021-11-30 06:22:33 --> Hooks Class Initialized
DEBUG - 2021-11-30 06:22:33 --> UTF-8 Support Enabled
INFO - 2021-11-30 06:22:33 --> Utf8 Class Initialized
INFO - 2021-11-30 06:22:33 --> URI Class Initialized
DEBUG - 2021-11-30 06:22:33 --> No URI present. Default controller set.
INFO - 2021-11-30 06:22:33 --> Router Class Initialized
INFO - 2021-11-30 06:22:33 --> Output Class Initialized
INFO - 2021-11-30 06:22:33 --> Security Class Initialized
DEBUG - 2021-11-30 06:22:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-30 06:22:33 --> Input Class Initialized
INFO - 2021-11-30 06:22:33 --> Language Class Initialized
INFO - 2021-11-30 06:22:33 --> Loader Class Initialized
INFO - 2021-11-30 06:22:33 --> Helper loaded: url_helper
INFO - 2021-11-30 06:22:33 --> Helper loaded: form_helper
INFO - 2021-11-30 06:22:33 --> Helper loaded: common_helper
INFO - 2021-11-30 06:22:33 --> Database Driver Class Initialized
DEBUG - 2021-11-30 06:22:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-30 06:22:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-30 06:22:33 --> Controller Class Initialized
INFO - 2021-11-30 06:22:33 --> Form Validation Class Initialized
DEBUG - 2021-11-30 06:22:33 --> Encrypt Class Initialized
DEBUG - 2021-11-30 06:22:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-30 06:22:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-30 06:22:33 --> Email Class Initialized
INFO - 2021-11-30 06:22:33 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-30 06:22:33 --> Calendar Class Initialized
INFO - 2021-11-30 06:22:33 --> Model "Login_model" initialized
INFO - 2021-11-30 06:22:33 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-11-30 06:22:33 --> Final output sent to browser
DEBUG - 2021-11-30 06:22:33 --> Total execution time: 0.4664
ERROR - 2021-11-30 06:28:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-30 06:28:40 --> Config Class Initialized
INFO - 2021-11-30 06:28:40 --> Hooks Class Initialized
DEBUG - 2021-11-30 06:28:40 --> UTF-8 Support Enabled
INFO - 2021-11-30 06:28:40 --> Utf8 Class Initialized
INFO - 2021-11-30 06:28:40 --> URI Class Initialized
INFO - 2021-11-30 06:28:40 --> Router Class Initialized
INFO - 2021-11-30 06:28:40 --> Output Class Initialized
INFO - 2021-11-30 06:28:40 --> Security Class Initialized
DEBUG - 2021-11-30 06:28:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-30 06:28:40 --> Input Class Initialized
INFO - 2021-11-30 06:28:40 --> Language Class Initialized
INFO - 2021-11-30 06:28:40 --> Loader Class Initialized
INFO - 2021-11-30 06:28:40 --> Helper loaded: url_helper
INFO - 2021-11-30 06:28:40 --> Helper loaded: form_helper
INFO - 2021-11-30 06:28:40 --> Helper loaded: common_helper
INFO - 2021-11-30 06:28:40 --> Database Driver Class Initialized
DEBUG - 2021-11-30 06:28:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-30 06:28:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-30 06:28:40 --> Controller Class Initialized
INFO - 2021-11-30 06:28:40 --> Form Validation Class Initialized
DEBUG - 2021-11-30 06:28:40 --> Encrypt Class Initialized
DEBUG - 2021-11-30 06:28:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-30 06:28:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-30 06:28:40 --> Email Class Initialized
INFO - 2021-11-30 06:28:40 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-30 06:28:40 --> Calendar Class Initialized
INFO - 2021-11-30 06:28:40 --> Model "Login_model" initialized
INFO - 2021-11-30 06:28:40 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-11-30 06:28:40 --> Final output sent to browser
DEBUG - 2021-11-30 06:28:40 --> Total execution time: 0.0398
ERROR - 2021-11-30 06:28:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-30 06:28:54 --> Config Class Initialized
INFO - 2021-11-30 06:28:54 --> Hooks Class Initialized
DEBUG - 2021-11-30 06:28:54 --> UTF-8 Support Enabled
INFO - 2021-11-30 06:28:54 --> Utf8 Class Initialized
INFO - 2021-11-30 06:28:54 --> URI Class Initialized
INFO - 2021-11-30 06:28:54 --> Router Class Initialized
INFO - 2021-11-30 06:28:54 --> Output Class Initialized
INFO - 2021-11-30 06:28:54 --> Security Class Initialized
DEBUG - 2021-11-30 06:28:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-30 06:28:54 --> Input Class Initialized
INFO - 2021-11-30 06:28:54 --> Language Class Initialized
INFO - 2021-11-30 06:28:54 --> Loader Class Initialized
INFO - 2021-11-30 06:28:54 --> Helper loaded: url_helper
INFO - 2021-11-30 06:28:54 --> Helper loaded: form_helper
INFO - 2021-11-30 06:28:54 --> Helper loaded: common_helper
INFO - 2021-11-30 06:28:54 --> Database Driver Class Initialized
DEBUG - 2021-11-30 06:28:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-30 06:28:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-30 06:28:54 --> Controller Class Initialized
INFO - 2021-11-30 06:28:54 --> Form Validation Class Initialized
DEBUG - 2021-11-30 06:28:54 --> Encrypt Class Initialized
DEBUG - 2021-11-30 06:28:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-30 06:28:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-30 06:28:54 --> Email Class Initialized
INFO - 2021-11-30 06:28:54 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-30 06:28:54 --> Calendar Class Initialized
INFO - 2021-11-30 06:28:54 --> Model "Login_model" initialized
INFO - 2021-11-30 06:28:54 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2021-11-30 06:28:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-30 06:28:55 --> Config Class Initialized
INFO - 2021-11-30 06:28:55 --> Hooks Class Initialized
DEBUG - 2021-11-30 06:28:55 --> UTF-8 Support Enabled
INFO - 2021-11-30 06:28:55 --> Utf8 Class Initialized
INFO - 2021-11-30 06:28:55 --> URI Class Initialized
INFO - 2021-11-30 06:28:55 --> Router Class Initialized
INFO - 2021-11-30 06:28:55 --> Output Class Initialized
INFO - 2021-11-30 06:28:55 --> Security Class Initialized
DEBUG - 2021-11-30 06:28:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-30 06:28:55 --> Input Class Initialized
INFO - 2021-11-30 06:28:55 --> Language Class Initialized
INFO - 2021-11-30 06:28:55 --> Loader Class Initialized
INFO - 2021-11-30 06:28:55 --> Helper loaded: url_helper
INFO - 2021-11-30 06:28:55 --> Helper loaded: form_helper
INFO - 2021-11-30 06:28:55 --> Helper loaded: common_helper
INFO - 2021-11-30 06:28:55 --> Database Driver Class Initialized
DEBUG - 2021-11-30 06:28:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-30 06:28:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-30 06:28:55 --> Controller Class Initialized
INFO - 2021-11-30 06:28:55 --> Form Validation Class Initialized
DEBUG - 2021-11-30 06:28:55 --> Encrypt Class Initialized
INFO - 2021-11-30 06:28:55 --> Model "Login_model" initialized
INFO - 2021-11-30 06:28:55 --> Model "Dashboard_model" initialized
INFO - 2021-11-30 06:28:55 --> Model "Case_model" initialized
INFO - 2021-11-30 06:29:11 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-11-30 06:29:22 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2021-11-30 06:29:22 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-11-30 06:29:22 --> Final output sent to browser
DEBUG - 2021-11-30 06:29:22 --> Total execution time: 26.4200
ERROR - 2021-11-30 06:29:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-30 06:29:23 --> Config Class Initialized
INFO - 2021-11-30 06:29:23 --> Hooks Class Initialized
DEBUG - 2021-11-30 06:29:23 --> UTF-8 Support Enabled
INFO - 2021-11-30 06:29:23 --> Utf8 Class Initialized
INFO - 2021-11-30 06:29:23 --> URI Class Initialized
INFO - 2021-11-30 06:29:23 --> Router Class Initialized
INFO - 2021-11-30 06:29:23 --> Output Class Initialized
INFO - 2021-11-30 06:29:23 --> Security Class Initialized
DEBUG - 2021-11-30 06:29:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-30 06:29:23 --> Input Class Initialized
INFO - 2021-11-30 06:29:23 --> Language Class Initialized
ERROR - 2021-11-30 06:29:23 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-11-30 06:29:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-30 06:29:36 --> Config Class Initialized
INFO - 2021-11-30 06:29:36 --> Hooks Class Initialized
DEBUG - 2021-11-30 06:29:36 --> UTF-8 Support Enabled
INFO - 2021-11-30 06:29:36 --> Utf8 Class Initialized
INFO - 2021-11-30 06:29:36 --> URI Class Initialized
INFO - 2021-11-30 06:29:36 --> Router Class Initialized
INFO - 2021-11-30 06:29:36 --> Output Class Initialized
INFO - 2021-11-30 06:29:36 --> Security Class Initialized
DEBUG - 2021-11-30 06:29:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-30 06:29:36 --> Input Class Initialized
INFO - 2021-11-30 06:29:36 --> Language Class Initialized
INFO - 2021-11-30 06:29:36 --> Loader Class Initialized
INFO - 2021-11-30 06:29:36 --> Helper loaded: url_helper
INFO - 2021-11-30 06:29:36 --> Helper loaded: form_helper
INFO - 2021-11-30 06:29:36 --> Helper loaded: common_helper
INFO - 2021-11-30 06:29:36 --> Database Driver Class Initialized
DEBUG - 2021-11-30 06:29:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-30 06:29:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-30 06:29:36 --> Controller Class Initialized
INFO - 2021-11-30 06:29:36 --> Form Validation Class Initialized
INFO - 2021-11-30 06:29:36 --> Model "Case_model" initialized
INFO - 2021-11-30 06:29:36 --> Model "Hospital_model" initialized
INFO - 2021-11-30 06:29:36 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-11-30 06:29:36 --> File loaded: /home3/karoteam/public_html/application/views/transaction/upcomingFollowup.php
INFO - 2021-11-30 06:29:36 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-11-30 06:29:36 --> Final output sent to browser
DEBUG - 2021-11-30 06:29:36 --> Total execution time: 0.0521
ERROR - 2021-11-30 06:29:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-30 06:29:37 --> Config Class Initialized
INFO - 2021-11-30 06:29:37 --> Hooks Class Initialized
DEBUG - 2021-11-30 06:29:37 --> UTF-8 Support Enabled
INFO - 2021-11-30 06:29:37 --> Utf8 Class Initialized
INFO - 2021-11-30 06:29:37 --> URI Class Initialized
INFO - 2021-11-30 06:29:37 --> Router Class Initialized
INFO - 2021-11-30 06:29:37 --> Output Class Initialized
INFO - 2021-11-30 06:29:37 --> Security Class Initialized
DEBUG - 2021-11-30 06:29:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-30 06:29:37 --> Input Class Initialized
INFO - 2021-11-30 06:29:37 --> Language Class Initialized
ERROR - 2021-11-30 06:29:37 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-11-30 06:29:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-30 06:29:53 --> Config Class Initialized
INFO - 2021-11-30 06:29:53 --> Hooks Class Initialized
DEBUG - 2021-11-30 06:29:53 --> UTF-8 Support Enabled
INFO - 2021-11-30 06:29:53 --> Utf8 Class Initialized
INFO - 2021-11-30 06:29:53 --> URI Class Initialized
INFO - 2021-11-30 06:29:53 --> Router Class Initialized
INFO - 2021-11-30 06:29:53 --> Output Class Initialized
INFO - 2021-11-30 06:29:53 --> Security Class Initialized
DEBUG - 2021-11-30 06:29:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-30 06:29:53 --> Input Class Initialized
INFO - 2021-11-30 06:29:53 --> Language Class Initialized
INFO - 2021-11-30 06:29:53 --> Loader Class Initialized
INFO - 2021-11-30 06:29:53 --> Helper loaded: url_helper
INFO - 2021-11-30 06:29:53 --> Helper loaded: form_helper
INFO - 2021-11-30 06:29:53 --> Helper loaded: common_helper
INFO - 2021-11-30 06:29:53 --> Database Driver Class Initialized
DEBUG - 2021-11-30 06:29:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-30 06:29:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-30 06:29:53 --> Controller Class Initialized
INFO - 2021-11-30 06:29:53 --> Form Validation Class Initialized
DEBUG - 2021-11-30 06:29:53 --> Encrypt Class Initialized
INFO - 2021-11-30 06:29:53 --> Model "Payment_model" initialized
INFO - 2021-11-30 06:29:53 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-11-30 06:29:53 --> File loaded: /home3/karoteam/public_html/application/views/payment/index.php
INFO - 2021-11-30 06:29:53 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-11-30 06:29:53 --> Final output sent to browser
DEBUG - 2021-11-30 06:29:53 --> Total execution time: 0.0372
ERROR - 2021-11-30 06:29:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-30 06:29:54 --> Config Class Initialized
INFO - 2021-11-30 06:29:54 --> Hooks Class Initialized
DEBUG - 2021-11-30 06:29:54 --> UTF-8 Support Enabled
INFO - 2021-11-30 06:29:54 --> Utf8 Class Initialized
INFO - 2021-11-30 06:29:54 --> URI Class Initialized
INFO - 2021-11-30 06:29:54 --> Router Class Initialized
INFO - 2021-11-30 06:29:54 --> Output Class Initialized
INFO - 2021-11-30 06:29:54 --> Security Class Initialized
DEBUG - 2021-11-30 06:29:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-30 06:29:54 --> Input Class Initialized
INFO - 2021-11-30 06:29:54 --> Language Class Initialized
ERROR - 2021-11-30 06:29:54 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-11-30 06:33:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-30 06:33:08 --> Config Class Initialized
INFO - 2021-11-30 06:33:08 --> Hooks Class Initialized
DEBUG - 2021-11-30 06:33:08 --> UTF-8 Support Enabled
INFO - 2021-11-30 06:33:08 --> Utf8 Class Initialized
INFO - 2021-11-30 06:33:08 --> URI Class Initialized
INFO - 2021-11-30 06:33:08 --> Router Class Initialized
INFO - 2021-11-30 06:33:08 --> Output Class Initialized
INFO - 2021-11-30 06:33:08 --> Security Class Initialized
DEBUG - 2021-11-30 06:33:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-30 06:33:08 --> Input Class Initialized
INFO - 2021-11-30 06:33:08 --> Language Class Initialized
INFO - 2021-11-30 06:33:08 --> Loader Class Initialized
INFO - 2021-11-30 06:33:08 --> Helper loaded: url_helper
INFO - 2021-11-30 06:33:08 --> Helper loaded: form_helper
INFO - 2021-11-30 06:33:08 --> Helper loaded: common_helper
INFO - 2021-11-30 06:33:08 --> Database Driver Class Initialized
DEBUG - 2021-11-30 06:33:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-30 06:33:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-30 06:33:08 --> Controller Class Initialized
INFO - 2021-11-30 06:33:08 --> Form Validation Class Initialized
DEBUG - 2021-11-30 06:33:08 --> Encrypt Class Initialized
INFO - 2021-11-30 06:33:08 --> Model "Hospital_model" initialized
INFO - 2021-11-30 06:33:08 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-11-30 06:33:08 --> File loaded: /home3/karoteam/public_html/application/views/hospital/depart.php
INFO - 2021-11-30 06:33:08 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-11-30 06:33:08 --> Final output sent to browser
DEBUG - 2021-11-30 06:33:08 --> Total execution time: 0.0433
ERROR - 2021-11-30 06:33:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-30 06:33:09 --> Config Class Initialized
INFO - 2021-11-30 06:33:09 --> Hooks Class Initialized
DEBUG - 2021-11-30 06:33:09 --> UTF-8 Support Enabled
INFO - 2021-11-30 06:33:09 --> Utf8 Class Initialized
INFO - 2021-11-30 06:33:09 --> URI Class Initialized
INFO - 2021-11-30 06:33:09 --> Router Class Initialized
INFO - 2021-11-30 06:33:09 --> Output Class Initialized
INFO - 2021-11-30 06:33:09 --> Security Class Initialized
DEBUG - 2021-11-30 06:33:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-30 06:33:09 --> Input Class Initialized
INFO - 2021-11-30 06:33:09 --> Language Class Initialized
ERROR - 2021-11-30 06:33:09 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-11-30 06:33:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-30 06:33:16 --> Config Class Initialized
INFO - 2021-11-30 06:33:16 --> Hooks Class Initialized
DEBUG - 2021-11-30 06:33:16 --> UTF-8 Support Enabled
INFO - 2021-11-30 06:33:16 --> Utf8 Class Initialized
INFO - 2021-11-30 06:33:16 --> URI Class Initialized
INFO - 2021-11-30 06:33:16 --> Router Class Initialized
INFO - 2021-11-30 06:33:16 --> Output Class Initialized
INFO - 2021-11-30 06:33:16 --> Security Class Initialized
DEBUG - 2021-11-30 06:33:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-30 06:33:16 --> Input Class Initialized
INFO - 2021-11-30 06:33:16 --> Language Class Initialized
INFO - 2021-11-30 06:33:16 --> Loader Class Initialized
INFO - 2021-11-30 06:33:16 --> Helper loaded: url_helper
INFO - 2021-11-30 06:33:16 --> Helper loaded: form_helper
INFO - 2021-11-30 06:33:16 --> Helper loaded: common_helper
INFO - 2021-11-30 06:33:16 --> Database Driver Class Initialized
DEBUG - 2021-11-30 06:33:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-30 06:33:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-30 06:33:16 --> Controller Class Initialized
INFO - 2021-11-30 06:33:16 --> Form Validation Class Initialized
DEBUG - 2021-11-30 06:33:16 --> Encrypt Class Initialized
INFO - 2021-11-30 06:33:16 --> Model "Login_model" initialized
INFO - 2021-11-30 06:33:16 --> Model "Dashboard_model" initialized
INFO - 2021-11-30 06:33:16 --> Model "Case_model" initialized
INFO - 2021-11-30 06:33:29 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-11-30 06:33:39 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2021-11-30 06:33:39 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-11-30 06:33:39 --> Final output sent to browser
DEBUG - 2021-11-30 06:33:39 --> Total execution time: 23.7109
ERROR - 2021-11-30 06:33:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-30 06:33:40 --> Config Class Initialized
INFO - 2021-11-30 06:33:40 --> Hooks Class Initialized
DEBUG - 2021-11-30 06:33:40 --> UTF-8 Support Enabled
INFO - 2021-11-30 06:33:40 --> Utf8 Class Initialized
INFO - 2021-11-30 06:33:40 --> URI Class Initialized
INFO - 2021-11-30 06:33:40 --> Router Class Initialized
INFO - 2021-11-30 06:33:40 --> Output Class Initialized
INFO - 2021-11-30 06:33:40 --> Security Class Initialized
DEBUG - 2021-11-30 06:33:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-30 06:33:40 --> Input Class Initialized
INFO - 2021-11-30 06:33:40 --> Language Class Initialized
ERROR - 2021-11-30 06:33:40 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-11-30 06:54:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-30 06:54:46 --> Config Class Initialized
INFO - 2021-11-30 06:54:46 --> Hooks Class Initialized
DEBUG - 2021-11-30 06:54:46 --> UTF-8 Support Enabled
INFO - 2021-11-30 06:54:46 --> Utf8 Class Initialized
INFO - 2021-11-30 06:54:46 --> URI Class Initialized
DEBUG - 2021-11-30 06:54:46 --> No URI present. Default controller set.
INFO - 2021-11-30 06:54:46 --> Router Class Initialized
INFO - 2021-11-30 06:54:46 --> Output Class Initialized
INFO - 2021-11-30 06:54:46 --> Security Class Initialized
DEBUG - 2021-11-30 06:54:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-30 06:54:46 --> Input Class Initialized
INFO - 2021-11-30 06:54:46 --> Language Class Initialized
INFO - 2021-11-30 06:54:46 --> Loader Class Initialized
INFO - 2021-11-30 06:54:46 --> Helper loaded: url_helper
INFO - 2021-11-30 06:54:46 --> Helper loaded: form_helper
INFO - 2021-11-30 06:54:46 --> Helper loaded: common_helper
INFO - 2021-11-30 06:54:46 --> Database Driver Class Initialized
DEBUG - 2021-11-30 06:54:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-30 06:54:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-30 06:54:46 --> Controller Class Initialized
INFO - 2021-11-30 06:54:46 --> Form Validation Class Initialized
DEBUG - 2021-11-30 06:54:46 --> Encrypt Class Initialized
DEBUG - 2021-11-30 06:54:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-30 06:54:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-30 06:54:46 --> Email Class Initialized
INFO - 2021-11-30 06:54:46 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-30 06:54:46 --> Calendar Class Initialized
INFO - 2021-11-30 06:54:46 --> Model "Login_model" initialized
INFO - 2021-11-30 06:54:46 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-11-30 06:54:46 --> Final output sent to browser
DEBUG - 2021-11-30 06:54:46 --> Total execution time: 0.0423
ERROR - 2021-11-30 06:55:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-30 06:55:21 --> Config Class Initialized
INFO - 2021-11-30 06:55:21 --> Hooks Class Initialized
DEBUG - 2021-11-30 06:55:21 --> UTF-8 Support Enabled
INFO - 2021-11-30 06:55:21 --> Utf8 Class Initialized
INFO - 2021-11-30 06:55:21 --> URI Class Initialized
DEBUG - 2021-11-30 06:55:21 --> No URI present. Default controller set.
INFO - 2021-11-30 06:55:21 --> Router Class Initialized
INFO - 2021-11-30 06:55:21 --> Output Class Initialized
INFO - 2021-11-30 06:55:21 --> Security Class Initialized
DEBUG - 2021-11-30 06:55:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-30 06:55:21 --> Input Class Initialized
INFO - 2021-11-30 06:55:21 --> Language Class Initialized
INFO - 2021-11-30 06:55:21 --> Loader Class Initialized
INFO - 2021-11-30 06:55:21 --> Helper loaded: url_helper
INFO - 2021-11-30 06:55:21 --> Helper loaded: form_helper
INFO - 2021-11-30 06:55:21 --> Helper loaded: common_helper
INFO - 2021-11-30 06:55:21 --> Database Driver Class Initialized
DEBUG - 2021-11-30 06:55:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-30 06:55:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-30 06:55:21 --> Controller Class Initialized
INFO - 2021-11-30 06:55:21 --> Form Validation Class Initialized
DEBUG - 2021-11-30 06:55:21 --> Encrypt Class Initialized
DEBUG - 2021-11-30 06:55:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-30 06:55:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-30 06:55:21 --> Email Class Initialized
INFO - 2021-11-30 06:55:21 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-30 06:55:21 --> Calendar Class Initialized
INFO - 2021-11-30 06:55:21 --> Model "Login_model" initialized
ERROR - 2021-11-30 06:55:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-30 06:55:22 --> Config Class Initialized
INFO - 2021-11-30 06:55:22 --> Hooks Class Initialized
DEBUG - 2021-11-30 06:55:22 --> UTF-8 Support Enabled
INFO - 2021-11-30 06:55:22 --> Utf8 Class Initialized
INFO - 2021-11-30 06:55:22 --> URI Class Initialized
INFO - 2021-11-30 06:55:22 --> Router Class Initialized
INFO - 2021-11-30 06:55:22 --> Output Class Initialized
INFO - 2021-11-30 06:55:22 --> Security Class Initialized
DEBUG - 2021-11-30 06:55:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-30 06:55:22 --> Input Class Initialized
INFO - 2021-11-30 06:55:22 --> Language Class Initialized
INFO - 2021-11-30 06:55:22 --> Loader Class Initialized
INFO - 2021-11-30 06:55:22 --> Helper loaded: url_helper
INFO - 2021-11-30 06:55:22 --> Helper loaded: form_helper
INFO - 2021-11-30 06:55:22 --> Helper loaded: common_helper
INFO - 2021-11-30 06:55:22 --> Database Driver Class Initialized
DEBUG - 2021-11-30 06:55:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-30 06:55:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-30 06:55:22 --> Controller Class Initialized
INFO - 2021-11-30 06:55:22 --> Form Validation Class Initialized
DEBUG - 2021-11-30 06:55:22 --> Encrypt Class Initialized
INFO - 2021-11-30 06:55:22 --> Model "Diseases_model" initialized
INFO - 2021-11-30 06:55:22 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-11-30 06:55:22 --> File loaded: /home3/karoteam/public_html/application/views/diseases/index.php
INFO - 2021-11-30 06:55:22 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-11-30 06:55:22 --> Final output sent to browser
DEBUG - 2021-11-30 06:55:22 --> Total execution time: 0.0332
ERROR - 2021-11-30 06:55:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-30 06:55:23 --> Config Class Initialized
INFO - 2021-11-30 06:55:23 --> Hooks Class Initialized
DEBUG - 2021-11-30 06:55:23 --> UTF-8 Support Enabled
INFO - 2021-11-30 06:55:23 --> Utf8 Class Initialized
INFO - 2021-11-30 06:55:23 --> URI Class Initialized
INFO - 2021-11-30 06:55:23 --> Router Class Initialized
INFO - 2021-11-30 06:55:23 --> Output Class Initialized
INFO - 2021-11-30 06:55:23 --> Security Class Initialized
DEBUG - 2021-11-30 06:55:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-30 06:55:23 --> Input Class Initialized
INFO - 2021-11-30 06:55:23 --> Language Class Initialized
ERROR - 2021-11-30 06:55:23 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-11-30 06:55:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-30 06:55:36 --> Config Class Initialized
INFO - 2021-11-30 06:55:36 --> Hooks Class Initialized
DEBUG - 2021-11-30 06:55:36 --> UTF-8 Support Enabled
INFO - 2021-11-30 06:55:36 --> Utf8 Class Initialized
INFO - 2021-11-30 06:55:36 --> URI Class Initialized
INFO - 2021-11-30 06:55:36 --> Router Class Initialized
INFO - 2021-11-30 06:55:36 --> Output Class Initialized
INFO - 2021-11-30 06:55:36 --> Security Class Initialized
DEBUG - 2021-11-30 06:55:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-30 06:55:36 --> Input Class Initialized
INFO - 2021-11-30 06:55:36 --> Language Class Initialized
INFO - 2021-11-30 06:55:36 --> Loader Class Initialized
INFO - 2021-11-30 06:55:36 --> Helper loaded: url_helper
INFO - 2021-11-30 06:55:36 --> Helper loaded: form_helper
INFO - 2021-11-30 06:55:36 --> Helper loaded: common_helper
INFO - 2021-11-30 06:55:36 --> Database Driver Class Initialized
DEBUG - 2021-11-30 06:55:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-30 06:55:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-30 06:55:36 --> Controller Class Initialized
ERROR - 2021-11-30 06:55:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-30 06:55:37 --> Config Class Initialized
INFO - 2021-11-30 06:55:37 --> Hooks Class Initialized
DEBUG - 2021-11-30 06:55:37 --> UTF-8 Support Enabled
INFO - 2021-11-30 06:55:37 --> Utf8 Class Initialized
INFO - 2021-11-30 06:55:37 --> URI Class Initialized
INFO - 2021-11-30 06:55:37 --> Router Class Initialized
INFO - 2021-11-30 06:55:37 --> Output Class Initialized
INFO - 2021-11-30 06:55:37 --> Security Class Initialized
DEBUG - 2021-11-30 06:55:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-30 06:55:37 --> Input Class Initialized
INFO - 2021-11-30 06:55:37 --> Language Class Initialized
INFO - 2021-11-30 06:55:37 --> Loader Class Initialized
INFO - 2021-11-30 06:55:37 --> Helper loaded: url_helper
INFO - 2021-11-30 06:55:37 --> Helper loaded: form_helper
INFO - 2021-11-30 06:55:37 --> Helper loaded: common_helper
INFO - 2021-11-30 06:55:37 --> Database Driver Class Initialized
DEBUG - 2021-11-30 06:55:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-30 06:55:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-30 06:55:37 --> Controller Class Initialized
INFO - 2021-11-30 06:55:37 --> Form Validation Class Initialized
DEBUG - 2021-11-30 06:55:37 --> Encrypt Class Initialized
DEBUG - 2021-11-30 06:55:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-30 06:55:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-30 06:55:37 --> Email Class Initialized
INFO - 2021-11-30 06:55:37 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-30 06:55:37 --> Calendar Class Initialized
INFO - 2021-11-30 06:55:37 --> Model "Login_model" initialized
INFO - 2021-11-30 06:55:37 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-11-30 06:55:37 --> Final output sent to browser
DEBUG - 2021-11-30 06:55:37 --> Total execution time: 0.0239
ERROR - 2021-11-30 06:58:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-30 06:58:48 --> Config Class Initialized
INFO - 2021-11-30 06:58:48 --> Hooks Class Initialized
DEBUG - 2021-11-30 06:58:48 --> UTF-8 Support Enabled
INFO - 2021-11-30 06:58:48 --> Utf8 Class Initialized
INFO - 2021-11-30 06:58:48 --> URI Class Initialized
DEBUG - 2021-11-30 06:58:48 --> No URI present. Default controller set.
INFO - 2021-11-30 06:58:48 --> Router Class Initialized
INFO - 2021-11-30 06:58:48 --> Output Class Initialized
INFO - 2021-11-30 06:58:48 --> Security Class Initialized
DEBUG - 2021-11-30 06:58:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-30 06:58:48 --> Input Class Initialized
INFO - 2021-11-30 06:58:48 --> Language Class Initialized
INFO - 2021-11-30 06:58:48 --> Loader Class Initialized
INFO - 2021-11-30 06:58:48 --> Helper loaded: url_helper
INFO - 2021-11-30 06:58:48 --> Helper loaded: form_helper
INFO - 2021-11-30 06:58:48 --> Helper loaded: common_helper
INFO - 2021-11-30 06:58:48 --> Database Driver Class Initialized
DEBUG - 2021-11-30 06:58:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-30 06:58:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-30 06:58:48 --> Controller Class Initialized
INFO - 2021-11-30 06:58:48 --> Form Validation Class Initialized
DEBUG - 2021-11-30 06:58:48 --> Encrypt Class Initialized
DEBUG - 2021-11-30 06:58:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-30 06:58:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-30 06:58:48 --> Email Class Initialized
INFO - 2021-11-30 06:58:48 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-30 06:58:48 --> Calendar Class Initialized
INFO - 2021-11-30 06:58:48 --> Model "Login_model" initialized
INFO - 2021-11-30 06:58:48 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-11-30 06:58:48 --> Final output sent to browser
DEBUG - 2021-11-30 06:58:48 --> Total execution time: 0.0388
ERROR - 2021-11-30 07:00:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-30 07:00:53 --> Config Class Initialized
INFO - 2021-11-30 07:00:53 --> Hooks Class Initialized
DEBUG - 2021-11-30 07:00:53 --> UTF-8 Support Enabled
INFO - 2021-11-30 07:00:53 --> Utf8 Class Initialized
INFO - 2021-11-30 07:00:53 --> URI Class Initialized
INFO - 2021-11-30 07:00:53 --> Router Class Initialized
INFO - 2021-11-30 07:00:53 --> Output Class Initialized
INFO - 2021-11-30 07:00:53 --> Security Class Initialized
DEBUG - 2021-11-30 07:00:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-30 07:00:53 --> Input Class Initialized
INFO - 2021-11-30 07:00:53 --> Language Class Initialized
INFO - 2021-11-30 07:00:53 --> Loader Class Initialized
INFO - 2021-11-30 07:00:53 --> Helper loaded: url_helper
INFO - 2021-11-30 07:00:53 --> Helper loaded: form_helper
INFO - 2021-11-30 07:00:53 --> Helper loaded: common_helper
INFO - 2021-11-30 07:00:53 --> Database Driver Class Initialized
DEBUG - 2021-11-30 07:00:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-30 07:00:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-30 07:00:53 --> Controller Class Initialized
INFO - 2021-11-30 07:00:53 --> Form Validation Class Initialized
DEBUG - 2021-11-30 07:00:53 --> Encrypt Class Initialized
DEBUG - 2021-11-30 07:00:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-30 07:00:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-30 07:00:53 --> Email Class Initialized
INFO - 2021-11-30 07:00:53 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-30 07:00:53 --> Calendar Class Initialized
INFO - 2021-11-30 07:00:53 --> Model "Login_model" initialized
ERROR - 2021-11-30 07:00:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-30 07:00:54 --> Config Class Initialized
INFO - 2021-11-30 07:00:54 --> Hooks Class Initialized
DEBUG - 2021-11-30 07:00:54 --> UTF-8 Support Enabled
INFO - 2021-11-30 07:00:54 --> Utf8 Class Initialized
INFO - 2021-11-30 07:00:54 --> URI Class Initialized
INFO - 2021-11-30 07:00:54 --> Router Class Initialized
INFO - 2021-11-30 07:00:54 --> Output Class Initialized
INFO - 2021-11-30 07:00:54 --> Security Class Initialized
DEBUG - 2021-11-30 07:00:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-30 07:00:54 --> Input Class Initialized
INFO - 2021-11-30 07:00:54 --> Language Class Initialized
INFO - 2021-11-30 07:00:54 --> Loader Class Initialized
INFO - 2021-11-30 07:00:54 --> Helper loaded: url_helper
INFO - 2021-11-30 07:00:54 --> Helper loaded: form_helper
INFO - 2021-11-30 07:00:54 --> Helper loaded: common_helper
INFO - 2021-11-30 07:00:54 --> Database Driver Class Initialized
DEBUG - 2021-11-30 07:00:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-30 07:00:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-30 07:00:54 --> Controller Class Initialized
INFO - 2021-11-30 07:00:54 --> Form Validation Class Initialized
DEBUG - 2021-11-30 07:00:54 --> Encrypt Class Initialized
DEBUG - 2021-11-30 07:00:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-30 07:00:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-30 07:00:54 --> Email Class Initialized
INFO - 2021-11-30 07:00:54 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-30 07:00:54 --> Calendar Class Initialized
INFO - 2021-11-30 07:00:54 --> Model "Login_model" initialized
INFO - 2021-11-30 07:00:54 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-11-30 07:00:54 --> Final output sent to browser
DEBUG - 2021-11-30 07:00:54 --> Total execution time: 0.0341
ERROR - 2021-11-30 07:00:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-30 07:00:58 --> Config Class Initialized
INFO - 2021-11-30 07:00:58 --> Hooks Class Initialized
DEBUG - 2021-11-30 07:00:58 --> UTF-8 Support Enabled
INFO - 2021-11-30 07:00:58 --> Utf8 Class Initialized
INFO - 2021-11-30 07:00:58 --> URI Class Initialized
INFO - 2021-11-30 07:00:58 --> Router Class Initialized
INFO - 2021-11-30 07:00:58 --> Output Class Initialized
INFO - 2021-11-30 07:00:58 --> Security Class Initialized
DEBUG - 2021-11-30 07:00:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-30 07:00:58 --> Input Class Initialized
INFO - 2021-11-30 07:00:58 --> Language Class Initialized
INFO - 2021-11-30 07:00:58 --> Loader Class Initialized
INFO - 2021-11-30 07:00:58 --> Helper loaded: url_helper
INFO - 2021-11-30 07:00:58 --> Helper loaded: form_helper
INFO - 2021-11-30 07:00:58 --> Helper loaded: common_helper
INFO - 2021-11-30 07:00:58 --> Database Driver Class Initialized
DEBUG - 2021-11-30 07:00:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-30 07:00:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-30 07:00:58 --> Controller Class Initialized
INFO - 2021-11-30 07:00:58 --> Form Validation Class Initialized
DEBUG - 2021-11-30 07:00:58 --> Encrypt Class Initialized
DEBUG - 2021-11-30 07:00:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-30 07:00:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-30 07:00:58 --> Email Class Initialized
INFO - 2021-11-30 07:00:58 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-30 07:00:58 --> Calendar Class Initialized
INFO - 2021-11-30 07:00:58 --> Model "Login_model" initialized
INFO - 2021-11-30 07:00:58 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-11-30 07:00:58 --> Final output sent to browser
DEBUG - 2021-11-30 07:00:58 --> Total execution time: 0.0342
ERROR - 2021-11-30 07:01:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-30 07:01:01 --> Config Class Initialized
INFO - 2021-11-30 07:01:01 --> Hooks Class Initialized
DEBUG - 2021-11-30 07:01:01 --> UTF-8 Support Enabled
INFO - 2021-11-30 07:01:01 --> Utf8 Class Initialized
INFO - 2021-11-30 07:01:01 --> URI Class Initialized
INFO - 2021-11-30 07:01:01 --> Router Class Initialized
INFO - 2021-11-30 07:01:01 --> Output Class Initialized
INFO - 2021-11-30 07:01:01 --> Security Class Initialized
DEBUG - 2021-11-30 07:01:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-30 07:01:01 --> Input Class Initialized
INFO - 2021-11-30 07:01:01 --> Language Class Initialized
INFO - 2021-11-30 07:01:01 --> Loader Class Initialized
INFO - 2021-11-30 07:01:01 --> Helper loaded: url_helper
INFO - 2021-11-30 07:01:01 --> Helper loaded: form_helper
INFO - 2021-11-30 07:01:01 --> Helper loaded: common_helper
INFO - 2021-11-30 07:01:01 --> Database Driver Class Initialized
DEBUG - 2021-11-30 07:01:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-30 07:01:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-30 07:01:01 --> Controller Class Initialized
INFO - 2021-11-30 07:01:01 --> Form Validation Class Initialized
DEBUG - 2021-11-30 07:01:01 --> Encrypt Class Initialized
DEBUG - 2021-11-30 07:01:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-30 07:01:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-30 07:01:01 --> Email Class Initialized
INFO - 2021-11-30 07:01:01 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-30 07:01:01 --> Calendar Class Initialized
INFO - 2021-11-30 07:01:01 --> Model "Login_model" initialized
INFO - 2021-11-30 07:01:01 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-11-30 07:01:01 --> Final output sent to browser
DEBUG - 2021-11-30 07:01:01 --> Total execution time: 0.0454
ERROR - 2021-11-30 07:01:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-30 07:01:48 --> Config Class Initialized
INFO - 2021-11-30 07:01:48 --> Hooks Class Initialized
DEBUG - 2021-11-30 07:01:48 --> UTF-8 Support Enabled
INFO - 2021-11-30 07:01:48 --> Utf8 Class Initialized
INFO - 2021-11-30 07:01:48 --> URI Class Initialized
DEBUG - 2021-11-30 07:01:48 --> No URI present. Default controller set.
INFO - 2021-11-30 07:01:48 --> Router Class Initialized
INFO - 2021-11-30 07:01:48 --> Output Class Initialized
INFO - 2021-11-30 07:01:48 --> Security Class Initialized
DEBUG - 2021-11-30 07:01:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-30 07:01:48 --> Input Class Initialized
INFO - 2021-11-30 07:01:48 --> Language Class Initialized
INFO - 2021-11-30 07:01:48 --> Loader Class Initialized
INFO - 2021-11-30 07:01:48 --> Helper loaded: url_helper
INFO - 2021-11-30 07:01:48 --> Helper loaded: form_helper
INFO - 2021-11-30 07:01:48 --> Helper loaded: common_helper
INFO - 2021-11-30 07:01:48 --> Database Driver Class Initialized
DEBUG - 2021-11-30 07:01:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-30 07:01:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-30 07:01:48 --> Controller Class Initialized
INFO - 2021-11-30 07:01:48 --> Form Validation Class Initialized
DEBUG - 2021-11-30 07:01:48 --> Encrypt Class Initialized
DEBUG - 2021-11-30 07:01:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-30 07:01:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-30 07:01:48 --> Email Class Initialized
INFO - 2021-11-30 07:01:48 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-30 07:01:48 --> Calendar Class Initialized
INFO - 2021-11-30 07:01:48 --> Model "Login_model" initialized
INFO - 2021-11-30 07:01:48 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-11-30 07:01:48 --> Final output sent to browser
DEBUG - 2021-11-30 07:01:48 --> Total execution time: 0.0224
ERROR - 2021-11-30 07:01:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-30 07:01:54 --> Config Class Initialized
INFO - 2021-11-30 07:01:54 --> Hooks Class Initialized
DEBUG - 2021-11-30 07:01:54 --> UTF-8 Support Enabled
INFO - 2021-11-30 07:01:54 --> Utf8 Class Initialized
INFO - 2021-11-30 07:01:54 --> URI Class Initialized
INFO - 2021-11-30 07:01:54 --> Router Class Initialized
INFO - 2021-11-30 07:01:54 --> Output Class Initialized
INFO - 2021-11-30 07:01:54 --> Security Class Initialized
DEBUG - 2021-11-30 07:01:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-30 07:01:54 --> Input Class Initialized
INFO - 2021-11-30 07:01:54 --> Language Class Initialized
INFO - 2021-11-30 07:01:54 --> Loader Class Initialized
INFO - 2021-11-30 07:01:54 --> Helper loaded: url_helper
INFO - 2021-11-30 07:01:54 --> Helper loaded: form_helper
INFO - 2021-11-30 07:01:54 --> Helper loaded: common_helper
INFO - 2021-11-30 07:01:54 --> Database Driver Class Initialized
DEBUG - 2021-11-30 07:01:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-30 07:01:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-30 07:01:54 --> Controller Class Initialized
INFO - 2021-11-30 07:01:54 --> Form Validation Class Initialized
DEBUG - 2021-11-30 07:01:54 --> Encrypt Class Initialized
DEBUG - 2021-11-30 07:01:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-30 07:01:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-30 07:01:54 --> Email Class Initialized
INFO - 2021-11-30 07:01:54 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-30 07:01:54 --> Calendar Class Initialized
INFO - 2021-11-30 07:01:54 --> Model "Login_model" initialized
INFO - 2021-11-30 07:01:54 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-11-30 07:01:54 --> Final output sent to browser
DEBUG - 2021-11-30 07:01:54 --> Total execution time: 0.0279
ERROR - 2021-11-30 07:02:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-30 07:02:15 --> Config Class Initialized
INFO - 2021-11-30 07:02:15 --> Hooks Class Initialized
DEBUG - 2021-11-30 07:02:15 --> UTF-8 Support Enabled
INFO - 2021-11-30 07:02:15 --> Utf8 Class Initialized
INFO - 2021-11-30 07:02:15 --> URI Class Initialized
INFO - 2021-11-30 07:02:15 --> Router Class Initialized
INFO - 2021-11-30 07:02:15 --> Output Class Initialized
INFO - 2021-11-30 07:02:15 --> Security Class Initialized
DEBUG - 2021-11-30 07:02:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-30 07:02:15 --> Input Class Initialized
INFO - 2021-11-30 07:02:15 --> Language Class Initialized
INFO - 2021-11-30 07:02:15 --> Loader Class Initialized
INFO - 2021-11-30 07:02:15 --> Helper loaded: url_helper
INFO - 2021-11-30 07:02:15 --> Helper loaded: form_helper
INFO - 2021-11-30 07:02:15 --> Helper loaded: common_helper
INFO - 2021-11-30 07:02:15 --> Database Driver Class Initialized
DEBUG - 2021-11-30 07:02:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-30 07:02:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-30 07:02:15 --> Controller Class Initialized
INFO - 2021-11-30 07:02:15 --> Form Validation Class Initialized
DEBUG - 2021-11-30 07:02:15 --> Encrypt Class Initialized
DEBUG - 2021-11-30 07:02:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-30 07:02:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-30 07:02:15 --> Email Class Initialized
INFO - 2021-11-30 07:02:15 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-30 07:02:15 --> Calendar Class Initialized
INFO - 2021-11-30 07:02:15 --> Model "Login_model" initialized
INFO - 2021-11-30 07:02:15 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2021-11-30 07:02:15 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
ERROR - 2021-11-30 07:02:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-30 07:02:22 --> Config Class Initialized
INFO - 2021-11-30 07:02:22 --> Hooks Class Initialized
DEBUG - 2021-11-30 07:02:22 --> UTF-8 Support Enabled
INFO - 2021-11-30 07:02:22 --> Utf8 Class Initialized
INFO - 2021-11-30 07:02:22 --> URI Class Initialized
INFO - 2021-11-30 07:02:22 --> Router Class Initialized
INFO - 2021-11-30 07:02:22 --> Output Class Initialized
INFO - 2021-11-30 07:02:22 --> Security Class Initialized
DEBUG - 2021-11-30 07:02:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-30 07:02:22 --> Input Class Initialized
INFO - 2021-11-30 07:02:22 --> Language Class Initialized
INFO - 2021-11-30 07:02:22 --> Loader Class Initialized
INFO - 2021-11-30 07:02:22 --> Helper loaded: url_helper
INFO - 2021-11-30 07:02:22 --> Helper loaded: form_helper
INFO - 2021-11-30 07:02:22 --> Helper loaded: common_helper
INFO - 2021-11-30 07:02:22 --> Database Driver Class Initialized
DEBUG - 2021-11-30 07:02:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-30 07:02:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-30 07:02:22 --> Controller Class Initialized
INFO - 2021-11-30 07:02:22 --> Form Validation Class Initialized
DEBUG - 2021-11-30 07:02:22 --> Encrypt Class Initialized
DEBUG - 2021-11-30 07:02:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-30 07:02:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-30 07:02:22 --> Email Class Initialized
INFO - 2021-11-30 07:02:22 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-30 07:02:22 --> Calendar Class Initialized
INFO - 2021-11-30 07:02:22 --> Model "Login_model" initialized
INFO - 2021-11-30 07:02:22 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2021-11-30 07:02:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-30 07:02:23 --> Config Class Initialized
INFO - 2021-11-30 07:02:23 --> Hooks Class Initialized
DEBUG - 2021-11-30 07:02:23 --> UTF-8 Support Enabled
INFO - 2021-11-30 07:02:23 --> Utf8 Class Initialized
INFO - 2021-11-30 07:02:23 --> URI Class Initialized
INFO - 2021-11-30 07:02:23 --> Router Class Initialized
INFO - 2021-11-30 07:02:23 --> Output Class Initialized
INFO - 2021-11-30 07:02:23 --> Security Class Initialized
DEBUG - 2021-11-30 07:02:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-30 07:02:23 --> Input Class Initialized
INFO - 2021-11-30 07:02:23 --> Language Class Initialized
INFO - 2021-11-30 07:02:23 --> Loader Class Initialized
INFO - 2021-11-30 07:02:23 --> Helper loaded: url_helper
INFO - 2021-11-30 07:02:23 --> Helper loaded: form_helper
INFO - 2021-11-30 07:02:23 --> Helper loaded: common_helper
INFO - 2021-11-30 07:02:23 --> Database Driver Class Initialized
DEBUG - 2021-11-30 07:02:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-30 07:02:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-30 07:02:23 --> Controller Class Initialized
INFO - 2021-11-30 07:02:23 --> Form Validation Class Initialized
DEBUG - 2021-11-30 07:02:23 --> Encrypt Class Initialized
INFO - 2021-11-30 07:02:23 --> Model "Login_model" initialized
INFO - 2021-11-30 07:02:23 --> Model "Dashboard_model" initialized
INFO - 2021-11-30 07:02:23 --> Model "Case_model" initialized
INFO - 2021-11-30 07:02:35 --> File loaded: /home3/karoteam/public_html/application/views/header.php
ERROR - 2021-11-30 07:02:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-30 07:02:39 --> Config Class Initialized
INFO - 2021-11-30 07:02:39 --> Hooks Class Initialized
DEBUG - 2021-11-30 07:02:39 --> UTF-8 Support Enabled
INFO - 2021-11-30 07:02:39 --> Utf8 Class Initialized
INFO - 2021-11-30 07:02:39 --> URI Class Initialized
INFO - 2021-11-30 07:02:39 --> Router Class Initialized
INFO - 2021-11-30 07:02:39 --> Output Class Initialized
INFO - 2021-11-30 07:02:39 --> Security Class Initialized
DEBUG - 2021-11-30 07:02:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-30 07:02:39 --> Input Class Initialized
INFO - 2021-11-30 07:02:39 --> Language Class Initialized
INFO - 2021-11-30 07:02:39 --> Loader Class Initialized
INFO - 2021-11-30 07:02:39 --> Helper loaded: url_helper
INFO - 2021-11-30 07:02:39 --> Helper loaded: form_helper
INFO - 2021-11-30 07:02:39 --> Helper loaded: common_helper
INFO - 2021-11-30 07:02:39 --> Database Driver Class Initialized
DEBUG - 2021-11-30 07:02:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-30 07:02:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-30 07:02:39 --> Controller Class Initialized
INFO - 2021-11-30 07:02:39 --> Form Validation Class Initialized
DEBUG - 2021-11-30 07:02:39 --> Encrypt Class Initialized
DEBUG - 2021-11-30 07:02:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-30 07:02:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-30 07:02:39 --> Email Class Initialized
INFO - 2021-11-30 07:02:39 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-30 07:02:39 --> Calendar Class Initialized
INFO - 2021-11-30 07:02:39 --> Model "Login_model" initialized
INFO - 2021-11-30 07:02:39 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2021-11-30 07:02:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-30 07:02:40 --> Config Class Initialized
INFO - 2021-11-30 07:02:40 --> Hooks Class Initialized
DEBUG - 2021-11-30 07:02:40 --> UTF-8 Support Enabled
INFO - 2021-11-30 07:02:40 --> Utf8 Class Initialized
INFO - 2021-11-30 07:02:40 --> URI Class Initialized
INFO - 2021-11-30 07:02:40 --> Router Class Initialized
INFO - 2021-11-30 07:02:40 --> Output Class Initialized
INFO - 2021-11-30 07:02:40 --> Security Class Initialized
DEBUG - 2021-11-30 07:02:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-30 07:02:40 --> Input Class Initialized
INFO - 2021-11-30 07:02:40 --> Language Class Initialized
INFO - 2021-11-30 07:02:40 --> Loader Class Initialized
INFO - 2021-11-30 07:02:40 --> Helper loaded: url_helper
INFO - 2021-11-30 07:02:40 --> Helper loaded: form_helper
INFO - 2021-11-30 07:02:40 --> Helper loaded: common_helper
INFO - 2021-11-30 07:02:40 --> Database Driver Class Initialized
DEBUG - 2021-11-30 07:02:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-30 07:02:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-30 07:02:40 --> Controller Class Initialized
INFO - 2021-11-30 07:02:40 --> Form Validation Class Initialized
DEBUG - 2021-11-30 07:02:40 --> Encrypt Class Initialized
INFO - 2021-11-30 07:02:40 --> Model "Login_model" initialized
INFO - 2021-11-30 07:02:40 --> Model "Dashboard_model" initialized
INFO - 2021-11-30 07:02:40 --> Model "Case_model" initialized
INFO - 2021-11-30 07:02:47 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2021-11-30 07:02:47 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-11-30 07:02:47 --> Final output sent to browser
DEBUG - 2021-11-30 07:02:47 --> Total execution time: 24.6139
ERROR - 2021-11-30 07:02:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-30 07:02:49 --> Config Class Initialized
INFO - 2021-11-30 07:02:49 --> Hooks Class Initialized
DEBUG - 2021-11-30 07:02:49 --> UTF-8 Support Enabled
INFO - 2021-11-30 07:02:49 --> Utf8 Class Initialized
INFO - 2021-11-30 07:02:49 --> URI Class Initialized
INFO - 2021-11-30 07:02:49 --> Router Class Initialized
INFO - 2021-11-30 07:02:49 --> Output Class Initialized
INFO - 2021-11-30 07:02:49 --> Security Class Initialized
DEBUG - 2021-11-30 07:02:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-30 07:02:49 --> Input Class Initialized
INFO - 2021-11-30 07:02:49 --> Language Class Initialized
ERROR - 2021-11-30 07:02:49 --> 404 Page Not Found: Karoclient/usersprofile
INFO - 2021-11-30 07:02:56 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-11-30 07:03:09 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2021-11-30 07:03:09 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-11-30 07:03:09 --> Final output sent to browser
DEBUG - 2021-11-30 07:03:09 --> Total execution time: 28.1473
ERROR - 2021-11-30 07:03:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-30 07:03:11 --> Config Class Initialized
INFO - 2021-11-30 07:03:11 --> Hooks Class Initialized
DEBUG - 2021-11-30 07:03:11 --> UTF-8 Support Enabled
INFO - 2021-11-30 07:03:11 --> Utf8 Class Initialized
INFO - 2021-11-30 07:03:11 --> URI Class Initialized
INFO - 2021-11-30 07:03:11 --> Router Class Initialized
INFO - 2021-11-30 07:03:11 --> Output Class Initialized
INFO - 2021-11-30 07:03:11 --> Security Class Initialized
DEBUG - 2021-11-30 07:03:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-30 07:03:11 --> Input Class Initialized
INFO - 2021-11-30 07:03:11 --> Language Class Initialized
ERROR - 2021-11-30 07:03:11 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-11-30 07:04:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-30 07:04:20 --> Config Class Initialized
INFO - 2021-11-30 07:04:20 --> Hooks Class Initialized
DEBUG - 2021-11-30 07:04:20 --> UTF-8 Support Enabled
INFO - 2021-11-30 07:04:20 --> Utf8 Class Initialized
INFO - 2021-11-30 07:04:20 --> URI Class Initialized
DEBUG - 2021-11-30 07:04:20 --> No URI present. Default controller set.
INFO - 2021-11-30 07:04:20 --> Router Class Initialized
INFO - 2021-11-30 07:04:20 --> Output Class Initialized
INFO - 2021-11-30 07:04:20 --> Security Class Initialized
DEBUG - 2021-11-30 07:04:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-30 07:04:20 --> Input Class Initialized
INFO - 2021-11-30 07:04:20 --> Language Class Initialized
INFO - 2021-11-30 07:04:20 --> Loader Class Initialized
INFO - 2021-11-30 07:04:20 --> Helper loaded: url_helper
INFO - 2021-11-30 07:04:20 --> Helper loaded: form_helper
INFO - 2021-11-30 07:04:20 --> Helper loaded: common_helper
INFO - 2021-11-30 07:04:20 --> Database Driver Class Initialized
DEBUG - 2021-11-30 07:04:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-30 07:04:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-30 07:04:21 --> Controller Class Initialized
INFO - 2021-11-30 07:04:21 --> Form Validation Class Initialized
DEBUG - 2021-11-30 07:04:21 --> Encrypt Class Initialized
DEBUG - 2021-11-30 07:04:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-30 07:04:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-30 07:04:21 --> Email Class Initialized
INFO - 2021-11-30 07:04:21 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-30 07:04:21 --> Calendar Class Initialized
INFO - 2021-11-30 07:04:21 --> Model "Login_model" initialized
INFO - 2021-11-30 07:04:21 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-11-30 07:04:21 --> Final output sent to browser
DEBUG - 2021-11-30 07:04:21 --> Total execution time: 0.0244
ERROR - 2021-11-30 07:04:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-30 07:04:29 --> Config Class Initialized
INFO - 2021-11-30 07:04:29 --> Hooks Class Initialized
DEBUG - 2021-11-30 07:04:29 --> UTF-8 Support Enabled
INFO - 2021-11-30 07:04:29 --> Utf8 Class Initialized
INFO - 2021-11-30 07:04:29 --> URI Class Initialized
DEBUG - 2021-11-30 07:04:29 --> No URI present. Default controller set.
INFO - 2021-11-30 07:04:29 --> Router Class Initialized
INFO - 2021-11-30 07:04:29 --> Output Class Initialized
INFO - 2021-11-30 07:04:29 --> Security Class Initialized
DEBUG - 2021-11-30 07:04:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-30 07:04:29 --> Input Class Initialized
INFO - 2021-11-30 07:04:29 --> Language Class Initialized
INFO - 2021-11-30 07:04:29 --> Loader Class Initialized
INFO - 2021-11-30 07:04:29 --> Helper loaded: url_helper
INFO - 2021-11-30 07:04:29 --> Helper loaded: form_helper
INFO - 2021-11-30 07:04:29 --> Helper loaded: common_helper
INFO - 2021-11-30 07:04:29 --> Database Driver Class Initialized
DEBUG - 2021-11-30 07:04:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-30 07:04:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-30 07:04:29 --> Controller Class Initialized
INFO - 2021-11-30 07:04:29 --> Form Validation Class Initialized
DEBUG - 2021-11-30 07:04:29 --> Encrypt Class Initialized
DEBUG - 2021-11-30 07:04:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-30 07:04:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-30 07:04:29 --> Email Class Initialized
INFO - 2021-11-30 07:04:29 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-30 07:04:29 --> Calendar Class Initialized
INFO - 2021-11-30 07:04:29 --> Model "Login_model" initialized
ERROR - 2021-11-30 07:04:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-30 07:04:29 --> Config Class Initialized
INFO - 2021-11-30 07:04:29 --> Hooks Class Initialized
DEBUG - 2021-11-30 07:04:29 --> UTF-8 Support Enabled
INFO - 2021-11-30 07:04:29 --> Utf8 Class Initialized
INFO - 2021-11-30 07:04:29 --> URI Class Initialized
INFO - 2021-11-30 07:04:29 --> Router Class Initialized
INFO - 2021-11-30 07:04:29 --> Output Class Initialized
INFO - 2021-11-30 07:04:29 --> Security Class Initialized
DEBUG - 2021-11-30 07:04:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-30 07:04:29 --> Input Class Initialized
INFO - 2021-11-30 07:04:29 --> Language Class Initialized
INFO - 2021-11-30 07:04:29 --> Loader Class Initialized
INFO - 2021-11-30 07:04:29 --> Helper loaded: url_helper
INFO - 2021-11-30 07:04:29 --> Helper loaded: form_helper
INFO - 2021-11-30 07:04:29 --> Helper loaded: common_helper
INFO - 2021-11-30 07:04:29 --> Database Driver Class Initialized
DEBUG - 2021-11-30 07:04:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-30 07:04:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-30 07:04:29 --> Controller Class Initialized
INFO - 2021-11-30 07:04:29 --> Form Validation Class Initialized
DEBUG - 2021-11-30 07:04:29 --> Encrypt Class Initialized
INFO - 2021-11-30 07:04:29 --> Model "Diseases_model" initialized
INFO - 2021-11-30 07:04:29 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-11-30 07:04:29 --> File loaded: /home3/karoteam/public_html/application/views/diseases/index.php
INFO - 2021-11-30 07:04:29 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-11-30 07:04:29 --> Final output sent to browser
DEBUG - 2021-11-30 07:04:29 --> Total execution time: 0.0741
ERROR - 2021-11-30 07:04:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-30 07:04:30 --> Config Class Initialized
INFO - 2021-11-30 07:04:30 --> Hooks Class Initialized
DEBUG - 2021-11-30 07:04:30 --> UTF-8 Support Enabled
INFO - 2021-11-30 07:04:30 --> Utf8 Class Initialized
INFO - 2021-11-30 07:04:30 --> URI Class Initialized
INFO - 2021-11-30 07:04:30 --> Router Class Initialized
INFO - 2021-11-30 07:04:30 --> Output Class Initialized
INFO - 2021-11-30 07:04:30 --> Security Class Initialized
DEBUG - 2021-11-30 07:04:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-30 07:04:30 --> Input Class Initialized
INFO - 2021-11-30 07:04:30 --> Language Class Initialized
ERROR - 2021-11-30 07:04:30 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-11-30 07:04:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-30 07:04:35 --> Config Class Initialized
INFO - 2021-11-30 07:04:35 --> Hooks Class Initialized
DEBUG - 2021-11-30 07:04:35 --> UTF-8 Support Enabled
INFO - 2021-11-30 07:04:35 --> Utf8 Class Initialized
INFO - 2021-11-30 07:04:35 --> URI Class Initialized
INFO - 2021-11-30 07:04:35 --> Router Class Initialized
INFO - 2021-11-30 07:04:35 --> Output Class Initialized
INFO - 2021-11-30 07:04:35 --> Security Class Initialized
DEBUG - 2021-11-30 07:04:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-30 07:04:35 --> Input Class Initialized
INFO - 2021-11-30 07:04:35 --> Language Class Initialized
INFO - 2021-11-30 07:04:35 --> Loader Class Initialized
INFO - 2021-11-30 07:04:35 --> Helper loaded: url_helper
INFO - 2021-11-30 07:04:35 --> Helper loaded: form_helper
INFO - 2021-11-30 07:04:35 --> Helper loaded: common_helper
INFO - 2021-11-30 07:04:35 --> Database Driver Class Initialized
DEBUG - 2021-11-30 07:04:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-30 07:04:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-30 07:04:35 --> Controller Class Initialized
INFO - 2021-11-30 07:04:35 --> Form Validation Class Initialized
DEBUG - 2021-11-30 07:04:35 --> Encrypt Class Initialized
INFO - 2021-11-30 07:04:35 --> Model "Login_model" initialized
INFO - 2021-11-30 07:04:35 --> Model "Dashboard_model" initialized
INFO - 2021-11-30 07:04:35 --> Model "Case_model" initialized
INFO - 2021-11-30 07:04:47 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-11-30 07:04:59 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2021-11-30 07:04:59 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-11-30 07:04:59 --> Final output sent to browser
DEBUG - 2021-11-30 07:04:59 --> Total execution time: 24.8209
ERROR - 2021-11-30 07:05:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-30 07:05:00 --> Config Class Initialized
INFO - 2021-11-30 07:05:00 --> Hooks Class Initialized
DEBUG - 2021-11-30 07:05:00 --> UTF-8 Support Enabled
INFO - 2021-11-30 07:05:00 --> Utf8 Class Initialized
INFO - 2021-11-30 07:05:00 --> URI Class Initialized
INFO - 2021-11-30 07:05:00 --> Router Class Initialized
INFO - 2021-11-30 07:05:00 --> Output Class Initialized
INFO - 2021-11-30 07:05:00 --> Security Class Initialized
DEBUG - 2021-11-30 07:05:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-30 07:05:00 --> Input Class Initialized
INFO - 2021-11-30 07:05:00 --> Language Class Initialized
ERROR - 2021-11-30 07:05:00 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-11-30 07:05:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-30 07:05:45 --> Config Class Initialized
INFO - 2021-11-30 07:05:45 --> Hooks Class Initialized
DEBUG - 2021-11-30 07:05:45 --> UTF-8 Support Enabled
INFO - 2021-11-30 07:05:45 --> Utf8 Class Initialized
INFO - 2021-11-30 07:05:45 --> URI Class Initialized
INFO - 2021-11-30 07:05:45 --> Router Class Initialized
INFO - 2021-11-30 07:05:45 --> Output Class Initialized
INFO - 2021-11-30 07:05:45 --> Security Class Initialized
DEBUG - 2021-11-30 07:05:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-30 07:05:45 --> Input Class Initialized
INFO - 2021-11-30 07:05:45 --> Language Class Initialized
INFO - 2021-11-30 07:05:45 --> Loader Class Initialized
INFO - 2021-11-30 07:05:45 --> Helper loaded: url_helper
INFO - 2021-11-30 07:05:45 --> Helper loaded: form_helper
INFO - 2021-11-30 07:05:45 --> Helper loaded: common_helper
INFO - 2021-11-30 07:05:45 --> Database Driver Class Initialized
DEBUG - 2021-11-30 07:05:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-30 07:05:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-30 07:05:45 --> Controller Class Initialized
INFO - 2021-11-30 07:05:45 --> Form Validation Class Initialized
DEBUG - 2021-11-30 07:05:45 --> Encrypt Class Initialized
INFO - 2021-11-30 07:05:45 --> Model "Login_model" initialized
INFO - 2021-11-30 07:05:45 --> Model "Dashboard_model" initialized
INFO - 2021-11-30 07:05:45 --> Model "Case_model" initialized
INFO - 2021-11-30 07:05:45 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-11-30 07:05:45 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/birthday.php
INFO - 2021-11-30 07:05:45 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-11-30 07:05:45 --> Final output sent to browser
DEBUG - 2021-11-30 07:05:45 --> Total execution time: 0.0445
ERROR - 2021-11-30 07:05:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-30 07:05:46 --> Config Class Initialized
INFO - 2021-11-30 07:05:46 --> Hooks Class Initialized
DEBUG - 2021-11-30 07:05:46 --> UTF-8 Support Enabled
INFO - 2021-11-30 07:05:46 --> Utf8 Class Initialized
INFO - 2021-11-30 07:05:46 --> URI Class Initialized
INFO - 2021-11-30 07:05:46 --> Router Class Initialized
INFO - 2021-11-30 07:05:46 --> Output Class Initialized
INFO - 2021-11-30 07:05:46 --> Security Class Initialized
DEBUG - 2021-11-30 07:05:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-30 07:05:46 --> Input Class Initialized
INFO - 2021-11-30 07:05:46 --> Language Class Initialized
ERROR - 2021-11-30 07:05:46 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-11-30 07:06:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-30 07:06:09 --> Config Class Initialized
INFO - 2021-11-30 07:06:09 --> Hooks Class Initialized
DEBUG - 2021-11-30 07:06:09 --> UTF-8 Support Enabled
INFO - 2021-11-30 07:06:09 --> Utf8 Class Initialized
INFO - 2021-11-30 07:06:09 --> URI Class Initialized
INFO - 2021-11-30 07:06:09 --> Router Class Initialized
INFO - 2021-11-30 07:06:09 --> Output Class Initialized
INFO - 2021-11-30 07:06:09 --> Security Class Initialized
DEBUG - 2021-11-30 07:06:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-30 07:06:09 --> Input Class Initialized
INFO - 2021-11-30 07:06:09 --> Language Class Initialized
INFO - 2021-11-30 07:06:09 --> Loader Class Initialized
INFO - 2021-11-30 07:06:09 --> Helper loaded: url_helper
INFO - 2021-11-30 07:06:09 --> Helper loaded: form_helper
INFO - 2021-11-30 07:06:09 --> Helper loaded: common_helper
INFO - 2021-11-30 07:06:09 --> Database Driver Class Initialized
DEBUG - 2021-11-30 07:06:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-30 07:06:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-30 07:06:09 --> Controller Class Initialized
INFO - 2021-11-30 07:06:09 --> Form Validation Class Initialized
INFO - 2021-11-30 07:06:09 --> Model "Case_model" initialized
INFO - 2021-11-30 07:06:09 --> Model "Hospital_model" initialized
INFO - 2021-11-30 07:06:09 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-11-30 07:06:09 --> File loaded: /home3/karoteam/public_html/application/views/transaction/upcomingFollowup.php
INFO - 2021-11-30 07:06:09 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-11-30 07:06:09 --> Final output sent to browser
DEBUG - 2021-11-30 07:06:09 --> Total execution time: 0.0372
ERROR - 2021-11-30 07:06:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-30 07:06:10 --> Config Class Initialized
INFO - 2021-11-30 07:06:10 --> Hooks Class Initialized
DEBUG - 2021-11-30 07:06:10 --> UTF-8 Support Enabled
INFO - 2021-11-30 07:06:10 --> Utf8 Class Initialized
INFO - 2021-11-30 07:06:10 --> URI Class Initialized
INFO - 2021-11-30 07:06:10 --> Router Class Initialized
INFO - 2021-11-30 07:06:10 --> Output Class Initialized
INFO - 2021-11-30 07:06:10 --> Security Class Initialized
DEBUG - 2021-11-30 07:06:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-30 07:06:10 --> Input Class Initialized
INFO - 2021-11-30 07:06:10 --> Language Class Initialized
ERROR - 2021-11-30 07:06:10 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-11-30 07:06:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-30 07:06:36 --> Config Class Initialized
INFO - 2021-11-30 07:06:36 --> Hooks Class Initialized
DEBUG - 2021-11-30 07:06:36 --> UTF-8 Support Enabled
INFO - 2021-11-30 07:06:36 --> Utf8 Class Initialized
INFO - 2021-11-30 07:06:36 --> URI Class Initialized
INFO - 2021-11-30 07:06:36 --> Router Class Initialized
INFO - 2021-11-30 07:06:36 --> Output Class Initialized
INFO - 2021-11-30 07:06:36 --> Security Class Initialized
DEBUG - 2021-11-30 07:06:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-30 07:06:36 --> Input Class Initialized
INFO - 2021-11-30 07:06:36 --> Language Class Initialized
INFO - 2021-11-30 07:06:36 --> Loader Class Initialized
INFO - 2021-11-30 07:06:36 --> Helper loaded: url_helper
INFO - 2021-11-30 07:06:36 --> Helper loaded: form_helper
INFO - 2021-11-30 07:06:36 --> Helper loaded: common_helper
INFO - 2021-11-30 07:06:36 --> Database Driver Class Initialized
DEBUG - 2021-11-30 07:06:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-30 07:06:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-30 07:06:36 --> Controller Class Initialized
INFO - 2021-11-30 07:06:36 --> Form Validation Class Initialized
INFO - 2021-11-30 07:06:36 --> Model "Case_model" initialized
INFO - 2021-11-30 07:06:41 --> Model "Hospital_model" initialized
INFO - 2021-11-30 07:06:41 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-11-30 07:06:41 --> File loaded: /home3/karoteam/public_html/application/views/transaction/upcomingFollowup.php
INFO - 2021-11-30 07:06:41 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-11-30 07:06:41 --> Final output sent to browser
DEBUG - 2021-11-30 07:06:41 --> Total execution time: 5.4125
ERROR - 2021-11-30 07:06:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-30 07:06:43 --> Config Class Initialized
INFO - 2021-11-30 07:06:43 --> Hooks Class Initialized
DEBUG - 2021-11-30 07:06:43 --> UTF-8 Support Enabled
INFO - 2021-11-30 07:06:43 --> Utf8 Class Initialized
INFO - 2021-11-30 07:06:43 --> URI Class Initialized
INFO - 2021-11-30 07:06:43 --> Router Class Initialized
INFO - 2021-11-30 07:06:43 --> Output Class Initialized
INFO - 2021-11-30 07:06:43 --> Security Class Initialized
DEBUG - 2021-11-30 07:06:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-30 07:06:43 --> Input Class Initialized
INFO - 2021-11-30 07:06:43 --> Language Class Initialized
ERROR - 2021-11-30 07:06:43 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-11-30 07:06:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-30 07:06:50 --> Config Class Initialized
INFO - 2021-11-30 07:06:50 --> Hooks Class Initialized
DEBUG - 2021-11-30 07:06:50 --> UTF-8 Support Enabled
INFO - 2021-11-30 07:06:50 --> Utf8 Class Initialized
INFO - 2021-11-30 07:06:50 --> URI Class Initialized
INFO - 2021-11-30 07:06:50 --> Router Class Initialized
INFO - 2021-11-30 07:06:50 --> Output Class Initialized
INFO - 2021-11-30 07:06:50 --> Security Class Initialized
DEBUG - 2021-11-30 07:06:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-30 07:06:50 --> Input Class Initialized
INFO - 2021-11-30 07:06:50 --> Language Class Initialized
INFO - 2021-11-30 07:06:50 --> Loader Class Initialized
INFO - 2021-11-30 07:06:50 --> Helper loaded: url_helper
INFO - 2021-11-30 07:06:50 --> Helper loaded: form_helper
INFO - 2021-11-30 07:06:50 --> Helper loaded: common_helper
INFO - 2021-11-30 07:06:50 --> Database Driver Class Initialized
DEBUG - 2021-11-30 07:06:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-30 07:06:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-30 07:06:50 --> Controller Class Initialized
INFO - 2021-11-30 07:06:50 --> Form Validation Class Initialized
INFO - 2021-11-30 07:06:50 --> Model "Case_model" initialized
INFO - 2021-11-30 07:06:56 --> Model "Hospital_model" initialized
INFO - 2021-11-30 07:06:56 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-11-30 07:06:56 --> File loaded: /home3/karoteam/public_html/application/views/transaction/upcomingFollowup.php
INFO - 2021-11-30 07:06:56 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-11-30 07:06:56 --> Final output sent to browser
DEBUG - 2021-11-30 07:06:56 --> Total execution time: 5.4510
ERROR - 2021-11-30 07:06:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-30 07:06:57 --> Config Class Initialized
INFO - 2021-11-30 07:06:57 --> Hooks Class Initialized
DEBUG - 2021-11-30 07:06:57 --> UTF-8 Support Enabled
INFO - 2021-11-30 07:06:57 --> Utf8 Class Initialized
INFO - 2021-11-30 07:06:57 --> URI Class Initialized
INFO - 2021-11-30 07:06:57 --> Router Class Initialized
INFO - 2021-11-30 07:06:57 --> Output Class Initialized
INFO - 2021-11-30 07:06:57 --> Security Class Initialized
DEBUG - 2021-11-30 07:06:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-30 07:06:57 --> Input Class Initialized
INFO - 2021-11-30 07:06:57 --> Language Class Initialized
ERROR - 2021-11-30 07:06:57 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-11-30 07:07:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-30 07:07:07 --> Config Class Initialized
INFO - 2021-11-30 07:07:07 --> Hooks Class Initialized
DEBUG - 2021-11-30 07:07:07 --> UTF-8 Support Enabled
INFO - 2021-11-30 07:07:07 --> Utf8 Class Initialized
INFO - 2021-11-30 07:07:07 --> URI Class Initialized
INFO - 2021-11-30 07:07:07 --> Router Class Initialized
INFO - 2021-11-30 07:07:07 --> Output Class Initialized
INFO - 2021-11-30 07:07:07 --> Security Class Initialized
DEBUG - 2021-11-30 07:07:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-30 07:07:07 --> Input Class Initialized
INFO - 2021-11-30 07:07:07 --> Language Class Initialized
INFO - 2021-11-30 07:07:07 --> Loader Class Initialized
INFO - 2021-11-30 07:07:07 --> Helper loaded: url_helper
INFO - 2021-11-30 07:07:07 --> Helper loaded: form_helper
INFO - 2021-11-30 07:07:07 --> Helper loaded: common_helper
INFO - 2021-11-30 07:07:07 --> Database Driver Class Initialized
DEBUG - 2021-11-30 07:07:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-30 07:07:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-30 07:07:07 --> Controller Class Initialized
INFO - 2021-11-30 07:07:07 --> Form Validation Class Initialized
INFO - 2021-11-30 07:07:07 --> Model "Case_model" initialized
INFO - 2021-11-30 07:07:12 --> Model "Hospital_model" initialized
INFO - 2021-11-30 07:07:12 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-11-30 07:07:12 --> File loaded: /home3/karoteam/public_html/application/views/transaction/upcomingFollowup.php
INFO - 2021-11-30 07:07:12 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-11-30 07:07:12 --> Final output sent to browser
DEBUG - 2021-11-30 07:07:12 --> Total execution time: 5.5191
ERROR - 2021-11-30 07:07:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-30 07:07:13 --> Config Class Initialized
INFO - 2021-11-30 07:07:13 --> Hooks Class Initialized
DEBUG - 2021-11-30 07:07:13 --> UTF-8 Support Enabled
INFO - 2021-11-30 07:07:13 --> Utf8 Class Initialized
INFO - 2021-11-30 07:07:13 --> URI Class Initialized
INFO - 2021-11-30 07:07:13 --> Router Class Initialized
INFO - 2021-11-30 07:07:13 --> Output Class Initialized
INFO - 2021-11-30 07:07:13 --> Security Class Initialized
DEBUG - 2021-11-30 07:07:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-30 07:07:13 --> Input Class Initialized
INFO - 2021-11-30 07:07:13 --> Language Class Initialized
ERROR - 2021-11-30 07:07:13 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-11-30 07:07:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-30 07:07:24 --> Config Class Initialized
INFO - 2021-11-30 07:07:24 --> Hooks Class Initialized
DEBUG - 2021-11-30 07:07:24 --> UTF-8 Support Enabled
INFO - 2021-11-30 07:07:24 --> Utf8 Class Initialized
INFO - 2021-11-30 07:07:24 --> URI Class Initialized
INFO - 2021-11-30 07:07:24 --> Router Class Initialized
INFO - 2021-11-30 07:07:24 --> Output Class Initialized
INFO - 2021-11-30 07:07:24 --> Security Class Initialized
DEBUG - 2021-11-30 07:07:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-30 07:07:24 --> Input Class Initialized
INFO - 2021-11-30 07:07:24 --> Language Class Initialized
INFO - 2021-11-30 07:07:24 --> Loader Class Initialized
INFO - 2021-11-30 07:07:24 --> Helper loaded: url_helper
INFO - 2021-11-30 07:07:24 --> Helper loaded: form_helper
INFO - 2021-11-30 07:07:24 --> Helper loaded: common_helper
INFO - 2021-11-30 07:07:24 --> Database Driver Class Initialized
DEBUG - 2021-11-30 07:07:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-30 07:07:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-30 07:07:24 --> Controller Class Initialized
INFO - 2021-11-30 07:07:24 --> Form Validation Class Initialized
INFO - 2021-11-30 07:07:24 --> Model "Case_model" initialized
INFO - 2021-11-30 07:07:24 --> Model "Hospital_model" initialized
INFO - 2021-11-30 07:07:24 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-11-30 07:07:24 --> File loaded: /home3/karoteam/public_html/application/views/transaction/refund_amount.php
INFO - 2021-11-30 07:07:24 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-11-30 07:07:24 --> Final output sent to browser
DEBUG - 2021-11-30 07:07:24 --> Total execution time: 0.0350
ERROR - 2021-11-30 07:07:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-30 07:07:25 --> Config Class Initialized
INFO - 2021-11-30 07:07:25 --> Hooks Class Initialized
DEBUG - 2021-11-30 07:07:25 --> UTF-8 Support Enabled
INFO - 2021-11-30 07:07:25 --> Utf8 Class Initialized
INFO - 2021-11-30 07:07:25 --> URI Class Initialized
INFO - 2021-11-30 07:07:25 --> Router Class Initialized
INFO - 2021-11-30 07:07:25 --> Output Class Initialized
INFO - 2021-11-30 07:07:25 --> Security Class Initialized
DEBUG - 2021-11-30 07:07:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-30 07:07:25 --> Input Class Initialized
INFO - 2021-11-30 07:07:25 --> Language Class Initialized
ERROR - 2021-11-30 07:07:25 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-11-30 09:41:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-30 09:41:12 --> Config Class Initialized
INFO - 2021-11-30 09:41:12 --> Hooks Class Initialized
DEBUG - 2021-11-30 09:41:12 --> UTF-8 Support Enabled
INFO - 2021-11-30 09:41:12 --> Utf8 Class Initialized
INFO - 2021-11-30 09:41:12 --> URI Class Initialized
DEBUG - 2021-11-30 09:41:12 --> No URI present. Default controller set.
INFO - 2021-11-30 09:41:12 --> Router Class Initialized
INFO - 2021-11-30 09:41:12 --> Output Class Initialized
INFO - 2021-11-30 09:41:12 --> Security Class Initialized
DEBUG - 2021-11-30 09:41:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-30 09:41:12 --> Input Class Initialized
INFO - 2021-11-30 09:41:12 --> Language Class Initialized
INFO - 2021-11-30 09:41:12 --> Loader Class Initialized
INFO - 2021-11-30 09:41:12 --> Helper loaded: url_helper
INFO - 2021-11-30 09:41:12 --> Helper loaded: form_helper
INFO - 2021-11-30 09:41:12 --> Helper loaded: common_helper
INFO - 2021-11-30 09:41:12 --> Database Driver Class Initialized
DEBUG - 2021-11-30 09:41:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-30 09:41:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-30 09:41:12 --> Controller Class Initialized
INFO - 2021-11-30 09:41:12 --> Form Validation Class Initialized
DEBUG - 2021-11-30 09:41:12 --> Encrypt Class Initialized
DEBUG - 2021-11-30 09:41:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-30 09:41:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-30 09:41:12 --> Email Class Initialized
INFO - 2021-11-30 09:41:12 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-30 09:41:12 --> Calendar Class Initialized
INFO - 2021-11-30 09:41:12 --> Model "Login_model" initialized
INFO - 2021-11-30 09:41:12 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-11-30 09:41:12 --> Final output sent to browser
DEBUG - 2021-11-30 09:41:12 --> Total execution time: 0.0225
ERROR - 2021-11-30 10:45:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-30 10:45:22 --> Config Class Initialized
INFO - 2021-11-30 10:45:22 --> Hooks Class Initialized
DEBUG - 2021-11-30 10:45:22 --> UTF-8 Support Enabled
INFO - 2021-11-30 10:45:22 --> Utf8 Class Initialized
INFO - 2021-11-30 10:45:22 --> URI Class Initialized
DEBUG - 2021-11-30 10:45:22 --> No URI present. Default controller set.
INFO - 2021-11-30 10:45:22 --> Router Class Initialized
INFO - 2021-11-30 10:45:22 --> Output Class Initialized
INFO - 2021-11-30 10:45:22 --> Security Class Initialized
DEBUG - 2021-11-30 10:45:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-30 10:45:22 --> Input Class Initialized
INFO - 2021-11-30 10:45:22 --> Language Class Initialized
INFO - 2021-11-30 10:45:22 --> Loader Class Initialized
INFO - 2021-11-30 10:45:22 --> Helper loaded: url_helper
INFO - 2021-11-30 10:45:22 --> Helper loaded: form_helper
INFO - 2021-11-30 10:45:22 --> Helper loaded: common_helper
INFO - 2021-11-30 10:45:22 --> Database Driver Class Initialized
DEBUG - 2021-11-30 10:45:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-30 10:45:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-30 10:45:22 --> Controller Class Initialized
INFO - 2021-11-30 10:45:22 --> Form Validation Class Initialized
DEBUG - 2021-11-30 10:45:22 --> Encrypt Class Initialized
DEBUG - 2021-11-30 10:45:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-30 10:45:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-30 10:45:22 --> Email Class Initialized
INFO - 2021-11-30 10:45:22 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-30 10:45:22 --> Calendar Class Initialized
INFO - 2021-11-30 10:45:22 --> Model "Login_model" initialized
INFO - 2021-11-30 10:45:22 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-11-30 10:45:22 --> Final output sent to browser
DEBUG - 2021-11-30 10:45:22 --> Total execution time: 0.0226
ERROR - 2021-11-30 10:45:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-30 10:45:39 --> Config Class Initialized
INFO - 2021-11-30 10:45:39 --> Hooks Class Initialized
DEBUG - 2021-11-30 10:45:39 --> UTF-8 Support Enabled
INFO - 2021-11-30 10:45:39 --> Utf8 Class Initialized
INFO - 2021-11-30 10:45:39 --> URI Class Initialized
DEBUG - 2021-11-30 10:45:39 --> No URI present. Default controller set.
INFO - 2021-11-30 10:45:39 --> Router Class Initialized
INFO - 2021-11-30 10:45:39 --> Output Class Initialized
INFO - 2021-11-30 10:45:39 --> Security Class Initialized
DEBUG - 2021-11-30 10:45:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-30 10:45:39 --> Input Class Initialized
INFO - 2021-11-30 10:45:39 --> Language Class Initialized
INFO - 2021-11-30 10:45:39 --> Loader Class Initialized
INFO - 2021-11-30 10:45:39 --> Helper loaded: url_helper
INFO - 2021-11-30 10:45:39 --> Helper loaded: form_helper
INFO - 2021-11-30 10:45:39 --> Helper loaded: common_helper
INFO - 2021-11-30 10:45:39 --> Database Driver Class Initialized
DEBUG - 2021-11-30 10:45:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-30 10:45:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-30 10:45:39 --> Controller Class Initialized
INFO - 2021-11-30 10:45:39 --> Form Validation Class Initialized
DEBUG - 2021-11-30 10:45:39 --> Encrypt Class Initialized
DEBUG - 2021-11-30 10:45:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-30 10:45:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-30 10:45:39 --> Email Class Initialized
INFO - 2021-11-30 10:45:39 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-30 10:45:39 --> Calendar Class Initialized
INFO - 2021-11-30 10:45:39 --> Model "Login_model" initialized
INFO - 2021-11-30 10:45:39 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-11-30 10:45:39 --> Final output sent to browser
DEBUG - 2021-11-30 10:45:39 --> Total execution time: 0.0226
ERROR - 2021-11-30 11:37:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-30 11:37:24 --> Config Class Initialized
INFO - 2021-11-30 11:37:24 --> Hooks Class Initialized
DEBUG - 2021-11-30 11:37:24 --> UTF-8 Support Enabled
INFO - 2021-11-30 11:37:24 --> Utf8 Class Initialized
INFO - 2021-11-30 11:37:24 --> URI Class Initialized
DEBUG - 2021-11-30 11:37:24 --> No URI present. Default controller set.
INFO - 2021-11-30 11:37:24 --> Router Class Initialized
INFO - 2021-11-30 11:37:24 --> Output Class Initialized
INFO - 2021-11-30 11:37:24 --> Security Class Initialized
DEBUG - 2021-11-30 11:37:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-30 11:37:24 --> Input Class Initialized
INFO - 2021-11-30 11:37:24 --> Language Class Initialized
INFO - 2021-11-30 11:37:24 --> Loader Class Initialized
INFO - 2021-11-30 11:37:24 --> Helper loaded: url_helper
INFO - 2021-11-30 11:37:24 --> Helper loaded: form_helper
INFO - 2021-11-30 11:37:24 --> Helper loaded: common_helper
INFO - 2021-11-30 11:37:24 --> Database Driver Class Initialized
DEBUG - 2021-11-30 11:37:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-30 11:37:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-30 11:37:24 --> Controller Class Initialized
INFO - 2021-11-30 11:37:24 --> Form Validation Class Initialized
DEBUG - 2021-11-30 11:37:24 --> Encrypt Class Initialized
DEBUG - 2021-11-30 11:37:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-30 11:37:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-30 11:37:24 --> Email Class Initialized
INFO - 2021-11-30 11:37:24 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-30 11:37:24 --> Calendar Class Initialized
INFO - 2021-11-30 11:37:24 --> Model "Login_model" initialized
INFO - 2021-11-30 11:37:24 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-11-30 11:37:24 --> Final output sent to browser
DEBUG - 2021-11-30 11:37:24 --> Total execution time: 0.0260
ERROR - 2021-11-30 14:02:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-30 14:02:38 --> Config Class Initialized
INFO - 2021-11-30 14:02:38 --> Hooks Class Initialized
DEBUG - 2021-11-30 14:02:38 --> UTF-8 Support Enabled
INFO - 2021-11-30 14:02:38 --> Utf8 Class Initialized
INFO - 2021-11-30 14:02:38 --> URI Class Initialized
DEBUG - 2021-11-30 14:02:38 --> No URI present. Default controller set.
INFO - 2021-11-30 14:02:38 --> Router Class Initialized
INFO - 2021-11-30 14:02:38 --> Output Class Initialized
INFO - 2021-11-30 14:02:38 --> Security Class Initialized
DEBUG - 2021-11-30 14:02:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-30 14:02:38 --> Input Class Initialized
INFO - 2021-11-30 14:02:38 --> Language Class Initialized
INFO - 2021-11-30 14:02:38 --> Loader Class Initialized
INFO - 2021-11-30 14:02:38 --> Helper loaded: url_helper
INFO - 2021-11-30 14:02:38 --> Helper loaded: form_helper
INFO - 2021-11-30 14:02:38 --> Helper loaded: common_helper
INFO - 2021-11-30 14:02:38 --> Database Driver Class Initialized
DEBUG - 2021-11-30 14:02:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-30 14:02:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-30 14:02:38 --> Controller Class Initialized
INFO - 2021-11-30 14:02:38 --> Form Validation Class Initialized
DEBUG - 2021-11-30 14:02:38 --> Encrypt Class Initialized
DEBUG - 2021-11-30 14:02:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-30 14:02:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-30 14:02:38 --> Email Class Initialized
INFO - 2021-11-30 14:02:38 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-30 14:02:38 --> Calendar Class Initialized
INFO - 2021-11-30 14:02:38 --> Model "Login_model" initialized
INFO - 2021-11-30 14:02:38 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-11-30 14:02:38 --> Final output sent to browser
DEBUG - 2021-11-30 14:02:38 --> Total execution time: 0.0240
ERROR - 2021-11-30 14:17:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-30 14:17:43 --> Config Class Initialized
INFO - 2021-11-30 14:17:43 --> Hooks Class Initialized
DEBUG - 2021-11-30 14:17:43 --> UTF-8 Support Enabled
INFO - 2021-11-30 14:17:43 --> Utf8 Class Initialized
INFO - 2021-11-30 14:17:43 --> URI Class Initialized
DEBUG - 2021-11-30 14:17:43 --> No URI present. Default controller set.
INFO - 2021-11-30 14:17:43 --> Router Class Initialized
INFO - 2021-11-30 14:17:43 --> Output Class Initialized
INFO - 2021-11-30 14:17:43 --> Security Class Initialized
DEBUG - 2021-11-30 14:17:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-30 14:17:43 --> Input Class Initialized
INFO - 2021-11-30 14:17:43 --> Language Class Initialized
INFO - 2021-11-30 14:17:43 --> Loader Class Initialized
INFO - 2021-11-30 14:17:43 --> Helper loaded: url_helper
INFO - 2021-11-30 14:17:43 --> Helper loaded: form_helper
INFO - 2021-11-30 14:17:43 --> Helper loaded: common_helper
INFO - 2021-11-30 14:17:43 --> Database Driver Class Initialized
DEBUG - 2021-11-30 14:17:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-30 14:17:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-30 14:17:43 --> Controller Class Initialized
INFO - 2021-11-30 14:17:43 --> Form Validation Class Initialized
DEBUG - 2021-11-30 14:17:43 --> Encrypt Class Initialized
DEBUG - 2021-11-30 14:17:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-30 14:17:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-30 14:17:43 --> Email Class Initialized
INFO - 2021-11-30 14:17:43 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-30 14:17:43 --> Calendar Class Initialized
INFO - 2021-11-30 14:17:43 --> Model "Login_model" initialized
INFO - 2021-11-30 14:17:43 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-11-30 14:17:43 --> Final output sent to browser
DEBUG - 2021-11-30 14:17:43 --> Total execution time: 0.0223
ERROR - 2021-11-30 14:17:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-30 14:17:43 --> Config Class Initialized
INFO - 2021-11-30 14:17:43 --> Hooks Class Initialized
DEBUG - 2021-11-30 14:17:43 --> UTF-8 Support Enabled
INFO - 2021-11-30 14:17:43 --> Utf8 Class Initialized
INFO - 2021-11-30 14:17:43 --> URI Class Initialized
INFO - 2021-11-30 14:17:43 --> Router Class Initialized
INFO - 2021-11-30 14:17:43 --> Output Class Initialized
INFO - 2021-11-30 14:17:43 --> Security Class Initialized
DEBUG - 2021-11-30 14:17:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-30 14:17:43 --> Input Class Initialized
INFO - 2021-11-30 14:17:43 --> Language Class Initialized
ERROR - 2021-11-30 14:17:43 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2021-11-30 14:18:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-30 14:18:06 --> Config Class Initialized
INFO - 2021-11-30 14:18:06 --> Hooks Class Initialized
DEBUG - 2021-11-30 14:18:06 --> UTF-8 Support Enabled
INFO - 2021-11-30 14:18:06 --> Utf8 Class Initialized
INFO - 2021-11-30 14:18:06 --> URI Class Initialized
INFO - 2021-11-30 14:18:06 --> Router Class Initialized
INFO - 2021-11-30 14:18:06 --> Output Class Initialized
INFO - 2021-11-30 14:18:06 --> Security Class Initialized
DEBUG - 2021-11-30 14:18:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-30 14:18:06 --> Input Class Initialized
INFO - 2021-11-30 14:18:06 --> Language Class Initialized
INFO - 2021-11-30 14:18:06 --> Loader Class Initialized
INFO - 2021-11-30 14:18:06 --> Helper loaded: url_helper
INFO - 2021-11-30 14:18:06 --> Helper loaded: form_helper
INFO - 2021-11-30 14:18:06 --> Helper loaded: common_helper
INFO - 2021-11-30 14:18:06 --> Database Driver Class Initialized
DEBUG - 2021-11-30 14:18:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-30 14:18:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-30 14:18:06 --> Controller Class Initialized
INFO - 2021-11-30 14:18:06 --> Form Validation Class Initialized
DEBUG - 2021-11-30 14:18:06 --> Encrypt Class Initialized
DEBUG - 2021-11-30 14:18:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-30 14:18:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-30 14:18:06 --> Email Class Initialized
INFO - 2021-11-30 14:18:06 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-30 14:18:06 --> Calendar Class Initialized
INFO - 2021-11-30 14:18:06 --> Model "Login_model" initialized
ERROR - 2021-11-30 14:18:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-30 14:18:07 --> Config Class Initialized
INFO - 2021-11-30 14:18:07 --> Hooks Class Initialized
DEBUG - 2021-11-30 14:18:07 --> UTF-8 Support Enabled
INFO - 2021-11-30 14:18:07 --> Utf8 Class Initialized
INFO - 2021-11-30 14:18:07 --> URI Class Initialized
INFO - 2021-11-30 14:18:07 --> Router Class Initialized
INFO - 2021-11-30 14:18:07 --> Output Class Initialized
INFO - 2021-11-30 14:18:07 --> Security Class Initialized
DEBUG - 2021-11-30 14:18:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-30 14:18:07 --> Input Class Initialized
INFO - 2021-11-30 14:18:07 --> Language Class Initialized
INFO - 2021-11-30 14:18:07 --> Loader Class Initialized
INFO - 2021-11-30 14:18:07 --> Helper loaded: url_helper
INFO - 2021-11-30 14:18:07 --> Helper loaded: form_helper
INFO - 2021-11-30 14:18:07 --> Helper loaded: common_helper
INFO - 2021-11-30 14:18:07 --> Database Driver Class Initialized
DEBUG - 2021-11-30 14:18:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-30 14:18:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-30 14:18:07 --> Controller Class Initialized
INFO - 2021-11-30 14:18:07 --> Form Validation Class Initialized
DEBUG - 2021-11-30 14:18:07 --> Encrypt Class Initialized
DEBUG - 2021-11-30 14:18:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-30 14:18:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-30 14:18:07 --> Email Class Initialized
INFO - 2021-11-30 14:18:07 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-30 14:18:07 --> Calendar Class Initialized
INFO - 2021-11-30 14:18:07 --> Model "Login_model" initialized
ERROR - 2021-11-30 14:18:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-30 14:18:07 --> Config Class Initialized
INFO - 2021-11-30 14:18:07 --> Hooks Class Initialized
DEBUG - 2021-11-30 14:18:07 --> UTF-8 Support Enabled
INFO - 2021-11-30 14:18:07 --> Utf8 Class Initialized
INFO - 2021-11-30 14:18:07 --> URI Class Initialized
INFO - 2021-11-30 14:18:07 --> Router Class Initialized
INFO - 2021-11-30 14:18:07 --> Output Class Initialized
INFO - 2021-11-30 14:18:07 --> Security Class Initialized
DEBUG - 2021-11-30 14:18:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-30 14:18:07 --> Input Class Initialized
INFO - 2021-11-30 14:18:07 --> Language Class Initialized
INFO - 2021-11-30 14:18:07 --> Loader Class Initialized
INFO - 2021-11-30 14:18:07 --> Helper loaded: url_helper
INFO - 2021-11-30 14:18:07 --> Helper loaded: form_helper
INFO - 2021-11-30 14:18:07 --> Helper loaded: common_helper
INFO - 2021-11-30 14:18:07 --> Database Driver Class Initialized
DEBUG - 2021-11-30 14:18:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-30 14:18:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-30 14:18:07 --> Controller Class Initialized
INFO - 2021-11-30 14:18:07 --> Form Validation Class Initialized
DEBUG - 2021-11-30 14:18:07 --> Encrypt Class Initialized
DEBUG - 2021-11-30 14:18:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-30 14:18:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-30 14:18:07 --> Email Class Initialized
INFO - 2021-11-30 14:18:07 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-30 14:18:07 --> Calendar Class Initialized
INFO - 2021-11-30 14:18:07 --> Model "Login_model" initialized
INFO - 2021-11-30 14:18:07 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-11-30 14:18:07 --> Final output sent to browser
DEBUG - 2021-11-30 14:18:07 --> Total execution time: 0.0224
ERROR - 2021-11-30 14:18:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-30 14:18:08 --> Config Class Initialized
INFO - 2021-11-30 14:18:08 --> Hooks Class Initialized
DEBUG - 2021-11-30 14:18:08 --> UTF-8 Support Enabled
INFO - 2021-11-30 14:18:08 --> Utf8 Class Initialized
INFO - 2021-11-30 14:18:08 --> URI Class Initialized
DEBUG - 2021-11-30 14:18:08 --> No URI present. Default controller set.
INFO - 2021-11-30 14:18:08 --> Router Class Initialized
INFO - 2021-11-30 14:18:08 --> Output Class Initialized
INFO - 2021-11-30 14:18:08 --> Security Class Initialized
DEBUG - 2021-11-30 14:18:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-30 14:18:08 --> Input Class Initialized
INFO - 2021-11-30 14:18:08 --> Language Class Initialized
INFO - 2021-11-30 14:18:08 --> Loader Class Initialized
INFO - 2021-11-30 14:18:08 --> Helper loaded: url_helper
INFO - 2021-11-30 14:18:08 --> Helper loaded: form_helper
INFO - 2021-11-30 14:18:08 --> Helper loaded: common_helper
INFO - 2021-11-30 14:18:08 --> Database Driver Class Initialized
DEBUG - 2021-11-30 14:18:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-30 14:18:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-30 14:18:08 --> Controller Class Initialized
INFO - 2021-11-30 14:18:08 --> Form Validation Class Initialized
DEBUG - 2021-11-30 14:18:08 --> Encrypt Class Initialized
DEBUG - 2021-11-30 14:18:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-30 14:18:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-30 14:18:08 --> Email Class Initialized
INFO - 2021-11-30 14:18:08 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-30 14:18:08 --> Calendar Class Initialized
INFO - 2021-11-30 14:18:08 --> Model "Login_model" initialized
INFO - 2021-11-30 14:18:08 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-11-30 14:18:08 --> Final output sent to browser
DEBUG - 2021-11-30 14:18:08 --> Total execution time: 0.0224
ERROR - 2021-11-30 15:45:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-30 15:45:57 --> Config Class Initialized
INFO - 2021-11-30 15:45:57 --> Hooks Class Initialized
DEBUG - 2021-11-30 15:45:57 --> UTF-8 Support Enabled
INFO - 2021-11-30 15:45:57 --> Utf8 Class Initialized
INFO - 2021-11-30 15:45:57 --> URI Class Initialized
DEBUG - 2021-11-30 15:45:57 --> No URI present. Default controller set.
INFO - 2021-11-30 15:45:57 --> Router Class Initialized
INFO - 2021-11-30 15:45:57 --> Output Class Initialized
INFO - 2021-11-30 15:45:57 --> Security Class Initialized
DEBUG - 2021-11-30 15:45:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-30 15:45:57 --> Input Class Initialized
INFO - 2021-11-30 15:45:57 --> Language Class Initialized
INFO - 2021-11-30 15:45:57 --> Loader Class Initialized
INFO - 2021-11-30 15:45:57 --> Helper loaded: url_helper
INFO - 2021-11-30 15:45:57 --> Helper loaded: form_helper
INFO - 2021-11-30 15:45:57 --> Helper loaded: common_helper
INFO - 2021-11-30 15:45:57 --> Database Driver Class Initialized
DEBUG - 2021-11-30 15:45:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-30 15:45:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-30 15:45:57 --> Controller Class Initialized
INFO - 2021-11-30 15:45:57 --> Form Validation Class Initialized
DEBUG - 2021-11-30 15:45:57 --> Encrypt Class Initialized
DEBUG - 2021-11-30 15:45:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-30 15:45:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-30 15:45:57 --> Email Class Initialized
INFO - 2021-11-30 15:45:57 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-30 15:45:57 --> Calendar Class Initialized
INFO - 2021-11-30 15:45:57 --> Model "Login_model" initialized
INFO - 2021-11-30 15:45:57 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-11-30 15:45:57 --> Final output sent to browser
DEBUG - 2021-11-30 15:45:57 --> Total execution time: 0.0241
ERROR - 2021-11-30 18:57:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-30 18:57:52 --> Config Class Initialized
INFO - 2021-11-30 18:57:52 --> Hooks Class Initialized
DEBUG - 2021-11-30 18:57:52 --> UTF-8 Support Enabled
INFO - 2021-11-30 18:57:52 --> Utf8 Class Initialized
INFO - 2021-11-30 18:57:52 --> URI Class Initialized
DEBUG - 2021-11-30 18:57:52 --> No URI present. Default controller set.
INFO - 2021-11-30 18:57:52 --> Router Class Initialized
INFO - 2021-11-30 18:57:52 --> Output Class Initialized
INFO - 2021-11-30 18:57:52 --> Security Class Initialized
DEBUG - 2021-11-30 18:57:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-30 18:57:52 --> Input Class Initialized
INFO - 2021-11-30 18:57:52 --> Language Class Initialized
INFO - 2021-11-30 18:57:52 --> Loader Class Initialized
INFO - 2021-11-30 18:57:52 --> Helper loaded: url_helper
INFO - 2021-11-30 18:57:52 --> Helper loaded: form_helper
INFO - 2021-11-30 18:57:52 --> Helper loaded: common_helper
INFO - 2021-11-30 18:57:52 --> Database Driver Class Initialized
DEBUG - 2021-11-30 18:57:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-30 18:57:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-30 18:57:52 --> Controller Class Initialized
INFO - 2021-11-30 18:57:52 --> Form Validation Class Initialized
DEBUG - 2021-11-30 18:57:52 --> Encrypt Class Initialized
DEBUG - 2021-11-30 18:57:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-30 18:57:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-30 18:57:52 --> Email Class Initialized
INFO - 2021-11-30 18:57:52 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-30 18:57:52 --> Calendar Class Initialized
INFO - 2021-11-30 18:57:52 --> Model "Login_model" initialized
INFO - 2021-11-30 18:57:52 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-11-30 18:57:52 --> Final output sent to browser
DEBUG - 2021-11-30 18:57:52 --> Total execution time: 0.0263
ERROR - 2021-11-30 18:57:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-30 18:57:52 --> Config Class Initialized
INFO - 2021-11-30 18:57:52 --> Hooks Class Initialized
DEBUG - 2021-11-30 18:57:52 --> UTF-8 Support Enabled
INFO - 2021-11-30 18:57:52 --> Utf8 Class Initialized
INFO - 2021-11-30 18:57:52 --> URI Class Initialized
DEBUG - 2021-11-30 18:57:52 --> No URI present. Default controller set.
INFO - 2021-11-30 18:57:52 --> Router Class Initialized
INFO - 2021-11-30 18:57:52 --> Output Class Initialized
INFO - 2021-11-30 18:57:52 --> Security Class Initialized
DEBUG - 2021-11-30 18:57:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-30 18:57:52 --> Input Class Initialized
INFO - 2021-11-30 18:57:52 --> Language Class Initialized
INFO - 2021-11-30 18:57:52 --> Loader Class Initialized
INFO - 2021-11-30 18:57:52 --> Helper loaded: url_helper
INFO - 2021-11-30 18:57:52 --> Helper loaded: form_helper
INFO - 2021-11-30 18:57:52 --> Helper loaded: common_helper
INFO - 2021-11-30 18:57:52 --> Database Driver Class Initialized
DEBUG - 2021-11-30 18:57:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-30 18:57:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-30 18:57:52 --> Controller Class Initialized
INFO - 2021-11-30 18:57:52 --> Form Validation Class Initialized
DEBUG - 2021-11-30 18:57:52 --> Encrypt Class Initialized
DEBUG - 2021-11-30 18:57:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-30 18:57:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-30 18:57:52 --> Email Class Initialized
INFO - 2021-11-30 18:57:52 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-30 18:57:52 --> Calendar Class Initialized
INFO - 2021-11-30 18:57:52 --> Model "Login_model" initialized
INFO - 2021-11-30 18:57:52 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-11-30 18:57:52 --> Final output sent to browser
DEBUG - 2021-11-30 18:57:52 --> Total execution time: 0.0216
ERROR - 2021-11-30 18:57:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-30 18:57:52 --> Config Class Initialized
INFO - 2021-11-30 18:57:52 --> Hooks Class Initialized
DEBUG - 2021-11-30 18:57:52 --> UTF-8 Support Enabled
INFO - 2021-11-30 18:57:52 --> Utf8 Class Initialized
INFO - 2021-11-30 18:57:52 --> URI Class Initialized
INFO - 2021-11-30 18:57:52 --> Router Class Initialized
INFO - 2021-11-30 18:57:52 --> Output Class Initialized
INFO - 2021-11-30 18:57:52 --> Security Class Initialized
DEBUG - 2021-11-30 18:57:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-30 18:57:52 --> Input Class Initialized
INFO - 2021-11-30 18:57:52 --> Language Class Initialized
ERROR - 2021-11-30 18:57:52 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
ERROR - 2021-11-30 18:57:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-30 18:57:53 --> Config Class Initialized
INFO - 2021-11-30 18:57:53 --> Hooks Class Initialized
DEBUG - 2021-11-30 18:57:53 --> UTF-8 Support Enabled
INFO - 2021-11-30 18:57:53 --> Utf8 Class Initialized
INFO - 2021-11-30 18:57:53 --> URI Class Initialized
INFO - 2021-11-30 18:57:53 --> Router Class Initialized
INFO - 2021-11-30 18:57:53 --> Output Class Initialized
INFO - 2021-11-30 18:57:53 --> Security Class Initialized
DEBUG - 2021-11-30 18:57:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-30 18:57:53 --> Input Class Initialized
INFO - 2021-11-30 18:57:53 --> Language Class Initialized
ERROR - 2021-11-30 18:57:53 --> 404 Page Not Found: Blog/wp-includes
ERROR - 2021-11-30 18:57:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-30 18:57:53 --> Config Class Initialized
INFO - 2021-11-30 18:57:53 --> Hooks Class Initialized
DEBUG - 2021-11-30 18:57:53 --> UTF-8 Support Enabled
INFO - 2021-11-30 18:57:53 --> Utf8 Class Initialized
INFO - 2021-11-30 18:57:53 --> URI Class Initialized
INFO - 2021-11-30 18:57:53 --> Router Class Initialized
INFO - 2021-11-30 18:57:53 --> Output Class Initialized
INFO - 2021-11-30 18:57:53 --> Security Class Initialized
DEBUG - 2021-11-30 18:57:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-30 18:57:53 --> Input Class Initialized
INFO - 2021-11-30 18:57:53 --> Language Class Initialized
ERROR - 2021-11-30 18:57:53 --> 404 Page Not Found: Web/wp-includes
ERROR - 2021-11-30 18:57:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-30 18:57:54 --> Config Class Initialized
INFO - 2021-11-30 18:57:54 --> Hooks Class Initialized
DEBUG - 2021-11-30 18:57:54 --> UTF-8 Support Enabled
INFO - 2021-11-30 18:57:54 --> Utf8 Class Initialized
INFO - 2021-11-30 18:57:54 --> URI Class Initialized
INFO - 2021-11-30 18:57:54 --> Router Class Initialized
INFO - 2021-11-30 18:57:54 --> Output Class Initialized
INFO - 2021-11-30 18:57:54 --> Security Class Initialized
DEBUG - 2021-11-30 18:57:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-30 18:57:54 --> Input Class Initialized
INFO - 2021-11-30 18:57:54 --> Language Class Initialized
ERROR - 2021-11-30 18:57:54 --> 404 Page Not Found: Wordpress/wp-includes
ERROR - 2021-11-30 18:57:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-30 18:57:54 --> Config Class Initialized
INFO - 2021-11-30 18:57:54 --> Hooks Class Initialized
DEBUG - 2021-11-30 18:57:54 --> UTF-8 Support Enabled
INFO - 2021-11-30 18:57:54 --> Utf8 Class Initialized
INFO - 2021-11-30 18:57:54 --> URI Class Initialized
INFO - 2021-11-30 18:57:54 --> Router Class Initialized
INFO - 2021-11-30 18:57:54 --> Output Class Initialized
INFO - 2021-11-30 18:57:54 --> Security Class Initialized
DEBUG - 2021-11-30 18:57:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-30 18:57:54 --> Input Class Initialized
INFO - 2021-11-30 18:57:54 --> Language Class Initialized
ERROR - 2021-11-30 18:57:54 --> 404 Page Not Found: Website/wp-includes
ERROR - 2021-11-30 18:57:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-30 18:57:54 --> Config Class Initialized
INFO - 2021-11-30 18:57:54 --> Hooks Class Initialized
DEBUG - 2021-11-30 18:57:54 --> UTF-8 Support Enabled
INFO - 2021-11-30 18:57:54 --> Utf8 Class Initialized
INFO - 2021-11-30 18:57:54 --> URI Class Initialized
INFO - 2021-11-30 18:57:54 --> Router Class Initialized
INFO - 2021-11-30 18:57:54 --> Output Class Initialized
INFO - 2021-11-30 18:57:54 --> Security Class Initialized
DEBUG - 2021-11-30 18:57:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-30 18:57:54 --> Input Class Initialized
INFO - 2021-11-30 18:57:54 --> Language Class Initialized
ERROR - 2021-11-30 18:57:54 --> 404 Page Not Found: Wp/wp-includes
ERROR - 2021-11-30 18:57:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-30 18:57:55 --> Config Class Initialized
INFO - 2021-11-30 18:57:55 --> Hooks Class Initialized
DEBUG - 2021-11-30 18:57:55 --> UTF-8 Support Enabled
INFO - 2021-11-30 18:57:55 --> Utf8 Class Initialized
INFO - 2021-11-30 18:57:55 --> URI Class Initialized
INFO - 2021-11-30 18:57:55 --> Router Class Initialized
INFO - 2021-11-30 18:57:55 --> Output Class Initialized
INFO - 2021-11-30 18:57:55 --> Security Class Initialized
DEBUG - 2021-11-30 18:57:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-30 18:57:55 --> Input Class Initialized
INFO - 2021-11-30 18:57:55 --> Language Class Initialized
ERROR - 2021-11-30 18:57:55 --> 404 Page Not Found: News/wp-includes
ERROR - 2021-11-30 18:57:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-30 18:57:55 --> Config Class Initialized
INFO - 2021-11-30 18:57:55 --> Hooks Class Initialized
DEBUG - 2021-11-30 18:57:55 --> UTF-8 Support Enabled
INFO - 2021-11-30 18:57:55 --> Utf8 Class Initialized
INFO - 2021-11-30 18:57:55 --> URI Class Initialized
INFO - 2021-11-30 18:57:55 --> Router Class Initialized
INFO - 2021-11-30 18:57:55 --> Output Class Initialized
INFO - 2021-11-30 18:57:55 --> Security Class Initialized
DEBUG - 2021-11-30 18:57:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-30 18:57:55 --> Input Class Initialized
INFO - 2021-11-30 18:57:55 --> Language Class Initialized
ERROR - 2021-11-30 18:57:55 --> 404 Page Not Found: 2020/wp-includes
ERROR - 2021-11-30 18:57:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-30 18:57:55 --> Config Class Initialized
INFO - 2021-11-30 18:57:55 --> Hooks Class Initialized
DEBUG - 2021-11-30 18:57:55 --> UTF-8 Support Enabled
INFO - 2021-11-30 18:57:55 --> Utf8 Class Initialized
INFO - 2021-11-30 18:57:55 --> URI Class Initialized
INFO - 2021-11-30 18:57:55 --> Router Class Initialized
INFO - 2021-11-30 18:57:55 --> Output Class Initialized
INFO - 2021-11-30 18:57:55 --> Security Class Initialized
DEBUG - 2021-11-30 18:57:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-30 18:57:55 --> Input Class Initialized
INFO - 2021-11-30 18:57:55 --> Language Class Initialized
ERROR - 2021-11-30 18:57:55 --> 404 Page Not Found: 2019/wp-includes
ERROR - 2021-11-30 18:57:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-30 18:57:56 --> Config Class Initialized
INFO - 2021-11-30 18:57:56 --> Hooks Class Initialized
DEBUG - 2021-11-30 18:57:56 --> UTF-8 Support Enabled
INFO - 2021-11-30 18:57:56 --> Utf8 Class Initialized
INFO - 2021-11-30 18:57:56 --> URI Class Initialized
INFO - 2021-11-30 18:57:56 --> Router Class Initialized
INFO - 2021-11-30 18:57:56 --> Output Class Initialized
INFO - 2021-11-30 18:57:56 --> Security Class Initialized
DEBUG - 2021-11-30 18:57:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-30 18:57:56 --> Input Class Initialized
INFO - 2021-11-30 18:57:56 --> Language Class Initialized
ERROR - 2021-11-30 18:57:56 --> 404 Page Not Found: Shop/wp-includes
ERROR - 2021-11-30 18:57:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-30 18:57:56 --> Config Class Initialized
INFO - 2021-11-30 18:57:56 --> Hooks Class Initialized
DEBUG - 2021-11-30 18:57:56 --> UTF-8 Support Enabled
INFO - 2021-11-30 18:57:56 --> Utf8 Class Initialized
INFO - 2021-11-30 18:57:56 --> URI Class Initialized
INFO - 2021-11-30 18:57:56 --> Router Class Initialized
INFO - 2021-11-30 18:57:56 --> Output Class Initialized
INFO - 2021-11-30 18:57:56 --> Security Class Initialized
DEBUG - 2021-11-30 18:57:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-30 18:57:56 --> Input Class Initialized
INFO - 2021-11-30 18:57:56 --> Language Class Initialized
ERROR - 2021-11-30 18:57:56 --> 404 Page Not Found: Wp1/wp-includes
ERROR - 2021-11-30 18:57:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-30 18:57:56 --> Config Class Initialized
INFO - 2021-11-30 18:57:56 --> Hooks Class Initialized
DEBUG - 2021-11-30 18:57:56 --> UTF-8 Support Enabled
INFO - 2021-11-30 18:57:56 --> Utf8 Class Initialized
INFO - 2021-11-30 18:57:56 --> URI Class Initialized
INFO - 2021-11-30 18:57:56 --> Router Class Initialized
INFO - 2021-11-30 18:57:56 --> Output Class Initialized
INFO - 2021-11-30 18:57:56 --> Security Class Initialized
DEBUG - 2021-11-30 18:57:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-30 18:57:56 --> Input Class Initialized
INFO - 2021-11-30 18:57:56 --> Language Class Initialized
ERROR - 2021-11-30 18:57:56 --> 404 Page Not Found: Test/wp-includes
ERROR - 2021-11-30 18:57:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-30 18:57:57 --> Config Class Initialized
INFO - 2021-11-30 18:57:57 --> Hooks Class Initialized
DEBUG - 2021-11-30 18:57:57 --> UTF-8 Support Enabled
INFO - 2021-11-30 18:57:57 --> Utf8 Class Initialized
INFO - 2021-11-30 18:57:57 --> URI Class Initialized
INFO - 2021-11-30 18:57:57 --> Router Class Initialized
INFO - 2021-11-30 18:57:57 --> Output Class Initialized
INFO - 2021-11-30 18:57:57 --> Security Class Initialized
DEBUG - 2021-11-30 18:57:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-30 18:57:57 --> Input Class Initialized
INFO - 2021-11-30 18:57:57 --> Language Class Initialized
ERROR - 2021-11-30 18:57:57 --> 404 Page Not Found: Wp2/wp-includes
ERROR - 2021-11-30 18:57:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-30 18:57:57 --> Config Class Initialized
INFO - 2021-11-30 18:57:57 --> Hooks Class Initialized
DEBUG - 2021-11-30 18:57:57 --> UTF-8 Support Enabled
INFO - 2021-11-30 18:57:57 --> Utf8 Class Initialized
INFO - 2021-11-30 18:57:57 --> URI Class Initialized
INFO - 2021-11-30 18:57:57 --> Router Class Initialized
INFO - 2021-11-30 18:57:57 --> Output Class Initialized
INFO - 2021-11-30 18:57:57 --> Security Class Initialized
DEBUG - 2021-11-30 18:57:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-30 18:57:57 --> Input Class Initialized
INFO - 2021-11-30 18:57:57 --> Language Class Initialized
ERROR - 2021-11-30 18:57:57 --> 404 Page Not Found: Site/wp-includes
ERROR - 2021-11-30 18:57:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-30 18:57:57 --> Config Class Initialized
INFO - 2021-11-30 18:57:57 --> Hooks Class Initialized
DEBUG - 2021-11-30 18:57:57 --> UTF-8 Support Enabled
INFO - 2021-11-30 18:57:57 --> Utf8 Class Initialized
INFO - 2021-11-30 18:57:57 --> URI Class Initialized
INFO - 2021-11-30 18:57:57 --> Router Class Initialized
INFO - 2021-11-30 18:57:57 --> Output Class Initialized
INFO - 2021-11-30 18:57:57 --> Security Class Initialized
DEBUG - 2021-11-30 18:57:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-30 18:57:57 --> Input Class Initialized
INFO - 2021-11-30 18:57:57 --> Language Class Initialized
ERROR - 2021-11-30 18:57:57 --> 404 Page Not Found: Cms/wp-includes
ERROR - 2021-11-30 18:57:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-30 18:57:58 --> Config Class Initialized
INFO - 2021-11-30 18:57:58 --> Hooks Class Initialized
DEBUG - 2021-11-30 18:57:58 --> UTF-8 Support Enabled
INFO - 2021-11-30 18:57:58 --> Utf8 Class Initialized
INFO - 2021-11-30 18:57:58 --> URI Class Initialized
INFO - 2021-11-30 18:57:58 --> Router Class Initialized
INFO - 2021-11-30 18:57:58 --> Output Class Initialized
INFO - 2021-11-30 18:57:58 --> Security Class Initialized
DEBUG - 2021-11-30 18:57:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-30 18:57:58 --> Input Class Initialized
INFO - 2021-11-30 18:57:58 --> Language Class Initialized
ERROR - 2021-11-30 18:57:58 --> 404 Page Not Found: Sito/wp-includes
ERROR - 2021-11-30 20:53:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-30 20:53:58 --> Config Class Initialized
INFO - 2021-11-30 20:53:58 --> Hooks Class Initialized
DEBUG - 2021-11-30 20:53:58 --> UTF-8 Support Enabled
INFO - 2021-11-30 20:53:58 --> Utf8 Class Initialized
INFO - 2021-11-30 20:53:58 --> URI Class Initialized
DEBUG - 2021-11-30 20:53:58 --> No URI present. Default controller set.
INFO - 2021-11-30 20:53:58 --> Router Class Initialized
INFO - 2021-11-30 20:53:58 --> Output Class Initialized
INFO - 2021-11-30 20:53:58 --> Security Class Initialized
DEBUG - 2021-11-30 20:53:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-30 20:53:58 --> Input Class Initialized
INFO - 2021-11-30 20:53:58 --> Language Class Initialized
INFO - 2021-11-30 20:53:58 --> Loader Class Initialized
INFO - 2021-11-30 20:53:58 --> Helper loaded: url_helper
INFO - 2021-11-30 20:53:58 --> Helper loaded: form_helper
INFO - 2021-11-30 20:53:58 --> Helper loaded: common_helper
INFO - 2021-11-30 20:53:58 --> Database Driver Class Initialized
DEBUG - 2021-11-30 20:53:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-30 20:53:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-30 20:53:58 --> Controller Class Initialized
INFO - 2021-11-30 20:53:58 --> Form Validation Class Initialized
DEBUG - 2021-11-30 20:53:58 --> Encrypt Class Initialized
DEBUG - 2021-11-30 20:53:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-30 20:53:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-30 20:53:58 --> Email Class Initialized
INFO - 2021-11-30 20:53:58 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-30 20:53:58 --> Calendar Class Initialized
INFO - 2021-11-30 20:53:58 --> Model "Login_model" initialized
INFO - 2021-11-30 20:53:58 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-11-30 20:53:58 --> Final output sent to browser
DEBUG - 2021-11-30 20:53:58 --> Total execution time: 0.0243
