<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-03-28 00:23:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 00:23:51 --> Config Class Initialized
INFO - 2022-03-28 00:23:51 --> Hooks Class Initialized
DEBUG - 2022-03-28 00:23:51 --> UTF-8 Support Enabled
INFO - 2022-03-28 00:23:51 --> Utf8 Class Initialized
INFO - 2022-03-28 00:23:51 --> URI Class Initialized
INFO - 2022-03-28 00:23:51 --> Router Class Initialized
INFO - 2022-03-28 00:23:51 --> Output Class Initialized
INFO - 2022-03-28 00:23:51 --> Security Class Initialized
DEBUG - 2022-03-28 00:23:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 00:23:51 --> Input Class Initialized
INFO - 2022-03-28 00:23:51 --> Language Class Initialized
INFO - 2022-03-28 00:23:51 --> Loader Class Initialized
INFO - 2022-03-28 00:23:51 --> Helper loaded: url_helper
INFO - 2022-03-28 00:23:51 --> Helper loaded: form_helper
INFO - 2022-03-28 00:23:51 --> Helper loaded: common_helper
INFO - 2022-03-28 00:23:51 --> Database Driver Class Initialized
DEBUG - 2022-03-28 00:23:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 00:23:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 00:23:51 --> Controller Class Initialized
ERROR - 2022-03-28 00:23:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 00:23:51 --> Config Class Initialized
INFO - 2022-03-28 00:23:51 --> Hooks Class Initialized
DEBUG - 2022-03-28 00:23:51 --> UTF-8 Support Enabled
INFO - 2022-03-28 00:23:51 --> Utf8 Class Initialized
INFO - 2022-03-28 00:23:51 --> URI Class Initialized
INFO - 2022-03-28 00:23:51 --> Router Class Initialized
INFO - 2022-03-28 00:23:51 --> Output Class Initialized
INFO - 2022-03-28 00:23:51 --> Security Class Initialized
DEBUG - 2022-03-28 00:23:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 00:23:51 --> Input Class Initialized
INFO - 2022-03-28 00:23:51 --> Language Class Initialized
INFO - 2022-03-28 00:23:51 --> Loader Class Initialized
INFO - 2022-03-28 00:23:51 --> Helper loaded: url_helper
INFO - 2022-03-28 00:23:51 --> Helper loaded: form_helper
INFO - 2022-03-28 00:23:51 --> Helper loaded: common_helper
INFO - 2022-03-28 00:23:51 --> Database Driver Class Initialized
DEBUG - 2022-03-28 00:23:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 00:23:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 00:23:51 --> Controller Class Initialized
INFO - 2022-03-28 00:23:51 --> Form Validation Class Initialized
DEBUG - 2022-03-28 00:23:51 --> Encrypt Class Initialized
DEBUG - 2022-03-28 00:23:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-28 00:23:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-28 00:23:51 --> Email Class Initialized
INFO - 2022-03-28 00:23:51 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-28 00:23:51 --> Calendar Class Initialized
INFO - 2022-03-28 00:23:51 --> Model "Login_model" initialized
INFO - 2022-03-28 00:23:51 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-28 00:23:51 --> Final output sent to browser
DEBUG - 2022-03-28 00:23:51 --> Total execution time: 0.0191
ERROR - 2022-03-28 00:24:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 00:24:14 --> Config Class Initialized
INFO - 2022-03-28 00:24:14 --> Hooks Class Initialized
DEBUG - 2022-03-28 00:24:14 --> UTF-8 Support Enabled
INFO - 2022-03-28 00:24:14 --> Utf8 Class Initialized
INFO - 2022-03-28 00:24:14 --> URI Class Initialized
INFO - 2022-03-28 00:24:14 --> Router Class Initialized
INFO - 2022-03-28 00:24:14 --> Output Class Initialized
INFO - 2022-03-28 00:24:14 --> Security Class Initialized
DEBUG - 2022-03-28 00:24:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 00:24:14 --> Input Class Initialized
INFO - 2022-03-28 00:24:14 --> Language Class Initialized
INFO - 2022-03-28 00:24:14 --> Loader Class Initialized
INFO - 2022-03-28 00:24:14 --> Helper loaded: url_helper
INFO - 2022-03-28 00:24:14 --> Helper loaded: form_helper
INFO - 2022-03-28 00:24:14 --> Helper loaded: common_helper
INFO - 2022-03-28 00:24:14 --> Database Driver Class Initialized
DEBUG - 2022-03-28 00:24:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 00:24:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 00:24:14 --> Controller Class Initialized
INFO - 2022-03-28 00:24:14 --> Form Validation Class Initialized
DEBUG - 2022-03-28 00:24:14 --> Encrypt Class Initialized
DEBUG - 2022-03-28 00:24:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-28 00:24:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-28 00:24:14 --> Email Class Initialized
INFO - 2022-03-28 00:24:14 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-28 00:24:14 --> Calendar Class Initialized
INFO - 2022-03-28 00:24:14 --> Model "Login_model" initialized
INFO - 2022-03-28 00:24:14 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-03-28 00:24:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 00:24:14 --> Config Class Initialized
INFO - 2022-03-28 00:24:14 --> Hooks Class Initialized
DEBUG - 2022-03-28 00:24:14 --> UTF-8 Support Enabled
INFO - 2022-03-28 00:24:14 --> Utf8 Class Initialized
INFO - 2022-03-28 00:24:14 --> URI Class Initialized
INFO - 2022-03-28 00:24:14 --> Router Class Initialized
INFO - 2022-03-28 00:24:14 --> Output Class Initialized
INFO - 2022-03-28 00:24:14 --> Security Class Initialized
DEBUG - 2022-03-28 00:24:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 00:24:14 --> Input Class Initialized
INFO - 2022-03-28 00:24:14 --> Language Class Initialized
INFO - 2022-03-28 00:24:14 --> Loader Class Initialized
INFO - 2022-03-28 00:24:14 --> Helper loaded: url_helper
INFO - 2022-03-28 00:24:14 --> Helper loaded: form_helper
INFO - 2022-03-28 00:24:14 --> Helper loaded: common_helper
INFO - 2022-03-28 00:24:14 --> Database Driver Class Initialized
DEBUG - 2022-03-28 00:24:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 00:24:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 00:24:14 --> Controller Class Initialized
INFO - 2022-03-28 00:24:14 --> Form Validation Class Initialized
DEBUG - 2022-03-28 00:24:14 --> Encrypt Class Initialized
INFO - 2022-03-28 00:24:14 --> Model "Login_model" initialized
INFO - 2022-03-28 00:24:14 --> Model "Dashboard_model" initialized
INFO - 2022-03-28 00:24:14 --> Model "Case_model" initialized
INFO - 2022-03-28 00:24:14 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-28 00:24:14 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2022-03-28 00:24:14 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-28 00:24:14 --> Final output sent to browser
DEBUG - 2022-03-28 00:24:14 --> Total execution time: 0.4002
ERROR - 2022-03-28 00:24:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 00:24:14 --> Config Class Initialized
INFO - 2022-03-28 00:24:14 --> Hooks Class Initialized
DEBUG - 2022-03-28 00:24:14 --> UTF-8 Support Enabled
INFO - 2022-03-28 00:24:14 --> Utf8 Class Initialized
INFO - 2022-03-28 00:24:14 --> URI Class Initialized
INFO - 2022-03-28 00:24:14 --> Router Class Initialized
INFO - 2022-03-28 00:24:14 --> Output Class Initialized
INFO - 2022-03-28 00:24:14 --> Security Class Initialized
DEBUG - 2022-03-28 00:24:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 00:24:14 --> Input Class Initialized
INFO - 2022-03-28 00:24:14 --> Language Class Initialized
INFO - 2022-03-28 00:24:14 --> Loader Class Initialized
INFO - 2022-03-28 00:24:14 --> Helper loaded: url_helper
INFO - 2022-03-28 00:24:14 --> Helper loaded: form_helper
INFO - 2022-03-28 00:24:14 --> Helper loaded: common_helper
INFO - 2022-03-28 00:24:14 --> Database Driver Class Initialized
DEBUG - 2022-03-28 00:24:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 00:24:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 00:24:14 --> Controller Class Initialized
INFO - 2022-03-28 00:24:14 --> Form Validation Class Initialized
DEBUG - 2022-03-28 00:24:14 --> Encrypt Class Initialized
DEBUG - 2022-03-28 00:24:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-28 00:24:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-28 00:24:14 --> Email Class Initialized
INFO - 2022-03-28 00:24:14 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-28 00:24:14 --> Calendar Class Initialized
INFO - 2022-03-28 00:24:14 --> Model "Login_model" initialized
INFO - 2022-03-28 00:24:14 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-03-28 00:24:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 00:24:15 --> Config Class Initialized
INFO - 2022-03-28 00:24:15 --> Hooks Class Initialized
DEBUG - 2022-03-28 00:24:15 --> UTF-8 Support Enabled
INFO - 2022-03-28 00:24:15 --> Utf8 Class Initialized
INFO - 2022-03-28 00:24:15 --> URI Class Initialized
INFO - 2022-03-28 00:24:15 --> Router Class Initialized
INFO - 2022-03-28 00:24:15 --> Output Class Initialized
INFO - 2022-03-28 00:24:15 --> Security Class Initialized
DEBUG - 2022-03-28 00:24:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 00:24:15 --> Input Class Initialized
INFO - 2022-03-28 00:24:15 --> Language Class Initialized
INFO - 2022-03-28 00:24:15 --> Loader Class Initialized
INFO - 2022-03-28 00:24:15 --> Helper loaded: url_helper
INFO - 2022-03-28 00:24:15 --> Helper loaded: form_helper
INFO - 2022-03-28 00:24:15 --> Helper loaded: common_helper
INFO - 2022-03-28 00:24:15 --> Database Driver Class Initialized
DEBUG - 2022-03-28 00:24:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 00:24:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 00:24:15 --> Controller Class Initialized
INFO - 2022-03-28 00:24:15 --> Form Validation Class Initialized
DEBUG - 2022-03-28 00:24:15 --> Encrypt Class Initialized
INFO - 2022-03-28 00:24:15 --> Model "Login_model" initialized
INFO - 2022-03-28 00:24:15 --> Model "Dashboard_model" initialized
INFO - 2022-03-28 00:24:15 --> Model "Case_model" initialized
INFO - 2022-03-28 00:24:15 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-28 00:24:15 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2022-03-28 00:24:15 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-28 00:24:15 --> Final output sent to browser
DEBUG - 2022-03-28 00:24:15 --> Total execution time: 0.1666
ERROR - 2022-03-28 00:24:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 00:24:26 --> Config Class Initialized
INFO - 2022-03-28 00:24:26 --> Hooks Class Initialized
DEBUG - 2022-03-28 00:24:26 --> UTF-8 Support Enabled
INFO - 2022-03-28 00:24:26 --> Utf8 Class Initialized
INFO - 2022-03-28 00:24:26 --> URI Class Initialized
INFO - 2022-03-28 00:24:26 --> Router Class Initialized
INFO - 2022-03-28 00:24:26 --> Output Class Initialized
INFO - 2022-03-28 00:24:26 --> Security Class Initialized
DEBUG - 2022-03-28 00:24:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 00:24:26 --> Input Class Initialized
INFO - 2022-03-28 00:24:26 --> Language Class Initialized
INFO - 2022-03-28 00:24:26 --> Loader Class Initialized
INFO - 2022-03-28 00:24:26 --> Helper loaded: url_helper
INFO - 2022-03-28 00:24:26 --> Helper loaded: form_helper
INFO - 2022-03-28 00:24:26 --> Helper loaded: common_helper
INFO - 2022-03-28 00:24:26 --> Database Driver Class Initialized
DEBUG - 2022-03-28 00:24:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 00:24:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 00:24:26 --> Controller Class Initialized
INFO - 2022-03-28 00:24:26 --> Form Validation Class Initialized
DEBUG - 2022-03-28 00:24:26 --> Encrypt Class Initialized
INFO - 2022-03-28 00:24:26 --> Model "Patient_model" initialized
INFO - 2022-03-28 00:24:26 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 00:24:26 --> Model "Referredby_model" initialized
INFO - 2022-03-28 00:24:26 --> Model "Prefix_master" initialized
INFO - 2022-03-28 00:24:26 --> Model "Hospital_model" initialized
INFO - 2022-03-28 00:24:26 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-28 00:24:26 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-28 00:24:26 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-28 00:24:26 --> Final output sent to browser
DEBUG - 2022-03-28 00:24:26 --> Total execution time: 0.1426
ERROR - 2022-03-28 00:26:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 00:26:16 --> Config Class Initialized
INFO - 2022-03-28 00:26:16 --> Hooks Class Initialized
DEBUG - 2022-03-28 00:26:16 --> UTF-8 Support Enabled
INFO - 2022-03-28 00:26:16 --> Utf8 Class Initialized
INFO - 2022-03-28 00:26:16 --> URI Class Initialized
DEBUG - 2022-03-28 00:26:16 --> No URI present. Default controller set.
INFO - 2022-03-28 00:26:16 --> Router Class Initialized
INFO - 2022-03-28 00:26:16 --> Output Class Initialized
INFO - 2022-03-28 00:26:16 --> Security Class Initialized
DEBUG - 2022-03-28 00:26:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 00:26:16 --> Input Class Initialized
INFO - 2022-03-28 00:26:16 --> Language Class Initialized
INFO - 2022-03-28 00:26:16 --> Loader Class Initialized
INFO - 2022-03-28 00:26:16 --> Helper loaded: url_helper
INFO - 2022-03-28 00:26:16 --> Helper loaded: form_helper
INFO - 2022-03-28 00:26:16 --> Helper loaded: common_helper
INFO - 2022-03-28 00:26:16 --> Database Driver Class Initialized
DEBUG - 2022-03-28 00:26:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 00:26:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 00:26:16 --> Controller Class Initialized
INFO - 2022-03-28 00:26:16 --> Form Validation Class Initialized
DEBUG - 2022-03-28 00:26:16 --> Encrypt Class Initialized
DEBUG - 2022-03-28 00:26:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-28 00:26:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-28 00:26:16 --> Email Class Initialized
INFO - 2022-03-28 00:26:16 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-28 00:26:16 --> Calendar Class Initialized
INFO - 2022-03-28 00:26:16 --> Model "Login_model" initialized
INFO - 2022-03-28 00:26:16 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-28 00:26:16 --> Final output sent to browser
DEBUG - 2022-03-28 00:26:16 --> Total execution time: 0.0061
ERROR - 2022-03-28 00:43:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 00:43:43 --> Config Class Initialized
INFO - 2022-03-28 00:43:43 --> Hooks Class Initialized
DEBUG - 2022-03-28 00:43:43 --> UTF-8 Support Enabled
INFO - 2022-03-28 00:43:43 --> Utf8 Class Initialized
INFO - 2022-03-28 00:43:43 --> URI Class Initialized
INFO - 2022-03-28 00:43:43 --> Router Class Initialized
INFO - 2022-03-28 00:43:43 --> Output Class Initialized
INFO - 2022-03-28 00:43:43 --> Security Class Initialized
DEBUG - 2022-03-28 00:43:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 00:43:43 --> Input Class Initialized
INFO - 2022-03-28 00:43:43 --> Language Class Initialized
INFO - 2022-03-28 00:43:43 --> Loader Class Initialized
INFO - 2022-03-28 00:43:43 --> Helper loaded: url_helper
INFO - 2022-03-28 00:43:43 --> Helper loaded: form_helper
INFO - 2022-03-28 00:43:43 --> Helper loaded: common_helper
INFO - 2022-03-28 00:43:43 --> Database Driver Class Initialized
DEBUG - 2022-03-28 00:43:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 00:43:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 00:43:43 --> Controller Class Initialized
INFO - 2022-03-28 00:43:43 --> Form Validation Class Initialized
DEBUG - 2022-03-28 00:43:43 --> Encrypt Class Initialized
INFO - 2022-03-28 00:43:43 --> Model "Patient_model" initialized
INFO - 2022-03-28 00:43:43 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 00:43:43 --> Model "Referredby_model" initialized
INFO - 2022-03-28 00:43:43 --> Model "Prefix_master" initialized
INFO - 2022-03-28 00:43:43 --> Model "Hospital_model" initialized
INFO - 2022-03-28 00:43:43 --> Upload Class Initialized
INFO - 2022-03-28 00:43:43 --> Final output sent to browser
DEBUG - 2022-03-28 00:43:43 --> Total execution time: 0.1219
ERROR - 2022-03-28 00:45:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 00:45:52 --> Config Class Initialized
INFO - 2022-03-28 00:45:52 --> Hooks Class Initialized
DEBUG - 2022-03-28 00:45:52 --> UTF-8 Support Enabled
INFO - 2022-03-28 00:45:52 --> Utf8 Class Initialized
INFO - 2022-03-28 00:45:52 --> URI Class Initialized
INFO - 2022-03-28 00:45:52 --> Router Class Initialized
INFO - 2022-03-28 00:45:52 --> Output Class Initialized
INFO - 2022-03-28 00:45:52 --> Security Class Initialized
DEBUG - 2022-03-28 00:45:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 00:45:52 --> Input Class Initialized
INFO - 2022-03-28 00:45:52 --> Language Class Initialized
INFO - 2022-03-28 00:45:52 --> Loader Class Initialized
INFO - 2022-03-28 00:45:52 --> Helper loaded: url_helper
INFO - 2022-03-28 00:45:52 --> Helper loaded: form_helper
INFO - 2022-03-28 00:45:52 --> Helper loaded: common_helper
INFO - 2022-03-28 00:45:52 --> Database Driver Class Initialized
DEBUG - 2022-03-28 00:45:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 00:45:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 00:45:52 --> Controller Class Initialized
INFO - 2022-03-28 00:45:52 --> Form Validation Class Initialized
DEBUG - 2022-03-28 00:45:52 --> Encrypt Class Initialized
INFO - 2022-03-28 00:45:52 --> Model "Patient_model" initialized
INFO - 2022-03-28 00:45:52 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 00:45:52 --> Model "Referredby_model" initialized
INFO - 2022-03-28 00:45:52 --> Model "Prefix_master" initialized
INFO - 2022-03-28 00:45:52 --> Model "Hospital_model" initialized
INFO - 2022-03-28 00:45:52 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-28 00:45:52 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-28 00:45:52 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-28 00:45:52 --> Final output sent to browser
DEBUG - 2022-03-28 00:45:52 --> Total execution time: 0.1062
ERROR - 2022-03-28 00:45:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 00:45:59 --> Config Class Initialized
INFO - 2022-03-28 00:45:59 --> Hooks Class Initialized
DEBUG - 2022-03-28 00:45:59 --> UTF-8 Support Enabled
INFO - 2022-03-28 00:45:59 --> Utf8 Class Initialized
INFO - 2022-03-28 00:45:59 --> URI Class Initialized
INFO - 2022-03-28 00:45:59 --> Router Class Initialized
INFO - 2022-03-28 00:45:59 --> Output Class Initialized
INFO - 2022-03-28 00:45:59 --> Security Class Initialized
DEBUG - 2022-03-28 00:45:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 00:45:59 --> Input Class Initialized
INFO - 2022-03-28 00:45:59 --> Language Class Initialized
INFO - 2022-03-28 00:45:59 --> Loader Class Initialized
INFO - 2022-03-28 00:45:59 --> Helper loaded: url_helper
INFO - 2022-03-28 00:45:59 --> Helper loaded: form_helper
INFO - 2022-03-28 00:45:59 --> Helper loaded: common_helper
INFO - 2022-03-28 00:45:59 --> Database Driver Class Initialized
DEBUG - 2022-03-28 00:45:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 00:45:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 00:45:59 --> Controller Class Initialized
INFO - 2022-03-28 00:45:59 --> Form Validation Class Initialized
DEBUG - 2022-03-28 00:45:59 --> Encrypt Class Initialized
INFO - 2022-03-28 00:45:59 --> Model "Patient_model" initialized
INFO - 2022-03-28 00:45:59 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 00:45:59 --> Model "Prefix_master" initialized
INFO - 2022-03-28 00:45:59 --> Model "Users_model" initialized
INFO - 2022-03-28 00:45:59 --> Model "Hospital_model" initialized
INFO - 2022-03-28 00:46:00 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-28 00:46:00 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-28 00:46:00 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-28 00:46:00 --> Final output sent to browser
DEBUG - 2022-03-28 00:46:00 --> Total execution time: 0.2243
ERROR - 2022-03-28 00:46:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 00:46:03 --> Config Class Initialized
INFO - 2022-03-28 00:46:03 --> Hooks Class Initialized
DEBUG - 2022-03-28 00:46:03 --> UTF-8 Support Enabled
INFO - 2022-03-28 00:46:03 --> Utf8 Class Initialized
INFO - 2022-03-28 00:46:03 --> URI Class Initialized
INFO - 2022-03-28 00:46:03 --> Router Class Initialized
INFO - 2022-03-28 00:46:03 --> Output Class Initialized
INFO - 2022-03-28 00:46:03 --> Security Class Initialized
DEBUG - 2022-03-28 00:46:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 00:46:03 --> Input Class Initialized
INFO - 2022-03-28 00:46:03 --> Language Class Initialized
INFO - 2022-03-28 00:46:03 --> Loader Class Initialized
INFO - 2022-03-28 00:46:03 --> Helper loaded: url_helper
INFO - 2022-03-28 00:46:03 --> Helper loaded: form_helper
INFO - 2022-03-28 00:46:03 --> Helper loaded: common_helper
INFO - 2022-03-28 00:46:03 --> Database Driver Class Initialized
DEBUG - 2022-03-28 00:46:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 00:46:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 00:46:03 --> Controller Class Initialized
INFO - 2022-03-28 00:46:03 --> Form Validation Class Initialized
DEBUG - 2022-03-28 00:46:03 --> Encrypt Class Initialized
INFO - 2022-03-28 00:46:03 --> Model "Patient_model" initialized
INFO - 2022-03-28 00:46:03 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 00:46:03 --> Model "Referredby_model" initialized
INFO - 2022-03-28 00:46:03 --> Model "Prefix_master" initialized
INFO - 2022-03-28 00:46:03 --> Model "Hospital_model" initialized
INFO - 2022-03-28 00:46:03 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-28 00:46:03 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-28 00:46:03 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-28 00:46:03 --> Final output sent to browser
DEBUG - 2022-03-28 00:46:03 --> Total execution time: 0.0924
ERROR - 2022-03-28 00:46:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 00:46:45 --> Config Class Initialized
INFO - 2022-03-28 00:46:45 --> Hooks Class Initialized
DEBUG - 2022-03-28 00:46:45 --> UTF-8 Support Enabled
INFO - 2022-03-28 00:46:45 --> Utf8 Class Initialized
INFO - 2022-03-28 00:46:45 --> URI Class Initialized
INFO - 2022-03-28 00:46:45 --> Router Class Initialized
INFO - 2022-03-28 00:46:45 --> Output Class Initialized
INFO - 2022-03-28 00:46:45 --> Security Class Initialized
DEBUG - 2022-03-28 00:46:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 00:46:45 --> Input Class Initialized
INFO - 2022-03-28 00:46:45 --> Language Class Initialized
INFO - 2022-03-28 00:46:45 --> Loader Class Initialized
INFO - 2022-03-28 00:46:45 --> Helper loaded: url_helper
INFO - 2022-03-28 00:46:45 --> Helper loaded: form_helper
INFO - 2022-03-28 00:46:45 --> Helper loaded: common_helper
INFO - 2022-03-28 00:46:45 --> Database Driver Class Initialized
DEBUG - 2022-03-28 00:46:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 00:46:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 00:46:45 --> Controller Class Initialized
INFO - 2022-03-28 00:46:45 --> Form Validation Class Initialized
DEBUG - 2022-03-28 00:46:45 --> Encrypt Class Initialized
INFO - 2022-03-28 00:46:45 --> Model "Patient_model" initialized
INFO - 2022-03-28 00:46:45 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 00:46:45 --> Model "Referredby_model" initialized
INFO - 2022-03-28 00:46:45 --> Model "Prefix_master" initialized
INFO - 2022-03-28 00:46:45 --> Model "Hospital_model" initialized
ERROR - 2022-03-28 00:46:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 00:46:46 --> Config Class Initialized
INFO - 2022-03-28 00:46:46 --> Hooks Class Initialized
DEBUG - 2022-03-28 00:46:46 --> UTF-8 Support Enabled
INFO - 2022-03-28 00:46:46 --> Utf8 Class Initialized
INFO - 2022-03-28 00:46:46 --> URI Class Initialized
INFO - 2022-03-28 00:46:46 --> Router Class Initialized
INFO - 2022-03-28 00:46:46 --> Output Class Initialized
INFO - 2022-03-28 00:46:46 --> Security Class Initialized
DEBUG - 2022-03-28 00:46:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 00:46:46 --> Input Class Initialized
INFO - 2022-03-28 00:46:46 --> Language Class Initialized
INFO - 2022-03-28 00:46:46 --> Loader Class Initialized
INFO - 2022-03-28 00:46:46 --> Helper loaded: url_helper
INFO - 2022-03-28 00:46:46 --> Helper loaded: form_helper
INFO - 2022-03-28 00:46:46 --> Helper loaded: common_helper
INFO - 2022-03-28 00:46:46 --> Database Driver Class Initialized
DEBUG - 2022-03-28 00:46:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 00:46:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 00:46:46 --> Controller Class Initialized
INFO - 2022-03-28 00:46:46 --> Form Validation Class Initialized
DEBUG - 2022-03-28 00:46:46 --> Encrypt Class Initialized
INFO - 2022-03-28 00:46:46 --> Model "Patient_model" initialized
INFO - 2022-03-28 00:46:46 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 00:46:46 --> Model "Referredby_model" initialized
INFO - 2022-03-28 00:46:46 --> Model "Prefix_master" initialized
INFO - 2022-03-28 00:46:46 --> Model "Hospital_model" initialized
INFO - 2022-03-28 00:46:46 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-28 00:46:46 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-28 00:46:46 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-28 00:46:46 --> Final output sent to browser
DEBUG - 2022-03-28 00:46:46 --> Total execution time: 0.0276
ERROR - 2022-03-28 00:46:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 00:46:47 --> Config Class Initialized
INFO - 2022-03-28 00:46:47 --> Hooks Class Initialized
DEBUG - 2022-03-28 00:46:47 --> UTF-8 Support Enabled
INFO - 2022-03-28 00:46:47 --> Utf8 Class Initialized
INFO - 2022-03-28 00:46:47 --> URI Class Initialized
INFO - 2022-03-28 00:46:47 --> Router Class Initialized
INFO - 2022-03-28 00:46:47 --> Output Class Initialized
INFO - 2022-03-28 00:46:47 --> Security Class Initialized
DEBUG - 2022-03-28 00:46:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 00:46:47 --> Input Class Initialized
INFO - 2022-03-28 00:46:47 --> Language Class Initialized
INFO - 2022-03-28 00:46:47 --> Loader Class Initialized
INFO - 2022-03-28 00:46:47 --> Helper loaded: url_helper
INFO - 2022-03-28 00:46:47 --> Helper loaded: form_helper
INFO - 2022-03-28 00:46:47 --> Helper loaded: common_helper
INFO - 2022-03-28 00:46:47 --> Database Driver Class Initialized
DEBUG - 2022-03-28 00:46:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 00:46:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 00:46:47 --> Controller Class Initialized
INFO - 2022-03-28 00:46:47 --> Form Validation Class Initialized
DEBUG - 2022-03-28 00:46:47 --> Encrypt Class Initialized
INFO - 2022-03-28 00:46:47 --> Model "Patient_model" initialized
INFO - 2022-03-28 00:46:47 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 00:46:47 --> Model "Prefix_master" initialized
INFO - 2022-03-28 00:46:47 --> Model "Users_model" initialized
INFO - 2022-03-28 00:46:47 --> Model "Hospital_model" initialized
INFO - 2022-03-28 00:46:47 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-28 00:46:47 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-28 00:46:47 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-28 00:46:47 --> Final output sent to browser
DEBUG - 2022-03-28 00:46:47 --> Total execution time: 0.0397
ERROR - 2022-03-28 00:47:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 00:47:32 --> Config Class Initialized
INFO - 2022-03-28 00:47:32 --> Hooks Class Initialized
DEBUG - 2022-03-28 00:47:32 --> UTF-8 Support Enabled
INFO - 2022-03-28 00:47:32 --> Utf8 Class Initialized
INFO - 2022-03-28 00:47:32 --> URI Class Initialized
INFO - 2022-03-28 00:47:32 --> Router Class Initialized
INFO - 2022-03-28 00:47:32 --> Output Class Initialized
INFO - 2022-03-28 00:47:32 --> Security Class Initialized
DEBUG - 2022-03-28 00:47:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 00:47:32 --> Input Class Initialized
INFO - 2022-03-28 00:47:32 --> Language Class Initialized
INFO - 2022-03-28 00:47:32 --> Loader Class Initialized
INFO - 2022-03-28 00:47:32 --> Helper loaded: url_helper
INFO - 2022-03-28 00:47:32 --> Helper loaded: form_helper
INFO - 2022-03-28 00:47:32 --> Helper loaded: common_helper
INFO - 2022-03-28 00:47:32 --> Database Driver Class Initialized
DEBUG - 2022-03-28 00:47:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 00:47:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 00:47:32 --> Controller Class Initialized
INFO - 2022-03-28 00:47:32 --> Form Validation Class Initialized
DEBUG - 2022-03-28 00:47:32 --> Encrypt Class Initialized
INFO - 2022-03-28 00:47:32 --> Model "Patient_model" initialized
INFO - 2022-03-28 00:47:32 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 00:47:32 --> Model "Prefix_master" initialized
INFO - 2022-03-28 00:47:32 --> Model "Users_model" initialized
INFO - 2022-03-28 00:47:32 --> Model "Hospital_model" initialized
ERROR - 2022-03-28 00:47:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 00:47:32 --> Config Class Initialized
INFO - 2022-03-28 00:47:32 --> Hooks Class Initialized
DEBUG - 2022-03-28 00:47:32 --> UTF-8 Support Enabled
INFO - 2022-03-28 00:47:32 --> Utf8 Class Initialized
INFO - 2022-03-28 00:47:32 --> URI Class Initialized
INFO - 2022-03-28 00:47:32 --> Router Class Initialized
INFO - 2022-03-28 00:47:32 --> Output Class Initialized
INFO - 2022-03-28 00:47:32 --> Security Class Initialized
DEBUG - 2022-03-28 00:47:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 00:47:32 --> Input Class Initialized
INFO - 2022-03-28 00:47:32 --> Language Class Initialized
INFO - 2022-03-28 00:47:32 --> Loader Class Initialized
INFO - 2022-03-28 00:47:32 --> Helper loaded: url_helper
INFO - 2022-03-28 00:47:32 --> Helper loaded: form_helper
INFO - 2022-03-28 00:47:32 --> Helper loaded: common_helper
INFO - 2022-03-28 00:47:32 --> Database Driver Class Initialized
DEBUG - 2022-03-28 00:47:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 00:47:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 00:47:32 --> Controller Class Initialized
INFO - 2022-03-28 00:47:32 --> Form Validation Class Initialized
DEBUG - 2022-03-28 00:47:32 --> Encrypt Class Initialized
INFO - 2022-03-28 00:47:32 --> Model "Patient_model" initialized
INFO - 2022-03-28 00:47:32 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 00:47:32 --> Model "Prefix_master" initialized
INFO - 2022-03-28 00:47:32 --> Model "Users_model" initialized
INFO - 2022-03-28 00:47:32 --> Model "Hospital_model" initialized
INFO - 2022-03-28 00:47:32 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-28 00:47:32 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-28 00:47:32 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-28 00:47:32 --> Final output sent to browser
DEBUG - 2022-03-28 00:47:32 --> Total execution time: 0.0720
ERROR - 2022-03-28 00:49:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 00:49:23 --> Config Class Initialized
INFO - 2022-03-28 00:49:23 --> Hooks Class Initialized
DEBUG - 2022-03-28 00:49:23 --> UTF-8 Support Enabled
INFO - 2022-03-28 00:49:23 --> Utf8 Class Initialized
INFO - 2022-03-28 00:49:23 --> URI Class Initialized
INFO - 2022-03-28 00:49:23 --> Router Class Initialized
INFO - 2022-03-28 00:49:23 --> Output Class Initialized
INFO - 2022-03-28 00:49:23 --> Security Class Initialized
DEBUG - 2022-03-28 00:49:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 00:49:23 --> Input Class Initialized
INFO - 2022-03-28 00:49:23 --> Language Class Initialized
INFO - 2022-03-28 00:49:23 --> Loader Class Initialized
INFO - 2022-03-28 00:49:23 --> Helper loaded: url_helper
INFO - 2022-03-28 00:49:23 --> Helper loaded: form_helper
INFO - 2022-03-28 00:49:23 --> Helper loaded: common_helper
INFO - 2022-03-28 00:49:23 --> Database Driver Class Initialized
DEBUG - 2022-03-28 00:49:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 00:49:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 00:49:23 --> Controller Class Initialized
INFO - 2022-03-28 00:49:23 --> Form Validation Class Initialized
DEBUG - 2022-03-28 00:49:23 --> Encrypt Class Initialized
INFO - 2022-03-28 00:49:23 --> Model "Patient_model" initialized
INFO - 2022-03-28 00:49:23 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 00:49:23 --> Model "Prefix_master" initialized
INFO - 2022-03-28 00:49:23 --> Model "Users_model" initialized
INFO - 2022-03-28 00:49:23 --> Model "Hospital_model" initialized
ERROR - 2022-03-28 00:49:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 00:49:23 --> Config Class Initialized
INFO - 2022-03-28 00:49:23 --> Hooks Class Initialized
DEBUG - 2022-03-28 00:49:23 --> UTF-8 Support Enabled
INFO - 2022-03-28 00:49:23 --> Utf8 Class Initialized
INFO - 2022-03-28 00:49:23 --> URI Class Initialized
INFO - 2022-03-28 00:49:23 --> Router Class Initialized
INFO - 2022-03-28 00:49:23 --> Output Class Initialized
INFO - 2022-03-28 00:49:23 --> Security Class Initialized
DEBUG - 2022-03-28 00:49:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 00:49:23 --> Input Class Initialized
INFO - 2022-03-28 00:49:23 --> Language Class Initialized
INFO - 2022-03-28 00:49:23 --> Loader Class Initialized
INFO - 2022-03-28 00:49:23 --> Helper loaded: url_helper
INFO - 2022-03-28 00:49:23 --> Helper loaded: form_helper
INFO - 2022-03-28 00:49:23 --> Helper loaded: common_helper
INFO - 2022-03-28 00:49:23 --> Database Driver Class Initialized
DEBUG - 2022-03-28 00:49:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 00:49:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 00:49:24 --> Controller Class Initialized
INFO - 2022-03-28 00:49:24 --> Form Validation Class Initialized
DEBUG - 2022-03-28 00:49:24 --> Encrypt Class Initialized
INFO - 2022-03-28 00:49:24 --> Model "Patient_model" initialized
INFO - 2022-03-28 00:49:24 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 00:49:24 --> Model "Prefix_master" initialized
INFO - 2022-03-28 00:49:24 --> Model "Users_model" initialized
INFO - 2022-03-28 00:49:24 --> Model "Hospital_model" initialized
INFO - 2022-03-28 00:49:24 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-28 00:49:24 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-28 00:49:24 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-28 00:49:24 --> Final output sent to browser
DEBUG - 2022-03-28 00:49:24 --> Total execution time: 0.0475
ERROR - 2022-03-28 00:49:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 00:49:42 --> Config Class Initialized
INFO - 2022-03-28 00:49:42 --> Hooks Class Initialized
DEBUG - 2022-03-28 00:49:42 --> UTF-8 Support Enabled
INFO - 2022-03-28 00:49:42 --> Utf8 Class Initialized
INFO - 2022-03-28 00:49:42 --> URI Class Initialized
INFO - 2022-03-28 00:49:42 --> Router Class Initialized
INFO - 2022-03-28 00:49:42 --> Output Class Initialized
INFO - 2022-03-28 00:49:42 --> Security Class Initialized
DEBUG - 2022-03-28 00:49:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 00:49:42 --> Input Class Initialized
INFO - 2022-03-28 00:49:42 --> Language Class Initialized
INFO - 2022-03-28 00:49:42 --> Loader Class Initialized
INFO - 2022-03-28 00:49:42 --> Helper loaded: url_helper
INFO - 2022-03-28 00:49:42 --> Helper loaded: form_helper
INFO - 2022-03-28 00:49:42 --> Helper loaded: common_helper
INFO - 2022-03-28 00:49:42 --> Database Driver Class Initialized
DEBUG - 2022-03-28 00:49:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 00:49:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 00:49:42 --> Controller Class Initialized
INFO - 2022-03-28 00:49:42 --> Form Validation Class Initialized
DEBUG - 2022-03-28 00:49:42 --> Encrypt Class Initialized
INFO - 2022-03-28 00:49:42 --> Model "Patient_model" initialized
INFO - 2022-03-28 00:49:42 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 00:49:42 --> Model "Prefix_master" initialized
INFO - 2022-03-28 00:49:42 --> Model "Users_model" initialized
INFO - 2022-03-28 00:49:42 --> Model "Hospital_model" initialized
ERROR - 2022-03-28 00:49:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 00:49:42 --> Config Class Initialized
INFO - 2022-03-28 00:49:42 --> Hooks Class Initialized
DEBUG - 2022-03-28 00:49:42 --> UTF-8 Support Enabled
INFO - 2022-03-28 00:49:42 --> Utf8 Class Initialized
INFO - 2022-03-28 00:49:42 --> URI Class Initialized
INFO - 2022-03-28 00:49:42 --> Router Class Initialized
INFO - 2022-03-28 00:49:42 --> Output Class Initialized
INFO - 2022-03-28 00:49:42 --> Security Class Initialized
DEBUG - 2022-03-28 00:49:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 00:49:42 --> Input Class Initialized
INFO - 2022-03-28 00:49:42 --> Language Class Initialized
INFO - 2022-03-28 00:49:42 --> Loader Class Initialized
INFO - 2022-03-28 00:49:42 --> Helper loaded: url_helper
INFO - 2022-03-28 00:49:42 --> Helper loaded: form_helper
INFO - 2022-03-28 00:49:42 --> Helper loaded: common_helper
INFO - 2022-03-28 00:49:42 --> Database Driver Class Initialized
DEBUG - 2022-03-28 00:49:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 00:49:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 00:49:42 --> Controller Class Initialized
INFO - 2022-03-28 00:49:42 --> Form Validation Class Initialized
DEBUG - 2022-03-28 00:49:42 --> Encrypt Class Initialized
INFO - 2022-03-28 00:49:42 --> Model "Patient_model" initialized
INFO - 2022-03-28 00:49:42 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 00:49:42 --> Model "Prefix_master" initialized
INFO - 2022-03-28 00:49:42 --> Model "Users_model" initialized
INFO - 2022-03-28 00:49:42 --> Model "Hospital_model" initialized
INFO - 2022-03-28 00:49:42 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-28 00:49:42 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-28 00:49:42 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-28 00:49:42 --> Final output sent to browser
DEBUG - 2022-03-28 00:49:42 --> Total execution time: 0.0490
ERROR - 2022-03-28 00:50:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 00:50:02 --> Config Class Initialized
INFO - 2022-03-28 00:50:02 --> Hooks Class Initialized
DEBUG - 2022-03-28 00:50:02 --> UTF-8 Support Enabled
INFO - 2022-03-28 00:50:02 --> Utf8 Class Initialized
INFO - 2022-03-28 00:50:02 --> URI Class Initialized
INFO - 2022-03-28 00:50:02 --> Router Class Initialized
INFO - 2022-03-28 00:50:02 --> Output Class Initialized
INFO - 2022-03-28 00:50:02 --> Security Class Initialized
DEBUG - 2022-03-28 00:50:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 00:50:02 --> Input Class Initialized
INFO - 2022-03-28 00:50:02 --> Language Class Initialized
INFO - 2022-03-28 00:50:02 --> Loader Class Initialized
INFO - 2022-03-28 00:50:02 --> Helper loaded: url_helper
INFO - 2022-03-28 00:50:02 --> Helper loaded: form_helper
INFO - 2022-03-28 00:50:02 --> Helper loaded: common_helper
INFO - 2022-03-28 00:50:02 --> Database Driver Class Initialized
DEBUG - 2022-03-28 00:50:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 00:50:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 00:50:02 --> Controller Class Initialized
INFO - 2022-03-28 00:50:02 --> Model "Referredby_model" initialized
INFO - 2022-03-28 00:50:02 --> Final output sent to browser
DEBUG - 2022-03-28 00:50:02 --> Total execution time: 0.0103
ERROR - 2022-03-28 00:51:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 00:51:56 --> Config Class Initialized
INFO - 2022-03-28 00:51:56 --> Hooks Class Initialized
DEBUG - 2022-03-28 00:51:56 --> UTF-8 Support Enabled
INFO - 2022-03-28 00:51:56 --> Utf8 Class Initialized
INFO - 2022-03-28 00:51:56 --> URI Class Initialized
INFO - 2022-03-28 00:51:56 --> Router Class Initialized
INFO - 2022-03-28 00:51:56 --> Output Class Initialized
INFO - 2022-03-28 00:51:56 --> Security Class Initialized
DEBUG - 2022-03-28 00:51:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 00:51:56 --> Input Class Initialized
INFO - 2022-03-28 00:51:56 --> Language Class Initialized
INFO - 2022-03-28 00:51:56 --> Loader Class Initialized
INFO - 2022-03-28 00:51:56 --> Helper loaded: url_helper
INFO - 2022-03-28 00:51:56 --> Helper loaded: form_helper
INFO - 2022-03-28 00:51:56 --> Helper loaded: common_helper
INFO - 2022-03-28 00:51:56 --> Database Driver Class Initialized
DEBUG - 2022-03-28 00:51:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 00:51:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 00:51:56 --> Controller Class Initialized
INFO - 2022-03-28 00:51:56 --> Model "Referredby_model" initialized
INFO - 2022-03-28 00:51:56 --> Final output sent to browser
DEBUG - 2022-03-28 00:51:56 --> Total execution time: 0.0080
ERROR - 2022-03-28 00:53:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 00:53:27 --> Config Class Initialized
INFO - 2022-03-28 00:53:27 --> Hooks Class Initialized
DEBUG - 2022-03-28 00:53:27 --> UTF-8 Support Enabled
INFO - 2022-03-28 00:53:27 --> Utf8 Class Initialized
INFO - 2022-03-28 00:53:27 --> URI Class Initialized
INFO - 2022-03-28 00:53:27 --> Router Class Initialized
INFO - 2022-03-28 00:53:27 --> Output Class Initialized
INFO - 2022-03-28 00:53:27 --> Security Class Initialized
DEBUG - 2022-03-28 00:53:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 00:53:27 --> Input Class Initialized
INFO - 2022-03-28 00:53:27 --> Language Class Initialized
INFO - 2022-03-28 00:53:27 --> Loader Class Initialized
INFO - 2022-03-28 00:53:27 --> Helper loaded: url_helper
INFO - 2022-03-28 00:53:27 --> Helper loaded: form_helper
INFO - 2022-03-28 00:53:27 --> Helper loaded: common_helper
INFO - 2022-03-28 00:53:27 --> Database Driver Class Initialized
DEBUG - 2022-03-28 00:53:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 00:53:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 00:53:27 --> Controller Class Initialized
INFO - 2022-03-28 00:53:27 --> Form Validation Class Initialized
DEBUG - 2022-03-28 00:53:27 --> Encrypt Class Initialized
INFO - 2022-03-28 00:53:27 --> Model "Patient_model" initialized
INFO - 2022-03-28 00:53:27 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 00:53:27 --> Model "Referredby_model" initialized
INFO - 2022-03-28 00:53:27 --> Model "Prefix_master" initialized
INFO - 2022-03-28 00:53:27 --> Model "Hospital_model" initialized
INFO - 2022-03-28 00:53:27 --> Final output sent to browser
DEBUG - 2022-03-28 00:53:27 --> Total execution time: 0.0088
ERROR - 2022-03-28 00:58:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 00:58:08 --> Config Class Initialized
INFO - 2022-03-28 00:58:08 --> Hooks Class Initialized
DEBUG - 2022-03-28 00:58:08 --> UTF-8 Support Enabled
INFO - 2022-03-28 00:58:08 --> Utf8 Class Initialized
INFO - 2022-03-28 00:58:08 --> URI Class Initialized
INFO - 2022-03-28 00:58:08 --> Router Class Initialized
INFO - 2022-03-28 00:58:08 --> Output Class Initialized
INFO - 2022-03-28 00:58:08 --> Security Class Initialized
DEBUG - 2022-03-28 00:58:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 00:58:08 --> Input Class Initialized
INFO - 2022-03-28 00:58:08 --> Language Class Initialized
INFO - 2022-03-28 00:58:08 --> Loader Class Initialized
INFO - 2022-03-28 00:58:08 --> Helper loaded: url_helper
INFO - 2022-03-28 00:58:08 --> Helper loaded: form_helper
INFO - 2022-03-28 00:58:08 --> Helper loaded: common_helper
INFO - 2022-03-28 00:58:08 --> Database Driver Class Initialized
DEBUG - 2022-03-28 00:58:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 00:58:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 00:58:08 --> Controller Class Initialized
INFO - 2022-03-28 00:58:08 --> Form Validation Class Initialized
DEBUG - 2022-03-28 00:58:08 --> Encrypt Class Initialized
INFO - 2022-03-28 00:58:08 --> Model "Patient_model" initialized
INFO - 2022-03-28 00:58:08 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 00:58:08 --> Model "Prefix_master" initialized
INFO - 2022-03-28 00:58:08 --> Model "Users_model" initialized
INFO - 2022-03-28 00:58:08 --> Model "Hospital_model" initialized
ERROR - 2022-03-28 00:58:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 00:58:09 --> Config Class Initialized
INFO - 2022-03-28 00:58:09 --> Hooks Class Initialized
DEBUG - 2022-03-28 00:58:09 --> UTF-8 Support Enabled
INFO - 2022-03-28 00:58:09 --> Utf8 Class Initialized
INFO - 2022-03-28 00:58:09 --> URI Class Initialized
INFO - 2022-03-28 00:58:09 --> Router Class Initialized
INFO - 2022-03-28 00:58:09 --> Output Class Initialized
INFO - 2022-03-28 00:58:09 --> Security Class Initialized
DEBUG - 2022-03-28 00:58:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 00:58:09 --> Input Class Initialized
INFO - 2022-03-28 00:58:09 --> Language Class Initialized
INFO - 2022-03-28 00:58:09 --> Loader Class Initialized
INFO - 2022-03-28 00:58:09 --> Helper loaded: url_helper
INFO - 2022-03-28 00:58:09 --> Helper loaded: form_helper
INFO - 2022-03-28 00:58:09 --> Helper loaded: common_helper
INFO - 2022-03-28 00:58:09 --> Database Driver Class Initialized
DEBUG - 2022-03-28 00:58:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 00:58:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 00:58:09 --> Controller Class Initialized
INFO - 2022-03-28 00:58:09 --> Form Validation Class Initialized
DEBUG - 2022-03-28 00:58:09 --> Encrypt Class Initialized
INFO - 2022-03-28 00:58:09 --> Model "Patient_model" initialized
INFO - 2022-03-28 00:58:09 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 00:58:09 --> Model "Prefix_master" initialized
INFO - 2022-03-28 00:58:09 --> Model "Users_model" initialized
INFO - 2022-03-28 00:58:09 --> Model "Hospital_model" initialized
INFO - 2022-03-28 00:58:09 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-28 00:58:09 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-28 00:58:09 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-28 00:58:09 --> Final output sent to browser
DEBUG - 2022-03-28 00:58:09 --> Total execution time: 0.0453
ERROR - 2022-03-28 00:58:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 00:58:34 --> Config Class Initialized
INFO - 2022-03-28 00:58:34 --> Hooks Class Initialized
DEBUG - 2022-03-28 00:58:34 --> UTF-8 Support Enabled
INFO - 2022-03-28 00:58:34 --> Utf8 Class Initialized
INFO - 2022-03-28 00:58:34 --> URI Class Initialized
INFO - 2022-03-28 00:58:34 --> Router Class Initialized
INFO - 2022-03-28 00:58:34 --> Output Class Initialized
INFO - 2022-03-28 00:58:34 --> Security Class Initialized
DEBUG - 2022-03-28 00:58:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 00:58:34 --> Input Class Initialized
INFO - 2022-03-28 00:58:34 --> Language Class Initialized
INFO - 2022-03-28 00:58:34 --> Loader Class Initialized
INFO - 2022-03-28 00:58:34 --> Helper loaded: url_helper
INFO - 2022-03-28 00:58:34 --> Helper loaded: form_helper
INFO - 2022-03-28 00:58:34 --> Helper loaded: common_helper
INFO - 2022-03-28 00:58:34 --> Database Driver Class Initialized
DEBUG - 2022-03-28 00:58:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 00:58:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 00:58:34 --> Controller Class Initialized
INFO - 2022-03-28 00:58:34 --> Form Validation Class Initialized
DEBUG - 2022-03-28 00:58:34 --> Encrypt Class Initialized
INFO - 2022-03-28 00:58:34 --> Model "Patient_model" initialized
INFO - 2022-03-28 00:58:34 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 00:58:34 --> Model "Prefix_master" initialized
INFO - 2022-03-28 00:58:34 --> Model "Users_model" initialized
INFO - 2022-03-28 00:58:34 --> Model "Hospital_model" initialized
INFO - 2022-03-28 00:58:34 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-28 00:58:35 --> Final output sent to browser
DEBUG - 2022-03-28 00:58:35 --> Total execution time: 1.3693
ERROR - 2022-03-28 00:58:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 00:58:56 --> Config Class Initialized
INFO - 2022-03-28 00:58:56 --> Hooks Class Initialized
DEBUG - 2022-03-28 00:58:56 --> UTF-8 Support Enabled
INFO - 2022-03-28 00:58:56 --> Utf8 Class Initialized
INFO - 2022-03-28 00:58:56 --> URI Class Initialized
INFO - 2022-03-28 00:58:56 --> Router Class Initialized
INFO - 2022-03-28 00:58:56 --> Output Class Initialized
INFO - 2022-03-28 00:58:56 --> Security Class Initialized
DEBUG - 2022-03-28 00:58:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 00:58:56 --> Input Class Initialized
INFO - 2022-03-28 00:58:56 --> Language Class Initialized
INFO - 2022-03-28 00:58:56 --> Loader Class Initialized
INFO - 2022-03-28 00:58:56 --> Helper loaded: url_helper
INFO - 2022-03-28 00:58:56 --> Helper loaded: form_helper
INFO - 2022-03-28 00:58:56 --> Helper loaded: common_helper
INFO - 2022-03-28 00:58:56 --> Database Driver Class Initialized
DEBUG - 2022-03-28 00:58:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 00:58:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 00:58:56 --> Controller Class Initialized
INFO - 2022-03-28 00:58:56 --> Form Validation Class Initialized
DEBUG - 2022-03-28 00:58:56 --> Encrypt Class Initialized
INFO - 2022-03-28 00:58:56 --> Model "Patient_model" initialized
INFO - 2022-03-28 00:58:56 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 00:58:56 --> Model "Prefix_master" initialized
INFO - 2022-03-28 00:58:56 --> Model "Users_model" initialized
INFO - 2022-03-28 00:58:56 --> Model "Hospital_model" initialized
INFO - 2022-03-28 00:58:56 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-28 00:58:56 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-28 00:58:56 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-28 00:58:56 --> Final output sent to browser
DEBUG - 2022-03-28 00:58:56 --> Total execution time: 0.0547
ERROR - 2022-03-28 00:59:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 00:59:04 --> Config Class Initialized
INFO - 2022-03-28 00:59:04 --> Hooks Class Initialized
DEBUG - 2022-03-28 00:59:04 --> UTF-8 Support Enabled
INFO - 2022-03-28 00:59:04 --> Utf8 Class Initialized
INFO - 2022-03-28 00:59:04 --> URI Class Initialized
INFO - 2022-03-28 00:59:04 --> Router Class Initialized
INFO - 2022-03-28 00:59:04 --> Output Class Initialized
INFO - 2022-03-28 00:59:04 --> Security Class Initialized
DEBUG - 2022-03-28 00:59:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 00:59:04 --> Input Class Initialized
INFO - 2022-03-28 00:59:04 --> Language Class Initialized
INFO - 2022-03-28 00:59:04 --> Loader Class Initialized
INFO - 2022-03-28 00:59:04 --> Helper loaded: url_helper
INFO - 2022-03-28 00:59:04 --> Helper loaded: form_helper
INFO - 2022-03-28 00:59:04 --> Helper loaded: common_helper
INFO - 2022-03-28 00:59:04 --> Database Driver Class Initialized
DEBUG - 2022-03-28 00:59:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 00:59:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 00:59:04 --> Controller Class Initialized
INFO - 2022-03-28 00:59:04 --> Form Validation Class Initialized
DEBUG - 2022-03-28 00:59:04 --> Encrypt Class Initialized
INFO - 2022-03-28 00:59:04 --> Model "Patient_model" initialized
INFO - 2022-03-28 00:59:04 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 00:59:04 --> Model "Referredby_model" initialized
INFO - 2022-03-28 00:59:04 --> Model "Prefix_master" initialized
INFO - 2022-03-28 00:59:04 --> Model "Hospital_model" initialized
INFO - 2022-03-28 00:59:04 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-28 00:59:04 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-28 00:59:04 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-28 00:59:04 --> Final output sent to browser
DEBUG - 2022-03-28 00:59:04 --> Total execution time: 0.0763
ERROR - 2022-03-28 00:59:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 00:59:30 --> Config Class Initialized
INFO - 2022-03-28 00:59:30 --> Hooks Class Initialized
DEBUG - 2022-03-28 00:59:30 --> UTF-8 Support Enabled
INFO - 2022-03-28 00:59:30 --> Utf8 Class Initialized
INFO - 2022-03-28 00:59:30 --> URI Class Initialized
INFO - 2022-03-28 00:59:30 --> Router Class Initialized
INFO - 2022-03-28 00:59:30 --> Output Class Initialized
INFO - 2022-03-28 00:59:30 --> Security Class Initialized
DEBUG - 2022-03-28 00:59:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 00:59:30 --> Input Class Initialized
INFO - 2022-03-28 00:59:30 --> Language Class Initialized
INFO - 2022-03-28 00:59:30 --> Loader Class Initialized
INFO - 2022-03-28 00:59:30 --> Helper loaded: url_helper
INFO - 2022-03-28 00:59:30 --> Helper loaded: form_helper
INFO - 2022-03-28 00:59:30 --> Helper loaded: common_helper
INFO - 2022-03-28 00:59:30 --> Database Driver Class Initialized
DEBUG - 2022-03-28 00:59:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 00:59:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 00:59:30 --> Controller Class Initialized
INFO - 2022-03-28 00:59:30 --> Form Validation Class Initialized
DEBUG - 2022-03-28 00:59:30 --> Encrypt Class Initialized
INFO - 2022-03-28 00:59:30 --> Model "Patient_model" initialized
INFO - 2022-03-28 00:59:30 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 00:59:30 --> Model "Prefix_master" initialized
INFO - 2022-03-28 00:59:30 --> Model "Users_model" initialized
INFO - 2022-03-28 00:59:30 --> Model "Hospital_model" initialized
INFO - 2022-03-28 00:59:30 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-28 00:59:31 --> Final output sent to browser
DEBUG - 2022-03-28 00:59:31 --> Total execution time: 0.7385
ERROR - 2022-03-28 00:59:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 00:59:48 --> Config Class Initialized
INFO - 2022-03-28 00:59:48 --> Hooks Class Initialized
DEBUG - 2022-03-28 00:59:48 --> UTF-8 Support Enabled
INFO - 2022-03-28 00:59:48 --> Utf8 Class Initialized
INFO - 2022-03-28 00:59:48 --> URI Class Initialized
INFO - 2022-03-28 00:59:48 --> Router Class Initialized
INFO - 2022-03-28 00:59:48 --> Output Class Initialized
INFO - 2022-03-28 00:59:48 --> Security Class Initialized
DEBUG - 2022-03-28 00:59:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 00:59:48 --> Input Class Initialized
INFO - 2022-03-28 00:59:48 --> Language Class Initialized
INFO - 2022-03-28 00:59:48 --> Loader Class Initialized
INFO - 2022-03-28 00:59:48 --> Helper loaded: url_helper
INFO - 2022-03-28 00:59:48 --> Helper loaded: form_helper
INFO - 2022-03-28 00:59:48 --> Helper loaded: common_helper
INFO - 2022-03-28 00:59:48 --> Database Driver Class Initialized
DEBUG - 2022-03-28 00:59:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 00:59:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 00:59:48 --> Controller Class Initialized
INFO - 2022-03-28 00:59:48 --> Form Validation Class Initialized
DEBUG - 2022-03-28 00:59:48 --> Encrypt Class Initialized
INFO - 2022-03-28 00:59:48 --> Model "Patient_model" initialized
INFO - 2022-03-28 00:59:48 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 00:59:48 --> Model "Prefix_master" initialized
INFO - 2022-03-28 00:59:48 --> Model "Users_model" initialized
INFO - 2022-03-28 00:59:48 --> Model "Hospital_model" initialized
INFO - 2022-03-28 00:59:48 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-28 00:59:49 --> Final output sent to browser
DEBUG - 2022-03-28 00:59:49 --> Total execution time: 0.7123
ERROR - 2022-03-28 00:59:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 00:59:57 --> Config Class Initialized
INFO - 2022-03-28 00:59:57 --> Hooks Class Initialized
DEBUG - 2022-03-28 00:59:57 --> UTF-8 Support Enabled
INFO - 2022-03-28 00:59:57 --> Utf8 Class Initialized
INFO - 2022-03-28 00:59:57 --> URI Class Initialized
INFO - 2022-03-28 00:59:57 --> Router Class Initialized
INFO - 2022-03-28 00:59:57 --> Output Class Initialized
INFO - 2022-03-28 00:59:57 --> Security Class Initialized
DEBUG - 2022-03-28 00:59:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 00:59:57 --> Input Class Initialized
INFO - 2022-03-28 00:59:57 --> Language Class Initialized
INFO - 2022-03-28 00:59:57 --> Loader Class Initialized
INFO - 2022-03-28 00:59:57 --> Helper loaded: url_helper
INFO - 2022-03-28 00:59:57 --> Helper loaded: form_helper
INFO - 2022-03-28 00:59:57 --> Helper loaded: common_helper
INFO - 2022-03-28 00:59:57 --> Database Driver Class Initialized
DEBUG - 2022-03-28 00:59:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 00:59:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 00:59:57 --> Controller Class Initialized
INFO - 2022-03-28 00:59:57 --> Form Validation Class Initialized
DEBUG - 2022-03-28 00:59:57 --> Encrypt Class Initialized
INFO - 2022-03-28 00:59:57 --> Model "Patient_model" initialized
INFO - 2022-03-28 00:59:57 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 00:59:57 --> Model "Prefix_master" initialized
INFO - 2022-03-28 00:59:57 --> Model "Users_model" initialized
INFO - 2022-03-28 00:59:57 --> Model "Hospital_model" initialized
INFO - 2022-03-28 00:59:57 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-28 00:59:57 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-28 00:59:57 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-28 00:59:57 --> Final output sent to browser
DEBUG - 2022-03-28 00:59:57 --> Total execution time: 0.0406
ERROR - 2022-03-28 01:00:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 01:00:00 --> Config Class Initialized
INFO - 2022-03-28 01:00:00 --> Hooks Class Initialized
DEBUG - 2022-03-28 01:00:00 --> UTF-8 Support Enabled
INFO - 2022-03-28 01:00:00 --> Utf8 Class Initialized
INFO - 2022-03-28 01:00:00 --> URI Class Initialized
INFO - 2022-03-28 01:00:00 --> Router Class Initialized
INFO - 2022-03-28 01:00:00 --> Output Class Initialized
INFO - 2022-03-28 01:00:00 --> Security Class Initialized
DEBUG - 2022-03-28 01:00:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 01:00:00 --> Input Class Initialized
INFO - 2022-03-28 01:00:00 --> Language Class Initialized
INFO - 2022-03-28 01:00:00 --> Loader Class Initialized
INFO - 2022-03-28 01:00:00 --> Helper loaded: url_helper
INFO - 2022-03-28 01:00:00 --> Helper loaded: form_helper
INFO - 2022-03-28 01:00:00 --> Helper loaded: common_helper
INFO - 2022-03-28 01:00:00 --> Database Driver Class Initialized
DEBUG - 2022-03-28 01:00:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 01:00:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 01:00:00 --> Controller Class Initialized
INFO - 2022-03-28 01:00:00 --> Form Validation Class Initialized
DEBUG - 2022-03-28 01:00:00 --> Encrypt Class Initialized
INFO - 2022-03-28 01:00:00 --> Model "Patient_model" initialized
INFO - 2022-03-28 01:00:00 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 01:00:00 --> Model "Referredby_model" initialized
INFO - 2022-03-28 01:00:00 --> Model "Prefix_master" initialized
INFO - 2022-03-28 01:00:00 --> Model "Hospital_model" initialized
INFO - 2022-03-28 01:00:00 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-28 01:00:00 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-28 01:00:00 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-28 01:00:00 --> Final output sent to browser
DEBUG - 2022-03-28 01:00:00 --> Total execution time: 0.0219
ERROR - 2022-03-28 01:00:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 01:00:22 --> Config Class Initialized
INFO - 2022-03-28 01:00:22 --> Hooks Class Initialized
DEBUG - 2022-03-28 01:00:22 --> UTF-8 Support Enabled
INFO - 2022-03-28 01:00:22 --> Utf8 Class Initialized
INFO - 2022-03-28 01:00:22 --> URI Class Initialized
INFO - 2022-03-28 01:00:22 --> Router Class Initialized
INFO - 2022-03-28 01:00:22 --> Output Class Initialized
INFO - 2022-03-28 01:00:22 --> Security Class Initialized
DEBUG - 2022-03-28 01:00:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 01:00:22 --> Input Class Initialized
INFO - 2022-03-28 01:00:22 --> Language Class Initialized
INFO - 2022-03-28 01:00:22 --> Loader Class Initialized
INFO - 2022-03-28 01:00:22 --> Helper loaded: url_helper
INFO - 2022-03-28 01:00:22 --> Helper loaded: form_helper
INFO - 2022-03-28 01:00:22 --> Helper loaded: common_helper
INFO - 2022-03-28 01:00:22 --> Database Driver Class Initialized
DEBUG - 2022-03-28 01:00:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 01:00:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 01:00:22 --> Controller Class Initialized
INFO - 2022-03-28 01:00:22 --> Form Validation Class Initialized
DEBUG - 2022-03-28 01:00:22 --> Encrypt Class Initialized
INFO - 2022-03-28 01:00:22 --> Model "Patient_model" initialized
INFO - 2022-03-28 01:00:22 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 01:00:22 --> Model "Referredby_model" initialized
INFO - 2022-03-28 01:00:22 --> Model "Prefix_master" initialized
INFO - 2022-03-28 01:00:22 --> Model "Hospital_model" initialized
INFO - 2022-03-28 01:00:22 --> Upload Class Initialized
INFO - 2022-03-28 01:00:22 --> Final output sent to browser
DEBUG - 2022-03-28 01:00:22 --> Total execution time: 0.0114
ERROR - 2022-03-28 01:00:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 01:00:38 --> Config Class Initialized
INFO - 2022-03-28 01:00:38 --> Hooks Class Initialized
DEBUG - 2022-03-28 01:00:38 --> UTF-8 Support Enabled
INFO - 2022-03-28 01:00:38 --> Utf8 Class Initialized
INFO - 2022-03-28 01:00:38 --> URI Class Initialized
INFO - 2022-03-28 01:00:38 --> Router Class Initialized
INFO - 2022-03-28 01:00:38 --> Output Class Initialized
INFO - 2022-03-28 01:00:38 --> Security Class Initialized
DEBUG - 2022-03-28 01:00:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 01:00:38 --> Input Class Initialized
INFO - 2022-03-28 01:00:38 --> Language Class Initialized
INFO - 2022-03-28 01:00:38 --> Loader Class Initialized
INFO - 2022-03-28 01:00:38 --> Helper loaded: url_helper
INFO - 2022-03-28 01:00:38 --> Helper loaded: form_helper
INFO - 2022-03-28 01:00:38 --> Helper loaded: common_helper
INFO - 2022-03-28 01:00:38 --> Database Driver Class Initialized
DEBUG - 2022-03-28 01:00:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 01:00:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 01:00:38 --> Controller Class Initialized
INFO - 2022-03-28 01:00:38 --> Form Validation Class Initialized
DEBUG - 2022-03-28 01:00:38 --> Encrypt Class Initialized
INFO - 2022-03-28 01:00:38 --> Model "Patient_model" initialized
INFO - 2022-03-28 01:00:38 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 01:00:38 --> Model "Prefix_master" initialized
INFO - 2022-03-28 01:00:38 --> Model "Users_model" initialized
INFO - 2022-03-28 01:00:38 --> Model "Hospital_model" initialized
INFO - 2022-03-28 01:00:38 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-28 01:00:39 --> Final output sent to browser
DEBUG - 2022-03-28 01:00:39 --> Total execution time: 0.7238
ERROR - 2022-03-28 01:01:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 01:01:04 --> Config Class Initialized
INFO - 2022-03-28 01:01:04 --> Hooks Class Initialized
DEBUG - 2022-03-28 01:01:04 --> UTF-8 Support Enabled
INFO - 2022-03-28 01:01:04 --> Utf8 Class Initialized
INFO - 2022-03-28 01:01:04 --> URI Class Initialized
INFO - 2022-03-28 01:01:04 --> Router Class Initialized
INFO - 2022-03-28 01:01:04 --> Output Class Initialized
INFO - 2022-03-28 01:01:04 --> Security Class Initialized
DEBUG - 2022-03-28 01:01:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 01:01:04 --> Input Class Initialized
INFO - 2022-03-28 01:01:04 --> Language Class Initialized
INFO - 2022-03-28 01:01:04 --> Loader Class Initialized
INFO - 2022-03-28 01:01:04 --> Helper loaded: url_helper
INFO - 2022-03-28 01:01:04 --> Helper loaded: form_helper
INFO - 2022-03-28 01:01:04 --> Helper loaded: common_helper
INFO - 2022-03-28 01:01:04 --> Database Driver Class Initialized
DEBUG - 2022-03-28 01:01:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 01:01:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 01:01:04 --> Controller Class Initialized
INFO - 2022-03-28 01:01:04 --> Form Validation Class Initialized
DEBUG - 2022-03-28 01:01:04 --> Encrypt Class Initialized
INFO - 2022-03-28 01:01:04 --> Model "Patient_model" initialized
INFO - 2022-03-28 01:01:04 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 01:01:04 --> Model "Referredby_model" initialized
INFO - 2022-03-28 01:01:04 --> Model "Prefix_master" initialized
INFO - 2022-03-28 01:01:04 --> Model "Hospital_model" initialized
INFO - 2022-03-28 01:01:04 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-28 01:01:04 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-28 01:01:04 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-28 01:01:04 --> Final output sent to browser
DEBUG - 2022-03-28 01:01:04 --> Total execution time: 0.0262
ERROR - 2022-03-28 01:01:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 01:01:27 --> Config Class Initialized
INFO - 2022-03-28 01:01:27 --> Hooks Class Initialized
DEBUG - 2022-03-28 01:01:27 --> UTF-8 Support Enabled
INFO - 2022-03-28 01:01:27 --> Utf8 Class Initialized
INFO - 2022-03-28 01:01:27 --> URI Class Initialized
INFO - 2022-03-28 01:01:27 --> Router Class Initialized
INFO - 2022-03-28 01:01:27 --> Output Class Initialized
INFO - 2022-03-28 01:01:27 --> Security Class Initialized
DEBUG - 2022-03-28 01:01:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 01:01:27 --> Input Class Initialized
INFO - 2022-03-28 01:01:27 --> Language Class Initialized
INFO - 2022-03-28 01:01:27 --> Loader Class Initialized
INFO - 2022-03-28 01:01:27 --> Helper loaded: url_helper
INFO - 2022-03-28 01:01:27 --> Helper loaded: form_helper
INFO - 2022-03-28 01:01:27 --> Helper loaded: common_helper
INFO - 2022-03-28 01:01:27 --> Database Driver Class Initialized
DEBUG - 2022-03-28 01:01:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 01:01:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 01:01:27 --> Controller Class Initialized
INFO - 2022-03-28 01:01:27 --> Form Validation Class Initialized
DEBUG - 2022-03-28 01:01:27 --> Encrypt Class Initialized
INFO - 2022-03-28 01:01:27 --> Model "Patient_model" initialized
INFO - 2022-03-28 01:01:27 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 01:01:27 --> Model "Referredby_model" initialized
INFO - 2022-03-28 01:01:27 --> Model "Prefix_master" initialized
INFO - 2022-03-28 01:01:27 --> Model "Hospital_model" initialized
ERROR - 2022-03-28 01:01:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 01:01:28 --> Config Class Initialized
INFO - 2022-03-28 01:01:28 --> Hooks Class Initialized
DEBUG - 2022-03-28 01:01:28 --> UTF-8 Support Enabled
INFO - 2022-03-28 01:01:28 --> Utf8 Class Initialized
INFO - 2022-03-28 01:01:28 --> URI Class Initialized
INFO - 2022-03-28 01:01:28 --> Router Class Initialized
INFO - 2022-03-28 01:01:28 --> Output Class Initialized
INFO - 2022-03-28 01:01:28 --> Security Class Initialized
DEBUG - 2022-03-28 01:01:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 01:01:28 --> Input Class Initialized
INFO - 2022-03-28 01:01:28 --> Language Class Initialized
INFO - 2022-03-28 01:01:28 --> Loader Class Initialized
INFO - 2022-03-28 01:01:28 --> Helper loaded: url_helper
INFO - 2022-03-28 01:01:28 --> Helper loaded: form_helper
INFO - 2022-03-28 01:01:28 --> Helper loaded: common_helper
INFO - 2022-03-28 01:01:28 --> Database Driver Class Initialized
DEBUG - 2022-03-28 01:01:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 01:01:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 01:01:28 --> Controller Class Initialized
INFO - 2022-03-28 01:01:28 --> Form Validation Class Initialized
DEBUG - 2022-03-28 01:01:28 --> Encrypt Class Initialized
INFO - 2022-03-28 01:01:28 --> Model "Patient_model" initialized
INFO - 2022-03-28 01:01:28 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 01:01:28 --> Model "Referredby_model" initialized
INFO - 2022-03-28 01:01:28 --> Model "Prefix_master" initialized
INFO - 2022-03-28 01:01:28 --> Model "Hospital_model" initialized
INFO - 2022-03-28 01:01:28 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-28 01:01:28 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-28 01:01:28 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-28 01:01:28 --> Final output sent to browser
DEBUG - 2022-03-28 01:01:28 --> Total execution time: 0.0272
ERROR - 2022-03-28 01:01:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 01:01:29 --> Config Class Initialized
INFO - 2022-03-28 01:01:29 --> Hooks Class Initialized
DEBUG - 2022-03-28 01:01:29 --> UTF-8 Support Enabled
INFO - 2022-03-28 01:01:29 --> Utf8 Class Initialized
INFO - 2022-03-28 01:01:29 --> URI Class Initialized
INFO - 2022-03-28 01:01:29 --> Router Class Initialized
INFO - 2022-03-28 01:01:29 --> Output Class Initialized
INFO - 2022-03-28 01:01:29 --> Security Class Initialized
DEBUG - 2022-03-28 01:01:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 01:01:29 --> Input Class Initialized
INFO - 2022-03-28 01:01:29 --> Language Class Initialized
INFO - 2022-03-28 01:01:29 --> Loader Class Initialized
INFO - 2022-03-28 01:01:29 --> Helper loaded: url_helper
INFO - 2022-03-28 01:01:29 --> Helper loaded: form_helper
INFO - 2022-03-28 01:01:29 --> Helper loaded: common_helper
INFO - 2022-03-28 01:01:29 --> Database Driver Class Initialized
DEBUG - 2022-03-28 01:01:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 01:01:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 01:01:29 --> Controller Class Initialized
INFO - 2022-03-28 01:01:29 --> Form Validation Class Initialized
DEBUG - 2022-03-28 01:01:29 --> Encrypt Class Initialized
INFO - 2022-03-28 01:01:29 --> Model "Patient_model" initialized
INFO - 2022-03-28 01:01:29 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 01:01:29 --> Model "Prefix_master" initialized
INFO - 2022-03-28 01:01:29 --> Model "Users_model" initialized
INFO - 2022-03-28 01:01:29 --> Model "Hospital_model" initialized
INFO - 2022-03-28 01:01:29 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-28 01:01:29 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-28 01:01:29 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-28 01:01:29 --> Final output sent to browser
DEBUG - 2022-03-28 01:01:29 --> Total execution time: 0.0565
ERROR - 2022-03-28 01:03:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 01:03:52 --> Config Class Initialized
INFO - 2022-03-28 01:03:52 --> Hooks Class Initialized
DEBUG - 2022-03-28 01:03:52 --> UTF-8 Support Enabled
INFO - 2022-03-28 01:03:52 --> Utf8 Class Initialized
INFO - 2022-03-28 01:03:52 --> URI Class Initialized
DEBUG - 2022-03-28 01:03:52 --> No URI present. Default controller set.
INFO - 2022-03-28 01:03:52 --> Router Class Initialized
INFO - 2022-03-28 01:03:52 --> Output Class Initialized
INFO - 2022-03-28 01:03:52 --> Security Class Initialized
DEBUG - 2022-03-28 01:03:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 01:03:52 --> Input Class Initialized
INFO - 2022-03-28 01:03:52 --> Language Class Initialized
INFO - 2022-03-28 01:03:52 --> Loader Class Initialized
INFO - 2022-03-28 01:03:52 --> Helper loaded: url_helper
INFO - 2022-03-28 01:03:52 --> Helper loaded: form_helper
INFO - 2022-03-28 01:03:52 --> Helper loaded: common_helper
INFO - 2022-03-28 01:03:52 --> Database Driver Class Initialized
DEBUG - 2022-03-28 01:03:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 01:03:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 01:03:52 --> Controller Class Initialized
INFO - 2022-03-28 01:03:52 --> Form Validation Class Initialized
DEBUG - 2022-03-28 01:03:52 --> Encrypt Class Initialized
DEBUG - 2022-03-28 01:03:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-28 01:03:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-28 01:03:52 --> Email Class Initialized
INFO - 2022-03-28 01:03:52 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-28 01:03:52 --> Calendar Class Initialized
INFO - 2022-03-28 01:03:52 --> Model "Login_model" initialized
INFO - 2022-03-28 01:03:52 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-28 01:03:52 --> Final output sent to browser
DEBUG - 2022-03-28 01:03:52 --> Total execution time: 0.0701
ERROR - 2022-03-28 01:05:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 01:05:08 --> Config Class Initialized
INFO - 2022-03-28 01:05:08 --> Hooks Class Initialized
DEBUG - 2022-03-28 01:05:08 --> UTF-8 Support Enabled
INFO - 2022-03-28 01:05:08 --> Utf8 Class Initialized
INFO - 2022-03-28 01:05:08 --> URI Class Initialized
INFO - 2022-03-28 01:05:08 --> Router Class Initialized
INFO - 2022-03-28 01:05:08 --> Output Class Initialized
INFO - 2022-03-28 01:05:08 --> Security Class Initialized
DEBUG - 2022-03-28 01:05:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 01:05:08 --> Input Class Initialized
INFO - 2022-03-28 01:05:08 --> Language Class Initialized
INFO - 2022-03-28 01:05:08 --> Loader Class Initialized
INFO - 2022-03-28 01:05:08 --> Helper loaded: url_helper
INFO - 2022-03-28 01:05:08 --> Helper loaded: form_helper
INFO - 2022-03-28 01:05:08 --> Helper loaded: common_helper
INFO - 2022-03-28 01:05:08 --> Database Driver Class Initialized
DEBUG - 2022-03-28 01:05:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 01:05:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 01:05:08 --> Controller Class Initialized
INFO - 2022-03-28 01:05:08 --> Form Validation Class Initialized
DEBUG - 2022-03-28 01:05:08 --> Encrypt Class Initialized
INFO - 2022-03-28 01:05:08 --> Model "Patient_model" initialized
INFO - 2022-03-28 01:05:08 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 01:05:08 --> Model "Prefix_master" initialized
INFO - 2022-03-28 01:05:08 --> Model "Users_model" initialized
INFO - 2022-03-28 01:05:08 --> Model "Hospital_model" initialized
ERROR - 2022-03-28 01:05:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 01:05:09 --> Config Class Initialized
INFO - 2022-03-28 01:05:09 --> Hooks Class Initialized
DEBUG - 2022-03-28 01:05:09 --> UTF-8 Support Enabled
INFO - 2022-03-28 01:05:09 --> Utf8 Class Initialized
INFO - 2022-03-28 01:05:09 --> URI Class Initialized
INFO - 2022-03-28 01:05:09 --> Router Class Initialized
INFO - 2022-03-28 01:05:09 --> Output Class Initialized
INFO - 2022-03-28 01:05:09 --> Security Class Initialized
DEBUG - 2022-03-28 01:05:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 01:05:09 --> Input Class Initialized
INFO - 2022-03-28 01:05:09 --> Language Class Initialized
INFO - 2022-03-28 01:05:09 --> Loader Class Initialized
INFO - 2022-03-28 01:05:09 --> Helper loaded: url_helper
INFO - 2022-03-28 01:05:09 --> Helper loaded: form_helper
INFO - 2022-03-28 01:05:09 --> Helper loaded: common_helper
INFO - 2022-03-28 01:05:09 --> Database Driver Class Initialized
DEBUG - 2022-03-28 01:05:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 01:05:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 01:05:09 --> Controller Class Initialized
INFO - 2022-03-28 01:05:09 --> Form Validation Class Initialized
DEBUG - 2022-03-28 01:05:09 --> Encrypt Class Initialized
INFO - 2022-03-28 01:05:09 --> Model "Patient_model" initialized
INFO - 2022-03-28 01:05:09 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 01:05:09 --> Model "Prefix_master" initialized
INFO - 2022-03-28 01:05:09 --> Model "Users_model" initialized
INFO - 2022-03-28 01:05:09 --> Model "Hospital_model" initialized
INFO - 2022-03-28 01:05:09 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-28 01:05:09 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-28 01:05:09 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-28 01:05:09 --> Final output sent to browser
DEBUG - 2022-03-28 01:05:09 --> Total execution time: 0.0781
ERROR - 2022-03-28 01:05:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 01:05:56 --> Config Class Initialized
INFO - 2022-03-28 01:05:56 --> Hooks Class Initialized
DEBUG - 2022-03-28 01:05:56 --> UTF-8 Support Enabled
INFO - 2022-03-28 01:05:56 --> Utf8 Class Initialized
INFO - 2022-03-28 01:05:56 --> URI Class Initialized
INFO - 2022-03-28 01:05:56 --> Router Class Initialized
INFO - 2022-03-28 01:05:56 --> Output Class Initialized
INFO - 2022-03-28 01:05:56 --> Security Class Initialized
DEBUG - 2022-03-28 01:05:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 01:05:56 --> Input Class Initialized
INFO - 2022-03-28 01:05:56 --> Language Class Initialized
INFO - 2022-03-28 01:05:56 --> Loader Class Initialized
INFO - 2022-03-28 01:05:56 --> Helper loaded: url_helper
INFO - 2022-03-28 01:05:56 --> Helper loaded: form_helper
INFO - 2022-03-28 01:05:56 --> Helper loaded: common_helper
INFO - 2022-03-28 01:05:56 --> Database Driver Class Initialized
DEBUG - 2022-03-28 01:05:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 01:05:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 01:05:56 --> Controller Class Initialized
INFO - 2022-03-28 01:05:56 --> Form Validation Class Initialized
DEBUG - 2022-03-28 01:05:56 --> Encrypt Class Initialized
INFO - 2022-03-28 01:05:56 --> Model "Patient_model" initialized
INFO - 2022-03-28 01:05:56 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 01:05:56 --> Model "Prefix_master" initialized
INFO - 2022-03-28 01:05:56 --> Model "Users_model" initialized
INFO - 2022-03-28 01:05:56 --> Model "Hospital_model" initialized
INFO - 2022-03-28 01:05:56 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-28 01:05:56 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-28 01:05:56 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-28 01:05:56 --> Final output sent to browser
DEBUG - 2022-03-28 01:05:56 --> Total execution time: 0.1310
ERROR - 2022-03-28 01:05:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 01:05:58 --> Config Class Initialized
INFO - 2022-03-28 01:05:58 --> Hooks Class Initialized
DEBUG - 2022-03-28 01:05:58 --> UTF-8 Support Enabled
INFO - 2022-03-28 01:05:58 --> Utf8 Class Initialized
INFO - 2022-03-28 01:05:58 --> URI Class Initialized
INFO - 2022-03-28 01:05:58 --> Router Class Initialized
INFO - 2022-03-28 01:05:58 --> Output Class Initialized
INFO - 2022-03-28 01:05:58 --> Security Class Initialized
DEBUG - 2022-03-28 01:05:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 01:05:58 --> Input Class Initialized
INFO - 2022-03-28 01:05:58 --> Language Class Initialized
INFO - 2022-03-28 01:05:58 --> Loader Class Initialized
INFO - 2022-03-28 01:05:58 --> Helper loaded: url_helper
INFO - 2022-03-28 01:05:58 --> Helper loaded: form_helper
INFO - 2022-03-28 01:05:58 --> Helper loaded: common_helper
INFO - 2022-03-28 01:05:58 --> Database Driver Class Initialized
DEBUG - 2022-03-28 01:05:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 01:05:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 01:05:58 --> Controller Class Initialized
INFO - 2022-03-28 01:05:58 --> Form Validation Class Initialized
DEBUG - 2022-03-28 01:05:58 --> Encrypt Class Initialized
INFO - 2022-03-28 01:05:58 --> Model "Patient_model" initialized
INFO - 2022-03-28 01:05:58 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 01:05:58 --> Model "Referredby_model" initialized
INFO - 2022-03-28 01:05:58 --> Model "Prefix_master" initialized
INFO - 2022-03-28 01:05:58 --> Model "Hospital_model" initialized
INFO - 2022-03-28 01:05:58 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-28 01:05:58 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-28 01:05:58 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-28 01:05:58 --> Final output sent to browser
DEBUG - 2022-03-28 01:05:58 --> Total execution time: 0.0321
ERROR - 2022-03-28 01:06:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 01:06:11 --> Config Class Initialized
INFO - 2022-03-28 01:06:11 --> Hooks Class Initialized
DEBUG - 2022-03-28 01:06:11 --> UTF-8 Support Enabled
INFO - 2022-03-28 01:06:11 --> Utf8 Class Initialized
INFO - 2022-03-28 01:06:11 --> URI Class Initialized
INFO - 2022-03-28 01:06:11 --> Router Class Initialized
INFO - 2022-03-28 01:06:11 --> Output Class Initialized
INFO - 2022-03-28 01:06:11 --> Security Class Initialized
DEBUG - 2022-03-28 01:06:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 01:06:11 --> Input Class Initialized
INFO - 2022-03-28 01:06:11 --> Language Class Initialized
INFO - 2022-03-28 01:06:11 --> Loader Class Initialized
INFO - 2022-03-28 01:06:11 --> Helper loaded: url_helper
INFO - 2022-03-28 01:06:11 --> Helper loaded: form_helper
INFO - 2022-03-28 01:06:11 --> Helper loaded: common_helper
INFO - 2022-03-28 01:06:11 --> Database Driver Class Initialized
DEBUG - 2022-03-28 01:06:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 01:06:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 01:06:11 --> Controller Class Initialized
INFO - 2022-03-28 01:06:11 --> Form Validation Class Initialized
DEBUG - 2022-03-28 01:06:11 --> Encrypt Class Initialized
INFO - 2022-03-28 01:06:11 --> Model "Patient_model" initialized
INFO - 2022-03-28 01:06:11 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 01:06:11 --> Model "Referredby_model" initialized
INFO - 2022-03-28 01:06:11 --> Model "Prefix_master" initialized
INFO - 2022-03-28 01:06:11 --> Model "Hospital_model" initialized
INFO - 2022-03-28 01:06:11 --> Upload Class Initialized
INFO - 2022-03-28 01:06:11 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2022-03-28 01:06:11 --> The filetype you are attempting to upload is not allowed.
INFO - 2022-03-28 01:06:11 --> Final output sent to browser
DEBUG - 2022-03-28 01:06:11 --> Total execution time: 0.0153
ERROR - 2022-03-28 01:06:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 01:06:31 --> Config Class Initialized
INFO - 2022-03-28 01:06:31 --> Hooks Class Initialized
DEBUG - 2022-03-28 01:06:31 --> UTF-8 Support Enabled
INFO - 2022-03-28 01:06:31 --> Utf8 Class Initialized
INFO - 2022-03-28 01:06:31 --> URI Class Initialized
INFO - 2022-03-28 01:06:31 --> Router Class Initialized
INFO - 2022-03-28 01:06:31 --> Output Class Initialized
INFO - 2022-03-28 01:06:31 --> Security Class Initialized
DEBUG - 2022-03-28 01:06:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 01:06:31 --> Input Class Initialized
INFO - 2022-03-28 01:06:31 --> Language Class Initialized
INFO - 2022-03-28 01:06:31 --> Loader Class Initialized
INFO - 2022-03-28 01:06:31 --> Helper loaded: url_helper
INFO - 2022-03-28 01:06:31 --> Helper loaded: form_helper
INFO - 2022-03-28 01:06:31 --> Helper loaded: common_helper
INFO - 2022-03-28 01:06:31 --> Database Driver Class Initialized
DEBUG - 2022-03-28 01:06:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 01:06:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 01:06:31 --> Controller Class Initialized
INFO - 2022-03-28 01:06:31 --> Form Validation Class Initialized
DEBUG - 2022-03-28 01:06:31 --> Encrypt Class Initialized
INFO - 2022-03-28 01:06:31 --> Model "Patient_model" initialized
INFO - 2022-03-28 01:06:31 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 01:06:31 --> Model "Prefix_master" initialized
INFO - 2022-03-28 01:06:31 --> Model "Users_model" initialized
INFO - 2022-03-28 01:06:31 --> Model "Hospital_model" initialized
INFO - 2022-03-28 01:06:31 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-28 01:06:32 --> Final output sent to browser
DEBUG - 2022-03-28 01:06:32 --> Total execution time: 0.9898
ERROR - 2022-03-28 01:07:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 01:07:18 --> Config Class Initialized
INFO - 2022-03-28 01:07:18 --> Hooks Class Initialized
DEBUG - 2022-03-28 01:07:18 --> UTF-8 Support Enabled
INFO - 2022-03-28 01:07:18 --> Utf8 Class Initialized
INFO - 2022-03-28 01:07:18 --> URI Class Initialized
INFO - 2022-03-28 01:07:18 --> Router Class Initialized
INFO - 2022-03-28 01:07:18 --> Output Class Initialized
INFO - 2022-03-28 01:07:18 --> Security Class Initialized
DEBUG - 2022-03-28 01:07:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 01:07:18 --> Input Class Initialized
INFO - 2022-03-28 01:07:18 --> Language Class Initialized
INFO - 2022-03-28 01:07:18 --> Loader Class Initialized
INFO - 2022-03-28 01:07:18 --> Helper loaded: url_helper
INFO - 2022-03-28 01:07:18 --> Helper loaded: form_helper
INFO - 2022-03-28 01:07:18 --> Helper loaded: common_helper
INFO - 2022-03-28 01:07:18 --> Database Driver Class Initialized
DEBUG - 2022-03-28 01:07:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 01:07:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 01:07:18 --> Controller Class Initialized
INFO - 2022-03-28 01:07:18 --> Form Validation Class Initialized
DEBUG - 2022-03-28 01:07:18 --> Encrypt Class Initialized
INFO - 2022-03-28 01:07:18 --> Model "Patient_model" initialized
INFO - 2022-03-28 01:07:18 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 01:07:18 --> Model "Referredby_model" initialized
INFO - 2022-03-28 01:07:18 --> Model "Prefix_master" initialized
INFO - 2022-03-28 01:07:18 --> Model "Hospital_model" initialized
INFO - 2022-03-28 01:07:18 --> Upload Class Initialized
INFO - 2022-03-28 01:07:18 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2022-03-28 01:07:18 --> The filetype you are attempting to upload is not allowed.
INFO - 2022-03-28 01:07:18 --> Final output sent to browser
DEBUG - 2022-03-28 01:07:18 --> Total execution time: 0.0104
ERROR - 2022-03-28 01:07:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 01:07:30 --> Config Class Initialized
INFO - 2022-03-28 01:07:30 --> Hooks Class Initialized
DEBUG - 2022-03-28 01:07:30 --> UTF-8 Support Enabled
INFO - 2022-03-28 01:07:30 --> Utf8 Class Initialized
INFO - 2022-03-28 01:07:30 --> URI Class Initialized
INFO - 2022-03-28 01:07:30 --> Router Class Initialized
INFO - 2022-03-28 01:07:30 --> Output Class Initialized
INFO - 2022-03-28 01:07:30 --> Security Class Initialized
DEBUG - 2022-03-28 01:07:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 01:07:30 --> Input Class Initialized
INFO - 2022-03-28 01:07:30 --> Language Class Initialized
INFO - 2022-03-28 01:07:30 --> Loader Class Initialized
INFO - 2022-03-28 01:07:30 --> Helper loaded: url_helper
INFO - 2022-03-28 01:07:30 --> Helper loaded: form_helper
INFO - 2022-03-28 01:07:30 --> Helper loaded: common_helper
INFO - 2022-03-28 01:07:30 --> Database Driver Class Initialized
DEBUG - 2022-03-28 01:07:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 01:07:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 01:07:30 --> Controller Class Initialized
INFO - 2022-03-28 01:07:30 --> Form Validation Class Initialized
DEBUG - 2022-03-28 01:07:30 --> Encrypt Class Initialized
INFO - 2022-03-28 01:07:30 --> Model "Patient_model" initialized
INFO - 2022-03-28 01:07:30 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 01:07:30 --> Model "Prefix_master" initialized
INFO - 2022-03-28 01:07:30 --> Model "Users_model" initialized
INFO - 2022-03-28 01:07:30 --> Model "Hospital_model" initialized
INFO - 2022-03-28 01:07:30 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-28 01:07:31 --> Final output sent to browser
DEBUG - 2022-03-28 01:07:31 --> Total execution time: 0.6896
ERROR - 2022-03-28 01:09:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 01:09:30 --> Config Class Initialized
INFO - 2022-03-28 01:09:30 --> Hooks Class Initialized
DEBUG - 2022-03-28 01:09:30 --> UTF-8 Support Enabled
INFO - 2022-03-28 01:09:30 --> Utf8 Class Initialized
INFO - 2022-03-28 01:09:30 --> URI Class Initialized
INFO - 2022-03-28 01:09:30 --> Router Class Initialized
INFO - 2022-03-28 01:09:30 --> Output Class Initialized
INFO - 2022-03-28 01:09:30 --> Security Class Initialized
DEBUG - 2022-03-28 01:09:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 01:09:30 --> Input Class Initialized
INFO - 2022-03-28 01:09:30 --> Language Class Initialized
INFO - 2022-03-28 01:09:30 --> Loader Class Initialized
INFO - 2022-03-28 01:09:30 --> Helper loaded: url_helper
INFO - 2022-03-28 01:09:30 --> Helper loaded: form_helper
INFO - 2022-03-28 01:09:30 --> Helper loaded: common_helper
INFO - 2022-03-28 01:09:30 --> Database Driver Class Initialized
DEBUG - 2022-03-28 01:09:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 01:09:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 01:09:30 --> Controller Class Initialized
INFO - 2022-03-28 01:09:30 --> Form Validation Class Initialized
DEBUG - 2022-03-28 01:09:30 --> Encrypt Class Initialized
INFO - 2022-03-28 01:09:30 --> Model "Patient_model" initialized
INFO - 2022-03-28 01:09:30 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 01:09:30 --> Model "Prefix_master" initialized
INFO - 2022-03-28 01:09:30 --> Model "Users_model" initialized
INFO - 2022-03-28 01:09:30 --> Model "Hospital_model" initialized
INFO - 2022-03-28 01:09:30 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-28 01:09:30 --> Final output sent to browser
DEBUG - 2022-03-28 01:09:30 --> Total execution time: 0.6797
ERROR - 2022-03-28 01:09:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 01:09:42 --> Config Class Initialized
INFO - 2022-03-28 01:09:42 --> Hooks Class Initialized
DEBUG - 2022-03-28 01:09:42 --> UTF-8 Support Enabled
INFO - 2022-03-28 01:09:42 --> Utf8 Class Initialized
INFO - 2022-03-28 01:09:42 --> URI Class Initialized
INFO - 2022-03-28 01:09:42 --> Router Class Initialized
INFO - 2022-03-28 01:09:42 --> Output Class Initialized
INFO - 2022-03-28 01:09:42 --> Security Class Initialized
DEBUG - 2022-03-28 01:09:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 01:09:42 --> Input Class Initialized
INFO - 2022-03-28 01:09:42 --> Language Class Initialized
INFO - 2022-03-28 01:09:42 --> Loader Class Initialized
INFO - 2022-03-28 01:09:42 --> Helper loaded: url_helper
INFO - 2022-03-28 01:09:42 --> Helper loaded: form_helper
INFO - 2022-03-28 01:09:42 --> Helper loaded: common_helper
INFO - 2022-03-28 01:09:42 --> Database Driver Class Initialized
DEBUG - 2022-03-28 01:09:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 01:09:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 01:09:42 --> Controller Class Initialized
INFO - 2022-03-28 01:09:42 --> Form Validation Class Initialized
DEBUG - 2022-03-28 01:09:42 --> Encrypt Class Initialized
INFO - 2022-03-28 01:09:42 --> Model "Patient_model" initialized
INFO - 2022-03-28 01:09:42 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 01:09:42 --> Model "Prefix_master" initialized
INFO - 2022-03-28 01:09:42 --> Model "Users_model" initialized
INFO - 2022-03-28 01:09:42 --> Model "Hospital_model" initialized
INFO - 2022-03-28 01:09:42 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-28 01:09:42 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-28 01:09:42 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-28 01:09:42 --> Final output sent to browser
DEBUG - 2022-03-28 01:09:42 --> Total execution time: 0.0550
ERROR - 2022-03-28 01:09:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 01:09:44 --> Config Class Initialized
INFO - 2022-03-28 01:09:44 --> Hooks Class Initialized
DEBUG - 2022-03-28 01:09:44 --> UTF-8 Support Enabled
INFO - 2022-03-28 01:09:44 --> Utf8 Class Initialized
INFO - 2022-03-28 01:09:44 --> URI Class Initialized
INFO - 2022-03-28 01:09:44 --> Router Class Initialized
INFO - 2022-03-28 01:09:44 --> Output Class Initialized
INFO - 2022-03-28 01:09:44 --> Security Class Initialized
DEBUG - 2022-03-28 01:09:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 01:09:44 --> Input Class Initialized
INFO - 2022-03-28 01:09:44 --> Language Class Initialized
INFO - 2022-03-28 01:09:44 --> Loader Class Initialized
INFO - 2022-03-28 01:09:44 --> Helper loaded: url_helper
INFO - 2022-03-28 01:09:44 --> Helper loaded: form_helper
INFO - 2022-03-28 01:09:44 --> Helper loaded: common_helper
INFO - 2022-03-28 01:09:44 --> Database Driver Class Initialized
DEBUG - 2022-03-28 01:09:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 01:09:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 01:09:44 --> Controller Class Initialized
INFO - 2022-03-28 01:09:44 --> Form Validation Class Initialized
DEBUG - 2022-03-28 01:09:44 --> Encrypt Class Initialized
INFO - 2022-03-28 01:09:44 --> Model "Patient_model" initialized
INFO - 2022-03-28 01:09:44 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 01:09:44 --> Model "Referredby_model" initialized
INFO - 2022-03-28 01:09:44 --> Model "Prefix_master" initialized
INFO - 2022-03-28 01:09:44 --> Model "Hospital_model" initialized
INFO - 2022-03-28 01:09:44 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-28 01:09:44 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-28 01:09:44 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-28 01:09:44 --> Final output sent to browser
DEBUG - 2022-03-28 01:09:44 --> Total execution time: 0.0283
ERROR - 2022-03-28 01:14:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 01:14:47 --> Config Class Initialized
INFO - 2022-03-28 01:14:47 --> Hooks Class Initialized
DEBUG - 2022-03-28 01:14:47 --> UTF-8 Support Enabled
INFO - 2022-03-28 01:14:47 --> Utf8 Class Initialized
INFO - 2022-03-28 01:14:47 --> URI Class Initialized
INFO - 2022-03-28 01:14:47 --> Router Class Initialized
INFO - 2022-03-28 01:14:47 --> Output Class Initialized
INFO - 2022-03-28 01:14:47 --> Security Class Initialized
DEBUG - 2022-03-28 01:14:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 01:14:47 --> Input Class Initialized
INFO - 2022-03-28 01:14:47 --> Language Class Initialized
INFO - 2022-03-28 01:14:47 --> Loader Class Initialized
INFO - 2022-03-28 01:14:47 --> Helper loaded: url_helper
INFO - 2022-03-28 01:14:47 --> Helper loaded: form_helper
INFO - 2022-03-28 01:14:47 --> Helper loaded: common_helper
INFO - 2022-03-28 01:14:47 --> Database Driver Class Initialized
DEBUG - 2022-03-28 01:14:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 01:14:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 01:14:47 --> Controller Class Initialized
INFO - 2022-03-28 01:14:47 --> Form Validation Class Initialized
DEBUG - 2022-03-28 01:14:47 --> Encrypt Class Initialized
INFO - 2022-03-28 01:14:47 --> Model "Patient_model" initialized
INFO - 2022-03-28 01:14:47 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 01:14:47 --> Model "Prefix_master" initialized
INFO - 2022-03-28 01:14:47 --> Model "Users_model" initialized
INFO - 2022-03-28 01:14:47 --> Model "Hospital_model" initialized
ERROR - 2022-03-28 01:14:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 01:14:48 --> Config Class Initialized
INFO - 2022-03-28 01:14:48 --> Hooks Class Initialized
DEBUG - 2022-03-28 01:14:48 --> UTF-8 Support Enabled
INFO - 2022-03-28 01:14:48 --> Utf8 Class Initialized
INFO - 2022-03-28 01:14:48 --> URI Class Initialized
INFO - 2022-03-28 01:14:48 --> Router Class Initialized
INFO - 2022-03-28 01:14:48 --> Output Class Initialized
INFO - 2022-03-28 01:14:48 --> Security Class Initialized
DEBUG - 2022-03-28 01:14:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 01:14:48 --> Input Class Initialized
INFO - 2022-03-28 01:14:48 --> Language Class Initialized
INFO - 2022-03-28 01:14:48 --> Loader Class Initialized
INFO - 2022-03-28 01:14:48 --> Helper loaded: url_helper
INFO - 2022-03-28 01:14:48 --> Helper loaded: form_helper
INFO - 2022-03-28 01:14:48 --> Helper loaded: common_helper
INFO - 2022-03-28 01:14:48 --> Database Driver Class Initialized
DEBUG - 2022-03-28 01:14:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 01:14:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 01:14:48 --> Controller Class Initialized
INFO - 2022-03-28 01:14:48 --> Form Validation Class Initialized
DEBUG - 2022-03-28 01:14:48 --> Encrypt Class Initialized
INFO - 2022-03-28 01:14:48 --> Model "Patient_model" initialized
INFO - 2022-03-28 01:14:48 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 01:14:48 --> Model "Prefix_master" initialized
INFO - 2022-03-28 01:14:48 --> Model "Users_model" initialized
INFO - 2022-03-28 01:14:48 --> Model "Hospital_model" initialized
INFO - 2022-03-28 01:14:48 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-28 01:14:48 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-28 01:14:48 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-28 01:14:48 --> Final output sent to browser
DEBUG - 2022-03-28 01:14:48 --> Total execution time: 0.0537
ERROR - 2022-03-28 01:15:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 01:15:52 --> Config Class Initialized
INFO - 2022-03-28 01:15:52 --> Hooks Class Initialized
DEBUG - 2022-03-28 01:15:52 --> UTF-8 Support Enabled
INFO - 2022-03-28 01:15:52 --> Utf8 Class Initialized
INFO - 2022-03-28 01:15:52 --> URI Class Initialized
INFO - 2022-03-28 01:15:52 --> Router Class Initialized
INFO - 2022-03-28 01:15:52 --> Output Class Initialized
INFO - 2022-03-28 01:15:52 --> Security Class Initialized
DEBUG - 2022-03-28 01:15:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 01:15:52 --> Input Class Initialized
INFO - 2022-03-28 01:15:52 --> Language Class Initialized
INFO - 2022-03-28 01:15:52 --> Loader Class Initialized
INFO - 2022-03-28 01:15:52 --> Helper loaded: url_helper
INFO - 2022-03-28 01:15:52 --> Helper loaded: form_helper
INFO - 2022-03-28 01:15:52 --> Helper loaded: common_helper
INFO - 2022-03-28 01:15:52 --> Database Driver Class Initialized
DEBUG - 2022-03-28 01:15:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 01:15:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 01:15:52 --> Controller Class Initialized
INFO - 2022-03-28 01:15:52 --> Form Validation Class Initialized
DEBUG - 2022-03-28 01:15:52 --> Encrypt Class Initialized
INFO - 2022-03-28 01:15:52 --> Model "Patient_model" initialized
INFO - 2022-03-28 01:15:52 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 01:15:52 --> Model "Prefix_master" initialized
INFO - 2022-03-28 01:15:52 --> Model "Users_model" initialized
INFO - 2022-03-28 01:15:52 --> Model "Hospital_model" initialized
INFO - 2022-03-28 01:15:52 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-28 01:15:52 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-28 01:15:52 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-28 01:15:52 --> Final output sent to browser
DEBUG - 2022-03-28 01:15:52 --> Total execution time: 0.0476
ERROR - 2022-03-28 01:15:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 01:15:53 --> Config Class Initialized
INFO - 2022-03-28 01:15:53 --> Hooks Class Initialized
DEBUG - 2022-03-28 01:15:53 --> UTF-8 Support Enabled
INFO - 2022-03-28 01:15:53 --> Utf8 Class Initialized
INFO - 2022-03-28 01:15:53 --> URI Class Initialized
INFO - 2022-03-28 01:15:53 --> Router Class Initialized
INFO - 2022-03-28 01:15:53 --> Output Class Initialized
INFO - 2022-03-28 01:15:53 --> Security Class Initialized
DEBUG - 2022-03-28 01:15:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 01:15:53 --> Input Class Initialized
INFO - 2022-03-28 01:15:53 --> Language Class Initialized
INFO - 2022-03-28 01:15:53 --> Loader Class Initialized
INFO - 2022-03-28 01:15:53 --> Helper loaded: url_helper
INFO - 2022-03-28 01:15:53 --> Helper loaded: form_helper
INFO - 2022-03-28 01:15:53 --> Helper loaded: common_helper
INFO - 2022-03-28 01:15:53 --> Database Driver Class Initialized
DEBUG - 2022-03-28 01:15:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 01:15:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 01:15:53 --> Controller Class Initialized
INFO - 2022-03-28 01:15:53 --> Form Validation Class Initialized
DEBUG - 2022-03-28 01:15:53 --> Encrypt Class Initialized
INFO - 2022-03-28 01:15:53 --> Model "Patient_model" initialized
INFO - 2022-03-28 01:15:53 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 01:15:53 --> Model "Prefix_master" initialized
INFO - 2022-03-28 01:15:53 --> Model "Users_model" initialized
INFO - 2022-03-28 01:15:53 --> Model "Hospital_model" initialized
INFO - 2022-03-28 01:15:53 --> Upload Class Initialized
INFO - 2022-03-28 01:15:53 --> Final output sent to browser
DEBUG - 2022-03-28 01:15:53 --> Total execution time: 0.0319
ERROR - 2022-03-28 01:15:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 01:15:56 --> Config Class Initialized
INFO - 2022-03-28 01:15:56 --> Hooks Class Initialized
DEBUG - 2022-03-28 01:15:56 --> UTF-8 Support Enabled
INFO - 2022-03-28 01:15:56 --> Utf8 Class Initialized
INFO - 2022-03-28 01:15:56 --> URI Class Initialized
INFO - 2022-03-28 01:15:56 --> Router Class Initialized
INFO - 2022-03-28 01:15:56 --> Output Class Initialized
INFO - 2022-03-28 01:15:56 --> Security Class Initialized
DEBUG - 2022-03-28 01:15:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 01:15:56 --> Input Class Initialized
INFO - 2022-03-28 01:15:56 --> Language Class Initialized
INFO - 2022-03-28 01:15:56 --> Loader Class Initialized
INFO - 2022-03-28 01:15:56 --> Helper loaded: url_helper
INFO - 2022-03-28 01:15:56 --> Helper loaded: form_helper
INFO - 2022-03-28 01:15:56 --> Helper loaded: common_helper
INFO - 2022-03-28 01:15:56 --> Database Driver Class Initialized
DEBUG - 2022-03-28 01:15:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 01:15:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 01:15:56 --> Controller Class Initialized
INFO - 2022-03-28 01:15:56 --> Form Validation Class Initialized
DEBUG - 2022-03-28 01:15:56 --> Encrypt Class Initialized
INFO - 2022-03-28 01:15:56 --> Model "Patient_model" initialized
INFO - 2022-03-28 01:15:56 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 01:15:56 --> Model "Referredby_model" initialized
INFO - 2022-03-28 01:15:56 --> Model "Prefix_master" initialized
INFO - 2022-03-28 01:15:56 --> Model "Hospital_model" initialized
INFO - 2022-03-28 01:15:56 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-28 01:15:56 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-28 01:15:56 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-28 01:15:56 --> Final output sent to browser
DEBUG - 2022-03-28 01:15:56 --> Total execution time: 0.0535
ERROR - 2022-03-28 01:16:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 01:16:05 --> Config Class Initialized
INFO - 2022-03-28 01:16:05 --> Hooks Class Initialized
DEBUG - 2022-03-28 01:16:05 --> UTF-8 Support Enabled
INFO - 2022-03-28 01:16:05 --> Utf8 Class Initialized
INFO - 2022-03-28 01:16:05 --> URI Class Initialized
INFO - 2022-03-28 01:16:05 --> Router Class Initialized
INFO - 2022-03-28 01:16:05 --> Output Class Initialized
INFO - 2022-03-28 01:16:05 --> Security Class Initialized
DEBUG - 2022-03-28 01:16:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 01:16:05 --> Input Class Initialized
INFO - 2022-03-28 01:16:05 --> Language Class Initialized
INFO - 2022-03-28 01:16:05 --> Loader Class Initialized
INFO - 2022-03-28 01:16:05 --> Helper loaded: url_helper
INFO - 2022-03-28 01:16:05 --> Helper loaded: form_helper
INFO - 2022-03-28 01:16:05 --> Helper loaded: common_helper
INFO - 2022-03-28 01:16:05 --> Database Driver Class Initialized
DEBUG - 2022-03-28 01:16:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 01:16:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 01:16:05 --> Controller Class Initialized
INFO - 2022-03-28 01:16:05 --> Form Validation Class Initialized
DEBUG - 2022-03-28 01:16:05 --> Encrypt Class Initialized
INFO - 2022-03-28 01:16:05 --> Model "Patient_model" initialized
INFO - 2022-03-28 01:16:05 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 01:16:05 --> Model "Referredby_model" initialized
INFO - 2022-03-28 01:16:05 --> Model "Prefix_master" initialized
INFO - 2022-03-28 01:16:05 --> Model "Hospital_model" initialized
INFO - 2022-03-28 01:16:05 --> Upload Class Initialized
INFO - 2022-03-28 01:16:05 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2022-03-28 01:16:05 --> The filetype you are attempting to upload is not allowed.
INFO - 2022-03-28 01:16:05 --> Final output sent to browser
DEBUG - 2022-03-28 01:16:05 --> Total execution time: 0.0166
ERROR - 2022-03-28 01:16:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 01:16:10 --> Config Class Initialized
INFO - 2022-03-28 01:16:10 --> Hooks Class Initialized
DEBUG - 2022-03-28 01:16:10 --> UTF-8 Support Enabled
INFO - 2022-03-28 01:16:10 --> Utf8 Class Initialized
INFO - 2022-03-28 01:16:10 --> URI Class Initialized
INFO - 2022-03-28 01:16:10 --> Router Class Initialized
INFO - 2022-03-28 01:16:10 --> Output Class Initialized
INFO - 2022-03-28 01:16:10 --> Security Class Initialized
DEBUG - 2022-03-28 01:16:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 01:16:10 --> Input Class Initialized
INFO - 2022-03-28 01:16:10 --> Language Class Initialized
INFO - 2022-03-28 01:16:10 --> Loader Class Initialized
INFO - 2022-03-28 01:16:10 --> Helper loaded: url_helper
INFO - 2022-03-28 01:16:10 --> Helper loaded: form_helper
INFO - 2022-03-28 01:16:10 --> Helper loaded: common_helper
INFO - 2022-03-28 01:16:10 --> Database Driver Class Initialized
DEBUG - 2022-03-28 01:16:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 01:16:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 01:16:10 --> Controller Class Initialized
INFO - 2022-03-28 01:16:10 --> Form Validation Class Initialized
DEBUG - 2022-03-28 01:16:10 --> Encrypt Class Initialized
INFO - 2022-03-28 01:16:10 --> Model "Patient_model" initialized
INFO - 2022-03-28 01:16:10 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 01:16:10 --> Model "Referredby_model" initialized
INFO - 2022-03-28 01:16:10 --> Model "Prefix_master" initialized
INFO - 2022-03-28 01:16:10 --> Model "Hospital_model" initialized
INFO - 2022-03-28 01:16:10 --> Upload Class Initialized
INFO - 2022-03-28 01:16:10 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2022-03-28 01:16:10 --> The filetype you are attempting to upload is not allowed.
INFO - 2022-03-28 01:16:10 --> Final output sent to browser
DEBUG - 2022-03-28 01:16:10 --> Total execution time: 0.0070
ERROR - 2022-03-28 01:16:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 01:16:31 --> Config Class Initialized
INFO - 2022-03-28 01:16:31 --> Hooks Class Initialized
DEBUG - 2022-03-28 01:16:31 --> UTF-8 Support Enabled
INFO - 2022-03-28 01:16:31 --> Utf8 Class Initialized
INFO - 2022-03-28 01:16:31 --> URI Class Initialized
INFO - 2022-03-28 01:16:31 --> Router Class Initialized
INFO - 2022-03-28 01:16:31 --> Output Class Initialized
INFO - 2022-03-28 01:16:31 --> Security Class Initialized
DEBUG - 2022-03-28 01:16:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 01:16:31 --> Input Class Initialized
INFO - 2022-03-28 01:16:31 --> Language Class Initialized
INFO - 2022-03-28 01:16:31 --> Loader Class Initialized
INFO - 2022-03-28 01:16:31 --> Helper loaded: url_helper
INFO - 2022-03-28 01:16:31 --> Helper loaded: form_helper
INFO - 2022-03-28 01:16:31 --> Helper loaded: common_helper
INFO - 2022-03-28 01:16:31 --> Database Driver Class Initialized
DEBUG - 2022-03-28 01:16:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 01:16:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 01:16:31 --> Controller Class Initialized
INFO - 2022-03-28 01:16:31 --> Form Validation Class Initialized
DEBUG - 2022-03-28 01:16:31 --> Encrypt Class Initialized
INFO - 2022-03-28 01:16:31 --> Model "Patient_model" initialized
INFO - 2022-03-28 01:16:31 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 01:16:31 --> Model "Referredby_model" initialized
INFO - 2022-03-28 01:16:31 --> Model "Prefix_master" initialized
INFO - 2022-03-28 01:16:31 --> Model "Hospital_model" initialized
INFO - 2022-03-28 01:16:31 --> Upload Class Initialized
INFO - 2022-03-28 01:16:31 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2022-03-28 01:16:31 --> The filetype you are attempting to upload is not allowed.
INFO - 2022-03-28 01:16:31 --> Final output sent to browser
DEBUG - 2022-03-28 01:16:31 --> Total execution time: 0.0287
ERROR - 2022-03-28 01:16:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 01:16:40 --> Config Class Initialized
INFO - 2022-03-28 01:16:40 --> Hooks Class Initialized
DEBUG - 2022-03-28 01:16:40 --> UTF-8 Support Enabled
INFO - 2022-03-28 01:16:40 --> Utf8 Class Initialized
INFO - 2022-03-28 01:16:40 --> URI Class Initialized
INFO - 2022-03-28 01:16:40 --> Router Class Initialized
INFO - 2022-03-28 01:16:40 --> Output Class Initialized
INFO - 2022-03-28 01:16:40 --> Security Class Initialized
DEBUG - 2022-03-28 01:16:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 01:16:40 --> Input Class Initialized
INFO - 2022-03-28 01:16:40 --> Language Class Initialized
INFO - 2022-03-28 01:16:40 --> Loader Class Initialized
INFO - 2022-03-28 01:16:40 --> Helper loaded: url_helper
INFO - 2022-03-28 01:16:40 --> Helper loaded: form_helper
INFO - 2022-03-28 01:16:40 --> Helper loaded: common_helper
INFO - 2022-03-28 01:16:40 --> Database Driver Class Initialized
DEBUG - 2022-03-28 01:16:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 01:16:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 01:16:40 --> Controller Class Initialized
INFO - 2022-03-28 01:16:40 --> Form Validation Class Initialized
DEBUG - 2022-03-28 01:16:40 --> Encrypt Class Initialized
INFO - 2022-03-28 01:16:40 --> Model "Patient_model" initialized
INFO - 2022-03-28 01:16:40 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 01:16:40 --> Model "Prefix_master" initialized
INFO - 2022-03-28 01:16:40 --> Model "Users_model" initialized
INFO - 2022-03-28 01:16:40 --> Model "Hospital_model" initialized
INFO - 2022-03-28 01:16:40 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-28 01:16:41 --> Final output sent to browser
DEBUG - 2022-03-28 01:16:41 --> Total execution time: 1.2126
ERROR - 2022-03-28 01:17:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 01:17:40 --> Config Class Initialized
INFO - 2022-03-28 01:17:40 --> Hooks Class Initialized
DEBUG - 2022-03-28 01:17:40 --> UTF-8 Support Enabled
INFO - 2022-03-28 01:17:40 --> Utf8 Class Initialized
INFO - 2022-03-28 01:17:40 --> URI Class Initialized
INFO - 2022-03-28 01:17:40 --> Router Class Initialized
INFO - 2022-03-28 01:17:40 --> Output Class Initialized
INFO - 2022-03-28 01:17:40 --> Security Class Initialized
DEBUG - 2022-03-28 01:17:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 01:17:40 --> Input Class Initialized
INFO - 2022-03-28 01:17:40 --> Language Class Initialized
INFO - 2022-03-28 01:17:40 --> Loader Class Initialized
INFO - 2022-03-28 01:17:40 --> Helper loaded: url_helper
INFO - 2022-03-28 01:17:40 --> Helper loaded: form_helper
INFO - 2022-03-28 01:17:40 --> Helper loaded: common_helper
INFO - 2022-03-28 01:17:40 --> Database Driver Class Initialized
DEBUG - 2022-03-28 01:17:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 01:17:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 01:17:40 --> Controller Class Initialized
INFO - 2022-03-28 01:17:40 --> Form Validation Class Initialized
DEBUG - 2022-03-28 01:17:40 --> Encrypt Class Initialized
INFO - 2022-03-28 01:17:40 --> Model "Patient_model" initialized
INFO - 2022-03-28 01:17:40 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 01:17:40 --> Model "Prefix_master" initialized
INFO - 2022-03-28 01:17:40 --> Model "Users_model" initialized
INFO - 2022-03-28 01:17:40 --> Model "Hospital_model" initialized
ERROR - 2022-03-28 01:17:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 01:17:41 --> Config Class Initialized
INFO - 2022-03-28 01:17:41 --> Hooks Class Initialized
DEBUG - 2022-03-28 01:17:41 --> UTF-8 Support Enabled
INFO - 2022-03-28 01:17:41 --> Utf8 Class Initialized
INFO - 2022-03-28 01:17:41 --> URI Class Initialized
INFO - 2022-03-28 01:17:41 --> Router Class Initialized
INFO - 2022-03-28 01:17:41 --> Output Class Initialized
INFO - 2022-03-28 01:17:41 --> Security Class Initialized
DEBUG - 2022-03-28 01:17:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 01:17:41 --> Input Class Initialized
INFO - 2022-03-28 01:17:41 --> Language Class Initialized
INFO - 2022-03-28 01:17:41 --> Loader Class Initialized
INFO - 2022-03-28 01:17:41 --> Helper loaded: url_helper
INFO - 2022-03-28 01:17:41 --> Helper loaded: form_helper
INFO - 2022-03-28 01:17:41 --> Helper loaded: common_helper
INFO - 2022-03-28 01:17:41 --> Database Driver Class Initialized
DEBUG - 2022-03-28 01:17:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 01:17:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 01:17:41 --> Controller Class Initialized
INFO - 2022-03-28 01:17:41 --> Form Validation Class Initialized
DEBUG - 2022-03-28 01:17:41 --> Encrypt Class Initialized
INFO - 2022-03-28 01:17:41 --> Model "Patient_model" initialized
INFO - 2022-03-28 01:17:41 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 01:17:41 --> Model "Prefix_master" initialized
INFO - 2022-03-28 01:17:41 --> Model "Users_model" initialized
INFO - 2022-03-28 01:17:41 --> Model "Hospital_model" initialized
INFO - 2022-03-28 01:17:41 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-28 01:17:41 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-28 01:17:41 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-28 01:17:41 --> Final output sent to browser
DEBUG - 2022-03-28 01:17:41 --> Total execution time: 0.0394
ERROR - 2022-03-28 01:26:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 01:26:46 --> Config Class Initialized
INFO - 2022-03-28 01:26:46 --> Hooks Class Initialized
DEBUG - 2022-03-28 01:26:46 --> UTF-8 Support Enabled
INFO - 2022-03-28 01:26:46 --> Utf8 Class Initialized
INFO - 2022-03-28 01:26:46 --> URI Class Initialized
DEBUG - 2022-03-28 01:26:46 --> No URI present. Default controller set.
INFO - 2022-03-28 01:26:46 --> Router Class Initialized
INFO - 2022-03-28 01:26:46 --> Output Class Initialized
INFO - 2022-03-28 01:26:46 --> Security Class Initialized
DEBUG - 2022-03-28 01:26:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 01:26:46 --> Input Class Initialized
INFO - 2022-03-28 01:26:46 --> Language Class Initialized
INFO - 2022-03-28 01:26:46 --> Loader Class Initialized
INFO - 2022-03-28 01:26:46 --> Helper loaded: url_helper
INFO - 2022-03-28 01:26:46 --> Helper loaded: form_helper
INFO - 2022-03-28 01:26:46 --> Helper loaded: common_helper
INFO - 2022-03-28 01:26:46 --> Database Driver Class Initialized
DEBUG - 2022-03-28 01:26:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 01:26:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 01:26:46 --> Controller Class Initialized
INFO - 2022-03-28 01:26:46 --> Form Validation Class Initialized
DEBUG - 2022-03-28 01:26:46 --> Encrypt Class Initialized
DEBUG - 2022-03-28 01:26:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-28 01:26:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-28 01:26:46 --> Email Class Initialized
INFO - 2022-03-28 01:26:46 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-28 01:26:46 --> Calendar Class Initialized
INFO - 2022-03-28 01:26:46 --> Model "Login_model" initialized
ERROR - 2022-03-28 01:26:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 01:26:46 --> Config Class Initialized
INFO - 2022-03-28 01:26:46 --> Hooks Class Initialized
DEBUG - 2022-03-28 01:26:46 --> UTF-8 Support Enabled
INFO - 2022-03-28 01:26:46 --> Utf8 Class Initialized
INFO - 2022-03-28 01:26:46 --> URI Class Initialized
INFO - 2022-03-28 01:26:46 --> Router Class Initialized
INFO - 2022-03-28 01:26:46 --> Output Class Initialized
INFO - 2022-03-28 01:26:46 --> Security Class Initialized
DEBUG - 2022-03-28 01:26:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 01:26:46 --> Input Class Initialized
INFO - 2022-03-28 01:26:46 --> Language Class Initialized
INFO - 2022-03-28 01:26:46 --> Loader Class Initialized
INFO - 2022-03-28 01:26:46 --> Helper loaded: url_helper
INFO - 2022-03-28 01:26:46 --> Helper loaded: form_helper
INFO - 2022-03-28 01:26:46 --> Helper loaded: common_helper
INFO - 2022-03-28 01:26:46 --> Database Driver Class Initialized
DEBUG - 2022-03-28 01:26:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 01:26:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 01:26:46 --> Controller Class Initialized
INFO - 2022-03-28 01:26:46 --> Form Validation Class Initialized
DEBUG - 2022-03-28 01:26:46 --> Encrypt Class Initialized
INFO - 2022-03-28 01:26:46 --> Model "Diseases_model" initialized
INFO - 2022-03-28 01:26:46 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-28 01:26:46 --> File loaded: /home3/karoteam/public_html/application/views/diseases/index.php
INFO - 2022-03-28 01:26:46 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-28 01:26:46 --> Final output sent to browser
DEBUG - 2022-03-28 01:26:46 --> Total execution time: 0.0141
ERROR - 2022-03-28 01:26:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 01:26:48 --> Config Class Initialized
INFO - 2022-03-28 01:26:48 --> Hooks Class Initialized
DEBUG - 2022-03-28 01:26:48 --> UTF-8 Support Enabled
INFO - 2022-03-28 01:26:48 --> Utf8 Class Initialized
INFO - 2022-03-28 01:26:48 --> URI Class Initialized
DEBUG - 2022-03-28 01:26:48 --> No URI present. Default controller set.
INFO - 2022-03-28 01:26:48 --> Router Class Initialized
INFO - 2022-03-28 01:26:48 --> Output Class Initialized
INFO - 2022-03-28 01:26:48 --> Security Class Initialized
DEBUG - 2022-03-28 01:26:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 01:26:48 --> Input Class Initialized
INFO - 2022-03-28 01:26:48 --> Language Class Initialized
INFO - 2022-03-28 01:26:48 --> Loader Class Initialized
INFO - 2022-03-28 01:26:48 --> Helper loaded: url_helper
INFO - 2022-03-28 01:26:48 --> Helper loaded: form_helper
INFO - 2022-03-28 01:26:48 --> Helper loaded: common_helper
INFO - 2022-03-28 01:26:48 --> Database Driver Class Initialized
DEBUG - 2022-03-28 01:26:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 01:26:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 01:26:48 --> Controller Class Initialized
INFO - 2022-03-28 01:26:48 --> Form Validation Class Initialized
DEBUG - 2022-03-28 01:26:48 --> Encrypt Class Initialized
DEBUG - 2022-03-28 01:26:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-28 01:26:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-28 01:26:48 --> Email Class Initialized
INFO - 2022-03-28 01:26:48 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-28 01:26:48 --> Calendar Class Initialized
INFO - 2022-03-28 01:26:48 --> Model "Login_model" initialized
ERROR - 2022-03-28 01:26:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 01:26:48 --> Config Class Initialized
INFO - 2022-03-28 01:26:48 --> Hooks Class Initialized
DEBUG - 2022-03-28 01:26:48 --> UTF-8 Support Enabled
INFO - 2022-03-28 01:26:48 --> Utf8 Class Initialized
INFO - 2022-03-28 01:26:48 --> URI Class Initialized
INFO - 2022-03-28 01:26:48 --> Router Class Initialized
INFO - 2022-03-28 01:26:48 --> Output Class Initialized
INFO - 2022-03-28 01:26:48 --> Security Class Initialized
DEBUG - 2022-03-28 01:26:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 01:26:48 --> Input Class Initialized
INFO - 2022-03-28 01:26:48 --> Language Class Initialized
INFO - 2022-03-28 01:26:48 --> Loader Class Initialized
INFO - 2022-03-28 01:26:48 --> Helper loaded: url_helper
INFO - 2022-03-28 01:26:48 --> Helper loaded: form_helper
INFO - 2022-03-28 01:26:48 --> Helper loaded: common_helper
INFO - 2022-03-28 01:26:48 --> Database Driver Class Initialized
DEBUG - 2022-03-28 01:26:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 01:26:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 01:26:48 --> Controller Class Initialized
INFO - 2022-03-28 01:26:48 --> Form Validation Class Initialized
DEBUG - 2022-03-28 01:26:48 --> Encrypt Class Initialized
INFO - 2022-03-28 01:26:48 --> Model "Diseases_model" initialized
INFO - 2022-03-28 01:26:48 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-28 01:26:48 --> File loaded: /home3/karoteam/public_html/application/views/diseases/index.php
INFO - 2022-03-28 01:26:48 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-28 01:26:48 --> Final output sent to browser
DEBUG - 2022-03-28 01:26:48 --> Total execution time: 0.0083
ERROR - 2022-03-28 01:26:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 01:26:53 --> Config Class Initialized
INFO - 2022-03-28 01:26:53 --> Hooks Class Initialized
DEBUG - 2022-03-28 01:26:53 --> UTF-8 Support Enabled
INFO - 2022-03-28 01:26:53 --> Utf8 Class Initialized
INFO - 2022-03-28 01:26:53 --> URI Class Initialized
INFO - 2022-03-28 01:26:53 --> Router Class Initialized
INFO - 2022-03-28 01:26:53 --> Output Class Initialized
INFO - 2022-03-28 01:26:53 --> Security Class Initialized
DEBUG - 2022-03-28 01:26:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 01:26:53 --> Input Class Initialized
INFO - 2022-03-28 01:26:53 --> Language Class Initialized
INFO - 2022-03-28 01:26:53 --> Loader Class Initialized
INFO - 2022-03-28 01:26:53 --> Helper loaded: url_helper
INFO - 2022-03-28 01:26:53 --> Helper loaded: form_helper
INFO - 2022-03-28 01:26:53 --> Helper loaded: common_helper
INFO - 2022-03-28 01:26:53 --> Database Driver Class Initialized
DEBUG - 2022-03-28 01:26:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 01:26:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 01:26:53 --> Controller Class Initialized
INFO - 2022-03-28 01:26:53 --> Form Validation Class Initialized
DEBUG - 2022-03-28 01:26:53 --> Encrypt Class Initialized
INFO - 2022-03-28 01:26:53 --> Model "Patient_model" initialized
INFO - 2022-03-28 01:26:53 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 01:26:53 --> Model "Referredby_model" initialized
INFO - 2022-03-28 01:26:53 --> Model "Prefix_master" initialized
INFO - 2022-03-28 01:26:53 --> Model "Hospital_model" initialized
INFO - 2022-03-28 01:26:53 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-28 01:26:53 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-28 01:26:53 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-28 01:26:53 --> Final output sent to browser
DEBUG - 2022-03-28 01:26:53 --> Total execution time: 0.0530
ERROR - 2022-03-28 01:27:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 01:27:05 --> Config Class Initialized
INFO - 2022-03-28 01:27:05 --> Hooks Class Initialized
DEBUG - 2022-03-28 01:27:05 --> UTF-8 Support Enabled
INFO - 2022-03-28 01:27:05 --> Utf8 Class Initialized
INFO - 2022-03-28 01:27:05 --> URI Class Initialized
INFO - 2022-03-28 01:27:05 --> Router Class Initialized
INFO - 2022-03-28 01:27:05 --> Output Class Initialized
INFO - 2022-03-28 01:27:05 --> Security Class Initialized
DEBUG - 2022-03-28 01:27:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 01:27:05 --> Input Class Initialized
INFO - 2022-03-28 01:27:05 --> Language Class Initialized
INFO - 2022-03-28 01:27:05 --> Loader Class Initialized
INFO - 2022-03-28 01:27:05 --> Helper loaded: url_helper
INFO - 2022-03-28 01:27:05 --> Helper loaded: form_helper
INFO - 2022-03-28 01:27:05 --> Helper loaded: common_helper
INFO - 2022-03-28 01:27:05 --> Database Driver Class Initialized
DEBUG - 2022-03-28 01:27:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 01:27:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 01:27:05 --> Controller Class Initialized
INFO - 2022-03-28 01:27:05 --> Form Validation Class Initialized
DEBUG - 2022-03-28 01:27:05 --> Encrypt Class Initialized
INFO - 2022-03-28 01:27:05 --> Model "Patient_model" initialized
INFO - 2022-03-28 01:27:05 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 01:27:05 --> Model "Prefix_master" initialized
INFO - 2022-03-28 01:27:05 --> Model "Users_model" initialized
INFO - 2022-03-28 01:27:05 --> Model "Hospital_model" initialized
INFO - 2022-03-28 01:27:05 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-28 01:27:05 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-28 01:27:05 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-28 01:27:05 --> Final output sent to browser
DEBUG - 2022-03-28 01:27:05 --> Total execution time: 0.0535
ERROR - 2022-03-28 01:27:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 01:27:12 --> Config Class Initialized
INFO - 2022-03-28 01:27:12 --> Hooks Class Initialized
DEBUG - 2022-03-28 01:27:12 --> UTF-8 Support Enabled
INFO - 2022-03-28 01:27:12 --> Utf8 Class Initialized
INFO - 2022-03-28 01:27:12 --> URI Class Initialized
INFO - 2022-03-28 01:27:12 --> Router Class Initialized
INFO - 2022-03-28 01:27:12 --> Output Class Initialized
INFO - 2022-03-28 01:27:12 --> Security Class Initialized
DEBUG - 2022-03-28 01:27:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 01:27:12 --> Input Class Initialized
INFO - 2022-03-28 01:27:12 --> Language Class Initialized
INFO - 2022-03-28 01:27:12 --> Loader Class Initialized
INFO - 2022-03-28 01:27:12 --> Helper loaded: url_helper
INFO - 2022-03-28 01:27:12 --> Helper loaded: form_helper
INFO - 2022-03-28 01:27:12 --> Helper loaded: common_helper
INFO - 2022-03-28 01:27:12 --> Database Driver Class Initialized
DEBUG - 2022-03-28 01:27:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 01:27:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 01:27:12 --> Controller Class Initialized
INFO - 2022-03-28 01:27:12 --> Form Validation Class Initialized
DEBUG - 2022-03-28 01:27:12 --> Encrypt Class Initialized
INFO - 2022-03-28 01:27:12 --> Model "Patient_model" initialized
INFO - 2022-03-28 01:27:12 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 01:27:12 --> Model "Referredby_model" initialized
INFO - 2022-03-28 01:27:12 --> Model "Prefix_master" initialized
INFO - 2022-03-28 01:27:12 --> Model "Hospital_model" initialized
INFO - 2022-03-28 01:27:12 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-28 01:27:12 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-28 01:27:12 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-28 01:27:12 --> Final output sent to browser
DEBUG - 2022-03-28 01:27:12 --> Total execution time: 0.0257
ERROR - 2022-03-28 01:27:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 01:27:24 --> Config Class Initialized
INFO - 2022-03-28 01:27:24 --> Hooks Class Initialized
DEBUG - 2022-03-28 01:27:24 --> UTF-8 Support Enabled
INFO - 2022-03-28 01:27:24 --> Utf8 Class Initialized
INFO - 2022-03-28 01:27:24 --> URI Class Initialized
INFO - 2022-03-28 01:27:24 --> Router Class Initialized
INFO - 2022-03-28 01:27:24 --> Output Class Initialized
INFO - 2022-03-28 01:27:24 --> Security Class Initialized
DEBUG - 2022-03-28 01:27:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 01:27:24 --> Input Class Initialized
INFO - 2022-03-28 01:27:24 --> Language Class Initialized
INFO - 2022-03-28 01:27:24 --> Loader Class Initialized
INFO - 2022-03-28 01:27:24 --> Helper loaded: url_helper
INFO - 2022-03-28 01:27:24 --> Helper loaded: form_helper
INFO - 2022-03-28 01:27:24 --> Helper loaded: common_helper
INFO - 2022-03-28 01:27:24 --> Database Driver Class Initialized
DEBUG - 2022-03-28 01:27:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 01:27:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 01:27:24 --> Controller Class Initialized
INFO - 2022-03-28 01:27:24 --> Form Validation Class Initialized
DEBUG - 2022-03-28 01:27:24 --> Encrypt Class Initialized
INFO - 2022-03-28 01:27:24 --> Model "Patient_model" initialized
INFO - 2022-03-28 01:27:24 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 01:27:24 --> Model "Referredby_model" initialized
INFO - 2022-03-28 01:27:24 --> Model "Prefix_master" initialized
INFO - 2022-03-28 01:27:24 --> Model "Hospital_model" initialized
INFO - 2022-03-28 01:27:24 --> Upload Class Initialized
INFO - 2022-03-28 01:27:24 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2022-03-28 01:27:24 --> The filetype you are attempting to upload is not allowed.
INFO - 2022-03-28 01:27:24 --> Final output sent to browser
DEBUG - 2022-03-28 01:27:24 --> Total execution time: 0.0104
ERROR - 2022-03-28 01:28:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 01:28:03 --> Config Class Initialized
INFO - 2022-03-28 01:28:03 --> Hooks Class Initialized
DEBUG - 2022-03-28 01:28:03 --> UTF-8 Support Enabled
INFO - 2022-03-28 01:28:03 --> Utf8 Class Initialized
INFO - 2022-03-28 01:28:03 --> URI Class Initialized
INFO - 2022-03-28 01:28:03 --> Router Class Initialized
INFO - 2022-03-28 01:28:03 --> Output Class Initialized
INFO - 2022-03-28 01:28:03 --> Security Class Initialized
DEBUG - 2022-03-28 01:28:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 01:28:03 --> Input Class Initialized
INFO - 2022-03-28 01:28:03 --> Language Class Initialized
INFO - 2022-03-28 01:28:03 --> Loader Class Initialized
INFO - 2022-03-28 01:28:03 --> Helper loaded: url_helper
INFO - 2022-03-28 01:28:03 --> Helper loaded: form_helper
INFO - 2022-03-28 01:28:03 --> Helper loaded: common_helper
INFO - 2022-03-28 01:28:03 --> Database Driver Class Initialized
DEBUG - 2022-03-28 01:28:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 01:28:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 01:28:03 --> Controller Class Initialized
INFO - 2022-03-28 01:28:03 --> Form Validation Class Initialized
DEBUG - 2022-03-28 01:28:03 --> Encrypt Class Initialized
INFO - 2022-03-28 01:28:03 --> Model "Patient_model" initialized
INFO - 2022-03-28 01:28:03 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 01:28:03 --> Model "Referredby_model" initialized
INFO - 2022-03-28 01:28:03 --> Model "Prefix_master" initialized
INFO - 2022-03-28 01:28:03 --> Model "Hospital_model" initialized
INFO - 2022-03-28 01:28:03 --> Upload Class Initialized
INFO - 2022-03-28 01:28:03 --> Final output sent to browser
DEBUG - 2022-03-28 01:28:03 --> Total execution time: 0.0086
ERROR - 2022-03-28 01:28:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 01:28:13 --> Config Class Initialized
INFO - 2022-03-28 01:28:13 --> Hooks Class Initialized
DEBUG - 2022-03-28 01:28:13 --> UTF-8 Support Enabled
INFO - 2022-03-28 01:28:13 --> Utf8 Class Initialized
INFO - 2022-03-28 01:28:13 --> URI Class Initialized
INFO - 2022-03-28 01:28:13 --> Router Class Initialized
INFO - 2022-03-28 01:28:13 --> Output Class Initialized
INFO - 2022-03-28 01:28:13 --> Security Class Initialized
DEBUG - 2022-03-28 01:28:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 01:28:13 --> Input Class Initialized
INFO - 2022-03-28 01:28:13 --> Language Class Initialized
INFO - 2022-03-28 01:28:13 --> Loader Class Initialized
INFO - 2022-03-28 01:28:13 --> Helper loaded: url_helper
INFO - 2022-03-28 01:28:13 --> Helper loaded: form_helper
INFO - 2022-03-28 01:28:13 --> Helper loaded: common_helper
INFO - 2022-03-28 01:28:13 --> Database Driver Class Initialized
DEBUG - 2022-03-28 01:28:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 01:28:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 01:28:13 --> Controller Class Initialized
INFO - 2022-03-28 01:28:13 --> Form Validation Class Initialized
DEBUG - 2022-03-28 01:28:13 --> Encrypt Class Initialized
INFO - 2022-03-28 01:28:13 --> Model "Patient_model" initialized
INFO - 2022-03-28 01:28:13 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 01:28:13 --> Model "Referredby_model" initialized
INFO - 2022-03-28 01:28:13 --> Model "Prefix_master" initialized
INFO - 2022-03-28 01:28:13 --> Model "Hospital_model" initialized
ERROR - 2022-03-28 01:28:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 01:28:13 --> Config Class Initialized
INFO - 2022-03-28 01:28:13 --> Hooks Class Initialized
DEBUG - 2022-03-28 01:28:13 --> UTF-8 Support Enabled
INFO - 2022-03-28 01:28:13 --> Utf8 Class Initialized
INFO - 2022-03-28 01:28:13 --> URI Class Initialized
INFO - 2022-03-28 01:28:13 --> Router Class Initialized
INFO - 2022-03-28 01:28:13 --> Output Class Initialized
INFO - 2022-03-28 01:28:13 --> Security Class Initialized
DEBUG - 2022-03-28 01:28:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 01:28:13 --> Input Class Initialized
INFO - 2022-03-28 01:28:13 --> Language Class Initialized
INFO - 2022-03-28 01:28:13 --> Loader Class Initialized
INFO - 2022-03-28 01:28:13 --> Helper loaded: url_helper
INFO - 2022-03-28 01:28:13 --> Helper loaded: form_helper
INFO - 2022-03-28 01:28:13 --> Helper loaded: common_helper
INFO - 2022-03-28 01:28:13 --> Database Driver Class Initialized
DEBUG - 2022-03-28 01:28:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 01:28:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 01:28:13 --> Controller Class Initialized
INFO - 2022-03-28 01:28:13 --> Form Validation Class Initialized
DEBUG - 2022-03-28 01:28:13 --> Encrypt Class Initialized
INFO - 2022-03-28 01:28:13 --> Model "Patient_model" initialized
INFO - 2022-03-28 01:28:13 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 01:28:13 --> Model "Referredby_model" initialized
INFO - 2022-03-28 01:28:13 --> Model "Prefix_master" initialized
INFO - 2022-03-28 01:28:13 --> Model "Hospital_model" initialized
INFO - 2022-03-28 01:28:13 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-28 01:28:13 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-28 01:28:13 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-28 01:28:13 --> Final output sent to browser
DEBUG - 2022-03-28 01:28:13 --> Total execution time: 0.0370
ERROR - 2022-03-28 01:28:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 01:28:14 --> Config Class Initialized
INFO - 2022-03-28 01:28:14 --> Hooks Class Initialized
DEBUG - 2022-03-28 01:28:14 --> UTF-8 Support Enabled
INFO - 2022-03-28 01:28:14 --> Utf8 Class Initialized
INFO - 2022-03-28 01:28:14 --> URI Class Initialized
INFO - 2022-03-28 01:28:14 --> Router Class Initialized
INFO - 2022-03-28 01:28:14 --> Output Class Initialized
INFO - 2022-03-28 01:28:14 --> Security Class Initialized
DEBUG - 2022-03-28 01:28:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 01:28:14 --> Input Class Initialized
INFO - 2022-03-28 01:28:14 --> Language Class Initialized
INFO - 2022-03-28 01:28:14 --> Loader Class Initialized
INFO - 2022-03-28 01:28:14 --> Helper loaded: url_helper
INFO - 2022-03-28 01:28:14 --> Helper loaded: form_helper
INFO - 2022-03-28 01:28:14 --> Helper loaded: common_helper
INFO - 2022-03-28 01:28:14 --> Database Driver Class Initialized
DEBUG - 2022-03-28 01:28:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 01:28:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 01:28:14 --> Controller Class Initialized
INFO - 2022-03-28 01:28:14 --> Form Validation Class Initialized
DEBUG - 2022-03-28 01:28:14 --> Encrypt Class Initialized
INFO - 2022-03-28 01:28:14 --> Model "Patient_model" initialized
INFO - 2022-03-28 01:28:14 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 01:28:14 --> Model "Prefix_master" initialized
INFO - 2022-03-28 01:28:14 --> Model "Users_model" initialized
INFO - 2022-03-28 01:28:14 --> Model "Hospital_model" initialized
INFO - 2022-03-28 01:28:14 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-28 01:28:14 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-28 01:28:14 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-28 01:28:14 --> Final output sent to browser
DEBUG - 2022-03-28 01:28:14 --> Total execution time: 0.0374
ERROR - 2022-03-28 01:28:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 01:28:17 --> Config Class Initialized
INFO - 2022-03-28 01:28:17 --> Hooks Class Initialized
DEBUG - 2022-03-28 01:28:17 --> UTF-8 Support Enabled
INFO - 2022-03-28 01:28:17 --> Utf8 Class Initialized
INFO - 2022-03-28 01:28:17 --> URI Class Initialized
INFO - 2022-03-28 01:28:17 --> Router Class Initialized
INFO - 2022-03-28 01:28:17 --> Output Class Initialized
INFO - 2022-03-28 01:28:17 --> Security Class Initialized
DEBUG - 2022-03-28 01:28:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 01:28:17 --> Input Class Initialized
INFO - 2022-03-28 01:28:17 --> Language Class Initialized
INFO - 2022-03-28 01:28:17 --> Loader Class Initialized
INFO - 2022-03-28 01:28:17 --> Helper loaded: url_helper
INFO - 2022-03-28 01:28:17 --> Helper loaded: form_helper
INFO - 2022-03-28 01:28:17 --> Helper loaded: common_helper
INFO - 2022-03-28 01:28:17 --> Database Driver Class Initialized
DEBUG - 2022-03-28 01:28:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 01:28:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 01:28:17 --> Controller Class Initialized
INFO - 2022-03-28 01:28:17 --> Form Validation Class Initialized
DEBUG - 2022-03-28 01:28:17 --> Encrypt Class Initialized
INFO - 2022-03-28 01:28:17 --> Model "Patient_model" initialized
INFO - 2022-03-28 01:28:17 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 01:28:17 --> Model "Referredby_model" initialized
INFO - 2022-03-28 01:28:17 --> Model "Prefix_master" initialized
INFO - 2022-03-28 01:28:17 --> Model "Hospital_model" initialized
INFO - 2022-03-28 01:28:17 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-28 01:28:17 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-28 01:28:17 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-28 01:28:17 --> Final output sent to browser
DEBUG - 2022-03-28 01:28:17 --> Total execution time: 0.0427
ERROR - 2022-03-28 01:28:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 01:28:28 --> Config Class Initialized
INFO - 2022-03-28 01:28:28 --> Hooks Class Initialized
DEBUG - 2022-03-28 01:28:28 --> UTF-8 Support Enabled
INFO - 2022-03-28 01:28:28 --> Utf8 Class Initialized
INFO - 2022-03-28 01:28:28 --> URI Class Initialized
INFO - 2022-03-28 01:28:28 --> Router Class Initialized
INFO - 2022-03-28 01:28:28 --> Output Class Initialized
INFO - 2022-03-28 01:28:28 --> Security Class Initialized
DEBUG - 2022-03-28 01:28:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 01:28:28 --> Input Class Initialized
INFO - 2022-03-28 01:28:28 --> Language Class Initialized
INFO - 2022-03-28 01:28:28 --> Loader Class Initialized
INFO - 2022-03-28 01:28:28 --> Helper loaded: url_helper
INFO - 2022-03-28 01:28:28 --> Helper loaded: form_helper
INFO - 2022-03-28 01:28:28 --> Helper loaded: common_helper
INFO - 2022-03-28 01:28:28 --> Database Driver Class Initialized
DEBUG - 2022-03-28 01:28:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 01:28:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 01:28:28 --> Controller Class Initialized
INFO - 2022-03-28 01:28:28 --> Form Validation Class Initialized
DEBUG - 2022-03-28 01:28:28 --> Encrypt Class Initialized
INFO - 2022-03-28 01:28:28 --> Model "Patient_model" initialized
INFO - 2022-03-28 01:28:28 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 01:28:28 --> Model "Prefix_master" initialized
INFO - 2022-03-28 01:28:28 --> Model "Users_model" initialized
INFO - 2022-03-28 01:28:28 --> Model "Hospital_model" initialized
INFO - 2022-03-28 01:28:28 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-28 01:28:29 --> Final output sent to browser
DEBUG - 2022-03-28 01:28:29 --> Total execution time: 0.9255
ERROR - 2022-03-28 01:29:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 01:29:51 --> Config Class Initialized
INFO - 2022-03-28 01:29:51 --> Hooks Class Initialized
DEBUG - 2022-03-28 01:29:51 --> UTF-8 Support Enabled
INFO - 2022-03-28 01:29:51 --> Utf8 Class Initialized
INFO - 2022-03-28 01:29:51 --> URI Class Initialized
INFO - 2022-03-28 01:29:51 --> Router Class Initialized
INFO - 2022-03-28 01:29:51 --> Output Class Initialized
INFO - 2022-03-28 01:29:51 --> Security Class Initialized
DEBUG - 2022-03-28 01:29:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 01:29:51 --> Input Class Initialized
INFO - 2022-03-28 01:29:51 --> Language Class Initialized
INFO - 2022-03-28 01:29:51 --> Loader Class Initialized
INFO - 2022-03-28 01:29:51 --> Helper loaded: url_helper
INFO - 2022-03-28 01:29:51 --> Helper loaded: form_helper
INFO - 2022-03-28 01:29:51 --> Helper loaded: common_helper
INFO - 2022-03-28 01:29:51 --> Database Driver Class Initialized
DEBUG - 2022-03-28 01:29:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 01:29:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 01:29:51 --> Controller Class Initialized
INFO - 2022-03-28 01:29:51 --> Form Validation Class Initialized
DEBUG - 2022-03-28 01:29:51 --> Encrypt Class Initialized
INFO - 2022-03-28 01:29:51 --> Model "Patient_model" initialized
INFO - 2022-03-28 01:29:51 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 01:29:51 --> Model "Referredby_model" initialized
INFO - 2022-03-28 01:29:51 --> Model "Prefix_master" initialized
INFO - 2022-03-28 01:29:51 --> Model "Hospital_model" initialized
INFO - 2022-03-28 01:29:51 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-28 01:29:51 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-28 01:29:51 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-28 01:29:51 --> Final output sent to browser
DEBUG - 2022-03-28 01:29:51 --> Total execution time: 0.0312
ERROR - 2022-03-28 01:30:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 01:30:09 --> Config Class Initialized
INFO - 2022-03-28 01:30:09 --> Hooks Class Initialized
DEBUG - 2022-03-28 01:30:09 --> UTF-8 Support Enabled
INFO - 2022-03-28 01:30:09 --> Utf8 Class Initialized
INFO - 2022-03-28 01:30:09 --> URI Class Initialized
INFO - 2022-03-28 01:30:09 --> Router Class Initialized
INFO - 2022-03-28 01:30:09 --> Output Class Initialized
INFO - 2022-03-28 01:30:09 --> Security Class Initialized
DEBUG - 2022-03-28 01:30:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 01:30:09 --> Input Class Initialized
INFO - 2022-03-28 01:30:09 --> Language Class Initialized
INFO - 2022-03-28 01:30:09 --> Loader Class Initialized
INFO - 2022-03-28 01:30:09 --> Helper loaded: url_helper
INFO - 2022-03-28 01:30:09 --> Helper loaded: form_helper
INFO - 2022-03-28 01:30:09 --> Helper loaded: common_helper
INFO - 2022-03-28 01:30:09 --> Database Driver Class Initialized
DEBUG - 2022-03-28 01:30:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 01:30:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 01:30:09 --> Controller Class Initialized
INFO - 2022-03-28 01:30:09 --> Form Validation Class Initialized
DEBUG - 2022-03-28 01:30:09 --> Encrypt Class Initialized
INFO - 2022-03-28 01:30:09 --> Model "Patient_model" initialized
INFO - 2022-03-28 01:30:09 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 01:30:09 --> Model "Referredby_model" initialized
INFO - 2022-03-28 01:30:09 --> Model "Prefix_master" initialized
INFO - 2022-03-28 01:30:09 --> Model "Hospital_model" initialized
INFO - 2022-03-28 01:30:09 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-28 01:30:09 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-28 01:30:09 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-28 01:30:09 --> Final output sent to browser
DEBUG - 2022-03-28 01:30:09 --> Total execution time: 0.0684
ERROR - 2022-03-28 01:30:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 01:30:19 --> Config Class Initialized
INFO - 2022-03-28 01:30:19 --> Hooks Class Initialized
DEBUG - 2022-03-28 01:30:19 --> UTF-8 Support Enabled
INFO - 2022-03-28 01:30:19 --> Utf8 Class Initialized
INFO - 2022-03-28 01:30:19 --> URI Class Initialized
INFO - 2022-03-28 01:30:19 --> Router Class Initialized
INFO - 2022-03-28 01:30:19 --> Output Class Initialized
INFO - 2022-03-28 01:30:19 --> Security Class Initialized
DEBUG - 2022-03-28 01:30:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 01:30:19 --> Input Class Initialized
INFO - 2022-03-28 01:30:19 --> Language Class Initialized
INFO - 2022-03-28 01:30:19 --> Loader Class Initialized
INFO - 2022-03-28 01:30:19 --> Helper loaded: url_helper
INFO - 2022-03-28 01:30:19 --> Helper loaded: form_helper
INFO - 2022-03-28 01:30:19 --> Helper loaded: common_helper
INFO - 2022-03-28 01:30:19 --> Database Driver Class Initialized
DEBUG - 2022-03-28 01:30:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 01:30:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 01:30:19 --> Controller Class Initialized
INFO - 2022-03-28 01:30:19 --> Form Validation Class Initialized
DEBUG - 2022-03-28 01:30:19 --> Encrypt Class Initialized
INFO - 2022-03-28 01:30:19 --> Model "Patient_model" initialized
INFO - 2022-03-28 01:30:19 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 01:30:19 --> Model "Prefix_master" initialized
INFO - 2022-03-28 01:30:19 --> Model "Users_model" initialized
INFO - 2022-03-28 01:30:19 --> Model "Hospital_model" initialized
INFO - 2022-03-28 01:30:20 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-28 01:30:20 --> Final output sent to browser
DEBUG - 2022-03-28 01:30:20 --> Total execution time: 0.6126
ERROR - 2022-03-28 01:31:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 01:31:07 --> Config Class Initialized
INFO - 2022-03-28 01:31:07 --> Hooks Class Initialized
DEBUG - 2022-03-28 01:31:07 --> UTF-8 Support Enabled
INFO - 2022-03-28 01:31:07 --> Utf8 Class Initialized
INFO - 2022-03-28 01:31:07 --> URI Class Initialized
INFO - 2022-03-28 01:31:07 --> Router Class Initialized
INFO - 2022-03-28 01:31:07 --> Output Class Initialized
INFO - 2022-03-28 01:31:07 --> Security Class Initialized
DEBUG - 2022-03-28 01:31:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 01:31:07 --> Input Class Initialized
INFO - 2022-03-28 01:31:07 --> Language Class Initialized
INFO - 2022-03-28 01:31:07 --> Loader Class Initialized
INFO - 2022-03-28 01:31:07 --> Helper loaded: url_helper
INFO - 2022-03-28 01:31:07 --> Helper loaded: form_helper
INFO - 2022-03-28 01:31:07 --> Helper loaded: common_helper
INFO - 2022-03-28 01:31:07 --> Database Driver Class Initialized
DEBUG - 2022-03-28 01:31:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 01:31:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 01:31:07 --> Controller Class Initialized
INFO - 2022-03-28 01:31:07 --> Form Validation Class Initialized
DEBUG - 2022-03-28 01:31:07 --> Encrypt Class Initialized
INFO - 2022-03-28 01:31:07 --> Model "Patient_model" initialized
INFO - 2022-03-28 01:31:07 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 01:31:07 --> Model "Referredby_model" initialized
INFO - 2022-03-28 01:31:07 --> Model "Prefix_master" initialized
INFO - 2022-03-28 01:31:07 --> Model "Hospital_model" initialized
INFO - 2022-03-28 01:31:08 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-28 01:31:08 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-28 01:31:08 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-28 01:31:08 --> Final output sent to browser
DEBUG - 2022-03-28 01:31:08 --> Total execution time: 0.0376
ERROR - 2022-03-28 01:31:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 01:31:29 --> Config Class Initialized
INFO - 2022-03-28 01:31:29 --> Hooks Class Initialized
DEBUG - 2022-03-28 01:31:29 --> UTF-8 Support Enabled
INFO - 2022-03-28 01:31:29 --> Utf8 Class Initialized
INFO - 2022-03-28 01:31:29 --> URI Class Initialized
INFO - 2022-03-28 01:31:29 --> Router Class Initialized
INFO - 2022-03-28 01:31:29 --> Output Class Initialized
INFO - 2022-03-28 01:31:29 --> Security Class Initialized
DEBUG - 2022-03-28 01:31:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 01:31:29 --> Input Class Initialized
INFO - 2022-03-28 01:31:29 --> Language Class Initialized
INFO - 2022-03-28 01:31:29 --> Loader Class Initialized
INFO - 2022-03-28 01:31:29 --> Helper loaded: url_helper
INFO - 2022-03-28 01:31:29 --> Helper loaded: form_helper
INFO - 2022-03-28 01:31:29 --> Helper loaded: common_helper
INFO - 2022-03-28 01:31:29 --> Database Driver Class Initialized
DEBUG - 2022-03-28 01:31:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 01:31:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 01:31:29 --> Controller Class Initialized
INFO - 2022-03-28 01:31:29 --> Form Validation Class Initialized
DEBUG - 2022-03-28 01:31:29 --> Encrypt Class Initialized
INFO - 2022-03-28 01:31:29 --> Model "Patient_model" initialized
INFO - 2022-03-28 01:31:29 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 01:31:29 --> Model "Referredby_model" initialized
INFO - 2022-03-28 01:31:29 --> Model "Prefix_master" initialized
INFO - 2022-03-28 01:31:29 --> Model "Hospital_model" initialized
INFO - 2022-03-28 01:31:29 --> Upload Class Initialized
INFO - 2022-03-28 01:31:29 --> Final output sent to browser
DEBUG - 2022-03-28 01:31:29 --> Total execution time: 0.0080
ERROR - 2022-03-28 01:31:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 01:31:40 --> Config Class Initialized
INFO - 2022-03-28 01:31:40 --> Hooks Class Initialized
DEBUG - 2022-03-28 01:31:40 --> UTF-8 Support Enabled
INFO - 2022-03-28 01:31:40 --> Utf8 Class Initialized
INFO - 2022-03-28 01:31:40 --> URI Class Initialized
INFO - 2022-03-28 01:31:40 --> Router Class Initialized
INFO - 2022-03-28 01:31:40 --> Output Class Initialized
INFO - 2022-03-28 01:31:40 --> Security Class Initialized
DEBUG - 2022-03-28 01:31:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 01:31:40 --> Input Class Initialized
INFO - 2022-03-28 01:31:40 --> Language Class Initialized
INFO - 2022-03-28 01:31:40 --> Loader Class Initialized
INFO - 2022-03-28 01:31:40 --> Helper loaded: url_helper
INFO - 2022-03-28 01:31:40 --> Helper loaded: form_helper
INFO - 2022-03-28 01:31:40 --> Helper loaded: common_helper
INFO - 2022-03-28 01:31:40 --> Database Driver Class Initialized
DEBUG - 2022-03-28 01:31:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 01:31:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 01:31:40 --> Controller Class Initialized
INFO - 2022-03-28 01:31:40 --> Form Validation Class Initialized
DEBUG - 2022-03-28 01:31:40 --> Encrypt Class Initialized
INFO - 2022-03-28 01:31:40 --> Model "Patient_model" initialized
INFO - 2022-03-28 01:31:40 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 01:31:40 --> Model "Referredby_model" initialized
INFO - 2022-03-28 01:31:40 --> Model "Prefix_master" initialized
INFO - 2022-03-28 01:31:40 --> Model "Hospital_model" initialized
ERROR - 2022-03-28 01:31:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 01:31:41 --> Config Class Initialized
INFO - 2022-03-28 01:31:41 --> Hooks Class Initialized
DEBUG - 2022-03-28 01:31:41 --> UTF-8 Support Enabled
INFO - 2022-03-28 01:31:41 --> Utf8 Class Initialized
INFO - 2022-03-28 01:31:41 --> URI Class Initialized
INFO - 2022-03-28 01:31:41 --> Router Class Initialized
INFO - 2022-03-28 01:31:41 --> Output Class Initialized
INFO - 2022-03-28 01:31:41 --> Security Class Initialized
DEBUG - 2022-03-28 01:31:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 01:31:41 --> Input Class Initialized
INFO - 2022-03-28 01:31:41 --> Language Class Initialized
INFO - 2022-03-28 01:31:41 --> Loader Class Initialized
INFO - 2022-03-28 01:31:41 --> Helper loaded: url_helper
INFO - 2022-03-28 01:31:41 --> Helper loaded: form_helper
INFO - 2022-03-28 01:31:41 --> Helper loaded: common_helper
INFO - 2022-03-28 01:31:41 --> Database Driver Class Initialized
DEBUG - 2022-03-28 01:31:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 01:31:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 01:31:41 --> Controller Class Initialized
INFO - 2022-03-28 01:31:41 --> Form Validation Class Initialized
DEBUG - 2022-03-28 01:31:41 --> Encrypt Class Initialized
INFO - 2022-03-28 01:31:41 --> Model "Patient_model" initialized
INFO - 2022-03-28 01:31:41 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 01:31:41 --> Model "Referredby_model" initialized
INFO - 2022-03-28 01:31:41 --> Model "Prefix_master" initialized
INFO - 2022-03-28 01:31:41 --> Model "Hospital_model" initialized
INFO - 2022-03-28 01:31:41 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-28 01:31:41 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-28 01:31:41 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-28 01:31:41 --> Final output sent to browser
DEBUG - 2022-03-28 01:31:41 --> Total execution time: 0.0256
ERROR - 2022-03-28 01:31:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 01:31:41 --> Config Class Initialized
INFO - 2022-03-28 01:31:41 --> Hooks Class Initialized
DEBUG - 2022-03-28 01:31:41 --> UTF-8 Support Enabled
INFO - 2022-03-28 01:31:41 --> Utf8 Class Initialized
INFO - 2022-03-28 01:31:41 --> URI Class Initialized
INFO - 2022-03-28 01:31:41 --> Router Class Initialized
INFO - 2022-03-28 01:31:41 --> Output Class Initialized
INFO - 2022-03-28 01:31:41 --> Security Class Initialized
DEBUG - 2022-03-28 01:31:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 01:31:41 --> Input Class Initialized
INFO - 2022-03-28 01:31:41 --> Language Class Initialized
INFO - 2022-03-28 01:31:41 --> Loader Class Initialized
INFO - 2022-03-28 01:31:41 --> Helper loaded: url_helper
INFO - 2022-03-28 01:31:41 --> Helper loaded: form_helper
INFO - 2022-03-28 01:31:41 --> Helper loaded: common_helper
INFO - 2022-03-28 01:31:41 --> Database Driver Class Initialized
DEBUG - 2022-03-28 01:31:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 01:31:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 01:31:41 --> Controller Class Initialized
INFO - 2022-03-28 01:31:41 --> Form Validation Class Initialized
DEBUG - 2022-03-28 01:31:41 --> Encrypt Class Initialized
INFO - 2022-03-28 01:31:41 --> Model "Patient_model" initialized
INFO - 2022-03-28 01:31:41 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 01:31:41 --> Model "Prefix_master" initialized
INFO - 2022-03-28 01:31:41 --> Model "Users_model" initialized
INFO - 2022-03-28 01:31:41 --> Model "Hospital_model" initialized
INFO - 2022-03-28 01:31:41 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-28 01:31:41 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-28 01:31:41 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-28 01:31:41 --> Final output sent to browser
DEBUG - 2022-03-28 01:31:41 --> Total execution time: 0.0780
ERROR - 2022-03-28 01:31:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 01:31:45 --> Config Class Initialized
INFO - 2022-03-28 01:31:45 --> Hooks Class Initialized
DEBUG - 2022-03-28 01:31:45 --> UTF-8 Support Enabled
INFO - 2022-03-28 01:31:45 --> Utf8 Class Initialized
INFO - 2022-03-28 01:31:45 --> URI Class Initialized
INFO - 2022-03-28 01:31:45 --> Router Class Initialized
INFO - 2022-03-28 01:31:45 --> Output Class Initialized
INFO - 2022-03-28 01:31:45 --> Security Class Initialized
DEBUG - 2022-03-28 01:31:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 01:31:45 --> Input Class Initialized
INFO - 2022-03-28 01:31:45 --> Language Class Initialized
INFO - 2022-03-28 01:31:45 --> Loader Class Initialized
INFO - 2022-03-28 01:31:45 --> Helper loaded: url_helper
INFO - 2022-03-28 01:31:45 --> Helper loaded: form_helper
INFO - 2022-03-28 01:31:45 --> Helper loaded: common_helper
INFO - 2022-03-28 01:31:45 --> Database Driver Class Initialized
DEBUG - 2022-03-28 01:31:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 01:31:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 01:31:45 --> Controller Class Initialized
INFO - 2022-03-28 01:31:45 --> Form Validation Class Initialized
DEBUG - 2022-03-28 01:31:45 --> Encrypt Class Initialized
INFO - 2022-03-28 01:31:45 --> Model "Patient_model" initialized
INFO - 2022-03-28 01:31:45 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 01:31:45 --> Model "Referredby_model" initialized
INFO - 2022-03-28 01:31:45 --> Model "Prefix_master" initialized
INFO - 2022-03-28 01:31:45 --> Model "Hospital_model" initialized
INFO - 2022-03-28 01:31:45 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-28 01:31:45 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-28 01:31:45 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-28 01:31:45 --> Final output sent to browser
DEBUG - 2022-03-28 01:31:45 --> Total execution time: 0.0490
ERROR - 2022-03-28 01:31:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 01:31:56 --> Config Class Initialized
INFO - 2022-03-28 01:31:56 --> Hooks Class Initialized
DEBUG - 2022-03-28 01:31:56 --> UTF-8 Support Enabled
INFO - 2022-03-28 01:31:56 --> Utf8 Class Initialized
INFO - 2022-03-28 01:31:56 --> URI Class Initialized
INFO - 2022-03-28 01:31:56 --> Router Class Initialized
INFO - 2022-03-28 01:31:56 --> Output Class Initialized
INFO - 2022-03-28 01:31:56 --> Security Class Initialized
DEBUG - 2022-03-28 01:31:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 01:31:56 --> Input Class Initialized
INFO - 2022-03-28 01:31:56 --> Language Class Initialized
INFO - 2022-03-28 01:31:56 --> Loader Class Initialized
INFO - 2022-03-28 01:31:56 --> Helper loaded: url_helper
INFO - 2022-03-28 01:31:56 --> Helper loaded: form_helper
INFO - 2022-03-28 01:31:56 --> Helper loaded: common_helper
INFO - 2022-03-28 01:31:56 --> Database Driver Class Initialized
DEBUG - 2022-03-28 01:31:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 01:31:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 01:31:56 --> Controller Class Initialized
INFO - 2022-03-28 01:31:56 --> Form Validation Class Initialized
DEBUG - 2022-03-28 01:31:56 --> Encrypt Class Initialized
INFO - 2022-03-28 01:31:56 --> Model "Patient_model" initialized
INFO - 2022-03-28 01:31:56 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 01:31:56 --> Model "Prefix_master" initialized
INFO - 2022-03-28 01:31:56 --> Model "Users_model" initialized
INFO - 2022-03-28 01:31:56 --> Model "Hospital_model" initialized
INFO - 2022-03-28 01:31:56 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-28 01:31:57 --> Final output sent to browser
DEBUG - 2022-03-28 01:31:57 --> Total execution time: 0.7413
ERROR - 2022-03-28 01:39:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 01:39:20 --> Config Class Initialized
INFO - 2022-03-28 01:39:20 --> Hooks Class Initialized
DEBUG - 2022-03-28 01:39:20 --> UTF-8 Support Enabled
INFO - 2022-03-28 01:39:20 --> Utf8 Class Initialized
INFO - 2022-03-28 01:39:20 --> URI Class Initialized
INFO - 2022-03-28 01:39:20 --> Router Class Initialized
INFO - 2022-03-28 01:39:20 --> Output Class Initialized
INFO - 2022-03-28 01:39:20 --> Security Class Initialized
DEBUG - 2022-03-28 01:39:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 01:39:20 --> Input Class Initialized
INFO - 2022-03-28 01:39:20 --> Language Class Initialized
INFO - 2022-03-28 01:39:20 --> Loader Class Initialized
INFO - 2022-03-28 01:39:20 --> Helper loaded: url_helper
INFO - 2022-03-28 01:39:20 --> Helper loaded: form_helper
INFO - 2022-03-28 01:39:20 --> Helper loaded: common_helper
INFO - 2022-03-28 01:39:20 --> Database Driver Class Initialized
DEBUG - 2022-03-28 01:39:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 01:39:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 01:39:20 --> Controller Class Initialized
INFO - 2022-03-28 01:39:20 --> Form Validation Class Initialized
DEBUG - 2022-03-28 01:39:20 --> Encrypt Class Initialized
INFO - 2022-03-28 01:39:20 --> Model "Patient_model" initialized
INFO - 2022-03-28 01:39:20 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 01:39:20 --> Model "Prefix_master" initialized
INFO - 2022-03-28 01:39:20 --> Model "Users_model" initialized
INFO - 2022-03-28 01:39:20 --> Model "Hospital_model" initialized
INFO - 2022-03-28 01:39:20 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-28 01:39:20 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-28 01:39:20 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-28 01:39:20 --> Final output sent to browser
DEBUG - 2022-03-28 01:39:20 --> Total execution time: 0.0973
ERROR - 2022-03-28 01:39:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 01:39:23 --> Config Class Initialized
INFO - 2022-03-28 01:39:23 --> Hooks Class Initialized
DEBUG - 2022-03-28 01:39:23 --> UTF-8 Support Enabled
INFO - 2022-03-28 01:39:23 --> Utf8 Class Initialized
INFO - 2022-03-28 01:39:23 --> URI Class Initialized
INFO - 2022-03-28 01:39:23 --> Router Class Initialized
INFO - 2022-03-28 01:39:23 --> Output Class Initialized
INFO - 2022-03-28 01:39:23 --> Security Class Initialized
DEBUG - 2022-03-28 01:39:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 01:39:23 --> Input Class Initialized
INFO - 2022-03-28 01:39:23 --> Language Class Initialized
INFO - 2022-03-28 01:39:23 --> Loader Class Initialized
INFO - 2022-03-28 01:39:23 --> Helper loaded: url_helper
INFO - 2022-03-28 01:39:23 --> Helper loaded: form_helper
INFO - 2022-03-28 01:39:23 --> Helper loaded: common_helper
INFO - 2022-03-28 01:39:23 --> Database Driver Class Initialized
DEBUG - 2022-03-28 01:39:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 01:39:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 01:39:23 --> Controller Class Initialized
INFO - 2022-03-28 01:39:23 --> Form Validation Class Initialized
DEBUG - 2022-03-28 01:39:23 --> Encrypt Class Initialized
INFO - 2022-03-28 01:39:23 --> Model "Patient_model" initialized
INFO - 2022-03-28 01:39:23 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 01:39:23 --> Model "Referredby_model" initialized
INFO - 2022-03-28 01:39:23 --> Model "Prefix_master" initialized
INFO - 2022-03-28 01:39:23 --> Model "Hospital_model" initialized
INFO - 2022-03-28 01:39:23 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-28 01:39:23 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-28 01:39:23 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-28 01:39:23 --> Final output sent to browser
DEBUG - 2022-03-28 01:39:23 --> Total execution time: 0.0292
ERROR - 2022-03-28 01:39:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 01:39:36 --> Config Class Initialized
INFO - 2022-03-28 01:39:36 --> Hooks Class Initialized
DEBUG - 2022-03-28 01:39:36 --> UTF-8 Support Enabled
INFO - 2022-03-28 01:39:36 --> Utf8 Class Initialized
INFO - 2022-03-28 01:39:36 --> URI Class Initialized
INFO - 2022-03-28 01:39:36 --> Router Class Initialized
INFO - 2022-03-28 01:39:36 --> Output Class Initialized
INFO - 2022-03-28 01:39:36 --> Security Class Initialized
DEBUG - 2022-03-28 01:39:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 01:39:36 --> Input Class Initialized
INFO - 2022-03-28 01:39:36 --> Language Class Initialized
INFO - 2022-03-28 01:39:36 --> Loader Class Initialized
INFO - 2022-03-28 01:39:36 --> Helper loaded: url_helper
INFO - 2022-03-28 01:39:36 --> Helper loaded: form_helper
INFO - 2022-03-28 01:39:36 --> Helper loaded: common_helper
INFO - 2022-03-28 01:39:36 --> Database Driver Class Initialized
DEBUG - 2022-03-28 01:39:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 01:39:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 01:39:36 --> Controller Class Initialized
INFO - 2022-03-28 01:39:36 --> Form Validation Class Initialized
DEBUG - 2022-03-28 01:39:36 --> Encrypt Class Initialized
INFO - 2022-03-28 01:39:36 --> Model "Patient_model" initialized
INFO - 2022-03-28 01:39:36 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 01:39:36 --> Model "Prefix_master" initialized
INFO - 2022-03-28 01:39:36 --> Model "Users_model" initialized
INFO - 2022-03-28 01:39:36 --> Model "Hospital_model" initialized
INFO - 2022-03-28 01:39:37 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-28 01:39:38 --> Final output sent to browser
DEBUG - 2022-03-28 01:39:38 --> Total execution time: 1.0953
ERROR - 2022-03-28 01:43:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 01:43:21 --> Config Class Initialized
INFO - 2022-03-28 01:43:21 --> Hooks Class Initialized
DEBUG - 2022-03-28 01:43:21 --> UTF-8 Support Enabled
INFO - 2022-03-28 01:43:21 --> Utf8 Class Initialized
INFO - 2022-03-28 01:43:21 --> URI Class Initialized
INFO - 2022-03-28 01:43:21 --> Router Class Initialized
INFO - 2022-03-28 01:43:21 --> Output Class Initialized
INFO - 2022-03-28 01:43:21 --> Security Class Initialized
DEBUG - 2022-03-28 01:43:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 01:43:21 --> Input Class Initialized
INFO - 2022-03-28 01:43:21 --> Language Class Initialized
INFO - 2022-03-28 01:43:21 --> Loader Class Initialized
INFO - 2022-03-28 01:43:21 --> Helper loaded: url_helper
INFO - 2022-03-28 01:43:21 --> Helper loaded: form_helper
INFO - 2022-03-28 01:43:21 --> Helper loaded: common_helper
INFO - 2022-03-28 01:43:21 --> Database Driver Class Initialized
DEBUG - 2022-03-28 01:43:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 01:43:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 01:43:21 --> Controller Class Initialized
INFO - 2022-03-28 01:43:21 --> Form Validation Class Initialized
DEBUG - 2022-03-28 01:43:21 --> Encrypt Class Initialized
INFO - 2022-03-28 01:43:21 --> Model "Patient_model" initialized
INFO - 2022-03-28 01:43:21 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 01:43:21 --> Model "Referredby_model" initialized
INFO - 2022-03-28 01:43:21 --> Model "Prefix_master" initialized
INFO - 2022-03-28 01:43:21 --> Model "Hospital_model" initialized
INFO - 2022-03-28 01:43:21 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-28 01:43:21 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-28 01:43:21 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-28 01:43:21 --> Final output sent to browser
DEBUG - 2022-03-28 01:43:21 --> Total execution time: 0.0722
ERROR - 2022-03-28 01:43:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 01:43:27 --> Config Class Initialized
INFO - 2022-03-28 01:43:27 --> Hooks Class Initialized
DEBUG - 2022-03-28 01:43:27 --> UTF-8 Support Enabled
INFO - 2022-03-28 01:43:27 --> Utf8 Class Initialized
INFO - 2022-03-28 01:43:27 --> URI Class Initialized
INFO - 2022-03-28 01:43:27 --> Router Class Initialized
INFO - 2022-03-28 01:43:27 --> Output Class Initialized
INFO - 2022-03-28 01:43:27 --> Security Class Initialized
DEBUG - 2022-03-28 01:43:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 01:43:27 --> Input Class Initialized
INFO - 2022-03-28 01:43:27 --> Language Class Initialized
INFO - 2022-03-28 01:43:27 --> Loader Class Initialized
INFO - 2022-03-28 01:43:27 --> Helper loaded: url_helper
INFO - 2022-03-28 01:43:27 --> Helper loaded: form_helper
INFO - 2022-03-28 01:43:27 --> Helper loaded: common_helper
INFO - 2022-03-28 01:43:27 --> Database Driver Class Initialized
DEBUG - 2022-03-28 01:43:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 01:43:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 01:43:27 --> Controller Class Initialized
INFO - 2022-03-28 01:43:27 --> Form Validation Class Initialized
DEBUG - 2022-03-28 01:43:27 --> Encrypt Class Initialized
INFO - 2022-03-28 01:43:27 --> Model "Patient_model" initialized
INFO - 2022-03-28 01:43:27 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 01:43:27 --> Model "Referredby_model" initialized
INFO - 2022-03-28 01:43:27 --> Model "Prefix_master" initialized
INFO - 2022-03-28 01:43:27 --> Model "Hospital_model" initialized
ERROR - 2022-03-28 01:43:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 01:43:27 --> Config Class Initialized
INFO - 2022-03-28 01:43:27 --> Hooks Class Initialized
DEBUG - 2022-03-28 01:43:27 --> UTF-8 Support Enabled
INFO - 2022-03-28 01:43:27 --> Utf8 Class Initialized
INFO - 2022-03-28 01:43:27 --> URI Class Initialized
INFO - 2022-03-28 01:43:27 --> Router Class Initialized
INFO - 2022-03-28 01:43:27 --> Output Class Initialized
INFO - 2022-03-28 01:43:27 --> Security Class Initialized
DEBUG - 2022-03-28 01:43:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 01:43:27 --> Input Class Initialized
INFO - 2022-03-28 01:43:27 --> Language Class Initialized
INFO - 2022-03-28 01:43:27 --> Loader Class Initialized
INFO - 2022-03-28 01:43:27 --> Helper loaded: url_helper
INFO - 2022-03-28 01:43:27 --> Helper loaded: form_helper
INFO - 2022-03-28 01:43:27 --> Helper loaded: common_helper
INFO - 2022-03-28 01:43:27 --> Database Driver Class Initialized
DEBUG - 2022-03-28 01:43:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 01:43:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 01:43:27 --> Controller Class Initialized
INFO - 2022-03-28 01:43:27 --> Form Validation Class Initialized
DEBUG - 2022-03-28 01:43:27 --> Encrypt Class Initialized
INFO - 2022-03-28 01:43:27 --> Model "Patient_model" initialized
INFO - 2022-03-28 01:43:27 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 01:43:27 --> Model "Referredby_model" initialized
INFO - 2022-03-28 01:43:27 --> Model "Prefix_master" initialized
INFO - 2022-03-28 01:43:27 --> Model "Hospital_model" initialized
INFO - 2022-03-28 01:43:27 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-28 01:43:27 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-28 01:43:27 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-28 01:43:27 --> Final output sent to browser
DEBUG - 2022-03-28 01:43:27 --> Total execution time: 0.0248
ERROR - 2022-03-28 01:43:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 01:43:28 --> Config Class Initialized
INFO - 2022-03-28 01:43:28 --> Hooks Class Initialized
DEBUG - 2022-03-28 01:43:28 --> UTF-8 Support Enabled
INFO - 2022-03-28 01:43:28 --> Utf8 Class Initialized
INFO - 2022-03-28 01:43:28 --> URI Class Initialized
INFO - 2022-03-28 01:43:28 --> Router Class Initialized
INFO - 2022-03-28 01:43:28 --> Output Class Initialized
INFO - 2022-03-28 01:43:28 --> Security Class Initialized
DEBUG - 2022-03-28 01:43:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 01:43:28 --> Input Class Initialized
INFO - 2022-03-28 01:43:28 --> Language Class Initialized
INFO - 2022-03-28 01:43:28 --> Loader Class Initialized
INFO - 2022-03-28 01:43:28 --> Helper loaded: url_helper
INFO - 2022-03-28 01:43:28 --> Helper loaded: form_helper
INFO - 2022-03-28 01:43:28 --> Helper loaded: common_helper
INFO - 2022-03-28 01:43:28 --> Database Driver Class Initialized
DEBUG - 2022-03-28 01:43:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 01:43:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 01:43:28 --> Controller Class Initialized
INFO - 2022-03-28 01:43:28 --> Form Validation Class Initialized
DEBUG - 2022-03-28 01:43:28 --> Encrypt Class Initialized
INFO - 2022-03-28 01:43:28 --> Model "Patient_model" initialized
INFO - 2022-03-28 01:43:28 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 01:43:28 --> Model "Prefix_master" initialized
INFO - 2022-03-28 01:43:28 --> Model "Users_model" initialized
INFO - 2022-03-28 01:43:28 --> Model "Hospital_model" initialized
INFO - 2022-03-28 01:43:28 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-28 01:43:28 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-28 01:43:28 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-28 01:43:28 --> Final output sent to browser
DEBUG - 2022-03-28 01:43:28 --> Total execution time: 0.0403
ERROR - 2022-03-28 01:46:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 01:46:40 --> Config Class Initialized
INFO - 2022-03-28 01:46:40 --> Hooks Class Initialized
DEBUG - 2022-03-28 01:46:40 --> UTF-8 Support Enabled
INFO - 2022-03-28 01:46:40 --> Utf8 Class Initialized
INFO - 2022-03-28 01:46:40 --> URI Class Initialized
INFO - 2022-03-28 01:46:40 --> Router Class Initialized
INFO - 2022-03-28 01:46:40 --> Output Class Initialized
INFO - 2022-03-28 01:46:40 --> Security Class Initialized
DEBUG - 2022-03-28 01:46:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 01:46:40 --> Input Class Initialized
INFO - 2022-03-28 01:46:40 --> Language Class Initialized
INFO - 2022-03-28 01:46:40 --> Loader Class Initialized
INFO - 2022-03-28 01:46:40 --> Helper loaded: url_helper
INFO - 2022-03-28 01:46:40 --> Helper loaded: form_helper
INFO - 2022-03-28 01:46:40 --> Helper loaded: common_helper
INFO - 2022-03-28 01:46:40 --> Database Driver Class Initialized
DEBUG - 2022-03-28 01:46:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 01:46:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 01:46:40 --> Controller Class Initialized
INFO - 2022-03-28 01:46:40 --> Form Validation Class Initialized
DEBUG - 2022-03-28 01:46:40 --> Encrypt Class Initialized
INFO - 2022-03-28 01:46:40 --> Model "Patient_model" initialized
INFO - 2022-03-28 01:46:40 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 01:46:40 --> Model "Prefix_master" initialized
INFO - 2022-03-28 01:46:40 --> Model "Users_model" initialized
INFO - 2022-03-28 01:46:40 --> Model "Hospital_model" initialized
ERROR - 2022-03-28 01:46:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 01:46:41 --> Config Class Initialized
INFO - 2022-03-28 01:46:41 --> Hooks Class Initialized
DEBUG - 2022-03-28 01:46:41 --> UTF-8 Support Enabled
INFO - 2022-03-28 01:46:41 --> Utf8 Class Initialized
INFO - 2022-03-28 01:46:41 --> URI Class Initialized
INFO - 2022-03-28 01:46:41 --> Router Class Initialized
INFO - 2022-03-28 01:46:41 --> Output Class Initialized
INFO - 2022-03-28 01:46:41 --> Security Class Initialized
DEBUG - 2022-03-28 01:46:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 01:46:41 --> Input Class Initialized
INFO - 2022-03-28 01:46:41 --> Language Class Initialized
INFO - 2022-03-28 01:46:41 --> Loader Class Initialized
INFO - 2022-03-28 01:46:41 --> Helper loaded: url_helper
INFO - 2022-03-28 01:46:41 --> Helper loaded: form_helper
INFO - 2022-03-28 01:46:41 --> Helper loaded: common_helper
INFO - 2022-03-28 01:46:41 --> Database Driver Class Initialized
DEBUG - 2022-03-28 01:46:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 01:46:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 01:46:41 --> Controller Class Initialized
INFO - 2022-03-28 01:46:41 --> Form Validation Class Initialized
DEBUG - 2022-03-28 01:46:41 --> Encrypt Class Initialized
INFO - 2022-03-28 01:46:41 --> Model "Patient_model" initialized
INFO - 2022-03-28 01:46:41 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 01:46:41 --> Model "Prefix_master" initialized
INFO - 2022-03-28 01:46:41 --> Model "Users_model" initialized
INFO - 2022-03-28 01:46:41 --> Model "Hospital_model" initialized
INFO - 2022-03-28 01:46:41 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-28 01:46:41 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-28 01:46:41 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-28 01:46:41 --> Final output sent to browser
DEBUG - 2022-03-28 01:46:41 --> Total execution time: 0.0449
ERROR - 2022-03-28 01:47:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 01:47:20 --> Config Class Initialized
INFO - 2022-03-28 01:47:20 --> Hooks Class Initialized
DEBUG - 2022-03-28 01:47:20 --> UTF-8 Support Enabled
INFO - 2022-03-28 01:47:20 --> Utf8 Class Initialized
INFO - 2022-03-28 01:47:20 --> URI Class Initialized
INFO - 2022-03-28 01:47:20 --> Router Class Initialized
INFO - 2022-03-28 01:47:20 --> Output Class Initialized
INFO - 2022-03-28 01:47:20 --> Security Class Initialized
DEBUG - 2022-03-28 01:47:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 01:47:20 --> Input Class Initialized
INFO - 2022-03-28 01:47:20 --> Language Class Initialized
INFO - 2022-03-28 01:47:20 --> Loader Class Initialized
INFO - 2022-03-28 01:47:20 --> Helper loaded: url_helper
INFO - 2022-03-28 01:47:20 --> Helper loaded: form_helper
INFO - 2022-03-28 01:47:20 --> Helper loaded: common_helper
INFO - 2022-03-28 01:47:20 --> Database Driver Class Initialized
DEBUG - 2022-03-28 01:47:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 01:47:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 01:47:20 --> Controller Class Initialized
INFO - 2022-03-28 01:47:20 --> Form Validation Class Initialized
DEBUG - 2022-03-28 01:47:20 --> Encrypt Class Initialized
INFO - 2022-03-28 01:47:20 --> Model "Patient_model" initialized
INFO - 2022-03-28 01:47:20 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 01:47:20 --> Model "Prefix_master" initialized
INFO - 2022-03-28 01:47:20 --> Model "Users_model" initialized
INFO - 2022-03-28 01:47:20 --> Model "Hospital_model" initialized
INFO - 2022-03-28 01:47:20 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-28 01:47:21 --> Final output sent to browser
DEBUG - 2022-03-28 01:47:21 --> Total execution time: 1.0433
ERROR - 2022-03-28 02:00:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 02:00:43 --> Config Class Initialized
INFO - 2022-03-28 02:00:43 --> Hooks Class Initialized
DEBUG - 2022-03-28 02:00:43 --> UTF-8 Support Enabled
INFO - 2022-03-28 02:00:43 --> Utf8 Class Initialized
INFO - 2022-03-28 02:00:43 --> URI Class Initialized
INFO - 2022-03-28 02:00:43 --> Router Class Initialized
INFO - 2022-03-28 02:00:43 --> Output Class Initialized
INFO - 2022-03-28 02:00:43 --> Security Class Initialized
DEBUG - 2022-03-28 02:00:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 02:00:43 --> Input Class Initialized
INFO - 2022-03-28 02:00:43 --> Language Class Initialized
INFO - 2022-03-28 02:00:43 --> Loader Class Initialized
INFO - 2022-03-28 02:00:43 --> Helper loaded: url_helper
INFO - 2022-03-28 02:00:43 --> Helper loaded: form_helper
INFO - 2022-03-28 02:00:43 --> Helper loaded: common_helper
INFO - 2022-03-28 02:00:43 --> Database Driver Class Initialized
DEBUG - 2022-03-28 02:00:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 02:00:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 02:00:43 --> Controller Class Initialized
INFO - 2022-03-28 02:00:43 --> Form Validation Class Initialized
DEBUG - 2022-03-28 02:00:43 --> Encrypt Class Initialized
INFO - 2022-03-28 02:00:43 --> Model "Patient_model" initialized
INFO - 2022-03-28 02:00:43 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 02:00:43 --> Model "Prefix_master" initialized
INFO - 2022-03-28 02:00:43 --> Model "Users_model" initialized
INFO - 2022-03-28 02:00:43 --> Model "Hospital_model" initialized
ERROR - 2022-03-28 02:00:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 02:00:44 --> Config Class Initialized
INFO - 2022-03-28 02:00:44 --> Hooks Class Initialized
DEBUG - 2022-03-28 02:00:44 --> UTF-8 Support Enabled
INFO - 2022-03-28 02:00:44 --> Utf8 Class Initialized
INFO - 2022-03-28 02:00:44 --> URI Class Initialized
INFO - 2022-03-28 02:00:44 --> Router Class Initialized
INFO - 2022-03-28 02:00:44 --> Output Class Initialized
INFO - 2022-03-28 02:00:44 --> Security Class Initialized
DEBUG - 2022-03-28 02:00:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 02:00:44 --> Input Class Initialized
INFO - 2022-03-28 02:00:44 --> Language Class Initialized
INFO - 2022-03-28 02:00:44 --> Loader Class Initialized
INFO - 2022-03-28 02:00:44 --> Helper loaded: url_helper
INFO - 2022-03-28 02:00:44 --> Helper loaded: form_helper
INFO - 2022-03-28 02:00:44 --> Helper loaded: common_helper
INFO - 2022-03-28 02:00:44 --> Database Driver Class Initialized
DEBUG - 2022-03-28 02:00:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 02:00:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 02:00:44 --> Controller Class Initialized
INFO - 2022-03-28 02:00:44 --> Form Validation Class Initialized
DEBUG - 2022-03-28 02:00:44 --> Encrypt Class Initialized
INFO - 2022-03-28 02:00:44 --> Model "Patient_model" initialized
INFO - 2022-03-28 02:00:44 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 02:00:44 --> Model "Prefix_master" initialized
INFO - 2022-03-28 02:00:44 --> Model "Users_model" initialized
INFO - 2022-03-28 02:00:44 --> Model "Hospital_model" initialized
INFO - 2022-03-28 02:00:44 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-28 02:00:44 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-28 02:00:44 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-28 02:00:44 --> Final output sent to browser
DEBUG - 2022-03-28 02:00:44 --> Total execution time: 0.0482
ERROR - 2022-03-28 02:13:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 02:13:09 --> Config Class Initialized
INFO - 2022-03-28 02:13:09 --> Hooks Class Initialized
DEBUG - 2022-03-28 02:13:09 --> UTF-8 Support Enabled
INFO - 2022-03-28 02:13:09 --> Utf8 Class Initialized
INFO - 2022-03-28 02:13:09 --> URI Class Initialized
INFO - 2022-03-28 02:13:09 --> Router Class Initialized
INFO - 2022-03-28 02:13:09 --> Output Class Initialized
INFO - 2022-03-28 02:13:09 --> Security Class Initialized
DEBUG - 2022-03-28 02:13:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 02:13:09 --> Input Class Initialized
INFO - 2022-03-28 02:13:09 --> Language Class Initialized
INFO - 2022-03-28 02:13:09 --> Loader Class Initialized
INFO - 2022-03-28 02:13:09 --> Helper loaded: url_helper
INFO - 2022-03-28 02:13:09 --> Helper loaded: form_helper
INFO - 2022-03-28 02:13:09 --> Helper loaded: common_helper
INFO - 2022-03-28 02:13:09 --> Database Driver Class Initialized
DEBUG - 2022-03-28 02:13:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 02:13:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 02:13:09 --> Controller Class Initialized
INFO - 2022-03-28 02:13:09 --> Form Validation Class Initialized
DEBUG - 2022-03-28 02:13:09 --> Encrypt Class Initialized
INFO - 2022-03-28 02:13:09 --> Model "Patient_model" initialized
INFO - 2022-03-28 02:13:09 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 02:13:09 --> Model "Prefix_master" initialized
INFO - 2022-03-28 02:13:09 --> Model "Users_model" initialized
INFO - 2022-03-28 02:13:09 --> Model "Hospital_model" initialized
ERROR - 2022-03-28 02:13:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 02:13:09 --> Config Class Initialized
INFO - 2022-03-28 02:13:09 --> Hooks Class Initialized
DEBUG - 2022-03-28 02:13:09 --> UTF-8 Support Enabled
INFO - 2022-03-28 02:13:09 --> Utf8 Class Initialized
INFO - 2022-03-28 02:13:09 --> URI Class Initialized
INFO - 2022-03-28 02:13:09 --> Router Class Initialized
INFO - 2022-03-28 02:13:09 --> Output Class Initialized
INFO - 2022-03-28 02:13:09 --> Security Class Initialized
DEBUG - 2022-03-28 02:13:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 02:13:09 --> Input Class Initialized
INFO - 2022-03-28 02:13:09 --> Language Class Initialized
INFO - 2022-03-28 02:13:09 --> Loader Class Initialized
INFO - 2022-03-28 02:13:09 --> Helper loaded: url_helper
INFO - 2022-03-28 02:13:09 --> Helper loaded: form_helper
INFO - 2022-03-28 02:13:09 --> Helper loaded: common_helper
INFO - 2022-03-28 02:13:09 --> Database Driver Class Initialized
DEBUG - 2022-03-28 02:13:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 02:13:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 02:13:09 --> Controller Class Initialized
INFO - 2022-03-28 02:13:09 --> Form Validation Class Initialized
DEBUG - 2022-03-28 02:13:09 --> Encrypt Class Initialized
INFO - 2022-03-28 02:13:09 --> Model "Patient_model" initialized
INFO - 2022-03-28 02:13:09 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 02:13:09 --> Model "Prefix_master" initialized
INFO - 2022-03-28 02:13:09 --> Model "Users_model" initialized
INFO - 2022-03-28 02:13:09 --> Model "Hospital_model" initialized
INFO - 2022-03-28 02:13:10 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-28 02:13:10 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-28 02:13:10 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-28 02:13:10 --> Final output sent to browser
DEBUG - 2022-03-28 02:13:10 --> Total execution time: 0.0475
ERROR - 2022-03-28 02:14:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 02:14:14 --> Config Class Initialized
INFO - 2022-03-28 02:14:14 --> Hooks Class Initialized
DEBUG - 2022-03-28 02:14:14 --> UTF-8 Support Enabled
INFO - 2022-03-28 02:14:14 --> Utf8 Class Initialized
INFO - 2022-03-28 02:14:14 --> URI Class Initialized
INFO - 2022-03-28 02:14:14 --> Router Class Initialized
INFO - 2022-03-28 02:14:14 --> Output Class Initialized
INFO - 2022-03-28 02:14:14 --> Security Class Initialized
DEBUG - 2022-03-28 02:14:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 02:14:14 --> Input Class Initialized
INFO - 2022-03-28 02:14:14 --> Language Class Initialized
INFO - 2022-03-28 02:14:14 --> Loader Class Initialized
INFO - 2022-03-28 02:14:14 --> Helper loaded: url_helper
INFO - 2022-03-28 02:14:14 --> Helper loaded: form_helper
INFO - 2022-03-28 02:14:14 --> Helper loaded: common_helper
INFO - 2022-03-28 02:14:14 --> Database Driver Class Initialized
DEBUG - 2022-03-28 02:14:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 02:14:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 02:14:14 --> Controller Class Initialized
INFO - 2022-03-28 02:14:14 --> Form Validation Class Initialized
DEBUG - 2022-03-28 02:14:14 --> Encrypt Class Initialized
INFO - 2022-03-28 02:14:14 --> Model "Patient_model" initialized
INFO - 2022-03-28 02:14:14 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 02:14:14 --> Model "Prefix_master" initialized
INFO - 2022-03-28 02:14:14 --> Model "Users_model" initialized
INFO - 2022-03-28 02:14:14 --> Model "Hospital_model" initialized
ERROR - 2022-03-28 02:14:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 02:14:15 --> Config Class Initialized
INFO - 2022-03-28 02:14:15 --> Hooks Class Initialized
DEBUG - 2022-03-28 02:14:15 --> UTF-8 Support Enabled
INFO - 2022-03-28 02:14:15 --> Utf8 Class Initialized
INFO - 2022-03-28 02:14:15 --> URI Class Initialized
INFO - 2022-03-28 02:14:15 --> Router Class Initialized
INFO - 2022-03-28 02:14:15 --> Output Class Initialized
INFO - 2022-03-28 02:14:15 --> Security Class Initialized
DEBUG - 2022-03-28 02:14:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 02:14:15 --> Input Class Initialized
INFO - 2022-03-28 02:14:15 --> Language Class Initialized
INFO - 2022-03-28 02:14:15 --> Loader Class Initialized
INFO - 2022-03-28 02:14:15 --> Helper loaded: url_helper
INFO - 2022-03-28 02:14:15 --> Helper loaded: form_helper
INFO - 2022-03-28 02:14:15 --> Helper loaded: common_helper
INFO - 2022-03-28 02:14:15 --> Database Driver Class Initialized
DEBUG - 2022-03-28 02:14:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 02:14:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 02:14:15 --> Controller Class Initialized
INFO - 2022-03-28 02:14:15 --> Form Validation Class Initialized
DEBUG - 2022-03-28 02:14:15 --> Encrypt Class Initialized
INFO - 2022-03-28 02:14:15 --> Model "Patient_model" initialized
INFO - 2022-03-28 02:14:15 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 02:14:15 --> Model "Prefix_master" initialized
INFO - 2022-03-28 02:14:15 --> Model "Users_model" initialized
INFO - 2022-03-28 02:14:15 --> Model "Hospital_model" initialized
INFO - 2022-03-28 02:14:15 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-28 02:14:15 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-28 02:14:15 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-28 02:14:15 --> Final output sent to browser
DEBUG - 2022-03-28 02:14:15 --> Total execution time: 0.0448
ERROR - 2022-03-28 02:17:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 02:17:51 --> Config Class Initialized
INFO - 2022-03-28 02:17:51 --> Hooks Class Initialized
DEBUG - 2022-03-28 02:17:51 --> UTF-8 Support Enabled
INFO - 2022-03-28 02:17:51 --> Utf8 Class Initialized
INFO - 2022-03-28 02:17:51 --> URI Class Initialized
INFO - 2022-03-28 02:17:51 --> Router Class Initialized
INFO - 2022-03-28 02:17:51 --> Output Class Initialized
INFO - 2022-03-28 02:17:51 --> Security Class Initialized
DEBUG - 2022-03-28 02:17:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 02:17:51 --> Input Class Initialized
INFO - 2022-03-28 02:17:51 --> Language Class Initialized
INFO - 2022-03-28 02:17:51 --> Loader Class Initialized
INFO - 2022-03-28 02:17:51 --> Helper loaded: url_helper
INFO - 2022-03-28 02:17:51 --> Helper loaded: form_helper
INFO - 2022-03-28 02:17:51 --> Helper loaded: common_helper
INFO - 2022-03-28 02:17:51 --> Database Driver Class Initialized
DEBUG - 2022-03-28 02:17:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 02:17:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 02:17:51 --> Controller Class Initialized
INFO - 2022-03-28 02:17:51 --> Form Validation Class Initialized
DEBUG - 2022-03-28 02:17:51 --> Encrypt Class Initialized
INFO - 2022-03-28 02:17:51 --> Model "Patient_model" initialized
INFO - 2022-03-28 02:17:51 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 02:17:51 --> Model "Referredby_model" initialized
INFO - 2022-03-28 02:17:51 --> Model "Prefix_master" initialized
INFO - 2022-03-28 02:17:51 --> Model "Hospital_model" initialized
INFO - 2022-03-28 02:17:51 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-28 02:17:51 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-28 02:17:51 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-28 02:17:51 --> Final output sent to browser
DEBUG - 2022-03-28 02:17:51 --> Total execution time: 0.0776
ERROR - 2022-03-28 02:20:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 02:20:19 --> Config Class Initialized
INFO - 2022-03-28 02:20:19 --> Hooks Class Initialized
DEBUG - 2022-03-28 02:20:19 --> UTF-8 Support Enabled
INFO - 2022-03-28 02:20:19 --> Utf8 Class Initialized
INFO - 2022-03-28 02:20:19 --> URI Class Initialized
INFO - 2022-03-28 02:20:19 --> Router Class Initialized
INFO - 2022-03-28 02:20:19 --> Output Class Initialized
INFO - 2022-03-28 02:20:19 --> Security Class Initialized
DEBUG - 2022-03-28 02:20:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 02:20:19 --> Input Class Initialized
INFO - 2022-03-28 02:20:19 --> Language Class Initialized
INFO - 2022-03-28 02:20:19 --> Loader Class Initialized
INFO - 2022-03-28 02:20:19 --> Helper loaded: url_helper
INFO - 2022-03-28 02:20:19 --> Helper loaded: form_helper
INFO - 2022-03-28 02:20:19 --> Helper loaded: common_helper
INFO - 2022-03-28 02:20:19 --> Database Driver Class Initialized
DEBUG - 2022-03-28 02:20:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 02:20:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 02:20:19 --> Controller Class Initialized
INFO - 2022-03-28 02:20:19 --> Form Validation Class Initialized
DEBUG - 2022-03-28 02:20:19 --> Encrypt Class Initialized
INFO - 2022-03-28 02:20:19 --> Model "Patient_model" initialized
INFO - 2022-03-28 02:20:19 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 02:20:19 --> Model "Referredby_model" initialized
INFO - 2022-03-28 02:20:19 --> Model "Prefix_master" initialized
INFO - 2022-03-28 02:20:19 --> Model "Hospital_model" initialized
ERROR - 2022-03-28 02:20:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 02:20:19 --> Config Class Initialized
INFO - 2022-03-28 02:20:19 --> Hooks Class Initialized
DEBUG - 2022-03-28 02:20:19 --> UTF-8 Support Enabled
INFO - 2022-03-28 02:20:19 --> Utf8 Class Initialized
INFO - 2022-03-28 02:20:19 --> URI Class Initialized
INFO - 2022-03-28 02:20:19 --> Router Class Initialized
INFO - 2022-03-28 02:20:19 --> Output Class Initialized
INFO - 2022-03-28 02:20:19 --> Security Class Initialized
DEBUG - 2022-03-28 02:20:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 02:20:19 --> Input Class Initialized
INFO - 2022-03-28 02:20:19 --> Language Class Initialized
INFO - 2022-03-28 02:20:19 --> Loader Class Initialized
INFO - 2022-03-28 02:20:19 --> Helper loaded: url_helper
INFO - 2022-03-28 02:20:19 --> Helper loaded: form_helper
INFO - 2022-03-28 02:20:19 --> Helper loaded: common_helper
INFO - 2022-03-28 02:20:19 --> Database Driver Class Initialized
DEBUG - 2022-03-28 02:20:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 02:20:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 02:20:19 --> Controller Class Initialized
INFO - 2022-03-28 02:20:19 --> Form Validation Class Initialized
DEBUG - 2022-03-28 02:20:19 --> Encrypt Class Initialized
INFO - 2022-03-28 02:20:19 --> Model "Patient_model" initialized
INFO - 2022-03-28 02:20:19 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 02:20:19 --> Model "Referredby_model" initialized
INFO - 2022-03-28 02:20:19 --> Model "Prefix_master" initialized
INFO - 2022-03-28 02:20:19 --> Model "Hospital_model" initialized
INFO - 2022-03-28 02:20:19 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-28 02:20:19 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-28 02:20:19 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-28 02:20:19 --> Final output sent to browser
DEBUG - 2022-03-28 02:20:19 --> Total execution time: 0.0260
ERROR - 2022-03-28 02:20:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 02:20:20 --> Config Class Initialized
INFO - 2022-03-28 02:20:20 --> Hooks Class Initialized
DEBUG - 2022-03-28 02:20:20 --> UTF-8 Support Enabled
INFO - 2022-03-28 02:20:20 --> Utf8 Class Initialized
INFO - 2022-03-28 02:20:20 --> URI Class Initialized
INFO - 2022-03-28 02:20:20 --> Router Class Initialized
INFO - 2022-03-28 02:20:20 --> Output Class Initialized
INFO - 2022-03-28 02:20:20 --> Security Class Initialized
DEBUG - 2022-03-28 02:20:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 02:20:20 --> Input Class Initialized
INFO - 2022-03-28 02:20:20 --> Language Class Initialized
INFO - 2022-03-28 02:20:20 --> Loader Class Initialized
INFO - 2022-03-28 02:20:20 --> Helper loaded: url_helper
INFO - 2022-03-28 02:20:20 --> Helper loaded: form_helper
INFO - 2022-03-28 02:20:20 --> Helper loaded: common_helper
INFO - 2022-03-28 02:20:20 --> Database Driver Class Initialized
DEBUG - 2022-03-28 02:20:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 02:20:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 02:20:20 --> Controller Class Initialized
INFO - 2022-03-28 02:20:20 --> Form Validation Class Initialized
DEBUG - 2022-03-28 02:20:20 --> Encrypt Class Initialized
INFO - 2022-03-28 02:20:20 --> Model "Patient_model" initialized
INFO - 2022-03-28 02:20:20 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 02:20:20 --> Model "Prefix_master" initialized
INFO - 2022-03-28 02:20:20 --> Model "Users_model" initialized
INFO - 2022-03-28 02:20:20 --> Model "Hospital_model" initialized
INFO - 2022-03-28 02:20:20 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-28 02:20:20 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-28 02:20:20 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-28 02:20:20 --> Final output sent to browser
DEBUG - 2022-03-28 02:20:20 --> Total execution time: 0.0530
ERROR - 2022-03-28 02:21:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 02:21:23 --> Config Class Initialized
INFO - 2022-03-28 02:21:23 --> Hooks Class Initialized
DEBUG - 2022-03-28 02:21:23 --> UTF-8 Support Enabled
INFO - 2022-03-28 02:21:23 --> Utf8 Class Initialized
INFO - 2022-03-28 02:21:23 --> URI Class Initialized
INFO - 2022-03-28 02:21:23 --> Router Class Initialized
INFO - 2022-03-28 02:21:23 --> Output Class Initialized
INFO - 2022-03-28 02:21:23 --> Security Class Initialized
DEBUG - 2022-03-28 02:21:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 02:21:23 --> Input Class Initialized
INFO - 2022-03-28 02:21:23 --> Language Class Initialized
INFO - 2022-03-28 02:21:23 --> Loader Class Initialized
INFO - 2022-03-28 02:21:23 --> Helper loaded: url_helper
INFO - 2022-03-28 02:21:23 --> Helper loaded: form_helper
INFO - 2022-03-28 02:21:23 --> Helper loaded: common_helper
INFO - 2022-03-28 02:21:23 --> Database Driver Class Initialized
DEBUG - 2022-03-28 02:21:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 02:21:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 02:21:23 --> Controller Class Initialized
INFO - 2022-03-28 02:21:23 --> Form Validation Class Initialized
DEBUG - 2022-03-28 02:21:23 --> Encrypt Class Initialized
INFO - 2022-03-28 02:21:23 --> Model "Patient_model" initialized
INFO - 2022-03-28 02:21:23 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 02:21:23 --> Model "Prefix_master" initialized
INFO - 2022-03-28 02:21:23 --> Model "Users_model" initialized
INFO - 2022-03-28 02:21:23 --> Model "Hospital_model" initialized
ERROR - 2022-03-28 02:21:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 02:21:23 --> Config Class Initialized
INFO - 2022-03-28 02:21:23 --> Hooks Class Initialized
DEBUG - 2022-03-28 02:21:23 --> UTF-8 Support Enabled
INFO - 2022-03-28 02:21:23 --> Utf8 Class Initialized
INFO - 2022-03-28 02:21:23 --> URI Class Initialized
INFO - 2022-03-28 02:21:23 --> Router Class Initialized
INFO - 2022-03-28 02:21:23 --> Output Class Initialized
INFO - 2022-03-28 02:21:23 --> Security Class Initialized
DEBUG - 2022-03-28 02:21:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 02:21:23 --> Input Class Initialized
INFO - 2022-03-28 02:21:23 --> Language Class Initialized
INFO - 2022-03-28 02:21:23 --> Loader Class Initialized
INFO - 2022-03-28 02:21:23 --> Helper loaded: url_helper
INFO - 2022-03-28 02:21:23 --> Helper loaded: form_helper
INFO - 2022-03-28 02:21:23 --> Helper loaded: common_helper
INFO - 2022-03-28 02:21:23 --> Database Driver Class Initialized
DEBUG - 2022-03-28 02:21:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 02:21:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 02:21:23 --> Controller Class Initialized
INFO - 2022-03-28 02:21:23 --> Form Validation Class Initialized
DEBUG - 2022-03-28 02:21:23 --> Encrypt Class Initialized
INFO - 2022-03-28 02:21:23 --> Model "Patient_model" initialized
INFO - 2022-03-28 02:21:23 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 02:21:23 --> Model "Prefix_master" initialized
INFO - 2022-03-28 02:21:23 --> Model "Users_model" initialized
INFO - 2022-03-28 02:21:23 --> Model "Hospital_model" initialized
INFO - 2022-03-28 02:21:23 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-28 02:21:23 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-28 02:21:23 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-28 02:21:23 --> Final output sent to browser
DEBUG - 2022-03-28 02:21:23 --> Total execution time: 0.0420
ERROR - 2022-03-28 02:25:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 02:25:08 --> Config Class Initialized
INFO - 2022-03-28 02:25:08 --> Hooks Class Initialized
DEBUG - 2022-03-28 02:25:08 --> UTF-8 Support Enabled
INFO - 2022-03-28 02:25:08 --> Utf8 Class Initialized
INFO - 2022-03-28 02:25:08 --> URI Class Initialized
INFO - 2022-03-28 02:25:08 --> Router Class Initialized
INFO - 2022-03-28 02:25:08 --> Output Class Initialized
INFO - 2022-03-28 02:25:08 --> Security Class Initialized
DEBUG - 2022-03-28 02:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 02:25:08 --> Input Class Initialized
INFO - 2022-03-28 02:25:08 --> Language Class Initialized
INFO - 2022-03-28 02:25:08 --> Loader Class Initialized
INFO - 2022-03-28 02:25:08 --> Helper loaded: url_helper
INFO - 2022-03-28 02:25:08 --> Helper loaded: form_helper
INFO - 2022-03-28 02:25:08 --> Helper loaded: common_helper
INFO - 2022-03-28 02:25:08 --> Database Driver Class Initialized
DEBUG - 2022-03-28 02:25:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 02:25:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 02:25:08 --> Controller Class Initialized
INFO - 2022-03-28 02:25:08 --> Form Validation Class Initialized
DEBUG - 2022-03-28 02:25:08 --> Encrypt Class Initialized
INFO - 2022-03-28 02:25:08 --> Model "Patient_model" initialized
INFO - 2022-03-28 02:25:08 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 02:25:08 --> Model "Prefix_master" initialized
INFO - 2022-03-28 02:25:08 --> Model "Users_model" initialized
INFO - 2022-03-28 02:25:08 --> Model "Hospital_model" initialized
ERROR - 2022-03-28 02:25:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 02:25:08 --> Config Class Initialized
INFO - 2022-03-28 02:25:08 --> Hooks Class Initialized
DEBUG - 2022-03-28 02:25:08 --> UTF-8 Support Enabled
INFO - 2022-03-28 02:25:08 --> Utf8 Class Initialized
INFO - 2022-03-28 02:25:08 --> URI Class Initialized
INFO - 2022-03-28 02:25:08 --> Router Class Initialized
INFO - 2022-03-28 02:25:08 --> Output Class Initialized
INFO - 2022-03-28 02:25:08 --> Security Class Initialized
DEBUG - 2022-03-28 02:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 02:25:08 --> Input Class Initialized
INFO - 2022-03-28 02:25:08 --> Language Class Initialized
INFO - 2022-03-28 02:25:08 --> Loader Class Initialized
INFO - 2022-03-28 02:25:08 --> Helper loaded: url_helper
INFO - 2022-03-28 02:25:08 --> Helper loaded: form_helper
INFO - 2022-03-28 02:25:08 --> Helper loaded: common_helper
INFO - 2022-03-28 02:25:08 --> Database Driver Class Initialized
DEBUG - 2022-03-28 02:25:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 02:25:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 02:25:08 --> Controller Class Initialized
INFO - 2022-03-28 02:25:08 --> Form Validation Class Initialized
DEBUG - 2022-03-28 02:25:08 --> Encrypt Class Initialized
INFO - 2022-03-28 02:25:08 --> Model "Patient_model" initialized
INFO - 2022-03-28 02:25:08 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 02:25:08 --> Model "Prefix_master" initialized
INFO - 2022-03-28 02:25:08 --> Model "Users_model" initialized
INFO - 2022-03-28 02:25:08 --> Model "Hospital_model" initialized
INFO - 2022-03-28 02:25:08 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-28 02:25:08 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-28 02:25:08 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-28 02:25:08 --> Final output sent to browser
DEBUG - 2022-03-28 02:25:08 --> Total execution time: 0.0508
ERROR - 2022-03-28 02:25:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 02:25:16 --> Config Class Initialized
INFO - 2022-03-28 02:25:16 --> Hooks Class Initialized
DEBUG - 2022-03-28 02:25:16 --> UTF-8 Support Enabled
INFO - 2022-03-28 02:25:16 --> Utf8 Class Initialized
INFO - 2022-03-28 02:25:16 --> URI Class Initialized
INFO - 2022-03-28 02:25:16 --> Router Class Initialized
INFO - 2022-03-28 02:25:16 --> Output Class Initialized
INFO - 2022-03-28 02:25:16 --> Security Class Initialized
DEBUG - 2022-03-28 02:25:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 02:25:16 --> Input Class Initialized
INFO - 2022-03-28 02:25:16 --> Language Class Initialized
INFO - 2022-03-28 02:25:16 --> Loader Class Initialized
INFO - 2022-03-28 02:25:16 --> Helper loaded: url_helper
INFO - 2022-03-28 02:25:16 --> Helper loaded: form_helper
INFO - 2022-03-28 02:25:16 --> Helper loaded: common_helper
INFO - 2022-03-28 02:25:16 --> Database Driver Class Initialized
DEBUG - 2022-03-28 02:25:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 02:25:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 02:25:16 --> Controller Class Initialized
INFO - 2022-03-28 02:25:16 --> Form Validation Class Initialized
INFO - 2022-03-28 02:25:16 --> Model "Case_model" initialized
INFO - 2022-03-28 02:25:16 --> Model "Hospital_model" initialized
INFO - 2022-03-28 02:25:16 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-28 02:25:16 --> File loaded: /home3/karoteam/public_html/application/views/transaction/upcomingFollowup.php
INFO - 2022-03-28 02:25:16 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-28 02:25:16 --> Final output sent to browser
DEBUG - 2022-03-28 02:25:16 --> Total execution time: 0.0127
ERROR - 2022-03-28 02:25:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 02:25:20 --> Config Class Initialized
INFO - 2022-03-28 02:25:20 --> Hooks Class Initialized
DEBUG - 2022-03-28 02:25:20 --> UTF-8 Support Enabled
INFO - 2022-03-28 02:25:20 --> Utf8 Class Initialized
INFO - 2022-03-28 02:25:20 --> URI Class Initialized
INFO - 2022-03-28 02:25:20 --> Router Class Initialized
INFO - 2022-03-28 02:25:20 --> Output Class Initialized
INFO - 2022-03-28 02:25:20 --> Security Class Initialized
DEBUG - 2022-03-28 02:25:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 02:25:20 --> Input Class Initialized
INFO - 2022-03-28 02:25:20 --> Language Class Initialized
INFO - 2022-03-28 02:25:20 --> Loader Class Initialized
INFO - 2022-03-28 02:25:20 --> Helper loaded: url_helper
INFO - 2022-03-28 02:25:20 --> Helper loaded: form_helper
INFO - 2022-03-28 02:25:20 --> Helper loaded: common_helper
INFO - 2022-03-28 02:25:20 --> Database Driver Class Initialized
DEBUG - 2022-03-28 02:25:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 02:25:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 02:25:20 --> Controller Class Initialized
INFO - 2022-03-28 02:25:20 --> Form Validation Class Initialized
DEBUG - 2022-03-28 02:25:20 --> Encrypt Class Initialized
INFO - 2022-03-28 02:25:20 --> Model "Patient_model" initialized
INFO - 2022-03-28 02:25:20 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 02:25:20 --> Model "Referredby_model" initialized
INFO - 2022-03-28 02:25:20 --> Model "Prefix_master" initialized
INFO - 2022-03-28 02:25:20 --> Model "Hospital_model" initialized
INFO - 2022-03-28 02:25:20 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-28 02:25:20 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-28 02:25:20 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-28 02:25:20 --> Final output sent to browser
DEBUG - 2022-03-28 02:25:20 --> Total execution time: 0.0611
ERROR - 2022-03-28 02:25:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 02:25:32 --> Config Class Initialized
INFO - 2022-03-28 02:25:32 --> Hooks Class Initialized
DEBUG - 2022-03-28 02:25:32 --> UTF-8 Support Enabled
INFO - 2022-03-28 02:25:32 --> Utf8 Class Initialized
INFO - 2022-03-28 02:25:32 --> URI Class Initialized
INFO - 2022-03-28 02:25:32 --> Router Class Initialized
INFO - 2022-03-28 02:25:32 --> Output Class Initialized
INFO - 2022-03-28 02:25:32 --> Security Class Initialized
DEBUG - 2022-03-28 02:25:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 02:25:32 --> Input Class Initialized
INFO - 2022-03-28 02:25:32 --> Language Class Initialized
INFO - 2022-03-28 02:25:32 --> Loader Class Initialized
INFO - 2022-03-28 02:25:32 --> Helper loaded: url_helper
INFO - 2022-03-28 02:25:32 --> Helper loaded: form_helper
INFO - 2022-03-28 02:25:32 --> Helper loaded: common_helper
INFO - 2022-03-28 02:25:32 --> Database Driver Class Initialized
DEBUG - 2022-03-28 02:25:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 02:25:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 02:25:32 --> Controller Class Initialized
INFO - 2022-03-28 02:25:32 --> Form Validation Class Initialized
DEBUG - 2022-03-28 02:25:32 --> Encrypt Class Initialized
INFO - 2022-03-28 02:25:32 --> Model "Patient_model" initialized
INFO - 2022-03-28 02:25:32 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 02:25:32 --> Model "Prefix_master" initialized
INFO - 2022-03-28 02:25:32 --> Model "Users_model" initialized
INFO - 2022-03-28 02:25:32 --> Model "Hospital_model" initialized
INFO - 2022-03-28 02:25:32 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-28 02:25:33 --> Final output sent to browser
DEBUG - 2022-03-28 02:25:33 --> Total execution time: 1.1140
ERROR - 2022-03-28 02:26:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 02:26:02 --> Config Class Initialized
INFO - 2022-03-28 02:26:02 --> Hooks Class Initialized
DEBUG - 2022-03-28 02:26:02 --> UTF-8 Support Enabled
INFO - 2022-03-28 02:26:02 --> Utf8 Class Initialized
INFO - 2022-03-28 02:26:02 --> URI Class Initialized
INFO - 2022-03-28 02:26:02 --> Router Class Initialized
INFO - 2022-03-28 02:26:02 --> Output Class Initialized
INFO - 2022-03-28 02:26:02 --> Security Class Initialized
DEBUG - 2022-03-28 02:26:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 02:26:02 --> Input Class Initialized
INFO - 2022-03-28 02:26:02 --> Language Class Initialized
INFO - 2022-03-28 02:26:02 --> Loader Class Initialized
INFO - 2022-03-28 02:26:02 --> Helper loaded: url_helper
INFO - 2022-03-28 02:26:02 --> Helper loaded: form_helper
INFO - 2022-03-28 02:26:02 --> Helper loaded: common_helper
INFO - 2022-03-28 02:26:02 --> Database Driver Class Initialized
DEBUG - 2022-03-28 02:26:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 02:26:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 02:26:02 --> Controller Class Initialized
INFO - 2022-03-28 02:26:02 --> Form Validation Class Initialized
DEBUG - 2022-03-28 02:26:02 --> Encrypt Class Initialized
INFO - 2022-03-28 02:26:02 --> Model "Patient_model" initialized
INFO - 2022-03-28 02:26:02 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 02:26:02 --> Model "Prefix_master" initialized
INFO - 2022-03-28 02:26:02 --> Model "Users_model" initialized
INFO - 2022-03-28 02:26:02 --> Model "Hospital_model" initialized
INFO - 2022-03-28 02:26:02 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-28 02:26:02 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-28 02:26:02 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-28 02:26:02 --> Final output sent to browser
DEBUG - 2022-03-28 02:26:02 --> Total execution time: 0.0387
ERROR - 2022-03-28 02:26:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 02:26:09 --> Config Class Initialized
INFO - 2022-03-28 02:26:09 --> Hooks Class Initialized
DEBUG - 2022-03-28 02:26:09 --> UTF-8 Support Enabled
INFO - 2022-03-28 02:26:09 --> Utf8 Class Initialized
INFO - 2022-03-28 02:26:09 --> URI Class Initialized
INFO - 2022-03-28 02:26:09 --> Router Class Initialized
INFO - 2022-03-28 02:26:09 --> Output Class Initialized
INFO - 2022-03-28 02:26:09 --> Security Class Initialized
DEBUG - 2022-03-28 02:26:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 02:26:09 --> Input Class Initialized
INFO - 2022-03-28 02:26:09 --> Language Class Initialized
INFO - 2022-03-28 02:26:09 --> Loader Class Initialized
INFO - 2022-03-28 02:26:09 --> Helper loaded: url_helper
INFO - 2022-03-28 02:26:09 --> Helper loaded: form_helper
INFO - 2022-03-28 02:26:09 --> Helper loaded: common_helper
INFO - 2022-03-28 02:26:09 --> Database Driver Class Initialized
DEBUG - 2022-03-28 02:26:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 02:26:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 02:26:09 --> Controller Class Initialized
INFO - 2022-03-28 02:26:09 --> Form Validation Class Initialized
DEBUG - 2022-03-28 02:26:09 --> Encrypt Class Initialized
INFO - 2022-03-28 02:26:09 --> Model "Patient_model" initialized
INFO - 2022-03-28 02:26:09 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 02:26:09 --> Model "Prefix_master" initialized
INFO - 2022-03-28 02:26:09 --> Model "Users_model" initialized
INFO - 2022-03-28 02:26:09 --> Model "Hospital_model" initialized
INFO - 2022-03-28 02:26:09 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-28 02:26:09 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-28 02:26:09 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-28 02:26:09 --> Final output sent to browser
DEBUG - 2022-03-28 02:26:09 --> Total execution time: 0.0433
ERROR - 2022-03-28 02:26:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 02:26:17 --> Config Class Initialized
INFO - 2022-03-28 02:26:17 --> Hooks Class Initialized
DEBUG - 2022-03-28 02:26:17 --> UTF-8 Support Enabled
INFO - 2022-03-28 02:26:17 --> Utf8 Class Initialized
INFO - 2022-03-28 02:26:17 --> URI Class Initialized
INFO - 2022-03-28 02:26:17 --> Router Class Initialized
INFO - 2022-03-28 02:26:17 --> Output Class Initialized
INFO - 2022-03-28 02:26:17 --> Security Class Initialized
DEBUG - 2022-03-28 02:26:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 02:26:17 --> Input Class Initialized
INFO - 2022-03-28 02:26:17 --> Language Class Initialized
INFO - 2022-03-28 02:26:17 --> Loader Class Initialized
INFO - 2022-03-28 02:26:17 --> Helper loaded: url_helper
INFO - 2022-03-28 02:26:17 --> Helper loaded: form_helper
INFO - 2022-03-28 02:26:17 --> Helper loaded: common_helper
INFO - 2022-03-28 02:26:17 --> Database Driver Class Initialized
DEBUG - 2022-03-28 02:26:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 02:26:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 02:26:17 --> Controller Class Initialized
INFO - 2022-03-28 02:26:17 --> Form Validation Class Initialized
DEBUG - 2022-03-28 02:26:17 --> Encrypt Class Initialized
INFO - 2022-03-28 02:26:17 --> Model "Patient_model" initialized
INFO - 2022-03-28 02:26:17 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 02:26:17 --> Model "Referredby_model" initialized
INFO - 2022-03-28 02:26:17 --> Model "Prefix_master" initialized
INFO - 2022-03-28 02:26:17 --> Model "Hospital_model" initialized
INFO - 2022-03-28 02:26:17 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-28 02:26:17 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-28 02:26:17 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-28 02:26:17 --> Final output sent to browser
DEBUG - 2022-03-28 02:26:17 --> Total execution time: 0.0267
ERROR - 2022-03-28 02:26:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 02:26:27 --> Config Class Initialized
INFO - 2022-03-28 02:26:27 --> Hooks Class Initialized
DEBUG - 2022-03-28 02:26:27 --> UTF-8 Support Enabled
INFO - 2022-03-28 02:26:27 --> Utf8 Class Initialized
INFO - 2022-03-28 02:26:27 --> URI Class Initialized
INFO - 2022-03-28 02:26:27 --> Router Class Initialized
INFO - 2022-03-28 02:26:27 --> Output Class Initialized
INFO - 2022-03-28 02:26:27 --> Security Class Initialized
DEBUG - 2022-03-28 02:26:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 02:26:27 --> Input Class Initialized
INFO - 2022-03-28 02:26:27 --> Language Class Initialized
INFO - 2022-03-28 02:26:27 --> Loader Class Initialized
INFO - 2022-03-28 02:26:27 --> Helper loaded: url_helper
INFO - 2022-03-28 02:26:27 --> Helper loaded: form_helper
INFO - 2022-03-28 02:26:27 --> Helper loaded: common_helper
INFO - 2022-03-28 02:26:27 --> Database Driver Class Initialized
DEBUG - 2022-03-28 02:26:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 02:26:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 02:26:27 --> Controller Class Initialized
INFO - 2022-03-28 02:26:27 --> Form Validation Class Initialized
DEBUG - 2022-03-28 02:26:27 --> Encrypt Class Initialized
INFO - 2022-03-28 02:26:27 --> Model "Patient_model" initialized
INFO - 2022-03-28 02:26:27 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 02:26:27 --> Model "Referredby_model" initialized
INFO - 2022-03-28 02:26:27 --> Model "Prefix_master" initialized
INFO - 2022-03-28 02:26:27 --> Model "Hospital_model" initialized
ERROR - 2022-03-28 02:26:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 02:26:27 --> Config Class Initialized
INFO - 2022-03-28 02:26:27 --> Hooks Class Initialized
DEBUG - 2022-03-28 02:26:27 --> UTF-8 Support Enabled
INFO - 2022-03-28 02:26:27 --> Utf8 Class Initialized
INFO - 2022-03-28 02:26:27 --> URI Class Initialized
INFO - 2022-03-28 02:26:27 --> Router Class Initialized
INFO - 2022-03-28 02:26:27 --> Output Class Initialized
INFO - 2022-03-28 02:26:27 --> Security Class Initialized
DEBUG - 2022-03-28 02:26:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 02:26:27 --> Input Class Initialized
INFO - 2022-03-28 02:26:27 --> Language Class Initialized
INFO - 2022-03-28 02:26:27 --> Loader Class Initialized
INFO - 2022-03-28 02:26:27 --> Helper loaded: url_helper
INFO - 2022-03-28 02:26:27 --> Helper loaded: form_helper
INFO - 2022-03-28 02:26:27 --> Helper loaded: common_helper
INFO - 2022-03-28 02:26:27 --> Database Driver Class Initialized
DEBUG - 2022-03-28 02:26:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 02:26:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 02:26:27 --> Controller Class Initialized
INFO - 2022-03-28 02:26:27 --> Form Validation Class Initialized
DEBUG - 2022-03-28 02:26:27 --> Encrypt Class Initialized
INFO - 2022-03-28 02:26:27 --> Model "Patient_model" initialized
INFO - 2022-03-28 02:26:27 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 02:26:27 --> Model "Referredby_model" initialized
INFO - 2022-03-28 02:26:27 --> Model "Prefix_master" initialized
INFO - 2022-03-28 02:26:27 --> Model "Hospital_model" initialized
INFO - 2022-03-28 02:26:27 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-28 02:26:27 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-28 02:26:27 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-28 02:26:27 --> Final output sent to browser
DEBUG - 2022-03-28 02:26:27 --> Total execution time: 0.0233
ERROR - 2022-03-28 02:26:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 02:26:28 --> Config Class Initialized
INFO - 2022-03-28 02:26:28 --> Hooks Class Initialized
DEBUG - 2022-03-28 02:26:28 --> UTF-8 Support Enabled
INFO - 2022-03-28 02:26:28 --> Utf8 Class Initialized
INFO - 2022-03-28 02:26:28 --> URI Class Initialized
INFO - 2022-03-28 02:26:28 --> Router Class Initialized
INFO - 2022-03-28 02:26:28 --> Output Class Initialized
INFO - 2022-03-28 02:26:28 --> Security Class Initialized
DEBUG - 2022-03-28 02:26:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 02:26:28 --> Input Class Initialized
INFO - 2022-03-28 02:26:28 --> Language Class Initialized
INFO - 2022-03-28 02:26:28 --> Loader Class Initialized
INFO - 2022-03-28 02:26:28 --> Helper loaded: url_helper
INFO - 2022-03-28 02:26:28 --> Helper loaded: form_helper
INFO - 2022-03-28 02:26:28 --> Helper loaded: common_helper
INFO - 2022-03-28 02:26:28 --> Database Driver Class Initialized
DEBUG - 2022-03-28 02:26:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 02:26:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 02:26:28 --> Controller Class Initialized
INFO - 2022-03-28 02:26:28 --> Form Validation Class Initialized
DEBUG - 2022-03-28 02:26:28 --> Encrypt Class Initialized
INFO - 2022-03-28 02:26:28 --> Model "Patient_model" initialized
INFO - 2022-03-28 02:26:28 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 02:26:28 --> Model "Prefix_master" initialized
INFO - 2022-03-28 02:26:28 --> Model "Users_model" initialized
INFO - 2022-03-28 02:26:28 --> Model "Hospital_model" initialized
INFO - 2022-03-28 02:26:28 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-28 02:26:28 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-28 02:26:28 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-28 02:26:28 --> Final output sent to browser
DEBUG - 2022-03-28 02:26:28 --> Total execution time: 0.0424
ERROR - 2022-03-28 02:26:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 02:26:39 --> Config Class Initialized
INFO - 2022-03-28 02:26:39 --> Hooks Class Initialized
DEBUG - 2022-03-28 02:26:39 --> UTF-8 Support Enabled
INFO - 2022-03-28 02:26:39 --> Utf8 Class Initialized
INFO - 2022-03-28 02:26:39 --> URI Class Initialized
INFO - 2022-03-28 02:26:39 --> Router Class Initialized
INFO - 2022-03-28 02:26:39 --> Output Class Initialized
INFO - 2022-03-28 02:26:39 --> Security Class Initialized
DEBUG - 2022-03-28 02:26:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 02:26:39 --> Input Class Initialized
INFO - 2022-03-28 02:26:39 --> Language Class Initialized
INFO - 2022-03-28 02:26:39 --> Loader Class Initialized
INFO - 2022-03-28 02:26:39 --> Helper loaded: url_helper
INFO - 2022-03-28 02:26:39 --> Helper loaded: form_helper
INFO - 2022-03-28 02:26:39 --> Helper loaded: common_helper
INFO - 2022-03-28 02:26:39 --> Database Driver Class Initialized
DEBUG - 2022-03-28 02:26:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 02:26:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 02:26:39 --> Controller Class Initialized
INFO - 2022-03-28 02:26:39 --> Form Validation Class Initialized
DEBUG - 2022-03-28 02:26:39 --> Encrypt Class Initialized
INFO - 2022-03-28 02:26:39 --> Model "Patient_model" initialized
INFO - 2022-03-28 02:26:39 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 02:26:39 --> Model "Prefix_master" initialized
INFO - 2022-03-28 02:26:39 --> Model "Users_model" initialized
INFO - 2022-03-28 02:26:39 --> Model "Hospital_model" initialized
ERROR - 2022-03-28 02:26:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 02:26:39 --> Config Class Initialized
INFO - 2022-03-28 02:26:39 --> Hooks Class Initialized
DEBUG - 2022-03-28 02:26:39 --> UTF-8 Support Enabled
INFO - 2022-03-28 02:26:39 --> Utf8 Class Initialized
INFO - 2022-03-28 02:26:39 --> URI Class Initialized
INFO - 2022-03-28 02:26:39 --> Router Class Initialized
INFO - 2022-03-28 02:26:39 --> Output Class Initialized
INFO - 2022-03-28 02:26:39 --> Security Class Initialized
DEBUG - 2022-03-28 02:26:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 02:26:39 --> Input Class Initialized
INFO - 2022-03-28 02:26:39 --> Language Class Initialized
INFO - 2022-03-28 02:26:39 --> Loader Class Initialized
INFO - 2022-03-28 02:26:39 --> Helper loaded: url_helper
INFO - 2022-03-28 02:26:39 --> Helper loaded: form_helper
INFO - 2022-03-28 02:26:39 --> Helper loaded: common_helper
INFO - 2022-03-28 02:26:39 --> Database Driver Class Initialized
DEBUG - 2022-03-28 02:26:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 02:26:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 02:26:39 --> Controller Class Initialized
INFO - 2022-03-28 02:26:39 --> Form Validation Class Initialized
DEBUG - 2022-03-28 02:26:39 --> Encrypt Class Initialized
INFO - 2022-03-28 02:26:39 --> Model "Patient_model" initialized
INFO - 2022-03-28 02:26:39 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 02:26:39 --> Model "Prefix_master" initialized
INFO - 2022-03-28 02:26:39 --> Model "Users_model" initialized
INFO - 2022-03-28 02:26:39 --> Model "Hospital_model" initialized
INFO - 2022-03-28 02:26:39 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-28 02:26:39 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-28 02:26:39 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-28 02:26:39 --> Final output sent to browser
DEBUG - 2022-03-28 02:26:39 --> Total execution time: 0.0364
ERROR - 2022-03-28 02:26:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 02:26:59 --> Config Class Initialized
INFO - 2022-03-28 02:26:59 --> Hooks Class Initialized
DEBUG - 2022-03-28 02:26:59 --> UTF-8 Support Enabled
INFO - 2022-03-28 02:26:59 --> Utf8 Class Initialized
INFO - 2022-03-28 02:26:59 --> URI Class Initialized
INFO - 2022-03-28 02:26:59 --> Router Class Initialized
INFO - 2022-03-28 02:26:59 --> Output Class Initialized
INFO - 2022-03-28 02:26:59 --> Security Class Initialized
DEBUG - 2022-03-28 02:26:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 02:26:59 --> Input Class Initialized
INFO - 2022-03-28 02:26:59 --> Language Class Initialized
INFO - 2022-03-28 02:26:59 --> Loader Class Initialized
INFO - 2022-03-28 02:26:59 --> Helper loaded: url_helper
INFO - 2022-03-28 02:26:59 --> Helper loaded: form_helper
INFO - 2022-03-28 02:26:59 --> Helper loaded: common_helper
INFO - 2022-03-28 02:26:59 --> Database Driver Class Initialized
DEBUG - 2022-03-28 02:26:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 02:26:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 02:26:59 --> Controller Class Initialized
INFO - 2022-03-28 02:26:59 --> Form Validation Class Initialized
DEBUG - 2022-03-28 02:26:59 --> Encrypt Class Initialized
INFO - 2022-03-28 02:26:59 --> Model "Patient_model" initialized
INFO - 2022-03-28 02:26:59 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 02:26:59 --> Model "Referredby_model" initialized
INFO - 2022-03-28 02:26:59 --> Model "Prefix_master" initialized
INFO - 2022-03-28 02:26:59 --> Model "Hospital_model" initialized
INFO - 2022-03-28 02:26:59 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-28 02:26:59 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-28 02:26:59 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-28 02:26:59 --> Final output sent to browser
DEBUG - 2022-03-28 02:26:59 --> Total execution time: 0.1567
ERROR - 2022-03-28 02:27:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 02:27:07 --> Config Class Initialized
INFO - 2022-03-28 02:27:07 --> Hooks Class Initialized
DEBUG - 2022-03-28 02:27:07 --> UTF-8 Support Enabled
INFO - 2022-03-28 02:27:07 --> Utf8 Class Initialized
INFO - 2022-03-28 02:27:07 --> URI Class Initialized
INFO - 2022-03-28 02:27:07 --> Router Class Initialized
INFO - 2022-03-28 02:27:07 --> Output Class Initialized
INFO - 2022-03-28 02:27:07 --> Security Class Initialized
DEBUG - 2022-03-28 02:27:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 02:27:07 --> Input Class Initialized
INFO - 2022-03-28 02:27:07 --> Language Class Initialized
INFO - 2022-03-28 02:27:07 --> Loader Class Initialized
INFO - 2022-03-28 02:27:07 --> Helper loaded: url_helper
INFO - 2022-03-28 02:27:07 --> Helper loaded: form_helper
INFO - 2022-03-28 02:27:07 --> Helper loaded: common_helper
INFO - 2022-03-28 02:27:07 --> Database Driver Class Initialized
DEBUG - 2022-03-28 02:27:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 02:27:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 02:27:07 --> Controller Class Initialized
INFO - 2022-03-28 02:27:07 --> Form Validation Class Initialized
DEBUG - 2022-03-28 02:27:07 --> Encrypt Class Initialized
INFO - 2022-03-28 02:27:07 --> Model "Patient_model" initialized
INFO - 2022-03-28 02:27:07 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 02:27:07 --> Model "Prefix_master" initialized
INFO - 2022-03-28 02:27:07 --> Model "Users_model" initialized
INFO - 2022-03-28 02:27:07 --> Model "Hospital_model" initialized
INFO - 2022-03-28 02:27:07 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-28 02:27:08 --> Final output sent to browser
DEBUG - 2022-03-28 02:27:08 --> Total execution time: 0.6495
ERROR - 2022-03-28 02:30:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 02:30:00 --> Config Class Initialized
INFO - 2022-03-28 02:30:00 --> Hooks Class Initialized
DEBUG - 2022-03-28 02:30:00 --> UTF-8 Support Enabled
INFO - 2022-03-28 02:30:00 --> Utf8 Class Initialized
INFO - 2022-03-28 02:30:00 --> URI Class Initialized
INFO - 2022-03-28 02:30:00 --> Router Class Initialized
INFO - 2022-03-28 02:30:00 --> Output Class Initialized
INFO - 2022-03-28 02:30:00 --> Security Class Initialized
DEBUG - 2022-03-28 02:30:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 02:30:00 --> Input Class Initialized
INFO - 2022-03-28 02:30:00 --> Language Class Initialized
INFO - 2022-03-28 02:30:00 --> Loader Class Initialized
INFO - 2022-03-28 02:30:00 --> Helper loaded: url_helper
INFO - 2022-03-28 02:30:00 --> Helper loaded: form_helper
INFO - 2022-03-28 02:30:00 --> Helper loaded: common_helper
INFO - 2022-03-28 02:30:00 --> Database Driver Class Initialized
DEBUG - 2022-03-28 02:30:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 02:30:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 02:30:00 --> Controller Class Initialized
INFO - 2022-03-28 02:30:00 --> Form Validation Class Initialized
DEBUG - 2022-03-28 02:30:00 --> Encrypt Class Initialized
INFO - 2022-03-28 02:30:00 --> Model "Patient_model" initialized
INFO - 2022-03-28 02:30:00 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 02:30:00 --> Model "Referredby_model" initialized
INFO - 2022-03-28 02:30:00 --> Model "Prefix_master" initialized
INFO - 2022-03-28 02:30:00 --> Model "Hospital_model" initialized
INFO - 2022-03-28 02:30:00 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-28 02:30:00 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-28 02:30:00 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-28 02:30:01 --> Final output sent to browser
DEBUG - 2022-03-28 02:30:01 --> Total execution time: 0.0950
ERROR - 2022-03-28 02:30:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 02:30:34 --> Config Class Initialized
INFO - 2022-03-28 02:30:34 --> Hooks Class Initialized
DEBUG - 2022-03-28 02:30:34 --> UTF-8 Support Enabled
INFO - 2022-03-28 02:30:34 --> Utf8 Class Initialized
INFO - 2022-03-28 02:30:34 --> URI Class Initialized
INFO - 2022-03-28 02:30:34 --> Router Class Initialized
INFO - 2022-03-28 02:30:34 --> Output Class Initialized
INFO - 2022-03-28 02:30:34 --> Security Class Initialized
DEBUG - 2022-03-28 02:30:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 02:30:34 --> Input Class Initialized
INFO - 2022-03-28 02:30:34 --> Language Class Initialized
ERROR - 2022-03-28 02:30:34 --> 404 Page Not Found: Karoclient/css
ERROR - 2022-03-28 02:31:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 02:31:02 --> Config Class Initialized
INFO - 2022-03-28 02:31:02 --> Hooks Class Initialized
DEBUG - 2022-03-28 02:31:02 --> UTF-8 Support Enabled
INFO - 2022-03-28 02:31:02 --> Utf8 Class Initialized
INFO - 2022-03-28 02:31:02 --> URI Class Initialized
INFO - 2022-03-28 02:31:02 --> Router Class Initialized
INFO - 2022-03-28 02:31:02 --> Output Class Initialized
INFO - 2022-03-28 02:31:02 --> Security Class Initialized
DEBUG - 2022-03-28 02:31:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 02:31:02 --> Input Class Initialized
INFO - 2022-03-28 02:31:02 --> Language Class Initialized
INFO - 2022-03-28 02:31:02 --> Loader Class Initialized
INFO - 2022-03-28 02:31:02 --> Helper loaded: url_helper
INFO - 2022-03-28 02:31:02 --> Helper loaded: form_helper
INFO - 2022-03-28 02:31:02 --> Helper loaded: common_helper
INFO - 2022-03-28 02:31:02 --> Database Driver Class Initialized
DEBUG - 2022-03-28 02:31:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 02:31:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 02:31:02 --> Controller Class Initialized
INFO - 2022-03-28 02:31:02 --> Form Validation Class Initialized
DEBUG - 2022-03-28 02:31:02 --> Encrypt Class Initialized
INFO - 2022-03-28 02:31:02 --> Model "Patient_model" initialized
INFO - 2022-03-28 02:31:02 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 02:31:02 --> Model "Referredby_model" initialized
INFO - 2022-03-28 02:31:02 --> Model "Prefix_master" initialized
INFO - 2022-03-28 02:31:02 --> Model "Hospital_model" initialized
ERROR - 2022-03-28 02:31:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 02:31:02 --> Config Class Initialized
INFO - 2022-03-28 02:31:02 --> Hooks Class Initialized
DEBUG - 2022-03-28 02:31:02 --> UTF-8 Support Enabled
INFO - 2022-03-28 02:31:02 --> Utf8 Class Initialized
INFO - 2022-03-28 02:31:02 --> URI Class Initialized
INFO - 2022-03-28 02:31:02 --> Router Class Initialized
INFO - 2022-03-28 02:31:02 --> Output Class Initialized
INFO - 2022-03-28 02:31:02 --> Security Class Initialized
DEBUG - 2022-03-28 02:31:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 02:31:02 --> Input Class Initialized
INFO - 2022-03-28 02:31:02 --> Language Class Initialized
INFO - 2022-03-28 02:31:02 --> Loader Class Initialized
INFO - 2022-03-28 02:31:02 --> Helper loaded: url_helper
INFO - 2022-03-28 02:31:02 --> Helper loaded: form_helper
INFO - 2022-03-28 02:31:02 --> Helper loaded: common_helper
INFO - 2022-03-28 02:31:02 --> Database Driver Class Initialized
DEBUG - 2022-03-28 02:31:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 02:31:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 02:31:02 --> Controller Class Initialized
INFO - 2022-03-28 02:31:02 --> Form Validation Class Initialized
DEBUG - 2022-03-28 02:31:02 --> Encrypt Class Initialized
INFO - 2022-03-28 02:31:02 --> Model "Patient_model" initialized
INFO - 2022-03-28 02:31:02 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 02:31:02 --> Model "Referredby_model" initialized
INFO - 2022-03-28 02:31:02 --> Model "Prefix_master" initialized
INFO - 2022-03-28 02:31:02 --> Model "Hospital_model" initialized
INFO - 2022-03-28 02:31:02 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-28 02:31:02 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-28 02:31:02 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-28 02:31:02 --> Final output sent to browser
DEBUG - 2022-03-28 02:31:02 --> Total execution time: 0.0419
ERROR - 2022-03-28 02:31:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 02:31:03 --> Config Class Initialized
INFO - 2022-03-28 02:31:03 --> Hooks Class Initialized
DEBUG - 2022-03-28 02:31:03 --> UTF-8 Support Enabled
INFO - 2022-03-28 02:31:03 --> Utf8 Class Initialized
INFO - 2022-03-28 02:31:03 --> URI Class Initialized
INFO - 2022-03-28 02:31:03 --> Router Class Initialized
INFO - 2022-03-28 02:31:03 --> Output Class Initialized
INFO - 2022-03-28 02:31:03 --> Security Class Initialized
DEBUG - 2022-03-28 02:31:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 02:31:03 --> Input Class Initialized
INFO - 2022-03-28 02:31:03 --> Language Class Initialized
INFO - 2022-03-28 02:31:03 --> Loader Class Initialized
INFO - 2022-03-28 02:31:03 --> Helper loaded: url_helper
INFO - 2022-03-28 02:31:03 --> Helper loaded: form_helper
INFO - 2022-03-28 02:31:03 --> Helper loaded: common_helper
INFO - 2022-03-28 02:31:03 --> Database Driver Class Initialized
DEBUG - 2022-03-28 02:31:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 02:31:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 02:31:03 --> Controller Class Initialized
INFO - 2022-03-28 02:31:03 --> Form Validation Class Initialized
DEBUG - 2022-03-28 02:31:03 --> Encrypt Class Initialized
INFO - 2022-03-28 02:31:03 --> Model "Patient_model" initialized
INFO - 2022-03-28 02:31:03 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 02:31:03 --> Model "Prefix_master" initialized
INFO - 2022-03-28 02:31:03 --> Model "Users_model" initialized
INFO - 2022-03-28 02:31:03 --> Model "Hospital_model" initialized
INFO - 2022-03-28 02:31:03 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-28 02:31:03 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-28 02:31:03 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-28 02:31:03 --> Final output sent to browser
DEBUG - 2022-03-28 02:31:03 --> Total execution time: 0.0455
ERROR - 2022-03-28 02:31:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 02:31:11 --> Config Class Initialized
INFO - 2022-03-28 02:31:11 --> Hooks Class Initialized
DEBUG - 2022-03-28 02:31:11 --> UTF-8 Support Enabled
INFO - 2022-03-28 02:31:11 --> Utf8 Class Initialized
INFO - 2022-03-28 02:31:11 --> URI Class Initialized
INFO - 2022-03-28 02:31:11 --> Router Class Initialized
INFO - 2022-03-28 02:31:11 --> Output Class Initialized
INFO - 2022-03-28 02:31:11 --> Security Class Initialized
DEBUG - 2022-03-28 02:31:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 02:31:11 --> Input Class Initialized
INFO - 2022-03-28 02:31:11 --> Language Class Initialized
INFO - 2022-03-28 02:31:11 --> Loader Class Initialized
INFO - 2022-03-28 02:31:11 --> Helper loaded: url_helper
INFO - 2022-03-28 02:31:11 --> Helper loaded: form_helper
INFO - 2022-03-28 02:31:11 --> Helper loaded: common_helper
INFO - 2022-03-28 02:31:11 --> Database Driver Class Initialized
DEBUG - 2022-03-28 02:31:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 02:31:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 02:31:11 --> Controller Class Initialized
INFO - 2022-03-28 02:31:11 --> Form Validation Class Initialized
DEBUG - 2022-03-28 02:31:11 --> Encrypt Class Initialized
INFO - 2022-03-28 02:31:11 --> Model "Patient_model" initialized
INFO - 2022-03-28 02:31:11 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 02:31:11 --> Model "Referredby_model" initialized
INFO - 2022-03-28 02:31:11 --> Model "Prefix_master" initialized
INFO - 2022-03-28 02:31:11 --> Model "Hospital_model" initialized
INFO - 2022-03-28 02:31:11 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-28 02:31:11 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-28 02:31:11 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-28 02:31:11 --> Final output sent to browser
DEBUG - 2022-03-28 02:31:11 --> Total execution time: 0.0774
ERROR - 2022-03-28 02:36:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 02:36:45 --> Config Class Initialized
INFO - 2022-03-28 02:36:45 --> Hooks Class Initialized
DEBUG - 2022-03-28 02:36:45 --> UTF-8 Support Enabled
INFO - 2022-03-28 02:36:45 --> Utf8 Class Initialized
INFO - 2022-03-28 02:36:45 --> URI Class Initialized
INFO - 2022-03-28 02:36:45 --> Router Class Initialized
INFO - 2022-03-28 02:36:45 --> Output Class Initialized
INFO - 2022-03-28 02:36:45 --> Security Class Initialized
DEBUG - 2022-03-28 02:36:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 02:36:45 --> Input Class Initialized
INFO - 2022-03-28 02:36:45 --> Language Class Initialized
INFO - 2022-03-28 02:36:45 --> Loader Class Initialized
INFO - 2022-03-28 02:36:45 --> Helper loaded: url_helper
INFO - 2022-03-28 02:36:45 --> Helper loaded: form_helper
INFO - 2022-03-28 02:36:45 --> Helper loaded: common_helper
INFO - 2022-03-28 02:36:45 --> Database Driver Class Initialized
DEBUG - 2022-03-28 02:36:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 02:36:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 02:36:45 --> Controller Class Initialized
INFO - 2022-03-28 02:36:45 --> Form Validation Class Initialized
DEBUG - 2022-03-28 02:36:45 --> Encrypt Class Initialized
INFO - 2022-03-28 02:36:45 --> Model "Patient_model" initialized
INFO - 2022-03-28 02:36:45 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 02:36:45 --> Model "Referredby_model" initialized
INFO - 2022-03-28 02:36:45 --> Model "Prefix_master" initialized
INFO - 2022-03-28 02:36:45 --> Model "Hospital_model" initialized
INFO - 2022-03-28 02:36:45 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-28 02:36:45 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-28 02:36:45 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-28 02:36:45 --> Final output sent to browser
DEBUG - 2022-03-28 02:36:45 --> Total execution time: 0.1206
ERROR - 2022-03-28 03:26:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 03:26:35 --> Config Class Initialized
INFO - 2022-03-28 03:26:35 --> Hooks Class Initialized
DEBUG - 2022-03-28 03:26:35 --> UTF-8 Support Enabled
INFO - 2022-03-28 03:26:35 --> Utf8 Class Initialized
INFO - 2022-03-28 03:26:35 --> URI Class Initialized
INFO - 2022-03-28 03:26:35 --> Router Class Initialized
INFO - 2022-03-28 03:26:35 --> Output Class Initialized
INFO - 2022-03-28 03:26:35 --> Security Class Initialized
DEBUG - 2022-03-28 03:26:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 03:26:35 --> Input Class Initialized
INFO - 2022-03-28 03:26:35 --> Language Class Initialized
INFO - 2022-03-28 03:26:35 --> Loader Class Initialized
INFO - 2022-03-28 03:26:35 --> Helper loaded: url_helper
INFO - 2022-03-28 03:26:35 --> Helper loaded: form_helper
INFO - 2022-03-28 03:26:35 --> Helper loaded: common_helper
INFO - 2022-03-28 03:26:35 --> Database Driver Class Initialized
DEBUG - 2022-03-28 03:26:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 03:26:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 03:26:35 --> Controller Class Initialized
INFO - 2022-03-28 03:26:35 --> Form Validation Class Initialized
DEBUG - 2022-03-28 03:26:35 --> Encrypt Class Initialized
DEBUG - 2022-03-28 03:26:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-28 03:26:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-28 03:26:35 --> Email Class Initialized
INFO - 2022-03-28 03:26:35 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-28 03:26:35 --> Calendar Class Initialized
INFO - 2022-03-28 03:26:35 --> Model "Login_model" initialized
ERROR - 2022-03-28 03:26:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 03:26:35 --> Config Class Initialized
INFO - 2022-03-28 03:26:35 --> Hooks Class Initialized
DEBUG - 2022-03-28 03:26:35 --> UTF-8 Support Enabled
INFO - 2022-03-28 03:26:35 --> Utf8 Class Initialized
INFO - 2022-03-28 03:26:35 --> URI Class Initialized
INFO - 2022-03-28 03:26:35 --> Router Class Initialized
INFO - 2022-03-28 03:26:35 --> Output Class Initialized
INFO - 2022-03-28 03:26:35 --> Security Class Initialized
DEBUG - 2022-03-28 03:26:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 03:26:35 --> Input Class Initialized
INFO - 2022-03-28 03:26:35 --> Language Class Initialized
INFO - 2022-03-28 03:26:35 --> Loader Class Initialized
INFO - 2022-03-28 03:26:35 --> Helper loaded: url_helper
INFO - 2022-03-28 03:26:35 --> Helper loaded: form_helper
INFO - 2022-03-28 03:26:35 --> Helper loaded: common_helper
INFO - 2022-03-28 03:26:35 --> Database Driver Class Initialized
DEBUG - 2022-03-28 03:26:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 03:26:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 03:26:35 --> Controller Class Initialized
INFO - 2022-03-28 03:26:35 --> Form Validation Class Initialized
DEBUG - 2022-03-28 03:26:35 --> Encrypt Class Initialized
INFO - 2022-03-28 03:26:35 --> Model "Diseases_model" initialized
INFO - 2022-03-28 03:26:35 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-28 03:26:35 --> File loaded: /home3/karoteam/public_html/application/views/diseases/index.php
INFO - 2022-03-28 03:26:35 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-28 03:26:35 --> Final output sent to browser
DEBUG - 2022-03-28 03:26:35 --> Total execution time: 0.1441
ERROR - 2022-03-28 03:26:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 03:26:46 --> Config Class Initialized
INFO - 2022-03-28 03:26:46 --> Hooks Class Initialized
DEBUG - 2022-03-28 03:26:46 --> UTF-8 Support Enabled
INFO - 2022-03-28 03:26:46 --> Utf8 Class Initialized
INFO - 2022-03-28 03:26:46 --> URI Class Initialized
INFO - 2022-03-28 03:26:46 --> Router Class Initialized
INFO - 2022-03-28 03:26:46 --> Output Class Initialized
INFO - 2022-03-28 03:26:46 --> Security Class Initialized
DEBUG - 2022-03-28 03:26:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 03:26:46 --> Input Class Initialized
INFO - 2022-03-28 03:26:46 --> Language Class Initialized
INFO - 2022-03-28 03:26:46 --> Loader Class Initialized
INFO - 2022-03-28 03:26:46 --> Helper loaded: url_helper
INFO - 2022-03-28 03:26:46 --> Helper loaded: form_helper
INFO - 2022-03-28 03:26:46 --> Helper loaded: common_helper
INFO - 2022-03-28 03:26:46 --> Database Driver Class Initialized
DEBUG - 2022-03-28 03:26:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 03:26:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 03:26:46 --> Controller Class Initialized
INFO - 2022-03-28 03:26:46 --> Form Validation Class Initialized
DEBUG - 2022-03-28 03:26:46 --> Encrypt Class Initialized
INFO - 2022-03-28 03:26:46 --> Model "Patient_model" initialized
INFO - 2022-03-28 03:26:46 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 03:26:46 --> Model "Referredby_model" initialized
INFO - 2022-03-28 03:26:46 --> Model "Prefix_master" initialized
INFO - 2022-03-28 03:26:46 --> Model "Hospital_model" initialized
INFO - 2022-03-28 03:26:46 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-28 03:26:46 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-28 03:26:46 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-28 03:26:46 --> Final output sent to browser
DEBUG - 2022-03-28 03:26:46 --> Total execution time: 0.0599
ERROR - 2022-03-28 03:26:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 03:26:58 --> Config Class Initialized
INFO - 2022-03-28 03:26:58 --> Hooks Class Initialized
DEBUG - 2022-03-28 03:26:58 --> UTF-8 Support Enabled
INFO - 2022-03-28 03:26:58 --> Utf8 Class Initialized
INFO - 2022-03-28 03:26:58 --> URI Class Initialized
INFO - 2022-03-28 03:26:58 --> Router Class Initialized
INFO - 2022-03-28 03:26:58 --> Output Class Initialized
INFO - 2022-03-28 03:26:58 --> Security Class Initialized
DEBUG - 2022-03-28 03:26:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 03:26:58 --> Input Class Initialized
INFO - 2022-03-28 03:26:58 --> Language Class Initialized
INFO - 2022-03-28 03:26:58 --> Loader Class Initialized
INFO - 2022-03-28 03:26:58 --> Helper loaded: url_helper
INFO - 2022-03-28 03:26:58 --> Helper loaded: form_helper
INFO - 2022-03-28 03:26:58 --> Helper loaded: common_helper
INFO - 2022-03-28 03:26:58 --> Database Driver Class Initialized
DEBUG - 2022-03-28 03:26:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 03:26:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 03:26:58 --> Controller Class Initialized
INFO - 2022-03-28 03:26:58 --> Form Validation Class Initialized
DEBUG - 2022-03-28 03:26:58 --> Encrypt Class Initialized
INFO - 2022-03-28 03:26:58 --> Model "Patient_model" initialized
INFO - 2022-03-28 03:26:58 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 03:26:58 --> Model "Prefix_master" initialized
INFO - 2022-03-28 03:26:58 --> Model "Users_model" initialized
INFO - 2022-03-28 03:26:58 --> Model "Hospital_model" initialized
INFO - 2022-03-28 03:26:58 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-28 03:26:59 --> Final output sent to browser
DEBUG - 2022-03-28 03:26:59 --> Total execution time: 1.2303
ERROR - 2022-03-28 03:28:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 03:28:21 --> Config Class Initialized
INFO - 2022-03-28 03:28:21 --> Hooks Class Initialized
DEBUG - 2022-03-28 03:28:21 --> UTF-8 Support Enabled
INFO - 2022-03-28 03:28:21 --> Utf8 Class Initialized
INFO - 2022-03-28 03:28:21 --> URI Class Initialized
INFO - 2022-03-28 03:28:21 --> Router Class Initialized
INFO - 2022-03-28 03:28:21 --> Output Class Initialized
INFO - 2022-03-28 03:28:21 --> Security Class Initialized
DEBUG - 2022-03-28 03:28:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 03:28:21 --> Input Class Initialized
INFO - 2022-03-28 03:28:21 --> Language Class Initialized
INFO - 2022-03-28 03:28:21 --> Loader Class Initialized
INFO - 2022-03-28 03:28:21 --> Helper loaded: url_helper
INFO - 2022-03-28 03:28:21 --> Helper loaded: form_helper
INFO - 2022-03-28 03:28:21 --> Helper loaded: common_helper
INFO - 2022-03-28 03:28:21 --> Database Driver Class Initialized
DEBUG - 2022-03-28 03:28:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 03:28:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 03:28:21 --> Controller Class Initialized
INFO - 2022-03-28 03:28:21 --> Form Validation Class Initialized
DEBUG - 2022-03-28 03:28:21 --> Encrypt Class Initialized
INFO - 2022-03-28 03:28:21 --> Model "Patient_model" initialized
INFO - 2022-03-28 03:28:21 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 03:28:21 --> Model "Referredby_model" initialized
INFO - 2022-03-28 03:28:21 --> Model "Prefix_master" initialized
INFO - 2022-03-28 03:28:21 --> Model "Hospital_model" initialized
INFO - 2022-03-28 03:28:21 --> File loaded: /home3/karoteam/public_html/application/views/header.php
ERROR - 2022-03-28 03:28:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 03:28:22 --> Config Class Initialized
INFO - 2022-03-28 03:28:22 --> Hooks Class Initialized
DEBUG - 2022-03-28 03:28:22 --> UTF-8 Support Enabled
INFO - 2022-03-28 03:28:22 --> Utf8 Class Initialized
INFO - 2022-03-28 03:28:22 --> URI Class Initialized
INFO - 2022-03-28 03:28:22 --> Router Class Initialized
INFO - 2022-03-28 03:28:22 --> Output Class Initialized
INFO - 2022-03-28 03:28:22 --> Security Class Initialized
DEBUG - 2022-03-28 03:28:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 03:28:22 --> Input Class Initialized
INFO - 2022-03-28 03:28:22 --> Language Class Initialized
INFO - 2022-03-28 03:28:22 --> Loader Class Initialized
INFO - 2022-03-28 03:28:22 --> Helper loaded: url_helper
INFO - 2022-03-28 03:28:22 --> Helper loaded: form_helper
INFO - 2022-03-28 03:28:22 --> Helper loaded: common_helper
INFO - 2022-03-28 03:28:22 --> Database Driver Class Initialized
DEBUG - 2022-03-28 03:28:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 03:28:22 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-28 03:28:22 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-28 03:28:22 --> Final output sent to browser
DEBUG - 2022-03-28 03:28:22 --> Total execution time: 0.0600
INFO - 2022-03-28 03:28:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 03:28:22 --> Controller Class Initialized
INFO - 2022-03-28 03:28:22 --> Form Validation Class Initialized
DEBUG - 2022-03-28 03:28:22 --> Encrypt Class Initialized
INFO - 2022-03-28 03:28:22 --> Model "Patient_model" initialized
INFO - 2022-03-28 03:28:22 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 03:28:22 --> Model "Referredby_model" initialized
INFO - 2022-03-28 03:28:22 --> Model "Prefix_master" initialized
INFO - 2022-03-28 03:28:22 --> Model "Hospital_model" initialized
INFO - 2022-03-28 03:28:22 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-28 03:28:22 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-28 03:28:22 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-28 03:28:22 --> Final output sent to browser
DEBUG - 2022-03-28 03:28:22 --> Total execution time: 0.0971
ERROR - 2022-03-28 03:28:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 03:28:46 --> Config Class Initialized
INFO - 2022-03-28 03:28:46 --> Hooks Class Initialized
DEBUG - 2022-03-28 03:28:46 --> UTF-8 Support Enabled
INFO - 2022-03-28 03:28:46 --> Utf8 Class Initialized
INFO - 2022-03-28 03:28:46 --> URI Class Initialized
INFO - 2022-03-28 03:28:46 --> Router Class Initialized
INFO - 2022-03-28 03:28:46 --> Output Class Initialized
INFO - 2022-03-28 03:28:46 --> Security Class Initialized
DEBUG - 2022-03-28 03:28:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 03:28:46 --> Input Class Initialized
INFO - 2022-03-28 03:28:46 --> Language Class Initialized
INFO - 2022-03-28 03:28:46 --> Loader Class Initialized
INFO - 2022-03-28 03:28:46 --> Helper loaded: url_helper
INFO - 2022-03-28 03:28:46 --> Helper loaded: form_helper
INFO - 2022-03-28 03:28:46 --> Helper loaded: common_helper
INFO - 2022-03-28 03:28:46 --> Database Driver Class Initialized
DEBUG - 2022-03-28 03:28:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 03:28:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 03:28:47 --> Controller Class Initialized
INFO - 2022-03-28 03:28:47 --> Form Validation Class Initialized
DEBUG - 2022-03-28 03:28:47 --> Encrypt Class Initialized
INFO - 2022-03-28 03:28:47 --> Model "Patient_model" initialized
INFO - 2022-03-28 03:28:47 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 03:28:47 --> Model "Referredby_model" initialized
INFO - 2022-03-28 03:28:47 --> Model "Prefix_master" initialized
INFO - 2022-03-28 03:28:47 --> Model "Hospital_model" initialized
ERROR - 2022-03-28 03:28:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 03:28:47 --> Config Class Initialized
INFO - 2022-03-28 03:28:47 --> Hooks Class Initialized
DEBUG - 2022-03-28 03:28:47 --> UTF-8 Support Enabled
INFO - 2022-03-28 03:28:47 --> Utf8 Class Initialized
INFO - 2022-03-28 03:28:47 --> URI Class Initialized
INFO - 2022-03-28 03:28:47 --> Router Class Initialized
INFO - 2022-03-28 03:28:47 --> Output Class Initialized
INFO - 2022-03-28 03:28:47 --> Security Class Initialized
DEBUG - 2022-03-28 03:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 03:28:47 --> Input Class Initialized
INFO - 2022-03-28 03:28:47 --> Language Class Initialized
INFO - 2022-03-28 03:28:47 --> Loader Class Initialized
INFO - 2022-03-28 03:28:47 --> Helper loaded: url_helper
INFO - 2022-03-28 03:28:47 --> Helper loaded: form_helper
INFO - 2022-03-28 03:28:47 --> Helper loaded: common_helper
INFO - 2022-03-28 03:28:47 --> Database Driver Class Initialized
DEBUG - 2022-03-28 03:28:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 03:28:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 03:28:48 --> Controller Class Initialized
INFO - 2022-03-28 03:28:48 --> Form Validation Class Initialized
DEBUG - 2022-03-28 03:28:48 --> Encrypt Class Initialized
INFO - 2022-03-28 03:28:48 --> Model "Patient_model" initialized
INFO - 2022-03-28 03:28:48 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 03:28:48 --> Model "Referredby_model" initialized
INFO - 2022-03-28 03:28:48 --> Model "Prefix_master" initialized
INFO - 2022-03-28 03:28:48 --> Model "Hospital_model" initialized
INFO - 2022-03-28 03:28:48 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-28 03:28:48 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-28 03:28:48 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-28 03:28:48 --> Final output sent to browser
DEBUG - 2022-03-28 03:28:48 --> Total execution time: 0.7572
ERROR - 2022-03-28 03:28:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 03:28:48 --> Config Class Initialized
INFO - 2022-03-28 03:28:48 --> Hooks Class Initialized
DEBUG - 2022-03-28 03:28:48 --> UTF-8 Support Enabled
INFO - 2022-03-28 03:28:48 --> Utf8 Class Initialized
INFO - 2022-03-28 03:28:48 --> URI Class Initialized
INFO - 2022-03-28 03:28:48 --> Router Class Initialized
INFO - 2022-03-28 03:28:48 --> Output Class Initialized
INFO - 2022-03-28 03:28:48 --> Security Class Initialized
DEBUG - 2022-03-28 03:28:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 03:28:48 --> Input Class Initialized
INFO - 2022-03-28 03:28:48 --> Language Class Initialized
INFO - 2022-03-28 03:28:48 --> Loader Class Initialized
INFO - 2022-03-28 03:28:48 --> Helper loaded: url_helper
INFO - 2022-03-28 03:28:48 --> Helper loaded: form_helper
INFO - 2022-03-28 03:28:48 --> Helper loaded: common_helper
INFO - 2022-03-28 03:28:48 --> Database Driver Class Initialized
DEBUG - 2022-03-28 03:28:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 03:28:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 03:28:48 --> Controller Class Initialized
INFO - 2022-03-28 03:28:48 --> Form Validation Class Initialized
DEBUG - 2022-03-28 03:28:48 --> Encrypt Class Initialized
INFO - 2022-03-28 03:28:48 --> Model "Patient_model" initialized
INFO - 2022-03-28 03:28:48 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 03:28:48 --> Model "Prefix_master" initialized
INFO - 2022-03-28 03:28:48 --> Model "Users_model" initialized
INFO - 2022-03-28 03:28:48 --> Model "Hospital_model" initialized
INFO - 2022-03-28 03:28:48 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-28 03:28:48 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-28 03:28:48 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-28 03:28:48 --> Final output sent to browser
DEBUG - 2022-03-28 03:28:48 --> Total execution time: 0.0916
ERROR - 2022-03-28 03:29:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 03:29:09 --> Config Class Initialized
INFO - 2022-03-28 03:29:09 --> Hooks Class Initialized
DEBUG - 2022-03-28 03:29:09 --> UTF-8 Support Enabled
INFO - 2022-03-28 03:29:09 --> Utf8 Class Initialized
INFO - 2022-03-28 03:29:09 --> URI Class Initialized
INFO - 2022-03-28 03:29:09 --> Router Class Initialized
INFO - 2022-03-28 03:29:09 --> Output Class Initialized
INFO - 2022-03-28 03:29:09 --> Security Class Initialized
DEBUG - 2022-03-28 03:29:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 03:29:09 --> Input Class Initialized
INFO - 2022-03-28 03:29:09 --> Language Class Initialized
INFO - 2022-03-28 03:29:09 --> Loader Class Initialized
INFO - 2022-03-28 03:29:09 --> Helper loaded: url_helper
INFO - 2022-03-28 03:29:09 --> Helper loaded: form_helper
INFO - 2022-03-28 03:29:09 --> Helper loaded: common_helper
INFO - 2022-03-28 03:29:09 --> Database Driver Class Initialized
DEBUG - 2022-03-28 03:29:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 03:29:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 03:29:09 --> Controller Class Initialized
INFO - 2022-03-28 03:29:09 --> Form Validation Class Initialized
DEBUG - 2022-03-28 03:29:09 --> Encrypt Class Initialized
INFO - 2022-03-28 03:29:09 --> Model "Patient_model" initialized
INFO - 2022-03-28 03:29:09 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 03:29:09 --> Model "Prefix_master" initialized
INFO - 2022-03-28 03:29:09 --> Model "Users_model" initialized
INFO - 2022-03-28 03:29:09 --> Model "Hospital_model" initialized
ERROR - 2022-03-28 03:29:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 03:29:10 --> Config Class Initialized
INFO - 2022-03-28 03:29:10 --> Hooks Class Initialized
DEBUG - 2022-03-28 03:29:10 --> UTF-8 Support Enabled
INFO - 2022-03-28 03:29:10 --> Utf8 Class Initialized
INFO - 2022-03-28 03:29:10 --> URI Class Initialized
INFO - 2022-03-28 03:29:10 --> Router Class Initialized
INFO - 2022-03-28 03:29:10 --> Output Class Initialized
INFO - 2022-03-28 03:29:10 --> Security Class Initialized
DEBUG - 2022-03-28 03:29:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 03:29:10 --> Input Class Initialized
INFO - 2022-03-28 03:29:10 --> Language Class Initialized
INFO - 2022-03-28 03:29:10 --> Loader Class Initialized
INFO - 2022-03-28 03:29:10 --> Helper loaded: url_helper
INFO - 2022-03-28 03:29:10 --> Helper loaded: form_helper
INFO - 2022-03-28 03:29:10 --> Helper loaded: common_helper
INFO - 2022-03-28 03:29:10 --> Database Driver Class Initialized
DEBUG - 2022-03-28 03:29:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 03:29:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 03:29:10 --> Controller Class Initialized
INFO - 2022-03-28 03:29:10 --> Form Validation Class Initialized
DEBUG - 2022-03-28 03:29:10 --> Encrypt Class Initialized
INFO - 2022-03-28 03:29:10 --> Model "Patient_model" initialized
INFO - 2022-03-28 03:29:10 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 03:29:10 --> Model "Prefix_master" initialized
INFO - 2022-03-28 03:29:10 --> Model "Users_model" initialized
INFO - 2022-03-28 03:29:10 --> Model "Hospital_model" initialized
INFO - 2022-03-28 03:29:10 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-28 03:29:10 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-28 03:29:10 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-28 03:29:10 --> Final output sent to browser
DEBUG - 2022-03-28 03:29:10 --> Total execution time: 0.0401
ERROR - 2022-03-28 03:29:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 03:29:31 --> Config Class Initialized
INFO - 2022-03-28 03:29:31 --> Hooks Class Initialized
DEBUG - 2022-03-28 03:29:31 --> UTF-8 Support Enabled
INFO - 2022-03-28 03:29:31 --> Utf8 Class Initialized
INFO - 2022-03-28 03:29:31 --> URI Class Initialized
INFO - 2022-03-28 03:29:31 --> Router Class Initialized
INFO - 2022-03-28 03:29:31 --> Output Class Initialized
INFO - 2022-03-28 03:29:31 --> Security Class Initialized
DEBUG - 2022-03-28 03:29:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 03:29:31 --> Input Class Initialized
INFO - 2022-03-28 03:29:31 --> Language Class Initialized
INFO - 2022-03-28 03:29:31 --> Loader Class Initialized
INFO - 2022-03-28 03:29:31 --> Helper loaded: url_helper
INFO - 2022-03-28 03:29:31 --> Helper loaded: form_helper
INFO - 2022-03-28 03:29:31 --> Helper loaded: common_helper
INFO - 2022-03-28 03:29:31 --> Database Driver Class Initialized
DEBUG - 2022-03-28 03:29:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 03:29:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 03:29:31 --> Controller Class Initialized
INFO - 2022-03-28 03:29:31 --> Form Validation Class Initialized
DEBUG - 2022-03-28 03:29:31 --> Encrypt Class Initialized
INFO - 2022-03-28 03:29:31 --> Model "Patient_model" initialized
INFO - 2022-03-28 03:29:31 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 03:29:31 --> Model "Prefix_master" initialized
INFO - 2022-03-28 03:29:31 --> Model "Users_model" initialized
INFO - 2022-03-28 03:29:31 --> Model "Hospital_model" initialized
ERROR - 2022-03-28 03:29:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 03:29:31 --> Config Class Initialized
INFO - 2022-03-28 03:29:31 --> Hooks Class Initialized
DEBUG - 2022-03-28 03:29:31 --> UTF-8 Support Enabled
INFO - 2022-03-28 03:29:31 --> Utf8 Class Initialized
INFO - 2022-03-28 03:29:31 --> URI Class Initialized
INFO - 2022-03-28 03:29:31 --> Router Class Initialized
INFO - 2022-03-28 03:29:31 --> Output Class Initialized
INFO - 2022-03-28 03:29:31 --> Security Class Initialized
DEBUG - 2022-03-28 03:29:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 03:29:31 --> Input Class Initialized
INFO - 2022-03-28 03:29:31 --> Language Class Initialized
INFO - 2022-03-28 03:29:31 --> Loader Class Initialized
INFO - 2022-03-28 03:29:31 --> Helper loaded: url_helper
INFO - 2022-03-28 03:29:31 --> Helper loaded: form_helper
INFO - 2022-03-28 03:29:31 --> Helper loaded: common_helper
INFO - 2022-03-28 03:29:31 --> Database Driver Class Initialized
DEBUG - 2022-03-28 03:29:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 03:29:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 03:29:31 --> Controller Class Initialized
INFO - 2022-03-28 03:29:31 --> Form Validation Class Initialized
DEBUG - 2022-03-28 03:29:31 --> Encrypt Class Initialized
INFO - 2022-03-28 03:29:31 --> Model "Patient_model" initialized
INFO - 2022-03-28 03:29:31 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 03:29:31 --> Model "Prefix_master" initialized
INFO - 2022-03-28 03:29:31 --> Model "Users_model" initialized
INFO - 2022-03-28 03:29:31 --> Model "Hospital_model" initialized
INFO - 2022-03-28 03:29:31 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-28 03:29:31 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-28 03:29:31 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-28 03:29:31 --> Final output sent to browser
DEBUG - 2022-03-28 03:29:31 --> Total execution time: 0.0573
ERROR - 2022-03-28 03:42:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 03:42:47 --> Config Class Initialized
INFO - 2022-03-28 03:42:47 --> Hooks Class Initialized
DEBUG - 2022-03-28 03:42:47 --> UTF-8 Support Enabled
INFO - 2022-03-28 03:42:47 --> Utf8 Class Initialized
INFO - 2022-03-28 03:42:47 --> URI Class Initialized
INFO - 2022-03-28 03:42:47 --> Router Class Initialized
INFO - 2022-03-28 03:42:47 --> Output Class Initialized
INFO - 2022-03-28 03:42:47 --> Security Class Initialized
DEBUG - 2022-03-28 03:42:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 03:42:47 --> Input Class Initialized
INFO - 2022-03-28 03:42:47 --> Language Class Initialized
INFO - 2022-03-28 03:42:47 --> Loader Class Initialized
INFO - 2022-03-28 03:42:47 --> Helper loaded: url_helper
INFO - 2022-03-28 03:42:47 --> Helper loaded: form_helper
INFO - 2022-03-28 03:42:47 --> Helper loaded: common_helper
INFO - 2022-03-28 03:42:47 --> Database Driver Class Initialized
DEBUG - 2022-03-28 03:42:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 03:42:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 03:42:47 --> Controller Class Initialized
INFO - 2022-03-28 03:42:47 --> Form Validation Class Initialized
DEBUG - 2022-03-28 03:42:47 --> Encrypt Class Initialized
INFO - 2022-03-28 03:42:47 --> Model "Patient_model" initialized
INFO - 2022-03-28 03:42:47 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 03:42:47 --> Model "Prefix_master" initialized
INFO - 2022-03-28 03:42:47 --> Model "Users_model" initialized
INFO - 2022-03-28 03:42:47 --> Model "Hospital_model" initialized
ERROR - 2022-03-28 03:42:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 03:42:47 --> Config Class Initialized
INFO - 2022-03-28 03:42:47 --> Hooks Class Initialized
DEBUG - 2022-03-28 03:42:47 --> UTF-8 Support Enabled
INFO - 2022-03-28 03:42:47 --> Utf8 Class Initialized
INFO - 2022-03-28 03:42:47 --> URI Class Initialized
INFO - 2022-03-28 03:42:47 --> Router Class Initialized
INFO - 2022-03-28 03:42:47 --> Output Class Initialized
INFO - 2022-03-28 03:42:47 --> Security Class Initialized
DEBUG - 2022-03-28 03:42:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 03:42:47 --> Input Class Initialized
INFO - 2022-03-28 03:42:47 --> Language Class Initialized
INFO - 2022-03-28 03:42:47 --> Loader Class Initialized
INFO - 2022-03-28 03:42:47 --> Helper loaded: url_helper
INFO - 2022-03-28 03:42:47 --> Helper loaded: form_helper
INFO - 2022-03-28 03:42:47 --> Helper loaded: common_helper
INFO - 2022-03-28 03:42:47 --> Database Driver Class Initialized
DEBUG - 2022-03-28 03:42:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 03:42:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 03:42:47 --> Controller Class Initialized
INFO - 2022-03-28 03:42:47 --> Form Validation Class Initialized
DEBUG - 2022-03-28 03:42:47 --> Encrypt Class Initialized
INFO - 2022-03-28 03:42:47 --> Model "Patient_model" initialized
INFO - 2022-03-28 03:42:47 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 03:42:47 --> Model "Prefix_master" initialized
INFO - 2022-03-28 03:42:47 --> Model "Users_model" initialized
INFO - 2022-03-28 03:42:47 --> Model "Hospital_model" initialized
INFO - 2022-03-28 03:42:47 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-28 03:42:47 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-28 03:42:47 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-28 03:42:47 --> Final output sent to browser
DEBUG - 2022-03-28 03:42:47 --> Total execution time: 0.0698
ERROR - 2022-03-28 03:45:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 03:45:35 --> Config Class Initialized
INFO - 2022-03-28 03:45:35 --> Hooks Class Initialized
DEBUG - 2022-03-28 03:45:35 --> UTF-8 Support Enabled
INFO - 2022-03-28 03:45:35 --> Utf8 Class Initialized
INFO - 2022-03-28 03:45:35 --> URI Class Initialized
INFO - 2022-03-28 03:45:35 --> Router Class Initialized
INFO - 2022-03-28 03:45:35 --> Output Class Initialized
INFO - 2022-03-28 03:45:35 --> Security Class Initialized
DEBUG - 2022-03-28 03:45:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 03:45:35 --> Input Class Initialized
INFO - 2022-03-28 03:45:35 --> Language Class Initialized
INFO - 2022-03-28 03:45:35 --> Loader Class Initialized
INFO - 2022-03-28 03:45:35 --> Helper loaded: url_helper
INFO - 2022-03-28 03:45:35 --> Helper loaded: form_helper
INFO - 2022-03-28 03:45:35 --> Helper loaded: common_helper
INFO - 2022-03-28 03:45:35 --> Database Driver Class Initialized
DEBUG - 2022-03-28 03:45:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 03:45:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 03:45:35 --> Controller Class Initialized
INFO - 2022-03-28 03:45:35 --> Form Validation Class Initialized
DEBUG - 2022-03-28 03:45:35 --> Encrypt Class Initialized
INFO - 2022-03-28 03:45:35 --> Model "Patient_model" initialized
INFO - 2022-03-28 03:45:35 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 03:45:35 --> Model "Prefix_master" initialized
INFO - 2022-03-28 03:45:35 --> Model "Users_model" initialized
INFO - 2022-03-28 03:45:35 --> Model "Hospital_model" initialized
ERROR - 2022-03-28 03:45:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 03:45:36 --> Config Class Initialized
INFO - 2022-03-28 03:45:36 --> Hooks Class Initialized
DEBUG - 2022-03-28 03:45:36 --> UTF-8 Support Enabled
INFO - 2022-03-28 03:45:36 --> Utf8 Class Initialized
INFO - 2022-03-28 03:45:36 --> URI Class Initialized
INFO - 2022-03-28 03:45:36 --> Router Class Initialized
INFO - 2022-03-28 03:45:36 --> Output Class Initialized
INFO - 2022-03-28 03:45:36 --> Security Class Initialized
DEBUG - 2022-03-28 03:45:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 03:45:36 --> Input Class Initialized
INFO - 2022-03-28 03:45:36 --> Language Class Initialized
INFO - 2022-03-28 03:45:36 --> Loader Class Initialized
INFO - 2022-03-28 03:45:36 --> Helper loaded: url_helper
INFO - 2022-03-28 03:45:36 --> Helper loaded: form_helper
INFO - 2022-03-28 03:45:36 --> Helper loaded: common_helper
INFO - 2022-03-28 03:45:36 --> Database Driver Class Initialized
DEBUG - 2022-03-28 03:45:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 03:45:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 03:45:36 --> Controller Class Initialized
INFO - 2022-03-28 03:45:36 --> Form Validation Class Initialized
DEBUG - 2022-03-28 03:45:36 --> Encrypt Class Initialized
INFO - 2022-03-28 03:45:36 --> Model "Patient_model" initialized
INFO - 2022-03-28 03:45:36 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 03:45:36 --> Model "Prefix_master" initialized
INFO - 2022-03-28 03:45:36 --> Model "Users_model" initialized
INFO - 2022-03-28 03:45:36 --> Model "Hospital_model" initialized
INFO - 2022-03-28 03:45:36 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-28 03:45:36 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-28 03:45:36 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-28 03:45:36 --> Final output sent to browser
DEBUG - 2022-03-28 03:45:36 --> Total execution time: 0.0839
ERROR - 2022-03-28 03:45:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 03:45:40 --> Config Class Initialized
INFO - 2022-03-28 03:45:40 --> Hooks Class Initialized
DEBUG - 2022-03-28 03:45:40 --> UTF-8 Support Enabled
INFO - 2022-03-28 03:45:40 --> Utf8 Class Initialized
INFO - 2022-03-28 03:45:40 --> URI Class Initialized
INFO - 2022-03-28 03:45:40 --> Router Class Initialized
INFO - 2022-03-28 03:45:40 --> Output Class Initialized
INFO - 2022-03-28 03:45:40 --> Security Class Initialized
DEBUG - 2022-03-28 03:45:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 03:45:40 --> Input Class Initialized
INFO - 2022-03-28 03:45:40 --> Language Class Initialized
INFO - 2022-03-28 03:45:40 --> Loader Class Initialized
INFO - 2022-03-28 03:45:40 --> Helper loaded: url_helper
INFO - 2022-03-28 03:45:40 --> Helper loaded: form_helper
INFO - 2022-03-28 03:45:40 --> Helper loaded: common_helper
INFO - 2022-03-28 03:45:40 --> Database Driver Class Initialized
DEBUG - 2022-03-28 03:45:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 03:45:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 03:45:40 --> Controller Class Initialized
INFO - 2022-03-28 03:45:40 --> Form Validation Class Initialized
DEBUG - 2022-03-28 03:45:40 --> Encrypt Class Initialized
INFO - 2022-03-28 03:45:40 --> Model "Patient_model" initialized
INFO - 2022-03-28 03:45:40 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 03:45:40 --> Model "Referredby_model" initialized
INFO - 2022-03-28 03:45:40 --> Model "Prefix_master" initialized
INFO - 2022-03-28 03:45:40 --> Model "Hospital_model" initialized
INFO - 2022-03-28 03:45:40 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-28 03:45:40 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-28 03:45:40 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-28 03:45:40 --> Final output sent to browser
DEBUG - 2022-03-28 03:45:40 --> Total execution time: 0.0519
ERROR - 2022-03-28 03:45:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 03:45:49 --> Config Class Initialized
INFO - 2022-03-28 03:45:49 --> Hooks Class Initialized
DEBUG - 2022-03-28 03:45:49 --> UTF-8 Support Enabled
INFO - 2022-03-28 03:45:49 --> Utf8 Class Initialized
INFO - 2022-03-28 03:45:49 --> URI Class Initialized
INFO - 2022-03-28 03:45:49 --> Router Class Initialized
INFO - 2022-03-28 03:45:49 --> Output Class Initialized
INFO - 2022-03-28 03:45:49 --> Security Class Initialized
DEBUG - 2022-03-28 03:45:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 03:45:49 --> Input Class Initialized
INFO - 2022-03-28 03:45:49 --> Language Class Initialized
INFO - 2022-03-28 03:45:49 --> Loader Class Initialized
INFO - 2022-03-28 03:45:49 --> Helper loaded: url_helper
INFO - 2022-03-28 03:45:49 --> Helper loaded: form_helper
INFO - 2022-03-28 03:45:49 --> Helper loaded: common_helper
INFO - 2022-03-28 03:45:49 --> Database Driver Class Initialized
DEBUG - 2022-03-28 03:45:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 03:45:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 03:45:49 --> Controller Class Initialized
INFO - 2022-03-28 03:45:49 --> Form Validation Class Initialized
DEBUG - 2022-03-28 03:45:49 --> Encrypt Class Initialized
INFO - 2022-03-28 03:45:49 --> Model "Patient_model" initialized
INFO - 2022-03-28 03:45:49 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 03:45:49 --> Model "Prefix_master" initialized
INFO - 2022-03-28 03:45:49 --> Model "Users_model" initialized
INFO - 2022-03-28 03:45:49 --> Model "Hospital_model" initialized
INFO - 2022-03-28 03:45:50 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-28 03:45:50 --> Final output sent to browser
DEBUG - 2022-03-28 03:45:50 --> Total execution time: 0.9912
ERROR - 2022-03-28 03:48:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 03:48:52 --> Config Class Initialized
INFO - 2022-03-28 03:48:52 --> Hooks Class Initialized
DEBUG - 2022-03-28 03:48:52 --> UTF-8 Support Enabled
INFO - 2022-03-28 03:48:52 --> Utf8 Class Initialized
INFO - 2022-03-28 03:48:52 --> URI Class Initialized
INFO - 2022-03-28 03:48:52 --> Router Class Initialized
INFO - 2022-03-28 03:48:52 --> Output Class Initialized
INFO - 2022-03-28 03:48:52 --> Security Class Initialized
DEBUG - 2022-03-28 03:48:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 03:48:52 --> Input Class Initialized
INFO - 2022-03-28 03:48:52 --> Language Class Initialized
INFO - 2022-03-28 03:48:52 --> Loader Class Initialized
INFO - 2022-03-28 03:48:52 --> Helper loaded: url_helper
INFO - 2022-03-28 03:48:52 --> Helper loaded: form_helper
INFO - 2022-03-28 03:48:52 --> Helper loaded: common_helper
INFO - 2022-03-28 03:48:52 --> Database Driver Class Initialized
DEBUG - 2022-03-28 03:48:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 03:48:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 03:48:52 --> Controller Class Initialized
INFO - 2022-03-28 03:48:52 --> Form Validation Class Initialized
DEBUG - 2022-03-28 03:48:52 --> Encrypt Class Initialized
INFO - 2022-03-28 03:48:52 --> Model "Patient_model" initialized
INFO - 2022-03-28 03:48:52 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 03:48:52 --> Model "Referredby_model" initialized
INFO - 2022-03-28 03:48:52 --> Model "Prefix_master" initialized
INFO - 2022-03-28 03:48:52 --> Model "Hospital_model" initialized
INFO - 2022-03-28 03:48:52 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-28 03:48:52 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-28 03:48:52 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-28 03:48:52 --> Final output sent to browser
DEBUG - 2022-03-28 03:48:52 --> Total execution time: 0.1048
ERROR - 2022-03-28 03:48:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 03:48:59 --> Config Class Initialized
INFO - 2022-03-28 03:48:59 --> Hooks Class Initialized
DEBUG - 2022-03-28 03:48:59 --> UTF-8 Support Enabled
INFO - 2022-03-28 03:48:59 --> Utf8 Class Initialized
INFO - 2022-03-28 03:48:59 --> URI Class Initialized
INFO - 2022-03-28 03:48:59 --> Router Class Initialized
INFO - 2022-03-28 03:48:59 --> Output Class Initialized
INFO - 2022-03-28 03:48:59 --> Security Class Initialized
DEBUG - 2022-03-28 03:48:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 03:48:59 --> Input Class Initialized
INFO - 2022-03-28 03:48:59 --> Language Class Initialized
INFO - 2022-03-28 03:48:59 --> Loader Class Initialized
INFO - 2022-03-28 03:48:59 --> Helper loaded: url_helper
INFO - 2022-03-28 03:48:59 --> Helper loaded: form_helper
INFO - 2022-03-28 03:48:59 --> Helper loaded: common_helper
INFO - 2022-03-28 03:48:59 --> Database Driver Class Initialized
DEBUG - 2022-03-28 03:48:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 03:48:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 03:48:59 --> Controller Class Initialized
INFO - 2022-03-28 03:48:59 --> Form Validation Class Initialized
DEBUG - 2022-03-28 03:48:59 --> Encrypt Class Initialized
INFO - 2022-03-28 03:48:59 --> Model "Patient_model" initialized
INFO - 2022-03-28 03:48:59 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 03:48:59 --> Model "Referredby_model" initialized
INFO - 2022-03-28 03:48:59 --> Model "Prefix_master" initialized
INFO - 2022-03-28 03:48:59 --> Model "Hospital_model" initialized
ERROR - 2022-03-28 03:49:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 03:49:00 --> Config Class Initialized
INFO - 2022-03-28 03:49:00 --> Hooks Class Initialized
DEBUG - 2022-03-28 03:49:00 --> UTF-8 Support Enabled
INFO - 2022-03-28 03:49:00 --> Utf8 Class Initialized
INFO - 2022-03-28 03:49:00 --> URI Class Initialized
INFO - 2022-03-28 03:49:00 --> Router Class Initialized
INFO - 2022-03-28 03:49:00 --> Output Class Initialized
INFO - 2022-03-28 03:49:00 --> Security Class Initialized
DEBUG - 2022-03-28 03:49:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 03:49:00 --> Input Class Initialized
INFO - 2022-03-28 03:49:00 --> Language Class Initialized
INFO - 2022-03-28 03:49:00 --> Loader Class Initialized
INFO - 2022-03-28 03:49:00 --> Helper loaded: url_helper
INFO - 2022-03-28 03:49:00 --> Helper loaded: form_helper
INFO - 2022-03-28 03:49:00 --> Helper loaded: common_helper
INFO - 2022-03-28 03:49:00 --> Database Driver Class Initialized
DEBUG - 2022-03-28 03:49:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 03:49:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 03:49:00 --> Controller Class Initialized
INFO - 2022-03-28 03:49:00 --> Form Validation Class Initialized
DEBUG - 2022-03-28 03:49:00 --> Encrypt Class Initialized
INFO - 2022-03-28 03:49:00 --> Model "Patient_model" initialized
INFO - 2022-03-28 03:49:00 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 03:49:00 --> Model "Referredby_model" initialized
INFO - 2022-03-28 03:49:00 --> Model "Prefix_master" initialized
INFO - 2022-03-28 03:49:00 --> Model "Hospital_model" initialized
INFO - 2022-03-28 03:49:00 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-28 03:49:00 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-28 03:49:00 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-28 03:49:00 --> Final output sent to browser
DEBUG - 2022-03-28 03:49:00 --> Total execution time: 0.0393
ERROR - 2022-03-28 03:49:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 03:49:01 --> Config Class Initialized
INFO - 2022-03-28 03:49:01 --> Hooks Class Initialized
DEBUG - 2022-03-28 03:49:01 --> UTF-8 Support Enabled
INFO - 2022-03-28 03:49:01 --> Utf8 Class Initialized
INFO - 2022-03-28 03:49:01 --> URI Class Initialized
INFO - 2022-03-28 03:49:01 --> Router Class Initialized
INFO - 2022-03-28 03:49:01 --> Output Class Initialized
INFO - 2022-03-28 03:49:01 --> Security Class Initialized
DEBUG - 2022-03-28 03:49:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 03:49:01 --> Input Class Initialized
INFO - 2022-03-28 03:49:01 --> Language Class Initialized
INFO - 2022-03-28 03:49:01 --> Loader Class Initialized
INFO - 2022-03-28 03:49:01 --> Helper loaded: url_helper
INFO - 2022-03-28 03:49:01 --> Helper loaded: form_helper
INFO - 2022-03-28 03:49:01 --> Helper loaded: common_helper
INFO - 2022-03-28 03:49:01 --> Database Driver Class Initialized
DEBUG - 2022-03-28 03:49:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 03:49:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 03:49:01 --> Controller Class Initialized
INFO - 2022-03-28 03:49:01 --> Form Validation Class Initialized
DEBUG - 2022-03-28 03:49:01 --> Encrypt Class Initialized
INFO - 2022-03-28 03:49:01 --> Model "Patient_model" initialized
INFO - 2022-03-28 03:49:01 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 03:49:01 --> Model "Prefix_master" initialized
INFO - 2022-03-28 03:49:01 --> Model "Users_model" initialized
INFO - 2022-03-28 03:49:01 --> Model "Hospital_model" initialized
INFO - 2022-03-28 03:49:01 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-28 03:49:01 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-28 03:49:01 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-28 03:49:01 --> Final output sent to browser
DEBUG - 2022-03-28 03:49:01 --> Total execution time: 0.0555
ERROR - 2022-03-28 03:51:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 03:51:10 --> Config Class Initialized
INFO - 2022-03-28 03:51:10 --> Hooks Class Initialized
DEBUG - 2022-03-28 03:51:10 --> UTF-8 Support Enabled
INFO - 2022-03-28 03:51:10 --> Utf8 Class Initialized
INFO - 2022-03-28 03:51:10 --> URI Class Initialized
INFO - 2022-03-28 03:51:10 --> Router Class Initialized
INFO - 2022-03-28 03:51:10 --> Output Class Initialized
INFO - 2022-03-28 03:51:10 --> Security Class Initialized
DEBUG - 2022-03-28 03:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 03:51:10 --> Input Class Initialized
INFO - 2022-03-28 03:51:10 --> Language Class Initialized
INFO - 2022-03-28 03:51:10 --> Loader Class Initialized
INFO - 2022-03-28 03:51:10 --> Helper loaded: url_helper
INFO - 2022-03-28 03:51:10 --> Helper loaded: form_helper
INFO - 2022-03-28 03:51:10 --> Helper loaded: common_helper
INFO - 2022-03-28 03:51:10 --> Database Driver Class Initialized
DEBUG - 2022-03-28 03:51:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 03:51:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 03:51:10 --> Controller Class Initialized
INFO - 2022-03-28 03:51:10 --> Form Validation Class Initialized
DEBUG - 2022-03-28 03:51:10 --> Encrypt Class Initialized
INFO - 2022-03-28 03:51:10 --> Model "Patient_model" initialized
INFO - 2022-03-28 03:51:10 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 03:51:10 --> Model "Prefix_master" initialized
INFO - 2022-03-28 03:51:10 --> Model "Users_model" initialized
INFO - 2022-03-28 03:51:10 --> Model "Hospital_model" initialized
ERROR - 2022-03-28 03:51:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 03:51:11 --> Config Class Initialized
INFO - 2022-03-28 03:51:11 --> Hooks Class Initialized
DEBUG - 2022-03-28 03:51:11 --> UTF-8 Support Enabled
INFO - 2022-03-28 03:51:11 --> Utf8 Class Initialized
INFO - 2022-03-28 03:51:11 --> URI Class Initialized
INFO - 2022-03-28 03:51:11 --> Router Class Initialized
INFO - 2022-03-28 03:51:11 --> Output Class Initialized
INFO - 2022-03-28 03:51:11 --> Security Class Initialized
DEBUG - 2022-03-28 03:51:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 03:51:11 --> Input Class Initialized
INFO - 2022-03-28 03:51:11 --> Language Class Initialized
INFO - 2022-03-28 03:51:11 --> Loader Class Initialized
INFO - 2022-03-28 03:51:11 --> Helper loaded: url_helper
INFO - 2022-03-28 03:51:11 --> Helper loaded: form_helper
INFO - 2022-03-28 03:51:11 --> Helper loaded: common_helper
INFO - 2022-03-28 03:51:11 --> Database Driver Class Initialized
DEBUG - 2022-03-28 03:51:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 03:51:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 03:51:11 --> Controller Class Initialized
INFO - 2022-03-28 03:51:11 --> Form Validation Class Initialized
DEBUG - 2022-03-28 03:51:11 --> Encrypt Class Initialized
INFO - 2022-03-28 03:51:11 --> Model "Patient_model" initialized
INFO - 2022-03-28 03:51:11 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 03:51:11 --> Model "Prefix_master" initialized
INFO - 2022-03-28 03:51:11 --> Model "Users_model" initialized
INFO - 2022-03-28 03:51:11 --> Model "Hospital_model" initialized
INFO - 2022-03-28 03:51:11 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-28 03:51:11 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-28 03:51:11 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-28 03:51:11 --> Final output sent to browser
DEBUG - 2022-03-28 03:51:11 --> Total execution time: 0.0669
ERROR - 2022-03-28 03:51:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 03:51:16 --> Config Class Initialized
INFO - 2022-03-28 03:51:16 --> Hooks Class Initialized
DEBUG - 2022-03-28 03:51:16 --> UTF-8 Support Enabled
INFO - 2022-03-28 03:51:16 --> Utf8 Class Initialized
INFO - 2022-03-28 03:51:16 --> URI Class Initialized
INFO - 2022-03-28 03:51:16 --> Router Class Initialized
INFO - 2022-03-28 03:51:16 --> Output Class Initialized
INFO - 2022-03-28 03:51:16 --> Security Class Initialized
DEBUG - 2022-03-28 03:51:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 03:51:16 --> Input Class Initialized
INFO - 2022-03-28 03:51:16 --> Language Class Initialized
INFO - 2022-03-28 03:51:16 --> Loader Class Initialized
INFO - 2022-03-28 03:51:16 --> Helper loaded: url_helper
INFO - 2022-03-28 03:51:16 --> Helper loaded: form_helper
INFO - 2022-03-28 03:51:16 --> Helper loaded: common_helper
INFO - 2022-03-28 03:51:16 --> Database Driver Class Initialized
DEBUG - 2022-03-28 03:51:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 03:51:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 03:51:16 --> Controller Class Initialized
INFO - 2022-03-28 03:51:16 --> Form Validation Class Initialized
DEBUG - 2022-03-28 03:51:16 --> Encrypt Class Initialized
INFO - 2022-03-28 03:51:16 --> Model "Patient_model" initialized
INFO - 2022-03-28 03:51:16 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 03:51:16 --> Model "Referredby_model" initialized
INFO - 2022-03-28 03:51:16 --> Model "Prefix_master" initialized
INFO - 2022-03-28 03:51:16 --> Model "Hospital_model" initialized
INFO - 2022-03-28 03:51:16 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-28 03:51:16 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-28 03:51:16 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-28 03:51:16 --> Final output sent to browser
DEBUG - 2022-03-28 03:51:16 --> Total execution time: 0.0719
ERROR - 2022-03-28 03:53:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 03:53:00 --> Config Class Initialized
INFO - 2022-03-28 03:53:00 --> Hooks Class Initialized
DEBUG - 2022-03-28 03:53:00 --> UTF-8 Support Enabled
INFO - 2022-03-28 03:53:00 --> Utf8 Class Initialized
INFO - 2022-03-28 03:53:00 --> URI Class Initialized
INFO - 2022-03-28 03:53:00 --> Router Class Initialized
INFO - 2022-03-28 03:53:00 --> Output Class Initialized
INFO - 2022-03-28 03:53:00 --> Security Class Initialized
DEBUG - 2022-03-28 03:53:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 03:53:00 --> Input Class Initialized
INFO - 2022-03-28 03:53:00 --> Language Class Initialized
INFO - 2022-03-28 03:53:00 --> Loader Class Initialized
INFO - 2022-03-28 03:53:00 --> Helper loaded: url_helper
INFO - 2022-03-28 03:53:00 --> Helper loaded: form_helper
INFO - 2022-03-28 03:53:00 --> Helper loaded: common_helper
INFO - 2022-03-28 03:53:00 --> Database Driver Class Initialized
DEBUG - 2022-03-28 03:53:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 03:53:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 03:53:00 --> Controller Class Initialized
INFO - 2022-03-28 03:53:00 --> Form Validation Class Initialized
DEBUG - 2022-03-28 03:53:00 --> Encrypt Class Initialized
INFO - 2022-03-28 03:53:00 --> Model "Patient_model" initialized
INFO - 2022-03-28 03:53:00 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 03:53:00 --> Model "Prefix_master" initialized
INFO - 2022-03-28 03:53:00 --> Model "Users_model" initialized
INFO - 2022-03-28 03:53:00 --> Model "Hospital_model" initialized
INFO - 2022-03-28 03:53:00 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-28 03:53:01 --> Final output sent to browser
DEBUG - 2022-03-28 03:53:01 --> Total execution time: 0.9919
ERROR - 2022-03-28 04:18:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 04:18:15 --> Config Class Initialized
INFO - 2022-03-28 04:18:15 --> Hooks Class Initialized
DEBUG - 2022-03-28 04:18:15 --> UTF-8 Support Enabled
INFO - 2022-03-28 04:18:15 --> Utf8 Class Initialized
INFO - 2022-03-28 04:18:15 --> URI Class Initialized
DEBUG - 2022-03-28 04:18:15 --> No URI present. Default controller set.
INFO - 2022-03-28 04:18:15 --> Router Class Initialized
INFO - 2022-03-28 04:18:15 --> Output Class Initialized
INFO - 2022-03-28 04:18:15 --> Security Class Initialized
DEBUG - 2022-03-28 04:18:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 04:18:15 --> Input Class Initialized
INFO - 2022-03-28 04:18:15 --> Language Class Initialized
INFO - 2022-03-28 04:18:15 --> Loader Class Initialized
INFO - 2022-03-28 04:18:15 --> Helper loaded: url_helper
INFO - 2022-03-28 04:18:15 --> Helper loaded: form_helper
INFO - 2022-03-28 04:18:15 --> Helper loaded: common_helper
INFO - 2022-03-28 04:18:15 --> Database Driver Class Initialized
DEBUG - 2022-03-28 04:18:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 04:18:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 04:18:15 --> Controller Class Initialized
INFO - 2022-03-28 04:18:15 --> Form Validation Class Initialized
DEBUG - 2022-03-28 04:18:15 --> Encrypt Class Initialized
DEBUG - 2022-03-28 04:18:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-28 04:18:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-28 04:18:15 --> Email Class Initialized
INFO - 2022-03-28 04:18:15 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-28 04:18:15 --> Calendar Class Initialized
INFO - 2022-03-28 04:18:15 --> Model "Login_model" initialized
INFO - 2022-03-28 04:18:15 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-28 04:18:15 --> Final output sent to browser
DEBUG - 2022-03-28 04:18:15 --> Total execution time: 0.1110
ERROR - 2022-03-28 04:23:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 04:23:17 --> Config Class Initialized
INFO - 2022-03-28 04:23:17 --> Hooks Class Initialized
DEBUG - 2022-03-28 04:23:17 --> UTF-8 Support Enabled
INFO - 2022-03-28 04:23:17 --> Utf8 Class Initialized
INFO - 2022-03-28 04:23:17 --> URI Class Initialized
DEBUG - 2022-03-28 04:23:17 --> No URI present. Default controller set.
INFO - 2022-03-28 04:23:17 --> Router Class Initialized
INFO - 2022-03-28 04:23:17 --> Output Class Initialized
INFO - 2022-03-28 04:23:17 --> Security Class Initialized
DEBUG - 2022-03-28 04:23:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 04:23:17 --> Input Class Initialized
INFO - 2022-03-28 04:23:17 --> Language Class Initialized
INFO - 2022-03-28 04:23:17 --> Loader Class Initialized
INFO - 2022-03-28 04:23:17 --> Helper loaded: url_helper
INFO - 2022-03-28 04:23:17 --> Helper loaded: form_helper
INFO - 2022-03-28 04:23:17 --> Helper loaded: common_helper
INFO - 2022-03-28 04:23:17 --> Database Driver Class Initialized
DEBUG - 2022-03-28 04:23:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 04:23:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 04:23:17 --> Controller Class Initialized
INFO - 2022-03-28 04:23:17 --> Form Validation Class Initialized
DEBUG - 2022-03-28 04:23:17 --> Encrypt Class Initialized
DEBUG - 2022-03-28 04:23:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-28 04:23:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-28 04:23:17 --> Email Class Initialized
INFO - 2022-03-28 04:23:17 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-28 04:23:17 --> Calendar Class Initialized
INFO - 2022-03-28 04:23:17 --> Model "Login_model" initialized
INFO - 2022-03-28 04:23:17 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-28 04:23:17 --> Final output sent to browser
DEBUG - 2022-03-28 04:23:17 --> Total execution time: 0.0532
ERROR - 2022-03-28 05:30:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 05:30:36 --> Config Class Initialized
INFO - 2022-03-28 05:30:36 --> Hooks Class Initialized
DEBUG - 2022-03-28 05:30:36 --> UTF-8 Support Enabled
INFO - 2022-03-28 05:30:36 --> Utf8 Class Initialized
INFO - 2022-03-28 05:30:36 --> URI Class Initialized
DEBUG - 2022-03-28 05:30:36 --> No URI present. Default controller set.
INFO - 2022-03-28 05:30:36 --> Router Class Initialized
INFO - 2022-03-28 05:30:36 --> Output Class Initialized
INFO - 2022-03-28 05:30:36 --> Security Class Initialized
DEBUG - 2022-03-28 05:30:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 05:30:36 --> Input Class Initialized
INFO - 2022-03-28 05:30:36 --> Language Class Initialized
INFO - 2022-03-28 05:30:36 --> Loader Class Initialized
INFO - 2022-03-28 05:30:36 --> Helper loaded: url_helper
INFO - 2022-03-28 05:30:36 --> Helper loaded: form_helper
INFO - 2022-03-28 05:30:36 --> Helper loaded: common_helper
INFO - 2022-03-28 05:30:36 --> Database Driver Class Initialized
DEBUG - 2022-03-28 05:30:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 05:30:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 05:30:36 --> Controller Class Initialized
INFO - 2022-03-28 05:30:36 --> Form Validation Class Initialized
DEBUG - 2022-03-28 05:30:36 --> Encrypt Class Initialized
DEBUG - 2022-03-28 05:30:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-28 05:30:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-28 05:30:36 --> Email Class Initialized
INFO - 2022-03-28 05:30:36 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-28 05:30:36 --> Calendar Class Initialized
INFO - 2022-03-28 05:30:36 --> Model "Login_model" initialized
INFO - 2022-03-28 05:30:36 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-28 05:30:36 --> Final output sent to browser
DEBUG - 2022-03-28 05:30:36 --> Total execution time: 0.0843
ERROR - 2022-03-28 05:30:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 05:30:41 --> Config Class Initialized
INFO - 2022-03-28 05:30:41 --> Hooks Class Initialized
DEBUG - 2022-03-28 05:30:41 --> UTF-8 Support Enabled
INFO - 2022-03-28 05:30:41 --> Utf8 Class Initialized
INFO - 2022-03-28 05:30:41 --> URI Class Initialized
INFO - 2022-03-28 05:30:41 --> Router Class Initialized
INFO - 2022-03-28 05:30:41 --> Output Class Initialized
INFO - 2022-03-28 05:30:41 --> Security Class Initialized
DEBUG - 2022-03-28 05:30:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 05:30:41 --> Input Class Initialized
INFO - 2022-03-28 05:30:41 --> Language Class Initialized
INFO - 2022-03-28 05:30:41 --> Loader Class Initialized
INFO - 2022-03-28 05:30:41 --> Helper loaded: url_helper
INFO - 2022-03-28 05:30:41 --> Helper loaded: form_helper
INFO - 2022-03-28 05:30:41 --> Helper loaded: common_helper
INFO - 2022-03-28 05:30:41 --> Database Driver Class Initialized
DEBUG - 2022-03-28 05:30:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 05:30:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 05:30:41 --> Controller Class Initialized
INFO - 2022-03-28 05:30:41 --> Form Validation Class Initialized
DEBUG - 2022-03-28 05:30:41 --> Encrypt Class Initialized
DEBUG - 2022-03-28 05:30:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-28 05:30:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-28 05:30:41 --> Email Class Initialized
INFO - 2022-03-28 05:30:41 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-28 05:30:41 --> Calendar Class Initialized
INFO - 2022-03-28 05:30:41 --> Model "Login_model" initialized
INFO - 2022-03-28 05:30:41 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-03-28 05:30:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 05:30:41 --> Config Class Initialized
INFO - 2022-03-28 05:30:41 --> Hooks Class Initialized
DEBUG - 2022-03-28 05:30:41 --> UTF-8 Support Enabled
INFO - 2022-03-28 05:30:41 --> Utf8 Class Initialized
INFO - 2022-03-28 05:30:41 --> URI Class Initialized
INFO - 2022-03-28 05:30:41 --> Router Class Initialized
INFO - 2022-03-28 05:30:41 --> Output Class Initialized
INFO - 2022-03-28 05:30:41 --> Security Class Initialized
DEBUG - 2022-03-28 05:30:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 05:30:41 --> Input Class Initialized
INFO - 2022-03-28 05:30:41 --> Language Class Initialized
INFO - 2022-03-28 05:30:41 --> Loader Class Initialized
INFO - 2022-03-28 05:30:41 --> Helper loaded: url_helper
INFO - 2022-03-28 05:30:41 --> Helper loaded: form_helper
INFO - 2022-03-28 05:30:41 --> Helper loaded: common_helper
INFO - 2022-03-28 05:30:41 --> Database Driver Class Initialized
DEBUG - 2022-03-28 05:30:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 05:30:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 05:30:41 --> Controller Class Initialized
INFO - 2022-03-28 05:30:41 --> Form Validation Class Initialized
DEBUG - 2022-03-28 05:30:41 --> Encrypt Class Initialized
INFO - 2022-03-28 05:30:41 --> Model "Login_model" initialized
INFO - 2022-03-28 05:30:41 --> Model "Dashboard_model" initialized
INFO - 2022-03-28 05:30:41 --> Model "Case_model" initialized
INFO - 2022-03-28 05:30:50 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-28 05:31:01 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2022-03-28 05:31:01 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-28 05:31:01 --> Final output sent to browser
DEBUG - 2022-03-28 05:31:01 --> Total execution time: 19.5853
ERROR - 2022-03-28 05:32:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 05:32:27 --> Config Class Initialized
INFO - 2022-03-28 05:32:27 --> Hooks Class Initialized
DEBUG - 2022-03-28 05:32:27 --> UTF-8 Support Enabled
INFO - 2022-03-28 05:32:27 --> Utf8 Class Initialized
INFO - 2022-03-28 05:32:27 --> URI Class Initialized
INFO - 2022-03-28 05:32:27 --> Router Class Initialized
INFO - 2022-03-28 05:32:27 --> Output Class Initialized
INFO - 2022-03-28 05:32:27 --> Security Class Initialized
DEBUG - 2022-03-28 05:32:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 05:32:27 --> Input Class Initialized
INFO - 2022-03-28 05:32:27 --> Language Class Initialized
INFO - 2022-03-28 05:32:27 --> Loader Class Initialized
INFO - 2022-03-28 05:32:27 --> Helper loaded: url_helper
INFO - 2022-03-28 05:32:27 --> Helper loaded: form_helper
INFO - 2022-03-28 05:32:27 --> Helper loaded: common_helper
INFO - 2022-03-28 05:32:27 --> Database Driver Class Initialized
DEBUG - 2022-03-28 05:32:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 05:32:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 05:32:27 --> Controller Class Initialized
INFO - 2022-03-28 05:32:27 --> Form Validation Class Initialized
DEBUG - 2022-03-28 05:32:27 --> Encrypt Class Initialized
INFO - 2022-03-28 05:32:27 --> Model "Patient_model" initialized
INFO - 2022-03-28 05:32:27 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 05:32:27 --> Model "Referredby_model" initialized
INFO - 2022-03-28 05:32:27 --> Model "Prefix_master" initialized
INFO - 2022-03-28 05:32:27 --> Model "Hospital_model" initialized
INFO - 2022-03-28 05:32:27 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-28 05:32:34 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-28 05:32:34 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-28 05:32:36 --> Final output sent to browser
DEBUG - 2022-03-28 05:32:36 --> Total execution time: 6.6409
ERROR - 2022-03-28 06:08:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 06:08:42 --> Config Class Initialized
INFO - 2022-03-28 06:08:42 --> Hooks Class Initialized
DEBUG - 2022-03-28 06:08:42 --> UTF-8 Support Enabled
INFO - 2022-03-28 06:08:42 --> Utf8 Class Initialized
INFO - 2022-03-28 06:08:42 --> URI Class Initialized
DEBUG - 2022-03-28 06:08:42 --> No URI present. Default controller set.
INFO - 2022-03-28 06:08:42 --> Router Class Initialized
INFO - 2022-03-28 06:08:42 --> Output Class Initialized
INFO - 2022-03-28 06:08:42 --> Security Class Initialized
DEBUG - 2022-03-28 06:08:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 06:08:42 --> Input Class Initialized
INFO - 2022-03-28 06:08:42 --> Language Class Initialized
INFO - 2022-03-28 06:08:42 --> Loader Class Initialized
INFO - 2022-03-28 06:08:42 --> Helper loaded: url_helper
INFO - 2022-03-28 06:08:42 --> Helper loaded: form_helper
INFO - 2022-03-28 06:08:42 --> Helper loaded: common_helper
INFO - 2022-03-28 06:08:42 --> Database Driver Class Initialized
DEBUG - 2022-03-28 06:08:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 06:08:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 06:08:42 --> Controller Class Initialized
INFO - 2022-03-28 06:08:42 --> Form Validation Class Initialized
DEBUG - 2022-03-28 06:08:42 --> Encrypt Class Initialized
DEBUG - 2022-03-28 06:08:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-28 06:08:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-28 06:08:42 --> Email Class Initialized
INFO - 2022-03-28 06:08:42 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-28 06:08:42 --> Calendar Class Initialized
INFO - 2022-03-28 06:08:42 --> Model "Login_model" initialized
INFO - 2022-03-28 06:08:42 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-28 06:08:42 --> Final output sent to browser
DEBUG - 2022-03-28 06:08:42 --> Total execution time: 0.0772
ERROR - 2022-03-28 06:08:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 06:08:44 --> Config Class Initialized
INFO - 2022-03-28 06:08:44 --> Hooks Class Initialized
DEBUG - 2022-03-28 06:08:44 --> UTF-8 Support Enabled
INFO - 2022-03-28 06:08:44 --> Utf8 Class Initialized
INFO - 2022-03-28 06:08:44 --> URI Class Initialized
DEBUG - 2022-03-28 06:08:44 --> No URI present. Default controller set.
INFO - 2022-03-28 06:08:44 --> Router Class Initialized
INFO - 2022-03-28 06:08:44 --> Output Class Initialized
INFO - 2022-03-28 06:08:44 --> Security Class Initialized
DEBUG - 2022-03-28 06:08:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 06:08:44 --> Input Class Initialized
INFO - 2022-03-28 06:08:44 --> Language Class Initialized
INFO - 2022-03-28 06:08:44 --> Loader Class Initialized
INFO - 2022-03-28 06:08:44 --> Helper loaded: url_helper
INFO - 2022-03-28 06:08:44 --> Helper loaded: form_helper
INFO - 2022-03-28 06:08:44 --> Helper loaded: common_helper
INFO - 2022-03-28 06:08:44 --> Database Driver Class Initialized
DEBUG - 2022-03-28 06:08:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 06:08:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 06:08:44 --> Controller Class Initialized
INFO - 2022-03-28 06:08:44 --> Form Validation Class Initialized
DEBUG - 2022-03-28 06:08:44 --> Encrypt Class Initialized
DEBUG - 2022-03-28 06:08:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-28 06:08:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-28 06:08:44 --> Email Class Initialized
INFO - 2022-03-28 06:08:44 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-28 06:08:44 --> Calendar Class Initialized
INFO - 2022-03-28 06:08:44 --> Model "Login_model" initialized
INFO - 2022-03-28 06:08:44 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-28 06:08:44 --> Final output sent to browser
DEBUG - 2022-03-28 06:08:44 --> Total execution time: 0.0062
ERROR - 2022-03-28 06:57:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-03-28 06:57:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-03-28 06:57:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-03-28 06:57:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 06:57:33 --> Config Class Initialized
INFO - 2022-03-28 06:57:33 --> Config Class Initialized
INFO - 2022-03-28 06:57:33 --> Hooks Class Initialized
INFO - 2022-03-28 06:57:33 --> Hooks Class Initialized
INFO - 2022-03-28 06:57:33 --> Config Class Initialized
INFO - 2022-03-28 06:57:33 --> Hooks Class Initialized
INFO - 2022-03-28 06:57:33 --> Config Class Initialized
INFO - 2022-03-28 06:57:33 --> Hooks Class Initialized
DEBUG - 2022-03-28 06:57:33 --> UTF-8 Support Enabled
INFO - 2022-03-28 06:57:33 --> Utf8 Class Initialized
DEBUG - 2022-03-28 06:57:33 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 06:57:33 --> UTF-8 Support Enabled
INFO - 2022-03-28 06:57:33 --> Utf8 Class Initialized
INFO - 2022-03-28 06:57:33 --> Utf8 Class Initialized
DEBUG - 2022-03-28 06:57:33 --> UTF-8 Support Enabled
INFO - 2022-03-28 06:57:33 --> Utf8 Class Initialized
INFO - 2022-03-28 06:57:33 --> URI Class Initialized
INFO - 2022-03-28 06:57:33 --> URI Class Initialized
INFO - 2022-03-28 06:57:33 --> URI Class Initialized
INFO - 2022-03-28 06:57:33 --> URI Class Initialized
INFO - 2022-03-28 06:57:33 --> Router Class Initialized
INFO - 2022-03-28 06:57:33 --> Router Class Initialized
INFO - 2022-03-28 06:57:33 --> Router Class Initialized
INFO - 2022-03-28 06:57:33 --> Router Class Initialized
INFO - 2022-03-28 06:57:33 --> Output Class Initialized
INFO - 2022-03-28 06:57:33 --> Output Class Initialized
INFO - 2022-03-28 06:57:33 --> Output Class Initialized
INFO - 2022-03-28 06:57:33 --> Output Class Initialized
INFO - 2022-03-28 06:57:33 --> Security Class Initialized
INFO - 2022-03-28 06:57:33 --> Security Class Initialized
INFO - 2022-03-28 06:57:33 --> Security Class Initialized
INFO - 2022-03-28 06:57:33 --> Security Class Initialized
DEBUG - 2022-03-28 06:57:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 06:57:33 --> Input Class Initialized
DEBUG - 2022-03-28 06:57:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 06:57:33 --> Input Class Initialized
INFO - 2022-03-28 06:57:33 --> Language Class Initialized
DEBUG - 2022-03-28 06:57:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 06:57:33 --> Language Class Initialized
INFO - 2022-03-28 06:57:33 --> Input Class Initialized
INFO - 2022-03-28 06:57:33 --> Language Class Initialized
DEBUG - 2022-03-28 06:57:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 06:57:33 --> Input Class Initialized
INFO - 2022-03-28 06:57:33 --> Language Class Initialized
ERROR - 2022-03-28 06:57:33 --> 404 Page Not Found: Xleetphp/index
ERROR - 2022-03-28 06:57:33 --> 404 Page Not Found: Takeoutphp/index
ERROR - 2022-03-28 06:57:33 --> 404 Page Not Found: Xletphp/index
ERROR - 2022-03-28 06:57:33 --> 404 Page Not Found: Sh3llxphp/index
ERROR - 2022-03-28 06:57:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 06:57:33 --> Config Class Initialized
INFO - 2022-03-28 06:57:33 --> Hooks Class Initialized
DEBUG - 2022-03-28 06:57:33 --> UTF-8 Support Enabled
INFO - 2022-03-28 06:57:33 --> Utf8 Class Initialized
INFO - 2022-03-28 06:57:33 --> URI Class Initialized
INFO - 2022-03-28 06:57:33 --> Router Class Initialized
INFO - 2022-03-28 06:57:33 --> Output Class Initialized
INFO - 2022-03-28 06:57:33 --> Security Class Initialized
DEBUG - 2022-03-28 06:57:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 06:57:33 --> Input Class Initialized
INFO - 2022-03-28 06:57:33 --> Language Class Initialized
ERROR - 2022-03-28 06:57:33 --> 404 Page Not Found: Xleet-shellphp/index
ERROR - 2022-03-28 06:57:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 06:57:33 --> Config Class Initialized
INFO - 2022-03-28 06:57:33 --> Hooks Class Initialized
DEBUG - 2022-03-28 06:57:33 --> UTF-8 Support Enabled
INFO - 2022-03-28 06:57:33 --> Utf8 Class Initialized
INFO - 2022-03-28 06:57:33 --> URI Class Initialized
INFO - 2022-03-28 06:57:33 --> Router Class Initialized
INFO - 2022-03-28 06:57:33 --> Output Class Initialized
INFO - 2022-03-28 06:57:33 --> Security Class Initialized
DEBUG - 2022-03-28 06:57:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 06:57:33 --> Input Class Initialized
INFO - 2022-03-28 06:57:33 --> Language Class Initialized
ERROR - 2022-03-28 06:57:33 --> 404 Page Not Found: Jindexphp/index
ERROR - 2022-03-28 06:57:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 06:57:33 --> Config Class Initialized
INFO - 2022-03-28 06:57:33 --> Hooks Class Initialized
DEBUG - 2022-03-28 06:57:33 --> UTF-8 Support Enabled
INFO - 2022-03-28 06:57:33 --> Utf8 Class Initialized
INFO - 2022-03-28 06:57:33 --> URI Class Initialized
INFO - 2022-03-28 06:57:33 --> Router Class Initialized
INFO - 2022-03-28 06:57:33 --> Output Class Initialized
INFO - 2022-03-28 06:57:33 --> Security Class Initialized
DEBUG - 2022-03-28 06:57:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 06:57:33 --> Input Class Initialized
INFO - 2022-03-28 06:57:33 --> Language Class Initialized
ERROR - 2022-03-28 06:57:33 --> 404 Page Not Found: Adminphp/index
ERROR - 2022-03-28 07:11:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 07:11:05 --> Config Class Initialized
INFO - 2022-03-28 07:11:05 --> Hooks Class Initialized
DEBUG - 2022-03-28 07:11:05 --> UTF-8 Support Enabled
INFO - 2022-03-28 07:11:05 --> Utf8 Class Initialized
INFO - 2022-03-28 07:11:05 --> URI Class Initialized
INFO - 2022-03-28 07:11:05 --> Router Class Initialized
INFO - 2022-03-28 07:11:05 --> Output Class Initialized
INFO - 2022-03-28 07:11:05 --> Security Class Initialized
DEBUG - 2022-03-28 07:11:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 07:11:05 --> Input Class Initialized
INFO - 2022-03-28 07:11:05 --> Language Class Initialized
INFO - 2022-03-28 07:11:05 --> Loader Class Initialized
INFO - 2022-03-28 07:11:05 --> Helper loaded: url_helper
INFO - 2022-03-28 07:11:05 --> Helper loaded: form_helper
INFO - 2022-03-28 07:11:05 --> Helper loaded: common_helper
INFO - 2022-03-28 07:11:05 --> Database Driver Class Initialized
DEBUG - 2022-03-28 07:11:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 07:11:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 07:11:05 --> Controller Class Initialized
INFO - 2022-03-28 07:11:05 --> Form Validation Class Initialized
DEBUG - 2022-03-28 07:11:05 --> Encrypt Class Initialized
INFO - 2022-03-28 07:11:05 --> Model "Patient_model" initialized
INFO - 2022-03-28 07:11:05 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 07:11:05 --> Model "Referredby_model" initialized
INFO - 2022-03-28 07:11:05 --> Model "Prefix_master" initialized
INFO - 2022-03-28 07:11:05 --> Model "Hospital_model" initialized
INFO - 2022-03-28 07:11:05 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-28 07:11:11 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-28 07:11:11 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-28 07:11:12 --> Final output sent to browser
DEBUG - 2022-03-28 07:11:12 --> Total execution time: 5.8175
ERROR - 2022-03-28 07:12:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 07:12:04 --> Config Class Initialized
INFO - 2022-03-28 07:12:04 --> Hooks Class Initialized
DEBUG - 2022-03-28 07:12:04 --> UTF-8 Support Enabled
INFO - 2022-03-28 07:12:04 --> Utf8 Class Initialized
INFO - 2022-03-28 07:12:04 --> URI Class Initialized
INFO - 2022-03-28 07:12:04 --> Router Class Initialized
INFO - 2022-03-28 07:12:04 --> Output Class Initialized
INFO - 2022-03-28 07:12:04 --> Security Class Initialized
DEBUG - 2022-03-28 07:12:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 07:12:04 --> Input Class Initialized
INFO - 2022-03-28 07:12:04 --> Language Class Initialized
INFO - 2022-03-28 07:12:04 --> Loader Class Initialized
INFO - 2022-03-28 07:12:04 --> Helper loaded: url_helper
INFO - 2022-03-28 07:12:04 --> Helper loaded: form_helper
INFO - 2022-03-28 07:12:04 --> Helper loaded: common_helper
INFO - 2022-03-28 07:12:04 --> Database Driver Class Initialized
DEBUG - 2022-03-28 07:12:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 07:12:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 07:12:04 --> Controller Class Initialized
ERROR - 2022-03-28 07:12:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 07:12:04 --> Config Class Initialized
INFO - 2022-03-28 07:12:04 --> Hooks Class Initialized
DEBUG - 2022-03-28 07:12:04 --> UTF-8 Support Enabled
INFO - 2022-03-28 07:12:04 --> Utf8 Class Initialized
INFO - 2022-03-28 07:12:04 --> URI Class Initialized
INFO - 2022-03-28 07:12:04 --> Router Class Initialized
INFO - 2022-03-28 07:12:04 --> Output Class Initialized
INFO - 2022-03-28 07:12:04 --> Security Class Initialized
DEBUG - 2022-03-28 07:12:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 07:12:04 --> Input Class Initialized
INFO - 2022-03-28 07:12:04 --> Language Class Initialized
INFO - 2022-03-28 07:12:04 --> Loader Class Initialized
INFO - 2022-03-28 07:12:04 --> Helper loaded: url_helper
INFO - 2022-03-28 07:12:04 --> Helper loaded: form_helper
INFO - 2022-03-28 07:12:04 --> Helper loaded: common_helper
INFO - 2022-03-28 07:12:04 --> Database Driver Class Initialized
DEBUG - 2022-03-28 07:12:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 07:12:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 07:12:04 --> Controller Class Initialized
INFO - 2022-03-28 07:12:04 --> Form Validation Class Initialized
DEBUG - 2022-03-28 07:12:04 --> Encrypt Class Initialized
DEBUG - 2022-03-28 07:12:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-28 07:12:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-28 07:12:04 --> Email Class Initialized
INFO - 2022-03-28 07:12:04 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-28 07:12:04 --> Calendar Class Initialized
INFO - 2022-03-28 07:12:04 --> Model "Login_model" initialized
INFO - 2022-03-28 07:12:04 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-28 07:12:04 --> Final output sent to browser
DEBUG - 2022-03-28 07:12:04 --> Total execution time: 0.0139
ERROR - 2022-03-28 07:12:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 07:12:16 --> Config Class Initialized
INFO - 2022-03-28 07:12:16 --> Hooks Class Initialized
DEBUG - 2022-03-28 07:12:16 --> UTF-8 Support Enabled
INFO - 2022-03-28 07:12:16 --> Utf8 Class Initialized
INFO - 2022-03-28 07:12:16 --> URI Class Initialized
INFO - 2022-03-28 07:12:16 --> Router Class Initialized
INFO - 2022-03-28 07:12:16 --> Output Class Initialized
INFO - 2022-03-28 07:12:16 --> Security Class Initialized
DEBUG - 2022-03-28 07:12:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 07:12:16 --> Input Class Initialized
INFO - 2022-03-28 07:12:16 --> Language Class Initialized
INFO - 2022-03-28 07:12:16 --> Loader Class Initialized
INFO - 2022-03-28 07:12:16 --> Helper loaded: url_helper
INFO - 2022-03-28 07:12:16 --> Helper loaded: form_helper
INFO - 2022-03-28 07:12:16 --> Helper loaded: common_helper
INFO - 2022-03-28 07:12:16 --> Database Driver Class Initialized
DEBUG - 2022-03-28 07:12:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 07:12:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 07:12:16 --> Controller Class Initialized
INFO - 2022-03-28 07:12:16 --> Form Validation Class Initialized
DEBUG - 2022-03-28 07:12:16 --> Encrypt Class Initialized
DEBUG - 2022-03-28 07:12:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-28 07:12:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-28 07:12:16 --> Email Class Initialized
INFO - 2022-03-28 07:12:16 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-28 07:12:16 --> Calendar Class Initialized
INFO - 2022-03-28 07:12:16 --> Model "Login_model" initialized
INFO - 2022-03-28 07:12:16 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-03-28 07:12:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 07:12:17 --> Config Class Initialized
INFO - 2022-03-28 07:12:17 --> Hooks Class Initialized
DEBUG - 2022-03-28 07:12:17 --> UTF-8 Support Enabled
INFO - 2022-03-28 07:12:17 --> Utf8 Class Initialized
INFO - 2022-03-28 07:12:17 --> URI Class Initialized
INFO - 2022-03-28 07:12:17 --> Router Class Initialized
INFO - 2022-03-28 07:12:17 --> Output Class Initialized
INFO - 2022-03-28 07:12:17 --> Security Class Initialized
DEBUG - 2022-03-28 07:12:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 07:12:17 --> Input Class Initialized
INFO - 2022-03-28 07:12:17 --> Language Class Initialized
INFO - 2022-03-28 07:12:17 --> Loader Class Initialized
INFO - 2022-03-28 07:12:17 --> Helper loaded: url_helper
INFO - 2022-03-28 07:12:17 --> Helper loaded: form_helper
INFO - 2022-03-28 07:12:17 --> Helper loaded: common_helper
INFO - 2022-03-28 07:12:17 --> Database Driver Class Initialized
DEBUG - 2022-03-28 07:12:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 07:12:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 07:12:17 --> Controller Class Initialized
INFO - 2022-03-28 07:12:17 --> Form Validation Class Initialized
DEBUG - 2022-03-28 07:12:17 --> Encrypt Class Initialized
INFO - 2022-03-28 07:12:17 --> Model "Login_model" initialized
INFO - 2022-03-28 07:12:17 --> Model "Dashboard_model" initialized
INFO - 2022-03-28 07:12:17 --> Model "Case_model" initialized
INFO - 2022-03-28 07:12:17 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-28 07:12:17 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2022-03-28 07:12:17 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-28 07:12:17 --> Final output sent to browser
DEBUG - 2022-03-28 07:12:17 --> Total execution time: 0.2723
ERROR - 2022-03-28 07:12:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 07:12:29 --> Config Class Initialized
INFO - 2022-03-28 07:12:29 --> Hooks Class Initialized
DEBUG - 2022-03-28 07:12:29 --> UTF-8 Support Enabled
INFO - 2022-03-28 07:12:29 --> Utf8 Class Initialized
INFO - 2022-03-28 07:12:29 --> URI Class Initialized
INFO - 2022-03-28 07:12:29 --> Router Class Initialized
INFO - 2022-03-28 07:12:29 --> Output Class Initialized
INFO - 2022-03-28 07:12:29 --> Security Class Initialized
DEBUG - 2022-03-28 07:12:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 07:12:29 --> Input Class Initialized
INFO - 2022-03-28 07:12:29 --> Language Class Initialized
INFO - 2022-03-28 07:12:29 --> Loader Class Initialized
INFO - 2022-03-28 07:12:29 --> Helper loaded: url_helper
INFO - 2022-03-28 07:12:29 --> Helper loaded: form_helper
INFO - 2022-03-28 07:12:29 --> Helper loaded: common_helper
INFO - 2022-03-28 07:12:29 --> Database Driver Class Initialized
DEBUG - 2022-03-28 07:12:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 07:12:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 07:12:29 --> Controller Class Initialized
INFO - 2022-03-28 07:12:29 --> Form Validation Class Initialized
DEBUG - 2022-03-28 07:12:29 --> Encrypt Class Initialized
INFO - 2022-03-28 07:12:29 --> Model "Patient_model" initialized
INFO - 2022-03-28 07:12:29 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 07:12:29 --> Model "Referredby_model" initialized
INFO - 2022-03-28 07:12:29 --> Model "Prefix_master" initialized
INFO - 2022-03-28 07:12:29 --> Model "Hospital_model" initialized
INFO - 2022-03-28 07:12:29 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-28 07:12:29 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-28 07:12:29 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-28 07:12:29 --> Final output sent to browser
DEBUG - 2022-03-28 07:12:29 --> Total execution time: 0.0272
ERROR - 2022-03-28 07:12:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 07:12:53 --> Config Class Initialized
INFO - 2022-03-28 07:12:53 --> Hooks Class Initialized
DEBUG - 2022-03-28 07:12:53 --> UTF-8 Support Enabled
INFO - 2022-03-28 07:12:53 --> Utf8 Class Initialized
INFO - 2022-03-28 07:12:53 --> URI Class Initialized
INFO - 2022-03-28 07:12:53 --> Router Class Initialized
INFO - 2022-03-28 07:12:53 --> Output Class Initialized
INFO - 2022-03-28 07:12:53 --> Security Class Initialized
DEBUG - 2022-03-28 07:12:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 07:12:53 --> Input Class Initialized
INFO - 2022-03-28 07:12:53 --> Language Class Initialized
INFO - 2022-03-28 07:12:53 --> Loader Class Initialized
INFO - 2022-03-28 07:12:53 --> Helper loaded: url_helper
INFO - 2022-03-28 07:12:53 --> Helper loaded: form_helper
INFO - 2022-03-28 07:12:53 --> Helper loaded: common_helper
INFO - 2022-03-28 07:12:53 --> Database Driver Class Initialized
DEBUG - 2022-03-28 07:12:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 07:12:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 07:12:53 --> Controller Class Initialized
INFO - 2022-03-28 07:12:53 --> Form Validation Class Initialized
DEBUG - 2022-03-28 07:12:53 --> Encrypt Class Initialized
INFO - 2022-03-28 07:12:53 --> Model "Patient_model" initialized
INFO - 2022-03-28 07:12:53 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 07:12:53 --> Model "Referredby_model" initialized
INFO - 2022-03-28 07:12:53 --> Model "Prefix_master" initialized
INFO - 2022-03-28 07:12:53 --> Model "Hospital_model" initialized
INFO - 2022-03-28 07:12:53 --> Upload Class Initialized
INFO - 2022-03-28 07:12:53 --> Final output sent to browser
DEBUG - 2022-03-28 07:12:53 --> Total execution time: 0.0375
ERROR - 2022-03-28 07:15:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 07:15:41 --> Config Class Initialized
INFO - 2022-03-28 07:15:41 --> Hooks Class Initialized
DEBUG - 2022-03-28 07:15:41 --> UTF-8 Support Enabled
INFO - 2022-03-28 07:15:41 --> Utf8 Class Initialized
INFO - 2022-03-28 07:15:41 --> URI Class Initialized
INFO - 2022-03-28 07:15:41 --> Router Class Initialized
INFO - 2022-03-28 07:15:41 --> Output Class Initialized
INFO - 2022-03-28 07:15:41 --> Security Class Initialized
DEBUG - 2022-03-28 07:15:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 07:15:41 --> Input Class Initialized
INFO - 2022-03-28 07:15:41 --> Language Class Initialized
INFO - 2022-03-28 07:15:41 --> Loader Class Initialized
INFO - 2022-03-28 07:15:41 --> Helper loaded: url_helper
INFO - 2022-03-28 07:15:41 --> Helper loaded: form_helper
INFO - 2022-03-28 07:15:41 --> Helper loaded: common_helper
INFO - 2022-03-28 07:15:41 --> Database Driver Class Initialized
DEBUG - 2022-03-28 07:15:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 07:15:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 07:15:41 --> Controller Class Initialized
INFO - 2022-03-28 07:15:41 --> Model "Referredby_model" initialized
INFO - 2022-03-28 07:15:41 --> Final output sent to browser
DEBUG - 2022-03-28 07:15:41 --> Total execution time: 0.0449
ERROR - 2022-03-28 07:16:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 07:16:23 --> Config Class Initialized
INFO - 2022-03-28 07:16:23 --> Hooks Class Initialized
DEBUG - 2022-03-28 07:16:23 --> UTF-8 Support Enabled
INFO - 2022-03-28 07:16:23 --> Utf8 Class Initialized
INFO - 2022-03-28 07:16:23 --> URI Class Initialized
INFO - 2022-03-28 07:16:23 --> Router Class Initialized
INFO - 2022-03-28 07:16:23 --> Output Class Initialized
INFO - 2022-03-28 07:16:23 --> Security Class Initialized
DEBUG - 2022-03-28 07:16:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 07:16:23 --> Input Class Initialized
INFO - 2022-03-28 07:16:23 --> Language Class Initialized
INFO - 2022-03-28 07:16:23 --> Loader Class Initialized
INFO - 2022-03-28 07:16:23 --> Helper loaded: url_helper
INFO - 2022-03-28 07:16:23 --> Helper loaded: form_helper
INFO - 2022-03-28 07:16:23 --> Helper loaded: common_helper
INFO - 2022-03-28 07:16:23 --> Database Driver Class Initialized
DEBUG - 2022-03-28 07:16:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 07:16:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 07:16:23 --> Controller Class Initialized
INFO - 2022-03-28 07:16:23 --> Model "Referredby_model" initialized
INFO - 2022-03-28 07:16:23 --> Final output sent to browser
DEBUG - 2022-03-28 07:16:23 --> Total execution time: 0.0085
ERROR - 2022-03-28 07:16:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 07:16:49 --> Config Class Initialized
INFO - 2022-03-28 07:16:49 --> Hooks Class Initialized
DEBUG - 2022-03-28 07:16:49 --> UTF-8 Support Enabled
INFO - 2022-03-28 07:16:49 --> Utf8 Class Initialized
INFO - 2022-03-28 07:16:49 --> URI Class Initialized
INFO - 2022-03-28 07:16:49 --> Router Class Initialized
INFO - 2022-03-28 07:16:49 --> Output Class Initialized
INFO - 2022-03-28 07:16:49 --> Security Class Initialized
DEBUG - 2022-03-28 07:16:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 07:16:49 --> Input Class Initialized
INFO - 2022-03-28 07:16:49 --> Language Class Initialized
INFO - 2022-03-28 07:16:49 --> Loader Class Initialized
INFO - 2022-03-28 07:16:49 --> Helper loaded: url_helper
INFO - 2022-03-28 07:16:49 --> Helper loaded: form_helper
INFO - 2022-03-28 07:16:49 --> Helper loaded: common_helper
INFO - 2022-03-28 07:16:49 --> Database Driver Class Initialized
DEBUG - 2022-03-28 07:16:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 07:16:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 07:16:49 --> Controller Class Initialized
INFO - 2022-03-28 07:16:49 --> Form Validation Class Initialized
DEBUG - 2022-03-28 07:16:49 --> Encrypt Class Initialized
INFO - 2022-03-28 07:16:49 --> Model "Patient_model" initialized
INFO - 2022-03-28 07:16:49 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 07:16:49 --> Model "Referredby_model" initialized
INFO - 2022-03-28 07:16:49 --> Model "Prefix_master" initialized
INFO - 2022-03-28 07:16:49 --> Model "Hospital_model" initialized
INFO - 2022-03-28 07:16:49 --> Final output sent to browser
DEBUG - 2022-03-28 07:16:49 --> Total execution time: 0.0235
ERROR - 2022-03-28 07:19:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 07:19:09 --> Config Class Initialized
INFO - 2022-03-28 07:19:09 --> Hooks Class Initialized
DEBUG - 2022-03-28 07:19:09 --> UTF-8 Support Enabled
INFO - 2022-03-28 07:19:09 --> Utf8 Class Initialized
INFO - 2022-03-28 07:19:09 --> URI Class Initialized
INFO - 2022-03-28 07:19:09 --> Router Class Initialized
INFO - 2022-03-28 07:19:09 --> Output Class Initialized
INFO - 2022-03-28 07:19:09 --> Security Class Initialized
DEBUG - 2022-03-28 07:19:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 07:19:09 --> Input Class Initialized
INFO - 2022-03-28 07:19:09 --> Language Class Initialized
INFO - 2022-03-28 07:19:09 --> Loader Class Initialized
INFO - 2022-03-28 07:19:09 --> Helper loaded: url_helper
INFO - 2022-03-28 07:19:09 --> Helper loaded: form_helper
INFO - 2022-03-28 07:19:09 --> Helper loaded: common_helper
INFO - 2022-03-28 07:19:09 --> Database Driver Class Initialized
DEBUG - 2022-03-28 07:19:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 07:19:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 07:19:09 --> Controller Class Initialized
INFO - 2022-03-28 07:19:09 --> Form Validation Class Initialized
DEBUG - 2022-03-28 07:19:09 --> Encrypt Class Initialized
INFO - 2022-03-28 07:19:09 --> Model "Patient_model" initialized
INFO - 2022-03-28 07:19:09 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 07:19:09 --> Model "Referredby_model" initialized
INFO - 2022-03-28 07:19:09 --> Model "Prefix_master" initialized
INFO - 2022-03-28 07:19:09 --> Model "Hospital_model" initialized
ERROR - 2022-03-28 07:19:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 07:19:10 --> Config Class Initialized
INFO - 2022-03-28 07:19:10 --> Hooks Class Initialized
DEBUG - 2022-03-28 07:19:10 --> UTF-8 Support Enabled
INFO - 2022-03-28 07:19:10 --> Utf8 Class Initialized
INFO - 2022-03-28 07:19:10 --> URI Class Initialized
INFO - 2022-03-28 07:19:10 --> Router Class Initialized
INFO - 2022-03-28 07:19:10 --> Output Class Initialized
INFO - 2022-03-28 07:19:10 --> Security Class Initialized
DEBUG - 2022-03-28 07:19:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 07:19:10 --> Input Class Initialized
INFO - 2022-03-28 07:19:10 --> Language Class Initialized
INFO - 2022-03-28 07:19:10 --> Loader Class Initialized
INFO - 2022-03-28 07:19:10 --> Helper loaded: url_helper
INFO - 2022-03-28 07:19:10 --> Helper loaded: form_helper
INFO - 2022-03-28 07:19:10 --> Helper loaded: common_helper
INFO - 2022-03-28 07:19:10 --> Database Driver Class Initialized
DEBUG - 2022-03-28 07:19:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 07:19:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 07:19:10 --> Controller Class Initialized
INFO - 2022-03-28 07:19:10 --> Form Validation Class Initialized
DEBUG - 2022-03-28 07:19:10 --> Encrypt Class Initialized
INFO - 2022-03-28 07:19:10 --> Model "Patient_model" initialized
INFO - 2022-03-28 07:19:10 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 07:19:10 --> Model "Referredby_model" initialized
INFO - 2022-03-28 07:19:10 --> Model "Prefix_master" initialized
INFO - 2022-03-28 07:19:10 --> Model "Hospital_model" initialized
INFO - 2022-03-28 07:19:10 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-28 07:19:10 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-28 07:19:10 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-28 07:19:10 --> Final output sent to browser
DEBUG - 2022-03-28 07:19:10 --> Total execution time: 0.0936
ERROR - 2022-03-28 07:19:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 07:19:10 --> Config Class Initialized
INFO - 2022-03-28 07:19:10 --> Hooks Class Initialized
DEBUG - 2022-03-28 07:19:10 --> UTF-8 Support Enabled
INFO - 2022-03-28 07:19:10 --> Utf8 Class Initialized
INFO - 2022-03-28 07:19:10 --> URI Class Initialized
INFO - 2022-03-28 07:19:10 --> Router Class Initialized
INFO - 2022-03-28 07:19:10 --> Output Class Initialized
INFO - 2022-03-28 07:19:10 --> Security Class Initialized
DEBUG - 2022-03-28 07:19:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 07:19:10 --> Input Class Initialized
INFO - 2022-03-28 07:19:10 --> Language Class Initialized
INFO - 2022-03-28 07:19:10 --> Loader Class Initialized
INFO - 2022-03-28 07:19:10 --> Helper loaded: url_helper
INFO - 2022-03-28 07:19:10 --> Helper loaded: form_helper
INFO - 2022-03-28 07:19:10 --> Helper loaded: common_helper
INFO - 2022-03-28 07:19:10 --> Database Driver Class Initialized
DEBUG - 2022-03-28 07:19:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 07:19:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 07:19:10 --> Controller Class Initialized
INFO - 2022-03-28 07:19:10 --> Form Validation Class Initialized
DEBUG - 2022-03-28 07:19:10 --> Encrypt Class Initialized
INFO - 2022-03-28 07:19:10 --> Model "Patient_model" initialized
INFO - 2022-03-28 07:19:10 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 07:19:10 --> Model "Prefix_master" initialized
INFO - 2022-03-28 07:19:10 --> Model "Users_model" initialized
INFO - 2022-03-28 07:19:10 --> Model "Hospital_model" initialized
INFO - 2022-03-28 07:19:11 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-28 07:19:11 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-28 07:19:11 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-28 07:19:11 --> Final output sent to browser
DEBUG - 2022-03-28 07:19:11 --> Total execution time: 0.1620
ERROR - 2022-03-28 07:21:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 07:21:19 --> Config Class Initialized
INFO - 2022-03-28 07:21:19 --> Hooks Class Initialized
DEBUG - 2022-03-28 07:21:19 --> UTF-8 Support Enabled
INFO - 2022-03-28 07:21:19 --> Utf8 Class Initialized
INFO - 2022-03-28 07:21:19 --> URI Class Initialized
INFO - 2022-03-28 07:21:19 --> Router Class Initialized
INFO - 2022-03-28 07:21:19 --> Output Class Initialized
INFO - 2022-03-28 07:21:19 --> Security Class Initialized
DEBUG - 2022-03-28 07:21:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 07:21:19 --> Input Class Initialized
INFO - 2022-03-28 07:21:19 --> Language Class Initialized
INFO - 2022-03-28 07:21:19 --> Loader Class Initialized
INFO - 2022-03-28 07:21:19 --> Helper loaded: url_helper
INFO - 2022-03-28 07:21:19 --> Helper loaded: form_helper
INFO - 2022-03-28 07:21:19 --> Helper loaded: common_helper
INFO - 2022-03-28 07:21:19 --> Database Driver Class Initialized
DEBUG - 2022-03-28 07:21:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 07:21:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 07:21:19 --> Controller Class Initialized
INFO - 2022-03-28 07:21:19 --> Form Validation Class Initialized
DEBUG - 2022-03-28 07:21:19 --> Encrypt Class Initialized
INFO - 2022-03-28 07:21:19 --> Model "Patient_model" initialized
INFO - 2022-03-28 07:21:19 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 07:21:19 --> Model "Prefix_master" initialized
INFO - 2022-03-28 07:21:19 --> Model "Users_model" initialized
INFO - 2022-03-28 07:21:19 --> Model "Hospital_model" initialized
ERROR - 2022-03-28 07:21:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 07:21:19 --> Config Class Initialized
INFO - 2022-03-28 07:21:19 --> Hooks Class Initialized
DEBUG - 2022-03-28 07:21:19 --> UTF-8 Support Enabled
INFO - 2022-03-28 07:21:19 --> Utf8 Class Initialized
INFO - 2022-03-28 07:21:19 --> URI Class Initialized
INFO - 2022-03-28 07:21:19 --> Router Class Initialized
INFO - 2022-03-28 07:21:19 --> Output Class Initialized
INFO - 2022-03-28 07:21:19 --> Security Class Initialized
DEBUG - 2022-03-28 07:21:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 07:21:19 --> Input Class Initialized
INFO - 2022-03-28 07:21:19 --> Language Class Initialized
INFO - 2022-03-28 07:21:19 --> Loader Class Initialized
INFO - 2022-03-28 07:21:19 --> Helper loaded: url_helper
INFO - 2022-03-28 07:21:19 --> Helper loaded: form_helper
INFO - 2022-03-28 07:21:19 --> Helper loaded: common_helper
INFO - 2022-03-28 07:21:19 --> Database Driver Class Initialized
DEBUG - 2022-03-28 07:21:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 07:21:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 07:21:19 --> Controller Class Initialized
INFO - 2022-03-28 07:21:19 --> Form Validation Class Initialized
DEBUG - 2022-03-28 07:21:19 --> Encrypt Class Initialized
INFO - 2022-03-28 07:21:19 --> Model "Patient_model" initialized
INFO - 2022-03-28 07:21:19 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 07:21:19 --> Model "Prefix_master" initialized
INFO - 2022-03-28 07:21:19 --> Model "Users_model" initialized
INFO - 2022-03-28 07:21:19 --> Model "Hospital_model" initialized
INFO - 2022-03-28 07:21:19 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-28 07:21:19 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-28 07:21:19 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-28 07:21:19 --> Final output sent to browser
DEBUG - 2022-03-28 07:21:19 --> Total execution time: 0.0457
ERROR - 2022-03-28 07:24:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 07:24:55 --> Config Class Initialized
INFO - 2022-03-28 07:24:55 --> Hooks Class Initialized
DEBUG - 2022-03-28 07:24:55 --> UTF-8 Support Enabled
INFO - 2022-03-28 07:24:55 --> Utf8 Class Initialized
INFO - 2022-03-28 07:24:55 --> URI Class Initialized
INFO - 2022-03-28 07:24:55 --> Router Class Initialized
INFO - 2022-03-28 07:24:55 --> Output Class Initialized
INFO - 2022-03-28 07:24:55 --> Security Class Initialized
DEBUG - 2022-03-28 07:24:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 07:24:55 --> Input Class Initialized
INFO - 2022-03-28 07:24:55 --> Language Class Initialized
INFO - 2022-03-28 07:24:55 --> Loader Class Initialized
INFO - 2022-03-28 07:24:55 --> Helper loaded: url_helper
INFO - 2022-03-28 07:24:55 --> Helper loaded: form_helper
INFO - 2022-03-28 07:24:55 --> Helper loaded: common_helper
INFO - 2022-03-28 07:24:55 --> Database Driver Class Initialized
DEBUG - 2022-03-28 07:24:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 07:24:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 07:24:55 --> Controller Class Initialized
INFO - 2022-03-28 07:24:55 --> Form Validation Class Initialized
DEBUG - 2022-03-28 07:24:55 --> Encrypt Class Initialized
INFO - 2022-03-28 07:24:55 --> Model "Patient_model" initialized
INFO - 2022-03-28 07:24:55 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 07:24:55 --> Model "Prefix_master" initialized
INFO - 2022-03-28 07:24:55 --> Model "Users_model" initialized
INFO - 2022-03-28 07:24:55 --> Model "Hospital_model" initialized
ERROR - 2022-03-28 07:24:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 07:24:56 --> Config Class Initialized
INFO - 2022-03-28 07:24:56 --> Hooks Class Initialized
DEBUG - 2022-03-28 07:24:56 --> UTF-8 Support Enabled
INFO - 2022-03-28 07:24:56 --> Utf8 Class Initialized
INFO - 2022-03-28 07:24:56 --> URI Class Initialized
INFO - 2022-03-28 07:24:56 --> Router Class Initialized
INFO - 2022-03-28 07:24:56 --> Output Class Initialized
INFO - 2022-03-28 07:24:56 --> Security Class Initialized
DEBUG - 2022-03-28 07:24:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 07:24:56 --> Input Class Initialized
INFO - 2022-03-28 07:24:56 --> Language Class Initialized
INFO - 2022-03-28 07:24:56 --> Loader Class Initialized
INFO - 2022-03-28 07:24:56 --> Helper loaded: url_helper
INFO - 2022-03-28 07:24:56 --> Helper loaded: form_helper
INFO - 2022-03-28 07:24:56 --> Helper loaded: common_helper
INFO - 2022-03-28 07:24:56 --> Database Driver Class Initialized
DEBUG - 2022-03-28 07:24:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 07:24:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 07:24:56 --> Controller Class Initialized
INFO - 2022-03-28 07:24:56 --> Form Validation Class Initialized
DEBUG - 2022-03-28 07:24:56 --> Encrypt Class Initialized
INFO - 2022-03-28 07:24:56 --> Model "Patient_model" initialized
INFO - 2022-03-28 07:24:56 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 07:24:56 --> Model "Prefix_master" initialized
INFO - 2022-03-28 07:24:56 --> Model "Users_model" initialized
INFO - 2022-03-28 07:24:56 --> Model "Hospital_model" initialized
INFO - 2022-03-28 07:24:56 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-28 07:24:56 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-28 07:24:56 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-28 07:24:56 --> Final output sent to browser
DEBUG - 2022-03-28 07:24:56 --> Total execution time: 0.0477
ERROR - 2022-03-28 07:25:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 07:25:39 --> Config Class Initialized
INFO - 2022-03-28 07:25:39 --> Hooks Class Initialized
DEBUG - 2022-03-28 07:25:39 --> UTF-8 Support Enabled
INFO - 2022-03-28 07:25:39 --> Utf8 Class Initialized
INFO - 2022-03-28 07:25:39 --> URI Class Initialized
INFO - 2022-03-28 07:25:39 --> Router Class Initialized
INFO - 2022-03-28 07:25:39 --> Output Class Initialized
INFO - 2022-03-28 07:25:39 --> Security Class Initialized
DEBUG - 2022-03-28 07:25:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 07:25:39 --> Input Class Initialized
INFO - 2022-03-28 07:25:39 --> Language Class Initialized
INFO - 2022-03-28 07:25:39 --> Loader Class Initialized
INFO - 2022-03-28 07:25:39 --> Helper loaded: url_helper
INFO - 2022-03-28 07:25:39 --> Helper loaded: form_helper
INFO - 2022-03-28 07:25:39 --> Helper loaded: common_helper
INFO - 2022-03-28 07:25:39 --> Database Driver Class Initialized
DEBUG - 2022-03-28 07:25:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 07:25:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 07:25:39 --> Controller Class Initialized
INFO - 2022-03-28 07:25:39 --> Form Validation Class Initialized
DEBUG - 2022-03-28 07:25:39 --> Encrypt Class Initialized
INFO - 2022-03-28 07:25:39 --> Model "Patient_model" initialized
INFO - 2022-03-28 07:25:39 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 07:25:39 --> Model "Prefix_master" initialized
INFO - 2022-03-28 07:25:39 --> Model "Users_model" initialized
INFO - 2022-03-28 07:25:39 --> Model "Hospital_model" initialized
INFO - 2022-03-28 07:25:39 --> Upload Class Initialized
INFO - 2022-03-28 07:25:39 --> Final output sent to browser
DEBUG - 2022-03-28 07:25:39 --> Total execution time: 0.0314
ERROR - 2022-03-28 07:25:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 07:25:49 --> Config Class Initialized
INFO - 2022-03-28 07:25:49 --> Hooks Class Initialized
DEBUG - 2022-03-28 07:25:49 --> UTF-8 Support Enabled
INFO - 2022-03-28 07:25:49 --> Utf8 Class Initialized
INFO - 2022-03-28 07:25:49 --> URI Class Initialized
INFO - 2022-03-28 07:25:49 --> Router Class Initialized
INFO - 2022-03-28 07:25:49 --> Output Class Initialized
INFO - 2022-03-28 07:25:49 --> Security Class Initialized
DEBUG - 2022-03-28 07:25:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 07:25:49 --> Input Class Initialized
INFO - 2022-03-28 07:25:49 --> Language Class Initialized
INFO - 2022-03-28 07:25:49 --> Loader Class Initialized
INFO - 2022-03-28 07:25:49 --> Helper loaded: url_helper
INFO - 2022-03-28 07:25:49 --> Helper loaded: form_helper
INFO - 2022-03-28 07:25:49 --> Helper loaded: common_helper
INFO - 2022-03-28 07:25:49 --> Database Driver Class Initialized
DEBUG - 2022-03-28 07:25:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 07:25:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 07:25:49 --> Controller Class Initialized
INFO - 2022-03-28 07:25:49 --> Form Validation Class Initialized
DEBUG - 2022-03-28 07:25:49 --> Encrypt Class Initialized
INFO - 2022-03-28 07:25:49 --> Model "Patient_model" initialized
INFO - 2022-03-28 07:25:49 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 07:25:49 --> Model "Prefix_master" initialized
INFO - 2022-03-28 07:25:49 --> Model "Users_model" initialized
INFO - 2022-03-28 07:25:49 --> Model "Hospital_model" initialized
ERROR - 2022-03-28 07:25:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 07:25:49 --> Config Class Initialized
INFO - 2022-03-28 07:25:49 --> Hooks Class Initialized
DEBUG - 2022-03-28 07:25:49 --> UTF-8 Support Enabled
INFO - 2022-03-28 07:25:49 --> Utf8 Class Initialized
INFO - 2022-03-28 07:25:49 --> URI Class Initialized
INFO - 2022-03-28 07:25:49 --> Router Class Initialized
INFO - 2022-03-28 07:25:49 --> Output Class Initialized
INFO - 2022-03-28 07:25:49 --> Security Class Initialized
DEBUG - 2022-03-28 07:25:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 07:25:49 --> Input Class Initialized
INFO - 2022-03-28 07:25:49 --> Language Class Initialized
INFO - 2022-03-28 07:25:49 --> Loader Class Initialized
INFO - 2022-03-28 07:25:49 --> Helper loaded: url_helper
INFO - 2022-03-28 07:25:49 --> Helper loaded: form_helper
INFO - 2022-03-28 07:25:49 --> Helper loaded: common_helper
INFO - 2022-03-28 07:25:49 --> Database Driver Class Initialized
DEBUG - 2022-03-28 07:25:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 07:25:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 07:25:50 --> Controller Class Initialized
INFO - 2022-03-28 07:25:50 --> Form Validation Class Initialized
DEBUG - 2022-03-28 07:25:50 --> Encrypt Class Initialized
INFO - 2022-03-28 07:25:50 --> Model "Patient_model" initialized
INFO - 2022-03-28 07:25:50 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 07:25:50 --> Model "Prefix_master" initialized
INFO - 2022-03-28 07:25:50 --> Model "Users_model" initialized
INFO - 2022-03-28 07:25:50 --> Model "Hospital_model" initialized
INFO - 2022-03-28 07:25:50 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-28 07:25:50 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-28 07:25:50 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-28 07:25:50 --> Final output sent to browser
DEBUG - 2022-03-28 07:25:50 --> Total execution time: 0.1635
ERROR - 2022-03-28 07:34:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 07:34:29 --> Config Class Initialized
INFO - 2022-03-28 07:34:29 --> Hooks Class Initialized
DEBUG - 2022-03-28 07:34:29 --> UTF-8 Support Enabled
INFO - 2022-03-28 07:34:29 --> Utf8 Class Initialized
INFO - 2022-03-28 07:34:29 --> URI Class Initialized
INFO - 2022-03-28 07:34:29 --> Router Class Initialized
INFO - 2022-03-28 07:34:29 --> Output Class Initialized
INFO - 2022-03-28 07:34:29 --> Security Class Initialized
DEBUG - 2022-03-28 07:34:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 07:34:29 --> Input Class Initialized
INFO - 2022-03-28 07:34:29 --> Language Class Initialized
INFO - 2022-03-28 07:34:29 --> Loader Class Initialized
INFO - 2022-03-28 07:34:29 --> Helper loaded: url_helper
INFO - 2022-03-28 07:34:29 --> Helper loaded: form_helper
INFO - 2022-03-28 07:34:29 --> Helper loaded: common_helper
INFO - 2022-03-28 07:34:29 --> Database Driver Class Initialized
DEBUG - 2022-03-28 07:34:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 07:34:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 07:34:29 --> Controller Class Initialized
INFO - 2022-03-28 07:34:29 --> Form Validation Class Initialized
DEBUG - 2022-03-28 07:34:29 --> Encrypt Class Initialized
INFO - 2022-03-28 07:34:29 --> Model "Patient_model" initialized
INFO - 2022-03-28 07:34:29 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 07:34:29 --> Model "Prefix_master" initialized
INFO - 2022-03-28 07:34:29 --> Model "Users_model" initialized
INFO - 2022-03-28 07:34:29 --> Model "Hospital_model" initialized
ERROR - 2022-03-28 07:34:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 07:34:29 --> Config Class Initialized
INFO - 2022-03-28 07:34:29 --> Hooks Class Initialized
DEBUG - 2022-03-28 07:34:29 --> UTF-8 Support Enabled
INFO - 2022-03-28 07:34:29 --> Utf8 Class Initialized
INFO - 2022-03-28 07:34:29 --> URI Class Initialized
INFO - 2022-03-28 07:34:29 --> Router Class Initialized
INFO - 2022-03-28 07:34:29 --> Output Class Initialized
INFO - 2022-03-28 07:34:29 --> Security Class Initialized
DEBUG - 2022-03-28 07:34:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 07:34:29 --> Input Class Initialized
INFO - 2022-03-28 07:34:29 --> Language Class Initialized
INFO - 2022-03-28 07:34:29 --> Loader Class Initialized
INFO - 2022-03-28 07:34:29 --> Helper loaded: url_helper
INFO - 2022-03-28 07:34:29 --> Helper loaded: form_helper
INFO - 2022-03-28 07:34:29 --> Helper loaded: common_helper
INFO - 2022-03-28 07:34:29 --> Database Driver Class Initialized
DEBUG - 2022-03-28 07:34:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 07:34:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 07:34:29 --> Controller Class Initialized
INFO - 2022-03-28 07:34:29 --> Form Validation Class Initialized
DEBUG - 2022-03-28 07:34:29 --> Encrypt Class Initialized
INFO - 2022-03-28 07:34:29 --> Model "Patient_model" initialized
INFO - 2022-03-28 07:34:29 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 07:34:29 --> Model "Prefix_master" initialized
INFO - 2022-03-28 07:34:29 --> Model "Users_model" initialized
INFO - 2022-03-28 07:34:29 --> Model "Hospital_model" initialized
INFO - 2022-03-28 07:34:29 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-28 07:34:29 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-28 07:34:29 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-28 07:34:29 --> Final output sent to browser
DEBUG - 2022-03-28 07:34:29 --> Total execution time: 0.0451
ERROR - 2022-03-28 07:34:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 07:34:37 --> Config Class Initialized
INFO - 2022-03-28 07:34:37 --> Hooks Class Initialized
DEBUG - 2022-03-28 07:34:37 --> UTF-8 Support Enabled
INFO - 2022-03-28 07:34:37 --> Utf8 Class Initialized
INFO - 2022-03-28 07:34:37 --> URI Class Initialized
INFO - 2022-03-28 07:34:37 --> Router Class Initialized
INFO - 2022-03-28 07:34:37 --> Output Class Initialized
INFO - 2022-03-28 07:34:37 --> Security Class Initialized
DEBUG - 2022-03-28 07:34:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 07:34:37 --> Input Class Initialized
INFO - 2022-03-28 07:34:37 --> Language Class Initialized
INFO - 2022-03-28 07:34:37 --> Loader Class Initialized
INFO - 2022-03-28 07:34:37 --> Helper loaded: url_helper
INFO - 2022-03-28 07:34:37 --> Helper loaded: form_helper
INFO - 2022-03-28 07:34:37 --> Helper loaded: common_helper
INFO - 2022-03-28 07:34:37 --> Database Driver Class Initialized
DEBUG - 2022-03-28 07:34:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 07:34:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 07:34:37 --> Controller Class Initialized
INFO - 2022-03-28 07:34:37 --> Form Validation Class Initialized
DEBUG - 2022-03-28 07:34:37 --> Encrypt Class Initialized
DEBUG - 2022-03-28 07:34:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-28 07:34:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-28 07:34:37 --> Email Class Initialized
INFO - 2022-03-28 07:34:37 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-28 07:34:37 --> Calendar Class Initialized
INFO - 2022-03-28 07:34:37 --> Model "Login_model" initialized
ERROR - 2022-03-28 07:34:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 07:34:38 --> Config Class Initialized
INFO - 2022-03-28 07:34:38 --> Hooks Class Initialized
DEBUG - 2022-03-28 07:34:38 --> UTF-8 Support Enabled
INFO - 2022-03-28 07:34:38 --> Utf8 Class Initialized
INFO - 2022-03-28 07:34:38 --> URI Class Initialized
INFO - 2022-03-28 07:34:38 --> Router Class Initialized
INFO - 2022-03-28 07:34:38 --> Output Class Initialized
INFO - 2022-03-28 07:34:38 --> Security Class Initialized
DEBUG - 2022-03-28 07:34:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 07:34:38 --> Input Class Initialized
INFO - 2022-03-28 07:34:38 --> Language Class Initialized
INFO - 2022-03-28 07:34:38 --> Loader Class Initialized
INFO - 2022-03-28 07:34:38 --> Helper loaded: url_helper
INFO - 2022-03-28 07:34:38 --> Helper loaded: form_helper
INFO - 2022-03-28 07:34:38 --> Helper loaded: common_helper
INFO - 2022-03-28 07:34:38 --> Database Driver Class Initialized
DEBUG - 2022-03-28 07:34:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 07:34:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 07:34:38 --> Controller Class Initialized
INFO - 2022-03-28 07:34:38 --> Form Validation Class Initialized
DEBUG - 2022-03-28 07:34:38 --> Encrypt Class Initialized
DEBUG - 2022-03-28 07:34:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-28 07:34:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-28 07:34:38 --> Email Class Initialized
INFO - 2022-03-28 07:34:38 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-28 07:34:38 --> Calendar Class Initialized
INFO - 2022-03-28 07:34:38 --> Model "Login_model" initialized
INFO - 2022-03-28 07:34:38 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-28 07:34:38 --> Final output sent to browser
DEBUG - 2022-03-28 07:34:38 --> Total execution time: 0.0085
ERROR - 2022-03-28 08:08:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 08:08:07 --> Config Class Initialized
INFO - 2022-03-28 08:08:07 --> Hooks Class Initialized
DEBUG - 2022-03-28 08:08:07 --> UTF-8 Support Enabled
INFO - 2022-03-28 08:08:07 --> Utf8 Class Initialized
INFO - 2022-03-28 08:08:07 --> URI Class Initialized
DEBUG - 2022-03-28 08:08:07 --> No URI present. Default controller set.
INFO - 2022-03-28 08:08:07 --> Router Class Initialized
INFO - 2022-03-28 08:08:07 --> Output Class Initialized
INFO - 2022-03-28 08:08:07 --> Security Class Initialized
DEBUG - 2022-03-28 08:08:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 08:08:07 --> Input Class Initialized
INFO - 2022-03-28 08:08:07 --> Language Class Initialized
INFO - 2022-03-28 08:08:07 --> Loader Class Initialized
INFO - 2022-03-28 08:08:07 --> Helper loaded: url_helper
INFO - 2022-03-28 08:08:07 --> Helper loaded: form_helper
INFO - 2022-03-28 08:08:07 --> Helper loaded: common_helper
INFO - 2022-03-28 08:08:07 --> Database Driver Class Initialized
DEBUG - 2022-03-28 08:08:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 08:08:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 08:08:07 --> Controller Class Initialized
INFO - 2022-03-28 08:08:07 --> Form Validation Class Initialized
DEBUG - 2022-03-28 08:08:07 --> Encrypt Class Initialized
DEBUG - 2022-03-28 08:08:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-28 08:08:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-28 08:08:07 --> Email Class Initialized
INFO - 2022-03-28 08:08:07 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-28 08:08:07 --> Calendar Class Initialized
INFO - 2022-03-28 08:08:07 --> Model "Login_model" initialized
INFO - 2022-03-28 08:08:07 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-28 08:08:07 --> Final output sent to browser
DEBUG - 2022-03-28 08:08:07 --> Total execution time: 0.0658
ERROR - 2022-03-28 11:58:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 11:58:23 --> Config Class Initialized
INFO - 2022-03-28 11:58:23 --> Hooks Class Initialized
DEBUG - 2022-03-28 11:58:23 --> UTF-8 Support Enabled
INFO - 2022-03-28 11:58:23 --> Utf8 Class Initialized
INFO - 2022-03-28 11:58:23 --> URI Class Initialized
DEBUG - 2022-03-28 11:58:23 --> No URI present. Default controller set.
INFO - 2022-03-28 11:58:23 --> Router Class Initialized
INFO - 2022-03-28 11:58:23 --> Output Class Initialized
INFO - 2022-03-28 11:58:23 --> Security Class Initialized
DEBUG - 2022-03-28 11:58:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 11:58:23 --> Input Class Initialized
INFO - 2022-03-28 11:58:23 --> Language Class Initialized
INFO - 2022-03-28 11:58:23 --> Loader Class Initialized
INFO - 2022-03-28 11:58:23 --> Helper loaded: url_helper
INFO - 2022-03-28 11:58:23 --> Helper loaded: form_helper
INFO - 2022-03-28 11:58:23 --> Helper loaded: common_helper
INFO - 2022-03-28 11:58:23 --> Database Driver Class Initialized
DEBUG - 2022-03-28 11:58:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 11:58:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 11:58:23 --> Controller Class Initialized
INFO - 2022-03-28 11:58:23 --> Form Validation Class Initialized
DEBUG - 2022-03-28 11:58:23 --> Encrypt Class Initialized
DEBUG - 2022-03-28 11:58:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-28 11:58:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-28 11:58:23 --> Email Class Initialized
INFO - 2022-03-28 11:58:23 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-28 11:58:23 --> Calendar Class Initialized
INFO - 2022-03-28 11:58:23 --> Model "Login_model" initialized
INFO - 2022-03-28 11:58:23 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-28 11:58:23 --> Final output sent to browser
DEBUG - 2022-03-28 11:58:23 --> Total execution time: 0.0815
ERROR - 2022-03-28 12:52:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 12:52:12 --> Config Class Initialized
INFO - 2022-03-28 12:52:12 --> Hooks Class Initialized
DEBUG - 2022-03-28 12:52:12 --> UTF-8 Support Enabled
INFO - 2022-03-28 12:52:12 --> Utf8 Class Initialized
INFO - 2022-03-28 12:52:12 --> URI Class Initialized
DEBUG - 2022-03-28 12:52:12 --> No URI present. Default controller set.
INFO - 2022-03-28 12:52:12 --> Router Class Initialized
INFO - 2022-03-28 12:52:12 --> Output Class Initialized
INFO - 2022-03-28 12:52:12 --> Security Class Initialized
DEBUG - 2022-03-28 12:52:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 12:52:12 --> Input Class Initialized
INFO - 2022-03-28 12:52:12 --> Language Class Initialized
INFO - 2022-03-28 12:52:12 --> Loader Class Initialized
INFO - 2022-03-28 12:52:12 --> Helper loaded: url_helper
INFO - 2022-03-28 12:52:12 --> Helper loaded: form_helper
INFO - 2022-03-28 12:52:12 --> Helper loaded: common_helper
INFO - 2022-03-28 12:52:12 --> Database Driver Class Initialized
DEBUG - 2022-03-28 12:52:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 12:52:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 12:52:12 --> Controller Class Initialized
INFO - 2022-03-28 12:52:12 --> Form Validation Class Initialized
DEBUG - 2022-03-28 12:52:12 --> Encrypt Class Initialized
DEBUG - 2022-03-28 12:52:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-28 12:52:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-28 12:52:12 --> Email Class Initialized
INFO - 2022-03-28 12:52:12 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-28 12:52:12 --> Calendar Class Initialized
INFO - 2022-03-28 12:52:12 --> Model "Login_model" initialized
INFO - 2022-03-28 12:52:12 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-28 12:52:12 --> Final output sent to browser
DEBUG - 2022-03-28 12:52:12 --> Total execution time: 0.0535
ERROR - 2022-03-28 14:19:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 14:19:32 --> Config Class Initialized
INFO - 2022-03-28 14:19:32 --> Hooks Class Initialized
DEBUG - 2022-03-28 14:19:32 --> UTF-8 Support Enabled
INFO - 2022-03-28 14:19:32 --> Utf8 Class Initialized
INFO - 2022-03-28 14:19:32 --> URI Class Initialized
DEBUG - 2022-03-28 14:19:32 --> No URI present. Default controller set.
INFO - 2022-03-28 14:19:32 --> Router Class Initialized
INFO - 2022-03-28 14:19:32 --> Output Class Initialized
INFO - 2022-03-28 14:19:32 --> Security Class Initialized
DEBUG - 2022-03-28 14:19:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 14:19:32 --> Input Class Initialized
INFO - 2022-03-28 14:19:32 --> Language Class Initialized
INFO - 2022-03-28 14:19:32 --> Loader Class Initialized
INFO - 2022-03-28 14:19:32 --> Helper loaded: url_helper
INFO - 2022-03-28 14:19:32 --> Helper loaded: form_helper
INFO - 2022-03-28 14:19:32 --> Helper loaded: common_helper
INFO - 2022-03-28 14:19:32 --> Database Driver Class Initialized
DEBUG - 2022-03-28 14:19:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 14:19:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 14:19:32 --> Controller Class Initialized
INFO - 2022-03-28 14:19:32 --> Form Validation Class Initialized
DEBUG - 2022-03-28 14:19:32 --> Encrypt Class Initialized
DEBUG - 2022-03-28 14:19:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-28 14:19:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-28 14:19:32 --> Email Class Initialized
INFO - 2022-03-28 14:19:32 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-28 14:19:32 --> Calendar Class Initialized
INFO - 2022-03-28 14:19:32 --> Model "Login_model" initialized
INFO - 2022-03-28 14:19:32 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-28 14:19:32 --> Final output sent to browser
DEBUG - 2022-03-28 14:19:32 --> Total execution time: 0.0969
ERROR - 2022-03-28 14:19:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 14:19:34 --> Config Class Initialized
INFO - 2022-03-28 14:19:34 --> Hooks Class Initialized
DEBUG - 2022-03-28 14:19:34 --> UTF-8 Support Enabled
INFO - 2022-03-28 14:19:34 --> Utf8 Class Initialized
INFO - 2022-03-28 14:19:34 --> URI Class Initialized
INFO - 2022-03-28 14:19:34 --> Router Class Initialized
INFO - 2022-03-28 14:19:34 --> Output Class Initialized
INFO - 2022-03-28 14:19:34 --> Security Class Initialized
DEBUG - 2022-03-28 14:19:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 14:19:34 --> Input Class Initialized
INFO - 2022-03-28 14:19:34 --> Language Class Initialized
ERROR - 2022-03-28 14:19:34 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2022-03-28 14:19:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 14:19:45 --> Config Class Initialized
INFO - 2022-03-28 14:19:45 --> Hooks Class Initialized
DEBUG - 2022-03-28 14:19:45 --> UTF-8 Support Enabled
INFO - 2022-03-28 14:19:45 --> Utf8 Class Initialized
INFO - 2022-03-28 14:19:45 --> URI Class Initialized
INFO - 2022-03-28 14:19:45 --> Router Class Initialized
INFO - 2022-03-28 14:19:45 --> Output Class Initialized
INFO - 2022-03-28 14:19:45 --> Security Class Initialized
DEBUG - 2022-03-28 14:19:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 14:19:45 --> Input Class Initialized
INFO - 2022-03-28 14:19:45 --> Language Class Initialized
INFO - 2022-03-28 14:19:45 --> Loader Class Initialized
INFO - 2022-03-28 14:19:45 --> Helper loaded: url_helper
INFO - 2022-03-28 14:19:45 --> Helper loaded: form_helper
INFO - 2022-03-28 14:19:45 --> Helper loaded: common_helper
INFO - 2022-03-28 14:19:45 --> Database Driver Class Initialized
DEBUG - 2022-03-28 14:19:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 14:19:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 14:19:45 --> Controller Class Initialized
INFO - 2022-03-28 14:19:45 --> Form Validation Class Initialized
DEBUG - 2022-03-28 14:19:45 --> Encrypt Class Initialized
DEBUG - 2022-03-28 14:19:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-28 14:19:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-28 14:19:45 --> Email Class Initialized
INFO - 2022-03-28 14:19:45 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-28 14:19:45 --> Calendar Class Initialized
INFO - 2022-03-28 14:19:45 --> Model "Login_model" initialized
ERROR - 2022-03-28 14:19:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 14:19:45 --> Config Class Initialized
INFO - 2022-03-28 14:19:45 --> Hooks Class Initialized
DEBUG - 2022-03-28 14:19:45 --> UTF-8 Support Enabled
INFO - 2022-03-28 14:19:45 --> Utf8 Class Initialized
INFO - 2022-03-28 14:19:45 --> URI Class Initialized
INFO - 2022-03-28 14:19:45 --> Router Class Initialized
INFO - 2022-03-28 14:19:45 --> Output Class Initialized
INFO - 2022-03-28 14:19:45 --> Security Class Initialized
DEBUG - 2022-03-28 14:19:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 14:19:45 --> Input Class Initialized
INFO - 2022-03-28 14:19:45 --> Language Class Initialized
INFO - 2022-03-28 14:19:45 --> Loader Class Initialized
INFO - 2022-03-28 14:19:45 --> Helper loaded: url_helper
INFO - 2022-03-28 14:19:45 --> Helper loaded: form_helper
INFO - 2022-03-28 14:19:45 --> Helper loaded: common_helper
INFO - 2022-03-28 14:19:45 --> Database Driver Class Initialized
DEBUG - 2022-03-28 14:19:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 14:19:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 14:19:45 --> Controller Class Initialized
INFO - 2022-03-28 14:19:45 --> Form Validation Class Initialized
DEBUG - 2022-03-28 14:19:45 --> Encrypt Class Initialized
DEBUG - 2022-03-28 14:19:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-28 14:19:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-28 14:19:45 --> Email Class Initialized
INFO - 2022-03-28 14:19:45 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-28 14:19:45 --> Calendar Class Initialized
INFO - 2022-03-28 14:19:45 --> Model "Login_model" initialized
ERROR - 2022-03-28 14:19:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 14:19:45 --> Config Class Initialized
INFO - 2022-03-28 14:19:45 --> Hooks Class Initialized
DEBUG - 2022-03-28 14:19:45 --> UTF-8 Support Enabled
INFO - 2022-03-28 14:19:45 --> Utf8 Class Initialized
INFO - 2022-03-28 14:19:45 --> URI Class Initialized
INFO - 2022-03-28 14:19:45 --> Router Class Initialized
INFO - 2022-03-28 14:19:45 --> Output Class Initialized
INFO - 2022-03-28 14:19:45 --> Security Class Initialized
DEBUG - 2022-03-28 14:19:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 14:19:45 --> Input Class Initialized
INFO - 2022-03-28 14:19:45 --> Language Class Initialized
INFO - 2022-03-28 14:19:45 --> Loader Class Initialized
INFO - 2022-03-28 14:19:45 --> Helper loaded: url_helper
INFO - 2022-03-28 14:19:45 --> Helper loaded: form_helper
INFO - 2022-03-28 14:19:45 --> Helper loaded: common_helper
INFO - 2022-03-28 14:19:45 --> Database Driver Class Initialized
DEBUG - 2022-03-28 14:19:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 14:19:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 14:19:45 --> Controller Class Initialized
INFO - 2022-03-28 14:19:45 --> Form Validation Class Initialized
DEBUG - 2022-03-28 14:19:45 --> Encrypt Class Initialized
DEBUG - 2022-03-28 14:19:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-28 14:19:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-28 14:19:45 --> Email Class Initialized
INFO - 2022-03-28 14:19:45 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-28 14:19:45 --> Calendar Class Initialized
INFO - 2022-03-28 14:19:45 --> Model "Login_model" initialized
INFO - 2022-03-28 14:19:45 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-28 14:19:45 --> Final output sent to browser
DEBUG - 2022-03-28 14:19:45 --> Total execution time: 0.0098
ERROR - 2022-03-28 14:19:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 14:19:45 --> Config Class Initialized
INFO - 2022-03-28 14:19:45 --> Hooks Class Initialized
DEBUG - 2022-03-28 14:19:45 --> UTF-8 Support Enabled
INFO - 2022-03-28 14:19:45 --> Utf8 Class Initialized
INFO - 2022-03-28 14:19:45 --> URI Class Initialized
DEBUG - 2022-03-28 14:19:45 --> No URI present. Default controller set.
INFO - 2022-03-28 14:19:45 --> Router Class Initialized
INFO - 2022-03-28 14:19:45 --> Output Class Initialized
INFO - 2022-03-28 14:19:45 --> Security Class Initialized
DEBUG - 2022-03-28 14:19:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 14:19:45 --> Input Class Initialized
INFO - 2022-03-28 14:19:45 --> Language Class Initialized
INFO - 2022-03-28 14:19:45 --> Loader Class Initialized
INFO - 2022-03-28 14:19:45 --> Helper loaded: url_helper
INFO - 2022-03-28 14:19:45 --> Helper loaded: form_helper
INFO - 2022-03-28 14:19:45 --> Helper loaded: common_helper
INFO - 2022-03-28 14:19:45 --> Database Driver Class Initialized
DEBUG - 2022-03-28 14:19:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 14:19:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 14:19:45 --> Controller Class Initialized
INFO - 2022-03-28 14:19:45 --> Form Validation Class Initialized
DEBUG - 2022-03-28 14:19:45 --> Encrypt Class Initialized
DEBUG - 2022-03-28 14:19:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-28 14:19:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-28 14:19:45 --> Email Class Initialized
INFO - 2022-03-28 14:19:45 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-28 14:19:45 --> Calendar Class Initialized
INFO - 2022-03-28 14:19:45 --> Model "Login_model" initialized
INFO - 2022-03-28 14:19:45 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-28 14:19:45 --> Final output sent to browser
DEBUG - 2022-03-28 14:19:45 --> Total execution time: 0.0173
ERROR - 2022-03-28 15:48:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 15:48:15 --> Config Class Initialized
INFO - 2022-03-28 15:48:15 --> Hooks Class Initialized
DEBUG - 2022-03-28 15:48:15 --> UTF-8 Support Enabled
INFO - 2022-03-28 15:48:15 --> Utf8 Class Initialized
INFO - 2022-03-28 15:48:15 --> URI Class Initialized
DEBUG - 2022-03-28 15:48:15 --> No URI present. Default controller set.
INFO - 2022-03-28 15:48:15 --> Router Class Initialized
INFO - 2022-03-28 15:48:15 --> Output Class Initialized
INFO - 2022-03-28 15:48:15 --> Security Class Initialized
DEBUG - 2022-03-28 15:48:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 15:48:15 --> Input Class Initialized
INFO - 2022-03-28 15:48:15 --> Language Class Initialized
INFO - 2022-03-28 15:48:15 --> Loader Class Initialized
INFO - 2022-03-28 15:48:15 --> Helper loaded: url_helper
INFO - 2022-03-28 15:48:15 --> Helper loaded: form_helper
INFO - 2022-03-28 15:48:15 --> Helper loaded: common_helper
INFO - 2022-03-28 15:48:15 --> Database Driver Class Initialized
DEBUG - 2022-03-28 15:48:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 15:48:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 15:48:15 --> Controller Class Initialized
INFO - 2022-03-28 15:48:15 --> Form Validation Class Initialized
DEBUG - 2022-03-28 15:48:15 --> Encrypt Class Initialized
DEBUG - 2022-03-28 15:48:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-28 15:48:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-28 15:48:15 --> Email Class Initialized
INFO - 2022-03-28 15:48:15 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-28 15:48:15 --> Calendar Class Initialized
INFO - 2022-03-28 15:48:15 --> Model "Login_model" initialized
INFO - 2022-03-28 15:48:15 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-28 15:48:15 --> Final output sent to browser
DEBUG - 2022-03-28 15:48:15 --> Total execution time: 0.0617
ERROR - 2022-03-28 15:53:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 15:53:34 --> Config Class Initialized
INFO - 2022-03-28 15:53:34 --> Hooks Class Initialized
DEBUG - 2022-03-28 15:53:34 --> UTF-8 Support Enabled
INFO - 2022-03-28 15:53:34 --> Utf8 Class Initialized
INFO - 2022-03-28 15:53:34 --> URI Class Initialized
DEBUG - 2022-03-28 15:53:34 --> No URI present. Default controller set.
INFO - 2022-03-28 15:53:34 --> Router Class Initialized
INFO - 2022-03-28 15:53:34 --> Output Class Initialized
INFO - 2022-03-28 15:53:34 --> Security Class Initialized
DEBUG - 2022-03-28 15:53:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 15:53:34 --> Input Class Initialized
INFO - 2022-03-28 15:53:34 --> Language Class Initialized
INFO - 2022-03-28 15:53:34 --> Loader Class Initialized
INFO - 2022-03-28 15:53:34 --> Helper loaded: url_helper
INFO - 2022-03-28 15:53:34 --> Helper loaded: form_helper
INFO - 2022-03-28 15:53:34 --> Helper loaded: common_helper
INFO - 2022-03-28 15:53:34 --> Database Driver Class Initialized
DEBUG - 2022-03-28 15:53:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 15:53:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 15:53:34 --> Controller Class Initialized
INFO - 2022-03-28 15:53:34 --> Form Validation Class Initialized
DEBUG - 2022-03-28 15:53:34 --> Encrypt Class Initialized
DEBUG - 2022-03-28 15:53:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-28 15:53:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-28 15:53:34 --> Email Class Initialized
INFO - 2022-03-28 15:53:34 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-28 15:53:34 --> Calendar Class Initialized
INFO - 2022-03-28 15:53:34 --> Model "Login_model" initialized
INFO - 2022-03-28 15:53:34 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-28 15:53:34 --> Final output sent to browser
DEBUG - 2022-03-28 15:53:34 --> Total execution time: 0.0649
ERROR - 2022-03-28 23:05:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 23:05:22 --> Config Class Initialized
INFO - 2022-03-28 23:05:22 --> Hooks Class Initialized
DEBUG - 2022-03-28 23:05:22 --> UTF-8 Support Enabled
INFO - 2022-03-28 23:05:22 --> Utf8 Class Initialized
INFO - 2022-03-28 23:05:22 --> URI Class Initialized
DEBUG - 2022-03-28 23:05:22 --> No URI present. Default controller set.
INFO - 2022-03-28 23:05:22 --> Router Class Initialized
INFO - 2022-03-28 23:05:22 --> Output Class Initialized
INFO - 2022-03-28 23:05:22 --> Security Class Initialized
DEBUG - 2022-03-28 23:05:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 23:05:22 --> Input Class Initialized
INFO - 2022-03-28 23:05:22 --> Language Class Initialized
INFO - 2022-03-28 23:05:22 --> Loader Class Initialized
INFO - 2022-03-28 23:05:22 --> Helper loaded: url_helper
INFO - 2022-03-28 23:05:22 --> Helper loaded: form_helper
INFO - 2022-03-28 23:05:22 --> Helper loaded: common_helper
INFO - 2022-03-28 23:05:22 --> Database Driver Class Initialized
DEBUG - 2022-03-28 23:05:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 23:05:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 23:05:22 --> Controller Class Initialized
INFO - 2022-03-28 23:05:22 --> Form Validation Class Initialized
DEBUG - 2022-03-28 23:05:22 --> Encrypt Class Initialized
DEBUG - 2022-03-28 23:05:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-28 23:05:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-28 23:05:22 --> Email Class Initialized
INFO - 2022-03-28 23:05:22 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-28 23:05:22 --> Calendar Class Initialized
INFO - 2022-03-28 23:05:22 --> Model "Login_model" initialized
INFO - 2022-03-28 23:05:22 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-28 23:05:22 --> Final output sent to browser
DEBUG - 2022-03-28 23:05:22 --> Total execution time: 0.0584
ERROR - 2022-03-28 23:24:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 23:24:27 --> Config Class Initialized
INFO - 2022-03-28 23:24:27 --> Hooks Class Initialized
DEBUG - 2022-03-28 23:24:27 --> UTF-8 Support Enabled
INFO - 2022-03-28 23:24:27 --> Utf8 Class Initialized
INFO - 2022-03-28 23:24:27 --> URI Class Initialized
INFO - 2022-03-28 23:24:27 --> Router Class Initialized
INFO - 2022-03-28 23:24:27 --> Output Class Initialized
INFO - 2022-03-28 23:24:27 --> Security Class Initialized
DEBUG - 2022-03-28 23:24:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 23:24:27 --> Input Class Initialized
INFO - 2022-03-28 23:24:27 --> Language Class Initialized
INFO - 2022-03-28 23:24:27 --> Loader Class Initialized
INFO - 2022-03-28 23:24:27 --> Helper loaded: url_helper
INFO - 2022-03-28 23:24:27 --> Helper loaded: form_helper
INFO - 2022-03-28 23:24:27 --> Helper loaded: common_helper
INFO - 2022-03-28 23:24:27 --> Database Driver Class Initialized
DEBUG - 2022-03-28 23:24:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 23:24:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 23:24:27 --> Controller Class Initialized
ERROR - 2022-03-28 23:24:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 23:24:28 --> Config Class Initialized
INFO - 2022-03-28 23:24:28 --> Hooks Class Initialized
DEBUG - 2022-03-28 23:24:28 --> UTF-8 Support Enabled
INFO - 2022-03-28 23:24:28 --> Utf8 Class Initialized
INFO - 2022-03-28 23:24:28 --> URI Class Initialized
INFO - 2022-03-28 23:24:28 --> Router Class Initialized
INFO - 2022-03-28 23:24:28 --> Output Class Initialized
INFO - 2022-03-28 23:24:28 --> Security Class Initialized
DEBUG - 2022-03-28 23:24:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 23:24:28 --> Input Class Initialized
INFO - 2022-03-28 23:24:28 --> Language Class Initialized
INFO - 2022-03-28 23:24:28 --> Loader Class Initialized
INFO - 2022-03-28 23:24:28 --> Helper loaded: url_helper
INFO - 2022-03-28 23:24:28 --> Helper loaded: form_helper
INFO - 2022-03-28 23:24:28 --> Helper loaded: common_helper
INFO - 2022-03-28 23:24:28 --> Database Driver Class Initialized
DEBUG - 2022-03-28 23:24:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 23:24:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 23:24:28 --> Controller Class Initialized
INFO - 2022-03-28 23:24:28 --> Form Validation Class Initialized
DEBUG - 2022-03-28 23:24:28 --> Encrypt Class Initialized
DEBUG - 2022-03-28 23:24:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-28 23:24:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-28 23:24:28 --> Email Class Initialized
INFO - 2022-03-28 23:24:28 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-28 23:24:28 --> Calendar Class Initialized
INFO - 2022-03-28 23:24:28 --> Model "Login_model" initialized
INFO - 2022-03-28 23:24:28 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-28 23:24:28 --> Final output sent to browser
DEBUG - 2022-03-28 23:24:28 --> Total execution time: 0.0237
ERROR - 2022-03-28 23:24:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 23:24:39 --> Config Class Initialized
INFO - 2022-03-28 23:24:39 --> Hooks Class Initialized
DEBUG - 2022-03-28 23:24:39 --> UTF-8 Support Enabled
INFO - 2022-03-28 23:24:39 --> Utf8 Class Initialized
INFO - 2022-03-28 23:24:39 --> URI Class Initialized
INFO - 2022-03-28 23:24:39 --> Router Class Initialized
INFO - 2022-03-28 23:24:39 --> Output Class Initialized
INFO - 2022-03-28 23:24:39 --> Security Class Initialized
DEBUG - 2022-03-28 23:24:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 23:24:39 --> Input Class Initialized
INFO - 2022-03-28 23:24:39 --> Language Class Initialized
INFO - 2022-03-28 23:24:39 --> Loader Class Initialized
INFO - 2022-03-28 23:24:39 --> Helper loaded: url_helper
INFO - 2022-03-28 23:24:39 --> Helper loaded: form_helper
INFO - 2022-03-28 23:24:39 --> Helper loaded: common_helper
INFO - 2022-03-28 23:24:39 --> Database Driver Class Initialized
DEBUG - 2022-03-28 23:24:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 23:24:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 23:24:39 --> Controller Class Initialized
INFO - 2022-03-28 23:24:39 --> Form Validation Class Initialized
DEBUG - 2022-03-28 23:24:39 --> Encrypt Class Initialized
DEBUG - 2022-03-28 23:24:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-28 23:24:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-28 23:24:39 --> Email Class Initialized
INFO - 2022-03-28 23:24:39 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-28 23:24:39 --> Calendar Class Initialized
INFO - 2022-03-28 23:24:39 --> Model "Login_model" initialized
INFO - 2022-03-28 23:24:39 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-03-28 23:24:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 23:24:40 --> Config Class Initialized
INFO - 2022-03-28 23:24:40 --> Hooks Class Initialized
DEBUG - 2022-03-28 23:24:40 --> UTF-8 Support Enabled
INFO - 2022-03-28 23:24:40 --> Utf8 Class Initialized
INFO - 2022-03-28 23:24:40 --> URI Class Initialized
INFO - 2022-03-28 23:24:40 --> Router Class Initialized
INFO - 2022-03-28 23:24:40 --> Output Class Initialized
INFO - 2022-03-28 23:24:40 --> Security Class Initialized
DEBUG - 2022-03-28 23:24:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 23:24:40 --> Input Class Initialized
INFO - 2022-03-28 23:24:40 --> Language Class Initialized
INFO - 2022-03-28 23:24:40 --> Loader Class Initialized
INFO - 2022-03-28 23:24:40 --> Helper loaded: url_helper
INFO - 2022-03-28 23:24:40 --> Helper loaded: form_helper
INFO - 2022-03-28 23:24:40 --> Helper loaded: common_helper
INFO - 2022-03-28 23:24:40 --> Database Driver Class Initialized
DEBUG - 2022-03-28 23:24:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 23:24:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 23:24:40 --> Controller Class Initialized
INFO - 2022-03-28 23:24:40 --> Form Validation Class Initialized
DEBUG - 2022-03-28 23:24:40 --> Encrypt Class Initialized
INFO - 2022-03-28 23:24:40 --> Model "Login_model" initialized
INFO - 2022-03-28 23:24:40 --> Model "Dashboard_model" initialized
INFO - 2022-03-28 23:24:40 --> Model "Case_model" initialized
INFO - 2022-03-28 23:24:40 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-28 23:24:40 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2022-03-28 23:24:40 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-28 23:24:40 --> Final output sent to browser
DEBUG - 2022-03-28 23:24:40 --> Total execution time: 0.7722
ERROR - 2022-03-28 23:25:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 23:25:26 --> Config Class Initialized
INFO - 2022-03-28 23:25:26 --> Hooks Class Initialized
DEBUG - 2022-03-28 23:25:26 --> UTF-8 Support Enabled
INFO - 2022-03-28 23:25:26 --> Utf8 Class Initialized
INFO - 2022-03-28 23:25:26 --> URI Class Initialized
DEBUG - 2022-03-28 23:25:26 --> No URI present. Default controller set.
INFO - 2022-03-28 23:25:26 --> Router Class Initialized
INFO - 2022-03-28 23:25:26 --> Output Class Initialized
INFO - 2022-03-28 23:25:26 --> Security Class Initialized
DEBUG - 2022-03-28 23:25:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 23:25:26 --> Input Class Initialized
INFO - 2022-03-28 23:25:26 --> Language Class Initialized
INFO - 2022-03-28 23:25:26 --> Loader Class Initialized
INFO - 2022-03-28 23:25:26 --> Helper loaded: url_helper
INFO - 2022-03-28 23:25:26 --> Helper loaded: form_helper
INFO - 2022-03-28 23:25:26 --> Helper loaded: common_helper
INFO - 2022-03-28 23:25:26 --> Database Driver Class Initialized
DEBUG - 2022-03-28 23:25:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 23:25:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 23:25:26 --> Controller Class Initialized
INFO - 2022-03-28 23:25:26 --> Form Validation Class Initialized
DEBUG - 2022-03-28 23:25:26 --> Encrypt Class Initialized
DEBUG - 2022-03-28 23:25:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-28 23:25:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-28 23:25:26 --> Email Class Initialized
INFO - 2022-03-28 23:25:26 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-28 23:25:26 --> Calendar Class Initialized
INFO - 2022-03-28 23:25:26 --> Model "Login_model" initialized
INFO - 2022-03-28 23:25:26 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-28 23:25:26 --> Final output sent to browser
DEBUG - 2022-03-28 23:25:26 --> Total execution time: 0.0075
ERROR - 2022-03-28 23:25:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 23:25:29 --> Config Class Initialized
INFO - 2022-03-28 23:25:29 --> Hooks Class Initialized
DEBUG - 2022-03-28 23:25:29 --> UTF-8 Support Enabled
INFO - 2022-03-28 23:25:29 --> Utf8 Class Initialized
INFO - 2022-03-28 23:25:29 --> URI Class Initialized
DEBUG - 2022-03-28 23:25:29 --> No URI present. Default controller set.
INFO - 2022-03-28 23:25:29 --> Router Class Initialized
INFO - 2022-03-28 23:25:29 --> Output Class Initialized
INFO - 2022-03-28 23:25:29 --> Security Class Initialized
DEBUG - 2022-03-28 23:25:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 23:25:29 --> Input Class Initialized
INFO - 2022-03-28 23:25:29 --> Language Class Initialized
INFO - 2022-03-28 23:25:29 --> Loader Class Initialized
INFO - 2022-03-28 23:25:29 --> Helper loaded: url_helper
INFO - 2022-03-28 23:25:29 --> Helper loaded: form_helper
INFO - 2022-03-28 23:25:29 --> Helper loaded: common_helper
INFO - 2022-03-28 23:25:29 --> Database Driver Class Initialized
DEBUG - 2022-03-28 23:25:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 23:25:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 23:25:29 --> Controller Class Initialized
INFO - 2022-03-28 23:25:29 --> Form Validation Class Initialized
DEBUG - 2022-03-28 23:25:29 --> Encrypt Class Initialized
DEBUG - 2022-03-28 23:25:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-28 23:25:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-28 23:25:29 --> Email Class Initialized
INFO - 2022-03-28 23:25:29 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-28 23:25:29 --> Calendar Class Initialized
INFO - 2022-03-28 23:25:29 --> Model "Login_model" initialized
INFO - 2022-03-28 23:25:29 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-28 23:25:29 --> Final output sent to browser
DEBUG - 2022-03-28 23:25:29 --> Total execution time: 0.0071
ERROR - 2022-03-28 23:25:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 23:25:43 --> Config Class Initialized
INFO - 2022-03-28 23:25:43 --> Hooks Class Initialized
DEBUG - 2022-03-28 23:25:43 --> UTF-8 Support Enabled
INFO - 2022-03-28 23:25:43 --> Utf8 Class Initialized
INFO - 2022-03-28 23:25:43 --> URI Class Initialized
INFO - 2022-03-28 23:25:43 --> Router Class Initialized
INFO - 2022-03-28 23:25:43 --> Output Class Initialized
INFO - 2022-03-28 23:25:43 --> Security Class Initialized
DEBUG - 2022-03-28 23:25:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 23:25:43 --> Input Class Initialized
INFO - 2022-03-28 23:25:43 --> Language Class Initialized
INFO - 2022-03-28 23:25:43 --> Loader Class Initialized
INFO - 2022-03-28 23:25:43 --> Helper loaded: url_helper
INFO - 2022-03-28 23:25:43 --> Helper loaded: form_helper
INFO - 2022-03-28 23:25:43 --> Helper loaded: common_helper
INFO - 2022-03-28 23:25:43 --> Database Driver Class Initialized
DEBUG - 2022-03-28 23:25:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 23:25:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 23:25:43 --> Controller Class Initialized
INFO - 2022-03-28 23:25:43 --> Form Validation Class Initialized
DEBUG - 2022-03-28 23:25:43 --> Encrypt Class Initialized
DEBUG - 2022-03-28 23:25:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-28 23:25:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-28 23:25:43 --> Email Class Initialized
INFO - 2022-03-28 23:25:43 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-28 23:25:43 --> Calendar Class Initialized
INFO - 2022-03-28 23:25:43 --> Model "Login_model" initialized
INFO - 2022-03-28 23:25:43 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-03-28 23:25:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 23:25:43 --> Config Class Initialized
INFO - 2022-03-28 23:25:43 --> Hooks Class Initialized
DEBUG - 2022-03-28 23:25:43 --> UTF-8 Support Enabled
INFO - 2022-03-28 23:25:43 --> Utf8 Class Initialized
INFO - 2022-03-28 23:25:43 --> URI Class Initialized
INFO - 2022-03-28 23:25:43 --> Router Class Initialized
INFO - 2022-03-28 23:25:43 --> Output Class Initialized
INFO - 2022-03-28 23:25:43 --> Security Class Initialized
DEBUG - 2022-03-28 23:25:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 23:25:43 --> Input Class Initialized
INFO - 2022-03-28 23:25:43 --> Language Class Initialized
INFO - 2022-03-28 23:25:43 --> Loader Class Initialized
INFO - 2022-03-28 23:25:43 --> Helper loaded: url_helper
INFO - 2022-03-28 23:25:43 --> Helper loaded: form_helper
INFO - 2022-03-28 23:25:43 --> Helper loaded: common_helper
INFO - 2022-03-28 23:25:43 --> Database Driver Class Initialized
DEBUG - 2022-03-28 23:25:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 23:25:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 23:25:43 --> Controller Class Initialized
INFO - 2022-03-28 23:25:43 --> Form Validation Class Initialized
DEBUG - 2022-03-28 23:25:43 --> Encrypt Class Initialized
INFO - 2022-03-28 23:25:43 --> Model "Login_model" initialized
INFO - 2022-03-28 23:25:43 --> Model "Dashboard_model" initialized
INFO - 2022-03-28 23:25:43 --> Model "Case_model" initialized
INFO - 2022-03-28 23:25:43 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-28 23:25:43 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2022-03-28 23:25:43 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-28 23:25:43 --> Final output sent to browser
DEBUG - 2022-03-28 23:25:43 --> Total execution time: 0.1434
ERROR - 2022-03-28 23:27:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 23:27:51 --> Config Class Initialized
INFO - 2022-03-28 23:27:51 --> Hooks Class Initialized
DEBUG - 2022-03-28 23:27:51 --> UTF-8 Support Enabled
INFO - 2022-03-28 23:27:51 --> Utf8 Class Initialized
INFO - 2022-03-28 23:27:51 --> URI Class Initialized
INFO - 2022-03-28 23:27:51 --> Router Class Initialized
INFO - 2022-03-28 23:27:51 --> Output Class Initialized
INFO - 2022-03-28 23:27:51 --> Security Class Initialized
DEBUG - 2022-03-28 23:27:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 23:27:51 --> Input Class Initialized
INFO - 2022-03-28 23:27:51 --> Language Class Initialized
INFO - 2022-03-28 23:27:51 --> Loader Class Initialized
INFO - 2022-03-28 23:27:51 --> Helper loaded: url_helper
INFO - 2022-03-28 23:27:51 --> Helper loaded: form_helper
INFO - 2022-03-28 23:27:51 --> Helper loaded: common_helper
INFO - 2022-03-28 23:27:51 --> Database Driver Class Initialized
DEBUG - 2022-03-28 23:27:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 23:27:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 23:27:51 --> Controller Class Initialized
INFO - 2022-03-28 23:27:51 --> Form Validation Class Initialized
DEBUG - 2022-03-28 23:27:51 --> Encrypt Class Initialized
INFO - 2022-03-28 23:27:51 --> Model "Patient_model" initialized
INFO - 2022-03-28 23:27:51 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 23:27:51 --> Model "Referredby_model" initialized
INFO - 2022-03-28 23:27:51 --> Model "Prefix_master" initialized
INFO - 2022-03-28 23:27:51 --> Model "Hospital_model" initialized
INFO - 2022-03-28 23:27:51 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-28 23:27:51 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-28 23:27:51 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-28 23:27:51 --> Final output sent to browser
DEBUG - 2022-03-28 23:27:51 --> Total execution time: 0.0797
ERROR - 2022-03-28 23:28:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 23:28:12 --> Config Class Initialized
INFO - 2022-03-28 23:28:12 --> Hooks Class Initialized
DEBUG - 2022-03-28 23:28:12 --> UTF-8 Support Enabled
INFO - 2022-03-28 23:28:12 --> Utf8 Class Initialized
INFO - 2022-03-28 23:28:12 --> URI Class Initialized
INFO - 2022-03-28 23:28:12 --> Router Class Initialized
INFO - 2022-03-28 23:28:12 --> Output Class Initialized
INFO - 2022-03-28 23:28:12 --> Security Class Initialized
DEBUG - 2022-03-28 23:28:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 23:28:12 --> Input Class Initialized
INFO - 2022-03-28 23:28:12 --> Language Class Initialized
INFO - 2022-03-28 23:28:12 --> Loader Class Initialized
INFO - 2022-03-28 23:28:12 --> Helper loaded: url_helper
INFO - 2022-03-28 23:28:12 --> Helper loaded: form_helper
INFO - 2022-03-28 23:28:12 --> Helper loaded: common_helper
INFO - 2022-03-28 23:28:12 --> Database Driver Class Initialized
DEBUG - 2022-03-28 23:28:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 23:28:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 23:28:12 --> Controller Class Initialized
INFO - 2022-03-28 23:28:12 --> Form Validation Class Initialized
DEBUG - 2022-03-28 23:28:12 --> Encrypt Class Initialized
INFO - 2022-03-28 23:28:12 --> Model "Patient_model" initialized
INFO - 2022-03-28 23:28:12 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 23:28:12 --> Model "Referredby_model" initialized
INFO - 2022-03-28 23:28:12 --> Model "Prefix_master" initialized
INFO - 2022-03-28 23:28:12 --> Model "Hospital_model" initialized
INFO - 2022-03-28 23:28:12 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-28 23:28:12 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-28 23:28:12 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-28 23:28:12 --> Final output sent to browser
DEBUG - 2022-03-28 23:28:12 --> Total execution time: 0.0951
ERROR - 2022-03-28 23:29:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 23:29:42 --> Config Class Initialized
INFO - 2022-03-28 23:29:42 --> Hooks Class Initialized
DEBUG - 2022-03-28 23:29:42 --> UTF-8 Support Enabled
INFO - 2022-03-28 23:29:42 --> Utf8 Class Initialized
INFO - 2022-03-28 23:29:42 --> URI Class Initialized
INFO - 2022-03-28 23:29:42 --> Router Class Initialized
INFO - 2022-03-28 23:29:42 --> Output Class Initialized
INFO - 2022-03-28 23:29:42 --> Security Class Initialized
DEBUG - 2022-03-28 23:29:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 23:29:42 --> Input Class Initialized
INFO - 2022-03-28 23:29:42 --> Language Class Initialized
INFO - 2022-03-28 23:29:42 --> Loader Class Initialized
INFO - 2022-03-28 23:29:42 --> Helper loaded: url_helper
INFO - 2022-03-28 23:29:42 --> Helper loaded: form_helper
INFO - 2022-03-28 23:29:42 --> Helper loaded: common_helper
INFO - 2022-03-28 23:29:42 --> Database Driver Class Initialized
DEBUG - 2022-03-28 23:29:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 23:29:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 23:29:42 --> Controller Class Initialized
INFO - 2022-03-28 23:29:42 --> Form Validation Class Initialized
DEBUG - 2022-03-28 23:29:42 --> Encrypt Class Initialized
INFO - 2022-03-28 23:29:42 --> Model "Patient_model" initialized
INFO - 2022-03-28 23:29:42 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 23:29:42 --> Model "Referredby_model" initialized
INFO - 2022-03-28 23:29:42 --> Model "Prefix_master" initialized
INFO - 2022-03-28 23:29:42 --> Model "Hospital_model" initialized
ERROR - 2022-03-28 23:29:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 23:29:43 --> Config Class Initialized
INFO - 2022-03-28 23:29:43 --> Hooks Class Initialized
DEBUG - 2022-03-28 23:29:43 --> UTF-8 Support Enabled
INFO - 2022-03-28 23:29:43 --> Utf8 Class Initialized
INFO - 2022-03-28 23:29:43 --> URI Class Initialized
INFO - 2022-03-28 23:29:43 --> Router Class Initialized
INFO - 2022-03-28 23:29:43 --> Output Class Initialized
INFO - 2022-03-28 23:29:43 --> Security Class Initialized
DEBUG - 2022-03-28 23:29:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 23:29:43 --> Input Class Initialized
INFO - 2022-03-28 23:29:43 --> Language Class Initialized
INFO - 2022-03-28 23:29:43 --> Loader Class Initialized
INFO - 2022-03-28 23:29:43 --> Helper loaded: url_helper
INFO - 2022-03-28 23:29:43 --> Helper loaded: form_helper
INFO - 2022-03-28 23:29:43 --> Helper loaded: common_helper
INFO - 2022-03-28 23:29:43 --> Database Driver Class Initialized
DEBUG - 2022-03-28 23:29:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 23:29:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 23:29:43 --> Controller Class Initialized
INFO - 2022-03-28 23:29:43 --> Form Validation Class Initialized
DEBUG - 2022-03-28 23:29:43 --> Encrypt Class Initialized
INFO - 2022-03-28 23:29:43 --> Model "Patient_model" initialized
INFO - 2022-03-28 23:29:43 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 23:29:43 --> Model "Referredby_model" initialized
INFO - 2022-03-28 23:29:43 --> Model "Prefix_master" initialized
INFO - 2022-03-28 23:29:43 --> Model "Hospital_model" initialized
INFO - 2022-03-28 23:29:43 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-28 23:29:43 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-28 23:29:43 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-28 23:29:43 --> Final output sent to browser
DEBUG - 2022-03-28 23:29:43 --> Total execution time: 0.0310
ERROR - 2022-03-28 23:29:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 23:29:43 --> Config Class Initialized
INFO - 2022-03-28 23:29:43 --> Hooks Class Initialized
DEBUG - 2022-03-28 23:29:43 --> UTF-8 Support Enabled
INFO - 2022-03-28 23:29:43 --> Utf8 Class Initialized
INFO - 2022-03-28 23:29:43 --> URI Class Initialized
INFO - 2022-03-28 23:29:43 --> Router Class Initialized
INFO - 2022-03-28 23:29:43 --> Output Class Initialized
INFO - 2022-03-28 23:29:43 --> Security Class Initialized
DEBUG - 2022-03-28 23:29:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 23:29:43 --> Input Class Initialized
INFO - 2022-03-28 23:29:43 --> Language Class Initialized
INFO - 2022-03-28 23:29:43 --> Loader Class Initialized
INFO - 2022-03-28 23:29:43 --> Helper loaded: url_helper
INFO - 2022-03-28 23:29:43 --> Helper loaded: form_helper
INFO - 2022-03-28 23:29:43 --> Helper loaded: common_helper
INFO - 2022-03-28 23:29:43 --> Database Driver Class Initialized
DEBUG - 2022-03-28 23:29:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 23:29:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 23:29:43 --> Controller Class Initialized
INFO - 2022-03-28 23:29:43 --> Form Validation Class Initialized
DEBUG - 2022-03-28 23:29:43 --> Encrypt Class Initialized
INFO - 2022-03-28 23:29:43 --> Model "Patient_model" initialized
INFO - 2022-03-28 23:29:43 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 23:29:43 --> Model "Prefix_master" initialized
INFO - 2022-03-28 23:29:43 --> Model "Users_model" initialized
INFO - 2022-03-28 23:29:43 --> Model "Hospital_model" initialized
INFO - 2022-03-28 23:29:44 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-28 23:29:44 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-28 23:29:44 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-28 23:29:44 --> Final output sent to browser
DEBUG - 2022-03-28 23:29:44 --> Total execution time: 0.1713
ERROR - 2022-03-28 23:30:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 23:30:49 --> Config Class Initialized
INFO - 2022-03-28 23:30:49 --> Hooks Class Initialized
DEBUG - 2022-03-28 23:30:49 --> UTF-8 Support Enabled
INFO - 2022-03-28 23:30:49 --> Utf8 Class Initialized
INFO - 2022-03-28 23:30:49 --> URI Class Initialized
INFO - 2022-03-28 23:30:49 --> Router Class Initialized
INFO - 2022-03-28 23:30:49 --> Output Class Initialized
INFO - 2022-03-28 23:30:49 --> Security Class Initialized
DEBUG - 2022-03-28 23:30:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 23:30:49 --> Input Class Initialized
INFO - 2022-03-28 23:30:49 --> Language Class Initialized
INFO - 2022-03-28 23:30:49 --> Loader Class Initialized
INFO - 2022-03-28 23:30:49 --> Helper loaded: url_helper
INFO - 2022-03-28 23:30:49 --> Helper loaded: form_helper
INFO - 2022-03-28 23:30:49 --> Helper loaded: common_helper
INFO - 2022-03-28 23:30:49 --> Database Driver Class Initialized
DEBUG - 2022-03-28 23:30:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 23:30:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 23:30:49 --> Controller Class Initialized
INFO - 2022-03-28 23:30:49 --> Form Validation Class Initialized
DEBUG - 2022-03-28 23:30:49 --> Encrypt Class Initialized
INFO - 2022-03-28 23:30:49 --> Model "Patient_model" initialized
INFO - 2022-03-28 23:30:49 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 23:30:49 --> Model "Prefix_master" initialized
INFO - 2022-03-28 23:30:49 --> Model "Users_model" initialized
INFO - 2022-03-28 23:30:49 --> Model "Hospital_model" initialized
ERROR - 2022-03-28 23:30:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 23:30:49 --> Config Class Initialized
INFO - 2022-03-28 23:30:49 --> Hooks Class Initialized
DEBUG - 2022-03-28 23:30:49 --> UTF-8 Support Enabled
INFO - 2022-03-28 23:30:49 --> Utf8 Class Initialized
INFO - 2022-03-28 23:30:49 --> URI Class Initialized
INFO - 2022-03-28 23:30:49 --> Router Class Initialized
INFO - 2022-03-28 23:30:49 --> Output Class Initialized
INFO - 2022-03-28 23:30:49 --> Security Class Initialized
DEBUG - 2022-03-28 23:30:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 23:30:49 --> Input Class Initialized
INFO - 2022-03-28 23:30:49 --> Language Class Initialized
INFO - 2022-03-28 23:30:49 --> Loader Class Initialized
INFO - 2022-03-28 23:30:49 --> Helper loaded: url_helper
INFO - 2022-03-28 23:30:49 --> Helper loaded: form_helper
INFO - 2022-03-28 23:30:49 --> Helper loaded: common_helper
INFO - 2022-03-28 23:30:49 --> Database Driver Class Initialized
DEBUG - 2022-03-28 23:30:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 23:30:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 23:30:49 --> Controller Class Initialized
INFO - 2022-03-28 23:30:49 --> Form Validation Class Initialized
DEBUG - 2022-03-28 23:30:49 --> Encrypt Class Initialized
INFO - 2022-03-28 23:30:49 --> Model "Patient_model" initialized
INFO - 2022-03-28 23:30:49 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 23:30:49 --> Model "Prefix_master" initialized
INFO - 2022-03-28 23:30:49 --> Model "Users_model" initialized
INFO - 2022-03-28 23:30:49 --> Model "Hospital_model" initialized
INFO - 2022-03-28 23:30:49 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-28 23:30:49 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-28 23:30:49 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-28 23:30:49 --> Final output sent to browser
DEBUG - 2022-03-28 23:30:49 --> Total execution time: 0.0444
ERROR - 2022-03-28 23:31:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 23:31:43 --> Config Class Initialized
INFO - 2022-03-28 23:31:43 --> Hooks Class Initialized
DEBUG - 2022-03-28 23:31:43 --> UTF-8 Support Enabled
INFO - 2022-03-28 23:31:43 --> Utf8 Class Initialized
INFO - 2022-03-28 23:31:43 --> URI Class Initialized
INFO - 2022-03-28 23:31:43 --> Router Class Initialized
INFO - 2022-03-28 23:31:43 --> Output Class Initialized
INFO - 2022-03-28 23:31:43 --> Security Class Initialized
DEBUG - 2022-03-28 23:31:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 23:31:43 --> Input Class Initialized
INFO - 2022-03-28 23:31:43 --> Language Class Initialized
INFO - 2022-03-28 23:31:43 --> Loader Class Initialized
INFO - 2022-03-28 23:31:43 --> Helper loaded: url_helper
INFO - 2022-03-28 23:31:43 --> Helper loaded: form_helper
INFO - 2022-03-28 23:31:43 --> Helper loaded: common_helper
INFO - 2022-03-28 23:31:43 --> Database Driver Class Initialized
DEBUG - 2022-03-28 23:31:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 23:31:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 23:31:43 --> Controller Class Initialized
INFO - 2022-03-28 23:31:43 --> Form Validation Class Initialized
DEBUG - 2022-03-28 23:31:43 --> Encrypt Class Initialized
INFO - 2022-03-28 23:31:43 --> Model "Patient_model" initialized
INFO - 2022-03-28 23:31:43 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 23:31:43 --> Model "Prefix_master" initialized
INFO - 2022-03-28 23:31:43 --> Model "Users_model" initialized
INFO - 2022-03-28 23:31:43 --> Model "Hospital_model" initialized
ERROR - 2022-03-28 23:31:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 23:31:43 --> Config Class Initialized
INFO - 2022-03-28 23:31:43 --> Hooks Class Initialized
DEBUG - 2022-03-28 23:31:43 --> UTF-8 Support Enabled
INFO - 2022-03-28 23:31:43 --> Utf8 Class Initialized
INFO - 2022-03-28 23:31:43 --> URI Class Initialized
INFO - 2022-03-28 23:31:43 --> Router Class Initialized
INFO - 2022-03-28 23:31:43 --> Output Class Initialized
INFO - 2022-03-28 23:31:43 --> Security Class Initialized
DEBUG - 2022-03-28 23:31:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 23:31:43 --> Input Class Initialized
INFO - 2022-03-28 23:31:43 --> Language Class Initialized
INFO - 2022-03-28 23:31:43 --> Loader Class Initialized
INFO - 2022-03-28 23:31:43 --> Helper loaded: url_helper
INFO - 2022-03-28 23:31:43 --> Helper loaded: form_helper
INFO - 2022-03-28 23:31:43 --> Helper loaded: common_helper
INFO - 2022-03-28 23:31:43 --> Database Driver Class Initialized
DEBUG - 2022-03-28 23:31:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 23:31:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 23:31:43 --> Controller Class Initialized
INFO - 2022-03-28 23:31:43 --> Form Validation Class Initialized
DEBUG - 2022-03-28 23:31:43 --> Encrypt Class Initialized
INFO - 2022-03-28 23:31:43 --> Model "Patient_model" initialized
INFO - 2022-03-28 23:31:43 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 23:31:43 --> Model "Prefix_master" initialized
INFO - 2022-03-28 23:31:43 --> Model "Users_model" initialized
INFO - 2022-03-28 23:31:43 --> Model "Hospital_model" initialized
INFO - 2022-03-28 23:31:43 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-28 23:31:43 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-28 23:31:43 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-28 23:31:43 --> Final output sent to browser
DEBUG - 2022-03-28 23:31:43 --> Total execution time: 0.0445
ERROR - 2022-03-28 23:33:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 23:33:43 --> Config Class Initialized
INFO - 2022-03-28 23:33:43 --> Hooks Class Initialized
DEBUG - 2022-03-28 23:33:43 --> UTF-8 Support Enabled
INFO - 2022-03-28 23:33:43 --> Utf8 Class Initialized
INFO - 2022-03-28 23:33:43 --> URI Class Initialized
INFO - 2022-03-28 23:33:43 --> Router Class Initialized
INFO - 2022-03-28 23:33:43 --> Output Class Initialized
INFO - 2022-03-28 23:33:43 --> Security Class Initialized
DEBUG - 2022-03-28 23:33:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 23:33:43 --> Input Class Initialized
INFO - 2022-03-28 23:33:43 --> Language Class Initialized
INFO - 2022-03-28 23:33:43 --> Loader Class Initialized
INFO - 2022-03-28 23:33:43 --> Helper loaded: url_helper
INFO - 2022-03-28 23:33:43 --> Helper loaded: form_helper
INFO - 2022-03-28 23:33:43 --> Helper loaded: common_helper
INFO - 2022-03-28 23:33:43 --> Database Driver Class Initialized
DEBUG - 2022-03-28 23:33:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 23:33:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 23:33:43 --> Controller Class Initialized
INFO - 2022-03-28 23:33:43 --> Form Validation Class Initialized
DEBUG - 2022-03-28 23:33:43 --> Encrypt Class Initialized
INFO - 2022-03-28 23:33:43 --> Model "Patient_model" initialized
INFO - 2022-03-28 23:33:43 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 23:33:43 --> Model "Prefix_master" initialized
INFO - 2022-03-28 23:33:43 --> Model "Users_model" initialized
INFO - 2022-03-28 23:33:43 --> Model "Hospital_model" initialized
ERROR - 2022-03-28 23:33:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 23:33:43 --> Config Class Initialized
INFO - 2022-03-28 23:33:43 --> Hooks Class Initialized
DEBUG - 2022-03-28 23:33:43 --> UTF-8 Support Enabled
INFO - 2022-03-28 23:33:43 --> Utf8 Class Initialized
INFO - 2022-03-28 23:33:43 --> URI Class Initialized
INFO - 2022-03-28 23:33:43 --> Router Class Initialized
INFO - 2022-03-28 23:33:43 --> Output Class Initialized
INFO - 2022-03-28 23:33:43 --> Security Class Initialized
DEBUG - 2022-03-28 23:33:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 23:33:43 --> Input Class Initialized
INFO - 2022-03-28 23:33:43 --> Language Class Initialized
INFO - 2022-03-28 23:33:43 --> Loader Class Initialized
INFO - 2022-03-28 23:33:43 --> Helper loaded: url_helper
INFO - 2022-03-28 23:33:43 --> Helper loaded: form_helper
INFO - 2022-03-28 23:33:43 --> Helper loaded: common_helper
INFO - 2022-03-28 23:33:43 --> Database Driver Class Initialized
DEBUG - 2022-03-28 23:33:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 23:33:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 23:33:43 --> Controller Class Initialized
INFO - 2022-03-28 23:33:43 --> Form Validation Class Initialized
DEBUG - 2022-03-28 23:33:43 --> Encrypt Class Initialized
INFO - 2022-03-28 23:33:43 --> Model "Patient_model" initialized
INFO - 2022-03-28 23:33:43 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 23:33:43 --> Model "Prefix_master" initialized
INFO - 2022-03-28 23:33:43 --> Model "Users_model" initialized
INFO - 2022-03-28 23:33:43 --> Model "Hospital_model" initialized
INFO - 2022-03-28 23:33:44 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-28 23:33:44 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-28 23:33:44 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-28 23:33:44 --> Final output sent to browser
DEBUG - 2022-03-28 23:33:44 --> Total execution time: 0.0680
ERROR - 2022-03-28 23:33:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 23:33:48 --> Config Class Initialized
INFO - 2022-03-28 23:33:48 --> Hooks Class Initialized
DEBUG - 2022-03-28 23:33:48 --> UTF-8 Support Enabled
INFO - 2022-03-28 23:33:48 --> Utf8 Class Initialized
INFO - 2022-03-28 23:33:48 --> URI Class Initialized
INFO - 2022-03-28 23:33:48 --> Router Class Initialized
INFO - 2022-03-28 23:33:48 --> Output Class Initialized
INFO - 2022-03-28 23:33:48 --> Security Class Initialized
DEBUG - 2022-03-28 23:33:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 23:33:48 --> Input Class Initialized
INFO - 2022-03-28 23:33:48 --> Language Class Initialized
INFO - 2022-03-28 23:33:48 --> Loader Class Initialized
INFO - 2022-03-28 23:33:48 --> Helper loaded: url_helper
INFO - 2022-03-28 23:33:48 --> Helper loaded: form_helper
INFO - 2022-03-28 23:33:48 --> Helper loaded: common_helper
INFO - 2022-03-28 23:33:48 --> Database Driver Class Initialized
DEBUG - 2022-03-28 23:33:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 23:33:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 23:33:48 --> Controller Class Initialized
INFO - 2022-03-28 23:33:48 --> Form Validation Class Initialized
DEBUG - 2022-03-28 23:33:48 --> Encrypt Class Initialized
INFO - 2022-03-28 23:33:48 --> Model "Patient_model" initialized
INFO - 2022-03-28 23:33:48 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 23:33:48 --> Model "Referredby_model" initialized
INFO - 2022-03-28 23:33:48 --> Model "Prefix_master" initialized
INFO - 2022-03-28 23:33:48 --> Model "Hospital_model" initialized
INFO - 2022-03-28 23:33:48 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-28 23:33:48 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-28 23:33:48 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-28 23:33:48 --> Final output sent to browser
DEBUG - 2022-03-28 23:33:48 --> Total execution time: 0.0928
ERROR - 2022-03-28 23:33:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 23:33:56 --> Config Class Initialized
INFO - 2022-03-28 23:33:56 --> Hooks Class Initialized
DEBUG - 2022-03-28 23:33:56 --> UTF-8 Support Enabled
INFO - 2022-03-28 23:33:56 --> Utf8 Class Initialized
INFO - 2022-03-28 23:33:56 --> URI Class Initialized
INFO - 2022-03-28 23:33:56 --> Router Class Initialized
INFO - 2022-03-28 23:33:56 --> Output Class Initialized
INFO - 2022-03-28 23:33:56 --> Security Class Initialized
DEBUG - 2022-03-28 23:33:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 23:33:56 --> Input Class Initialized
INFO - 2022-03-28 23:33:56 --> Language Class Initialized
INFO - 2022-03-28 23:33:56 --> Loader Class Initialized
INFO - 2022-03-28 23:33:56 --> Helper loaded: url_helper
INFO - 2022-03-28 23:33:56 --> Helper loaded: form_helper
INFO - 2022-03-28 23:33:56 --> Helper loaded: common_helper
INFO - 2022-03-28 23:33:56 --> Database Driver Class Initialized
DEBUG - 2022-03-28 23:33:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 23:33:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 23:33:56 --> Controller Class Initialized
INFO - 2022-03-28 23:33:56 --> Form Validation Class Initialized
DEBUG - 2022-03-28 23:33:56 --> Encrypt Class Initialized
INFO - 2022-03-28 23:33:56 --> Model "Patient_model" initialized
INFO - 2022-03-28 23:33:56 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 23:33:56 --> Model "Prefix_master" initialized
INFO - 2022-03-28 23:33:56 --> Model "Users_model" initialized
INFO - 2022-03-28 23:33:56 --> Model "Hospital_model" initialized
INFO - 2022-03-28 23:33:56 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-28 23:33:57 --> Final output sent to browser
DEBUG - 2022-03-28 23:33:57 --> Total execution time: 1.2553
ERROR - 2022-03-28 23:36:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 23:36:00 --> Config Class Initialized
INFO - 2022-03-28 23:36:00 --> Hooks Class Initialized
DEBUG - 2022-03-28 23:36:00 --> UTF-8 Support Enabled
INFO - 2022-03-28 23:36:00 --> Utf8 Class Initialized
INFO - 2022-03-28 23:36:00 --> URI Class Initialized
INFO - 2022-03-28 23:36:00 --> Router Class Initialized
INFO - 2022-03-28 23:36:00 --> Output Class Initialized
INFO - 2022-03-28 23:36:00 --> Security Class Initialized
DEBUG - 2022-03-28 23:36:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 23:36:00 --> Input Class Initialized
INFO - 2022-03-28 23:36:00 --> Language Class Initialized
INFO - 2022-03-28 23:36:00 --> Loader Class Initialized
INFO - 2022-03-28 23:36:00 --> Helper loaded: url_helper
INFO - 2022-03-28 23:36:00 --> Helper loaded: form_helper
INFO - 2022-03-28 23:36:00 --> Helper loaded: common_helper
INFO - 2022-03-28 23:36:00 --> Database Driver Class Initialized
DEBUG - 2022-03-28 23:36:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 23:36:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 23:36:00 --> Controller Class Initialized
INFO - 2022-03-28 23:36:00 --> Form Validation Class Initialized
DEBUG - 2022-03-28 23:36:00 --> Encrypt Class Initialized
INFO - 2022-03-28 23:36:00 --> Model "Patient_model" initialized
INFO - 2022-03-28 23:36:00 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 23:36:00 --> Model "Referredby_model" initialized
INFO - 2022-03-28 23:36:00 --> Model "Prefix_master" initialized
INFO - 2022-03-28 23:36:00 --> Model "Hospital_model" initialized
INFO - 2022-03-28 23:36:00 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-28 23:36:00 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-28 23:36:00 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-28 23:36:00 --> Final output sent to browser
DEBUG - 2022-03-28 23:36:00 --> Total execution time: 0.0722
ERROR - 2022-03-28 23:36:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 23:36:11 --> Config Class Initialized
INFO - 2022-03-28 23:36:11 --> Hooks Class Initialized
DEBUG - 2022-03-28 23:36:11 --> UTF-8 Support Enabled
INFO - 2022-03-28 23:36:11 --> Utf8 Class Initialized
INFO - 2022-03-28 23:36:11 --> URI Class Initialized
INFO - 2022-03-28 23:36:11 --> Router Class Initialized
INFO - 2022-03-28 23:36:11 --> Output Class Initialized
INFO - 2022-03-28 23:36:11 --> Security Class Initialized
DEBUG - 2022-03-28 23:36:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 23:36:11 --> Input Class Initialized
INFO - 2022-03-28 23:36:11 --> Language Class Initialized
INFO - 2022-03-28 23:36:11 --> Loader Class Initialized
INFO - 2022-03-28 23:36:11 --> Helper loaded: url_helper
INFO - 2022-03-28 23:36:11 --> Helper loaded: form_helper
INFO - 2022-03-28 23:36:11 --> Helper loaded: common_helper
INFO - 2022-03-28 23:36:11 --> Database Driver Class Initialized
DEBUG - 2022-03-28 23:36:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 23:36:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 23:36:11 --> Controller Class Initialized
INFO - 2022-03-28 23:36:11 --> Form Validation Class Initialized
DEBUG - 2022-03-28 23:36:11 --> Encrypt Class Initialized
INFO - 2022-03-28 23:36:11 --> Model "Patient_model" initialized
INFO - 2022-03-28 23:36:11 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 23:36:11 --> Model "Referredby_model" initialized
INFO - 2022-03-28 23:36:11 --> Model "Prefix_master" initialized
INFO - 2022-03-28 23:36:11 --> Model "Hospital_model" initialized
INFO - 2022-03-28 23:36:11 --> Upload Class Initialized
INFO - 2022-03-28 23:36:11 --> Final output sent to browser
DEBUG - 2022-03-28 23:36:11 --> Total execution time: 0.0103
ERROR - 2022-03-28 23:36:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 23:36:19 --> Config Class Initialized
INFO - 2022-03-28 23:36:19 --> Hooks Class Initialized
DEBUG - 2022-03-28 23:36:19 --> UTF-8 Support Enabled
INFO - 2022-03-28 23:36:19 --> Utf8 Class Initialized
INFO - 2022-03-28 23:36:19 --> URI Class Initialized
INFO - 2022-03-28 23:36:19 --> Router Class Initialized
INFO - 2022-03-28 23:36:19 --> Output Class Initialized
INFO - 2022-03-28 23:36:19 --> Security Class Initialized
DEBUG - 2022-03-28 23:36:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 23:36:19 --> Input Class Initialized
INFO - 2022-03-28 23:36:19 --> Language Class Initialized
INFO - 2022-03-28 23:36:19 --> Loader Class Initialized
INFO - 2022-03-28 23:36:19 --> Helper loaded: url_helper
INFO - 2022-03-28 23:36:19 --> Helper loaded: form_helper
INFO - 2022-03-28 23:36:19 --> Helper loaded: common_helper
INFO - 2022-03-28 23:36:19 --> Database Driver Class Initialized
DEBUG - 2022-03-28 23:36:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 23:36:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 23:36:19 --> Controller Class Initialized
INFO - 2022-03-28 23:36:19 --> Form Validation Class Initialized
DEBUG - 2022-03-28 23:36:19 --> Encrypt Class Initialized
INFO - 2022-03-28 23:36:19 --> Model "Patient_model" initialized
INFO - 2022-03-28 23:36:19 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 23:36:19 --> Model "Referredby_model" initialized
INFO - 2022-03-28 23:36:19 --> Model "Prefix_master" initialized
INFO - 2022-03-28 23:36:19 --> Model "Hospital_model" initialized
ERROR - 2022-03-28 23:36:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 23:36:19 --> Config Class Initialized
INFO - 2022-03-28 23:36:19 --> Hooks Class Initialized
DEBUG - 2022-03-28 23:36:19 --> UTF-8 Support Enabled
INFO - 2022-03-28 23:36:19 --> Utf8 Class Initialized
INFO - 2022-03-28 23:36:19 --> URI Class Initialized
INFO - 2022-03-28 23:36:19 --> Router Class Initialized
INFO - 2022-03-28 23:36:19 --> Output Class Initialized
INFO - 2022-03-28 23:36:19 --> Security Class Initialized
DEBUG - 2022-03-28 23:36:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 23:36:19 --> Input Class Initialized
INFO - 2022-03-28 23:36:19 --> Language Class Initialized
INFO - 2022-03-28 23:36:19 --> Loader Class Initialized
INFO - 2022-03-28 23:36:19 --> Helper loaded: url_helper
INFO - 2022-03-28 23:36:19 --> Helper loaded: form_helper
INFO - 2022-03-28 23:36:19 --> Helper loaded: common_helper
INFO - 2022-03-28 23:36:19 --> Database Driver Class Initialized
DEBUG - 2022-03-28 23:36:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 23:36:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 23:36:19 --> Controller Class Initialized
INFO - 2022-03-28 23:36:19 --> Form Validation Class Initialized
DEBUG - 2022-03-28 23:36:19 --> Encrypt Class Initialized
INFO - 2022-03-28 23:36:19 --> Model "Patient_model" initialized
INFO - 2022-03-28 23:36:19 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 23:36:19 --> Model "Referredby_model" initialized
INFO - 2022-03-28 23:36:19 --> Model "Prefix_master" initialized
INFO - 2022-03-28 23:36:19 --> Model "Hospital_model" initialized
INFO - 2022-03-28 23:36:19 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-28 23:36:19 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-28 23:36:19 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-28 23:36:19 --> Final output sent to browser
DEBUG - 2022-03-28 23:36:19 --> Total execution time: 0.0266
ERROR - 2022-03-28 23:36:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 23:36:20 --> Config Class Initialized
INFO - 2022-03-28 23:36:20 --> Hooks Class Initialized
DEBUG - 2022-03-28 23:36:20 --> UTF-8 Support Enabled
INFO - 2022-03-28 23:36:20 --> Utf8 Class Initialized
INFO - 2022-03-28 23:36:20 --> URI Class Initialized
INFO - 2022-03-28 23:36:20 --> Router Class Initialized
INFO - 2022-03-28 23:36:20 --> Output Class Initialized
INFO - 2022-03-28 23:36:20 --> Security Class Initialized
DEBUG - 2022-03-28 23:36:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 23:36:20 --> Input Class Initialized
INFO - 2022-03-28 23:36:20 --> Language Class Initialized
INFO - 2022-03-28 23:36:20 --> Loader Class Initialized
INFO - 2022-03-28 23:36:20 --> Helper loaded: url_helper
INFO - 2022-03-28 23:36:20 --> Helper loaded: form_helper
INFO - 2022-03-28 23:36:20 --> Helper loaded: common_helper
INFO - 2022-03-28 23:36:20 --> Database Driver Class Initialized
DEBUG - 2022-03-28 23:36:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 23:36:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 23:36:20 --> Controller Class Initialized
INFO - 2022-03-28 23:36:20 --> Form Validation Class Initialized
DEBUG - 2022-03-28 23:36:20 --> Encrypt Class Initialized
INFO - 2022-03-28 23:36:20 --> Model "Patient_model" initialized
INFO - 2022-03-28 23:36:20 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 23:36:20 --> Model "Prefix_master" initialized
INFO - 2022-03-28 23:36:20 --> Model "Users_model" initialized
INFO - 2022-03-28 23:36:20 --> Model "Hospital_model" initialized
INFO - 2022-03-28 23:36:20 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-28 23:36:20 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-28 23:36:20 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-28 23:36:20 --> Final output sent to browser
DEBUG - 2022-03-28 23:36:20 --> Total execution time: 0.0422
ERROR - 2022-03-28 23:36:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 23:36:26 --> Config Class Initialized
INFO - 2022-03-28 23:36:26 --> Hooks Class Initialized
DEBUG - 2022-03-28 23:36:26 --> UTF-8 Support Enabled
INFO - 2022-03-28 23:36:26 --> Utf8 Class Initialized
INFO - 2022-03-28 23:36:26 --> URI Class Initialized
INFO - 2022-03-28 23:36:26 --> Router Class Initialized
INFO - 2022-03-28 23:36:26 --> Output Class Initialized
INFO - 2022-03-28 23:36:26 --> Security Class Initialized
DEBUG - 2022-03-28 23:36:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 23:36:26 --> Input Class Initialized
INFO - 2022-03-28 23:36:26 --> Language Class Initialized
INFO - 2022-03-28 23:36:26 --> Loader Class Initialized
INFO - 2022-03-28 23:36:26 --> Helper loaded: url_helper
INFO - 2022-03-28 23:36:26 --> Helper loaded: form_helper
INFO - 2022-03-28 23:36:26 --> Helper loaded: common_helper
INFO - 2022-03-28 23:36:26 --> Database Driver Class Initialized
DEBUG - 2022-03-28 23:36:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 23:36:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 23:36:26 --> Controller Class Initialized
INFO - 2022-03-28 23:36:26 --> Form Validation Class Initialized
DEBUG - 2022-03-28 23:36:26 --> Encrypt Class Initialized
INFO - 2022-03-28 23:36:26 --> Model "Patient_model" initialized
INFO - 2022-03-28 23:36:26 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 23:36:26 --> Model "Referredby_model" initialized
INFO - 2022-03-28 23:36:26 --> Model "Prefix_master" initialized
INFO - 2022-03-28 23:36:26 --> Model "Hospital_model" initialized
INFO - 2022-03-28 23:36:26 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-28 23:36:26 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-28 23:36:26 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-28 23:36:26 --> Final output sent to browser
DEBUG - 2022-03-28 23:36:26 --> Total execution time: 0.0594
ERROR - 2022-03-28 23:36:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 23:36:38 --> Config Class Initialized
INFO - 2022-03-28 23:36:38 --> Hooks Class Initialized
DEBUG - 2022-03-28 23:36:38 --> UTF-8 Support Enabled
INFO - 2022-03-28 23:36:38 --> Utf8 Class Initialized
INFO - 2022-03-28 23:36:38 --> URI Class Initialized
INFO - 2022-03-28 23:36:38 --> Router Class Initialized
INFO - 2022-03-28 23:36:38 --> Output Class Initialized
INFO - 2022-03-28 23:36:38 --> Security Class Initialized
DEBUG - 2022-03-28 23:36:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 23:36:38 --> Input Class Initialized
INFO - 2022-03-28 23:36:38 --> Language Class Initialized
INFO - 2022-03-28 23:36:38 --> Loader Class Initialized
INFO - 2022-03-28 23:36:38 --> Helper loaded: url_helper
INFO - 2022-03-28 23:36:38 --> Helper loaded: form_helper
INFO - 2022-03-28 23:36:38 --> Helper loaded: common_helper
INFO - 2022-03-28 23:36:38 --> Database Driver Class Initialized
DEBUG - 2022-03-28 23:36:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 23:36:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 23:36:38 --> Controller Class Initialized
INFO - 2022-03-28 23:36:38 --> Form Validation Class Initialized
DEBUG - 2022-03-28 23:36:38 --> Encrypt Class Initialized
INFO - 2022-03-28 23:36:38 --> Model "Patient_model" initialized
INFO - 2022-03-28 23:36:38 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 23:36:38 --> Model "Prefix_master" initialized
INFO - 2022-03-28 23:36:38 --> Model "Users_model" initialized
INFO - 2022-03-28 23:36:38 --> Model "Hospital_model" initialized
INFO - 2022-03-28 23:36:38 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-28 23:36:39 --> Final output sent to browser
DEBUG - 2022-03-28 23:36:39 --> Total execution time: 1.0862
ERROR - 2022-03-28 23:42:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 23:42:10 --> Config Class Initialized
INFO - 2022-03-28 23:42:10 --> Hooks Class Initialized
DEBUG - 2022-03-28 23:42:10 --> UTF-8 Support Enabled
INFO - 2022-03-28 23:42:10 --> Utf8 Class Initialized
INFO - 2022-03-28 23:42:10 --> URI Class Initialized
INFO - 2022-03-28 23:42:10 --> Router Class Initialized
INFO - 2022-03-28 23:42:10 --> Output Class Initialized
INFO - 2022-03-28 23:42:10 --> Security Class Initialized
DEBUG - 2022-03-28 23:42:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 23:42:10 --> Input Class Initialized
INFO - 2022-03-28 23:42:10 --> Language Class Initialized
INFO - 2022-03-28 23:42:10 --> Loader Class Initialized
INFO - 2022-03-28 23:42:10 --> Helper loaded: url_helper
INFO - 2022-03-28 23:42:10 --> Helper loaded: form_helper
INFO - 2022-03-28 23:42:10 --> Helper loaded: common_helper
INFO - 2022-03-28 23:42:10 --> Database Driver Class Initialized
DEBUG - 2022-03-28 23:42:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 23:42:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 23:42:10 --> Controller Class Initialized
INFO - 2022-03-28 23:42:10 --> Form Validation Class Initialized
DEBUG - 2022-03-28 23:42:10 --> Encrypt Class Initialized
INFO - 2022-03-28 23:42:10 --> Model "Patient_model" initialized
INFO - 2022-03-28 23:42:10 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 23:42:10 --> Model "Referredby_model" initialized
INFO - 2022-03-28 23:42:10 --> Model "Prefix_master" initialized
INFO - 2022-03-28 23:42:10 --> Model "Hospital_model" initialized
INFO - 2022-03-28 23:42:10 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-28 23:42:10 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-28 23:42:10 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-28 23:42:10 --> Final output sent to browser
DEBUG - 2022-03-28 23:42:10 --> Total execution time: 0.0752
ERROR - 2022-03-28 23:42:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 23:42:29 --> Config Class Initialized
INFO - 2022-03-28 23:42:29 --> Hooks Class Initialized
DEBUG - 2022-03-28 23:42:29 --> UTF-8 Support Enabled
INFO - 2022-03-28 23:42:29 --> Utf8 Class Initialized
INFO - 2022-03-28 23:42:29 --> URI Class Initialized
INFO - 2022-03-28 23:42:29 --> Router Class Initialized
INFO - 2022-03-28 23:42:29 --> Output Class Initialized
INFO - 2022-03-28 23:42:29 --> Security Class Initialized
DEBUG - 2022-03-28 23:42:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 23:42:29 --> Input Class Initialized
INFO - 2022-03-28 23:42:29 --> Language Class Initialized
INFO - 2022-03-28 23:42:29 --> Loader Class Initialized
INFO - 2022-03-28 23:42:29 --> Helper loaded: url_helper
INFO - 2022-03-28 23:42:29 --> Helper loaded: form_helper
INFO - 2022-03-28 23:42:29 --> Helper loaded: common_helper
INFO - 2022-03-28 23:42:29 --> Database Driver Class Initialized
DEBUG - 2022-03-28 23:42:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 23:42:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 23:42:29 --> Controller Class Initialized
INFO - 2022-03-28 23:42:29 --> Form Validation Class Initialized
DEBUG - 2022-03-28 23:42:29 --> Encrypt Class Initialized
INFO - 2022-03-28 23:42:29 --> Model "Patient_model" initialized
INFO - 2022-03-28 23:42:29 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 23:42:29 --> Model "Referredby_model" initialized
INFO - 2022-03-28 23:42:29 --> Model "Prefix_master" initialized
INFO - 2022-03-28 23:42:29 --> Model "Hospital_model" initialized
ERROR - 2022-03-28 23:42:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 23:42:29 --> Config Class Initialized
INFO - 2022-03-28 23:42:29 --> Hooks Class Initialized
DEBUG - 2022-03-28 23:42:29 --> UTF-8 Support Enabled
INFO - 2022-03-28 23:42:29 --> Utf8 Class Initialized
INFO - 2022-03-28 23:42:29 --> URI Class Initialized
INFO - 2022-03-28 23:42:29 --> Router Class Initialized
INFO - 2022-03-28 23:42:29 --> Output Class Initialized
INFO - 2022-03-28 23:42:29 --> Security Class Initialized
DEBUG - 2022-03-28 23:42:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 23:42:29 --> Input Class Initialized
INFO - 2022-03-28 23:42:29 --> Language Class Initialized
INFO - 2022-03-28 23:42:29 --> Loader Class Initialized
INFO - 2022-03-28 23:42:29 --> Helper loaded: url_helper
INFO - 2022-03-28 23:42:29 --> Helper loaded: form_helper
INFO - 2022-03-28 23:42:29 --> Helper loaded: common_helper
INFO - 2022-03-28 23:42:29 --> Database Driver Class Initialized
DEBUG - 2022-03-28 23:42:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 23:42:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 23:42:29 --> Controller Class Initialized
INFO - 2022-03-28 23:42:29 --> Form Validation Class Initialized
DEBUG - 2022-03-28 23:42:29 --> Encrypt Class Initialized
INFO - 2022-03-28 23:42:29 --> Model "Patient_model" initialized
INFO - 2022-03-28 23:42:29 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 23:42:29 --> Model "Referredby_model" initialized
INFO - 2022-03-28 23:42:29 --> Model "Prefix_master" initialized
INFO - 2022-03-28 23:42:29 --> Model "Hospital_model" initialized
INFO - 2022-03-28 23:42:29 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-28 23:42:29 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-28 23:42:29 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-28 23:42:29 --> Final output sent to browser
DEBUG - 2022-03-28 23:42:29 --> Total execution time: 0.0283
ERROR - 2022-03-28 23:42:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 23:42:30 --> Config Class Initialized
INFO - 2022-03-28 23:42:30 --> Hooks Class Initialized
DEBUG - 2022-03-28 23:42:30 --> UTF-8 Support Enabled
INFO - 2022-03-28 23:42:30 --> Utf8 Class Initialized
INFO - 2022-03-28 23:42:30 --> URI Class Initialized
INFO - 2022-03-28 23:42:30 --> Router Class Initialized
INFO - 2022-03-28 23:42:30 --> Output Class Initialized
INFO - 2022-03-28 23:42:30 --> Security Class Initialized
DEBUG - 2022-03-28 23:42:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 23:42:30 --> Input Class Initialized
INFO - 2022-03-28 23:42:30 --> Language Class Initialized
INFO - 2022-03-28 23:42:30 --> Loader Class Initialized
INFO - 2022-03-28 23:42:30 --> Helper loaded: url_helper
INFO - 2022-03-28 23:42:30 --> Helper loaded: form_helper
INFO - 2022-03-28 23:42:30 --> Helper loaded: common_helper
INFO - 2022-03-28 23:42:30 --> Database Driver Class Initialized
DEBUG - 2022-03-28 23:42:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 23:42:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 23:42:30 --> Controller Class Initialized
INFO - 2022-03-28 23:42:30 --> Form Validation Class Initialized
DEBUG - 2022-03-28 23:42:30 --> Encrypt Class Initialized
INFO - 2022-03-28 23:42:30 --> Model "Patient_model" initialized
INFO - 2022-03-28 23:42:30 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 23:42:30 --> Model "Prefix_master" initialized
INFO - 2022-03-28 23:42:30 --> Model "Users_model" initialized
INFO - 2022-03-28 23:42:30 --> Model "Hospital_model" initialized
INFO - 2022-03-28 23:42:30 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-28 23:42:30 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-28 23:42:30 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-28 23:42:30 --> Final output sent to browser
DEBUG - 2022-03-28 23:42:30 --> Total execution time: 0.0420
ERROR - 2022-03-28 23:42:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 23:42:52 --> Config Class Initialized
INFO - 2022-03-28 23:42:52 --> Hooks Class Initialized
DEBUG - 2022-03-28 23:42:52 --> UTF-8 Support Enabled
INFO - 2022-03-28 23:42:52 --> Utf8 Class Initialized
INFO - 2022-03-28 23:42:52 --> URI Class Initialized
INFO - 2022-03-28 23:42:52 --> Router Class Initialized
INFO - 2022-03-28 23:42:52 --> Output Class Initialized
INFO - 2022-03-28 23:42:52 --> Security Class Initialized
DEBUG - 2022-03-28 23:42:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 23:42:52 --> Input Class Initialized
INFO - 2022-03-28 23:42:52 --> Language Class Initialized
INFO - 2022-03-28 23:42:52 --> Loader Class Initialized
INFO - 2022-03-28 23:42:52 --> Helper loaded: url_helper
INFO - 2022-03-28 23:42:52 --> Helper loaded: form_helper
INFO - 2022-03-28 23:42:52 --> Helper loaded: common_helper
INFO - 2022-03-28 23:42:52 --> Database Driver Class Initialized
DEBUG - 2022-03-28 23:42:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 23:42:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 23:42:52 --> Controller Class Initialized
INFO - 2022-03-28 23:42:52 --> Form Validation Class Initialized
DEBUG - 2022-03-28 23:42:52 --> Encrypt Class Initialized
INFO - 2022-03-28 23:42:52 --> Model "Patient_model" initialized
INFO - 2022-03-28 23:42:52 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 23:42:52 --> Model "Prefix_master" initialized
INFO - 2022-03-28 23:42:52 --> Model "Users_model" initialized
INFO - 2022-03-28 23:42:52 --> Model "Hospital_model" initialized
ERROR - 2022-03-28 23:42:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 23:42:53 --> Config Class Initialized
INFO - 2022-03-28 23:42:53 --> Hooks Class Initialized
DEBUG - 2022-03-28 23:42:53 --> UTF-8 Support Enabled
INFO - 2022-03-28 23:42:53 --> Utf8 Class Initialized
INFO - 2022-03-28 23:42:53 --> URI Class Initialized
INFO - 2022-03-28 23:42:53 --> Router Class Initialized
INFO - 2022-03-28 23:42:53 --> Output Class Initialized
INFO - 2022-03-28 23:42:53 --> Security Class Initialized
DEBUG - 2022-03-28 23:42:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 23:42:53 --> Input Class Initialized
INFO - 2022-03-28 23:42:53 --> Language Class Initialized
INFO - 2022-03-28 23:42:53 --> Loader Class Initialized
INFO - 2022-03-28 23:42:53 --> Helper loaded: url_helper
INFO - 2022-03-28 23:42:53 --> Helper loaded: form_helper
INFO - 2022-03-28 23:42:53 --> Helper loaded: common_helper
INFO - 2022-03-28 23:42:53 --> Database Driver Class Initialized
DEBUG - 2022-03-28 23:42:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 23:42:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 23:42:53 --> Controller Class Initialized
INFO - 2022-03-28 23:42:53 --> Form Validation Class Initialized
DEBUG - 2022-03-28 23:42:53 --> Encrypt Class Initialized
INFO - 2022-03-28 23:42:53 --> Model "Patient_model" initialized
INFO - 2022-03-28 23:42:53 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 23:42:53 --> Model "Prefix_master" initialized
INFO - 2022-03-28 23:42:53 --> Model "Users_model" initialized
INFO - 2022-03-28 23:42:53 --> Model "Hospital_model" initialized
INFO - 2022-03-28 23:42:53 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-28 23:42:53 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-28 23:42:53 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-28 23:42:53 --> Final output sent to browser
DEBUG - 2022-03-28 23:42:53 --> Total execution time: 0.0473
ERROR - 2022-03-28 23:43:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 23:43:14 --> Config Class Initialized
INFO - 2022-03-28 23:43:14 --> Hooks Class Initialized
DEBUG - 2022-03-28 23:43:14 --> UTF-8 Support Enabled
INFO - 2022-03-28 23:43:14 --> Utf8 Class Initialized
INFO - 2022-03-28 23:43:14 --> URI Class Initialized
INFO - 2022-03-28 23:43:14 --> Router Class Initialized
INFO - 2022-03-28 23:43:14 --> Output Class Initialized
INFO - 2022-03-28 23:43:14 --> Security Class Initialized
DEBUG - 2022-03-28 23:43:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 23:43:14 --> Input Class Initialized
INFO - 2022-03-28 23:43:14 --> Language Class Initialized
INFO - 2022-03-28 23:43:14 --> Loader Class Initialized
INFO - 2022-03-28 23:43:14 --> Helper loaded: url_helper
INFO - 2022-03-28 23:43:14 --> Helper loaded: form_helper
INFO - 2022-03-28 23:43:14 --> Helper loaded: common_helper
INFO - 2022-03-28 23:43:14 --> Database Driver Class Initialized
DEBUG - 2022-03-28 23:43:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 23:43:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 23:43:14 --> Controller Class Initialized
INFO - 2022-03-28 23:43:14 --> Form Validation Class Initialized
DEBUG - 2022-03-28 23:43:14 --> Encrypt Class Initialized
INFO - 2022-03-28 23:43:14 --> Model "Patient_model" initialized
INFO - 2022-03-28 23:43:14 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 23:43:14 --> Model "Prefix_master" initialized
INFO - 2022-03-28 23:43:14 --> Model "Users_model" initialized
INFO - 2022-03-28 23:43:14 --> Model "Hospital_model" initialized
ERROR - 2022-03-28 23:43:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 23:43:14 --> Config Class Initialized
INFO - 2022-03-28 23:43:14 --> Hooks Class Initialized
DEBUG - 2022-03-28 23:43:14 --> UTF-8 Support Enabled
INFO - 2022-03-28 23:43:14 --> Utf8 Class Initialized
INFO - 2022-03-28 23:43:14 --> URI Class Initialized
INFO - 2022-03-28 23:43:14 --> Router Class Initialized
INFO - 2022-03-28 23:43:14 --> Output Class Initialized
INFO - 2022-03-28 23:43:14 --> Security Class Initialized
DEBUG - 2022-03-28 23:43:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 23:43:14 --> Input Class Initialized
INFO - 2022-03-28 23:43:14 --> Language Class Initialized
INFO - 2022-03-28 23:43:14 --> Loader Class Initialized
INFO - 2022-03-28 23:43:14 --> Helper loaded: url_helper
INFO - 2022-03-28 23:43:14 --> Helper loaded: form_helper
INFO - 2022-03-28 23:43:14 --> Helper loaded: common_helper
INFO - 2022-03-28 23:43:14 --> Database Driver Class Initialized
DEBUG - 2022-03-28 23:43:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 23:43:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 23:43:14 --> Controller Class Initialized
INFO - 2022-03-28 23:43:14 --> Form Validation Class Initialized
DEBUG - 2022-03-28 23:43:14 --> Encrypt Class Initialized
INFO - 2022-03-28 23:43:14 --> Model "Patient_model" initialized
INFO - 2022-03-28 23:43:14 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 23:43:14 --> Model "Prefix_master" initialized
INFO - 2022-03-28 23:43:14 --> Model "Users_model" initialized
INFO - 2022-03-28 23:43:14 --> Model "Hospital_model" initialized
INFO - 2022-03-28 23:43:14 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-28 23:43:14 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-28 23:43:14 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-28 23:43:14 --> Final output sent to browser
DEBUG - 2022-03-28 23:43:14 --> Total execution time: 0.0431
ERROR - 2022-03-28 23:43:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 23:43:35 --> Config Class Initialized
INFO - 2022-03-28 23:43:35 --> Hooks Class Initialized
DEBUG - 2022-03-28 23:43:35 --> UTF-8 Support Enabled
INFO - 2022-03-28 23:43:35 --> Utf8 Class Initialized
INFO - 2022-03-28 23:43:35 --> URI Class Initialized
INFO - 2022-03-28 23:43:35 --> Router Class Initialized
INFO - 2022-03-28 23:43:35 --> Output Class Initialized
INFO - 2022-03-28 23:43:35 --> Security Class Initialized
DEBUG - 2022-03-28 23:43:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 23:43:35 --> Input Class Initialized
INFO - 2022-03-28 23:43:35 --> Language Class Initialized
INFO - 2022-03-28 23:43:35 --> Loader Class Initialized
INFO - 2022-03-28 23:43:35 --> Helper loaded: url_helper
INFO - 2022-03-28 23:43:35 --> Helper loaded: form_helper
INFO - 2022-03-28 23:43:35 --> Helper loaded: common_helper
INFO - 2022-03-28 23:43:35 --> Database Driver Class Initialized
DEBUG - 2022-03-28 23:43:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 23:43:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 23:43:35 --> Controller Class Initialized
INFO - 2022-03-28 23:43:35 --> Form Validation Class Initialized
DEBUG - 2022-03-28 23:43:35 --> Encrypt Class Initialized
INFO - 2022-03-28 23:43:35 --> Model "Patient_model" initialized
INFO - 2022-03-28 23:43:35 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 23:43:35 --> Model "Referredby_model" initialized
INFO - 2022-03-28 23:43:35 --> Model "Prefix_master" initialized
INFO - 2022-03-28 23:43:35 --> Model "Hospital_model" initialized
INFO - 2022-03-28 23:43:35 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-28 23:43:35 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-28 23:43:35 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-28 23:43:35 --> Final output sent to browser
DEBUG - 2022-03-28 23:43:35 --> Total execution time: 0.0210
ERROR - 2022-03-28 23:44:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 23:44:34 --> Config Class Initialized
INFO - 2022-03-28 23:44:34 --> Hooks Class Initialized
DEBUG - 2022-03-28 23:44:34 --> UTF-8 Support Enabled
INFO - 2022-03-28 23:44:34 --> Utf8 Class Initialized
INFO - 2022-03-28 23:44:34 --> URI Class Initialized
INFO - 2022-03-28 23:44:34 --> Router Class Initialized
INFO - 2022-03-28 23:44:34 --> Output Class Initialized
INFO - 2022-03-28 23:44:34 --> Security Class Initialized
DEBUG - 2022-03-28 23:44:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 23:44:34 --> Input Class Initialized
INFO - 2022-03-28 23:44:34 --> Language Class Initialized
INFO - 2022-03-28 23:44:34 --> Loader Class Initialized
INFO - 2022-03-28 23:44:34 --> Helper loaded: url_helper
INFO - 2022-03-28 23:44:34 --> Helper loaded: form_helper
INFO - 2022-03-28 23:44:34 --> Helper loaded: common_helper
INFO - 2022-03-28 23:44:34 --> Database Driver Class Initialized
DEBUG - 2022-03-28 23:44:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 23:44:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 23:44:34 --> Controller Class Initialized
INFO - 2022-03-28 23:44:34 --> Form Validation Class Initialized
DEBUG - 2022-03-28 23:44:34 --> Encrypt Class Initialized
INFO - 2022-03-28 23:44:34 --> Model "Patient_model" initialized
INFO - 2022-03-28 23:44:34 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 23:44:34 --> Model "Prefix_master" initialized
INFO - 2022-03-28 23:44:34 --> Model "Users_model" initialized
INFO - 2022-03-28 23:44:34 --> Model "Hospital_model" initialized
ERROR - 2022-03-28 23:44:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 23:44:35 --> Config Class Initialized
INFO - 2022-03-28 23:44:35 --> Hooks Class Initialized
DEBUG - 2022-03-28 23:44:35 --> UTF-8 Support Enabled
INFO - 2022-03-28 23:44:35 --> Utf8 Class Initialized
INFO - 2022-03-28 23:44:35 --> URI Class Initialized
INFO - 2022-03-28 23:44:35 --> Router Class Initialized
INFO - 2022-03-28 23:44:35 --> Output Class Initialized
INFO - 2022-03-28 23:44:35 --> Security Class Initialized
DEBUG - 2022-03-28 23:44:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 23:44:35 --> Input Class Initialized
INFO - 2022-03-28 23:44:35 --> Language Class Initialized
INFO - 2022-03-28 23:44:35 --> Loader Class Initialized
INFO - 2022-03-28 23:44:35 --> Helper loaded: url_helper
INFO - 2022-03-28 23:44:35 --> Helper loaded: form_helper
INFO - 2022-03-28 23:44:35 --> Helper loaded: common_helper
INFO - 2022-03-28 23:44:35 --> Database Driver Class Initialized
DEBUG - 2022-03-28 23:44:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 23:44:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 23:44:35 --> Controller Class Initialized
INFO - 2022-03-28 23:44:35 --> Form Validation Class Initialized
DEBUG - 2022-03-28 23:44:35 --> Encrypt Class Initialized
INFO - 2022-03-28 23:44:35 --> Model "Patient_model" initialized
INFO - 2022-03-28 23:44:35 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 23:44:35 --> Model "Prefix_master" initialized
INFO - 2022-03-28 23:44:35 --> Model "Users_model" initialized
INFO - 2022-03-28 23:44:35 --> Model "Hospital_model" initialized
INFO - 2022-03-28 23:44:35 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-28 23:44:35 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-28 23:44:35 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-28 23:44:35 --> Final output sent to browser
DEBUG - 2022-03-28 23:44:35 --> Total execution time: 0.0388
ERROR - 2022-03-28 23:44:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 23:44:42 --> Config Class Initialized
INFO - 2022-03-28 23:44:42 --> Hooks Class Initialized
DEBUG - 2022-03-28 23:44:42 --> UTF-8 Support Enabled
INFO - 2022-03-28 23:44:42 --> Utf8 Class Initialized
INFO - 2022-03-28 23:44:42 --> URI Class Initialized
INFO - 2022-03-28 23:44:42 --> Router Class Initialized
INFO - 2022-03-28 23:44:42 --> Output Class Initialized
INFO - 2022-03-28 23:44:42 --> Security Class Initialized
DEBUG - 2022-03-28 23:44:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 23:44:42 --> Input Class Initialized
INFO - 2022-03-28 23:44:42 --> Language Class Initialized
INFO - 2022-03-28 23:44:42 --> Loader Class Initialized
INFO - 2022-03-28 23:44:42 --> Helper loaded: url_helper
INFO - 2022-03-28 23:44:42 --> Helper loaded: form_helper
INFO - 2022-03-28 23:44:42 --> Helper loaded: common_helper
INFO - 2022-03-28 23:44:42 --> Database Driver Class Initialized
DEBUG - 2022-03-28 23:44:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 23:44:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 23:44:42 --> Controller Class Initialized
INFO - 2022-03-28 23:44:42 --> Form Validation Class Initialized
DEBUG - 2022-03-28 23:44:42 --> Encrypt Class Initialized
INFO - 2022-03-28 23:44:42 --> Model "Patient_model" initialized
INFO - 2022-03-28 23:44:42 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 23:44:42 --> Model "Referredby_model" initialized
INFO - 2022-03-28 23:44:42 --> Model "Prefix_master" initialized
INFO - 2022-03-28 23:44:42 --> Model "Hospital_model" initialized
INFO - 2022-03-28 23:44:42 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-28 23:44:42 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-28 23:44:42 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-28 23:44:42 --> Final output sent to browser
DEBUG - 2022-03-28 23:44:42 --> Total execution time: 0.0547
ERROR - 2022-03-28 23:53:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 23:53:52 --> Config Class Initialized
INFO - 2022-03-28 23:53:52 --> Hooks Class Initialized
DEBUG - 2022-03-28 23:53:52 --> UTF-8 Support Enabled
INFO - 2022-03-28 23:53:52 --> Utf8 Class Initialized
INFO - 2022-03-28 23:53:52 --> URI Class Initialized
INFO - 2022-03-28 23:53:52 --> Router Class Initialized
INFO - 2022-03-28 23:53:52 --> Output Class Initialized
INFO - 2022-03-28 23:53:52 --> Security Class Initialized
DEBUG - 2022-03-28 23:53:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 23:53:52 --> Input Class Initialized
INFO - 2022-03-28 23:53:52 --> Language Class Initialized
INFO - 2022-03-28 23:53:52 --> Loader Class Initialized
INFO - 2022-03-28 23:53:52 --> Helper loaded: url_helper
INFO - 2022-03-28 23:53:52 --> Helper loaded: form_helper
INFO - 2022-03-28 23:53:52 --> Helper loaded: common_helper
INFO - 2022-03-28 23:53:52 --> Database Driver Class Initialized
DEBUG - 2022-03-28 23:53:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 23:53:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 23:53:52 --> Controller Class Initialized
INFO - 2022-03-28 23:53:52 --> Model "Referredby_model" initialized
INFO - 2022-03-28 23:53:52 --> Final output sent to browser
DEBUG - 2022-03-28 23:53:52 --> Total execution time: 0.0439
ERROR - 2022-03-28 23:54:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 23:54:02 --> Config Class Initialized
INFO - 2022-03-28 23:54:02 --> Hooks Class Initialized
DEBUG - 2022-03-28 23:54:02 --> UTF-8 Support Enabled
INFO - 2022-03-28 23:54:02 --> Utf8 Class Initialized
INFO - 2022-03-28 23:54:02 --> URI Class Initialized
INFO - 2022-03-28 23:54:02 --> Router Class Initialized
INFO - 2022-03-28 23:54:02 --> Output Class Initialized
INFO - 2022-03-28 23:54:02 --> Security Class Initialized
DEBUG - 2022-03-28 23:54:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 23:54:02 --> Input Class Initialized
INFO - 2022-03-28 23:54:02 --> Language Class Initialized
INFO - 2022-03-28 23:54:02 --> Loader Class Initialized
INFO - 2022-03-28 23:54:02 --> Helper loaded: url_helper
INFO - 2022-03-28 23:54:02 --> Helper loaded: form_helper
INFO - 2022-03-28 23:54:02 --> Helper loaded: common_helper
INFO - 2022-03-28 23:54:02 --> Database Driver Class Initialized
DEBUG - 2022-03-28 23:54:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 23:54:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 23:54:02 --> Controller Class Initialized
INFO - 2022-03-28 23:54:02 --> Model "Referredby_model" initialized
INFO - 2022-03-28 23:54:02 --> Final output sent to browser
DEBUG - 2022-03-28 23:54:02 --> Total execution time: 0.0092
ERROR - 2022-03-28 23:54:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 23:54:47 --> Config Class Initialized
INFO - 2022-03-28 23:54:47 --> Hooks Class Initialized
DEBUG - 2022-03-28 23:54:47 --> UTF-8 Support Enabled
INFO - 2022-03-28 23:54:47 --> Utf8 Class Initialized
INFO - 2022-03-28 23:54:47 --> URI Class Initialized
INFO - 2022-03-28 23:54:47 --> Router Class Initialized
INFO - 2022-03-28 23:54:47 --> Output Class Initialized
INFO - 2022-03-28 23:54:47 --> Security Class Initialized
DEBUG - 2022-03-28 23:54:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 23:54:47 --> Input Class Initialized
INFO - 2022-03-28 23:54:47 --> Language Class Initialized
INFO - 2022-03-28 23:54:47 --> Loader Class Initialized
INFO - 2022-03-28 23:54:47 --> Helper loaded: url_helper
INFO - 2022-03-28 23:54:47 --> Helper loaded: form_helper
INFO - 2022-03-28 23:54:47 --> Helper loaded: common_helper
INFO - 2022-03-28 23:54:47 --> Database Driver Class Initialized
DEBUG - 2022-03-28 23:54:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 23:54:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 23:54:47 --> Controller Class Initialized
INFO - 2022-03-28 23:54:47 --> Form Validation Class Initialized
DEBUG - 2022-03-28 23:54:47 --> Encrypt Class Initialized
INFO - 2022-03-28 23:54:47 --> Model "Patient_model" initialized
INFO - 2022-03-28 23:54:47 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 23:54:47 --> Model "Referredby_model" initialized
INFO - 2022-03-28 23:54:47 --> Model "Prefix_master" initialized
INFO - 2022-03-28 23:54:47 --> Model "Hospital_model" initialized
INFO - 2022-03-28 23:54:47 --> Final output sent to browser
DEBUG - 2022-03-28 23:54:47 --> Total execution time: 0.0198
ERROR - 2022-03-28 23:56:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 23:56:23 --> Config Class Initialized
INFO - 2022-03-28 23:56:23 --> Hooks Class Initialized
DEBUG - 2022-03-28 23:56:23 --> UTF-8 Support Enabled
INFO - 2022-03-28 23:56:23 --> Utf8 Class Initialized
INFO - 2022-03-28 23:56:23 --> URI Class Initialized
INFO - 2022-03-28 23:56:23 --> Router Class Initialized
INFO - 2022-03-28 23:56:23 --> Output Class Initialized
INFO - 2022-03-28 23:56:23 --> Security Class Initialized
DEBUG - 2022-03-28 23:56:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 23:56:23 --> Input Class Initialized
INFO - 2022-03-28 23:56:23 --> Language Class Initialized
INFO - 2022-03-28 23:56:23 --> Loader Class Initialized
INFO - 2022-03-28 23:56:23 --> Helper loaded: url_helper
INFO - 2022-03-28 23:56:23 --> Helper loaded: form_helper
INFO - 2022-03-28 23:56:23 --> Helper loaded: common_helper
INFO - 2022-03-28 23:56:23 --> Database Driver Class Initialized
DEBUG - 2022-03-28 23:56:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 23:56:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 23:56:23 --> Controller Class Initialized
INFO - 2022-03-28 23:56:23 --> Form Validation Class Initialized
DEBUG - 2022-03-28 23:56:23 --> Encrypt Class Initialized
INFO - 2022-03-28 23:56:23 --> Model "Patient_model" initialized
INFO - 2022-03-28 23:56:23 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 23:56:23 --> Model "Prefix_master" initialized
INFO - 2022-03-28 23:56:23 --> Model "Users_model" initialized
INFO - 2022-03-28 23:56:23 --> Model "Hospital_model" initialized
INFO - 2022-03-28 23:56:23 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-28 23:56:24 --> Final output sent to browser
DEBUG - 2022-03-28 23:56:24 --> Total execution time: 1.0118
ERROR - 2022-03-28 23:56:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 23:56:49 --> Config Class Initialized
INFO - 2022-03-28 23:56:49 --> Hooks Class Initialized
DEBUG - 2022-03-28 23:56:49 --> UTF-8 Support Enabled
INFO - 2022-03-28 23:56:49 --> Utf8 Class Initialized
INFO - 2022-03-28 23:56:49 --> URI Class Initialized
INFO - 2022-03-28 23:56:49 --> Router Class Initialized
INFO - 2022-03-28 23:56:49 --> Output Class Initialized
INFO - 2022-03-28 23:56:49 --> Security Class Initialized
DEBUG - 2022-03-28 23:56:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 23:56:49 --> Input Class Initialized
INFO - 2022-03-28 23:56:49 --> Language Class Initialized
INFO - 2022-03-28 23:56:49 --> Loader Class Initialized
INFO - 2022-03-28 23:56:49 --> Helper loaded: url_helper
INFO - 2022-03-28 23:56:49 --> Helper loaded: form_helper
INFO - 2022-03-28 23:56:49 --> Helper loaded: common_helper
INFO - 2022-03-28 23:56:49 --> Database Driver Class Initialized
DEBUG - 2022-03-28 23:56:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 23:56:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 23:56:49 --> Controller Class Initialized
INFO - 2022-03-28 23:56:49 --> Form Validation Class Initialized
DEBUG - 2022-03-28 23:56:49 --> Encrypt Class Initialized
INFO - 2022-03-28 23:56:49 --> Model "Patient_model" initialized
INFO - 2022-03-28 23:56:49 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 23:56:49 --> Model "Prefix_master" initialized
INFO - 2022-03-28 23:56:49 --> Model "Users_model" initialized
INFO - 2022-03-28 23:56:49 --> Model "Hospital_model" initialized
INFO - 2022-03-28 23:56:49 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-28 23:56:50 --> Final output sent to browser
DEBUG - 2022-03-28 23:56:50 --> Total execution time: 0.6489
ERROR - 2022-03-28 23:57:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 23:57:37 --> Config Class Initialized
INFO - 2022-03-28 23:57:37 --> Hooks Class Initialized
DEBUG - 2022-03-28 23:57:37 --> UTF-8 Support Enabled
INFO - 2022-03-28 23:57:37 --> Utf8 Class Initialized
INFO - 2022-03-28 23:57:37 --> URI Class Initialized
INFO - 2022-03-28 23:57:37 --> Router Class Initialized
INFO - 2022-03-28 23:57:37 --> Output Class Initialized
INFO - 2022-03-28 23:57:37 --> Security Class Initialized
DEBUG - 2022-03-28 23:57:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 23:57:37 --> Input Class Initialized
INFO - 2022-03-28 23:57:37 --> Language Class Initialized
INFO - 2022-03-28 23:57:37 --> Loader Class Initialized
INFO - 2022-03-28 23:57:37 --> Helper loaded: url_helper
INFO - 2022-03-28 23:57:37 --> Helper loaded: form_helper
INFO - 2022-03-28 23:57:37 --> Helper loaded: common_helper
INFO - 2022-03-28 23:57:37 --> Database Driver Class Initialized
DEBUG - 2022-03-28 23:57:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 23:57:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 23:57:37 --> Controller Class Initialized
INFO - 2022-03-28 23:57:37 --> Form Validation Class Initialized
DEBUG - 2022-03-28 23:57:37 --> Encrypt Class Initialized
INFO - 2022-03-28 23:57:37 --> Model "Patient_model" initialized
INFO - 2022-03-28 23:57:37 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 23:57:37 --> Model "Referredby_model" initialized
INFO - 2022-03-28 23:57:37 --> Model "Prefix_master" initialized
INFO - 2022-03-28 23:57:37 --> Model "Hospital_model" initialized
INFO - 2022-03-28 23:57:37 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-28 23:57:37 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-28 23:57:37 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-28 23:57:37 --> Final output sent to browser
DEBUG - 2022-03-28 23:57:37 --> Total execution time: 0.0279
ERROR - 2022-03-28 23:57:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 23:57:42 --> Config Class Initialized
INFO - 2022-03-28 23:57:42 --> Hooks Class Initialized
DEBUG - 2022-03-28 23:57:42 --> UTF-8 Support Enabled
INFO - 2022-03-28 23:57:42 --> Utf8 Class Initialized
INFO - 2022-03-28 23:57:42 --> URI Class Initialized
INFO - 2022-03-28 23:57:42 --> Router Class Initialized
INFO - 2022-03-28 23:57:42 --> Output Class Initialized
INFO - 2022-03-28 23:57:42 --> Security Class Initialized
DEBUG - 2022-03-28 23:57:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 23:57:42 --> Input Class Initialized
INFO - 2022-03-28 23:57:42 --> Language Class Initialized
INFO - 2022-03-28 23:57:42 --> Loader Class Initialized
INFO - 2022-03-28 23:57:42 --> Helper loaded: url_helper
INFO - 2022-03-28 23:57:42 --> Helper loaded: form_helper
INFO - 2022-03-28 23:57:42 --> Helper loaded: common_helper
INFO - 2022-03-28 23:57:42 --> Database Driver Class Initialized
DEBUG - 2022-03-28 23:57:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 23:57:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 23:57:42 --> Controller Class Initialized
INFO - 2022-03-28 23:57:42 --> Form Validation Class Initialized
DEBUG - 2022-03-28 23:57:42 --> Encrypt Class Initialized
INFO - 2022-03-28 23:57:42 --> Model "Patient_model" initialized
INFO - 2022-03-28 23:57:42 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 23:57:42 --> Model "Referredby_model" initialized
INFO - 2022-03-28 23:57:42 --> Model "Prefix_master" initialized
INFO - 2022-03-28 23:57:42 --> Model "Hospital_model" initialized
ERROR - 2022-03-28 23:57:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 23:57:42 --> Config Class Initialized
INFO - 2022-03-28 23:57:42 --> Hooks Class Initialized
DEBUG - 2022-03-28 23:57:42 --> UTF-8 Support Enabled
INFO - 2022-03-28 23:57:42 --> Utf8 Class Initialized
INFO - 2022-03-28 23:57:42 --> URI Class Initialized
INFO - 2022-03-28 23:57:42 --> Router Class Initialized
INFO - 2022-03-28 23:57:42 --> Output Class Initialized
INFO - 2022-03-28 23:57:42 --> Security Class Initialized
DEBUG - 2022-03-28 23:57:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 23:57:42 --> Input Class Initialized
INFO - 2022-03-28 23:57:42 --> Language Class Initialized
INFO - 2022-03-28 23:57:42 --> Loader Class Initialized
INFO - 2022-03-28 23:57:42 --> Helper loaded: url_helper
INFO - 2022-03-28 23:57:42 --> Helper loaded: form_helper
INFO - 2022-03-28 23:57:42 --> Helper loaded: common_helper
INFO - 2022-03-28 23:57:42 --> Database Driver Class Initialized
DEBUG - 2022-03-28 23:57:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 23:57:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 23:57:42 --> Controller Class Initialized
INFO - 2022-03-28 23:57:42 --> Form Validation Class Initialized
DEBUG - 2022-03-28 23:57:42 --> Encrypt Class Initialized
INFO - 2022-03-28 23:57:42 --> Model "Patient_model" initialized
INFO - 2022-03-28 23:57:42 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 23:57:42 --> Model "Referredby_model" initialized
INFO - 2022-03-28 23:57:42 --> Model "Prefix_master" initialized
INFO - 2022-03-28 23:57:42 --> Model "Hospital_model" initialized
INFO - 2022-03-28 23:57:42 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-28 23:57:42 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-28 23:57:42 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-28 23:57:42 --> Final output sent to browser
DEBUG - 2022-03-28 23:57:42 --> Total execution time: 0.0276
ERROR - 2022-03-28 23:57:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 23:57:43 --> Config Class Initialized
INFO - 2022-03-28 23:57:43 --> Hooks Class Initialized
DEBUG - 2022-03-28 23:57:43 --> UTF-8 Support Enabled
INFO - 2022-03-28 23:57:43 --> Utf8 Class Initialized
INFO - 2022-03-28 23:57:43 --> URI Class Initialized
INFO - 2022-03-28 23:57:43 --> Router Class Initialized
INFO - 2022-03-28 23:57:43 --> Output Class Initialized
INFO - 2022-03-28 23:57:43 --> Security Class Initialized
DEBUG - 2022-03-28 23:57:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 23:57:43 --> Input Class Initialized
INFO - 2022-03-28 23:57:43 --> Language Class Initialized
INFO - 2022-03-28 23:57:43 --> Loader Class Initialized
INFO - 2022-03-28 23:57:43 --> Helper loaded: url_helper
INFO - 2022-03-28 23:57:43 --> Helper loaded: form_helper
INFO - 2022-03-28 23:57:43 --> Helper loaded: common_helper
INFO - 2022-03-28 23:57:43 --> Database Driver Class Initialized
DEBUG - 2022-03-28 23:57:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 23:57:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 23:57:43 --> Controller Class Initialized
INFO - 2022-03-28 23:57:43 --> Form Validation Class Initialized
DEBUG - 2022-03-28 23:57:43 --> Encrypt Class Initialized
INFO - 2022-03-28 23:57:43 --> Model "Patient_model" initialized
INFO - 2022-03-28 23:57:43 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 23:57:43 --> Model "Prefix_master" initialized
INFO - 2022-03-28 23:57:43 --> Model "Users_model" initialized
INFO - 2022-03-28 23:57:43 --> Model "Hospital_model" initialized
INFO - 2022-03-28 23:57:43 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-28 23:57:43 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-28 23:57:43 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-28 23:57:43 --> Final output sent to browser
DEBUG - 2022-03-28 23:57:43 --> Total execution time: 0.0459
ERROR - 2022-03-28 23:58:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 23:58:29 --> Config Class Initialized
INFO - 2022-03-28 23:58:29 --> Hooks Class Initialized
DEBUG - 2022-03-28 23:58:29 --> UTF-8 Support Enabled
INFO - 2022-03-28 23:58:29 --> Utf8 Class Initialized
INFO - 2022-03-28 23:58:29 --> URI Class Initialized
INFO - 2022-03-28 23:58:29 --> Router Class Initialized
INFO - 2022-03-28 23:58:29 --> Output Class Initialized
INFO - 2022-03-28 23:58:29 --> Security Class Initialized
DEBUG - 2022-03-28 23:58:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 23:58:29 --> Input Class Initialized
INFO - 2022-03-28 23:58:29 --> Language Class Initialized
INFO - 2022-03-28 23:58:29 --> Loader Class Initialized
INFO - 2022-03-28 23:58:29 --> Helper loaded: url_helper
INFO - 2022-03-28 23:58:29 --> Helper loaded: form_helper
INFO - 2022-03-28 23:58:29 --> Helper loaded: common_helper
INFO - 2022-03-28 23:58:29 --> Database Driver Class Initialized
DEBUG - 2022-03-28 23:58:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 23:58:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 23:58:29 --> Controller Class Initialized
INFO - 2022-03-28 23:58:29 --> Form Validation Class Initialized
DEBUG - 2022-03-28 23:58:29 --> Encrypt Class Initialized
INFO - 2022-03-28 23:58:29 --> Model "Patient_model" initialized
INFO - 2022-03-28 23:58:29 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 23:58:29 --> Model "Prefix_master" initialized
INFO - 2022-03-28 23:58:29 --> Model "Users_model" initialized
INFO - 2022-03-28 23:58:29 --> Model "Hospital_model" initialized
ERROR - 2022-03-28 23:58:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 23:58:29 --> Config Class Initialized
INFO - 2022-03-28 23:58:29 --> Hooks Class Initialized
DEBUG - 2022-03-28 23:58:29 --> UTF-8 Support Enabled
INFO - 2022-03-28 23:58:29 --> Utf8 Class Initialized
INFO - 2022-03-28 23:58:29 --> URI Class Initialized
INFO - 2022-03-28 23:58:29 --> Router Class Initialized
INFO - 2022-03-28 23:58:29 --> Output Class Initialized
INFO - 2022-03-28 23:58:29 --> Security Class Initialized
DEBUG - 2022-03-28 23:58:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 23:58:29 --> Input Class Initialized
INFO - 2022-03-28 23:58:29 --> Language Class Initialized
INFO - 2022-03-28 23:58:29 --> Loader Class Initialized
INFO - 2022-03-28 23:58:29 --> Helper loaded: url_helper
INFO - 2022-03-28 23:58:29 --> Helper loaded: form_helper
INFO - 2022-03-28 23:58:29 --> Helper loaded: common_helper
INFO - 2022-03-28 23:58:29 --> Database Driver Class Initialized
DEBUG - 2022-03-28 23:58:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 23:58:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 23:58:29 --> Controller Class Initialized
INFO - 2022-03-28 23:58:29 --> Form Validation Class Initialized
DEBUG - 2022-03-28 23:58:29 --> Encrypt Class Initialized
INFO - 2022-03-28 23:58:29 --> Model "Patient_model" initialized
INFO - 2022-03-28 23:58:29 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 23:58:29 --> Model "Prefix_master" initialized
INFO - 2022-03-28 23:58:29 --> Model "Users_model" initialized
INFO - 2022-03-28 23:58:29 --> Model "Hospital_model" initialized
INFO - 2022-03-28 23:58:29 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-28 23:58:29 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-28 23:58:29 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-28 23:58:29 --> Final output sent to browser
DEBUG - 2022-03-28 23:58:29 --> Total execution time: 0.0391
ERROR - 2022-03-28 23:58:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 23:58:38 --> Config Class Initialized
INFO - 2022-03-28 23:58:38 --> Hooks Class Initialized
DEBUG - 2022-03-28 23:58:38 --> UTF-8 Support Enabled
INFO - 2022-03-28 23:58:38 --> Utf8 Class Initialized
INFO - 2022-03-28 23:58:38 --> URI Class Initialized
INFO - 2022-03-28 23:58:38 --> Router Class Initialized
INFO - 2022-03-28 23:58:38 --> Output Class Initialized
INFO - 2022-03-28 23:58:38 --> Security Class Initialized
DEBUG - 2022-03-28 23:58:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 23:58:38 --> Input Class Initialized
INFO - 2022-03-28 23:58:38 --> Language Class Initialized
INFO - 2022-03-28 23:58:38 --> Loader Class Initialized
INFO - 2022-03-28 23:58:38 --> Helper loaded: url_helper
INFO - 2022-03-28 23:58:38 --> Helper loaded: form_helper
INFO - 2022-03-28 23:58:38 --> Helper loaded: common_helper
INFO - 2022-03-28 23:58:38 --> Database Driver Class Initialized
DEBUG - 2022-03-28 23:58:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 23:58:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 23:58:38 --> Controller Class Initialized
INFO - 2022-03-28 23:58:38 --> Form Validation Class Initialized
DEBUG - 2022-03-28 23:58:38 --> Encrypt Class Initialized
INFO - 2022-03-28 23:58:38 --> Model "Patient_model" initialized
INFO - 2022-03-28 23:58:38 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 23:58:38 --> Model "Referredby_model" initialized
INFO - 2022-03-28 23:58:38 --> Model "Prefix_master" initialized
INFO - 2022-03-28 23:58:38 --> Model "Hospital_model" initialized
INFO - 2022-03-28 23:58:38 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-28 23:58:38 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-28 23:58:38 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-28 23:58:38 --> Final output sent to browser
DEBUG - 2022-03-28 23:58:38 --> Total execution time: 0.0497
ERROR - 2022-03-28 23:58:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 23:58:59 --> Config Class Initialized
INFO - 2022-03-28 23:58:59 --> Hooks Class Initialized
DEBUG - 2022-03-28 23:58:59 --> UTF-8 Support Enabled
INFO - 2022-03-28 23:58:59 --> Utf8 Class Initialized
INFO - 2022-03-28 23:58:59 --> URI Class Initialized
INFO - 2022-03-28 23:58:59 --> Router Class Initialized
INFO - 2022-03-28 23:58:59 --> Output Class Initialized
INFO - 2022-03-28 23:58:59 --> Security Class Initialized
DEBUG - 2022-03-28 23:58:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 23:58:59 --> Input Class Initialized
INFO - 2022-03-28 23:58:59 --> Language Class Initialized
INFO - 2022-03-28 23:58:59 --> Loader Class Initialized
INFO - 2022-03-28 23:58:59 --> Helper loaded: url_helper
INFO - 2022-03-28 23:58:59 --> Helper loaded: form_helper
INFO - 2022-03-28 23:58:59 --> Helper loaded: common_helper
INFO - 2022-03-28 23:58:59 --> Database Driver Class Initialized
DEBUG - 2022-03-28 23:58:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 23:58:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 23:58:59 --> Controller Class Initialized
INFO - 2022-03-28 23:58:59 --> Form Validation Class Initialized
DEBUG - 2022-03-28 23:58:59 --> Encrypt Class Initialized
INFO - 2022-03-28 23:58:59 --> Model "Patient_model" initialized
INFO - 2022-03-28 23:58:59 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 23:58:59 --> Model "Referredby_model" initialized
INFO - 2022-03-28 23:58:59 --> Model "Prefix_master" initialized
INFO - 2022-03-28 23:58:59 --> Model "Hospital_model" initialized
INFO - 2022-03-28 23:58:59 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-28 23:58:59 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-28 23:58:59 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-28 23:58:59 --> Final output sent to browser
DEBUG - 2022-03-28 23:58:59 --> Total execution time: 0.0508
ERROR - 2022-03-28 23:59:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-28 23:59:09 --> Config Class Initialized
INFO - 2022-03-28 23:59:09 --> Hooks Class Initialized
DEBUG - 2022-03-28 23:59:09 --> UTF-8 Support Enabled
INFO - 2022-03-28 23:59:09 --> Utf8 Class Initialized
INFO - 2022-03-28 23:59:09 --> URI Class Initialized
INFO - 2022-03-28 23:59:09 --> Router Class Initialized
INFO - 2022-03-28 23:59:09 --> Output Class Initialized
INFO - 2022-03-28 23:59:09 --> Security Class Initialized
DEBUG - 2022-03-28 23:59:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-28 23:59:09 --> Input Class Initialized
INFO - 2022-03-28 23:59:09 --> Language Class Initialized
INFO - 2022-03-28 23:59:09 --> Loader Class Initialized
INFO - 2022-03-28 23:59:09 --> Helper loaded: url_helper
INFO - 2022-03-28 23:59:09 --> Helper loaded: form_helper
INFO - 2022-03-28 23:59:09 --> Helper loaded: common_helper
INFO - 2022-03-28 23:59:09 --> Database Driver Class Initialized
DEBUG - 2022-03-28 23:59:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-28 23:59:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-28 23:59:09 --> Controller Class Initialized
INFO - 2022-03-28 23:59:09 --> Form Validation Class Initialized
DEBUG - 2022-03-28 23:59:09 --> Encrypt Class Initialized
INFO - 2022-03-28 23:59:09 --> Model "Patient_model" initialized
INFO - 2022-03-28 23:59:09 --> Model "Patientcase_model" initialized
INFO - 2022-03-28 23:59:09 --> Model "Prefix_master" initialized
INFO - 2022-03-28 23:59:09 --> Model "Users_model" initialized
INFO - 2022-03-28 23:59:09 --> Model "Hospital_model" initialized
INFO - 2022-03-28 23:59:09 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-28 23:59:09 --> Final output sent to browser
DEBUG - 2022-03-28 23:59:09 --> Total execution time: 0.5885
