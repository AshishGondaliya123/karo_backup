<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-03-04 00:50:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-04 00:50:46 --> Config Class Initialized
INFO - 2022-03-04 00:50:46 --> Hooks Class Initialized
DEBUG - 2022-03-04 00:50:46 --> UTF-8 Support Enabled
INFO - 2022-03-04 00:50:46 --> Utf8 Class Initialized
INFO - 2022-03-04 00:50:46 --> URI Class Initialized
INFO - 2022-03-04 00:50:46 --> Router Class Initialized
INFO - 2022-03-04 00:50:46 --> Output Class Initialized
INFO - 2022-03-04 00:50:46 --> Security Class Initialized
DEBUG - 2022-03-04 00:50:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-04 00:50:46 --> Input Class Initialized
INFO - 2022-03-04 00:50:46 --> Language Class Initialized
ERROR - 2022-03-04 00:50:46 --> 404 Page Not Found: Aws/credentials
ERROR - 2022-03-04 00:50:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-04 00:50:47 --> Config Class Initialized
INFO - 2022-03-04 00:50:47 --> Hooks Class Initialized
DEBUG - 2022-03-04 00:50:47 --> UTF-8 Support Enabled
INFO - 2022-03-04 00:50:47 --> Utf8 Class Initialized
INFO - 2022-03-04 00:50:47 --> URI Class Initialized
INFO - 2022-03-04 00:50:47 --> Router Class Initialized
INFO - 2022-03-04 00:50:47 --> Output Class Initialized
INFO - 2022-03-04 00:50:47 --> Security Class Initialized
DEBUG - 2022-03-04 00:50:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-04 00:50:47 --> Input Class Initialized
INFO - 2022-03-04 00:50:47 --> Language Class Initialized
ERROR - 2022-03-04 00:50:47 --> 404 Page Not Found: Aws/credentials
ERROR - 2022-03-04 01:09:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-04 01:09:46 --> Config Class Initialized
INFO - 2022-03-04 01:09:46 --> Hooks Class Initialized
DEBUG - 2022-03-04 01:09:46 --> UTF-8 Support Enabled
INFO - 2022-03-04 01:09:46 --> Utf8 Class Initialized
INFO - 2022-03-04 01:09:46 --> URI Class Initialized
DEBUG - 2022-03-04 01:09:46 --> No URI present. Default controller set.
INFO - 2022-03-04 01:09:46 --> Router Class Initialized
INFO - 2022-03-04 01:09:46 --> Output Class Initialized
INFO - 2022-03-04 01:09:46 --> Security Class Initialized
DEBUG - 2022-03-04 01:09:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-04 01:09:46 --> Input Class Initialized
INFO - 2022-03-04 01:09:46 --> Language Class Initialized
INFO - 2022-03-04 01:09:46 --> Loader Class Initialized
INFO - 2022-03-04 01:09:46 --> Helper loaded: url_helper
INFO - 2022-03-04 01:09:46 --> Helper loaded: form_helper
INFO - 2022-03-04 01:09:46 --> Helper loaded: common_helper
INFO - 2022-03-04 01:09:46 --> Database Driver Class Initialized
DEBUG - 2022-03-04 01:09:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-04 01:09:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-04 01:09:46 --> Controller Class Initialized
INFO - 2022-03-04 01:09:46 --> Form Validation Class Initialized
DEBUG - 2022-03-04 01:09:46 --> Encrypt Class Initialized
DEBUG - 2022-03-04 01:09:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-04 01:09:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-04 01:09:46 --> Email Class Initialized
INFO - 2022-03-04 01:09:46 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-04 01:09:46 --> Calendar Class Initialized
INFO - 2022-03-04 01:09:46 --> Model "Login_model" initialized
INFO - 2022-03-04 01:09:46 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-04 01:09:46 --> Final output sent to browser
DEBUG - 2022-03-04 01:09:46 --> Total execution time: 0.0326
ERROR - 2022-03-04 06:10:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-04 06:10:23 --> Config Class Initialized
INFO - 2022-03-04 06:10:23 --> Hooks Class Initialized
DEBUG - 2022-03-04 06:10:23 --> UTF-8 Support Enabled
INFO - 2022-03-04 06:10:23 --> Utf8 Class Initialized
INFO - 2022-03-04 06:10:23 --> URI Class Initialized
DEBUG - 2022-03-04 06:10:23 --> No URI present. Default controller set.
INFO - 2022-03-04 06:10:23 --> Router Class Initialized
INFO - 2022-03-04 06:10:23 --> Output Class Initialized
INFO - 2022-03-04 06:10:23 --> Security Class Initialized
DEBUG - 2022-03-04 06:10:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-04 06:10:23 --> Input Class Initialized
INFO - 2022-03-04 06:10:23 --> Language Class Initialized
INFO - 2022-03-04 06:10:23 --> Loader Class Initialized
INFO - 2022-03-04 06:10:23 --> Helper loaded: url_helper
INFO - 2022-03-04 06:10:23 --> Helper loaded: form_helper
INFO - 2022-03-04 06:10:23 --> Helper loaded: common_helper
INFO - 2022-03-04 06:10:23 --> Database Driver Class Initialized
DEBUG - 2022-03-04 06:10:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-04 06:10:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-04 06:10:23 --> Controller Class Initialized
INFO - 2022-03-04 06:10:23 --> Form Validation Class Initialized
DEBUG - 2022-03-04 06:10:23 --> Encrypt Class Initialized
DEBUG - 2022-03-04 06:10:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-04 06:10:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-04 06:10:23 --> Email Class Initialized
INFO - 2022-03-04 06:10:23 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-04 06:10:23 --> Calendar Class Initialized
INFO - 2022-03-04 06:10:23 --> Model "Login_model" initialized
INFO - 2022-03-04 06:10:23 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-04 06:10:23 --> Final output sent to browser
DEBUG - 2022-03-04 06:10:23 --> Total execution time: 0.0336
ERROR - 2022-03-04 06:23:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-04 06:23:57 --> Config Class Initialized
INFO - 2022-03-04 06:23:57 --> Hooks Class Initialized
DEBUG - 2022-03-04 06:23:57 --> UTF-8 Support Enabled
INFO - 2022-03-04 06:23:57 --> Utf8 Class Initialized
INFO - 2022-03-04 06:23:57 --> URI Class Initialized
DEBUG - 2022-03-04 06:23:57 --> No URI present. Default controller set.
INFO - 2022-03-04 06:23:57 --> Router Class Initialized
INFO - 2022-03-04 06:23:57 --> Output Class Initialized
INFO - 2022-03-04 06:23:57 --> Security Class Initialized
DEBUG - 2022-03-04 06:23:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-04 06:23:57 --> Input Class Initialized
INFO - 2022-03-04 06:23:57 --> Language Class Initialized
INFO - 2022-03-04 06:23:57 --> Loader Class Initialized
INFO - 2022-03-04 06:23:57 --> Helper loaded: url_helper
INFO - 2022-03-04 06:23:57 --> Helper loaded: form_helper
INFO - 2022-03-04 06:23:57 --> Helper loaded: common_helper
INFO - 2022-03-04 06:23:57 --> Database Driver Class Initialized
DEBUG - 2022-03-04 06:23:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-04 06:23:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-04 06:23:57 --> Controller Class Initialized
INFO - 2022-03-04 06:23:57 --> Form Validation Class Initialized
DEBUG - 2022-03-04 06:23:57 --> Encrypt Class Initialized
DEBUG - 2022-03-04 06:23:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-04 06:23:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-04 06:23:57 --> Email Class Initialized
INFO - 2022-03-04 06:23:57 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-04 06:23:57 --> Calendar Class Initialized
INFO - 2022-03-04 06:23:57 --> Model "Login_model" initialized
INFO - 2022-03-04 06:23:57 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-04 06:23:57 --> Final output sent to browser
DEBUG - 2022-03-04 06:23:57 --> Total execution time: 0.0235
ERROR - 2022-03-04 10:30:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-04 10:30:52 --> Config Class Initialized
INFO - 2022-03-04 10:30:52 --> Hooks Class Initialized
DEBUG - 2022-03-04 10:30:52 --> UTF-8 Support Enabled
INFO - 2022-03-04 10:30:52 --> Utf8 Class Initialized
INFO - 2022-03-04 10:30:52 --> URI Class Initialized
DEBUG - 2022-03-04 10:30:52 --> No URI present. Default controller set.
INFO - 2022-03-04 10:30:52 --> Router Class Initialized
INFO - 2022-03-04 10:30:52 --> Output Class Initialized
INFO - 2022-03-04 10:30:52 --> Security Class Initialized
DEBUG - 2022-03-04 10:30:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-04 10:30:52 --> Input Class Initialized
INFO - 2022-03-04 10:30:52 --> Language Class Initialized
INFO - 2022-03-04 10:30:52 --> Loader Class Initialized
INFO - 2022-03-04 10:30:52 --> Helper loaded: url_helper
INFO - 2022-03-04 10:30:52 --> Helper loaded: form_helper
INFO - 2022-03-04 10:30:52 --> Helper loaded: common_helper
INFO - 2022-03-04 10:30:52 --> Database Driver Class Initialized
DEBUG - 2022-03-04 10:30:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-04 10:30:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-04 10:30:52 --> Controller Class Initialized
INFO - 2022-03-04 10:30:52 --> Form Validation Class Initialized
DEBUG - 2022-03-04 10:30:52 --> Encrypt Class Initialized
DEBUG - 2022-03-04 10:30:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-04 10:30:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-04 10:30:52 --> Email Class Initialized
INFO - 2022-03-04 10:30:52 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-04 10:30:52 --> Calendar Class Initialized
INFO - 2022-03-04 10:30:52 --> Model "Login_model" initialized
INFO - 2022-03-04 10:30:52 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-04 10:30:52 --> Final output sent to browser
DEBUG - 2022-03-04 10:30:52 --> Total execution time: 0.0350
ERROR - 2022-03-04 14:18:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-04 14:18:27 --> Config Class Initialized
INFO - 2022-03-04 14:18:27 --> Hooks Class Initialized
DEBUG - 2022-03-04 14:18:27 --> UTF-8 Support Enabled
INFO - 2022-03-04 14:18:27 --> Utf8 Class Initialized
INFO - 2022-03-04 14:18:27 --> URI Class Initialized
DEBUG - 2022-03-04 14:18:27 --> No URI present. Default controller set.
INFO - 2022-03-04 14:18:27 --> Router Class Initialized
INFO - 2022-03-04 14:18:27 --> Output Class Initialized
INFO - 2022-03-04 14:18:27 --> Security Class Initialized
DEBUG - 2022-03-04 14:18:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-04 14:18:27 --> Input Class Initialized
INFO - 2022-03-04 14:18:27 --> Language Class Initialized
INFO - 2022-03-04 14:18:27 --> Loader Class Initialized
INFO - 2022-03-04 14:18:27 --> Helper loaded: url_helper
INFO - 2022-03-04 14:18:27 --> Helper loaded: form_helper
INFO - 2022-03-04 14:18:27 --> Helper loaded: common_helper
INFO - 2022-03-04 14:18:27 --> Database Driver Class Initialized
DEBUG - 2022-03-04 14:18:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-04 14:18:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-04 14:18:27 --> Controller Class Initialized
INFO - 2022-03-04 14:18:27 --> Form Validation Class Initialized
DEBUG - 2022-03-04 14:18:27 --> Encrypt Class Initialized
DEBUG - 2022-03-04 14:18:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-04 14:18:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-04 14:18:27 --> Email Class Initialized
INFO - 2022-03-04 14:18:27 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-04 14:18:27 --> Calendar Class Initialized
INFO - 2022-03-04 14:18:27 --> Model "Login_model" initialized
INFO - 2022-03-04 14:18:27 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-04 14:18:27 --> Final output sent to browser
DEBUG - 2022-03-04 14:18:27 --> Total execution time: 0.0307
ERROR - 2022-03-04 14:18:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-04 14:18:28 --> Config Class Initialized
INFO - 2022-03-04 14:18:28 --> Hooks Class Initialized
DEBUG - 2022-03-04 14:18:28 --> UTF-8 Support Enabled
INFO - 2022-03-04 14:18:28 --> Utf8 Class Initialized
INFO - 2022-03-04 14:18:28 --> URI Class Initialized
INFO - 2022-03-04 14:18:28 --> Router Class Initialized
INFO - 2022-03-04 14:18:28 --> Output Class Initialized
INFO - 2022-03-04 14:18:28 --> Security Class Initialized
DEBUG - 2022-03-04 14:18:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-04 14:18:28 --> Input Class Initialized
INFO - 2022-03-04 14:18:28 --> Language Class Initialized
ERROR - 2022-03-04 14:18:28 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2022-03-04 14:18:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-04 14:18:48 --> Config Class Initialized
INFO - 2022-03-04 14:18:48 --> Hooks Class Initialized
DEBUG - 2022-03-04 14:18:48 --> UTF-8 Support Enabled
INFO - 2022-03-04 14:18:48 --> Utf8 Class Initialized
INFO - 2022-03-04 14:18:48 --> URI Class Initialized
INFO - 2022-03-04 14:18:48 --> Router Class Initialized
INFO - 2022-03-04 14:18:48 --> Output Class Initialized
INFO - 2022-03-04 14:18:48 --> Security Class Initialized
DEBUG - 2022-03-04 14:18:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-04 14:18:48 --> Input Class Initialized
INFO - 2022-03-04 14:18:48 --> Language Class Initialized
INFO - 2022-03-04 14:18:48 --> Loader Class Initialized
INFO - 2022-03-04 14:18:48 --> Helper loaded: url_helper
INFO - 2022-03-04 14:18:48 --> Helper loaded: form_helper
INFO - 2022-03-04 14:18:48 --> Helper loaded: common_helper
INFO - 2022-03-04 14:18:48 --> Database Driver Class Initialized
DEBUG - 2022-03-04 14:18:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-04 14:18:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-04 14:18:48 --> Controller Class Initialized
INFO - 2022-03-04 14:18:48 --> Form Validation Class Initialized
DEBUG - 2022-03-04 14:18:48 --> Encrypt Class Initialized
DEBUG - 2022-03-04 14:18:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-04 14:18:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-04 14:18:48 --> Email Class Initialized
INFO - 2022-03-04 14:18:48 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-04 14:18:48 --> Calendar Class Initialized
INFO - 2022-03-04 14:18:48 --> Model "Login_model" initialized
INFO - 2022-03-04 14:18:48 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-04 14:18:48 --> Final output sent to browser
DEBUG - 2022-03-04 14:18:48 --> Total execution time: 0.0227
ERROR - 2022-03-04 14:18:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-04 14:18:49 --> Config Class Initialized
INFO - 2022-03-04 14:18:49 --> Hooks Class Initialized
DEBUG - 2022-03-04 14:18:49 --> UTF-8 Support Enabled
INFO - 2022-03-04 14:18:49 --> Utf8 Class Initialized
INFO - 2022-03-04 14:18:49 --> URI Class Initialized
INFO - 2022-03-04 14:18:49 --> Router Class Initialized
INFO - 2022-03-04 14:18:49 --> Output Class Initialized
INFO - 2022-03-04 14:18:49 --> Security Class Initialized
DEBUG - 2022-03-04 14:18:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-04 14:18:49 --> Input Class Initialized
INFO - 2022-03-04 14:18:49 --> Language Class Initialized
INFO - 2022-03-04 14:18:49 --> Loader Class Initialized
INFO - 2022-03-04 14:18:49 --> Helper loaded: url_helper
INFO - 2022-03-04 14:18:49 --> Helper loaded: form_helper
INFO - 2022-03-04 14:18:49 --> Helper loaded: common_helper
INFO - 2022-03-04 14:18:49 --> Database Driver Class Initialized
DEBUG - 2022-03-04 14:18:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-04 14:18:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-04 14:18:49 --> Controller Class Initialized
INFO - 2022-03-04 14:18:49 --> Form Validation Class Initialized
DEBUG - 2022-03-04 14:18:49 --> Encrypt Class Initialized
DEBUG - 2022-03-04 14:18:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-04 14:18:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-04 14:18:49 --> Email Class Initialized
INFO - 2022-03-04 14:18:49 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-04 14:18:49 --> Calendar Class Initialized
INFO - 2022-03-04 14:18:49 --> Model "Login_model" initialized
ERROR - 2022-03-04 14:18:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-04 14:18:49 --> Config Class Initialized
INFO - 2022-03-04 14:18:49 --> Hooks Class Initialized
DEBUG - 2022-03-04 14:18:49 --> UTF-8 Support Enabled
INFO - 2022-03-04 14:18:49 --> Utf8 Class Initialized
INFO - 2022-03-04 14:18:49 --> URI Class Initialized
INFO - 2022-03-04 14:18:49 --> Router Class Initialized
INFO - 2022-03-04 14:18:49 --> Output Class Initialized
INFO - 2022-03-04 14:18:49 --> Security Class Initialized
DEBUG - 2022-03-04 14:18:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-04 14:18:49 --> Input Class Initialized
INFO - 2022-03-04 14:18:49 --> Language Class Initialized
INFO - 2022-03-04 14:18:49 --> Loader Class Initialized
INFO - 2022-03-04 14:18:49 --> Helper loaded: url_helper
INFO - 2022-03-04 14:18:49 --> Helper loaded: form_helper
INFO - 2022-03-04 14:18:49 --> Helper loaded: common_helper
INFO - 2022-03-04 14:18:49 --> Database Driver Class Initialized
DEBUG - 2022-03-04 14:18:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-04 14:18:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-04 14:18:49 --> Controller Class Initialized
INFO - 2022-03-04 14:18:49 --> Form Validation Class Initialized
DEBUG - 2022-03-04 14:18:49 --> Encrypt Class Initialized
DEBUG - 2022-03-04 14:18:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-04 14:18:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-04 14:18:49 --> Email Class Initialized
INFO - 2022-03-04 14:18:49 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-04 14:18:49 --> Calendar Class Initialized
INFO - 2022-03-04 14:18:49 --> Model "Login_model" initialized
ERROR - 2022-03-04 14:18:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-04 14:18:50 --> Config Class Initialized
INFO - 2022-03-04 14:18:50 --> Hooks Class Initialized
DEBUG - 2022-03-04 14:18:50 --> UTF-8 Support Enabled
INFO - 2022-03-04 14:18:50 --> Utf8 Class Initialized
INFO - 2022-03-04 14:18:50 --> URI Class Initialized
DEBUG - 2022-03-04 14:18:50 --> No URI present. Default controller set.
INFO - 2022-03-04 14:18:50 --> Router Class Initialized
INFO - 2022-03-04 14:18:50 --> Output Class Initialized
INFO - 2022-03-04 14:18:50 --> Security Class Initialized
DEBUG - 2022-03-04 14:18:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-04 14:18:50 --> Input Class Initialized
INFO - 2022-03-04 14:18:50 --> Language Class Initialized
INFO - 2022-03-04 14:18:50 --> Loader Class Initialized
INFO - 2022-03-04 14:18:50 --> Helper loaded: url_helper
INFO - 2022-03-04 14:18:50 --> Helper loaded: form_helper
INFO - 2022-03-04 14:18:50 --> Helper loaded: common_helper
INFO - 2022-03-04 14:18:50 --> Database Driver Class Initialized
DEBUG - 2022-03-04 14:18:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-04 14:18:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-04 14:18:50 --> Controller Class Initialized
INFO - 2022-03-04 14:18:50 --> Form Validation Class Initialized
DEBUG - 2022-03-04 14:18:50 --> Encrypt Class Initialized
DEBUG - 2022-03-04 14:18:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-04 14:18:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-04 14:18:50 --> Email Class Initialized
INFO - 2022-03-04 14:18:50 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-04 14:18:50 --> Calendar Class Initialized
INFO - 2022-03-04 14:18:50 --> Model "Login_model" initialized
INFO - 2022-03-04 14:18:50 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-04 14:18:50 --> Final output sent to browser
DEBUG - 2022-03-04 14:18:50 --> Total execution time: 0.0316
ERROR - 2022-03-04 15:49:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-04 15:49:50 --> Config Class Initialized
INFO - 2022-03-04 15:49:50 --> Hooks Class Initialized
DEBUG - 2022-03-04 15:49:50 --> UTF-8 Support Enabled
INFO - 2022-03-04 15:49:50 --> Utf8 Class Initialized
INFO - 2022-03-04 15:49:50 --> URI Class Initialized
DEBUG - 2022-03-04 15:49:50 --> No URI present. Default controller set.
INFO - 2022-03-04 15:49:50 --> Router Class Initialized
INFO - 2022-03-04 15:49:50 --> Output Class Initialized
INFO - 2022-03-04 15:49:50 --> Security Class Initialized
DEBUG - 2022-03-04 15:49:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-04 15:49:50 --> Input Class Initialized
INFO - 2022-03-04 15:49:50 --> Language Class Initialized
INFO - 2022-03-04 15:49:50 --> Loader Class Initialized
INFO - 2022-03-04 15:49:50 --> Helper loaded: url_helper
INFO - 2022-03-04 15:49:50 --> Helper loaded: form_helper
INFO - 2022-03-04 15:49:50 --> Helper loaded: common_helper
INFO - 2022-03-04 15:49:50 --> Database Driver Class Initialized
DEBUG - 2022-03-04 15:49:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-04 15:49:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-04 15:49:50 --> Controller Class Initialized
INFO - 2022-03-04 15:49:50 --> Form Validation Class Initialized
DEBUG - 2022-03-04 15:49:50 --> Encrypt Class Initialized
DEBUG - 2022-03-04 15:49:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-04 15:49:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-04 15:49:50 --> Email Class Initialized
INFO - 2022-03-04 15:49:50 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-04 15:49:50 --> Calendar Class Initialized
INFO - 2022-03-04 15:49:50 --> Model "Login_model" initialized
INFO - 2022-03-04 15:49:50 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-04 15:49:50 --> Final output sent to browser
DEBUG - 2022-03-04 15:49:50 --> Total execution time: 0.0251
ERROR - 2022-03-04 15:52:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-04 15:52:48 --> Config Class Initialized
INFO - 2022-03-04 15:52:48 --> Hooks Class Initialized
DEBUG - 2022-03-04 15:52:48 --> UTF-8 Support Enabled
INFO - 2022-03-04 15:52:48 --> Utf8 Class Initialized
INFO - 2022-03-04 15:52:48 --> URI Class Initialized
DEBUG - 2022-03-04 15:52:48 --> No URI present. Default controller set.
INFO - 2022-03-04 15:52:48 --> Router Class Initialized
INFO - 2022-03-04 15:52:48 --> Output Class Initialized
INFO - 2022-03-04 15:52:48 --> Security Class Initialized
DEBUG - 2022-03-04 15:52:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-04 15:52:48 --> Input Class Initialized
INFO - 2022-03-04 15:52:48 --> Language Class Initialized
INFO - 2022-03-04 15:52:48 --> Loader Class Initialized
INFO - 2022-03-04 15:52:48 --> Helper loaded: url_helper
INFO - 2022-03-04 15:52:48 --> Helper loaded: form_helper
INFO - 2022-03-04 15:52:48 --> Helper loaded: common_helper
INFO - 2022-03-04 15:52:48 --> Database Driver Class Initialized
DEBUG - 2022-03-04 15:52:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-04 15:52:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-04 15:52:48 --> Controller Class Initialized
INFO - 2022-03-04 15:52:48 --> Form Validation Class Initialized
DEBUG - 2022-03-04 15:52:48 --> Encrypt Class Initialized
DEBUG - 2022-03-04 15:52:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-04 15:52:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-04 15:52:48 --> Email Class Initialized
INFO - 2022-03-04 15:52:48 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-04 15:52:48 --> Calendar Class Initialized
INFO - 2022-03-04 15:52:48 --> Model "Login_model" initialized
INFO - 2022-03-04 15:52:48 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-04 15:52:48 --> Final output sent to browser
DEBUG - 2022-03-04 15:52:48 --> Total execution time: 0.0259
ERROR - 2022-03-04 17:29:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-04 17:29:56 --> Config Class Initialized
INFO - 2022-03-04 17:29:56 --> Hooks Class Initialized
DEBUG - 2022-03-04 17:29:56 --> UTF-8 Support Enabled
INFO - 2022-03-04 17:29:56 --> Utf8 Class Initialized
INFO - 2022-03-04 17:29:56 --> URI Class Initialized
DEBUG - 2022-03-04 17:29:56 --> No URI present. Default controller set.
INFO - 2022-03-04 17:29:56 --> Router Class Initialized
INFO - 2022-03-04 17:29:56 --> Output Class Initialized
INFO - 2022-03-04 17:29:56 --> Security Class Initialized
DEBUG - 2022-03-04 17:29:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-04 17:29:56 --> Input Class Initialized
INFO - 2022-03-04 17:29:56 --> Language Class Initialized
INFO - 2022-03-04 17:29:56 --> Loader Class Initialized
INFO - 2022-03-04 17:29:56 --> Helper loaded: url_helper
INFO - 2022-03-04 17:29:56 --> Helper loaded: form_helper
INFO - 2022-03-04 17:29:56 --> Helper loaded: common_helper
INFO - 2022-03-04 17:29:56 --> Database Driver Class Initialized
DEBUG - 2022-03-04 17:29:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-04 17:29:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-04 17:29:56 --> Controller Class Initialized
INFO - 2022-03-04 17:29:56 --> Form Validation Class Initialized
DEBUG - 2022-03-04 17:29:56 --> Encrypt Class Initialized
DEBUG - 2022-03-04 17:29:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-04 17:29:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-04 17:29:56 --> Email Class Initialized
INFO - 2022-03-04 17:29:56 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-04 17:29:56 --> Calendar Class Initialized
INFO - 2022-03-04 17:29:56 --> Model "Login_model" initialized
INFO - 2022-03-04 17:29:56 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-04 17:29:56 --> Final output sent to browser
DEBUG - 2022-03-04 17:29:56 --> Total execution time: 0.0214
ERROR - 2022-03-04 17:49:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-04 17:49:49 --> Config Class Initialized
INFO - 2022-03-04 17:49:49 --> Hooks Class Initialized
DEBUG - 2022-03-04 17:49:49 --> UTF-8 Support Enabled
INFO - 2022-03-04 17:49:49 --> Utf8 Class Initialized
INFO - 2022-03-04 17:49:49 --> URI Class Initialized
INFO - 2022-03-04 17:49:49 --> Router Class Initialized
INFO - 2022-03-04 17:49:49 --> Output Class Initialized
INFO - 2022-03-04 17:49:49 --> Security Class Initialized
DEBUG - 2022-03-04 17:49:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-04 17:49:49 --> Input Class Initialized
INFO - 2022-03-04 17:49:49 --> Language Class Initialized
ERROR - 2022-03-04 17:49:49 --> 404 Page Not Found: Wordpress/index
ERROR - 2022-03-04 17:49:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-04 17:49:50 --> Config Class Initialized
INFO - 2022-03-04 17:49:50 --> Hooks Class Initialized
DEBUG - 2022-03-04 17:49:50 --> UTF-8 Support Enabled
INFO - 2022-03-04 17:49:50 --> Utf8 Class Initialized
INFO - 2022-03-04 17:49:50 --> URI Class Initialized
DEBUG - 2022-03-04 17:49:50 --> No URI present. Default controller set.
INFO - 2022-03-04 17:49:50 --> Router Class Initialized
INFO - 2022-03-04 17:49:50 --> Output Class Initialized
INFO - 2022-03-04 17:49:50 --> Security Class Initialized
DEBUG - 2022-03-04 17:49:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-04 17:49:50 --> Input Class Initialized
INFO - 2022-03-04 17:49:50 --> Language Class Initialized
INFO - 2022-03-04 17:49:50 --> Loader Class Initialized
INFO - 2022-03-04 17:49:50 --> Helper loaded: url_helper
INFO - 2022-03-04 17:49:50 --> Helper loaded: form_helper
INFO - 2022-03-04 17:49:50 --> Helper loaded: common_helper
INFO - 2022-03-04 17:49:50 --> Database Driver Class Initialized
DEBUG - 2022-03-04 17:49:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-04 17:49:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-04 17:49:50 --> Controller Class Initialized
INFO - 2022-03-04 17:49:50 --> Form Validation Class Initialized
DEBUG - 2022-03-04 17:49:50 --> Encrypt Class Initialized
DEBUG - 2022-03-04 17:49:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-04 17:49:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-04 17:49:50 --> Email Class Initialized
INFO - 2022-03-04 17:49:50 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-04 17:49:50 --> Calendar Class Initialized
INFO - 2022-03-04 17:49:50 --> Model "Login_model" initialized
INFO - 2022-03-04 17:49:50 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-04 17:49:50 --> Final output sent to browser
DEBUG - 2022-03-04 17:49:50 --> Total execution time: 0.0237
ERROR - 2022-03-04 17:49:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-04 17:49:50 --> Config Class Initialized
INFO - 2022-03-04 17:49:50 --> Hooks Class Initialized
DEBUG - 2022-03-04 17:49:50 --> UTF-8 Support Enabled
INFO - 2022-03-04 17:49:50 --> Utf8 Class Initialized
INFO - 2022-03-04 17:49:50 --> URI Class Initialized
INFO - 2022-03-04 17:49:50 --> Router Class Initialized
INFO - 2022-03-04 17:49:50 --> Output Class Initialized
INFO - 2022-03-04 17:49:50 --> Security Class Initialized
DEBUG - 2022-03-04 17:49:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-04 17:49:50 --> Input Class Initialized
INFO - 2022-03-04 17:49:50 --> Language Class Initialized
ERROR - 2022-03-04 17:49:50 --> 404 Page Not Found: Wp/index
ERROR - 2022-03-04 17:49:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-04 17:49:51 --> Config Class Initialized
INFO - 2022-03-04 17:49:51 --> Hooks Class Initialized
DEBUG - 2022-03-04 17:49:51 --> UTF-8 Support Enabled
INFO - 2022-03-04 17:49:51 --> Utf8 Class Initialized
INFO - 2022-03-04 17:49:51 --> URI Class Initialized
INFO - 2022-03-04 17:49:51 --> Router Class Initialized
INFO - 2022-03-04 17:49:51 --> Output Class Initialized
INFO - 2022-03-04 17:49:51 --> Security Class Initialized
DEBUG - 2022-03-04 17:49:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-04 17:49:51 --> Input Class Initialized
INFO - 2022-03-04 17:49:51 --> Language Class Initialized
ERROR - 2022-03-04 17:49:51 --> 404 Page Not Found: Bc/index
ERROR - 2022-03-04 17:49:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-04 17:49:52 --> Config Class Initialized
INFO - 2022-03-04 17:49:52 --> Hooks Class Initialized
DEBUG - 2022-03-04 17:49:52 --> UTF-8 Support Enabled
INFO - 2022-03-04 17:49:52 --> Utf8 Class Initialized
INFO - 2022-03-04 17:49:52 --> URI Class Initialized
INFO - 2022-03-04 17:49:52 --> Router Class Initialized
INFO - 2022-03-04 17:49:52 --> Output Class Initialized
INFO - 2022-03-04 17:49:52 --> Security Class Initialized
DEBUG - 2022-03-04 17:49:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-04 17:49:52 --> Input Class Initialized
INFO - 2022-03-04 17:49:52 --> Language Class Initialized
ERROR - 2022-03-04 17:49:52 --> 404 Page Not Found: Bk/index
ERROR - 2022-03-04 17:49:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-04 17:49:52 --> Config Class Initialized
INFO - 2022-03-04 17:49:52 --> Hooks Class Initialized
DEBUG - 2022-03-04 17:49:52 --> UTF-8 Support Enabled
INFO - 2022-03-04 17:49:52 --> Utf8 Class Initialized
INFO - 2022-03-04 17:49:52 --> URI Class Initialized
INFO - 2022-03-04 17:49:52 --> Router Class Initialized
INFO - 2022-03-04 17:49:52 --> Output Class Initialized
INFO - 2022-03-04 17:49:52 --> Security Class Initialized
DEBUG - 2022-03-04 17:49:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-04 17:49:52 --> Input Class Initialized
INFO - 2022-03-04 17:49:52 --> Language Class Initialized
ERROR - 2022-03-04 17:49:52 --> 404 Page Not Found: Backup/index
ERROR - 2022-03-04 17:49:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-04 17:49:53 --> Config Class Initialized
INFO - 2022-03-04 17:49:53 --> Hooks Class Initialized
DEBUG - 2022-03-04 17:49:53 --> UTF-8 Support Enabled
INFO - 2022-03-04 17:49:53 --> Utf8 Class Initialized
INFO - 2022-03-04 17:49:53 --> URI Class Initialized
INFO - 2022-03-04 17:49:53 --> Router Class Initialized
INFO - 2022-03-04 17:49:53 --> Output Class Initialized
INFO - 2022-03-04 17:49:53 --> Security Class Initialized
DEBUG - 2022-03-04 17:49:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-04 17:49:53 --> Input Class Initialized
INFO - 2022-03-04 17:49:53 --> Language Class Initialized
ERROR - 2022-03-04 17:49:53 --> 404 Page Not Found: Old/index
ERROR - 2022-03-04 17:49:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-04 17:49:53 --> Config Class Initialized
INFO - 2022-03-04 17:49:53 --> Hooks Class Initialized
DEBUG - 2022-03-04 17:49:53 --> UTF-8 Support Enabled
INFO - 2022-03-04 17:49:53 --> Utf8 Class Initialized
INFO - 2022-03-04 17:49:53 --> URI Class Initialized
INFO - 2022-03-04 17:49:53 --> Router Class Initialized
INFO - 2022-03-04 17:49:53 --> Output Class Initialized
INFO - 2022-03-04 17:49:53 --> Security Class Initialized
DEBUG - 2022-03-04 17:49:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-04 17:49:53 --> Input Class Initialized
INFO - 2022-03-04 17:49:53 --> Language Class Initialized
ERROR - 2022-03-04 17:49:53 --> 404 Page Not Found: New/index
ERROR - 2022-03-04 17:49:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-04 17:49:54 --> Config Class Initialized
INFO - 2022-03-04 17:49:54 --> Hooks Class Initialized
DEBUG - 2022-03-04 17:49:54 --> UTF-8 Support Enabled
INFO - 2022-03-04 17:49:54 --> Utf8 Class Initialized
INFO - 2022-03-04 17:49:54 --> URI Class Initialized
INFO - 2022-03-04 17:49:54 --> Router Class Initialized
INFO - 2022-03-04 17:49:54 --> Output Class Initialized
INFO - 2022-03-04 17:49:54 --> Security Class Initialized
DEBUG - 2022-03-04 17:49:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-04 17:49:54 --> Input Class Initialized
INFO - 2022-03-04 17:49:54 --> Language Class Initialized
ERROR - 2022-03-04 17:49:54 --> 404 Page Not Found: Main/index
ERROR - 2022-03-04 17:49:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-04 17:49:54 --> Config Class Initialized
INFO - 2022-03-04 17:49:54 --> Hooks Class Initialized
DEBUG - 2022-03-04 17:49:54 --> UTF-8 Support Enabled
INFO - 2022-03-04 17:49:54 --> Utf8 Class Initialized
INFO - 2022-03-04 17:49:54 --> URI Class Initialized
INFO - 2022-03-04 17:49:54 --> Router Class Initialized
INFO - 2022-03-04 17:49:54 --> Output Class Initialized
INFO - 2022-03-04 17:49:54 --> Security Class Initialized
DEBUG - 2022-03-04 17:49:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-04 17:49:54 --> Input Class Initialized
INFO - 2022-03-04 17:49:54 --> Language Class Initialized
ERROR - 2022-03-04 17:49:54 --> 404 Page Not Found: Home/index
ERROR - 2022-03-04 22:41:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-04 22:41:21 --> Config Class Initialized
INFO - 2022-03-04 22:41:21 --> Hooks Class Initialized
DEBUG - 2022-03-04 22:41:21 --> UTF-8 Support Enabled
INFO - 2022-03-04 22:41:21 --> Utf8 Class Initialized
INFO - 2022-03-04 22:41:21 --> URI Class Initialized
DEBUG - 2022-03-04 22:41:21 --> No URI present. Default controller set.
INFO - 2022-03-04 22:41:21 --> Router Class Initialized
INFO - 2022-03-04 22:41:21 --> Output Class Initialized
INFO - 2022-03-04 22:41:21 --> Security Class Initialized
DEBUG - 2022-03-04 22:41:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-04 22:41:21 --> Input Class Initialized
INFO - 2022-03-04 22:41:21 --> Language Class Initialized
INFO - 2022-03-04 22:41:21 --> Loader Class Initialized
INFO - 2022-03-04 22:41:21 --> Helper loaded: url_helper
INFO - 2022-03-04 22:41:21 --> Helper loaded: form_helper
INFO - 2022-03-04 22:41:21 --> Helper loaded: common_helper
INFO - 2022-03-04 22:41:21 --> Database Driver Class Initialized
DEBUG - 2022-03-04 22:41:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-04 22:41:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-04 22:41:21 --> Controller Class Initialized
INFO - 2022-03-04 22:41:21 --> Form Validation Class Initialized
DEBUG - 2022-03-04 22:41:21 --> Encrypt Class Initialized
DEBUG - 2022-03-04 22:41:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-04 22:41:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-04 22:41:21 --> Email Class Initialized
INFO - 2022-03-04 22:41:21 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-04 22:41:21 --> Calendar Class Initialized
INFO - 2022-03-04 22:41:21 --> Model "Login_model" initialized
INFO - 2022-03-04 22:41:21 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-04 22:41:21 --> Final output sent to browser
DEBUG - 2022-03-04 22:41:21 --> Total execution time: 0.0242
