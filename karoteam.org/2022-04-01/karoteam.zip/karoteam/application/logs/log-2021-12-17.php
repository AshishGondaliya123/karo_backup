<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-12-17 02:51:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-17 02:51:31 --> Config Class Initialized
INFO - 2021-12-17 02:51:31 --> Hooks Class Initialized
DEBUG - 2021-12-17 02:51:31 --> UTF-8 Support Enabled
INFO - 2021-12-17 02:51:31 --> Utf8 Class Initialized
INFO - 2021-12-17 02:51:31 --> URI Class Initialized
DEBUG - 2021-12-17 02:51:31 --> No URI present. Default controller set.
INFO - 2021-12-17 02:51:31 --> Router Class Initialized
INFO - 2021-12-17 02:51:31 --> Output Class Initialized
INFO - 2021-12-17 02:51:31 --> Security Class Initialized
DEBUG - 2021-12-17 02:51:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-17 02:51:31 --> Input Class Initialized
INFO - 2021-12-17 02:51:31 --> Language Class Initialized
INFO - 2021-12-17 02:51:31 --> Loader Class Initialized
INFO - 2021-12-17 02:51:31 --> Helper loaded: url_helper
INFO - 2021-12-17 02:51:31 --> Helper loaded: form_helper
INFO - 2021-12-17 02:51:31 --> Helper loaded: common_helper
INFO - 2021-12-17 02:51:31 --> Database Driver Class Initialized
DEBUG - 2021-12-17 02:51:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-17 02:51:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-17 02:51:31 --> Controller Class Initialized
INFO - 2021-12-17 02:51:31 --> Form Validation Class Initialized
DEBUG - 2021-12-17 02:51:31 --> Encrypt Class Initialized
DEBUG - 2021-12-17 02:51:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-17 02:51:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-17 02:51:31 --> Email Class Initialized
INFO - 2021-12-17 02:51:31 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-17 02:51:31 --> Calendar Class Initialized
INFO - 2021-12-17 02:51:31 --> Model "Login_model" initialized
INFO - 2021-12-17 02:51:31 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-17 02:51:31 --> Final output sent to browser
DEBUG - 2021-12-17 02:51:31 --> Total execution time: 0.0230
ERROR - 2021-12-17 02:51:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-17 02:51:53 --> Config Class Initialized
INFO - 2021-12-17 02:51:53 --> Hooks Class Initialized
DEBUG - 2021-12-17 02:51:53 --> UTF-8 Support Enabled
INFO - 2021-12-17 02:51:53 --> Utf8 Class Initialized
INFO - 2021-12-17 02:51:53 --> URI Class Initialized
INFO - 2021-12-17 02:51:53 --> Router Class Initialized
INFO - 2021-12-17 02:51:53 --> Output Class Initialized
INFO - 2021-12-17 02:51:53 --> Security Class Initialized
DEBUG - 2021-12-17 02:51:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-17 02:51:53 --> Input Class Initialized
INFO - 2021-12-17 02:51:53 --> Language Class Initialized
INFO - 2021-12-17 02:51:53 --> Loader Class Initialized
INFO - 2021-12-17 02:51:53 --> Helper loaded: url_helper
INFO - 2021-12-17 02:51:53 --> Helper loaded: form_helper
INFO - 2021-12-17 02:51:53 --> Helper loaded: common_helper
INFO - 2021-12-17 02:51:53 --> Database Driver Class Initialized
DEBUG - 2021-12-17 02:51:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-17 02:51:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-17 02:51:53 --> Controller Class Initialized
INFO - 2021-12-17 02:51:53 --> Form Validation Class Initialized
DEBUG - 2021-12-17 02:51:53 --> Encrypt Class Initialized
DEBUG - 2021-12-17 02:51:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-17 02:51:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-17 02:51:53 --> Email Class Initialized
INFO - 2021-12-17 02:51:53 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-17 02:51:53 --> Calendar Class Initialized
INFO - 2021-12-17 02:51:53 --> Model "Login_model" initialized
INFO - 2021-12-17 02:51:53 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2021-12-17 02:51:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-17 02:51:54 --> Config Class Initialized
INFO - 2021-12-17 02:51:54 --> Hooks Class Initialized
DEBUG - 2021-12-17 02:51:54 --> UTF-8 Support Enabled
INFO - 2021-12-17 02:51:54 --> Utf8 Class Initialized
INFO - 2021-12-17 02:51:54 --> URI Class Initialized
INFO - 2021-12-17 02:51:54 --> Router Class Initialized
INFO - 2021-12-17 02:51:54 --> Output Class Initialized
INFO - 2021-12-17 02:51:54 --> Security Class Initialized
DEBUG - 2021-12-17 02:51:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-17 02:51:54 --> Input Class Initialized
INFO - 2021-12-17 02:51:54 --> Language Class Initialized
INFO - 2021-12-17 02:51:54 --> Loader Class Initialized
INFO - 2021-12-17 02:51:54 --> Helper loaded: url_helper
INFO - 2021-12-17 02:51:54 --> Helper loaded: form_helper
INFO - 2021-12-17 02:51:54 --> Helper loaded: common_helper
INFO - 2021-12-17 02:51:54 --> Database Driver Class Initialized
DEBUG - 2021-12-17 02:51:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-17 02:51:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-17 02:51:54 --> Controller Class Initialized
INFO - 2021-12-17 02:51:54 --> Form Validation Class Initialized
DEBUG - 2021-12-17 02:51:54 --> Encrypt Class Initialized
INFO - 2021-12-17 02:51:54 --> Model "Login_model" initialized
INFO - 2021-12-17 02:51:54 --> Model "Dashboard_model" initialized
INFO - 2021-12-17 02:51:54 --> Model "Case_model" initialized
ERROR - 2021-12-17 02:51:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-17 02:51:55 --> Config Class Initialized
INFO - 2021-12-17 02:51:55 --> Hooks Class Initialized
DEBUG - 2021-12-17 02:51:55 --> UTF-8 Support Enabled
INFO - 2021-12-17 02:51:55 --> Utf8 Class Initialized
INFO - 2021-12-17 02:51:55 --> URI Class Initialized
INFO - 2021-12-17 02:51:55 --> Router Class Initialized
INFO - 2021-12-17 02:51:55 --> Output Class Initialized
INFO - 2021-12-17 02:51:55 --> Security Class Initialized
DEBUG - 2021-12-17 02:51:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-17 02:51:55 --> Input Class Initialized
INFO - 2021-12-17 02:51:55 --> Language Class Initialized
INFO - 2021-12-17 02:51:55 --> Loader Class Initialized
INFO - 2021-12-17 02:51:55 --> Helper loaded: url_helper
INFO - 2021-12-17 02:51:55 --> Helper loaded: form_helper
INFO - 2021-12-17 02:51:55 --> Helper loaded: common_helper
INFO - 2021-12-17 02:51:55 --> Database Driver Class Initialized
DEBUG - 2021-12-17 02:51:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-17 02:51:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-17 02:51:57 --> Config Class Initialized
INFO - 2021-12-17 02:51:57 --> Hooks Class Initialized
DEBUG - 2021-12-17 02:51:57 --> UTF-8 Support Enabled
INFO - 2021-12-17 02:51:57 --> Utf8 Class Initialized
INFO - 2021-12-17 02:51:57 --> URI Class Initialized
INFO - 2021-12-17 02:51:57 --> Router Class Initialized
INFO - 2021-12-17 02:51:57 --> Output Class Initialized
INFO - 2021-12-17 02:51:57 --> Security Class Initialized
DEBUG - 2021-12-17 02:51:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-17 02:51:57 --> Input Class Initialized
INFO - 2021-12-17 02:51:57 --> Language Class Initialized
INFO - 2021-12-17 02:51:57 --> Loader Class Initialized
INFO - 2021-12-17 02:51:57 --> Helper loaded: url_helper
INFO - 2021-12-17 02:51:57 --> Helper loaded: form_helper
INFO - 2021-12-17 02:51:57 --> Helper loaded: common_helper
INFO - 2021-12-17 02:51:57 --> Database Driver Class Initialized
DEBUG - 2021-12-17 02:51:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-17 02:52:03 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-17 02:52:14 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2021-12-17 02:52:14 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-17 02:52:14 --> Final output sent to browser
DEBUG - 2021-12-17 02:52:14 --> Total execution time: 20.0794
INFO - 2021-12-17 02:52:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-17 02:52:14 --> Controller Class Initialized
INFO - 2021-12-17 02:52:14 --> Form Validation Class Initialized
DEBUG - 2021-12-17 02:52:14 --> Encrypt Class Initialized
DEBUG - 2021-12-17 02:52:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-17 02:52:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-17 02:52:14 --> Email Class Initialized
INFO - 2021-12-17 02:52:14 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-17 02:52:14 --> Calendar Class Initialized
INFO - 2021-12-17 02:52:14 --> Model "Login_model" initialized
INFO - 2021-12-17 02:52:14 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2021-12-17 02:52:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-17 02:52:14 --> Controller Class Initialized
INFO - 2021-12-17 02:52:14 --> Form Validation Class Initialized
DEBUG - 2021-12-17 02:52:14 --> Encrypt Class Initialized
DEBUG - 2021-12-17 02:52:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-17 02:52:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-17 02:52:14 --> Email Class Initialized
INFO - 2021-12-17 02:52:14 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-17 02:52:14 --> Calendar Class Initialized
INFO - 2021-12-17 02:52:14 --> Model "Login_model" initialized
INFO - 2021-12-17 02:52:14 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2021-12-17 02:52:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-17 02:52:16 --> Config Class Initialized
INFO - 2021-12-17 02:52:16 --> Hooks Class Initialized
DEBUG - 2021-12-17 02:52:16 --> UTF-8 Support Enabled
INFO - 2021-12-17 02:52:16 --> Utf8 Class Initialized
INFO - 2021-12-17 02:52:16 --> URI Class Initialized
INFO - 2021-12-17 02:52:16 --> Router Class Initialized
INFO - 2021-12-17 02:52:16 --> Output Class Initialized
INFO - 2021-12-17 02:52:16 --> Security Class Initialized
DEBUG - 2021-12-17 02:52:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-17 02:52:16 --> Input Class Initialized
INFO - 2021-12-17 02:52:16 --> Language Class Initialized
INFO - 2021-12-17 02:52:16 --> Loader Class Initialized
INFO - 2021-12-17 02:52:16 --> Helper loaded: url_helper
INFO - 2021-12-17 02:52:16 --> Helper loaded: form_helper
INFO - 2021-12-17 02:52:16 --> Helper loaded: common_helper
INFO - 2021-12-17 02:52:16 --> Database Driver Class Initialized
DEBUG - 2021-12-17 02:52:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-17 02:52:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-17 02:52:16 --> Controller Class Initialized
INFO - 2021-12-17 02:52:16 --> Form Validation Class Initialized
DEBUG - 2021-12-17 02:52:16 --> Encrypt Class Initialized
INFO - 2021-12-17 02:52:16 --> Model "Login_model" initialized
INFO - 2021-12-17 02:52:16 --> Model "Dashboard_model" initialized
INFO - 2021-12-17 02:52:16 --> Model "Case_model" initialized
INFO - 2021-12-17 02:52:24 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-17 02:52:34 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2021-12-17 02:52:34 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-17 02:52:34 --> Final output sent to browser
DEBUG - 2021-12-17 02:52:34 --> Total execution time: 18.1513
ERROR - 2021-12-17 02:52:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-17 02:52:34 --> Config Class Initialized
INFO - 2021-12-17 02:52:34 --> Hooks Class Initialized
DEBUG - 2021-12-17 02:52:34 --> UTF-8 Support Enabled
INFO - 2021-12-17 02:52:34 --> Utf8 Class Initialized
INFO - 2021-12-17 02:52:34 --> URI Class Initialized
INFO - 2021-12-17 02:52:34 --> Router Class Initialized
INFO - 2021-12-17 02:52:34 --> Output Class Initialized
INFO - 2021-12-17 02:52:34 --> Security Class Initialized
DEBUG - 2021-12-17 02:52:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-17 02:52:34 --> Input Class Initialized
INFO - 2021-12-17 02:52:34 --> Language Class Initialized
INFO - 2021-12-17 02:52:34 --> Loader Class Initialized
INFO - 2021-12-17 02:52:34 --> Helper loaded: url_helper
INFO - 2021-12-17 02:52:34 --> Helper loaded: form_helper
INFO - 2021-12-17 02:52:34 --> Helper loaded: common_helper
INFO - 2021-12-17 02:52:34 --> Database Driver Class Initialized
DEBUG - 2021-12-17 02:52:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-17 02:52:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-17 02:52:34 --> Controller Class Initialized
INFO - 2021-12-17 02:52:34 --> Form Validation Class Initialized
DEBUG - 2021-12-17 02:52:34 --> Encrypt Class Initialized
DEBUG - 2021-12-17 02:52:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-17 02:52:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-17 02:52:34 --> Email Class Initialized
INFO - 2021-12-17 02:52:34 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-17 02:52:34 --> Calendar Class Initialized
INFO - 2021-12-17 02:52:34 --> Model "Login_model" initialized
INFO - 2021-12-17 02:52:34 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2021-12-17 02:52:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-17 02:52:35 --> Config Class Initialized
INFO - 2021-12-17 02:52:35 --> Hooks Class Initialized
DEBUG - 2021-12-17 02:52:35 --> UTF-8 Support Enabled
INFO - 2021-12-17 02:52:35 --> Utf8 Class Initialized
INFO - 2021-12-17 02:52:35 --> URI Class Initialized
INFO - 2021-12-17 02:52:35 --> Router Class Initialized
INFO - 2021-12-17 02:52:35 --> Output Class Initialized
INFO - 2021-12-17 02:52:35 --> Security Class Initialized
DEBUG - 2021-12-17 02:52:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-17 02:52:35 --> Input Class Initialized
INFO - 2021-12-17 02:52:35 --> Language Class Initialized
INFO - 2021-12-17 02:52:35 --> Loader Class Initialized
INFO - 2021-12-17 02:52:35 --> Helper loaded: url_helper
INFO - 2021-12-17 02:52:35 --> Helper loaded: form_helper
INFO - 2021-12-17 02:52:35 --> Helper loaded: common_helper
INFO - 2021-12-17 02:52:35 --> Database Driver Class Initialized
DEBUG - 2021-12-17 02:52:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-17 02:52:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-17 02:52:35 --> Controller Class Initialized
INFO - 2021-12-17 02:52:35 --> Form Validation Class Initialized
DEBUG - 2021-12-17 02:52:35 --> Encrypt Class Initialized
INFO - 2021-12-17 02:52:35 --> Model "Login_model" initialized
INFO - 2021-12-17 02:52:35 --> Model "Dashboard_model" initialized
INFO - 2021-12-17 02:52:35 --> Model "Case_model" initialized
ERROR - 2021-12-17 02:52:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-17 02:52:41 --> Config Class Initialized
INFO - 2021-12-17 02:52:41 --> Hooks Class Initialized
DEBUG - 2021-12-17 02:52:41 --> UTF-8 Support Enabled
INFO - 2021-12-17 02:52:41 --> Utf8 Class Initialized
INFO - 2021-12-17 02:52:41 --> URI Class Initialized
INFO - 2021-12-17 02:52:41 --> Router Class Initialized
INFO - 2021-12-17 02:52:41 --> Output Class Initialized
INFO - 2021-12-17 02:52:41 --> Security Class Initialized
DEBUG - 2021-12-17 02:52:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-17 02:52:41 --> Input Class Initialized
INFO - 2021-12-17 02:52:41 --> Language Class Initialized
INFO - 2021-12-17 02:52:41 --> Loader Class Initialized
INFO - 2021-12-17 02:52:41 --> Helper loaded: url_helper
INFO - 2021-12-17 02:52:41 --> Helper loaded: form_helper
INFO - 2021-12-17 02:52:41 --> Helper loaded: common_helper
INFO - 2021-12-17 02:52:41 --> Database Driver Class Initialized
DEBUG - 2021-12-17 02:52:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-17 02:52:43 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-17 02:52:53 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2021-12-17 02:52:53 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-17 02:52:53 --> Final output sent to browser
DEBUG - 2021-12-17 02:52:53 --> Total execution time: 17.8046
INFO - 2021-12-17 02:52:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-17 02:52:53 --> Controller Class Initialized
INFO - 2021-12-17 02:52:53 --> Form Validation Class Initialized
DEBUG - 2021-12-17 02:52:53 --> Encrypt Class Initialized
DEBUG - 2021-12-17 02:52:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-17 02:52:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-17 02:52:53 --> Email Class Initialized
INFO - 2021-12-17 02:52:53 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-17 02:52:53 --> Calendar Class Initialized
INFO - 2021-12-17 02:52:53 --> Model "Login_model" initialized
INFO - 2021-12-17 02:52:53 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2021-12-17 02:52:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-17 02:52:54 --> Config Class Initialized
INFO - 2021-12-17 02:52:54 --> Hooks Class Initialized
DEBUG - 2021-12-17 02:52:54 --> UTF-8 Support Enabled
INFO - 2021-12-17 02:52:54 --> Utf8 Class Initialized
INFO - 2021-12-17 02:52:54 --> URI Class Initialized
INFO - 2021-12-17 02:52:54 --> Router Class Initialized
INFO - 2021-12-17 02:52:54 --> Output Class Initialized
INFO - 2021-12-17 02:52:54 --> Security Class Initialized
DEBUG - 2021-12-17 02:52:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-17 02:52:54 --> Input Class Initialized
INFO - 2021-12-17 02:52:54 --> Language Class Initialized
INFO - 2021-12-17 02:52:54 --> Loader Class Initialized
INFO - 2021-12-17 02:52:54 --> Helper loaded: url_helper
INFO - 2021-12-17 02:52:54 --> Helper loaded: form_helper
INFO - 2021-12-17 02:52:54 --> Helper loaded: common_helper
INFO - 2021-12-17 02:52:54 --> Database Driver Class Initialized
DEBUG - 2021-12-17 02:52:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-17 02:52:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-17 02:52:54 --> Controller Class Initialized
INFO - 2021-12-17 02:52:54 --> Form Validation Class Initialized
DEBUG - 2021-12-17 02:52:54 --> Encrypt Class Initialized
INFO - 2021-12-17 02:52:54 --> Model "Login_model" initialized
INFO - 2021-12-17 02:52:54 --> Model "Dashboard_model" initialized
INFO - 2021-12-17 02:52:54 --> Model "Case_model" initialized
ERROR - 2021-12-17 02:52:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-17 02:52:57 --> Config Class Initialized
INFO - 2021-12-17 02:52:57 --> Hooks Class Initialized
DEBUG - 2021-12-17 02:52:57 --> UTF-8 Support Enabled
INFO - 2021-12-17 02:52:57 --> Utf8 Class Initialized
INFO - 2021-12-17 02:52:57 --> URI Class Initialized
INFO - 2021-12-17 02:52:57 --> Router Class Initialized
INFO - 2021-12-17 02:52:57 --> Output Class Initialized
INFO - 2021-12-17 02:52:57 --> Security Class Initialized
DEBUG - 2021-12-17 02:52:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-17 02:52:57 --> Input Class Initialized
INFO - 2021-12-17 02:52:57 --> Language Class Initialized
INFO - 2021-12-17 02:52:57 --> Loader Class Initialized
INFO - 2021-12-17 02:52:57 --> Helper loaded: url_helper
INFO - 2021-12-17 02:52:57 --> Helper loaded: form_helper
INFO - 2021-12-17 02:52:57 --> Helper loaded: common_helper
INFO - 2021-12-17 02:52:57 --> Database Driver Class Initialized
DEBUG - 2021-12-17 02:52:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-17 02:53:02 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-17 02:53:12 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2021-12-17 02:53:12 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-17 02:53:12 --> Final output sent to browser
DEBUG - 2021-12-17 02:53:12 --> Total execution time: 18.0097
INFO - 2021-12-17 02:53:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-17 02:53:12 --> Controller Class Initialized
INFO - 2021-12-17 02:53:12 --> Form Validation Class Initialized
DEBUG - 2021-12-17 02:53:12 --> Encrypt Class Initialized
DEBUG - 2021-12-17 02:53:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-17 02:53:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-17 02:53:12 --> Email Class Initialized
INFO - 2021-12-17 02:53:12 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-17 02:53:12 --> Calendar Class Initialized
INFO - 2021-12-17 02:53:12 --> Model "Login_model" initialized
INFO - 2021-12-17 02:53:12 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2021-12-17 02:53:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-17 02:53:12 --> Config Class Initialized
INFO - 2021-12-17 02:53:12 --> Hooks Class Initialized
DEBUG - 2021-12-17 02:53:12 --> UTF-8 Support Enabled
INFO - 2021-12-17 02:53:12 --> Utf8 Class Initialized
INFO - 2021-12-17 02:53:12 --> URI Class Initialized
INFO - 2021-12-17 02:53:12 --> Router Class Initialized
INFO - 2021-12-17 02:53:12 --> Output Class Initialized
INFO - 2021-12-17 02:53:12 --> Security Class Initialized
DEBUG - 2021-12-17 02:53:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-17 02:53:12 --> Input Class Initialized
INFO - 2021-12-17 02:53:12 --> Language Class Initialized
INFO - 2021-12-17 02:53:12 --> Loader Class Initialized
INFO - 2021-12-17 02:53:12 --> Helper loaded: url_helper
INFO - 2021-12-17 02:53:12 --> Helper loaded: form_helper
INFO - 2021-12-17 02:53:12 --> Helper loaded: common_helper
INFO - 2021-12-17 02:53:13 --> Database Driver Class Initialized
DEBUG - 2021-12-17 02:53:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-17 02:53:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-17 02:53:13 --> Controller Class Initialized
INFO - 2021-12-17 02:53:13 --> Form Validation Class Initialized
DEBUG - 2021-12-17 02:53:13 --> Encrypt Class Initialized
DEBUG - 2021-12-17 02:53:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-17 02:53:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-17 02:53:13 --> Email Class Initialized
INFO - 2021-12-17 02:53:13 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-17 02:53:13 --> Calendar Class Initialized
INFO - 2021-12-17 02:53:13 --> Model "Login_model" initialized
INFO - 2021-12-17 02:53:13 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2021-12-17 02:53:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-17 02:53:13 --> Config Class Initialized
INFO - 2021-12-17 02:53:13 --> Hooks Class Initialized
DEBUG - 2021-12-17 02:53:13 --> UTF-8 Support Enabled
INFO - 2021-12-17 02:53:13 --> Utf8 Class Initialized
INFO - 2021-12-17 02:53:13 --> URI Class Initialized
INFO - 2021-12-17 02:53:13 --> Router Class Initialized
INFO - 2021-12-17 02:53:13 --> Output Class Initialized
INFO - 2021-12-17 02:53:13 --> Security Class Initialized
DEBUG - 2021-12-17 02:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-17 02:53:13 --> Input Class Initialized
INFO - 2021-12-17 02:53:13 --> Language Class Initialized
INFO - 2021-12-17 02:53:13 --> Loader Class Initialized
INFO - 2021-12-17 02:53:13 --> Helper loaded: url_helper
INFO - 2021-12-17 02:53:13 --> Helper loaded: form_helper
INFO - 2021-12-17 02:53:13 --> Helper loaded: common_helper
INFO - 2021-12-17 02:53:13 --> Database Driver Class Initialized
DEBUG - 2021-12-17 02:53:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-17 02:53:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-17 02:53:13 --> Controller Class Initialized
INFO - 2021-12-17 02:53:13 --> Form Validation Class Initialized
DEBUG - 2021-12-17 02:53:13 --> Encrypt Class Initialized
INFO - 2021-12-17 02:53:13 --> Model "Login_model" initialized
INFO - 2021-12-17 02:53:13 --> Model "Dashboard_model" initialized
INFO - 2021-12-17 02:53:13 --> Model "Case_model" initialized
INFO - 2021-12-17 02:53:22 --> File loaded: /home3/karoteam/public_html/application/views/header.php
ERROR - 2021-12-17 02:53:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-17 02:53:31 --> Config Class Initialized
INFO - 2021-12-17 02:53:31 --> Hooks Class Initialized
DEBUG - 2021-12-17 02:53:31 --> UTF-8 Support Enabled
INFO - 2021-12-17 02:53:31 --> Utf8 Class Initialized
INFO - 2021-12-17 02:53:31 --> URI Class Initialized
INFO - 2021-12-17 02:53:31 --> Router Class Initialized
INFO - 2021-12-17 02:53:31 --> Output Class Initialized
INFO - 2021-12-17 02:53:31 --> Security Class Initialized
DEBUG - 2021-12-17 02:53:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-17 02:53:31 --> Input Class Initialized
INFO - 2021-12-17 02:53:31 --> Language Class Initialized
INFO - 2021-12-17 02:53:31 --> Loader Class Initialized
INFO - 2021-12-17 02:53:31 --> Helper loaded: url_helper
INFO - 2021-12-17 02:53:31 --> Helper loaded: form_helper
INFO - 2021-12-17 02:53:31 --> Helper loaded: common_helper
INFO - 2021-12-17 02:53:31 --> Database Driver Class Initialized
DEBUG - 2021-12-17 02:53:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-17 02:53:32 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2021-12-17 02:53:32 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-17 02:53:32 --> Final output sent to browser
DEBUG - 2021-12-17 02:53:32 --> Total execution time: 18.9246
INFO - 2021-12-17 02:53:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-17 02:53:32 --> Controller Class Initialized
INFO - 2021-12-17 02:53:32 --> Form Validation Class Initialized
DEBUG - 2021-12-17 02:53:32 --> Encrypt Class Initialized
DEBUG - 2021-12-17 02:53:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-17 02:53:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-17 02:53:32 --> Email Class Initialized
INFO - 2021-12-17 02:53:32 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-17 02:53:32 --> Calendar Class Initialized
INFO - 2021-12-17 02:53:32 --> Model "Login_model" initialized
INFO - 2021-12-17 02:53:32 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2021-12-17 02:53:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-17 02:53:33 --> Config Class Initialized
INFO - 2021-12-17 02:53:33 --> Hooks Class Initialized
DEBUG - 2021-12-17 02:53:33 --> UTF-8 Support Enabled
INFO - 2021-12-17 02:53:33 --> Utf8 Class Initialized
INFO - 2021-12-17 02:53:33 --> URI Class Initialized
INFO - 2021-12-17 02:53:33 --> Router Class Initialized
INFO - 2021-12-17 02:53:33 --> Output Class Initialized
INFO - 2021-12-17 02:53:33 --> Security Class Initialized
DEBUG - 2021-12-17 02:53:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-17 02:53:33 --> Input Class Initialized
INFO - 2021-12-17 02:53:33 --> Language Class Initialized
INFO - 2021-12-17 02:53:33 --> Loader Class Initialized
INFO - 2021-12-17 02:53:33 --> Helper loaded: url_helper
INFO - 2021-12-17 02:53:33 --> Helper loaded: form_helper
INFO - 2021-12-17 02:53:33 --> Helper loaded: common_helper
INFO - 2021-12-17 02:53:33 --> Database Driver Class Initialized
DEBUG - 2021-12-17 02:53:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-17 02:53:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-17 02:53:33 --> Controller Class Initialized
INFO - 2021-12-17 02:53:33 --> Form Validation Class Initialized
DEBUG - 2021-12-17 02:53:33 --> Encrypt Class Initialized
INFO - 2021-12-17 02:53:33 --> Model "Login_model" initialized
INFO - 2021-12-17 02:53:33 --> Model "Dashboard_model" initialized
INFO - 2021-12-17 02:53:33 --> Model "Case_model" initialized
INFO - 2021-12-17 02:53:40 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-17 02:53:50 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2021-12-17 02:53:50 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-17 02:53:50 --> Final output sent to browser
DEBUG - 2021-12-17 02:53:50 --> Total execution time: 17.6320
ERROR - 2021-12-17 02:53:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-17 02:53:51 --> Config Class Initialized
INFO - 2021-12-17 02:53:51 --> Hooks Class Initialized
DEBUG - 2021-12-17 02:53:51 --> UTF-8 Support Enabled
INFO - 2021-12-17 02:53:51 --> Utf8 Class Initialized
INFO - 2021-12-17 02:53:51 --> URI Class Initialized
INFO - 2021-12-17 02:53:51 --> Router Class Initialized
INFO - 2021-12-17 02:53:51 --> Output Class Initialized
INFO - 2021-12-17 02:53:51 --> Security Class Initialized
DEBUG - 2021-12-17 02:53:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-17 02:53:51 --> Input Class Initialized
INFO - 2021-12-17 02:53:51 --> Language Class Initialized
ERROR - 2021-12-17 02:53:51 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-12-17 03:07:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-17 03:07:04 --> Config Class Initialized
INFO - 2021-12-17 03:07:04 --> Hooks Class Initialized
DEBUG - 2021-12-17 03:07:04 --> UTF-8 Support Enabled
INFO - 2021-12-17 03:07:04 --> Utf8 Class Initialized
INFO - 2021-12-17 03:07:04 --> URI Class Initialized
INFO - 2021-12-17 03:07:04 --> Router Class Initialized
INFO - 2021-12-17 03:07:04 --> Output Class Initialized
INFO - 2021-12-17 03:07:04 --> Security Class Initialized
DEBUG - 2021-12-17 03:07:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-17 03:07:04 --> Input Class Initialized
INFO - 2021-12-17 03:07:04 --> Language Class Initialized
INFO - 2021-12-17 03:07:04 --> Loader Class Initialized
INFO - 2021-12-17 03:07:04 --> Helper loaded: url_helper
INFO - 2021-12-17 03:07:04 --> Helper loaded: form_helper
INFO - 2021-12-17 03:07:04 --> Helper loaded: common_helper
INFO - 2021-12-17 03:07:04 --> Database Driver Class Initialized
DEBUG - 2021-12-17 03:07:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-17 03:07:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-17 03:07:04 --> Controller Class Initialized
INFO - 2021-12-17 03:07:04 --> Form Validation Class Initialized
INFO - 2021-12-17 03:07:04 --> Model "Case_model" initialized
INFO - 2021-12-17 03:07:04 --> Model "Hospital_model" initialized
INFO - 2021-12-17 03:07:04 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-17 03:07:04 --> File loaded: /home3/karoteam/public_html/application/views/transaction/upcomingFollowup.php
INFO - 2021-12-17 03:07:04 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-17 03:07:04 --> Final output sent to browser
DEBUG - 2021-12-17 03:07:04 --> Total execution time: 0.0263
ERROR - 2021-12-17 03:07:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-17 03:07:05 --> Config Class Initialized
INFO - 2021-12-17 03:07:05 --> Hooks Class Initialized
DEBUG - 2021-12-17 03:07:05 --> UTF-8 Support Enabled
INFO - 2021-12-17 03:07:05 --> Utf8 Class Initialized
INFO - 2021-12-17 03:07:05 --> URI Class Initialized
INFO - 2021-12-17 03:07:05 --> Router Class Initialized
INFO - 2021-12-17 03:07:05 --> Output Class Initialized
INFO - 2021-12-17 03:07:05 --> Security Class Initialized
DEBUG - 2021-12-17 03:07:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-17 03:07:05 --> Input Class Initialized
INFO - 2021-12-17 03:07:05 --> Language Class Initialized
ERROR - 2021-12-17 03:07:05 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-12-17 03:07:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-17 03:07:42 --> Config Class Initialized
INFO - 2021-12-17 03:07:42 --> Hooks Class Initialized
DEBUG - 2021-12-17 03:07:42 --> UTF-8 Support Enabled
INFO - 2021-12-17 03:07:42 --> Utf8 Class Initialized
INFO - 2021-12-17 03:07:42 --> URI Class Initialized
INFO - 2021-12-17 03:07:42 --> Router Class Initialized
INFO - 2021-12-17 03:07:42 --> Output Class Initialized
INFO - 2021-12-17 03:07:42 --> Security Class Initialized
DEBUG - 2021-12-17 03:07:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-17 03:07:42 --> Input Class Initialized
INFO - 2021-12-17 03:07:42 --> Language Class Initialized
INFO - 2021-12-17 03:07:42 --> Loader Class Initialized
INFO - 2021-12-17 03:07:42 --> Helper loaded: url_helper
INFO - 2021-12-17 03:07:42 --> Helper loaded: form_helper
INFO - 2021-12-17 03:07:42 --> Helper loaded: common_helper
INFO - 2021-12-17 03:07:42 --> Database Driver Class Initialized
DEBUG - 2021-12-17 03:07:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-17 03:07:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-17 03:07:42 --> Controller Class Initialized
INFO - 2021-12-17 03:07:42 --> Form Validation Class Initialized
DEBUG - 2021-12-17 03:07:42 --> Encrypt Class Initialized
INFO - 2021-12-17 03:07:42 --> Model "Hospital_model" initialized
INFO - 2021-12-17 03:07:42 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-17 03:07:42 --> File loaded: /home3/karoteam/public_html/application/views/hospital/index.php
INFO - 2021-12-17 03:07:42 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-17 03:07:42 --> Final output sent to browser
DEBUG - 2021-12-17 03:07:42 --> Total execution time: 0.0462
ERROR - 2021-12-17 03:07:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-17 03:07:43 --> Config Class Initialized
INFO - 2021-12-17 03:07:43 --> Hooks Class Initialized
DEBUG - 2021-12-17 03:07:43 --> UTF-8 Support Enabled
INFO - 2021-12-17 03:07:43 --> Utf8 Class Initialized
INFO - 2021-12-17 03:07:43 --> URI Class Initialized
INFO - 2021-12-17 03:07:43 --> Router Class Initialized
INFO - 2021-12-17 03:07:43 --> Output Class Initialized
INFO - 2021-12-17 03:07:43 --> Security Class Initialized
DEBUG - 2021-12-17 03:07:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-17 03:07:43 --> Input Class Initialized
INFO - 2021-12-17 03:07:43 --> Language Class Initialized
ERROR - 2021-12-17 03:07:43 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-12-17 03:08:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-17 03:08:58 --> Config Class Initialized
INFO - 2021-12-17 03:08:58 --> Hooks Class Initialized
DEBUG - 2021-12-17 03:08:58 --> UTF-8 Support Enabled
INFO - 2021-12-17 03:08:58 --> Utf8 Class Initialized
INFO - 2021-12-17 03:08:58 --> URI Class Initialized
INFO - 2021-12-17 03:08:58 --> Router Class Initialized
INFO - 2021-12-17 03:08:58 --> Output Class Initialized
INFO - 2021-12-17 03:08:58 --> Security Class Initialized
DEBUG - 2021-12-17 03:08:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-17 03:08:58 --> Input Class Initialized
INFO - 2021-12-17 03:08:58 --> Language Class Initialized
INFO - 2021-12-17 03:08:58 --> Loader Class Initialized
INFO - 2021-12-17 03:08:58 --> Helper loaded: url_helper
INFO - 2021-12-17 03:08:58 --> Helper loaded: form_helper
INFO - 2021-12-17 03:08:58 --> Helper loaded: common_helper
INFO - 2021-12-17 03:08:58 --> Database Driver Class Initialized
DEBUG - 2021-12-17 03:08:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-17 03:08:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-17 03:08:58 --> Controller Class Initialized
INFO - 2021-12-17 03:08:58 --> Form Validation Class Initialized
DEBUG - 2021-12-17 03:08:58 --> Encrypt Class Initialized
INFO - 2021-12-17 03:08:58 --> Model "Login_model" initialized
INFO - 2021-12-17 03:08:58 --> Model "Dashboard_model" initialized
INFO - 2021-12-17 03:08:58 --> Model "Case_model" initialized
ERROR - 2021-12-17 03:08:58 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'GROUP BY  CALCULATEAGE(YEAR(patient_dob))
     
     UNION 
     
  SELECT calcu' at line 7 - Invalid query: SELECT SUM(TotalPatient) as TotalPatient ,AgeGroup
FROM
( 
SELECT CALCULATEAGE(YEAR(patient_dob)) AS AgeGroup, COUNT(CALCULATEAGE(YEAR(patient_dob)))  AS TotalPatient FROM patient_master
       
    WHERE  IFNULL(`status`,0)!= '1' AND patient_dob IS NOT NULL AND patient_dob != '0000-00-00'  AND patient_master.created_by = 
     GROUP BY  CALCULATEAGE(YEAR(patient_dob))
     
     UNION 
     
  SELECT calculateWithoutDOBAge(SUBSTRING(patient_age,1,2)) AS AgeGroup, COUNT(calculateWithoutDOBAge(SUBSTRING(patient_age,1,2))) AS 
  TotalPatient FROM patient_master WHERE IFNULL(`status`,0)!= '1' AND IFNULL(patient_dob,'')='0000-00-00'  AND IFNULL(patient_age,'')!=''  AND patient_master.created_by = 
        GROUP BY calculateWithoutDOBAge(SUBSTRING(patient_age,1,2))
        )B GROUP BY AgeGroup
INFO - 2021-12-17 03:08:58 --> Language file loaded: language/english/db_lang.php
ERROR - 2021-12-17 03:14:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-17 03:14:25 --> Config Class Initialized
INFO - 2021-12-17 03:14:25 --> Hooks Class Initialized
DEBUG - 2021-12-17 03:14:25 --> UTF-8 Support Enabled
INFO - 2021-12-17 03:14:25 --> Utf8 Class Initialized
INFO - 2021-12-17 03:14:25 --> URI Class Initialized
INFO - 2021-12-17 03:14:25 --> Router Class Initialized
INFO - 2021-12-17 03:14:25 --> Output Class Initialized
INFO - 2021-12-17 03:14:25 --> Security Class Initialized
DEBUG - 2021-12-17 03:14:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-17 03:14:25 --> Input Class Initialized
INFO - 2021-12-17 03:14:25 --> Language Class Initialized
INFO - 2021-12-17 03:14:25 --> Loader Class Initialized
INFO - 2021-12-17 03:14:25 --> Helper loaded: url_helper
INFO - 2021-12-17 03:14:25 --> Helper loaded: form_helper
INFO - 2021-12-17 03:14:25 --> Helper loaded: common_helper
INFO - 2021-12-17 03:14:25 --> Database Driver Class Initialized
DEBUG - 2021-12-17 03:14:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-17 03:14:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-17 03:14:25 --> Controller Class Initialized
INFO - 2021-12-17 03:14:25 --> Form Validation Class Initialized
DEBUG - 2021-12-17 03:14:25 --> Encrypt Class Initialized
INFO - 2021-12-17 03:14:25 --> Model "Login_model" initialized
INFO - 2021-12-17 03:14:25 --> Model "Dashboard_model" initialized
INFO - 2021-12-17 03:14:25 --> Model "Case_model" initialized
ERROR - 2021-12-17 03:14:25 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'GROUP BY  CALCULATEAGE(YEAR(patient_dob))
     
     UNION 
     
  SELECT calcu' at line 7 - Invalid query: SELECT SUM(TotalPatient) as TotalPatient ,AgeGroup
FROM
( 
SELECT CALCULATEAGE(YEAR(patient_dob)) AS AgeGroup, COUNT(CALCULATEAGE(YEAR(patient_dob)))  AS TotalPatient FROM patient_master
       
    WHERE  IFNULL(`status`,0)!= '1' AND patient_dob IS NOT NULL AND patient_dob != '0000-00-00'  AND patient_master.created_by = 
     GROUP BY  CALCULATEAGE(YEAR(patient_dob))
     
     UNION 
     
  SELECT calculateWithoutDOBAge(SUBSTRING(patient_age,1,2)) AS AgeGroup, COUNT(calculateWithoutDOBAge(SUBSTRING(patient_age,1,2))) AS 
  TotalPatient FROM patient_master WHERE IFNULL(`status`,0)!= '1' AND IFNULL(patient_dob,'')='0000-00-00'  AND IFNULL(patient_age,'')!=''  AND patient_master.created_by = 
        GROUP BY calculateWithoutDOBAge(SUBSTRING(patient_age,1,2))
        )B GROUP BY AgeGroup
INFO - 2021-12-17 03:14:25 --> Language file loaded: language/english/db_lang.php
ERROR - 2021-12-17 03:14:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-17 03:14:30 --> Config Class Initialized
INFO - 2021-12-17 03:14:30 --> Hooks Class Initialized
DEBUG - 2021-12-17 03:14:30 --> UTF-8 Support Enabled
INFO - 2021-12-17 03:14:30 --> Utf8 Class Initialized
INFO - 2021-12-17 03:14:30 --> URI Class Initialized
DEBUG - 2021-12-17 03:14:30 --> No URI present. Default controller set.
INFO - 2021-12-17 03:14:30 --> Router Class Initialized
INFO - 2021-12-17 03:14:30 --> Output Class Initialized
INFO - 2021-12-17 03:14:30 --> Security Class Initialized
DEBUG - 2021-12-17 03:14:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-17 03:14:30 --> Input Class Initialized
INFO - 2021-12-17 03:14:30 --> Language Class Initialized
INFO - 2021-12-17 03:14:30 --> Loader Class Initialized
INFO - 2021-12-17 03:14:30 --> Helper loaded: url_helper
INFO - 2021-12-17 03:14:30 --> Helper loaded: form_helper
INFO - 2021-12-17 03:14:30 --> Helper loaded: common_helper
INFO - 2021-12-17 03:14:30 --> Database Driver Class Initialized
DEBUG - 2021-12-17 03:14:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-17 03:14:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-17 03:14:30 --> Controller Class Initialized
INFO - 2021-12-17 03:14:30 --> Form Validation Class Initialized
DEBUG - 2021-12-17 03:14:30 --> Encrypt Class Initialized
DEBUG - 2021-12-17 03:14:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-17 03:14:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-17 03:14:30 --> Email Class Initialized
INFO - 2021-12-17 03:14:30 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-17 03:14:30 --> Calendar Class Initialized
INFO - 2021-12-17 03:14:30 --> Model "Login_model" initialized
INFO - 2021-12-17 03:14:30 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-17 03:14:30 --> Final output sent to browser
DEBUG - 2021-12-17 03:14:30 --> Total execution time: 0.0220
ERROR - 2021-12-17 03:14:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-17 03:14:43 --> Config Class Initialized
INFO - 2021-12-17 03:14:43 --> Hooks Class Initialized
DEBUG - 2021-12-17 03:14:43 --> UTF-8 Support Enabled
INFO - 2021-12-17 03:14:43 --> Utf8 Class Initialized
INFO - 2021-12-17 03:14:43 --> URI Class Initialized
DEBUG - 2021-12-17 03:14:43 --> No URI present. Default controller set.
INFO - 2021-12-17 03:14:43 --> Router Class Initialized
INFO - 2021-12-17 03:14:43 --> Output Class Initialized
INFO - 2021-12-17 03:14:43 --> Security Class Initialized
DEBUG - 2021-12-17 03:14:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-17 03:14:43 --> Input Class Initialized
INFO - 2021-12-17 03:14:43 --> Language Class Initialized
INFO - 2021-12-17 03:14:43 --> Loader Class Initialized
INFO - 2021-12-17 03:14:43 --> Helper loaded: url_helper
INFO - 2021-12-17 03:14:43 --> Helper loaded: form_helper
INFO - 2021-12-17 03:14:43 --> Helper loaded: common_helper
INFO - 2021-12-17 03:14:43 --> Database Driver Class Initialized
DEBUG - 2021-12-17 03:14:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-17 03:14:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-17 03:14:43 --> Controller Class Initialized
INFO - 2021-12-17 03:14:43 --> Form Validation Class Initialized
DEBUG - 2021-12-17 03:14:43 --> Encrypt Class Initialized
DEBUG - 2021-12-17 03:14:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-17 03:14:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-17 03:14:43 --> Email Class Initialized
INFO - 2021-12-17 03:14:43 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-17 03:14:43 --> Calendar Class Initialized
INFO - 2021-12-17 03:14:43 --> Model "Login_model" initialized
INFO - 2021-12-17 03:14:43 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-17 03:14:43 --> Final output sent to browser
DEBUG - 2021-12-17 03:14:43 --> Total execution time: 0.0217
ERROR - 2021-12-17 03:14:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-17 03:14:45 --> Config Class Initialized
INFO - 2021-12-17 03:14:45 --> Hooks Class Initialized
DEBUG - 2021-12-17 03:14:45 --> UTF-8 Support Enabled
INFO - 2021-12-17 03:14:45 --> Utf8 Class Initialized
INFO - 2021-12-17 03:14:45 --> URI Class Initialized
INFO - 2021-12-17 03:14:45 --> Router Class Initialized
INFO - 2021-12-17 03:14:45 --> Output Class Initialized
INFO - 2021-12-17 03:14:45 --> Security Class Initialized
DEBUG - 2021-12-17 03:14:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-17 03:14:45 --> Input Class Initialized
INFO - 2021-12-17 03:14:45 --> Language Class Initialized
INFO - 2021-12-17 03:14:45 --> Loader Class Initialized
INFO - 2021-12-17 03:14:45 --> Helper loaded: url_helper
INFO - 2021-12-17 03:14:45 --> Helper loaded: form_helper
INFO - 2021-12-17 03:14:45 --> Helper loaded: common_helper
INFO - 2021-12-17 03:14:45 --> Database Driver Class Initialized
DEBUG - 2021-12-17 03:14:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-17 03:14:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-17 03:14:45 --> Controller Class Initialized
INFO - 2021-12-17 03:14:45 --> Form Validation Class Initialized
DEBUG - 2021-12-17 03:14:45 --> Encrypt Class Initialized
DEBUG - 2021-12-17 03:14:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-17 03:14:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-17 03:14:45 --> Email Class Initialized
INFO - 2021-12-17 03:14:45 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-17 03:14:45 --> Calendar Class Initialized
INFO - 2021-12-17 03:14:45 --> Model "Login_model" initialized
INFO - 2021-12-17 03:14:45 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2021-12-17 03:14:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-17 03:14:47 --> Config Class Initialized
INFO - 2021-12-17 03:14:47 --> Hooks Class Initialized
DEBUG - 2021-12-17 03:14:47 --> UTF-8 Support Enabled
INFO - 2021-12-17 03:14:47 --> Utf8 Class Initialized
INFO - 2021-12-17 03:14:47 --> URI Class Initialized
INFO - 2021-12-17 03:14:47 --> Router Class Initialized
INFO - 2021-12-17 03:14:47 --> Output Class Initialized
INFO - 2021-12-17 03:14:47 --> Security Class Initialized
DEBUG - 2021-12-17 03:14:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-17 03:14:47 --> Input Class Initialized
INFO - 2021-12-17 03:14:47 --> Language Class Initialized
INFO - 2021-12-17 03:14:47 --> Loader Class Initialized
INFO - 2021-12-17 03:14:47 --> Helper loaded: url_helper
INFO - 2021-12-17 03:14:47 --> Helper loaded: form_helper
INFO - 2021-12-17 03:14:47 --> Helper loaded: common_helper
INFO - 2021-12-17 03:14:47 --> Database Driver Class Initialized
DEBUG - 2021-12-17 03:14:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-17 03:14:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-17 03:14:47 --> Controller Class Initialized
INFO - 2021-12-17 03:14:47 --> Form Validation Class Initialized
DEBUG - 2021-12-17 03:14:47 --> Encrypt Class Initialized
INFO - 2021-12-17 03:14:47 --> Model "Login_model" initialized
INFO - 2021-12-17 03:14:47 --> Model "Dashboard_model" initialized
INFO - 2021-12-17 03:14:47 --> Model "Case_model" initialized
INFO - 2021-12-17 03:14:55 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-17 03:15:06 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2021-12-17 03:15:06 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-17 03:15:06 --> Final output sent to browser
DEBUG - 2021-12-17 03:15:06 --> Total execution time: 19.4729
ERROR - 2021-12-17 03:15:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-17 03:15:09 --> Config Class Initialized
INFO - 2021-12-17 03:15:09 --> Hooks Class Initialized
DEBUG - 2021-12-17 03:15:09 --> UTF-8 Support Enabled
INFO - 2021-12-17 03:15:09 --> Utf8 Class Initialized
INFO - 2021-12-17 03:15:09 --> URI Class Initialized
INFO - 2021-12-17 03:15:09 --> Router Class Initialized
INFO - 2021-12-17 03:15:09 --> Output Class Initialized
INFO - 2021-12-17 03:15:09 --> Security Class Initialized
DEBUG - 2021-12-17 03:15:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-17 03:15:09 --> Input Class Initialized
INFO - 2021-12-17 03:15:09 --> Language Class Initialized
ERROR - 2021-12-17 03:15:09 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-12-17 03:15:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-17 03:15:12 --> Config Class Initialized
INFO - 2021-12-17 03:15:12 --> Hooks Class Initialized
DEBUG - 2021-12-17 03:15:12 --> UTF-8 Support Enabled
INFO - 2021-12-17 03:15:12 --> Utf8 Class Initialized
INFO - 2021-12-17 03:15:12 --> URI Class Initialized
INFO - 2021-12-17 03:15:12 --> Router Class Initialized
INFO - 2021-12-17 03:15:12 --> Output Class Initialized
INFO - 2021-12-17 03:15:12 --> Security Class Initialized
DEBUG - 2021-12-17 03:15:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-17 03:15:12 --> Input Class Initialized
INFO - 2021-12-17 03:15:12 --> Language Class Initialized
INFO - 2021-12-17 03:15:12 --> Loader Class Initialized
INFO - 2021-12-17 03:15:12 --> Helper loaded: url_helper
INFO - 2021-12-17 03:15:12 --> Helper loaded: form_helper
INFO - 2021-12-17 03:15:12 --> Helper loaded: common_helper
INFO - 2021-12-17 03:15:12 --> Database Driver Class Initialized
DEBUG - 2021-12-17 03:15:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-17 03:15:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-17 03:15:12 --> Controller Class Initialized
INFO - 2021-12-17 03:15:12 --> Form Validation Class Initialized
DEBUG - 2021-12-17 03:15:12 --> Encrypt Class Initialized
DEBUG - 2021-12-17 03:15:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-17 03:15:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-17 03:15:12 --> Email Class Initialized
INFO - 2021-12-17 03:15:12 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-17 03:15:12 --> Calendar Class Initialized
INFO - 2021-12-17 03:15:12 --> Model "Login_model" initialized
INFO - 2021-12-17 03:15:12 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2021-12-17 03:15:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-17 03:15:13 --> Config Class Initialized
INFO - 2021-12-17 03:15:13 --> Hooks Class Initialized
DEBUG - 2021-12-17 03:15:13 --> UTF-8 Support Enabled
INFO - 2021-12-17 03:15:13 --> Utf8 Class Initialized
INFO - 2021-12-17 03:15:13 --> URI Class Initialized
INFO - 2021-12-17 03:15:13 --> Router Class Initialized
INFO - 2021-12-17 03:15:13 --> Output Class Initialized
INFO - 2021-12-17 03:15:13 --> Security Class Initialized
DEBUG - 2021-12-17 03:15:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-17 03:15:13 --> Input Class Initialized
INFO - 2021-12-17 03:15:13 --> Language Class Initialized
INFO - 2021-12-17 03:15:13 --> Loader Class Initialized
INFO - 2021-12-17 03:15:13 --> Helper loaded: url_helper
INFO - 2021-12-17 03:15:13 --> Helper loaded: form_helper
INFO - 2021-12-17 03:15:13 --> Helper loaded: common_helper
INFO - 2021-12-17 03:15:13 --> Database Driver Class Initialized
DEBUG - 2021-12-17 03:15:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-17 03:15:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-17 03:15:13 --> Controller Class Initialized
INFO - 2021-12-17 03:15:13 --> Form Validation Class Initialized
DEBUG - 2021-12-17 03:15:13 --> Encrypt Class Initialized
INFO - 2021-12-17 03:15:13 --> Model "Login_model" initialized
INFO - 2021-12-17 03:15:13 --> Model "Dashboard_model" initialized
INFO - 2021-12-17 03:15:13 --> Model "Case_model" initialized
INFO - 2021-12-17 03:15:21 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-17 03:15:30 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2021-12-17 03:15:30 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-17 03:15:30 --> Final output sent to browser
DEBUG - 2021-12-17 03:15:30 --> Total execution time: 17.5482
ERROR - 2021-12-17 03:15:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-17 03:15:31 --> Config Class Initialized
INFO - 2021-12-17 03:15:31 --> Hooks Class Initialized
DEBUG - 2021-12-17 03:15:31 --> UTF-8 Support Enabled
INFO - 2021-12-17 03:15:31 --> Utf8 Class Initialized
INFO - 2021-12-17 03:15:31 --> URI Class Initialized
INFO - 2021-12-17 03:15:31 --> Router Class Initialized
INFO - 2021-12-17 03:15:31 --> Output Class Initialized
INFO - 2021-12-17 03:15:31 --> Security Class Initialized
DEBUG - 2021-12-17 03:15:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-17 03:15:31 --> Input Class Initialized
INFO - 2021-12-17 03:15:31 --> Language Class Initialized
ERROR - 2021-12-17 03:15:31 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-12-17 03:24:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-17 03:24:03 --> Config Class Initialized
INFO - 2021-12-17 03:24:03 --> Hooks Class Initialized
DEBUG - 2021-12-17 03:24:03 --> UTF-8 Support Enabled
INFO - 2021-12-17 03:24:03 --> Utf8 Class Initialized
INFO - 2021-12-17 03:24:03 --> URI Class Initialized
DEBUG - 2021-12-17 03:24:03 --> No URI present. Default controller set.
INFO - 2021-12-17 03:24:03 --> Router Class Initialized
INFO - 2021-12-17 03:24:03 --> Output Class Initialized
INFO - 2021-12-17 03:24:03 --> Security Class Initialized
DEBUG - 2021-12-17 03:24:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-17 03:24:03 --> Input Class Initialized
INFO - 2021-12-17 03:24:03 --> Language Class Initialized
INFO - 2021-12-17 03:24:03 --> Loader Class Initialized
INFO - 2021-12-17 03:24:03 --> Helper loaded: url_helper
INFO - 2021-12-17 03:24:03 --> Helper loaded: form_helper
INFO - 2021-12-17 03:24:03 --> Helper loaded: common_helper
INFO - 2021-12-17 03:24:03 --> Database Driver Class Initialized
DEBUG - 2021-12-17 03:24:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-17 03:24:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-17 03:24:03 --> Controller Class Initialized
INFO - 2021-12-17 03:24:03 --> Form Validation Class Initialized
DEBUG - 2021-12-17 03:24:03 --> Encrypt Class Initialized
DEBUG - 2021-12-17 03:24:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-17 03:24:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-17 03:24:03 --> Email Class Initialized
INFO - 2021-12-17 03:24:03 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-17 03:24:03 --> Calendar Class Initialized
INFO - 2021-12-17 03:24:03 --> Model "Login_model" initialized
INFO - 2021-12-17 03:24:03 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-17 03:24:03 --> Final output sent to browser
DEBUG - 2021-12-17 03:24:03 --> Total execution time: 0.0604
ERROR - 2021-12-17 03:24:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-17 03:24:04 --> Config Class Initialized
INFO - 2021-12-17 03:24:04 --> Hooks Class Initialized
DEBUG - 2021-12-17 03:24:04 --> UTF-8 Support Enabled
INFO - 2021-12-17 03:24:04 --> Utf8 Class Initialized
INFO - 2021-12-17 03:24:04 --> URI Class Initialized
INFO - 2021-12-17 03:24:04 --> Router Class Initialized
INFO - 2021-12-17 03:24:04 --> Output Class Initialized
INFO - 2021-12-17 03:24:04 --> Security Class Initialized
DEBUG - 2021-12-17 03:24:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-17 03:24:04 --> Input Class Initialized
INFO - 2021-12-17 03:24:04 --> Language Class Initialized
ERROR - 2021-12-17 03:24:04 --> 404 Page Not Found: Blog/index
ERROR - 2021-12-17 03:24:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-17 03:24:05 --> Config Class Initialized
INFO - 2021-12-17 03:24:05 --> Hooks Class Initialized
DEBUG - 2021-12-17 03:24:05 --> UTF-8 Support Enabled
INFO - 2021-12-17 03:24:05 --> Utf8 Class Initialized
INFO - 2021-12-17 03:24:05 --> URI Class Initialized
INFO - 2021-12-17 03:24:05 --> Router Class Initialized
INFO - 2021-12-17 03:24:05 --> Output Class Initialized
INFO - 2021-12-17 03:24:05 --> Security Class Initialized
DEBUG - 2021-12-17 03:24:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-17 03:24:05 --> Input Class Initialized
INFO - 2021-12-17 03:24:05 --> Language Class Initialized
ERROR - 2021-12-17 03:24:05 --> 404 Page Not Found: Wp/index
ERROR - 2021-12-17 03:24:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-17 03:24:05 --> Config Class Initialized
INFO - 2021-12-17 03:24:05 --> Hooks Class Initialized
DEBUG - 2021-12-17 03:24:05 --> UTF-8 Support Enabled
INFO - 2021-12-17 03:24:05 --> Utf8 Class Initialized
INFO - 2021-12-17 03:24:05 --> URI Class Initialized
INFO - 2021-12-17 03:24:05 --> Router Class Initialized
INFO - 2021-12-17 03:24:05 --> Output Class Initialized
INFO - 2021-12-17 03:24:05 --> Security Class Initialized
DEBUG - 2021-12-17 03:24:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-17 03:24:05 --> Input Class Initialized
INFO - 2021-12-17 03:24:05 --> Language Class Initialized
ERROR - 2021-12-17 03:24:05 --> 404 Page Not Found: Wordpress/index
ERROR - 2021-12-17 03:24:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-17 03:24:06 --> Config Class Initialized
INFO - 2021-12-17 03:24:06 --> Hooks Class Initialized
DEBUG - 2021-12-17 03:24:06 --> UTF-8 Support Enabled
INFO - 2021-12-17 03:24:06 --> Utf8 Class Initialized
INFO - 2021-12-17 03:24:06 --> URI Class Initialized
INFO - 2021-12-17 03:24:06 --> Router Class Initialized
INFO - 2021-12-17 03:24:06 --> Output Class Initialized
INFO - 2021-12-17 03:24:06 --> Security Class Initialized
DEBUG - 2021-12-17 03:24:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-17 03:24:06 --> Input Class Initialized
INFO - 2021-12-17 03:24:06 --> Language Class Initialized
ERROR - 2021-12-17 03:24:06 --> 404 Page Not Found: New/index
ERROR - 2021-12-17 03:24:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-17 03:24:06 --> Config Class Initialized
INFO - 2021-12-17 03:24:06 --> Hooks Class Initialized
DEBUG - 2021-12-17 03:24:06 --> UTF-8 Support Enabled
INFO - 2021-12-17 03:24:06 --> Utf8 Class Initialized
INFO - 2021-12-17 03:24:06 --> URI Class Initialized
INFO - 2021-12-17 03:24:06 --> Router Class Initialized
INFO - 2021-12-17 03:24:06 --> Output Class Initialized
INFO - 2021-12-17 03:24:06 --> Security Class Initialized
DEBUG - 2021-12-17 03:24:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-17 03:24:06 --> Input Class Initialized
INFO - 2021-12-17 03:24:06 --> Language Class Initialized
ERROR - 2021-12-17 03:24:06 --> 404 Page Not Found: Old/index
ERROR - 2021-12-17 03:24:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-17 03:24:07 --> Config Class Initialized
INFO - 2021-12-17 03:24:07 --> Hooks Class Initialized
DEBUG - 2021-12-17 03:24:07 --> UTF-8 Support Enabled
INFO - 2021-12-17 03:24:07 --> Utf8 Class Initialized
INFO - 2021-12-17 03:24:07 --> URI Class Initialized
INFO - 2021-12-17 03:24:07 --> Router Class Initialized
INFO - 2021-12-17 03:24:07 --> Output Class Initialized
INFO - 2021-12-17 03:24:07 --> Security Class Initialized
DEBUG - 2021-12-17 03:24:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-17 03:24:07 --> Input Class Initialized
INFO - 2021-12-17 03:24:07 --> Language Class Initialized
ERROR - 2021-12-17 03:24:07 --> 404 Page Not Found: Test/index
ERROR - 2021-12-17 03:24:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-17 03:24:08 --> Config Class Initialized
INFO - 2021-12-17 03:24:08 --> Hooks Class Initialized
DEBUG - 2021-12-17 03:24:08 --> UTF-8 Support Enabled
INFO - 2021-12-17 03:24:08 --> Utf8 Class Initialized
INFO - 2021-12-17 03:24:08 --> URI Class Initialized
INFO - 2021-12-17 03:24:08 --> Router Class Initialized
INFO - 2021-12-17 03:24:08 --> Output Class Initialized
INFO - 2021-12-17 03:24:08 --> Security Class Initialized
DEBUG - 2021-12-17 03:24:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-17 03:24:08 --> Input Class Initialized
INFO - 2021-12-17 03:24:08 --> Language Class Initialized
ERROR - 2021-12-17 03:24:08 --> 404 Page Not Found: Main/index
ERROR - 2021-12-17 03:24:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-17 03:24:08 --> Config Class Initialized
INFO - 2021-12-17 03:24:08 --> Hooks Class Initialized
DEBUG - 2021-12-17 03:24:08 --> UTF-8 Support Enabled
INFO - 2021-12-17 03:24:08 --> Utf8 Class Initialized
INFO - 2021-12-17 03:24:08 --> URI Class Initialized
INFO - 2021-12-17 03:24:08 --> Router Class Initialized
INFO - 2021-12-17 03:24:08 --> Output Class Initialized
INFO - 2021-12-17 03:24:08 --> Security Class Initialized
DEBUG - 2021-12-17 03:24:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-17 03:24:08 --> Input Class Initialized
INFO - 2021-12-17 03:24:08 --> Language Class Initialized
ERROR - 2021-12-17 03:24:08 --> 404 Page Not Found: Site/index
ERROR - 2021-12-17 03:24:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-17 03:24:09 --> Config Class Initialized
INFO - 2021-12-17 03:24:09 --> Hooks Class Initialized
DEBUG - 2021-12-17 03:24:09 --> UTF-8 Support Enabled
INFO - 2021-12-17 03:24:09 --> Utf8 Class Initialized
INFO - 2021-12-17 03:24:09 --> URI Class Initialized
INFO - 2021-12-17 03:24:09 --> Router Class Initialized
INFO - 2021-12-17 03:24:09 --> Output Class Initialized
INFO - 2021-12-17 03:24:09 --> Security Class Initialized
DEBUG - 2021-12-17 03:24:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-17 03:24:09 --> Input Class Initialized
INFO - 2021-12-17 03:24:09 --> Language Class Initialized
ERROR - 2021-12-17 03:24:09 --> 404 Page Not Found: Backup/index
ERROR - 2021-12-17 03:24:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-17 03:24:10 --> Config Class Initialized
INFO - 2021-12-17 03:24:10 --> Hooks Class Initialized
DEBUG - 2021-12-17 03:24:10 --> UTF-8 Support Enabled
INFO - 2021-12-17 03:24:10 --> Utf8 Class Initialized
INFO - 2021-12-17 03:24:10 --> URI Class Initialized
INFO - 2021-12-17 03:24:10 --> Router Class Initialized
INFO - 2021-12-17 03:24:10 --> Output Class Initialized
INFO - 2021-12-17 03:24:10 --> Security Class Initialized
DEBUG - 2021-12-17 03:24:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-17 03:24:10 --> Input Class Initialized
INFO - 2021-12-17 03:24:10 --> Language Class Initialized
ERROR - 2021-12-17 03:24:10 --> 404 Page Not Found: Demo/index
ERROR - 2021-12-17 03:24:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-17 03:24:10 --> Config Class Initialized
INFO - 2021-12-17 03:24:10 --> Hooks Class Initialized
DEBUG - 2021-12-17 03:24:10 --> UTF-8 Support Enabled
INFO - 2021-12-17 03:24:10 --> Utf8 Class Initialized
INFO - 2021-12-17 03:24:10 --> URI Class Initialized
INFO - 2021-12-17 03:24:10 --> Router Class Initialized
INFO - 2021-12-17 03:24:10 --> Output Class Initialized
INFO - 2021-12-17 03:24:10 --> Security Class Initialized
DEBUG - 2021-12-17 03:24:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-17 03:24:10 --> Input Class Initialized
INFO - 2021-12-17 03:24:10 --> Language Class Initialized
ERROR - 2021-12-17 03:24:10 --> 404 Page Not Found: Home/index
ERROR - 2021-12-17 03:24:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-17 03:24:11 --> Config Class Initialized
INFO - 2021-12-17 03:24:11 --> Hooks Class Initialized
DEBUG - 2021-12-17 03:24:11 --> UTF-8 Support Enabled
INFO - 2021-12-17 03:24:11 --> Utf8 Class Initialized
INFO - 2021-12-17 03:24:11 --> URI Class Initialized
INFO - 2021-12-17 03:24:11 --> Router Class Initialized
INFO - 2021-12-17 03:24:11 --> Output Class Initialized
INFO - 2021-12-17 03:24:11 --> Security Class Initialized
DEBUG - 2021-12-17 03:24:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-17 03:24:11 --> Input Class Initialized
INFO - 2021-12-17 03:24:11 --> Language Class Initialized
ERROR - 2021-12-17 03:24:11 --> 404 Page Not Found: Tmp/index
ERROR - 2021-12-17 03:24:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-17 03:24:12 --> Config Class Initialized
INFO - 2021-12-17 03:24:12 --> Hooks Class Initialized
DEBUG - 2021-12-17 03:24:12 --> UTF-8 Support Enabled
INFO - 2021-12-17 03:24:12 --> Utf8 Class Initialized
INFO - 2021-12-17 03:24:12 --> URI Class Initialized
INFO - 2021-12-17 03:24:12 --> Router Class Initialized
INFO - 2021-12-17 03:24:12 --> Output Class Initialized
INFO - 2021-12-17 03:24:12 --> Security Class Initialized
DEBUG - 2021-12-17 03:24:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-17 03:24:12 --> Input Class Initialized
INFO - 2021-12-17 03:24:12 --> Language Class Initialized
ERROR - 2021-12-17 03:24:12 --> 404 Page Not Found: Cms/index
ERROR - 2021-12-17 03:24:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-17 03:24:12 --> Config Class Initialized
INFO - 2021-12-17 03:24:12 --> Hooks Class Initialized
DEBUG - 2021-12-17 03:24:12 --> UTF-8 Support Enabled
INFO - 2021-12-17 03:24:12 --> Utf8 Class Initialized
INFO - 2021-12-17 03:24:12 --> URI Class Initialized
INFO - 2021-12-17 03:24:12 --> Router Class Initialized
INFO - 2021-12-17 03:24:12 --> Output Class Initialized
INFO - 2021-12-17 03:24:12 --> Security Class Initialized
DEBUG - 2021-12-17 03:24:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-17 03:24:12 --> Input Class Initialized
INFO - 2021-12-17 03:24:12 --> Language Class Initialized
ERROR - 2021-12-17 03:24:12 --> 404 Page Not Found: Dev/index
ERROR - 2021-12-17 03:24:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-17 03:24:13 --> Config Class Initialized
INFO - 2021-12-17 03:24:13 --> Hooks Class Initialized
DEBUG - 2021-12-17 03:24:13 --> UTF-8 Support Enabled
INFO - 2021-12-17 03:24:13 --> Utf8 Class Initialized
INFO - 2021-12-17 03:24:13 --> URI Class Initialized
INFO - 2021-12-17 03:24:13 --> Router Class Initialized
INFO - 2021-12-17 03:24:13 --> Output Class Initialized
INFO - 2021-12-17 03:24:13 --> Security Class Initialized
DEBUG - 2021-12-17 03:24:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-17 03:24:13 --> Input Class Initialized
INFO - 2021-12-17 03:24:13 --> Language Class Initialized
ERROR - 2021-12-17 03:24:13 --> 404 Page Not Found: Old-wp/index
ERROR - 2021-12-17 03:24:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-17 03:24:14 --> Config Class Initialized
INFO - 2021-12-17 03:24:14 --> Hooks Class Initialized
DEBUG - 2021-12-17 03:24:14 --> UTF-8 Support Enabled
INFO - 2021-12-17 03:24:14 --> Utf8 Class Initialized
INFO - 2021-12-17 03:24:14 --> URI Class Initialized
INFO - 2021-12-17 03:24:14 --> Router Class Initialized
INFO - 2021-12-17 03:24:14 --> Output Class Initialized
INFO - 2021-12-17 03:24:14 --> Security Class Initialized
DEBUG - 2021-12-17 03:24:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-17 03:24:14 --> Input Class Initialized
INFO - 2021-12-17 03:24:14 --> Language Class Initialized
ERROR - 2021-12-17 03:24:14 --> 404 Page Not Found: Web/index
ERROR - 2021-12-17 03:24:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-17 03:24:14 --> Config Class Initialized
INFO - 2021-12-17 03:24:14 --> Hooks Class Initialized
DEBUG - 2021-12-17 03:24:14 --> UTF-8 Support Enabled
INFO - 2021-12-17 03:24:14 --> Utf8 Class Initialized
INFO - 2021-12-17 03:24:14 --> URI Class Initialized
INFO - 2021-12-17 03:24:14 --> Router Class Initialized
INFO - 2021-12-17 03:24:14 --> Output Class Initialized
INFO - 2021-12-17 03:24:14 --> Security Class Initialized
DEBUG - 2021-12-17 03:24:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-17 03:24:14 --> Input Class Initialized
INFO - 2021-12-17 03:24:14 --> Language Class Initialized
ERROR - 2021-12-17 03:24:14 --> 404 Page Not Found: Old-site/index
ERROR - 2021-12-17 03:24:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-17 03:24:15 --> Config Class Initialized
INFO - 2021-12-17 03:24:15 --> Hooks Class Initialized
DEBUG - 2021-12-17 03:24:15 --> UTF-8 Support Enabled
INFO - 2021-12-17 03:24:15 --> Utf8 Class Initialized
INFO - 2021-12-17 03:24:15 --> URI Class Initialized
INFO - 2021-12-17 03:24:15 --> Router Class Initialized
INFO - 2021-12-17 03:24:15 --> Output Class Initialized
INFO - 2021-12-17 03:24:15 --> Security Class Initialized
DEBUG - 2021-12-17 03:24:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-17 03:24:15 --> Input Class Initialized
INFO - 2021-12-17 03:24:15 --> Language Class Initialized
ERROR - 2021-12-17 03:24:15 --> 404 Page Not Found: Temp/index
ERROR - 2021-12-17 03:24:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-17 03:24:16 --> Config Class Initialized
INFO - 2021-12-17 03:24:16 --> Hooks Class Initialized
DEBUG - 2021-12-17 03:24:16 --> UTF-8 Support Enabled
INFO - 2021-12-17 03:24:16 --> Utf8 Class Initialized
INFO - 2021-12-17 03:24:16 --> URI Class Initialized
INFO - 2021-12-17 03:24:16 --> Router Class Initialized
INFO - 2021-12-17 03:24:16 --> Output Class Initialized
INFO - 2021-12-17 03:24:16 --> Security Class Initialized
DEBUG - 2021-12-17 03:24:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-17 03:24:16 --> Input Class Initialized
INFO - 2021-12-17 03:24:16 --> Language Class Initialized
ERROR - 2021-12-17 03:24:16 --> 404 Page Not Found: 2018/index
ERROR - 2021-12-17 03:24:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-17 03:24:17 --> Config Class Initialized
INFO - 2021-12-17 03:24:17 --> Hooks Class Initialized
DEBUG - 2021-12-17 03:24:17 --> UTF-8 Support Enabled
INFO - 2021-12-17 03:24:17 --> Utf8 Class Initialized
INFO - 2021-12-17 03:24:17 --> URI Class Initialized
INFO - 2021-12-17 03:24:17 --> Router Class Initialized
INFO - 2021-12-17 03:24:17 --> Output Class Initialized
INFO - 2021-12-17 03:24:17 --> Security Class Initialized
DEBUG - 2021-12-17 03:24:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-17 03:24:17 --> Input Class Initialized
INFO - 2021-12-17 03:24:17 --> Language Class Initialized
ERROR - 2021-12-17 03:24:17 --> 404 Page Not Found: 2019/index
ERROR - 2021-12-17 03:24:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-17 03:24:17 --> Config Class Initialized
INFO - 2021-12-17 03:24:17 --> Hooks Class Initialized
DEBUG - 2021-12-17 03:24:17 --> UTF-8 Support Enabled
INFO - 2021-12-17 03:24:17 --> Utf8 Class Initialized
INFO - 2021-12-17 03:24:17 --> URI Class Initialized
INFO - 2021-12-17 03:24:17 --> Router Class Initialized
INFO - 2021-12-17 03:24:17 --> Output Class Initialized
INFO - 2021-12-17 03:24:17 --> Security Class Initialized
DEBUG - 2021-12-17 03:24:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-17 03:24:17 --> Input Class Initialized
INFO - 2021-12-17 03:24:17 --> Language Class Initialized
ERROR - 2021-12-17 03:24:17 --> 404 Page Not Found: Bk/index
ERROR - 2021-12-17 03:24:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-17 03:24:18 --> Config Class Initialized
INFO - 2021-12-17 03:24:18 --> Hooks Class Initialized
DEBUG - 2021-12-17 03:24:18 --> UTF-8 Support Enabled
INFO - 2021-12-17 03:24:18 --> Utf8 Class Initialized
INFO - 2021-12-17 03:24:18 --> URI Class Initialized
INFO - 2021-12-17 03:24:18 --> Router Class Initialized
INFO - 2021-12-17 03:24:18 --> Output Class Initialized
INFO - 2021-12-17 03:24:18 --> Security Class Initialized
DEBUG - 2021-12-17 03:24:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-17 03:24:18 --> Input Class Initialized
INFO - 2021-12-17 03:24:18 --> Language Class Initialized
ERROR - 2021-12-17 03:24:18 --> 404 Page Not Found: Wp1/index
ERROR - 2021-12-17 03:24:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-17 03:24:19 --> Config Class Initialized
INFO - 2021-12-17 03:24:19 --> Hooks Class Initialized
DEBUG - 2021-12-17 03:24:19 --> UTF-8 Support Enabled
INFO - 2021-12-17 03:24:19 --> Utf8 Class Initialized
INFO - 2021-12-17 03:24:19 --> URI Class Initialized
INFO - 2021-12-17 03:24:19 --> Router Class Initialized
INFO - 2021-12-17 03:24:19 --> Output Class Initialized
INFO - 2021-12-17 03:24:19 --> Security Class Initialized
DEBUG - 2021-12-17 03:24:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-17 03:24:19 --> Input Class Initialized
INFO - 2021-12-17 03:24:19 --> Language Class Initialized
ERROR - 2021-12-17 03:24:19 --> 404 Page Not Found: Wp2/index
ERROR - 2021-12-17 03:24:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-17 03:24:20 --> Config Class Initialized
INFO - 2021-12-17 03:24:20 --> Hooks Class Initialized
DEBUG - 2021-12-17 03:24:20 --> UTF-8 Support Enabled
INFO - 2021-12-17 03:24:20 --> Utf8 Class Initialized
INFO - 2021-12-17 03:24:20 --> URI Class Initialized
INFO - 2021-12-17 03:24:20 --> Router Class Initialized
INFO - 2021-12-17 03:24:20 --> Output Class Initialized
INFO - 2021-12-17 03:24:20 --> Security Class Initialized
DEBUG - 2021-12-17 03:24:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-17 03:24:20 --> Input Class Initialized
INFO - 2021-12-17 03:24:20 --> Language Class Initialized
ERROR - 2021-12-17 03:24:20 --> 404 Page Not Found: V1/index
ERROR - 2021-12-17 03:24:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-17 03:24:20 --> Config Class Initialized
INFO - 2021-12-17 03:24:20 --> Hooks Class Initialized
DEBUG - 2021-12-17 03:24:20 --> UTF-8 Support Enabled
INFO - 2021-12-17 03:24:20 --> Utf8 Class Initialized
INFO - 2021-12-17 03:24:20 --> URI Class Initialized
INFO - 2021-12-17 03:24:20 --> Router Class Initialized
INFO - 2021-12-17 03:24:20 --> Output Class Initialized
INFO - 2021-12-17 03:24:20 --> Security Class Initialized
DEBUG - 2021-12-17 03:24:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-17 03:24:20 --> Input Class Initialized
INFO - 2021-12-17 03:24:20 --> Language Class Initialized
ERROR - 2021-12-17 03:24:20 --> 404 Page Not Found: V2/index
ERROR - 2021-12-17 03:24:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-17 03:24:21 --> Config Class Initialized
INFO - 2021-12-17 03:24:21 --> Hooks Class Initialized
DEBUG - 2021-12-17 03:24:21 --> UTF-8 Support Enabled
INFO - 2021-12-17 03:24:21 --> Utf8 Class Initialized
INFO - 2021-12-17 03:24:21 --> URI Class Initialized
INFO - 2021-12-17 03:24:21 --> Router Class Initialized
INFO - 2021-12-17 03:24:21 --> Output Class Initialized
INFO - 2021-12-17 03:24:21 --> Security Class Initialized
DEBUG - 2021-12-17 03:24:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-17 03:24:21 --> Input Class Initialized
INFO - 2021-12-17 03:24:21 --> Language Class Initialized
ERROR - 2021-12-17 03:24:21 --> 404 Page Not Found: Bak/index
ERROR - 2021-12-17 03:24:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-17 03:24:22 --> Config Class Initialized
INFO - 2021-12-17 03:24:22 --> Hooks Class Initialized
DEBUG - 2021-12-17 03:24:22 --> UTF-8 Support Enabled
INFO - 2021-12-17 03:24:22 --> Utf8 Class Initialized
INFO - 2021-12-17 03:24:22 --> URI Class Initialized
INFO - 2021-12-17 03:24:22 --> Router Class Initialized
INFO - 2021-12-17 03:24:22 --> Output Class Initialized
INFO - 2021-12-17 03:24:22 --> Security Class Initialized
DEBUG - 2021-12-17 03:24:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-17 03:24:22 --> Input Class Initialized
INFO - 2021-12-17 03:24:22 --> Language Class Initialized
ERROR - 2021-12-17 03:24:22 --> 404 Page Not Found: Install/index
ERROR - 2021-12-17 03:24:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-17 03:24:22 --> Config Class Initialized
INFO - 2021-12-17 03:24:22 --> Hooks Class Initialized
DEBUG - 2021-12-17 03:24:22 --> UTF-8 Support Enabled
INFO - 2021-12-17 03:24:22 --> Utf8 Class Initialized
INFO - 2021-12-17 03:24:22 --> URI Class Initialized
INFO - 2021-12-17 03:24:22 --> Router Class Initialized
INFO - 2021-12-17 03:24:22 --> Output Class Initialized
INFO - 2021-12-17 03:24:22 --> Security Class Initialized
DEBUG - 2021-12-17 03:24:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-17 03:24:22 --> Input Class Initialized
INFO - 2021-12-17 03:24:22 --> Language Class Initialized
ERROR - 2021-12-17 03:24:22 --> 404 Page Not Found: 2020/index
ERROR - 2021-12-17 03:24:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-17 03:24:23 --> Config Class Initialized
INFO - 2021-12-17 03:24:23 --> Hooks Class Initialized
DEBUG - 2021-12-17 03:24:23 --> UTF-8 Support Enabled
INFO - 2021-12-17 03:24:23 --> Utf8 Class Initialized
INFO - 2021-12-17 03:24:23 --> URI Class Initialized
INFO - 2021-12-17 03:24:23 --> Router Class Initialized
INFO - 2021-12-17 03:24:23 --> Output Class Initialized
INFO - 2021-12-17 03:24:23 --> Security Class Initialized
DEBUG - 2021-12-17 03:24:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-17 03:24:23 --> Input Class Initialized
INFO - 2021-12-17 03:24:23 --> Language Class Initialized
ERROR - 2021-12-17 03:24:23 --> 404 Page Not Found: New-site/index
ERROR - 2021-12-17 03:25:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-17 03:25:25 --> Config Class Initialized
INFO - 2021-12-17 03:25:25 --> Hooks Class Initialized
DEBUG - 2021-12-17 03:25:25 --> UTF-8 Support Enabled
INFO - 2021-12-17 03:25:25 --> Utf8 Class Initialized
INFO - 2021-12-17 03:25:25 --> URI Class Initialized
INFO - 2021-12-17 03:25:25 --> Router Class Initialized
INFO - 2021-12-17 03:25:25 --> Output Class Initialized
INFO - 2021-12-17 03:25:25 --> Security Class Initialized
DEBUG - 2021-12-17 03:25:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-17 03:25:25 --> Input Class Initialized
INFO - 2021-12-17 03:25:25 --> Language Class Initialized
INFO - 2021-12-17 03:25:25 --> Loader Class Initialized
INFO - 2021-12-17 03:25:25 --> Helper loaded: url_helper
INFO - 2021-12-17 03:25:25 --> Helper loaded: form_helper
INFO - 2021-12-17 03:25:25 --> Helper loaded: common_helper
INFO - 2021-12-17 03:25:25 --> Database Driver Class Initialized
DEBUG - 2021-12-17 03:25:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-17 03:25:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-17 03:25:25 --> Controller Class Initialized
INFO - 2021-12-17 03:25:25 --> Form Validation Class Initialized
DEBUG - 2021-12-17 03:25:25 --> Encrypt Class Initialized
INFO - 2021-12-17 03:25:25 --> Model "Patient_model" initialized
INFO - 2021-12-17 03:25:25 --> Model "Patientcase_model" initialized
INFO - 2021-12-17 03:25:25 --> Model "Referredby_model" initialized
INFO - 2021-12-17 03:25:25 --> Model "Prefix_master" initialized
INFO - 2021-12-17 03:25:25 --> Model "Hospital_model" initialized
INFO - 2021-12-17 03:25:25 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-17 03:25:25 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2021-12-17 03:25:25 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-17 03:25:25 --> Final output sent to browser
DEBUG - 2021-12-17 03:25:25 --> Total execution time: 0.0653
ERROR - 2021-12-17 03:25:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-17 03:25:26 --> Config Class Initialized
INFO - 2021-12-17 03:25:26 --> Hooks Class Initialized
DEBUG - 2021-12-17 03:25:26 --> UTF-8 Support Enabled
INFO - 2021-12-17 03:25:26 --> Utf8 Class Initialized
INFO - 2021-12-17 03:25:26 --> URI Class Initialized
INFO - 2021-12-17 03:25:26 --> Router Class Initialized
INFO - 2021-12-17 03:25:26 --> Output Class Initialized
INFO - 2021-12-17 03:25:26 --> Security Class Initialized
DEBUG - 2021-12-17 03:25:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-17 03:25:26 --> Input Class Initialized
INFO - 2021-12-17 03:25:26 --> Language Class Initialized
ERROR - 2021-12-17 03:25:26 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-12-17 03:25:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-17 03:25:29 --> Config Class Initialized
INFO - 2021-12-17 03:25:29 --> Hooks Class Initialized
DEBUG - 2021-12-17 03:25:29 --> UTF-8 Support Enabled
INFO - 2021-12-17 03:25:29 --> Utf8 Class Initialized
INFO - 2021-12-17 03:25:29 --> URI Class Initialized
INFO - 2021-12-17 03:25:29 --> Router Class Initialized
INFO - 2021-12-17 03:25:29 --> Output Class Initialized
INFO - 2021-12-17 03:25:29 --> Security Class Initialized
DEBUG - 2021-12-17 03:25:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-17 03:25:29 --> Input Class Initialized
INFO - 2021-12-17 03:25:29 --> Language Class Initialized
INFO - 2021-12-17 03:25:29 --> Loader Class Initialized
INFO - 2021-12-17 03:25:29 --> Helper loaded: url_helper
INFO - 2021-12-17 03:25:29 --> Helper loaded: form_helper
INFO - 2021-12-17 03:25:29 --> Helper loaded: common_helper
INFO - 2021-12-17 03:25:29 --> Database Driver Class Initialized
DEBUG - 2021-12-17 03:25:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-17 03:25:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-17 03:25:29 --> Controller Class Initialized
INFO - 2021-12-17 03:25:29 --> Form Validation Class Initialized
INFO - 2021-12-17 03:25:29 --> Model "Case_model" initialized
INFO - 2021-12-17 03:25:29 --> Model "Hospital_model" initialized
INFO - 2021-12-17 03:25:29 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-17 03:25:29 --> File loaded: /home3/karoteam/public_html/application/views/transaction/upcomingFollowup.php
INFO - 2021-12-17 03:25:29 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-17 03:25:29 --> Final output sent to browser
DEBUG - 2021-12-17 03:25:29 --> Total execution time: 0.0379
ERROR - 2021-12-17 03:25:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-17 03:25:29 --> Config Class Initialized
INFO - 2021-12-17 03:25:29 --> Hooks Class Initialized
DEBUG - 2021-12-17 03:25:29 --> UTF-8 Support Enabled
INFO - 2021-12-17 03:25:29 --> Utf8 Class Initialized
INFO - 2021-12-17 03:25:29 --> URI Class Initialized
INFO - 2021-12-17 03:25:29 --> Router Class Initialized
INFO - 2021-12-17 03:25:29 --> Output Class Initialized
INFO - 2021-12-17 03:25:29 --> Security Class Initialized
DEBUG - 2021-12-17 03:25:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-17 03:25:29 --> Input Class Initialized
INFO - 2021-12-17 03:25:29 --> Language Class Initialized
ERROR - 2021-12-17 03:25:29 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-12-17 03:25:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-17 03:25:30 --> Config Class Initialized
INFO - 2021-12-17 03:25:30 --> Hooks Class Initialized
DEBUG - 2021-12-17 03:25:30 --> UTF-8 Support Enabled
INFO - 2021-12-17 03:25:30 --> Utf8 Class Initialized
INFO - 2021-12-17 03:25:30 --> URI Class Initialized
INFO - 2021-12-17 03:25:30 --> Router Class Initialized
INFO - 2021-12-17 03:25:30 --> Output Class Initialized
INFO - 2021-12-17 03:25:30 --> Security Class Initialized
DEBUG - 2021-12-17 03:25:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-17 03:25:30 --> Input Class Initialized
INFO - 2021-12-17 03:25:30 --> Language Class Initialized
INFO - 2021-12-17 03:25:30 --> Loader Class Initialized
INFO - 2021-12-17 03:25:30 --> Helper loaded: url_helper
INFO - 2021-12-17 03:25:30 --> Helper loaded: form_helper
INFO - 2021-12-17 03:25:30 --> Helper loaded: common_helper
INFO - 2021-12-17 03:25:30 --> Database Driver Class Initialized
DEBUG - 2021-12-17 03:25:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-17 03:25:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-17 03:25:30 --> Controller Class Initialized
INFO - 2021-12-17 03:25:30 --> Form Validation Class Initialized
DEBUG - 2021-12-17 03:25:30 --> Encrypt Class Initialized
INFO - 2021-12-17 03:25:30 --> Model "Login_model" initialized
INFO - 2021-12-17 03:25:30 --> Model "Dashboard_model" initialized
INFO - 2021-12-17 03:25:30 --> Model "Case_model" initialized
ERROR - 2021-12-17 03:25:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-17 03:25:31 --> Config Class Initialized
INFO - 2021-12-17 03:25:31 --> Hooks Class Initialized
DEBUG - 2021-12-17 03:25:31 --> UTF-8 Support Enabled
INFO - 2021-12-17 03:25:31 --> Utf8 Class Initialized
INFO - 2021-12-17 03:25:31 --> URI Class Initialized
INFO - 2021-12-17 03:25:31 --> Router Class Initialized
INFO - 2021-12-17 03:25:31 --> Output Class Initialized
INFO - 2021-12-17 03:25:31 --> Security Class Initialized
DEBUG - 2021-12-17 03:25:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-17 03:25:31 --> Input Class Initialized
INFO - 2021-12-17 03:25:31 --> Language Class Initialized
INFO - 2021-12-17 03:25:31 --> Loader Class Initialized
INFO - 2021-12-17 03:25:31 --> Helper loaded: url_helper
INFO - 2021-12-17 03:25:31 --> Helper loaded: form_helper
INFO - 2021-12-17 03:25:31 --> Helper loaded: common_helper
INFO - 2021-12-17 03:25:31 --> Database Driver Class Initialized
DEBUG - 2021-12-17 03:25:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-17 03:25:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-17 03:25:36 --> Config Class Initialized
INFO - 2021-12-17 03:25:36 --> Hooks Class Initialized
DEBUG - 2021-12-17 03:25:36 --> UTF-8 Support Enabled
INFO - 2021-12-17 03:25:36 --> Utf8 Class Initialized
INFO - 2021-12-17 03:25:36 --> URI Class Initialized
INFO - 2021-12-17 03:25:36 --> Router Class Initialized
INFO - 2021-12-17 03:25:36 --> Output Class Initialized
INFO - 2021-12-17 03:25:36 --> Security Class Initialized
DEBUG - 2021-12-17 03:25:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-17 03:25:36 --> Input Class Initialized
INFO - 2021-12-17 03:25:36 --> Language Class Initialized
INFO - 2021-12-17 03:25:36 --> Loader Class Initialized
INFO - 2021-12-17 03:25:36 --> Helper loaded: url_helper
INFO - 2021-12-17 03:25:36 --> Helper loaded: form_helper
INFO - 2021-12-17 03:25:36 --> Helper loaded: common_helper
INFO - 2021-12-17 03:25:36 --> Database Driver Class Initialized
DEBUG - 2021-12-17 03:25:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-17 03:25:38 --> File loaded: /home3/karoteam/public_html/application/views/header.php
ERROR - 2021-12-17 03:25:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-17 03:25:40 --> Config Class Initialized
INFO - 2021-12-17 03:25:40 --> Hooks Class Initialized
DEBUG - 2021-12-17 03:25:40 --> UTF-8 Support Enabled
INFO - 2021-12-17 03:25:40 --> Utf8 Class Initialized
INFO - 2021-12-17 03:25:40 --> URI Class Initialized
INFO - 2021-12-17 03:25:40 --> Router Class Initialized
INFO - 2021-12-17 03:25:40 --> Output Class Initialized
INFO - 2021-12-17 03:25:40 --> Security Class Initialized
DEBUG - 2021-12-17 03:25:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-17 03:25:40 --> Input Class Initialized
INFO - 2021-12-17 03:25:40 --> Language Class Initialized
INFO - 2021-12-17 03:25:40 --> Loader Class Initialized
INFO - 2021-12-17 03:25:40 --> Helper loaded: url_helper
INFO - 2021-12-17 03:25:40 --> Helper loaded: form_helper
INFO - 2021-12-17 03:25:40 --> Helper loaded: common_helper
INFO - 2021-12-17 03:25:40 --> Database Driver Class Initialized
DEBUG - 2021-12-17 03:25:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-17 03:25:48 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2021-12-17 03:25:48 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-17 03:25:48 --> Final output sent to browser
DEBUG - 2021-12-17 03:25:48 --> Total execution time: 17.8608
INFO - 2021-12-17 03:25:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-17 03:25:48 --> Controller Class Initialized
INFO - 2021-12-17 03:25:48 --> Form Validation Class Initialized
DEBUG - 2021-12-17 03:25:48 --> Encrypt Class Initialized
INFO - 2021-12-17 03:25:48 --> Model "Login_model" initialized
INFO - 2021-12-17 03:25:48 --> Model "Dashboard_model" initialized
INFO - 2021-12-17 03:25:48 --> Model "Case_model" initialized
INFO - 2021-12-17 03:25:56 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-17 03:26:06 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2021-12-17 03:26:06 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-17 03:26:06 --> Final output sent to browser
DEBUG - 2021-12-17 03:26:06 --> Total execution time: 34.6194
INFO - 2021-12-17 03:26:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-17 03:26:06 --> Controller Class Initialized
INFO - 2021-12-17 03:26:06 --> Form Validation Class Initialized
DEBUG - 2021-12-17 03:26:06 --> Encrypt Class Initialized
INFO - 2021-12-17 03:26:06 --> Model "Login_model" initialized
INFO - 2021-12-17 03:26:06 --> Model "Dashboard_model" initialized
INFO - 2021-12-17 03:26:06 --> Model "Case_model" initialized
INFO - 2021-12-17 03:26:14 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-17 03:26:24 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2021-12-17 03:26:24 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-17 03:26:24 --> Final output sent to browser
DEBUG - 2021-12-17 03:26:24 --> Total execution time: 47.9647
INFO - 2021-12-17 03:26:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-17 03:26:24 --> Controller Class Initialized
INFO - 2021-12-17 03:26:24 --> Form Validation Class Initialized
DEBUG - 2021-12-17 03:26:24 --> Encrypt Class Initialized
INFO - 2021-12-17 03:26:24 --> Model "Login_model" initialized
INFO - 2021-12-17 03:26:24 --> Model "Dashboard_model" initialized
INFO - 2021-12-17 03:26:24 --> Model "Case_model" initialized
ERROR - 2021-12-17 03:26:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-17 03:26:24 --> Config Class Initialized
INFO - 2021-12-17 03:26:24 --> Hooks Class Initialized
DEBUG - 2021-12-17 03:26:24 --> UTF-8 Support Enabled
INFO - 2021-12-17 03:26:24 --> Utf8 Class Initialized
INFO - 2021-12-17 03:26:24 --> URI Class Initialized
INFO - 2021-12-17 03:26:24 --> Router Class Initialized
INFO - 2021-12-17 03:26:24 --> Output Class Initialized
INFO - 2021-12-17 03:26:24 --> Security Class Initialized
DEBUG - 2021-12-17 03:26:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-17 03:26:24 --> Input Class Initialized
INFO - 2021-12-17 03:26:24 --> Language Class Initialized
INFO - 2021-12-17 03:26:24 --> Loader Class Initialized
INFO - 2021-12-17 03:26:24 --> Helper loaded: url_helper
INFO - 2021-12-17 03:26:24 --> Helper loaded: form_helper
INFO - 2021-12-17 03:26:24 --> Helper loaded: common_helper
INFO - 2021-12-17 03:26:24 --> Database Driver Class Initialized
DEBUG - 2021-12-17 03:26:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-17 03:26:31 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-17 03:26:41 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2021-12-17 03:26:41 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-17 03:26:41 --> Final output sent to browser
DEBUG - 2021-12-17 03:26:41 --> Total execution time: 61.8795
INFO - 2021-12-17 03:26:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-17 03:26:41 --> Controller Class Initialized
INFO - 2021-12-17 03:26:41 --> Form Validation Class Initialized
DEBUG - 2021-12-17 03:26:41 --> Encrypt Class Initialized
INFO - 2021-12-17 03:26:41 --> Model "Login_model" initialized
INFO - 2021-12-17 03:26:41 --> Model "Dashboard_model" initialized
INFO - 2021-12-17 03:26:41 --> Model "Case_model" initialized
INFO - 2021-12-17 03:26:49 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-17 03:27:00 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2021-12-17 03:27:00 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-17 03:27:00 --> Final output sent to browser
DEBUG - 2021-12-17 03:27:00 --> Total execution time: 36.0494
ERROR - 2021-12-17 03:27:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-17 03:27:01 --> Config Class Initialized
INFO - 2021-12-17 03:27:01 --> Hooks Class Initialized
DEBUG - 2021-12-17 03:27:01 --> UTF-8 Support Enabled
INFO - 2021-12-17 03:27:01 --> Utf8 Class Initialized
INFO - 2021-12-17 03:27:01 --> URI Class Initialized
INFO - 2021-12-17 03:27:01 --> Router Class Initialized
INFO - 2021-12-17 03:27:01 --> Output Class Initialized
INFO - 2021-12-17 03:27:01 --> Security Class Initialized
DEBUG - 2021-12-17 03:27:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-17 03:27:01 --> Input Class Initialized
INFO - 2021-12-17 03:27:01 --> Language Class Initialized
ERROR - 2021-12-17 03:27:01 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-12-17 03:31:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-17 03:31:54 --> Config Class Initialized
INFO - 2021-12-17 03:31:54 --> Hooks Class Initialized
DEBUG - 2021-12-17 03:31:54 --> UTF-8 Support Enabled
INFO - 2021-12-17 03:31:54 --> Utf8 Class Initialized
INFO - 2021-12-17 03:31:54 --> URI Class Initialized
INFO - 2021-12-17 03:31:54 --> Router Class Initialized
INFO - 2021-12-17 03:31:54 --> Output Class Initialized
INFO - 2021-12-17 03:31:54 --> Security Class Initialized
DEBUG - 2021-12-17 03:31:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-17 03:31:54 --> Input Class Initialized
INFO - 2021-12-17 03:31:54 --> Language Class Initialized
INFO - 2021-12-17 03:31:54 --> Loader Class Initialized
INFO - 2021-12-17 03:31:54 --> Helper loaded: url_helper
INFO - 2021-12-17 03:31:54 --> Helper loaded: form_helper
INFO - 2021-12-17 03:31:54 --> Helper loaded: common_helper
INFO - 2021-12-17 03:31:54 --> Database Driver Class Initialized
DEBUG - 2021-12-17 03:31:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-17 03:31:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-17 03:31:54 --> Controller Class Initialized
INFO - 2021-12-17 03:31:54 --> Form Validation Class Initialized
DEBUG - 2021-12-17 03:31:54 --> Encrypt Class Initialized
INFO - 2021-12-17 03:31:54 --> Model "Patient_model" initialized
INFO - 2021-12-17 03:31:54 --> Model "Patientcase_model" initialized
INFO - 2021-12-17 03:31:54 --> Model "Referredby_model" initialized
INFO - 2021-12-17 03:31:54 --> Model "Prefix_master" initialized
INFO - 2021-12-17 03:31:54 --> Model "Hospital_model" initialized
INFO - 2021-12-17 03:31:54 --> File loaded: /home3/karoteam/public_html/application/views/header.php
ERROR - 2021-12-17 03:31:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-17 03:31:59 --> Config Class Initialized
INFO - 2021-12-17 03:31:59 --> Hooks Class Initialized
DEBUG - 2021-12-17 03:31:59 --> UTF-8 Support Enabled
INFO - 2021-12-17 03:31:59 --> Utf8 Class Initialized
INFO - 2021-12-17 03:31:59 --> URI Class Initialized
INFO - 2021-12-17 03:31:59 --> Router Class Initialized
INFO - 2021-12-17 03:31:59 --> Output Class Initialized
INFO - 2021-12-17 03:31:59 --> Security Class Initialized
DEBUG - 2021-12-17 03:31:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-17 03:31:59 --> Input Class Initialized
INFO - 2021-12-17 03:31:59 --> Language Class Initialized
INFO - 2021-12-17 03:31:59 --> Loader Class Initialized
INFO - 2021-12-17 03:31:59 --> Helper loaded: url_helper
INFO - 2021-12-17 03:31:59 --> Helper loaded: form_helper
INFO - 2021-12-17 03:31:59 --> Helper loaded: common_helper
INFO - 2021-12-17 03:31:59 --> Database Driver Class Initialized
DEBUG - 2021-12-17 03:31:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-17 03:31:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-17 03:31:59 --> Controller Class Initialized
INFO - 2021-12-17 03:31:59 --> Form Validation Class Initialized
DEBUG - 2021-12-17 03:31:59 --> Encrypt Class Initialized
INFO - 2021-12-17 03:31:59 --> Model "Patient_model" initialized
INFO - 2021-12-17 03:31:59 --> Model "Patientcase_model" initialized
INFO - 2021-12-17 03:31:59 --> Model "Referredby_model" initialized
INFO - 2021-12-17 03:31:59 --> Model "Prefix_master" initialized
INFO - 2021-12-17 03:31:59 --> Model "Hospital_model" initialized
INFO - 2021-12-17 03:31:59 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-17 03:31:59 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2021-12-17 03:31:59 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-17 03:31:59 --> Final output sent to browser
DEBUG - 2021-12-17 03:31:59 --> Total execution time: 0.0510
ERROR - 2021-12-17 03:31:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-17 03:31:59 --> Config Class Initialized
INFO - 2021-12-17 03:31:59 --> Hooks Class Initialized
DEBUG - 2021-12-17 03:31:59 --> UTF-8 Support Enabled
INFO - 2021-12-17 03:31:59 --> Utf8 Class Initialized
INFO - 2021-12-17 03:31:59 --> URI Class Initialized
INFO - 2021-12-17 03:31:59 --> Router Class Initialized
INFO - 2021-12-17 03:31:59 --> Output Class Initialized
INFO - 2021-12-17 03:31:59 --> Security Class Initialized
DEBUG - 2021-12-17 03:31:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-17 03:31:59 --> Input Class Initialized
INFO - 2021-12-17 03:31:59 --> Language Class Initialized
ERROR - 2021-12-17 03:31:59 --> 404 Page Not Found: Karoclient/usersprofile
INFO - 2021-12-17 03:32:00 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2021-12-17 03:32:00 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
ERROR - 2021-12-17 03:32:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-17 03:32:28 --> Config Class Initialized
INFO - 2021-12-17 03:32:28 --> Hooks Class Initialized
DEBUG - 2021-12-17 03:32:28 --> UTF-8 Support Enabled
INFO - 2021-12-17 03:32:28 --> Utf8 Class Initialized
INFO - 2021-12-17 03:32:28 --> URI Class Initialized
INFO - 2021-12-17 03:32:28 --> Router Class Initialized
INFO - 2021-12-17 03:32:28 --> Output Class Initialized
INFO - 2021-12-17 03:32:28 --> Security Class Initialized
DEBUG - 2021-12-17 03:32:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-17 03:32:28 --> Input Class Initialized
INFO - 2021-12-17 03:32:28 --> Language Class Initialized
INFO - 2021-12-17 03:32:28 --> Loader Class Initialized
INFO - 2021-12-17 03:32:28 --> Helper loaded: url_helper
INFO - 2021-12-17 03:32:28 --> Helper loaded: form_helper
INFO - 2021-12-17 03:32:28 --> Helper loaded: common_helper
INFO - 2021-12-17 03:32:28 --> Database Driver Class Initialized
DEBUG - 2021-12-17 03:32:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-17 03:32:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-17 03:32:28 --> Controller Class Initialized
INFO - 2021-12-17 03:32:28 --> Form Validation Class Initialized
DEBUG - 2021-12-17 03:32:28 --> Encrypt Class Initialized
INFO - 2021-12-17 03:32:28 --> Model "Patient_model" initialized
INFO - 2021-12-17 03:32:28 --> Model "Patientcase_model" initialized
INFO - 2021-12-17 03:32:28 --> Model "Referredby_model" initialized
INFO - 2021-12-17 03:32:28 --> Model "Prefix_master" initialized
INFO - 2021-12-17 03:32:28 --> Model "Hospital_model" initialized
INFO - 2021-12-17 03:32:28 --> File loaded: /home3/karoteam/public_html/application/views/header.php
ERROR - 2021-12-17 03:32:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-17 03:32:30 --> Config Class Initialized
INFO - 2021-12-17 03:32:30 --> Hooks Class Initialized
DEBUG - 2021-12-17 03:32:30 --> UTF-8 Support Enabled
INFO - 2021-12-17 03:32:30 --> Utf8 Class Initialized
INFO - 2021-12-17 03:32:30 --> URI Class Initialized
INFO - 2021-12-17 03:32:30 --> Router Class Initialized
INFO - 2021-12-17 03:32:30 --> Output Class Initialized
INFO - 2021-12-17 03:32:30 --> Security Class Initialized
DEBUG - 2021-12-17 03:32:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-17 03:32:30 --> Input Class Initialized
INFO - 2021-12-17 03:32:30 --> Language Class Initialized
INFO - 2021-12-17 03:32:30 --> Loader Class Initialized
INFO - 2021-12-17 03:32:30 --> Helper loaded: url_helper
INFO - 2021-12-17 03:32:30 --> Helper loaded: form_helper
INFO - 2021-12-17 03:32:30 --> Helper loaded: common_helper
INFO - 2021-12-17 03:32:30 --> Database Driver Class Initialized
DEBUG - 2021-12-17 03:32:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-17 03:32:34 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2021-12-17 03:32:34 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-17 03:32:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-17 03:32:34 --> Controller Class Initialized
INFO - 2021-12-17 03:32:34 --> Form Validation Class Initialized
DEBUG - 2021-12-17 03:32:34 --> Encrypt Class Initialized
INFO - 2021-12-17 03:32:34 --> Model "Patient_model" initialized
INFO - 2021-12-17 03:32:34 --> Model "Patientcase_model" initialized
INFO - 2021-12-17 03:32:34 --> Model "Referredby_model" initialized
INFO - 2021-12-17 03:32:34 --> Model "Prefix_master" initialized
INFO - 2021-12-17 03:32:34 --> Model "Hospital_model" initialized
INFO - 2021-12-17 03:32:34 --> File loaded: /home3/karoteam/public_html/application/views/header.php
ERROR - 2021-12-17 03:32:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-17 03:32:34 --> Config Class Initialized
INFO - 2021-12-17 03:32:34 --> Hooks Class Initialized
DEBUG - 2021-12-17 03:32:34 --> UTF-8 Support Enabled
INFO - 2021-12-17 03:32:34 --> Utf8 Class Initialized
INFO - 2021-12-17 03:32:34 --> URI Class Initialized
INFO - 2021-12-17 03:32:34 --> Router Class Initialized
INFO - 2021-12-17 03:32:34 --> Output Class Initialized
INFO - 2021-12-17 03:32:34 --> Security Class Initialized
DEBUG - 2021-12-17 03:32:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-17 03:32:34 --> Input Class Initialized
INFO - 2021-12-17 03:32:34 --> Language Class Initialized
INFO - 2021-12-17 03:32:34 --> Loader Class Initialized
INFO - 2021-12-17 03:32:34 --> Helper loaded: url_helper
INFO - 2021-12-17 03:32:34 --> Helper loaded: form_helper
INFO - 2021-12-17 03:32:34 --> Helper loaded: common_helper
INFO - 2021-12-17 03:32:34 --> Database Driver Class Initialized
DEBUG - 2021-12-17 03:32:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-17 03:32:40 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2021-12-17 03:32:40 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-17 03:32:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-17 03:32:40 --> Controller Class Initialized
INFO - 2021-12-17 03:32:40 --> Form Validation Class Initialized
DEBUG - 2021-12-17 03:32:40 --> Encrypt Class Initialized
INFO - 2021-12-17 03:32:40 --> Model "Patient_model" initialized
INFO - 2021-12-17 03:32:40 --> Model "Patientcase_model" initialized
INFO - 2021-12-17 03:32:40 --> Model "Referredby_model" initialized
INFO - 2021-12-17 03:32:40 --> Model "Prefix_master" initialized
INFO - 2021-12-17 03:32:40 --> Model "Hospital_model" initialized
INFO - 2021-12-17 03:32:40 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-17 03:32:45 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2021-12-17 03:32:45 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
ERROR - 2021-12-17 03:32:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-17 03:32:46 --> Config Class Initialized
INFO - 2021-12-17 03:32:46 --> Hooks Class Initialized
DEBUG - 2021-12-17 03:32:46 --> UTF-8 Support Enabled
INFO - 2021-12-17 03:32:46 --> Utf8 Class Initialized
INFO - 2021-12-17 03:32:46 --> URI Class Initialized
INFO - 2021-12-17 03:32:46 --> Router Class Initialized
INFO - 2021-12-17 03:32:46 --> Output Class Initialized
INFO - 2021-12-17 03:32:46 --> Security Class Initialized
DEBUG - 2021-12-17 03:32:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-17 03:32:46 --> Input Class Initialized
INFO - 2021-12-17 03:32:46 --> Language Class Initialized
ERROR - 2021-12-17 03:32:46 --> 404 Page Not Found: Karoclient/usersprofile
INFO - 2021-12-17 03:32:47 --> Final output sent to browser
DEBUG - 2021-12-17 03:32:47 --> Total execution time: 11.0934
ERROR - 2021-12-17 03:34:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-17 03:34:03 --> Config Class Initialized
INFO - 2021-12-17 03:34:03 --> Hooks Class Initialized
DEBUG - 2021-12-17 03:34:03 --> UTF-8 Support Enabled
INFO - 2021-12-17 03:34:03 --> Utf8 Class Initialized
INFO - 2021-12-17 03:34:03 --> URI Class Initialized
INFO - 2021-12-17 03:34:03 --> Router Class Initialized
INFO - 2021-12-17 03:34:03 --> Output Class Initialized
INFO - 2021-12-17 03:34:03 --> Security Class Initialized
DEBUG - 2021-12-17 03:34:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-17 03:34:03 --> Input Class Initialized
INFO - 2021-12-17 03:34:03 --> Language Class Initialized
INFO - 2021-12-17 03:34:03 --> Loader Class Initialized
INFO - 2021-12-17 03:34:03 --> Helper loaded: url_helper
INFO - 2021-12-17 03:34:03 --> Helper loaded: form_helper
INFO - 2021-12-17 03:34:03 --> Helper loaded: common_helper
INFO - 2021-12-17 03:34:03 --> Database Driver Class Initialized
DEBUG - 2021-12-17 03:34:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-17 03:34:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-17 03:34:03 --> Controller Class Initialized
INFO - 2021-12-17 03:34:03 --> Form Validation Class Initialized
DEBUG - 2021-12-17 03:34:03 --> Encrypt Class Initialized
INFO - 2021-12-17 03:34:03 --> Model "Patient_model" initialized
INFO - 2021-12-17 03:34:03 --> Model "Patientcase_model" initialized
INFO - 2021-12-17 03:34:03 --> Model "Prefix_master" initialized
INFO - 2021-12-17 03:34:03 --> Model "Users_model" initialized
INFO - 2021-12-17 03:34:03 --> Model "Hospital_model" initialized
INFO - 2021-12-17 03:34:04 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-17 03:34:04 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2021-12-17 03:34:04 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-17 03:34:04 --> Final output sent to browser
DEBUG - 2021-12-17 03:34:04 --> Total execution time: 0.2866
ERROR - 2021-12-17 03:34:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-17 03:34:04 --> Config Class Initialized
INFO - 2021-12-17 03:34:04 --> Hooks Class Initialized
DEBUG - 2021-12-17 03:34:04 --> UTF-8 Support Enabled
INFO - 2021-12-17 03:34:04 --> Utf8 Class Initialized
INFO - 2021-12-17 03:34:04 --> URI Class Initialized
INFO - 2021-12-17 03:34:04 --> Router Class Initialized
INFO - 2021-12-17 03:34:04 --> Output Class Initialized
INFO - 2021-12-17 03:34:04 --> Security Class Initialized
DEBUG - 2021-12-17 03:34:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-17 03:34:04 --> Input Class Initialized
INFO - 2021-12-17 03:34:04 --> Language Class Initialized
ERROR - 2021-12-17 03:34:04 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-12-17 03:34:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-17 03:34:13 --> Config Class Initialized
INFO - 2021-12-17 03:34:13 --> Hooks Class Initialized
DEBUG - 2021-12-17 03:34:13 --> UTF-8 Support Enabled
INFO - 2021-12-17 03:34:13 --> Utf8 Class Initialized
INFO - 2021-12-17 03:34:13 --> URI Class Initialized
INFO - 2021-12-17 03:34:13 --> Router Class Initialized
INFO - 2021-12-17 03:34:13 --> Output Class Initialized
INFO - 2021-12-17 03:34:13 --> Security Class Initialized
DEBUG - 2021-12-17 03:34:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-17 03:34:13 --> Input Class Initialized
INFO - 2021-12-17 03:34:13 --> Language Class Initialized
INFO - 2021-12-17 03:34:13 --> Loader Class Initialized
INFO - 2021-12-17 03:34:13 --> Helper loaded: url_helper
INFO - 2021-12-17 03:34:13 --> Helper loaded: form_helper
INFO - 2021-12-17 03:34:13 --> Helper loaded: common_helper
INFO - 2021-12-17 03:34:13 --> Database Driver Class Initialized
DEBUG - 2021-12-17 03:34:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-17 03:34:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-17 03:34:13 --> Controller Class Initialized
INFO - 2021-12-17 03:34:13 --> Form Validation Class Initialized
DEBUG - 2021-12-17 03:34:13 --> Encrypt Class Initialized
INFO - 2021-12-17 03:34:13 --> Model "Patient_model" initialized
INFO - 2021-12-17 03:34:13 --> Model "Patientcase_model" initialized
INFO - 2021-12-17 03:34:13 --> Model "Referredby_model" initialized
INFO - 2021-12-17 03:34:13 --> Model "Prefix_master" initialized
INFO - 2021-12-17 03:34:13 --> Model "Hospital_model" initialized
ERROR - 2021-12-17 03:34:13 --> Severity: error --> Exception: Too few arguments to function Patient_model::getPatient(), 1 passed in /home3/karoteam/public_html/application/controllers/Patientmaster.php on line 25 and exactly 5 expected /home3/karoteam/public_html/application/models/Patient_model.php 6
ERROR - 2021-12-17 03:34:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-17 03:34:20 --> Config Class Initialized
INFO - 2021-12-17 03:34:20 --> Hooks Class Initialized
DEBUG - 2021-12-17 03:34:20 --> UTF-8 Support Enabled
INFO - 2021-12-17 03:34:20 --> Utf8 Class Initialized
INFO - 2021-12-17 03:34:20 --> URI Class Initialized
INFO - 2021-12-17 03:34:20 --> Router Class Initialized
INFO - 2021-12-17 03:34:20 --> Output Class Initialized
INFO - 2021-12-17 03:34:20 --> Security Class Initialized
DEBUG - 2021-12-17 03:34:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-17 03:34:20 --> Input Class Initialized
INFO - 2021-12-17 03:34:20 --> Language Class Initialized
INFO - 2021-12-17 03:34:20 --> Loader Class Initialized
INFO - 2021-12-17 03:34:20 --> Helper loaded: url_helper
INFO - 2021-12-17 03:34:20 --> Helper loaded: form_helper
INFO - 2021-12-17 03:34:20 --> Helper loaded: common_helper
INFO - 2021-12-17 03:34:20 --> Database Driver Class Initialized
DEBUG - 2021-12-17 03:34:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-17 03:34:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-17 03:34:20 --> Controller Class Initialized
INFO - 2021-12-17 03:34:20 --> Form Validation Class Initialized
DEBUG - 2021-12-17 03:34:20 --> Encrypt Class Initialized
INFO - 2021-12-17 03:34:20 --> Model "Patient_model" initialized
INFO - 2021-12-17 03:34:20 --> Model "Patientcase_model" initialized
INFO - 2021-12-17 03:34:20 --> Model "Referredby_model" initialized
INFO - 2021-12-17 03:34:20 --> Model "Prefix_master" initialized
INFO - 2021-12-17 03:34:20 --> Model "Hospital_model" initialized
ERROR - 2021-12-17 03:34:20 --> Severity: error --> Exception: Too few arguments to function Patient_model::getPatient(), 1 passed in /home3/karoteam/public_html/application/controllers/Patientmaster.php on line 25 and exactly 5 expected /home3/karoteam/public_html/application/models/Patient_model.php 6
ERROR - 2021-12-17 03:34:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-17 03:34:54 --> Config Class Initialized
INFO - 2021-12-17 03:34:54 --> Hooks Class Initialized
DEBUG - 2021-12-17 03:34:54 --> UTF-8 Support Enabled
INFO - 2021-12-17 03:34:54 --> Utf8 Class Initialized
INFO - 2021-12-17 03:34:54 --> URI Class Initialized
INFO - 2021-12-17 03:34:54 --> Router Class Initialized
INFO - 2021-12-17 03:34:54 --> Output Class Initialized
INFO - 2021-12-17 03:34:54 --> Security Class Initialized
DEBUG - 2021-12-17 03:34:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-17 03:34:54 --> Input Class Initialized
INFO - 2021-12-17 03:34:54 --> Language Class Initialized
INFO - 2021-12-17 03:34:54 --> Loader Class Initialized
INFO - 2021-12-17 03:34:54 --> Helper loaded: url_helper
INFO - 2021-12-17 03:34:54 --> Helper loaded: form_helper
INFO - 2021-12-17 03:34:54 --> Helper loaded: common_helper
INFO - 2021-12-17 03:34:54 --> Database Driver Class Initialized
DEBUG - 2021-12-17 03:34:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-17 03:34:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-17 03:34:54 --> Controller Class Initialized
INFO - 2021-12-17 03:34:54 --> Form Validation Class Initialized
DEBUG - 2021-12-17 03:34:54 --> Encrypt Class Initialized
INFO - 2021-12-17 03:34:54 --> Model "Patient_model" initialized
INFO - 2021-12-17 03:34:54 --> Model "Patientcase_model" initialized
INFO - 2021-12-17 03:34:54 --> Model "Prefix_master" initialized
INFO - 2021-12-17 03:34:54 --> Model "Users_model" initialized
INFO - 2021-12-17 03:34:54 --> Model "Hospital_model" initialized
INFO - 2021-12-17 03:34:54 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-17 03:34:54 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2021-12-17 03:34:54 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-17 03:34:54 --> Final output sent to browser
DEBUG - 2021-12-17 03:34:54 --> Total execution time: 0.0557
ERROR - 2021-12-17 03:34:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-17 03:34:55 --> Config Class Initialized
INFO - 2021-12-17 03:34:55 --> Hooks Class Initialized
DEBUG - 2021-12-17 03:34:55 --> UTF-8 Support Enabled
INFO - 2021-12-17 03:34:55 --> Utf8 Class Initialized
INFO - 2021-12-17 03:34:55 --> URI Class Initialized
INFO - 2021-12-17 03:34:55 --> Router Class Initialized
INFO - 2021-12-17 03:34:55 --> Output Class Initialized
INFO - 2021-12-17 03:34:55 --> Security Class Initialized
DEBUG - 2021-12-17 03:34:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-17 03:34:55 --> Input Class Initialized
INFO - 2021-12-17 03:34:55 --> Language Class Initialized
ERROR - 2021-12-17 03:34:55 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-12-17 06:21:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-17 06:21:52 --> Config Class Initialized
INFO - 2021-12-17 06:21:52 --> Hooks Class Initialized
DEBUG - 2021-12-17 06:21:52 --> UTF-8 Support Enabled
INFO - 2021-12-17 06:21:52 --> Utf8 Class Initialized
INFO - 2021-12-17 06:21:52 --> URI Class Initialized
DEBUG - 2021-12-17 06:21:52 --> No URI present. Default controller set.
INFO - 2021-12-17 06:21:52 --> Router Class Initialized
INFO - 2021-12-17 06:21:52 --> Output Class Initialized
INFO - 2021-12-17 06:21:52 --> Security Class Initialized
DEBUG - 2021-12-17 06:21:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-17 06:21:52 --> Input Class Initialized
INFO - 2021-12-17 06:21:52 --> Language Class Initialized
INFO - 2021-12-17 06:21:52 --> Loader Class Initialized
INFO - 2021-12-17 06:21:52 --> Helper loaded: url_helper
INFO - 2021-12-17 06:21:52 --> Helper loaded: form_helper
INFO - 2021-12-17 06:21:52 --> Helper loaded: common_helper
INFO - 2021-12-17 06:21:52 --> Database Driver Class Initialized
DEBUG - 2021-12-17 06:21:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-17 06:21:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-17 06:21:52 --> Controller Class Initialized
INFO - 2021-12-17 06:21:52 --> Form Validation Class Initialized
DEBUG - 2021-12-17 06:21:52 --> Encrypt Class Initialized
DEBUG - 2021-12-17 06:21:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-17 06:21:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-17 06:21:52 --> Email Class Initialized
INFO - 2021-12-17 06:21:52 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-17 06:21:52 --> Calendar Class Initialized
INFO - 2021-12-17 06:21:52 --> Model "Login_model" initialized
INFO - 2021-12-17 06:21:52 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-17 06:21:52 --> Final output sent to browser
DEBUG - 2021-12-17 06:21:52 --> Total execution time: 0.0372
ERROR - 2021-12-17 06:26:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-17 06:26:42 --> Config Class Initialized
INFO - 2021-12-17 06:26:42 --> Hooks Class Initialized
DEBUG - 2021-12-17 06:26:42 --> UTF-8 Support Enabled
INFO - 2021-12-17 06:26:42 --> Utf8 Class Initialized
INFO - 2021-12-17 06:26:42 --> URI Class Initialized
DEBUG - 2021-12-17 06:26:42 --> No URI present. Default controller set.
INFO - 2021-12-17 06:26:42 --> Router Class Initialized
INFO - 2021-12-17 06:26:42 --> Output Class Initialized
INFO - 2021-12-17 06:26:42 --> Security Class Initialized
DEBUG - 2021-12-17 06:26:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-17 06:26:42 --> Input Class Initialized
INFO - 2021-12-17 06:26:42 --> Language Class Initialized
INFO - 2021-12-17 06:26:42 --> Loader Class Initialized
INFO - 2021-12-17 06:26:42 --> Helper loaded: url_helper
INFO - 2021-12-17 06:26:42 --> Helper loaded: form_helper
INFO - 2021-12-17 06:26:42 --> Helper loaded: common_helper
INFO - 2021-12-17 06:26:42 --> Database Driver Class Initialized
DEBUG - 2021-12-17 06:26:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-17 06:26:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-17 06:26:42 --> Controller Class Initialized
INFO - 2021-12-17 06:26:42 --> Form Validation Class Initialized
DEBUG - 2021-12-17 06:26:42 --> Encrypt Class Initialized
DEBUG - 2021-12-17 06:26:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-17 06:26:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-17 06:26:42 --> Email Class Initialized
INFO - 2021-12-17 06:26:42 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-17 06:26:42 --> Calendar Class Initialized
INFO - 2021-12-17 06:26:42 --> Model "Login_model" initialized
INFO - 2021-12-17 06:26:42 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-17 06:26:42 --> Final output sent to browser
DEBUG - 2021-12-17 06:26:42 --> Total execution time: 0.0283
ERROR - 2021-12-17 06:42:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-17 06:42:54 --> Config Class Initialized
INFO - 2021-12-17 06:42:54 --> Hooks Class Initialized
DEBUG - 2021-12-17 06:42:54 --> UTF-8 Support Enabled
INFO - 2021-12-17 06:42:54 --> Utf8 Class Initialized
INFO - 2021-12-17 06:42:54 --> URI Class Initialized
INFO - 2021-12-17 06:42:54 --> Router Class Initialized
INFO - 2021-12-17 06:42:54 --> Output Class Initialized
INFO - 2021-12-17 06:42:54 --> Security Class Initialized
DEBUG - 2021-12-17 06:42:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-17 06:42:54 --> Input Class Initialized
INFO - 2021-12-17 06:42:54 --> Language Class Initialized
INFO - 2021-12-17 06:42:54 --> Loader Class Initialized
INFO - 2021-12-17 06:42:54 --> Helper loaded: url_helper
INFO - 2021-12-17 06:42:54 --> Helper loaded: form_helper
INFO - 2021-12-17 06:42:54 --> Helper loaded: common_helper
INFO - 2021-12-17 06:42:54 --> Database Driver Class Initialized
DEBUG - 2021-12-17 06:42:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-17 06:42:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-17 06:42:54 --> Controller Class Initialized
INFO - 2021-12-17 06:42:54 --> Form Validation Class Initialized
DEBUG - 2021-12-17 06:42:54 --> Encrypt Class Initialized
INFO - 2021-12-17 06:42:54 --> Model "Login_model" initialized
INFO - 2021-12-17 06:42:54 --> Model "Dashboard_model" initialized
INFO - 2021-12-17 06:42:54 --> Model "Case_model" initialized
ERROR - 2021-12-17 06:42:54 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'GROUP BY  CALCULATEAGE(YEAR(patient_dob))
     
     UNION 
     
  SELECT calcu' at line 7 - Invalid query: SELECT SUM(TotalPatient) as TotalPatient ,AgeGroup
FROM
( 
SELECT CALCULATEAGE(YEAR(patient_dob)) AS AgeGroup, COUNT(CALCULATEAGE(YEAR(patient_dob)))  AS TotalPatient FROM patient_master
       
    WHERE  IFNULL(`status`,0)!= '1' AND patient_dob IS NOT NULL AND patient_dob != '0000-00-00'  AND patient_master.created_by = 
     GROUP BY  CALCULATEAGE(YEAR(patient_dob))
     
     UNION 
     
  SELECT calculateWithoutDOBAge(SUBSTRING(patient_age,1,2)) AS AgeGroup, COUNT(calculateWithoutDOBAge(SUBSTRING(patient_age,1,2))) AS 
  TotalPatient FROM patient_master WHERE IFNULL(`status`,0)!= '1' AND IFNULL(patient_dob,'')='0000-00-00'  AND IFNULL(patient_age,'')!=''  AND patient_master.created_by = 
        GROUP BY calculateWithoutDOBAge(SUBSTRING(patient_age,1,2))
        )B GROUP BY AgeGroup
INFO - 2021-12-17 06:42:54 --> Language file loaded: language/english/db_lang.php
ERROR - 2021-12-17 06:43:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-17 06:43:04 --> Config Class Initialized
INFO - 2021-12-17 06:43:04 --> Hooks Class Initialized
DEBUG - 2021-12-17 06:43:04 --> UTF-8 Support Enabled
INFO - 2021-12-17 06:43:04 --> Utf8 Class Initialized
INFO - 2021-12-17 06:43:04 --> URI Class Initialized
DEBUG - 2021-12-17 06:43:04 --> No URI present. Default controller set.
INFO - 2021-12-17 06:43:04 --> Router Class Initialized
INFO - 2021-12-17 06:43:04 --> Output Class Initialized
INFO - 2021-12-17 06:43:04 --> Security Class Initialized
DEBUG - 2021-12-17 06:43:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-17 06:43:04 --> Input Class Initialized
INFO - 2021-12-17 06:43:04 --> Language Class Initialized
INFO - 2021-12-17 06:43:04 --> Loader Class Initialized
INFO - 2021-12-17 06:43:04 --> Helper loaded: url_helper
INFO - 2021-12-17 06:43:04 --> Helper loaded: form_helper
INFO - 2021-12-17 06:43:04 --> Helper loaded: common_helper
INFO - 2021-12-17 06:43:04 --> Database Driver Class Initialized
DEBUG - 2021-12-17 06:43:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-17 06:43:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-17 06:43:04 --> Controller Class Initialized
INFO - 2021-12-17 06:43:04 --> Form Validation Class Initialized
DEBUG - 2021-12-17 06:43:04 --> Encrypt Class Initialized
DEBUG - 2021-12-17 06:43:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-17 06:43:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-17 06:43:04 --> Email Class Initialized
INFO - 2021-12-17 06:43:04 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-17 06:43:04 --> Calendar Class Initialized
INFO - 2021-12-17 06:43:04 --> Model "Login_model" initialized
INFO - 2021-12-17 06:43:04 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-17 06:43:04 --> Final output sent to browser
DEBUG - 2021-12-17 06:43:04 --> Total execution time: 0.0236
ERROR - 2021-12-17 10:10:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-17 10:10:42 --> Config Class Initialized
INFO - 2021-12-17 10:10:42 --> Hooks Class Initialized
DEBUG - 2021-12-17 10:10:42 --> UTF-8 Support Enabled
INFO - 2021-12-17 10:10:42 --> Utf8 Class Initialized
INFO - 2021-12-17 10:10:42 --> URI Class Initialized
DEBUG - 2021-12-17 10:10:42 --> No URI present. Default controller set.
INFO - 2021-12-17 10:10:42 --> Router Class Initialized
INFO - 2021-12-17 10:10:42 --> Output Class Initialized
INFO - 2021-12-17 10:10:42 --> Security Class Initialized
DEBUG - 2021-12-17 10:10:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-17 10:10:42 --> Input Class Initialized
INFO - 2021-12-17 10:10:42 --> Language Class Initialized
INFO - 2021-12-17 10:10:42 --> Loader Class Initialized
INFO - 2021-12-17 10:10:42 --> Helper loaded: url_helper
INFO - 2021-12-17 10:10:42 --> Helper loaded: form_helper
INFO - 2021-12-17 10:10:42 --> Helper loaded: common_helper
INFO - 2021-12-17 10:10:42 --> Database Driver Class Initialized
DEBUG - 2021-12-17 10:10:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-17 10:10:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-17 10:10:42 --> Controller Class Initialized
INFO - 2021-12-17 10:10:42 --> Form Validation Class Initialized
DEBUG - 2021-12-17 10:10:42 --> Encrypt Class Initialized
DEBUG - 2021-12-17 10:10:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-17 10:10:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-17 10:10:42 --> Email Class Initialized
INFO - 2021-12-17 10:10:42 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-17 10:10:42 --> Calendar Class Initialized
INFO - 2021-12-17 10:10:42 --> Model "Login_model" initialized
INFO - 2021-12-17 10:10:42 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-17 10:10:42 --> Final output sent to browser
DEBUG - 2021-12-17 10:10:42 --> Total execution time: 0.0282
ERROR - 2021-12-17 13:51:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-17 13:51:23 --> Config Class Initialized
INFO - 2021-12-17 13:51:23 --> Hooks Class Initialized
DEBUG - 2021-12-17 13:51:23 --> UTF-8 Support Enabled
INFO - 2021-12-17 13:51:23 --> Utf8 Class Initialized
INFO - 2021-12-17 13:51:23 --> URI Class Initialized
DEBUG - 2021-12-17 13:51:23 --> No URI present. Default controller set.
INFO - 2021-12-17 13:51:23 --> Router Class Initialized
INFO - 2021-12-17 13:51:23 --> Output Class Initialized
INFO - 2021-12-17 13:51:23 --> Security Class Initialized
DEBUG - 2021-12-17 13:51:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-17 13:51:23 --> Input Class Initialized
INFO - 2021-12-17 13:51:23 --> Language Class Initialized
INFO - 2021-12-17 13:51:23 --> Loader Class Initialized
INFO - 2021-12-17 13:51:23 --> Helper loaded: url_helper
INFO - 2021-12-17 13:51:23 --> Helper loaded: form_helper
INFO - 2021-12-17 13:51:23 --> Helper loaded: common_helper
INFO - 2021-12-17 13:51:23 --> Database Driver Class Initialized
DEBUG - 2021-12-17 13:51:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-17 13:51:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-17 13:51:23 --> Controller Class Initialized
INFO - 2021-12-17 13:51:23 --> Form Validation Class Initialized
DEBUG - 2021-12-17 13:51:23 --> Encrypt Class Initialized
DEBUG - 2021-12-17 13:51:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-17 13:51:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-17 13:51:23 --> Email Class Initialized
INFO - 2021-12-17 13:51:23 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-17 13:51:23 --> Calendar Class Initialized
INFO - 2021-12-17 13:51:23 --> Model "Login_model" initialized
INFO - 2021-12-17 13:51:23 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-17 13:51:23 --> Final output sent to browser
DEBUG - 2021-12-17 13:51:23 --> Total execution time: 0.0417
ERROR - 2021-12-17 14:16:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-17 14:16:31 --> Config Class Initialized
INFO - 2021-12-17 14:16:31 --> Hooks Class Initialized
DEBUG - 2021-12-17 14:16:31 --> UTF-8 Support Enabled
INFO - 2021-12-17 14:16:31 --> Utf8 Class Initialized
INFO - 2021-12-17 14:16:31 --> URI Class Initialized
DEBUG - 2021-12-17 14:16:31 --> No URI present. Default controller set.
INFO - 2021-12-17 14:16:31 --> Router Class Initialized
INFO - 2021-12-17 14:16:31 --> Output Class Initialized
INFO - 2021-12-17 14:16:31 --> Security Class Initialized
DEBUG - 2021-12-17 14:16:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-17 14:16:31 --> Input Class Initialized
INFO - 2021-12-17 14:16:31 --> Language Class Initialized
INFO - 2021-12-17 14:16:31 --> Loader Class Initialized
INFO - 2021-12-17 14:16:31 --> Helper loaded: url_helper
INFO - 2021-12-17 14:16:31 --> Helper loaded: form_helper
INFO - 2021-12-17 14:16:31 --> Helper loaded: common_helper
INFO - 2021-12-17 14:16:31 --> Database Driver Class Initialized
DEBUG - 2021-12-17 14:16:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-17 14:16:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-17 14:16:31 --> Controller Class Initialized
INFO - 2021-12-17 14:16:31 --> Form Validation Class Initialized
DEBUG - 2021-12-17 14:16:31 --> Encrypt Class Initialized
DEBUG - 2021-12-17 14:16:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-17 14:16:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-17 14:16:31 --> Email Class Initialized
INFO - 2021-12-17 14:16:31 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-17 14:16:31 --> Calendar Class Initialized
INFO - 2021-12-17 14:16:31 --> Model "Login_model" initialized
INFO - 2021-12-17 14:16:31 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-17 14:16:31 --> Final output sent to browser
DEBUG - 2021-12-17 14:16:31 --> Total execution time: 0.0353
ERROR - 2021-12-17 14:16:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-17 14:16:34 --> Config Class Initialized
INFO - 2021-12-17 14:16:34 --> Hooks Class Initialized
DEBUG - 2021-12-17 14:16:34 --> UTF-8 Support Enabled
INFO - 2021-12-17 14:16:34 --> Utf8 Class Initialized
INFO - 2021-12-17 14:16:34 --> URI Class Initialized
INFO - 2021-12-17 14:16:34 --> Router Class Initialized
INFO - 2021-12-17 14:16:34 --> Output Class Initialized
INFO - 2021-12-17 14:16:34 --> Security Class Initialized
DEBUG - 2021-12-17 14:16:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-17 14:16:34 --> Input Class Initialized
INFO - 2021-12-17 14:16:34 --> Language Class Initialized
ERROR - 2021-12-17 14:16:34 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2021-12-17 14:18:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-17 14:18:14 --> Config Class Initialized
INFO - 2021-12-17 14:18:14 --> Hooks Class Initialized
DEBUG - 2021-12-17 14:18:14 --> UTF-8 Support Enabled
INFO - 2021-12-17 14:18:14 --> Utf8 Class Initialized
INFO - 2021-12-17 14:18:14 --> URI Class Initialized
INFO - 2021-12-17 14:18:14 --> Router Class Initialized
INFO - 2021-12-17 14:18:14 --> Output Class Initialized
INFO - 2021-12-17 14:18:14 --> Security Class Initialized
DEBUG - 2021-12-17 14:18:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-17 14:18:14 --> Input Class Initialized
INFO - 2021-12-17 14:18:14 --> Language Class Initialized
INFO - 2021-12-17 14:18:14 --> Loader Class Initialized
INFO - 2021-12-17 14:18:14 --> Helper loaded: url_helper
INFO - 2021-12-17 14:18:14 --> Helper loaded: form_helper
INFO - 2021-12-17 14:18:14 --> Helper loaded: common_helper
INFO - 2021-12-17 14:18:14 --> Database Driver Class Initialized
DEBUG - 2021-12-17 14:18:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-17 14:18:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-17 14:18:14 --> Controller Class Initialized
INFO - 2021-12-17 14:18:14 --> Form Validation Class Initialized
DEBUG - 2021-12-17 14:18:14 --> Encrypt Class Initialized
DEBUG - 2021-12-17 14:18:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-17 14:18:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-17 14:18:14 --> Email Class Initialized
INFO - 2021-12-17 14:18:14 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-17 14:18:14 --> Calendar Class Initialized
INFO - 2021-12-17 14:18:14 --> Model "Login_model" initialized
INFO - 2021-12-17 14:18:14 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-17 14:18:14 --> Final output sent to browser
DEBUG - 2021-12-17 14:18:14 --> Total execution time: 0.3623
ERROR - 2021-12-17 14:18:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-17 14:18:15 --> Config Class Initialized
INFO - 2021-12-17 14:18:15 --> Hooks Class Initialized
DEBUG - 2021-12-17 14:18:15 --> UTF-8 Support Enabled
INFO - 2021-12-17 14:18:15 --> Utf8 Class Initialized
INFO - 2021-12-17 14:18:15 --> URI Class Initialized
DEBUG - 2021-12-17 14:18:15 --> No URI present. Default controller set.
INFO - 2021-12-17 14:18:15 --> Router Class Initialized
INFO - 2021-12-17 14:18:15 --> Output Class Initialized
INFO - 2021-12-17 14:18:15 --> Security Class Initialized
DEBUG - 2021-12-17 14:18:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-17 14:18:15 --> Input Class Initialized
INFO - 2021-12-17 14:18:15 --> Language Class Initialized
INFO - 2021-12-17 14:18:15 --> Loader Class Initialized
INFO - 2021-12-17 14:18:15 --> Helper loaded: url_helper
INFO - 2021-12-17 14:18:15 --> Helper loaded: form_helper
INFO - 2021-12-17 14:18:15 --> Helper loaded: common_helper
INFO - 2021-12-17 14:18:15 --> Database Driver Class Initialized
DEBUG - 2021-12-17 14:18:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-17 14:18:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-17 14:18:15 --> Controller Class Initialized
INFO - 2021-12-17 14:18:15 --> Form Validation Class Initialized
DEBUG - 2021-12-17 14:18:15 --> Encrypt Class Initialized
DEBUG - 2021-12-17 14:18:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-17 14:18:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-17 14:18:15 --> Email Class Initialized
INFO - 2021-12-17 14:18:15 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-17 14:18:15 --> Calendar Class Initialized
INFO - 2021-12-17 14:18:15 --> Model "Login_model" initialized
INFO - 2021-12-17 14:18:15 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-17 14:18:15 --> Final output sent to browser
DEBUG - 2021-12-17 14:18:15 --> Total execution time: 0.0266
ERROR - 2021-12-17 14:18:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-17 14:18:16 --> Config Class Initialized
INFO - 2021-12-17 14:18:16 --> Hooks Class Initialized
DEBUG - 2021-12-17 14:18:16 --> UTF-8 Support Enabled
INFO - 2021-12-17 14:18:16 --> Utf8 Class Initialized
INFO - 2021-12-17 14:18:16 --> URI Class Initialized
INFO - 2021-12-17 14:18:16 --> Router Class Initialized
INFO - 2021-12-17 14:18:16 --> Output Class Initialized
INFO - 2021-12-17 14:18:16 --> Security Class Initialized
DEBUG - 2021-12-17 14:18:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-17 14:18:16 --> Input Class Initialized
INFO - 2021-12-17 14:18:16 --> Language Class Initialized
INFO - 2021-12-17 14:18:16 --> Loader Class Initialized
INFO - 2021-12-17 14:18:16 --> Helper loaded: url_helper
INFO - 2021-12-17 14:18:16 --> Helper loaded: form_helper
INFO - 2021-12-17 14:18:16 --> Helper loaded: common_helper
INFO - 2021-12-17 14:18:16 --> Database Driver Class Initialized
DEBUG - 2021-12-17 14:18:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-17 14:18:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-17 14:18:16 --> Controller Class Initialized
INFO - 2021-12-17 14:18:16 --> Form Validation Class Initialized
DEBUG - 2021-12-17 14:18:16 --> Encrypt Class Initialized
DEBUG - 2021-12-17 14:18:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-17 14:18:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-17 14:18:16 --> Email Class Initialized
INFO - 2021-12-17 14:18:16 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-17 14:18:16 --> Calendar Class Initialized
INFO - 2021-12-17 14:18:16 --> Model "Login_model" initialized
ERROR - 2021-12-17 14:18:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-17 14:18:16 --> Config Class Initialized
INFO - 2021-12-17 14:18:16 --> Hooks Class Initialized
DEBUG - 2021-12-17 14:18:16 --> UTF-8 Support Enabled
INFO - 2021-12-17 14:18:16 --> Utf8 Class Initialized
INFO - 2021-12-17 14:18:16 --> URI Class Initialized
INFO - 2021-12-17 14:18:16 --> Router Class Initialized
INFO - 2021-12-17 14:18:16 --> Output Class Initialized
INFO - 2021-12-17 14:18:16 --> Security Class Initialized
DEBUG - 2021-12-17 14:18:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-17 14:18:16 --> Input Class Initialized
INFO - 2021-12-17 14:18:16 --> Language Class Initialized
INFO - 2021-12-17 14:18:16 --> Loader Class Initialized
INFO - 2021-12-17 14:18:16 --> Helper loaded: url_helper
INFO - 2021-12-17 14:18:16 --> Helper loaded: form_helper
INFO - 2021-12-17 14:18:16 --> Helper loaded: common_helper
INFO - 2021-12-17 14:18:16 --> Database Driver Class Initialized
DEBUG - 2021-12-17 14:18:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-17 14:18:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-17 14:18:16 --> Controller Class Initialized
INFO - 2021-12-17 14:18:16 --> Form Validation Class Initialized
DEBUG - 2021-12-17 14:18:16 --> Encrypt Class Initialized
DEBUG - 2021-12-17 14:18:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-17 14:18:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-17 14:18:16 --> Email Class Initialized
INFO - 2021-12-17 14:18:16 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-17 14:18:16 --> Calendar Class Initialized
INFO - 2021-12-17 14:18:16 --> Model "Login_model" initialized
ERROR - 2021-12-17 15:39:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-17 15:39:10 --> Config Class Initialized
INFO - 2021-12-17 15:39:10 --> Hooks Class Initialized
DEBUG - 2021-12-17 15:39:10 --> UTF-8 Support Enabled
INFO - 2021-12-17 15:39:10 --> Utf8 Class Initialized
INFO - 2021-12-17 15:39:10 --> URI Class Initialized
DEBUG - 2021-12-17 15:39:10 --> No URI present. Default controller set.
INFO - 2021-12-17 15:39:10 --> Router Class Initialized
INFO - 2021-12-17 15:39:10 --> Output Class Initialized
INFO - 2021-12-17 15:39:10 --> Security Class Initialized
DEBUG - 2021-12-17 15:39:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-17 15:39:10 --> Input Class Initialized
INFO - 2021-12-17 15:39:10 --> Language Class Initialized
INFO - 2021-12-17 15:39:10 --> Loader Class Initialized
INFO - 2021-12-17 15:39:10 --> Helper loaded: url_helper
INFO - 2021-12-17 15:39:10 --> Helper loaded: form_helper
INFO - 2021-12-17 15:39:10 --> Helper loaded: common_helper
INFO - 2021-12-17 15:39:10 --> Database Driver Class Initialized
DEBUG - 2021-12-17 15:39:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-17 15:39:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-17 15:39:10 --> Controller Class Initialized
INFO - 2021-12-17 15:39:10 --> Form Validation Class Initialized
DEBUG - 2021-12-17 15:39:10 --> Encrypt Class Initialized
DEBUG - 2021-12-17 15:39:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-17 15:39:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-17 15:39:10 --> Email Class Initialized
INFO - 2021-12-17 15:39:10 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-17 15:39:10 --> Calendar Class Initialized
INFO - 2021-12-17 15:39:10 --> Model "Login_model" initialized
INFO - 2021-12-17 15:39:10 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-17 15:39:10 --> Final output sent to browser
DEBUG - 2021-12-17 15:39:10 --> Total execution time: 0.0293
ERROR - 2021-12-17 18:07:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-17 18:07:29 --> Config Class Initialized
INFO - 2021-12-17 18:07:29 --> Hooks Class Initialized
DEBUG - 2021-12-17 18:07:29 --> UTF-8 Support Enabled
INFO - 2021-12-17 18:07:29 --> Utf8 Class Initialized
INFO - 2021-12-17 18:07:29 --> URI Class Initialized
INFO - 2021-12-17 18:07:29 --> Router Class Initialized
INFO - 2021-12-17 18:07:29 --> Output Class Initialized
INFO - 2021-12-17 18:07:29 --> Security Class Initialized
DEBUG - 2021-12-17 18:07:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-17 18:07:29 --> Input Class Initialized
INFO - 2021-12-17 18:07:29 --> Language Class Initialized
ERROR - 2021-12-17 18:07:29 --> 404 Page Not Found: Humanstxt/index
ERROR - 2021-12-17 18:07:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-17 18:07:30 --> Config Class Initialized
INFO - 2021-12-17 18:07:30 --> Hooks Class Initialized
DEBUG - 2021-12-17 18:07:30 --> UTF-8 Support Enabled
INFO - 2021-12-17 18:07:30 --> Utf8 Class Initialized
INFO - 2021-12-17 18:07:30 --> URI Class Initialized
INFO - 2021-12-17 18:07:30 --> Router Class Initialized
INFO - 2021-12-17 18:07:30 --> Output Class Initialized
INFO - 2021-12-17 18:07:30 --> Security Class Initialized
DEBUG - 2021-12-17 18:07:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-17 18:07:30 --> Input Class Initialized
INFO - 2021-12-17 18:07:30 --> Language Class Initialized
ERROR - 2021-12-17 18:07:30 --> 404 Page Not Found: Adstxt/index
ERROR - 2021-12-17 18:07:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-17 18:07:31 --> Config Class Initialized
INFO - 2021-12-17 18:07:31 --> Hooks Class Initialized
DEBUG - 2021-12-17 18:07:31 --> UTF-8 Support Enabled
INFO - 2021-12-17 18:07:31 --> Utf8 Class Initialized
INFO - 2021-12-17 18:07:31 --> URI Class Initialized
DEBUG - 2021-12-17 18:07:31 --> No URI present. Default controller set.
INFO - 2021-12-17 18:07:31 --> Router Class Initialized
INFO - 2021-12-17 18:07:31 --> Output Class Initialized
INFO - 2021-12-17 18:07:31 --> Security Class Initialized
DEBUG - 2021-12-17 18:07:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-17 18:07:31 --> Input Class Initialized
INFO - 2021-12-17 18:07:31 --> Language Class Initialized
INFO - 2021-12-17 18:07:31 --> Loader Class Initialized
INFO - 2021-12-17 18:07:31 --> Helper loaded: url_helper
INFO - 2021-12-17 18:07:31 --> Helper loaded: form_helper
INFO - 2021-12-17 18:07:31 --> Helper loaded: common_helper
INFO - 2021-12-17 18:07:31 --> Database Driver Class Initialized
DEBUG - 2021-12-17 18:07:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-17 18:07:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-17 18:07:31 --> Controller Class Initialized
INFO - 2021-12-17 18:07:31 --> Form Validation Class Initialized
DEBUG - 2021-12-17 18:07:31 --> Encrypt Class Initialized
DEBUG - 2021-12-17 18:07:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-17 18:07:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-17 18:07:31 --> Email Class Initialized
INFO - 2021-12-17 18:07:31 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-17 18:07:31 --> Calendar Class Initialized
INFO - 2021-12-17 18:07:31 --> Model "Login_model" initialized
INFO - 2021-12-17 18:07:31 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-17 18:07:31 --> Final output sent to browser
DEBUG - 2021-12-17 18:07:31 --> Total execution time: 0.0439
ERROR - 2021-12-17 21:49:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-17 21:49:06 --> Config Class Initialized
INFO - 2021-12-17 21:49:06 --> Hooks Class Initialized
DEBUG - 2021-12-17 21:49:06 --> UTF-8 Support Enabled
INFO - 2021-12-17 21:49:06 --> Utf8 Class Initialized
INFO - 2021-12-17 21:49:06 --> URI Class Initialized
DEBUG - 2021-12-17 21:49:06 --> No URI present. Default controller set.
INFO - 2021-12-17 21:49:06 --> Router Class Initialized
INFO - 2021-12-17 21:49:06 --> Output Class Initialized
INFO - 2021-12-17 21:49:06 --> Security Class Initialized
DEBUG - 2021-12-17 21:49:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-17 21:49:06 --> Input Class Initialized
INFO - 2021-12-17 21:49:06 --> Language Class Initialized
INFO - 2021-12-17 21:49:06 --> Loader Class Initialized
INFO - 2021-12-17 21:49:06 --> Helper loaded: url_helper
INFO - 2021-12-17 21:49:06 --> Helper loaded: form_helper
INFO - 2021-12-17 21:49:06 --> Helper loaded: common_helper
INFO - 2021-12-17 21:49:06 --> Database Driver Class Initialized
DEBUG - 2021-12-17 21:49:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-17 21:49:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-17 21:49:06 --> Controller Class Initialized
INFO - 2021-12-17 21:49:06 --> Form Validation Class Initialized
DEBUG - 2021-12-17 21:49:06 --> Encrypt Class Initialized
DEBUG - 2021-12-17 21:49:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-17 21:49:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-17 21:49:06 --> Email Class Initialized
INFO - 2021-12-17 21:49:06 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-17 21:49:06 --> Calendar Class Initialized
INFO - 2021-12-17 21:49:06 --> Model "Login_model" initialized
INFO - 2021-12-17 21:49:06 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-17 21:49:06 --> Final output sent to browser
DEBUG - 2021-12-17 21:49:06 --> Total execution time: 0.0243
ERROR - 2021-12-17 21:49:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-17 21:49:34 --> Config Class Initialized
INFO - 2021-12-17 21:49:34 --> Hooks Class Initialized
DEBUG - 2021-12-17 21:49:34 --> UTF-8 Support Enabled
INFO - 2021-12-17 21:49:34 --> Utf8 Class Initialized
INFO - 2021-12-17 21:49:34 --> URI Class Initialized
DEBUG - 2021-12-17 21:49:34 --> No URI present. Default controller set.
INFO - 2021-12-17 21:49:34 --> Router Class Initialized
INFO - 2021-12-17 21:49:34 --> Output Class Initialized
INFO - 2021-12-17 21:49:34 --> Security Class Initialized
DEBUG - 2021-12-17 21:49:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-17 21:49:34 --> Input Class Initialized
INFO - 2021-12-17 21:49:34 --> Language Class Initialized
INFO - 2021-12-17 21:49:34 --> Loader Class Initialized
INFO - 2021-12-17 21:49:34 --> Helper loaded: url_helper
INFO - 2021-12-17 21:49:34 --> Helper loaded: form_helper
INFO - 2021-12-17 21:49:34 --> Helper loaded: common_helper
INFO - 2021-12-17 21:49:34 --> Database Driver Class Initialized
DEBUG - 2021-12-17 21:49:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-17 21:49:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-17 21:49:34 --> Controller Class Initialized
INFO - 2021-12-17 21:49:34 --> Form Validation Class Initialized
DEBUG - 2021-12-17 21:49:34 --> Encrypt Class Initialized
DEBUG - 2021-12-17 21:49:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-17 21:49:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-17 21:49:34 --> Email Class Initialized
INFO - 2021-12-17 21:49:34 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-17 21:49:34 --> Calendar Class Initialized
INFO - 2021-12-17 21:49:34 --> Model "Login_model" initialized
INFO - 2021-12-17 21:49:34 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-17 21:49:34 --> Final output sent to browser
DEBUG - 2021-12-17 21:49:34 --> Total execution time: 0.5051
