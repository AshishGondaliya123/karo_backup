<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-08-17 03:30:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-17 03:30:17 --> Config Class Initialized
INFO - 2021-08-17 03:30:17 --> Hooks Class Initialized
DEBUG - 2021-08-17 03:30:17 --> UTF-8 Support Enabled
INFO - 2021-08-17 03:30:17 --> Utf8 Class Initialized
INFO - 2021-08-17 03:30:17 --> URI Class Initialized
DEBUG - 2021-08-17 03:30:17 --> No URI present. Default controller set.
INFO - 2021-08-17 03:30:17 --> Router Class Initialized
INFO - 2021-08-17 03:30:17 --> Output Class Initialized
INFO - 2021-08-17 03:30:17 --> Security Class Initialized
DEBUG - 2021-08-17 03:30:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-17 03:30:17 --> Input Class Initialized
INFO - 2021-08-17 03:30:17 --> Language Class Initialized
INFO - 2021-08-17 03:30:17 --> Loader Class Initialized
INFO - 2021-08-17 03:30:17 --> Helper loaded: url_helper
INFO - 2021-08-17 03:30:17 --> Helper loaded: form_helper
INFO - 2021-08-17 03:30:17 --> Helper loaded: common_helper
INFO - 2021-08-17 03:30:17 --> Database Driver Class Initialized
DEBUG - 2021-08-17 03:30:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-17 03:30:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-17 03:30:17 --> Controller Class Initialized
INFO - 2021-08-17 03:30:17 --> Form Validation Class Initialized
DEBUG - 2021-08-17 03:30:17 --> Encrypt Class Initialized
DEBUG - 2021-08-17 03:30:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-08-17 03:30:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-08-17 03:30:17 --> Email Class Initialized
INFO - 2021-08-17 03:30:17 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-08-17 03:30:17 --> Calendar Class Initialized
INFO - 2021-08-17 03:30:17 --> Model "Login_model" initialized
INFO - 2021-08-17 03:30:17 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-08-17 03:30:17 --> Final output sent to browser
DEBUG - 2021-08-17 03:30:17 --> Total execution time: 0.0527
ERROR - 2021-08-17 03:30:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-17 03:30:17 --> Config Class Initialized
INFO - 2021-08-17 03:30:17 --> Hooks Class Initialized
DEBUG - 2021-08-17 03:30:17 --> UTF-8 Support Enabled
INFO - 2021-08-17 03:30:17 --> Utf8 Class Initialized
INFO - 2021-08-17 03:30:17 --> URI Class Initialized
INFO - 2021-08-17 03:30:17 --> Router Class Initialized
INFO - 2021-08-17 03:30:17 --> Output Class Initialized
INFO - 2021-08-17 03:30:17 --> Security Class Initialized
DEBUG - 2021-08-17 03:30:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-17 03:30:17 --> Input Class Initialized
INFO - 2021-08-17 03:30:17 --> Language Class Initialized
ERROR - 2021-08-17 03:30:17 --> 404 Page Not Found: Blog/index
ERROR - 2021-08-17 03:30:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-17 03:30:17 --> Config Class Initialized
INFO - 2021-08-17 03:30:17 --> Hooks Class Initialized
DEBUG - 2021-08-17 03:30:17 --> UTF-8 Support Enabled
INFO - 2021-08-17 03:30:17 --> Utf8 Class Initialized
INFO - 2021-08-17 03:30:17 --> URI Class Initialized
INFO - 2021-08-17 03:30:17 --> Router Class Initialized
INFO - 2021-08-17 03:30:17 --> Output Class Initialized
INFO - 2021-08-17 03:30:17 --> Security Class Initialized
DEBUG - 2021-08-17 03:30:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-17 03:30:17 --> Input Class Initialized
INFO - 2021-08-17 03:30:17 --> Language Class Initialized
ERROR - 2021-08-17 03:30:17 --> 404 Page Not Found: Wp/index
ERROR - 2021-08-17 03:30:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-17 03:30:18 --> Config Class Initialized
INFO - 2021-08-17 03:30:18 --> Hooks Class Initialized
DEBUG - 2021-08-17 03:30:18 --> UTF-8 Support Enabled
INFO - 2021-08-17 03:30:18 --> Utf8 Class Initialized
INFO - 2021-08-17 03:30:18 --> URI Class Initialized
INFO - 2021-08-17 03:30:18 --> Router Class Initialized
INFO - 2021-08-17 03:30:18 --> Output Class Initialized
INFO - 2021-08-17 03:30:18 --> Security Class Initialized
DEBUG - 2021-08-17 03:30:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-17 03:30:18 --> Input Class Initialized
INFO - 2021-08-17 03:30:18 --> Language Class Initialized
ERROR - 2021-08-17 03:30:18 --> 404 Page Not Found: Wordpress/index
ERROR - 2021-08-17 03:30:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-17 03:30:18 --> Config Class Initialized
INFO - 2021-08-17 03:30:18 --> Hooks Class Initialized
DEBUG - 2021-08-17 03:30:18 --> UTF-8 Support Enabled
INFO - 2021-08-17 03:30:18 --> Utf8 Class Initialized
INFO - 2021-08-17 03:30:18 --> URI Class Initialized
INFO - 2021-08-17 03:30:18 --> Router Class Initialized
INFO - 2021-08-17 03:30:18 --> Output Class Initialized
INFO - 2021-08-17 03:30:18 --> Security Class Initialized
DEBUG - 2021-08-17 03:30:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-17 03:30:18 --> Input Class Initialized
INFO - 2021-08-17 03:30:18 --> Language Class Initialized
ERROR - 2021-08-17 03:30:18 --> 404 Page Not Found: New/index
ERROR - 2021-08-17 03:30:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-17 03:30:18 --> Config Class Initialized
INFO - 2021-08-17 03:30:18 --> Hooks Class Initialized
DEBUG - 2021-08-17 03:30:18 --> UTF-8 Support Enabled
INFO - 2021-08-17 03:30:18 --> Utf8 Class Initialized
INFO - 2021-08-17 03:30:18 --> URI Class Initialized
INFO - 2021-08-17 03:30:18 --> Router Class Initialized
INFO - 2021-08-17 03:30:18 --> Output Class Initialized
INFO - 2021-08-17 03:30:18 --> Security Class Initialized
DEBUG - 2021-08-17 03:30:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-17 03:30:18 --> Input Class Initialized
INFO - 2021-08-17 03:30:18 --> Language Class Initialized
ERROR - 2021-08-17 03:30:18 --> 404 Page Not Found: Old/index
ERROR - 2021-08-17 03:30:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-17 03:30:19 --> Config Class Initialized
INFO - 2021-08-17 03:30:19 --> Hooks Class Initialized
DEBUG - 2021-08-17 03:30:19 --> UTF-8 Support Enabled
INFO - 2021-08-17 03:30:19 --> Utf8 Class Initialized
INFO - 2021-08-17 03:30:19 --> URI Class Initialized
INFO - 2021-08-17 03:30:19 --> Router Class Initialized
INFO - 2021-08-17 03:30:19 --> Output Class Initialized
INFO - 2021-08-17 03:30:19 --> Security Class Initialized
DEBUG - 2021-08-17 03:30:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-17 03:30:19 --> Input Class Initialized
INFO - 2021-08-17 03:30:19 --> Language Class Initialized
ERROR - 2021-08-17 03:30:19 --> 404 Page Not Found: Test/index
ERROR - 2021-08-17 03:30:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-17 03:30:19 --> Config Class Initialized
INFO - 2021-08-17 03:30:19 --> Hooks Class Initialized
DEBUG - 2021-08-17 03:30:19 --> UTF-8 Support Enabled
INFO - 2021-08-17 03:30:19 --> Utf8 Class Initialized
INFO - 2021-08-17 03:30:19 --> URI Class Initialized
INFO - 2021-08-17 03:30:19 --> Router Class Initialized
INFO - 2021-08-17 03:30:19 --> Output Class Initialized
INFO - 2021-08-17 03:30:19 --> Security Class Initialized
DEBUG - 2021-08-17 03:30:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-17 03:30:19 --> Input Class Initialized
INFO - 2021-08-17 03:30:19 --> Language Class Initialized
ERROR - 2021-08-17 03:30:19 --> 404 Page Not Found: Main/index
ERROR - 2021-08-17 03:30:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-17 03:30:19 --> Config Class Initialized
INFO - 2021-08-17 03:30:19 --> Hooks Class Initialized
DEBUG - 2021-08-17 03:30:19 --> UTF-8 Support Enabled
INFO - 2021-08-17 03:30:19 --> Utf8 Class Initialized
INFO - 2021-08-17 03:30:19 --> URI Class Initialized
INFO - 2021-08-17 03:30:19 --> Router Class Initialized
INFO - 2021-08-17 03:30:19 --> Output Class Initialized
INFO - 2021-08-17 03:30:19 --> Security Class Initialized
DEBUG - 2021-08-17 03:30:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-17 03:30:19 --> Input Class Initialized
INFO - 2021-08-17 03:30:19 --> Language Class Initialized
ERROR - 2021-08-17 03:30:19 --> 404 Page Not Found: Site/index
ERROR - 2021-08-17 03:30:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-17 03:30:19 --> Config Class Initialized
INFO - 2021-08-17 03:30:19 --> Hooks Class Initialized
DEBUG - 2021-08-17 03:30:19 --> UTF-8 Support Enabled
INFO - 2021-08-17 03:30:19 --> Utf8 Class Initialized
INFO - 2021-08-17 03:30:19 --> URI Class Initialized
INFO - 2021-08-17 03:30:19 --> Router Class Initialized
INFO - 2021-08-17 03:30:19 --> Output Class Initialized
INFO - 2021-08-17 03:30:19 --> Security Class Initialized
DEBUG - 2021-08-17 03:30:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-17 03:30:19 --> Input Class Initialized
INFO - 2021-08-17 03:30:19 --> Language Class Initialized
ERROR - 2021-08-17 03:30:19 --> 404 Page Not Found: Backup/index
ERROR - 2021-08-17 03:30:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-17 03:30:20 --> Config Class Initialized
INFO - 2021-08-17 03:30:20 --> Hooks Class Initialized
DEBUG - 2021-08-17 03:30:20 --> UTF-8 Support Enabled
INFO - 2021-08-17 03:30:20 --> Utf8 Class Initialized
INFO - 2021-08-17 03:30:20 --> URI Class Initialized
INFO - 2021-08-17 03:30:20 --> Router Class Initialized
INFO - 2021-08-17 03:30:20 --> Output Class Initialized
INFO - 2021-08-17 03:30:20 --> Security Class Initialized
DEBUG - 2021-08-17 03:30:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-17 03:30:20 --> Input Class Initialized
INFO - 2021-08-17 03:30:20 --> Language Class Initialized
ERROR - 2021-08-17 03:30:20 --> 404 Page Not Found: Demo/index
ERROR - 2021-08-17 03:30:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-17 03:30:20 --> Config Class Initialized
INFO - 2021-08-17 03:30:20 --> Hooks Class Initialized
DEBUG - 2021-08-17 03:30:20 --> UTF-8 Support Enabled
INFO - 2021-08-17 03:30:20 --> Utf8 Class Initialized
INFO - 2021-08-17 03:30:20 --> URI Class Initialized
INFO - 2021-08-17 03:30:20 --> Router Class Initialized
INFO - 2021-08-17 03:30:20 --> Output Class Initialized
INFO - 2021-08-17 03:30:20 --> Security Class Initialized
DEBUG - 2021-08-17 03:30:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-17 03:30:20 --> Input Class Initialized
INFO - 2021-08-17 03:30:20 --> Language Class Initialized
ERROR - 2021-08-17 03:30:20 --> 404 Page Not Found: Home/index
ERROR - 2021-08-17 03:30:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-17 03:30:21 --> Config Class Initialized
INFO - 2021-08-17 03:30:21 --> Hooks Class Initialized
DEBUG - 2021-08-17 03:30:21 --> UTF-8 Support Enabled
INFO - 2021-08-17 03:30:21 --> Utf8 Class Initialized
INFO - 2021-08-17 03:30:21 --> URI Class Initialized
INFO - 2021-08-17 03:30:21 --> Router Class Initialized
INFO - 2021-08-17 03:30:21 --> Output Class Initialized
INFO - 2021-08-17 03:30:21 --> Security Class Initialized
DEBUG - 2021-08-17 03:30:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-17 03:30:21 --> Input Class Initialized
INFO - 2021-08-17 03:30:21 --> Language Class Initialized
ERROR - 2021-08-17 03:30:21 --> 404 Page Not Found: Tmp/index
ERROR - 2021-08-17 03:30:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-17 03:30:21 --> Config Class Initialized
INFO - 2021-08-17 03:30:21 --> Hooks Class Initialized
DEBUG - 2021-08-17 03:30:21 --> UTF-8 Support Enabled
INFO - 2021-08-17 03:30:21 --> Utf8 Class Initialized
INFO - 2021-08-17 03:30:21 --> URI Class Initialized
INFO - 2021-08-17 03:30:21 --> Router Class Initialized
INFO - 2021-08-17 03:30:21 --> Output Class Initialized
INFO - 2021-08-17 03:30:21 --> Security Class Initialized
DEBUG - 2021-08-17 03:30:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-17 03:30:21 --> Input Class Initialized
INFO - 2021-08-17 03:30:21 --> Language Class Initialized
ERROR - 2021-08-17 03:30:21 --> 404 Page Not Found: Cms/index
ERROR - 2021-08-17 03:30:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-17 03:30:21 --> Config Class Initialized
INFO - 2021-08-17 03:30:21 --> Hooks Class Initialized
DEBUG - 2021-08-17 03:30:21 --> UTF-8 Support Enabled
INFO - 2021-08-17 03:30:21 --> Utf8 Class Initialized
INFO - 2021-08-17 03:30:21 --> URI Class Initialized
INFO - 2021-08-17 03:30:21 --> Router Class Initialized
INFO - 2021-08-17 03:30:21 --> Output Class Initialized
INFO - 2021-08-17 03:30:21 --> Security Class Initialized
DEBUG - 2021-08-17 03:30:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-17 03:30:21 --> Input Class Initialized
INFO - 2021-08-17 03:30:21 --> Language Class Initialized
ERROR - 2021-08-17 03:30:21 --> 404 Page Not Found: Dev/index
ERROR - 2021-08-17 03:30:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-17 03:30:22 --> Config Class Initialized
INFO - 2021-08-17 03:30:22 --> Hooks Class Initialized
DEBUG - 2021-08-17 03:30:22 --> UTF-8 Support Enabled
INFO - 2021-08-17 03:30:22 --> Utf8 Class Initialized
INFO - 2021-08-17 03:30:22 --> URI Class Initialized
INFO - 2021-08-17 03:30:22 --> Router Class Initialized
INFO - 2021-08-17 03:30:22 --> Output Class Initialized
INFO - 2021-08-17 03:30:22 --> Security Class Initialized
DEBUG - 2021-08-17 03:30:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-17 03:30:22 --> Input Class Initialized
INFO - 2021-08-17 03:30:22 --> Language Class Initialized
ERROR - 2021-08-17 03:30:22 --> 404 Page Not Found: Old-wp/index
ERROR - 2021-08-17 03:30:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-17 03:30:22 --> Config Class Initialized
INFO - 2021-08-17 03:30:22 --> Hooks Class Initialized
DEBUG - 2021-08-17 03:30:22 --> UTF-8 Support Enabled
INFO - 2021-08-17 03:30:22 --> Utf8 Class Initialized
INFO - 2021-08-17 03:30:22 --> URI Class Initialized
INFO - 2021-08-17 03:30:22 --> Router Class Initialized
INFO - 2021-08-17 03:30:22 --> Output Class Initialized
INFO - 2021-08-17 03:30:22 --> Security Class Initialized
DEBUG - 2021-08-17 03:30:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-17 03:30:22 --> Input Class Initialized
INFO - 2021-08-17 03:30:22 --> Language Class Initialized
ERROR - 2021-08-17 03:30:22 --> 404 Page Not Found: Web/index
ERROR - 2021-08-17 03:30:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-17 03:30:22 --> Config Class Initialized
INFO - 2021-08-17 03:30:22 --> Hooks Class Initialized
DEBUG - 2021-08-17 03:30:22 --> UTF-8 Support Enabled
INFO - 2021-08-17 03:30:22 --> Utf8 Class Initialized
INFO - 2021-08-17 03:30:22 --> URI Class Initialized
INFO - 2021-08-17 03:30:22 --> Router Class Initialized
INFO - 2021-08-17 03:30:22 --> Output Class Initialized
INFO - 2021-08-17 03:30:22 --> Security Class Initialized
DEBUG - 2021-08-17 03:30:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-17 03:30:22 --> Input Class Initialized
INFO - 2021-08-17 03:30:22 --> Language Class Initialized
ERROR - 2021-08-17 03:30:22 --> 404 Page Not Found: Old-site/index
ERROR - 2021-08-17 03:30:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-17 03:30:23 --> Config Class Initialized
INFO - 2021-08-17 03:30:23 --> Hooks Class Initialized
DEBUG - 2021-08-17 03:30:23 --> UTF-8 Support Enabled
INFO - 2021-08-17 03:30:23 --> Utf8 Class Initialized
INFO - 2021-08-17 03:30:23 --> URI Class Initialized
INFO - 2021-08-17 03:30:23 --> Router Class Initialized
INFO - 2021-08-17 03:30:23 --> Output Class Initialized
INFO - 2021-08-17 03:30:23 --> Security Class Initialized
DEBUG - 2021-08-17 03:30:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-17 03:30:23 --> Input Class Initialized
INFO - 2021-08-17 03:30:23 --> Language Class Initialized
ERROR - 2021-08-17 03:30:23 --> 404 Page Not Found: Temp/index
ERROR - 2021-08-17 03:30:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-17 03:30:23 --> Config Class Initialized
INFO - 2021-08-17 03:30:23 --> Hooks Class Initialized
DEBUG - 2021-08-17 03:30:23 --> UTF-8 Support Enabled
INFO - 2021-08-17 03:30:23 --> Utf8 Class Initialized
INFO - 2021-08-17 03:30:23 --> URI Class Initialized
INFO - 2021-08-17 03:30:23 --> Router Class Initialized
INFO - 2021-08-17 03:30:23 --> Output Class Initialized
INFO - 2021-08-17 03:30:23 --> Security Class Initialized
DEBUG - 2021-08-17 03:30:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-17 03:30:23 --> Input Class Initialized
INFO - 2021-08-17 03:30:23 --> Language Class Initialized
ERROR - 2021-08-17 03:30:23 --> 404 Page Not Found: 2018/index
ERROR - 2021-08-17 03:30:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-17 03:30:23 --> Config Class Initialized
INFO - 2021-08-17 03:30:23 --> Hooks Class Initialized
DEBUG - 2021-08-17 03:30:23 --> UTF-8 Support Enabled
INFO - 2021-08-17 03:30:23 --> Utf8 Class Initialized
INFO - 2021-08-17 03:30:23 --> URI Class Initialized
INFO - 2021-08-17 03:30:23 --> Router Class Initialized
INFO - 2021-08-17 03:30:23 --> Output Class Initialized
INFO - 2021-08-17 03:30:23 --> Security Class Initialized
DEBUG - 2021-08-17 03:30:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-17 03:30:23 --> Input Class Initialized
INFO - 2021-08-17 03:30:23 --> Language Class Initialized
ERROR - 2021-08-17 03:30:23 --> 404 Page Not Found: 2019/index
ERROR - 2021-08-17 03:30:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-17 03:30:24 --> Config Class Initialized
INFO - 2021-08-17 03:30:24 --> Hooks Class Initialized
DEBUG - 2021-08-17 03:30:24 --> UTF-8 Support Enabled
INFO - 2021-08-17 03:30:24 --> Utf8 Class Initialized
INFO - 2021-08-17 03:30:24 --> URI Class Initialized
INFO - 2021-08-17 03:30:24 --> Router Class Initialized
INFO - 2021-08-17 03:30:24 --> Output Class Initialized
INFO - 2021-08-17 03:30:24 --> Security Class Initialized
DEBUG - 2021-08-17 03:30:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-17 03:30:24 --> Input Class Initialized
INFO - 2021-08-17 03:30:24 --> Language Class Initialized
ERROR - 2021-08-17 03:30:24 --> 404 Page Not Found: Bk/index
ERROR - 2021-08-17 03:30:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-17 03:30:24 --> Config Class Initialized
INFO - 2021-08-17 03:30:24 --> Hooks Class Initialized
DEBUG - 2021-08-17 03:30:24 --> UTF-8 Support Enabled
INFO - 2021-08-17 03:30:24 --> Utf8 Class Initialized
INFO - 2021-08-17 03:30:24 --> URI Class Initialized
INFO - 2021-08-17 03:30:24 --> Router Class Initialized
INFO - 2021-08-17 03:30:24 --> Output Class Initialized
INFO - 2021-08-17 03:30:24 --> Security Class Initialized
DEBUG - 2021-08-17 03:30:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-17 03:30:24 --> Input Class Initialized
INFO - 2021-08-17 03:30:24 --> Language Class Initialized
ERROR - 2021-08-17 03:30:24 --> 404 Page Not Found: Wp1/index
ERROR - 2021-08-17 03:30:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-17 03:30:24 --> Config Class Initialized
INFO - 2021-08-17 03:30:24 --> Hooks Class Initialized
DEBUG - 2021-08-17 03:30:24 --> UTF-8 Support Enabled
INFO - 2021-08-17 03:30:24 --> Utf8 Class Initialized
INFO - 2021-08-17 03:30:24 --> URI Class Initialized
INFO - 2021-08-17 03:30:24 --> Router Class Initialized
INFO - 2021-08-17 03:30:24 --> Output Class Initialized
INFO - 2021-08-17 03:30:24 --> Security Class Initialized
DEBUG - 2021-08-17 03:30:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-17 03:30:24 --> Input Class Initialized
INFO - 2021-08-17 03:30:24 --> Language Class Initialized
ERROR - 2021-08-17 03:30:24 --> 404 Page Not Found: Wp2/index
ERROR - 2021-08-17 03:30:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-17 03:30:24 --> Config Class Initialized
INFO - 2021-08-17 03:30:24 --> Hooks Class Initialized
DEBUG - 2021-08-17 03:30:24 --> UTF-8 Support Enabled
INFO - 2021-08-17 03:30:24 --> Utf8 Class Initialized
INFO - 2021-08-17 03:30:24 --> URI Class Initialized
INFO - 2021-08-17 03:30:24 --> Router Class Initialized
INFO - 2021-08-17 03:30:24 --> Output Class Initialized
INFO - 2021-08-17 03:30:24 --> Security Class Initialized
DEBUG - 2021-08-17 03:30:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-17 03:30:24 --> Input Class Initialized
INFO - 2021-08-17 03:30:24 --> Language Class Initialized
ERROR - 2021-08-17 03:30:24 --> 404 Page Not Found: V1/index
ERROR - 2021-08-17 03:30:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-17 03:30:25 --> Config Class Initialized
INFO - 2021-08-17 03:30:25 --> Hooks Class Initialized
DEBUG - 2021-08-17 03:30:25 --> UTF-8 Support Enabled
INFO - 2021-08-17 03:30:25 --> Utf8 Class Initialized
INFO - 2021-08-17 03:30:25 --> URI Class Initialized
INFO - 2021-08-17 03:30:25 --> Router Class Initialized
INFO - 2021-08-17 03:30:25 --> Output Class Initialized
INFO - 2021-08-17 03:30:25 --> Security Class Initialized
DEBUG - 2021-08-17 03:30:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-17 03:30:25 --> Input Class Initialized
INFO - 2021-08-17 03:30:25 --> Language Class Initialized
ERROR - 2021-08-17 03:30:25 --> 404 Page Not Found: V2/index
ERROR - 2021-08-17 03:30:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-17 03:30:25 --> Config Class Initialized
INFO - 2021-08-17 03:30:25 --> Hooks Class Initialized
DEBUG - 2021-08-17 03:30:25 --> UTF-8 Support Enabled
INFO - 2021-08-17 03:30:25 --> Utf8 Class Initialized
INFO - 2021-08-17 03:30:25 --> URI Class Initialized
INFO - 2021-08-17 03:30:25 --> Router Class Initialized
INFO - 2021-08-17 03:30:25 --> Output Class Initialized
INFO - 2021-08-17 03:30:25 --> Security Class Initialized
DEBUG - 2021-08-17 03:30:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-17 03:30:25 --> Input Class Initialized
INFO - 2021-08-17 03:30:25 --> Language Class Initialized
ERROR - 2021-08-17 03:30:25 --> 404 Page Not Found: Bak/index
ERROR - 2021-08-17 03:30:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-17 03:30:25 --> Config Class Initialized
INFO - 2021-08-17 03:30:25 --> Hooks Class Initialized
DEBUG - 2021-08-17 03:30:25 --> UTF-8 Support Enabled
INFO - 2021-08-17 03:30:25 --> Utf8 Class Initialized
INFO - 2021-08-17 03:30:25 --> URI Class Initialized
INFO - 2021-08-17 03:30:25 --> Router Class Initialized
INFO - 2021-08-17 03:30:25 --> Output Class Initialized
INFO - 2021-08-17 03:30:25 --> Security Class Initialized
DEBUG - 2021-08-17 03:30:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-17 03:30:25 --> Input Class Initialized
INFO - 2021-08-17 03:30:25 --> Language Class Initialized
ERROR - 2021-08-17 03:30:25 --> 404 Page Not Found: Install/index
ERROR - 2021-08-17 03:30:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-17 03:30:26 --> Config Class Initialized
INFO - 2021-08-17 03:30:26 --> Hooks Class Initialized
DEBUG - 2021-08-17 03:30:26 --> UTF-8 Support Enabled
INFO - 2021-08-17 03:30:26 --> Utf8 Class Initialized
INFO - 2021-08-17 03:30:26 --> URI Class Initialized
INFO - 2021-08-17 03:30:26 --> Router Class Initialized
INFO - 2021-08-17 03:30:26 --> Output Class Initialized
INFO - 2021-08-17 03:30:26 --> Security Class Initialized
DEBUG - 2021-08-17 03:30:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-17 03:30:26 --> Input Class Initialized
INFO - 2021-08-17 03:30:26 --> Language Class Initialized
ERROR - 2021-08-17 03:30:26 --> 404 Page Not Found: 2020/index
ERROR - 2021-08-17 03:30:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-17 03:30:26 --> Config Class Initialized
INFO - 2021-08-17 03:30:26 --> Hooks Class Initialized
DEBUG - 2021-08-17 03:30:26 --> UTF-8 Support Enabled
INFO - 2021-08-17 03:30:26 --> Utf8 Class Initialized
INFO - 2021-08-17 03:30:26 --> URI Class Initialized
INFO - 2021-08-17 03:30:26 --> Router Class Initialized
INFO - 2021-08-17 03:30:26 --> Output Class Initialized
INFO - 2021-08-17 03:30:26 --> Security Class Initialized
DEBUG - 2021-08-17 03:30:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-17 03:30:26 --> Input Class Initialized
INFO - 2021-08-17 03:30:26 --> Language Class Initialized
ERROR - 2021-08-17 03:30:26 --> 404 Page Not Found: New-site/index
