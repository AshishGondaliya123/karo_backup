<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-03-30 00:42:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 00:42:53 --> Config Class Initialized
INFO - 2022-03-30 00:42:53 --> Hooks Class Initialized
DEBUG - 2022-03-30 00:42:53 --> UTF-8 Support Enabled
INFO - 2022-03-30 00:42:53 --> Utf8 Class Initialized
INFO - 2022-03-30 00:42:53 --> URI Class Initialized
INFO - 2022-03-30 00:42:53 --> Router Class Initialized
INFO - 2022-03-30 00:42:53 --> Output Class Initialized
INFO - 2022-03-30 00:42:53 --> Security Class Initialized
DEBUG - 2022-03-30 00:42:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 00:42:53 --> Input Class Initialized
INFO - 2022-03-30 00:42:53 --> Language Class Initialized
INFO - 2022-03-30 00:42:53 --> Loader Class Initialized
INFO - 2022-03-30 00:42:53 --> Helper loaded: url_helper
INFO - 2022-03-30 00:42:53 --> Helper loaded: form_helper
INFO - 2022-03-30 00:42:53 --> Helper loaded: common_helper
INFO - 2022-03-30 00:42:53 --> Database Driver Class Initialized
DEBUG - 2022-03-30 00:42:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 00:42:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 00:42:53 --> Controller Class Initialized
INFO - 2022-03-30 00:42:53 --> Form Validation Class Initialized
DEBUG - 2022-03-30 00:42:53 --> Encrypt Class Initialized
DEBUG - 2022-03-30 00:42:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-30 00:42:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-30 00:42:53 --> Email Class Initialized
INFO - 2022-03-30 00:42:53 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-30 00:42:53 --> Calendar Class Initialized
INFO - 2022-03-30 00:42:53 --> Model "Login_model" initialized
INFO - 2022-03-30 00:42:53 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-30 00:42:53 --> Final output sent to browser
DEBUG - 2022-03-30 00:42:53 --> Total execution time: 0.0654
ERROR - 2022-03-30 00:43:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 00:43:06 --> Config Class Initialized
INFO - 2022-03-30 00:43:06 --> Hooks Class Initialized
DEBUG - 2022-03-30 00:43:06 --> UTF-8 Support Enabled
INFO - 2022-03-30 00:43:06 --> Utf8 Class Initialized
INFO - 2022-03-30 00:43:06 --> URI Class Initialized
INFO - 2022-03-30 00:43:06 --> Router Class Initialized
INFO - 2022-03-30 00:43:06 --> Output Class Initialized
INFO - 2022-03-30 00:43:06 --> Security Class Initialized
DEBUG - 2022-03-30 00:43:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 00:43:06 --> Input Class Initialized
INFO - 2022-03-30 00:43:06 --> Language Class Initialized
INFO - 2022-03-30 00:43:06 --> Loader Class Initialized
INFO - 2022-03-30 00:43:06 --> Helper loaded: url_helper
INFO - 2022-03-30 00:43:06 --> Helper loaded: form_helper
INFO - 2022-03-30 00:43:06 --> Helper loaded: common_helper
INFO - 2022-03-30 00:43:06 --> Database Driver Class Initialized
DEBUG - 2022-03-30 00:43:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 00:43:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 00:43:06 --> Controller Class Initialized
INFO - 2022-03-30 00:43:06 --> Form Validation Class Initialized
DEBUG - 2022-03-30 00:43:06 --> Encrypt Class Initialized
DEBUG - 2022-03-30 00:43:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-30 00:43:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-30 00:43:06 --> Email Class Initialized
INFO - 2022-03-30 00:43:06 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-30 00:43:06 --> Calendar Class Initialized
INFO - 2022-03-30 00:43:06 --> Model "Login_model" initialized
INFO - 2022-03-30 00:43:06 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-03-30 00:43:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 00:43:06 --> Config Class Initialized
INFO - 2022-03-30 00:43:06 --> Hooks Class Initialized
DEBUG - 2022-03-30 00:43:06 --> UTF-8 Support Enabled
INFO - 2022-03-30 00:43:06 --> Utf8 Class Initialized
INFO - 2022-03-30 00:43:06 --> URI Class Initialized
INFO - 2022-03-30 00:43:06 --> Router Class Initialized
INFO - 2022-03-30 00:43:06 --> Output Class Initialized
INFO - 2022-03-30 00:43:06 --> Security Class Initialized
DEBUG - 2022-03-30 00:43:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 00:43:06 --> Input Class Initialized
INFO - 2022-03-30 00:43:06 --> Language Class Initialized
INFO - 2022-03-30 00:43:06 --> Loader Class Initialized
INFO - 2022-03-30 00:43:06 --> Helper loaded: url_helper
INFO - 2022-03-30 00:43:06 --> Helper loaded: form_helper
INFO - 2022-03-30 00:43:06 --> Helper loaded: common_helper
INFO - 2022-03-30 00:43:06 --> Database Driver Class Initialized
DEBUG - 2022-03-30 00:43:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 00:43:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 00:43:06 --> Controller Class Initialized
INFO - 2022-03-30 00:43:06 --> Form Validation Class Initialized
DEBUG - 2022-03-30 00:43:06 --> Encrypt Class Initialized
INFO - 2022-03-30 00:43:06 --> Model "Login_model" initialized
INFO - 2022-03-30 00:43:06 --> Model "Dashboard_model" initialized
INFO - 2022-03-30 00:43:06 --> Model "Case_model" initialized
INFO - 2022-03-30 00:43:06 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 00:43:06 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2022-03-30 00:43:06 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 00:43:06 --> Final output sent to browser
DEBUG - 2022-03-30 00:43:06 --> Total execution time: 0.2604
ERROR - 2022-03-30 00:43:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 00:43:07 --> Config Class Initialized
INFO - 2022-03-30 00:43:07 --> Hooks Class Initialized
DEBUG - 2022-03-30 00:43:07 --> UTF-8 Support Enabled
INFO - 2022-03-30 00:43:07 --> Utf8 Class Initialized
INFO - 2022-03-30 00:43:07 --> URI Class Initialized
INFO - 2022-03-30 00:43:07 --> Router Class Initialized
INFO - 2022-03-30 00:43:07 --> Output Class Initialized
INFO - 2022-03-30 00:43:07 --> Security Class Initialized
DEBUG - 2022-03-30 00:43:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 00:43:07 --> Input Class Initialized
INFO - 2022-03-30 00:43:07 --> Language Class Initialized
INFO - 2022-03-30 00:43:07 --> Loader Class Initialized
INFO - 2022-03-30 00:43:07 --> Helper loaded: url_helper
INFO - 2022-03-30 00:43:07 --> Helper loaded: form_helper
INFO - 2022-03-30 00:43:07 --> Helper loaded: common_helper
INFO - 2022-03-30 00:43:07 --> Database Driver Class Initialized
DEBUG - 2022-03-30 00:43:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 00:43:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 00:43:07 --> Controller Class Initialized
INFO - 2022-03-30 00:43:07 --> Form Validation Class Initialized
DEBUG - 2022-03-30 00:43:07 --> Encrypt Class Initialized
DEBUG - 2022-03-30 00:43:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-30 00:43:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-30 00:43:07 --> Email Class Initialized
INFO - 2022-03-30 00:43:07 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-30 00:43:07 --> Calendar Class Initialized
INFO - 2022-03-30 00:43:07 --> Model "Login_model" initialized
INFO - 2022-03-30 00:43:07 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-03-30 00:43:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 00:43:07 --> Config Class Initialized
INFO - 2022-03-30 00:43:07 --> Hooks Class Initialized
DEBUG - 2022-03-30 00:43:07 --> UTF-8 Support Enabled
INFO - 2022-03-30 00:43:07 --> Utf8 Class Initialized
INFO - 2022-03-30 00:43:07 --> URI Class Initialized
INFO - 2022-03-30 00:43:07 --> Router Class Initialized
INFO - 2022-03-30 00:43:07 --> Output Class Initialized
INFO - 2022-03-30 00:43:07 --> Security Class Initialized
DEBUG - 2022-03-30 00:43:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 00:43:07 --> Input Class Initialized
INFO - 2022-03-30 00:43:07 --> Language Class Initialized
INFO - 2022-03-30 00:43:07 --> Loader Class Initialized
INFO - 2022-03-30 00:43:07 --> Helper loaded: url_helper
INFO - 2022-03-30 00:43:07 --> Helper loaded: form_helper
INFO - 2022-03-30 00:43:07 --> Helper loaded: common_helper
INFO - 2022-03-30 00:43:07 --> Database Driver Class Initialized
DEBUG - 2022-03-30 00:43:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 00:43:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 00:43:07 --> Controller Class Initialized
INFO - 2022-03-30 00:43:07 --> Form Validation Class Initialized
DEBUG - 2022-03-30 00:43:07 --> Encrypt Class Initialized
INFO - 2022-03-30 00:43:07 --> Model "Login_model" initialized
INFO - 2022-03-30 00:43:07 --> Model "Dashboard_model" initialized
INFO - 2022-03-30 00:43:07 --> Model "Case_model" initialized
INFO - 2022-03-30 00:43:07 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 00:43:07 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2022-03-30 00:43:07 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 00:43:07 --> Final output sent to browser
DEBUG - 2022-03-30 00:43:07 --> Total execution time: 0.2053
ERROR - 2022-03-30 00:43:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 00:43:16 --> Config Class Initialized
INFO - 2022-03-30 00:43:16 --> Hooks Class Initialized
DEBUG - 2022-03-30 00:43:16 --> UTF-8 Support Enabled
INFO - 2022-03-30 00:43:16 --> Utf8 Class Initialized
INFO - 2022-03-30 00:43:16 --> URI Class Initialized
INFO - 2022-03-30 00:43:16 --> Router Class Initialized
INFO - 2022-03-30 00:43:16 --> Output Class Initialized
INFO - 2022-03-30 00:43:16 --> Security Class Initialized
DEBUG - 2022-03-30 00:43:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 00:43:16 --> Input Class Initialized
INFO - 2022-03-30 00:43:16 --> Language Class Initialized
INFO - 2022-03-30 00:43:16 --> Loader Class Initialized
INFO - 2022-03-30 00:43:16 --> Helper loaded: url_helper
INFO - 2022-03-30 00:43:16 --> Helper loaded: form_helper
INFO - 2022-03-30 00:43:16 --> Helper loaded: common_helper
INFO - 2022-03-30 00:43:16 --> Database Driver Class Initialized
DEBUG - 2022-03-30 00:43:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 00:43:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 00:43:16 --> Controller Class Initialized
INFO - 2022-03-30 00:43:16 --> Form Validation Class Initialized
DEBUG - 2022-03-30 00:43:16 --> Encrypt Class Initialized
INFO - 2022-03-30 00:43:16 --> Model "Patient_model" initialized
INFO - 2022-03-30 00:43:16 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 00:43:16 --> Model "Referredby_model" initialized
INFO - 2022-03-30 00:43:16 --> Model "Prefix_master" initialized
INFO - 2022-03-30 00:43:16 --> Model "Hospital_model" initialized
INFO - 2022-03-30 00:43:16 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 00:43:16 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-30 00:43:16 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 00:43:16 --> Final output sent to browser
DEBUG - 2022-03-30 00:43:16 --> Total execution time: 0.1154
ERROR - 2022-03-30 00:43:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 00:43:45 --> Config Class Initialized
INFO - 2022-03-30 00:43:45 --> Hooks Class Initialized
DEBUG - 2022-03-30 00:43:45 --> UTF-8 Support Enabled
INFO - 2022-03-30 00:43:45 --> Utf8 Class Initialized
INFO - 2022-03-30 00:43:45 --> URI Class Initialized
INFO - 2022-03-30 00:43:45 --> Router Class Initialized
INFO - 2022-03-30 00:43:45 --> Output Class Initialized
INFO - 2022-03-30 00:43:45 --> Security Class Initialized
DEBUG - 2022-03-30 00:43:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 00:43:45 --> Input Class Initialized
INFO - 2022-03-30 00:43:45 --> Language Class Initialized
INFO - 2022-03-30 00:43:45 --> Loader Class Initialized
INFO - 2022-03-30 00:43:45 --> Helper loaded: url_helper
INFO - 2022-03-30 00:43:45 --> Helper loaded: form_helper
INFO - 2022-03-30 00:43:45 --> Helper loaded: common_helper
INFO - 2022-03-30 00:43:45 --> Database Driver Class Initialized
DEBUG - 2022-03-30 00:43:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 00:43:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 00:43:45 --> Controller Class Initialized
INFO - 2022-03-30 00:43:45 --> Form Validation Class Initialized
DEBUG - 2022-03-30 00:43:45 --> Encrypt Class Initialized
INFO - 2022-03-30 00:43:45 --> Model "Patient_model" initialized
INFO - 2022-03-30 00:43:45 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 00:43:45 --> Model "Referredby_model" initialized
INFO - 2022-03-30 00:43:45 --> Model "Prefix_master" initialized
INFO - 2022-03-30 00:43:45 --> Model "Hospital_model" initialized
INFO - 2022-03-30 00:43:45 --> Upload Class Initialized
INFO - 2022-03-30 00:43:45 --> Final output sent to browser
DEBUG - 2022-03-30 00:43:45 --> Total execution time: 0.0160
ERROR - 2022-03-30 00:48:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 00:48:19 --> Config Class Initialized
INFO - 2022-03-30 00:48:19 --> Hooks Class Initialized
DEBUG - 2022-03-30 00:48:19 --> UTF-8 Support Enabled
INFO - 2022-03-30 00:48:19 --> Utf8 Class Initialized
INFO - 2022-03-30 00:48:19 --> URI Class Initialized
INFO - 2022-03-30 00:48:19 --> Router Class Initialized
INFO - 2022-03-30 00:48:19 --> Output Class Initialized
INFO - 2022-03-30 00:48:19 --> Security Class Initialized
DEBUG - 2022-03-30 00:48:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 00:48:19 --> Input Class Initialized
INFO - 2022-03-30 00:48:19 --> Language Class Initialized
INFO - 2022-03-30 00:48:19 --> Loader Class Initialized
INFO - 2022-03-30 00:48:19 --> Helper loaded: url_helper
INFO - 2022-03-30 00:48:19 --> Helper loaded: form_helper
INFO - 2022-03-30 00:48:19 --> Helper loaded: common_helper
INFO - 2022-03-30 00:48:19 --> Database Driver Class Initialized
DEBUG - 2022-03-30 00:48:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 00:48:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 00:48:19 --> Controller Class Initialized
INFO - 2022-03-30 00:48:19 --> Model "Referredby_model" initialized
INFO - 2022-03-30 00:48:19 --> Final output sent to browser
DEBUG - 2022-03-30 00:48:19 --> Total execution time: 0.0470
ERROR - 2022-03-30 00:51:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 00:51:14 --> Config Class Initialized
INFO - 2022-03-30 00:51:14 --> Hooks Class Initialized
DEBUG - 2022-03-30 00:51:14 --> UTF-8 Support Enabled
INFO - 2022-03-30 00:51:14 --> Utf8 Class Initialized
INFO - 2022-03-30 00:51:14 --> URI Class Initialized
INFO - 2022-03-30 00:51:14 --> Router Class Initialized
INFO - 2022-03-30 00:51:14 --> Output Class Initialized
INFO - 2022-03-30 00:51:14 --> Security Class Initialized
DEBUG - 2022-03-30 00:51:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 00:51:14 --> Input Class Initialized
INFO - 2022-03-30 00:51:14 --> Language Class Initialized
INFO - 2022-03-30 00:51:14 --> Loader Class Initialized
INFO - 2022-03-30 00:51:14 --> Helper loaded: url_helper
INFO - 2022-03-30 00:51:14 --> Helper loaded: form_helper
INFO - 2022-03-30 00:51:14 --> Helper loaded: common_helper
INFO - 2022-03-30 00:51:14 --> Database Driver Class Initialized
DEBUG - 2022-03-30 00:51:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 00:51:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 00:51:14 --> Controller Class Initialized
INFO - 2022-03-30 00:51:14 --> Model "Referredby_model" initialized
INFO - 2022-03-30 00:51:14 --> Final output sent to browser
DEBUG - 2022-03-30 00:51:14 --> Total execution time: 0.0437
ERROR - 2022-03-30 00:52:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 00:52:33 --> Config Class Initialized
INFO - 2022-03-30 00:52:33 --> Hooks Class Initialized
DEBUG - 2022-03-30 00:52:33 --> UTF-8 Support Enabled
INFO - 2022-03-30 00:52:33 --> Utf8 Class Initialized
INFO - 2022-03-30 00:52:33 --> URI Class Initialized
INFO - 2022-03-30 00:52:33 --> Router Class Initialized
INFO - 2022-03-30 00:52:33 --> Output Class Initialized
INFO - 2022-03-30 00:52:33 --> Security Class Initialized
DEBUG - 2022-03-30 00:52:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 00:52:33 --> Input Class Initialized
INFO - 2022-03-30 00:52:33 --> Language Class Initialized
INFO - 2022-03-30 00:52:33 --> Loader Class Initialized
INFO - 2022-03-30 00:52:33 --> Helper loaded: url_helper
INFO - 2022-03-30 00:52:33 --> Helper loaded: form_helper
INFO - 2022-03-30 00:52:33 --> Helper loaded: common_helper
INFO - 2022-03-30 00:52:33 --> Database Driver Class Initialized
DEBUG - 2022-03-30 00:52:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 00:52:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 00:52:33 --> Controller Class Initialized
INFO - 2022-03-30 00:52:33 --> Form Validation Class Initialized
DEBUG - 2022-03-30 00:52:33 --> Encrypt Class Initialized
INFO - 2022-03-30 00:52:33 --> Model "Patient_model" initialized
INFO - 2022-03-30 00:52:33 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 00:52:33 --> Model "Referredby_model" initialized
INFO - 2022-03-30 00:52:33 --> Model "Prefix_master" initialized
INFO - 2022-03-30 00:52:33 --> Model "Hospital_model" initialized
INFO - 2022-03-30 00:52:33 --> Final output sent to browser
DEBUG - 2022-03-30 00:52:33 --> Total execution time: 0.0260
ERROR - 2022-03-30 00:55:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 00:55:23 --> Config Class Initialized
INFO - 2022-03-30 00:55:23 --> Hooks Class Initialized
DEBUG - 2022-03-30 00:55:23 --> UTF-8 Support Enabled
INFO - 2022-03-30 00:55:23 --> Utf8 Class Initialized
INFO - 2022-03-30 00:55:23 --> URI Class Initialized
INFO - 2022-03-30 00:55:23 --> Router Class Initialized
INFO - 2022-03-30 00:55:23 --> Output Class Initialized
INFO - 2022-03-30 00:55:23 --> Security Class Initialized
DEBUG - 2022-03-30 00:55:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 00:55:23 --> Input Class Initialized
INFO - 2022-03-30 00:55:23 --> Language Class Initialized
INFO - 2022-03-30 00:55:23 --> Loader Class Initialized
INFO - 2022-03-30 00:55:23 --> Helper loaded: url_helper
INFO - 2022-03-30 00:55:23 --> Helper loaded: form_helper
INFO - 2022-03-30 00:55:23 --> Helper loaded: common_helper
INFO - 2022-03-30 00:55:23 --> Database Driver Class Initialized
DEBUG - 2022-03-30 00:55:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 00:55:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 00:55:24 --> Controller Class Initialized
INFO - 2022-03-30 00:55:24 --> Form Validation Class Initialized
DEBUG - 2022-03-30 00:55:24 --> Encrypt Class Initialized
INFO - 2022-03-30 00:55:24 --> Model "Patient_model" initialized
INFO - 2022-03-30 00:55:24 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 00:55:24 --> Model "Referredby_model" initialized
INFO - 2022-03-30 00:55:24 --> Model "Prefix_master" initialized
INFO - 2022-03-30 00:55:24 --> Model "Hospital_model" initialized
ERROR - 2022-03-30 00:55:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 00:55:24 --> Config Class Initialized
INFO - 2022-03-30 00:55:24 --> Hooks Class Initialized
DEBUG - 2022-03-30 00:55:24 --> UTF-8 Support Enabled
INFO - 2022-03-30 00:55:24 --> Utf8 Class Initialized
INFO - 2022-03-30 00:55:24 --> URI Class Initialized
INFO - 2022-03-30 00:55:24 --> Router Class Initialized
INFO - 2022-03-30 00:55:24 --> Output Class Initialized
INFO - 2022-03-30 00:55:24 --> Security Class Initialized
DEBUG - 2022-03-30 00:55:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 00:55:24 --> Input Class Initialized
INFO - 2022-03-30 00:55:24 --> Language Class Initialized
INFO - 2022-03-30 00:55:24 --> Loader Class Initialized
INFO - 2022-03-30 00:55:24 --> Helper loaded: url_helper
INFO - 2022-03-30 00:55:24 --> Helper loaded: form_helper
INFO - 2022-03-30 00:55:24 --> Helper loaded: common_helper
INFO - 2022-03-30 00:55:24 --> Database Driver Class Initialized
DEBUG - 2022-03-30 00:55:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 00:55:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 00:55:24 --> Controller Class Initialized
INFO - 2022-03-30 00:55:24 --> Form Validation Class Initialized
DEBUG - 2022-03-30 00:55:24 --> Encrypt Class Initialized
INFO - 2022-03-30 00:55:24 --> Model "Patient_model" initialized
INFO - 2022-03-30 00:55:24 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 00:55:24 --> Model "Referredby_model" initialized
INFO - 2022-03-30 00:55:24 --> Model "Prefix_master" initialized
INFO - 2022-03-30 00:55:24 --> Model "Hospital_model" initialized
INFO - 2022-03-30 00:55:25 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 00:55:25 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-30 00:55:25 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 00:55:25 --> Final output sent to browser
DEBUG - 2022-03-30 00:55:25 --> Total execution time: 0.3028
ERROR - 2022-03-30 00:55:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 00:55:25 --> Config Class Initialized
INFO - 2022-03-30 00:55:25 --> Hooks Class Initialized
DEBUG - 2022-03-30 00:55:25 --> UTF-8 Support Enabled
INFO - 2022-03-30 00:55:25 --> Utf8 Class Initialized
INFO - 2022-03-30 00:55:25 --> URI Class Initialized
INFO - 2022-03-30 00:55:25 --> Router Class Initialized
INFO - 2022-03-30 00:55:25 --> Output Class Initialized
INFO - 2022-03-30 00:55:25 --> Security Class Initialized
DEBUG - 2022-03-30 00:55:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 00:55:25 --> Input Class Initialized
INFO - 2022-03-30 00:55:25 --> Language Class Initialized
INFO - 2022-03-30 00:55:25 --> Loader Class Initialized
INFO - 2022-03-30 00:55:25 --> Helper loaded: url_helper
INFO - 2022-03-30 00:55:25 --> Helper loaded: form_helper
INFO - 2022-03-30 00:55:25 --> Helper loaded: common_helper
INFO - 2022-03-30 00:55:25 --> Database Driver Class Initialized
DEBUG - 2022-03-30 00:55:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 00:55:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 00:55:25 --> Controller Class Initialized
INFO - 2022-03-30 00:55:25 --> Form Validation Class Initialized
DEBUG - 2022-03-30 00:55:25 --> Encrypt Class Initialized
INFO - 2022-03-30 00:55:25 --> Model "Patient_model" initialized
INFO - 2022-03-30 00:55:25 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 00:55:25 --> Model "Prefix_master" initialized
INFO - 2022-03-30 00:55:25 --> Model "Users_model" initialized
INFO - 2022-03-30 00:55:25 --> Model "Hospital_model" initialized
INFO - 2022-03-30 00:55:25 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 00:55:25 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-30 00:55:25 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 00:55:25 --> Final output sent to browser
DEBUG - 2022-03-30 00:55:25 --> Total execution time: 0.2213
ERROR - 2022-03-30 00:55:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 00:55:31 --> Config Class Initialized
INFO - 2022-03-30 00:55:31 --> Hooks Class Initialized
DEBUG - 2022-03-30 00:55:31 --> UTF-8 Support Enabled
INFO - 2022-03-30 00:55:31 --> Utf8 Class Initialized
INFO - 2022-03-30 00:55:31 --> URI Class Initialized
INFO - 2022-03-30 00:55:31 --> Router Class Initialized
INFO - 2022-03-30 00:55:31 --> Output Class Initialized
INFO - 2022-03-30 00:55:31 --> Security Class Initialized
DEBUG - 2022-03-30 00:55:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 00:55:31 --> Input Class Initialized
INFO - 2022-03-30 00:55:31 --> Language Class Initialized
INFO - 2022-03-30 00:55:31 --> Loader Class Initialized
INFO - 2022-03-30 00:55:31 --> Helper loaded: url_helper
INFO - 2022-03-30 00:55:31 --> Helper loaded: form_helper
INFO - 2022-03-30 00:55:31 --> Helper loaded: common_helper
INFO - 2022-03-30 00:55:31 --> Database Driver Class Initialized
DEBUG - 2022-03-30 00:55:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 00:55:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 00:55:31 --> Controller Class Initialized
INFO - 2022-03-30 00:55:31 --> Form Validation Class Initialized
DEBUG - 2022-03-30 00:55:31 --> Encrypt Class Initialized
INFO - 2022-03-30 00:55:31 --> Model "Patient_model" initialized
INFO - 2022-03-30 00:55:31 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 00:55:31 --> Model "Referredby_model" initialized
INFO - 2022-03-30 00:55:31 --> Model "Prefix_master" initialized
INFO - 2022-03-30 00:55:31 --> Model "Hospital_model" initialized
INFO - 2022-03-30 00:55:31 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 00:55:31 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-30 00:55:31 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 00:55:31 --> Final output sent to browser
DEBUG - 2022-03-30 00:55:31 --> Total execution time: 0.0720
ERROR - 2022-03-30 00:55:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 00:55:38 --> Config Class Initialized
INFO - 2022-03-30 00:55:38 --> Hooks Class Initialized
DEBUG - 2022-03-30 00:55:38 --> UTF-8 Support Enabled
INFO - 2022-03-30 00:55:38 --> Utf8 Class Initialized
INFO - 2022-03-30 00:55:38 --> URI Class Initialized
INFO - 2022-03-30 00:55:38 --> Router Class Initialized
INFO - 2022-03-30 00:55:38 --> Output Class Initialized
INFO - 2022-03-30 00:55:38 --> Security Class Initialized
DEBUG - 2022-03-30 00:55:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 00:55:38 --> Input Class Initialized
INFO - 2022-03-30 00:55:38 --> Language Class Initialized
INFO - 2022-03-30 00:55:38 --> Loader Class Initialized
INFO - 2022-03-30 00:55:38 --> Helper loaded: url_helper
INFO - 2022-03-30 00:55:38 --> Helper loaded: form_helper
INFO - 2022-03-30 00:55:38 --> Helper loaded: common_helper
INFO - 2022-03-30 00:55:38 --> Database Driver Class Initialized
DEBUG - 2022-03-30 00:55:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 00:55:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 00:55:38 --> Controller Class Initialized
INFO - 2022-03-30 00:55:38 --> Form Validation Class Initialized
DEBUG - 2022-03-30 00:55:38 --> Encrypt Class Initialized
INFO - 2022-03-30 00:55:38 --> Model "Patient_model" initialized
INFO - 2022-03-30 00:55:38 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 00:55:38 --> Model "Prefix_master" initialized
INFO - 2022-03-30 00:55:38 --> Model "Users_model" initialized
INFO - 2022-03-30 00:55:38 --> Model "Hospital_model" initialized
INFO - 2022-03-30 00:55:38 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-30 00:55:39 --> Final output sent to browser
DEBUG - 2022-03-30 00:55:39 --> Total execution time: 1.0559
ERROR - 2022-03-30 00:55:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 00:55:45 --> Config Class Initialized
INFO - 2022-03-30 00:55:45 --> Hooks Class Initialized
DEBUG - 2022-03-30 00:55:45 --> UTF-8 Support Enabled
INFO - 2022-03-30 00:55:45 --> Utf8 Class Initialized
INFO - 2022-03-30 00:55:45 --> URI Class Initialized
INFO - 2022-03-30 00:55:45 --> Router Class Initialized
INFO - 2022-03-30 00:55:45 --> Output Class Initialized
INFO - 2022-03-30 00:55:45 --> Security Class Initialized
DEBUG - 2022-03-30 00:55:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 00:55:45 --> Input Class Initialized
INFO - 2022-03-30 00:55:45 --> Language Class Initialized
INFO - 2022-03-30 00:55:45 --> Loader Class Initialized
INFO - 2022-03-30 00:55:45 --> Helper loaded: url_helper
INFO - 2022-03-30 00:55:45 --> Helper loaded: form_helper
INFO - 2022-03-30 00:55:45 --> Helper loaded: common_helper
INFO - 2022-03-30 00:55:45 --> Database Driver Class Initialized
DEBUG - 2022-03-30 00:55:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 00:55:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 00:55:45 --> Controller Class Initialized
INFO - 2022-03-30 00:55:45 --> Form Validation Class Initialized
DEBUG - 2022-03-30 00:55:45 --> Encrypt Class Initialized
INFO - 2022-03-30 00:55:45 --> Model "Patient_model" initialized
INFO - 2022-03-30 00:55:45 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 00:55:45 --> Model "Referredby_model" initialized
INFO - 2022-03-30 00:55:45 --> Model "Prefix_master" initialized
INFO - 2022-03-30 00:55:45 --> Model "Hospital_model" initialized
INFO - 2022-03-30 00:55:45 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 00:55:45 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-30 00:55:45 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 00:55:45 --> Final output sent to browser
DEBUG - 2022-03-30 00:55:45 --> Total execution time: 0.0409
ERROR - 2022-03-30 00:55:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 00:55:52 --> Config Class Initialized
INFO - 2022-03-30 00:55:52 --> Hooks Class Initialized
DEBUG - 2022-03-30 00:55:52 --> UTF-8 Support Enabled
INFO - 2022-03-30 00:55:52 --> Utf8 Class Initialized
INFO - 2022-03-30 00:55:52 --> URI Class Initialized
INFO - 2022-03-30 00:55:52 --> Router Class Initialized
INFO - 2022-03-30 00:55:52 --> Output Class Initialized
INFO - 2022-03-30 00:55:52 --> Security Class Initialized
DEBUG - 2022-03-30 00:55:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 00:55:52 --> Input Class Initialized
INFO - 2022-03-30 00:55:52 --> Language Class Initialized
INFO - 2022-03-30 00:55:52 --> Loader Class Initialized
INFO - 2022-03-30 00:55:52 --> Helper loaded: url_helper
INFO - 2022-03-30 00:55:52 --> Helper loaded: form_helper
INFO - 2022-03-30 00:55:52 --> Helper loaded: common_helper
INFO - 2022-03-30 00:55:52 --> Database Driver Class Initialized
DEBUG - 2022-03-30 00:55:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 00:55:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 00:55:52 --> Controller Class Initialized
INFO - 2022-03-30 00:55:52 --> Form Validation Class Initialized
DEBUG - 2022-03-30 00:55:52 --> Encrypt Class Initialized
INFO - 2022-03-30 00:55:52 --> Model "Patient_model" initialized
INFO - 2022-03-30 00:55:52 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 00:55:52 --> Model "Referredby_model" initialized
INFO - 2022-03-30 00:55:52 --> Model "Prefix_master" initialized
INFO - 2022-03-30 00:55:52 --> Model "Hospital_model" initialized
ERROR - 2022-03-30 00:55:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 00:55:52 --> Config Class Initialized
INFO - 2022-03-30 00:55:52 --> Hooks Class Initialized
DEBUG - 2022-03-30 00:55:52 --> UTF-8 Support Enabled
INFO - 2022-03-30 00:55:52 --> Utf8 Class Initialized
INFO - 2022-03-30 00:55:52 --> URI Class Initialized
INFO - 2022-03-30 00:55:52 --> Router Class Initialized
INFO - 2022-03-30 00:55:52 --> Output Class Initialized
INFO - 2022-03-30 00:55:52 --> Security Class Initialized
DEBUG - 2022-03-30 00:55:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 00:55:52 --> Input Class Initialized
INFO - 2022-03-30 00:55:52 --> Language Class Initialized
INFO - 2022-03-30 00:55:52 --> Loader Class Initialized
INFO - 2022-03-30 00:55:52 --> Helper loaded: url_helper
INFO - 2022-03-30 00:55:52 --> Helper loaded: form_helper
INFO - 2022-03-30 00:55:52 --> Helper loaded: common_helper
INFO - 2022-03-30 00:55:52 --> Database Driver Class Initialized
DEBUG - 2022-03-30 00:55:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 00:55:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 00:55:52 --> Controller Class Initialized
INFO - 2022-03-30 00:55:52 --> Form Validation Class Initialized
DEBUG - 2022-03-30 00:55:52 --> Encrypt Class Initialized
INFO - 2022-03-30 00:55:52 --> Model "Patient_model" initialized
INFO - 2022-03-30 00:55:52 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 00:55:52 --> Model "Referredby_model" initialized
INFO - 2022-03-30 00:55:52 --> Model "Prefix_master" initialized
INFO - 2022-03-30 00:55:52 --> Model "Hospital_model" initialized
INFO - 2022-03-30 00:55:52 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 00:55:52 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-30 00:55:52 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 00:55:52 --> Final output sent to browser
DEBUG - 2022-03-30 00:55:52 --> Total execution time: 0.0356
ERROR - 2022-03-30 00:55:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 00:55:53 --> Config Class Initialized
INFO - 2022-03-30 00:55:53 --> Hooks Class Initialized
DEBUG - 2022-03-30 00:55:53 --> UTF-8 Support Enabled
INFO - 2022-03-30 00:55:53 --> Utf8 Class Initialized
INFO - 2022-03-30 00:55:53 --> URI Class Initialized
INFO - 2022-03-30 00:55:53 --> Router Class Initialized
INFO - 2022-03-30 00:55:53 --> Output Class Initialized
INFO - 2022-03-30 00:55:53 --> Security Class Initialized
DEBUG - 2022-03-30 00:55:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 00:55:53 --> Input Class Initialized
INFO - 2022-03-30 00:55:53 --> Language Class Initialized
INFO - 2022-03-30 00:55:53 --> Loader Class Initialized
INFO - 2022-03-30 00:55:53 --> Helper loaded: url_helper
INFO - 2022-03-30 00:55:53 --> Helper loaded: form_helper
INFO - 2022-03-30 00:55:53 --> Helper loaded: common_helper
INFO - 2022-03-30 00:55:53 --> Database Driver Class Initialized
DEBUG - 2022-03-30 00:55:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 00:55:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 00:55:53 --> Controller Class Initialized
INFO - 2022-03-30 00:55:53 --> Form Validation Class Initialized
DEBUG - 2022-03-30 00:55:53 --> Encrypt Class Initialized
INFO - 2022-03-30 00:55:53 --> Model "Patient_model" initialized
INFO - 2022-03-30 00:55:53 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 00:55:53 --> Model "Prefix_master" initialized
INFO - 2022-03-30 00:55:53 --> Model "Users_model" initialized
INFO - 2022-03-30 00:55:53 --> Model "Hospital_model" initialized
INFO - 2022-03-30 00:55:53 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 00:55:53 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-30 00:55:53 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 00:55:53 --> Final output sent to browser
DEBUG - 2022-03-30 00:55:53 --> Total execution time: 0.0388
ERROR - 2022-03-30 00:59:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 00:59:35 --> Config Class Initialized
INFO - 2022-03-30 00:59:35 --> Hooks Class Initialized
DEBUG - 2022-03-30 00:59:35 --> UTF-8 Support Enabled
INFO - 2022-03-30 00:59:35 --> Utf8 Class Initialized
INFO - 2022-03-30 00:59:35 --> URI Class Initialized
INFO - 2022-03-30 00:59:35 --> Router Class Initialized
INFO - 2022-03-30 00:59:35 --> Output Class Initialized
INFO - 2022-03-30 00:59:35 --> Security Class Initialized
DEBUG - 2022-03-30 00:59:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 00:59:35 --> Input Class Initialized
INFO - 2022-03-30 00:59:35 --> Language Class Initialized
INFO - 2022-03-30 00:59:35 --> Loader Class Initialized
INFO - 2022-03-30 00:59:35 --> Helper loaded: url_helper
INFO - 2022-03-30 00:59:35 --> Helper loaded: form_helper
INFO - 2022-03-30 00:59:35 --> Helper loaded: common_helper
INFO - 2022-03-30 00:59:35 --> Database Driver Class Initialized
DEBUG - 2022-03-30 00:59:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 00:59:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 00:59:35 --> Controller Class Initialized
INFO - 2022-03-30 00:59:35 --> Form Validation Class Initialized
DEBUG - 2022-03-30 00:59:35 --> Encrypt Class Initialized
INFO - 2022-03-30 00:59:35 --> Model "Patient_model" initialized
INFO - 2022-03-30 00:59:35 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 00:59:35 --> Model "Prefix_master" initialized
INFO - 2022-03-30 00:59:35 --> Model "Users_model" initialized
INFO - 2022-03-30 00:59:35 --> Model "Hospital_model" initialized
INFO - 2022-03-30 00:59:35 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-30 00:59:36 --> Final output sent to browser
DEBUG - 2022-03-30 00:59:36 --> Total execution time: 1.7093
ERROR - 2022-03-30 01:00:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 01:00:54 --> Config Class Initialized
INFO - 2022-03-30 01:00:54 --> Hooks Class Initialized
DEBUG - 2022-03-30 01:00:54 --> UTF-8 Support Enabled
INFO - 2022-03-30 01:00:54 --> Utf8 Class Initialized
INFO - 2022-03-30 01:00:54 --> URI Class Initialized
INFO - 2022-03-30 01:00:54 --> Router Class Initialized
INFO - 2022-03-30 01:00:54 --> Output Class Initialized
INFO - 2022-03-30 01:00:54 --> Security Class Initialized
DEBUG - 2022-03-30 01:00:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 01:00:54 --> Input Class Initialized
INFO - 2022-03-30 01:00:54 --> Language Class Initialized
INFO - 2022-03-30 01:00:54 --> Loader Class Initialized
INFO - 2022-03-30 01:00:54 --> Helper loaded: url_helper
INFO - 2022-03-30 01:00:54 --> Helper loaded: form_helper
INFO - 2022-03-30 01:00:54 --> Helper loaded: common_helper
INFO - 2022-03-30 01:00:54 --> Database Driver Class Initialized
DEBUG - 2022-03-30 01:00:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 01:00:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 01:00:54 --> Controller Class Initialized
INFO - 2022-03-30 01:00:54 --> Form Validation Class Initialized
DEBUG - 2022-03-30 01:00:54 --> Encrypt Class Initialized
INFO - 2022-03-30 01:00:54 --> Model "Patient_model" initialized
INFO - 2022-03-30 01:00:54 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 01:00:54 --> Model "Prefix_master" initialized
INFO - 2022-03-30 01:00:54 --> Model "Users_model" initialized
INFO - 2022-03-30 01:00:54 --> Model "Hospital_model" initialized
INFO - 2022-03-30 01:00:54 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 01:00:54 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-30 01:00:54 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 01:00:54 --> Final output sent to browser
DEBUG - 2022-03-30 01:00:54 --> Total execution time: 0.0415
ERROR - 2022-03-30 01:01:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 01:01:20 --> Config Class Initialized
INFO - 2022-03-30 01:01:20 --> Hooks Class Initialized
DEBUG - 2022-03-30 01:01:20 --> UTF-8 Support Enabled
INFO - 2022-03-30 01:01:20 --> Utf8 Class Initialized
INFO - 2022-03-30 01:01:20 --> URI Class Initialized
INFO - 2022-03-30 01:01:20 --> Router Class Initialized
INFO - 2022-03-30 01:01:20 --> Output Class Initialized
INFO - 2022-03-30 01:01:20 --> Security Class Initialized
DEBUG - 2022-03-30 01:01:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 01:01:20 --> Input Class Initialized
INFO - 2022-03-30 01:01:20 --> Language Class Initialized
INFO - 2022-03-30 01:01:20 --> Loader Class Initialized
INFO - 2022-03-30 01:01:20 --> Helper loaded: url_helper
INFO - 2022-03-30 01:01:20 --> Helper loaded: form_helper
INFO - 2022-03-30 01:01:20 --> Helper loaded: common_helper
INFO - 2022-03-30 01:01:20 --> Database Driver Class Initialized
DEBUG - 2022-03-30 01:01:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 01:01:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 01:01:20 --> Controller Class Initialized
INFO - 2022-03-30 01:01:20 --> Form Validation Class Initialized
DEBUG - 2022-03-30 01:01:20 --> Encrypt Class Initialized
INFO - 2022-03-30 01:01:20 --> Model "Patient_model" initialized
INFO - 2022-03-30 01:01:20 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 01:01:20 --> Model "Prefix_master" initialized
INFO - 2022-03-30 01:01:20 --> Model "Users_model" initialized
INFO - 2022-03-30 01:01:20 --> Model "Hospital_model" initialized
ERROR - 2022-03-30 01:01:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 01:01:20 --> Config Class Initialized
INFO - 2022-03-30 01:01:20 --> Hooks Class Initialized
DEBUG - 2022-03-30 01:01:20 --> UTF-8 Support Enabled
INFO - 2022-03-30 01:01:20 --> Utf8 Class Initialized
INFO - 2022-03-30 01:01:20 --> URI Class Initialized
INFO - 2022-03-30 01:01:20 --> Router Class Initialized
INFO - 2022-03-30 01:01:20 --> Output Class Initialized
INFO - 2022-03-30 01:01:20 --> Security Class Initialized
DEBUG - 2022-03-30 01:01:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 01:01:20 --> Input Class Initialized
INFO - 2022-03-30 01:01:20 --> Language Class Initialized
INFO - 2022-03-30 01:01:20 --> Loader Class Initialized
INFO - 2022-03-30 01:01:20 --> Helper loaded: url_helper
INFO - 2022-03-30 01:01:20 --> Helper loaded: form_helper
INFO - 2022-03-30 01:01:20 --> Helper loaded: common_helper
INFO - 2022-03-30 01:01:20 --> Database Driver Class Initialized
DEBUG - 2022-03-30 01:01:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 01:01:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 01:01:20 --> Controller Class Initialized
INFO - 2022-03-30 01:01:20 --> Form Validation Class Initialized
DEBUG - 2022-03-30 01:01:20 --> Encrypt Class Initialized
INFO - 2022-03-30 01:01:20 --> Model "Patient_model" initialized
INFO - 2022-03-30 01:01:20 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 01:01:20 --> Model "Prefix_master" initialized
INFO - 2022-03-30 01:01:20 --> Model "Users_model" initialized
INFO - 2022-03-30 01:01:20 --> Model "Hospital_model" initialized
INFO - 2022-03-30 01:01:20 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 01:01:20 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-30 01:01:20 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 01:01:20 --> Final output sent to browser
DEBUG - 2022-03-30 01:01:20 --> Total execution time: 0.0419
ERROR - 2022-03-30 01:01:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 01:01:54 --> Config Class Initialized
INFO - 2022-03-30 01:01:54 --> Hooks Class Initialized
DEBUG - 2022-03-30 01:01:54 --> UTF-8 Support Enabled
INFO - 2022-03-30 01:01:54 --> Utf8 Class Initialized
INFO - 2022-03-30 01:01:54 --> URI Class Initialized
INFO - 2022-03-30 01:01:54 --> Router Class Initialized
INFO - 2022-03-30 01:01:54 --> Output Class Initialized
INFO - 2022-03-30 01:01:54 --> Security Class Initialized
DEBUG - 2022-03-30 01:01:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 01:01:54 --> Input Class Initialized
INFO - 2022-03-30 01:01:54 --> Language Class Initialized
INFO - 2022-03-30 01:01:54 --> Loader Class Initialized
INFO - 2022-03-30 01:01:54 --> Helper loaded: url_helper
INFO - 2022-03-30 01:01:54 --> Helper loaded: form_helper
INFO - 2022-03-30 01:01:54 --> Helper loaded: common_helper
INFO - 2022-03-30 01:01:54 --> Database Driver Class Initialized
DEBUG - 2022-03-30 01:01:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 01:01:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 01:01:54 --> Controller Class Initialized
INFO - 2022-03-30 01:01:54 --> Form Validation Class Initialized
DEBUG - 2022-03-30 01:01:54 --> Encrypt Class Initialized
INFO - 2022-03-30 01:01:54 --> Model "Patient_model" initialized
INFO - 2022-03-30 01:01:54 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 01:01:54 --> Model "Prefix_master" initialized
INFO - 2022-03-30 01:01:54 --> Model "Users_model" initialized
INFO - 2022-03-30 01:01:54 --> Model "Hospital_model" initialized
INFO - 2022-03-30 01:01:54 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-30 01:01:54 --> Final output sent to browser
DEBUG - 2022-03-30 01:01:54 --> Total execution time: 0.7483
ERROR - 2022-03-30 01:02:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 01:02:58 --> Config Class Initialized
INFO - 2022-03-30 01:02:58 --> Hooks Class Initialized
DEBUG - 2022-03-30 01:02:58 --> UTF-8 Support Enabled
INFO - 2022-03-30 01:02:58 --> Utf8 Class Initialized
INFO - 2022-03-30 01:02:58 --> URI Class Initialized
INFO - 2022-03-30 01:02:58 --> Router Class Initialized
INFO - 2022-03-30 01:02:58 --> Output Class Initialized
INFO - 2022-03-30 01:02:58 --> Security Class Initialized
DEBUG - 2022-03-30 01:02:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 01:02:58 --> Input Class Initialized
INFO - 2022-03-30 01:02:58 --> Language Class Initialized
INFO - 2022-03-30 01:02:58 --> Loader Class Initialized
INFO - 2022-03-30 01:02:58 --> Helper loaded: url_helper
INFO - 2022-03-30 01:02:58 --> Helper loaded: form_helper
INFO - 2022-03-30 01:02:58 --> Helper loaded: common_helper
INFO - 2022-03-30 01:02:58 --> Database Driver Class Initialized
DEBUG - 2022-03-30 01:02:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 01:02:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 01:02:58 --> Controller Class Initialized
INFO - 2022-03-30 01:02:58 --> Form Validation Class Initialized
DEBUG - 2022-03-30 01:02:58 --> Encrypt Class Initialized
INFO - 2022-03-30 01:02:58 --> Model "Patient_model" initialized
INFO - 2022-03-30 01:02:58 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 01:02:58 --> Model "Prefix_master" initialized
INFO - 2022-03-30 01:02:58 --> Model "Users_model" initialized
INFO - 2022-03-30 01:02:58 --> Model "Hospital_model" initialized
ERROR - 2022-03-30 01:02:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 01:02:58 --> Config Class Initialized
INFO - 2022-03-30 01:02:58 --> Hooks Class Initialized
DEBUG - 2022-03-30 01:02:58 --> UTF-8 Support Enabled
INFO - 2022-03-30 01:02:58 --> Utf8 Class Initialized
INFO - 2022-03-30 01:02:58 --> URI Class Initialized
INFO - 2022-03-30 01:02:58 --> Router Class Initialized
INFO - 2022-03-30 01:02:58 --> Output Class Initialized
INFO - 2022-03-30 01:02:58 --> Security Class Initialized
DEBUG - 2022-03-30 01:02:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 01:02:58 --> Input Class Initialized
INFO - 2022-03-30 01:02:58 --> Language Class Initialized
INFO - 2022-03-30 01:02:58 --> Loader Class Initialized
INFO - 2022-03-30 01:02:58 --> Helper loaded: url_helper
INFO - 2022-03-30 01:02:58 --> Helper loaded: form_helper
INFO - 2022-03-30 01:02:58 --> Helper loaded: common_helper
INFO - 2022-03-30 01:02:58 --> Database Driver Class Initialized
DEBUG - 2022-03-30 01:02:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 01:02:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 01:02:58 --> Controller Class Initialized
INFO - 2022-03-30 01:02:58 --> Form Validation Class Initialized
DEBUG - 2022-03-30 01:02:58 --> Encrypt Class Initialized
INFO - 2022-03-30 01:02:58 --> Model "Patient_model" initialized
INFO - 2022-03-30 01:02:58 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 01:02:58 --> Model "Prefix_master" initialized
INFO - 2022-03-30 01:02:58 --> Model "Users_model" initialized
INFO - 2022-03-30 01:02:58 --> Model "Hospital_model" initialized
INFO - 2022-03-30 01:02:59 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 01:02:59 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-30 01:02:59 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 01:02:59 --> Final output sent to browser
DEBUG - 2022-03-30 01:02:59 --> Total execution time: 0.0618
ERROR - 2022-03-30 01:12:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 01:12:18 --> Config Class Initialized
INFO - 2022-03-30 01:12:18 --> Hooks Class Initialized
DEBUG - 2022-03-30 01:12:18 --> UTF-8 Support Enabled
INFO - 2022-03-30 01:12:18 --> Utf8 Class Initialized
INFO - 2022-03-30 01:12:18 --> URI Class Initialized
INFO - 2022-03-30 01:12:18 --> Router Class Initialized
INFO - 2022-03-30 01:12:18 --> Output Class Initialized
INFO - 2022-03-30 01:12:18 --> Security Class Initialized
DEBUG - 2022-03-30 01:12:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 01:12:18 --> Input Class Initialized
INFO - 2022-03-30 01:12:18 --> Language Class Initialized
INFO - 2022-03-30 01:12:18 --> Loader Class Initialized
INFO - 2022-03-30 01:12:18 --> Helper loaded: url_helper
INFO - 2022-03-30 01:12:18 --> Helper loaded: form_helper
INFO - 2022-03-30 01:12:18 --> Helper loaded: common_helper
INFO - 2022-03-30 01:12:18 --> Database Driver Class Initialized
DEBUG - 2022-03-30 01:12:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 01:12:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 01:12:18 --> Controller Class Initialized
INFO - 2022-03-30 01:12:18 --> Form Validation Class Initialized
DEBUG - 2022-03-30 01:12:18 --> Encrypt Class Initialized
INFO - 2022-03-30 01:12:18 --> Model "Patient_model" initialized
INFO - 2022-03-30 01:12:18 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 01:12:18 --> Model "Prefix_master" initialized
INFO - 2022-03-30 01:12:18 --> Model "Users_model" initialized
INFO - 2022-03-30 01:12:18 --> Model "Hospital_model" initialized
ERROR - 2022-03-30 01:12:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 01:12:18 --> Config Class Initialized
INFO - 2022-03-30 01:12:18 --> Hooks Class Initialized
DEBUG - 2022-03-30 01:12:18 --> UTF-8 Support Enabled
INFO - 2022-03-30 01:12:18 --> Utf8 Class Initialized
INFO - 2022-03-30 01:12:18 --> URI Class Initialized
INFO - 2022-03-30 01:12:18 --> Router Class Initialized
INFO - 2022-03-30 01:12:18 --> Output Class Initialized
INFO - 2022-03-30 01:12:18 --> Security Class Initialized
DEBUG - 2022-03-30 01:12:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 01:12:18 --> Input Class Initialized
INFO - 2022-03-30 01:12:18 --> Language Class Initialized
INFO - 2022-03-30 01:12:18 --> Loader Class Initialized
INFO - 2022-03-30 01:12:18 --> Helper loaded: url_helper
INFO - 2022-03-30 01:12:18 --> Helper loaded: form_helper
INFO - 2022-03-30 01:12:18 --> Helper loaded: common_helper
INFO - 2022-03-30 01:12:18 --> Database Driver Class Initialized
DEBUG - 2022-03-30 01:12:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 01:12:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 01:12:18 --> Controller Class Initialized
INFO - 2022-03-30 01:12:18 --> Form Validation Class Initialized
DEBUG - 2022-03-30 01:12:18 --> Encrypt Class Initialized
INFO - 2022-03-30 01:12:18 --> Model "Patient_model" initialized
INFO - 2022-03-30 01:12:18 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 01:12:18 --> Model "Prefix_master" initialized
INFO - 2022-03-30 01:12:18 --> Model "Users_model" initialized
INFO - 2022-03-30 01:12:18 --> Model "Hospital_model" initialized
INFO - 2022-03-30 01:12:18 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 01:12:18 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-30 01:12:18 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 01:12:18 --> Final output sent to browser
DEBUG - 2022-03-30 01:12:18 --> Total execution time: 0.0918
ERROR - 2022-03-30 01:13:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 01:13:37 --> Config Class Initialized
INFO - 2022-03-30 01:13:37 --> Hooks Class Initialized
DEBUG - 2022-03-30 01:13:37 --> UTF-8 Support Enabled
INFO - 2022-03-30 01:13:37 --> Utf8 Class Initialized
INFO - 2022-03-30 01:13:37 --> URI Class Initialized
INFO - 2022-03-30 01:13:37 --> Router Class Initialized
INFO - 2022-03-30 01:13:37 --> Output Class Initialized
INFO - 2022-03-30 01:13:37 --> Security Class Initialized
DEBUG - 2022-03-30 01:13:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 01:13:37 --> Input Class Initialized
INFO - 2022-03-30 01:13:37 --> Language Class Initialized
INFO - 2022-03-30 01:13:37 --> Loader Class Initialized
INFO - 2022-03-30 01:13:37 --> Helper loaded: url_helper
INFO - 2022-03-30 01:13:37 --> Helper loaded: form_helper
INFO - 2022-03-30 01:13:37 --> Helper loaded: common_helper
INFO - 2022-03-30 01:13:37 --> Database Driver Class Initialized
DEBUG - 2022-03-30 01:13:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 01:13:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 01:13:37 --> Controller Class Initialized
INFO - 2022-03-30 01:13:37 --> Form Validation Class Initialized
DEBUG - 2022-03-30 01:13:37 --> Encrypt Class Initialized
INFO - 2022-03-30 01:13:37 --> Model "Patient_model" initialized
INFO - 2022-03-30 01:13:37 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 01:13:37 --> Model "Prefix_master" initialized
INFO - 2022-03-30 01:13:37 --> Model "Users_model" initialized
INFO - 2022-03-30 01:13:37 --> Model "Hospital_model" initialized
INFO - 2022-03-30 01:13:37 --> Upload Class Initialized
INFO - 2022-03-30 01:13:38 --> Final output sent to browser
DEBUG - 2022-03-30 01:13:38 --> Total execution time: 0.0298
ERROR - 2022-03-30 01:13:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 01:13:41 --> Config Class Initialized
INFO - 2022-03-30 01:13:41 --> Hooks Class Initialized
DEBUG - 2022-03-30 01:13:41 --> UTF-8 Support Enabled
INFO - 2022-03-30 01:13:41 --> Utf8 Class Initialized
INFO - 2022-03-30 01:13:41 --> URI Class Initialized
INFO - 2022-03-30 01:13:41 --> Router Class Initialized
INFO - 2022-03-30 01:13:41 --> Output Class Initialized
INFO - 2022-03-30 01:13:41 --> Security Class Initialized
DEBUG - 2022-03-30 01:13:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 01:13:41 --> Input Class Initialized
INFO - 2022-03-30 01:13:41 --> Language Class Initialized
INFO - 2022-03-30 01:13:41 --> Loader Class Initialized
INFO - 2022-03-30 01:13:41 --> Helper loaded: url_helper
INFO - 2022-03-30 01:13:41 --> Helper loaded: form_helper
INFO - 2022-03-30 01:13:41 --> Helper loaded: common_helper
INFO - 2022-03-30 01:13:41 --> Database Driver Class Initialized
DEBUG - 2022-03-30 01:13:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 01:13:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 01:13:41 --> Controller Class Initialized
INFO - 2022-03-30 01:13:41 --> Form Validation Class Initialized
DEBUG - 2022-03-30 01:13:41 --> Encrypt Class Initialized
INFO - 2022-03-30 01:13:41 --> Model "Patient_model" initialized
INFO - 2022-03-30 01:13:41 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 01:13:41 --> Model "Prefix_master" initialized
INFO - 2022-03-30 01:13:41 --> Model "Users_model" initialized
INFO - 2022-03-30 01:13:41 --> Model "Hospital_model" initialized
ERROR - 2022-03-30 01:13:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 01:13:41 --> Config Class Initialized
INFO - 2022-03-30 01:13:41 --> Hooks Class Initialized
DEBUG - 2022-03-30 01:13:41 --> UTF-8 Support Enabled
INFO - 2022-03-30 01:13:41 --> Utf8 Class Initialized
INFO - 2022-03-30 01:13:41 --> URI Class Initialized
INFO - 2022-03-30 01:13:41 --> Router Class Initialized
INFO - 2022-03-30 01:13:41 --> Output Class Initialized
INFO - 2022-03-30 01:13:41 --> Security Class Initialized
DEBUG - 2022-03-30 01:13:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 01:13:41 --> Input Class Initialized
INFO - 2022-03-30 01:13:41 --> Language Class Initialized
INFO - 2022-03-30 01:13:41 --> Loader Class Initialized
INFO - 2022-03-30 01:13:41 --> Helper loaded: url_helper
INFO - 2022-03-30 01:13:41 --> Helper loaded: form_helper
INFO - 2022-03-30 01:13:41 --> Helper loaded: common_helper
INFO - 2022-03-30 01:13:41 --> Database Driver Class Initialized
DEBUG - 2022-03-30 01:13:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 01:13:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 01:13:41 --> Controller Class Initialized
INFO - 2022-03-30 01:13:41 --> Form Validation Class Initialized
DEBUG - 2022-03-30 01:13:41 --> Encrypt Class Initialized
INFO - 2022-03-30 01:13:41 --> Model "Patient_model" initialized
INFO - 2022-03-30 01:13:41 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 01:13:41 --> Model "Prefix_master" initialized
INFO - 2022-03-30 01:13:41 --> Model "Users_model" initialized
INFO - 2022-03-30 01:13:41 --> Model "Hospital_model" initialized
INFO - 2022-03-30 01:13:41 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 01:13:41 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-30 01:13:41 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 01:13:41 --> Final output sent to browser
DEBUG - 2022-03-30 01:13:41 --> Total execution time: 0.1036
ERROR - 2022-03-30 01:20:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 01:20:23 --> Config Class Initialized
INFO - 2022-03-30 01:20:23 --> Hooks Class Initialized
DEBUG - 2022-03-30 01:20:23 --> UTF-8 Support Enabled
INFO - 2022-03-30 01:20:23 --> Utf8 Class Initialized
INFO - 2022-03-30 01:20:23 --> URI Class Initialized
DEBUG - 2022-03-30 01:20:23 --> No URI present. Default controller set.
INFO - 2022-03-30 01:20:23 --> Router Class Initialized
INFO - 2022-03-30 01:20:23 --> Output Class Initialized
INFO - 2022-03-30 01:20:23 --> Security Class Initialized
DEBUG - 2022-03-30 01:20:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 01:20:23 --> Input Class Initialized
INFO - 2022-03-30 01:20:23 --> Language Class Initialized
INFO - 2022-03-30 01:20:23 --> Loader Class Initialized
INFO - 2022-03-30 01:20:23 --> Helper loaded: url_helper
INFO - 2022-03-30 01:20:23 --> Helper loaded: form_helper
INFO - 2022-03-30 01:20:23 --> Helper loaded: common_helper
INFO - 2022-03-30 01:20:23 --> Database Driver Class Initialized
DEBUG - 2022-03-30 01:20:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 01:20:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 01:20:23 --> Controller Class Initialized
INFO - 2022-03-30 01:20:23 --> Form Validation Class Initialized
DEBUG - 2022-03-30 01:20:23 --> Encrypt Class Initialized
DEBUG - 2022-03-30 01:20:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-30 01:20:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-30 01:20:23 --> Email Class Initialized
INFO - 2022-03-30 01:20:23 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-30 01:20:23 --> Calendar Class Initialized
INFO - 2022-03-30 01:20:23 --> Model "Login_model" initialized
INFO - 2022-03-30 01:20:23 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-30 01:20:23 --> Final output sent to browser
DEBUG - 2022-03-30 01:20:23 --> Total execution time: 0.0693
ERROR - 2022-03-30 01:28:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 01:28:41 --> Config Class Initialized
INFO - 2022-03-30 01:28:41 --> Hooks Class Initialized
DEBUG - 2022-03-30 01:28:41 --> UTF-8 Support Enabled
INFO - 2022-03-30 01:28:41 --> Utf8 Class Initialized
INFO - 2022-03-30 01:28:41 --> URI Class Initialized
INFO - 2022-03-30 01:28:41 --> Router Class Initialized
INFO - 2022-03-30 01:28:41 --> Output Class Initialized
INFO - 2022-03-30 01:28:41 --> Security Class Initialized
DEBUG - 2022-03-30 01:28:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 01:28:41 --> Input Class Initialized
INFO - 2022-03-30 01:28:41 --> Language Class Initialized
INFO - 2022-03-30 01:28:41 --> Loader Class Initialized
INFO - 2022-03-30 01:28:41 --> Helper loaded: url_helper
INFO - 2022-03-30 01:28:41 --> Helper loaded: form_helper
INFO - 2022-03-30 01:28:41 --> Helper loaded: common_helper
INFO - 2022-03-30 01:28:41 --> Database Driver Class Initialized
DEBUG - 2022-03-30 01:28:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 01:28:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 01:28:41 --> Controller Class Initialized
INFO - 2022-03-30 01:28:41 --> Form Validation Class Initialized
DEBUG - 2022-03-30 01:28:41 --> Encrypt Class Initialized
INFO - 2022-03-30 01:28:41 --> Model "Patient_model" initialized
INFO - 2022-03-30 01:28:41 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 01:28:41 --> Model "Prefix_master" initialized
INFO - 2022-03-30 01:28:41 --> Model "Users_model" initialized
INFO - 2022-03-30 01:28:41 --> Model "Hospital_model" initialized
ERROR - 2022-03-30 01:28:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 01:28:41 --> Config Class Initialized
INFO - 2022-03-30 01:28:41 --> Hooks Class Initialized
DEBUG - 2022-03-30 01:28:41 --> UTF-8 Support Enabled
INFO - 2022-03-30 01:28:41 --> Utf8 Class Initialized
INFO - 2022-03-30 01:28:41 --> URI Class Initialized
INFO - 2022-03-30 01:28:41 --> Router Class Initialized
INFO - 2022-03-30 01:28:41 --> Output Class Initialized
INFO - 2022-03-30 01:28:41 --> Security Class Initialized
DEBUG - 2022-03-30 01:28:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 01:28:41 --> Input Class Initialized
INFO - 2022-03-30 01:28:41 --> Language Class Initialized
INFO - 2022-03-30 01:28:41 --> Loader Class Initialized
INFO - 2022-03-30 01:28:41 --> Helper loaded: url_helper
INFO - 2022-03-30 01:28:41 --> Helper loaded: form_helper
INFO - 2022-03-30 01:28:41 --> Helper loaded: common_helper
INFO - 2022-03-30 01:28:41 --> Database Driver Class Initialized
DEBUG - 2022-03-30 01:28:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 01:28:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 01:28:41 --> Controller Class Initialized
INFO - 2022-03-30 01:28:41 --> Form Validation Class Initialized
DEBUG - 2022-03-30 01:28:41 --> Encrypt Class Initialized
INFO - 2022-03-30 01:28:41 --> Model "Patient_model" initialized
INFO - 2022-03-30 01:28:41 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 01:28:41 --> Model "Prefix_master" initialized
INFO - 2022-03-30 01:28:41 --> Model "Users_model" initialized
INFO - 2022-03-30 01:28:41 --> Model "Hospital_model" initialized
INFO - 2022-03-30 01:28:41 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 01:28:42 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-30 01:28:42 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 01:28:42 --> Final output sent to browser
DEBUG - 2022-03-30 01:28:42 --> Total execution time: 0.0483
ERROR - 2022-03-30 01:28:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 01:28:49 --> Config Class Initialized
INFO - 2022-03-30 01:28:49 --> Hooks Class Initialized
DEBUG - 2022-03-30 01:28:49 --> UTF-8 Support Enabled
INFO - 2022-03-30 01:28:49 --> Utf8 Class Initialized
INFO - 2022-03-30 01:28:49 --> URI Class Initialized
INFO - 2022-03-30 01:28:49 --> Router Class Initialized
INFO - 2022-03-30 01:28:49 --> Output Class Initialized
INFO - 2022-03-30 01:28:49 --> Security Class Initialized
DEBUG - 2022-03-30 01:28:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 01:28:49 --> Input Class Initialized
INFO - 2022-03-30 01:28:49 --> Language Class Initialized
INFO - 2022-03-30 01:28:49 --> Loader Class Initialized
INFO - 2022-03-30 01:28:49 --> Helper loaded: url_helper
INFO - 2022-03-30 01:28:49 --> Helper loaded: form_helper
INFO - 2022-03-30 01:28:49 --> Helper loaded: common_helper
INFO - 2022-03-30 01:28:49 --> Database Driver Class Initialized
DEBUG - 2022-03-30 01:28:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 01:28:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 01:28:49 --> Controller Class Initialized
INFO - 2022-03-30 01:28:49 --> Form Validation Class Initialized
DEBUG - 2022-03-30 01:28:49 --> Encrypt Class Initialized
INFO - 2022-03-30 01:28:49 --> Model "Patient_model" initialized
INFO - 2022-03-30 01:28:49 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 01:28:49 --> Model "Referredby_model" initialized
INFO - 2022-03-30 01:28:49 --> Model "Prefix_master" initialized
INFO - 2022-03-30 01:28:49 --> Model "Hospital_model" initialized
INFO - 2022-03-30 01:28:49 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 01:28:49 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-30 01:28:49 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 01:28:49 --> Final output sent to browser
DEBUG - 2022-03-30 01:28:49 --> Total execution time: 0.5870
ERROR - 2022-03-30 01:28:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 01:28:59 --> Config Class Initialized
INFO - 2022-03-30 01:28:59 --> Hooks Class Initialized
DEBUG - 2022-03-30 01:28:59 --> UTF-8 Support Enabled
INFO - 2022-03-30 01:28:59 --> Utf8 Class Initialized
INFO - 2022-03-30 01:28:59 --> URI Class Initialized
INFO - 2022-03-30 01:28:59 --> Router Class Initialized
INFO - 2022-03-30 01:28:59 --> Output Class Initialized
INFO - 2022-03-30 01:28:59 --> Security Class Initialized
DEBUG - 2022-03-30 01:28:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 01:28:59 --> Input Class Initialized
INFO - 2022-03-30 01:28:59 --> Language Class Initialized
INFO - 2022-03-30 01:28:59 --> Loader Class Initialized
INFO - 2022-03-30 01:28:59 --> Helper loaded: url_helper
INFO - 2022-03-30 01:28:59 --> Helper loaded: form_helper
INFO - 2022-03-30 01:28:59 --> Helper loaded: common_helper
INFO - 2022-03-30 01:28:59 --> Database Driver Class Initialized
DEBUG - 2022-03-30 01:28:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 01:28:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 01:28:59 --> Controller Class Initialized
INFO - 2022-03-30 01:28:59 --> Form Validation Class Initialized
DEBUG - 2022-03-30 01:28:59 --> Encrypt Class Initialized
INFO - 2022-03-30 01:28:59 --> Model "Patient_model" initialized
INFO - 2022-03-30 01:28:59 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 01:28:59 --> Model "Prefix_master" initialized
INFO - 2022-03-30 01:28:59 --> Model "Users_model" initialized
INFO - 2022-03-30 01:28:59 --> Model "Hospital_model" initialized
INFO - 2022-03-30 01:28:59 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-30 01:29:00 --> Final output sent to browser
DEBUG - 2022-03-30 01:29:00 --> Total execution time: 0.9187
ERROR - 2022-03-30 01:35:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 01:35:51 --> Config Class Initialized
INFO - 2022-03-30 01:35:51 --> Hooks Class Initialized
DEBUG - 2022-03-30 01:35:51 --> UTF-8 Support Enabled
INFO - 2022-03-30 01:35:51 --> Utf8 Class Initialized
INFO - 2022-03-30 01:35:51 --> URI Class Initialized
INFO - 2022-03-30 01:35:51 --> Router Class Initialized
INFO - 2022-03-30 01:35:51 --> Output Class Initialized
INFO - 2022-03-30 01:35:51 --> Security Class Initialized
DEBUG - 2022-03-30 01:35:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 01:35:51 --> Input Class Initialized
INFO - 2022-03-30 01:35:51 --> Language Class Initialized
INFO - 2022-03-30 01:35:51 --> Loader Class Initialized
INFO - 2022-03-30 01:35:51 --> Helper loaded: url_helper
INFO - 2022-03-30 01:35:51 --> Helper loaded: form_helper
INFO - 2022-03-30 01:35:51 --> Helper loaded: common_helper
INFO - 2022-03-30 01:35:51 --> Database Driver Class Initialized
DEBUG - 2022-03-30 01:35:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 01:35:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 01:35:51 --> Controller Class Initialized
INFO - 2022-03-30 01:35:51 --> Form Validation Class Initialized
DEBUG - 2022-03-30 01:35:51 --> Encrypt Class Initialized
INFO - 2022-03-30 01:35:51 --> Model "Patient_model" initialized
INFO - 2022-03-30 01:35:51 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 01:35:51 --> Model "Referredby_model" initialized
INFO - 2022-03-30 01:35:51 --> Model "Prefix_master" initialized
INFO - 2022-03-30 01:35:51 --> Model "Hospital_model" initialized
INFO - 2022-03-30 01:35:51 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 01:35:51 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-30 01:35:51 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 01:35:51 --> Final output sent to browser
DEBUG - 2022-03-30 01:35:51 --> Total execution time: 0.0975
ERROR - 2022-03-30 01:35:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 01:35:59 --> Config Class Initialized
INFO - 2022-03-30 01:35:59 --> Hooks Class Initialized
DEBUG - 2022-03-30 01:35:59 --> UTF-8 Support Enabled
INFO - 2022-03-30 01:35:59 --> Utf8 Class Initialized
INFO - 2022-03-30 01:35:59 --> URI Class Initialized
INFO - 2022-03-30 01:35:59 --> Router Class Initialized
INFO - 2022-03-30 01:35:59 --> Output Class Initialized
INFO - 2022-03-30 01:35:59 --> Security Class Initialized
DEBUG - 2022-03-30 01:35:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 01:35:59 --> Input Class Initialized
INFO - 2022-03-30 01:35:59 --> Language Class Initialized
INFO - 2022-03-30 01:35:59 --> Loader Class Initialized
INFO - 2022-03-30 01:35:59 --> Helper loaded: url_helper
INFO - 2022-03-30 01:35:59 --> Helper loaded: form_helper
INFO - 2022-03-30 01:35:59 --> Helper loaded: common_helper
INFO - 2022-03-30 01:35:59 --> Database Driver Class Initialized
DEBUG - 2022-03-30 01:35:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 01:35:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 01:35:59 --> Controller Class Initialized
INFO - 2022-03-30 01:35:59 --> Form Validation Class Initialized
DEBUG - 2022-03-30 01:35:59 --> Encrypt Class Initialized
INFO - 2022-03-30 01:35:59 --> Model "Patient_model" initialized
INFO - 2022-03-30 01:35:59 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 01:35:59 --> Model "Referredby_model" initialized
INFO - 2022-03-30 01:35:59 --> Model "Prefix_master" initialized
INFO - 2022-03-30 01:35:59 --> Model "Hospital_model" initialized
ERROR - 2022-03-30 01:35:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 01:35:59 --> Config Class Initialized
INFO - 2022-03-30 01:35:59 --> Hooks Class Initialized
DEBUG - 2022-03-30 01:35:59 --> UTF-8 Support Enabled
INFO - 2022-03-30 01:35:59 --> Utf8 Class Initialized
INFO - 2022-03-30 01:35:59 --> URI Class Initialized
INFO - 2022-03-30 01:35:59 --> Router Class Initialized
INFO - 2022-03-30 01:35:59 --> Output Class Initialized
INFO - 2022-03-30 01:35:59 --> Security Class Initialized
DEBUG - 2022-03-30 01:35:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 01:35:59 --> Input Class Initialized
INFO - 2022-03-30 01:35:59 --> Language Class Initialized
INFO - 2022-03-30 01:35:59 --> Loader Class Initialized
INFO - 2022-03-30 01:35:59 --> Helper loaded: url_helper
INFO - 2022-03-30 01:35:59 --> Helper loaded: form_helper
INFO - 2022-03-30 01:35:59 --> Helper loaded: common_helper
INFO - 2022-03-30 01:35:59 --> Database Driver Class Initialized
DEBUG - 2022-03-30 01:35:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 01:35:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 01:35:59 --> Controller Class Initialized
INFO - 2022-03-30 01:35:59 --> Form Validation Class Initialized
DEBUG - 2022-03-30 01:35:59 --> Encrypt Class Initialized
INFO - 2022-03-30 01:35:59 --> Model "Patient_model" initialized
INFO - 2022-03-30 01:35:59 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 01:35:59 --> Model "Referredby_model" initialized
INFO - 2022-03-30 01:35:59 --> Model "Prefix_master" initialized
INFO - 2022-03-30 01:35:59 --> Model "Hospital_model" initialized
INFO - 2022-03-30 01:35:59 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 01:35:59 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-30 01:35:59 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 01:35:59 --> Final output sent to browser
DEBUG - 2022-03-30 01:35:59 --> Total execution time: 0.0256
ERROR - 2022-03-30 01:36:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 01:36:00 --> Config Class Initialized
INFO - 2022-03-30 01:36:00 --> Hooks Class Initialized
DEBUG - 2022-03-30 01:36:00 --> UTF-8 Support Enabled
INFO - 2022-03-30 01:36:00 --> Utf8 Class Initialized
INFO - 2022-03-30 01:36:00 --> URI Class Initialized
INFO - 2022-03-30 01:36:00 --> Router Class Initialized
INFO - 2022-03-30 01:36:00 --> Output Class Initialized
INFO - 2022-03-30 01:36:00 --> Security Class Initialized
DEBUG - 2022-03-30 01:36:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 01:36:00 --> Input Class Initialized
INFO - 2022-03-30 01:36:00 --> Language Class Initialized
INFO - 2022-03-30 01:36:00 --> Loader Class Initialized
INFO - 2022-03-30 01:36:00 --> Helper loaded: url_helper
INFO - 2022-03-30 01:36:00 --> Helper loaded: form_helper
INFO - 2022-03-30 01:36:00 --> Helper loaded: common_helper
INFO - 2022-03-30 01:36:00 --> Database Driver Class Initialized
DEBUG - 2022-03-30 01:36:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 01:36:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 01:36:00 --> Controller Class Initialized
INFO - 2022-03-30 01:36:00 --> Form Validation Class Initialized
DEBUG - 2022-03-30 01:36:00 --> Encrypt Class Initialized
INFO - 2022-03-30 01:36:00 --> Model "Patient_model" initialized
INFO - 2022-03-30 01:36:00 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 01:36:00 --> Model "Prefix_master" initialized
INFO - 2022-03-30 01:36:00 --> Model "Users_model" initialized
INFO - 2022-03-30 01:36:00 --> Model "Hospital_model" initialized
INFO - 2022-03-30 01:36:00 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 01:36:00 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-30 01:36:00 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 01:36:00 --> Final output sent to browser
DEBUG - 2022-03-30 01:36:00 --> Total execution time: 0.0410
ERROR - 2022-03-30 01:37:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 01:37:08 --> Config Class Initialized
INFO - 2022-03-30 01:37:08 --> Hooks Class Initialized
DEBUG - 2022-03-30 01:37:08 --> UTF-8 Support Enabled
INFO - 2022-03-30 01:37:08 --> Utf8 Class Initialized
INFO - 2022-03-30 01:37:08 --> URI Class Initialized
INFO - 2022-03-30 01:37:08 --> Router Class Initialized
INFO - 2022-03-30 01:37:08 --> Output Class Initialized
INFO - 2022-03-30 01:37:08 --> Security Class Initialized
DEBUG - 2022-03-30 01:37:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 01:37:08 --> Input Class Initialized
INFO - 2022-03-30 01:37:08 --> Language Class Initialized
INFO - 2022-03-30 01:37:08 --> Loader Class Initialized
INFO - 2022-03-30 01:37:08 --> Helper loaded: url_helper
INFO - 2022-03-30 01:37:08 --> Helper loaded: form_helper
INFO - 2022-03-30 01:37:08 --> Helper loaded: common_helper
INFO - 2022-03-30 01:37:08 --> Database Driver Class Initialized
DEBUG - 2022-03-30 01:37:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 01:37:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 01:37:08 --> Controller Class Initialized
INFO - 2022-03-30 01:37:08 --> Form Validation Class Initialized
DEBUG - 2022-03-30 01:37:08 --> Encrypt Class Initialized
INFO - 2022-03-30 01:37:08 --> Model "Patient_model" initialized
INFO - 2022-03-30 01:37:08 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 01:37:08 --> Model "Prefix_master" initialized
INFO - 2022-03-30 01:37:08 --> Model "Users_model" initialized
INFO - 2022-03-30 01:37:08 --> Model "Hospital_model" initialized
ERROR - 2022-03-30 01:37:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 01:37:09 --> Config Class Initialized
INFO - 2022-03-30 01:37:09 --> Hooks Class Initialized
DEBUG - 2022-03-30 01:37:09 --> UTF-8 Support Enabled
INFO - 2022-03-30 01:37:09 --> Utf8 Class Initialized
INFO - 2022-03-30 01:37:09 --> URI Class Initialized
INFO - 2022-03-30 01:37:09 --> Router Class Initialized
INFO - 2022-03-30 01:37:09 --> Output Class Initialized
INFO - 2022-03-30 01:37:09 --> Security Class Initialized
DEBUG - 2022-03-30 01:37:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 01:37:09 --> Input Class Initialized
INFO - 2022-03-30 01:37:09 --> Language Class Initialized
INFO - 2022-03-30 01:37:09 --> Loader Class Initialized
INFO - 2022-03-30 01:37:09 --> Helper loaded: url_helper
INFO - 2022-03-30 01:37:09 --> Helper loaded: form_helper
INFO - 2022-03-30 01:37:09 --> Helper loaded: common_helper
INFO - 2022-03-30 01:37:09 --> Database Driver Class Initialized
DEBUG - 2022-03-30 01:37:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 01:37:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 01:37:09 --> Controller Class Initialized
INFO - 2022-03-30 01:37:09 --> Form Validation Class Initialized
DEBUG - 2022-03-30 01:37:09 --> Encrypt Class Initialized
INFO - 2022-03-30 01:37:09 --> Model "Patient_model" initialized
INFO - 2022-03-30 01:37:09 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 01:37:09 --> Model "Prefix_master" initialized
INFO - 2022-03-30 01:37:09 --> Model "Users_model" initialized
INFO - 2022-03-30 01:37:09 --> Model "Hospital_model" initialized
INFO - 2022-03-30 01:37:09 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 01:37:09 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-30 01:37:09 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 01:37:09 --> Final output sent to browser
DEBUG - 2022-03-30 01:37:09 --> Total execution time: 0.0416
ERROR - 2022-03-30 01:37:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 01:37:38 --> Config Class Initialized
INFO - 2022-03-30 01:37:38 --> Hooks Class Initialized
DEBUG - 2022-03-30 01:37:38 --> UTF-8 Support Enabled
INFO - 2022-03-30 01:37:38 --> Utf8 Class Initialized
INFO - 2022-03-30 01:37:38 --> URI Class Initialized
INFO - 2022-03-30 01:37:38 --> Router Class Initialized
INFO - 2022-03-30 01:37:38 --> Output Class Initialized
INFO - 2022-03-30 01:37:38 --> Security Class Initialized
DEBUG - 2022-03-30 01:37:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 01:37:38 --> Input Class Initialized
INFO - 2022-03-30 01:37:38 --> Language Class Initialized
INFO - 2022-03-30 01:37:38 --> Loader Class Initialized
INFO - 2022-03-30 01:37:38 --> Helper loaded: url_helper
INFO - 2022-03-30 01:37:38 --> Helper loaded: form_helper
INFO - 2022-03-30 01:37:38 --> Helper loaded: common_helper
INFO - 2022-03-30 01:37:38 --> Database Driver Class Initialized
DEBUG - 2022-03-30 01:37:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 01:37:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 01:37:38 --> Controller Class Initialized
INFO - 2022-03-30 01:37:38 --> Form Validation Class Initialized
DEBUG - 2022-03-30 01:37:38 --> Encrypt Class Initialized
INFO - 2022-03-30 01:37:38 --> Model "Patient_model" initialized
INFO - 2022-03-30 01:37:38 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 01:37:38 --> Model "Referredby_model" initialized
INFO - 2022-03-30 01:37:38 --> Model "Prefix_master" initialized
INFO - 2022-03-30 01:37:38 --> Model "Hospital_model" initialized
INFO - 2022-03-30 01:37:38 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 01:37:38 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-30 01:37:38 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 01:37:38 --> Final output sent to browser
DEBUG - 2022-03-30 01:37:38 --> Total execution time: 0.0392
ERROR - 2022-03-30 01:37:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 01:37:52 --> Config Class Initialized
INFO - 2022-03-30 01:37:52 --> Hooks Class Initialized
DEBUG - 2022-03-30 01:37:52 --> UTF-8 Support Enabled
INFO - 2022-03-30 01:37:52 --> Utf8 Class Initialized
INFO - 2022-03-30 01:37:52 --> URI Class Initialized
INFO - 2022-03-30 01:37:52 --> Router Class Initialized
INFO - 2022-03-30 01:37:52 --> Output Class Initialized
INFO - 2022-03-30 01:37:52 --> Security Class Initialized
DEBUG - 2022-03-30 01:37:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 01:37:52 --> Input Class Initialized
INFO - 2022-03-30 01:37:52 --> Language Class Initialized
INFO - 2022-03-30 01:37:52 --> Loader Class Initialized
INFO - 2022-03-30 01:37:52 --> Helper loaded: url_helper
INFO - 2022-03-30 01:37:52 --> Helper loaded: form_helper
INFO - 2022-03-30 01:37:52 --> Helper loaded: common_helper
INFO - 2022-03-30 01:37:52 --> Database Driver Class Initialized
DEBUG - 2022-03-30 01:37:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 01:37:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 01:37:52 --> Controller Class Initialized
INFO - 2022-03-30 01:37:52 --> Form Validation Class Initialized
DEBUG - 2022-03-30 01:37:52 --> Encrypt Class Initialized
INFO - 2022-03-30 01:37:52 --> Model "Patient_model" initialized
INFO - 2022-03-30 01:37:52 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 01:37:52 --> Model "Referredby_model" initialized
INFO - 2022-03-30 01:37:52 --> Model "Prefix_master" initialized
INFO - 2022-03-30 01:37:52 --> Model "Hospital_model" initialized
ERROR - 2022-03-30 01:37:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 01:37:52 --> Config Class Initialized
INFO - 2022-03-30 01:37:52 --> Hooks Class Initialized
DEBUG - 2022-03-30 01:37:52 --> UTF-8 Support Enabled
INFO - 2022-03-30 01:37:52 --> Utf8 Class Initialized
INFO - 2022-03-30 01:37:52 --> URI Class Initialized
INFO - 2022-03-30 01:37:52 --> Router Class Initialized
INFO - 2022-03-30 01:37:52 --> Output Class Initialized
INFO - 2022-03-30 01:37:52 --> Security Class Initialized
DEBUG - 2022-03-30 01:37:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 01:37:52 --> Input Class Initialized
INFO - 2022-03-30 01:37:52 --> Language Class Initialized
INFO - 2022-03-30 01:37:52 --> Loader Class Initialized
INFO - 2022-03-30 01:37:52 --> Helper loaded: url_helper
INFO - 2022-03-30 01:37:52 --> Helper loaded: form_helper
INFO - 2022-03-30 01:37:52 --> Helper loaded: common_helper
INFO - 2022-03-30 01:37:52 --> Database Driver Class Initialized
DEBUG - 2022-03-30 01:37:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 01:37:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 01:37:52 --> Controller Class Initialized
INFO - 2022-03-30 01:37:52 --> Form Validation Class Initialized
DEBUG - 2022-03-30 01:37:52 --> Encrypt Class Initialized
INFO - 2022-03-30 01:37:52 --> Model "Patient_model" initialized
INFO - 2022-03-30 01:37:52 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 01:37:52 --> Model "Referredby_model" initialized
INFO - 2022-03-30 01:37:52 --> Model "Prefix_master" initialized
INFO - 2022-03-30 01:37:52 --> Model "Hospital_model" initialized
INFO - 2022-03-30 01:37:52 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 01:37:52 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-30 01:37:52 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 01:37:52 --> Final output sent to browser
DEBUG - 2022-03-30 01:37:52 --> Total execution time: 0.0447
ERROR - 2022-03-30 01:37:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 01:37:53 --> Config Class Initialized
INFO - 2022-03-30 01:37:53 --> Hooks Class Initialized
DEBUG - 2022-03-30 01:37:53 --> UTF-8 Support Enabled
INFO - 2022-03-30 01:37:53 --> Utf8 Class Initialized
INFO - 2022-03-30 01:37:53 --> URI Class Initialized
INFO - 2022-03-30 01:37:53 --> Router Class Initialized
INFO - 2022-03-30 01:37:53 --> Output Class Initialized
INFO - 2022-03-30 01:37:53 --> Security Class Initialized
DEBUG - 2022-03-30 01:37:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 01:37:53 --> Input Class Initialized
INFO - 2022-03-30 01:37:53 --> Language Class Initialized
INFO - 2022-03-30 01:37:53 --> Loader Class Initialized
INFO - 2022-03-30 01:37:53 --> Helper loaded: url_helper
INFO - 2022-03-30 01:37:53 --> Helper loaded: form_helper
INFO - 2022-03-30 01:37:53 --> Helper loaded: common_helper
INFO - 2022-03-30 01:37:53 --> Database Driver Class Initialized
DEBUG - 2022-03-30 01:37:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 01:37:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 01:37:53 --> Controller Class Initialized
INFO - 2022-03-30 01:37:53 --> Form Validation Class Initialized
DEBUG - 2022-03-30 01:37:53 --> Encrypt Class Initialized
INFO - 2022-03-30 01:37:53 --> Model "Patient_model" initialized
INFO - 2022-03-30 01:37:53 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 01:37:53 --> Model "Prefix_master" initialized
INFO - 2022-03-30 01:37:53 --> Model "Users_model" initialized
INFO - 2022-03-30 01:37:53 --> Model "Hospital_model" initialized
INFO - 2022-03-30 01:37:53 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 01:37:53 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-30 01:37:53 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 01:37:53 --> Final output sent to browser
DEBUG - 2022-03-30 01:37:53 --> Total execution time: 0.0384
ERROR - 2022-03-30 01:38:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 01:38:06 --> Config Class Initialized
INFO - 2022-03-30 01:38:06 --> Hooks Class Initialized
DEBUG - 2022-03-30 01:38:06 --> UTF-8 Support Enabled
INFO - 2022-03-30 01:38:06 --> Utf8 Class Initialized
INFO - 2022-03-30 01:38:06 --> URI Class Initialized
INFO - 2022-03-30 01:38:06 --> Router Class Initialized
INFO - 2022-03-30 01:38:06 --> Output Class Initialized
INFO - 2022-03-30 01:38:06 --> Security Class Initialized
DEBUG - 2022-03-30 01:38:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 01:38:06 --> Input Class Initialized
INFO - 2022-03-30 01:38:06 --> Language Class Initialized
INFO - 2022-03-30 01:38:06 --> Loader Class Initialized
INFO - 2022-03-30 01:38:06 --> Helper loaded: url_helper
INFO - 2022-03-30 01:38:06 --> Helper loaded: form_helper
INFO - 2022-03-30 01:38:06 --> Helper loaded: common_helper
INFO - 2022-03-30 01:38:06 --> Database Driver Class Initialized
DEBUG - 2022-03-30 01:38:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 01:38:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 01:38:06 --> Controller Class Initialized
INFO - 2022-03-30 01:38:06 --> Form Validation Class Initialized
DEBUG - 2022-03-30 01:38:06 --> Encrypt Class Initialized
INFO - 2022-03-30 01:38:06 --> Model "Patient_model" initialized
INFO - 2022-03-30 01:38:06 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 01:38:06 --> Model "Referredby_model" initialized
INFO - 2022-03-30 01:38:06 --> Model "Prefix_master" initialized
INFO - 2022-03-30 01:38:06 --> Model "Hospital_model" initialized
INFO - 2022-03-30 01:38:06 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 01:38:06 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-30 01:38:06 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 01:38:06 --> Final output sent to browser
DEBUG - 2022-03-30 01:38:06 --> Total execution time: 0.0320
ERROR - 2022-03-30 01:38:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 01:38:42 --> Config Class Initialized
INFO - 2022-03-30 01:38:42 --> Hooks Class Initialized
DEBUG - 2022-03-30 01:38:42 --> UTF-8 Support Enabled
INFO - 2022-03-30 01:38:42 --> Utf8 Class Initialized
INFO - 2022-03-30 01:38:42 --> URI Class Initialized
INFO - 2022-03-30 01:38:42 --> Router Class Initialized
INFO - 2022-03-30 01:38:42 --> Output Class Initialized
INFO - 2022-03-30 01:38:42 --> Security Class Initialized
DEBUG - 2022-03-30 01:38:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 01:38:42 --> Input Class Initialized
INFO - 2022-03-30 01:38:42 --> Language Class Initialized
INFO - 2022-03-30 01:38:42 --> Loader Class Initialized
INFO - 2022-03-30 01:38:42 --> Helper loaded: url_helper
INFO - 2022-03-30 01:38:42 --> Helper loaded: form_helper
INFO - 2022-03-30 01:38:42 --> Helper loaded: common_helper
INFO - 2022-03-30 01:38:42 --> Database Driver Class Initialized
DEBUG - 2022-03-30 01:38:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 01:38:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 01:38:42 --> Controller Class Initialized
INFO - 2022-03-30 01:38:42 --> Form Validation Class Initialized
DEBUG - 2022-03-30 01:38:42 --> Encrypt Class Initialized
INFO - 2022-03-30 01:38:42 --> Model "Patient_model" initialized
INFO - 2022-03-30 01:38:42 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 01:38:42 --> Model "Referredby_model" initialized
INFO - 2022-03-30 01:38:42 --> Model "Prefix_master" initialized
INFO - 2022-03-30 01:38:42 --> Model "Hospital_model" initialized
ERROR - 2022-03-30 01:38:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 01:38:42 --> Config Class Initialized
INFO - 2022-03-30 01:38:42 --> Hooks Class Initialized
DEBUG - 2022-03-30 01:38:42 --> UTF-8 Support Enabled
INFO - 2022-03-30 01:38:42 --> Utf8 Class Initialized
INFO - 2022-03-30 01:38:42 --> URI Class Initialized
INFO - 2022-03-30 01:38:42 --> Router Class Initialized
INFO - 2022-03-30 01:38:42 --> Output Class Initialized
INFO - 2022-03-30 01:38:42 --> Security Class Initialized
DEBUG - 2022-03-30 01:38:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 01:38:42 --> Input Class Initialized
INFO - 2022-03-30 01:38:42 --> Language Class Initialized
INFO - 2022-03-30 01:38:42 --> Loader Class Initialized
INFO - 2022-03-30 01:38:42 --> Helper loaded: url_helper
INFO - 2022-03-30 01:38:42 --> Helper loaded: form_helper
INFO - 2022-03-30 01:38:42 --> Helper loaded: common_helper
INFO - 2022-03-30 01:38:42 --> Database Driver Class Initialized
DEBUG - 2022-03-30 01:38:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 01:38:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 01:38:42 --> Controller Class Initialized
INFO - 2022-03-30 01:38:42 --> Form Validation Class Initialized
DEBUG - 2022-03-30 01:38:42 --> Encrypt Class Initialized
INFO - 2022-03-30 01:38:42 --> Model "Patient_model" initialized
INFO - 2022-03-30 01:38:42 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 01:38:42 --> Model "Referredby_model" initialized
INFO - 2022-03-30 01:38:42 --> Model "Prefix_master" initialized
INFO - 2022-03-30 01:38:42 --> Model "Hospital_model" initialized
INFO - 2022-03-30 01:38:42 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 01:38:42 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-30 01:38:42 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 01:38:42 --> Final output sent to browser
DEBUG - 2022-03-30 01:38:42 --> Total execution time: 0.0256
ERROR - 2022-03-30 01:38:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 01:38:43 --> Config Class Initialized
INFO - 2022-03-30 01:38:43 --> Hooks Class Initialized
DEBUG - 2022-03-30 01:38:43 --> UTF-8 Support Enabled
INFO - 2022-03-30 01:38:43 --> Utf8 Class Initialized
INFO - 2022-03-30 01:38:43 --> URI Class Initialized
INFO - 2022-03-30 01:38:43 --> Router Class Initialized
INFO - 2022-03-30 01:38:43 --> Output Class Initialized
INFO - 2022-03-30 01:38:43 --> Security Class Initialized
DEBUG - 2022-03-30 01:38:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 01:38:43 --> Input Class Initialized
INFO - 2022-03-30 01:38:43 --> Language Class Initialized
INFO - 2022-03-30 01:38:43 --> Loader Class Initialized
INFO - 2022-03-30 01:38:43 --> Helper loaded: url_helper
INFO - 2022-03-30 01:38:43 --> Helper loaded: form_helper
INFO - 2022-03-30 01:38:43 --> Helper loaded: common_helper
INFO - 2022-03-30 01:38:43 --> Database Driver Class Initialized
DEBUG - 2022-03-30 01:38:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 01:38:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 01:38:43 --> Controller Class Initialized
INFO - 2022-03-30 01:38:43 --> Form Validation Class Initialized
DEBUG - 2022-03-30 01:38:43 --> Encrypt Class Initialized
INFO - 2022-03-30 01:38:43 --> Model "Patient_model" initialized
INFO - 2022-03-30 01:38:43 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 01:38:43 --> Model "Prefix_master" initialized
INFO - 2022-03-30 01:38:43 --> Model "Users_model" initialized
INFO - 2022-03-30 01:38:43 --> Model "Hospital_model" initialized
INFO - 2022-03-30 01:38:43 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 01:38:43 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-30 01:38:43 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 01:38:43 --> Final output sent to browser
DEBUG - 2022-03-30 01:38:43 --> Total execution time: 0.0351
ERROR - 2022-03-30 01:39:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 01:39:14 --> Config Class Initialized
INFO - 2022-03-30 01:39:14 --> Hooks Class Initialized
DEBUG - 2022-03-30 01:39:14 --> UTF-8 Support Enabled
INFO - 2022-03-30 01:39:14 --> Utf8 Class Initialized
INFO - 2022-03-30 01:39:14 --> URI Class Initialized
INFO - 2022-03-30 01:39:14 --> Router Class Initialized
INFO - 2022-03-30 01:39:14 --> Output Class Initialized
INFO - 2022-03-30 01:39:14 --> Security Class Initialized
DEBUG - 2022-03-30 01:39:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 01:39:14 --> Input Class Initialized
INFO - 2022-03-30 01:39:14 --> Language Class Initialized
INFO - 2022-03-30 01:39:14 --> Loader Class Initialized
INFO - 2022-03-30 01:39:14 --> Helper loaded: url_helper
INFO - 2022-03-30 01:39:14 --> Helper loaded: form_helper
INFO - 2022-03-30 01:39:14 --> Helper loaded: common_helper
INFO - 2022-03-30 01:39:14 --> Database Driver Class Initialized
DEBUG - 2022-03-30 01:39:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 01:39:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 01:39:14 --> Controller Class Initialized
INFO - 2022-03-30 01:39:14 --> Form Validation Class Initialized
DEBUG - 2022-03-30 01:39:14 --> Encrypt Class Initialized
INFO - 2022-03-30 01:39:14 --> Model "Patient_model" initialized
INFO - 2022-03-30 01:39:14 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 01:39:14 --> Model "Prefix_master" initialized
INFO - 2022-03-30 01:39:14 --> Model "Users_model" initialized
INFO - 2022-03-30 01:39:14 --> Model "Hospital_model" initialized
ERROR - 2022-03-30 01:39:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 01:39:15 --> Config Class Initialized
INFO - 2022-03-30 01:39:15 --> Hooks Class Initialized
DEBUG - 2022-03-30 01:39:15 --> UTF-8 Support Enabled
INFO - 2022-03-30 01:39:15 --> Utf8 Class Initialized
INFO - 2022-03-30 01:39:15 --> URI Class Initialized
INFO - 2022-03-30 01:39:15 --> Router Class Initialized
INFO - 2022-03-30 01:39:15 --> Output Class Initialized
INFO - 2022-03-30 01:39:15 --> Security Class Initialized
DEBUG - 2022-03-30 01:39:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 01:39:15 --> Input Class Initialized
INFO - 2022-03-30 01:39:15 --> Language Class Initialized
INFO - 2022-03-30 01:39:15 --> Loader Class Initialized
INFO - 2022-03-30 01:39:15 --> Helper loaded: url_helper
INFO - 2022-03-30 01:39:15 --> Helper loaded: form_helper
INFO - 2022-03-30 01:39:15 --> Helper loaded: common_helper
INFO - 2022-03-30 01:39:15 --> Database Driver Class Initialized
DEBUG - 2022-03-30 01:39:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 01:39:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 01:39:15 --> Controller Class Initialized
INFO - 2022-03-30 01:39:15 --> Form Validation Class Initialized
DEBUG - 2022-03-30 01:39:15 --> Encrypt Class Initialized
INFO - 2022-03-30 01:39:15 --> Model "Patient_model" initialized
INFO - 2022-03-30 01:39:15 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 01:39:15 --> Model "Prefix_master" initialized
INFO - 2022-03-30 01:39:15 --> Model "Users_model" initialized
INFO - 2022-03-30 01:39:15 --> Model "Hospital_model" initialized
INFO - 2022-03-30 01:39:15 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 01:39:15 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-30 01:39:15 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 01:39:15 --> Final output sent to browser
DEBUG - 2022-03-30 01:39:15 --> Total execution time: 0.0439
ERROR - 2022-03-30 01:44:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 01:44:26 --> Config Class Initialized
INFO - 2022-03-30 01:44:26 --> Hooks Class Initialized
DEBUG - 2022-03-30 01:44:26 --> UTF-8 Support Enabled
INFO - 2022-03-30 01:44:26 --> Utf8 Class Initialized
INFO - 2022-03-30 01:44:26 --> URI Class Initialized
INFO - 2022-03-30 01:44:26 --> Router Class Initialized
INFO - 2022-03-30 01:44:26 --> Output Class Initialized
INFO - 2022-03-30 01:44:26 --> Security Class Initialized
DEBUG - 2022-03-30 01:44:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 01:44:26 --> Input Class Initialized
INFO - 2022-03-30 01:44:26 --> Language Class Initialized
INFO - 2022-03-30 01:44:26 --> Loader Class Initialized
INFO - 2022-03-30 01:44:26 --> Helper loaded: url_helper
INFO - 2022-03-30 01:44:26 --> Helper loaded: form_helper
INFO - 2022-03-30 01:44:26 --> Helper loaded: common_helper
INFO - 2022-03-30 01:44:26 --> Database Driver Class Initialized
DEBUG - 2022-03-30 01:44:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 01:44:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 01:44:26 --> Controller Class Initialized
INFO - 2022-03-30 01:44:26 --> Form Validation Class Initialized
DEBUG - 2022-03-30 01:44:26 --> Encrypt Class Initialized
INFO - 2022-03-30 01:44:26 --> Model "Patient_model" initialized
INFO - 2022-03-30 01:44:26 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 01:44:26 --> Model "Prefix_master" initialized
INFO - 2022-03-30 01:44:26 --> Model "Users_model" initialized
INFO - 2022-03-30 01:44:26 --> Model "Hospital_model" initialized
ERROR - 2022-03-30 01:44:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 01:44:27 --> Config Class Initialized
INFO - 2022-03-30 01:44:27 --> Hooks Class Initialized
DEBUG - 2022-03-30 01:44:27 --> UTF-8 Support Enabled
INFO - 2022-03-30 01:44:27 --> Utf8 Class Initialized
INFO - 2022-03-30 01:44:27 --> URI Class Initialized
INFO - 2022-03-30 01:44:27 --> Router Class Initialized
INFO - 2022-03-30 01:44:27 --> Output Class Initialized
INFO - 2022-03-30 01:44:27 --> Security Class Initialized
DEBUG - 2022-03-30 01:44:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 01:44:27 --> Input Class Initialized
INFO - 2022-03-30 01:44:27 --> Language Class Initialized
INFO - 2022-03-30 01:44:27 --> Loader Class Initialized
INFO - 2022-03-30 01:44:27 --> Helper loaded: url_helper
INFO - 2022-03-30 01:44:27 --> Helper loaded: form_helper
INFO - 2022-03-30 01:44:27 --> Helper loaded: common_helper
INFO - 2022-03-30 01:44:27 --> Database Driver Class Initialized
DEBUG - 2022-03-30 01:44:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 01:44:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 01:44:27 --> Controller Class Initialized
INFO - 2022-03-30 01:44:27 --> Form Validation Class Initialized
DEBUG - 2022-03-30 01:44:27 --> Encrypt Class Initialized
INFO - 2022-03-30 01:44:27 --> Model "Patient_model" initialized
INFO - 2022-03-30 01:44:27 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 01:44:27 --> Model "Prefix_master" initialized
INFO - 2022-03-30 01:44:27 --> Model "Users_model" initialized
INFO - 2022-03-30 01:44:27 --> Model "Hospital_model" initialized
INFO - 2022-03-30 01:44:27 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 01:44:27 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-30 01:44:27 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 01:44:27 --> Final output sent to browser
DEBUG - 2022-03-30 01:44:27 --> Total execution time: 0.0533
ERROR - 2022-03-30 01:44:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 01:44:59 --> Config Class Initialized
INFO - 2022-03-30 01:44:59 --> Hooks Class Initialized
DEBUG - 2022-03-30 01:44:59 --> UTF-8 Support Enabled
INFO - 2022-03-30 01:44:59 --> Utf8 Class Initialized
INFO - 2022-03-30 01:44:59 --> URI Class Initialized
INFO - 2022-03-30 01:44:59 --> Router Class Initialized
INFO - 2022-03-30 01:44:59 --> Output Class Initialized
INFO - 2022-03-30 01:44:59 --> Security Class Initialized
DEBUG - 2022-03-30 01:44:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 01:44:59 --> Input Class Initialized
INFO - 2022-03-30 01:44:59 --> Language Class Initialized
INFO - 2022-03-30 01:44:59 --> Loader Class Initialized
INFO - 2022-03-30 01:44:59 --> Helper loaded: url_helper
INFO - 2022-03-30 01:44:59 --> Helper loaded: form_helper
INFO - 2022-03-30 01:44:59 --> Helper loaded: common_helper
INFO - 2022-03-30 01:44:59 --> Database Driver Class Initialized
DEBUG - 2022-03-30 01:44:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 01:44:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 01:44:59 --> Controller Class Initialized
INFO - 2022-03-30 01:44:59 --> Form Validation Class Initialized
DEBUG - 2022-03-30 01:44:59 --> Encrypt Class Initialized
INFO - 2022-03-30 01:44:59 --> Model "Patient_model" initialized
INFO - 2022-03-30 01:44:59 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 01:44:59 --> Model "Referredby_model" initialized
INFO - 2022-03-30 01:44:59 --> Model "Prefix_master" initialized
INFO - 2022-03-30 01:44:59 --> Model "Hospital_model" initialized
INFO - 2022-03-30 01:44:59 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 01:44:59 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-30 01:44:59 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 01:44:59 --> Final output sent to browser
DEBUG - 2022-03-30 01:44:59 --> Total execution time: 0.0668
ERROR - 2022-03-30 01:45:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 01:45:07 --> Config Class Initialized
INFO - 2022-03-30 01:45:07 --> Hooks Class Initialized
DEBUG - 2022-03-30 01:45:07 --> UTF-8 Support Enabled
INFO - 2022-03-30 01:45:07 --> Utf8 Class Initialized
INFO - 2022-03-30 01:45:07 --> URI Class Initialized
INFO - 2022-03-30 01:45:07 --> Router Class Initialized
INFO - 2022-03-30 01:45:07 --> Output Class Initialized
INFO - 2022-03-30 01:45:07 --> Security Class Initialized
DEBUG - 2022-03-30 01:45:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 01:45:07 --> Input Class Initialized
INFO - 2022-03-30 01:45:07 --> Language Class Initialized
INFO - 2022-03-30 01:45:07 --> Loader Class Initialized
INFO - 2022-03-30 01:45:07 --> Helper loaded: url_helper
INFO - 2022-03-30 01:45:07 --> Helper loaded: form_helper
INFO - 2022-03-30 01:45:07 --> Helper loaded: common_helper
INFO - 2022-03-30 01:45:07 --> Database Driver Class Initialized
DEBUG - 2022-03-30 01:45:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 01:45:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 01:45:07 --> Controller Class Initialized
INFO - 2022-03-30 01:45:07 --> Form Validation Class Initialized
DEBUG - 2022-03-30 01:45:07 --> Encrypt Class Initialized
INFO - 2022-03-30 01:45:07 --> Model "Patient_model" initialized
INFO - 2022-03-30 01:45:07 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 01:45:07 --> Model "Prefix_master" initialized
INFO - 2022-03-30 01:45:07 --> Model "Users_model" initialized
INFO - 2022-03-30 01:45:07 --> Model "Hospital_model" initialized
INFO - 2022-03-30 01:45:07 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-30 01:45:08 --> Final output sent to browser
DEBUG - 2022-03-30 01:45:08 --> Total execution time: 0.9193
ERROR - 2022-03-30 01:45:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 01:45:59 --> Config Class Initialized
INFO - 2022-03-30 01:45:59 --> Hooks Class Initialized
DEBUG - 2022-03-30 01:45:59 --> UTF-8 Support Enabled
INFO - 2022-03-30 01:45:59 --> Utf8 Class Initialized
INFO - 2022-03-30 01:45:59 --> URI Class Initialized
INFO - 2022-03-30 01:45:59 --> Router Class Initialized
INFO - 2022-03-30 01:45:59 --> Output Class Initialized
INFO - 2022-03-30 01:45:59 --> Security Class Initialized
DEBUG - 2022-03-30 01:45:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 01:45:59 --> Input Class Initialized
INFO - 2022-03-30 01:45:59 --> Language Class Initialized
INFO - 2022-03-30 01:45:59 --> Loader Class Initialized
INFO - 2022-03-30 01:45:59 --> Helper loaded: url_helper
INFO - 2022-03-30 01:45:59 --> Helper loaded: form_helper
INFO - 2022-03-30 01:45:59 --> Helper loaded: common_helper
INFO - 2022-03-30 01:45:59 --> Database Driver Class Initialized
DEBUG - 2022-03-30 01:45:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 01:45:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 01:45:59 --> Controller Class Initialized
INFO - 2022-03-30 01:45:59 --> Form Validation Class Initialized
DEBUG - 2022-03-30 01:45:59 --> Encrypt Class Initialized
INFO - 2022-03-30 01:45:59 --> Model "Patient_model" initialized
INFO - 2022-03-30 01:45:59 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 01:45:59 --> Model "Referredby_model" initialized
INFO - 2022-03-30 01:45:59 --> Model "Prefix_master" initialized
INFO - 2022-03-30 01:45:59 --> Model "Hospital_model" initialized
INFO - 2022-03-30 01:45:59 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 01:45:59 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-30 01:45:59 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 01:45:59 --> Final output sent to browser
DEBUG - 2022-03-30 01:45:59 --> Total execution time: 0.0359
ERROR - 2022-03-30 01:46:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 01:46:09 --> Config Class Initialized
INFO - 2022-03-30 01:46:09 --> Hooks Class Initialized
DEBUG - 2022-03-30 01:46:09 --> UTF-8 Support Enabled
INFO - 2022-03-30 01:46:09 --> Utf8 Class Initialized
INFO - 2022-03-30 01:46:09 --> URI Class Initialized
INFO - 2022-03-30 01:46:09 --> Router Class Initialized
INFO - 2022-03-30 01:46:09 --> Output Class Initialized
INFO - 2022-03-30 01:46:09 --> Security Class Initialized
DEBUG - 2022-03-30 01:46:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 01:46:09 --> Input Class Initialized
INFO - 2022-03-30 01:46:09 --> Language Class Initialized
INFO - 2022-03-30 01:46:09 --> Loader Class Initialized
INFO - 2022-03-30 01:46:09 --> Helper loaded: url_helper
INFO - 2022-03-30 01:46:09 --> Helper loaded: form_helper
INFO - 2022-03-30 01:46:09 --> Helper loaded: common_helper
INFO - 2022-03-30 01:46:09 --> Database Driver Class Initialized
DEBUG - 2022-03-30 01:46:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 01:46:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 01:46:09 --> Controller Class Initialized
INFO - 2022-03-30 01:46:09 --> Form Validation Class Initialized
DEBUG - 2022-03-30 01:46:09 --> Encrypt Class Initialized
INFO - 2022-03-30 01:46:09 --> Model "Patient_model" initialized
INFO - 2022-03-30 01:46:09 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 01:46:09 --> Model "Referredby_model" initialized
INFO - 2022-03-30 01:46:09 --> Model "Prefix_master" initialized
INFO - 2022-03-30 01:46:09 --> Model "Hospital_model" initialized
ERROR - 2022-03-30 01:46:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 01:46:10 --> Config Class Initialized
INFO - 2022-03-30 01:46:10 --> Hooks Class Initialized
DEBUG - 2022-03-30 01:46:10 --> UTF-8 Support Enabled
INFO - 2022-03-30 01:46:10 --> Utf8 Class Initialized
INFO - 2022-03-30 01:46:10 --> URI Class Initialized
INFO - 2022-03-30 01:46:10 --> Router Class Initialized
INFO - 2022-03-30 01:46:10 --> Output Class Initialized
INFO - 2022-03-30 01:46:10 --> Security Class Initialized
DEBUG - 2022-03-30 01:46:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 01:46:10 --> Input Class Initialized
INFO - 2022-03-30 01:46:10 --> Language Class Initialized
INFO - 2022-03-30 01:46:10 --> Loader Class Initialized
INFO - 2022-03-30 01:46:10 --> Helper loaded: url_helper
INFO - 2022-03-30 01:46:10 --> Helper loaded: form_helper
INFO - 2022-03-30 01:46:10 --> Helper loaded: common_helper
INFO - 2022-03-30 01:46:10 --> Database Driver Class Initialized
DEBUG - 2022-03-30 01:46:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 01:46:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 01:46:10 --> Controller Class Initialized
INFO - 2022-03-30 01:46:10 --> Form Validation Class Initialized
DEBUG - 2022-03-30 01:46:10 --> Encrypt Class Initialized
INFO - 2022-03-30 01:46:10 --> Model "Patient_model" initialized
INFO - 2022-03-30 01:46:10 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 01:46:10 --> Model "Referredby_model" initialized
INFO - 2022-03-30 01:46:10 --> Model "Prefix_master" initialized
INFO - 2022-03-30 01:46:10 --> Model "Hospital_model" initialized
INFO - 2022-03-30 01:46:10 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 01:46:10 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-30 01:46:10 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 01:46:10 --> Final output sent to browser
DEBUG - 2022-03-30 01:46:10 --> Total execution time: 0.0225
ERROR - 2022-03-30 01:46:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 01:46:10 --> Config Class Initialized
INFO - 2022-03-30 01:46:10 --> Hooks Class Initialized
DEBUG - 2022-03-30 01:46:10 --> UTF-8 Support Enabled
INFO - 2022-03-30 01:46:10 --> Utf8 Class Initialized
INFO - 2022-03-30 01:46:10 --> URI Class Initialized
INFO - 2022-03-30 01:46:10 --> Router Class Initialized
INFO - 2022-03-30 01:46:10 --> Output Class Initialized
INFO - 2022-03-30 01:46:10 --> Security Class Initialized
DEBUG - 2022-03-30 01:46:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 01:46:10 --> Input Class Initialized
INFO - 2022-03-30 01:46:10 --> Language Class Initialized
INFO - 2022-03-30 01:46:10 --> Loader Class Initialized
INFO - 2022-03-30 01:46:10 --> Helper loaded: url_helper
INFO - 2022-03-30 01:46:10 --> Helper loaded: form_helper
INFO - 2022-03-30 01:46:10 --> Helper loaded: common_helper
INFO - 2022-03-30 01:46:10 --> Database Driver Class Initialized
DEBUG - 2022-03-30 01:46:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 01:46:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 01:46:10 --> Controller Class Initialized
INFO - 2022-03-30 01:46:10 --> Form Validation Class Initialized
DEBUG - 2022-03-30 01:46:10 --> Encrypt Class Initialized
INFO - 2022-03-30 01:46:10 --> Model "Patient_model" initialized
INFO - 2022-03-30 01:46:10 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 01:46:10 --> Model "Prefix_master" initialized
INFO - 2022-03-30 01:46:10 --> Model "Users_model" initialized
INFO - 2022-03-30 01:46:10 --> Model "Hospital_model" initialized
INFO - 2022-03-30 01:46:11 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 01:46:11 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-30 01:46:11 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 01:46:11 --> Final output sent to browser
DEBUG - 2022-03-30 01:46:11 --> Total execution time: 0.0336
ERROR - 2022-03-30 01:46:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 01:46:24 --> Config Class Initialized
INFO - 2022-03-30 01:46:24 --> Hooks Class Initialized
DEBUG - 2022-03-30 01:46:24 --> UTF-8 Support Enabled
INFO - 2022-03-30 01:46:24 --> Utf8 Class Initialized
INFO - 2022-03-30 01:46:24 --> URI Class Initialized
INFO - 2022-03-30 01:46:24 --> Router Class Initialized
INFO - 2022-03-30 01:46:24 --> Output Class Initialized
INFO - 2022-03-30 01:46:24 --> Security Class Initialized
DEBUG - 2022-03-30 01:46:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 01:46:24 --> Input Class Initialized
INFO - 2022-03-30 01:46:24 --> Language Class Initialized
INFO - 2022-03-30 01:46:24 --> Loader Class Initialized
INFO - 2022-03-30 01:46:24 --> Helper loaded: url_helper
INFO - 2022-03-30 01:46:24 --> Helper loaded: form_helper
INFO - 2022-03-30 01:46:24 --> Helper loaded: common_helper
INFO - 2022-03-30 01:46:24 --> Database Driver Class Initialized
DEBUG - 2022-03-30 01:46:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 01:46:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 01:46:24 --> Controller Class Initialized
INFO - 2022-03-30 01:46:24 --> Form Validation Class Initialized
DEBUG - 2022-03-30 01:46:24 --> Encrypt Class Initialized
INFO - 2022-03-30 01:46:24 --> Model "Patient_model" initialized
INFO - 2022-03-30 01:46:24 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 01:46:24 --> Model "Prefix_master" initialized
INFO - 2022-03-30 01:46:24 --> Model "Users_model" initialized
INFO - 2022-03-30 01:46:24 --> Model "Hospital_model" initialized
ERROR - 2022-03-30 01:46:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 01:46:24 --> Config Class Initialized
INFO - 2022-03-30 01:46:24 --> Hooks Class Initialized
DEBUG - 2022-03-30 01:46:24 --> UTF-8 Support Enabled
INFO - 2022-03-30 01:46:24 --> Utf8 Class Initialized
INFO - 2022-03-30 01:46:24 --> URI Class Initialized
INFO - 2022-03-30 01:46:24 --> Router Class Initialized
INFO - 2022-03-30 01:46:24 --> Output Class Initialized
INFO - 2022-03-30 01:46:24 --> Security Class Initialized
DEBUG - 2022-03-30 01:46:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 01:46:24 --> Input Class Initialized
INFO - 2022-03-30 01:46:24 --> Language Class Initialized
INFO - 2022-03-30 01:46:24 --> Loader Class Initialized
INFO - 2022-03-30 01:46:24 --> Helper loaded: url_helper
INFO - 2022-03-30 01:46:24 --> Helper loaded: form_helper
INFO - 2022-03-30 01:46:24 --> Helper loaded: common_helper
INFO - 2022-03-30 01:46:24 --> Database Driver Class Initialized
DEBUG - 2022-03-30 01:46:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 01:46:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 01:46:24 --> Controller Class Initialized
INFO - 2022-03-30 01:46:24 --> Form Validation Class Initialized
DEBUG - 2022-03-30 01:46:24 --> Encrypt Class Initialized
INFO - 2022-03-30 01:46:24 --> Model "Patient_model" initialized
INFO - 2022-03-30 01:46:24 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 01:46:24 --> Model "Prefix_master" initialized
INFO - 2022-03-30 01:46:24 --> Model "Users_model" initialized
INFO - 2022-03-30 01:46:24 --> Model "Hospital_model" initialized
INFO - 2022-03-30 01:46:24 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 01:46:24 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-30 01:46:24 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 01:46:24 --> Final output sent to browser
DEBUG - 2022-03-30 01:46:24 --> Total execution time: 0.0353
ERROR - 2022-03-30 01:46:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 01:46:28 --> Config Class Initialized
INFO - 2022-03-30 01:46:28 --> Hooks Class Initialized
DEBUG - 2022-03-30 01:46:28 --> UTF-8 Support Enabled
INFO - 2022-03-30 01:46:28 --> Utf8 Class Initialized
INFO - 2022-03-30 01:46:28 --> URI Class Initialized
INFO - 2022-03-30 01:46:28 --> Router Class Initialized
INFO - 2022-03-30 01:46:28 --> Output Class Initialized
INFO - 2022-03-30 01:46:28 --> Security Class Initialized
DEBUG - 2022-03-30 01:46:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 01:46:28 --> Input Class Initialized
INFO - 2022-03-30 01:46:28 --> Language Class Initialized
INFO - 2022-03-30 01:46:28 --> Loader Class Initialized
INFO - 2022-03-30 01:46:28 --> Helper loaded: url_helper
INFO - 2022-03-30 01:46:28 --> Helper loaded: form_helper
INFO - 2022-03-30 01:46:28 --> Helper loaded: common_helper
INFO - 2022-03-30 01:46:28 --> Database Driver Class Initialized
DEBUG - 2022-03-30 01:46:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 01:46:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 01:46:28 --> Controller Class Initialized
INFO - 2022-03-30 01:46:28 --> Form Validation Class Initialized
DEBUG - 2022-03-30 01:46:28 --> Encrypt Class Initialized
INFO - 2022-03-30 01:46:28 --> Model "Patient_model" initialized
INFO - 2022-03-30 01:46:28 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 01:46:28 --> Model "Referredby_model" initialized
INFO - 2022-03-30 01:46:28 --> Model "Prefix_master" initialized
INFO - 2022-03-30 01:46:28 --> Model "Hospital_model" initialized
INFO - 2022-03-30 01:46:28 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 01:46:28 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-30 01:46:28 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 01:46:28 --> Final output sent to browser
DEBUG - 2022-03-30 01:46:28 --> Total execution time: 0.0526
ERROR - 2022-03-30 01:46:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 01:46:40 --> Config Class Initialized
INFO - 2022-03-30 01:46:40 --> Hooks Class Initialized
DEBUG - 2022-03-30 01:46:40 --> UTF-8 Support Enabled
INFO - 2022-03-30 01:46:40 --> Utf8 Class Initialized
INFO - 2022-03-30 01:46:40 --> URI Class Initialized
INFO - 2022-03-30 01:46:40 --> Router Class Initialized
INFO - 2022-03-30 01:46:40 --> Output Class Initialized
INFO - 2022-03-30 01:46:40 --> Security Class Initialized
DEBUG - 2022-03-30 01:46:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 01:46:40 --> Input Class Initialized
INFO - 2022-03-30 01:46:40 --> Language Class Initialized
INFO - 2022-03-30 01:46:40 --> Loader Class Initialized
INFO - 2022-03-30 01:46:40 --> Helper loaded: url_helper
INFO - 2022-03-30 01:46:40 --> Helper loaded: form_helper
INFO - 2022-03-30 01:46:40 --> Helper loaded: common_helper
INFO - 2022-03-30 01:46:40 --> Database Driver Class Initialized
DEBUG - 2022-03-30 01:46:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 01:46:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 01:46:40 --> Controller Class Initialized
INFO - 2022-03-30 01:46:40 --> Form Validation Class Initialized
DEBUG - 2022-03-30 01:46:40 --> Encrypt Class Initialized
INFO - 2022-03-30 01:46:40 --> Model "Patient_model" initialized
INFO - 2022-03-30 01:46:40 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 01:46:40 --> Model "Prefix_master" initialized
INFO - 2022-03-30 01:46:40 --> Model "Users_model" initialized
INFO - 2022-03-30 01:46:40 --> Model "Hospital_model" initialized
INFO - 2022-03-30 01:46:40 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-30 01:46:41 --> Final output sent to browser
DEBUG - 2022-03-30 01:46:41 --> Total execution time: 0.5927
ERROR - 2022-03-30 02:11:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 02:11:46 --> Config Class Initialized
INFO - 2022-03-30 02:11:46 --> Hooks Class Initialized
DEBUG - 2022-03-30 02:11:46 --> UTF-8 Support Enabled
INFO - 2022-03-30 02:11:46 --> Utf8 Class Initialized
INFO - 2022-03-30 02:11:46 --> URI Class Initialized
DEBUG - 2022-03-30 02:11:46 --> No URI present. Default controller set.
INFO - 2022-03-30 02:11:46 --> Router Class Initialized
INFO - 2022-03-30 02:11:46 --> Output Class Initialized
INFO - 2022-03-30 02:11:46 --> Security Class Initialized
DEBUG - 2022-03-30 02:11:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 02:11:46 --> Input Class Initialized
INFO - 2022-03-30 02:11:46 --> Language Class Initialized
INFO - 2022-03-30 02:11:46 --> Loader Class Initialized
INFO - 2022-03-30 02:11:46 --> Helper loaded: url_helper
INFO - 2022-03-30 02:11:46 --> Helper loaded: form_helper
INFO - 2022-03-30 02:11:46 --> Helper loaded: common_helper
INFO - 2022-03-30 02:11:46 --> Database Driver Class Initialized
DEBUG - 2022-03-30 02:11:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 02:11:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 02:11:46 --> Controller Class Initialized
INFO - 2022-03-30 02:11:46 --> Form Validation Class Initialized
DEBUG - 2022-03-30 02:11:46 --> Encrypt Class Initialized
DEBUG - 2022-03-30 02:11:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-30 02:11:46 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-30 02:11:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 02:11:46 --> Config Class Initialized
INFO - 2022-03-30 02:11:46 --> Hooks Class Initialized
DEBUG - 2022-03-30 02:11:46 --> UTF-8 Support Enabled
INFO - 2022-03-30 02:11:46 --> Utf8 Class Initialized
INFO - 2022-03-30 02:11:46 --> URI Class Initialized
DEBUG - 2022-03-30 02:11:46 --> No URI present. Default controller set.
INFO - 2022-03-30 02:11:46 --> Router Class Initialized
INFO - 2022-03-30 02:11:46 --> Output Class Initialized
INFO - 2022-03-30 02:11:46 --> Security Class Initialized
DEBUG - 2022-03-30 02:11:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 02:11:46 --> Input Class Initialized
INFO - 2022-03-30 02:11:46 --> Language Class Initialized
INFO - 2022-03-30 02:11:46 --> Loader Class Initialized
INFO - 2022-03-30 02:11:46 --> Helper loaded: url_helper
INFO - 2022-03-30 02:11:46 --> Email Class Initialized
INFO - 2022-03-30 02:11:46 --> Helper loaded: form_helper
INFO - 2022-03-30 02:11:46 --> Helper loaded: common_helper
INFO - 2022-03-30 02:11:46 --> Database Driver Class Initialized
INFO - 2022-03-30 02:11:46 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-30 02:11:46 --> Calendar Class Initialized
INFO - 2022-03-30 02:11:46 --> Model "Login_model" initialized
INFO - 2022-03-30 02:11:46 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-30 02:11:46 --> Final output sent to browser
DEBUG - 2022-03-30 02:11:46 --> Total execution time: 0.0620
DEBUG - 2022-03-30 02:11:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 02:11:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 02:11:46 --> Controller Class Initialized
INFO - 2022-03-30 02:11:46 --> Form Validation Class Initialized
DEBUG - 2022-03-30 02:11:46 --> Encrypt Class Initialized
DEBUG - 2022-03-30 02:11:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-30 02:11:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-30 02:11:46 --> Email Class Initialized
INFO - 2022-03-30 02:11:46 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-30 02:11:46 --> Calendar Class Initialized
INFO - 2022-03-30 02:11:46 --> Model "Login_model" initialized
INFO - 2022-03-30 02:11:46 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-30 02:11:46 --> Final output sent to browser
DEBUG - 2022-03-30 02:11:46 --> Total execution time: 0.0079
ERROR - 2022-03-30 02:11:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 02:11:47 --> Config Class Initialized
INFO - 2022-03-30 02:11:47 --> Hooks Class Initialized
DEBUG - 2022-03-30 02:11:47 --> UTF-8 Support Enabled
INFO - 2022-03-30 02:11:47 --> Utf8 Class Initialized
INFO - 2022-03-30 02:11:47 --> URI Class Initialized
DEBUG - 2022-03-30 02:11:47 --> No URI present. Default controller set.
INFO - 2022-03-30 02:11:47 --> Router Class Initialized
INFO - 2022-03-30 02:11:47 --> Output Class Initialized
INFO - 2022-03-30 02:11:47 --> Security Class Initialized
DEBUG - 2022-03-30 02:11:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 02:11:47 --> Input Class Initialized
INFO - 2022-03-30 02:11:47 --> Language Class Initialized
INFO - 2022-03-30 02:11:47 --> Loader Class Initialized
INFO - 2022-03-30 02:11:47 --> Helper loaded: url_helper
INFO - 2022-03-30 02:11:47 --> Helper loaded: form_helper
INFO - 2022-03-30 02:11:47 --> Helper loaded: common_helper
INFO - 2022-03-30 02:11:47 --> Database Driver Class Initialized
DEBUG - 2022-03-30 02:11:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 02:11:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 02:11:47 --> Controller Class Initialized
INFO - 2022-03-30 02:11:47 --> Form Validation Class Initialized
DEBUG - 2022-03-30 02:11:47 --> Encrypt Class Initialized
DEBUG - 2022-03-30 02:11:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-30 02:11:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-30 02:11:47 --> Email Class Initialized
INFO - 2022-03-30 02:11:47 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-30 02:11:47 --> Calendar Class Initialized
INFO - 2022-03-30 02:11:47 --> Model "Login_model" initialized
INFO - 2022-03-30 02:11:47 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-30 02:11:47 --> Final output sent to browser
DEBUG - 2022-03-30 02:11:47 --> Total execution time: 0.0125
ERROR - 2022-03-30 02:11:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 02:11:50 --> Config Class Initialized
INFO - 2022-03-30 02:11:50 --> Hooks Class Initialized
DEBUG - 2022-03-30 02:11:50 --> UTF-8 Support Enabled
INFO - 2022-03-30 02:11:50 --> Utf8 Class Initialized
INFO - 2022-03-30 02:11:50 --> URI Class Initialized
INFO - 2022-03-30 02:11:50 --> Router Class Initialized
INFO - 2022-03-30 02:11:50 --> Output Class Initialized
INFO - 2022-03-30 02:11:50 --> Security Class Initialized
DEBUG - 2022-03-30 02:11:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 02:11:50 --> Input Class Initialized
INFO - 2022-03-30 02:11:50 --> Language Class Initialized
INFO - 2022-03-30 02:11:50 --> Loader Class Initialized
INFO - 2022-03-30 02:11:50 --> Helper loaded: url_helper
INFO - 2022-03-30 02:11:50 --> Helper loaded: form_helper
INFO - 2022-03-30 02:11:50 --> Helper loaded: common_helper
INFO - 2022-03-30 02:11:50 --> Database Driver Class Initialized
DEBUG - 2022-03-30 02:11:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 02:11:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 02:11:50 --> Controller Class Initialized
INFO - 2022-03-30 02:11:50 --> Form Validation Class Initialized
DEBUG - 2022-03-30 02:11:50 --> Encrypt Class Initialized
DEBUG - 2022-03-30 02:11:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-30 02:11:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-30 02:11:50 --> Email Class Initialized
INFO - 2022-03-30 02:11:50 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-30 02:11:50 --> Calendar Class Initialized
INFO - 2022-03-30 02:11:50 --> Model "Login_model" initialized
INFO - 2022-03-30 02:11:50 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-03-30 02:11:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 02:11:50 --> Config Class Initialized
INFO - 2022-03-30 02:11:50 --> Hooks Class Initialized
DEBUG - 2022-03-30 02:11:50 --> UTF-8 Support Enabled
INFO - 2022-03-30 02:11:50 --> Utf8 Class Initialized
INFO - 2022-03-30 02:11:50 --> URI Class Initialized
INFO - 2022-03-30 02:11:50 --> Router Class Initialized
INFO - 2022-03-30 02:11:50 --> Output Class Initialized
INFO - 2022-03-30 02:11:50 --> Security Class Initialized
DEBUG - 2022-03-30 02:11:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 02:11:50 --> Input Class Initialized
INFO - 2022-03-30 02:11:50 --> Language Class Initialized
INFO - 2022-03-30 02:11:50 --> Loader Class Initialized
INFO - 2022-03-30 02:11:50 --> Helper loaded: url_helper
INFO - 2022-03-30 02:11:50 --> Helper loaded: form_helper
INFO - 2022-03-30 02:11:50 --> Helper loaded: common_helper
INFO - 2022-03-30 02:11:50 --> Database Driver Class Initialized
DEBUG - 2022-03-30 02:11:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 02:11:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 02:11:50 --> Controller Class Initialized
INFO - 2022-03-30 02:11:50 --> Form Validation Class Initialized
DEBUG - 2022-03-30 02:11:50 --> Encrypt Class Initialized
INFO - 2022-03-30 02:11:50 --> Model "Login_model" initialized
INFO - 2022-03-30 02:11:50 --> Model "Dashboard_model" initialized
INFO - 2022-03-30 02:11:50 --> Model "Case_model" initialized
INFO - 2022-03-30 02:11:59 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 02:12:10 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2022-03-30 02:12:10 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 02:12:10 --> Final output sent to browser
DEBUG - 2022-03-30 02:12:10 --> Total execution time: 19.8358
ERROR - 2022-03-30 02:12:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 02:12:19 --> Config Class Initialized
INFO - 2022-03-30 02:12:19 --> Hooks Class Initialized
DEBUG - 2022-03-30 02:12:19 --> UTF-8 Support Enabled
INFO - 2022-03-30 02:12:19 --> Utf8 Class Initialized
INFO - 2022-03-30 02:12:19 --> URI Class Initialized
INFO - 2022-03-30 02:12:19 --> Router Class Initialized
INFO - 2022-03-30 02:12:19 --> Output Class Initialized
INFO - 2022-03-30 02:12:19 --> Security Class Initialized
DEBUG - 2022-03-30 02:12:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 02:12:19 --> Input Class Initialized
INFO - 2022-03-30 02:12:19 --> Language Class Initialized
INFO - 2022-03-30 02:12:19 --> Loader Class Initialized
INFO - 2022-03-30 02:12:19 --> Helper loaded: url_helper
INFO - 2022-03-30 02:12:19 --> Helper loaded: form_helper
INFO - 2022-03-30 02:12:19 --> Helper loaded: common_helper
INFO - 2022-03-30 02:12:19 --> Database Driver Class Initialized
DEBUG - 2022-03-30 02:12:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 02:12:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 02:12:19 --> Controller Class Initialized
INFO - 2022-03-30 02:12:19 --> Form Validation Class Initialized
DEBUG - 2022-03-30 02:12:19 --> Encrypt Class Initialized
INFO - 2022-03-30 02:12:19 --> Model "Patient_model" initialized
INFO - 2022-03-30 02:12:19 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 02:12:19 --> Model "Referredby_model" initialized
INFO - 2022-03-30 02:12:19 --> Model "Prefix_master" initialized
INFO - 2022-03-30 02:12:19 --> Model "Hospital_model" initialized
INFO - 2022-03-30 02:12:19 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 02:12:25 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-30 02:12:25 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 02:12:27 --> Final output sent to browser
DEBUG - 2022-03-30 02:12:27 --> Total execution time: 6.1076
ERROR - 2022-03-30 02:12:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 02:12:49 --> Config Class Initialized
INFO - 2022-03-30 02:12:49 --> Hooks Class Initialized
DEBUG - 2022-03-30 02:12:49 --> UTF-8 Support Enabled
INFO - 2022-03-30 02:12:49 --> Utf8 Class Initialized
INFO - 2022-03-30 02:12:49 --> URI Class Initialized
DEBUG - 2022-03-30 02:12:49 --> No URI present. Default controller set.
INFO - 2022-03-30 02:12:49 --> Router Class Initialized
INFO - 2022-03-30 02:12:49 --> Output Class Initialized
INFO - 2022-03-30 02:12:49 --> Security Class Initialized
DEBUG - 2022-03-30 02:12:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 02:12:49 --> Input Class Initialized
INFO - 2022-03-30 02:12:49 --> Language Class Initialized
INFO - 2022-03-30 02:12:49 --> Loader Class Initialized
INFO - 2022-03-30 02:12:49 --> Helper loaded: url_helper
INFO - 2022-03-30 02:12:49 --> Helper loaded: form_helper
INFO - 2022-03-30 02:12:49 --> Helper loaded: common_helper
INFO - 2022-03-30 02:12:49 --> Database Driver Class Initialized
DEBUG - 2022-03-30 02:12:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 02:12:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 02:12:49 --> Controller Class Initialized
INFO - 2022-03-30 02:12:49 --> Form Validation Class Initialized
DEBUG - 2022-03-30 02:12:49 --> Encrypt Class Initialized
DEBUG - 2022-03-30 02:12:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-30 02:12:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-30 02:12:49 --> Email Class Initialized
INFO - 2022-03-30 02:12:49 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-30 02:12:49 --> Calendar Class Initialized
INFO - 2022-03-30 02:12:49 --> Model "Login_model" initialized
INFO - 2022-03-30 02:12:49 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-30 02:12:49 --> Final output sent to browser
DEBUG - 2022-03-30 02:12:49 --> Total execution time: 0.0063
ERROR - 2022-03-30 02:20:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 02:20:05 --> Config Class Initialized
INFO - 2022-03-30 02:20:05 --> Hooks Class Initialized
DEBUG - 2022-03-30 02:20:05 --> UTF-8 Support Enabled
INFO - 2022-03-30 02:20:05 --> Utf8 Class Initialized
INFO - 2022-03-30 02:20:05 --> URI Class Initialized
INFO - 2022-03-30 02:20:05 --> Router Class Initialized
INFO - 2022-03-30 02:20:05 --> Output Class Initialized
INFO - 2022-03-30 02:20:05 --> Security Class Initialized
DEBUG - 2022-03-30 02:20:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 02:20:05 --> Input Class Initialized
INFO - 2022-03-30 02:20:05 --> Language Class Initialized
INFO - 2022-03-30 02:20:05 --> Loader Class Initialized
INFO - 2022-03-30 02:20:05 --> Helper loaded: url_helper
INFO - 2022-03-30 02:20:05 --> Helper loaded: form_helper
INFO - 2022-03-30 02:20:05 --> Helper loaded: common_helper
INFO - 2022-03-30 02:20:05 --> Database Driver Class Initialized
DEBUG - 2022-03-30 02:20:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 02:20:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 02:20:05 --> Controller Class Initialized
INFO - 2022-03-30 02:20:05 --> Form Validation Class Initialized
DEBUG - 2022-03-30 02:20:05 --> Encrypt Class Initialized
INFO - 2022-03-30 02:20:05 --> Model "Patient_model" initialized
INFO - 2022-03-30 02:20:05 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 02:20:05 --> Model "Referredby_model" initialized
INFO - 2022-03-30 02:20:05 --> Model "Prefix_master" initialized
INFO - 2022-03-30 02:20:05 --> Model "Hospital_model" initialized
INFO - 2022-03-30 02:20:05 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 02:20:05 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-30 02:20:05 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 02:20:05 --> Final output sent to browser
DEBUG - 2022-03-30 02:20:05 --> Total execution time: 0.0897
ERROR - 2022-03-30 02:22:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 02:22:58 --> Config Class Initialized
INFO - 2022-03-30 02:22:58 --> Hooks Class Initialized
DEBUG - 2022-03-30 02:22:58 --> UTF-8 Support Enabled
INFO - 2022-03-30 02:22:58 --> Utf8 Class Initialized
INFO - 2022-03-30 02:22:58 --> URI Class Initialized
INFO - 2022-03-30 02:22:58 --> Router Class Initialized
INFO - 2022-03-30 02:22:58 --> Output Class Initialized
INFO - 2022-03-30 02:22:58 --> Security Class Initialized
DEBUG - 2022-03-30 02:22:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 02:22:58 --> Input Class Initialized
INFO - 2022-03-30 02:22:58 --> Language Class Initialized
INFO - 2022-03-30 02:22:58 --> Loader Class Initialized
INFO - 2022-03-30 02:22:58 --> Helper loaded: url_helper
INFO - 2022-03-30 02:22:58 --> Helper loaded: form_helper
INFO - 2022-03-30 02:22:58 --> Helper loaded: common_helper
INFO - 2022-03-30 02:22:58 --> Database Driver Class Initialized
DEBUG - 2022-03-30 02:22:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 02:22:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 02:22:58 --> Controller Class Initialized
INFO - 2022-03-30 02:22:58 --> Form Validation Class Initialized
DEBUG - 2022-03-30 02:22:58 --> Encrypt Class Initialized
INFO - 2022-03-30 02:22:58 --> Model "Patient_model" initialized
INFO - 2022-03-30 02:22:58 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 02:22:58 --> Model "Referredby_model" initialized
INFO - 2022-03-30 02:22:58 --> Model "Prefix_master" initialized
INFO - 2022-03-30 02:22:58 --> Model "Hospital_model" initialized
ERROR - 2022-03-30 02:22:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 02:22:58 --> Config Class Initialized
INFO - 2022-03-30 02:22:58 --> Hooks Class Initialized
DEBUG - 2022-03-30 02:22:58 --> UTF-8 Support Enabled
INFO - 2022-03-30 02:22:58 --> Utf8 Class Initialized
INFO - 2022-03-30 02:22:58 --> URI Class Initialized
INFO - 2022-03-30 02:22:58 --> Router Class Initialized
INFO - 2022-03-30 02:22:58 --> Output Class Initialized
INFO - 2022-03-30 02:22:58 --> Security Class Initialized
DEBUG - 2022-03-30 02:22:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 02:22:58 --> Input Class Initialized
INFO - 2022-03-30 02:22:58 --> Language Class Initialized
INFO - 2022-03-30 02:22:58 --> Loader Class Initialized
INFO - 2022-03-30 02:22:58 --> Helper loaded: url_helper
INFO - 2022-03-30 02:22:58 --> Helper loaded: form_helper
INFO - 2022-03-30 02:22:58 --> Helper loaded: common_helper
INFO - 2022-03-30 02:22:58 --> Database Driver Class Initialized
DEBUG - 2022-03-30 02:22:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 02:22:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 02:22:58 --> Controller Class Initialized
INFO - 2022-03-30 02:22:58 --> Form Validation Class Initialized
DEBUG - 2022-03-30 02:22:58 --> Encrypt Class Initialized
INFO - 2022-03-30 02:22:58 --> Model "Patient_model" initialized
INFO - 2022-03-30 02:22:58 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 02:22:58 --> Model "Referredby_model" initialized
INFO - 2022-03-30 02:22:58 --> Model "Prefix_master" initialized
INFO - 2022-03-30 02:22:58 --> Model "Hospital_model" initialized
INFO - 2022-03-30 02:22:58 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 02:22:58 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-30 02:22:58 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 02:22:58 --> Final output sent to browser
DEBUG - 2022-03-30 02:22:58 --> Total execution time: 0.0303
ERROR - 2022-03-30 02:22:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 02:22:59 --> Config Class Initialized
INFO - 2022-03-30 02:22:59 --> Hooks Class Initialized
DEBUG - 2022-03-30 02:22:59 --> UTF-8 Support Enabled
INFO - 2022-03-30 02:22:59 --> Utf8 Class Initialized
INFO - 2022-03-30 02:22:59 --> URI Class Initialized
INFO - 2022-03-30 02:22:59 --> Router Class Initialized
INFO - 2022-03-30 02:22:59 --> Output Class Initialized
INFO - 2022-03-30 02:22:59 --> Security Class Initialized
DEBUG - 2022-03-30 02:22:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 02:22:59 --> Input Class Initialized
INFO - 2022-03-30 02:22:59 --> Language Class Initialized
INFO - 2022-03-30 02:22:59 --> Loader Class Initialized
INFO - 2022-03-30 02:22:59 --> Helper loaded: url_helper
INFO - 2022-03-30 02:22:59 --> Helper loaded: form_helper
INFO - 2022-03-30 02:22:59 --> Helper loaded: common_helper
INFO - 2022-03-30 02:22:59 --> Database Driver Class Initialized
DEBUG - 2022-03-30 02:22:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 02:22:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 02:22:59 --> Controller Class Initialized
INFO - 2022-03-30 02:22:59 --> Form Validation Class Initialized
DEBUG - 2022-03-30 02:22:59 --> Encrypt Class Initialized
INFO - 2022-03-30 02:22:59 --> Model "Patient_model" initialized
INFO - 2022-03-30 02:22:59 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 02:22:59 --> Model "Prefix_master" initialized
INFO - 2022-03-30 02:22:59 --> Model "Users_model" initialized
INFO - 2022-03-30 02:22:59 --> Model "Hospital_model" initialized
INFO - 2022-03-30 02:22:59 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 02:22:59 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-30 02:22:59 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 02:22:59 --> Final output sent to browser
DEBUG - 2022-03-30 02:22:59 --> Total execution time: 0.0591
ERROR - 2022-03-30 02:38:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 02:38:49 --> Config Class Initialized
INFO - 2022-03-30 02:38:49 --> Hooks Class Initialized
DEBUG - 2022-03-30 02:38:49 --> UTF-8 Support Enabled
INFO - 2022-03-30 02:38:49 --> Utf8 Class Initialized
INFO - 2022-03-30 02:38:49 --> URI Class Initialized
INFO - 2022-03-30 02:38:49 --> Router Class Initialized
INFO - 2022-03-30 02:38:49 --> Output Class Initialized
INFO - 2022-03-30 02:38:49 --> Security Class Initialized
DEBUG - 2022-03-30 02:38:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 02:38:49 --> Input Class Initialized
INFO - 2022-03-30 02:38:49 --> Language Class Initialized
INFO - 2022-03-30 02:38:49 --> Loader Class Initialized
INFO - 2022-03-30 02:38:49 --> Helper loaded: url_helper
INFO - 2022-03-30 02:38:49 --> Helper loaded: form_helper
INFO - 2022-03-30 02:38:49 --> Helper loaded: common_helper
INFO - 2022-03-30 02:38:49 --> Database Driver Class Initialized
DEBUG - 2022-03-30 02:38:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 02:38:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 02:38:49 --> Controller Class Initialized
INFO - 2022-03-30 02:38:49 --> Form Validation Class Initialized
DEBUG - 2022-03-30 02:38:49 --> Encrypt Class Initialized
INFO - 2022-03-30 02:38:49 --> Model "Patient_model" initialized
INFO - 2022-03-30 02:38:49 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 02:38:49 --> Model "Prefix_master" initialized
INFO - 2022-03-30 02:38:49 --> Model "Users_model" initialized
INFO - 2022-03-30 02:38:49 --> Model "Hospital_model" initialized
ERROR - 2022-03-30 02:38:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 02:38:50 --> Config Class Initialized
INFO - 2022-03-30 02:38:50 --> Hooks Class Initialized
DEBUG - 2022-03-30 02:38:50 --> UTF-8 Support Enabled
INFO - 2022-03-30 02:38:50 --> Utf8 Class Initialized
INFO - 2022-03-30 02:38:50 --> URI Class Initialized
INFO - 2022-03-30 02:38:50 --> Router Class Initialized
INFO - 2022-03-30 02:38:50 --> Output Class Initialized
INFO - 2022-03-30 02:38:50 --> Security Class Initialized
DEBUG - 2022-03-30 02:38:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 02:38:50 --> Input Class Initialized
INFO - 2022-03-30 02:38:50 --> Language Class Initialized
INFO - 2022-03-30 02:38:50 --> Loader Class Initialized
INFO - 2022-03-30 02:38:50 --> Helper loaded: url_helper
INFO - 2022-03-30 02:38:50 --> Helper loaded: form_helper
INFO - 2022-03-30 02:38:50 --> Helper loaded: common_helper
INFO - 2022-03-30 02:38:50 --> Database Driver Class Initialized
DEBUG - 2022-03-30 02:38:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 02:38:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 02:38:50 --> Controller Class Initialized
INFO - 2022-03-30 02:38:50 --> Form Validation Class Initialized
DEBUG - 2022-03-30 02:38:50 --> Encrypt Class Initialized
INFO - 2022-03-30 02:38:50 --> Model "Patient_model" initialized
INFO - 2022-03-30 02:38:50 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 02:38:50 --> Model "Prefix_master" initialized
INFO - 2022-03-30 02:38:50 --> Model "Users_model" initialized
INFO - 2022-03-30 02:38:50 --> Model "Hospital_model" initialized
INFO - 2022-03-30 02:38:50 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 02:38:50 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-30 02:38:50 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 02:38:50 --> Final output sent to browser
DEBUG - 2022-03-30 02:38:50 --> Total execution time: 0.0417
ERROR - 2022-03-30 02:38:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 02:38:54 --> Config Class Initialized
INFO - 2022-03-30 02:38:54 --> Hooks Class Initialized
DEBUG - 2022-03-30 02:38:54 --> UTF-8 Support Enabled
INFO - 2022-03-30 02:38:54 --> Utf8 Class Initialized
INFO - 2022-03-30 02:38:54 --> URI Class Initialized
INFO - 2022-03-30 02:38:54 --> Router Class Initialized
INFO - 2022-03-30 02:38:54 --> Output Class Initialized
INFO - 2022-03-30 02:38:54 --> Security Class Initialized
DEBUG - 2022-03-30 02:38:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 02:38:54 --> Input Class Initialized
INFO - 2022-03-30 02:38:54 --> Language Class Initialized
INFO - 2022-03-30 02:38:54 --> Loader Class Initialized
INFO - 2022-03-30 02:38:54 --> Helper loaded: url_helper
INFO - 2022-03-30 02:38:54 --> Helper loaded: form_helper
INFO - 2022-03-30 02:38:54 --> Helper loaded: common_helper
INFO - 2022-03-30 02:38:54 --> Database Driver Class Initialized
DEBUG - 2022-03-30 02:38:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 02:38:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 02:38:54 --> Controller Class Initialized
INFO - 2022-03-30 02:38:54 --> Form Validation Class Initialized
DEBUG - 2022-03-30 02:38:54 --> Encrypt Class Initialized
INFO - 2022-03-30 02:38:54 --> Model "Patient_model" initialized
INFO - 2022-03-30 02:38:54 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 02:38:54 --> Model "Referredby_model" initialized
INFO - 2022-03-30 02:38:54 --> Model "Prefix_master" initialized
INFO - 2022-03-30 02:38:54 --> Model "Hospital_model" initialized
INFO - 2022-03-30 02:38:54 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 02:39:00 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-30 02:39:00 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 02:39:01 --> Final output sent to browser
DEBUG - 2022-03-30 02:39:01 --> Total execution time: 5.9404
ERROR - 2022-03-30 02:39:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 02:39:33 --> Config Class Initialized
INFO - 2022-03-30 02:39:33 --> Hooks Class Initialized
DEBUG - 2022-03-30 02:39:33 --> UTF-8 Support Enabled
INFO - 2022-03-30 02:39:33 --> Utf8 Class Initialized
INFO - 2022-03-30 02:39:33 --> URI Class Initialized
INFO - 2022-03-30 02:39:33 --> Router Class Initialized
INFO - 2022-03-30 02:39:33 --> Output Class Initialized
INFO - 2022-03-30 02:39:33 --> Security Class Initialized
DEBUG - 2022-03-30 02:39:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 02:39:33 --> Input Class Initialized
INFO - 2022-03-30 02:39:33 --> Language Class Initialized
INFO - 2022-03-30 02:39:33 --> Loader Class Initialized
INFO - 2022-03-30 02:39:33 --> Helper loaded: url_helper
INFO - 2022-03-30 02:39:33 --> Helper loaded: form_helper
INFO - 2022-03-30 02:39:33 --> Helper loaded: common_helper
INFO - 2022-03-30 02:39:33 --> Database Driver Class Initialized
DEBUG - 2022-03-30 02:39:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 02:39:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 02:39:33 --> Controller Class Initialized
INFO - 2022-03-30 02:39:33 --> Form Validation Class Initialized
DEBUG - 2022-03-30 02:39:33 --> Encrypt Class Initialized
INFO - 2022-03-30 02:39:33 --> Model "Patient_model" initialized
INFO - 2022-03-30 02:39:33 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 02:39:33 --> Model "Referredby_model" initialized
INFO - 2022-03-30 02:39:33 --> Model "Prefix_master" initialized
INFO - 2022-03-30 02:39:33 --> Model "Hospital_model" initialized
INFO - 2022-03-30 02:39:33 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 02:39:33 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-30 02:39:33 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 02:39:33 --> Final output sent to browser
DEBUG - 2022-03-30 02:39:33 --> Total execution time: 0.0304
ERROR - 2022-03-30 02:59:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 02:59:59 --> Config Class Initialized
INFO - 2022-03-30 02:59:59 --> Hooks Class Initialized
DEBUG - 2022-03-30 02:59:59 --> UTF-8 Support Enabled
INFO - 2022-03-30 02:59:59 --> Utf8 Class Initialized
INFO - 2022-03-30 02:59:59 --> URI Class Initialized
INFO - 2022-03-30 02:59:59 --> Router Class Initialized
INFO - 2022-03-30 02:59:59 --> Output Class Initialized
INFO - 2022-03-30 02:59:59 --> Security Class Initialized
DEBUG - 2022-03-30 02:59:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 02:59:59 --> Input Class Initialized
INFO - 2022-03-30 02:59:59 --> Language Class Initialized
INFO - 2022-03-30 02:59:59 --> Loader Class Initialized
INFO - 2022-03-30 02:59:59 --> Helper loaded: url_helper
INFO - 2022-03-30 02:59:59 --> Helper loaded: form_helper
INFO - 2022-03-30 02:59:59 --> Helper loaded: common_helper
INFO - 2022-03-30 02:59:59 --> Database Driver Class Initialized
DEBUG - 2022-03-30 02:59:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 02:59:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 02:59:59 --> Controller Class Initialized
INFO - 2022-03-30 02:59:59 --> Form Validation Class Initialized
DEBUG - 2022-03-30 02:59:59 --> Encrypt Class Initialized
INFO - 2022-03-30 02:59:59 --> Model "Patient_model" initialized
INFO - 2022-03-30 02:59:59 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 02:59:59 --> Model "Referredby_model" initialized
INFO - 2022-03-30 02:59:59 --> Model "Prefix_master" initialized
INFO - 2022-03-30 02:59:59 --> Model "Hospital_model" initialized
ERROR - 2022-03-30 03:00:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 03:00:00 --> Config Class Initialized
INFO - 2022-03-30 03:00:00 --> Hooks Class Initialized
DEBUG - 2022-03-30 03:00:00 --> UTF-8 Support Enabled
INFO - 2022-03-30 03:00:00 --> Utf8 Class Initialized
INFO - 2022-03-30 03:00:00 --> URI Class Initialized
INFO - 2022-03-30 03:00:00 --> Router Class Initialized
INFO - 2022-03-30 03:00:00 --> Output Class Initialized
INFO - 2022-03-30 03:00:00 --> Security Class Initialized
DEBUG - 2022-03-30 03:00:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 03:00:00 --> Input Class Initialized
INFO - 2022-03-30 03:00:00 --> Language Class Initialized
INFO - 2022-03-30 03:00:00 --> Loader Class Initialized
INFO - 2022-03-30 03:00:00 --> Helper loaded: url_helper
INFO - 2022-03-30 03:00:00 --> Helper loaded: form_helper
INFO - 2022-03-30 03:00:00 --> Helper loaded: common_helper
INFO - 2022-03-30 03:00:00 --> Database Driver Class Initialized
DEBUG - 2022-03-30 03:00:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 03:00:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 03:00:00 --> Controller Class Initialized
INFO - 2022-03-30 03:00:00 --> Form Validation Class Initialized
DEBUG - 2022-03-30 03:00:00 --> Encrypt Class Initialized
INFO - 2022-03-30 03:00:00 --> Model "Patient_model" initialized
INFO - 2022-03-30 03:00:00 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 03:00:00 --> Model "Referredby_model" initialized
INFO - 2022-03-30 03:00:00 --> Model "Prefix_master" initialized
INFO - 2022-03-30 03:00:00 --> Model "Hospital_model" initialized
INFO - 2022-03-30 03:00:00 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 03:00:00 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-30 03:00:00 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 03:00:00 --> Final output sent to browser
DEBUG - 2022-03-30 03:00:00 --> Total execution time: 0.0246
ERROR - 2022-03-30 03:00:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 03:00:00 --> Config Class Initialized
INFO - 2022-03-30 03:00:00 --> Hooks Class Initialized
DEBUG - 2022-03-30 03:00:00 --> UTF-8 Support Enabled
INFO - 2022-03-30 03:00:00 --> Utf8 Class Initialized
INFO - 2022-03-30 03:00:00 --> URI Class Initialized
INFO - 2022-03-30 03:00:00 --> Router Class Initialized
INFO - 2022-03-30 03:00:00 --> Output Class Initialized
INFO - 2022-03-30 03:00:00 --> Security Class Initialized
DEBUG - 2022-03-30 03:00:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 03:00:00 --> Input Class Initialized
INFO - 2022-03-30 03:00:00 --> Language Class Initialized
INFO - 2022-03-30 03:00:00 --> Loader Class Initialized
INFO - 2022-03-30 03:00:00 --> Helper loaded: url_helper
INFO - 2022-03-30 03:00:00 --> Helper loaded: form_helper
INFO - 2022-03-30 03:00:00 --> Helper loaded: common_helper
INFO - 2022-03-30 03:00:00 --> Database Driver Class Initialized
DEBUG - 2022-03-30 03:00:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 03:00:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 03:00:00 --> Controller Class Initialized
INFO - 2022-03-30 03:00:00 --> Form Validation Class Initialized
DEBUG - 2022-03-30 03:00:00 --> Encrypt Class Initialized
INFO - 2022-03-30 03:00:00 --> Model "Patient_model" initialized
INFO - 2022-03-30 03:00:00 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 03:00:00 --> Model "Prefix_master" initialized
INFO - 2022-03-30 03:00:00 --> Model "Users_model" initialized
INFO - 2022-03-30 03:00:00 --> Model "Hospital_model" initialized
INFO - 2022-03-30 03:00:00 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 03:00:00 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-30 03:00:00 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 03:00:00 --> Final output sent to browser
DEBUG - 2022-03-30 03:00:00 --> Total execution time: 0.0491
ERROR - 2022-03-30 03:04:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 03:04:56 --> Config Class Initialized
INFO - 2022-03-30 03:04:56 --> Hooks Class Initialized
DEBUG - 2022-03-30 03:04:56 --> UTF-8 Support Enabled
INFO - 2022-03-30 03:04:56 --> Utf8 Class Initialized
INFO - 2022-03-30 03:04:56 --> URI Class Initialized
INFO - 2022-03-30 03:04:56 --> Router Class Initialized
INFO - 2022-03-30 03:04:56 --> Output Class Initialized
INFO - 2022-03-30 03:04:56 --> Security Class Initialized
DEBUG - 2022-03-30 03:04:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 03:04:56 --> Input Class Initialized
INFO - 2022-03-30 03:04:56 --> Language Class Initialized
INFO - 2022-03-30 03:04:56 --> Loader Class Initialized
INFO - 2022-03-30 03:04:56 --> Helper loaded: url_helper
INFO - 2022-03-30 03:04:56 --> Helper loaded: form_helper
INFO - 2022-03-30 03:04:56 --> Helper loaded: common_helper
INFO - 2022-03-30 03:04:56 --> Database Driver Class Initialized
DEBUG - 2022-03-30 03:04:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 03:04:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 03:04:56 --> Controller Class Initialized
INFO - 2022-03-30 03:04:56 --> Form Validation Class Initialized
DEBUG - 2022-03-30 03:04:56 --> Encrypt Class Initialized
INFO - 2022-03-30 03:04:56 --> Model "Patient_model" initialized
INFO - 2022-03-30 03:04:56 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 03:04:56 --> Model "Referredby_model" initialized
INFO - 2022-03-30 03:04:56 --> Model "Prefix_master" initialized
INFO - 2022-03-30 03:04:56 --> Model "Hospital_model" initialized
INFO - 2022-03-30 03:04:56 --> File loaded: /home3/karoteam/public_html/application/views/header.php
ERROR - 2022-03-30 03:05:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 03:05:00 --> Config Class Initialized
INFO - 2022-03-30 03:05:00 --> Hooks Class Initialized
DEBUG - 2022-03-30 03:05:00 --> UTF-8 Support Enabled
INFO - 2022-03-30 03:05:00 --> Utf8 Class Initialized
INFO - 2022-03-30 03:05:00 --> URI Class Initialized
INFO - 2022-03-30 03:05:00 --> Router Class Initialized
INFO - 2022-03-30 03:05:00 --> Output Class Initialized
INFO - 2022-03-30 03:05:00 --> Security Class Initialized
DEBUG - 2022-03-30 03:05:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 03:05:00 --> Input Class Initialized
INFO - 2022-03-30 03:05:00 --> Language Class Initialized
INFO - 2022-03-30 03:05:00 --> Loader Class Initialized
INFO - 2022-03-30 03:05:00 --> Helper loaded: url_helper
INFO - 2022-03-30 03:05:00 --> Helper loaded: form_helper
INFO - 2022-03-30 03:05:00 --> Helper loaded: common_helper
INFO - 2022-03-30 03:05:00 --> Database Driver Class Initialized
DEBUG - 2022-03-30 03:05:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-03-30 03:05:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 03:05:01 --> Config Class Initialized
INFO - 2022-03-30 03:05:01 --> Hooks Class Initialized
DEBUG - 2022-03-30 03:05:01 --> UTF-8 Support Enabled
INFO - 2022-03-30 03:05:01 --> Utf8 Class Initialized
INFO - 2022-03-30 03:05:01 --> URI Class Initialized
INFO - 2022-03-30 03:05:01 --> Router Class Initialized
INFO - 2022-03-30 03:05:01 --> Output Class Initialized
INFO - 2022-03-30 03:05:01 --> Security Class Initialized
DEBUG - 2022-03-30 03:05:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 03:05:01 --> Input Class Initialized
INFO - 2022-03-30 03:05:01 --> Language Class Initialized
INFO - 2022-03-30 03:05:01 --> Loader Class Initialized
INFO - 2022-03-30 03:05:01 --> Helper loaded: url_helper
INFO - 2022-03-30 03:05:01 --> Helper loaded: form_helper
INFO - 2022-03-30 03:05:01 --> Helper loaded: common_helper
INFO - 2022-03-30 03:05:01 --> Database Driver Class Initialized
DEBUG - 2022-03-30 03:05:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 03:05:03 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-30 03:05:03 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 03:05:03 --> Final output sent to browser
DEBUG - 2022-03-30 03:05:03 --> Total execution time: 6.7866
INFO - 2022-03-30 03:05:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 03:05:03 --> Controller Class Initialized
INFO - 2022-03-30 03:05:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 03:05:03 --> Form Validation Class Initialized
INFO - 2022-03-30 03:05:03 --> Controller Class Initialized
DEBUG - 2022-03-30 03:05:03 --> Encrypt Class Initialized
INFO - 2022-03-30 03:05:03 --> Model "Patient_model" initialized
INFO - 2022-03-30 03:05:03 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 03:05:03 --> Model "Referredby_model" initialized
INFO - 2022-03-30 03:05:03 --> Model "Prefix_master" initialized
INFO - 2022-03-30 03:05:03 --> Model "Hospital_model" initialized
INFO - 2022-03-30 03:05:03 --> Form Validation Class Initialized
DEBUG - 2022-03-30 03:05:03 --> Encrypt Class Initialized
INFO - 2022-03-30 03:05:03 --> Model "Patient_model" initialized
INFO - 2022-03-30 03:05:03 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 03:05:03 --> Model "Referredby_model" initialized
INFO - 2022-03-30 03:05:03 --> Model "Prefix_master" initialized
INFO - 2022-03-30 03:05:03 --> Model "Hospital_model" initialized
INFO - 2022-03-30 03:05:03 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 03:05:03 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 03:05:10 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-30 03:05:10 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 03:05:10 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-30 03:05:10 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 03:05:10 --> Final output sent to browser
DEBUG - 2022-03-30 03:05:10 --> Total execution time: 9.4274
INFO - 2022-03-30 03:05:12 --> Final output sent to browser
DEBUG - 2022-03-30 03:05:12 --> Total execution time: 9.6164
ERROR - 2022-03-30 03:15:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 03:15:15 --> Config Class Initialized
INFO - 2022-03-30 03:15:15 --> Hooks Class Initialized
DEBUG - 2022-03-30 03:15:15 --> UTF-8 Support Enabled
INFO - 2022-03-30 03:15:15 --> Utf8 Class Initialized
INFO - 2022-03-30 03:15:15 --> URI Class Initialized
INFO - 2022-03-30 03:15:15 --> Router Class Initialized
INFO - 2022-03-30 03:15:15 --> Output Class Initialized
INFO - 2022-03-30 03:15:15 --> Security Class Initialized
DEBUG - 2022-03-30 03:15:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 03:15:15 --> Input Class Initialized
INFO - 2022-03-30 03:15:15 --> Language Class Initialized
ERROR - 2022-03-30 03:15:15 --> 404 Page Not Found: Humanstxt/index
ERROR - 2022-03-30 03:15:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 03:15:15 --> Config Class Initialized
INFO - 2022-03-30 03:15:15 --> Hooks Class Initialized
DEBUG - 2022-03-30 03:15:15 --> UTF-8 Support Enabled
INFO - 2022-03-30 03:15:15 --> Utf8 Class Initialized
INFO - 2022-03-30 03:15:15 --> URI Class Initialized
INFO - 2022-03-30 03:15:15 --> Router Class Initialized
INFO - 2022-03-30 03:15:15 --> Output Class Initialized
INFO - 2022-03-30 03:15:15 --> Security Class Initialized
DEBUG - 2022-03-30 03:15:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 03:15:15 --> Input Class Initialized
INFO - 2022-03-30 03:15:15 --> Language Class Initialized
ERROR - 2022-03-30 03:15:15 --> 404 Page Not Found: Adstxt/index
ERROR - 2022-03-30 03:15:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 03:15:16 --> Config Class Initialized
INFO - 2022-03-30 03:15:16 --> Hooks Class Initialized
DEBUG - 2022-03-30 03:15:16 --> UTF-8 Support Enabled
INFO - 2022-03-30 03:15:16 --> Utf8 Class Initialized
INFO - 2022-03-30 03:15:16 --> URI Class Initialized
DEBUG - 2022-03-30 03:15:16 --> No URI present. Default controller set.
INFO - 2022-03-30 03:15:16 --> Router Class Initialized
INFO - 2022-03-30 03:15:16 --> Output Class Initialized
INFO - 2022-03-30 03:15:16 --> Security Class Initialized
DEBUG - 2022-03-30 03:15:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 03:15:16 --> Input Class Initialized
INFO - 2022-03-30 03:15:16 --> Language Class Initialized
INFO - 2022-03-30 03:15:16 --> Loader Class Initialized
INFO - 2022-03-30 03:15:16 --> Helper loaded: url_helper
INFO - 2022-03-30 03:15:16 --> Helper loaded: form_helper
INFO - 2022-03-30 03:15:16 --> Helper loaded: common_helper
INFO - 2022-03-30 03:15:16 --> Database Driver Class Initialized
DEBUG - 2022-03-30 03:15:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 03:15:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 03:15:16 --> Controller Class Initialized
INFO - 2022-03-30 03:15:16 --> Form Validation Class Initialized
DEBUG - 2022-03-30 03:15:16 --> Encrypt Class Initialized
DEBUG - 2022-03-30 03:15:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-30 03:15:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-30 03:15:16 --> Email Class Initialized
INFO - 2022-03-30 03:15:16 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-30 03:15:16 --> Calendar Class Initialized
INFO - 2022-03-30 03:15:16 --> Model "Login_model" initialized
INFO - 2022-03-30 03:15:16 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-30 03:15:16 --> Final output sent to browser
DEBUG - 2022-03-30 03:15:16 --> Total execution time: 0.0410
ERROR - 2022-03-30 03:38:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 03:38:03 --> Config Class Initialized
INFO - 2022-03-30 03:38:03 --> Hooks Class Initialized
DEBUG - 2022-03-30 03:38:03 --> UTF-8 Support Enabled
INFO - 2022-03-30 03:38:03 --> Utf8 Class Initialized
INFO - 2022-03-30 03:38:03 --> URI Class Initialized
INFO - 2022-03-30 03:38:03 --> Router Class Initialized
INFO - 2022-03-30 03:38:03 --> Output Class Initialized
INFO - 2022-03-30 03:38:03 --> Security Class Initialized
DEBUG - 2022-03-30 03:38:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 03:38:03 --> Input Class Initialized
INFO - 2022-03-30 03:38:03 --> Language Class Initialized
INFO - 2022-03-30 03:38:03 --> Loader Class Initialized
INFO - 2022-03-30 03:38:03 --> Helper loaded: url_helper
INFO - 2022-03-30 03:38:03 --> Helper loaded: form_helper
INFO - 2022-03-30 03:38:03 --> Helper loaded: common_helper
INFO - 2022-03-30 03:38:03 --> Database Driver Class Initialized
DEBUG - 2022-03-30 03:38:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 03:38:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 03:38:03 --> Controller Class Initialized
ERROR - 2022-03-30 03:38:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 03:38:04 --> Config Class Initialized
INFO - 2022-03-30 03:38:04 --> Hooks Class Initialized
DEBUG - 2022-03-30 03:38:04 --> UTF-8 Support Enabled
INFO - 2022-03-30 03:38:04 --> Utf8 Class Initialized
INFO - 2022-03-30 03:38:04 --> URI Class Initialized
INFO - 2022-03-30 03:38:04 --> Router Class Initialized
INFO - 2022-03-30 03:38:04 --> Output Class Initialized
INFO - 2022-03-30 03:38:04 --> Security Class Initialized
DEBUG - 2022-03-30 03:38:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 03:38:04 --> Input Class Initialized
INFO - 2022-03-30 03:38:04 --> Language Class Initialized
INFO - 2022-03-30 03:38:04 --> Loader Class Initialized
INFO - 2022-03-30 03:38:04 --> Helper loaded: url_helper
INFO - 2022-03-30 03:38:04 --> Helper loaded: form_helper
INFO - 2022-03-30 03:38:04 --> Helper loaded: common_helper
INFO - 2022-03-30 03:38:04 --> Database Driver Class Initialized
DEBUG - 2022-03-30 03:38:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 03:38:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 03:38:04 --> Controller Class Initialized
INFO - 2022-03-30 03:38:04 --> Form Validation Class Initialized
DEBUG - 2022-03-30 03:38:04 --> Encrypt Class Initialized
DEBUG - 2022-03-30 03:38:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-30 03:38:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-30 03:38:04 --> Email Class Initialized
INFO - 2022-03-30 03:38:04 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-30 03:38:04 --> Calendar Class Initialized
INFO - 2022-03-30 03:38:04 --> Model "Login_model" initialized
INFO - 2022-03-30 03:38:04 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-30 03:38:04 --> Final output sent to browser
DEBUG - 2022-03-30 03:38:04 --> Total execution time: 0.0177
ERROR - 2022-03-30 03:38:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 03:38:21 --> Config Class Initialized
INFO - 2022-03-30 03:38:21 --> Hooks Class Initialized
DEBUG - 2022-03-30 03:38:21 --> UTF-8 Support Enabled
INFO - 2022-03-30 03:38:21 --> Utf8 Class Initialized
INFO - 2022-03-30 03:38:21 --> URI Class Initialized
INFO - 2022-03-30 03:38:21 --> Router Class Initialized
INFO - 2022-03-30 03:38:21 --> Output Class Initialized
INFO - 2022-03-30 03:38:21 --> Security Class Initialized
DEBUG - 2022-03-30 03:38:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 03:38:21 --> Input Class Initialized
INFO - 2022-03-30 03:38:21 --> Language Class Initialized
INFO - 2022-03-30 03:38:21 --> Loader Class Initialized
INFO - 2022-03-30 03:38:21 --> Helper loaded: url_helper
INFO - 2022-03-30 03:38:21 --> Helper loaded: form_helper
INFO - 2022-03-30 03:38:21 --> Helper loaded: common_helper
INFO - 2022-03-30 03:38:21 --> Database Driver Class Initialized
DEBUG - 2022-03-30 03:38:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 03:38:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 03:38:21 --> Controller Class Initialized
INFO - 2022-03-30 03:38:21 --> Form Validation Class Initialized
DEBUG - 2022-03-30 03:38:21 --> Encrypt Class Initialized
DEBUG - 2022-03-30 03:38:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-30 03:38:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-30 03:38:21 --> Email Class Initialized
INFO - 2022-03-30 03:38:21 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-30 03:38:21 --> Calendar Class Initialized
INFO - 2022-03-30 03:38:21 --> Model "Login_model" initialized
INFO - 2022-03-30 03:38:21 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-03-30 03:38:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 03:38:21 --> Config Class Initialized
INFO - 2022-03-30 03:38:21 --> Hooks Class Initialized
DEBUG - 2022-03-30 03:38:21 --> UTF-8 Support Enabled
INFO - 2022-03-30 03:38:21 --> Utf8 Class Initialized
INFO - 2022-03-30 03:38:21 --> URI Class Initialized
INFO - 2022-03-30 03:38:21 --> Router Class Initialized
INFO - 2022-03-30 03:38:21 --> Output Class Initialized
INFO - 2022-03-30 03:38:21 --> Security Class Initialized
DEBUG - 2022-03-30 03:38:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 03:38:21 --> Input Class Initialized
INFO - 2022-03-30 03:38:21 --> Language Class Initialized
INFO - 2022-03-30 03:38:21 --> Loader Class Initialized
INFO - 2022-03-30 03:38:21 --> Helper loaded: url_helper
INFO - 2022-03-30 03:38:21 --> Helper loaded: form_helper
INFO - 2022-03-30 03:38:21 --> Helper loaded: common_helper
INFO - 2022-03-30 03:38:21 --> Database Driver Class Initialized
DEBUG - 2022-03-30 03:38:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 03:38:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 03:38:21 --> Controller Class Initialized
INFO - 2022-03-30 03:38:21 --> Form Validation Class Initialized
DEBUG - 2022-03-30 03:38:21 --> Encrypt Class Initialized
INFO - 2022-03-30 03:38:21 --> Model "Login_model" initialized
INFO - 2022-03-30 03:38:21 --> Model "Dashboard_model" initialized
INFO - 2022-03-30 03:38:21 --> Model "Case_model" initialized
INFO - 2022-03-30 03:38:21 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 03:38:21 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2022-03-30 03:38:21 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 03:38:21 --> Final output sent to browser
DEBUG - 2022-03-30 03:38:21 --> Total execution time: 0.2022
ERROR - 2022-03-30 03:39:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 03:39:10 --> Config Class Initialized
INFO - 2022-03-30 03:39:10 --> Hooks Class Initialized
DEBUG - 2022-03-30 03:39:10 --> UTF-8 Support Enabled
INFO - 2022-03-30 03:39:10 --> Utf8 Class Initialized
INFO - 2022-03-30 03:39:10 --> URI Class Initialized
INFO - 2022-03-30 03:39:10 --> Router Class Initialized
INFO - 2022-03-30 03:39:10 --> Output Class Initialized
INFO - 2022-03-30 03:39:10 --> Security Class Initialized
DEBUG - 2022-03-30 03:39:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 03:39:10 --> Input Class Initialized
INFO - 2022-03-30 03:39:10 --> Language Class Initialized
INFO - 2022-03-30 03:39:10 --> Loader Class Initialized
INFO - 2022-03-30 03:39:10 --> Helper loaded: url_helper
INFO - 2022-03-30 03:39:10 --> Helper loaded: form_helper
INFO - 2022-03-30 03:39:10 --> Helper loaded: common_helper
INFO - 2022-03-30 03:39:10 --> Database Driver Class Initialized
DEBUG - 2022-03-30 03:39:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 03:39:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 03:39:10 --> Controller Class Initialized
INFO - 2022-03-30 03:39:10 --> Form Validation Class Initialized
DEBUG - 2022-03-30 03:39:10 --> Encrypt Class Initialized
INFO - 2022-03-30 03:39:10 --> Model "Patient_model" initialized
INFO - 2022-03-30 03:39:10 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 03:39:10 --> Model "Referredby_model" initialized
INFO - 2022-03-30 03:39:10 --> Model "Prefix_master" initialized
INFO - 2022-03-30 03:39:10 --> Model "Hospital_model" initialized
INFO - 2022-03-30 03:39:10 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 03:39:10 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-30 03:39:10 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 03:39:10 --> Final output sent to browser
DEBUG - 2022-03-30 03:39:10 --> Total execution time: 0.0706
ERROR - 2022-03-30 03:45:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 03:45:14 --> Config Class Initialized
INFO - 2022-03-30 03:45:14 --> Hooks Class Initialized
DEBUG - 2022-03-30 03:45:14 --> UTF-8 Support Enabled
INFO - 2022-03-30 03:45:14 --> Utf8 Class Initialized
INFO - 2022-03-30 03:45:14 --> URI Class Initialized
INFO - 2022-03-30 03:45:14 --> Router Class Initialized
INFO - 2022-03-30 03:45:14 --> Output Class Initialized
INFO - 2022-03-30 03:45:14 --> Security Class Initialized
DEBUG - 2022-03-30 03:45:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 03:45:14 --> Input Class Initialized
INFO - 2022-03-30 03:45:14 --> Language Class Initialized
INFO - 2022-03-30 03:45:14 --> Loader Class Initialized
INFO - 2022-03-30 03:45:14 --> Helper loaded: url_helper
INFO - 2022-03-30 03:45:14 --> Helper loaded: form_helper
INFO - 2022-03-30 03:45:14 --> Helper loaded: common_helper
INFO - 2022-03-30 03:45:14 --> Database Driver Class Initialized
DEBUG - 2022-03-30 03:45:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 03:45:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 03:45:14 --> Controller Class Initialized
INFO - 2022-03-30 03:45:14 --> Model "Referredby_model" initialized
INFO - 2022-03-30 03:45:14 --> Final output sent to browser
DEBUG - 2022-03-30 03:45:14 --> Total execution time: 0.0441
ERROR - 2022-03-30 03:45:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 03:45:51 --> Config Class Initialized
INFO - 2022-03-30 03:45:51 --> Hooks Class Initialized
DEBUG - 2022-03-30 03:45:51 --> UTF-8 Support Enabled
INFO - 2022-03-30 03:45:51 --> Utf8 Class Initialized
INFO - 2022-03-30 03:45:51 --> URI Class Initialized
INFO - 2022-03-30 03:45:51 --> Router Class Initialized
INFO - 2022-03-30 03:45:51 --> Output Class Initialized
INFO - 2022-03-30 03:45:51 --> Security Class Initialized
DEBUG - 2022-03-30 03:45:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 03:45:51 --> Input Class Initialized
INFO - 2022-03-30 03:45:51 --> Language Class Initialized
INFO - 2022-03-30 03:45:51 --> Loader Class Initialized
INFO - 2022-03-30 03:45:51 --> Helper loaded: url_helper
INFO - 2022-03-30 03:45:51 --> Helper loaded: form_helper
INFO - 2022-03-30 03:45:51 --> Helper loaded: common_helper
INFO - 2022-03-30 03:45:51 --> Database Driver Class Initialized
DEBUG - 2022-03-30 03:45:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 03:45:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 03:45:51 --> Controller Class Initialized
INFO - 2022-03-30 03:45:51 --> Model "Referredby_model" initialized
INFO - 2022-03-30 03:45:51 --> Final output sent to browser
DEBUG - 2022-03-30 03:45:51 --> Total execution time: 0.0082
ERROR - 2022-03-30 03:46:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 03:46:14 --> Config Class Initialized
INFO - 2022-03-30 03:46:14 --> Hooks Class Initialized
DEBUG - 2022-03-30 03:46:14 --> UTF-8 Support Enabled
INFO - 2022-03-30 03:46:14 --> Utf8 Class Initialized
INFO - 2022-03-30 03:46:14 --> URI Class Initialized
INFO - 2022-03-30 03:46:14 --> Router Class Initialized
INFO - 2022-03-30 03:46:14 --> Output Class Initialized
INFO - 2022-03-30 03:46:14 --> Security Class Initialized
DEBUG - 2022-03-30 03:46:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 03:46:14 --> Input Class Initialized
INFO - 2022-03-30 03:46:14 --> Language Class Initialized
INFO - 2022-03-30 03:46:14 --> Loader Class Initialized
INFO - 2022-03-30 03:46:14 --> Helper loaded: url_helper
INFO - 2022-03-30 03:46:14 --> Helper loaded: form_helper
INFO - 2022-03-30 03:46:14 --> Helper loaded: common_helper
INFO - 2022-03-30 03:46:14 --> Database Driver Class Initialized
DEBUG - 2022-03-30 03:46:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 03:46:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 03:46:14 --> Controller Class Initialized
INFO - 2022-03-30 03:46:14 --> Form Validation Class Initialized
DEBUG - 2022-03-30 03:46:14 --> Encrypt Class Initialized
INFO - 2022-03-30 03:46:14 --> Model "Patient_model" initialized
INFO - 2022-03-30 03:46:14 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 03:46:14 --> Model "Referredby_model" initialized
INFO - 2022-03-30 03:46:14 --> Model "Prefix_master" initialized
INFO - 2022-03-30 03:46:14 --> Model "Hospital_model" initialized
INFO - 2022-03-30 03:46:14 --> Final output sent to browser
DEBUG - 2022-03-30 03:46:14 --> Total execution time: 0.0210
ERROR - 2022-03-30 03:48:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 03:48:07 --> Config Class Initialized
INFO - 2022-03-30 03:48:07 --> Hooks Class Initialized
DEBUG - 2022-03-30 03:48:07 --> UTF-8 Support Enabled
INFO - 2022-03-30 03:48:07 --> Utf8 Class Initialized
INFO - 2022-03-30 03:48:07 --> URI Class Initialized
INFO - 2022-03-30 03:48:07 --> Router Class Initialized
INFO - 2022-03-30 03:48:07 --> Output Class Initialized
INFO - 2022-03-30 03:48:07 --> Security Class Initialized
DEBUG - 2022-03-30 03:48:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 03:48:07 --> Input Class Initialized
INFO - 2022-03-30 03:48:07 --> Language Class Initialized
INFO - 2022-03-30 03:48:07 --> Loader Class Initialized
INFO - 2022-03-30 03:48:07 --> Helper loaded: url_helper
INFO - 2022-03-30 03:48:07 --> Helper loaded: form_helper
INFO - 2022-03-30 03:48:07 --> Helper loaded: common_helper
INFO - 2022-03-30 03:48:07 --> Database Driver Class Initialized
DEBUG - 2022-03-30 03:48:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 03:48:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 03:48:07 --> Controller Class Initialized
ERROR - 2022-03-30 03:48:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 03:48:07 --> Config Class Initialized
INFO - 2022-03-30 03:48:07 --> Hooks Class Initialized
DEBUG - 2022-03-30 03:48:07 --> UTF-8 Support Enabled
INFO - 2022-03-30 03:48:07 --> Utf8 Class Initialized
INFO - 2022-03-30 03:48:07 --> URI Class Initialized
INFO - 2022-03-30 03:48:07 --> Router Class Initialized
INFO - 2022-03-30 03:48:07 --> Output Class Initialized
INFO - 2022-03-30 03:48:07 --> Security Class Initialized
DEBUG - 2022-03-30 03:48:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 03:48:07 --> Input Class Initialized
INFO - 2022-03-30 03:48:07 --> Language Class Initialized
INFO - 2022-03-30 03:48:07 --> Loader Class Initialized
INFO - 2022-03-30 03:48:07 --> Helper loaded: url_helper
INFO - 2022-03-30 03:48:07 --> Helper loaded: form_helper
INFO - 2022-03-30 03:48:07 --> Helper loaded: common_helper
INFO - 2022-03-30 03:48:07 --> Database Driver Class Initialized
DEBUG - 2022-03-30 03:48:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 03:48:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 03:48:07 --> Controller Class Initialized
INFO - 2022-03-30 03:48:07 --> Form Validation Class Initialized
DEBUG - 2022-03-30 03:48:07 --> Encrypt Class Initialized
DEBUG - 2022-03-30 03:48:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-30 03:48:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-30 03:48:07 --> Email Class Initialized
INFO - 2022-03-30 03:48:07 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-30 03:48:07 --> Calendar Class Initialized
INFO - 2022-03-30 03:48:07 --> Model "Login_model" initialized
INFO - 2022-03-30 03:48:07 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-30 03:48:07 --> Final output sent to browser
DEBUG - 2022-03-30 03:48:07 --> Total execution time: 0.0180
ERROR - 2022-03-30 03:48:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 03:48:21 --> Config Class Initialized
INFO - 2022-03-30 03:48:21 --> Hooks Class Initialized
DEBUG - 2022-03-30 03:48:21 --> UTF-8 Support Enabled
INFO - 2022-03-30 03:48:21 --> Utf8 Class Initialized
INFO - 2022-03-30 03:48:21 --> URI Class Initialized
INFO - 2022-03-30 03:48:21 --> Router Class Initialized
INFO - 2022-03-30 03:48:21 --> Output Class Initialized
INFO - 2022-03-30 03:48:21 --> Security Class Initialized
DEBUG - 2022-03-30 03:48:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 03:48:21 --> Input Class Initialized
INFO - 2022-03-30 03:48:21 --> Language Class Initialized
INFO - 2022-03-30 03:48:21 --> Loader Class Initialized
INFO - 2022-03-30 03:48:21 --> Helper loaded: url_helper
INFO - 2022-03-30 03:48:21 --> Helper loaded: form_helper
INFO - 2022-03-30 03:48:21 --> Helper loaded: common_helper
INFO - 2022-03-30 03:48:21 --> Database Driver Class Initialized
DEBUG - 2022-03-30 03:48:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 03:48:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 03:48:21 --> Controller Class Initialized
INFO - 2022-03-30 03:48:21 --> Form Validation Class Initialized
DEBUG - 2022-03-30 03:48:21 --> Encrypt Class Initialized
DEBUG - 2022-03-30 03:48:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-30 03:48:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-30 03:48:21 --> Email Class Initialized
INFO - 2022-03-30 03:48:21 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-30 03:48:21 --> Calendar Class Initialized
INFO - 2022-03-30 03:48:21 --> Model "Login_model" initialized
INFO - 2022-03-30 03:48:21 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-03-30 03:48:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 03:48:21 --> Config Class Initialized
INFO - 2022-03-30 03:48:21 --> Hooks Class Initialized
DEBUG - 2022-03-30 03:48:21 --> UTF-8 Support Enabled
INFO - 2022-03-30 03:48:21 --> Utf8 Class Initialized
INFO - 2022-03-30 03:48:21 --> URI Class Initialized
INFO - 2022-03-30 03:48:21 --> Router Class Initialized
INFO - 2022-03-30 03:48:21 --> Output Class Initialized
INFO - 2022-03-30 03:48:21 --> Security Class Initialized
DEBUG - 2022-03-30 03:48:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 03:48:21 --> Input Class Initialized
INFO - 2022-03-30 03:48:21 --> Language Class Initialized
INFO - 2022-03-30 03:48:21 --> Loader Class Initialized
INFO - 2022-03-30 03:48:21 --> Helper loaded: url_helper
INFO - 2022-03-30 03:48:21 --> Helper loaded: form_helper
INFO - 2022-03-30 03:48:21 --> Helper loaded: common_helper
INFO - 2022-03-30 03:48:21 --> Database Driver Class Initialized
DEBUG - 2022-03-30 03:48:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 03:48:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 03:48:21 --> Controller Class Initialized
INFO - 2022-03-30 03:48:21 --> Form Validation Class Initialized
DEBUG - 2022-03-30 03:48:21 --> Encrypt Class Initialized
INFO - 2022-03-30 03:48:21 --> Model "Login_model" initialized
INFO - 2022-03-30 03:48:21 --> Model "Dashboard_model" initialized
INFO - 2022-03-30 03:48:21 --> Model "Case_model" initialized
INFO - 2022-03-30 03:48:21 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 03:48:21 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2022-03-30 03:48:21 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 03:48:21 --> Final output sent to browser
DEBUG - 2022-03-30 03:48:21 --> Total execution time: 0.1969
ERROR - 2022-03-30 03:48:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 03:48:43 --> Config Class Initialized
INFO - 2022-03-30 03:48:43 --> Hooks Class Initialized
DEBUG - 2022-03-30 03:48:43 --> UTF-8 Support Enabled
INFO - 2022-03-30 03:48:43 --> Utf8 Class Initialized
INFO - 2022-03-30 03:48:43 --> URI Class Initialized
INFO - 2022-03-30 03:48:43 --> Router Class Initialized
INFO - 2022-03-30 03:48:43 --> Output Class Initialized
INFO - 2022-03-30 03:48:43 --> Security Class Initialized
DEBUG - 2022-03-30 03:48:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 03:48:43 --> Input Class Initialized
INFO - 2022-03-30 03:48:43 --> Language Class Initialized
INFO - 2022-03-30 03:48:43 --> Loader Class Initialized
INFO - 2022-03-30 03:48:43 --> Helper loaded: url_helper
INFO - 2022-03-30 03:48:43 --> Helper loaded: form_helper
INFO - 2022-03-30 03:48:43 --> Helper loaded: common_helper
INFO - 2022-03-30 03:48:43 --> Database Driver Class Initialized
DEBUG - 2022-03-30 03:48:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 03:48:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 03:48:43 --> Controller Class Initialized
INFO - 2022-03-30 03:48:43 --> Form Validation Class Initialized
DEBUG - 2022-03-30 03:48:43 --> Encrypt Class Initialized
INFO - 2022-03-30 03:48:43 --> Model "Patient_model" initialized
INFO - 2022-03-30 03:48:43 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 03:48:43 --> Model "Referredby_model" initialized
INFO - 2022-03-30 03:48:43 --> Model "Prefix_master" initialized
INFO - 2022-03-30 03:48:43 --> Model "Hospital_model" initialized
INFO - 2022-03-30 03:48:43 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 03:48:43 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-30 03:48:43 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 03:48:43 --> Final output sent to browser
DEBUG - 2022-03-30 03:48:43 --> Total execution time: 0.0597
ERROR - 2022-03-30 03:49:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 03:49:08 --> Config Class Initialized
INFO - 2022-03-30 03:49:08 --> Hooks Class Initialized
DEBUG - 2022-03-30 03:49:08 --> UTF-8 Support Enabled
INFO - 2022-03-30 03:49:08 --> Utf8 Class Initialized
INFO - 2022-03-30 03:49:08 --> URI Class Initialized
INFO - 2022-03-30 03:49:08 --> Router Class Initialized
INFO - 2022-03-30 03:49:08 --> Output Class Initialized
INFO - 2022-03-30 03:49:08 --> Security Class Initialized
DEBUG - 2022-03-30 03:49:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 03:49:08 --> Input Class Initialized
INFO - 2022-03-30 03:49:08 --> Language Class Initialized
INFO - 2022-03-30 03:49:08 --> Loader Class Initialized
INFO - 2022-03-30 03:49:08 --> Helper loaded: url_helper
INFO - 2022-03-30 03:49:08 --> Helper loaded: form_helper
INFO - 2022-03-30 03:49:08 --> Helper loaded: common_helper
INFO - 2022-03-30 03:49:08 --> Database Driver Class Initialized
DEBUG - 2022-03-30 03:49:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 03:49:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 03:49:08 --> Controller Class Initialized
INFO - 2022-03-30 03:49:08 --> Form Validation Class Initialized
DEBUG - 2022-03-30 03:49:08 --> Encrypt Class Initialized
INFO - 2022-03-30 03:49:08 --> Model "Patient_model" initialized
INFO - 2022-03-30 03:49:08 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 03:49:08 --> Model "Prefix_master" initialized
INFO - 2022-03-30 03:49:08 --> Model "Users_model" initialized
INFO - 2022-03-30 03:49:08 --> Model "Hospital_model" initialized
INFO - 2022-03-30 03:49:08 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 03:49:08 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-30 03:49:08 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 03:49:08 --> Final output sent to browser
DEBUG - 2022-03-30 03:49:08 --> Total execution time: 0.0468
ERROR - 2022-03-30 03:49:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 03:49:13 --> Config Class Initialized
INFO - 2022-03-30 03:49:13 --> Hooks Class Initialized
DEBUG - 2022-03-30 03:49:13 --> UTF-8 Support Enabled
INFO - 2022-03-30 03:49:13 --> Utf8 Class Initialized
INFO - 2022-03-30 03:49:13 --> URI Class Initialized
INFO - 2022-03-30 03:49:13 --> Router Class Initialized
INFO - 2022-03-30 03:49:13 --> Output Class Initialized
INFO - 2022-03-30 03:49:13 --> Security Class Initialized
DEBUG - 2022-03-30 03:49:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 03:49:13 --> Input Class Initialized
INFO - 2022-03-30 03:49:13 --> Language Class Initialized
INFO - 2022-03-30 03:49:13 --> Loader Class Initialized
INFO - 2022-03-30 03:49:13 --> Helper loaded: url_helper
INFO - 2022-03-30 03:49:13 --> Helper loaded: form_helper
INFO - 2022-03-30 03:49:13 --> Helper loaded: common_helper
INFO - 2022-03-30 03:49:13 --> Database Driver Class Initialized
DEBUG - 2022-03-30 03:49:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 03:49:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 03:49:13 --> Controller Class Initialized
INFO - 2022-03-30 03:49:13 --> Form Validation Class Initialized
DEBUG - 2022-03-30 03:49:13 --> Encrypt Class Initialized
INFO - 2022-03-30 03:49:13 --> Model "Patient_model" initialized
INFO - 2022-03-30 03:49:13 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 03:49:13 --> Model "Referredby_model" initialized
INFO - 2022-03-30 03:49:13 --> Model "Prefix_master" initialized
INFO - 2022-03-30 03:49:13 --> Model "Hospital_model" initialized
INFO - 2022-03-30 03:49:13 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 03:49:13 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-30 03:49:13 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 03:49:13 --> Final output sent to browser
DEBUG - 2022-03-30 03:49:13 --> Total execution time: 0.0268
ERROR - 2022-03-30 03:51:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 03:51:53 --> Config Class Initialized
INFO - 2022-03-30 03:51:53 --> Hooks Class Initialized
DEBUG - 2022-03-30 03:51:53 --> UTF-8 Support Enabled
INFO - 2022-03-30 03:51:53 --> Utf8 Class Initialized
INFO - 2022-03-30 03:51:53 --> URI Class Initialized
INFO - 2022-03-30 03:51:53 --> Router Class Initialized
INFO - 2022-03-30 03:51:53 --> Output Class Initialized
INFO - 2022-03-30 03:51:53 --> Security Class Initialized
DEBUG - 2022-03-30 03:51:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 03:51:53 --> Input Class Initialized
INFO - 2022-03-30 03:51:53 --> Language Class Initialized
INFO - 2022-03-30 03:51:53 --> Loader Class Initialized
INFO - 2022-03-30 03:51:53 --> Helper loaded: url_helper
INFO - 2022-03-30 03:51:53 --> Helper loaded: form_helper
INFO - 2022-03-30 03:51:53 --> Helper loaded: common_helper
INFO - 2022-03-30 03:51:53 --> Database Driver Class Initialized
DEBUG - 2022-03-30 03:51:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 03:51:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 03:51:53 --> Controller Class Initialized
INFO - 2022-03-30 03:51:53 --> Form Validation Class Initialized
DEBUG - 2022-03-30 03:51:53 --> Encrypt Class Initialized
INFO - 2022-03-30 03:51:53 --> Model "Patient_model" initialized
INFO - 2022-03-30 03:51:53 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 03:51:53 --> Model "Referredby_model" initialized
INFO - 2022-03-30 03:51:53 --> Model "Prefix_master" initialized
INFO - 2022-03-30 03:51:53 --> Model "Hospital_model" initialized
ERROR - 2022-03-30 03:51:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 03:51:54 --> Config Class Initialized
INFO - 2022-03-30 03:51:54 --> Hooks Class Initialized
DEBUG - 2022-03-30 03:51:54 --> UTF-8 Support Enabled
INFO - 2022-03-30 03:51:54 --> Utf8 Class Initialized
INFO - 2022-03-30 03:51:54 --> URI Class Initialized
INFO - 2022-03-30 03:51:54 --> Router Class Initialized
INFO - 2022-03-30 03:51:54 --> Output Class Initialized
INFO - 2022-03-30 03:51:54 --> Security Class Initialized
DEBUG - 2022-03-30 03:51:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 03:51:54 --> Input Class Initialized
INFO - 2022-03-30 03:51:54 --> Language Class Initialized
INFO - 2022-03-30 03:51:54 --> Loader Class Initialized
INFO - 2022-03-30 03:51:54 --> Helper loaded: url_helper
INFO - 2022-03-30 03:51:54 --> Helper loaded: form_helper
INFO - 2022-03-30 03:51:54 --> Helper loaded: common_helper
INFO - 2022-03-30 03:51:54 --> Database Driver Class Initialized
DEBUG - 2022-03-30 03:51:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 03:51:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 03:51:54 --> Controller Class Initialized
INFO - 2022-03-30 03:51:54 --> Form Validation Class Initialized
DEBUG - 2022-03-30 03:51:54 --> Encrypt Class Initialized
INFO - 2022-03-30 03:51:54 --> Model "Patient_model" initialized
INFO - 2022-03-30 03:51:54 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 03:51:54 --> Model "Referredby_model" initialized
INFO - 2022-03-30 03:51:54 --> Model "Prefix_master" initialized
INFO - 2022-03-30 03:51:54 --> Model "Hospital_model" initialized
INFO - 2022-03-30 03:51:54 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 03:51:54 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-30 03:51:54 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 03:51:54 --> Final output sent to browser
DEBUG - 2022-03-30 03:51:54 --> Total execution time: 0.0331
ERROR - 2022-03-30 03:51:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 03:51:55 --> Config Class Initialized
INFO - 2022-03-30 03:51:55 --> Hooks Class Initialized
DEBUG - 2022-03-30 03:51:55 --> UTF-8 Support Enabled
INFO - 2022-03-30 03:51:55 --> Utf8 Class Initialized
INFO - 2022-03-30 03:51:55 --> URI Class Initialized
INFO - 2022-03-30 03:51:55 --> Router Class Initialized
INFO - 2022-03-30 03:51:55 --> Output Class Initialized
INFO - 2022-03-30 03:51:55 --> Security Class Initialized
DEBUG - 2022-03-30 03:51:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 03:51:55 --> Input Class Initialized
INFO - 2022-03-30 03:51:55 --> Language Class Initialized
INFO - 2022-03-30 03:51:55 --> Loader Class Initialized
INFO - 2022-03-30 03:51:55 --> Helper loaded: url_helper
INFO - 2022-03-30 03:51:55 --> Helper loaded: form_helper
INFO - 2022-03-30 03:51:55 --> Helper loaded: common_helper
INFO - 2022-03-30 03:51:55 --> Database Driver Class Initialized
DEBUG - 2022-03-30 03:51:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 03:51:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 03:51:55 --> Controller Class Initialized
INFO - 2022-03-30 03:51:55 --> Form Validation Class Initialized
DEBUG - 2022-03-30 03:51:55 --> Encrypt Class Initialized
INFO - 2022-03-30 03:51:55 --> Model "Patient_model" initialized
INFO - 2022-03-30 03:51:55 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 03:51:55 --> Model "Prefix_master" initialized
INFO - 2022-03-30 03:51:55 --> Model "Users_model" initialized
INFO - 2022-03-30 03:51:55 --> Model "Hospital_model" initialized
INFO - 2022-03-30 03:51:55 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 03:51:55 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-30 03:51:55 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 03:51:55 --> Final output sent to browser
DEBUG - 2022-03-30 03:51:55 --> Total execution time: 0.0492
ERROR - 2022-03-30 03:52:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 03:52:13 --> Config Class Initialized
INFO - 2022-03-30 03:52:13 --> Hooks Class Initialized
DEBUG - 2022-03-30 03:52:13 --> UTF-8 Support Enabled
INFO - 2022-03-30 03:52:13 --> Utf8 Class Initialized
INFO - 2022-03-30 03:52:13 --> URI Class Initialized
INFO - 2022-03-30 03:52:13 --> Router Class Initialized
INFO - 2022-03-30 03:52:13 --> Output Class Initialized
INFO - 2022-03-30 03:52:13 --> Security Class Initialized
DEBUG - 2022-03-30 03:52:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 03:52:13 --> Input Class Initialized
INFO - 2022-03-30 03:52:13 --> Language Class Initialized
INFO - 2022-03-30 03:52:13 --> Loader Class Initialized
INFO - 2022-03-30 03:52:13 --> Helper loaded: url_helper
INFO - 2022-03-30 03:52:13 --> Helper loaded: form_helper
INFO - 2022-03-30 03:52:13 --> Helper loaded: common_helper
INFO - 2022-03-30 03:52:13 --> Database Driver Class Initialized
DEBUG - 2022-03-30 03:52:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 03:52:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 03:52:13 --> Controller Class Initialized
INFO - 2022-03-30 03:52:13 --> Form Validation Class Initialized
DEBUG - 2022-03-30 03:52:13 --> Encrypt Class Initialized
INFO - 2022-03-30 03:52:13 --> Model "Patient_model" initialized
INFO - 2022-03-30 03:52:13 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 03:52:13 --> Model "Referredby_model" initialized
INFO - 2022-03-30 03:52:13 --> Model "Prefix_master" initialized
INFO - 2022-03-30 03:52:13 --> Model "Hospital_model" initialized
ERROR - 2022-03-30 03:52:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 03:52:14 --> Config Class Initialized
INFO - 2022-03-30 03:52:14 --> Hooks Class Initialized
DEBUG - 2022-03-30 03:52:14 --> UTF-8 Support Enabled
INFO - 2022-03-30 03:52:14 --> Utf8 Class Initialized
INFO - 2022-03-30 03:52:14 --> URI Class Initialized
INFO - 2022-03-30 03:52:14 --> Router Class Initialized
INFO - 2022-03-30 03:52:14 --> Output Class Initialized
INFO - 2022-03-30 03:52:14 --> Security Class Initialized
DEBUG - 2022-03-30 03:52:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 03:52:14 --> Input Class Initialized
INFO - 2022-03-30 03:52:14 --> Language Class Initialized
INFO - 2022-03-30 03:52:14 --> Loader Class Initialized
INFO - 2022-03-30 03:52:14 --> Helper loaded: url_helper
INFO - 2022-03-30 03:52:14 --> Helper loaded: form_helper
INFO - 2022-03-30 03:52:14 --> Helper loaded: common_helper
INFO - 2022-03-30 03:52:14 --> Database Driver Class Initialized
DEBUG - 2022-03-30 03:52:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 03:52:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 03:52:14 --> Controller Class Initialized
INFO - 2022-03-30 03:52:14 --> Form Validation Class Initialized
DEBUG - 2022-03-30 03:52:14 --> Encrypt Class Initialized
INFO - 2022-03-30 03:52:14 --> Model "Patient_model" initialized
INFO - 2022-03-30 03:52:14 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 03:52:14 --> Model "Referredby_model" initialized
INFO - 2022-03-30 03:52:14 --> Model "Prefix_master" initialized
INFO - 2022-03-30 03:52:14 --> Model "Hospital_model" initialized
INFO - 2022-03-30 03:52:14 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 03:52:14 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-30 03:52:14 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 03:52:14 --> Final output sent to browser
DEBUG - 2022-03-30 03:52:14 --> Total execution time: 0.0285
ERROR - 2022-03-30 03:52:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 03:52:15 --> Config Class Initialized
INFO - 2022-03-30 03:52:15 --> Hooks Class Initialized
DEBUG - 2022-03-30 03:52:15 --> UTF-8 Support Enabled
INFO - 2022-03-30 03:52:15 --> Utf8 Class Initialized
INFO - 2022-03-30 03:52:15 --> URI Class Initialized
INFO - 2022-03-30 03:52:15 --> Router Class Initialized
INFO - 2022-03-30 03:52:15 --> Output Class Initialized
INFO - 2022-03-30 03:52:15 --> Security Class Initialized
DEBUG - 2022-03-30 03:52:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 03:52:15 --> Input Class Initialized
INFO - 2022-03-30 03:52:15 --> Language Class Initialized
INFO - 2022-03-30 03:52:15 --> Loader Class Initialized
INFO - 2022-03-30 03:52:15 --> Helper loaded: url_helper
INFO - 2022-03-30 03:52:15 --> Helper loaded: form_helper
INFO - 2022-03-30 03:52:15 --> Helper loaded: common_helper
INFO - 2022-03-30 03:52:15 --> Database Driver Class Initialized
DEBUG - 2022-03-30 03:52:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 03:52:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 03:52:15 --> Controller Class Initialized
INFO - 2022-03-30 03:52:15 --> Form Validation Class Initialized
DEBUG - 2022-03-30 03:52:15 --> Encrypt Class Initialized
INFO - 2022-03-30 03:52:15 --> Model "Patient_model" initialized
INFO - 2022-03-30 03:52:15 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 03:52:15 --> Model "Prefix_master" initialized
INFO - 2022-03-30 03:52:15 --> Model "Users_model" initialized
INFO - 2022-03-30 03:52:15 --> Model "Hospital_model" initialized
INFO - 2022-03-30 03:52:15 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 03:52:15 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-30 03:52:15 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 03:52:15 --> Final output sent to browser
DEBUG - 2022-03-30 03:52:15 --> Total execution time: 0.0480
ERROR - 2022-03-30 03:54:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 03:54:43 --> Config Class Initialized
INFO - 2022-03-30 03:54:43 --> Hooks Class Initialized
DEBUG - 2022-03-30 03:54:43 --> UTF-8 Support Enabled
INFO - 2022-03-30 03:54:43 --> Utf8 Class Initialized
INFO - 2022-03-30 03:54:43 --> URI Class Initialized
INFO - 2022-03-30 03:54:43 --> Router Class Initialized
INFO - 2022-03-30 03:54:43 --> Output Class Initialized
INFO - 2022-03-30 03:54:43 --> Security Class Initialized
DEBUG - 2022-03-30 03:54:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 03:54:43 --> Input Class Initialized
INFO - 2022-03-30 03:54:43 --> Language Class Initialized
INFO - 2022-03-30 03:54:43 --> Loader Class Initialized
INFO - 2022-03-30 03:54:43 --> Helper loaded: url_helper
INFO - 2022-03-30 03:54:43 --> Helper loaded: form_helper
INFO - 2022-03-30 03:54:43 --> Helper loaded: common_helper
INFO - 2022-03-30 03:54:43 --> Database Driver Class Initialized
DEBUG - 2022-03-30 03:54:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 03:54:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 03:54:43 --> Controller Class Initialized
INFO - 2022-03-30 03:54:43 --> Form Validation Class Initialized
DEBUG - 2022-03-30 03:54:43 --> Encrypt Class Initialized
INFO - 2022-03-30 03:54:43 --> Model "Patient_model" initialized
INFO - 2022-03-30 03:54:43 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 03:54:43 --> Model "Prefix_master" initialized
INFO - 2022-03-30 03:54:43 --> Model "Users_model" initialized
INFO - 2022-03-30 03:54:43 --> Model "Hospital_model" initialized
ERROR - 2022-03-30 03:54:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 03:54:44 --> Config Class Initialized
INFO - 2022-03-30 03:54:44 --> Hooks Class Initialized
DEBUG - 2022-03-30 03:54:44 --> UTF-8 Support Enabled
INFO - 2022-03-30 03:54:44 --> Utf8 Class Initialized
INFO - 2022-03-30 03:54:44 --> URI Class Initialized
INFO - 2022-03-30 03:54:44 --> Router Class Initialized
INFO - 2022-03-30 03:54:44 --> Output Class Initialized
INFO - 2022-03-30 03:54:44 --> Security Class Initialized
DEBUG - 2022-03-30 03:54:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 03:54:44 --> Input Class Initialized
INFO - 2022-03-30 03:54:44 --> Language Class Initialized
INFO - 2022-03-30 03:54:44 --> Loader Class Initialized
INFO - 2022-03-30 03:54:44 --> Helper loaded: url_helper
INFO - 2022-03-30 03:54:44 --> Helper loaded: form_helper
INFO - 2022-03-30 03:54:44 --> Helper loaded: common_helper
INFO - 2022-03-30 03:54:44 --> Database Driver Class Initialized
DEBUG - 2022-03-30 03:54:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 03:54:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 03:54:44 --> Controller Class Initialized
INFO - 2022-03-30 03:54:44 --> Form Validation Class Initialized
DEBUG - 2022-03-30 03:54:44 --> Encrypt Class Initialized
INFO - 2022-03-30 03:54:44 --> Model "Patient_model" initialized
INFO - 2022-03-30 03:54:44 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 03:54:44 --> Model "Prefix_master" initialized
INFO - 2022-03-30 03:54:44 --> Model "Users_model" initialized
INFO - 2022-03-30 03:54:44 --> Model "Hospital_model" initialized
INFO - 2022-03-30 03:54:44 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 03:54:44 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-30 03:54:44 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 03:54:44 --> Final output sent to browser
DEBUG - 2022-03-30 03:54:44 --> Total execution time: 0.0459
ERROR - 2022-03-30 04:01:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 04:01:37 --> Config Class Initialized
INFO - 2022-03-30 04:01:37 --> Hooks Class Initialized
DEBUG - 2022-03-30 04:01:37 --> UTF-8 Support Enabled
INFO - 2022-03-30 04:01:37 --> Utf8 Class Initialized
INFO - 2022-03-30 04:01:37 --> URI Class Initialized
INFO - 2022-03-30 04:01:37 --> Router Class Initialized
INFO - 2022-03-30 04:01:37 --> Output Class Initialized
INFO - 2022-03-30 04:01:37 --> Security Class Initialized
DEBUG - 2022-03-30 04:01:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 04:01:37 --> Input Class Initialized
INFO - 2022-03-30 04:01:37 --> Language Class Initialized
INFO - 2022-03-30 04:01:37 --> Loader Class Initialized
INFO - 2022-03-30 04:01:37 --> Helper loaded: url_helper
INFO - 2022-03-30 04:01:37 --> Helper loaded: form_helper
INFO - 2022-03-30 04:01:37 --> Helper loaded: common_helper
INFO - 2022-03-30 04:01:37 --> Database Driver Class Initialized
DEBUG - 2022-03-30 04:01:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 04:01:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 04:01:37 --> Controller Class Initialized
INFO - 2022-03-30 04:01:37 --> Form Validation Class Initialized
DEBUG - 2022-03-30 04:01:37 --> Encrypt Class Initialized
INFO - 2022-03-30 04:01:37 --> Model "Patient_model" initialized
INFO - 2022-03-30 04:01:37 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 04:01:37 --> Model "Prefix_master" initialized
INFO - 2022-03-30 04:01:37 --> Model "Users_model" initialized
INFO - 2022-03-30 04:01:37 --> Model "Hospital_model" initialized
ERROR - 2022-03-30 04:01:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 04:01:38 --> Config Class Initialized
INFO - 2022-03-30 04:01:38 --> Hooks Class Initialized
DEBUG - 2022-03-30 04:01:38 --> UTF-8 Support Enabled
INFO - 2022-03-30 04:01:38 --> Utf8 Class Initialized
INFO - 2022-03-30 04:01:38 --> URI Class Initialized
INFO - 2022-03-30 04:01:38 --> Router Class Initialized
INFO - 2022-03-30 04:01:38 --> Output Class Initialized
INFO - 2022-03-30 04:01:38 --> Security Class Initialized
DEBUG - 2022-03-30 04:01:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 04:01:38 --> Input Class Initialized
INFO - 2022-03-30 04:01:38 --> Language Class Initialized
INFO - 2022-03-30 04:01:38 --> Loader Class Initialized
INFO - 2022-03-30 04:01:38 --> Helper loaded: url_helper
INFO - 2022-03-30 04:01:38 --> Helper loaded: form_helper
INFO - 2022-03-30 04:01:38 --> Helper loaded: common_helper
INFO - 2022-03-30 04:01:38 --> Database Driver Class Initialized
DEBUG - 2022-03-30 04:01:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 04:01:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 04:01:38 --> Controller Class Initialized
INFO - 2022-03-30 04:01:38 --> Form Validation Class Initialized
DEBUG - 2022-03-30 04:01:38 --> Encrypt Class Initialized
INFO - 2022-03-30 04:01:38 --> Model "Patient_model" initialized
INFO - 2022-03-30 04:01:38 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 04:01:38 --> Model "Prefix_master" initialized
INFO - 2022-03-30 04:01:38 --> Model "Users_model" initialized
INFO - 2022-03-30 04:01:38 --> Model "Hospital_model" initialized
INFO - 2022-03-30 04:01:38 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 04:01:38 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-30 04:01:38 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 04:01:38 --> Final output sent to browser
DEBUG - 2022-03-30 04:01:38 --> Total execution time: 0.0916
ERROR - 2022-03-30 04:05:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 04:05:04 --> Config Class Initialized
INFO - 2022-03-30 04:05:04 --> Hooks Class Initialized
DEBUG - 2022-03-30 04:05:04 --> UTF-8 Support Enabled
INFO - 2022-03-30 04:05:04 --> Utf8 Class Initialized
INFO - 2022-03-30 04:05:04 --> URI Class Initialized
INFO - 2022-03-30 04:05:04 --> Router Class Initialized
INFO - 2022-03-30 04:05:04 --> Output Class Initialized
INFO - 2022-03-30 04:05:04 --> Security Class Initialized
DEBUG - 2022-03-30 04:05:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 04:05:04 --> Input Class Initialized
INFO - 2022-03-30 04:05:04 --> Language Class Initialized
INFO - 2022-03-30 04:05:04 --> Loader Class Initialized
INFO - 2022-03-30 04:05:04 --> Helper loaded: url_helper
INFO - 2022-03-30 04:05:04 --> Helper loaded: form_helper
INFO - 2022-03-30 04:05:04 --> Helper loaded: common_helper
INFO - 2022-03-30 04:05:04 --> Database Driver Class Initialized
DEBUG - 2022-03-30 04:05:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 04:05:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 04:05:04 --> Controller Class Initialized
INFO - 2022-03-30 04:05:04 --> Form Validation Class Initialized
DEBUG - 2022-03-30 04:05:04 --> Encrypt Class Initialized
INFO - 2022-03-30 04:05:04 --> Model "Patient_model" initialized
INFO - 2022-03-30 04:05:04 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 04:05:04 --> Model "Prefix_master" initialized
INFO - 2022-03-30 04:05:04 --> Model "Users_model" initialized
INFO - 2022-03-30 04:05:04 --> Model "Hospital_model" initialized
ERROR - 2022-03-30 04:05:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 04:05:04 --> Config Class Initialized
INFO - 2022-03-30 04:05:04 --> Hooks Class Initialized
DEBUG - 2022-03-30 04:05:04 --> UTF-8 Support Enabled
INFO - 2022-03-30 04:05:04 --> Utf8 Class Initialized
INFO - 2022-03-30 04:05:04 --> URI Class Initialized
INFO - 2022-03-30 04:05:04 --> Router Class Initialized
INFO - 2022-03-30 04:05:04 --> Output Class Initialized
INFO - 2022-03-30 04:05:04 --> Security Class Initialized
DEBUG - 2022-03-30 04:05:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 04:05:04 --> Input Class Initialized
INFO - 2022-03-30 04:05:04 --> Language Class Initialized
INFO - 2022-03-30 04:05:04 --> Loader Class Initialized
INFO - 2022-03-30 04:05:04 --> Helper loaded: url_helper
INFO - 2022-03-30 04:05:04 --> Helper loaded: form_helper
INFO - 2022-03-30 04:05:04 --> Helper loaded: common_helper
INFO - 2022-03-30 04:05:04 --> Database Driver Class Initialized
DEBUG - 2022-03-30 04:05:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 04:05:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 04:05:04 --> Controller Class Initialized
INFO - 2022-03-30 04:05:04 --> Form Validation Class Initialized
DEBUG - 2022-03-30 04:05:04 --> Encrypt Class Initialized
INFO - 2022-03-30 04:05:04 --> Model "Patient_model" initialized
INFO - 2022-03-30 04:05:04 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 04:05:04 --> Model "Prefix_master" initialized
INFO - 2022-03-30 04:05:04 --> Model "Users_model" initialized
INFO - 2022-03-30 04:05:04 --> Model "Hospital_model" initialized
INFO - 2022-03-30 04:05:04 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 04:05:04 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-30 04:05:04 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 04:05:04 --> Final output sent to browser
DEBUG - 2022-03-30 04:05:04 --> Total execution time: 0.0934
ERROR - 2022-03-30 04:05:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 04:05:19 --> Config Class Initialized
INFO - 2022-03-30 04:05:19 --> Hooks Class Initialized
DEBUG - 2022-03-30 04:05:19 --> UTF-8 Support Enabled
INFO - 2022-03-30 04:05:19 --> Utf8 Class Initialized
INFO - 2022-03-30 04:05:19 --> URI Class Initialized
INFO - 2022-03-30 04:05:19 --> Router Class Initialized
INFO - 2022-03-30 04:05:19 --> Output Class Initialized
INFO - 2022-03-30 04:05:19 --> Security Class Initialized
DEBUG - 2022-03-30 04:05:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 04:05:19 --> Input Class Initialized
INFO - 2022-03-30 04:05:19 --> Language Class Initialized
INFO - 2022-03-30 04:05:19 --> Loader Class Initialized
INFO - 2022-03-30 04:05:19 --> Helper loaded: url_helper
INFO - 2022-03-30 04:05:19 --> Helper loaded: form_helper
INFO - 2022-03-30 04:05:19 --> Helper loaded: common_helper
INFO - 2022-03-30 04:05:19 --> Database Driver Class Initialized
DEBUG - 2022-03-30 04:05:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 04:05:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 04:05:19 --> Controller Class Initialized
INFO - 2022-03-30 04:05:19 --> Form Validation Class Initialized
DEBUG - 2022-03-30 04:05:19 --> Encrypt Class Initialized
INFO - 2022-03-30 04:05:19 --> Model "Patient_model" initialized
INFO - 2022-03-30 04:05:19 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 04:05:19 --> Model "Prefix_master" initialized
INFO - 2022-03-30 04:05:19 --> Model "Users_model" initialized
INFO - 2022-03-30 04:05:19 --> Model "Hospital_model" initialized
ERROR - 2022-03-30 04:05:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 04:05:20 --> Config Class Initialized
INFO - 2022-03-30 04:05:20 --> Hooks Class Initialized
DEBUG - 2022-03-30 04:05:20 --> UTF-8 Support Enabled
INFO - 2022-03-30 04:05:20 --> Utf8 Class Initialized
INFO - 2022-03-30 04:05:20 --> URI Class Initialized
INFO - 2022-03-30 04:05:20 --> Router Class Initialized
INFO - 2022-03-30 04:05:20 --> Output Class Initialized
INFO - 2022-03-30 04:05:20 --> Security Class Initialized
DEBUG - 2022-03-30 04:05:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 04:05:20 --> Input Class Initialized
INFO - 2022-03-30 04:05:20 --> Language Class Initialized
INFO - 2022-03-30 04:05:20 --> Loader Class Initialized
INFO - 2022-03-30 04:05:20 --> Helper loaded: url_helper
INFO - 2022-03-30 04:05:20 --> Helper loaded: form_helper
INFO - 2022-03-30 04:05:20 --> Helper loaded: common_helper
INFO - 2022-03-30 04:05:20 --> Database Driver Class Initialized
DEBUG - 2022-03-30 04:05:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 04:05:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 04:05:20 --> Controller Class Initialized
INFO - 2022-03-30 04:05:20 --> Form Validation Class Initialized
DEBUG - 2022-03-30 04:05:20 --> Encrypt Class Initialized
INFO - 2022-03-30 04:05:20 --> Model "Patient_model" initialized
INFO - 2022-03-30 04:05:20 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 04:05:20 --> Model "Prefix_master" initialized
INFO - 2022-03-30 04:05:20 --> Model "Users_model" initialized
INFO - 2022-03-30 04:05:20 --> Model "Hospital_model" initialized
INFO - 2022-03-30 04:05:20 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 04:05:20 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-30 04:05:20 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 04:05:20 --> Final output sent to browser
DEBUG - 2022-03-30 04:05:20 --> Total execution time: 0.0435
ERROR - 2022-03-30 04:06:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 04:06:06 --> Config Class Initialized
INFO - 2022-03-30 04:06:06 --> Hooks Class Initialized
DEBUG - 2022-03-30 04:06:06 --> UTF-8 Support Enabled
INFO - 2022-03-30 04:06:06 --> Utf8 Class Initialized
INFO - 2022-03-30 04:06:06 --> URI Class Initialized
INFO - 2022-03-30 04:06:06 --> Router Class Initialized
INFO - 2022-03-30 04:06:06 --> Output Class Initialized
INFO - 2022-03-30 04:06:06 --> Security Class Initialized
DEBUG - 2022-03-30 04:06:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 04:06:06 --> Input Class Initialized
INFO - 2022-03-30 04:06:06 --> Language Class Initialized
INFO - 2022-03-30 04:06:06 --> Loader Class Initialized
INFO - 2022-03-30 04:06:06 --> Helper loaded: url_helper
INFO - 2022-03-30 04:06:06 --> Helper loaded: form_helper
INFO - 2022-03-30 04:06:06 --> Helper loaded: common_helper
INFO - 2022-03-30 04:06:06 --> Database Driver Class Initialized
DEBUG - 2022-03-30 04:06:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 04:06:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 04:06:06 --> Controller Class Initialized
INFO - 2022-03-30 04:06:06 --> Form Validation Class Initialized
DEBUG - 2022-03-30 04:06:06 --> Encrypt Class Initialized
INFO - 2022-03-30 04:06:06 --> Model "Patient_model" initialized
INFO - 2022-03-30 04:06:06 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 04:06:06 --> Model "Prefix_master" initialized
INFO - 2022-03-30 04:06:06 --> Model "Users_model" initialized
INFO - 2022-03-30 04:06:06 --> Model "Hospital_model" initialized
ERROR - 2022-03-30 04:06:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 04:06:06 --> Config Class Initialized
INFO - 2022-03-30 04:06:06 --> Hooks Class Initialized
DEBUG - 2022-03-30 04:06:06 --> UTF-8 Support Enabled
INFO - 2022-03-30 04:06:06 --> Utf8 Class Initialized
INFO - 2022-03-30 04:06:06 --> URI Class Initialized
INFO - 2022-03-30 04:06:06 --> Router Class Initialized
INFO - 2022-03-30 04:06:06 --> Output Class Initialized
INFO - 2022-03-30 04:06:06 --> Security Class Initialized
DEBUG - 2022-03-30 04:06:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 04:06:06 --> Input Class Initialized
INFO - 2022-03-30 04:06:06 --> Language Class Initialized
INFO - 2022-03-30 04:06:06 --> Loader Class Initialized
INFO - 2022-03-30 04:06:06 --> Helper loaded: url_helper
INFO - 2022-03-30 04:06:06 --> Helper loaded: form_helper
INFO - 2022-03-30 04:06:06 --> Helper loaded: common_helper
INFO - 2022-03-30 04:06:06 --> Database Driver Class Initialized
DEBUG - 2022-03-30 04:06:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 04:06:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 04:06:06 --> Controller Class Initialized
INFO - 2022-03-30 04:06:06 --> Form Validation Class Initialized
DEBUG - 2022-03-30 04:06:06 --> Encrypt Class Initialized
INFO - 2022-03-30 04:06:06 --> Model "Patient_model" initialized
INFO - 2022-03-30 04:06:06 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 04:06:06 --> Model "Prefix_master" initialized
INFO - 2022-03-30 04:06:06 --> Model "Users_model" initialized
INFO - 2022-03-30 04:06:06 --> Model "Hospital_model" initialized
INFO - 2022-03-30 04:06:06 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 04:06:06 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-30 04:06:06 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 04:06:06 --> Final output sent to browser
DEBUG - 2022-03-30 04:06:06 --> Total execution time: 0.0418
ERROR - 2022-03-30 04:07:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 04:07:53 --> Config Class Initialized
INFO - 2022-03-30 04:07:53 --> Hooks Class Initialized
DEBUG - 2022-03-30 04:07:53 --> UTF-8 Support Enabled
INFO - 2022-03-30 04:07:53 --> Utf8 Class Initialized
INFO - 2022-03-30 04:07:53 --> URI Class Initialized
INFO - 2022-03-30 04:07:53 --> Router Class Initialized
INFO - 2022-03-30 04:07:53 --> Output Class Initialized
INFO - 2022-03-30 04:07:53 --> Security Class Initialized
DEBUG - 2022-03-30 04:07:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 04:07:53 --> Input Class Initialized
INFO - 2022-03-30 04:07:53 --> Language Class Initialized
INFO - 2022-03-30 04:07:53 --> Loader Class Initialized
INFO - 2022-03-30 04:07:53 --> Helper loaded: url_helper
INFO - 2022-03-30 04:07:53 --> Helper loaded: form_helper
INFO - 2022-03-30 04:07:53 --> Helper loaded: common_helper
INFO - 2022-03-30 04:07:53 --> Database Driver Class Initialized
DEBUG - 2022-03-30 04:07:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 04:07:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 04:07:53 --> Controller Class Initialized
INFO - 2022-03-30 04:07:53 --> Form Validation Class Initialized
DEBUG - 2022-03-30 04:07:53 --> Encrypt Class Initialized
INFO - 2022-03-30 04:07:53 --> Model "Patient_model" initialized
INFO - 2022-03-30 04:07:53 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 04:07:53 --> Model "Referredby_model" initialized
INFO - 2022-03-30 04:07:53 --> Model "Prefix_master" initialized
INFO - 2022-03-30 04:07:53 --> Model "Hospital_model" initialized
INFO - 2022-03-30 04:07:53 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 04:07:53 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-30 04:07:53 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 04:07:53 --> Final output sent to browser
DEBUG - 2022-03-30 04:07:53 --> Total execution time: 0.0555
ERROR - 2022-03-30 04:15:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 04:15:55 --> Config Class Initialized
INFO - 2022-03-30 04:15:55 --> Hooks Class Initialized
DEBUG - 2022-03-30 04:15:55 --> UTF-8 Support Enabled
INFO - 2022-03-30 04:15:55 --> Utf8 Class Initialized
INFO - 2022-03-30 04:15:55 --> URI Class Initialized
INFO - 2022-03-30 04:15:55 --> Router Class Initialized
INFO - 2022-03-30 04:15:55 --> Output Class Initialized
INFO - 2022-03-30 04:15:55 --> Security Class Initialized
DEBUG - 2022-03-30 04:15:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 04:15:55 --> Input Class Initialized
INFO - 2022-03-30 04:15:55 --> Language Class Initialized
INFO - 2022-03-30 04:15:55 --> Loader Class Initialized
INFO - 2022-03-30 04:15:55 --> Helper loaded: url_helper
INFO - 2022-03-30 04:15:55 --> Helper loaded: form_helper
INFO - 2022-03-30 04:15:55 --> Helper loaded: common_helper
INFO - 2022-03-30 04:15:55 --> Database Driver Class Initialized
DEBUG - 2022-03-30 04:15:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 04:15:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 04:15:55 --> Controller Class Initialized
INFO - 2022-03-30 04:15:55 --> Form Validation Class Initialized
DEBUG - 2022-03-30 04:15:55 --> Encrypt Class Initialized
INFO - 2022-03-30 04:15:55 --> Model "Patient_model" initialized
INFO - 2022-03-30 04:15:55 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 04:15:55 --> Model "Prefix_master" initialized
INFO - 2022-03-30 04:15:55 --> Model "Users_model" initialized
INFO - 2022-03-30 04:15:55 --> Model "Hospital_model" initialized
ERROR - 2022-03-30 04:15:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 04:15:55 --> Config Class Initialized
INFO - 2022-03-30 04:15:55 --> Hooks Class Initialized
DEBUG - 2022-03-30 04:15:55 --> UTF-8 Support Enabled
INFO - 2022-03-30 04:15:55 --> Utf8 Class Initialized
INFO - 2022-03-30 04:15:55 --> URI Class Initialized
INFO - 2022-03-30 04:15:55 --> Router Class Initialized
INFO - 2022-03-30 04:15:55 --> Output Class Initialized
INFO - 2022-03-30 04:15:55 --> Security Class Initialized
DEBUG - 2022-03-30 04:15:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 04:15:55 --> Input Class Initialized
INFO - 2022-03-30 04:15:55 --> Language Class Initialized
INFO - 2022-03-30 04:15:55 --> Loader Class Initialized
INFO - 2022-03-30 04:15:55 --> Helper loaded: url_helper
INFO - 2022-03-30 04:15:55 --> Helper loaded: form_helper
INFO - 2022-03-30 04:15:55 --> Helper loaded: common_helper
INFO - 2022-03-30 04:15:55 --> Database Driver Class Initialized
DEBUG - 2022-03-30 04:15:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 04:15:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 04:15:55 --> Controller Class Initialized
INFO - 2022-03-30 04:15:55 --> Form Validation Class Initialized
DEBUG - 2022-03-30 04:15:55 --> Encrypt Class Initialized
INFO - 2022-03-30 04:15:55 --> Model "Patient_model" initialized
INFO - 2022-03-30 04:15:55 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 04:15:55 --> Model "Prefix_master" initialized
INFO - 2022-03-30 04:15:55 --> Model "Users_model" initialized
INFO - 2022-03-30 04:15:55 --> Model "Hospital_model" initialized
INFO - 2022-03-30 04:15:55 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 04:15:55 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-30 04:15:55 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 04:15:55 --> Final output sent to browser
DEBUG - 2022-03-30 04:15:55 --> Total execution time: 0.0396
ERROR - 2022-03-30 04:16:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 04:16:30 --> Config Class Initialized
INFO - 2022-03-30 04:16:30 --> Hooks Class Initialized
DEBUG - 2022-03-30 04:16:30 --> UTF-8 Support Enabled
INFO - 2022-03-30 04:16:30 --> Utf8 Class Initialized
INFO - 2022-03-30 04:16:30 --> URI Class Initialized
INFO - 2022-03-30 04:16:30 --> Router Class Initialized
INFO - 2022-03-30 04:16:30 --> Output Class Initialized
INFO - 2022-03-30 04:16:30 --> Security Class Initialized
DEBUG - 2022-03-30 04:16:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 04:16:30 --> Input Class Initialized
INFO - 2022-03-30 04:16:30 --> Language Class Initialized
INFO - 2022-03-30 04:16:30 --> Loader Class Initialized
INFO - 2022-03-30 04:16:30 --> Helper loaded: url_helper
INFO - 2022-03-30 04:16:30 --> Helper loaded: form_helper
INFO - 2022-03-30 04:16:30 --> Helper loaded: common_helper
INFO - 2022-03-30 04:16:30 --> Database Driver Class Initialized
DEBUG - 2022-03-30 04:16:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 04:16:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 04:16:30 --> Controller Class Initialized
INFO - 2022-03-30 04:16:30 --> Form Validation Class Initialized
DEBUG - 2022-03-30 04:16:30 --> Encrypt Class Initialized
INFO - 2022-03-30 04:16:30 --> Model "Patient_model" initialized
INFO - 2022-03-30 04:16:30 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 04:16:30 --> Model "Prefix_master" initialized
INFO - 2022-03-30 04:16:30 --> Model "Users_model" initialized
INFO - 2022-03-30 04:16:30 --> Model "Hospital_model" initialized
ERROR - 2022-03-30 04:16:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 04:16:31 --> Config Class Initialized
INFO - 2022-03-30 04:16:31 --> Hooks Class Initialized
DEBUG - 2022-03-30 04:16:31 --> UTF-8 Support Enabled
INFO - 2022-03-30 04:16:31 --> Utf8 Class Initialized
INFO - 2022-03-30 04:16:31 --> URI Class Initialized
INFO - 2022-03-30 04:16:31 --> Router Class Initialized
INFO - 2022-03-30 04:16:31 --> Output Class Initialized
INFO - 2022-03-30 04:16:31 --> Security Class Initialized
DEBUG - 2022-03-30 04:16:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 04:16:31 --> Input Class Initialized
INFO - 2022-03-30 04:16:31 --> Language Class Initialized
INFO - 2022-03-30 04:16:31 --> Loader Class Initialized
INFO - 2022-03-30 04:16:31 --> Helper loaded: url_helper
INFO - 2022-03-30 04:16:31 --> Helper loaded: form_helper
INFO - 2022-03-30 04:16:31 --> Helper loaded: common_helper
INFO - 2022-03-30 04:16:31 --> Database Driver Class Initialized
DEBUG - 2022-03-30 04:16:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 04:16:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 04:16:31 --> Controller Class Initialized
INFO - 2022-03-30 04:16:31 --> Form Validation Class Initialized
DEBUG - 2022-03-30 04:16:31 --> Encrypt Class Initialized
INFO - 2022-03-30 04:16:31 --> Model "Patient_model" initialized
INFO - 2022-03-30 04:16:31 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 04:16:31 --> Model "Prefix_master" initialized
INFO - 2022-03-30 04:16:31 --> Model "Users_model" initialized
INFO - 2022-03-30 04:16:31 --> Model "Hospital_model" initialized
INFO - 2022-03-30 04:16:31 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 04:16:31 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-30 04:16:31 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 04:16:31 --> Final output sent to browser
DEBUG - 2022-03-30 04:16:31 --> Total execution time: 0.0494
ERROR - 2022-03-30 04:17:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 04:17:53 --> Config Class Initialized
INFO - 2022-03-30 04:17:53 --> Hooks Class Initialized
DEBUG - 2022-03-30 04:17:53 --> UTF-8 Support Enabled
INFO - 2022-03-30 04:17:53 --> Utf8 Class Initialized
INFO - 2022-03-30 04:17:53 --> URI Class Initialized
INFO - 2022-03-30 04:17:53 --> Router Class Initialized
INFO - 2022-03-30 04:17:53 --> Output Class Initialized
INFO - 2022-03-30 04:17:53 --> Security Class Initialized
DEBUG - 2022-03-30 04:17:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 04:17:53 --> Input Class Initialized
INFO - 2022-03-30 04:17:53 --> Language Class Initialized
INFO - 2022-03-30 04:17:53 --> Loader Class Initialized
INFO - 2022-03-30 04:17:53 --> Helper loaded: url_helper
INFO - 2022-03-30 04:17:53 --> Helper loaded: form_helper
INFO - 2022-03-30 04:17:53 --> Helper loaded: common_helper
INFO - 2022-03-30 04:17:53 --> Database Driver Class Initialized
DEBUG - 2022-03-30 04:17:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 04:17:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 04:17:53 --> Controller Class Initialized
INFO - 2022-03-30 04:17:53 --> Form Validation Class Initialized
DEBUG - 2022-03-30 04:17:53 --> Encrypt Class Initialized
INFO - 2022-03-30 04:17:53 --> Model "Patient_model" initialized
INFO - 2022-03-30 04:17:53 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 04:17:53 --> Model "Referredby_model" initialized
INFO - 2022-03-30 04:17:53 --> Model "Prefix_master" initialized
INFO - 2022-03-30 04:17:53 --> Model "Hospital_model" initialized
ERROR - 2022-03-30 04:17:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 04:17:54 --> Config Class Initialized
INFO - 2022-03-30 04:17:54 --> Hooks Class Initialized
DEBUG - 2022-03-30 04:17:54 --> UTF-8 Support Enabled
INFO - 2022-03-30 04:17:54 --> Utf8 Class Initialized
INFO - 2022-03-30 04:17:54 --> URI Class Initialized
INFO - 2022-03-30 04:17:54 --> Router Class Initialized
INFO - 2022-03-30 04:17:54 --> Output Class Initialized
INFO - 2022-03-30 04:17:54 --> Security Class Initialized
DEBUG - 2022-03-30 04:17:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 04:17:54 --> Input Class Initialized
INFO - 2022-03-30 04:17:54 --> Language Class Initialized
INFO - 2022-03-30 04:17:54 --> Loader Class Initialized
INFO - 2022-03-30 04:17:54 --> Helper loaded: url_helper
INFO - 2022-03-30 04:17:54 --> Helper loaded: form_helper
INFO - 2022-03-30 04:17:54 --> Helper loaded: common_helper
INFO - 2022-03-30 04:17:54 --> Database Driver Class Initialized
DEBUG - 2022-03-30 04:17:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 04:17:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 04:17:54 --> Controller Class Initialized
INFO - 2022-03-30 04:17:54 --> Form Validation Class Initialized
DEBUG - 2022-03-30 04:17:54 --> Encrypt Class Initialized
INFO - 2022-03-30 04:17:54 --> Model "Patient_model" initialized
INFO - 2022-03-30 04:17:54 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 04:17:54 --> Model "Referredby_model" initialized
INFO - 2022-03-30 04:17:54 --> Model "Prefix_master" initialized
INFO - 2022-03-30 04:17:54 --> Model "Hospital_model" initialized
INFO - 2022-03-30 04:17:54 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 04:17:54 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-30 04:17:54 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 04:17:54 --> Final output sent to browser
DEBUG - 2022-03-30 04:17:54 --> Total execution time: 0.0322
ERROR - 2022-03-30 04:17:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 04:17:55 --> Config Class Initialized
INFO - 2022-03-30 04:17:55 --> Hooks Class Initialized
DEBUG - 2022-03-30 04:17:55 --> UTF-8 Support Enabled
INFO - 2022-03-30 04:17:55 --> Utf8 Class Initialized
INFO - 2022-03-30 04:17:55 --> URI Class Initialized
INFO - 2022-03-30 04:17:55 --> Router Class Initialized
INFO - 2022-03-30 04:17:55 --> Output Class Initialized
INFO - 2022-03-30 04:17:55 --> Security Class Initialized
DEBUG - 2022-03-30 04:17:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 04:17:55 --> Input Class Initialized
INFO - 2022-03-30 04:17:55 --> Language Class Initialized
INFO - 2022-03-30 04:17:55 --> Loader Class Initialized
INFO - 2022-03-30 04:17:55 --> Helper loaded: url_helper
INFO - 2022-03-30 04:17:55 --> Helper loaded: form_helper
INFO - 2022-03-30 04:17:55 --> Helper loaded: common_helper
INFO - 2022-03-30 04:17:55 --> Database Driver Class Initialized
DEBUG - 2022-03-30 04:17:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 04:17:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 04:17:55 --> Controller Class Initialized
INFO - 2022-03-30 04:17:55 --> Form Validation Class Initialized
DEBUG - 2022-03-30 04:17:55 --> Encrypt Class Initialized
INFO - 2022-03-30 04:17:55 --> Model "Patient_model" initialized
INFO - 2022-03-30 04:17:55 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 04:17:55 --> Model "Prefix_master" initialized
INFO - 2022-03-30 04:17:55 --> Model "Users_model" initialized
INFO - 2022-03-30 04:17:55 --> Model "Hospital_model" initialized
INFO - 2022-03-30 04:17:55 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 04:17:55 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-30 04:17:55 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 04:17:55 --> Final output sent to browser
DEBUG - 2022-03-30 04:17:55 --> Total execution time: 0.0389
ERROR - 2022-03-30 04:18:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 04:18:52 --> Config Class Initialized
INFO - 2022-03-30 04:18:52 --> Hooks Class Initialized
DEBUG - 2022-03-30 04:18:52 --> UTF-8 Support Enabled
INFO - 2022-03-30 04:18:52 --> Utf8 Class Initialized
INFO - 2022-03-30 04:18:52 --> URI Class Initialized
INFO - 2022-03-30 04:18:52 --> Router Class Initialized
INFO - 2022-03-30 04:18:52 --> Output Class Initialized
INFO - 2022-03-30 04:18:52 --> Security Class Initialized
DEBUG - 2022-03-30 04:18:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 04:18:52 --> Input Class Initialized
INFO - 2022-03-30 04:18:52 --> Language Class Initialized
INFO - 2022-03-30 04:18:52 --> Loader Class Initialized
INFO - 2022-03-30 04:18:52 --> Helper loaded: url_helper
INFO - 2022-03-30 04:18:52 --> Helper loaded: form_helper
INFO - 2022-03-30 04:18:52 --> Helper loaded: common_helper
INFO - 2022-03-30 04:18:52 --> Database Driver Class Initialized
DEBUG - 2022-03-30 04:18:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 04:18:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 04:18:52 --> Controller Class Initialized
INFO - 2022-03-30 04:18:52 --> Form Validation Class Initialized
DEBUG - 2022-03-30 04:18:52 --> Encrypt Class Initialized
INFO - 2022-03-30 04:18:52 --> Model "Patient_model" initialized
INFO - 2022-03-30 04:18:52 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 04:18:52 --> Model "Prefix_master" initialized
INFO - 2022-03-30 04:18:52 --> Model "Users_model" initialized
INFO - 2022-03-30 04:18:52 --> Model "Hospital_model" initialized
INFO - 2022-03-30 04:18:53 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 04:18:53 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-30 04:18:53 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 04:18:53 --> Final output sent to browser
DEBUG - 2022-03-30 04:18:53 --> Total execution time: 0.0749
ERROR - 2022-03-30 04:23:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 04:23:15 --> Config Class Initialized
INFO - 2022-03-30 04:23:15 --> Hooks Class Initialized
DEBUG - 2022-03-30 04:23:15 --> UTF-8 Support Enabled
INFO - 2022-03-30 04:23:15 --> Utf8 Class Initialized
INFO - 2022-03-30 04:23:15 --> URI Class Initialized
INFO - 2022-03-30 04:23:15 --> Router Class Initialized
INFO - 2022-03-30 04:23:15 --> Output Class Initialized
INFO - 2022-03-30 04:23:15 --> Security Class Initialized
DEBUG - 2022-03-30 04:23:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 04:23:15 --> Input Class Initialized
INFO - 2022-03-30 04:23:15 --> Language Class Initialized
INFO - 2022-03-30 04:23:15 --> Loader Class Initialized
INFO - 2022-03-30 04:23:15 --> Helper loaded: url_helper
INFO - 2022-03-30 04:23:15 --> Helper loaded: form_helper
INFO - 2022-03-30 04:23:15 --> Helper loaded: common_helper
INFO - 2022-03-30 04:23:15 --> Database Driver Class Initialized
DEBUG - 2022-03-30 04:23:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 04:23:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 04:23:15 --> Controller Class Initialized
INFO - 2022-03-30 04:23:15 --> Form Validation Class Initialized
DEBUG - 2022-03-30 04:23:15 --> Encrypt Class Initialized
INFO - 2022-03-30 04:23:15 --> Model "Patient_model" initialized
INFO - 2022-03-30 04:23:15 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 04:23:15 --> Model "Referredby_model" initialized
INFO - 2022-03-30 04:23:15 --> Model "Prefix_master" initialized
INFO - 2022-03-30 04:23:15 --> Model "Hospital_model" initialized
INFO - 2022-03-30 04:23:15 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 04:23:21 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-30 04:23:21 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 04:23:23 --> Final output sent to browser
DEBUG - 2022-03-30 04:23:23 --> Total execution time: 6.2360
ERROR - 2022-03-30 04:24:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 04:24:13 --> Config Class Initialized
INFO - 2022-03-30 04:24:13 --> Hooks Class Initialized
DEBUG - 2022-03-30 04:24:13 --> UTF-8 Support Enabled
INFO - 2022-03-30 04:24:13 --> Utf8 Class Initialized
INFO - 2022-03-30 04:24:13 --> URI Class Initialized
INFO - 2022-03-30 04:24:13 --> Router Class Initialized
INFO - 2022-03-30 04:24:13 --> Output Class Initialized
INFO - 2022-03-30 04:24:13 --> Security Class Initialized
DEBUG - 2022-03-30 04:24:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 04:24:13 --> Input Class Initialized
INFO - 2022-03-30 04:24:13 --> Language Class Initialized
INFO - 2022-03-30 04:24:13 --> Loader Class Initialized
INFO - 2022-03-30 04:24:13 --> Helper loaded: url_helper
INFO - 2022-03-30 04:24:13 --> Helper loaded: form_helper
INFO - 2022-03-30 04:24:13 --> Helper loaded: common_helper
INFO - 2022-03-30 04:24:13 --> Database Driver Class Initialized
DEBUG - 2022-03-30 04:24:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 04:24:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 04:24:14 --> Controller Class Initialized
INFO - 2022-03-30 04:24:14 --> Form Validation Class Initialized
DEBUG - 2022-03-30 04:24:14 --> Encrypt Class Initialized
INFO - 2022-03-30 04:24:14 --> Model "Patient_model" initialized
INFO - 2022-03-30 04:24:14 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 04:24:14 --> Model "Referredby_model" initialized
INFO - 2022-03-30 04:24:14 --> Model "Prefix_master" initialized
INFO - 2022-03-30 04:24:14 --> Model "Hospital_model" initialized
INFO - 2022-03-30 04:24:14 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 04:24:14 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-30 04:24:14 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 04:24:14 --> Final output sent to browser
DEBUG - 2022-03-30 04:24:14 --> Total execution time: 0.6272
ERROR - 2022-03-30 04:25:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 04:25:09 --> Config Class Initialized
INFO - 2022-03-30 04:25:09 --> Hooks Class Initialized
DEBUG - 2022-03-30 04:25:09 --> UTF-8 Support Enabled
INFO - 2022-03-30 04:25:09 --> Utf8 Class Initialized
INFO - 2022-03-30 04:25:09 --> URI Class Initialized
INFO - 2022-03-30 04:25:09 --> Router Class Initialized
INFO - 2022-03-30 04:25:09 --> Output Class Initialized
INFO - 2022-03-30 04:25:09 --> Security Class Initialized
DEBUG - 2022-03-30 04:25:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 04:25:09 --> Input Class Initialized
INFO - 2022-03-30 04:25:09 --> Language Class Initialized
INFO - 2022-03-30 04:25:09 --> Loader Class Initialized
INFO - 2022-03-30 04:25:09 --> Helper loaded: url_helper
INFO - 2022-03-30 04:25:09 --> Helper loaded: form_helper
INFO - 2022-03-30 04:25:09 --> Helper loaded: common_helper
INFO - 2022-03-30 04:25:09 --> Database Driver Class Initialized
DEBUG - 2022-03-30 04:25:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 04:25:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 04:25:09 --> Controller Class Initialized
INFO - 2022-03-30 04:25:09 --> Form Validation Class Initialized
DEBUG - 2022-03-30 04:25:09 --> Encrypt Class Initialized
INFO - 2022-03-30 04:25:09 --> Model "Patient_model" initialized
INFO - 2022-03-30 04:25:09 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 04:25:09 --> Model "Referredby_model" initialized
INFO - 2022-03-30 04:25:09 --> Model "Prefix_master" initialized
INFO - 2022-03-30 04:25:09 --> Model "Hospital_model" initialized
INFO - 2022-03-30 04:25:09 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 04:25:15 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-30 04:25:15 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 04:25:17 --> Final output sent to browser
DEBUG - 2022-03-30 04:25:17 --> Total execution time: 6.0326
ERROR - 2022-03-30 04:25:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 04:25:44 --> Config Class Initialized
INFO - 2022-03-30 04:25:44 --> Hooks Class Initialized
DEBUG - 2022-03-30 04:25:44 --> UTF-8 Support Enabled
INFO - 2022-03-30 04:25:44 --> Utf8 Class Initialized
INFO - 2022-03-30 04:25:44 --> URI Class Initialized
INFO - 2022-03-30 04:25:44 --> Router Class Initialized
INFO - 2022-03-30 04:25:44 --> Output Class Initialized
INFO - 2022-03-30 04:25:44 --> Security Class Initialized
DEBUG - 2022-03-30 04:25:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 04:25:44 --> Input Class Initialized
INFO - 2022-03-30 04:25:44 --> Language Class Initialized
INFO - 2022-03-30 04:25:44 --> Loader Class Initialized
INFO - 2022-03-30 04:25:44 --> Helper loaded: url_helper
INFO - 2022-03-30 04:25:44 --> Helper loaded: form_helper
INFO - 2022-03-30 04:25:44 --> Helper loaded: common_helper
INFO - 2022-03-30 04:25:44 --> Database Driver Class Initialized
DEBUG - 2022-03-30 04:25:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 04:25:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 04:25:44 --> Controller Class Initialized
INFO - 2022-03-30 04:25:44 --> Form Validation Class Initialized
DEBUG - 2022-03-30 04:25:44 --> Encrypt Class Initialized
INFO - 2022-03-30 04:25:44 --> Model "Patient_model" initialized
INFO - 2022-03-30 04:25:44 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 04:25:44 --> Model "Referredby_model" initialized
INFO - 2022-03-30 04:25:44 --> Model "Prefix_master" initialized
INFO - 2022-03-30 04:25:44 --> Model "Hospital_model" initialized
INFO - 2022-03-30 04:25:44 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 04:25:44 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-30 04:25:44 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 04:25:44 --> Final output sent to browser
DEBUG - 2022-03-30 04:25:44 --> Total execution time: 0.0419
ERROR - 2022-03-30 04:30:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 04:30:40 --> Config Class Initialized
INFO - 2022-03-30 04:30:40 --> Hooks Class Initialized
DEBUG - 2022-03-30 04:30:40 --> UTF-8 Support Enabled
INFO - 2022-03-30 04:30:40 --> Utf8 Class Initialized
INFO - 2022-03-30 04:30:40 --> URI Class Initialized
INFO - 2022-03-30 04:30:40 --> Router Class Initialized
INFO - 2022-03-30 04:30:40 --> Output Class Initialized
INFO - 2022-03-30 04:30:40 --> Security Class Initialized
DEBUG - 2022-03-30 04:30:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 04:30:40 --> Input Class Initialized
INFO - 2022-03-30 04:30:40 --> Language Class Initialized
INFO - 2022-03-30 04:30:40 --> Loader Class Initialized
INFO - 2022-03-30 04:30:40 --> Helper loaded: url_helper
INFO - 2022-03-30 04:30:40 --> Helper loaded: form_helper
INFO - 2022-03-30 04:30:40 --> Helper loaded: common_helper
INFO - 2022-03-30 04:30:40 --> Database Driver Class Initialized
DEBUG - 2022-03-30 04:30:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 04:30:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 04:30:40 --> Controller Class Initialized
INFO - 2022-03-30 04:30:40 --> Form Validation Class Initialized
DEBUG - 2022-03-30 04:30:40 --> Encrypt Class Initialized
INFO - 2022-03-30 04:30:40 --> Model "Patient_model" initialized
INFO - 2022-03-30 04:30:40 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 04:30:40 --> Model "Referredby_model" initialized
INFO - 2022-03-30 04:30:40 --> Model "Prefix_master" initialized
INFO - 2022-03-30 04:30:40 --> Model "Hospital_model" initialized
ERROR - 2022-03-30 04:30:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 04:30:41 --> Config Class Initialized
INFO - 2022-03-30 04:30:41 --> Hooks Class Initialized
DEBUG - 2022-03-30 04:30:41 --> UTF-8 Support Enabled
INFO - 2022-03-30 04:30:41 --> Utf8 Class Initialized
INFO - 2022-03-30 04:30:41 --> URI Class Initialized
INFO - 2022-03-30 04:30:41 --> Router Class Initialized
INFO - 2022-03-30 04:30:41 --> Output Class Initialized
INFO - 2022-03-30 04:30:41 --> Security Class Initialized
DEBUG - 2022-03-30 04:30:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 04:30:41 --> Input Class Initialized
INFO - 2022-03-30 04:30:41 --> Language Class Initialized
INFO - 2022-03-30 04:30:41 --> Loader Class Initialized
INFO - 2022-03-30 04:30:41 --> Helper loaded: url_helper
INFO - 2022-03-30 04:30:41 --> Helper loaded: form_helper
INFO - 2022-03-30 04:30:41 --> Helper loaded: common_helper
INFO - 2022-03-30 04:30:41 --> Database Driver Class Initialized
DEBUG - 2022-03-30 04:30:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 04:30:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 04:30:41 --> Controller Class Initialized
INFO - 2022-03-30 04:30:41 --> Form Validation Class Initialized
DEBUG - 2022-03-30 04:30:41 --> Encrypt Class Initialized
INFO - 2022-03-30 04:30:41 --> Model "Patient_model" initialized
INFO - 2022-03-30 04:30:41 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 04:30:41 --> Model "Referredby_model" initialized
INFO - 2022-03-30 04:30:41 --> Model "Prefix_master" initialized
INFO - 2022-03-30 04:30:41 --> Model "Hospital_model" initialized
INFO - 2022-03-30 04:30:41 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 04:30:41 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-30 04:30:41 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 04:30:41 --> Final output sent to browser
DEBUG - 2022-03-30 04:30:41 --> Total execution time: 0.0369
ERROR - 2022-03-30 04:30:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 04:30:42 --> Config Class Initialized
INFO - 2022-03-30 04:30:42 --> Hooks Class Initialized
DEBUG - 2022-03-30 04:30:42 --> UTF-8 Support Enabled
INFO - 2022-03-30 04:30:42 --> Utf8 Class Initialized
INFO - 2022-03-30 04:30:42 --> URI Class Initialized
INFO - 2022-03-30 04:30:42 --> Router Class Initialized
INFO - 2022-03-30 04:30:42 --> Output Class Initialized
INFO - 2022-03-30 04:30:42 --> Security Class Initialized
DEBUG - 2022-03-30 04:30:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 04:30:42 --> Input Class Initialized
INFO - 2022-03-30 04:30:42 --> Language Class Initialized
INFO - 2022-03-30 04:30:42 --> Loader Class Initialized
INFO - 2022-03-30 04:30:42 --> Helper loaded: url_helper
INFO - 2022-03-30 04:30:42 --> Helper loaded: form_helper
INFO - 2022-03-30 04:30:42 --> Helper loaded: common_helper
INFO - 2022-03-30 04:30:42 --> Database Driver Class Initialized
DEBUG - 2022-03-30 04:30:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 04:30:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 04:30:42 --> Controller Class Initialized
INFO - 2022-03-30 04:30:42 --> Form Validation Class Initialized
DEBUG - 2022-03-30 04:30:42 --> Encrypt Class Initialized
INFO - 2022-03-30 04:30:42 --> Model "Patient_model" initialized
INFO - 2022-03-30 04:30:42 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 04:30:42 --> Model "Prefix_master" initialized
INFO - 2022-03-30 04:30:42 --> Model "Users_model" initialized
INFO - 2022-03-30 04:30:42 --> Model "Hospital_model" initialized
INFO - 2022-03-30 04:30:42 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 04:30:42 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-30 04:30:42 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 04:30:42 --> Final output sent to browser
DEBUG - 2022-03-30 04:30:42 --> Total execution time: 0.0871
ERROR - 2022-03-30 04:36:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 04:36:17 --> Config Class Initialized
INFO - 2022-03-30 04:36:17 --> Hooks Class Initialized
DEBUG - 2022-03-30 04:36:17 --> UTF-8 Support Enabled
INFO - 2022-03-30 04:36:17 --> Utf8 Class Initialized
INFO - 2022-03-30 04:36:17 --> URI Class Initialized
INFO - 2022-03-30 04:36:17 --> Router Class Initialized
INFO - 2022-03-30 04:36:17 --> Output Class Initialized
INFO - 2022-03-30 04:36:17 --> Security Class Initialized
DEBUG - 2022-03-30 04:36:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 04:36:17 --> Input Class Initialized
INFO - 2022-03-30 04:36:17 --> Language Class Initialized
INFO - 2022-03-30 04:36:17 --> Loader Class Initialized
INFO - 2022-03-30 04:36:17 --> Helper loaded: url_helper
INFO - 2022-03-30 04:36:17 --> Helper loaded: form_helper
INFO - 2022-03-30 04:36:17 --> Helper loaded: common_helper
INFO - 2022-03-30 04:36:17 --> Database Driver Class Initialized
DEBUG - 2022-03-30 04:36:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 04:36:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 04:36:17 --> Controller Class Initialized
INFO - 2022-03-30 04:36:17 --> Form Validation Class Initialized
DEBUG - 2022-03-30 04:36:17 --> Encrypt Class Initialized
INFO - 2022-03-30 04:36:17 --> Model "Patient_model" initialized
INFO - 2022-03-30 04:36:17 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 04:36:17 --> Model "Referredby_model" initialized
INFO - 2022-03-30 04:36:17 --> Model "Prefix_master" initialized
INFO - 2022-03-30 04:36:17 --> Model "Hospital_model" initialized
INFO - 2022-03-30 04:36:17 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 04:36:17 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-30 04:36:17 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 04:36:17 --> Final output sent to browser
DEBUG - 2022-03-30 04:36:17 --> Total execution time: 0.0817
ERROR - 2022-03-30 04:39:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 04:39:39 --> Config Class Initialized
INFO - 2022-03-30 04:39:39 --> Hooks Class Initialized
DEBUG - 2022-03-30 04:39:39 --> UTF-8 Support Enabled
INFO - 2022-03-30 04:39:39 --> Utf8 Class Initialized
INFO - 2022-03-30 04:39:39 --> URI Class Initialized
INFO - 2022-03-30 04:39:39 --> Router Class Initialized
INFO - 2022-03-30 04:39:39 --> Output Class Initialized
INFO - 2022-03-30 04:39:39 --> Security Class Initialized
DEBUG - 2022-03-30 04:39:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 04:39:39 --> Input Class Initialized
INFO - 2022-03-30 04:39:39 --> Language Class Initialized
INFO - 2022-03-30 04:39:39 --> Loader Class Initialized
INFO - 2022-03-30 04:39:39 --> Helper loaded: url_helper
INFO - 2022-03-30 04:39:39 --> Helper loaded: form_helper
INFO - 2022-03-30 04:39:39 --> Helper loaded: common_helper
INFO - 2022-03-30 04:39:39 --> Database Driver Class Initialized
DEBUG - 2022-03-30 04:39:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 04:39:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 04:39:39 --> Controller Class Initialized
INFO - 2022-03-30 04:39:39 --> Form Validation Class Initialized
DEBUG - 2022-03-30 04:39:39 --> Encrypt Class Initialized
INFO - 2022-03-30 04:39:39 --> Model "Patient_model" initialized
INFO - 2022-03-30 04:39:39 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 04:39:39 --> Model "Referredby_model" initialized
INFO - 2022-03-30 04:39:39 --> Model "Prefix_master" initialized
INFO - 2022-03-30 04:39:39 --> Model "Hospital_model" initialized
INFO - 2022-03-30 04:39:39 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 04:39:39 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-30 04:39:39 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 04:39:39 --> Final output sent to browser
DEBUG - 2022-03-30 04:39:39 --> Total execution time: 0.0696
ERROR - 2022-03-30 04:39:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 04:39:41 --> Config Class Initialized
INFO - 2022-03-30 04:39:41 --> Hooks Class Initialized
DEBUG - 2022-03-30 04:39:41 --> UTF-8 Support Enabled
INFO - 2022-03-30 04:39:41 --> Utf8 Class Initialized
INFO - 2022-03-30 04:39:41 --> URI Class Initialized
INFO - 2022-03-30 04:39:41 --> Router Class Initialized
INFO - 2022-03-30 04:39:41 --> Output Class Initialized
INFO - 2022-03-30 04:39:41 --> Security Class Initialized
DEBUG - 2022-03-30 04:39:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 04:39:41 --> Input Class Initialized
INFO - 2022-03-30 04:39:41 --> Language Class Initialized
INFO - 2022-03-30 04:39:41 --> Loader Class Initialized
INFO - 2022-03-30 04:39:41 --> Helper loaded: url_helper
INFO - 2022-03-30 04:39:41 --> Helper loaded: form_helper
INFO - 2022-03-30 04:39:41 --> Helper loaded: common_helper
INFO - 2022-03-30 04:39:41 --> Database Driver Class Initialized
DEBUG - 2022-03-30 04:39:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 04:39:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 04:39:41 --> Controller Class Initialized
INFO - 2022-03-30 04:39:41 --> Form Validation Class Initialized
DEBUG - 2022-03-30 04:39:41 --> Encrypt Class Initialized
INFO - 2022-03-30 04:39:41 --> Model "Patient_model" initialized
INFO - 2022-03-30 04:39:41 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 04:39:41 --> Model "Referredby_model" initialized
INFO - 2022-03-30 04:39:41 --> Model "Prefix_master" initialized
INFO - 2022-03-30 04:39:41 --> Model "Hospital_model" initialized
INFO - 2022-03-30 04:39:41 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 04:39:41 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-30 04:39:41 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 04:39:41 --> Final output sent to browser
DEBUG - 2022-03-30 04:39:41 --> Total execution time: 0.0092
ERROR - 2022-03-30 04:41:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 04:41:30 --> Config Class Initialized
INFO - 2022-03-30 04:41:30 --> Hooks Class Initialized
DEBUG - 2022-03-30 04:41:30 --> UTF-8 Support Enabled
INFO - 2022-03-30 04:41:30 --> Utf8 Class Initialized
INFO - 2022-03-30 04:41:30 --> URI Class Initialized
INFO - 2022-03-30 04:41:30 --> Router Class Initialized
INFO - 2022-03-30 04:41:30 --> Output Class Initialized
INFO - 2022-03-30 04:41:30 --> Security Class Initialized
DEBUG - 2022-03-30 04:41:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 04:41:30 --> Input Class Initialized
INFO - 2022-03-30 04:41:30 --> Language Class Initialized
INFO - 2022-03-30 04:41:30 --> Loader Class Initialized
INFO - 2022-03-30 04:41:30 --> Helper loaded: url_helper
INFO - 2022-03-30 04:41:30 --> Helper loaded: form_helper
INFO - 2022-03-30 04:41:30 --> Helper loaded: common_helper
INFO - 2022-03-30 04:41:30 --> Database Driver Class Initialized
DEBUG - 2022-03-30 04:41:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 04:41:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 04:41:30 --> Controller Class Initialized
INFO - 2022-03-30 04:41:30 --> Form Validation Class Initialized
DEBUG - 2022-03-30 04:41:30 --> Encrypt Class Initialized
INFO - 2022-03-30 04:41:30 --> Model "Patient_model" initialized
INFO - 2022-03-30 04:41:30 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 04:41:30 --> Model "Referredby_model" initialized
INFO - 2022-03-30 04:41:30 --> Model "Prefix_master" initialized
INFO - 2022-03-30 04:41:30 --> Model "Hospital_model" initialized
INFO - 2022-03-30 04:41:30 --> Upload Class Initialized
INFO - 2022-03-30 04:41:30 --> Final output sent to browser
DEBUG - 2022-03-30 04:41:30 --> Total execution time: 0.0192
ERROR - 2022-03-30 04:45:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 04:45:10 --> Config Class Initialized
INFO - 2022-03-30 04:45:10 --> Hooks Class Initialized
DEBUG - 2022-03-30 04:45:10 --> UTF-8 Support Enabled
INFO - 2022-03-30 04:45:10 --> Utf8 Class Initialized
INFO - 2022-03-30 04:45:10 --> URI Class Initialized
INFO - 2022-03-30 04:45:10 --> Router Class Initialized
INFO - 2022-03-30 04:45:10 --> Output Class Initialized
INFO - 2022-03-30 04:45:10 --> Security Class Initialized
DEBUG - 2022-03-30 04:45:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 04:45:10 --> Input Class Initialized
INFO - 2022-03-30 04:45:10 --> Language Class Initialized
INFO - 2022-03-30 04:45:10 --> Loader Class Initialized
INFO - 2022-03-30 04:45:10 --> Helper loaded: url_helper
INFO - 2022-03-30 04:45:10 --> Helper loaded: form_helper
INFO - 2022-03-30 04:45:10 --> Helper loaded: common_helper
INFO - 2022-03-30 04:45:10 --> Database Driver Class Initialized
DEBUG - 2022-03-30 04:45:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 04:45:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 04:45:10 --> Controller Class Initialized
INFO - 2022-03-30 04:45:10 --> Form Validation Class Initialized
DEBUG - 2022-03-30 04:45:10 --> Encrypt Class Initialized
INFO - 2022-03-30 04:45:10 --> Model "Patient_model" initialized
INFO - 2022-03-30 04:45:10 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 04:45:10 --> Model "Referredby_model" initialized
INFO - 2022-03-30 04:45:10 --> Model "Prefix_master" initialized
INFO - 2022-03-30 04:45:10 --> Model "Hospital_model" initialized
INFO - 2022-03-30 04:45:10 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 04:45:17 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-30 04:45:17 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 04:45:19 --> Final output sent to browser
DEBUG - 2022-03-30 04:45:19 --> Total execution time: 6.8295
ERROR - 2022-03-30 04:46:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 04:46:37 --> Config Class Initialized
INFO - 2022-03-30 04:46:37 --> Hooks Class Initialized
DEBUG - 2022-03-30 04:46:37 --> UTF-8 Support Enabled
INFO - 2022-03-30 04:46:37 --> Utf8 Class Initialized
INFO - 2022-03-30 04:46:37 --> URI Class Initialized
INFO - 2022-03-30 04:46:37 --> Router Class Initialized
INFO - 2022-03-30 04:46:37 --> Output Class Initialized
INFO - 2022-03-30 04:46:37 --> Security Class Initialized
DEBUG - 2022-03-30 04:46:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 04:46:37 --> Input Class Initialized
INFO - 2022-03-30 04:46:37 --> Language Class Initialized
INFO - 2022-03-30 04:46:37 --> Loader Class Initialized
INFO - 2022-03-30 04:46:37 --> Helper loaded: url_helper
INFO - 2022-03-30 04:46:37 --> Helper loaded: form_helper
INFO - 2022-03-30 04:46:37 --> Helper loaded: common_helper
INFO - 2022-03-30 04:46:37 --> Database Driver Class Initialized
DEBUG - 2022-03-30 04:46:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 04:46:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 04:46:37 --> Controller Class Initialized
INFO - 2022-03-30 04:46:37 --> Form Validation Class Initialized
DEBUG - 2022-03-30 04:46:37 --> Encrypt Class Initialized
INFO - 2022-03-30 04:46:37 --> Model "Patient_model" initialized
INFO - 2022-03-30 04:46:37 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 04:46:37 --> Model "Referredby_model" initialized
INFO - 2022-03-30 04:46:37 --> Model "Prefix_master" initialized
INFO - 2022-03-30 04:46:37 --> Model "Hospital_model" initialized
INFO - 2022-03-30 04:46:37 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 04:46:37 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-30 04:46:37 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 04:46:37 --> Final output sent to browser
DEBUG - 2022-03-30 04:46:37 --> Total execution time: 0.0385
ERROR - 2022-03-30 04:48:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 04:48:29 --> Config Class Initialized
INFO - 2022-03-30 04:48:29 --> Hooks Class Initialized
DEBUG - 2022-03-30 04:48:29 --> UTF-8 Support Enabled
INFO - 2022-03-30 04:48:29 --> Utf8 Class Initialized
INFO - 2022-03-30 04:48:29 --> URI Class Initialized
INFO - 2022-03-30 04:48:29 --> Router Class Initialized
INFO - 2022-03-30 04:48:29 --> Output Class Initialized
INFO - 2022-03-30 04:48:29 --> Security Class Initialized
DEBUG - 2022-03-30 04:48:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 04:48:29 --> Input Class Initialized
INFO - 2022-03-30 04:48:29 --> Language Class Initialized
INFO - 2022-03-30 04:48:29 --> Loader Class Initialized
INFO - 2022-03-30 04:48:29 --> Helper loaded: url_helper
INFO - 2022-03-30 04:48:29 --> Helper loaded: form_helper
INFO - 2022-03-30 04:48:29 --> Helper loaded: common_helper
INFO - 2022-03-30 04:48:29 --> Database Driver Class Initialized
DEBUG - 2022-03-30 04:48:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 04:48:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 04:48:29 --> Controller Class Initialized
INFO - 2022-03-30 04:48:29 --> Model "Referredby_model" initialized
INFO - 2022-03-30 04:48:29 --> Final output sent to browser
DEBUG - 2022-03-30 04:48:29 --> Total execution time: 0.3779
ERROR - 2022-03-30 04:48:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 04:48:39 --> Config Class Initialized
INFO - 2022-03-30 04:48:39 --> Hooks Class Initialized
DEBUG - 2022-03-30 04:48:39 --> UTF-8 Support Enabled
INFO - 2022-03-30 04:48:39 --> Utf8 Class Initialized
INFO - 2022-03-30 04:48:39 --> URI Class Initialized
INFO - 2022-03-30 04:48:39 --> Router Class Initialized
INFO - 2022-03-30 04:48:39 --> Output Class Initialized
INFO - 2022-03-30 04:48:39 --> Security Class Initialized
DEBUG - 2022-03-30 04:48:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 04:48:39 --> Input Class Initialized
INFO - 2022-03-30 04:48:39 --> Language Class Initialized
INFO - 2022-03-30 04:48:39 --> Loader Class Initialized
INFO - 2022-03-30 04:48:39 --> Helper loaded: url_helper
INFO - 2022-03-30 04:48:39 --> Helper loaded: form_helper
INFO - 2022-03-30 04:48:39 --> Helper loaded: common_helper
INFO - 2022-03-30 04:48:39 --> Database Driver Class Initialized
DEBUG - 2022-03-30 04:48:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 04:48:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 04:48:39 --> Controller Class Initialized
INFO - 2022-03-30 04:48:39 --> Form Validation Class Initialized
DEBUG - 2022-03-30 04:48:39 --> Encrypt Class Initialized
INFO - 2022-03-30 04:48:39 --> Model "Patient_model" initialized
INFO - 2022-03-30 04:48:39 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 04:48:39 --> Model "Referredby_model" initialized
INFO - 2022-03-30 04:48:39 --> Model "Prefix_master" initialized
INFO - 2022-03-30 04:48:39 --> Model "Hospital_model" initialized
ERROR - 2022-03-30 04:48:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 04:48:40 --> Config Class Initialized
INFO - 2022-03-30 04:48:40 --> Hooks Class Initialized
DEBUG - 2022-03-30 04:48:40 --> UTF-8 Support Enabled
INFO - 2022-03-30 04:48:40 --> Utf8 Class Initialized
INFO - 2022-03-30 04:48:40 --> URI Class Initialized
INFO - 2022-03-30 04:48:40 --> Router Class Initialized
INFO - 2022-03-30 04:48:40 --> Output Class Initialized
INFO - 2022-03-30 04:48:40 --> Security Class Initialized
DEBUG - 2022-03-30 04:48:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 04:48:40 --> Input Class Initialized
INFO - 2022-03-30 04:48:40 --> Language Class Initialized
INFO - 2022-03-30 04:48:40 --> Loader Class Initialized
INFO - 2022-03-30 04:48:40 --> Helper loaded: url_helper
INFO - 2022-03-30 04:48:40 --> Helper loaded: form_helper
INFO - 2022-03-30 04:48:40 --> Helper loaded: common_helper
INFO - 2022-03-30 04:48:40 --> Database Driver Class Initialized
DEBUG - 2022-03-30 04:48:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 04:48:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 04:48:40 --> Controller Class Initialized
INFO - 2022-03-30 04:48:40 --> Form Validation Class Initialized
DEBUG - 2022-03-30 04:48:40 --> Encrypt Class Initialized
INFO - 2022-03-30 04:48:40 --> Model "Patient_model" initialized
INFO - 2022-03-30 04:48:40 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 04:48:40 --> Model "Referredby_model" initialized
INFO - 2022-03-30 04:48:40 --> Model "Prefix_master" initialized
INFO - 2022-03-30 04:48:40 --> Model "Hospital_model" initialized
INFO - 2022-03-30 04:48:40 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 04:48:40 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-30 04:48:40 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 04:48:40 --> Final output sent to browser
DEBUG - 2022-03-30 04:48:40 --> Total execution time: 0.0261
ERROR - 2022-03-30 04:48:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 04:48:41 --> Config Class Initialized
INFO - 2022-03-30 04:48:41 --> Hooks Class Initialized
DEBUG - 2022-03-30 04:48:41 --> UTF-8 Support Enabled
INFO - 2022-03-30 04:48:41 --> Utf8 Class Initialized
INFO - 2022-03-30 04:48:41 --> URI Class Initialized
INFO - 2022-03-30 04:48:41 --> Router Class Initialized
INFO - 2022-03-30 04:48:41 --> Output Class Initialized
INFO - 2022-03-30 04:48:41 --> Security Class Initialized
DEBUG - 2022-03-30 04:48:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 04:48:41 --> Input Class Initialized
INFO - 2022-03-30 04:48:41 --> Language Class Initialized
INFO - 2022-03-30 04:48:41 --> Loader Class Initialized
INFO - 2022-03-30 04:48:41 --> Helper loaded: url_helper
INFO - 2022-03-30 04:48:41 --> Helper loaded: form_helper
INFO - 2022-03-30 04:48:41 --> Helper loaded: common_helper
INFO - 2022-03-30 04:48:41 --> Database Driver Class Initialized
DEBUG - 2022-03-30 04:48:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 04:48:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 04:48:41 --> Controller Class Initialized
INFO - 2022-03-30 04:48:41 --> Form Validation Class Initialized
DEBUG - 2022-03-30 04:48:41 --> Encrypt Class Initialized
INFO - 2022-03-30 04:48:41 --> Model "Patient_model" initialized
INFO - 2022-03-30 04:48:41 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 04:48:41 --> Model "Prefix_master" initialized
INFO - 2022-03-30 04:48:41 --> Model "Users_model" initialized
INFO - 2022-03-30 04:48:41 --> Model "Hospital_model" initialized
INFO - 2022-03-30 04:48:41 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 04:48:41 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-30 04:48:41 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 04:48:41 --> Final output sent to browser
DEBUG - 2022-03-30 04:48:41 --> Total execution time: 0.0560
ERROR - 2022-03-30 04:49:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 04:49:02 --> Config Class Initialized
INFO - 2022-03-30 04:49:02 --> Hooks Class Initialized
DEBUG - 2022-03-30 04:49:02 --> UTF-8 Support Enabled
INFO - 2022-03-30 04:49:02 --> Utf8 Class Initialized
INFO - 2022-03-30 04:49:02 --> URI Class Initialized
INFO - 2022-03-30 04:49:02 --> Router Class Initialized
INFO - 2022-03-30 04:49:02 --> Output Class Initialized
INFO - 2022-03-30 04:49:02 --> Security Class Initialized
DEBUG - 2022-03-30 04:49:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 04:49:02 --> Input Class Initialized
INFO - 2022-03-30 04:49:02 --> Language Class Initialized
INFO - 2022-03-30 04:49:02 --> Loader Class Initialized
INFO - 2022-03-30 04:49:02 --> Helper loaded: url_helper
INFO - 2022-03-30 04:49:02 --> Helper loaded: form_helper
INFO - 2022-03-30 04:49:02 --> Helper loaded: common_helper
INFO - 2022-03-30 04:49:02 --> Database Driver Class Initialized
DEBUG - 2022-03-30 04:49:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 04:49:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 04:49:02 --> Controller Class Initialized
INFO - 2022-03-30 04:49:02 --> Model "Referredby_model" initialized
INFO - 2022-03-30 04:49:02 --> Final output sent to browser
DEBUG - 2022-03-30 04:49:02 --> Total execution time: 0.0066
ERROR - 2022-03-30 04:49:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 04:49:11 --> Config Class Initialized
INFO - 2022-03-30 04:49:11 --> Hooks Class Initialized
DEBUG - 2022-03-30 04:49:11 --> UTF-8 Support Enabled
INFO - 2022-03-30 04:49:11 --> Utf8 Class Initialized
INFO - 2022-03-30 04:49:11 --> URI Class Initialized
INFO - 2022-03-30 04:49:11 --> Router Class Initialized
INFO - 2022-03-30 04:49:11 --> Output Class Initialized
INFO - 2022-03-30 04:49:11 --> Security Class Initialized
DEBUG - 2022-03-30 04:49:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 04:49:11 --> Input Class Initialized
INFO - 2022-03-30 04:49:11 --> Language Class Initialized
INFO - 2022-03-30 04:49:11 --> Loader Class Initialized
INFO - 2022-03-30 04:49:11 --> Helper loaded: url_helper
INFO - 2022-03-30 04:49:11 --> Helper loaded: form_helper
INFO - 2022-03-30 04:49:11 --> Helper loaded: common_helper
INFO - 2022-03-30 04:49:11 --> Database Driver Class Initialized
DEBUG - 2022-03-30 04:49:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 04:49:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 04:49:11 --> Controller Class Initialized
INFO - 2022-03-30 04:49:11 --> Form Validation Class Initialized
DEBUG - 2022-03-30 04:49:11 --> Encrypt Class Initialized
INFO - 2022-03-30 04:49:11 --> Model "Patient_model" initialized
INFO - 2022-03-30 04:49:11 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 04:49:11 --> Model "Referredby_model" initialized
INFO - 2022-03-30 04:49:11 --> Model "Prefix_master" initialized
INFO - 2022-03-30 04:49:11 --> Model "Hospital_model" initialized
INFO - 2022-03-30 04:49:11 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 04:49:11 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-30 04:49:11 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 04:49:11 --> Final output sent to browser
DEBUG - 2022-03-30 04:49:11 --> Total execution time: 0.0337
ERROR - 2022-03-30 04:49:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 04:49:20 --> Config Class Initialized
INFO - 2022-03-30 04:49:20 --> Hooks Class Initialized
DEBUG - 2022-03-30 04:49:20 --> UTF-8 Support Enabled
INFO - 2022-03-30 04:49:20 --> Utf8 Class Initialized
INFO - 2022-03-30 04:49:20 --> URI Class Initialized
INFO - 2022-03-30 04:49:20 --> Router Class Initialized
INFO - 2022-03-30 04:49:20 --> Output Class Initialized
INFO - 2022-03-30 04:49:20 --> Security Class Initialized
DEBUG - 2022-03-30 04:49:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 04:49:20 --> Input Class Initialized
INFO - 2022-03-30 04:49:20 --> Language Class Initialized
INFO - 2022-03-30 04:49:20 --> Loader Class Initialized
INFO - 2022-03-30 04:49:20 --> Helper loaded: url_helper
INFO - 2022-03-30 04:49:20 --> Helper loaded: form_helper
INFO - 2022-03-30 04:49:20 --> Helper loaded: common_helper
INFO - 2022-03-30 04:49:20 --> Database Driver Class Initialized
DEBUG - 2022-03-30 04:49:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 04:49:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 04:49:20 --> Controller Class Initialized
INFO - 2022-03-30 04:49:20 --> Form Validation Class Initialized
DEBUG - 2022-03-30 04:49:20 --> Encrypt Class Initialized
INFO - 2022-03-30 04:49:20 --> Model "Patient_model" initialized
INFO - 2022-03-30 04:49:20 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 04:49:20 --> Model "Referredby_model" initialized
INFO - 2022-03-30 04:49:20 --> Model "Prefix_master" initialized
INFO - 2022-03-30 04:49:20 --> Model "Hospital_model" initialized
INFO - 2022-03-30 04:49:20 --> Final output sent to browser
DEBUG - 2022-03-30 04:49:20 --> Total execution time: 0.0090
ERROR - 2022-03-30 04:51:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 04:51:36 --> Config Class Initialized
INFO - 2022-03-30 04:51:36 --> Hooks Class Initialized
DEBUG - 2022-03-30 04:51:36 --> UTF-8 Support Enabled
INFO - 2022-03-30 04:51:36 --> Utf8 Class Initialized
INFO - 2022-03-30 04:51:36 --> URI Class Initialized
INFO - 2022-03-30 04:51:36 --> Router Class Initialized
INFO - 2022-03-30 04:51:36 --> Output Class Initialized
INFO - 2022-03-30 04:51:36 --> Security Class Initialized
DEBUG - 2022-03-30 04:51:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 04:51:36 --> Input Class Initialized
INFO - 2022-03-30 04:51:36 --> Language Class Initialized
INFO - 2022-03-30 04:51:36 --> Loader Class Initialized
INFO - 2022-03-30 04:51:36 --> Helper loaded: url_helper
INFO - 2022-03-30 04:51:36 --> Helper loaded: form_helper
INFO - 2022-03-30 04:51:36 --> Helper loaded: common_helper
INFO - 2022-03-30 04:51:36 --> Database Driver Class Initialized
DEBUG - 2022-03-30 04:51:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 04:51:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 04:51:36 --> Controller Class Initialized
INFO - 2022-03-30 04:51:36 --> Form Validation Class Initialized
DEBUG - 2022-03-30 04:51:36 --> Encrypt Class Initialized
INFO - 2022-03-30 04:51:36 --> Model "Patient_model" initialized
INFO - 2022-03-30 04:51:36 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 04:51:36 --> Model "Referredby_model" initialized
INFO - 2022-03-30 04:51:36 --> Model "Prefix_master" initialized
INFO - 2022-03-30 04:51:36 --> Model "Hospital_model" initialized
ERROR - 2022-03-30 04:51:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 04:51:36 --> Config Class Initialized
INFO - 2022-03-30 04:51:36 --> Hooks Class Initialized
DEBUG - 2022-03-30 04:51:36 --> UTF-8 Support Enabled
INFO - 2022-03-30 04:51:36 --> Utf8 Class Initialized
INFO - 2022-03-30 04:51:36 --> URI Class Initialized
INFO - 2022-03-30 04:51:36 --> Router Class Initialized
INFO - 2022-03-30 04:51:36 --> Output Class Initialized
INFO - 2022-03-30 04:51:36 --> Security Class Initialized
DEBUG - 2022-03-30 04:51:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 04:51:36 --> Input Class Initialized
INFO - 2022-03-30 04:51:36 --> Language Class Initialized
INFO - 2022-03-30 04:51:36 --> Loader Class Initialized
INFO - 2022-03-30 04:51:36 --> Helper loaded: url_helper
INFO - 2022-03-30 04:51:36 --> Helper loaded: form_helper
INFO - 2022-03-30 04:51:36 --> Helper loaded: common_helper
INFO - 2022-03-30 04:51:36 --> Database Driver Class Initialized
DEBUG - 2022-03-30 04:51:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 04:51:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 04:51:36 --> Controller Class Initialized
INFO - 2022-03-30 04:51:36 --> Form Validation Class Initialized
DEBUG - 2022-03-30 04:51:36 --> Encrypt Class Initialized
INFO - 2022-03-30 04:51:36 --> Model "Patient_model" initialized
INFO - 2022-03-30 04:51:36 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 04:51:36 --> Model "Referredby_model" initialized
INFO - 2022-03-30 04:51:36 --> Model "Prefix_master" initialized
INFO - 2022-03-30 04:51:36 --> Model "Hospital_model" initialized
INFO - 2022-03-30 04:51:36 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 04:51:36 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-30 04:51:36 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 04:51:36 --> Final output sent to browser
DEBUG - 2022-03-30 04:51:36 --> Total execution time: 0.0530
ERROR - 2022-03-30 04:51:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 04:51:37 --> Config Class Initialized
INFO - 2022-03-30 04:51:37 --> Hooks Class Initialized
DEBUG - 2022-03-30 04:51:37 --> UTF-8 Support Enabled
INFO - 2022-03-30 04:51:37 --> Utf8 Class Initialized
INFO - 2022-03-30 04:51:37 --> URI Class Initialized
INFO - 2022-03-30 04:51:37 --> Router Class Initialized
INFO - 2022-03-30 04:51:37 --> Output Class Initialized
INFO - 2022-03-30 04:51:37 --> Security Class Initialized
DEBUG - 2022-03-30 04:51:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 04:51:37 --> Input Class Initialized
INFO - 2022-03-30 04:51:37 --> Language Class Initialized
INFO - 2022-03-30 04:51:37 --> Loader Class Initialized
INFO - 2022-03-30 04:51:37 --> Helper loaded: url_helper
INFO - 2022-03-30 04:51:37 --> Helper loaded: form_helper
INFO - 2022-03-30 04:51:37 --> Helper loaded: common_helper
INFO - 2022-03-30 04:51:37 --> Database Driver Class Initialized
DEBUG - 2022-03-30 04:51:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 04:51:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 04:51:37 --> Controller Class Initialized
INFO - 2022-03-30 04:51:37 --> Form Validation Class Initialized
DEBUG - 2022-03-30 04:51:37 --> Encrypt Class Initialized
INFO - 2022-03-30 04:51:37 --> Model "Patient_model" initialized
INFO - 2022-03-30 04:51:37 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 04:51:37 --> Model "Prefix_master" initialized
INFO - 2022-03-30 04:51:37 --> Model "Users_model" initialized
INFO - 2022-03-30 04:51:37 --> Model "Hospital_model" initialized
INFO - 2022-03-30 04:51:37 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 04:51:37 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-30 04:51:37 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 04:51:37 --> Final output sent to browser
DEBUG - 2022-03-30 04:51:37 --> Total execution time: 0.0447
ERROR - 2022-03-30 04:55:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 04:55:26 --> Config Class Initialized
INFO - 2022-03-30 04:55:26 --> Hooks Class Initialized
DEBUG - 2022-03-30 04:55:26 --> UTF-8 Support Enabled
INFO - 2022-03-30 04:55:26 --> Utf8 Class Initialized
INFO - 2022-03-30 04:55:26 --> URI Class Initialized
INFO - 2022-03-30 04:55:26 --> Router Class Initialized
INFO - 2022-03-30 04:55:26 --> Output Class Initialized
INFO - 2022-03-30 04:55:26 --> Security Class Initialized
DEBUG - 2022-03-30 04:55:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 04:55:26 --> Input Class Initialized
INFO - 2022-03-30 04:55:26 --> Language Class Initialized
INFO - 2022-03-30 04:55:26 --> Loader Class Initialized
INFO - 2022-03-30 04:55:26 --> Helper loaded: url_helper
INFO - 2022-03-30 04:55:26 --> Helper loaded: form_helper
INFO - 2022-03-30 04:55:26 --> Helper loaded: common_helper
INFO - 2022-03-30 04:55:26 --> Database Driver Class Initialized
DEBUG - 2022-03-30 04:55:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 04:55:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 04:55:26 --> Controller Class Initialized
INFO - 2022-03-30 04:55:26 --> Form Validation Class Initialized
DEBUG - 2022-03-30 04:55:26 --> Encrypt Class Initialized
INFO - 2022-03-30 04:55:26 --> Model "Patient_model" initialized
INFO - 2022-03-30 04:55:26 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 04:55:26 --> Model "Referredby_model" initialized
INFO - 2022-03-30 04:55:26 --> Model "Prefix_master" initialized
INFO - 2022-03-30 04:55:26 --> Model "Hospital_model" initialized
INFO - 2022-03-30 04:55:26 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 04:55:33 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-30 04:55:33 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 04:55:35 --> Final output sent to browser
DEBUG - 2022-03-30 04:55:35 --> Total execution time: 6.7304
ERROR - 2022-03-30 04:55:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 04:55:55 --> Config Class Initialized
INFO - 2022-03-30 04:55:55 --> Hooks Class Initialized
DEBUG - 2022-03-30 04:55:55 --> UTF-8 Support Enabled
INFO - 2022-03-30 04:55:55 --> Utf8 Class Initialized
INFO - 2022-03-30 04:55:55 --> URI Class Initialized
INFO - 2022-03-30 04:55:55 --> Router Class Initialized
INFO - 2022-03-30 04:55:55 --> Output Class Initialized
INFO - 2022-03-30 04:55:55 --> Security Class Initialized
DEBUG - 2022-03-30 04:55:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 04:55:55 --> Input Class Initialized
INFO - 2022-03-30 04:55:55 --> Language Class Initialized
INFO - 2022-03-30 04:55:55 --> Loader Class Initialized
INFO - 2022-03-30 04:55:55 --> Helper loaded: url_helper
INFO - 2022-03-30 04:55:55 --> Helper loaded: form_helper
INFO - 2022-03-30 04:55:55 --> Helper loaded: common_helper
INFO - 2022-03-30 04:55:55 --> Database Driver Class Initialized
DEBUG - 2022-03-30 04:55:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 04:55:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 04:55:55 --> Controller Class Initialized
INFO - 2022-03-30 04:55:55 --> Form Validation Class Initialized
DEBUG - 2022-03-30 04:55:55 --> Encrypt Class Initialized
INFO - 2022-03-30 04:55:55 --> Model "Patient_model" initialized
INFO - 2022-03-30 04:55:55 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 04:55:55 --> Model "Prefix_master" initialized
INFO - 2022-03-30 04:55:55 --> Model "Users_model" initialized
INFO - 2022-03-30 04:55:55 --> Model "Hospital_model" initialized
ERROR - 2022-03-30 04:55:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 04:55:55 --> Config Class Initialized
INFO - 2022-03-30 04:55:55 --> Hooks Class Initialized
DEBUG - 2022-03-30 04:55:55 --> UTF-8 Support Enabled
INFO - 2022-03-30 04:55:55 --> Utf8 Class Initialized
INFO - 2022-03-30 04:55:55 --> URI Class Initialized
INFO - 2022-03-30 04:55:55 --> Router Class Initialized
INFO - 2022-03-30 04:55:55 --> Output Class Initialized
INFO - 2022-03-30 04:55:55 --> Security Class Initialized
DEBUG - 2022-03-30 04:55:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 04:55:55 --> Input Class Initialized
INFO - 2022-03-30 04:55:55 --> Language Class Initialized
INFO - 2022-03-30 04:55:55 --> Loader Class Initialized
INFO - 2022-03-30 04:55:55 --> Helper loaded: url_helper
INFO - 2022-03-30 04:55:55 --> Helper loaded: form_helper
INFO - 2022-03-30 04:55:55 --> Helper loaded: common_helper
INFO - 2022-03-30 04:55:55 --> Database Driver Class Initialized
DEBUG - 2022-03-30 04:55:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 04:55:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 04:55:55 --> Controller Class Initialized
INFO - 2022-03-30 04:55:55 --> Form Validation Class Initialized
DEBUG - 2022-03-30 04:55:55 --> Encrypt Class Initialized
INFO - 2022-03-30 04:55:55 --> Model "Patient_model" initialized
INFO - 2022-03-30 04:55:55 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 04:55:55 --> Model "Prefix_master" initialized
INFO - 2022-03-30 04:55:55 --> Model "Users_model" initialized
INFO - 2022-03-30 04:55:55 --> Model "Hospital_model" initialized
INFO - 2022-03-30 04:55:55 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 04:55:55 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-30 04:55:55 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 04:55:55 --> Final output sent to browser
DEBUG - 2022-03-30 04:55:55 --> Total execution time: 0.0445
ERROR - 2022-03-30 04:56:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 04:56:36 --> Config Class Initialized
INFO - 2022-03-30 04:56:36 --> Hooks Class Initialized
DEBUG - 2022-03-30 04:56:36 --> UTF-8 Support Enabled
INFO - 2022-03-30 04:56:36 --> Utf8 Class Initialized
INFO - 2022-03-30 04:56:36 --> URI Class Initialized
INFO - 2022-03-30 04:56:36 --> Router Class Initialized
INFO - 2022-03-30 04:56:36 --> Output Class Initialized
INFO - 2022-03-30 04:56:36 --> Security Class Initialized
DEBUG - 2022-03-30 04:56:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 04:56:36 --> Input Class Initialized
INFO - 2022-03-30 04:56:36 --> Language Class Initialized
INFO - 2022-03-30 04:56:36 --> Loader Class Initialized
INFO - 2022-03-30 04:56:36 --> Helper loaded: url_helper
INFO - 2022-03-30 04:56:36 --> Helper loaded: form_helper
INFO - 2022-03-30 04:56:36 --> Helper loaded: common_helper
INFO - 2022-03-30 04:56:36 --> Database Driver Class Initialized
DEBUG - 2022-03-30 04:56:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 04:56:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 04:56:36 --> Controller Class Initialized
INFO - 2022-03-30 04:56:36 --> Form Validation Class Initialized
DEBUG - 2022-03-30 04:56:36 --> Encrypt Class Initialized
INFO - 2022-03-30 04:56:36 --> Model "Patient_model" initialized
INFO - 2022-03-30 04:56:36 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 04:56:36 --> Model "Referredby_model" initialized
INFO - 2022-03-30 04:56:36 --> Model "Prefix_master" initialized
INFO - 2022-03-30 04:56:36 --> Model "Hospital_model" initialized
INFO - 2022-03-30 04:56:36 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 04:56:36 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-30 04:56:36 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 04:56:36 --> Final output sent to browser
DEBUG - 2022-03-30 04:56:36 --> Total execution time: 0.0293
ERROR - 2022-03-30 05:00:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 05:00:26 --> Config Class Initialized
INFO - 2022-03-30 05:00:26 --> Hooks Class Initialized
DEBUG - 2022-03-30 05:00:26 --> UTF-8 Support Enabled
INFO - 2022-03-30 05:00:26 --> Utf8 Class Initialized
INFO - 2022-03-30 05:00:26 --> URI Class Initialized
INFO - 2022-03-30 05:00:26 --> Router Class Initialized
INFO - 2022-03-30 05:00:26 --> Output Class Initialized
INFO - 2022-03-30 05:00:26 --> Security Class Initialized
DEBUG - 2022-03-30 05:00:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 05:00:26 --> Input Class Initialized
INFO - 2022-03-30 05:00:26 --> Language Class Initialized
INFO - 2022-03-30 05:00:26 --> Loader Class Initialized
INFO - 2022-03-30 05:00:26 --> Helper loaded: url_helper
INFO - 2022-03-30 05:00:26 --> Helper loaded: form_helper
INFO - 2022-03-30 05:00:26 --> Helper loaded: common_helper
INFO - 2022-03-30 05:00:26 --> Database Driver Class Initialized
DEBUG - 2022-03-30 05:00:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 05:00:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 05:00:26 --> Controller Class Initialized
INFO - 2022-03-30 05:00:26 --> Form Validation Class Initialized
DEBUG - 2022-03-30 05:00:26 --> Encrypt Class Initialized
INFO - 2022-03-30 05:00:26 --> Model "Patient_model" initialized
INFO - 2022-03-30 05:00:26 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 05:00:26 --> Model "Referredby_model" initialized
INFO - 2022-03-30 05:00:26 --> Model "Prefix_master" initialized
INFO - 2022-03-30 05:00:26 --> Model "Hospital_model" initialized
ERROR - 2022-03-30 05:00:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 05:00:26 --> Config Class Initialized
INFO - 2022-03-30 05:00:26 --> Hooks Class Initialized
DEBUG - 2022-03-30 05:00:26 --> UTF-8 Support Enabled
INFO - 2022-03-30 05:00:26 --> Utf8 Class Initialized
INFO - 2022-03-30 05:00:26 --> URI Class Initialized
INFO - 2022-03-30 05:00:26 --> Router Class Initialized
INFO - 2022-03-30 05:00:26 --> Output Class Initialized
INFO - 2022-03-30 05:00:26 --> Security Class Initialized
DEBUG - 2022-03-30 05:00:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 05:00:26 --> Input Class Initialized
INFO - 2022-03-30 05:00:26 --> Language Class Initialized
INFO - 2022-03-30 05:00:26 --> Loader Class Initialized
INFO - 2022-03-30 05:00:26 --> Helper loaded: url_helper
INFO - 2022-03-30 05:00:26 --> Helper loaded: form_helper
INFO - 2022-03-30 05:00:26 --> Helper loaded: common_helper
INFO - 2022-03-30 05:00:26 --> Database Driver Class Initialized
DEBUG - 2022-03-30 05:00:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 05:00:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 05:00:26 --> Controller Class Initialized
INFO - 2022-03-30 05:00:26 --> Form Validation Class Initialized
DEBUG - 2022-03-30 05:00:26 --> Encrypt Class Initialized
INFO - 2022-03-30 05:00:26 --> Model "Patient_model" initialized
INFO - 2022-03-30 05:00:26 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 05:00:26 --> Model "Referredby_model" initialized
INFO - 2022-03-30 05:00:26 --> Model "Prefix_master" initialized
INFO - 2022-03-30 05:00:26 --> Model "Hospital_model" initialized
INFO - 2022-03-30 05:00:26 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 05:00:26 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-30 05:00:26 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 05:00:26 --> Final output sent to browser
DEBUG - 2022-03-30 05:00:26 --> Total execution time: 0.0428
ERROR - 2022-03-30 05:00:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 05:00:27 --> Config Class Initialized
INFO - 2022-03-30 05:00:27 --> Hooks Class Initialized
DEBUG - 2022-03-30 05:00:27 --> UTF-8 Support Enabled
INFO - 2022-03-30 05:00:27 --> Utf8 Class Initialized
INFO - 2022-03-30 05:00:27 --> URI Class Initialized
INFO - 2022-03-30 05:00:27 --> Router Class Initialized
INFO - 2022-03-30 05:00:27 --> Output Class Initialized
INFO - 2022-03-30 05:00:27 --> Security Class Initialized
DEBUG - 2022-03-30 05:00:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 05:00:27 --> Input Class Initialized
INFO - 2022-03-30 05:00:27 --> Language Class Initialized
INFO - 2022-03-30 05:00:27 --> Loader Class Initialized
INFO - 2022-03-30 05:00:27 --> Helper loaded: url_helper
INFO - 2022-03-30 05:00:27 --> Helper loaded: form_helper
INFO - 2022-03-30 05:00:27 --> Helper loaded: common_helper
INFO - 2022-03-30 05:00:27 --> Database Driver Class Initialized
DEBUG - 2022-03-30 05:00:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 05:00:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 05:00:27 --> Controller Class Initialized
INFO - 2022-03-30 05:00:27 --> Form Validation Class Initialized
DEBUG - 2022-03-30 05:00:27 --> Encrypt Class Initialized
INFO - 2022-03-30 05:00:27 --> Model "Patient_model" initialized
INFO - 2022-03-30 05:00:27 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 05:00:27 --> Model "Prefix_master" initialized
INFO - 2022-03-30 05:00:27 --> Model "Users_model" initialized
INFO - 2022-03-30 05:00:27 --> Model "Hospital_model" initialized
INFO - 2022-03-30 05:00:27 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 05:00:27 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-30 05:00:27 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 05:00:27 --> Final output sent to browser
DEBUG - 2022-03-30 05:00:27 --> Total execution time: 0.0504
ERROR - 2022-03-30 05:01:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 05:01:36 --> Config Class Initialized
INFO - 2022-03-30 05:01:36 --> Hooks Class Initialized
DEBUG - 2022-03-30 05:01:36 --> UTF-8 Support Enabled
INFO - 2022-03-30 05:01:36 --> Utf8 Class Initialized
INFO - 2022-03-30 05:01:36 --> URI Class Initialized
INFO - 2022-03-30 05:01:36 --> Router Class Initialized
INFO - 2022-03-30 05:01:36 --> Output Class Initialized
INFO - 2022-03-30 05:01:36 --> Security Class Initialized
DEBUG - 2022-03-30 05:01:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 05:01:36 --> Input Class Initialized
INFO - 2022-03-30 05:01:36 --> Language Class Initialized
INFO - 2022-03-30 05:01:36 --> Loader Class Initialized
INFO - 2022-03-30 05:01:36 --> Helper loaded: url_helper
INFO - 2022-03-30 05:01:36 --> Helper loaded: form_helper
INFO - 2022-03-30 05:01:36 --> Helper loaded: common_helper
INFO - 2022-03-30 05:01:36 --> Database Driver Class Initialized
DEBUG - 2022-03-30 05:01:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 05:01:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 05:01:36 --> Controller Class Initialized
INFO - 2022-03-30 05:01:36 --> Form Validation Class Initialized
DEBUG - 2022-03-30 05:01:36 --> Encrypt Class Initialized
INFO - 2022-03-30 05:01:36 --> Model "Patient_model" initialized
INFO - 2022-03-30 05:01:36 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 05:01:36 --> Model "Prefix_master" initialized
INFO - 2022-03-30 05:01:36 --> Model "Users_model" initialized
INFO - 2022-03-30 05:01:36 --> Model "Hospital_model" initialized
ERROR - 2022-03-30 05:01:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 05:01:36 --> Config Class Initialized
INFO - 2022-03-30 05:01:36 --> Hooks Class Initialized
DEBUG - 2022-03-30 05:01:36 --> UTF-8 Support Enabled
INFO - 2022-03-30 05:01:36 --> Utf8 Class Initialized
INFO - 2022-03-30 05:01:36 --> URI Class Initialized
INFO - 2022-03-30 05:01:36 --> Router Class Initialized
INFO - 2022-03-30 05:01:36 --> Output Class Initialized
INFO - 2022-03-30 05:01:36 --> Security Class Initialized
DEBUG - 2022-03-30 05:01:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 05:01:36 --> Input Class Initialized
INFO - 2022-03-30 05:01:36 --> Language Class Initialized
INFO - 2022-03-30 05:01:36 --> Loader Class Initialized
INFO - 2022-03-30 05:01:36 --> Helper loaded: url_helper
INFO - 2022-03-30 05:01:36 --> Helper loaded: form_helper
INFO - 2022-03-30 05:01:36 --> Helper loaded: common_helper
INFO - 2022-03-30 05:01:36 --> Database Driver Class Initialized
DEBUG - 2022-03-30 05:01:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 05:01:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 05:01:36 --> Controller Class Initialized
INFO - 2022-03-30 05:01:36 --> Form Validation Class Initialized
DEBUG - 2022-03-30 05:01:36 --> Encrypt Class Initialized
INFO - 2022-03-30 05:01:36 --> Model "Patient_model" initialized
INFO - 2022-03-30 05:01:36 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 05:01:36 --> Model "Prefix_master" initialized
INFO - 2022-03-30 05:01:36 --> Model "Users_model" initialized
INFO - 2022-03-30 05:01:36 --> Model "Hospital_model" initialized
INFO - 2022-03-30 05:01:36 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 05:01:36 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-30 05:01:36 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 05:01:36 --> Final output sent to browser
DEBUG - 2022-03-30 05:01:36 --> Total execution time: 0.0654
ERROR - 2022-03-30 05:03:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 05:03:47 --> Config Class Initialized
INFO - 2022-03-30 05:03:47 --> Hooks Class Initialized
DEBUG - 2022-03-30 05:03:47 --> UTF-8 Support Enabled
INFO - 2022-03-30 05:03:47 --> Utf8 Class Initialized
INFO - 2022-03-30 05:03:47 --> URI Class Initialized
INFO - 2022-03-30 05:03:47 --> Router Class Initialized
INFO - 2022-03-30 05:03:47 --> Output Class Initialized
INFO - 2022-03-30 05:03:47 --> Security Class Initialized
DEBUG - 2022-03-30 05:03:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 05:03:47 --> Input Class Initialized
INFO - 2022-03-30 05:03:47 --> Language Class Initialized
INFO - 2022-03-30 05:03:47 --> Loader Class Initialized
INFO - 2022-03-30 05:03:47 --> Helper loaded: url_helper
INFO - 2022-03-30 05:03:47 --> Helper loaded: form_helper
INFO - 2022-03-30 05:03:47 --> Helper loaded: common_helper
INFO - 2022-03-30 05:03:47 --> Database Driver Class Initialized
DEBUG - 2022-03-30 05:03:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 05:03:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 05:03:47 --> Controller Class Initialized
INFO - 2022-03-30 05:03:47 --> Form Validation Class Initialized
DEBUG - 2022-03-30 05:03:47 --> Encrypt Class Initialized
INFO - 2022-03-30 05:03:47 --> Model "Patient_model" initialized
INFO - 2022-03-30 05:03:47 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 05:03:47 --> Model "Prefix_master" initialized
INFO - 2022-03-30 05:03:47 --> Model "Users_model" initialized
INFO - 2022-03-30 05:03:47 --> Model "Hospital_model" initialized
INFO - 2022-03-30 05:03:47 --> Upload Class Initialized
INFO - 2022-03-30 05:03:47 --> Final output sent to browser
DEBUG - 2022-03-30 05:03:47 --> Total execution time: 0.0282
ERROR - 2022-03-30 05:06:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 05:06:50 --> Config Class Initialized
INFO - 2022-03-30 05:06:50 --> Hooks Class Initialized
DEBUG - 2022-03-30 05:06:50 --> UTF-8 Support Enabled
INFO - 2022-03-30 05:06:50 --> Utf8 Class Initialized
INFO - 2022-03-30 05:06:50 --> URI Class Initialized
INFO - 2022-03-30 05:06:50 --> Router Class Initialized
INFO - 2022-03-30 05:06:50 --> Output Class Initialized
INFO - 2022-03-30 05:06:50 --> Security Class Initialized
DEBUG - 2022-03-30 05:06:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 05:06:50 --> Input Class Initialized
INFO - 2022-03-30 05:06:50 --> Language Class Initialized
INFO - 2022-03-30 05:06:50 --> Loader Class Initialized
INFO - 2022-03-30 05:06:50 --> Helper loaded: url_helper
INFO - 2022-03-30 05:06:50 --> Helper loaded: form_helper
INFO - 2022-03-30 05:06:50 --> Helper loaded: common_helper
INFO - 2022-03-30 05:06:50 --> Database Driver Class Initialized
DEBUG - 2022-03-30 05:06:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 05:06:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 05:06:50 --> Controller Class Initialized
INFO - 2022-03-30 05:06:50 --> Form Validation Class Initialized
DEBUG - 2022-03-30 05:06:50 --> Encrypt Class Initialized
INFO - 2022-03-30 05:06:50 --> Model "Patient_model" initialized
INFO - 2022-03-30 05:06:50 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 05:06:50 --> Model "Prefix_master" initialized
INFO - 2022-03-30 05:06:50 --> Model "Users_model" initialized
INFO - 2022-03-30 05:06:50 --> Model "Hospital_model" initialized
ERROR - 2022-03-30 05:06:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 05:06:51 --> Config Class Initialized
INFO - 2022-03-30 05:06:51 --> Hooks Class Initialized
DEBUG - 2022-03-30 05:06:51 --> UTF-8 Support Enabled
INFO - 2022-03-30 05:06:51 --> Utf8 Class Initialized
INFO - 2022-03-30 05:06:51 --> URI Class Initialized
INFO - 2022-03-30 05:06:51 --> Router Class Initialized
INFO - 2022-03-30 05:06:51 --> Output Class Initialized
INFO - 2022-03-30 05:06:51 --> Security Class Initialized
DEBUG - 2022-03-30 05:06:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 05:06:51 --> Input Class Initialized
INFO - 2022-03-30 05:06:51 --> Language Class Initialized
INFO - 2022-03-30 05:06:51 --> Loader Class Initialized
INFO - 2022-03-30 05:06:51 --> Helper loaded: url_helper
INFO - 2022-03-30 05:06:51 --> Helper loaded: form_helper
INFO - 2022-03-30 05:06:51 --> Helper loaded: common_helper
INFO - 2022-03-30 05:06:51 --> Database Driver Class Initialized
DEBUG - 2022-03-30 05:06:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 05:06:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 05:06:51 --> Controller Class Initialized
INFO - 2022-03-30 05:06:51 --> Form Validation Class Initialized
DEBUG - 2022-03-30 05:06:51 --> Encrypt Class Initialized
INFO - 2022-03-30 05:06:51 --> Model "Patient_model" initialized
INFO - 2022-03-30 05:06:51 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 05:06:51 --> Model "Prefix_master" initialized
INFO - 2022-03-30 05:06:51 --> Model "Users_model" initialized
INFO - 2022-03-30 05:06:51 --> Model "Hospital_model" initialized
INFO - 2022-03-30 05:06:51 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 05:06:51 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-30 05:06:51 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 05:06:51 --> Final output sent to browser
DEBUG - 2022-03-30 05:06:51 --> Total execution time: 0.0553
ERROR - 2022-03-30 05:06:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 05:06:55 --> Config Class Initialized
INFO - 2022-03-30 05:06:55 --> Hooks Class Initialized
DEBUG - 2022-03-30 05:06:55 --> UTF-8 Support Enabled
INFO - 2022-03-30 05:06:55 --> Utf8 Class Initialized
INFO - 2022-03-30 05:06:55 --> URI Class Initialized
INFO - 2022-03-30 05:06:55 --> Router Class Initialized
INFO - 2022-03-30 05:06:55 --> Output Class Initialized
INFO - 2022-03-30 05:06:55 --> Security Class Initialized
DEBUG - 2022-03-30 05:06:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 05:06:55 --> Input Class Initialized
INFO - 2022-03-30 05:06:55 --> Language Class Initialized
INFO - 2022-03-30 05:06:55 --> Loader Class Initialized
INFO - 2022-03-30 05:06:55 --> Helper loaded: url_helper
INFO - 2022-03-30 05:06:55 --> Helper loaded: form_helper
INFO - 2022-03-30 05:06:55 --> Helper loaded: common_helper
INFO - 2022-03-30 05:06:55 --> Database Driver Class Initialized
DEBUG - 2022-03-30 05:06:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 05:06:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 05:06:55 --> Controller Class Initialized
INFO - 2022-03-30 05:06:55 --> Form Validation Class Initialized
DEBUG - 2022-03-30 05:06:55 --> Encrypt Class Initialized
INFO - 2022-03-30 05:06:55 --> Model "Patient_model" initialized
INFO - 2022-03-30 05:06:55 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 05:06:55 --> Model "Referredby_model" initialized
INFO - 2022-03-30 05:06:55 --> Model "Prefix_master" initialized
INFO - 2022-03-30 05:06:55 --> Model "Hospital_model" initialized
INFO - 2022-03-30 05:06:55 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 05:07:03 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-30 05:07:03 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 05:07:04 --> Final output sent to browser
DEBUG - 2022-03-30 05:07:04 --> Total execution time: 7.6049
ERROR - 2022-03-30 05:07:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 05:07:51 --> Config Class Initialized
INFO - 2022-03-30 05:07:51 --> Hooks Class Initialized
DEBUG - 2022-03-30 05:07:51 --> UTF-8 Support Enabled
INFO - 2022-03-30 05:07:51 --> Utf8 Class Initialized
INFO - 2022-03-30 05:07:51 --> URI Class Initialized
INFO - 2022-03-30 05:07:51 --> Router Class Initialized
INFO - 2022-03-30 05:07:51 --> Output Class Initialized
INFO - 2022-03-30 05:07:51 --> Security Class Initialized
DEBUG - 2022-03-30 05:07:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 05:07:51 --> Input Class Initialized
INFO - 2022-03-30 05:07:51 --> Language Class Initialized
INFO - 2022-03-30 05:07:51 --> Loader Class Initialized
INFO - 2022-03-30 05:07:51 --> Helper loaded: url_helper
INFO - 2022-03-30 05:07:51 --> Helper loaded: form_helper
INFO - 2022-03-30 05:07:51 --> Helper loaded: common_helper
INFO - 2022-03-30 05:07:51 --> Database Driver Class Initialized
DEBUG - 2022-03-30 05:07:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 05:07:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 05:07:51 --> Controller Class Initialized
INFO - 2022-03-30 05:07:51 --> Form Validation Class Initialized
DEBUG - 2022-03-30 05:07:51 --> Encrypt Class Initialized
INFO - 2022-03-30 05:07:51 --> Model "Patient_model" initialized
INFO - 2022-03-30 05:07:51 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 05:07:51 --> Model "Referredby_model" initialized
INFO - 2022-03-30 05:07:51 --> Model "Prefix_master" initialized
INFO - 2022-03-30 05:07:51 --> Model "Hospital_model" initialized
INFO - 2022-03-30 05:07:51 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 05:07:51 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-30 05:07:51 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 05:07:51 --> Final output sent to browser
DEBUG - 2022-03-30 05:07:51 --> Total execution time: 0.0386
ERROR - 2022-03-30 05:16:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 05:16:17 --> Config Class Initialized
INFO - 2022-03-30 05:16:17 --> Hooks Class Initialized
DEBUG - 2022-03-30 05:16:17 --> UTF-8 Support Enabled
INFO - 2022-03-30 05:16:17 --> Utf8 Class Initialized
INFO - 2022-03-30 05:16:17 --> URI Class Initialized
INFO - 2022-03-30 05:16:17 --> Router Class Initialized
INFO - 2022-03-30 05:16:17 --> Output Class Initialized
INFO - 2022-03-30 05:16:17 --> Security Class Initialized
DEBUG - 2022-03-30 05:16:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 05:16:17 --> Input Class Initialized
INFO - 2022-03-30 05:16:17 --> Language Class Initialized
INFO - 2022-03-30 05:16:17 --> Loader Class Initialized
INFO - 2022-03-30 05:16:17 --> Helper loaded: url_helper
INFO - 2022-03-30 05:16:17 --> Helper loaded: form_helper
INFO - 2022-03-30 05:16:17 --> Helper loaded: common_helper
INFO - 2022-03-30 05:16:17 --> Database Driver Class Initialized
DEBUG - 2022-03-30 05:16:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 05:16:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 05:16:17 --> Controller Class Initialized
INFO - 2022-03-30 05:16:17 --> Form Validation Class Initialized
DEBUG - 2022-03-30 05:16:17 --> Encrypt Class Initialized
INFO - 2022-03-30 05:16:17 --> Model "Patient_model" initialized
INFO - 2022-03-30 05:16:17 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 05:16:17 --> Model "Prefix_master" initialized
INFO - 2022-03-30 05:16:17 --> Model "Users_model" initialized
INFO - 2022-03-30 05:16:17 --> Model "Hospital_model" initialized
ERROR - 2022-03-30 05:16:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 05:16:17 --> Config Class Initialized
INFO - 2022-03-30 05:16:17 --> Hooks Class Initialized
DEBUG - 2022-03-30 05:16:17 --> UTF-8 Support Enabled
INFO - 2022-03-30 05:16:17 --> Utf8 Class Initialized
INFO - 2022-03-30 05:16:17 --> URI Class Initialized
INFO - 2022-03-30 05:16:17 --> Router Class Initialized
INFO - 2022-03-30 05:16:17 --> Output Class Initialized
INFO - 2022-03-30 05:16:17 --> Security Class Initialized
DEBUG - 2022-03-30 05:16:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 05:16:17 --> Input Class Initialized
INFO - 2022-03-30 05:16:17 --> Language Class Initialized
INFO - 2022-03-30 05:16:17 --> Loader Class Initialized
INFO - 2022-03-30 05:16:17 --> Helper loaded: url_helper
INFO - 2022-03-30 05:16:17 --> Helper loaded: form_helper
INFO - 2022-03-30 05:16:17 --> Helper loaded: common_helper
INFO - 2022-03-30 05:16:17 --> Database Driver Class Initialized
DEBUG - 2022-03-30 05:16:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 05:16:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 05:16:17 --> Controller Class Initialized
INFO - 2022-03-30 05:16:17 --> Form Validation Class Initialized
DEBUG - 2022-03-30 05:16:17 --> Encrypt Class Initialized
INFO - 2022-03-30 05:16:17 --> Model "Patient_model" initialized
INFO - 2022-03-30 05:16:17 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 05:16:17 --> Model "Prefix_master" initialized
INFO - 2022-03-30 05:16:17 --> Model "Users_model" initialized
INFO - 2022-03-30 05:16:17 --> Model "Hospital_model" initialized
INFO - 2022-03-30 05:16:17 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 05:16:17 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-30 05:16:17 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 05:16:17 --> Final output sent to browser
DEBUG - 2022-03-30 05:16:17 --> Total execution time: 0.0505
ERROR - 2022-03-30 05:24:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 05:24:48 --> Config Class Initialized
INFO - 2022-03-30 05:24:48 --> Hooks Class Initialized
DEBUG - 2022-03-30 05:24:48 --> UTF-8 Support Enabled
INFO - 2022-03-30 05:24:48 --> Utf8 Class Initialized
INFO - 2022-03-30 05:24:48 --> URI Class Initialized
INFO - 2022-03-30 05:24:48 --> Router Class Initialized
INFO - 2022-03-30 05:24:48 --> Output Class Initialized
INFO - 2022-03-30 05:24:48 --> Security Class Initialized
DEBUG - 2022-03-30 05:24:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 05:24:48 --> Input Class Initialized
INFO - 2022-03-30 05:24:48 --> Language Class Initialized
INFO - 2022-03-30 05:24:48 --> Loader Class Initialized
INFO - 2022-03-30 05:24:48 --> Helper loaded: url_helper
INFO - 2022-03-30 05:24:48 --> Helper loaded: form_helper
INFO - 2022-03-30 05:24:48 --> Helper loaded: common_helper
INFO - 2022-03-30 05:24:48 --> Database Driver Class Initialized
DEBUG - 2022-03-30 05:24:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 05:24:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 05:24:48 --> Controller Class Initialized
INFO - 2022-03-30 05:24:48 --> Form Validation Class Initialized
DEBUG - 2022-03-30 05:24:48 --> Encrypt Class Initialized
INFO - 2022-03-30 05:24:48 --> Model "Patient_model" initialized
INFO - 2022-03-30 05:24:48 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 05:24:48 --> Model "Prefix_master" initialized
INFO - 2022-03-30 05:24:48 --> Model "Users_model" initialized
INFO - 2022-03-30 05:24:48 --> Model "Hospital_model" initialized
ERROR - 2022-03-30 05:24:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 05:24:48 --> Config Class Initialized
INFO - 2022-03-30 05:24:48 --> Hooks Class Initialized
DEBUG - 2022-03-30 05:24:48 --> UTF-8 Support Enabled
INFO - 2022-03-30 05:24:48 --> Utf8 Class Initialized
INFO - 2022-03-30 05:24:48 --> URI Class Initialized
INFO - 2022-03-30 05:24:48 --> Router Class Initialized
INFO - 2022-03-30 05:24:48 --> Output Class Initialized
INFO - 2022-03-30 05:24:48 --> Security Class Initialized
DEBUG - 2022-03-30 05:24:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 05:24:48 --> Input Class Initialized
INFO - 2022-03-30 05:24:48 --> Language Class Initialized
INFO - 2022-03-30 05:24:48 --> Loader Class Initialized
INFO - 2022-03-30 05:24:48 --> Helper loaded: url_helper
INFO - 2022-03-30 05:24:48 --> Helper loaded: form_helper
INFO - 2022-03-30 05:24:48 --> Helper loaded: common_helper
INFO - 2022-03-30 05:24:48 --> Database Driver Class Initialized
DEBUG - 2022-03-30 05:24:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 05:24:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 05:24:48 --> Controller Class Initialized
INFO - 2022-03-30 05:24:48 --> Form Validation Class Initialized
DEBUG - 2022-03-30 05:24:48 --> Encrypt Class Initialized
INFO - 2022-03-30 05:24:48 --> Model "Patient_model" initialized
INFO - 2022-03-30 05:24:48 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 05:24:48 --> Model "Prefix_master" initialized
INFO - 2022-03-30 05:24:48 --> Model "Users_model" initialized
INFO - 2022-03-30 05:24:48 --> Model "Hospital_model" initialized
INFO - 2022-03-30 05:24:48 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 05:24:48 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-30 05:24:48 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 05:24:48 --> Final output sent to browser
DEBUG - 2022-03-30 05:24:48 --> Total execution time: 0.1508
ERROR - 2022-03-30 05:24:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 05:24:58 --> Config Class Initialized
INFO - 2022-03-30 05:24:58 --> Hooks Class Initialized
DEBUG - 2022-03-30 05:24:58 --> UTF-8 Support Enabled
INFO - 2022-03-30 05:24:58 --> Utf8 Class Initialized
INFO - 2022-03-30 05:24:58 --> URI Class Initialized
INFO - 2022-03-30 05:24:58 --> Router Class Initialized
INFO - 2022-03-30 05:24:58 --> Output Class Initialized
INFO - 2022-03-30 05:24:58 --> Security Class Initialized
DEBUG - 2022-03-30 05:24:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 05:24:58 --> Input Class Initialized
INFO - 2022-03-30 05:24:58 --> Language Class Initialized
INFO - 2022-03-30 05:24:58 --> Loader Class Initialized
INFO - 2022-03-30 05:24:58 --> Helper loaded: url_helper
INFO - 2022-03-30 05:24:58 --> Helper loaded: form_helper
INFO - 2022-03-30 05:24:58 --> Helper loaded: common_helper
INFO - 2022-03-30 05:24:58 --> Database Driver Class Initialized
DEBUG - 2022-03-30 05:24:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 05:24:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 05:24:58 --> Controller Class Initialized
INFO - 2022-03-30 05:24:58 --> Form Validation Class Initialized
DEBUG - 2022-03-30 05:24:58 --> Encrypt Class Initialized
INFO - 2022-03-30 05:24:58 --> Model "Patient_model" initialized
INFO - 2022-03-30 05:24:58 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 05:24:58 --> Model "Referredby_model" initialized
INFO - 2022-03-30 05:24:58 --> Model "Prefix_master" initialized
INFO - 2022-03-30 05:24:58 --> Model "Hospital_model" initialized
INFO - 2022-03-30 05:24:58 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 05:24:58 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-30 05:24:58 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 05:24:58 --> Final output sent to browser
DEBUG - 2022-03-30 05:24:58 --> Total execution time: 0.0803
ERROR - 2022-03-30 05:25:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 05:25:09 --> Config Class Initialized
INFO - 2022-03-30 05:25:09 --> Hooks Class Initialized
DEBUG - 2022-03-30 05:25:09 --> UTF-8 Support Enabled
INFO - 2022-03-30 05:25:09 --> Utf8 Class Initialized
INFO - 2022-03-30 05:25:09 --> URI Class Initialized
INFO - 2022-03-30 05:25:09 --> Router Class Initialized
INFO - 2022-03-30 05:25:09 --> Output Class Initialized
INFO - 2022-03-30 05:25:09 --> Security Class Initialized
DEBUG - 2022-03-30 05:25:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 05:25:09 --> Input Class Initialized
INFO - 2022-03-30 05:25:09 --> Language Class Initialized
INFO - 2022-03-30 05:25:09 --> Loader Class Initialized
INFO - 2022-03-30 05:25:09 --> Helper loaded: url_helper
INFO - 2022-03-30 05:25:09 --> Helper loaded: form_helper
INFO - 2022-03-30 05:25:09 --> Helper loaded: common_helper
INFO - 2022-03-30 05:25:09 --> Database Driver Class Initialized
DEBUG - 2022-03-30 05:25:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 05:25:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 05:25:09 --> Controller Class Initialized
INFO - 2022-03-30 05:25:09 --> Form Validation Class Initialized
DEBUG - 2022-03-30 05:25:09 --> Encrypt Class Initialized
INFO - 2022-03-30 05:25:09 --> Model "Patient_model" initialized
INFO - 2022-03-30 05:25:09 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 05:25:09 --> Model "Prefix_master" initialized
INFO - 2022-03-30 05:25:09 --> Model "Users_model" initialized
INFO - 2022-03-30 05:25:09 --> Model "Hospital_model" initialized
INFO - 2022-03-30 05:25:09 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-30 05:25:11 --> Final output sent to browser
DEBUG - 2022-03-30 05:25:11 --> Total execution time: 1.5660
ERROR - 2022-03-30 05:27:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 05:27:57 --> Config Class Initialized
INFO - 2022-03-30 05:27:57 --> Hooks Class Initialized
DEBUG - 2022-03-30 05:27:57 --> UTF-8 Support Enabled
INFO - 2022-03-30 05:27:57 --> Utf8 Class Initialized
INFO - 2022-03-30 05:27:57 --> URI Class Initialized
INFO - 2022-03-30 05:27:57 --> Router Class Initialized
INFO - 2022-03-30 05:27:57 --> Output Class Initialized
INFO - 2022-03-30 05:27:57 --> Security Class Initialized
DEBUG - 2022-03-30 05:27:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 05:27:57 --> Input Class Initialized
INFO - 2022-03-30 05:27:57 --> Language Class Initialized
INFO - 2022-03-30 05:27:57 --> Loader Class Initialized
INFO - 2022-03-30 05:27:57 --> Helper loaded: url_helper
INFO - 2022-03-30 05:27:57 --> Helper loaded: form_helper
INFO - 2022-03-30 05:27:57 --> Helper loaded: common_helper
INFO - 2022-03-30 05:27:57 --> Database Driver Class Initialized
DEBUG - 2022-03-30 05:27:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 05:27:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 05:27:57 --> Controller Class Initialized
INFO - 2022-03-30 05:27:57 --> Form Validation Class Initialized
DEBUG - 2022-03-30 05:27:57 --> Encrypt Class Initialized
INFO - 2022-03-30 05:27:57 --> Model "Patient_model" initialized
INFO - 2022-03-30 05:27:57 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 05:27:57 --> Model "Referredby_model" initialized
INFO - 2022-03-30 05:27:57 --> Model "Prefix_master" initialized
INFO - 2022-03-30 05:27:57 --> Model "Hospital_model" initialized
INFO - 2022-03-30 05:27:57 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 05:27:57 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-30 05:27:57 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 05:27:57 --> Final output sent to browser
DEBUG - 2022-03-30 05:27:57 --> Total execution time: 0.0737
ERROR - 2022-03-30 05:28:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 05:28:12 --> Config Class Initialized
INFO - 2022-03-30 05:28:12 --> Hooks Class Initialized
DEBUG - 2022-03-30 05:28:12 --> UTF-8 Support Enabled
INFO - 2022-03-30 05:28:12 --> Utf8 Class Initialized
INFO - 2022-03-30 05:28:12 --> URI Class Initialized
INFO - 2022-03-30 05:28:12 --> Router Class Initialized
INFO - 2022-03-30 05:28:12 --> Output Class Initialized
INFO - 2022-03-30 05:28:12 --> Security Class Initialized
DEBUG - 2022-03-30 05:28:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 05:28:12 --> Input Class Initialized
INFO - 2022-03-30 05:28:12 --> Language Class Initialized
INFO - 2022-03-30 05:28:12 --> Loader Class Initialized
INFO - 2022-03-30 05:28:12 --> Helper loaded: url_helper
INFO - 2022-03-30 05:28:12 --> Helper loaded: form_helper
INFO - 2022-03-30 05:28:12 --> Helper loaded: common_helper
INFO - 2022-03-30 05:28:12 --> Database Driver Class Initialized
DEBUG - 2022-03-30 05:28:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 05:28:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 05:28:12 --> Controller Class Initialized
INFO - 2022-03-30 05:28:12 --> Form Validation Class Initialized
DEBUG - 2022-03-30 05:28:12 --> Encrypt Class Initialized
INFO - 2022-03-30 05:28:12 --> Model "Patient_model" initialized
INFO - 2022-03-30 05:28:12 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 05:28:12 --> Model "Referredby_model" initialized
INFO - 2022-03-30 05:28:12 --> Model "Prefix_master" initialized
INFO - 2022-03-30 05:28:12 --> Model "Hospital_model" initialized
ERROR - 2022-03-30 05:28:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 05:28:12 --> Config Class Initialized
INFO - 2022-03-30 05:28:12 --> Hooks Class Initialized
DEBUG - 2022-03-30 05:28:12 --> UTF-8 Support Enabled
INFO - 2022-03-30 05:28:12 --> Utf8 Class Initialized
INFO - 2022-03-30 05:28:12 --> URI Class Initialized
INFO - 2022-03-30 05:28:12 --> Router Class Initialized
INFO - 2022-03-30 05:28:12 --> Output Class Initialized
INFO - 2022-03-30 05:28:12 --> Security Class Initialized
DEBUG - 2022-03-30 05:28:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 05:28:12 --> Input Class Initialized
INFO - 2022-03-30 05:28:12 --> Language Class Initialized
INFO - 2022-03-30 05:28:12 --> Loader Class Initialized
INFO - 2022-03-30 05:28:12 --> Helper loaded: url_helper
INFO - 2022-03-30 05:28:12 --> Helper loaded: form_helper
INFO - 2022-03-30 05:28:12 --> Helper loaded: common_helper
INFO - 2022-03-30 05:28:12 --> Database Driver Class Initialized
DEBUG - 2022-03-30 05:28:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 05:28:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 05:28:12 --> Controller Class Initialized
INFO - 2022-03-30 05:28:12 --> Form Validation Class Initialized
DEBUG - 2022-03-30 05:28:12 --> Encrypt Class Initialized
INFO - 2022-03-30 05:28:12 --> Model "Patient_model" initialized
INFO - 2022-03-30 05:28:12 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 05:28:12 --> Model "Referredby_model" initialized
INFO - 2022-03-30 05:28:12 --> Model "Prefix_master" initialized
INFO - 2022-03-30 05:28:12 --> Model "Hospital_model" initialized
INFO - 2022-03-30 05:28:12 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 05:28:12 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-30 05:28:12 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 05:28:12 --> Final output sent to browser
DEBUG - 2022-03-30 05:28:12 --> Total execution time: 0.0284
ERROR - 2022-03-30 05:28:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 05:28:12 --> Config Class Initialized
INFO - 2022-03-30 05:28:12 --> Hooks Class Initialized
DEBUG - 2022-03-30 05:28:12 --> UTF-8 Support Enabled
INFO - 2022-03-30 05:28:12 --> Utf8 Class Initialized
INFO - 2022-03-30 05:28:12 --> URI Class Initialized
INFO - 2022-03-30 05:28:12 --> Router Class Initialized
INFO - 2022-03-30 05:28:12 --> Output Class Initialized
INFO - 2022-03-30 05:28:12 --> Security Class Initialized
DEBUG - 2022-03-30 05:28:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 05:28:12 --> Input Class Initialized
INFO - 2022-03-30 05:28:12 --> Language Class Initialized
INFO - 2022-03-30 05:28:13 --> Loader Class Initialized
INFO - 2022-03-30 05:28:13 --> Helper loaded: url_helper
INFO - 2022-03-30 05:28:13 --> Helper loaded: form_helper
INFO - 2022-03-30 05:28:13 --> Helper loaded: common_helper
INFO - 2022-03-30 05:28:13 --> Database Driver Class Initialized
DEBUG - 2022-03-30 05:28:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 05:28:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 05:28:13 --> Controller Class Initialized
INFO - 2022-03-30 05:28:13 --> Form Validation Class Initialized
DEBUG - 2022-03-30 05:28:13 --> Encrypt Class Initialized
INFO - 2022-03-30 05:28:13 --> Model "Patient_model" initialized
INFO - 2022-03-30 05:28:13 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 05:28:13 --> Model "Prefix_master" initialized
INFO - 2022-03-30 05:28:13 --> Model "Users_model" initialized
INFO - 2022-03-30 05:28:13 --> Model "Hospital_model" initialized
INFO - 2022-03-30 05:28:13 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 05:28:13 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-30 05:28:13 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 05:28:13 --> Final output sent to browser
DEBUG - 2022-03-30 05:28:13 --> Total execution time: 0.0447
ERROR - 2022-03-30 05:29:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 05:29:26 --> Config Class Initialized
INFO - 2022-03-30 05:29:26 --> Hooks Class Initialized
DEBUG - 2022-03-30 05:29:26 --> UTF-8 Support Enabled
INFO - 2022-03-30 05:29:26 --> Utf8 Class Initialized
INFO - 2022-03-30 05:29:26 --> URI Class Initialized
INFO - 2022-03-30 05:29:26 --> Router Class Initialized
INFO - 2022-03-30 05:29:26 --> Output Class Initialized
INFO - 2022-03-30 05:29:26 --> Security Class Initialized
DEBUG - 2022-03-30 05:29:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 05:29:26 --> Input Class Initialized
INFO - 2022-03-30 05:29:26 --> Language Class Initialized
INFO - 2022-03-30 05:29:26 --> Loader Class Initialized
INFO - 2022-03-30 05:29:26 --> Helper loaded: url_helper
INFO - 2022-03-30 05:29:26 --> Helper loaded: form_helper
INFO - 2022-03-30 05:29:26 --> Helper loaded: common_helper
INFO - 2022-03-30 05:29:26 --> Database Driver Class Initialized
DEBUG - 2022-03-30 05:29:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 05:29:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 05:29:26 --> Controller Class Initialized
INFO - 2022-03-30 05:29:26 --> Form Validation Class Initialized
DEBUG - 2022-03-30 05:29:26 --> Encrypt Class Initialized
INFO - 2022-03-30 05:29:26 --> Model "Patient_model" initialized
INFO - 2022-03-30 05:29:26 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 05:29:26 --> Model "Prefix_master" initialized
INFO - 2022-03-30 05:29:26 --> Model "Users_model" initialized
INFO - 2022-03-30 05:29:26 --> Model "Hospital_model" initialized
ERROR - 2022-03-30 05:29:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 05:29:26 --> Config Class Initialized
INFO - 2022-03-30 05:29:26 --> Hooks Class Initialized
DEBUG - 2022-03-30 05:29:26 --> UTF-8 Support Enabled
INFO - 2022-03-30 05:29:26 --> Utf8 Class Initialized
INFO - 2022-03-30 05:29:26 --> URI Class Initialized
INFO - 2022-03-30 05:29:26 --> Router Class Initialized
INFO - 2022-03-30 05:29:26 --> Output Class Initialized
INFO - 2022-03-30 05:29:26 --> Security Class Initialized
DEBUG - 2022-03-30 05:29:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 05:29:26 --> Input Class Initialized
INFO - 2022-03-30 05:29:26 --> Language Class Initialized
INFO - 2022-03-30 05:29:26 --> Loader Class Initialized
INFO - 2022-03-30 05:29:26 --> Helper loaded: url_helper
INFO - 2022-03-30 05:29:26 --> Helper loaded: form_helper
INFO - 2022-03-30 05:29:26 --> Helper loaded: common_helper
INFO - 2022-03-30 05:29:26 --> Database Driver Class Initialized
DEBUG - 2022-03-30 05:29:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 05:29:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 05:29:26 --> Controller Class Initialized
INFO - 2022-03-30 05:29:26 --> Form Validation Class Initialized
DEBUG - 2022-03-30 05:29:26 --> Encrypt Class Initialized
INFO - 2022-03-30 05:29:26 --> Model "Patient_model" initialized
INFO - 2022-03-30 05:29:26 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 05:29:26 --> Model "Prefix_master" initialized
INFO - 2022-03-30 05:29:26 --> Model "Users_model" initialized
INFO - 2022-03-30 05:29:26 --> Model "Hospital_model" initialized
INFO - 2022-03-30 05:29:26 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 05:29:26 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-30 05:29:26 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 05:29:26 --> Final output sent to browser
DEBUG - 2022-03-30 05:29:26 --> Total execution time: 0.0672
ERROR - 2022-03-30 05:32:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 05:32:05 --> Config Class Initialized
INFO - 2022-03-30 05:32:05 --> Hooks Class Initialized
DEBUG - 2022-03-30 05:32:05 --> UTF-8 Support Enabled
INFO - 2022-03-30 05:32:05 --> Utf8 Class Initialized
INFO - 2022-03-30 05:32:05 --> URI Class Initialized
INFO - 2022-03-30 05:32:05 --> Router Class Initialized
INFO - 2022-03-30 05:32:05 --> Output Class Initialized
INFO - 2022-03-30 05:32:05 --> Security Class Initialized
DEBUG - 2022-03-30 05:32:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 05:32:05 --> Input Class Initialized
INFO - 2022-03-30 05:32:05 --> Language Class Initialized
INFO - 2022-03-30 05:32:05 --> Loader Class Initialized
INFO - 2022-03-30 05:32:05 --> Helper loaded: url_helper
INFO - 2022-03-30 05:32:05 --> Helper loaded: form_helper
INFO - 2022-03-30 05:32:05 --> Helper loaded: common_helper
INFO - 2022-03-30 05:32:05 --> Database Driver Class Initialized
DEBUG - 2022-03-30 05:32:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 05:32:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 05:32:05 --> Controller Class Initialized
INFO - 2022-03-30 05:32:05 --> Form Validation Class Initialized
DEBUG - 2022-03-30 05:32:05 --> Encrypt Class Initialized
INFO - 2022-03-30 05:32:05 --> Model "Patient_model" initialized
INFO - 2022-03-30 05:32:05 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 05:32:05 --> Model "Prefix_master" initialized
INFO - 2022-03-30 05:32:05 --> Model "Users_model" initialized
INFO - 2022-03-30 05:32:05 --> Model "Hospital_model" initialized
ERROR - 2022-03-30 05:32:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 05:32:06 --> Config Class Initialized
INFO - 2022-03-30 05:32:06 --> Hooks Class Initialized
DEBUG - 2022-03-30 05:32:06 --> UTF-8 Support Enabled
INFO - 2022-03-30 05:32:06 --> Utf8 Class Initialized
INFO - 2022-03-30 05:32:06 --> URI Class Initialized
INFO - 2022-03-30 05:32:06 --> Router Class Initialized
INFO - 2022-03-30 05:32:06 --> Output Class Initialized
INFO - 2022-03-30 05:32:06 --> Security Class Initialized
DEBUG - 2022-03-30 05:32:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 05:32:06 --> Input Class Initialized
INFO - 2022-03-30 05:32:06 --> Language Class Initialized
INFO - 2022-03-30 05:32:06 --> Loader Class Initialized
INFO - 2022-03-30 05:32:06 --> Helper loaded: url_helper
INFO - 2022-03-30 05:32:06 --> Helper loaded: form_helper
INFO - 2022-03-30 05:32:06 --> Helper loaded: common_helper
INFO - 2022-03-30 05:32:06 --> Database Driver Class Initialized
DEBUG - 2022-03-30 05:32:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 05:32:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 05:32:06 --> Controller Class Initialized
INFO - 2022-03-30 05:32:06 --> Form Validation Class Initialized
DEBUG - 2022-03-30 05:32:06 --> Encrypt Class Initialized
INFO - 2022-03-30 05:32:06 --> Model "Patient_model" initialized
INFO - 2022-03-30 05:32:06 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 05:32:06 --> Model "Prefix_master" initialized
INFO - 2022-03-30 05:32:06 --> Model "Users_model" initialized
INFO - 2022-03-30 05:32:06 --> Model "Hospital_model" initialized
INFO - 2022-03-30 05:32:06 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 05:32:06 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-30 05:32:06 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 05:32:06 --> Final output sent to browser
DEBUG - 2022-03-30 05:32:06 --> Total execution time: 0.0535
ERROR - 2022-03-30 05:32:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 05:32:45 --> Config Class Initialized
INFO - 2022-03-30 05:32:45 --> Hooks Class Initialized
DEBUG - 2022-03-30 05:32:45 --> UTF-8 Support Enabled
INFO - 2022-03-30 05:32:45 --> Utf8 Class Initialized
INFO - 2022-03-30 05:32:45 --> URI Class Initialized
INFO - 2022-03-30 05:32:45 --> Router Class Initialized
INFO - 2022-03-30 05:32:45 --> Output Class Initialized
INFO - 2022-03-30 05:32:45 --> Security Class Initialized
DEBUG - 2022-03-30 05:32:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 05:32:45 --> Input Class Initialized
INFO - 2022-03-30 05:32:45 --> Language Class Initialized
INFO - 2022-03-30 05:32:45 --> Loader Class Initialized
INFO - 2022-03-30 05:32:45 --> Helper loaded: url_helper
INFO - 2022-03-30 05:32:45 --> Helper loaded: form_helper
INFO - 2022-03-30 05:32:45 --> Helper loaded: common_helper
INFO - 2022-03-30 05:32:45 --> Database Driver Class Initialized
DEBUG - 2022-03-30 05:32:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 05:32:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 05:32:45 --> Controller Class Initialized
INFO - 2022-03-30 05:32:45 --> Form Validation Class Initialized
DEBUG - 2022-03-30 05:32:45 --> Encrypt Class Initialized
INFO - 2022-03-30 05:32:45 --> Model "Patient_model" initialized
INFO - 2022-03-30 05:32:45 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 05:32:45 --> Model "Referredby_model" initialized
INFO - 2022-03-30 05:32:45 --> Model "Prefix_master" initialized
INFO - 2022-03-30 05:32:45 --> Model "Hospital_model" initialized
ERROR - 2022-03-30 05:32:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 05:32:45 --> Config Class Initialized
INFO - 2022-03-30 05:32:45 --> Hooks Class Initialized
DEBUG - 2022-03-30 05:32:45 --> UTF-8 Support Enabled
INFO - 2022-03-30 05:32:45 --> Utf8 Class Initialized
INFO - 2022-03-30 05:32:45 --> URI Class Initialized
INFO - 2022-03-30 05:32:45 --> Router Class Initialized
INFO - 2022-03-30 05:32:45 --> Output Class Initialized
INFO - 2022-03-30 05:32:45 --> Security Class Initialized
DEBUG - 2022-03-30 05:32:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 05:32:45 --> Input Class Initialized
INFO - 2022-03-30 05:32:45 --> Language Class Initialized
INFO - 2022-03-30 05:32:45 --> Loader Class Initialized
INFO - 2022-03-30 05:32:45 --> Helper loaded: url_helper
INFO - 2022-03-30 05:32:45 --> Helper loaded: form_helper
INFO - 2022-03-30 05:32:45 --> Helper loaded: common_helper
INFO - 2022-03-30 05:32:45 --> Database Driver Class Initialized
DEBUG - 2022-03-30 05:32:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 05:32:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 05:32:45 --> Controller Class Initialized
INFO - 2022-03-30 05:32:45 --> Form Validation Class Initialized
DEBUG - 2022-03-30 05:32:45 --> Encrypt Class Initialized
INFO - 2022-03-30 05:32:45 --> Model "Patient_model" initialized
INFO - 2022-03-30 05:32:45 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 05:32:45 --> Model "Referredby_model" initialized
INFO - 2022-03-30 05:32:45 --> Model "Prefix_master" initialized
INFO - 2022-03-30 05:32:45 --> Model "Hospital_model" initialized
INFO - 2022-03-30 05:32:45 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 05:32:45 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-30 05:32:45 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 05:32:45 --> Final output sent to browser
DEBUG - 2022-03-30 05:32:45 --> Total execution time: 0.0316
ERROR - 2022-03-30 05:32:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 05:32:46 --> Config Class Initialized
INFO - 2022-03-30 05:32:46 --> Hooks Class Initialized
DEBUG - 2022-03-30 05:32:46 --> UTF-8 Support Enabled
INFO - 2022-03-30 05:32:46 --> Utf8 Class Initialized
INFO - 2022-03-30 05:32:46 --> URI Class Initialized
INFO - 2022-03-30 05:32:46 --> Router Class Initialized
INFO - 2022-03-30 05:32:46 --> Output Class Initialized
INFO - 2022-03-30 05:32:46 --> Security Class Initialized
DEBUG - 2022-03-30 05:32:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 05:32:46 --> Input Class Initialized
INFO - 2022-03-30 05:32:46 --> Language Class Initialized
INFO - 2022-03-30 05:32:46 --> Loader Class Initialized
INFO - 2022-03-30 05:32:46 --> Helper loaded: url_helper
INFO - 2022-03-30 05:32:46 --> Helper loaded: form_helper
INFO - 2022-03-30 05:32:46 --> Helper loaded: common_helper
INFO - 2022-03-30 05:32:46 --> Database Driver Class Initialized
DEBUG - 2022-03-30 05:32:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 05:32:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 05:32:46 --> Controller Class Initialized
INFO - 2022-03-30 05:32:46 --> Form Validation Class Initialized
DEBUG - 2022-03-30 05:32:46 --> Encrypt Class Initialized
INFO - 2022-03-30 05:32:46 --> Model "Patient_model" initialized
INFO - 2022-03-30 05:32:46 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 05:32:46 --> Model "Prefix_master" initialized
INFO - 2022-03-30 05:32:46 --> Model "Users_model" initialized
INFO - 2022-03-30 05:32:46 --> Model "Hospital_model" initialized
INFO - 2022-03-30 05:32:46 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 05:32:46 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-30 05:32:46 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 05:32:46 --> Final output sent to browser
DEBUG - 2022-03-30 05:32:46 --> Total execution time: 0.0374
ERROR - 2022-03-30 05:32:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 05:32:59 --> Config Class Initialized
INFO - 2022-03-30 05:32:59 --> Hooks Class Initialized
DEBUG - 2022-03-30 05:32:59 --> UTF-8 Support Enabled
INFO - 2022-03-30 05:32:59 --> Utf8 Class Initialized
INFO - 2022-03-30 05:32:59 --> URI Class Initialized
INFO - 2022-03-30 05:32:59 --> Router Class Initialized
INFO - 2022-03-30 05:32:59 --> Output Class Initialized
INFO - 2022-03-30 05:32:59 --> Security Class Initialized
DEBUG - 2022-03-30 05:32:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 05:32:59 --> Input Class Initialized
INFO - 2022-03-30 05:32:59 --> Language Class Initialized
INFO - 2022-03-30 05:32:59 --> Loader Class Initialized
INFO - 2022-03-30 05:32:59 --> Helper loaded: url_helper
INFO - 2022-03-30 05:32:59 --> Helper loaded: form_helper
INFO - 2022-03-30 05:32:59 --> Helper loaded: common_helper
INFO - 2022-03-30 05:32:59 --> Database Driver Class Initialized
DEBUG - 2022-03-30 05:32:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 05:32:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 05:32:59 --> Controller Class Initialized
INFO - 2022-03-30 05:32:59 --> Form Validation Class Initialized
DEBUG - 2022-03-30 05:32:59 --> Encrypt Class Initialized
INFO - 2022-03-30 05:32:59 --> Model "Patient_model" initialized
INFO - 2022-03-30 05:32:59 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 05:32:59 --> Model "Prefix_master" initialized
INFO - 2022-03-30 05:32:59 --> Model "Users_model" initialized
INFO - 2022-03-30 05:32:59 --> Model "Hospital_model" initialized
ERROR - 2022-03-30 05:32:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 05:32:59 --> Config Class Initialized
INFO - 2022-03-30 05:33:00 --> Hooks Class Initialized
DEBUG - 2022-03-30 05:33:00 --> UTF-8 Support Enabled
INFO - 2022-03-30 05:33:00 --> Utf8 Class Initialized
INFO - 2022-03-30 05:33:00 --> URI Class Initialized
INFO - 2022-03-30 05:33:00 --> Router Class Initialized
INFO - 2022-03-30 05:33:00 --> Output Class Initialized
INFO - 2022-03-30 05:33:00 --> Security Class Initialized
DEBUG - 2022-03-30 05:33:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 05:33:00 --> Input Class Initialized
INFO - 2022-03-30 05:33:00 --> Language Class Initialized
INFO - 2022-03-30 05:33:00 --> Loader Class Initialized
INFO - 2022-03-30 05:33:00 --> Helper loaded: url_helper
INFO - 2022-03-30 05:33:00 --> Helper loaded: form_helper
INFO - 2022-03-30 05:33:00 --> Helper loaded: common_helper
INFO - 2022-03-30 05:33:00 --> Database Driver Class Initialized
DEBUG - 2022-03-30 05:33:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 05:33:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 05:33:00 --> Controller Class Initialized
INFO - 2022-03-30 05:33:00 --> Form Validation Class Initialized
DEBUG - 2022-03-30 05:33:00 --> Encrypt Class Initialized
INFO - 2022-03-30 05:33:00 --> Model "Patient_model" initialized
INFO - 2022-03-30 05:33:00 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 05:33:00 --> Model "Prefix_master" initialized
INFO - 2022-03-30 05:33:00 --> Model "Users_model" initialized
INFO - 2022-03-30 05:33:00 --> Model "Hospital_model" initialized
INFO - 2022-03-30 05:33:00 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 05:33:00 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-30 05:33:00 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 05:33:00 --> Final output sent to browser
DEBUG - 2022-03-30 05:33:00 --> Total execution time: 0.1669
ERROR - 2022-03-30 05:33:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 05:33:04 --> Config Class Initialized
INFO - 2022-03-30 05:33:04 --> Hooks Class Initialized
DEBUG - 2022-03-30 05:33:04 --> UTF-8 Support Enabled
INFO - 2022-03-30 05:33:04 --> Utf8 Class Initialized
INFO - 2022-03-30 05:33:04 --> URI Class Initialized
INFO - 2022-03-30 05:33:04 --> Router Class Initialized
INFO - 2022-03-30 05:33:04 --> Output Class Initialized
INFO - 2022-03-30 05:33:04 --> Security Class Initialized
DEBUG - 2022-03-30 05:33:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 05:33:04 --> Input Class Initialized
INFO - 2022-03-30 05:33:04 --> Language Class Initialized
INFO - 2022-03-30 05:33:04 --> Loader Class Initialized
INFO - 2022-03-30 05:33:04 --> Helper loaded: url_helper
INFO - 2022-03-30 05:33:04 --> Helper loaded: form_helper
INFO - 2022-03-30 05:33:04 --> Helper loaded: common_helper
INFO - 2022-03-30 05:33:04 --> Database Driver Class Initialized
DEBUG - 2022-03-30 05:33:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 05:33:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 05:33:04 --> Controller Class Initialized
INFO - 2022-03-30 05:33:04 --> Form Validation Class Initialized
DEBUG - 2022-03-30 05:33:04 --> Encrypt Class Initialized
INFO - 2022-03-30 05:33:04 --> Model "Patient_model" initialized
INFO - 2022-03-30 05:33:04 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 05:33:04 --> Model "Referredby_model" initialized
INFO - 2022-03-30 05:33:04 --> Model "Prefix_master" initialized
INFO - 2022-03-30 05:33:04 --> Model "Hospital_model" initialized
INFO - 2022-03-30 05:33:04 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 05:33:04 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-30 05:33:04 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 05:33:04 --> Final output sent to browser
DEBUG - 2022-03-30 05:33:04 --> Total execution time: 0.0711
ERROR - 2022-03-30 05:33:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 05:33:15 --> Config Class Initialized
INFO - 2022-03-30 05:33:15 --> Hooks Class Initialized
DEBUG - 2022-03-30 05:33:15 --> UTF-8 Support Enabled
INFO - 2022-03-30 05:33:15 --> Utf8 Class Initialized
INFO - 2022-03-30 05:33:15 --> URI Class Initialized
INFO - 2022-03-30 05:33:15 --> Router Class Initialized
INFO - 2022-03-30 05:33:15 --> Output Class Initialized
INFO - 2022-03-30 05:33:15 --> Security Class Initialized
DEBUG - 2022-03-30 05:33:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 05:33:15 --> Input Class Initialized
INFO - 2022-03-30 05:33:15 --> Language Class Initialized
INFO - 2022-03-30 05:33:15 --> Loader Class Initialized
INFO - 2022-03-30 05:33:15 --> Helper loaded: url_helper
INFO - 2022-03-30 05:33:15 --> Helper loaded: form_helper
INFO - 2022-03-30 05:33:15 --> Helper loaded: common_helper
INFO - 2022-03-30 05:33:15 --> Database Driver Class Initialized
DEBUG - 2022-03-30 05:33:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 05:33:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 05:33:15 --> Controller Class Initialized
INFO - 2022-03-30 05:33:15 --> Form Validation Class Initialized
DEBUG - 2022-03-30 05:33:15 --> Encrypt Class Initialized
INFO - 2022-03-30 05:33:15 --> Model "Patient_model" initialized
INFO - 2022-03-30 05:33:15 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 05:33:15 --> Model "Prefix_master" initialized
INFO - 2022-03-30 05:33:15 --> Model "Users_model" initialized
INFO - 2022-03-30 05:33:15 --> Model "Hospital_model" initialized
INFO - 2022-03-30 05:33:15 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-30 05:33:16 --> Final output sent to browser
DEBUG - 2022-03-30 05:33:16 --> Total execution time: 1.0856
ERROR - 2022-03-30 05:40:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 05:40:15 --> Config Class Initialized
INFO - 2022-03-30 05:40:15 --> Hooks Class Initialized
DEBUG - 2022-03-30 05:40:15 --> UTF-8 Support Enabled
INFO - 2022-03-30 05:40:15 --> Utf8 Class Initialized
INFO - 2022-03-30 05:40:15 --> URI Class Initialized
INFO - 2022-03-30 05:40:15 --> Router Class Initialized
INFO - 2022-03-30 05:40:15 --> Output Class Initialized
INFO - 2022-03-30 05:40:15 --> Security Class Initialized
DEBUG - 2022-03-30 05:40:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 05:40:15 --> Input Class Initialized
INFO - 2022-03-30 05:40:15 --> Language Class Initialized
INFO - 2022-03-30 05:40:15 --> Loader Class Initialized
INFO - 2022-03-30 05:40:15 --> Helper loaded: url_helper
INFO - 2022-03-30 05:40:15 --> Helper loaded: form_helper
INFO - 2022-03-30 05:40:15 --> Helper loaded: common_helper
INFO - 2022-03-30 05:40:15 --> Database Driver Class Initialized
DEBUG - 2022-03-30 05:40:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 05:40:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 05:40:15 --> Controller Class Initialized
INFO - 2022-03-30 05:40:15 --> Form Validation Class Initialized
DEBUG - 2022-03-30 05:40:15 --> Encrypt Class Initialized
INFO - 2022-03-30 05:40:15 --> Model "Patient_model" initialized
INFO - 2022-03-30 05:40:15 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 05:40:15 --> Model "Referredby_model" initialized
INFO - 2022-03-30 05:40:15 --> Model "Prefix_master" initialized
INFO - 2022-03-30 05:40:15 --> Model "Hospital_model" initialized
INFO - 2022-03-30 05:40:16 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 05:40:22 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-30 05:40:22 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 05:40:24 --> Final output sent to browser
DEBUG - 2022-03-30 05:40:24 --> Total execution time: 6.6478
ERROR - 2022-03-30 06:04:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 06:04:38 --> Config Class Initialized
INFO - 2022-03-30 06:04:38 --> Hooks Class Initialized
DEBUG - 2022-03-30 06:04:38 --> UTF-8 Support Enabled
INFO - 2022-03-30 06:04:38 --> Utf8 Class Initialized
INFO - 2022-03-30 06:04:38 --> URI Class Initialized
INFO - 2022-03-30 06:04:38 --> Router Class Initialized
INFO - 2022-03-30 06:04:38 --> Output Class Initialized
INFO - 2022-03-30 06:04:38 --> Security Class Initialized
DEBUG - 2022-03-30 06:04:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 06:04:38 --> Input Class Initialized
INFO - 2022-03-30 06:04:38 --> Language Class Initialized
INFO - 2022-03-30 06:04:38 --> Loader Class Initialized
INFO - 2022-03-30 06:04:38 --> Helper loaded: url_helper
INFO - 2022-03-30 06:04:38 --> Helper loaded: form_helper
INFO - 2022-03-30 06:04:38 --> Helper loaded: common_helper
INFO - 2022-03-30 06:04:38 --> Database Driver Class Initialized
DEBUG - 2022-03-30 06:04:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 06:04:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 06:04:38 --> Controller Class Initialized
INFO - 2022-03-30 06:04:38 --> Form Validation Class Initialized
DEBUG - 2022-03-30 06:04:38 --> Encrypt Class Initialized
INFO - 2022-03-30 06:04:38 --> Model "Patient_model" initialized
INFO - 2022-03-30 06:04:38 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 06:04:38 --> Model "Referredby_model" initialized
INFO - 2022-03-30 06:04:38 --> Model "Prefix_master" initialized
INFO - 2022-03-30 06:04:38 --> Model "Hospital_model" initialized
INFO - 2022-03-30 06:04:38 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 06:04:46 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-30 06:04:46 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 06:04:48 --> Final output sent to browser
DEBUG - 2022-03-30 06:04:48 --> Total execution time: 8.3710
ERROR - 2022-03-30 06:07:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 06:07:52 --> Config Class Initialized
INFO - 2022-03-30 06:07:52 --> Hooks Class Initialized
DEBUG - 2022-03-30 06:07:52 --> UTF-8 Support Enabled
INFO - 2022-03-30 06:07:52 --> Utf8 Class Initialized
INFO - 2022-03-30 06:07:52 --> URI Class Initialized
INFO - 2022-03-30 06:07:52 --> Router Class Initialized
INFO - 2022-03-30 06:07:52 --> Output Class Initialized
INFO - 2022-03-30 06:07:52 --> Security Class Initialized
DEBUG - 2022-03-30 06:07:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 06:07:52 --> Input Class Initialized
INFO - 2022-03-30 06:07:52 --> Language Class Initialized
INFO - 2022-03-30 06:07:52 --> Loader Class Initialized
INFO - 2022-03-30 06:07:52 --> Helper loaded: url_helper
INFO - 2022-03-30 06:07:52 --> Helper loaded: form_helper
INFO - 2022-03-30 06:07:52 --> Helper loaded: common_helper
INFO - 2022-03-30 06:07:52 --> Database Driver Class Initialized
DEBUG - 2022-03-30 06:07:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 06:07:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 06:07:52 --> Controller Class Initialized
INFO - 2022-03-30 06:07:52 --> Form Validation Class Initialized
DEBUG - 2022-03-30 06:07:52 --> Encrypt Class Initialized
INFO - 2022-03-30 06:07:52 --> Model "Patient_model" initialized
INFO - 2022-03-30 06:07:52 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 06:07:52 --> Model "Referredby_model" initialized
INFO - 2022-03-30 06:07:52 --> Model "Prefix_master" initialized
INFO - 2022-03-30 06:07:52 --> Model "Hospital_model" initialized
INFO - 2022-03-30 06:07:52 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 06:07:52 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-30 06:07:52 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 06:07:52 --> Final output sent to browser
DEBUG - 2022-03-30 06:07:52 --> Total execution time: 0.1390
ERROR - 2022-03-30 06:25:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 06:25:32 --> Config Class Initialized
INFO - 2022-03-30 06:25:32 --> Hooks Class Initialized
DEBUG - 2022-03-30 06:25:32 --> UTF-8 Support Enabled
INFO - 2022-03-30 06:25:32 --> Utf8 Class Initialized
INFO - 2022-03-30 06:25:32 --> URI Class Initialized
INFO - 2022-03-30 06:25:32 --> Router Class Initialized
INFO - 2022-03-30 06:25:32 --> Output Class Initialized
INFO - 2022-03-30 06:25:32 --> Security Class Initialized
DEBUG - 2022-03-30 06:25:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 06:25:32 --> Input Class Initialized
INFO - 2022-03-30 06:25:32 --> Language Class Initialized
INFO - 2022-03-30 06:25:32 --> Loader Class Initialized
INFO - 2022-03-30 06:25:32 --> Helper loaded: url_helper
INFO - 2022-03-30 06:25:32 --> Helper loaded: form_helper
INFO - 2022-03-30 06:25:32 --> Helper loaded: common_helper
INFO - 2022-03-30 06:25:32 --> Database Driver Class Initialized
DEBUG - 2022-03-30 06:25:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 06:25:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 06:25:32 --> Controller Class Initialized
INFO - 2022-03-30 06:25:32 --> Form Validation Class Initialized
DEBUG - 2022-03-30 06:25:32 --> Encrypt Class Initialized
INFO - 2022-03-30 06:25:32 --> Model "Patient_model" initialized
INFO - 2022-03-30 06:25:32 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 06:25:32 --> Model "Referredby_model" initialized
INFO - 2022-03-30 06:25:32 --> Model "Prefix_master" initialized
INFO - 2022-03-30 06:25:32 --> Model "Hospital_model" initialized
INFO - 2022-03-30 06:25:32 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 06:25:32 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-30 06:25:32 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 06:25:32 --> Final output sent to browser
DEBUG - 2022-03-30 06:25:32 --> Total execution time: 0.1381
ERROR - 2022-03-30 06:25:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 06:25:43 --> Config Class Initialized
INFO - 2022-03-30 06:25:43 --> Hooks Class Initialized
DEBUG - 2022-03-30 06:25:43 --> UTF-8 Support Enabled
INFO - 2022-03-30 06:25:43 --> Utf8 Class Initialized
INFO - 2022-03-30 06:25:43 --> URI Class Initialized
INFO - 2022-03-30 06:25:43 --> Router Class Initialized
INFO - 2022-03-30 06:25:43 --> Output Class Initialized
INFO - 2022-03-30 06:25:43 --> Security Class Initialized
DEBUG - 2022-03-30 06:25:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 06:25:43 --> Input Class Initialized
INFO - 2022-03-30 06:25:43 --> Language Class Initialized
INFO - 2022-03-30 06:25:43 --> Loader Class Initialized
INFO - 2022-03-30 06:25:43 --> Helper loaded: url_helper
INFO - 2022-03-30 06:25:43 --> Helper loaded: form_helper
INFO - 2022-03-30 06:25:43 --> Helper loaded: common_helper
INFO - 2022-03-30 06:25:43 --> Database Driver Class Initialized
DEBUG - 2022-03-30 06:25:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 06:25:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 06:25:43 --> Controller Class Initialized
INFO - 2022-03-30 06:25:43 --> Form Validation Class Initialized
DEBUG - 2022-03-30 06:25:43 --> Encrypt Class Initialized
INFO - 2022-03-30 06:25:43 --> Model "Patient_model" initialized
INFO - 2022-03-30 06:25:43 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 06:25:43 --> Model "Referredby_model" initialized
INFO - 2022-03-30 06:25:43 --> Model "Prefix_master" initialized
INFO - 2022-03-30 06:25:43 --> Model "Hospital_model" initialized
INFO - 2022-03-30 06:25:43 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 06:25:43 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-30 06:25:43 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 06:25:43 --> Final output sent to browser
DEBUG - 2022-03-30 06:25:43 --> Total execution time: 0.0258
ERROR - 2022-03-30 06:25:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 06:25:55 --> Config Class Initialized
INFO - 2022-03-30 06:25:55 --> Hooks Class Initialized
DEBUG - 2022-03-30 06:25:55 --> UTF-8 Support Enabled
INFO - 2022-03-30 06:25:55 --> Utf8 Class Initialized
INFO - 2022-03-30 06:25:55 --> URI Class Initialized
INFO - 2022-03-30 06:25:55 --> Router Class Initialized
INFO - 2022-03-30 06:25:55 --> Output Class Initialized
INFO - 2022-03-30 06:25:55 --> Security Class Initialized
DEBUG - 2022-03-30 06:25:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 06:25:55 --> Input Class Initialized
INFO - 2022-03-30 06:25:55 --> Language Class Initialized
INFO - 2022-03-30 06:25:55 --> Loader Class Initialized
INFO - 2022-03-30 06:25:55 --> Helper loaded: url_helper
INFO - 2022-03-30 06:25:55 --> Helper loaded: form_helper
INFO - 2022-03-30 06:25:55 --> Helper loaded: common_helper
INFO - 2022-03-30 06:25:55 --> Database Driver Class Initialized
DEBUG - 2022-03-30 06:25:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 06:25:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 06:25:55 --> Controller Class Initialized
INFO - 2022-03-30 06:25:55 --> Form Validation Class Initialized
DEBUG - 2022-03-30 06:25:55 --> Encrypt Class Initialized
INFO - 2022-03-30 06:25:55 --> Model "Patient_model" initialized
INFO - 2022-03-30 06:25:55 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 06:25:55 --> Model "Referredby_model" initialized
INFO - 2022-03-30 06:25:55 --> Model "Prefix_master" initialized
INFO - 2022-03-30 06:25:55 --> Model "Hospital_model" initialized
ERROR - 2022-03-30 06:25:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 06:25:55 --> Config Class Initialized
INFO - 2022-03-30 06:25:55 --> Hooks Class Initialized
DEBUG - 2022-03-30 06:25:55 --> UTF-8 Support Enabled
INFO - 2022-03-30 06:25:55 --> Utf8 Class Initialized
INFO - 2022-03-30 06:25:55 --> URI Class Initialized
INFO - 2022-03-30 06:25:55 --> Router Class Initialized
INFO - 2022-03-30 06:25:55 --> Output Class Initialized
INFO - 2022-03-30 06:25:55 --> Security Class Initialized
DEBUG - 2022-03-30 06:25:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 06:25:55 --> Input Class Initialized
INFO - 2022-03-30 06:25:55 --> Language Class Initialized
INFO - 2022-03-30 06:25:55 --> Loader Class Initialized
INFO - 2022-03-30 06:25:55 --> Helper loaded: url_helper
INFO - 2022-03-30 06:25:55 --> Helper loaded: form_helper
INFO - 2022-03-30 06:25:55 --> Helper loaded: common_helper
INFO - 2022-03-30 06:25:55 --> Database Driver Class Initialized
DEBUG - 2022-03-30 06:25:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 06:25:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 06:25:55 --> Controller Class Initialized
INFO - 2022-03-30 06:25:55 --> Form Validation Class Initialized
DEBUG - 2022-03-30 06:25:55 --> Encrypt Class Initialized
INFO - 2022-03-30 06:25:55 --> Model "Patient_model" initialized
INFO - 2022-03-30 06:25:55 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 06:25:55 --> Model "Referredby_model" initialized
INFO - 2022-03-30 06:25:55 --> Model "Prefix_master" initialized
INFO - 2022-03-30 06:25:55 --> Model "Hospital_model" initialized
INFO - 2022-03-30 06:25:55 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 06:25:55 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-30 06:25:55 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 06:25:55 --> Final output sent to browser
DEBUG - 2022-03-30 06:25:55 --> Total execution time: 0.0308
ERROR - 2022-03-30 06:25:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 06:25:56 --> Config Class Initialized
INFO - 2022-03-30 06:25:56 --> Hooks Class Initialized
DEBUG - 2022-03-30 06:25:56 --> UTF-8 Support Enabled
INFO - 2022-03-30 06:25:56 --> Utf8 Class Initialized
INFO - 2022-03-30 06:25:56 --> URI Class Initialized
INFO - 2022-03-30 06:25:56 --> Router Class Initialized
INFO - 2022-03-30 06:25:56 --> Output Class Initialized
INFO - 2022-03-30 06:25:56 --> Security Class Initialized
DEBUG - 2022-03-30 06:25:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 06:25:56 --> Input Class Initialized
INFO - 2022-03-30 06:25:56 --> Language Class Initialized
INFO - 2022-03-30 06:25:56 --> Loader Class Initialized
INFO - 2022-03-30 06:25:56 --> Helper loaded: url_helper
INFO - 2022-03-30 06:25:56 --> Helper loaded: form_helper
INFO - 2022-03-30 06:25:56 --> Helper loaded: common_helper
INFO - 2022-03-30 06:25:56 --> Database Driver Class Initialized
DEBUG - 2022-03-30 06:25:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 06:25:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 06:25:56 --> Controller Class Initialized
INFO - 2022-03-30 06:25:56 --> Form Validation Class Initialized
DEBUG - 2022-03-30 06:25:56 --> Encrypt Class Initialized
INFO - 2022-03-30 06:25:56 --> Model "Patient_model" initialized
INFO - 2022-03-30 06:25:56 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 06:25:56 --> Model "Prefix_master" initialized
INFO - 2022-03-30 06:25:56 --> Model "Users_model" initialized
INFO - 2022-03-30 06:25:56 --> Model "Hospital_model" initialized
INFO - 2022-03-30 06:25:56 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 06:25:56 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-30 06:25:56 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 06:25:56 --> Final output sent to browser
DEBUG - 2022-03-30 06:25:56 --> Total execution time: 0.0544
ERROR - 2022-03-30 06:26:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 06:26:25 --> Config Class Initialized
INFO - 2022-03-30 06:26:25 --> Hooks Class Initialized
DEBUG - 2022-03-30 06:26:25 --> UTF-8 Support Enabled
INFO - 2022-03-30 06:26:25 --> Utf8 Class Initialized
INFO - 2022-03-30 06:26:25 --> URI Class Initialized
INFO - 2022-03-30 06:26:25 --> Router Class Initialized
INFO - 2022-03-30 06:26:25 --> Output Class Initialized
INFO - 2022-03-30 06:26:25 --> Security Class Initialized
DEBUG - 2022-03-30 06:26:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 06:26:25 --> Input Class Initialized
INFO - 2022-03-30 06:26:25 --> Language Class Initialized
INFO - 2022-03-30 06:26:25 --> Loader Class Initialized
INFO - 2022-03-30 06:26:25 --> Helper loaded: url_helper
INFO - 2022-03-30 06:26:25 --> Helper loaded: form_helper
INFO - 2022-03-30 06:26:25 --> Helper loaded: common_helper
INFO - 2022-03-30 06:26:25 --> Database Driver Class Initialized
DEBUG - 2022-03-30 06:26:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 06:26:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 06:26:25 --> Controller Class Initialized
INFO - 2022-03-30 06:26:25 --> Form Validation Class Initialized
DEBUG - 2022-03-30 06:26:25 --> Encrypt Class Initialized
INFO - 2022-03-30 06:26:25 --> Model "Patient_model" initialized
INFO - 2022-03-30 06:26:25 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 06:26:25 --> Model "Prefix_master" initialized
INFO - 2022-03-30 06:26:25 --> Model "Users_model" initialized
INFO - 2022-03-30 06:26:25 --> Model "Hospital_model" initialized
ERROR - 2022-03-30 06:26:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 06:26:25 --> Config Class Initialized
INFO - 2022-03-30 06:26:25 --> Hooks Class Initialized
DEBUG - 2022-03-30 06:26:25 --> UTF-8 Support Enabled
INFO - 2022-03-30 06:26:25 --> Utf8 Class Initialized
INFO - 2022-03-30 06:26:25 --> URI Class Initialized
INFO - 2022-03-30 06:26:25 --> Router Class Initialized
INFO - 2022-03-30 06:26:25 --> Output Class Initialized
INFO - 2022-03-30 06:26:25 --> Security Class Initialized
DEBUG - 2022-03-30 06:26:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 06:26:25 --> Input Class Initialized
INFO - 2022-03-30 06:26:25 --> Language Class Initialized
INFO - 2022-03-30 06:26:25 --> Loader Class Initialized
INFO - 2022-03-30 06:26:25 --> Helper loaded: url_helper
INFO - 2022-03-30 06:26:25 --> Helper loaded: form_helper
INFO - 2022-03-30 06:26:25 --> Helper loaded: common_helper
INFO - 2022-03-30 06:26:25 --> Database Driver Class Initialized
DEBUG - 2022-03-30 06:26:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 06:26:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 06:26:25 --> Controller Class Initialized
INFO - 2022-03-30 06:26:25 --> Form Validation Class Initialized
DEBUG - 2022-03-30 06:26:25 --> Encrypt Class Initialized
INFO - 2022-03-30 06:26:25 --> Model "Patient_model" initialized
INFO - 2022-03-30 06:26:25 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 06:26:25 --> Model "Prefix_master" initialized
INFO - 2022-03-30 06:26:25 --> Model "Users_model" initialized
INFO - 2022-03-30 06:26:25 --> Model "Hospital_model" initialized
INFO - 2022-03-30 06:26:25 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 06:26:25 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-30 06:26:25 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 06:26:25 --> Final output sent to browser
DEBUG - 2022-03-30 06:26:25 --> Total execution time: 0.0364
ERROR - 2022-03-30 06:26:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 06:26:29 --> Config Class Initialized
INFO - 2022-03-30 06:26:29 --> Hooks Class Initialized
DEBUG - 2022-03-30 06:26:29 --> UTF-8 Support Enabled
INFO - 2022-03-30 06:26:29 --> Utf8 Class Initialized
INFO - 2022-03-30 06:26:29 --> URI Class Initialized
INFO - 2022-03-30 06:26:29 --> Router Class Initialized
INFO - 2022-03-30 06:26:29 --> Output Class Initialized
INFO - 2022-03-30 06:26:29 --> Security Class Initialized
DEBUG - 2022-03-30 06:26:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 06:26:29 --> Input Class Initialized
INFO - 2022-03-30 06:26:29 --> Language Class Initialized
INFO - 2022-03-30 06:26:29 --> Loader Class Initialized
INFO - 2022-03-30 06:26:29 --> Helper loaded: url_helper
INFO - 2022-03-30 06:26:29 --> Helper loaded: form_helper
INFO - 2022-03-30 06:26:29 --> Helper loaded: common_helper
INFO - 2022-03-30 06:26:29 --> Database Driver Class Initialized
DEBUG - 2022-03-30 06:26:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 06:26:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 06:26:29 --> Controller Class Initialized
INFO - 2022-03-30 06:26:29 --> Form Validation Class Initialized
DEBUG - 2022-03-30 06:26:29 --> Encrypt Class Initialized
INFO - 2022-03-30 06:26:29 --> Model "Patient_model" initialized
INFO - 2022-03-30 06:26:29 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 06:26:29 --> Model "Referredby_model" initialized
INFO - 2022-03-30 06:26:29 --> Model "Prefix_master" initialized
INFO - 2022-03-30 06:26:29 --> Model "Hospital_model" initialized
INFO - 2022-03-30 06:26:29 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 06:26:29 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-30 06:26:29 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 06:26:29 --> Final output sent to browser
DEBUG - 2022-03-30 06:26:29 --> Total execution time: 0.0845
ERROR - 2022-03-30 06:26:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 06:26:43 --> Config Class Initialized
INFO - 2022-03-30 06:26:43 --> Hooks Class Initialized
DEBUG - 2022-03-30 06:26:43 --> UTF-8 Support Enabled
INFO - 2022-03-30 06:26:43 --> Utf8 Class Initialized
INFO - 2022-03-30 06:26:43 --> URI Class Initialized
INFO - 2022-03-30 06:26:43 --> Router Class Initialized
INFO - 2022-03-30 06:26:43 --> Output Class Initialized
INFO - 2022-03-30 06:26:43 --> Security Class Initialized
DEBUG - 2022-03-30 06:26:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 06:26:43 --> Input Class Initialized
INFO - 2022-03-30 06:26:43 --> Language Class Initialized
INFO - 2022-03-30 06:26:43 --> Loader Class Initialized
INFO - 2022-03-30 06:26:43 --> Helper loaded: url_helper
INFO - 2022-03-30 06:26:43 --> Helper loaded: form_helper
INFO - 2022-03-30 06:26:43 --> Helper loaded: common_helper
INFO - 2022-03-30 06:26:43 --> Database Driver Class Initialized
DEBUG - 2022-03-30 06:26:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 06:26:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 06:26:43 --> Controller Class Initialized
INFO - 2022-03-30 06:26:43 --> Form Validation Class Initialized
DEBUG - 2022-03-30 06:26:43 --> Encrypt Class Initialized
INFO - 2022-03-30 06:26:43 --> Model "Patient_model" initialized
INFO - 2022-03-30 06:26:43 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 06:26:43 --> Model "Prefix_master" initialized
INFO - 2022-03-30 06:26:43 --> Model "Users_model" initialized
INFO - 2022-03-30 06:26:43 --> Model "Hospital_model" initialized
INFO - 2022-03-30 06:26:43 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-30 06:26:44 --> Final output sent to browser
DEBUG - 2022-03-30 06:26:44 --> Total execution time: 1.0465
ERROR - 2022-03-30 06:45:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 06:45:23 --> Config Class Initialized
INFO - 2022-03-30 06:45:23 --> Hooks Class Initialized
DEBUG - 2022-03-30 06:45:23 --> UTF-8 Support Enabled
INFO - 2022-03-30 06:45:23 --> Utf8 Class Initialized
INFO - 2022-03-30 06:45:23 --> URI Class Initialized
DEBUG - 2022-03-30 06:45:23 --> No URI present. Default controller set.
INFO - 2022-03-30 06:45:23 --> Router Class Initialized
INFO - 2022-03-30 06:45:23 --> Output Class Initialized
INFO - 2022-03-30 06:45:23 --> Security Class Initialized
DEBUG - 2022-03-30 06:45:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 06:45:23 --> Input Class Initialized
INFO - 2022-03-30 06:45:23 --> Language Class Initialized
INFO - 2022-03-30 06:45:23 --> Loader Class Initialized
INFO - 2022-03-30 06:45:23 --> Helper loaded: url_helper
INFO - 2022-03-30 06:45:23 --> Helper loaded: form_helper
INFO - 2022-03-30 06:45:23 --> Helper loaded: common_helper
INFO - 2022-03-30 06:45:23 --> Database Driver Class Initialized
DEBUG - 2022-03-30 06:45:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 06:45:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 06:45:23 --> Controller Class Initialized
INFO - 2022-03-30 06:45:23 --> Form Validation Class Initialized
DEBUG - 2022-03-30 06:45:23 --> Encrypt Class Initialized
DEBUG - 2022-03-30 06:45:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-30 06:45:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-30 06:45:23 --> Email Class Initialized
INFO - 2022-03-30 06:45:23 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-30 06:45:23 --> Calendar Class Initialized
INFO - 2022-03-30 06:45:23 --> Model "Login_model" initialized
ERROR - 2022-03-30 06:45:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 06:45:23 --> Config Class Initialized
INFO - 2022-03-30 06:45:23 --> Hooks Class Initialized
DEBUG - 2022-03-30 06:45:23 --> UTF-8 Support Enabled
INFO - 2022-03-30 06:45:23 --> Utf8 Class Initialized
INFO - 2022-03-30 06:45:23 --> URI Class Initialized
INFO - 2022-03-30 06:45:23 --> Router Class Initialized
INFO - 2022-03-30 06:45:23 --> Output Class Initialized
INFO - 2022-03-30 06:45:23 --> Security Class Initialized
DEBUG - 2022-03-30 06:45:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 06:45:23 --> Input Class Initialized
INFO - 2022-03-30 06:45:23 --> Language Class Initialized
INFO - 2022-03-30 06:45:23 --> Loader Class Initialized
INFO - 2022-03-30 06:45:23 --> Helper loaded: url_helper
INFO - 2022-03-30 06:45:23 --> Helper loaded: form_helper
INFO - 2022-03-30 06:45:23 --> Helper loaded: common_helper
INFO - 2022-03-30 06:45:23 --> Database Driver Class Initialized
DEBUG - 2022-03-30 06:45:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 06:45:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 06:45:23 --> Controller Class Initialized
INFO - 2022-03-30 06:45:23 --> Form Validation Class Initialized
DEBUG - 2022-03-30 06:45:23 --> Encrypt Class Initialized
INFO - 2022-03-30 06:45:23 --> Model "Diseases_model" initialized
INFO - 2022-03-30 06:45:23 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 06:45:23 --> File loaded: /home3/karoteam/public_html/application/views/diseases/index.php
INFO - 2022-03-30 06:45:23 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 06:45:23 --> Final output sent to browser
DEBUG - 2022-03-30 06:45:23 --> Total execution time: 0.0137
ERROR - 2022-03-30 06:47:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 06:47:10 --> Config Class Initialized
INFO - 2022-03-30 06:47:10 --> Hooks Class Initialized
DEBUG - 2022-03-30 06:47:10 --> UTF-8 Support Enabled
INFO - 2022-03-30 06:47:10 --> Utf8 Class Initialized
INFO - 2022-03-30 06:47:10 --> URI Class Initialized
INFO - 2022-03-30 06:47:10 --> Router Class Initialized
INFO - 2022-03-30 06:47:10 --> Output Class Initialized
INFO - 2022-03-30 06:47:10 --> Security Class Initialized
DEBUG - 2022-03-30 06:47:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 06:47:10 --> Input Class Initialized
INFO - 2022-03-30 06:47:10 --> Language Class Initialized
INFO - 2022-03-30 06:47:10 --> Loader Class Initialized
INFO - 2022-03-30 06:47:10 --> Helper loaded: url_helper
INFO - 2022-03-30 06:47:10 --> Helper loaded: form_helper
INFO - 2022-03-30 06:47:10 --> Helper loaded: common_helper
INFO - 2022-03-30 06:47:10 --> Database Driver Class Initialized
DEBUG - 2022-03-30 06:47:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 06:47:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 06:47:10 --> Controller Class Initialized
INFO - 2022-03-30 06:47:10 --> Form Validation Class Initialized
DEBUG - 2022-03-30 06:47:10 --> Encrypt Class Initialized
INFO - 2022-03-30 06:47:10 --> Model "Patient_model" initialized
INFO - 2022-03-30 06:47:10 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 06:47:10 --> Model "Referredby_model" initialized
INFO - 2022-03-30 06:47:10 --> Model "Prefix_master" initialized
INFO - 2022-03-30 06:47:10 --> Model "Hospital_model" initialized
INFO - 2022-03-30 06:47:10 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 06:47:17 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-30 06:47:17 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 06:47:19 --> Final output sent to browser
DEBUG - 2022-03-30 06:47:19 --> Total execution time: 6.6879
ERROR - 2022-03-30 06:56:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 06:56:41 --> Config Class Initialized
INFO - 2022-03-30 06:56:41 --> Hooks Class Initialized
DEBUG - 2022-03-30 06:56:41 --> UTF-8 Support Enabled
INFO - 2022-03-30 06:56:41 --> Utf8 Class Initialized
INFO - 2022-03-30 06:56:41 --> URI Class Initialized
INFO - 2022-03-30 06:56:41 --> Router Class Initialized
INFO - 2022-03-30 06:56:41 --> Output Class Initialized
INFO - 2022-03-30 06:56:41 --> Security Class Initialized
DEBUG - 2022-03-30 06:56:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 06:56:41 --> Input Class Initialized
INFO - 2022-03-30 06:56:41 --> Language Class Initialized
INFO - 2022-03-30 06:56:41 --> Loader Class Initialized
INFO - 2022-03-30 06:56:41 --> Helper loaded: url_helper
INFO - 2022-03-30 06:56:41 --> Helper loaded: form_helper
INFO - 2022-03-30 06:56:41 --> Helper loaded: common_helper
INFO - 2022-03-30 06:56:41 --> Database Driver Class Initialized
DEBUG - 2022-03-30 06:56:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 06:56:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 06:56:41 --> Controller Class Initialized
INFO - 2022-03-30 06:56:41 --> Form Validation Class Initialized
DEBUG - 2022-03-30 06:56:41 --> Encrypt Class Initialized
INFO - 2022-03-30 06:56:41 --> Model "Patient_model" initialized
INFO - 2022-03-30 06:56:41 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 06:56:41 --> Model "Referredby_model" initialized
INFO - 2022-03-30 06:56:41 --> Model "Prefix_master" initialized
INFO - 2022-03-30 06:56:41 --> Model "Hospital_model" initialized
INFO - 2022-03-30 06:56:41 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 06:56:41 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-30 06:56:41 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 06:56:41 --> Final output sent to browser
DEBUG - 2022-03-30 06:56:41 --> Total execution time: 0.0995
ERROR - 2022-03-30 06:58:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 06:58:01 --> Config Class Initialized
INFO - 2022-03-30 06:58:01 --> Hooks Class Initialized
DEBUG - 2022-03-30 06:58:01 --> UTF-8 Support Enabled
INFO - 2022-03-30 06:58:01 --> Utf8 Class Initialized
INFO - 2022-03-30 06:58:01 --> URI Class Initialized
INFO - 2022-03-30 06:58:01 --> Router Class Initialized
INFO - 2022-03-30 06:58:01 --> Output Class Initialized
INFO - 2022-03-30 06:58:01 --> Security Class Initialized
DEBUG - 2022-03-30 06:58:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 06:58:01 --> Input Class Initialized
INFO - 2022-03-30 06:58:01 --> Language Class Initialized
INFO - 2022-03-30 06:58:01 --> Loader Class Initialized
INFO - 2022-03-30 06:58:01 --> Helper loaded: url_helper
INFO - 2022-03-30 06:58:01 --> Helper loaded: form_helper
INFO - 2022-03-30 06:58:01 --> Helper loaded: common_helper
INFO - 2022-03-30 06:58:01 --> Database Driver Class Initialized
DEBUG - 2022-03-30 06:58:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 06:58:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 06:58:01 --> Controller Class Initialized
INFO - 2022-03-30 06:58:01 --> Form Validation Class Initialized
DEBUG - 2022-03-30 06:58:01 --> Encrypt Class Initialized
INFO - 2022-03-30 06:58:01 --> Model "Patient_model" initialized
INFO - 2022-03-30 06:58:01 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 06:58:01 --> Model "Referredby_model" initialized
INFO - 2022-03-30 06:58:01 --> Model "Prefix_master" initialized
INFO - 2022-03-30 06:58:01 --> Model "Hospital_model" initialized
ERROR - 2022-03-30 06:58:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 06:58:01 --> Config Class Initialized
INFO - 2022-03-30 06:58:01 --> Hooks Class Initialized
DEBUG - 2022-03-30 06:58:01 --> UTF-8 Support Enabled
INFO - 2022-03-30 06:58:01 --> Utf8 Class Initialized
INFO - 2022-03-30 06:58:01 --> URI Class Initialized
INFO - 2022-03-30 06:58:01 --> Router Class Initialized
INFO - 2022-03-30 06:58:01 --> Output Class Initialized
INFO - 2022-03-30 06:58:01 --> Security Class Initialized
DEBUG - 2022-03-30 06:58:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 06:58:01 --> Input Class Initialized
INFO - 2022-03-30 06:58:01 --> Language Class Initialized
INFO - 2022-03-30 06:58:01 --> Loader Class Initialized
INFO - 2022-03-30 06:58:01 --> Helper loaded: url_helper
INFO - 2022-03-30 06:58:01 --> Helper loaded: form_helper
INFO - 2022-03-30 06:58:01 --> Helper loaded: common_helper
INFO - 2022-03-30 06:58:01 --> Database Driver Class Initialized
DEBUG - 2022-03-30 06:58:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 06:58:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 06:58:01 --> Controller Class Initialized
INFO - 2022-03-30 06:58:01 --> Form Validation Class Initialized
DEBUG - 2022-03-30 06:58:01 --> Encrypt Class Initialized
INFO - 2022-03-30 06:58:01 --> Model "Patient_model" initialized
INFO - 2022-03-30 06:58:01 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 06:58:01 --> Model "Referredby_model" initialized
INFO - 2022-03-30 06:58:01 --> Model "Prefix_master" initialized
INFO - 2022-03-30 06:58:01 --> Model "Hospital_model" initialized
INFO - 2022-03-30 06:58:01 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 06:58:01 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-30 06:58:01 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 06:58:01 --> Final output sent to browser
DEBUG - 2022-03-30 06:58:01 --> Total execution time: 0.0370
ERROR - 2022-03-30 06:58:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 06:58:02 --> Config Class Initialized
INFO - 2022-03-30 06:58:02 --> Hooks Class Initialized
DEBUG - 2022-03-30 06:58:02 --> UTF-8 Support Enabled
INFO - 2022-03-30 06:58:02 --> Utf8 Class Initialized
INFO - 2022-03-30 06:58:02 --> URI Class Initialized
INFO - 2022-03-30 06:58:02 --> Router Class Initialized
INFO - 2022-03-30 06:58:02 --> Output Class Initialized
INFO - 2022-03-30 06:58:02 --> Security Class Initialized
DEBUG - 2022-03-30 06:58:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 06:58:02 --> Input Class Initialized
INFO - 2022-03-30 06:58:02 --> Language Class Initialized
INFO - 2022-03-30 06:58:02 --> Loader Class Initialized
INFO - 2022-03-30 06:58:02 --> Helper loaded: url_helper
INFO - 2022-03-30 06:58:02 --> Helper loaded: form_helper
INFO - 2022-03-30 06:58:02 --> Helper loaded: common_helper
INFO - 2022-03-30 06:58:02 --> Database Driver Class Initialized
DEBUG - 2022-03-30 06:58:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 06:58:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 06:58:02 --> Controller Class Initialized
INFO - 2022-03-30 06:58:02 --> Form Validation Class Initialized
DEBUG - 2022-03-30 06:58:02 --> Encrypt Class Initialized
INFO - 2022-03-30 06:58:02 --> Model "Patient_model" initialized
INFO - 2022-03-30 06:58:02 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 06:58:02 --> Model "Prefix_master" initialized
INFO - 2022-03-30 06:58:02 --> Model "Users_model" initialized
INFO - 2022-03-30 06:58:02 --> Model "Hospital_model" initialized
INFO - 2022-03-30 06:58:02 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 06:58:02 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-30 06:58:02 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 06:58:02 --> Final output sent to browser
DEBUG - 2022-03-30 06:58:02 --> Total execution time: 0.0582
ERROR - 2022-03-30 07:03:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 07:03:49 --> Config Class Initialized
INFO - 2022-03-30 07:03:49 --> Hooks Class Initialized
DEBUG - 2022-03-30 07:03:49 --> UTF-8 Support Enabled
INFO - 2022-03-30 07:03:49 --> Utf8 Class Initialized
INFO - 2022-03-30 07:03:49 --> URI Class Initialized
INFO - 2022-03-30 07:03:49 --> Router Class Initialized
INFO - 2022-03-30 07:03:49 --> Output Class Initialized
INFO - 2022-03-30 07:03:49 --> Security Class Initialized
DEBUG - 2022-03-30 07:03:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 07:03:49 --> Input Class Initialized
INFO - 2022-03-30 07:03:49 --> Language Class Initialized
INFO - 2022-03-30 07:03:49 --> Loader Class Initialized
INFO - 2022-03-30 07:03:49 --> Helper loaded: url_helper
INFO - 2022-03-30 07:03:49 --> Helper loaded: form_helper
INFO - 2022-03-30 07:03:49 --> Helper loaded: common_helper
INFO - 2022-03-30 07:03:49 --> Database Driver Class Initialized
DEBUG - 2022-03-30 07:03:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 07:03:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 07:03:49 --> Controller Class Initialized
INFO - 2022-03-30 07:03:49 --> Form Validation Class Initialized
DEBUG - 2022-03-30 07:03:49 --> Encrypt Class Initialized
INFO - 2022-03-30 07:03:49 --> Model "Patient_model" initialized
INFO - 2022-03-30 07:03:49 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 07:03:49 --> Model "Referredby_model" initialized
INFO - 2022-03-30 07:03:49 --> Model "Prefix_master" initialized
INFO - 2022-03-30 07:03:49 --> Model "Hospital_model" initialized
INFO - 2022-03-30 07:03:49 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 07:03:56 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-30 07:03:56 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 07:03:58 --> Final output sent to browser
DEBUG - 2022-03-30 07:03:58 --> Total execution time: 7.2037
ERROR - 2022-03-30 07:06:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 07:06:21 --> Config Class Initialized
INFO - 2022-03-30 07:06:21 --> Hooks Class Initialized
DEBUG - 2022-03-30 07:06:21 --> UTF-8 Support Enabled
INFO - 2022-03-30 07:06:21 --> Utf8 Class Initialized
INFO - 2022-03-30 07:06:21 --> URI Class Initialized
INFO - 2022-03-30 07:06:21 --> Router Class Initialized
INFO - 2022-03-30 07:06:21 --> Output Class Initialized
INFO - 2022-03-30 07:06:21 --> Security Class Initialized
DEBUG - 2022-03-30 07:06:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 07:06:21 --> Input Class Initialized
INFO - 2022-03-30 07:06:21 --> Language Class Initialized
INFO - 2022-03-30 07:06:21 --> Loader Class Initialized
INFO - 2022-03-30 07:06:21 --> Helper loaded: url_helper
INFO - 2022-03-30 07:06:21 --> Helper loaded: form_helper
INFO - 2022-03-30 07:06:21 --> Helper loaded: common_helper
INFO - 2022-03-30 07:06:21 --> Database Driver Class Initialized
DEBUG - 2022-03-30 07:06:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 07:06:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 07:06:21 --> Controller Class Initialized
INFO - 2022-03-30 07:06:21 --> Form Validation Class Initialized
DEBUG - 2022-03-30 07:06:21 --> Encrypt Class Initialized
INFO - 2022-03-30 07:06:21 --> Model "Patient_model" initialized
INFO - 2022-03-30 07:06:21 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 07:06:21 --> Model "Referredby_model" initialized
INFO - 2022-03-30 07:06:21 --> Model "Prefix_master" initialized
INFO - 2022-03-30 07:06:21 --> Model "Hospital_model" initialized
INFO - 2022-03-30 07:06:21 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 07:06:21 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-30 07:06:21 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 07:06:21 --> Final output sent to browser
DEBUG - 2022-03-30 07:06:21 --> Total execution time: 0.1235
ERROR - 2022-03-30 07:07:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 07:07:00 --> Config Class Initialized
INFO - 2022-03-30 07:07:00 --> Hooks Class Initialized
DEBUG - 2022-03-30 07:07:00 --> UTF-8 Support Enabled
INFO - 2022-03-30 07:07:00 --> Utf8 Class Initialized
INFO - 2022-03-30 07:07:00 --> URI Class Initialized
INFO - 2022-03-30 07:07:00 --> Router Class Initialized
INFO - 2022-03-30 07:07:00 --> Output Class Initialized
INFO - 2022-03-30 07:07:00 --> Security Class Initialized
DEBUG - 2022-03-30 07:07:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 07:07:00 --> Input Class Initialized
INFO - 2022-03-30 07:07:00 --> Language Class Initialized
INFO - 2022-03-30 07:07:00 --> Loader Class Initialized
INFO - 2022-03-30 07:07:00 --> Helper loaded: url_helper
INFO - 2022-03-30 07:07:00 --> Helper loaded: form_helper
INFO - 2022-03-30 07:07:00 --> Helper loaded: common_helper
INFO - 2022-03-30 07:07:00 --> Database Driver Class Initialized
DEBUG - 2022-03-30 07:07:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 07:07:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 07:07:00 --> Controller Class Initialized
INFO - 2022-03-30 07:07:00 --> Form Validation Class Initialized
DEBUG - 2022-03-30 07:07:00 --> Encrypt Class Initialized
INFO - 2022-03-30 07:07:00 --> Model "Patient_model" initialized
INFO - 2022-03-30 07:07:00 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 07:07:00 --> Model "Referredby_model" initialized
INFO - 2022-03-30 07:07:00 --> Model "Prefix_master" initialized
INFO - 2022-03-30 07:07:00 --> Model "Hospital_model" initialized
ERROR - 2022-03-30 07:07:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 07:07:00 --> Config Class Initialized
INFO - 2022-03-30 07:07:00 --> Hooks Class Initialized
DEBUG - 2022-03-30 07:07:00 --> UTF-8 Support Enabled
INFO - 2022-03-30 07:07:00 --> Utf8 Class Initialized
INFO - 2022-03-30 07:07:00 --> URI Class Initialized
INFO - 2022-03-30 07:07:00 --> Router Class Initialized
INFO - 2022-03-30 07:07:00 --> Output Class Initialized
INFO - 2022-03-30 07:07:00 --> Security Class Initialized
DEBUG - 2022-03-30 07:07:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 07:07:00 --> Input Class Initialized
INFO - 2022-03-30 07:07:00 --> Language Class Initialized
INFO - 2022-03-30 07:07:00 --> Loader Class Initialized
INFO - 2022-03-30 07:07:00 --> Helper loaded: url_helper
INFO - 2022-03-30 07:07:00 --> Helper loaded: form_helper
INFO - 2022-03-30 07:07:00 --> Helper loaded: common_helper
INFO - 2022-03-30 07:07:00 --> Database Driver Class Initialized
DEBUG - 2022-03-30 07:07:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 07:07:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 07:07:00 --> Controller Class Initialized
INFO - 2022-03-30 07:07:00 --> Form Validation Class Initialized
DEBUG - 2022-03-30 07:07:00 --> Encrypt Class Initialized
INFO - 2022-03-30 07:07:00 --> Model "Patient_model" initialized
INFO - 2022-03-30 07:07:00 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 07:07:00 --> Model "Referredby_model" initialized
INFO - 2022-03-30 07:07:00 --> Model "Prefix_master" initialized
INFO - 2022-03-30 07:07:00 --> Model "Hospital_model" initialized
INFO - 2022-03-30 07:07:00 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 07:07:00 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-30 07:07:00 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 07:07:00 --> Final output sent to browser
DEBUG - 2022-03-30 07:07:00 --> Total execution time: 0.0760
ERROR - 2022-03-30 07:07:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 07:07:01 --> Config Class Initialized
INFO - 2022-03-30 07:07:01 --> Hooks Class Initialized
DEBUG - 2022-03-30 07:07:01 --> UTF-8 Support Enabled
INFO - 2022-03-30 07:07:01 --> Utf8 Class Initialized
INFO - 2022-03-30 07:07:01 --> URI Class Initialized
INFO - 2022-03-30 07:07:01 --> Router Class Initialized
INFO - 2022-03-30 07:07:01 --> Output Class Initialized
INFO - 2022-03-30 07:07:01 --> Security Class Initialized
DEBUG - 2022-03-30 07:07:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 07:07:01 --> Input Class Initialized
INFO - 2022-03-30 07:07:01 --> Language Class Initialized
INFO - 2022-03-30 07:07:01 --> Loader Class Initialized
INFO - 2022-03-30 07:07:01 --> Helper loaded: url_helper
INFO - 2022-03-30 07:07:01 --> Helper loaded: form_helper
INFO - 2022-03-30 07:07:01 --> Helper loaded: common_helper
INFO - 2022-03-30 07:07:01 --> Database Driver Class Initialized
DEBUG - 2022-03-30 07:07:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 07:07:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 07:07:01 --> Controller Class Initialized
INFO - 2022-03-30 07:07:01 --> Form Validation Class Initialized
DEBUG - 2022-03-30 07:07:01 --> Encrypt Class Initialized
INFO - 2022-03-30 07:07:01 --> Model "Patient_model" initialized
INFO - 2022-03-30 07:07:01 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 07:07:01 --> Model "Prefix_master" initialized
INFO - 2022-03-30 07:07:01 --> Model "Users_model" initialized
INFO - 2022-03-30 07:07:01 --> Model "Hospital_model" initialized
INFO - 2022-03-30 07:07:01 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 07:07:01 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-30 07:07:01 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 07:07:01 --> Final output sent to browser
DEBUG - 2022-03-30 07:07:01 --> Total execution time: 0.0456
ERROR - 2022-03-30 07:09:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 07:09:28 --> Config Class Initialized
INFO - 2022-03-30 07:09:28 --> Hooks Class Initialized
DEBUG - 2022-03-30 07:09:28 --> UTF-8 Support Enabled
INFO - 2022-03-30 07:09:28 --> Utf8 Class Initialized
INFO - 2022-03-30 07:09:28 --> URI Class Initialized
INFO - 2022-03-30 07:09:28 --> Router Class Initialized
INFO - 2022-03-30 07:09:28 --> Output Class Initialized
INFO - 2022-03-30 07:09:28 --> Security Class Initialized
DEBUG - 2022-03-30 07:09:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 07:09:28 --> Input Class Initialized
INFO - 2022-03-30 07:09:28 --> Language Class Initialized
INFO - 2022-03-30 07:09:28 --> Loader Class Initialized
INFO - 2022-03-30 07:09:28 --> Helper loaded: url_helper
INFO - 2022-03-30 07:09:28 --> Helper loaded: form_helper
INFO - 2022-03-30 07:09:28 --> Helper loaded: common_helper
INFO - 2022-03-30 07:09:28 --> Database Driver Class Initialized
DEBUG - 2022-03-30 07:09:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 07:09:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 07:09:28 --> Controller Class Initialized
INFO - 2022-03-30 07:09:28 --> Form Validation Class Initialized
DEBUG - 2022-03-30 07:09:28 --> Encrypt Class Initialized
INFO - 2022-03-30 07:09:28 --> Model "Patient_model" initialized
INFO - 2022-03-30 07:09:28 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 07:09:28 --> Model "Referredby_model" initialized
INFO - 2022-03-30 07:09:28 --> Model "Prefix_master" initialized
INFO - 2022-03-30 07:09:28 --> Model "Hospital_model" initialized
INFO - 2022-03-30 07:09:28 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 07:09:34 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-30 07:09:34 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 07:09:36 --> Final output sent to browser
DEBUG - 2022-03-30 07:09:36 --> Total execution time: 6.1029
ERROR - 2022-03-30 07:10:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 07:10:02 --> Config Class Initialized
INFO - 2022-03-30 07:10:02 --> Hooks Class Initialized
DEBUG - 2022-03-30 07:10:02 --> UTF-8 Support Enabled
INFO - 2022-03-30 07:10:02 --> Utf8 Class Initialized
INFO - 2022-03-30 07:10:02 --> URI Class Initialized
INFO - 2022-03-30 07:10:02 --> Router Class Initialized
INFO - 2022-03-30 07:10:02 --> Output Class Initialized
INFO - 2022-03-30 07:10:02 --> Security Class Initialized
DEBUG - 2022-03-30 07:10:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 07:10:02 --> Input Class Initialized
INFO - 2022-03-30 07:10:02 --> Language Class Initialized
INFO - 2022-03-30 07:10:02 --> Loader Class Initialized
INFO - 2022-03-30 07:10:02 --> Helper loaded: url_helper
INFO - 2022-03-30 07:10:02 --> Helper loaded: form_helper
INFO - 2022-03-30 07:10:02 --> Helper loaded: common_helper
INFO - 2022-03-30 07:10:02 --> Database Driver Class Initialized
DEBUG - 2022-03-30 07:10:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 07:10:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 07:10:02 --> Controller Class Initialized
INFO - 2022-03-30 07:10:02 --> Form Validation Class Initialized
DEBUG - 2022-03-30 07:10:02 --> Encrypt Class Initialized
INFO - 2022-03-30 07:10:02 --> Model "Patient_model" initialized
INFO - 2022-03-30 07:10:02 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 07:10:02 --> Model "Referredby_model" initialized
INFO - 2022-03-30 07:10:02 --> Model "Prefix_master" initialized
INFO - 2022-03-30 07:10:02 --> Model "Hospital_model" initialized
INFO - 2022-03-30 07:10:02 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 07:10:02 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-30 07:10:02 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 07:10:02 --> Final output sent to browser
DEBUG - 2022-03-30 07:10:02 --> Total execution time: 0.0326
ERROR - 2022-03-30 07:12:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 07:12:22 --> Config Class Initialized
INFO - 2022-03-30 07:12:22 --> Hooks Class Initialized
DEBUG - 2022-03-30 07:12:22 --> UTF-8 Support Enabled
INFO - 2022-03-30 07:12:22 --> Utf8 Class Initialized
INFO - 2022-03-30 07:12:22 --> URI Class Initialized
INFO - 2022-03-30 07:12:22 --> Router Class Initialized
INFO - 2022-03-30 07:12:22 --> Output Class Initialized
INFO - 2022-03-30 07:12:22 --> Security Class Initialized
DEBUG - 2022-03-30 07:12:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 07:12:22 --> Input Class Initialized
INFO - 2022-03-30 07:12:22 --> Language Class Initialized
INFO - 2022-03-30 07:12:22 --> Loader Class Initialized
INFO - 2022-03-30 07:12:22 --> Helper loaded: url_helper
INFO - 2022-03-30 07:12:22 --> Helper loaded: form_helper
INFO - 2022-03-30 07:12:22 --> Helper loaded: common_helper
INFO - 2022-03-30 07:12:22 --> Database Driver Class Initialized
DEBUG - 2022-03-30 07:12:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 07:12:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 07:12:22 --> Controller Class Initialized
INFO - 2022-03-30 07:12:22 --> Form Validation Class Initialized
DEBUG - 2022-03-30 07:12:22 --> Encrypt Class Initialized
INFO - 2022-03-30 07:12:22 --> Model "Patient_model" initialized
INFO - 2022-03-30 07:12:22 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 07:12:22 --> Model "Referredby_model" initialized
INFO - 2022-03-30 07:12:22 --> Model "Prefix_master" initialized
INFO - 2022-03-30 07:12:22 --> Model "Hospital_model" initialized
ERROR - 2022-03-30 07:12:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 07:12:22 --> Config Class Initialized
INFO - 2022-03-30 07:12:22 --> Hooks Class Initialized
DEBUG - 2022-03-30 07:12:22 --> UTF-8 Support Enabled
INFO - 2022-03-30 07:12:22 --> Utf8 Class Initialized
INFO - 2022-03-30 07:12:22 --> URI Class Initialized
INFO - 2022-03-30 07:12:22 --> Router Class Initialized
INFO - 2022-03-30 07:12:22 --> Output Class Initialized
INFO - 2022-03-30 07:12:22 --> Security Class Initialized
DEBUG - 2022-03-30 07:12:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 07:12:22 --> Input Class Initialized
INFO - 2022-03-30 07:12:22 --> Language Class Initialized
INFO - 2022-03-30 07:12:22 --> Loader Class Initialized
INFO - 2022-03-30 07:12:22 --> Helper loaded: url_helper
INFO - 2022-03-30 07:12:22 --> Helper loaded: form_helper
INFO - 2022-03-30 07:12:22 --> Helper loaded: common_helper
INFO - 2022-03-30 07:12:22 --> Database Driver Class Initialized
DEBUG - 2022-03-30 07:12:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 07:12:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 07:12:22 --> Controller Class Initialized
INFO - 2022-03-30 07:12:22 --> Form Validation Class Initialized
DEBUG - 2022-03-30 07:12:22 --> Encrypt Class Initialized
INFO - 2022-03-30 07:12:22 --> Model "Patient_model" initialized
INFO - 2022-03-30 07:12:22 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 07:12:22 --> Model "Referredby_model" initialized
INFO - 2022-03-30 07:12:22 --> Model "Prefix_master" initialized
INFO - 2022-03-30 07:12:22 --> Model "Hospital_model" initialized
INFO - 2022-03-30 07:12:22 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 07:12:22 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-30 07:12:22 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 07:12:22 --> Final output sent to browser
DEBUG - 2022-03-30 07:12:22 --> Total execution time: 0.0449
ERROR - 2022-03-30 07:12:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 07:12:23 --> Config Class Initialized
INFO - 2022-03-30 07:12:23 --> Hooks Class Initialized
DEBUG - 2022-03-30 07:12:23 --> UTF-8 Support Enabled
INFO - 2022-03-30 07:12:23 --> Utf8 Class Initialized
INFO - 2022-03-30 07:12:23 --> URI Class Initialized
INFO - 2022-03-30 07:12:23 --> Router Class Initialized
INFO - 2022-03-30 07:12:23 --> Output Class Initialized
INFO - 2022-03-30 07:12:23 --> Security Class Initialized
DEBUG - 2022-03-30 07:12:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 07:12:23 --> Input Class Initialized
INFO - 2022-03-30 07:12:23 --> Language Class Initialized
INFO - 2022-03-30 07:12:23 --> Loader Class Initialized
INFO - 2022-03-30 07:12:23 --> Helper loaded: url_helper
INFO - 2022-03-30 07:12:23 --> Helper loaded: form_helper
INFO - 2022-03-30 07:12:23 --> Helper loaded: common_helper
INFO - 2022-03-30 07:12:23 --> Database Driver Class Initialized
DEBUG - 2022-03-30 07:12:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 07:12:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 07:12:23 --> Controller Class Initialized
INFO - 2022-03-30 07:12:23 --> Form Validation Class Initialized
DEBUG - 2022-03-30 07:12:23 --> Encrypt Class Initialized
INFO - 2022-03-30 07:12:23 --> Model "Patient_model" initialized
INFO - 2022-03-30 07:12:23 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 07:12:23 --> Model "Prefix_master" initialized
INFO - 2022-03-30 07:12:23 --> Model "Users_model" initialized
INFO - 2022-03-30 07:12:23 --> Model "Hospital_model" initialized
INFO - 2022-03-30 07:12:23 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 07:12:23 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-30 07:12:23 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 07:12:23 --> Final output sent to browser
DEBUG - 2022-03-30 07:12:23 --> Total execution time: 0.0641
ERROR - 2022-03-30 07:13:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 07:13:30 --> Config Class Initialized
INFO - 2022-03-30 07:13:30 --> Hooks Class Initialized
DEBUG - 2022-03-30 07:13:30 --> UTF-8 Support Enabled
INFO - 2022-03-30 07:13:30 --> Utf8 Class Initialized
INFO - 2022-03-30 07:13:30 --> URI Class Initialized
INFO - 2022-03-30 07:13:30 --> Router Class Initialized
INFO - 2022-03-30 07:13:30 --> Output Class Initialized
INFO - 2022-03-30 07:13:30 --> Security Class Initialized
DEBUG - 2022-03-30 07:13:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 07:13:30 --> Input Class Initialized
INFO - 2022-03-30 07:13:30 --> Language Class Initialized
INFO - 2022-03-30 07:13:30 --> Loader Class Initialized
INFO - 2022-03-30 07:13:30 --> Helper loaded: url_helper
INFO - 2022-03-30 07:13:30 --> Helper loaded: form_helper
INFO - 2022-03-30 07:13:30 --> Helper loaded: common_helper
INFO - 2022-03-30 07:13:30 --> Database Driver Class Initialized
DEBUG - 2022-03-30 07:13:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 07:13:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 07:13:30 --> Controller Class Initialized
INFO - 2022-03-30 07:13:30 --> Form Validation Class Initialized
DEBUG - 2022-03-30 07:13:30 --> Encrypt Class Initialized
INFO - 2022-03-30 07:13:30 --> Model "Patient_model" initialized
INFO - 2022-03-30 07:13:30 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 07:13:30 --> Model "Prefix_master" initialized
INFO - 2022-03-30 07:13:30 --> Model "Users_model" initialized
INFO - 2022-03-30 07:13:30 --> Model "Hospital_model" initialized
INFO - 2022-03-30 07:13:30 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 07:13:30 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-30 07:13:30 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 07:13:30 --> Final output sent to browser
DEBUG - 2022-03-30 07:13:30 --> Total execution time: 0.0357
ERROR - 2022-03-30 07:13:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 07:13:37 --> Config Class Initialized
INFO - 2022-03-30 07:13:37 --> Hooks Class Initialized
DEBUG - 2022-03-30 07:13:37 --> UTF-8 Support Enabled
INFO - 2022-03-30 07:13:37 --> Utf8 Class Initialized
INFO - 2022-03-30 07:13:37 --> URI Class Initialized
INFO - 2022-03-30 07:13:37 --> Router Class Initialized
INFO - 2022-03-30 07:13:37 --> Output Class Initialized
INFO - 2022-03-30 07:13:37 --> Security Class Initialized
DEBUG - 2022-03-30 07:13:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 07:13:37 --> Input Class Initialized
INFO - 2022-03-30 07:13:37 --> Language Class Initialized
INFO - 2022-03-30 07:13:37 --> Loader Class Initialized
INFO - 2022-03-30 07:13:37 --> Helper loaded: url_helper
INFO - 2022-03-30 07:13:37 --> Helper loaded: form_helper
INFO - 2022-03-30 07:13:37 --> Helper loaded: common_helper
INFO - 2022-03-30 07:13:37 --> Database Driver Class Initialized
DEBUG - 2022-03-30 07:13:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 07:13:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 07:13:37 --> Controller Class Initialized
INFO - 2022-03-30 07:13:37 --> Form Validation Class Initialized
DEBUG - 2022-03-30 07:13:37 --> Encrypt Class Initialized
INFO - 2022-03-30 07:13:37 --> Model "Patient_model" initialized
INFO - 2022-03-30 07:13:37 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 07:13:37 --> Model "Referredby_model" initialized
INFO - 2022-03-30 07:13:37 --> Model "Prefix_master" initialized
INFO - 2022-03-30 07:13:37 --> Model "Hospital_model" initialized
INFO - 2022-03-30 07:13:37 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 07:13:37 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-30 07:13:37 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 07:13:37 --> Final output sent to browser
DEBUG - 2022-03-30 07:13:37 --> Total execution time: 0.0173
ERROR - 2022-03-30 07:14:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 07:14:06 --> Config Class Initialized
INFO - 2022-03-30 07:14:06 --> Hooks Class Initialized
DEBUG - 2022-03-30 07:14:06 --> UTF-8 Support Enabled
INFO - 2022-03-30 07:14:06 --> Utf8 Class Initialized
INFO - 2022-03-30 07:14:06 --> URI Class Initialized
INFO - 2022-03-30 07:14:06 --> Router Class Initialized
INFO - 2022-03-30 07:14:06 --> Output Class Initialized
INFO - 2022-03-30 07:14:06 --> Security Class Initialized
DEBUG - 2022-03-30 07:14:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 07:14:06 --> Input Class Initialized
INFO - 2022-03-30 07:14:06 --> Language Class Initialized
INFO - 2022-03-30 07:14:06 --> Loader Class Initialized
INFO - 2022-03-30 07:14:06 --> Helper loaded: url_helper
INFO - 2022-03-30 07:14:06 --> Helper loaded: form_helper
INFO - 2022-03-30 07:14:06 --> Helper loaded: common_helper
INFO - 2022-03-30 07:14:06 --> Database Driver Class Initialized
DEBUG - 2022-03-30 07:14:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 07:14:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 07:14:06 --> Controller Class Initialized
INFO - 2022-03-30 07:14:06 --> Form Validation Class Initialized
DEBUG - 2022-03-30 07:14:06 --> Encrypt Class Initialized
INFO - 2022-03-30 07:14:06 --> Model "Patient_model" initialized
INFO - 2022-03-30 07:14:06 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 07:14:06 --> Model "Referredby_model" initialized
INFO - 2022-03-30 07:14:06 --> Model "Prefix_master" initialized
INFO - 2022-03-30 07:14:06 --> Model "Hospital_model" initialized
INFO - 2022-03-30 07:14:06 --> Upload Class Initialized
INFO - 2022-03-30 07:14:06 --> Final output sent to browser
DEBUG - 2022-03-30 07:14:06 --> Total execution time: 0.0153
ERROR - 2022-03-30 07:15:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 07:15:20 --> Config Class Initialized
INFO - 2022-03-30 07:15:20 --> Hooks Class Initialized
DEBUG - 2022-03-30 07:15:20 --> UTF-8 Support Enabled
INFO - 2022-03-30 07:15:20 --> Utf8 Class Initialized
INFO - 2022-03-30 07:15:20 --> URI Class Initialized
INFO - 2022-03-30 07:15:20 --> Router Class Initialized
INFO - 2022-03-30 07:15:20 --> Output Class Initialized
INFO - 2022-03-30 07:15:20 --> Security Class Initialized
DEBUG - 2022-03-30 07:15:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 07:15:20 --> Input Class Initialized
INFO - 2022-03-30 07:15:20 --> Language Class Initialized
INFO - 2022-03-30 07:15:20 --> Loader Class Initialized
INFO - 2022-03-30 07:15:20 --> Helper loaded: url_helper
INFO - 2022-03-30 07:15:20 --> Helper loaded: form_helper
INFO - 2022-03-30 07:15:20 --> Helper loaded: common_helper
INFO - 2022-03-30 07:15:20 --> Database Driver Class Initialized
DEBUG - 2022-03-30 07:15:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 07:15:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 07:15:20 --> Controller Class Initialized
INFO - 2022-03-30 07:15:20 --> Form Validation Class Initialized
DEBUG - 2022-03-30 07:15:20 --> Encrypt Class Initialized
INFO - 2022-03-30 07:15:20 --> Model "Patient_model" initialized
INFO - 2022-03-30 07:15:20 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 07:15:20 --> Model "Referredby_model" initialized
INFO - 2022-03-30 07:15:20 --> Model "Prefix_master" initialized
INFO - 2022-03-30 07:15:20 --> Model "Hospital_model" initialized
INFO - 2022-03-30 07:15:20 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 07:15:20 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-30 07:15:20 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 07:15:20 --> Final output sent to browser
DEBUG - 2022-03-30 07:15:20 --> Total execution time: 0.0141
ERROR - 2022-03-30 07:15:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 07:15:37 --> Config Class Initialized
INFO - 2022-03-30 07:15:37 --> Hooks Class Initialized
DEBUG - 2022-03-30 07:15:37 --> UTF-8 Support Enabled
INFO - 2022-03-30 07:15:37 --> Utf8 Class Initialized
INFO - 2022-03-30 07:15:37 --> URI Class Initialized
INFO - 2022-03-30 07:15:37 --> Router Class Initialized
INFO - 2022-03-30 07:15:37 --> Output Class Initialized
INFO - 2022-03-30 07:15:37 --> Security Class Initialized
DEBUG - 2022-03-30 07:15:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 07:15:37 --> Input Class Initialized
INFO - 2022-03-30 07:15:37 --> Language Class Initialized
INFO - 2022-03-30 07:15:37 --> Loader Class Initialized
INFO - 2022-03-30 07:15:37 --> Helper loaded: url_helper
INFO - 2022-03-30 07:15:37 --> Helper loaded: form_helper
INFO - 2022-03-30 07:15:37 --> Helper loaded: common_helper
INFO - 2022-03-30 07:15:37 --> Database Driver Class Initialized
DEBUG - 2022-03-30 07:15:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 07:15:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 07:15:37 --> Controller Class Initialized
INFO - 2022-03-30 07:15:37 --> Form Validation Class Initialized
DEBUG - 2022-03-30 07:15:37 --> Encrypt Class Initialized
INFO - 2022-03-30 07:15:37 --> Model "Patient_model" initialized
INFO - 2022-03-30 07:15:37 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 07:15:37 --> Model "Referredby_model" initialized
INFO - 2022-03-30 07:15:37 --> Model "Prefix_master" initialized
INFO - 2022-03-30 07:15:37 --> Model "Hospital_model" initialized
INFO - 2022-03-30 07:15:37 --> Upload Class Initialized
INFO - 2022-03-30 07:15:37 --> Final output sent to browser
DEBUG - 2022-03-30 07:15:37 --> Total execution time: 0.0065
ERROR - 2022-03-30 07:15:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 07:15:49 --> Config Class Initialized
INFO - 2022-03-30 07:15:49 --> Hooks Class Initialized
DEBUG - 2022-03-30 07:15:49 --> UTF-8 Support Enabled
INFO - 2022-03-30 07:15:49 --> Utf8 Class Initialized
INFO - 2022-03-30 07:15:49 --> URI Class Initialized
INFO - 2022-03-30 07:15:49 --> Router Class Initialized
INFO - 2022-03-30 07:15:49 --> Output Class Initialized
INFO - 2022-03-30 07:15:49 --> Security Class Initialized
DEBUG - 2022-03-30 07:15:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 07:15:49 --> Input Class Initialized
INFO - 2022-03-30 07:15:49 --> Language Class Initialized
INFO - 2022-03-30 07:15:49 --> Loader Class Initialized
INFO - 2022-03-30 07:15:49 --> Helper loaded: url_helper
INFO - 2022-03-30 07:15:49 --> Helper loaded: form_helper
INFO - 2022-03-30 07:15:49 --> Helper loaded: common_helper
INFO - 2022-03-30 07:15:49 --> Database Driver Class Initialized
DEBUG - 2022-03-30 07:15:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 07:15:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 07:15:49 --> Controller Class Initialized
INFO - 2022-03-30 07:15:49 --> Form Validation Class Initialized
DEBUG - 2022-03-30 07:15:49 --> Encrypt Class Initialized
INFO - 2022-03-30 07:15:49 --> Model "Patient_model" initialized
INFO - 2022-03-30 07:15:49 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 07:15:49 --> Model "Referredby_model" initialized
INFO - 2022-03-30 07:15:49 --> Model "Prefix_master" initialized
INFO - 2022-03-30 07:15:49 --> Model "Hospital_model" initialized
INFO - 2022-03-30 07:15:49 --> File loaded: /home3/karoteam/public_html/application/views/header.php
ERROR - 2022-03-30 07:15:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 07:15:52 --> Config Class Initialized
INFO - 2022-03-30 07:15:52 --> Hooks Class Initialized
DEBUG - 2022-03-30 07:15:52 --> UTF-8 Support Enabled
INFO - 2022-03-30 07:15:52 --> Utf8 Class Initialized
INFO - 2022-03-30 07:15:52 --> URI Class Initialized
INFO - 2022-03-30 07:15:52 --> Router Class Initialized
INFO - 2022-03-30 07:15:52 --> Output Class Initialized
INFO - 2022-03-30 07:15:52 --> Security Class Initialized
DEBUG - 2022-03-30 07:15:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 07:15:52 --> Input Class Initialized
INFO - 2022-03-30 07:15:52 --> Language Class Initialized
INFO - 2022-03-30 07:15:52 --> Loader Class Initialized
INFO - 2022-03-30 07:15:52 --> Helper loaded: url_helper
INFO - 2022-03-30 07:15:52 --> Helper loaded: form_helper
INFO - 2022-03-30 07:15:52 --> Helper loaded: common_helper
INFO - 2022-03-30 07:15:52 --> Database Driver Class Initialized
DEBUG - 2022-03-30 07:15:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 07:15:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 07:15:52 --> Controller Class Initialized
INFO - 2022-03-30 07:15:52 --> Form Validation Class Initialized
DEBUG - 2022-03-30 07:15:52 --> Encrypt Class Initialized
INFO - 2022-03-30 07:15:52 --> Model "Patient_model" initialized
INFO - 2022-03-30 07:15:52 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 07:15:52 --> Model "Referredby_model" initialized
INFO - 2022-03-30 07:15:52 --> Model "Prefix_master" initialized
INFO - 2022-03-30 07:15:52 --> Model "Hospital_model" initialized
INFO - 2022-03-30 07:15:52 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 07:15:55 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-30 07:15:55 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 07:15:56 --> Final output sent to browser
DEBUG - 2022-03-30 07:15:56 --> Total execution time: 6.7613
ERROR - 2022-03-30 07:15:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 07:15:58 --> Config Class Initialized
INFO - 2022-03-30 07:15:58 --> Hooks Class Initialized
DEBUG - 2022-03-30 07:15:58 --> UTF-8 Support Enabled
INFO - 2022-03-30 07:15:58 --> Utf8 Class Initialized
INFO - 2022-03-30 07:15:58 --> URI Class Initialized
INFO - 2022-03-30 07:15:58 --> Router Class Initialized
INFO - 2022-03-30 07:15:58 --> Output Class Initialized
INFO - 2022-03-30 07:15:58 --> Security Class Initialized
DEBUG - 2022-03-30 07:15:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 07:15:58 --> Input Class Initialized
INFO - 2022-03-30 07:15:58 --> Language Class Initialized
INFO - 2022-03-30 07:15:58 --> Loader Class Initialized
INFO - 2022-03-30 07:15:58 --> Helper loaded: url_helper
INFO - 2022-03-30 07:15:58 --> Helper loaded: form_helper
INFO - 2022-03-30 07:15:58 --> Helper loaded: common_helper
INFO - 2022-03-30 07:15:58 --> Database Driver Class Initialized
DEBUG - 2022-03-30 07:15:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 07:15:59 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-30 07:15:59 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 07:16:00 --> Final output sent to browser
DEBUG - 2022-03-30 07:16:00 --> Total execution time: 7.7172
INFO - 2022-03-30 07:16:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 07:16:00 --> Controller Class Initialized
INFO - 2022-03-30 07:16:00 --> Form Validation Class Initialized
DEBUG - 2022-03-30 07:16:00 --> Encrypt Class Initialized
INFO - 2022-03-30 07:16:00 --> Model "Patient_model" initialized
INFO - 2022-03-30 07:16:00 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 07:16:00 --> Model "Referredby_model" initialized
INFO - 2022-03-30 07:16:00 --> Model "Prefix_master" initialized
INFO - 2022-03-30 07:16:00 --> Model "Hospital_model" initialized
ERROR - 2022-03-30 07:16:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 07:16:00 --> Config Class Initialized
INFO - 2022-03-30 07:16:00 --> Hooks Class Initialized
DEBUG - 2022-03-30 07:16:00 --> UTF-8 Support Enabled
INFO - 2022-03-30 07:16:00 --> Utf8 Class Initialized
INFO - 2022-03-30 07:16:00 --> URI Class Initialized
INFO - 2022-03-30 07:16:00 --> Router Class Initialized
INFO - 2022-03-30 07:16:00 --> Output Class Initialized
INFO - 2022-03-30 07:16:00 --> Security Class Initialized
DEBUG - 2022-03-30 07:16:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 07:16:00 --> Input Class Initialized
INFO - 2022-03-30 07:16:00 --> Language Class Initialized
INFO - 2022-03-30 07:16:00 --> Loader Class Initialized
INFO - 2022-03-30 07:16:00 --> Helper loaded: url_helper
INFO - 2022-03-30 07:16:00 --> Helper loaded: form_helper
INFO - 2022-03-30 07:16:00 --> Helper loaded: common_helper
INFO - 2022-03-30 07:16:00 --> Database Driver Class Initialized
DEBUG - 2022-03-30 07:16:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 07:16:00 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 07:16:07 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-30 07:16:07 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 07:16:07 --> Final output sent to browser
DEBUG - 2022-03-30 07:16:07 --> Total execution time: 9.1390
INFO - 2022-03-30 07:16:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 07:16:07 --> Controller Class Initialized
INFO - 2022-03-30 07:16:07 --> Form Validation Class Initialized
DEBUG - 2022-03-30 07:16:07 --> Encrypt Class Initialized
INFO - 2022-03-30 07:16:07 --> Model "Patient_model" initialized
INFO - 2022-03-30 07:16:07 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 07:16:07 --> Model "Referredby_model" initialized
INFO - 2022-03-30 07:16:07 --> Model "Prefix_master" initialized
INFO - 2022-03-30 07:16:07 --> Model "Hospital_model" initialized
INFO - 2022-03-30 07:16:07 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 07:16:14 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-30 07:16:14 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 07:16:16 --> Final output sent to browser
DEBUG - 2022-03-30 07:16:16 --> Total execution time: 14.0994
ERROR - 2022-03-30 07:16:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 07:16:44 --> Config Class Initialized
INFO - 2022-03-30 07:16:44 --> Hooks Class Initialized
DEBUG - 2022-03-30 07:16:44 --> UTF-8 Support Enabled
INFO - 2022-03-30 07:16:44 --> Utf8 Class Initialized
INFO - 2022-03-30 07:16:44 --> URI Class Initialized
INFO - 2022-03-30 07:16:44 --> Router Class Initialized
INFO - 2022-03-30 07:16:44 --> Output Class Initialized
INFO - 2022-03-30 07:16:44 --> Security Class Initialized
DEBUG - 2022-03-30 07:16:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 07:16:44 --> Input Class Initialized
INFO - 2022-03-30 07:16:44 --> Language Class Initialized
INFO - 2022-03-30 07:16:44 --> Loader Class Initialized
INFO - 2022-03-30 07:16:44 --> Helper loaded: url_helper
INFO - 2022-03-30 07:16:44 --> Helper loaded: form_helper
INFO - 2022-03-30 07:16:44 --> Helper loaded: common_helper
INFO - 2022-03-30 07:16:44 --> Database Driver Class Initialized
DEBUG - 2022-03-30 07:16:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 07:16:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 07:16:44 --> Controller Class Initialized
INFO - 2022-03-30 07:16:44 --> Form Validation Class Initialized
DEBUG - 2022-03-30 07:16:44 --> Encrypt Class Initialized
INFO - 2022-03-30 07:16:44 --> Model "Patient_model" initialized
INFO - 2022-03-30 07:16:44 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 07:16:44 --> Model "Referredby_model" initialized
INFO - 2022-03-30 07:16:44 --> Model "Prefix_master" initialized
INFO - 2022-03-30 07:16:44 --> Model "Hospital_model" initialized
INFO - 2022-03-30 07:16:45 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 07:16:45 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-30 07:16:45 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 07:16:45 --> Final output sent to browser
DEBUG - 2022-03-30 07:16:45 --> Total execution time: 0.0297
ERROR - 2022-03-30 07:17:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 07:17:14 --> Config Class Initialized
INFO - 2022-03-30 07:17:14 --> Hooks Class Initialized
DEBUG - 2022-03-30 07:17:14 --> UTF-8 Support Enabled
INFO - 2022-03-30 07:17:14 --> Utf8 Class Initialized
INFO - 2022-03-30 07:17:14 --> URI Class Initialized
INFO - 2022-03-30 07:17:14 --> Router Class Initialized
INFO - 2022-03-30 07:17:14 --> Output Class Initialized
INFO - 2022-03-30 07:17:14 --> Security Class Initialized
DEBUG - 2022-03-30 07:17:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 07:17:14 --> Input Class Initialized
INFO - 2022-03-30 07:17:14 --> Language Class Initialized
INFO - 2022-03-30 07:17:14 --> Loader Class Initialized
INFO - 2022-03-30 07:17:14 --> Helper loaded: url_helper
INFO - 2022-03-30 07:17:14 --> Helper loaded: form_helper
INFO - 2022-03-30 07:17:14 --> Helper loaded: common_helper
INFO - 2022-03-30 07:17:14 --> Database Driver Class Initialized
DEBUG - 2022-03-30 07:17:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 07:17:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 07:17:14 --> Controller Class Initialized
INFO - 2022-03-30 07:17:14 --> Model "Referredby_model" initialized
INFO - 2022-03-30 07:17:14 --> Final output sent to browser
DEBUG - 2022-03-30 07:17:14 --> Total execution time: 0.0079
ERROR - 2022-03-30 07:17:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 07:17:29 --> Config Class Initialized
INFO - 2022-03-30 07:17:29 --> Hooks Class Initialized
DEBUG - 2022-03-30 07:17:29 --> UTF-8 Support Enabled
INFO - 2022-03-30 07:17:29 --> Utf8 Class Initialized
INFO - 2022-03-30 07:17:29 --> URI Class Initialized
INFO - 2022-03-30 07:17:29 --> Router Class Initialized
INFO - 2022-03-30 07:17:29 --> Output Class Initialized
INFO - 2022-03-30 07:17:29 --> Security Class Initialized
DEBUG - 2022-03-30 07:17:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 07:17:29 --> Input Class Initialized
INFO - 2022-03-30 07:17:29 --> Language Class Initialized
INFO - 2022-03-30 07:17:29 --> Loader Class Initialized
INFO - 2022-03-30 07:17:29 --> Helper loaded: url_helper
INFO - 2022-03-30 07:17:29 --> Helper loaded: form_helper
INFO - 2022-03-30 07:17:29 --> Helper loaded: common_helper
INFO - 2022-03-30 07:17:29 --> Database Driver Class Initialized
DEBUG - 2022-03-30 07:17:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 07:17:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 07:17:29 --> Controller Class Initialized
INFO - 2022-03-30 07:17:29 --> Model "Referredby_model" initialized
INFO - 2022-03-30 07:17:29 --> Final output sent to browser
DEBUG - 2022-03-30 07:17:29 --> Total execution time: 0.0083
ERROR - 2022-03-30 07:17:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 07:17:50 --> Config Class Initialized
INFO - 2022-03-30 07:17:50 --> Hooks Class Initialized
DEBUG - 2022-03-30 07:17:50 --> UTF-8 Support Enabled
INFO - 2022-03-30 07:17:50 --> Utf8 Class Initialized
INFO - 2022-03-30 07:17:50 --> URI Class Initialized
INFO - 2022-03-30 07:17:50 --> Router Class Initialized
INFO - 2022-03-30 07:17:50 --> Output Class Initialized
INFO - 2022-03-30 07:17:50 --> Security Class Initialized
DEBUG - 2022-03-30 07:17:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 07:17:50 --> Input Class Initialized
INFO - 2022-03-30 07:17:50 --> Language Class Initialized
INFO - 2022-03-30 07:17:50 --> Loader Class Initialized
INFO - 2022-03-30 07:17:50 --> Helper loaded: url_helper
INFO - 2022-03-30 07:17:50 --> Helper loaded: form_helper
INFO - 2022-03-30 07:17:50 --> Helper loaded: common_helper
INFO - 2022-03-30 07:17:50 --> Database Driver Class Initialized
DEBUG - 2022-03-30 07:17:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 07:17:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 07:17:50 --> Controller Class Initialized
INFO - 2022-03-30 07:17:50 --> Form Validation Class Initialized
DEBUG - 2022-03-30 07:17:50 --> Encrypt Class Initialized
INFO - 2022-03-30 07:17:50 --> Model "Patient_model" initialized
INFO - 2022-03-30 07:17:50 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 07:17:50 --> Model "Referredby_model" initialized
INFO - 2022-03-30 07:17:50 --> Model "Prefix_master" initialized
INFO - 2022-03-30 07:17:50 --> Model "Hospital_model" initialized
ERROR - 2022-03-30 07:17:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 07:17:50 --> Config Class Initialized
INFO - 2022-03-30 07:17:50 --> Hooks Class Initialized
DEBUG - 2022-03-30 07:17:50 --> UTF-8 Support Enabled
INFO - 2022-03-30 07:17:50 --> Utf8 Class Initialized
INFO - 2022-03-30 07:17:50 --> URI Class Initialized
INFO - 2022-03-30 07:17:50 --> Router Class Initialized
INFO - 2022-03-30 07:17:50 --> Output Class Initialized
INFO - 2022-03-30 07:17:50 --> Security Class Initialized
DEBUG - 2022-03-30 07:17:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 07:17:50 --> Input Class Initialized
INFO - 2022-03-30 07:17:50 --> Language Class Initialized
INFO - 2022-03-30 07:17:50 --> Loader Class Initialized
INFO - 2022-03-30 07:17:50 --> Helper loaded: url_helper
INFO - 2022-03-30 07:17:50 --> Helper loaded: form_helper
INFO - 2022-03-30 07:17:50 --> Helper loaded: common_helper
INFO - 2022-03-30 07:17:50 --> Database Driver Class Initialized
DEBUG - 2022-03-30 07:17:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 07:17:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 07:17:50 --> Controller Class Initialized
INFO - 2022-03-30 07:17:50 --> Form Validation Class Initialized
DEBUG - 2022-03-30 07:17:50 --> Encrypt Class Initialized
INFO - 2022-03-30 07:17:50 --> Model "Patient_model" initialized
INFO - 2022-03-30 07:17:50 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 07:17:50 --> Model "Referredby_model" initialized
INFO - 2022-03-30 07:17:50 --> Model "Prefix_master" initialized
INFO - 2022-03-30 07:17:50 --> Model "Hospital_model" initialized
INFO - 2022-03-30 07:17:50 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 07:17:50 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-30 07:17:50 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 07:17:50 --> Final output sent to browser
DEBUG - 2022-03-30 07:17:50 --> Total execution time: 0.0386
ERROR - 2022-03-30 07:17:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 07:17:51 --> Config Class Initialized
INFO - 2022-03-30 07:17:51 --> Hooks Class Initialized
DEBUG - 2022-03-30 07:17:51 --> UTF-8 Support Enabled
INFO - 2022-03-30 07:17:51 --> Utf8 Class Initialized
INFO - 2022-03-30 07:17:51 --> URI Class Initialized
INFO - 2022-03-30 07:17:51 --> Router Class Initialized
INFO - 2022-03-30 07:17:51 --> Output Class Initialized
INFO - 2022-03-30 07:17:51 --> Security Class Initialized
DEBUG - 2022-03-30 07:17:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 07:17:51 --> Input Class Initialized
INFO - 2022-03-30 07:17:51 --> Language Class Initialized
INFO - 2022-03-30 07:17:51 --> Loader Class Initialized
INFO - 2022-03-30 07:17:51 --> Helper loaded: url_helper
INFO - 2022-03-30 07:17:51 --> Helper loaded: form_helper
INFO - 2022-03-30 07:17:51 --> Helper loaded: common_helper
INFO - 2022-03-30 07:17:51 --> Database Driver Class Initialized
DEBUG - 2022-03-30 07:17:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 07:17:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 07:17:51 --> Controller Class Initialized
INFO - 2022-03-30 07:17:51 --> Form Validation Class Initialized
DEBUG - 2022-03-30 07:17:51 --> Encrypt Class Initialized
INFO - 2022-03-30 07:17:51 --> Model "Patient_model" initialized
INFO - 2022-03-30 07:17:51 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 07:17:51 --> Model "Prefix_master" initialized
INFO - 2022-03-30 07:17:51 --> Model "Users_model" initialized
INFO - 2022-03-30 07:17:51 --> Model "Hospital_model" initialized
INFO - 2022-03-30 07:17:51 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 07:17:51 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-30 07:17:51 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 07:17:51 --> Final output sent to browser
DEBUG - 2022-03-30 07:17:51 --> Total execution time: 0.0467
ERROR - 2022-03-30 07:18:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 07:18:05 --> Config Class Initialized
INFO - 2022-03-30 07:18:05 --> Hooks Class Initialized
DEBUG - 2022-03-30 07:18:05 --> UTF-8 Support Enabled
INFO - 2022-03-30 07:18:05 --> Utf8 Class Initialized
INFO - 2022-03-30 07:18:05 --> URI Class Initialized
INFO - 2022-03-30 07:18:05 --> Router Class Initialized
INFO - 2022-03-30 07:18:05 --> Output Class Initialized
INFO - 2022-03-30 07:18:05 --> Security Class Initialized
DEBUG - 2022-03-30 07:18:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 07:18:05 --> Input Class Initialized
INFO - 2022-03-30 07:18:05 --> Language Class Initialized
INFO - 2022-03-30 07:18:05 --> Loader Class Initialized
INFO - 2022-03-30 07:18:05 --> Helper loaded: url_helper
INFO - 2022-03-30 07:18:05 --> Helper loaded: form_helper
INFO - 2022-03-30 07:18:05 --> Helper loaded: common_helper
INFO - 2022-03-30 07:18:05 --> Database Driver Class Initialized
DEBUG - 2022-03-30 07:18:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 07:18:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 07:18:05 --> Controller Class Initialized
INFO - 2022-03-30 07:18:05 --> Model "Referredby_model" initialized
INFO - 2022-03-30 07:18:05 --> Final output sent to browser
DEBUG - 2022-03-30 07:18:05 --> Total execution time: 0.0081
ERROR - 2022-03-30 07:18:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 07:18:35 --> Config Class Initialized
INFO - 2022-03-30 07:18:35 --> Hooks Class Initialized
DEBUG - 2022-03-30 07:18:35 --> UTF-8 Support Enabled
INFO - 2022-03-30 07:18:35 --> Utf8 Class Initialized
INFO - 2022-03-30 07:18:35 --> URI Class Initialized
INFO - 2022-03-30 07:18:35 --> Router Class Initialized
INFO - 2022-03-30 07:18:35 --> Output Class Initialized
INFO - 2022-03-30 07:18:35 --> Security Class Initialized
DEBUG - 2022-03-30 07:18:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 07:18:35 --> Input Class Initialized
INFO - 2022-03-30 07:18:35 --> Language Class Initialized
INFO - 2022-03-30 07:18:35 --> Loader Class Initialized
INFO - 2022-03-30 07:18:35 --> Helper loaded: url_helper
INFO - 2022-03-30 07:18:35 --> Helper loaded: form_helper
INFO - 2022-03-30 07:18:35 --> Helper loaded: common_helper
INFO - 2022-03-30 07:18:35 --> Database Driver Class Initialized
DEBUG - 2022-03-30 07:18:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 07:18:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 07:18:35 --> Controller Class Initialized
INFO - 2022-03-30 07:18:35 --> Form Validation Class Initialized
DEBUG - 2022-03-30 07:18:35 --> Encrypt Class Initialized
INFO - 2022-03-30 07:18:35 --> Model "Patient_model" initialized
INFO - 2022-03-30 07:18:35 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 07:18:35 --> Model "Referredby_model" initialized
INFO - 2022-03-30 07:18:35 --> Model "Prefix_master" initialized
INFO - 2022-03-30 07:18:35 --> Model "Hospital_model" initialized
INFO - 2022-03-30 07:18:35 --> Final output sent to browser
DEBUG - 2022-03-30 07:18:35 --> Total execution time: 0.0093
ERROR - 2022-03-30 07:21:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 07:21:09 --> Config Class Initialized
INFO - 2022-03-30 07:21:09 --> Hooks Class Initialized
DEBUG - 2022-03-30 07:21:09 --> UTF-8 Support Enabled
INFO - 2022-03-30 07:21:09 --> Utf8 Class Initialized
INFO - 2022-03-30 07:21:09 --> URI Class Initialized
INFO - 2022-03-30 07:21:09 --> Router Class Initialized
INFO - 2022-03-30 07:21:09 --> Output Class Initialized
INFO - 2022-03-30 07:21:09 --> Security Class Initialized
DEBUG - 2022-03-30 07:21:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 07:21:09 --> Input Class Initialized
INFO - 2022-03-30 07:21:09 --> Language Class Initialized
INFO - 2022-03-30 07:21:09 --> Loader Class Initialized
INFO - 2022-03-30 07:21:09 --> Helper loaded: url_helper
INFO - 2022-03-30 07:21:09 --> Helper loaded: form_helper
INFO - 2022-03-30 07:21:09 --> Helper loaded: common_helper
INFO - 2022-03-30 07:21:09 --> Database Driver Class Initialized
DEBUG - 2022-03-30 07:21:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 07:21:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 07:21:09 --> Controller Class Initialized
INFO - 2022-03-30 07:21:09 --> Form Validation Class Initialized
DEBUG - 2022-03-30 07:21:09 --> Encrypt Class Initialized
INFO - 2022-03-30 07:21:09 --> Model "Patient_model" initialized
INFO - 2022-03-30 07:21:09 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 07:21:09 --> Model "Referredby_model" initialized
INFO - 2022-03-30 07:21:09 --> Model "Prefix_master" initialized
INFO - 2022-03-30 07:21:09 --> Model "Hospital_model" initialized
INFO - 2022-03-30 07:21:09 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 07:21:16 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-30 07:21:16 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 07:21:18 --> Final output sent to browser
DEBUG - 2022-03-30 07:21:18 --> Total execution time: 7.1400
ERROR - 2022-03-30 07:21:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 07:21:32 --> Config Class Initialized
INFO - 2022-03-30 07:21:32 --> Hooks Class Initialized
DEBUG - 2022-03-30 07:21:32 --> UTF-8 Support Enabled
INFO - 2022-03-30 07:21:32 --> Utf8 Class Initialized
INFO - 2022-03-30 07:21:32 --> URI Class Initialized
INFO - 2022-03-30 07:21:32 --> Router Class Initialized
INFO - 2022-03-30 07:21:32 --> Output Class Initialized
INFO - 2022-03-30 07:21:32 --> Security Class Initialized
DEBUG - 2022-03-30 07:21:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 07:21:32 --> Input Class Initialized
INFO - 2022-03-30 07:21:32 --> Language Class Initialized
INFO - 2022-03-30 07:21:32 --> Loader Class Initialized
INFO - 2022-03-30 07:21:32 --> Helper loaded: url_helper
INFO - 2022-03-30 07:21:32 --> Helper loaded: form_helper
INFO - 2022-03-30 07:21:32 --> Helper loaded: common_helper
INFO - 2022-03-30 07:21:32 --> Database Driver Class Initialized
DEBUG - 2022-03-30 07:21:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 07:21:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 07:21:32 --> Controller Class Initialized
INFO - 2022-03-30 07:21:32 --> Form Validation Class Initialized
DEBUG - 2022-03-30 07:21:32 --> Encrypt Class Initialized
INFO - 2022-03-30 07:21:32 --> Model "Patient_model" initialized
INFO - 2022-03-30 07:21:32 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 07:21:32 --> Model "Referredby_model" initialized
INFO - 2022-03-30 07:21:32 --> Model "Prefix_master" initialized
INFO - 2022-03-30 07:21:32 --> Model "Hospital_model" initialized
ERROR - 2022-03-30 07:21:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 07:21:33 --> Config Class Initialized
INFO - 2022-03-30 07:21:33 --> Hooks Class Initialized
DEBUG - 2022-03-30 07:21:33 --> UTF-8 Support Enabled
INFO - 2022-03-30 07:21:33 --> Utf8 Class Initialized
INFO - 2022-03-30 07:21:33 --> URI Class Initialized
INFO - 2022-03-30 07:21:33 --> Router Class Initialized
INFO - 2022-03-30 07:21:33 --> Output Class Initialized
INFO - 2022-03-30 07:21:33 --> Security Class Initialized
DEBUG - 2022-03-30 07:21:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 07:21:33 --> Input Class Initialized
INFO - 2022-03-30 07:21:33 --> Language Class Initialized
INFO - 2022-03-30 07:21:33 --> Loader Class Initialized
INFO - 2022-03-30 07:21:33 --> Helper loaded: url_helper
INFO - 2022-03-30 07:21:33 --> Helper loaded: form_helper
INFO - 2022-03-30 07:21:33 --> Helper loaded: common_helper
INFO - 2022-03-30 07:21:33 --> Database Driver Class Initialized
DEBUG - 2022-03-30 07:21:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 07:21:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 07:21:33 --> Controller Class Initialized
INFO - 2022-03-30 07:21:33 --> Form Validation Class Initialized
DEBUG - 2022-03-30 07:21:33 --> Encrypt Class Initialized
INFO - 2022-03-30 07:21:33 --> Model "Patient_model" initialized
INFO - 2022-03-30 07:21:33 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 07:21:33 --> Model "Referredby_model" initialized
INFO - 2022-03-30 07:21:33 --> Model "Prefix_master" initialized
INFO - 2022-03-30 07:21:33 --> Model "Hospital_model" initialized
INFO - 2022-03-30 07:21:33 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 07:21:33 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-30 07:21:33 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 07:21:33 --> Final output sent to browser
DEBUG - 2022-03-30 07:21:33 --> Total execution time: 0.0362
ERROR - 2022-03-30 07:21:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 07:21:33 --> Config Class Initialized
INFO - 2022-03-30 07:21:33 --> Hooks Class Initialized
DEBUG - 2022-03-30 07:21:33 --> UTF-8 Support Enabled
INFO - 2022-03-30 07:21:33 --> Utf8 Class Initialized
INFO - 2022-03-30 07:21:33 --> URI Class Initialized
INFO - 2022-03-30 07:21:33 --> Router Class Initialized
INFO - 2022-03-30 07:21:33 --> Output Class Initialized
INFO - 2022-03-30 07:21:33 --> Security Class Initialized
DEBUG - 2022-03-30 07:21:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 07:21:33 --> Input Class Initialized
INFO - 2022-03-30 07:21:33 --> Language Class Initialized
INFO - 2022-03-30 07:21:33 --> Loader Class Initialized
INFO - 2022-03-30 07:21:33 --> Helper loaded: url_helper
INFO - 2022-03-30 07:21:33 --> Helper loaded: form_helper
INFO - 2022-03-30 07:21:33 --> Helper loaded: common_helper
INFO - 2022-03-30 07:21:33 --> Database Driver Class Initialized
DEBUG - 2022-03-30 07:21:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 07:21:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 07:21:33 --> Controller Class Initialized
INFO - 2022-03-30 07:21:33 --> Form Validation Class Initialized
DEBUG - 2022-03-30 07:21:33 --> Encrypt Class Initialized
INFO - 2022-03-30 07:21:33 --> Model "Patient_model" initialized
INFO - 2022-03-30 07:21:33 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 07:21:33 --> Model "Prefix_master" initialized
INFO - 2022-03-30 07:21:33 --> Model "Users_model" initialized
INFO - 2022-03-30 07:21:33 --> Model "Hospital_model" initialized
INFO - 2022-03-30 07:21:33 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 07:21:33 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-30 07:21:33 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 07:21:33 --> Final output sent to browser
DEBUG - 2022-03-30 07:21:33 --> Total execution time: 0.0540
ERROR - 2022-03-30 07:22:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 07:22:07 --> Config Class Initialized
INFO - 2022-03-30 07:22:07 --> Hooks Class Initialized
DEBUG - 2022-03-30 07:22:07 --> UTF-8 Support Enabled
INFO - 2022-03-30 07:22:07 --> Utf8 Class Initialized
INFO - 2022-03-30 07:22:07 --> URI Class Initialized
INFO - 2022-03-30 07:22:07 --> Router Class Initialized
INFO - 2022-03-30 07:22:07 --> Output Class Initialized
INFO - 2022-03-30 07:22:07 --> Security Class Initialized
DEBUG - 2022-03-30 07:22:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 07:22:07 --> Input Class Initialized
INFO - 2022-03-30 07:22:07 --> Language Class Initialized
INFO - 2022-03-30 07:22:07 --> Loader Class Initialized
INFO - 2022-03-30 07:22:07 --> Helper loaded: url_helper
INFO - 2022-03-30 07:22:07 --> Helper loaded: form_helper
INFO - 2022-03-30 07:22:07 --> Helper loaded: common_helper
INFO - 2022-03-30 07:22:07 --> Database Driver Class Initialized
DEBUG - 2022-03-30 07:22:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 07:22:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 07:22:07 --> Controller Class Initialized
INFO - 2022-03-30 07:22:07 --> Form Validation Class Initialized
DEBUG - 2022-03-30 07:22:07 --> Encrypt Class Initialized
INFO - 2022-03-30 07:22:07 --> Model "Patient_model" initialized
INFO - 2022-03-30 07:22:07 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 07:22:07 --> Model "Referredby_model" initialized
INFO - 2022-03-30 07:22:07 --> Model "Prefix_master" initialized
INFO - 2022-03-30 07:22:07 --> Model "Hospital_model" initialized
INFO - 2022-03-30 07:22:07 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 07:22:07 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-30 07:22:07 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 07:22:07 --> Final output sent to browser
DEBUG - 2022-03-30 07:22:07 --> Total execution time: 0.0309
ERROR - 2022-03-30 07:24:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 07:24:08 --> Config Class Initialized
INFO - 2022-03-30 07:24:08 --> Hooks Class Initialized
DEBUG - 2022-03-30 07:24:08 --> UTF-8 Support Enabled
INFO - 2022-03-30 07:24:08 --> Utf8 Class Initialized
INFO - 2022-03-30 07:24:08 --> URI Class Initialized
INFO - 2022-03-30 07:24:08 --> Router Class Initialized
INFO - 2022-03-30 07:24:08 --> Output Class Initialized
INFO - 2022-03-30 07:24:08 --> Security Class Initialized
DEBUG - 2022-03-30 07:24:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 07:24:08 --> Input Class Initialized
INFO - 2022-03-30 07:24:08 --> Language Class Initialized
INFO - 2022-03-30 07:24:08 --> Loader Class Initialized
INFO - 2022-03-30 07:24:08 --> Helper loaded: url_helper
INFO - 2022-03-30 07:24:08 --> Helper loaded: form_helper
INFO - 2022-03-30 07:24:08 --> Helper loaded: common_helper
INFO - 2022-03-30 07:24:08 --> Database Driver Class Initialized
DEBUG - 2022-03-30 07:24:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 07:24:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 07:24:08 --> Controller Class Initialized
INFO - 2022-03-30 07:24:08 --> Form Validation Class Initialized
DEBUG - 2022-03-30 07:24:08 --> Encrypt Class Initialized
INFO - 2022-03-30 07:24:08 --> Model "Patient_model" initialized
INFO - 2022-03-30 07:24:08 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 07:24:08 --> Model "Prefix_master" initialized
INFO - 2022-03-30 07:24:08 --> Model "Users_model" initialized
INFO - 2022-03-30 07:24:08 --> Model "Hospital_model" initialized
ERROR - 2022-03-30 07:24:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 07:24:09 --> Config Class Initialized
INFO - 2022-03-30 07:24:09 --> Hooks Class Initialized
DEBUG - 2022-03-30 07:24:09 --> UTF-8 Support Enabled
INFO - 2022-03-30 07:24:09 --> Utf8 Class Initialized
INFO - 2022-03-30 07:24:09 --> URI Class Initialized
INFO - 2022-03-30 07:24:09 --> Router Class Initialized
INFO - 2022-03-30 07:24:09 --> Output Class Initialized
INFO - 2022-03-30 07:24:09 --> Security Class Initialized
DEBUG - 2022-03-30 07:24:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 07:24:09 --> Input Class Initialized
INFO - 2022-03-30 07:24:09 --> Language Class Initialized
INFO - 2022-03-30 07:24:09 --> Loader Class Initialized
INFO - 2022-03-30 07:24:09 --> Helper loaded: url_helper
INFO - 2022-03-30 07:24:09 --> Helper loaded: form_helper
INFO - 2022-03-30 07:24:09 --> Helper loaded: common_helper
INFO - 2022-03-30 07:24:09 --> Database Driver Class Initialized
DEBUG - 2022-03-30 07:24:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 07:24:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 07:24:09 --> Controller Class Initialized
INFO - 2022-03-30 07:24:09 --> Form Validation Class Initialized
DEBUG - 2022-03-30 07:24:09 --> Encrypt Class Initialized
INFO - 2022-03-30 07:24:09 --> Model "Patient_model" initialized
INFO - 2022-03-30 07:24:09 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 07:24:09 --> Model "Prefix_master" initialized
INFO - 2022-03-30 07:24:09 --> Model "Users_model" initialized
INFO - 2022-03-30 07:24:09 --> Model "Hospital_model" initialized
INFO - 2022-03-30 07:24:09 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 07:24:09 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-30 07:24:09 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 07:24:09 --> Final output sent to browser
DEBUG - 2022-03-30 07:24:09 --> Total execution time: 0.0428
ERROR - 2022-03-30 07:24:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 07:24:59 --> Config Class Initialized
INFO - 2022-03-30 07:24:59 --> Hooks Class Initialized
DEBUG - 2022-03-30 07:24:59 --> UTF-8 Support Enabled
INFO - 2022-03-30 07:24:59 --> Utf8 Class Initialized
INFO - 2022-03-30 07:24:59 --> URI Class Initialized
INFO - 2022-03-30 07:24:59 --> Router Class Initialized
INFO - 2022-03-30 07:24:59 --> Output Class Initialized
INFO - 2022-03-30 07:24:59 --> Security Class Initialized
DEBUG - 2022-03-30 07:24:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 07:24:59 --> Input Class Initialized
INFO - 2022-03-30 07:24:59 --> Language Class Initialized
INFO - 2022-03-30 07:24:59 --> Loader Class Initialized
INFO - 2022-03-30 07:24:59 --> Helper loaded: url_helper
INFO - 2022-03-30 07:24:59 --> Helper loaded: form_helper
INFO - 2022-03-30 07:24:59 --> Helper loaded: common_helper
INFO - 2022-03-30 07:24:59 --> Database Driver Class Initialized
DEBUG - 2022-03-30 07:24:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 07:24:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 07:24:59 --> Controller Class Initialized
INFO - 2022-03-30 07:24:59 --> Form Validation Class Initialized
DEBUG - 2022-03-30 07:24:59 --> Encrypt Class Initialized
INFO - 2022-03-30 07:24:59 --> Model "Patient_model" initialized
INFO - 2022-03-30 07:24:59 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 07:24:59 --> Model "Referredby_model" initialized
INFO - 2022-03-30 07:24:59 --> Model "Prefix_master" initialized
INFO - 2022-03-30 07:24:59 --> Model "Hospital_model" initialized
ERROR - 2022-03-30 07:24:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 07:24:59 --> Config Class Initialized
INFO - 2022-03-30 07:24:59 --> Hooks Class Initialized
DEBUG - 2022-03-30 07:24:59 --> UTF-8 Support Enabled
INFO - 2022-03-30 07:24:59 --> Utf8 Class Initialized
INFO - 2022-03-30 07:24:59 --> URI Class Initialized
INFO - 2022-03-30 07:24:59 --> Router Class Initialized
INFO - 2022-03-30 07:24:59 --> Output Class Initialized
INFO - 2022-03-30 07:24:59 --> Security Class Initialized
DEBUG - 2022-03-30 07:24:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 07:24:59 --> Input Class Initialized
INFO - 2022-03-30 07:24:59 --> Language Class Initialized
INFO - 2022-03-30 07:24:59 --> Loader Class Initialized
INFO - 2022-03-30 07:24:59 --> Helper loaded: url_helper
INFO - 2022-03-30 07:24:59 --> Helper loaded: form_helper
INFO - 2022-03-30 07:24:59 --> Helper loaded: common_helper
INFO - 2022-03-30 07:24:59 --> Database Driver Class Initialized
DEBUG - 2022-03-30 07:24:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 07:24:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 07:24:59 --> Controller Class Initialized
INFO - 2022-03-30 07:24:59 --> Form Validation Class Initialized
DEBUG - 2022-03-30 07:24:59 --> Encrypt Class Initialized
INFO - 2022-03-30 07:24:59 --> Model "Patient_model" initialized
INFO - 2022-03-30 07:24:59 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 07:24:59 --> Model "Referredby_model" initialized
INFO - 2022-03-30 07:24:59 --> Model "Prefix_master" initialized
INFO - 2022-03-30 07:24:59 --> Model "Hospital_model" initialized
INFO - 2022-03-30 07:24:59 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 07:24:59 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-30 07:24:59 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 07:24:59 --> Final output sent to browser
DEBUG - 2022-03-30 07:24:59 --> Total execution time: 0.0423
ERROR - 2022-03-30 07:25:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 07:25:00 --> Config Class Initialized
INFO - 2022-03-30 07:25:00 --> Hooks Class Initialized
DEBUG - 2022-03-30 07:25:00 --> UTF-8 Support Enabled
INFO - 2022-03-30 07:25:00 --> Utf8 Class Initialized
INFO - 2022-03-30 07:25:00 --> URI Class Initialized
INFO - 2022-03-30 07:25:00 --> Router Class Initialized
INFO - 2022-03-30 07:25:00 --> Output Class Initialized
INFO - 2022-03-30 07:25:00 --> Security Class Initialized
DEBUG - 2022-03-30 07:25:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 07:25:00 --> Input Class Initialized
INFO - 2022-03-30 07:25:00 --> Language Class Initialized
INFO - 2022-03-30 07:25:00 --> Loader Class Initialized
INFO - 2022-03-30 07:25:00 --> Helper loaded: url_helper
INFO - 2022-03-30 07:25:00 --> Helper loaded: form_helper
INFO - 2022-03-30 07:25:00 --> Helper loaded: common_helper
INFO - 2022-03-30 07:25:00 --> Database Driver Class Initialized
DEBUG - 2022-03-30 07:25:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 07:25:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 07:25:00 --> Controller Class Initialized
INFO - 2022-03-30 07:25:00 --> Form Validation Class Initialized
DEBUG - 2022-03-30 07:25:00 --> Encrypt Class Initialized
INFO - 2022-03-30 07:25:00 --> Model "Patient_model" initialized
INFO - 2022-03-30 07:25:00 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 07:25:00 --> Model "Prefix_master" initialized
INFO - 2022-03-30 07:25:00 --> Model "Users_model" initialized
INFO - 2022-03-30 07:25:00 --> Model "Hospital_model" initialized
INFO - 2022-03-30 07:25:00 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 07:25:00 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-30 07:25:00 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 07:25:00 --> Final output sent to browser
DEBUG - 2022-03-30 07:25:00 --> Total execution time: 0.0447
ERROR - 2022-03-30 07:27:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 07:27:25 --> Config Class Initialized
INFO - 2022-03-30 07:27:25 --> Hooks Class Initialized
DEBUG - 2022-03-30 07:27:25 --> UTF-8 Support Enabled
INFO - 2022-03-30 07:27:25 --> Utf8 Class Initialized
INFO - 2022-03-30 07:27:25 --> URI Class Initialized
INFO - 2022-03-30 07:27:25 --> Router Class Initialized
INFO - 2022-03-30 07:27:25 --> Output Class Initialized
INFO - 2022-03-30 07:27:25 --> Security Class Initialized
DEBUG - 2022-03-30 07:27:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 07:27:25 --> Input Class Initialized
INFO - 2022-03-30 07:27:25 --> Language Class Initialized
INFO - 2022-03-30 07:27:25 --> Loader Class Initialized
INFO - 2022-03-30 07:27:25 --> Helper loaded: url_helper
INFO - 2022-03-30 07:27:25 --> Helper loaded: form_helper
INFO - 2022-03-30 07:27:25 --> Helper loaded: common_helper
INFO - 2022-03-30 07:27:25 --> Database Driver Class Initialized
DEBUG - 2022-03-30 07:27:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 07:27:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 07:27:25 --> Controller Class Initialized
INFO - 2022-03-30 07:27:25 --> Form Validation Class Initialized
DEBUG - 2022-03-30 07:27:25 --> Encrypt Class Initialized
INFO - 2022-03-30 07:27:25 --> Model "Patient_model" initialized
INFO - 2022-03-30 07:27:25 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 07:27:25 --> Model "Prefix_master" initialized
INFO - 2022-03-30 07:27:25 --> Model "Users_model" initialized
INFO - 2022-03-30 07:27:25 --> Model "Hospital_model" initialized
ERROR - 2022-03-30 07:27:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 07:27:25 --> Config Class Initialized
INFO - 2022-03-30 07:27:25 --> Hooks Class Initialized
DEBUG - 2022-03-30 07:27:25 --> UTF-8 Support Enabled
INFO - 2022-03-30 07:27:25 --> Utf8 Class Initialized
INFO - 2022-03-30 07:27:25 --> URI Class Initialized
INFO - 2022-03-30 07:27:25 --> Router Class Initialized
INFO - 2022-03-30 07:27:25 --> Output Class Initialized
INFO - 2022-03-30 07:27:25 --> Security Class Initialized
DEBUG - 2022-03-30 07:27:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 07:27:25 --> Input Class Initialized
INFO - 2022-03-30 07:27:25 --> Language Class Initialized
INFO - 2022-03-30 07:27:25 --> Loader Class Initialized
INFO - 2022-03-30 07:27:25 --> Helper loaded: url_helper
INFO - 2022-03-30 07:27:25 --> Helper loaded: form_helper
INFO - 2022-03-30 07:27:25 --> Helper loaded: common_helper
INFO - 2022-03-30 07:27:25 --> Database Driver Class Initialized
DEBUG - 2022-03-30 07:27:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 07:27:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 07:27:25 --> Controller Class Initialized
INFO - 2022-03-30 07:27:25 --> Form Validation Class Initialized
DEBUG - 2022-03-30 07:27:25 --> Encrypt Class Initialized
INFO - 2022-03-30 07:27:25 --> Model "Patient_model" initialized
INFO - 2022-03-30 07:27:25 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 07:27:25 --> Model "Prefix_master" initialized
INFO - 2022-03-30 07:27:25 --> Model "Users_model" initialized
INFO - 2022-03-30 07:27:25 --> Model "Hospital_model" initialized
INFO - 2022-03-30 07:27:25 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 07:27:25 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-30 07:27:25 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 07:27:25 --> Final output sent to browser
DEBUG - 2022-03-30 07:27:25 --> Total execution time: 0.0394
ERROR - 2022-03-30 07:28:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 07:28:19 --> Config Class Initialized
INFO - 2022-03-30 07:28:19 --> Hooks Class Initialized
DEBUG - 2022-03-30 07:28:19 --> UTF-8 Support Enabled
INFO - 2022-03-30 07:28:19 --> Utf8 Class Initialized
INFO - 2022-03-30 07:28:19 --> URI Class Initialized
INFO - 2022-03-30 07:28:19 --> Router Class Initialized
INFO - 2022-03-30 07:28:19 --> Output Class Initialized
INFO - 2022-03-30 07:28:19 --> Security Class Initialized
DEBUG - 2022-03-30 07:28:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 07:28:19 --> Input Class Initialized
INFO - 2022-03-30 07:28:19 --> Language Class Initialized
INFO - 2022-03-30 07:28:19 --> Loader Class Initialized
INFO - 2022-03-30 07:28:19 --> Helper loaded: url_helper
INFO - 2022-03-30 07:28:19 --> Helper loaded: form_helper
INFO - 2022-03-30 07:28:19 --> Helper loaded: common_helper
INFO - 2022-03-30 07:28:19 --> Database Driver Class Initialized
DEBUG - 2022-03-30 07:28:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 07:28:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 07:28:19 --> Controller Class Initialized
INFO - 2022-03-30 07:28:19 --> Form Validation Class Initialized
DEBUG - 2022-03-30 07:28:19 --> Encrypt Class Initialized
INFO - 2022-03-30 07:28:19 --> Model "Patient_model" initialized
INFO - 2022-03-30 07:28:19 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 07:28:19 --> Model "Referredby_model" initialized
INFO - 2022-03-30 07:28:19 --> Model "Prefix_master" initialized
INFO - 2022-03-30 07:28:19 --> Model "Hospital_model" initialized
INFO - 2022-03-30 07:28:19 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 07:28:26 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-30 07:28:26 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 07:28:28 --> Final output sent to browser
DEBUG - 2022-03-30 07:28:28 --> Total execution time: 6.1618
ERROR - 2022-03-30 07:30:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 07:30:08 --> Config Class Initialized
INFO - 2022-03-30 07:30:08 --> Hooks Class Initialized
DEBUG - 2022-03-30 07:30:08 --> UTF-8 Support Enabled
INFO - 2022-03-30 07:30:08 --> Utf8 Class Initialized
INFO - 2022-03-30 07:30:08 --> URI Class Initialized
INFO - 2022-03-30 07:30:08 --> Router Class Initialized
INFO - 2022-03-30 07:30:08 --> Output Class Initialized
INFO - 2022-03-30 07:30:08 --> Security Class Initialized
DEBUG - 2022-03-30 07:30:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 07:30:08 --> Input Class Initialized
INFO - 2022-03-30 07:30:08 --> Language Class Initialized
INFO - 2022-03-30 07:30:08 --> Loader Class Initialized
INFO - 2022-03-30 07:30:08 --> Helper loaded: url_helper
INFO - 2022-03-30 07:30:08 --> Helper loaded: form_helper
INFO - 2022-03-30 07:30:08 --> Helper loaded: common_helper
INFO - 2022-03-30 07:30:08 --> Database Driver Class Initialized
DEBUG - 2022-03-30 07:30:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 07:30:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 07:30:08 --> Controller Class Initialized
INFO - 2022-03-30 07:30:08 --> Form Validation Class Initialized
DEBUG - 2022-03-30 07:30:08 --> Encrypt Class Initialized
INFO - 2022-03-30 07:30:08 --> Model "Patient_model" initialized
INFO - 2022-03-30 07:30:08 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 07:30:08 --> Model "Prefix_master" initialized
INFO - 2022-03-30 07:30:08 --> Model "Users_model" initialized
INFO - 2022-03-30 07:30:08 --> Model "Hospital_model" initialized
ERROR - 2022-03-30 07:30:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 07:30:08 --> Config Class Initialized
INFO - 2022-03-30 07:30:08 --> Hooks Class Initialized
DEBUG - 2022-03-30 07:30:08 --> UTF-8 Support Enabled
INFO - 2022-03-30 07:30:08 --> Utf8 Class Initialized
INFO - 2022-03-30 07:30:08 --> URI Class Initialized
INFO - 2022-03-30 07:30:08 --> Router Class Initialized
INFO - 2022-03-30 07:30:08 --> Output Class Initialized
INFO - 2022-03-30 07:30:08 --> Security Class Initialized
DEBUG - 2022-03-30 07:30:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 07:30:08 --> Input Class Initialized
INFO - 2022-03-30 07:30:08 --> Language Class Initialized
INFO - 2022-03-30 07:30:08 --> Loader Class Initialized
INFO - 2022-03-30 07:30:08 --> Helper loaded: url_helper
INFO - 2022-03-30 07:30:08 --> Helper loaded: form_helper
INFO - 2022-03-30 07:30:08 --> Helper loaded: common_helper
INFO - 2022-03-30 07:30:08 --> Database Driver Class Initialized
DEBUG - 2022-03-30 07:30:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 07:30:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 07:30:08 --> Controller Class Initialized
INFO - 2022-03-30 07:30:08 --> Form Validation Class Initialized
DEBUG - 2022-03-30 07:30:08 --> Encrypt Class Initialized
INFO - 2022-03-30 07:30:08 --> Model "Patient_model" initialized
INFO - 2022-03-30 07:30:08 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 07:30:08 --> Model "Prefix_master" initialized
INFO - 2022-03-30 07:30:08 --> Model "Users_model" initialized
INFO - 2022-03-30 07:30:08 --> Model "Hospital_model" initialized
INFO - 2022-03-30 07:30:08 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 07:30:08 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-30 07:30:08 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 07:30:08 --> Final output sent to browser
DEBUG - 2022-03-30 07:30:08 --> Total execution time: 0.0611
ERROR - 2022-03-30 07:30:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 07:30:25 --> Config Class Initialized
INFO - 2022-03-30 07:30:25 --> Hooks Class Initialized
DEBUG - 2022-03-30 07:30:25 --> UTF-8 Support Enabled
INFO - 2022-03-30 07:30:25 --> Utf8 Class Initialized
INFO - 2022-03-30 07:30:25 --> URI Class Initialized
INFO - 2022-03-30 07:30:25 --> Router Class Initialized
INFO - 2022-03-30 07:30:25 --> Output Class Initialized
INFO - 2022-03-30 07:30:25 --> Security Class Initialized
DEBUG - 2022-03-30 07:30:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 07:30:25 --> Input Class Initialized
INFO - 2022-03-30 07:30:25 --> Language Class Initialized
INFO - 2022-03-30 07:30:25 --> Loader Class Initialized
INFO - 2022-03-30 07:30:25 --> Helper loaded: url_helper
INFO - 2022-03-30 07:30:25 --> Helper loaded: form_helper
INFO - 2022-03-30 07:30:25 --> Helper loaded: common_helper
INFO - 2022-03-30 07:30:25 --> Database Driver Class Initialized
DEBUG - 2022-03-30 07:30:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 07:30:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 07:30:25 --> Controller Class Initialized
INFO - 2022-03-30 07:30:25 --> Form Validation Class Initialized
DEBUG - 2022-03-30 07:30:25 --> Encrypt Class Initialized
INFO - 2022-03-30 07:30:25 --> Model "Patient_model" initialized
INFO - 2022-03-30 07:30:25 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 07:30:25 --> Model "Prefix_master" initialized
INFO - 2022-03-30 07:30:25 --> Model "Users_model" initialized
INFO - 2022-03-30 07:30:25 --> Model "Hospital_model" initialized
INFO - 2022-03-30 07:30:25 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 07:30:25 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-30 07:30:25 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 07:30:25 --> Final output sent to browser
DEBUG - 2022-03-30 07:30:25 --> Total execution time: 0.0624
ERROR - 2022-03-30 07:32:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 07:32:25 --> Config Class Initialized
INFO - 2022-03-30 07:32:25 --> Hooks Class Initialized
DEBUG - 2022-03-30 07:32:25 --> UTF-8 Support Enabled
INFO - 2022-03-30 07:32:25 --> Utf8 Class Initialized
INFO - 2022-03-30 07:32:25 --> URI Class Initialized
INFO - 2022-03-30 07:32:25 --> Router Class Initialized
INFO - 2022-03-30 07:32:25 --> Output Class Initialized
INFO - 2022-03-30 07:32:25 --> Security Class Initialized
DEBUG - 2022-03-30 07:32:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 07:32:25 --> Input Class Initialized
INFO - 2022-03-30 07:32:25 --> Language Class Initialized
INFO - 2022-03-30 07:32:25 --> Loader Class Initialized
INFO - 2022-03-30 07:32:25 --> Helper loaded: url_helper
INFO - 2022-03-30 07:32:25 --> Helper loaded: form_helper
INFO - 2022-03-30 07:32:25 --> Helper loaded: common_helper
INFO - 2022-03-30 07:32:25 --> Database Driver Class Initialized
DEBUG - 2022-03-30 07:32:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 07:32:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 07:32:25 --> Controller Class Initialized
INFO - 2022-03-30 07:32:25 --> Form Validation Class Initialized
DEBUG - 2022-03-30 07:32:25 --> Encrypt Class Initialized
INFO - 2022-03-30 07:32:25 --> Model "Patient_model" initialized
INFO - 2022-03-30 07:32:25 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 07:32:25 --> Model "Referredby_model" initialized
INFO - 2022-03-30 07:32:25 --> Model "Prefix_master" initialized
INFO - 2022-03-30 07:32:25 --> Model "Hospital_model" initialized
INFO - 2022-03-30 07:32:26 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 07:32:32 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-30 07:32:32 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 07:32:34 --> Final output sent to browser
DEBUG - 2022-03-30 07:32:34 --> Total execution time: 7.0365
ERROR - 2022-03-30 07:33:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 07:33:00 --> Config Class Initialized
INFO - 2022-03-30 07:33:00 --> Hooks Class Initialized
DEBUG - 2022-03-30 07:33:00 --> UTF-8 Support Enabled
INFO - 2022-03-30 07:33:00 --> Utf8 Class Initialized
INFO - 2022-03-30 07:33:00 --> URI Class Initialized
INFO - 2022-03-30 07:33:00 --> Router Class Initialized
INFO - 2022-03-30 07:33:00 --> Output Class Initialized
INFO - 2022-03-30 07:33:00 --> Security Class Initialized
DEBUG - 2022-03-30 07:33:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 07:33:00 --> Input Class Initialized
INFO - 2022-03-30 07:33:00 --> Language Class Initialized
INFO - 2022-03-30 07:33:00 --> Loader Class Initialized
INFO - 2022-03-30 07:33:00 --> Helper loaded: url_helper
INFO - 2022-03-30 07:33:00 --> Helper loaded: form_helper
INFO - 2022-03-30 07:33:00 --> Helper loaded: common_helper
INFO - 2022-03-30 07:33:00 --> Database Driver Class Initialized
DEBUG - 2022-03-30 07:33:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 07:33:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 07:33:00 --> Controller Class Initialized
INFO - 2022-03-30 07:33:00 --> Form Validation Class Initialized
DEBUG - 2022-03-30 07:33:00 --> Encrypt Class Initialized
INFO - 2022-03-30 07:33:00 --> Model "Patient_model" initialized
INFO - 2022-03-30 07:33:00 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 07:33:00 --> Model "Referredby_model" initialized
INFO - 2022-03-30 07:33:00 --> Model "Prefix_master" initialized
INFO - 2022-03-30 07:33:00 --> Model "Hospital_model" initialized
INFO - 2022-03-30 07:33:00 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 07:33:00 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-30 07:33:00 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 07:33:00 --> Final output sent to browser
DEBUG - 2022-03-30 07:33:00 --> Total execution time: 0.0297
ERROR - 2022-03-30 07:33:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 07:33:56 --> Config Class Initialized
INFO - 2022-03-30 07:33:56 --> Hooks Class Initialized
DEBUG - 2022-03-30 07:33:56 --> UTF-8 Support Enabled
INFO - 2022-03-30 07:33:56 --> Utf8 Class Initialized
INFO - 2022-03-30 07:33:56 --> URI Class Initialized
INFO - 2022-03-30 07:33:56 --> Router Class Initialized
INFO - 2022-03-30 07:33:56 --> Output Class Initialized
INFO - 2022-03-30 07:33:56 --> Security Class Initialized
DEBUG - 2022-03-30 07:33:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 07:33:56 --> Input Class Initialized
INFO - 2022-03-30 07:33:56 --> Language Class Initialized
INFO - 2022-03-30 07:33:56 --> Loader Class Initialized
INFO - 2022-03-30 07:33:56 --> Helper loaded: url_helper
INFO - 2022-03-30 07:33:56 --> Helper loaded: form_helper
INFO - 2022-03-30 07:33:56 --> Helper loaded: common_helper
INFO - 2022-03-30 07:33:56 --> Database Driver Class Initialized
DEBUG - 2022-03-30 07:33:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 07:33:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 07:33:56 --> Controller Class Initialized
INFO - 2022-03-30 07:33:56 --> Form Validation Class Initialized
DEBUG - 2022-03-30 07:33:56 --> Encrypt Class Initialized
INFO - 2022-03-30 07:33:56 --> Model "Patient_model" initialized
INFO - 2022-03-30 07:33:56 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 07:33:56 --> Model "Referredby_model" initialized
INFO - 2022-03-30 07:33:56 --> Model "Prefix_master" initialized
INFO - 2022-03-30 07:33:56 --> Model "Hospital_model" initialized
ERROR - 2022-03-30 07:33:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 07:33:56 --> Config Class Initialized
INFO - 2022-03-30 07:33:56 --> Hooks Class Initialized
DEBUG - 2022-03-30 07:33:56 --> UTF-8 Support Enabled
INFO - 2022-03-30 07:33:56 --> Utf8 Class Initialized
INFO - 2022-03-30 07:33:56 --> URI Class Initialized
INFO - 2022-03-30 07:33:56 --> Router Class Initialized
INFO - 2022-03-30 07:33:56 --> Output Class Initialized
INFO - 2022-03-30 07:33:56 --> Security Class Initialized
DEBUG - 2022-03-30 07:33:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 07:33:56 --> Input Class Initialized
INFO - 2022-03-30 07:33:56 --> Language Class Initialized
INFO - 2022-03-30 07:33:56 --> Loader Class Initialized
INFO - 2022-03-30 07:33:56 --> Helper loaded: url_helper
INFO - 2022-03-30 07:33:56 --> Helper loaded: form_helper
INFO - 2022-03-30 07:33:56 --> Helper loaded: common_helper
INFO - 2022-03-30 07:33:56 --> Database Driver Class Initialized
DEBUG - 2022-03-30 07:33:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 07:33:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 07:33:56 --> Controller Class Initialized
INFO - 2022-03-30 07:33:56 --> Form Validation Class Initialized
DEBUG - 2022-03-30 07:33:56 --> Encrypt Class Initialized
INFO - 2022-03-30 07:33:56 --> Model "Patient_model" initialized
INFO - 2022-03-30 07:33:56 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 07:33:56 --> Model "Referredby_model" initialized
INFO - 2022-03-30 07:33:56 --> Model "Prefix_master" initialized
INFO - 2022-03-30 07:33:56 --> Model "Hospital_model" initialized
INFO - 2022-03-30 07:33:56 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 07:33:56 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-30 07:33:56 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 07:33:56 --> Final output sent to browser
DEBUG - 2022-03-30 07:33:56 --> Total execution time: 0.0325
ERROR - 2022-03-30 07:33:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 07:33:57 --> Config Class Initialized
INFO - 2022-03-30 07:33:57 --> Hooks Class Initialized
DEBUG - 2022-03-30 07:33:57 --> UTF-8 Support Enabled
INFO - 2022-03-30 07:33:57 --> Utf8 Class Initialized
INFO - 2022-03-30 07:33:57 --> URI Class Initialized
INFO - 2022-03-30 07:33:57 --> Router Class Initialized
INFO - 2022-03-30 07:33:57 --> Output Class Initialized
INFO - 2022-03-30 07:33:57 --> Security Class Initialized
DEBUG - 2022-03-30 07:33:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 07:33:57 --> Input Class Initialized
INFO - 2022-03-30 07:33:57 --> Language Class Initialized
INFO - 2022-03-30 07:33:57 --> Loader Class Initialized
INFO - 2022-03-30 07:33:57 --> Helper loaded: url_helper
INFO - 2022-03-30 07:33:57 --> Helper loaded: form_helper
INFO - 2022-03-30 07:33:57 --> Helper loaded: common_helper
INFO - 2022-03-30 07:33:57 --> Database Driver Class Initialized
DEBUG - 2022-03-30 07:33:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 07:33:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 07:33:57 --> Controller Class Initialized
INFO - 2022-03-30 07:33:57 --> Form Validation Class Initialized
DEBUG - 2022-03-30 07:33:57 --> Encrypt Class Initialized
INFO - 2022-03-30 07:33:57 --> Model "Patient_model" initialized
INFO - 2022-03-30 07:33:57 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 07:33:57 --> Model "Prefix_master" initialized
INFO - 2022-03-30 07:33:57 --> Model "Users_model" initialized
INFO - 2022-03-30 07:33:57 --> Model "Hospital_model" initialized
INFO - 2022-03-30 07:33:57 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 07:33:57 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-30 07:33:57 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 07:33:57 --> Final output sent to browser
DEBUG - 2022-03-30 07:33:57 --> Total execution time: 0.0458
ERROR - 2022-03-30 07:36:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 07:36:03 --> Config Class Initialized
INFO - 2022-03-30 07:36:03 --> Hooks Class Initialized
DEBUG - 2022-03-30 07:36:03 --> UTF-8 Support Enabled
INFO - 2022-03-30 07:36:03 --> Utf8 Class Initialized
INFO - 2022-03-30 07:36:03 --> URI Class Initialized
INFO - 2022-03-30 07:36:03 --> Router Class Initialized
INFO - 2022-03-30 07:36:03 --> Output Class Initialized
INFO - 2022-03-30 07:36:03 --> Security Class Initialized
DEBUG - 2022-03-30 07:36:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 07:36:03 --> Input Class Initialized
INFO - 2022-03-30 07:36:03 --> Language Class Initialized
INFO - 2022-03-30 07:36:03 --> Loader Class Initialized
INFO - 2022-03-30 07:36:03 --> Helper loaded: url_helper
INFO - 2022-03-30 07:36:03 --> Helper loaded: form_helper
INFO - 2022-03-30 07:36:03 --> Helper loaded: common_helper
INFO - 2022-03-30 07:36:03 --> Database Driver Class Initialized
DEBUG - 2022-03-30 07:36:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 07:36:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 07:36:03 --> Controller Class Initialized
INFO - 2022-03-30 07:36:03 --> Form Validation Class Initialized
DEBUG - 2022-03-30 07:36:03 --> Encrypt Class Initialized
INFO - 2022-03-30 07:36:03 --> Model "Patient_model" initialized
INFO - 2022-03-30 07:36:03 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 07:36:03 --> Model "Prefix_master" initialized
INFO - 2022-03-30 07:36:03 --> Model "Users_model" initialized
INFO - 2022-03-30 07:36:03 --> Model "Hospital_model" initialized
ERROR - 2022-03-30 07:36:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 07:36:03 --> Config Class Initialized
INFO - 2022-03-30 07:36:03 --> Hooks Class Initialized
DEBUG - 2022-03-30 07:36:03 --> UTF-8 Support Enabled
INFO - 2022-03-30 07:36:03 --> Utf8 Class Initialized
INFO - 2022-03-30 07:36:03 --> URI Class Initialized
INFO - 2022-03-30 07:36:03 --> Router Class Initialized
INFO - 2022-03-30 07:36:03 --> Output Class Initialized
INFO - 2022-03-30 07:36:03 --> Security Class Initialized
DEBUG - 2022-03-30 07:36:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 07:36:03 --> Input Class Initialized
INFO - 2022-03-30 07:36:03 --> Language Class Initialized
INFO - 2022-03-30 07:36:03 --> Loader Class Initialized
INFO - 2022-03-30 07:36:03 --> Helper loaded: url_helper
INFO - 2022-03-30 07:36:03 --> Helper loaded: form_helper
INFO - 2022-03-30 07:36:03 --> Helper loaded: common_helper
INFO - 2022-03-30 07:36:03 --> Database Driver Class Initialized
DEBUG - 2022-03-30 07:36:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 07:36:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 07:36:03 --> Controller Class Initialized
INFO - 2022-03-30 07:36:03 --> Form Validation Class Initialized
DEBUG - 2022-03-30 07:36:03 --> Encrypt Class Initialized
INFO - 2022-03-30 07:36:03 --> Model "Patient_model" initialized
INFO - 2022-03-30 07:36:03 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 07:36:03 --> Model "Prefix_master" initialized
INFO - 2022-03-30 07:36:03 --> Model "Users_model" initialized
INFO - 2022-03-30 07:36:03 --> Model "Hospital_model" initialized
INFO - 2022-03-30 07:36:03 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 07:36:03 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-30 07:36:03 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 07:36:03 --> Final output sent to browser
DEBUG - 2022-03-30 07:36:03 --> Total execution time: 0.0624
ERROR - 2022-03-30 07:39:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 07:39:15 --> Config Class Initialized
INFO - 2022-03-30 07:39:15 --> Hooks Class Initialized
DEBUG - 2022-03-30 07:39:15 --> UTF-8 Support Enabled
INFO - 2022-03-30 07:39:15 --> Utf8 Class Initialized
INFO - 2022-03-30 07:39:15 --> URI Class Initialized
INFO - 2022-03-30 07:39:15 --> Router Class Initialized
INFO - 2022-03-30 07:39:15 --> Output Class Initialized
INFO - 2022-03-30 07:39:15 --> Security Class Initialized
DEBUG - 2022-03-30 07:39:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 07:39:15 --> Input Class Initialized
INFO - 2022-03-30 07:39:15 --> Language Class Initialized
INFO - 2022-03-30 07:39:15 --> Loader Class Initialized
INFO - 2022-03-30 07:39:15 --> Helper loaded: url_helper
INFO - 2022-03-30 07:39:15 --> Helper loaded: form_helper
INFO - 2022-03-30 07:39:15 --> Helper loaded: common_helper
INFO - 2022-03-30 07:39:15 --> Database Driver Class Initialized
DEBUG - 2022-03-30 07:39:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 07:39:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 07:39:15 --> Controller Class Initialized
INFO - 2022-03-30 07:39:15 --> Form Validation Class Initialized
DEBUG - 2022-03-30 07:39:15 --> Encrypt Class Initialized
INFO - 2022-03-30 07:39:15 --> Model "Patient_model" initialized
INFO - 2022-03-30 07:39:15 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 07:39:15 --> Model "Referredby_model" initialized
INFO - 2022-03-30 07:39:15 --> Model "Prefix_master" initialized
INFO - 2022-03-30 07:39:15 --> Model "Hospital_model" initialized
INFO - 2022-03-30 07:39:16 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 07:39:22 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-30 07:39:22 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 07:39:24 --> Final output sent to browser
DEBUG - 2022-03-30 07:39:24 --> Total execution time: 7.1361
ERROR - 2022-03-30 07:39:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 07:39:50 --> Config Class Initialized
INFO - 2022-03-30 07:39:50 --> Hooks Class Initialized
DEBUG - 2022-03-30 07:39:50 --> UTF-8 Support Enabled
INFO - 2022-03-30 07:39:50 --> Utf8 Class Initialized
INFO - 2022-03-30 07:39:50 --> URI Class Initialized
INFO - 2022-03-30 07:39:50 --> Router Class Initialized
INFO - 2022-03-30 07:39:50 --> Output Class Initialized
INFO - 2022-03-30 07:39:50 --> Security Class Initialized
DEBUG - 2022-03-30 07:39:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 07:39:50 --> Input Class Initialized
INFO - 2022-03-30 07:39:50 --> Language Class Initialized
INFO - 2022-03-30 07:39:50 --> Loader Class Initialized
INFO - 2022-03-30 07:39:50 --> Helper loaded: url_helper
INFO - 2022-03-30 07:39:50 --> Helper loaded: form_helper
INFO - 2022-03-30 07:39:50 --> Helper loaded: common_helper
INFO - 2022-03-30 07:39:50 --> Database Driver Class Initialized
DEBUG - 2022-03-30 07:39:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 07:39:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 07:39:50 --> Controller Class Initialized
INFO - 2022-03-30 07:39:50 --> Form Validation Class Initialized
DEBUG - 2022-03-30 07:39:50 --> Encrypt Class Initialized
INFO - 2022-03-30 07:39:50 --> Model "Patient_model" initialized
INFO - 2022-03-30 07:39:50 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 07:39:50 --> Model "Referredby_model" initialized
INFO - 2022-03-30 07:39:50 --> Model "Prefix_master" initialized
INFO - 2022-03-30 07:39:50 --> Model "Hospital_model" initialized
INFO - 2022-03-30 07:39:50 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 07:39:50 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-30 07:39:50 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 07:39:50 --> Final output sent to browser
DEBUG - 2022-03-30 07:39:50 --> Total execution time: 0.0442
ERROR - 2022-03-30 07:40:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 07:40:36 --> Config Class Initialized
INFO - 2022-03-30 07:40:36 --> Hooks Class Initialized
DEBUG - 2022-03-30 07:40:36 --> UTF-8 Support Enabled
INFO - 2022-03-30 07:40:36 --> Utf8 Class Initialized
INFO - 2022-03-30 07:40:36 --> URI Class Initialized
INFO - 2022-03-30 07:40:36 --> Router Class Initialized
INFO - 2022-03-30 07:40:36 --> Output Class Initialized
INFO - 2022-03-30 07:40:36 --> Security Class Initialized
DEBUG - 2022-03-30 07:40:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 07:40:36 --> Input Class Initialized
INFO - 2022-03-30 07:40:36 --> Language Class Initialized
INFO - 2022-03-30 07:40:36 --> Loader Class Initialized
INFO - 2022-03-30 07:40:36 --> Helper loaded: url_helper
INFO - 2022-03-30 07:40:36 --> Helper loaded: form_helper
INFO - 2022-03-30 07:40:36 --> Helper loaded: common_helper
INFO - 2022-03-30 07:40:36 --> Database Driver Class Initialized
DEBUG - 2022-03-30 07:40:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 07:40:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 07:40:36 --> Controller Class Initialized
INFO - 2022-03-30 07:40:36 --> Form Validation Class Initialized
DEBUG - 2022-03-30 07:40:36 --> Encrypt Class Initialized
INFO - 2022-03-30 07:40:36 --> Model "Patient_model" initialized
INFO - 2022-03-30 07:40:36 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 07:40:36 --> Model "Referredby_model" initialized
INFO - 2022-03-30 07:40:36 --> Model "Prefix_master" initialized
INFO - 2022-03-30 07:40:36 --> Model "Hospital_model" initialized
INFO - 2022-03-30 07:40:36 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 07:40:36 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-30 07:40:36 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 07:40:36 --> Final output sent to browser
DEBUG - 2022-03-30 07:40:36 --> Total execution time: 0.0581
ERROR - 2022-03-30 07:43:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 07:43:30 --> Config Class Initialized
INFO - 2022-03-30 07:43:30 --> Hooks Class Initialized
DEBUG - 2022-03-30 07:43:30 --> UTF-8 Support Enabled
INFO - 2022-03-30 07:43:30 --> Utf8 Class Initialized
INFO - 2022-03-30 07:43:30 --> URI Class Initialized
INFO - 2022-03-30 07:43:30 --> Router Class Initialized
INFO - 2022-03-30 07:43:30 --> Output Class Initialized
INFO - 2022-03-30 07:43:30 --> Security Class Initialized
DEBUG - 2022-03-30 07:43:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 07:43:30 --> Input Class Initialized
INFO - 2022-03-30 07:43:30 --> Language Class Initialized
INFO - 2022-03-30 07:43:30 --> Loader Class Initialized
INFO - 2022-03-30 07:43:30 --> Helper loaded: url_helper
INFO - 2022-03-30 07:43:30 --> Helper loaded: form_helper
INFO - 2022-03-30 07:43:30 --> Helper loaded: common_helper
INFO - 2022-03-30 07:43:30 --> Database Driver Class Initialized
DEBUG - 2022-03-30 07:43:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 07:43:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 07:43:30 --> Controller Class Initialized
INFO - 2022-03-30 07:43:30 --> Form Validation Class Initialized
DEBUG - 2022-03-30 07:43:30 --> Encrypt Class Initialized
INFO - 2022-03-30 07:43:30 --> Model "Patient_model" initialized
INFO - 2022-03-30 07:43:30 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 07:43:30 --> Model "Referredby_model" initialized
INFO - 2022-03-30 07:43:30 --> Model "Prefix_master" initialized
INFO - 2022-03-30 07:43:30 --> Model "Hospital_model" initialized
ERROR - 2022-03-30 07:43:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 07:43:30 --> Config Class Initialized
INFO - 2022-03-30 07:43:30 --> Hooks Class Initialized
DEBUG - 2022-03-30 07:43:30 --> UTF-8 Support Enabled
INFO - 2022-03-30 07:43:30 --> Utf8 Class Initialized
INFO - 2022-03-30 07:43:30 --> URI Class Initialized
INFO - 2022-03-30 07:43:30 --> Router Class Initialized
INFO - 2022-03-30 07:43:30 --> Output Class Initialized
INFO - 2022-03-30 07:43:30 --> Security Class Initialized
DEBUG - 2022-03-30 07:43:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 07:43:30 --> Input Class Initialized
INFO - 2022-03-30 07:43:30 --> Language Class Initialized
INFO - 2022-03-30 07:43:30 --> Loader Class Initialized
INFO - 2022-03-30 07:43:30 --> Helper loaded: url_helper
INFO - 2022-03-30 07:43:30 --> Helper loaded: form_helper
INFO - 2022-03-30 07:43:30 --> Helper loaded: common_helper
INFO - 2022-03-30 07:43:30 --> Database Driver Class Initialized
DEBUG - 2022-03-30 07:43:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 07:43:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 07:43:30 --> Controller Class Initialized
INFO - 2022-03-30 07:43:30 --> Form Validation Class Initialized
DEBUG - 2022-03-30 07:43:30 --> Encrypt Class Initialized
INFO - 2022-03-30 07:43:30 --> Model "Patient_model" initialized
INFO - 2022-03-30 07:43:30 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 07:43:30 --> Model "Referredby_model" initialized
INFO - 2022-03-30 07:43:30 --> Model "Prefix_master" initialized
INFO - 2022-03-30 07:43:30 --> Model "Hospital_model" initialized
INFO - 2022-03-30 07:43:30 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 07:43:30 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-30 07:43:30 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 07:43:30 --> Final output sent to browser
DEBUG - 2022-03-30 07:43:30 --> Total execution time: 0.0334
ERROR - 2022-03-30 07:43:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 07:43:31 --> Config Class Initialized
INFO - 2022-03-30 07:43:31 --> Hooks Class Initialized
DEBUG - 2022-03-30 07:43:31 --> UTF-8 Support Enabled
INFO - 2022-03-30 07:43:31 --> Utf8 Class Initialized
INFO - 2022-03-30 07:43:31 --> URI Class Initialized
INFO - 2022-03-30 07:43:31 --> Router Class Initialized
INFO - 2022-03-30 07:43:31 --> Output Class Initialized
INFO - 2022-03-30 07:43:31 --> Security Class Initialized
DEBUG - 2022-03-30 07:43:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 07:43:31 --> Input Class Initialized
INFO - 2022-03-30 07:43:31 --> Language Class Initialized
INFO - 2022-03-30 07:43:31 --> Loader Class Initialized
INFO - 2022-03-30 07:43:31 --> Helper loaded: url_helper
INFO - 2022-03-30 07:43:31 --> Helper loaded: form_helper
INFO - 2022-03-30 07:43:31 --> Helper loaded: common_helper
INFO - 2022-03-30 07:43:31 --> Database Driver Class Initialized
DEBUG - 2022-03-30 07:43:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 07:43:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 07:43:31 --> Controller Class Initialized
INFO - 2022-03-30 07:43:31 --> Form Validation Class Initialized
DEBUG - 2022-03-30 07:43:31 --> Encrypt Class Initialized
INFO - 2022-03-30 07:43:31 --> Model "Patient_model" initialized
INFO - 2022-03-30 07:43:31 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 07:43:31 --> Model "Prefix_master" initialized
INFO - 2022-03-30 07:43:31 --> Model "Users_model" initialized
INFO - 2022-03-30 07:43:31 --> Model "Hospital_model" initialized
INFO - 2022-03-30 07:43:31 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 07:43:31 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-30 07:43:31 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 07:43:31 --> Final output sent to browser
DEBUG - 2022-03-30 07:43:31 --> Total execution time: 0.0628
ERROR - 2022-03-30 07:45:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 07:45:47 --> Config Class Initialized
INFO - 2022-03-30 07:45:47 --> Hooks Class Initialized
DEBUG - 2022-03-30 07:45:47 --> UTF-8 Support Enabled
INFO - 2022-03-30 07:45:47 --> Utf8 Class Initialized
INFO - 2022-03-30 07:45:47 --> URI Class Initialized
INFO - 2022-03-30 07:45:47 --> Router Class Initialized
INFO - 2022-03-30 07:45:47 --> Output Class Initialized
INFO - 2022-03-30 07:45:47 --> Security Class Initialized
DEBUG - 2022-03-30 07:45:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 07:45:47 --> Input Class Initialized
INFO - 2022-03-30 07:45:47 --> Language Class Initialized
INFO - 2022-03-30 07:45:47 --> Loader Class Initialized
INFO - 2022-03-30 07:45:47 --> Helper loaded: url_helper
INFO - 2022-03-30 07:45:47 --> Helper loaded: form_helper
INFO - 2022-03-30 07:45:47 --> Helper loaded: common_helper
INFO - 2022-03-30 07:45:47 --> Database Driver Class Initialized
DEBUG - 2022-03-30 07:45:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 07:45:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 07:45:47 --> Controller Class Initialized
INFO - 2022-03-30 07:45:47 --> Form Validation Class Initialized
DEBUG - 2022-03-30 07:45:47 --> Encrypt Class Initialized
INFO - 2022-03-30 07:45:47 --> Model "Patient_model" initialized
INFO - 2022-03-30 07:45:47 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 07:45:47 --> Model "Referredby_model" initialized
INFO - 2022-03-30 07:45:47 --> Model "Prefix_master" initialized
INFO - 2022-03-30 07:45:47 --> Model "Hospital_model" initialized
INFO - 2022-03-30 07:45:47 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 07:45:54 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-30 07:45:54 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 07:45:56 --> Final output sent to browser
DEBUG - 2022-03-30 07:45:56 --> Total execution time: 7.0401
ERROR - 2022-03-30 07:46:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 07:46:19 --> Config Class Initialized
INFO - 2022-03-30 07:46:19 --> Hooks Class Initialized
DEBUG - 2022-03-30 07:46:19 --> UTF-8 Support Enabled
INFO - 2022-03-30 07:46:19 --> Utf8 Class Initialized
INFO - 2022-03-30 07:46:19 --> URI Class Initialized
INFO - 2022-03-30 07:46:19 --> Router Class Initialized
INFO - 2022-03-30 07:46:19 --> Output Class Initialized
INFO - 2022-03-30 07:46:19 --> Security Class Initialized
DEBUG - 2022-03-30 07:46:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 07:46:19 --> Input Class Initialized
INFO - 2022-03-30 07:46:19 --> Language Class Initialized
INFO - 2022-03-30 07:46:19 --> Loader Class Initialized
INFO - 2022-03-30 07:46:19 --> Helper loaded: url_helper
INFO - 2022-03-30 07:46:19 --> Helper loaded: form_helper
INFO - 2022-03-30 07:46:19 --> Helper loaded: common_helper
INFO - 2022-03-30 07:46:19 --> Database Driver Class Initialized
DEBUG - 2022-03-30 07:46:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 07:46:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 07:46:19 --> Controller Class Initialized
INFO - 2022-03-30 07:46:19 --> Form Validation Class Initialized
DEBUG - 2022-03-30 07:46:19 --> Encrypt Class Initialized
INFO - 2022-03-30 07:46:19 --> Model "Patient_model" initialized
INFO - 2022-03-30 07:46:19 --> Model "Patientcase_model" initialized
INFO - 2022-03-30 07:46:19 --> Model "Prefix_master" initialized
INFO - 2022-03-30 07:46:19 --> Model "Users_model" initialized
INFO - 2022-03-30 07:46:19 --> Model "Hospital_model" initialized
INFO - 2022-03-30 07:46:19 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-30 07:46:20 --> Final output sent to browser
DEBUG - 2022-03-30 07:46:20 --> Total execution time: 1.0231
ERROR - 2022-03-30 12:03:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 12:03:58 --> Config Class Initialized
INFO - 2022-03-30 12:03:58 --> Hooks Class Initialized
DEBUG - 2022-03-30 12:03:58 --> UTF-8 Support Enabled
INFO - 2022-03-30 12:03:58 --> Utf8 Class Initialized
INFO - 2022-03-30 12:03:58 --> URI Class Initialized
DEBUG - 2022-03-30 12:03:58 --> No URI present. Default controller set.
INFO - 2022-03-30 12:03:58 --> Router Class Initialized
INFO - 2022-03-30 12:03:58 --> Output Class Initialized
INFO - 2022-03-30 12:03:58 --> Security Class Initialized
DEBUG - 2022-03-30 12:03:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 12:03:58 --> Input Class Initialized
INFO - 2022-03-30 12:03:58 --> Language Class Initialized
INFO - 2022-03-30 12:03:58 --> Loader Class Initialized
INFO - 2022-03-30 12:03:58 --> Helper loaded: url_helper
INFO - 2022-03-30 12:03:58 --> Helper loaded: form_helper
INFO - 2022-03-30 12:03:58 --> Helper loaded: common_helper
INFO - 2022-03-30 12:03:58 --> Database Driver Class Initialized
DEBUG - 2022-03-30 12:03:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 12:03:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 12:03:58 --> Controller Class Initialized
INFO - 2022-03-30 12:03:58 --> Form Validation Class Initialized
DEBUG - 2022-03-30 12:03:58 --> Encrypt Class Initialized
DEBUG - 2022-03-30 12:03:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-30 12:03:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-30 12:03:58 --> Email Class Initialized
INFO - 2022-03-30 12:03:58 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-30 12:03:58 --> Calendar Class Initialized
INFO - 2022-03-30 12:03:58 --> Model "Login_model" initialized
INFO - 2022-03-30 12:03:58 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-30 12:03:58 --> Final output sent to browser
DEBUG - 2022-03-30 12:03:58 --> Total execution time: 0.0906
ERROR - 2022-03-30 12:46:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 12:46:34 --> Config Class Initialized
INFO - 2022-03-30 12:46:34 --> Hooks Class Initialized
DEBUG - 2022-03-30 12:46:34 --> UTF-8 Support Enabled
INFO - 2022-03-30 12:46:34 --> Utf8 Class Initialized
INFO - 2022-03-30 12:46:34 --> URI Class Initialized
DEBUG - 2022-03-30 12:46:34 --> No URI present. Default controller set.
INFO - 2022-03-30 12:46:34 --> Router Class Initialized
INFO - 2022-03-30 12:46:34 --> Output Class Initialized
INFO - 2022-03-30 12:46:34 --> Security Class Initialized
DEBUG - 2022-03-30 12:46:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 12:46:34 --> Input Class Initialized
INFO - 2022-03-30 12:46:34 --> Language Class Initialized
INFO - 2022-03-30 12:46:34 --> Loader Class Initialized
INFO - 2022-03-30 12:46:34 --> Helper loaded: url_helper
INFO - 2022-03-30 12:46:34 --> Helper loaded: form_helper
INFO - 2022-03-30 12:46:34 --> Helper loaded: common_helper
INFO - 2022-03-30 12:46:34 --> Database Driver Class Initialized
DEBUG - 2022-03-30 12:46:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 12:46:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 12:46:34 --> Controller Class Initialized
INFO - 2022-03-30 12:46:34 --> Form Validation Class Initialized
DEBUG - 2022-03-30 12:46:34 --> Encrypt Class Initialized
DEBUG - 2022-03-30 12:46:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-30 12:46:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-30 12:46:34 --> Email Class Initialized
INFO - 2022-03-30 12:46:34 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-30 12:46:34 --> Calendar Class Initialized
INFO - 2022-03-30 12:46:34 --> Model "Login_model" initialized
INFO - 2022-03-30 12:46:34 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-30 12:46:34 --> Final output sent to browser
DEBUG - 2022-03-30 12:46:34 --> Total execution time: 0.0654
ERROR - 2022-03-30 12:46:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 12:46:34 --> Config Class Initialized
INFO - 2022-03-30 12:46:34 --> Hooks Class Initialized
DEBUG - 2022-03-30 12:46:34 --> UTF-8 Support Enabled
INFO - 2022-03-30 12:46:34 --> Utf8 Class Initialized
INFO - 2022-03-30 12:46:34 --> URI Class Initialized
DEBUG - 2022-03-30 12:46:34 --> No URI present. Default controller set.
INFO - 2022-03-30 12:46:34 --> Router Class Initialized
INFO - 2022-03-30 12:46:34 --> Output Class Initialized
INFO - 2022-03-30 12:46:34 --> Security Class Initialized
DEBUG - 2022-03-30 12:46:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 12:46:34 --> Input Class Initialized
INFO - 2022-03-30 12:46:34 --> Language Class Initialized
INFO - 2022-03-30 12:46:34 --> Loader Class Initialized
INFO - 2022-03-30 12:46:34 --> Helper loaded: url_helper
INFO - 2022-03-30 12:46:34 --> Helper loaded: form_helper
INFO - 2022-03-30 12:46:34 --> Helper loaded: common_helper
INFO - 2022-03-30 12:46:34 --> Database Driver Class Initialized
DEBUG - 2022-03-30 12:46:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 12:46:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 12:46:34 --> Controller Class Initialized
INFO - 2022-03-30 12:46:34 --> Form Validation Class Initialized
DEBUG - 2022-03-30 12:46:34 --> Encrypt Class Initialized
DEBUG - 2022-03-30 12:46:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-30 12:46:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-30 12:46:34 --> Email Class Initialized
INFO - 2022-03-30 12:46:34 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-30 12:46:34 --> Calendar Class Initialized
INFO - 2022-03-30 12:46:34 --> Model "Login_model" initialized
INFO - 2022-03-30 12:46:34 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-30 12:46:34 --> Final output sent to browser
DEBUG - 2022-03-30 12:46:34 --> Total execution time: 0.0061
ERROR - 2022-03-30 13:41:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 13:41:52 --> Config Class Initialized
INFO - 2022-03-30 13:41:52 --> Hooks Class Initialized
DEBUG - 2022-03-30 13:41:52 --> UTF-8 Support Enabled
INFO - 2022-03-30 13:41:52 --> Utf8 Class Initialized
INFO - 2022-03-30 13:41:52 --> URI Class Initialized
INFO - 2022-03-30 13:41:52 --> Router Class Initialized
INFO - 2022-03-30 13:41:52 --> Output Class Initialized
INFO - 2022-03-30 13:41:52 --> Security Class Initialized
DEBUG - 2022-03-30 13:41:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 13:41:52 --> Input Class Initialized
INFO - 2022-03-30 13:41:52 --> Language Class Initialized
ERROR - 2022-03-30 13:41:52 --> 404 Page Not Found: Wordpress/license.txt
ERROR - 2022-03-30 14:19:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 14:19:35 --> Config Class Initialized
INFO - 2022-03-30 14:19:35 --> Hooks Class Initialized
DEBUG - 2022-03-30 14:19:35 --> UTF-8 Support Enabled
INFO - 2022-03-30 14:19:35 --> Utf8 Class Initialized
INFO - 2022-03-30 14:19:35 --> URI Class Initialized
DEBUG - 2022-03-30 14:19:35 --> No URI present. Default controller set.
INFO - 2022-03-30 14:19:35 --> Router Class Initialized
INFO - 2022-03-30 14:19:35 --> Output Class Initialized
INFO - 2022-03-30 14:19:35 --> Security Class Initialized
DEBUG - 2022-03-30 14:19:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 14:19:35 --> Input Class Initialized
INFO - 2022-03-30 14:19:35 --> Language Class Initialized
INFO - 2022-03-30 14:19:35 --> Loader Class Initialized
INFO - 2022-03-30 14:19:35 --> Helper loaded: url_helper
INFO - 2022-03-30 14:19:35 --> Helper loaded: form_helper
INFO - 2022-03-30 14:19:35 --> Helper loaded: common_helper
INFO - 2022-03-30 14:19:35 --> Database Driver Class Initialized
DEBUG - 2022-03-30 14:19:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 14:19:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 14:19:35 --> Controller Class Initialized
INFO - 2022-03-30 14:19:35 --> Form Validation Class Initialized
DEBUG - 2022-03-30 14:19:35 --> Encrypt Class Initialized
DEBUG - 2022-03-30 14:19:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-30 14:19:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-30 14:19:35 --> Email Class Initialized
INFO - 2022-03-30 14:19:35 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-30 14:19:35 --> Calendar Class Initialized
INFO - 2022-03-30 14:19:35 --> Model "Login_model" initialized
INFO - 2022-03-30 14:19:35 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-30 14:19:35 --> Final output sent to browser
DEBUG - 2022-03-30 14:19:35 --> Total execution time: 0.0699
ERROR - 2022-03-30 14:19:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 14:19:37 --> Config Class Initialized
INFO - 2022-03-30 14:19:37 --> Hooks Class Initialized
DEBUG - 2022-03-30 14:19:37 --> UTF-8 Support Enabled
INFO - 2022-03-30 14:19:37 --> Utf8 Class Initialized
INFO - 2022-03-30 14:19:37 --> URI Class Initialized
INFO - 2022-03-30 14:19:37 --> Router Class Initialized
INFO - 2022-03-30 14:19:37 --> Output Class Initialized
INFO - 2022-03-30 14:19:37 --> Security Class Initialized
DEBUG - 2022-03-30 14:19:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 14:19:37 --> Input Class Initialized
INFO - 2022-03-30 14:19:37 --> Language Class Initialized
ERROR - 2022-03-30 14:19:37 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2022-03-30 14:20:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 14:20:03 --> Config Class Initialized
INFO - 2022-03-30 14:20:03 --> Hooks Class Initialized
DEBUG - 2022-03-30 14:20:03 --> UTF-8 Support Enabled
INFO - 2022-03-30 14:20:03 --> Utf8 Class Initialized
INFO - 2022-03-30 14:20:03 --> URI Class Initialized
DEBUG - 2022-03-30 14:20:03 --> No URI present. Default controller set.
INFO - 2022-03-30 14:20:03 --> Router Class Initialized
INFO - 2022-03-30 14:20:03 --> Output Class Initialized
INFO - 2022-03-30 14:20:03 --> Security Class Initialized
DEBUG - 2022-03-30 14:20:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 14:20:03 --> Input Class Initialized
INFO - 2022-03-30 14:20:03 --> Language Class Initialized
INFO - 2022-03-30 14:20:03 --> Loader Class Initialized
INFO - 2022-03-30 14:20:03 --> Helper loaded: url_helper
INFO - 2022-03-30 14:20:03 --> Helper loaded: form_helper
INFO - 2022-03-30 14:20:03 --> Helper loaded: common_helper
INFO - 2022-03-30 14:20:03 --> Database Driver Class Initialized
DEBUG - 2022-03-30 14:20:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 14:20:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 14:20:03 --> Controller Class Initialized
INFO - 2022-03-30 14:20:03 --> Form Validation Class Initialized
DEBUG - 2022-03-30 14:20:03 --> Encrypt Class Initialized
DEBUG - 2022-03-30 14:20:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-30 14:20:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-30 14:20:03 --> Email Class Initialized
INFO - 2022-03-30 14:20:03 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-30 14:20:03 --> Calendar Class Initialized
INFO - 2022-03-30 14:20:03 --> Model "Login_model" initialized
INFO - 2022-03-30 14:20:03 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-30 14:20:03 --> Final output sent to browser
DEBUG - 2022-03-30 14:20:03 --> Total execution time: 0.0088
ERROR - 2022-03-30 14:20:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 14:20:03 --> Config Class Initialized
INFO - 2022-03-30 14:20:03 --> Hooks Class Initialized
DEBUG - 2022-03-30 14:20:03 --> UTF-8 Support Enabled
INFO - 2022-03-30 14:20:03 --> Utf8 Class Initialized
INFO - 2022-03-30 14:20:03 --> URI Class Initialized
INFO - 2022-03-30 14:20:03 --> Router Class Initialized
INFO - 2022-03-30 14:20:03 --> Output Class Initialized
INFO - 2022-03-30 14:20:03 --> Security Class Initialized
DEBUG - 2022-03-30 14:20:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 14:20:03 --> Input Class Initialized
INFO - 2022-03-30 14:20:03 --> Language Class Initialized
INFO - 2022-03-30 14:20:03 --> Loader Class Initialized
INFO - 2022-03-30 14:20:03 --> Helper loaded: url_helper
INFO - 2022-03-30 14:20:03 --> Helper loaded: form_helper
INFO - 2022-03-30 14:20:03 --> Helper loaded: common_helper
INFO - 2022-03-30 14:20:03 --> Database Driver Class Initialized
DEBUG - 2022-03-30 14:20:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 14:20:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 14:20:03 --> Controller Class Initialized
INFO - 2022-03-30 14:20:03 --> Form Validation Class Initialized
DEBUG - 2022-03-30 14:20:03 --> Encrypt Class Initialized
DEBUG - 2022-03-30 14:20:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-30 14:20:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-30 14:20:03 --> Email Class Initialized
INFO - 2022-03-30 14:20:03 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-30 14:20:03 --> Calendar Class Initialized
INFO - 2022-03-30 14:20:03 --> Model "Login_model" initialized
INFO - 2022-03-30 14:20:03 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-30 14:20:03 --> Final output sent to browser
DEBUG - 2022-03-30 14:20:03 --> Total execution time: 0.0089
ERROR - 2022-03-30 14:20:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 14:20:03 --> Config Class Initialized
INFO - 2022-03-30 14:20:03 --> Hooks Class Initialized
DEBUG - 2022-03-30 14:20:03 --> UTF-8 Support Enabled
INFO - 2022-03-30 14:20:03 --> Utf8 Class Initialized
INFO - 2022-03-30 14:20:03 --> URI Class Initialized
INFO - 2022-03-30 14:20:03 --> Router Class Initialized
INFO - 2022-03-30 14:20:03 --> Output Class Initialized
INFO - 2022-03-30 14:20:03 --> Security Class Initialized
DEBUG - 2022-03-30 14:20:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 14:20:03 --> Input Class Initialized
INFO - 2022-03-30 14:20:03 --> Language Class Initialized
INFO - 2022-03-30 14:20:03 --> Loader Class Initialized
INFO - 2022-03-30 14:20:03 --> Helper loaded: url_helper
INFO - 2022-03-30 14:20:03 --> Helper loaded: form_helper
INFO - 2022-03-30 14:20:03 --> Helper loaded: common_helper
INFO - 2022-03-30 14:20:03 --> Database Driver Class Initialized
DEBUG - 2022-03-30 14:20:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 14:20:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 14:20:03 --> Controller Class Initialized
INFO - 2022-03-30 14:20:03 --> Form Validation Class Initialized
DEBUG - 2022-03-30 14:20:03 --> Encrypt Class Initialized
DEBUG - 2022-03-30 14:20:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-30 14:20:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-30 14:20:03 --> Email Class Initialized
INFO - 2022-03-30 14:20:03 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-30 14:20:03 --> Calendar Class Initialized
INFO - 2022-03-30 14:20:03 --> Model "Login_model" initialized
ERROR - 2022-03-30 14:20:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 14:20:03 --> Config Class Initialized
INFO - 2022-03-30 14:20:03 --> Hooks Class Initialized
DEBUG - 2022-03-30 14:20:03 --> UTF-8 Support Enabled
INFO - 2022-03-30 14:20:03 --> Utf8 Class Initialized
INFO - 2022-03-30 14:20:03 --> URI Class Initialized
INFO - 2022-03-30 14:20:03 --> Router Class Initialized
INFO - 2022-03-30 14:20:03 --> Output Class Initialized
INFO - 2022-03-30 14:20:03 --> Security Class Initialized
DEBUG - 2022-03-30 14:20:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 14:20:03 --> Input Class Initialized
INFO - 2022-03-30 14:20:03 --> Language Class Initialized
INFO - 2022-03-30 14:20:03 --> Loader Class Initialized
INFO - 2022-03-30 14:20:03 --> Helper loaded: url_helper
INFO - 2022-03-30 14:20:03 --> Helper loaded: form_helper
INFO - 2022-03-30 14:20:03 --> Helper loaded: common_helper
INFO - 2022-03-30 14:20:03 --> Database Driver Class Initialized
DEBUG - 2022-03-30 14:20:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 14:20:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 14:20:03 --> Controller Class Initialized
INFO - 2022-03-30 14:20:03 --> Form Validation Class Initialized
DEBUG - 2022-03-30 14:20:03 --> Encrypt Class Initialized
DEBUG - 2022-03-30 14:20:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-30 14:20:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-30 14:20:03 --> Email Class Initialized
INFO - 2022-03-30 14:20:03 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-30 14:20:03 --> Calendar Class Initialized
INFO - 2022-03-30 14:20:03 --> Model "Login_model" initialized
ERROR - 2022-03-30 23:04:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 23:04:52 --> Config Class Initialized
INFO - 2022-03-30 23:04:52 --> Hooks Class Initialized
DEBUG - 2022-03-30 23:04:52 --> UTF-8 Support Enabled
INFO - 2022-03-30 23:04:52 --> Utf8 Class Initialized
INFO - 2022-03-30 23:04:52 --> URI Class Initialized
DEBUG - 2022-03-30 23:04:52 --> No URI present. Default controller set.
INFO - 2022-03-30 23:04:52 --> Router Class Initialized
INFO - 2022-03-30 23:04:52 --> Output Class Initialized
INFO - 2022-03-30 23:04:52 --> Security Class Initialized
DEBUG - 2022-03-30 23:04:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 23:04:52 --> Input Class Initialized
INFO - 2022-03-30 23:04:52 --> Language Class Initialized
INFO - 2022-03-30 23:04:52 --> Loader Class Initialized
INFO - 2022-03-30 23:04:52 --> Helper loaded: url_helper
INFO - 2022-03-30 23:04:52 --> Helper loaded: form_helper
INFO - 2022-03-30 23:04:52 --> Helper loaded: common_helper
INFO - 2022-03-30 23:04:52 --> Database Driver Class Initialized
DEBUG - 2022-03-30 23:04:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 23:04:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 23:04:52 --> Controller Class Initialized
INFO - 2022-03-30 23:04:52 --> Form Validation Class Initialized
DEBUG - 2022-03-30 23:04:52 --> Encrypt Class Initialized
DEBUG - 2022-03-30 23:04:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-30 23:04:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-30 23:04:52 --> Email Class Initialized
INFO - 2022-03-30 23:04:52 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-30 23:04:52 --> Calendar Class Initialized
INFO - 2022-03-30 23:04:52 --> Model "Login_model" initialized
INFO - 2022-03-30 23:04:52 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-30 23:04:52 --> Final output sent to browser
DEBUG - 2022-03-30 23:04:52 --> Total execution time: 0.0688
ERROR - 2022-03-30 23:09:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 23:09:20 --> Config Class Initialized
INFO - 2022-03-30 23:09:20 --> Hooks Class Initialized
DEBUG - 2022-03-30 23:09:20 --> UTF-8 Support Enabled
INFO - 2022-03-30 23:09:20 --> Utf8 Class Initialized
INFO - 2022-03-30 23:09:20 --> URI Class Initialized
DEBUG - 2022-03-30 23:09:20 --> No URI present. Default controller set.
INFO - 2022-03-30 23:09:20 --> Router Class Initialized
INFO - 2022-03-30 23:09:20 --> Output Class Initialized
INFO - 2022-03-30 23:09:20 --> Security Class Initialized
DEBUG - 2022-03-30 23:09:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 23:09:20 --> Input Class Initialized
INFO - 2022-03-30 23:09:20 --> Language Class Initialized
INFO - 2022-03-30 23:09:20 --> Loader Class Initialized
INFO - 2022-03-30 23:09:20 --> Helper loaded: url_helper
INFO - 2022-03-30 23:09:20 --> Helper loaded: form_helper
INFO - 2022-03-30 23:09:20 --> Helper loaded: common_helper
INFO - 2022-03-30 23:09:20 --> Database Driver Class Initialized
DEBUG - 2022-03-30 23:09:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 23:09:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 23:09:20 --> Controller Class Initialized
INFO - 2022-03-30 23:09:20 --> Form Validation Class Initialized
DEBUG - 2022-03-30 23:09:20 --> Encrypt Class Initialized
DEBUG - 2022-03-30 23:09:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-30 23:09:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-30 23:09:20 --> Email Class Initialized
INFO - 2022-03-30 23:09:20 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-30 23:09:20 --> Calendar Class Initialized
INFO - 2022-03-30 23:09:20 --> Model "Login_model" initialized
INFO - 2022-03-30 23:09:20 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-30 23:09:20 --> Final output sent to browser
DEBUG - 2022-03-30 23:09:20 --> Total execution time: 0.0539
ERROR - 2022-03-30 23:10:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 23:10:15 --> Config Class Initialized
INFO - 2022-03-30 23:10:15 --> Hooks Class Initialized
DEBUG - 2022-03-30 23:10:15 --> UTF-8 Support Enabled
INFO - 2022-03-30 23:10:15 --> Utf8 Class Initialized
INFO - 2022-03-30 23:10:15 --> URI Class Initialized
DEBUG - 2022-03-30 23:10:15 --> No URI present. Default controller set.
INFO - 2022-03-30 23:10:15 --> Router Class Initialized
INFO - 2022-03-30 23:10:15 --> Output Class Initialized
INFO - 2022-03-30 23:10:15 --> Security Class Initialized
DEBUG - 2022-03-30 23:10:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 23:10:15 --> Input Class Initialized
INFO - 2022-03-30 23:10:15 --> Language Class Initialized
INFO - 2022-03-30 23:10:15 --> Loader Class Initialized
INFO - 2022-03-30 23:10:15 --> Helper loaded: url_helper
INFO - 2022-03-30 23:10:15 --> Helper loaded: form_helper
INFO - 2022-03-30 23:10:15 --> Helper loaded: common_helper
INFO - 2022-03-30 23:10:15 --> Database Driver Class Initialized
DEBUG - 2022-03-30 23:10:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 23:10:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 23:10:15 --> Controller Class Initialized
INFO - 2022-03-30 23:10:15 --> Form Validation Class Initialized
DEBUG - 2022-03-30 23:10:15 --> Encrypt Class Initialized
DEBUG - 2022-03-30 23:10:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-30 23:10:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-30 23:10:15 --> Email Class Initialized
INFO - 2022-03-30 23:10:15 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-30 23:10:15 --> Calendar Class Initialized
INFO - 2022-03-30 23:10:15 --> Model "Login_model" initialized
INFO - 2022-03-30 23:10:15 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-30 23:10:15 --> Final output sent to browser
DEBUG - 2022-03-30 23:10:15 --> Total execution time: 0.0071
ERROR - 2022-03-30 23:10:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 23:10:17 --> Config Class Initialized
INFO - 2022-03-30 23:10:17 --> Hooks Class Initialized
DEBUG - 2022-03-30 23:10:17 --> UTF-8 Support Enabled
INFO - 2022-03-30 23:10:17 --> Utf8 Class Initialized
INFO - 2022-03-30 23:10:17 --> URI Class Initialized
DEBUG - 2022-03-30 23:10:17 --> No URI present. Default controller set.
INFO - 2022-03-30 23:10:17 --> Router Class Initialized
INFO - 2022-03-30 23:10:17 --> Output Class Initialized
INFO - 2022-03-30 23:10:17 --> Security Class Initialized
DEBUG - 2022-03-30 23:10:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 23:10:17 --> Input Class Initialized
INFO - 2022-03-30 23:10:17 --> Language Class Initialized
INFO - 2022-03-30 23:10:17 --> Loader Class Initialized
INFO - 2022-03-30 23:10:17 --> Helper loaded: url_helper
INFO - 2022-03-30 23:10:17 --> Helper loaded: form_helper
INFO - 2022-03-30 23:10:17 --> Helper loaded: common_helper
INFO - 2022-03-30 23:10:17 --> Database Driver Class Initialized
DEBUG - 2022-03-30 23:10:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 23:10:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 23:10:17 --> Controller Class Initialized
INFO - 2022-03-30 23:10:17 --> Form Validation Class Initialized
DEBUG - 2022-03-30 23:10:17 --> Encrypt Class Initialized
DEBUG - 2022-03-30 23:10:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-30 23:10:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-30 23:10:17 --> Email Class Initialized
INFO - 2022-03-30 23:10:17 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-30 23:10:17 --> Calendar Class Initialized
INFO - 2022-03-30 23:10:17 --> Model "Login_model" initialized
INFO - 2022-03-30 23:10:17 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-30 23:10:17 --> Final output sent to browser
DEBUG - 2022-03-30 23:10:17 --> Total execution time: 0.0056
ERROR - 2022-03-30 23:11:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 23:11:23 --> Config Class Initialized
INFO - 2022-03-30 23:11:23 --> Hooks Class Initialized
DEBUG - 2022-03-30 23:11:23 --> UTF-8 Support Enabled
INFO - 2022-03-30 23:11:23 --> Utf8 Class Initialized
INFO - 2022-03-30 23:11:23 --> URI Class Initialized
INFO - 2022-03-30 23:11:23 --> Router Class Initialized
INFO - 2022-03-30 23:11:23 --> Output Class Initialized
INFO - 2022-03-30 23:11:23 --> Security Class Initialized
DEBUG - 2022-03-30 23:11:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 23:11:23 --> Input Class Initialized
INFO - 2022-03-30 23:11:23 --> Language Class Initialized
INFO - 2022-03-30 23:11:23 --> Loader Class Initialized
INFO - 2022-03-30 23:11:23 --> Helper loaded: url_helper
INFO - 2022-03-30 23:11:23 --> Helper loaded: form_helper
INFO - 2022-03-30 23:11:23 --> Helper loaded: common_helper
INFO - 2022-03-30 23:11:23 --> Database Driver Class Initialized
DEBUG - 2022-03-30 23:11:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 23:11:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 23:11:23 --> Controller Class Initialized
INFO - 2022-03-30 23:11:23 --> Form Validation Class Initialized
DEBUG - 2022-03-30 23:11:23 --> Encrypt Class Initialized
DEBUG - 2022-03-30 23:11:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-30 23:11:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-30 23:11:23 --> Email Class Initialized
INFO - 2022-03-30 23:11:23 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-30 23:11:23 --> Calendar Class Initialized
INFO - 2022-03-30 23:11:23 --> Model "Login_model" initialized
INFO - 2022-03-30 23:11:23 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-03-30 23:11:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-30 23:11:23 --> Config Class Initialized
INFO - 2022-03-30 23:11:23 --> Hooks Class Initialized
DEBUG - 2022-03-30 23:11:23 --> UTF-8 Support Enabled
INFO - 2022-03-30 23:11:23 --> Utf8 Class Initialized
INFO - 2022-03-30 23:11:23 --> URI Class Initialized
INFO - 2022-03-30 23:11:23 --> Router Class Initialized
INFO - 2022-03-30 23:11:23 --> Output Class Initialized
INFO - 2022-03-30 23:11:23 --> Security Class Initialized
DEBUG - 2022-03-30 23:11:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-30 23:11:23 --> Input Class Initialized
INFO - 2022-03-30 23:11:23 --> Language Class Initialized
INFO - 2022-03-30 23:11:23 --> Loader Class Initialized
INFO - 2022-03-30 23:11:23 --> Helper loaded: url_helper
INFO - 2022-03-30 23:11:23 --> Helper loaded: form_helper
INFO - 2022-03-30 23:11:23 --> Helper loaded: common_helper
INFO - 2022-03-30 23:11:23 --> Database Driver Class Initialized
DEBUG - 2022-03-30 23:11:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-30 23:11:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-30 23:11:23 --> Controller Class Initialized
INFO - 2022-03-30 23:11:23 --> Form Validation Class Initialized
DEBUG - 2022-03-30 23:11:23 --> Encrypt Class Initialized
INFO - 2022-03-30 23:11:23 --> Model "Login_model" initialized
INFO - 2022-03-30 23:11:23 --> Model "Dashboard_model" initialized
INFO - 2022-03-30 23:11:23 --> Model "Case_model" initialized
INFO - 2022-03-30 23:11:25 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-30 23:11:25 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2022-03-30 23:11:25 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-30 23:11:25 --> Final output sent to browser
DEBUG - 2022-03-30 23:11:25 --> Total execution time: 1.4872
