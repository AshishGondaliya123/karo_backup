<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-01-04 14:16:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-04 14:16:38 --> Config Class Initialized
INFO - 2022-01-04 14:16:38 --> Hooks Class Initialized
DEBUG - 2022-01-04 14:16:38 --> UTF-8 Support Enabled
INFO - 2022-01-04 14:16:38 --> Utf8 Class Initialized
INFO - 2022-01-04 14:16:38 --> URI Class Initialized
DEBUG - 2022-01-04 14:16:38 --> No URI present. Default controller set.
INFO - 2022-01-04 14:16:38 --> Router Class Initialized
INFO - 2022-01-04 14:16:38 --> Output Class Initialized
INFO - 2022-01-04 14:16:38 --> Security Class Initialized
DEBUG - 2022-01-04 14:16:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 14:16:38 --> Input Class Initialized
INFO - 2022-01-04 14:16:38 --> Language Class Initialized
INFO - 2022-01-04 14:16:38 --> Loader Class Initialized
INFO - 2022-01-04 14:16:38 --> Helper loaded: url_helper
INFO - 2022-01-04 14:16:38 --> Helper loaded: form_helper
INFO - 2022-01-04 14:16:38 --> Helper loaded: common_helper
INFO - 2022-01-04 14:16:38 --> Database Driver Class Initialized
DEBUG - 2022-01-04 14:16:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 14:16:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 14:16:38 --> Controller Class Initialized
INFO - 2022-01-04 14:16:38 --> Form Validation Class Initialized
DEBUG - 2022-01-04 14:16:38 --> Encrypt Class Initialized
DEBUG - 2022-01-04 14:16:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-04 14:16:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-04 14:16:38 --> Email Class Initialized
INFO - 2022-01-04 14:16:38 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-04 14:16:38 --> Calendar Class Initialized
INFO - 2022-01-04 14:16:38 --> Model "Login_model" initialized
INFO - 2022-01-04 14:16:38 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-04 14:16:38 --> Final output sent to browser
DEBUG - 2022-01-04 14:16:38 --> Total execution time: 0.0373
ERROR - 2022-01-04 14:16:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-04 14:16:38 --> Config Class Initialized
INFO - 2022-01-04 14:16:38 --> Hooks Class Initialized
DEBUG - 2022-01-04 14:16:38 --> UTF-8 Support Enabled
INFO - 2022-01-04 14:16:38 --> Utf8 Class Initialized
INFO - 2022-01-04 14:16:38 --> URI Class Initialized
INFO - 2022-01-04 14:16:38 --> Router Class Initialized
INFO - 2022-01-04 14:16:38 --> Output Class Initialized
INFO - 2022-01-04 14:16:38 --> Security Class Initialized
DEBUG - 2022-01-04 14:16:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 14:16:38 --> Input Class Initialized
INFO - 2022-01-04 14:16:38 --> Language Class Initialized
ERROR - 2022-01-04 14:16:38 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2022-01-04 14:17:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-04 14:17:06 --> Config Class Initialized
INFO - 2022-01-04 14:17:06 --> Hooks Class Initialized
DEBUG - 2022-01-04 14:17:06 --> UTF-8 Support Enabled
INFO - 2022-01-04 14:17:06 --> Utf8 Class Initialized
INFO - 2022-01-04 14:17:06 --> URI Class Initialized
INFO - 2022-01-04 14:17:06 --> Router Class Initialized
INFO - 2022-01-04 14:17:06 --> Output Class Initialized
INFO - 2022-01-04 14:17:06 --> Security Class Initialized
DEBUG - 2022-01-04 14:17:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 14:17:06 --> Input Class Initialized
INFO - 2022-01-04 14:17:06 --> Language Class Initialized
INFO - 2022-01-04 14:17:06 --> Loader Class Initialized
INFO - 2022-01-04 14:17:06 --> Helper loaded: url_helper
INFO - 2022-01-04 14:17:06 --> Helper loaded: form_helper
INFO - 2022-01-04 14:17:06 --> Helper loaded: common_helper
INFO - 2022-01-04 14:17:06 --> Database Driver Class Initialized
DEBUG - 2022-01-04 14:17:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 14:17:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 14:17:06 --> Controller Class Initialized
INFO - 2022-01-04 14:17:06 --> Form Validation Class Initialized
DEBUG - 2022-01-04 14:17:06 --> Encrypt Class Initialized
DEBUG - 2022-01-04 14:17:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-04 14:17:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-04 14:17:06 --> Email Class Initialized
INFO - 2022-01-04 14:17:06 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-04 14:17:06 --> Calendar Class Initialized
INFO - 2022-01-04 14:17:06 --> Model "Login_model" initialized
ERROR - 2022-01-04 14:17:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-04 14:17:06 --> Config Class Initialized
INFO - 2022-01-04 14:17:06 --> Hooks Class Initialized
DEBUG - 2022-01-04 14:17:06 --> UTF-8 Support Enabled
INFO - 2022-01-04 14:17:06 --> Utf8 Class Initialized
INFO - 2022-01-04 14:17:06 --> URI Class Initialized
INFO - 2022-01-04 14:17:06 --> Router Class Initialized
INFO - 2022-01-04 14:17:06 --> Output Class Initialized
INFO - 2022-01-04 14:17:06 --> Security Class Initialized
DEBUG - 2022-01-04 14:17:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 14:17:06 --> Input Class Initialized
INFO - 2022-01-04 14:17:06 --> Language Class Initialized
INFO - 2022-01-04 14:17:06 --> Loader Class Initialized
INFO - 2022-01-04 14:17:06 --> Helper loaded: url_helper
INFO - 2022-01-04 14:17:06 --> Helper loaded: form_helper
INFO - 2022-01-04 14:17:06 --> Helper loaded: common_helper
INFO - 2022-01-04 14:17:06 --> Database Driver Class Initialized
DEBUG - 2022-01-04 14:17:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 14:17:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 14:17:06 --> Controller Class Initialized
INFO - 2022-01-04 14:17:06 --> Form Validation Class Initialized
DEBUG - 2022-01-04 14:17:06 --> Encrypt Class Initialized
DEBUG - 2022-01-04 14:17:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-04 14:17:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-04 14:17:06 --> Email Class Initialized
INFO - 2022-01-04 14:17:06 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-04 14:17:06 --> Calendar Class Initialized
INFO - 2022-01-04 14:17:06 --> Model "Login_model" initialized
ERROR - 2022-01-04 14:17:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-04 14:17:07 --> Config Class Initialized
INFO - 2022-01-04 14:17:07 --> Hooks Class Initialized
DEBUG - 2022-01-04 14:17:07 --> UTF-8 Support Enabled
INFO - 2022-01-04 14:17:07 --> Utf8 Class Initialized
INFO - 2022-01-04 14:17:07 --> URI Class Initialized
DEBUG - 2022-01-04 14:17:07 --> No URI present. Default controller set.
INFO - 2022-01-04 14:17:07 --> Router Class Initialized
INFO - 2022-01-04 14:17:07 --> Output Class Initialized
INFO - 2022-01-04 14:17:07 --> Security Class Initialized
DEBUG - 2022-01-04 14:17:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 14:17:07 --> Input Class Initialized
INFO - 2022-01-04 14:17:07 --> Language Class Initialized
INFO - 2022-01-04 14:17:07 --> Loader Class Initialized
INFO - 2022-01-04 14:17:07 --> Helper loaded: url_helper
INFO - 2022-01-04 14:17:07 --> Helper loaded: form_helper
INFO - 2022-01-04 14:17:07 --> Helper loaded: common_helper
INFO - 2022-01-04 14:17:07 --> Database Driver Class Initialized
DEBUG - 2022-01-04 14:17:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 14:17:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 14:17:07 --> Controller Class Initialized
INFO - 2022-01-04 14:17:07 --> Form Validation Class Initialized
DEBUG - 2022-01-04 14:17:07 --> Encrypt Class Initialized
DEBUG - 2022-01-04 14:17:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-04 14:17:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-04 14:17:07 --> Email Class Initialized
INFO - 2022-01-04 14:17:07 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-04 14:17:07 --> Calendar Class Initialized
INFO - 2022-01-04 14:17:07 --> Model "Login_model" initialized
INFO - 2022-01-04 14:17:07 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-04 14:17:07 --> Final output sent to browser
DEBUG - 2022-01-04 14:17:07 --> Total execution time: 0.0305
ERROR - 2022-01-04 14:17:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-04 14:17:08 --> Config Class Initialized
INFO - 2022-01-04 14:17:08 --> Hooks Class Initialized
DEBUG - 2022-01-04 14:17:08 --> UTF-8 Support Enabled
INFO - 2022-01-04 14:17:08 --> Utf8 Class Initialized
INFO - 2022-01-04 14:17:08 --> URI Class Initialized
INFO - 2022-01-04 14:17:08 --> Router Class Initialized
INFO - 2022-01-04 14:17:08 --> Output Class Initialized
INFO - 2022-01-04 14:17:08 --> Security Class Initialized
DEBUG - 2022-01-04 14:17:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 14:17:08 --> Input Class Initialized
INFO - 2022-01-04 14:17:08 --> Language Class Initialized
INFO - 2022-01-04 14:17:08 --> Loader Class Initialized
INFO - 2022-01-04 14:17:08 --> Helper loaded: url_helper
INFO - 2022-01-04 14:17:08 --> Helper loaded: form_helper
INFO - 2022-01-04 14:17:08 --> Helper loaded: common_helper
INFO - 2022-01-04 14:17:08 --> Database Driver Class Initialized
DEBUG - 2022-01-04 14:17:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 14:17:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 14:17:08 --> Controller Class Initialized
INFO - 2022-01-04 14:17:08 --> Form Validation Class Initialized
DEBUG - 2022-01-04 14:17:08 --> Encrypt Class Initialized
DEBUG - 2022-01-04 14:17:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-04 14:17:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-04 14:17:08 --> Email Class Initialized
INFO - 2022-01-04 14:17:08 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-04 14:17:08 --> Calendar Class Initialized
INFO - 2022-01-04 14:17:08 --> Model "Login_model" initialized
INFO - 2022-01-04 14:17:08 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-04 14:17:08 --> Final output sent to browser
DEBUG - 2022-01-04 14:17:08 --> Total execution time: 0.0233
ERROR - 2022-01-04 14:48:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-04 14:48:20 --> Config Class Initialized
INFO - 2022-01-04 14:48:20 --> Hooks Class Initialized
DEBUG - 2022-01-04 14:48:20 --> UTF-8 Support Enabled
INFO - 2022-01-04 14:48:20 --> Utf8 Class Initialized
INFO - 2022-01-04 14:48:20 --> URI Class Initialized
DEBUG - 2022-01-04 14:48:20 --> No URI present. Default controller set.
INFO - 2022-01-04 14:48:20 --> Router Class Initialized
INFO - 2022-01-04 14:48:20 --> Output Class Initialized
INFO - 2022-01-04 14:48:20 --> Security Class Initialized
DEBUG - 2022-01-04 14:48:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 14:48:20 --> Input Class Initialized
INFO - 2022-01-04 14:48:20 --> Language Class Initialized
INFO - 2022-01-04 14:48:20 --> Loader Class Initialized
INFO - 2022-01-04 14:48:20 --> Helper loaded: url_helper
INFO - 2022-01-04 14:48:20 --> Helper loaded: form_helper
INFO - 2022-01-04 14:48:20 --> Helper loaded: common_helper
INFO - 2022-01-04 14:48:20 --> Database Driver Class Initialized
DEBUG - 2022-01-04 14:48:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 14:48:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 14:48:20 --> Controller Class Initialized
INFO - 2022-01-04 14:48:20 --> Form Validation Class Initialized
DEBUG - 2022-01-04 14:48:20 --> Encrypt Class Initialized
DEBUG - 2022-01-04 14:48:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-04 14:48:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-04 14:48:20 --> Email Class Initialized
INFO - 2022-01-04 14:48:20 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-04 14:48:20 --> Calendar Class Initialized
INFO - 2022-01-04 14:48:20 --> Model "Login_model" initialized
INFO - 2022-01-04 14:48:20 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-04 14:48:20 --> Final output sent to browser
DEBUG - 2022-01-04 14:48:20 --> Total execution time: 0.0245
ERROR - 2022-01-04 15:48:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-04 15:48:29 --> Config Class Initialized
INFO - 2022-01-04 15:48:29 --> Hooks Class Initialized
DEBUG - 2022-01-04 15:48:29 --> UTF-8 Support Enabled
INFO - 2022-01-04 15:48:29 --> Utf8 Class Initialized
INFO - 2022-01-04 15:48:29 --> URI Class Initialized
DEBUG - 2022-01-04 15:48:29 --> No URI present. Default controller set.
INFO - 2022-01-04 15:48:29 --> Router Class Initialized
INFO - 2022-01-04 15:48:29 --> Output Class Initialized
INFO - 2022-01-04 15:48:29 --> Security Class Initialized
DEBUG - 2022-01-04 15:48:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 15:48:29 --> Input Class Initialized
INFO - 2022-01-04 15:48:29 --> Language Class Initialized
INFO - 2022-01-04 15:48:29 --> Loader Class Initialized
INFO - 2022-01-04 15:48:29 --> Helper loaded: url_helper
INFO - 2022-01-04 15:48:29 --> Helper loaded: form_helper
INFO - 2022-01-04 15:48:29 --> Helper loaded: common_helper
INFO - 2022-01-04 15:48:29 --> Database Driver Class Initialized
DEBUG - 2022-01-04 15:48:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 15:48:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 15:48:29 --> Controller Class Initialized
INFO - 2022-01-04 15:48:29 --> Form Validation Class Initialized
DEBUG - 2022-01-04 15:48:29 --> Encrypt Class Initialized
DEBUG - 2022-01-04 15:48:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-04 15:48:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-04 15:48:29 --> Email Class Initialized
INFO - 2022-01-04 15:48:29 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-04 15:48:29 --> Calendar Class Initialized
INFO - 2022-01-04 15:48:29 --> Model "Login_model" initialized
INFO - 2022-01-04 15:48:29 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-04 15:48:29 --> Final output sent to browser
DEBUG - 2022-01-04 15:48:29 --> Total execution time: 0.0245
ERROR - 2022-01-04 15:49:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-04 15:49:59 --> Config Class Initialized
INFO - 2022-01-04 15:49:59 --> Hooks Class Initialized
DEBUG - 2022-01-04 15:49:59 --> UTF-8 Support Enabled
INFO - 2022-01-04 15:49:59 --> Utf8 Class Initialized
INFO - 2022-01-04 15:49:59 --> URI Class Initialized
DEBUG - 2022-01-04 15:49:59 --> No URI present. Default controller set.
INFO - 2022-01-04 15:49:59 --> Router Class Initialized
INFO - 2022-01-04 15:49:59 --> Output Class Initialized
INFO - 2022-01-04 15:49:59 --> Security Class Initialized
DEBUG - 2022-01-04 15:49:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 15:49:59 --> Input Class Initialized
INFO - 2022-01-04 15:49:59 --> Language Class Initialized
INFO - 2022-01-04 15:49:59 --> Loader Class Initialized
INFO - 2022-01-04 15:49:59 --> Helper loaded: url_helper
INFO - 2022-01-04 15:49:59 --> Helper loaded: form_helper
INFO - 2022-01-04 15:49:59 --> Helper loaded: common_helper
INFO - 2022-01-04 15:49:59 --> Database Driver Class Initialized
DEBUG - 2022-01-04 15:49:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 15:49:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 15:49:59 --> Controller Class Initialized
INFO - 2022-01-04 15:49:59 --> Form Validation Class Initialized
DEBUG - 2022-01-04 15:49:59 --> Encrypt Class Initialized
DEBUG - 2022-01-04 15:49:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-04 15:49:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-04 15:49:59 --> Email Class Initialized
INFO - 2022-01-04 15:49:59 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-04 15:49:59 --> Calendar Class Initialized
INFO - 2022-01-04 15:49:59 --> Model "Login_model" initialized
INFO - 2022-01-04 15:49:59 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-04 15:49:59 --> Final output sent to browser
DEBUG - 2022-01-04 15:49:59 --> Total execution time: 0.0272
ERROR - 2022-01-04 18:41:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-04 18:41:22 --> Config Class Initialized
INFO - 2022-01-04 18:41:22 --> Hooks Class Initialized
DEBUG - 2022-01-04 18:41:22 --> UTF-8 Support Enabled
INFO - 2022-01-04 18:41:22 --> Utf8 Class Initialized
INFO - 2022-01-04 18:41:22 --> URI Class Initialized
INFO - 2022-01-04 18:41:22 --> Router Class Initialized
INFO - 2022-01-04 18:41:22 --> Output Class Initialized
INFO - 2022-01-04 18:41:22 --> Security Class Initialized
DEBUG - 2022-01-04 18:41:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 18:41:22 --> Input Class Initialized
INFO - 2022-01-04 18:41:22 --> Language Class Initialized
ERROR - 2022-01-04 18:41:22 --> 404 Page Not Found: Assets/js
ERROR - 2022-01-04 18:41:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-04 18:41:22 --> Config Class Initialized
INFO - 2022-01-04 18:41:22 --> Hooks Class Initialized
DEBUG - 2022-01-04 18:41:22 --> UTF-8 Support Enabled
INFO - 2022-01-04 18:41:22 --> Utf8 Class Initialized
INFO - 2022-01-04 18:41:22 --> URI Class Initialized
INFO - 2022-01-04 18:41:22 --> Router Class Initialized
INFO - 2022-01-04 18:41:22 --> Output Class Initialized
INFO - 2022-01-04 18:41:22 --> Security Class Initialized
DEBUG - 2022-01-04 18:41:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 18:41:22 --> Input Class Initialized
INFO - 2022-01-04 18:41:22 --> Language Class Initialized
ERROR - 2022-01-04 18:41:22 --> 404 Page Not Found: Assets/js
ERROR - 2022-01-04 22:32:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-04 22:32:23 --> Config Class Initialized
INFO - 2022-01-04 22:32:23 --> Hooks Class Initialized
DEBUG - 2022-01-04 22:32:23 --> UTF-8 Support Enabled
INFO - 2022-01-04 22:32:23 --> Utf8 Class Initialized
INFO - 2022-01-04 22:32:23 --> URI Class Initialized
DEBUG - 2022-01-04 22:32:23 --> No URI present. Default controller set.
INFO - 2022-01-04 22:32:23 --> Router Class Initialized
INFO - 2022-01-04 22:32:23 --> Output Class Initialized
INFO - 2022-01-04 22:32:23 --> Security Class Initialized
DEBUG - 2022-01-04 22:32:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 22:32:23 --> Input Class Initialized
INFO - 2022-01-04 22:32:23 --> Language Class Initialized
INFO - 2022-01-04 22:32:23 --> Loader Class Initialized
INFO - 2022-01-04 22:32:23 --> Helper loaded: url_helper
INFO - 2022-01-04 22:32:23 --> Helper loaded: form_helper
INFO - 2022-01-04 22:32:23 --> Helper loaded: common_helper
INFO - 2022-01-04 22:32:23 --> Database Driver Class Initialized
DEBUG - 2022-01-04 22:32:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 22:32:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 22:32:23 --> Controller Class Initialized
INFO - 2022-01-04 22:32:23 --> Form Validation Class Initialized
DEBUG - 2022-01-04 22:32:23 --> Encrypt Class Initialized
DEBUG - 2022-01-04 22:32:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-04 22:32:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-04 22:32:23 --> Email Class Initialized
INFO - 2022-01-04 22:32:23 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-04 22:32:23 --> Calendar Class Initialized
INFO - 2022-01-04 22:32:23 --> Model "Login_model" initialized
INFO - 2022-01-04 22:32:23 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-04 22:32:23 --> Final output sent to browser
DEBUG - 2022-01-04 22:32:23 --> Total execution time: 0.0264
