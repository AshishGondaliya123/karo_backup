<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-02-17 02:24:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-17 02:24:15 --> Config Class Initialized
INFO - 2022-02-17 02:24:15 --> Hooks Class Initialized
DEBUG - 2022-02-17 02:24:15 --> UTF-8 Support Enabled
INFO - 2022-02-17 02:24:15 --> Utf8 Class Initialized
INFO - 2022-02-17 02:24:15 --> URI Class Initialized
DEBUG - 2022-02-17 02:24:15 --> No URI present. Default controller set.
INFO - 2022-02-17 02:24:15 --> Router Class Initialized
INFO - 2022-02-17 02:24:15 --> Output Class Initialized
INFO - 2022-02-17 02:24:15 --> Security Class Initialized
DEBUG - 2022-02-17 02:24:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-17 02:24:15 --> Input Class Initialized
INFO - 2022-02-17 02:24:15 --> Language Class Initialized
INFO - 2022-02-17 02:24:15 --> Loader Class Initialized
INFO - 2022-02-17 02:24:15 --> Helper loaded: url_helper
INFO - 2022-02-17 02:24:15 --> Helper loaded: form_helper
INFO - 2022-02-17 02:24:15 --> Helper loaded: common_helper
INFO - 2022-02-17 02:24:15 --> Database Driver Class Initialized
DEBUG - 2022-02-17 02:24:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-17 02:24:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-17 02:24:15 --> Controller Class Initialized
INFO - 2022-02-17 02:24:15 --> Form Validation Class Initialized
DEBUG - 2022-02-17 02:24:15 --> Encrypt Class Initialized
DEBUG - 2022-02-17 02:24:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 02:24:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-17 02:24:15 --> Email Class Initialized
INFO - 2022-02-17 02:24:15 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-17 02:24:15 --> Calendar Class Initialized
INFO - 2022-02-17 02:24:15 --> Model "Login_model" initialized
INFO - 2022-02-17 02:24:15 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-17 02:24:15 --> Final output sent to browser
DEBUG - 2022-02-17 02:24:15 --> Total execution time: 0.0745
ERROR - 2022-02-17 02:52:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-17 02:52:59 --> Config Class Initialized
INFO - 2022-02-17 02:52:59 --> Hooks Class Initialized
DEBUG - 2022-02-17 02:52:59 --> UTF-8 Support Enabled
INFO - 2022-02-17 02:52:59 --> Utf8 Class Initialized
INFO - 2022-02-17 02:52:59 --> URI Class Initialized
DEBUG - 2022-02-17 02:52:59 --> No URI present. Default controller set.
INFO - 2022-02-17 02:52:59 --> Router Class Initialized
INFO - 2022-02-17 02:52:59 --> Output Class Initialized
INFO - 2022-02-17 02:52:59 --> Security Class Initialized
DEBUG - 2022-02-17 02:52:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-17 02:52:59 --> Input Class Initialized
INFO - 2022-02-17 02:52:59 --> Language Class Initialized
INFO - 2022-02-17 02:52:59 --> Loader Class Initialized
INFO - 2022-02-17 02:52:59 --> Helper loaded: url_helper
INFO - 2022-02-17 02:52:59 --> Helper loaded: form_helper
INFO - 2022-02-17 02:52:59 --> Helper loaded: common_helper
INFO - 2022-02-17 02:52:59 --> Database Driver Class Initialized
DEBUG - 2022-02-17 02:52:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-17 02:52:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-17 02:52:59 --> Controller Class Initialized
INFO - 2022-02-17 02:52:59 --> Form Validation Class Initialized
DEBUG - 2022-02-17 02:52:59 --> Encrypt Class Initialized
DEBUG - 2022-02-17 02:52:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 02:52:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-17 02:52:59 --> Email Class Initialized
INFO - 2022-02-17 02:52:59 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-17 02:52:59 --> Calendar Class Initialized
INFO - 2022-02-17 02:52:59 --> Model "Login_model" initialized
INFO - 2022-02-17 02:52:59 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-17 02:52:59 --> Final output sent to browser
DEBUG - 2022-02-17 02:52:59 --> Total execution time: 0.0302
ERROR - 2022-02-17 12:25:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-17 12:25:54 --> Config Class Initialized
INFO - 2022-02-17 12:25:54 --> Hooks Class Initialized
DEBUG - 2022-02-17 12:25:54 --> UTF-8 Support Enabled
INFO - 2022-02-17 12:25:54 --> Utf8 Class Initialized
INFO - 2022-02-17 12:25:54 --> URI Class Initialized
DEBUG - 2022-02-17 12:25:54 --> No URI present. Default controller set.
INFO - 2022-02-17 12:25:54 --> Router Class Initialized
INFO - 2022-02-17 12:25:54 --> Output Class Initialized
INFO - 2022-02-17 12:25:54 --> Security Class Initialized
DEBUG - 2022-02-17 12:25:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-17 12:25:54 --> Input Class Initialized
INFO - 2022-02-17 12:25:54 --> Language Class Initialized
INFO - 2022-02-17 12:25:54 --> Loader Class Initialized
INFO - 2022-02-17 12:25:54 --> Helper loaded: url_helper
INFO - 2022-02-17 12:25:54 --> Helper loaded: form_helper
INFO - 2022-02-17 12:25:54 --> Helper loaded: common_helper
INFO - 2022-02-17 12:25:54 --> Database Driver Class Initialized
DEBUG - 2022-02-17 12:25:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-17 12:25:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-17 12:25:54 --> Controller Class Initialized
INFO - 2022-02-17 12:25:54 --> Form Validation Class Initialized
DEBUG - 2022-02-17 12:25:54 --> Encrypt Class Initialized
DEBUG - 2022-02-17 12:25:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 12:25:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-17 12:25:54 --> Email Class Initialized
INFO - 2022-02-17 12:25:54 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-17 12:25:54 --> Calendar Class Initialized
INFO - 2022-02-17 12:25:54 --> Model "Login_model" initialized
INFO - 2022-02-17 12:25:54 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-17 12:25:54 --> Final output sent to browser
DEBUG - 2022-02-17 12:25:54 --> Total execution time: 0.0562
ERROR - 2022-02-17 14:19:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-17 14:19:50 --> Config Class Initialized
INFO - 2022-02-17 14:19:50 --> Hooks Class Initialized
DEBUG - 2022-02-17 14:19:50 --> UTF-8 Support Enabled
INFO - 2022-02-17 14:19:50 --> Utf8 Class Initialized
INFO - 2022-02-17 14:19:50 --> URI Class Initialized
DEBUG - 2022-02-17 14:19:50 --> No URI present. Default controller set.
INFO - 2022-02-17 14:19:50 --> Router Class Initialized
INFO - 2022-02-17 14:19:50 --> Output Class Initialized
INFO - 2022-02-17 14:19:50 --> Security Class Initialized
DEBUG - 2022-02-17 14:19:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-17 14:19:50 --> Input Class Initialized
INFO - 2022-02-17 14:19:50 --> Language Class Initialized
INFO - 2022-02-17 14:19:50 --> Loader Class Initialized
INFO - 2022-02-17 14:19:50 --> Helper loaded: url_helper
INFO - 2022-02-17 14:19:50 --> Helper loaded: form_helper
INFO - 2022-02-17 14:19:50 --> Helper loaded: common_helper
INFO - 2022-02-17 14:19:50 --> Database Driver Class Initialized
DEBUG - 2022-02-17 14:19:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-17 14:19:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-17 14:19:50 --> Controller Class Initialized
INFO - 2022-02-17 14:19:50 --> Form Validation Class Initialized
DEBUG - 2022-02-17 14:19:50 --> Encrypt Class Initialized
DEBUG - 2022-02-17 14:19:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 14:19:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-17 14:19:50 --> Email Class Initialized
INFO - 2022-02-17 14:19:50 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-17 14:19:50 --> Calendar Class Initialized
INFO - 2022-02-17 14:19:50 --> Model "Login_model" initialized
INFO - 2022-02-17 14:19:50 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-17 14:19:50 --> Final output sent to browser
DEBUG - 2022-02-17 14:19:50 --> Total execution time: 0.0247
ERROR - 2022-02-17 14:19:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-17 14:19:51 --> Config Class Initialized
INFO - 2022-02-17 14:19:51 --> Hooks Class Initialized
DEBUG - 2022-02-17 14:19:51 --> UTF-8 Support Enabled
INFO - 2022-02-17 14:19:51 --> Utf8 Class Initialized
INFO - 2022-02-17 14:19:51 --> URI Class Initialized
INFO - 2022-02-17 14:19:51 --> Router Class Initialized
INFO - 2022-02-17 14:19:51 --> Output Class Initialized
INFO - 2022-02-17 14:19:51 --> Security Class Initialized
DEBUG - 2022-02-17 14:19:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-17 14:19:51 --> Input Class Initialized
INFO - 2022-02-17 14:19:51 --> Language Class Initialized
ERROR - 2022-02-17 14:19:51 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2022-02-17 14:20:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-17 14:20:11 --> Config Class Initialized
INFO - 2022-02-17 14:20:11 --> Hooks Class Initialized
DEBUG - 2022-02-17 14:20:11 --> UTF-8 Support Enabled
INFO - 2022-02-17 14:20:11 --> Utf8 Class Initialized
INFO - 2022-02-17 14:20:11 --> URI Class Initialized
INFO - 2022-02-17 14:20:11 --> Router Class Initialized
INFO - 2022-02-17 14:20:11 --> Output Class Initialized
INFO - 2022-02-17 14:20:11 --> Security Class Initialized
DEBUG - 2022-02-17 14:20:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-17 14:20:11 --> Input Class Initialized
INFO - 2022-02-17 14:20:11 --> Language Class Initialized
INFO - 2022-02-17 14:20:11 --> Loader Class Initialized
INFO - 2022-02-17 14:20:11 --> Helper loaded: url_helper
INFO - 2022-02-17 14:20:11 --> Helper loaded: form_helper
INFO - 2022-02-17 14:20:11 --> Helper loaded: common_helper
INFO - 2022-02-17 14:20:11 --> Database Driver Class Initialized
DEBUG - 2022-02-17 14:20:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-17 14:20:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-17 14:20:11 --> Controller Class Initialized
INFO - 2022-02-17 14:20:11 --> Form Validation Class Initialized
DEBUG - 2022-02-17 14:20:11 --> Encrypt Class Initialized
DEBUG - 2022-02-17 14:20:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 14:20:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-17 14:20:11 --> Email Class Initialized
INFO - 2022-02-17 14:20:11 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-17 14:20:11 --> Calendar Class Initialized
INFO - 2022-02-17 14:20:11 --> Model "Login_model" initialized
INFO - 2022-02-17 14:20:11 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-17 14:20:11 --> Final output sent to browser
DEBUG - 2022-02-17 14:20:11 --> Total execution time: 0.0301
ERROR - 2022-02-17 14:20:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-17 14:20:11 --> Config Class Initialized
INFO - 2022-02-17 14:20:11 --> Hooks Class Initialized
DEBUG - 2022-02-17 14:20:11 --> UTF-8 Support Enabled
INFO - 2022-02-17 14:20:11 --> Utf8 Class Initialized
INFO - 2022-02-17 14:20:11 --> URI Class Initialized
DEBUG - 2022-02-17 14:20:11 --> No URI present. Default controller set.
INFO - 2022-02-17 14:20:11 --> Router Class Initialized
INFO - 2022-02-17 14:20:11 --> Output Class Initialized
INFO - 2022-02-17 14:20:11 --> Security Class Initialized
DEBUG - 2022-02-17 14:20:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-17 14:20:11 --> Input Class Initialized
INFO - 2022-02-17 14:20:11 --> Language Class Initialized
INFO - 2022-02-17 14:20:11 --> Loader Class Initialized
INFO - 2022-02-17 14:20:11 --> Helper loaded: url_helper
INFO - 2022-02-17 14:20:11 --> Helper loaded: form_helper
INFO - 2022-02-17 14:20:11 --> Helper loaded: common_helper
INFO - 2022-02-17 14:20:11 --> Database Driver Class Initialized
DEBUG - 2022-02-17 14:20:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-17 14:20:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-17 14:20:11 --> Controller Class Initialized
INFO - 2022-02-17 14:20:11 --> Form Validation Class Initialized
DEBUG - 2022-02-17 14:20:11 --> Encrypt Class Initialized
DEBUG - 2022-02-17 14:20:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 14:20:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-17 14:20:11 --> Email Class Initialized
INFO - 2022-02-17 14:20:11 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-17 14:20:11 --> Calendar Class Initialized
INFO - 2022-02-17 14:20:11 --> Model "Login_model" initialized
INFO - 2022-02-17 14:20:11 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-17 14:20:11 --> Final output sent to browser
DEBUG - 2022-02-17 14:20:11 --> Total execution time: 0.0342
ERROR - 2022-02-17 14:20:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-17 14:20:12 --> Config Class Initialized
INFO - 2022-02-17 14:20:12 --> Hooks Class Initialized
DEBUG - 2022-02-17 14:20:12 --> UTF-8 Support Enabled
INFO - 2022-02-17 14:20:12 --> Utf8 Class Initialized
INFO - 2022-02-17 14:20:12 --> URI Class Initialized
INFO - 2022-02-17 14:20:12 --> Router Class Initialized
INFO - 2022-02-17 14:20:12 --> Output Class Initialized
INFO - 2022-02-17 14:20:12 --> Security Class Initialized
DEBUG - 2022-02-17 14:20:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-17 14:20:12 --> Input Class Initialized
INFO - 2022-02-17 14:20:12 --> Language Class Initialized
INFO - 2022-02-17 14:20:12 --> Loader Class Initialized
INFO - 2022-02-17 14:20:12 --> Helper loaded: url_helper
INFO - 2022-02-17 14:20:12 --> Helper loaded: form_helper
INFO - 2022-02-17 14:20:12 --> Helper loaded: common_helper
INFO - 2022-02-17 14:20:12 --> Database Driver Class Initialized
DEBUG - 2022-02-17 14:20:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-17 14:20:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-17 14:20:12 --> Controller Class Initialized
INFO - 2022-02-17 14:20:12 --> Form Validation Class Initialized
DEBUG - 2022-02-17 14:20:12 --> Encrypt Class Initialized
DEBUG - 2022-02-17 14:20:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 14:20:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-17 14:20:12 --> Email Class Initialized
INFO - 2022-02-17 14:20:12 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-17 14:20:12 --> Calendar Class Initialized
INFO - 2022-02-17 14:20:12 --> Model "Login_model" initialized
ERROR - 2022-02-17 14:20:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-17 14:20:13 --> Config Class Initialized
INFO - 2022-02-17 14:20:13 --> Hooks Class Initialized
DEBUG - 2022-02-17 14:20:13 --> UTF-8 Support Enabled
INFO - 2022-02-17 14:20:13 --> Utf8 Class Initialized
INFO - 2022-02-17 14:20:13 --> URI Class Initialized
INFO - 2022-02-17 14:20:13 --> Router Class Initialized
INFO - 2022-02-17 14:20:13 --> Output Class Initialized
INFO - 2022-02-17 14:20:13 --> Security Class Initialized
DEBUG - 2022-02-17 14:20:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-17 14:20:13 --> Input Class Initialized
INFO - 2022-02-17 14:20:13 --> Language Class Initialized
INFO - 2022-02-17 14:20:13 --> Loader Class Initialized
INFO - 2022-02-17 14:20:13 --> Helper loaded: url_helper
INFO - 2022-02-17 14:20:13 --> Helper loaded: form_helper
INFO - 2022-02-17 14:20:13 --> Helper loaded: common_helper
INFO - 2022-02-17 14:20:13 --> Database Driver Class Initialized
DEBUG - 2022-02-17 14:20:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-17 14:20:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-17 14:20:13 --> Controller Class Initialized
INFO - 2022-02-17 14:20:13 --> Form Validation Class Initialized
DEBUG - 2022-02-17 14:20:13 --> Encrypt Class Initialized
DEBUG - 2022-02-17 14:20:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 14:20:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-17 14:20:13 --> Email Class Initialized
INFO - 2022-02-17 14:20:13 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-17 14:20:13 --> Calendar Class Initialized
INFO - 2022-02-17 14:20:13 --> Model "Login_model" initialized
ERROR - 2022-02-17 15:11:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-17 15:11:03 --> Config Class Initialized
INFO - 2022-02-17 15:11:03 --> Hooks Class Initialized
DEBUG - 2022-02-17 15:11:03 --> UTF-8 Support Enabled
INFO - 2022-02-17 15:11:03 --> Utf8 Class Initialized
INFO - 2022-02-17 15:11:03 --> URI Class Initialized
DEBUG - 2022-02-17 15:11:03 --> No URI present. Default controller set.
INFO - 2022-02-17 15:11:03 --> Router Class Initialized
INFO - 2022-02-17 15:11:03 --> Output Class Initialized
INFO - 2022-02-17 15:11:03 --> Security Class Initialized
DEBUG - 2022-02-17 15:11:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-17 15:11:03 --> Input Class Initialized
INFO - 2022-02-17 15:11:03 --> Language Class Initialized
INFO - 2022-02-17 15:11:03 --> Loader Class Initialized
INFO - 2022-02-17 15:11:03 --> Helper loaded: url_helper
INFO - 2022-02-17 15:11:03 --> Helper loaded: form_helper
INFO - 2022-02-17 15:11:03 --> Helper loaded: common_helper
INFO - 2022-02-17 15:11:03 --> Database Driver Class Initialized
DEBUG - 2022-02-17 15:11:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-17 15:11:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-17 15:11:03 --> Controller Class Initialized
INFO - 2022-02-17 15:11:03 --> Form Validation Class Initialized
DEBUG - 2022-02-17 15:11:03 --> Encrypt Class Initialized
DEBUG - 2022-02-17 15:11:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 15:11:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-17 15:11:03 --> Email Class Initialized
INFO - 2022-02-17 15:11:03 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-17 15:11:03 --> Calendar Class Initialized
INFO - 2022-02-17 15:11:03 --> Model "Login_model" initialized
INFO - 2022-02-17 15:11:03 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-17 15:11:03 --> Final output sent to browser
DEBUG - 2022-02-17 15:11:03 --> Total execution time: 0.0304
ERROR - 2022-02-17 18:39:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-17 18:39:45 --> Config Class Initialized
INFO - 2022-02-17 18:39:45 --> Hooks Class Initialized
DEBUG - 2022-02-17 18:39:45 --> UTF-8 Support Enabled
INFO - 2022-02-17 18:39:45 --> Utf8 Class Initialized
INFO - 2022-02-17 18:39:45 --> URI Class Initialized
DEBUG - 2022-02-17 18:39:45 --> No URI present. Default controller set.
INFO - 2022-02-17 18:39:45 --> Router Class Initialized
INFO - 2022-02-17 18:39:45 --> Output Class Initialized
INFO - 2022-02-17 18:39:45 --> Security Class Initialized
DEBUG - 2022-02-17 18:39:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-17 18:39:45 --> Input Class Initialized
INFO - 2022-02-17 18:39:45 --> Language Class Initialized
INFO - 2022-02-17 18:39:45 --> Loader Class Initialized
INFO - 2022-02-17 18:39:45 --> Helper loaded: url_helper
INFO - 2022-02-17 18:39:45 --> Helper loaded: form_helper
INFO - 2022-02-17 18:39:45 --> Helper loaded: common_helper
INFO - 2022-02-17 18:39:45 --> Database Driver Class Initialized
DEBUG - 2022-02-17 18:39:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-17 18:39:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-17 18:39:46 --> Controller Class Initialized
INFO - 2022-02-17 18:39:46 --> Form Validation Class Initialized
DEBUG - 2022-02-17 18:39:46 --> Encrypt Class Initialized
DEBUG - 2022-02-17 18:39:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 18:39:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-17 18:39:46 --> Email Class Initialized
INFO - 2022-02-17 18:39:46 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-17 18:39:46 --> Calendar Class Initialized
INFO - 2022-02-17 18:39:46 --> Model "Login_model" initialized
INFO - 2022-02-17 18:39:46 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-17 18:39:46 --> Final output sent to browser
DEBUG - 2022-02-17 18:39:46 --> Total execution time: 0.0221
