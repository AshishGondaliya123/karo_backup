<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-03-19 00:39:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-19 00:39:56 --> Config Class Initialized
INFO - 2022-03-19 00:39:56 --> Hooks Class Initialized
DEBUG - 2022-03-19 00:39:56 --> UTF-8 Support Enabled
INFO - 2022-03-19 00:39:56 --> Utf8 Class Initialized
INFO - 2022-03-19 00:39:56 --> URI Class Initialized
DEBUG - 2022-03-19 00:39:56 --> No URI present. Default controller set.
INFO - 2022-03-19 00:39:56 --> Router Class Initialized
INFO - 2022-03-19 00:39:56 --> Output Class Initialized
INFO - 2022-03-19 00:39:56 --> Security Class Initialized
DEBUG - 2022-03-19 00:39:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-19 00:39:56 --> Input Class Initialized
INFO - 2022-03-19 00:39:56 --> Language Class Initialized
INFO - 2022-03-19 00:39:56 --> Loader Class Initialized
INFO - 2022-03-19 00:39:56 --> Helper loaded: url_helper
INFO - 2022-03-19 00:39:56 --> Helper loaded: form_helper
INFO - 2022-03-19 00:39:56 --> Helper loaded: common_helper
INFO - 2022-03-19 00:39:56 --> Database Driver Class Initialized
DEBUG - 2022-03-19 00:39:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-19 00:39:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-19 00:39:56 --> Controller Class Initialized
INFO - 2022-03-19 00:39:56 --> Form Validation Class Initialized
DEBUG - 2022-03-19 00:39:56 --> Encrypt Class Initialized
DEBUG - 2022-03-19 00:39:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-19 00:39:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-19 00:39:56 --> Email Class Initialized
INFO - 2022-03-19 00:39:56 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-19 00:39:56 --> Calendar Class Initialized
INFO - 2022-03-19 00:39:56 --> Model "Login_model" initialized
INFO - 2022-03-19 00:39:56 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-19 00:39:56 --> Final output sent to browser
DEBUG - 2022-03-19 00:39:56 --> Total execution time: 0.0348
ERROR - 2022-03-19 02:14:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-19 02:14:08 --> Config Class Initialized
INFO - 2022-03-19 02:14:08 --> Hooks Class Initialized
DEBUG - 2022-03-19 02:14:08 --> UTF-8 Support Enabled
INFO - 2022-03-19 02:14:08 --> Utf8 Class Initialized
INFO - 2022-03-19 02:14:08 --> URI Class Initialized
INFO - 2022-03-19 02:14:08 --> Router Class Initialized
INFO - 2022-03-19 02:14:08 --> Output Class Initialized
INFO - 2022-03-19 02:14:08 --> Security Class Initialized
DEBUG - 2022-03-19 02:14:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-19 02:14:08 --> Input Class Initialized
INFO - 2022-03-19 02:14:08 --> Language Class Initialized
ERROR - 2022-03-19 02:14:08 --> 404 Page Not Found: Public/.aws
ERROR - 2022-03-19 02:14:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-19 02:14:08 --> Config Class Initialized
INFO - 2022-03-19 02:14:08 --> Hooks Class Initialized
DEBUG - 2022-03-19 02:14:08 --> UTF-8 Support Enabled
INFO - 2022-03-19 02:14:08 --> Utf8 Class Initialized
INFO - 2022-03-19 02:14:08 --> URI Class Initialized
INFO - 2022-03-19 02:14:08 --> Router Class Initialized
INFO - 2022-03-19 02:14:08 --> Output Class Initialized
INFO - 2022-03-19 02:14:08 --> Security Class Initialized
DEBUG - 2022-03-19 02:14:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-19 02:14:08 --> Input Class Initialized
INFO - 2022-03-19 02:14:08 --> Language Class Initialized
ERROR - 2022-03-19 02:14:08 --> 404 Page Not Found: Public/.aws
ERROR - 2022-03-19 06:02:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-19 06:02:38 --> Config Class Initialized
INFO - 2022-03-19 06:02:38 --> Hooks Class Initialized
DEBUG - 2022-03-19 06:02:38 --> UTF-8 Support Enabled
INFO - 2022-03-19 06:02:38 --> Utf8 Class Initialized
INFO - 2022-03-19 06:02:38 --> URI Class Initialized
DEBUG - 2022-03-19 06:02:38 --> No URI present. Default controller set.
INFO - 2022-03-19 06:02:38 --> Router Class Initialized
INFO - 2022-03-19 06:02:38 --> Output Class Initialized
INFO - 2022-03-19 06:02:38 --> Security Class Initialized
DEBUG - 2022-03-19 06:02:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-19 06:02:38 --> Input Class Initialized
INFO - 2022-03-19 06:02:38 --> Language Class Initialized
INFO - 2022-03-19 06:02:38 --> Loader Class Initialized
INFO - 2022-03-19 06:02:38 --> Helper loaded: url_helper
INFO - 2022-03-19 06:02:38 --> Helper loaded: form_helper
INFO - 2022-03-19 06:02:38 --> Helper loaded: common_helper
INFO - 2022-03-19 06:02:38 --> Database Driver Class Initialized
DEBUG - 2022-03-19 06:02:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-19 06:02:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-19 06:02:38 --> Controller Class Initialized
INFO - 2022-03-19 06:02:38 --> Form Validation Class Initialized
DEBUG - 2022-03-19 06:02:38 --> Encrypt Class Initialized
DEBUG - 2022-03-19 06:02:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-19 06:02:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-19 06:02:38 --> Email Class Initialized
INFO - 2022-03-19 06:02:38 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-19 06:02:38 --> Calendar Class Initialized
INFO - 2022-03-19 06:02:38 --> Model "Login_model" initialized
INFO - 2022-03-19 06:02:38 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-19 06:02:38 --> Final output sent to browser
DEBUG - 2022-03-19 06:02:38 --> Total execution time: 0.0573
ERROR - 2022-03-19 09:06:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-19 09:06:19 --> Config Class Initialized
INFO - 2022-03-19 09:06:19 --> Hooks Class Initialized
DEBUG - 2022-03-19 09:06:19 --> UTF-8 Support Enabled
INFO - 2022-03-19 09:06:19 --> Utf8 Class Initialized
INFO - 2022-03-19 09:06:19 --> URI Class Initialized
DEBUG - 2022-03-19 09:06:19 --> No URI present. Default controller set.
INFO - 2022-03-19 09:06:19 --> Router Class Initialized
INFO - 2022-03-19 09:06:19 --> Output Class Initialized
INFO - 2022-03-19 09:06:19 --> Security Class Initialized
DEBUG - 2022-03-19 09:06:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-19 09:06:19 --> Input Class Initialized
INFO - 2022-03-19 09:06:19 --> Language Class Initialized
INFO - 2022-03-19 09:06:19 --> Loader Class Initialized
INFO - 2022-03-19 09:06:19 --> Helper loaded: url_helper
INFO - 2022-03-19 09:06:19 --> Helper loaded: form_helper
INFO - 2022-03-19 09:06:19 --> Helper loaded: common_helper
INFO - 2022-03-19 09:06:19 --> Database Driver Class Initialized
DEBUG - 2022-03-19 09:06:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-19 09:06:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-19 09:06:19 --> Controller Class Initialized
INFO - 2022-03-19 09:06:19 --> Form Validation Class Initialized
DEBUG - 2022-03-19 09:06:19 --> Encrypt Class Initialized
DEBUG - 2022-03-19 09:06:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-19 09:06:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-19 09:06:19 --> Email Class Initialized
INFO - 2022-03-19 09:06:19 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-19 09:06:19 --> Calendar Class Initialized
INFO - 2022-03-19 09:06:19 --> Model "Login_model" initialized
INFO - 2022-03-19 09:06:19 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-19 09:06:19 --> Final output sent to browser
DEBUG - 2022-03-19 09:06:19 --> Total execution time: 0.0458
ERROR - 2022-03-19 11:22:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-19 11:22:35 --> Config Class Initialized
INFO - 2022-03-19 11:22:35 --> Hooks Class Initialized
DEBUG - 2022-03-19 11:22:35 --> UTF-8 Support Enabled
INFO - 2022-03-19 11:22:35 --> Utf8 Class Initialized
INFO - 2022-03-19 11:22:35 --> URI Class Initialized
DEBUG - 2022-03-19 11:22:35 --> No URI present. Default controller set.
INFO - 2022-03-19 11:22:35 --> Router Class Initialized
INFO - 2022-03-19 11:22:35 --> Output Class Initialized
INFO - 2022-03-19 11:22:35 --> Security Class Initialized
DEBUG - 2022-03-19 11:22:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-19 11:22:35 --> Input Class Initialized
INFO - 2022-03-19 11:22:35 --> Language Class Initialized
INFO - 2022-03-19 11:22:35 --> Loader Class Initialized
INFO - 2022-03-19 11:22:35 --> Helper loaded: url_helper
INFO - 2022-03-19 11:22:35 --> Helper loaded: form_helper
INFO - 2022-03-19 11:22:35 --> Helper loaded: common_helper
INFO - 2022-03-19 11:22:35 --> Database Driver Class Initialized
DEBUG - 2022-03-19 11:22:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-19 11:22:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-19 11:22:35 --> Controller Class Initialized
INFO - 2022-03-19 11:22:35 --> Form Validation Class Initialized
DEBUG - 2022-03-19 11:22:35 --> Encrypt Class Initialized
DEBUG - 2022-03-19 11:22:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-19 11:22:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-19 11:22:35 --> Email Class Initialized
INFO - 2022-03-19 11:22:35 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-19 11:22:35 --> Calendar Class Initialized
INFO - 2022-03-19 11:22:35 --> Model "Login_model" initialized
INFO - 2022-03-19 11:22:35 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-19 11:22:35 --> Final output sent to browser
DEBUG - 2022-03-19 11:22:35 --> Total execution time: 0.0285
ERROR - 2022-03-19 11:22:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-19 11:22:37 --> Config Class Initialized
INFO - 2022-03-19 11:22:37 --> Hooks Class Initialized
DEBUG - 2022-03-19 11:22:37 --> UTF-8 Support Enabled
INFO - 2022-03-19 11:22:37 --> Utf8 Class Initialized
INFO - 2022-03-19 11:22:37 --> URI Class Initialized
DEBUG - 2022-03-19 11:22:37 --> No URI present. Default controller set.
INFO - 2022-03-19 11:22:37 --> Router Class Initialized
INFO - 2022-03-19 11:22:37 --> Output Class Initialized
INFO - 2022-03-19 11:22:37 --> Security Class Initialized
DEBUG - 2022-03-19 11:22:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-19 11:22:37 --> Input Class Initialized
INFO - 2022-03-19 11:22:37 --> Language Class Initialized
INFO - 2022-03-19 11:22:37 --> Loader Class Initialized
INFO - 2022-03-19 11:22:37 --> Helper loaded: url_helper
INFO - 2022-03-19 11:22:37 --> Helper loaded: form_helper
INFO - 2022-03-19 11:22:37 --> Helper loaded: common_helper
INFO - 2022-03-19 11:22:37 --> Database Driver Class Initialized
DEBUG - 2022-03-19 11:22:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-19 11:22:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-19 11:22:37 --> Controller Class Initialized
INFO - 2022-03-19 11:22:37 --> Form Validation Class Initialized
DEBUG - 2022-03-19 11:22:37 --> Encrypt Class Initialized
DEBUG - 2022-03-19 11:22:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-19 11:22:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-19 11:22:37 --> Email Class Initialized
INFO - 2022-03-19 11:22:37 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-19 11:22:37 --> Calendar Class Initialized
INFO - 2022-03-19 11:22:37 --> Model "Login_model" initialized
INFO - 2022-03-19 11:22:37 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-19 11:22:37 --> Final output sent to browser
DEBUG - 2022-03-19 11:22:37 --> Total execution time: 0.0306
ERROR - 2022-03-19 11:31:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-19 11:31:47 --> Config Class Initialized
INFO - 2022-03-19 11:31:47 --> Hooks Class Initialized
DEBUG - 2022-03-19 11:31:47 --> UTF-8 Support Enabled
INFO - 2022-03-19 11:31:47 --> Utf8 Class Initialized
INFO - 2022-03-19 11:31:47 --> URI Class Initialized
DEBUG - 2022-03-19 11:31:47 --> No URI present. Default controller set.
INFO - 2022-03-19 11:31:47 --> Router Class Initialized
INFO - 2022-03-19 11:31:47 --> Output Class Initialized
INFO - 2022-03-19 11:31:47 --> Security Class Initialized
DEBUG - 2022-03-19 11:31:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-19 11:31:47 --> Input Class Initialized
INFO - 2022-03-19 11:31:47 --> Language Class Initialized
INFO - 2022-03-19 11:31:47 --> Loader Class Initialized
INFO - 2022-03-19 11:31:47 --> Helper loaded: url_helper
INFO - 2022-03-19 11:31:47 --> Helper loaded: form_helper
INFO - 2022-03-19 11:31:47 --> Helper loaded: common_helper
INFO - 2022-03-19 11:31:47 --> Database Driver Class Initialized
DEBUG - 2022-03-19 11:31:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-19 11:31:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-19 11:31:47 --> Controller Class Initialized
INFO - 2022-03-19 11:31:47 --> Form Validation Class Initialized
DEBUG - 2022-03-19 11:31:47 --> Encrypt Class Initialized
DEBUG - 2022-03-19 11:31:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-19 11:31:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-19 11:31:47 --> Email Class Initialized
INFO - 2022-03-19 11:31:47 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-19 11:31:47 --> Calendar Class Initialized
INFO - 2022-03-19 11:31:47 --> Model "Login_model" initialized
INFO - 2022-03-19 11:31:47 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-19 11:31:47 --> Final output sent to browser
DEBUG - 2022-03-19 11:31:47 --> Total execution time: 0.0360
ERROR - 2022-03-19 14:16:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-19 14:16:44 --> Config Class Initialized
INFO - 2022-03-19 14:16:44 --> Hooks Class Initialized
DEBUG - 2022-03-19 14:16:44 --> UTF-8 Support Enabled
INFO - 2022-03-19 14:16:44 --> Utf8 Class Initialized
INFO - 2022-03-19 14:16:44 --> URI Class Initialized
DEBUG - 2022-03-19 14:16:44 --> No URI present. Default controller set.
INFO - 2022-03-19 14:16:44 --> Router Class Initialized
INFO - 2022-03-19 14:16:44 --> Output Class Initialized
INFO - 2022-03-19 14:16:44 --> Security Class Initialized
DEBUG - 2022-03-19 14:16:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-19 14:16:44 --> Input Class Initialized
INFO - 2022-03-19 14:16:44 --> Language Class Initialized
INFO - 2022-03-19 14:16:44 --> Loader Class Initialized
INFO - 2022-03-19 14:16:44 --> Helper loaded: url_helper
INFO - 2022-03-19 14:16:44 --> Helper loaded: form_helper
INFO - 2022-03-19 14:16:44 --> Helper loaded: common_helper
INFO - 2022-03-19 14:16:44 --> Database Driver Class Initialized
DEBUG - 2022-03-19 14:16:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-19 14:16:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-19 14:16:44 --> Controller Class Initialized
INFO - 2022-03-19 14:16:44 --> Form Validation Class Initialized
DEBUG - 2022-03-19 14:16:44 --> Encrypt Class Initialized
DEBUG - 2022-03-19 14:16:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-19 14:16:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-19 14:16:44 --> Email Class Initialized
INFO - 2022-03-19 14:16:44 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-19 14:16:44 --> Calendar Class Initialized
INFO - 2022-03-19 14:16:44 --> Model "Login_model" initialized
INFO - 2022-03-19 14:16:44 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-19 14:16:44 --> Final output sent to browser
DEBUG - 2022-03-19 14:16:44 --> Total execution time: 0.0395
ERROR - 2022-03-19 14:16:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-19 14:16:44 --> Config Class Initialized
INFO - 2022-03-19 14:16:44 --> Hooks Class Initialized
DEBUG - 2022-03-19 14:16:44 --> UTF-8 Support Enabled
INFO - 2022-03-19 14:16:44 --> Utf8 Class Initialized
INFO - 2022-03-19 14:16:44 --> URI Class Initialized
INFO - 2022-03-19 14:16:44 --> Router Class Initialized
INFO - 2022-03-19 14:16:44 --> Output Class Initialized
INFO - 2022-03-19 14:16:44 --> Security Class Initialized
DEBUG - 2022-03-19 14:16:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-19 14:16:44 --> Input Class Initialized
INFO - 2022-03-19 14:16:44 --> Language Class Initialized
ERROR - 2022-03-19 14:16:44 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2022-03-19 14:17:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-19 14:17:51 --> Config Class Initialized
INFO - 2022-03-19 14:17:51 --> Hooks Class Initialized
DEBUG - 2022-03-19 14:17:51 --> UTF-8 Support Enabled
INFO - 2022-03-19 14:17:51 --> Utf8 Class Initialized
INFO - 2022-03-19 14:17:51 --> URI Class Initialized
INFO - 2022-03-19 14:17:51 --> Router Class Initialized
INFO - 2022-03-19 14:17:51 --> Output Class Initialized
INFO - 2022-03-19 14:17:51 --> Security Class Initialized
DEBUG - 2022-03-19 14:17:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-19 14:17:51 --> Input Class Initialized
INFO - 2022-03-19 14:17:51 --> Language Class Initialized
INFO - 2022-03-19 14:17:51 --> Loader Class Initialized
INFO - 2022-03-19 14:17:51 --> Helper loaded: url_helper
INFO - 2022-03-19 14:17:51 --> Helper loaded: form_helper
INFO - 2022-03-19 14:17:51 --> Helper loaded: common_helper
INFO - 2022-03-19 14:17:51 --> Database Driver Class Initialized
DEBUG - 2022-03-19 14:17:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-19 14:17:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-19 14:17:51 --> Controller Class Initialized
INFO - 2022-03-19 14:17:51 --> Form Validation Class Initialized
DEBUG - 2022-03-19 14:17:51 --> Encrypt Class Initialized
DEBUG - 2022-03-19 14:17:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-19 14:17:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-19 14:17:51 --> Email Class Initialized
INFO - 2022-03-19 14:17:51 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-19 14:17:51 --> Calendar Class Initialized
INFO - 2022-03-19 14:17:51 --> Model "Login_model" initialized
INFO - 2022-03-19 14:17:51 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-19 14:17:51 --> Final output sent to browser
DEBUG - 2022-03-19 14:17:51 --> Total execution time: 0.0373
ERROR - 2022-03-19 14:17:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-19 14:17:51 --> Config Class Initialized
INFO - 2022-03-19 14:17:51 --> Hooks Class Initialized
DEBUG - 2022-03-19 14:17:51 --> UTF-8 Support Enabled
INFO - 2022-03-19 14:17:51 --> Utf8 Class Initialized
INFO - 2022-03-19 14:17:51 --> URI Class Initialized
DEBUG - 2022-03-19 14:17:51 --> No URI present. Default controller set.
INFO - 2022-03-19 14:17:51 --> Router Class Initialized
INFO - 2022-03-19 14:17:51 --> Output Class Initialized
INFO - 2022-03-19 14:17:51 --> Security Class Initialized
DEBUG - 2022-03-19 14:17:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-19 14:17:51 --> Input Class Initialized
INFO - 2022-03-19 14:17:51 --> Language Class Initialized
INFO - 2022-03-19 14:17:51 --> Loader Class Initialized
INFO - 2022-03-19 14:17:51 --> Helper loaded: url_helper
INFO - 2022-03-19 14:17:51 --> Helper loaded: form_helper
INFO - 2022-03-19 14:17:51 --> Helper loaded: common_helper
INFO - 2022-03-19 14:17:51 --> Database Driver Class Initialized
DEBUG - 2022-03-19 14:17:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-19 14:17:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-19 14:17:51 --> Controller Class Initialized
INFO - 2022-03-19 14:17:51 --> Form Validation Class Initialized
DEBUG - 2022-03-19 14:17:51 --> Encrypt Class Initialized
DEBUG - 2022-03-19 14:17:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-19 14:17:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-19 14:17:51 --> Email Class Initialized
INFO - 2022-03-19 14:17:51 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-19 14:17:51 --> Calendar Class Initialized
INFO - 2022-03-19 14:17:51 --> Model "Login_model" initialized
INFO - 2022-03-19 14:17:51 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-19 14:17:51 --> Final output sent to browser
DEBUG - 2022-03-19 14:17:51 --> Total execution time: 0.0313
ERROR - 2022-03-19 14:17:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-19 14:17:52 --> Config Class Initialized
INFO - 2022-03-19 14:17:52 --> Hooks Class Initialized
DEBUG - 2022-03-19 14:17:52 --> UTF-8 Support Enabled
INFO - 2022-03-19 14:17:52 --> Utf8 Class Initialized
INFO - 2022-03-19 14:17:52 --> URI Class Initialized
INFO - 2022-03-19 14:17:52 --> Router Class Initialized
INFO - 2022-03-19 14:17:52 --> Output Class Initialized
INFO - 2022-03-19 14:17:52 --> Security Class Initialized
DEBUG - 2022-03-19 14:17:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-19 14:17:52 --> Input Class Initialized
INFO - 2022-03-19 14:17:52 --> Language Class Initialized
INFO - 2022-03-19 14:17:52 --> Loader Class Initialized
INFO - 2022-03-19 14:17:52 --> Helper loaded: url_helper
INFO - 2022-03-19 14:17:52 --> Helper loaded: form_helper
INFO - 2022-03-19 14:17:52 --> Helper loaded: common_helper
INFO - 2022-03-19 14:17:52 --> Database Driver Class Initialized
DEBUG - 2022-03-19 14:17:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-19 14:17:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-19 14:17:52 --> Controller Class Initialized
INFO - 2022-03-19 14:17:52 --> Form Validation Class Initialized
DEBUG - 2022-03-19 14:17:52 --> Encrypt Class Initialized
DEBUG - 2022-03-19 14:17:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-19 14:17:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-19 14:17:52 --> Email Class Initialized
INFO - 2022-03-19 14:17:52 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-19 14:17:52 --> Calendar Class Initialized
INFO - 2022-03-19 14:17:52 --> Model "Login_model" initialized
ERROR - 2022-03-19 14:17:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-19 14:17:53 --> Config Class Initialized
INFO - 2022-03-19 14:17:53 --> Hooks Class Initialized
DEBUG - 2022-03-19 14:17:53 --> UTF-8 Support Enabled
INFO - 2022-03-19 14:17:53 --> Utf8 Class Initialized
INFO - 2022-03-19 14:17:53 --> URI Class Initialized
INFO - 2022-03-19 14:17:53 --> Router Class Initialized
INFO - 2022-03-19 14:17:53 --> Output Class Initialized
INFO - 2022-03-19 14:17:53 --> Security Class Initialized
DEBUG - 2022-03-19 14:17:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-19 14:17:53 --> Input Class Initialized
INFO - 2022-03-19 14:17:53 --> Language Class Initialized
INFO - 2022-03-19 14:17:53 --> Loader Class Initialized
INFO - 2022-03-19 14:17:53 --> Helper loaded: url_helper
INFO - 2022-03-19 14:17:53 --> Helper loaded: form_helper
INFO - 2022-03-19 14:17:53 --> Helper loaded: common_helper
INFO - 2022-03-19 14:17:53 --> Database Driver Class Initialized
DEBUG - 2022-03-19 14:17:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-19 14:17:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-19 14:17:53 --> Controller Class Initialized
INFO - 2022-03-19 14:17:53 --> Form Validation Class Initialized
DEBUG - 2022-03-19 14:17:53 --> Encrypt Class Initialized
DEBUG - 2022-03-19 14:17:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-19 14:17:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-19 14:17:53 --> Email Class Initialized
INFO - 2022-03-19 14:17:53 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-19 14:17:53 --> Calendar Class Initialized
INFO - 2022-03-19 14:17:53 --> Model "Login_model" initialized
ERROR - 2022-03-19 14:49:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-19 14:49:35 --> Config Class Initialized
INFO - 2022-03-19 14:49:35 --> Hooks Class Initialized
DEBUG - 2022-03-19 14:49:35 --> UTF-8 Support Enabled
INFO - 2022-03-19 14:49:35 --> Utf8 Class Initialized
INFO - 2022-03-19 14:49:35 --> URI Class Initialized
DEBUG - 2022-03-19 14:49:35 --> No URI present. Default controller set.
INFO - 2022-03-19 14:49:35 --> Router Class Initialized
INFO - 2022-03-19 14:49:35 --> Output Class Initialized
INFO - 2022-03-19 14:49:35 --> Security Class Initialized
DEBUG - 2022-03-19 14:49:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-19 14:49:35 --> Input Class Initialized
INFO - 2022-03-19 14:49:35 --> Language Class Initialized
INFO - 2022-03-19 14:49:35 --> Loader Class Initialized
INFO - 2022-03-19 14:49:35 --> Helper loaded: url_helper
INFO - 2022-03-19 14:49:35 --> Helper loaded: form_helper
INFO - 2022-03-19 14:49:35 --> Helper loaded: common_helper
INFO - 2022-03-19 14:49:35 --> Database Driver Class Initialized
DEBUG - 2022-03-19 14:49:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-19 14:49:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-19 14:49:35 --> Controller Class Initialized
INFO - 2022-03-19 14:49:35 --> Form Validation Class Initialized
DEBUG - 2022-03-19 14:49:35 --> Encrypt Class Initialized
DEBUG - 2022-03-19 14:49:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-19 14:49:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-19 14:49:35 --> Email Class Initialized
INFO - 2022-03-19 14:49:35 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-19 14:49:35 --> Calendar Class Initialized
INFO - 2022-03-19 14:49:35 --> Model "Login_model" initialized
INFO - 2022-03-19 14:49:35 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-19 14:49:35 --> Final output sent to browser
DEBUG - 2022-03-19 14:49:35 --> Total execution time: 0.0469
ERROR - 2022-03-19 17:34:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-19 17:34:07 --> Config Class Initialized
INFO - 2022-03-19 17:34:07 --> Hooks Class Initialized
DEBUG - 2022-03-19 17:34:07 --> UTF-8 Support Enabled
INFO - 2022-03-19 17:34:07 --> Utf8 Class Initialized
INFO - 2022-03-19 17:34:07 --> URI Class Initialized
DEBUG - 2022-03-19 17:34:07 --> No URI present. Default controller set.
INFO - 2022-03-19 17:34:07 --> Router Class Initialized
INFO - 2022-03-19 17:34:07 --> Output Class Initialized
INFO - 2022-03-19 17:34:07 --> Security Class Initialized
DEBUG - 2022-03-19 17:34:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-19 17:34:07 --> Input Class Initialized
INFO - 2022-03-19 17:34:07 --> Language Class Initialized
INFO - 2022-03-19 17:34:07 --> Loader Class Initialized
INFO - 2022-03-19 17:34:07 --> Helper loaded: url_helper
INFO - 2022-03-19 17:34:07 --> Helper loaded: form_helper
INFO - 2022-03-19 17:34:07 --> Helper loaded: common_helper
INFO - 2022-03-19 17:34:07 --> Database Driver Class Initialized
DEBUG - 2022-03-19 17:34:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-19 17:34:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-19 17:34:07 --> Controller Class Initialized
INFO - 2022-03-19 17:34:07 --> Form Validation Class Initialized
DEBUG - 2022-03-19 17:34:07 --> Encrypt Class Initialized
DEBUG - 2022-03-19 17:34:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-19 17:34:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-19 17:34:07 --> Email Class Initialized
INFO - 2022-03-19 17:34:07 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-19 17:34:07 --> Calendar Class Initialized
INFO - 2022-03-19 17:34:07 --> Model "Login_model" initialized
INFO - 2022-03-19 17:34:07 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-19 17:34:07 --> Final output sent to browser
DEBUG - 2022-03-19 17:34:07 --> Total execution time: 0.0419
ERROR - 2022-03-19 19:32:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-19 19:32:12 --> Config Class Initialized
INFO - 2022-03-19 19:32:12 --> Hooks Class Initialized
DEBUG - 2022-03-19 19:32:12 --> UTF-8 Support Enabled
INFO - 2022-03-19 19:32:12 --> Utf8 Class Initialized
INFO - 2022-03-19 19:32:12 --> URI Class Initialized
INFO - 2022-03-19 19:32:12 --> Router Class Initialized
INFO - 2022-03-19 19:32:12 --> Output Class Initialized
INFO - 2022-03-19 19:32:12 --> Security Class Initialized
DEBUG - 2022-03-19 19:32:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-19 19:32:12 --> Input Class Initialized
INFO - 2022-03-19 19:32:12 --> Language Class Initialized
ERROR - 2022-03-19 19:32:12 --> 404 Page Not Found: Git/config
ERROR - 2022-03-19 19:56:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-19 19:56:49 --> Config Class Initialized
INFO - 2022-03-19 19:56:49 --> Hooks Class Initialized
DEBUG - 2022-03-19 19:56:49 --> UTF-8 Support Enabled
INFO - 2022-03-19 19:56:49 --> Utf8 Class Initialized
INFO - 2022-03-19 19:56:49 --> URI Class Initialized
DEBUG - 2022-03-19 19:56:49 --> No URI present. Default controller set.
INFO - 2022-03-19 19:56:49 --> Router Class Initialized
INFO - 2022-03-19 19:56:49 --> Output Class Initialized
INFO - 2022-03-19 19:56:49 --> Security Class Initialized
DEBUG - 2022-03-19 19:56:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-19 19:56:49 --> Input Class Initialized
INFO - 2022-03-19 19:56:49 --> Language Class Initialized
INFO - 2022-03-19 19:56:49 --> Loader Class Initialized
INFO - 2022-03-19 19:56:49 --> Helper loaded: url_helper
INFO - 2022-03-19 19:56:49 --> Helper loaded: form_helper
INFO - 2022-03-19 19:56:49 --> Helper loaded: common_helper
INFO - 2022-03-19 19:56:49 --> Database Driver Class Initialized
DEBUG - 2022-03-19 19:56:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-19 19:56:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-19 19:56:49 --> Controller Class Initialized
INFO - 2022-03-19 19:56:49 --> Form Validation Class Initialized
DEBUG - 2022-03-19 19:56:49 --> Encrypt Class Initialized
DEBUG - 2022-03-19 19:56:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-19 19:56:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-19 19:56:49 --> Email Class Initialized
INFO - 2022-03-19 19:56:49 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-19 19:56:49 --> Calendar Class Initialized
INFO - 2022-03-19 19:56:49 --> Model "Login_model" initialized
INFO - 2022-03-19 19:56:49 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-19 19:56:49 --> Final output sent to browser
DEBUG - 2022-03-19 19:56:49 --> Total execution time: 0.0352
