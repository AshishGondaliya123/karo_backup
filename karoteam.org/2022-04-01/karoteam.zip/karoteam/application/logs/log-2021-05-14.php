<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-05-14 16:53:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 16:53:52 --> Config Class Initialized
INFO - 2021-05-14 16:53:52 --> Hooks Class Initialized
DEBUG - 2021-05-14 16:53:52 --> UTF-8 Support Enabled
INFO - 2021-05-14 16:53:52 --> Utf8 Class Initialized
INFO - 2021-05-14 16:53:52 --> URI Class Initialized
DEBUG - 2021-05-14 16:53:52 --> No URI present. Default controller set.
INFO - 2021-05-14 16:53:52 --> Router Class Initialized
INFO - 2021-05-14 16:53:52 --> Output Class Initialized
INFO - 2021-05-14 16:53:52 --> Security Class Initialized
DEBUG - 2021-05-14 16:53:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 16:53:52 --> Input Class Initialized
INFO - 2021-05-14 16:53:52 --> Language Class Initialized
INFO - 2021-05-14 16:53:52 --> Loader Class Initialized
INFO - 2021-05-14 16:53:52 --> Helper loaded: url_helper
INFO - 2021-05-14 16:53:52 --> Helper loaded: form_helper
INFO - 2021-05-14 16:53:52 --> Helper loaded: common_helper
INFO - 2021-05-14 16:53:52 --> Database Driver Class Initialized
DEBUG - 2021-05-14 16:53:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 16:53:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 16:53:52 --> Controller Class Initialized
INFO - 2021-05-14 16:53:52 --> Form Validation Class Initialized
INFO - 2021-05-14 16:53:52 --> Encrypt Class Initialized
DEBUG - 2021-05-14 16:53:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-05-14 16:53:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-05-14 16:53:52 --> Email Class Initialized
INFO - 2021-05-14 16:53:53 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-05-14 16:53:53 --> Calendar Class Initialized
INFO - 2021-05-14 16:53:53 --> Model "Login_model" initialized
INFO - 2021-05-14 16:53:53 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\login/index.php
INFO - 2021-05-14 16:53:53 --> Final output sent to browser
DEBUG - 2021-05-14 16:53:53 --> Total execution time: 0.6656
ERROR - 2021-05-14 16:55:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 16:55:44 --> Config Class Initialized
INFO - 2021-05-14 16:55:44 --> Hooks Class Initialized
DEBUG - 2021-05-14 16:55:44 --> UTF-8 Support Enabled
INFO - 2021-05-14 16:55:44 --> Utf8 Class Initialized
INFO - 2021-05-14 16:55:44 --> URI Class Initialized
INFO - 2021-05-14 16:55:44 --> Router Class Initialized
INFO - 2021-05-14 16:55:44 --> Output Class Initialized
INFO - 2021-05-14 16:55:44 --> Security Class Initialized
DEBUG - 2021-05-14 16:55:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 16:55:44 --> Input Class Initialized
INFO - 2021-05-14 16:55:44 --> Language Class Initialized
INFO - 2021-05-14 16:55:44 --> Loader Class Initialized
INFO - 2021-05-14 16:55:44 --> Helper loaded: url_helper
INFO - 2021-05-14 16:55:44 --> Helper loaded: form_helper
INFO - 2021-05-14 16:55:44 --> Helper loaded: common_helper
INFO - 2021-05-14 16:55:44 --> Database Driver Class Initialized
DEBUG - 2021-05-14 16:55:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 16:55:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 16:55:44 --> Controller Class Initialized
INFO - 2021-05-14 16:55:44 --> Form Validation Class Initialized
INFO - 2021-05-14 16:55:44 --> Encrypt Class Initialized
DEBUG - 2021-05-14 16:55:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-05-14 16:55:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-05-14 16:55:44 --> Email Class Initialized
INFO - 2021-05-14 16:55:44 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-05-14 16:55:44 --> Calendar Class Initialized
INFO - 2021-05-14 16:55:44 --> Model "Login_model" initialized
INFO - 2021-05-14 16:55:44 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2021-05-14 16:55:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 16:55:45 --> Config Class Initialized
INFO - 2021-05-14 16:55:45 --> Hooks Class Initialized
DEBUG - 2021-05-14 16:55:45 --> UTF-8 Support Enabled
INFO - 2021-05-14 16:55:45 --> Utf8 Class Initialized
INFO - 2021-05-14 16:55:45 --> URI Class Initialized
INFO - 2021-05-14 16:55:45 --> Router Class Initialized
INFO - 2021-05-14 16:55:45 --> Output Class Initialized
INFO - 2021-05-14 16:55:45 --> Security Class Initialized
DEBUG - 2021-05-14 16:55:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 16:55:45 --> Input Class Initialized
INFO - 2021-05-14 16:55:45 --> Language Class Initialized
INFO - 2021-05-14 16:55:45 --> Loader Class Initialized
INFO - 2021-05-14 16:55:45 --> Helper loaded: url_helper
INFO - 2021-05-14 16:55:45 --> Helper loaded: form_helper
INFO - 2021-05-14 16:55:45 --> Helper loaded: common_helper
INFO - 2021-05-14 16:55:45 --> Database Driver Class Initialized
DEBUG - 2021-05-14 16:55:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 16:55:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 16:55:45 --> Controller Class Initialized
INFO - 2021-05-14 16:55:45 --> Form Validation Class Initialized
INFO - 2021-05-14 16:55:45 --> Encrypt Class Initialized
INFO - 2021-05-14 16:55:45 --> Model "Login_model" initialized
INFO - 2021-05-14 16:55:45 --> Model "Dashboard_model" initialized
INFO - 2021-05-14 16:55:45 --> Model "Case_model" initialized
INFO - 2021-05-14 16:55:54 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-05-14 16:56:12 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\dashboard/index.php
INFO - 2021-05-14 16:56:12 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-05-14 16:56:12 --> Final output sent to browser
DEBUG - 2021-05-14 16:56:12 --> Total execution time: 27.6439
ERROR - 2021-05-14 16:56:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 16:56:16 --> Config Class Initialized
INFO - 2021-05-14 16:56:16 --> Hooks Class Initialized
DEBUG - 2021-05-14 16:56:16 --> UTF-8 Support Enabled
INFO - 2021-05-14 16:56:16 --> Utf8 Class Initialized
INFO - 2021-05-14 16:56:16 --> URI Class Initialized
INFO - 2021-05-14 16:56:16 --> Router Class Initialized
INFO - 2021-05-14 16:56:16 --> Output Class Initialized
INFO - 2021-05-14 16:56:16 --> Security Class Initialized
DEBUG - 2021-05-14 16:56:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 16:56:16 --> Input Class Initialized
INFO - 2021-05-14 16:56:16 --> Language Class Initialized
ERROR - 2021-05-14 16:56:16 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-05-14 17:14:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 17:14:13 --> Config Class Initialized
INFO - 2021-05-14 17:14:13 --> Hooks Class Initialized
DEBUG - 2021-05-14 17:14:13 --> UTF-8 Support Enabled
INFO - 2021-05-14 17:14:13 --> Utf8 Class Initialized
INFO - 2021-05-14 17:14:13 --> URI Class Initialized
INFO - 2021-05-14 17:14:13 --> Router Class Initialized
INFO - 2021-05-14 17:14:13 --> Output Class Initialized
INFO - 2021-05-14 17:14:13 --> Security Class Initialized
DEBUG - 2021-05-14 17:14:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 17:14:13 --> Input Class Initialized
INFO - 2021-05-14 17:14:13 --> Language Class Initialized
INFO - 2021-05-14 17:14:13 --> Loader Class Initialized
INFO - 2021-05-14 17:14:13 --> Helper loaded: url_helper
INFO - 2021-05-14 17:14:13 --> Helper loaded: form_helper
INFO - 2021-05-14 17:14:13 --> Helper loaded: common_helper
INFO - 2021-05-14 17:14:13 --> Database Driver Class Initialized
DEBUG - 2021-05-14 17:14:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 17:14:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 17:14:13 --> Controller Class Initialized
INFO - 2021-05-14 17:14:13 --> Form Validation Class Initialized
INFO - 2021-05-14 17:14:13 --> Encrypt Class Initialized
INFO - 2021-05-14 17:14:13 --> Model "Login_model" initialized
INFO - 2021-05-14 17:14:13 --> Model "Dashboard_model" initialized
INFO - 2021-05-14 17:14:13 --> Model "Case_model" initialized
INFO - 2021-05-14 17:14:20 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-05-14 17:14:35 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\dashboard/index.php
INFO - 2021-05-14 17:14:35 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-05-14 17:14:35 --> Final output sent to browser
DEBUG - 2021-05-14 17:14:35 --> Total execution time: 22.1259
ERROR - 2021-05-14 17:14:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 17:14:35 --> Config Class Initialized
INFO - 2021-05-14 17:14:35 --> Hooks Class Initialized
DEBUG - 2021-05-14 17:14:35 --> UTF-8 Support Enabled
INFO - 2021-05-14 17:14:35 --> Utf8 Class Initialized
INFO - 2021-05-14 17:14:35 --> URI Class Initialized
INFO - 2021-05-14 17:14:35 --> Router Class Initialized
INFO - 2021-05-14 17:14:35 --> Output Class Initialized
INFO - 2021-05-14 17:14:35 --> Security Class Initialized
DEBUG - 2021-05-14 17:14:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 17:14:35 --> Input Class Initialized
INFO - 2021-05-14 17:14:35 --> Language Class Initialized
ERROR - 2021-05-14 17:14:35 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-05-14 17:15:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 17:15:47 --> Config Class Initialized
INFO - 2021-05-14 17:15:47 --> Hooks Class Initialized
DEBUG - 2021-05-14 17:15:47 --> UTF-8 Support Enabled
INFO - 2021-05-14 17:15:47 --> Utf8 Class Initialized
INFO - 2021-05-14 17:15:47 --> URI Class Initialized
INFO - 2021-05-14 17:15:47 --> Router Class Initialized
INFO - 2021-05-14 17:15:47 --> Output Class Initialized
INFO - 2021-05-14 17:15:47 --> Security Class Initialized
DEBUG - 2021-05-14 17:15:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 17:15:47 --> Input Class Initialized
INFO - 2021-05-14 17:15:47 --> Language Class Initialized
INFO - 2021-05-14 17:15:47 --> Loader Class Initialized
INFO - 2021-05-14 17:15:47 --> Helper loaded: url_helper
INFO - 2021-05-14 17:15:47 --> Helper loaded: form_helper
INFO - 2021-05-14 17:15:47 --> Helper loaded: common_helper
INFO - 2021-05-14 17:15:47 --> Database Driver Class Initialized
DEBUG - 2021-05-14 17:15:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 17:15:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 17:15:47 --> Controller Class Initialized
INFO - 2021-05-14 17:15:47 --> Form Validation Class Initialized
INFO - 2021-05-14 17:15:47 --> Encrypt Class Initialized
INFO - 2021-05-14 17:15:47 --> Model "Login_model" initialized
INFO - 2021-05-14 17:15:47 --> Model "Dashboard_model" initialized
INFO - 2021-05-14 17:15:47 --> Model "Case_model" initialized
INFO - 2021-05-14 17:15:54 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-05-14 17:16:11 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\dashboard/index.php
INFO - 2021-05-14 17:16:11 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-05-14 17:16:11 --> Final output sent to browser
DEBUG - 2021-05-14 17:16:11 --> Total execution time: 24.4889
ERROR - 2021-05-14 17:16:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 17:16:12 --> Config Class Initialized
INFO - 2021-05-14 17:16:12 --> Hooks Class Initialized
DEBUG - 2021-05-14 17:16:12 --> UTF-8 Support Enabled
INFO - 2021-05-14 17:16:12 --> Utf8 Class Initialized
INFO - 2021-05-14 17:16:12 --> URI Class Initialized
INFO - 2021-05-14 17:16:12 --> Router Class Initialized
INFO - 2021-05-14 17:16:12 --> Output Class Initialized
INFO - 2021-05-14 17:16:12 --> Security Class Initialized
DEBUG - 2021-05-14 17:16:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 17:16:12 --> Input Class Initialized
INFO - 2021-05-14 17:16:12 --> Language Class Initialized
ERROR - 2021-05-14 17:16:12 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-05-14 17:18:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 17:18:00 --> Config Class Initialized
INFO - 2021-05-14 17:18:00 --> Hooks Class Initialized
DEBUG - 2021-05-14 17:18:00 --> UTF-8 Support Enabled
INFO - 2021-05-14 17:18:00 --> Utf8 Class Initialized
INFO - 2021-05-14 17:18:00 --> URI Class Initialized
INFO - 2021-05-14 17:18:00 --> Router Class Initialized
INFO - 2021-05-14 17:18:00 --> Output Class Initialized
INFO - 2021-05-14 17:18:00 --> Security Class Initialized
DEBUG - 2021-05-14 17:18:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 17:18:00 --> Input Class Initialized
INFO - 2021-05-14 17:18:00 --> Language Class Initialized
INFO - 2021-05-14 17:18:00 --> Loader Class Initialized
INFO - 2021-05-14 17:18:00 --> Helper loaded: url_helper
INFO - 2021-05-14 17:18:00 --> Helper loaded: form_helper
INFO - 2021-05-14 17:18:00 --> Helper loaded: common_helper
INFO - 2021-05-14 17:18:00 --> Database Driver Class Initialized
DEBUG - 2021-05-14 17:18:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 17:18:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 17:18:00 --> Controller Class Initialized
INFO - 2021-05-14 17:18:00 --> Form Validation Class Initialized
INFO - 2021-05-14 17:18:00 --> Encrypt Class Initialized
INFO - 2021-05-14 17:18:00 --> Model "Login_model" initialized
INFO - 2021-05-14 17:18:00 --> Model "Dashboard_model" initialized
INFO - 2021-05-14 17:18:00 --> Model "Case_model" initialized
INFO - 2021-05-14 17:18:05 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-05-14 17:18:16 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\dashboard/index.php
INFO - 2021-05-14 17:18:16 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-05-14 17:18:16 --> Final output sent to browser
DEBUG - 2021-05-14 17:18:16 --> Total execution time: 16.6375
ERROR - 2021-05-14 17:18:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 17:18:17 --> Config Class Initialized
INFO - 2021-05-14 17:18:17 --> Hooks Class Initialized
DEBUG - 2021-05-14 17:18:17 --> UTF-8 Support Enabled
INFO - 2021-05-14 17:18:17 --> Utf8 Class Initialized
INFO - 2021-05-14 17:18:17 --> URI Class Initialized
INFO - 2021-05-14 17:18:17 --> Router Class Initialized
INFO - 2021-05-14 17:18:17 --> Output Class Initialized
INFO - 2021-05-14 17:18:17 --> Security Class Initialized
DEBUG - 2021-05-14 17:18:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 17:18:17 --> Input Class Initialized
INFO - 2021-05-14 17:18:17 --> Language Class Initialized
ERROR - 2021-05-14 17:18:17 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-05-14 17:19:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 17:19:08 --> Config Class Initialized
INFO - 2021-05-14 17:19:08 --> Hooks Class Initialized
DEBUG - 2021-05-14 17:19:08 --> UTF-8 Support Enabled
INFO - 2021-05-14 17:19:08 --> Utf8 Class Initialized
INFO - 2021-05-14 17:19:08 --> URI Class Initialized
INFO - 2021-05-14 17:19:08 --> Router Class Initialized
INFO - 2021-05-14 17:19:08 --> Output Class Initialized
INFO - 2021-05-14 17:19:08 --> Security Class Initialized
DEBUG - 2021-05-14 17:19:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 17:19:08 --> Input Class Initialized
INFO - 2021-05-14 17:19:08 --> Language Class Initialized
INFO - 2021-05-14 17:19:08 --> Loader Class Initialized
INFO - 2021-05-14 17:19:08 --> Helper loaded: url_helper
INFO - 2021-05-14 17:19:08 --> Helper loaded: form_helper
INFO - 2021-05-14 17:19:08 --> Helper loaded: common_helper
INFO - 2021-05-14 17:19:08 --> Database Driver Class Initialized
DEBUG - 2021-05-14 17:19:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 17:19:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 17:19:08 --> Controller Class Initialized
INFO - 2021-05-14 17:19:08 --> Form Validation Class Initialized
INFO - 2021-05-14 17:19:08 --> Encrypt Class Initialized
INFO - 2021-05-14 17:19:08 --> Model "Login_model" initialized
INFO - 2021-05-14 17:19:08 --> Model "Dashboard_model" initialized
INFO - 2021-05-14 17:19:08 --> Model "Case_model" initialized
INFO - 2021-05-14 17:19:13 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-05-14 17:19:24 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\dashboard/index.php
INFO - 2021-05-14 17:19:24 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-05-14 17:19:24 --> Final output sent to browser
DEBUG - 2021-05-14 17:19:24 --> Total execution time: 16.0340
ERROR - 2021-05-14 17:19:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 17:19:24 --> Config Class Initialized
INFO - 2021-05-14 17:19:24 --> Hooks Class Initialized
DEBUG - 2021-05-14 17:19:24 --> UTF-8 Support Enabled
INFO - 2021-05-14 17:19:24 --> Utf8 Class Initialized
INFO - 2021-05-14 17:19:24 --> URI Class Initialized
INFO - 2021-05-14 17:19:24 --> Router Class Initialized
INFO - 2021-05-14 17:19:24 --> Output Class Initialized
INFO - 2021-05-14 17:19:24 --> Security Class Initialized
DEBUG - 2021-05-14 17:19:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 17:19:24 --> Input Class Initialized
INFO - 2021-05-14 17:19:24 --> Language Class Initialized
ERROR - 2021-05-14 17:19:24 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-05-14 17:19:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 17:19:31 --> Config Class Initialized
INFO - 2021-05-14 17:19:31 --> Hooks Class Initialized
DEBUG - 2021-05-14 17:19:31 --> UTF-8 Support Enabled
INFO - 2021-05-14 17:19:31 --> Utf8 Class Initialized
INFO - 2021-05-14 17:19:31 --> URI Class Initialized
INFO - 2021-05-14 17:19:31 --> Router Class Initialized
INFO - 2021-05-14 17:19:31 --> Output Class Initialized
INFO - 2021-05-14 17:19:31 --> Security Class Initialized
DEBUG - 2021-05-14 17:19:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 17:19:31 --> Input Class Initialized
INFO - 2021-05-14 17:19:31 --> Language Class Initialized
INFO - 2021-05-14 17:19:31 --> Loader Class Initialized
INFO - 2021-05-14 17:19:31 --> Helper loaded: url_helper
INFO - 2021-05-14 17:19:31 --> Helper loaded: form_helper
INFO - 2021-05-14 17:19:31 --> Helper loaded: common_helper
INFO - 2021-05-14 17:19:31 --> Database Driver Class Initialized
DEBUG - 2021-05-14 17:19:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 17:19:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 17:19:31 --> Controller Class Initialized
INFO - 2021-05-14 17:19:31 --> Form Validation Class Initialized
INFO - 2021-05-14 17:19:31 --> Model "Case_model" initialized
INFO - 2021-05-14 17:19:31 --> Model "Patientcase_model" initialized
INFO - 2021-05-14 17:19:34 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-05-14 17:19:34 --> Model "Case_model" initialized
INFO - 2021-05-14 17:19:36 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\cases/closed_case.php
INFO - 2021-05-14 17:19:36 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-05-14 17:19:36 --> Final output sent to browser
DEBUG - 2021-05-14 17:19:36 --> Total execution time: 5.1423
ERROR - 2021-05-14 17:19:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 17:19:36 --> Config Class Initialized
INFO - 2021-05-14 17:19:36 --> Hooks Class Initialized
DEBUG - 2021-05-14 17:19:36 --> UTF-8 Support Enabled
INFO - 2021-05-14 17:19:36 --> Utf8 Class Initialized
INFO - 2021-05-14 17:19:36 --> URI Class Initialized
INFO - 2021-05-14 17:19:36 --> Router Class Initialized
INFO - 2021-05-14 17:19:36 --> Output Class Initialized
INFO - 2021-05-14 17:19:36 --> Security Class Initialized
DEBUG - 2021-05-14 17:19:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 17:19:36 --> Input Class Initialized
INFO - 2021-05-14 17:19:36 --> Language Class Initialized
ERROR - 2021-05-14 17:19:36 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-05-14 17:19:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 17:19:52 --> Config Class Initialized
INFO - 2021-05-14 17:19:52 --> Hooks Class Initialized
DEBUG - 2021-05-14 17:19:52 --> UTF-8 Support Enabled
INFO - 2021-05-14 17:19:52 --> Utf8 Class Initialized
INFO - 2021-05-14 17:19:52 --> URI Class Initialized
DEBUG - 2021-05-14 17:19:52 --> No URI present. Default controller set.
INFO - 2021-05-14 17:19:52 --> Router Class Initialized
INFO - 2021-05-14 17:19:52 --> Output Class Initialized
INFO - 2021-05-14 17:19:52 --> Security Class Initialized
DEBUG - 2021-05-14 17:19:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 17:19:52 --> Input Class Initialized
INFO - 2021-05-14 17:19:52 --> Language Class Initialized
INFO - 2021-05-14 17:19:52 --> Loader Class Initialized
INFO - 2021-05-14 17:19:52 --> Helper loaded: url_helper
INFO - 2021-05-14 17:19:52 --> Helper loaded: form_helper
INFO - 2021-05-14 17:19:52 --> Helper loaded: common_helper
INFO - 2021-05-14 17:19:52 --> Database Driver Class Initialized
DEBUG - 2021-05-14 17:19:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 17:19:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 17:19:52 --> Controller Class Initialized
INFO - 2021-05-14 17:19:52 --> Form Validation Class Initialized
INFO - 2021-05-14 17:19:52 --> Encrypt Class Initialized
DEBUG - 2021-05-14 17:19:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-05-14 17:19:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-05-14 17:19:52 --> Email Class Initialized
INFO - 2021-05-14 17:19:52 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-05-14 17:19:52 --> Calendar Class Initialized
INFO - 2021-05-14 17:19:52 --> Model "Login_model" initialized
ERROR - 2021-05-14 17:19:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 17:19:52 --> Config Class Initialized
INFO - 2021-05-14 17:19:52 --> Hooks Class Initialized
DEBUG - 2021-05-14 17:19:52 --> UTF-8 Support Enabled
INFO - 2021-05-14 17:19:52 --> Utf8 Class Initialized
INFO - 2021-05-14 17:19:52 --> URI Class Initialized
INFO - 2021-05-14 17:19:52 --> Router Class Initialized
INFO - 2021-05-14 17:19:52 --> Output Class Initialized
INFO - 2021-05-14 17:19:52 --> Security Class Initialized
DEBUG - 2021-05-14 17:19:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 17:19:52 --> Input Class Initialized
INFO - 2021-05-14 17:19:52 --> Language Class Initialized
INFO - 2021-05-14 17:19:52 --> Loader Class Initialized
INFO - 2021-05-14 17:19:52 --> Helper loaded: url_helper
INFO - 2021-05-14 17:19:52 --> Helper loaded: form_helper
INFO - 2021-05-14 17:19:52 --> Helper loaded: common_helper
INFO - 2021-05-14 17:19:52 --> Database Driver Class Initialized
DEBUG - 2021-05-14 17:19:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 17:19:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 17:19:52 --> Controller Class Initialized
INFO - 2021-05-14 17:19:52 --> Form Validation Class Initialized
INFO - 2021-05-14 17:19:52 --> Encrypt Class Initialized
INFO - 2021-05-14 17:19:52 --> Model "Diseases_model" initialized
INFO - 2021-05-14 17:19:52 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-05-14 17:19:52 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\diseases/index.php
INFO - 2021-05-14 17:19:52 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-05-14 17:19:52 --> Final output sent to browser
DEBUG - 2021-05-14 17:19:52 --> Total execution time: 0.1550
ERROR - 2021-05-14 17:23:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 17:23:33 --> Config Class Initialized
INFO - 2021-05-14 17:23:33 --> Hooks Class Initialized
DEBUG - 2021-05-14 17:23:33 --> UTF-8 Support Enabled
INFO - 2021-05-14 17:23:33 --> Utf8 Class Initialized
INFO - 2021-05-14 17:23:33 --> URI Class Initialized
INFO - 2021-05-14 17:23:33 --> Router Class Initialized
INFO - 2021-05-14 17:23:33 --> Output Class Initialized
INFO - 2021-05-14 17:23:33 --> Security Class Initialized
DEBUG - 2021-05-14 17:23:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 17:23:33 --> Input Class Initialized
INFO - 2021-05-14 17:23:33 --> Language Class Initialized
INFO - 2021-05-14 17:23:33 --> Loader Class Initialized
INFO - 2021-05-14 17:23:33 --> Helper loaded: url_helper
INFO - 2021-05-14 17:23:33 --> Helper loaded: form_helper
INFO - 2021-05-14 17:23:33 --> Helper loaded: common_helper
INFO - 2021-05-14 17:23:33 --> Database Driver Class Initialized
DEBUG - 2021-05-14 17:23:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 17:23:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 17:23:33 --> Controller Class Initialized
INFO - 2021-05-14 17:23:33 --> Form Validation Class Initialized
INFO - 2021-05-14 17:23:33 --> Encrypt Class Initialized
INFO - 2021-05-14 17:23:33 --> Model "Diseases_model" initialized
INFO - 2021-05-14 17:23:33 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-05-14 17:23:33 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\diseases/index.php
INFO - 2021-05-14 17:23:33 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-05-14 17:23:33 --> Final output sent to browser
DEBUG - 2021-05-14 17:23:33 --> Total execution time: 0.0652
ERROR - 2021-05-14 17:23:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 17:23:35 --> Config Class Initialized
INFO - 2021-05-14 17:23:35 --> Hooks Class Initialized
DEBUG - 2021-05-14 17:23:35 --> UTF-8 Support Enabled
INFO - 2021-05-14 17:23:35 --> Utf8 Class Initialized
INFO - 2021-05-14 17:23:35 --> URI Class Initialized
INFO - 2021-05-14 17:23:35 --> Router Class Initialized
INFO - 2021-05-14 17:23:35 --> Output Class Initialized
INFO - 2021-05-14 17:23:35 --> Security Class Initialized
DEBUG - 2021-05-14 17:23:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 17:23:35 --> Input Class Initialized
INFO - 2021-05-14 17:23:35 --> Language Class Initialized
INFO - 2021-05-14 17:23:35 --> Loader Class Initialized
INFO - 2021-05-14 17:23:35 --> Helper loaded: url_helper
INFO - 2021-05-14 17:23:35 --> Helper loaded: form_helper
INFO - 2021-05-14 17:23:35 --> Helper loaded: common_helper
INFO - 2021-05-14 17:23:35 --> Database Driver Class Initialized
DEBUG - 2021-05-14 17:23:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 17:23:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 17:23:35 --> Controller Class Initialized
INFO - 2021-05-14 17:23:35 --> Form Validation Class Initialized
INFO - 2021-05-14 17:23:35 --> Encrypt Class Initialized
INFO - 2021-05-14 17:23:35 --> Model "Login_model" initialized
INFO - 2021-05-14 17:23:35 --> Model "Dashboard_model" initialized
INFO - 2021-05-14 17:23:35 --> Model "Case_model" initialized
ERROR - 2021-05-14 17:23:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 17:23:39 --> Config Class Initialized
INFO - 2021-05-14 17:23:39 --> Hooks Class Initialized
DEBUG - 2021-05-14 17:23:39 --> UTF-8 Support Enabled
INFO - 2021-05-14 17:23:39 --> Utf8 Class Initialized
INFO - 2021-05-14 17:23:39 --> URI Class Initialized
INFO - 2021-05-14 17:23:39 --> Router Class Initialized
INFO - 2021-05-14 17:23:39 --> Output Class Initialized
INFO - 2021-05-14 17:23:39 --> Security Class Initialized
DEBUG - 2021-05-14 17:23:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 17:23:39 --> Input Class Initialized
INFO - 2021-05-14 17:23:39 --> Language Class Initialized
INFO - 2021-05-14 17:23:39 --> Loader Class Initialized
INFO - 2021-05-14 17:23:39 --> Helper loaded: url_helper
INFO - 2021-05-14 17:23:39 --> Helper loaded: form_helper
INFO - 2021-05-14 17:23:39 --> Helper loaded: common_helper
INFO - 2021-05-14 17:23:39 --> Database Driver Class Initialized
DEBUG - 2021-05-14 17:23:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 17:23:40 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-05-14 17:23:50 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\dashboard/index.php
INFO - 2021-05-14 17:23:50 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-05-14 17:23:50 --> Final output sent to browser
DEBUG - 2021-05-14 17:23:50 --> Total execution time: 15.7607
INFO - 2021-05-14 17:23:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 17:23:50 --> Controller Class Initialized
INFO - 2021-05-14 17:23:50 --> Form Validation Class Initialized
INFO - 2021-05-14 17:23:50 --> Encrypt Class Initialized
INFO - 2021-05-14 17:23:50 --> Model "Login_model" initialized
INFO - 2021-05-14 17:23:50 --> Model "Dashboard_model" initialized
INFO - 2021-05-14 17:23:50 --> Model "Case_model" initialized
INFO - 2021-05-14 17:23:55 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-05-14 17:24:06 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\dashboard/index.php
INFO - 2021-05-14 17:24:06 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-05-14 17:24:06 --> Final output sent to browser
DEBUG - 2021-05-14 17:24:06 --> Total execution time: 26.8997
ERROR - 2021-05-14 17:24:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 17:24:06 --> Config Class Initialized
INFO - 2021-05-14 17:24:06 --> Hooks Class Initialized
DEBUG - 2021-05-14 17:24:06 --> UTF-8 Support Enabled
INFO - 2021-05-14 17:24:06 --> Utf8 Class Initialized
INFO - 2021-05-14 17:24:06 --> URI Class Initialized
INFO - 2021-05-14 17:24:06 --> Router Class Initialized
INFO - 2021-05-14 17:24:06 --> Output Class Initialized
INFO - 2021-05-14 17:24:06 --> Security Class Initialized
DEBUG - 2021-05-14 17:24:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 17:24:06 --> Input Class Initialized
INFO - 2021-05-14 17:24:06 --> Language Class Initialized
ERROR - 2021-05-14 17:24:06 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-05-14 17:26:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 17:26:14 --> Config Class Initialized
INFO - 2021-05-14 17:26:14 --> Hooks Class Initialized
DEBUG - 2021-05-14 17:26:14 --> UTF-8 Support Enabled
INFO - 2021-05-14 17:26:14 --> Utf8 Class Initialized
INFO - 2021-05-14 17:26:14 --> URI Class Initialized
INFO - 2021-05-14 17:26:14 --> Router Class Initialized
INFO - 2021-05-14 17:26:14 --> Output Class Initialized
INFO - 2021-05-14 17:26:14 --> Security Class Initialized
DEBUG - 2021-05-14 17:26:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 17:26:14 --> Input Class Initialized
INFO - 2021-05-14 17:26:14 --> Language Class Initialized
INFO - 2021-05-14 17:26:14 --> Loader Class Initialized
INFO - 2021-05-14 17:26:14 --> Helper loaded: url_helper
INFO - 2021-05-14 17:26:14 --> Helper loaded: form_helper
INFO - 2021-05-14 17:26:14 --> Helper loaded: common_helper
INFO - 2021-05-14 17:26:14 --> Database Driver Class Initialized
DEBUG - 2021-05-14 17:26:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 17:26:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 17:26:14 --> Controller Class Initialized
INFO - 2021-05-14 17:26:14 --> Form Validation Class Initialized
INFO - 2021-05-14 17:26:14 --> Model "Case_model" initialized
INFO - 2021-05-14 17:26:14 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-05-14 17:26:14 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\transaction/upcomingFollowup.php
INFO - 2021-05-14 17:26:14 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-05-14 17:26:14 --> Final output sent to browser
DEBUG - 2021-05-14 17:26:14 --> Total execution time: 0.0474
ERROR - 2021-05-14 17:26:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 17:26:14 --> Config Class Initialized
INFO - 2021-05-14 17:26:14 --> Hooks Class Initialized
DEBUG - 2021-05-14 17:26:14 --> UTF-8 Support Enabled
INFO - 2021-05-14 17:26:14 --> Utf8 Class Initialized
INFO - 2021-05-14 17:26:14 --> URI Class Initialized
INFO - 2021-05-14 17:26:14 --> Router Class Initialized
INFO - 2021-05-14 17:26:14 --> Output Class Initialized
INFO - 2021-05-14 17:26:14 --> Security Class Initialized
DEBUG - 2021-05-14 17:26:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 17:26:14 --> Input Class Initialized
INFO - 2021-05-14 17:26:14 --> Language Class Initialized
ERROR - 2021-05-14 17:26:14 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-05-14 17:48:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 17:48:37 --> Config Class Initialized
INFO - 2021-05-14 17:48:37 --> Hooks Class Initialized
DEBUG - 2021-05-14 17:48:37 --> UTF-8 Support Enabled
INFO - 2021-05-14 17:48:37 --> Utf8 Class Initialized
INFO - 2021-05-14 17:48:37 --> URI Class Initialized
INFO - 2021-05-14 17:48:37 --> Router Class Initialized
INFO - 2021-05-14 17:48:37 --> Output Class Initialized
INFO - 2021-05-14 17:48:37 --> Security Class Initialized
DEBUG - 2021-05-14 17:48:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 17:48:37 --> Input Class Initialized
INFO - 2021-05-14 17:48:37 --> Language Class Initialized
INFO - 2021-05-14 17:48:37 --> Loader Class Initialized
INFO - 2021-05-14 17:48:37 --> Helper loaded: url_helper
INFO - 2021-05-14 17:48:37 --> Helper loaded: form_helper
INFO - 2021-05-14 17:48:37 --> Helper loaded: common_helper
INFO - 2021-05-14 17:48:37 --> Database Driver Class Initialized
DEBUG - 2021-05-14 17:48:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 17:48:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 17:48:37 --> Controller Class Initialized
INFO - 2021-05-14 17:48:37 --> Form Validation Class Initialized
INFO - 2021-05-14 17:48:37 --> Model "Case_model" initialized
INFO - 2021-05-14 17:48:38 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-05-14 17:48:38 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\transaction/donner_donation.php
INFO - 2021-05-14 17:48:38 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-05-14 17:48:38 --> Final output sent to browser
DEBUG - 2021-05-14 17:48:38 --> Total execution time: 0.1833
ERROR - 2021-05-14 17:48:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 17:48:38 --> Config Class Initialized
INFO - 2021-05-14 17:48:38 --> Hooks Class Initialized
DEBUG - 2021-05-14 17:48:38 --> UTF-8 Support Enabled
INFO - 2021-05-14 17:48:38 --> Utf8 Class Initialized
INFO - 2021-05-14 17:48:38 --> URI Class Initialized
INFO - 2021-05-14 17:48:38 --> Router Class Initialized
INFO - 2021-05-14 17:48:38 --> Output Class Initialized
INFO - 2021-05-14 17:48:38 --> Security Class Initialized
DEBUG - 2021-05-14 17:48:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 17:48:38 --> Input Class Initialized
INFO - 2021-05-14 17:48:38 --> Language Class Initialized
ERROR - 2021-05-14 17:48:38 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-05-14 17:49:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 17:49:48 --> Config Class Initialized
INFO - 2021-05-14 17:49:48 --> Hooks Class Initialized
DEBUG - 2021-05-14 17:49:48 --> UTF-8 Support Enabled
INFO - 2021-05-14 17:49:48 --> Utf8 Class Initialized
INFO - 2021-05-14 17:49:48 --> URI Class Initialized
INFO - 2021-05-14 17:49:48 --> Router Class Initialized
INFO - 2021-05-14 17:49:48 --> Output Class Initialized
INFO - 2021-05-14 17:49:48 --> Security Class Initialized
DEBUG - 2021-05-14 17:49:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 17:49:48 --> Input Class Initialized
INFO - 2021-05-14 17:49:48 --> Language Class Initialized
INFO - 2021-05-14 17:49:48 --> Loader Class Initialized
INFO - 2021-05-14 17:49:48 --> Helper loaded: url_helper
INFO - 2021-05-14 17:49:48 --> Helper loaded: form_helper
INFO - 2021-05-14 17:49:48 --> Helper loaded: common_helper
INFO - 2021-05-14 17:49:48 --> Database Driver Class Initialized
DEBUG - 2021-05-14 17:49:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 17:49:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 17:49:48 --> Controller Class Initialized
INFO - 2021-05-14 17:49:48 --> Form Validation Class Initialized
INFO - 2021-05-14 17:49:48 --> Model "Case_model" initialized
INFO - 2021-05-14 17:49:48 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
ERROR - 2021-05-14 17:49:48 --> Severity: error --> Exception: Call to undefined function money_format() C:\xampp\htdocs\study\karosoftware\application\helpers\common_helper.php 19
ERROR - 2021-05-14 17:53:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 17:53:36 --> Config Class Initialized
INFO - 2021-05-14 17:53:36 --> Hooks Class Initialized
DEBUG - 2021-05-14 17:53:36 --> UTF-8 Support Enabled
INFO - 2021-05-14 17:53:36 --> Utf8 Class Initialized
INFO - 2021-05-14 17:53:36 --> URI Class Initialized
INFO - 2021-05-14 17:53:36 --> Router Class Initialized
INFO - 2021-05-14 17:53:36 --> Output Class Initialized
INFO - 2021-05-14 17:53:36 --> Security Class Initialized
DEBUG - 2021-05-14 17:53:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 17:53:36 --> Input Class Initialized
INFO - 2021-05-14 17:53:36 --> Language Class Initialized
INFO - 2021-05-14 17:53:36 --> Loader Class Initialized
INFO - 2021-05-14 17:53:36 --> Helper loaded: url_helper
INFO - 2021-05-14 17:53:36 --> Helper loaded: form_helper
INFO - 2021-05-14 17:53:36 --> Helper loaded: common_helper
INFO - 2021-05-14 17:53:36 --> Database Driver Class Initialized
DEBUG - 2021-05-14 17:53:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 17:53:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 17:53:36 --> Controller Class Initialized
INFO - 2021-05-14 17:53:36 --> Form Validation Class Initialized
INFO - 2021-05-14 17:53:36 --> Model "Case_model" initialized
INFO - 2021-05-14 17:53:36 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
ERROR - 2021-05-14 17:53:36 --> Severity: error --> Exception: Call to undefined function money_format() C:\xampp\htdocs\study\karosoftware\application\helpers\common_helper.php 21
ERROR - 2021-05-14 17:55:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 17:55:49 --> Config Class Initialized
INFO - 2021-05-14 17:55:49 --> Hooks Class Initialized
DEBUG - 2021-05-14 17:55:49 --> UTF-8 Support Enabled
INFO - 2021-05-14 17:55:49 --> Utf8 Class Initialized
INFO - 2021-05-14 17:55:49 --> URI Class Initialized
INFO - 2021-05-14 17:55:49 --> Router Class Initialized
INFO - 2021-05-14 17:55:49 --> Output Class Initialized
INFO - 2021-05-14 17:55:49 --> Security Class Initialized
DEBUG - 2021-05-14 17:55:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 17:55:49 --> Input Class Initialized
INFO - 2021-05-14 17:55:49 --> Language Class Initialized
INFO - 2021-05-14 17:55:49 --> Loader Class Initialized
INFO - 2021-05-14 17:55:49 --> Helper loaded: url_helper
INFO - 2021-05-14 17:55:49 --> Helper loaded: form_helper
INFO - 2021-05-14 17:55:49 --> Helper loaded: common_helper
INFO - 2021-05-14 17:55:49 --> Database Driver Class Initialized
DEBUG - 2021-05-14 17:55:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 17:55:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 17:55:49 --> Controller Class Initialized
INFO - 2021-05-14 17:55:49 --> Form Validation Class Initialized
INFO - 2021-05-14 17:55:49 --> Model "Case_model" initialized
INFO - 2021-05-14 17:55:49 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-05-14 17:55:49 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\transaction/donner_donation.php
INFO - 2021-05-14 17:55:49 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-05-14 17:55:49 --> Final output sent to browser
DEBUG - 2021-05-14 17:55:49 --> Total execution time: 0.0623
ERROR - 2021-05-14 17:55:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 17:55:49 --> Config Class Initialized
INFO - 2021-05-14 17:55:49 --> Hooks Class Initialized
DEBUG - 2021-05-14 17:55:49 --> UTF-8 Support Enabled
INFO - 2021-05-14 17:55:49 --> Utf8 Class Initialized
INFO - 2021-05-14 17:55:49 --> URI Class Initialized
INFO - 2021-05-14 17:55:49 --> Router Class Initialized
INFO - 2021-05-14 17:55:49 --> Output Class Initialized
INFO - 2021-05-14 17:55:49 --> Security Class Initialized
DEBUG - 2021-05-14 17:55:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 17:55:49 --> Input Class Initialized
INFO - 2021-05-14 17:55:49 --> Language Class Initialized
ERROR - 2021-05-14 17:55:49 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-05-14 17:56:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 17:56:10 --> Config Class Initialized
INFO - 2021-05-14 17:56:10 --> Hooks Class Initialized
DEBUG - 2021-05-14 17:56:10 --> UTF-8 Support Enabled
INFO - 2021-05-14 17:56:10 --> Utf8 Class Initialized
INFO - 2021-05-14 17:56:10 --> URI Class Initialized
INFO - 2021-05-14 17:56:10 --> Router Class Initialized
INFO - 2021-05-14 17:56:10 --> Output Class Initialized
INFO - 2021-05-14 17:56:10 --> Security Class Initialized
DEBUG - 2021-05-14 17:56:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 17:56:10 --> Input Class Initialized
INFO - 2021-05-14 17:56:10 --> Language Class Initialized
INFO - 2021-05-14 17:56:10 --> Loader Class Initialized
INFO - 2021-05-14 17:56:10 --> Helper loaded: url_helper
INFO - 2021-05-14 17:56:10 --> Helper loaded: form_helper
INFO - 2021-05-14 17:56:10 --> Helper loaded: common_helper
INFO - 2021-05-14 17:56:10 --> Database Driver Class Initialized
DEBUG - 2021-05-14 17:56:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 17:56:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 17:56:10 --> Controller Class Initialized
INFO - 2021-05-14 17:56:10 --> Form Validation Class Initialized
INFO - 2021-05-14 17:56:10 --> Model "Case_model" initialized
INFO - 2021-05-14 17:56:10 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-05-14 17:56:10 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\transaction/donner_donation.php
INFO - 2021-05-14 17:56:10 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-05-14 17:56:10 --> Final output sent to browser
DEBUG - 2021-05-14 17:56:10 --> Total execution time: 0.0534
ERROR - 2021-05-14 17:56:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 17:56:10 --> Config Class Initialized
INFO - 2021-05-14 17:56:10 --> Hooks Class Initialized
DEBUG - 2021-05-14 17:56:10 --> UTF-8 Support Enabled
INFO - 2021-05-14 17:56:10 --> Utf8 Class Initialized
INFO - 2021-05-14 17:56:10 --> URI Class Initialized
INFO - 2021-05-14 17:56:10 --> Router Class Initialized
INFO - 2021-05-14 17:56:10 --> Output Class Initialized
INFO - 2021-05-14 17:56:10 --> Security Class Initialized
DEBUG - 2021-05-14 17:56:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 17:56:10 --> Input Class Initialized
INFO - 2021-05-14 17:56:10 --> Language Class Initialized
ERROR - 2021-05-14 17:56:10 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-05-14 17:56:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 17:56:33 --> Config Class Initialized
INFO - 2021-05-14 17:56:33 --> Hooks Class Initialized
DEBUG - 2021-05-14 17:56:33 --> UTF-8 Support Enabled
INFO - 2021-05-14 17:56:33 --> Utf8 Class Initialized
INFO - 2021-05-14 17:56:33 --> URI Class Initialized
INFO - 2021-05-14 17:56:33 --> Router Class Initialized
INFO - 2021-05-14 17:56:33 --> Output Class Initialized
INFO - 2021-05-14 17:56:33 --> Security Class Initialized
DEBUG - 2021-05-14 17:56:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 17:56:33 --> Input Class Initialized
INFO - 2021-05-14 17:56:33 --> Language Class Initialized
INFO - 2021-05-14 17:56:33 --> Loader Class Initialized
INFO - 2021-05-14 17:56:33 --> Helper loaded: url_helper
INFO - 2021-05-14 17:56:33 --> Helper loaded: form_helper
INFO - 2021-05-14 17:56:33 --> Helper loaded: common_helper
INFO - 2021-05-14 17:56:33 --> Database Driver Class Initialized
DEBUG - 2021-05-14 17:56:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 17:56:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 17:56:33 --> Controller Class Initialized
INFO - 2021-05-14 17:56:33 --> Form Validation Class Initialized
INFO - 2021-05-14 17:56:33 --> Model "Case_model" initialized
INFO - 2021-05-14 17:56:33 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-05-14 17:56:33 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\transaction/donner_donation.php
INFO - 2021-05-14 17:56:33 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-05-14 17:56:33 --> Final output sent to browser
DEBUG - 2021-05-14 17:56:33 --> Total execution time: 0.0783
ERROR - 2021-05-14 17:56:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 17:56:33 --> Config Class Initialized
INFO - 2021-05-14 17:56:33 --> Hooks Class Initialized
DEBUG - 2021-05-14 17:56:33 --> UTF-8 Support Enabled
INFO - 2021-05-14 17:56:33 --> Utf8 Class Initialized
INFO - 2021-05-14 17:56:33 --> URI Class Initialized
INFO - 2021-05-14 17:56:33 --> Router Class Initialized
INFO - 2021-05-14 17:56:33 --> Output Class Initialized
INFO - 2021-05-14 17:56:33 --> Security Class Initialized
DEBUG - 2021-05-14 17:56:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 17:56:33 --> Input Class Initialized
INFO - 2021-05-14 17:56:33 --> Language Class Initialized
ERROR - 2021-05-14 17:56:33 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-05-14 17:57:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 17:57:09 --> Config Class Initialized
INFO - 2021-05-14 17:57:09 --> Hooks Class Initialized
DEBUG - 2021-05-14 17:57:09 --> UTF-8 Support Enabled
INFO - 2021-05-14 17:57:09 --> Utf8 Class Initialized
INFO - 2021-05-14 17:57:09 --> URI Class Initialized
INFO - 2021-05-14 17:57:09 --> Router Class Initialized
INFO - 2021-05-14 17:57:09 --> Output Class Initialized
INFO - 2021-05-14 17:57:09 --> Security Class Initialized
DEBUG - 2021-05-14 17:57:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 17:57:09 --> Input Class Initialized
INFO - 2021-05-14 17:57:09 --> Language Class Initialized
INFO - 2021-05-14 17:57:09 --> Loader Class Initialized
INFO - 2021-05-14 17:57:09 --> Helper loaded: url_helper
INFO - 2021-05-14 17:57:09 --> Helper loaded: form_helper
INFO - 2021-05-14 17:57:09 --> Helper loaded: common_helper
INFO - 2021-05-14 17:57:09 --> Database Driver Class Initialized
DEBUG - 2021-05-14 17:57:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 17:57:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 17:57:09 --> Controller Class Initialized
INFO - 2021-05-14 17:57:09 --> Form Validation Class Initialized
INFO - 2021-05-14 17:57:09 --> Model "Case_model" initialized
INFO - 2021-05-14 17:57:09 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-05-14 17:57:09 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\transaction/donner_donation.php
INFO - 2021-05-14 17:57:09 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-05-14 17:57:09 --> Final output sent to browser
DEBUG - 2021-05-14 17:57:09 --> Total execution time: 0.0494
ERROR - 2021-05-14 17:57:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 17:57:10 --> Config Class Initialized
INFO - 2021-05-14 17:57:10 --> Hooks Class Initialized
DEBUG - 2021-05-14 17:57:10 --> UTF-8 Support Enabled
INFO - 2021-05-14 17:57:10 --> Utf8 Class Initialized
INFO - 2021-05-14 17:57:10 --> URI Class Initialized
INFO - 2021-05-14 17:57:10 --> Router Class Initialized
INFO - 2021-05-14 17:57:10 --> Output Class Initialized
INFO - 2021-05-14 17:57:10 --> Security Class Initialized
DEBUG - 2021-05-14 17:57:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 17:57:10 --> Input Class Initialized
INFO - 2021-05-14 17:57:10 --> Language Class Initialized
ERROR - 2021-05-14 17:57:10 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-05-14 17:59:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 17:59:52 --> Config Class Initialized
INFO - 2021-05-14 17:59:52 --> Hooks Class Initialized
DEBUG - 2021-05-14 17:59:52 --> UTF-8 Support Enabled
INFO - 2021-05-14 17:59:52 --> Utf8 Class Initialized
INFO - 2021-05-14 17:59:52 --> URI Class Initialized
INFO - 2021-05-14 17:59:52 --> Router Class Initialized
INFO - 2021-05-14 17:59:52 --> Output Class Initialized
INFO - 2021-05-14 17:59:52 --> Security Class Initialized
DEBUG - 2021-05-14 17:59:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 17:59:52 --> Input Class Initialized
INFO - 2021-05-14 17:59:52 --> Language Class Initialized
INFO - 2021-05-14 17:59:52 --> Loader Class Initialized
INFO - 2021-05-14 17:59:52 --> Helper loaded: url_helper
INFO - 2021-05-14 17:59:52 --> Helper loaded: form_helper
INFO - 2021-05-14 17:59:52 --> Helper loaded: common_helper
INFO - 2021-05-14 17:59:52 --> Database Driver Class Initialized
DEBUG - 2021-05-14 17:59:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 17:59:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 17:59:52 --> Controller Class Initialized
INFO - 2021-05-14 17:59:52 --> Form Validation Class Initialized
INFO - 2021-05-14 17:59:52 --> Model "Case_model" initialized
INFO - 2021-05-14 17:59:52 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-05-14 17:59:52 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\transaction/donner_donation.php
INFO - 2021-05-14 17:59:52 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-05-14 17:59:52 --> Final output sent to browser
DEBUG - 2021-05-14 17:59:52 --> Total execution time: 0.0504
ERROR - 2021-05-14 17:59:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 17:59:54 --> Config Class Initialized
INFO - 2021-05-14 17:59:54 --> Hooks Class Initialized
DEBUG - 2021-05-14 17:59:54 --> UTF-8 Support Enabled
INFO - 2021-05-14 17:59:54 --> Utf8 Class Initialized
INFO - 2021-05-14 17:59:54 --> URI Class Initialized
INFO - 2021-05-14 17:59:54 --> Router Class Initialized
INFO - 2021-05-14 17:59:54 --> Output Class Initialized
INFO - 2021-05-14 17:59:54 --> Security Class Initialized
DEBUG - 2021-05-14 17:59:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 17:59:54 --> Input Class Initialized
INFO - 2021-05-14 17:59:54 --> Language Class Initialized
ERROR - 2021-05-14 17:59:54 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-05-14 18:01:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 18:01:15 --> Config Class Initialized
INFO - 2021-05-14 18:01:15 --> Hooks Class Initialized
DEBUG - 2021-05-14 18:01:15 --> UTF-8 Support Enabled
INFO - 2021-05-14 18:01:15 --> Utf8 Class Initialized
INFO - 2021-05-14 18:01:15 --> URI Class Initialized
INFO - 2021-05-14 18:01:15 --> Router Class Initialized
INFO - 2021-05-14 18:01:15 --> Output Class Initialized
INFO - 2021-05-14 18:01:15 --> Security Class Initialized
DEBUG - 2021-05-14 18:01:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 18:01:15 --> Input Class Initialized
INFO - 2021-05-14 18:01:15 --> Language Class Initialized
INFO - 2021-05-14 18:01:15 --> Loader Class Initialized
INFO - 2021-05-14 18:01:15 --> Helper loaded: url_helper
INFO - 2021-05-14 18:01:15 --> Helper loaded: form_helper
INFO - 2021-05-14 18:01:15 --> Helper loaded: common_helper
INFO - 2021-05-14 18:01:15 --> Database Driver Class Initialized
DEBUG - 2021-05-14 18:01:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 18:01:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 18:01:15 --> Controller Class Initialized
INFO - 2021-05-14 18:01:15 --> Form Validation Class Initialized
INFO - 2021-05-14 18:01:15 --> Model "Case_model" initialized
INFO - 2021-05-14 18:01:15 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-05-14 18:01:15 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\transaction/donner_donation.php
INFO - 2021-05-14 18:01:15 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-05-14 18:01:15 --> Final output sent to browser
DEBUG - 2021-05-14 18:01:15 --> Total execution time: 0.0608
ERROR - 2021-05-14 18:01:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 18:01:17 --> Config Class Initialized
INFO - 2021-05-14 18:01:17 --> Hooks Class Initialized
DEBUG - 2021-05-14 18:01:17 --> UTF-8 Support Enabled
INFO - 2021-05-14 18:01:17 --> Utf8 Class Initialized
INFO - 2021-05-14 18:01:17 --> URI Class Initialized
INFO - 2021-05-14 18:01:17 --> Router Class Initialized
INFO - 2021-05-14 18:01:17 --> Output Class Initialized
INFO - 2021-05-14 18:01:17 --> Security Class Initialized
DEBUG - 2021-05-14 18:01:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 18:01:17 --> Input Class Initialized
INFO - 2021-05-14 18:01:17 --> Language Class Initialized
ERROR - 2021-05-14 18:01:17 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-05-14 18:06:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 18:06:22 --> Config Class Initialized
INFO - 2021-05-14 18:06:22 --> Hooks Class Initialized
DEBUG - 2021-05-14 18:06:22 --> UTF-8 Support Enabled
INFO - 2021-05-14 18:06:22 --> Utf8 Class Initialized
INFO - 2021-05-14 18:06:22 --> URI Class Initialized
INFO - 2021-05-14 18:06:22 --> Router Class Initialized
INFO - 2021-05-14 18:06:22 --> Output Class Initialized
INFO - 2021-05-14 18:06:22 --> Security Class Initialized
DEBUG - 2021-05-14 18:06:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 18:06:22 --> Input Class Initialized
INFO - 2021-05-14 18:06:22 --> Language Class Initialized
INFO - 2021-05-14 18:06:22 --> Loader Class Initialized
INFO - 2021-05-14 18:06:22 --> Helper loaded: url_helper
INFO - 2021-05-14 18:06:22 --> Helper loaded: form_helper
INFO - 2021-05-14 18:06:22 --> Helper loaded: common_helper
INFO - 2021-05-14 18:06:22 --> Database Driver Class Initialized
DEBUG - 2021-05-14 18:06:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 18:06:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 18:06:22 --> Controller Class Initialized
INFO - 2021-05-14 18:06:22 --> Form Validation Class Initialized
INFO - 2021-05-14 18:06:22 --> Model "Case_model" initialized
INFO - 2021-05-14 18:06:22 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-05-14 18:06:22 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\transaction/donner_donation.php
INFO - 2021-05-14 18:06:22 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-05-14 18:06:22 --> Final output sent to browser
DEBUG - 2021-05-14 18:06:22 --> Total execution time: 0.1393
ERROR - 2021-05-14 18:06:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 18:06:23 --> Config Class Initialized
INFO - 2021-05-14 18:06:23 --> Hooks Class Initialized
DEBUG - 2021-05-14 18:06:23 --> UTF-8 Support Enabled
INFO - 2021-05-14 18:06:23 --> Utf8 Class Initialized
INFO - 2021-05-14 18:06:23 --> URI Class Initialized
INFO - 2021-05-14 18:06:23 --> Router Class Initialized
INFO - 2021-05-14 18:06:23 --> Output Class Initialized
INFO - 2021-05-14 18:06:23 --> Security Class Initialized
DEBUG - 2021-05-14 18:06:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 18:06:23 --> Input Class Initialized
INFO - 2021-05-14 18:06:23 --> Language Class Initialized
ERROR - 2021-05-14 18:06:23 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-05-14 18:06:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 18:06:34 --> Config Class Initialized
INFO - 2021-05-14 18:06:34 --> Hooks Class Initialized
DEBUG - 2021-05-14 18:06:34 --> UTF-8 Support Enabled
INFO - 2021-05-14 18:06:34 --> Utf8 Class Initialized
INFO - 2021-05-14 18:06:34 --> URI Class Initialized
INFO - 2021-05-14 18:06:34 --> Router Class Initialized
INFO - 2021-05-14 18:06:34 --> Output Class Initialized
INFO - 2021-05-14 18:06:34 --> Security Class Initialized
DEBUG - 2021-05-14 18:06:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 18:06:34 --> Input Class Initialized
INFO - 2021-05-14 18:06:34 --> Language Class Initialized
INFO - 2021-05-14 18:06:34 --> Loader Class Initialized
INFO - 2021-05-14 18:06:34 --> Helper loaded: url_helper
INFO - 2021-05-14 18:06:34 --> Helper loaded: form_helper
INFO - 2021-05-14 18:06:34 --> Helper loaded: common_helper
INFO - 2021-05-14 18:06:34 --> Database Driver Class Initialized
DEBUG - 2021-05-14 18:06:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 18:06:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 18:06:34 --> Controller Class Initialized
INFO - 2021-05-14 18:06:34 --> Form Validation Class Initialized
INFO - 2021-05-14 18:06:34 --> Model "Case_model" initialized
INFO - 2021-05-14 18:06:34 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
ERROR - 2021-05-14 18:06:34 --> Severity: error --> Exception: Call to undefined function money_format() C:\xampp\htdocs\study\karosoftware\application\helpers\common_helper.php 19
ERROR - 2021-05-14 18:12:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 18:12:18 --> Config Class Initialized
INFO - 2021-05-14 18:12:18 --> Hooks Class Initialized
DEBUG - 2021-05-14 18:12:18 --> UTF-8 Support Enabled
INFO - 2021-05-14 18:12:18 --> Utf8 Class Initialized
INFO - 2021-05-14 18:12:18 --> URI Class Initialized
INFO - 2021-05-14 18:12:18 --> Router Class Initialized
INFO - 2021-05-14 18:12:18 --> Output Class Initialized
INFO - 2021-05-14 18:12:18 --> Security Class Initialized
DEBUG - 2021-05-14 18:12:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 18:12:18 --> Input Class Initialized
INFO - 2021-05-14 18:12:18 --> Language Class Initialized
INFO - 2021-05-14 18:12:18 --> Loader Class Initialized
INFO - 2021-05-14 18:12:18 --> Helper loaded: url_helper
INFO - 2021-05-14 18:12:18 --> Helper loaded: form_helper
INFO - 2021-05-14 18:12:18 --> Helper loaded: common_helper
INFO - 2021-05-14 18:12:18 --> Database Driver Class Initialized
DEBUG - 2021-05-14 18:12:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 18:12:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 18:12:18 --> Controller Class Initialized
INFO - 2021-05-14 18:12:18 --> Form Validation Class Initialized
INFO - 2021-05-14 18:12:18 --> Model "Case_model" initialized
INFO - 2021-05-14 18:12:18 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
ERROR - 2021-05-14 18:12:18 --> Severity: error --> Exception: Call to undefined function money_format() C:\xampp\htdocs\study\karosoftware\application\helpers\common_helper.php 19
ERROR - 2021-05-14 18:12:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 18:12:20 --> Config Class Initialized
INFO - 2021-05-14 18:12:20 --> Hooks Class Initialized
DEBUG - 2021-05-14 18:12:20 --> UTF-8 Support Enabled
INFO - 2021-05-14 18:12:20 --> Utf8 Class Initialized
INFO - 2021-05-14 18:12:20 --> URI Class Initialized
INFO - 2021-05-14 18:12:20 --> Router Class Initialized
INFO - 2021-05-14 18:12:20 --> Output Class Initialized
INFO - 2021-05-14 18:12:20 --> Security Class Initialized
DEBUG - 2021-05-14 18:12:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 18:12:20 --> Input Class Initialized
INFO - 2021-05-14 18:12:20 --> Language Class Initialized
INFO - 2021-05-14 18:12:20 --> Loader Class Initialized
INFO - 2021-05-14 18:12:20 --> Helper loaded: url_helper
INFO - 2021-05-14 18:12:20 --> Helper loaded: form_helper
INFO - 2021-05-14 18:12:20 --> Helper loaded: common_helper
INFO - 2021-05-14 18:12:20 --> Database Driver Class Initialized
DEBUG - 2021-05-14 18:12:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 18:12:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 18:12:20 --> Controller Class Initialized
INFO - 2021-05-14 18:12:20 --> Form Validation Class Initialized
INFO - 2021-05-14 18:12:20 --> Model "Case_model" initialized
INFO - 2021-05-14 18:12:20 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
ERROR - 2021-05-14 18:12:20 --> Severity: error --> Exception: Call to undefined function money_format() C:\xampp\htdocs\study\karosoftware\application\helpers\common_helper.php 19
ERROR - 2021-05-14 18:12:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 18:12:24 --> Config Class Initialized
INFO - 2021-05-14 18:12:24 --> Hooks Class Initialized
DEBUG - 2021-05-14 18:12:24 --> UTF-8 Support Enabled
INFO - 2021-05-14 18:12:24 --> Utf8 Class Initialized
INFO - 2021-05-14 18:12:24 --> URI Class Initialized
INFO - 2021-05-14 18:12:24 --> Router Class Initialized
INFO - 2021-05-14 18:12:24 --> Output Class Initialized
INFO - 2021-05-14 18:12:24 --> Security Class Initialized
DEBUG - 2021-05-14 18:12:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 18:12:24 --> Input Class Initialized
INFO - 2021-05-14 18:12:24 --> Language Class Initialized
INFO - 2021-05-14 18:12:24 --> Loader Class Initialized
INFO - 2021-05-14 18:12:24 --> Helper loaded: url_helper
INFO - 2021-05-14 18:12:24 --> Helper loaded: form_helper
INFO - 2021-05-14 18:12:24 --> Helper loaded: common_helper
INFO - 2021-05-14 18:12:24 --> Database Driver Class Initialized
DEBUG - 2021-05-14 18:12:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 18:12:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 18:12:24 --> Controller Class Initialized
INFO - 2021-05-14 18:12:24 --> Form Validation Class Initialized
INFO - 2021-05-14 18:12:24 --> Model "Case_model" initialized
INFO - 2021-05-14 18:12:24 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-05-14 18:12:24 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\transaction/donner_donation.php
INFO - 2021-05-14 18:12:24 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-05-14 18:12:24 --> Final output sent to browser
DEBUG - 2021-05-14 18:12:24 --> Total execution time: 0.0614
ERROR - 2021-05-14 18:12:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 18:12:31 --> Config Class Initialized
INFO - 2021-05-14 18:12:31 --> Hooks Class Initialized
DEBUG - 2021-05-14 18:12:31 --> UTF-8 Support Enabled
INFO - 2021-05-14 18:12:31 --> Utf8 Class Initialized
INFO - 2021-05-14 18:12:31 --> URI Class Initialized
INFO - 2021-05-14 18:12:31 --> Router Class Initialized
INFO - 2021-05-14 18:12:31 --> Output Class Initialized
INFO - 2021-05-14 18:12:31 --> Security Class Initialized
DEBUG - 2021-05-14 18:12:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 18:12:31 --> Input Class Initialized
INFO - 2021-05-14 18:12:31 --> Language Class Initialized
ERROR - 2021-05-14 18:12:31 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-05-14 18:14:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 18:14:24 --> Config Class Initialized
INFO - 2021-05-14 18:14:24 --> Hooks Class Initialized
DEBUG - 2021-05-14 18:14:24 --> UTF-8 Support Enabled
INFO - 2021-05-14 18:14:24 --> Utf8 Class Initialized
INFO - 2021-05-14 18:14:24 --> URI Class Initialized
INFO - 2021-05-14 18:14:24 --> Router Class Initialized
INFO - 2021-05-14 18:14:24 --> Output Class Initialized
INFO - 2021-05-14 18:14:24 --> Security Class Initialized
DEBUG - 2021-05-14 18:14:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 18:14:24 --> Input Class Initialized
INFO - 2021-05-14 18:14:24 --> Language Class Initialized
INFO - 2021-05-14 18:14:24 --> Loader Class Initialized
INFO - 2021-05-14 18:14:24 --> Helper loaded: url_helper
INFO - 2021-05-14 18:14:24 --> Helper loaded: form_helper
INFO - 2021-05-14 18:14:24 --> Helper loaded: common_helper
INFO - 2021-05-14 18:14:24 --> Database Driver Class Initialized
DEBUG - 2021-05-14 18:14:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 18:14:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 18:14:24 --> Controller Class Initialized
INFO - 2021-05-14 18:14:24 --> Form Validation Class Initialized
INFO - 2021-05-14 18:14:24 --> Model "Case_model" initialized
INFO - 2021-05-14 18:14:24 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-05-14 18:14:24 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\transaction/donner_donation.php
INFO - 2021-05-14 18:14:24 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-05-14 18:14:24 --> Final output sent to browser
DEBUG - 2021-05-14 18:14:24 --> Total execution time: 0.0508
ERROR - 2021-05-14 18:14:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 18:14:25 --> Config Class Initialized
INFO - 2021-05-14 18:14:25 --> Hooks Class Initialized
DEBUG - 2021-05-14 18:14:25 --> UTF-8 Support Enabled
INFO - 2021-05-14 18:14:25 --> Utf8 Class Initialized
INFO - 2021-05-14 18:14:25 --> URI Class Initialized
INFO - 2021-05-14 18:14:25 --> Router Class Initialized
INFO - 2021-05-14 18:14:25 --> Output Class Initialized
INFO - 2021-05-14 18:14:25 --> Security Class Initialized
DEBUG - 2021-05-14 18:14:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 18:14:25 --> Input Class Initialized
INFO - 2021-05-14 18:14:25 --> Language Class Initialized
ERROR - 2021-05-14 18:14:25 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-05-14 18:15:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 18:15:13 --> Config Class Initialized
INFO - 2021-05-14 18:15:13 --> Hooks Class Initialized
DEBUG - 2021-05-14 18:15:13 --> UTF-8 Support Enabled
INFO - 2021-05-14 18:15:13 --> Utf8 Class Initialized
INFO - 2021-05-14 18:15:13 --> URI Class Initialized
INFO - 2021-05-14 18:15:13 --> Router Class Initialized
INFO - 2021-05-14 18:15:13 --> Output Class Initialized
INFO - 2021-05-14 18:15:13 --> Security Class Initialized
DEBUG - 2021-05-14 18:15:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 18:15:13 --> Input Class Initialized
INFO - 2021-05-14 18:15:13 --> Language Class Initialized
INFO - 2021-05-14 18:15:13 --> Loader Class Initialized
INFO - 2021-05-14 18:15:13 --> Helper loaded: url_helper
INFO - 2021-05-14 18:15:13 --> Helper loaded: form_helper
INFO - 2021-05-14 18:15:13 --> Helper loaded: common_helper
INFO - 2021-05-14 18:15:13 --> Database Driver Class Initialized
DEBUG - 2021-05-14 18:15:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 18:15:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 18:15:13 --> Controller Class Initialized
INFO - 2021-05-14 18:15:13 --> Form Validation Class Initialized
INFO - 2021-05-14 18:15:13 --> Model "Case_model" initialized
INFO - 2021-05-14 18:15:13 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-05-14 18:15:13 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\transaction/donner_donation.php
INFO - 2021-05-14 18:15:13 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-05-14 18:15:13 --> Final output sent to browser
DEBUG - 2021-05-14 18:15:13 --> Total execution time: 0.0547
ERROR - 2021-05-14 18:15:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 18:15:14 --> Config Class Initialized
INFO - 2021-05-14 18:15:14 --> Hooks Class Initialized
DEBUG - 2021-05-14 18:15:14 --> UTF-8 Support Enabled
INFO - 2021-05-14 18:15:14 --> Utf8 Class Initialized
INFO - 2021-05-14 18:15:14 --> URI Class Initialized
INFO - 2021-05-14 18:15:14 --> Router Class Initialized
INFO - 2021-05-14 18:15:14 --> Output Class Initialized
INFO - 2021-05-14 18:15:14 --> Security Class Initialized
DEBUG - 2021-05-14 18:15:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 18:15:14 --> Input Class Initialized
INFO - 2021-05-14 18:15:14 --> Language Class Initialized
ERROR - 2021-05-14 18:15:14 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-05-14 18:15:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 18:15:27 --> Config Class Initialized
INFO - 2021-05-14 18:15:27 --> Hooks Class Initialized
DEBUG - 2021-05-14 18:15:27 --> UTF-8 Support Enabled
INFO - 2021-05-14 18:15:27 --> Utf8 Class Initialized
INFO - 2021-05-14 18:15:27 --> URI Class Initialized
INFO - 2021-05-14 18:15:27 --> Router Class Initialized
INFO - 2021-05-14 18:15:27 --> Output Class Initialized
INFO - 2021-05-14 18:15:27 --> Security Class Initialized
DEBUG - 2021-05-14 18:15:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 18:15:27 --> Input Class Initialized
INFO - 2021-05-14 18:15:27 --> Language Class Initialized
INFO - 2021-05-14 18:15:27 --> Loader Class Initialized
INFO - 2021-05-14 18:15:27 --> Helper loaded: url_helper
INFO - 2021-05-14 18:15:27 --> Helper loaded: form_helper
INFO - 2021-05-14 18:15:27 --> Helper loaded: common_helper
INFO - 2021-05-14 18:15:27 --> Database Driver Class Initialized
DEBUG - 2021-05-14 18:15:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 18:15:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 18:15:27 --> Controller Class Initialized
INFO - 2021-05-14 18:15:27 --> Form Validation Class Initialized
INFO - 2021-05-14 18:15:27 --> Model "Case_model" initialized
INFO - 2021-05-14 18:15:27 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-05-14 18:15:27 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\transaction/donner_donation.php
INFO - 2021-05-14 18:15:27 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-05-14 18:15:27 --> Final output sent to browser
DEBUG - 2021-05-14 18:15:27 --> Total execution time: 0.0603
ERROR - 2021-05-14 18:15:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 18:15:28 --> Config Class Initialized
INFO - 2021-05-14 18:15:28 --> Hooks Class Initialized
DEBUG - 2021-05-14 18:15:28 --> UTF-8 Support Enabled
INFO - 2021-05-14 18:15:28 --> Utf8 Class Initialized
INFO - 2021-05-14 18:15:28 --> URI Class Initialized
INFO - 2021-05-14 18:15:28 --> Router Class Initialized
INFO - 2021-05-14 18:15:28 --> Output Class Initialized
INFO - 2021-05-14 18:15:28 --> Security Class Initialized
DEBUG - 2021-05-14 18:15:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 18:15:28 --> Input Class Initialized
INFO - 2021-05-14 18:15:28 --> Language Class Initialized
ERROR - 2021-05-14 18:15:28 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-05-14 18:15:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 18:15:41 --> Config Class Initialized
INFO - 2021-05-14 18:15:41 --> Hooks Class Initialized
DEBUG - 2021-05-14 18:15:41 --> UTF-8 Support Enabled
INFO - 2021-05-14 18:15:41 --> Utf8 Class Initialized
INFO - 2021-05-14 18:15:41 --> URI Class Initialized
INFO - 2021-05-14 18:15:41 --> Router Class Initialized
INFO - 2021-05-14 18:15:41 --> Output Class Initialized
INFO - 2021-05-14 18:15:41 --> Security Class Initialized
DEBUG - 2021-05-14 18:15:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 18:15:41 --> Input Class Initialized
INFO - 2021-05-14 18:15:41 --> Language Class Initialized
INFO - 2021-05-14 18:15:41 --> Loader Class Initialized
INFO - 2021-05-14 18:15:41 --> Helper loaded: url_helper
INFO - 2021-05-14 18:15:41 --> Helper loaded: form_helper
INFO - 2021-05-14 18:15:41 --> Helper loaded: common_helper
INFO - 2021-05-14 18:15:41 --> Database Driver Class Initialized
DEBUG - 2021-05-14 18:15:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 18:15:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 18:15:41 --> Controller Class Initialized
INFO - 2021-05-14 18:15:41 --> Form Validation Class Initialized
INFO - 2021-05-14 18:15:41 --> Model "Case_model" initialized
INFO - 2021-05-14 18:15:41 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-05-14 18:15:41 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\transaction/donner_donation.php
INFO - 2021-05-14 18:15:41 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-05-14 18:15:41 --> Final output sent to browser
DEBUG - 2021-05-14 18:15:41 --> Total execution time: 0.0657
ERROR - 2021-05-14 18:15:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 18:15:41 --> Config Class Initialized
INFO - 2021-05-14 18:15:41 --> Hooks Class Initialized
DEBUG - 2021-05-14 18:15:41 --> UTF-8 Support Enabled
INFO - 2021-05-14 18:15:41 --> Utf8 Class Initialized
INFO - 2021-05-14 18:15:41 --> URI Class Initialized
INFO - 2021-05-14 18:15:41 --> Router Class Initialized
INFO - 2021-05-14 18:15:41 --> Output Class Initialized
INFO - 2021-05-14 18:15:41 --> Security Class Initialized
DEBUG - 2021-05-14 18:15:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 18:15:41 --> Input Class Initialized
INFO - 2021-05-14 18:15:41 --> Language Class Initialized
ERROR - 2021-05-14 18:15:41 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-05-14 18:31:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 18:31:04 --> Config Class Initialized
INFO - 2021-05-14 18:31:04 --> Hooks Class Initialized
DEBUG - 2021-05-14 18:31:04 --> UTF-8 Support Enabled
INFO - 2021-05-14 18:31:04 --> Utf8 Class Initialized
INFO - 2021-05-14 18:31:04 --> URI Class Initialized
INFO - 2021-05-14 18:31:04 --> Router Class Initialized
INFO - 2021-05-14 18:31:04 --> Output Class Initialized
INFO - 2021-05-14 18:31:04 --> Security Class Initialized
DEBUG - 2021-05-14 18:31:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 18:31:04 --> Input Class Initialized
INFO - 2021-05-14 18:31:04 --> Language Class Initialized
INFO - 2021-05-14 18:31:04 --> Loader Class Initialized
INFO - 2021-05-14 18:31:04 --> Helper loaded: url_helper
INFO - 2021-05-14 18:31:04 --> Helper loaded: form_helper
INFO - 2021-05-14 18:31:04 --> Helper loaded: common_helper
INFO - 2021-05-14 18:31:04 --> Database Driver Class Initialized
DEBUG - 2021-05-14 18:31:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 18:31:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 18:31:04 --> Controller Class Initialized
INFO - 2021-05-14 18:31:04 --> Form Validation Class Initialized
INFO - 2021-05-14 18:31:04 --> Model "Case_model" initialized
INFO - 2021-05-14 18:31:04 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
ERROR - 2021-05-14 18:31:04 --> Severity: error --> Exception: Call to undefined function number_to_currency() C:\xampp\htdocs\study\karosoftware\application\views\transaction\donner_donation.php 106
ERROR - 2021-05-14 18:32:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 18:32:51 --> Config Class Initialized
INFO - 2021-05-14 18:32:51 --> Hooks Class Initialized
DEBUG - 2021-05-14 18:32:51 --> UTF-8 Support Enabled
INFO - 2021-05-14 18:32:51 --> Utf8 Class Initialized
INFO - 2021-05-14 18:32:51 --> URI Class Initialized
INFO - 2021-05-14 18:32:51 --> Router Class Initialized
INFO - 2021-05-14 18:32:51 --> Output Class Initialized
INFO - 2021-05-14 18:32:51 --> Security Class Initialized
DEBUG - 2021-05-14 18:32:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 18:32:51 --> Input Class Initialized
INFO - 2021-05-14 18:32:51 --> Language Class Initialized
INFO - 2021-05-14 18:32:51 --> Loader Class Initialized
INFO - 2021-05-14 18:32:51 --> Helper loaded: url_helper
INFO - 2021-05-14 18:32:51 --> Helper loaded: form_helper
INFO - 2021-05-14 18:32:51 --> Helper loaded: common_helper
INFO - 2021-05-14 18:32:51 --> Database Driver Class Initialized
DEBUG - 2021-05-14 18:32:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 18:32:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 18:32:51 --> Controller Class Initialized
INFO - 2021-05-14 18:32:51 --> Form Validation Class Initialized
INFO - 2021-05-14 18:32:51 --> Model "Case_model" initialized
INFO - 2021-05-14 18:32:51 --> Helper loaded: number_helper
INFO - 2021-05-14 18:32:51 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
ERROR - 2021-05-14 18:32:51 --> Severity: error --> Exception: Call to undefined function number_to_currency() C:\xampp\htdocs\study\karosoftware\application\views\transaction\donner_donation.php 106
ERROR - 2021-05-14 18:33:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 18:33:04 --> Config Class Initialized
INFO - 2021-05-14 18:33:04 --> Hooks Class Initialized
DEBUG - 2021-05-14 18:33:04 --> UTF-8 Support Enabled
INFO - 2021-05-14 18:33:04 --> Utf8 Class Initialized
INFO - 2021-05-14 18:33:04 --> URI Class Initialized
INFO - 2021-05-14 18:33:04 --> Router Class Initialized
INFO - 2021-05-14 18:33:04 --> Output Class Initialized
INFO - 2021-05-14 18:33:04 --> Security Class Initialized
DEBUG - 2021-05-14 18:33:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 18:33:04 --> Input Class Initialized
INFO - 2021-05-14 18:33:04 --> Language Class Initialized
INFO - 2021-05-14 18:33:04 --> Loader Class Initialized
INFO - 2021-05-14 18:33:04 --> Helper loaded: url_helper
INFO - 2021-05-14 18:33:04 --> Helper loaded: form_helper
INFO - 2021-05-14 18:33:04 --> Helper loaded: common_helper
INFO - 2021-05-14 18:33:04 --> Database Driver Class Initialized
DEBUG - 2021-05-14 18:33:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 18:33:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 18:33:04 --> Controller Class Initialized
INFO - 2021-05-14 18:33:04 --> Form Validation Class Initialized
INFO - 2021-05-14 18:33:04 --> Model "Case_model" initialized
INFO - 2021-05-14 18:33:04 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-05-14 18:33:04 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\transaction/donner_donation.php
INFO - 2021-05-14 18:33:04 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-05-14 18:33:04 --> Final output sent to browser
DEBUG - 2021-05-14 18:33:04 --> Total execution time: 0.0495
ERROR - 2021-05-14 18:33:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 18:33:04 --> Config Class Initialized
INFO - 2021-05-14 18:33:04 --> Hooks Class Initialized
DEBUG - 2021-05-14 18:33:04 --> UTF-8 Support Enabled
INFO - 2021-05-14 18:33:04 --> Utf8 Class Initialized
INFO - 2021-05-14 18:33:04 --> URI Class Initialized
INFO - 2021-05-14 18:33:04 --> Router Class Initialized
INFO - 2021-05-14 18:33:04 --> Output Class Initialized
INFO - 2021-05-14 18:33:04 --> Security Class Initialized
DEBUG - 2021-05-14 18:33:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 18:33:04 --> Input Class Initialized
INFO - 2021-05-14 18:33:04 --> Language Class Initialized
ERROR - 2021-05-14 18:33:04 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-05-14 18:41:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 18:41:38 --> Config Class Initialized
INFO - 2021-05-14 18:41:38 --> Hooks Class Initialized
DEBUG - 2021-05-14 18:41:38 --> UTF-8 Support Enabled
INFO - 2021-05-14 18:41:38 --> Utf8 Class Initialized
INFO - 2021-05-14 18:41:38 --> URI Class Initialized
INFO - 2021-05-14 18:41:38 --> Router Class Initialized
INFO - 2021-05-14 18:41:38 --> Output Class Initialized
INFO - 2021-05-14 18:41:38 --> Security Class Initialized
DEBUG - 2021-05-14 18:41:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 18:41:38 --> Input Class Initialized
INFO - 2021-05-14 18:41:38 --> Language Class Initialized
INFO - 2021-05-14 18:41:38 --> Loader Class Initialized
INFO - 2021-05-14 18:41:38 --> Helper loaded: url_helper
INFO - 2021-05-14 18:41:38 --> Helper loaded: form_helper
INFO - 2021-05-14 18:41:38 --> Helper loaded: common_helper
INFO - 2021-05-14 18:41:38 --> Database Driver Class Initialized
DEBUG - 2021-05-14 18:41:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 18:41:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 18:41:38 --> Controller Class Initialized
INFO - 2021-05-14 18:41:38 --> Form Validation Class Initialized
INFO - 2021-05-14 18:41:38 --> Model "Case_model" initialized
INFO - 2021-05-14 18:41:38 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
ERROR - 2021-05-14 18:41:38 --> Severity: error --> Exception: Class 'NumberFormatter' not found C:\xampp\htdocs\study\karosoftware\application\helpers\common_helper.php 20
ERROR - 2021-05-14 18:44:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 18:44:21 --> Config Class Initialized
INFO - 2021-05-14 18:44:21 --> Hooks Class Initialized
DEBUG - 2021-05-14 18:44:21 --> UTF-8 Support Enabled
INFO - 2021-05-14 18:44:21 --> Utf8 Class Initialized
INFO - 2021-05-14 18:44:21 --> URI Class Initialized
INFO - 2021-05-14 18:44:21 --> Router Class Initialized
INFO - 2021-05-14 18:44:21 --> Output Class Initialized
INFO - 2021-05-14 18:44:21 --> Security Class Initialized
DEBUG - 2021-05-14 18:44:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 18:44:21 --> Input Class Initialized
INFO - 2021-05-14 18:44:21 --> Language Class Initialized
INFO - 2021-05-14 18:44:21 --> Loader Class Initialized
INFO - 2021-05-14 18:44:21 --> Helper loaded: url_helper
INFO - 2021-05-14 18:44:21 --> Helper loaded: form_helper
INFO - 2021-05-14 18:44:21 --> Helper loaded: common_helper
INFO - 2021-05-14 18:44:21 --> Database Driver Class Initialized
DEBUG - 2021-05-14 18:44:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 18:44:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 18:44:21 --> Controller Class Initialized
INFO - 2021-05-14 18:44:21 --> Form Validation Class Initialized
INFO - 2021-05-14 18:44:21 --> Model "Case_model" initialized
INFO - 2021-05-14 18:44:21 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-05-14 18:44:21 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\transaction/donner_donation.php
INFO - 2021-05-14 18:44:21 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-05-14 18:44:21 --> Final output sent to browser
DEBUG - 2021-05-14 18:44:21 --> Total execution time: 0.0559
ERROR - 2021-05-14 18:44:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 18:44:23 --> Config Class Initialized
INFO - 2021-05-14 18:44:23 --> Hooks Class Initialized
DEBUG - 2021-05-14 18:44:23 --> UTF-8 Support Enabled
INFO - 2021-05-14 18:44:23 --> Utf8 Class Initialized
INFO - 2021-05-14 18:44:23 --> URI Class Initialized
INFO - 2021-05-14 18:44:23 --> Router Class Initialized
INFO - 2021-05-14 18:44:23 --> Output Class Initialized
INFO - 2021-05-14 18:44:23 --> Security Class Initialized
DEBUG - 2021-05-14 18:44:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 18:44:23 --> Input Class Initialized
INFO - 2021-05-14 18:44:23 --> Language Class Initialized
ERROR - 2021-05-14 18:44:23 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-05-14 18:46:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 18:46:29 --> Config Class Initialized
INFO - 2021-05-14 18:46:29 --> Hooks Class Initialized
DEBUG - 2021-05-14 18:46:29 --> UTF-8 Support Enabled
INFO - 2021-05-14 18:46:29 --> Utf8 Class Initialized
INFO - 2021-05-14 18:46:29 --> URI Class Initialized
INFO - 2021-05-14 18:46:29 --> Router Class Initialized
INFO - 2021-05-14 18:46:29 --> Output Class Initialized
INFO - 2021-05-14 18:46:29 --> Security Class Initialized
DEBUG - 2021-05-14 18:46:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 18:46:29 --> Input Class Initialized
INFO - 2021-05-14 18:46:29 --> Language Class Initialized
INFO - 2021-05-14 18:46:29 --> Loader Class Initialized
INFO - 2021-05-14 18:46:29 --> Helper loaded: url_helper
INFO - 2021-05-14 18:46:29 --> Helper loaded: form_helper
INFO - 2021-05-14 18:46:29 --> Helper loaded: common_helper
INFO - 2021-05-14 18:46:29 --> Database Driver Class Initialized
DEBUG - 2021-05-14 18:46:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 18:46:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 18:46:29 --> Controller Class Initialized
INFO - 2021-05-14 18:46:29 --> Form Validation Class Initialized
INFO - 2021-05-14 18:46:29 --> Model "Case_model" initialized
INFO - 2021-05-14 18:46:29 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-05-14 18:46:29 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\transaction/donner_donation.php
INFO - 2021-05-14 18:46:29 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-05-14 18:46:29 --> Final output sent to browser
DEBUG - 2021-05-14 18:46:29 --> Total execution time: 0.0555
ERROR - 2021-05-14 18:46:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 18:46:29 --> Config Class Initialized
INFO - 2021-05-14 18:46:29 --> Hooks Class Initialized
DEBUG - 2021-05-14 18:46:29 --> UTF-8 Support Enabled
INFO - 2021-05-14 18:46:29 --> Utf8 Class Initialized
INFO - 2021-05-14 18:46:29 --> URI Class Initialized
INFO - 2021-05-14 18:46:29 --> Router Class Initialized
INFO - 2021-05-14 18:46:29 --> Output Class Initialized
INFO - 2021-05-14 18:46:29 --> Security Class Initialized
DEBUG - 2021-05-14 18:46:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 18:46:29 --> Input Class Initialized
INFO - 2021-05-14 18:46:29 --> Language Class Initialized
ERROR - 2021-05-14 18:46:29 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-05-14 18:46:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 18:46:59 --> Config Class Initialized
INFO - 2021-05-14 18:46:59 --> Hooks Class Initialized
DEBUG - 2021-05-14 18:46:59 --> UTF-8 Support Enabled
INFO - 2021-05-14 18:46:59 --> Utf8 Class Initialized
INFO - 2021-05-14 18:46:59 --> URI Class Initialized
INFO - 2021-05-14 18:46:59 --> Router Class Initialized
INFO - 2021-05-14 18:46:59 --> Output Class Initialized
INFO - 2021-05-14 18:46:59 --> Security Class Initialized
DEBUG - 2021-05-14 18:46:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 18:46:59 --> Input Class Initialized
INFO - 2021-05-14 18:46:59 --> Language Class Initialized
INFO - 2021-05-14 18:46:59 --> Loader Class Initialized
INFO - 2021-05-14 18:46:59 --> Helper loaded: url_helper
INFO - 2021-05-14 18:46:59 --> Helper loaded: form_helper
INFO - 2021-05-14 18:46:59 --> Helper loaded: common_helper
INFO - 2021-05-14 18:46:59 --> Database Driver Class Initialized
DEBUG - 2021-05-14 18:46:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 18:46:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 18:46:59 --> Controller Class Initialized
INFO - 2021-05-14 18:46:59 --> Form Validation Class Initialized
INFO - 2021-05-14 18:46:59 --> Model "Case_model" initialized
INFO - 2021-05-14 18:46:59 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-05-14 18:46:59 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\transaction/donner_donation.php
INFO - 2021-05-14 18:46:59 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-05-14 18:46:59 --> Final output sent to browser
DEBUG - 2021-05-14 18:46:59 --> Total execution time: 0.0621
ERROR - 2021-05-14 18:46:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 18:46:59 --> Config Class Initialized
INFO - 2021-05-14 18:46:59 --> Hooks Class Initialized
DEBUG - 2021-05-14 18:46:59 --> UTF-8 Support Enabled
INFO - 2021-05-14 18:46:59 --> Utf8 Class Initialized
INFO - 2021-05-14 18:46:59 --> URI Class Initialized
INFO - 2021-05-14 18:46:59 --> Router Class Initialized
INFO - 2021-05-14 18:46:59 --> Output Class Initialized
INFO - 2021-05-14 18:46:59 --> Security Class Initialized
DEBUG - 2021-05-14 18:46:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 18:46:59 --> Input Class Initialized
INFO - 2021-05-14 18:46:59 --> Language Class Initialized
ERROR - 2021-05-14 18:46:59 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-05-14 18:47:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 18:47:44 --> Config Class Initialized
INFO - 2021-05-14 18:47:44 --> Hooks Class Initialized
DEBUG - 2021-05-14 18:47:44 --> UTF-8 Support Enabled
INFO - 2021-05-14 18:47:44 --> Utf8 Class Initialized
INFO - 2021-05-14 18:47:44 --> URI Class Initialized
INFO - 2021-05-14 18:47:44 --> Router Class Initialized
INFO - 2021-05-14 18:47:44 --> Output Class Initialized
INFO - 2021-05-14 18:47:44 --> Security Class Initialized
DEBUG - 2021-05-14 18:47:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 18:47:44 --> Input Class Initialized
INFO - 2021-05-14 18:47:44 --> Language Class Initialized
INFO - 2021-05-14 18:47:44 --> Loader Class Initialized
INFO - 2021-05-14 18:47:44 --> Helper loaded: url_helper
INFO - 2021-05-14 18:47:44 --> Helper loaded: form_helper
INFO - 2021-05-14 18:47:44 --> Helper loaded: common_helper
INFO - 2021-05-14 18:47:44 --> Database Driver Class Initialized
DEBUG - 2021-05-14 18:47:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 18:47:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 18:47:44 --> Controller Class Initialized
INFO - 2021-05-14 18:47:44 --> Form Validation Class Initialized
INFO - 2021-05-14 18:47:44 --> Model "Case_model" initialized
INFO - 2021-05-14 18:47:44 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-05-14 18:47:44 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\transaction/donner_donation.php
INFO - 2021-05-14 18:47:44 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-05-14 18:47:44 --> Final output sent to browser
DEBUG - 2021-05-14 18:47:44 --> Total execution time: 0.0731
ERROR - 2021-05-14 18:47:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 18:47:44 --> Config Class Initialized
INFO - 2021-05-14 18:47:44 --> Hooks Class Initialized
DEBUG - 2021-05-14 18:47:44 --> UTF-8 Support Enabled
INFO - 2021-05-14 18:47:44 --> Utf8 Class Initialized
INFO - 2021-05-14 18:47:44 --> URI Class Initialized
INFO - 2021-05-14 18:47:44 --> Router Class Initialized
INFO - 2021-05-14 18:47:44 --> Output Class Initialized
INFO - 2021-05-14 18:47:44 --> Security Class Initialized
DEBUG - 2021-05-14 18:47:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 18:47:44 --> Input Class Initialized
INFO - 2021-05-14 18:47:44 --> Language Class Initialized
ERROR - 2021-05-14 18:47:44 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-05-14 18:48:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 18:48:01 --> Config Class Initialized
INFO - 2021-05-14 18:48:01 --> Hooks Class Initialized
DEBUG - 2021-05-14 18:48:01 --> UTF-8 Support Enabled
INFO - 2021-05-14 18:48:01 --> Utf8 Class Initialized
INFO - 2021-05-14 18:48:01 --> URI Class Initialized
INFO - 2021-05-14 18:48:01 --> Router Class Initialized
INFO - 2021-05-14 18:48:01 --> Output Class Initialized
INFO - 2021-05-14 18:48:01 --> Security Class Initialized
DEBUG - 2021-05-14 18:48:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 18:48:01 --> Input Class Initialized
INFO - 2021-05-14 18:48:01 --> Language Class Initialized
INFO - 2021-05-14 18:48:01 --> Loader Class Initialized
INFO - 2021-05-14 18:48:01 --> Helper loaded: url_helper
INFO - 2021-05-14 18:48:01 --> Helper loaded: form_helper
INFO - 2021-05-14 18:48:01 --> Helper loaded: common_helper
INFO - 2021-05-14 18:48:01 --> Database Driver Class Initialized
DEBUG - 2021-05-14 18:48:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 18:48:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 18:48:01 --> Controller Class Initialized
INFO - 2021-05-14 18:48:01 --> Form Validation Class Initialized
INFO - 2021-05-14 18:48:01 --> Model "Case_model" initialized
INFO - 2021-05-14 18:48:01 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-05-14 18:48:01 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\transaction/donner_donation.php
INFO - 2021-05-14 18:48:01 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-05-14 18:48:01 --> Final output sent to browser
DEBUG - 2021-05-14 18:48:01 --> Total execution time: 0.0625
ERROR - 2021-05-14 18:48:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 18:48:01 --> Config Class Initialized
INFO - 2021-05-14 18:48:01 --> Hooks Class Initialized
DEBUG - 2021-05-14 18:48:01 --> UTF-8 Support Enabled
INFO - 2021-05-14 18:48:01 --> Utf8 Class Initialized
INFO - 2021-05-14 18:48:01 --> URI Class Initialized
INFO - 2021-05-14 18:48:01 --> Router Class Initialized
INFO - 2021-05-14 18:48:01 --> Output Class Initialized
INFO - 2021-05-14 18:48:01 --> Security Class Initialized
DEBUG - 2021-05-14 18:48:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 18:48:01 --> Input Class Initialized
INFO - 2021-05-14 18:48:01 --> Language Class Initialized
ERROR - 2021-05-14 18:48:01 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-05-14 18:50:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 18:50:17 --> Config Class Initialized
INFO - 2021-05-14 18:50:17 --> Hooks Class Initialized
DEBUG - 2021-05-14 18:50:17 --> UTF-8 Support Enabled
INFO - 2021-05-14 18:50:17 --> Utf8 Class Initialized
INFO - 2021-05-14 18:50:17 --> URI Class Initialized
INFO - 2021-05-14 18:50:17 --> Router Class Initialized
INFO - 2021-05-14 18:50:17 --> Output Class Initialized
INFO - 2021-05-14 18:50:17 --> Security Class Initialized
DEBUG - 2021-05-14 18:50:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 18:50:17 --> Input Class Initialized
INFO - 2021-05-14 18:50:17 --> Language Class Initialized
INFO - 2021-05-14 18:50:17 --> Loader Class Initialized
INFO - 2021-05-14 18:50:17 --> Helper loaded: url_helper
INFO - 2021-05-14 18:50:17 --> Helper loaded: form_helper
INFO - 2021-05-14 18:50:17 --> Helper loaded: common_helper
INFO - 2021-05-14 18:50:17 --> Database Driver Class Initialized
DEBUG - 2021-05-14 18:50:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 18:50:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 18:50:17 --> Controller Class Initialized
INFO - 2021-05-14 18:50:17 --> Form Validation Class Initialized
INFO - 2021-05-14 18:50:17 --> Model "Case_model" initialized
INFO - 2021-05-14 18:50:17 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-05-14 18:50:17 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\transaction/donner_donation.php
INFO - 2021-05-14 18:50:17 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-05-14 18:50:17 --> Final output sent to browser
DEBUG - 2021-05-14 18:50:17 --> Total execution time: 0.0720
ERROR - 2021-05-14 18:50:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 18:50:17 --> Config Class Initialized
INFO - 2021-05-14 18:50:17 --> Hooks Class Initialized
DEBUG - 2021-05-14 18:50:17 --> UTF-8 Support Enabled
INFO - 2021-05-14 18:50:17 --> Utf8 Class Initialized
INFO - 2021-05-14 18:50:17 --> URI Class Initialized
INFO - 2021-05-14 18:50:17 --> Router Class Initialized
INFO - 2021-05-14 18:50:17 --> Output Class Initialized
INFO - 2021-05-14 18:50:17 --> Security Class Initialized
DEBUG - 2021-05-14 18:50:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 18:50:17 --> Input Class Initialized
INFO - 2021-05-14 18:50:17 --> Language Class Initialized
ERROR - 2021-05-14 18:50:17 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-05-14 18:50:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 18:50:35 --> Config Class Initialized
INFO - 2021-05-14 18:50:35 --> Hooks Class Initialized
DEBUG - 2021-05-14 18:50:35 --> UTF-8 Support Enabled
INFO - 2021-05-14 18:50:35 --> Utf8 Class Initialized
INFO - 2021-05-14 18:50:35 --> URI Class Initialized
INFO - 2021-05-14 18:50:35 --> Router Class Initialized
INFO - 2021-05-14 18:50:35 --> Output Class Initialized
INFO - 2021-05-14 18:50:35 --> Security Class Initialized
DEBUG - 2021-05-14 18:50:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 18:50:35 --> Input Class Initialized
INFO - 2021-05-14 18:50:35 --> Language Class Initialized
INFO - 2021-05-14 18:50:35 --> Loader Class Initialized
INFO - 2021-05-14 18:50:35 --> Helper loaded: url_helper
INFO - 2021-05-14 18:50:35 --> Helper loaded: form_helper
INFO - 2021-05-14 18:50:35 --> Helper loaded: common_helper
INFO - 2021-05-14 18:50:35 --> Database Driver Class Initialized
DEBUG - 2021-05-14 18:50:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 18:50:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 18:50:35 --> Controller Class Initialized
INFO - 2021-05-14 18:50:35 --> Form Validation Class Initialized
INFO - 2021-05-14 18:50:35 --> Model "Case_model" initialized
INFO - 2021-05-14 18:50:35 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-05-14 18:50:35 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\transaction/donner_donation.php
INFO - 2021-05-14 18:50:35 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-05-14 18:50:35 --> Final output sent to browser
DEBUG - 2021-05-14 18:50:35 --> Total execution time: 0.0501
ERROR - 2021-05-14 18:50:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 18:50:36 --> Config Class Initialized
INFO - 2021-05-14 18:50:36 --> Hooks Class Initialized
DEBUG - 2021-05-14 18:50:36 --> UTF-8 Support Enabled
INFO - 2021-05-14 18:50:36 --> Utf8 Class Initialized
INFO - 2021-05-14 18:50:36 --> URI Class Initialized
INFO - 2021-05-14 18:50:36 --> Router Class Initialized
INFO - 2021-05-14 18:50:36 --> Output Class Initialized
INFO - 2021-05-14 18:50:36 --> Security Class Initialized
DEBUG - 2021-05-14 18:50:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 18:50:36 --> Input Class Initialized
INFO - 2021-05-14 18:50:36 --> Language Class Initialized
ERROR - 2021-05-14 18:50:36 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-05-14 18:50:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 18:50:45 --> Config Class Initialized
INFO - 2021-05-14 18:50:45 --> Hooks Class Initialized
DEBUG - 2021-05-14 18:50:45 --> UTF-8 Support Enabled
INFO - 2021-05-14 18:50:45 --> Utf8 Class Initialized
INFO - 2021-05-14 18:50:45 --> URI Class Initialized
INFO - 2021-05-14 18:50:45 --> Router Class Initialized
INFO - 2021-05-14 18:50:45 --> Output Class Initialized
INFO - 2021-05-14 18:50:45 --> Security Class Initialized
DEBUG - 2021-05-14 18:50:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 18:50:45 --> Input Class Initialized
INFO - 2021-05-14 18:50:45 --> Language Class Initialized
INFO - 2021-05-14 18:50:45 --> Loader Class Initialized
INFO - 2021-05-14 18:50:45 --> Helper loaded: url_helper
INFO - 2021-05-14 18:50:45 --> Helper loaded: form_helper
INFO - 2021-05-14 18:50:45 --> Helper loaded: common_helper
INFO - 2021-05-14 18:50:45 --> Database Driver Class Initialized
DEBUG - 2021-05-14 18:50:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 18:50:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 18:50:45 --> Controller Class Initialized
INFO - 2021-05-14 18:50:45 --> Form Validation Class Initialized
INFO - 2021-05-14 18:50:45 --> Model "Case_model" initialized
INFO - 2021-05-14 18:50:45 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-05-14 18:50:45 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\transaction/donner_donation.php
INFO - 2021-05-14 18:50:45 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-05-14 18:50:45 --> Final output sent to browser
DEBUG - 2021-05-14 18:50:45 --> Total execution time: 0.0591
ERROR - 2021-05-14 18:50:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 18:50:46 --> Config Class Initialized
INFO - 2021-05-14 18:50:46 --> Hooks Class Initialized
DEBUG - 2021-05-14 18:50:46 --> UTF-8 Support Enabled
INFO - 2021-05-14 18:50:46 --> Utf8 Class Initialized
INFO - 2021-05-14 18:50:46 --> URI Class Initialized
INFO - 2021-05-14 18:50:46 --> Router Class Initialized
INFO - 2021-05-14 18:50:46 --> Output Class Initialized
INFO - 2021-05-14 18:50:46 --> Security Class Initialized
DEBUG - 2021-05-14 18:50:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 18:50:46 --> Input Class Initialized
INFO - 2021-05-14 18:50:46 --> Language Class Initialized
ERROR - 2021-05-14 18:50:46 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-05-14 18:52:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 18:52:41 --> Config Class Initialized
INFO - 2021-05-14 18:52:41 --> Hooks Class Initialized
DEBUG - 2021-05-14 18:52:41 --> UTF-8 Support Enabled
INFO - 2021-05-14 18:52:41 --> Utf8 Class Initialized
INFO - 2021-05-14 18:52:41 --> URI Class Initialized
INFO - 2021-05-14 18:52:41 --> Router Class Initialized
INFO - 2021-05-14 18:52:41 --> Output Class Initialized
INFO - 2021-05-14 18:52:41 --> Security Class Initialized
DEBUG - 2021-05-14 18:52:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 18:52:41 --> Input Class Initialized
INFO - 2021-05-14 18:52:41 --> Language Class Initialized
INFO - 2021-05-14 18:52:41 --> Loader Class Initialized
INFO - 2021-05-14 18:52:41 --> Helper loaded: url_helper
INFO - 2021-05-14 18:52:41 --> Helper loaded: form_helper
INFO - 2021-05-14 18:52:41 --> Helper loaded: common_helper
INFO - 2021-05-14 18:52:41 --> Database Driver Class Initialized
DEBUG - 2021-05-14 18:52:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 18:52:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 18:52:41 --> Controller Class Initialized
INFO - 2021-05-14 18:52:41 --> Form Validation Class Initialized
INFO - 2021-05-14 18:52:41 --> Model "Case_model" initialized
INFO - 2021-05-14 18:52:41 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-05-14 18:52:41 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\transaction/donner_donation.php
INFO - 2021-05-14 18:52:41 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-05-14 18:52:41 --> Final output sent to browser
DEBUG - 2021-05-14 18:52:41 --> Total execution time: 0.0591
ERROR - 2021-05-14 18:52:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 18:52:41 --> Config Class Initialized
INFO - 2021-05-14 18:52:41 --> Hooks Class Initialized
DEBUG - 2021-05-14 18:52:41 --> UTF-8 Support Enabled
INFO - 2021-05-14 18:52:41 --> Utf8 Class Initialized
INFO - 2021-05-14 18:52:41 --> URI Class Initialized
INFO - 2021-05-14 18:52:41 --> Router Class Initialized
INFO - 2021-05-14 18:52:41 --> Output Class Initialized
INFO - 2021-05-14 18:52:41 --> Security Class Initialized
DEBUG - 2021-05-14 18:52:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 18:52:41 --> Input Class Initialized
INFO - 2021-05-14 18:52:41 --> Language Class Initialized
ERROR - 2021-05-14 18:52:41 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-05-14 18:53:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 18:53:00 --> Config Class Initialized
INFO - 2021-05-14 18:53:00 --> Hooks Class Initialized
DEBUG - 2021-05-14 18:53:00 --> UTF-8 Support Enabled
INFO - 2021-05-14 18:53:00 --> Utf8 Class Initialized
INFO - 2021-05-14 18:53:00 --> URI Class Initialized
INFO - 2021-05-14 18:53:00 --> Router Class Initialized
INFO - 2021-05-14 18:53:00 --> Output Class Initialized
INFO - 2021-05-14 18:53:00 --> Security Class Initialized
DEBUG - 2021-05-14 18:53:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 18:53:00 --> Input Class Initialized
INFO - 2021-05-14 18:53:00 --> Language Class Initialized
INFO - 2021-05-14 18:53:00 --> Loader Class Initialized
INFO - 2021-05-14 18:53:00 --> Helper loaded: url_helper
INFO - 2021-05-14 18:53:00 --> Helper loaded: form_helper
INFO - 2021-05-14 18:53:00 --> Helper loaded: common_helper
INFO - 2021-05-14 18:53:00 --> Database Driver Class Initialized
DEBUG - 2021-05-14 18:53:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 18:53:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 18:53:00 --> Controller Class Initialized
INFO - 2021-05-14 18:53:00 --> Form Validation Class Initialized
INFO - 2021-05-14 18:53:00 --> Model "Case_model" initialized
INFO - 2021-05-14 18:53:00 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-05-14 18:53:01 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\transaction/donner_donation.php
INFO - 2021-05-14 18:53:01 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-05-14 18:53:01 --> Final output sent to browser
DEBUG - 2021-05-14 18:53:01 --> Total execution time: 0.0524
ERROR - 2021-05-14 18:53:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 18:53:01 --> Config Class Initialized
INFO - 2021-05-14 18:53:01 --> Hooks Class Initialized
DEBUG - 2021-05-14 18:53:01 --> UTF-8 Support Enabled
INFO - 2021-05-14 18:53:01 --> Utf8 Class Initialized
INFO - 2021-05-14 18:53:01 --> URI Class Initialized
INFO - 2021-05-14 18:53:01 --> Router Class Initialized
INFO - 2021-05-14 18:53:01 --> Output Class Initialized
INFO - 2021-05-14 18:53:01 --> Security Class Initialized
DEBUG - 2021-05-14 18:53:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 18:53:01 --> Input Class Initialized
INFO - 2021-05-14 18:53:01 --> Language Class Initialized
ERROR - 2021-05-14 18:53:01 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-05-14 18:53:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 18:53:36 --> Config Class Initialized
INFO - 2021-05-14 18:53:36 --> Hooks Class Initialized
DEBUG - 2021-05-14 18:53:36 --> UTF-8 Support Enabled
INFO - 2021-05-14 18:53:36 --> Utf8 Class Initialized
INFO - 2021-05-14 18:53:36 --> URI Class Initialized
INFO - 2021-05-14 18:53:36 --> Router Class Initialized
INFO - 2021-05-14 18:53:36 --> Output Class Initialized
INFO - 2021-05-14 18:53:36 --> Security Class Initialized
DEBUG - 2021-05-14 18:53:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 18:53:36 --> Input Class Initialized
INFO - 2021-05-14 18:53:36 --> Language Class Initialized
INFO - 2021-05-14 18:53:36 --> Loader Class Initialized
INFO - 2021-05-14 18:53:36 --> Helper loaded: url_helper
INFO - 2021-05-14 18:53:36 --> Helper loaded: form_helper
INFO - 2021-05-14 18:53:36 --> Helper loaded: common_helper
INFO - 2021-05-14 18:53:36 --> Database Driver Class Initialized
DEBUG - 2021-05-14 18:53:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 18:53:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 18:53:36 --> Controller Class Initialized
INFO - 2021-05-14 18:53:36 --> Form Validation Class Initialized
INFO - 2021-05-14 18:53:36 --> Model "Case_model" initialized
INFO - 2021-05-14 18:53:36 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
ERROR - 2021-05-14 18:54:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 18:54:57 --> Config Class Initialized
INFO - 2021-05-14 18:54:57 --> Hooks Class Initialized
DEBUG - 2021-05-14 18:54:57 --> UTF-8 Support Enabled
INFO - 2021-05-14 18:54:57 --> Utf8 Class Initialized
INFO - 2021-05-14 18:54:57 --> URI Class Initialized
INFO - 2021-05-14 18:54:57 --> Router Class Initialized
INFO - 2021-05-14 18:54:57 --> Output Class Initialized
INFO - 2021-05-14 18:54:57 --> Security Class Initialized
DEBUG - 2021-05-14 18:54:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 18:54:57 --> Input Class Initialized
INFO - 2021-05-14 18:54:57 --> Language Class Initialized
INFO - 2021-05-14 18:54:57 --> Loader Class Initialized
INFO - 2021-05-14 18:54:57 --> Helper loaded: url_helper
INFO - 2021-05-14 18:54:57 --> Helper loaded: form_helper
INFO - 2021-05-14 18:54:57 --> Helper loaded: common_helper
INFO - 2021-05-14 18:54:57 --> Database Driver Class Initialized
DEBUG - 2021-05-14 18:54:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 18:54:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 18:54:57 --> Controller Class Initialized
INFO - 2021-05-14 18:54:57 --> Form Validation Class Initialized
INFO - 2021-05-14 18:54:57 --> Model "Case_model" initialized
INFO - 2021-05-14 18:54:57 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-05-14 18:54:57 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\transaction/donner_donation.php
INFO - 2021-05-14 18:54:57 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-05-14 18:54:57 --> Final output sent to browser
DEBUG - 2021-05-14 18:54:57 --> Total execution time: 0.0562
ERROR - 2021-05-14 18:54:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 18:54:57 --> Config Class Initialized
INFO - 2021-05-14 18:54:57 --> Hooks Class Initialized
DEBUG - 2021-05-14 18:54:57 --> UTF-8 Support Enabled
INFO - 2021-05-14 18:54:57 --> Utf8 Class Initialized
INFO - 2021-05-14 18:54:57 --> URI Class Initialized
INFO - 2021-05-14 18:54:57 --> Router Class Initialized
INFO - 2021-05-14 18:54:57 --> Output Class Initialized
INFO - 2021-05-14 18:54:57 --> Security Class Initialized
DEBUG - 2021-05-14 18:54:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 18:54:57 --> Input Class Initialized
INFO - 2021-05-14 18:54:57 --> Language Class Initialized
ERROR - 2021-05-14 18:54:57 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-05-14 18:55:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 18:55:11 --> Config Class Initialized
INFO - 2021-05-14 18:55:11 --> Hooks Class Initialized
DEBUG - 2021-05-14 18:55:11 --> UTF-8 Support Enabled
INFO - 2021-05-14 18:55:11 --> Utf8 Class Initialized
INFO - 2021-05-14 18:55:11 --> URI Class Initialized
INFO - 2021-05-14 18:55:11 --> Router Class Initialized
INFO - 2021-05-14 18:55:11 --> Output Class Initialized
INFO - 2021-05-14 18:55:11 --> Security Class Initialized
DEBUG - 2021-05-14 18:55:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 18:55:11 --> Input Class Initialized
INFO - 2021-05-14 18:55:11 --> Language Class Initialized
INFO - 2021-05-14 18:55:11 --> Loader Class Initialized
INFO - 2021-05-14 18:55:11 --> Helper loaded: url_helper
INFO - 2021-05-14 18:55:11 --> Helper loaded: form_helper
INFO - 2021-05-14 18:55:11 --> Helper loaded: common_helper
INFO - 2021-05-14 18:55:11 --> Database Driver Class Initialized
DEBUG - 2021-05-14 18:55:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 18:55:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 18:55:11 --> Controller Class Initialized
INFO - 2021-05-14 18:55:11 --> Form Validation Class Initialized
INFO - 2021-05-14 18:55:11 --> Model "Case_model" initialized
INFO - 2021-05-14 18:55:11 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-05-14 18:55:11 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\transaction/donner_donation.php
INFO - 2021-05-14 18:55:11 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-05-14 18:55:11 --> Final output sent to browser
DEBUG - 2021-05-14 18:55:11 --> Total execution time: 0.0568
ERROR - 2021-05-14 18:55:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 18:55:11 --> Config Class Initialized
INFO - 2021-05-14 18:55:11 --> Hooks Class Initialized
DEBUG - 2021-05-14 18:55:11 --> UTF-8 Support Enabled
INFO - 2021-05-14 18:55:11 --> Utf8 Class Initialized
INFO - 2021-05-14 18:55:11 --> URI Class Initialized
INFO - 2021-05-14 18:55:11 --> Router Class Initialized
INFO - 2021-05-14 18:55:11 --> Output Class Initialized
INFO - 2021-05-14 18:55:11 --> Security Class Initialized
DEBUG - 2021-05-14 18:55:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 18:55:11 --> Input Class Initialized
INFO - 2021-05-14 18:55:11 --> Language Class Initialized
ERROR - 2021-05-14 18:55:11 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-05-14 18:55:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 18:55:42 --> Config Class Initialized
INFO - 2021-05-14 18:55:42 --> Hooks Class Initialized
DEBUG - 2021-05-14 18:55:42 --> UTF-8 Support Enabled
INFO - 2021-05-14 18:55:42 --> Utf8 Class Initialized
INFO - 2021-05-14 18:55:42 --> URI Class Initialized
INFO - 2021-05-14 18:55:42 --> Router Class Initialized
INFO - 2021-05-14 18:55:42 --> Output Class Initialized
INFO - 2021-05-14 18:55:42 --> Security Class Initialized
DEBUG - 2021-05-14 18:55:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 18:55:42 --> Input Class Initialized
INFO - 2021-05-14 18:55:42 --> Language Class Initialized
INFO - 2021-05-14 18:55:42 --> Loader Class Initialized
INFO - 2021-05-14 18:55:42 --> Helper loaded: url_helper
INFO - 2021-05-14 18:55:42 --> Helper loaded: form_helper
INFO - 2021-05-14 18:55:42 --> Helper loaded: common_helper
INFO - 2021-05-14 18:55:42 --> Database Driver Class Initialized
DEBUG - 2021-05-14 18:55:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 18:55:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 18:55:42 --> Controller Class Initialized
INFO - 2021-05-14 18:55:42 --> Form Validation Class Initialized
INFO - 2021-05-14 18:55:42 --> Model "Case_model" initialized
INFO - 2021-05-14 18:55:42 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-05-14 18:55:42 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\transaction/donner_donation.php
INFO - 2021-05-14 18:55:42 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-05-14 18:55:42 --> Final output sent to browser
DEBUG - 2021-05-14 18:55:42 --> Total execution time: 0.0681
ERROR - 2021-05-14 18:55:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 18:55:43 --> Config Class Initialized
INFO - 2021-05-14 18:55:43 --> Hooks Class Initialized
DEBUG - 2021-05-14 18:55:43 --> UTF-8 Support Enabled
INFO - 2021-05-14 18:55:43 --> Utf8 Class Initialized
INFO - 2021-05-14 18:55:43 --> URI Class Initialized
INFO - 2021-05-14 18:55:43 --> Router Class Initialized
INFO - 2021-05-14 18:55:43 --> Output Class Initialized
INFO - 2021-05-14 18:55:43 --> Security Class Initialized
DEBUG - 2021-05-14 18:55:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 18:55:43 --> Input Class Initialized
INFO - 2021-05-14 18:55:43 --> Language Class Initialized
ERROR - 2021-05-14 18:55:43 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-05-14 18:55:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 18:55:57 --> Config Class Initialized
INFO - 2021-05-14 18:55:57 --> Hooks Class Initialized
DEBUG - 2021-05-14 18:55:57 --> UTF-8 Support Enabled
INFO - 2021-05-14 18:55:57 --> Utf8 Class Initialized
INFO - 2021-05-14 18:55:57 --> URI Class Initialized
INFO - 2021-05-14 18:55:57 --> Router Class Initialized
INFO - 2021-05-14 18:55:57 --> Output Class Initialized
INFO - 2021-05-14 18:55:57 --> Security Class Initialized
DEBUG - 2021-05-14 18:55:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 18:55:57 --> Input Class Initialized
INFO - 2021-05-14 18:55:57 --> Language Class Initialized
INFO - 2021-05-14 18:55:57 --> Loader Class Initialized
INFO - 2021-05-14 18:55:57 --> Helper loaded: url_helper
INFO - 2021-05-14 18:55:57 --> Helper loaded: form_helper
INFO - 2021-05-14 18:55:57 --> Helper loaded: common_helper
INFO - 2021-05-14 18:55:57 --> Database Driver Class Initialized
DEBUG - 2021-05-14 18:55:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 18:55:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 18:55:57 --> Controller Class Initialized
INFO - 2021-05-14 18:55:57 --> Form Validation Class Initialized
INFO - 2021-05-14 18:55:57 --> Model "Case_model" initialized
INFO - 2021-05-14 18:55:57 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-05-14 18:55:57 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\transaction/donner_donation.php
INFO - 2021-05-14 18:55:57 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-05-14 18:55:57 --> Final output sent to browser
DEBUG - 2021-05-14 18:55:57 --> Total execution time: 0.0677
ERROR - 2021-05-14 18:55:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 18:55:57 --> Config Class Initialized
INFO - 2021-05-14 18:55:57 --> Hooks Class Initialized
DEBUG - 2021-05-14 18:55:57 --> UTF-8 Support Enabled
INFO - 2021-05-14 18:55:57 --> Utf8 Class Initialized
INFO - 2021-05-14 18:55:57 --> URI Class Initialized
INFO - 2021-05-14 18:55:57 --> Router Class Initialized
INFO - 2021-05-14 18:55:57 --> Output Class Initialized
INFO - 2021-05-14 18:55:57 --> Security Class Initialized
DEBUG - 2021-05-14 18:55:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 18:55:57 --> Input Class Initialized
INFO - 2021-05-14 18:55:57 --> Language Class Initialized
ERROR - 2021-05-14 18:55:57 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-05-14 18:58:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 18:58:42 --> Config Class Initialized
INFO - 2021-05-14 18:58:42 --> Hooks Class Initialized
DEBUG - 2021-05-14 18:58:42 --> UTF-8 Support Enabled
INFO - 2021-05-14 18:58:42 --> Utf8 Class Initialized
INFO - 2021-05-14 18:58:42 --> URI Class Initialized
INFO - 2021-05-14 18:58:42 --> Router Class Initialized
INFO - 2021-05-14 18:58:42 --> Output Class Initialized
INFO - 2021-05-14 18:58:42 --> Security Class Initialized
DEBUG - 2021-05-14 18:58:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 18:58:42 --> Input Class Initialized
INFO - 2021-05-14 18:58:42 --> Language Class Initialized
INFO - 2021-05-14 18:58:42 --> Loader Class Initialized
INFO - 2021-05-14 18:58:42 --> Helper loaded: url_helper
INFO - 2021-05-14 18:58:42 --> Helper loaded: form_helper
INFO - 2021-05-14 18:58:42 --> Helper loaded: common_helper
INFO - 2021-05-14 18:58:42 --> Database Driver Class Initialized
DEBUG - 2021-05-14 18:58:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 18:58:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 18:58:42 --> Controller Class Initialized
INFO - 2021-05-14 18:58:42 --> Form Validation Class Initialized
INFO - 2021-05-14 18:58:42 --> Model "Case_model" initialized
INFO - 2021-05-14 18:58:42 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-05-14 18:58:42 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\transaction/donner_donation.php
INFO - 2021-05-14 18:58:42 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-05-14 18:58:42 --> Final output sent to browser
DEBUG - 2021-05-14 18:58:42 --> Total execution time: 0.0633
ERROR - 2021-05-14 18:58:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 18:58:43 --> Config Class Initialized
INFO - 2021-05-14 18:58:43 --> Hooks Class Initialized
DEBUG - 2021-05-14 18:58:43 --> UTF-8 Support Enabled
INFO - 2021-05-14 18:58:43 --> Utf8 Class Initialized
INFO - 2021-05-14 18:58:43 --> URI Class Initialized
INFO - 2021-05-14 18:58:43 --> Router Class Initialized
INFO - 2021-05-14 18:58:43 --> Output Class Initialized
INFO - 2021-05-14 18:58:43 --> Security Class Initialized
DEBUG - 2021-05-14 18:58:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 18:58:43 --> Input Class Initialized
INFO - 2021-05-14 18:58:43 --> Language Class Initialized
ERROR - 2021-05-14 18:58:43 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-05-14 19:00:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 19:00:37 --> Config Class Initialized
INFO - 2021-05-14 19:00:37 --> Hooks Class Initialized
DEBUG - 2021-05-14 19:00:37 --> UTF-8 Support Enabled
INFO - 2021-05-14 19:00:37 --> Utf8 Class Initialized
INFO - 2021-05-14 19:00:37 --> URI Class Initialized
INFO - 2021-05-14 19:00:37 --> Router Class Initialized
INFO - 2021-05-14 19:00:37 --> Output Class Initialized
INFO - 2021-05-14 19:00:37 --> Security Class Initialized
DEBUG - 2021-05-14 19:00:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 19:00:37 --> Input Class Initialized
INFO - 2021-05-14 19:00:37 --> Language Class Initialized
INFO - 2021-05-14 19:00:37 --> Loader Class Initialized
INFO - 2021-05-14 19:00:37 --> Helper loaded: url_helper
INFO - 2021-05-14 19:00:37 --> Helper loaded: form_helper
INFO - 2021-05-14 19:00:37 --> Helper loaded: common_helper
INFO - 2021-05-14 19:00:37 --> Database Driver Class Initialized
DEBUG - 2021-05-14 19:00:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 19:00:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 19:00:37 --> Controller Class Initialized
INFO - 2021-05-14 19:00:37 --> Form Validation Class Initialized
INFO - 2021-05-14 19:00:37 --> Model "Case_model" initialized
INFO - 2021-05-14 19:00:37 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-05-14 19:00:37 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\transaction/donner_donation.php
INFO - 2021-05-14 19:00:37 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-05-14 19:00:37 --> Final output sent to browser
DEBUG - 2021-05-14 19:00:37 --> Total execution time: 0.0506
ERROR - 2021-05-14 19:00:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 19:00:38 --> Config Class Initialized
INFO - 2021-05-14 19:00:38 --> Hooks Class Initialized
DEBUG - 2021-05-14 19:00:38 --> UTF-8 Support Enabled
INFO - 2021-05-14 19:00:38 --> Utf8 Class Initialized
INFO - 2021-05-14 19:00:38 --> URI Class Initialized
INFO - 2021-05-14 19:00:38 --> Router Class Initialized
INFO - 2021-05-14 19:00:38 --> Output Class Initialized
INFO - 2021-05-14 19:00:38 --> Security Class Initialized
DEBUG - 2021-05-14 19:00:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 19:00:38 --> Input Class Initialized
INFO - 2021-05-14 19:00:38 --> Language Class Initialized
ERROR - 2021-05-14 19:00:38 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-05-14 19:07:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 19:07:24 --> Config Class Initialized
INFO - 2021-05-14 19:07:24 --> Hooks Class Initialized
DEBUG - 2021-05-14 19:07:24 --> UTF-8 Support Enabled
INFO - 2021-05-14 19:07:24 --> Utf8 Class Initialized
INFO - 2021-05-14 19:07:24 --> URI Class Initialized
INFO - 2021-05-14 19:07:24 --> Router Class Initialized
INFO - 2021-05-14 19:07:24 --> Output Class Initialized
INFO - 2021-05-14 19:07:24 --> Security Class Initialized
DEBUG - 2021-05-14 19:07:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 19:07:24 --> Input Class Initialized
INFO - 2021-05-14 19:07:24 --> Language Class Initialized
INFO - 2021-05-14 19:07:24 --> Loader Class Initialized
INFO - 2021-05-14 19:07:24 --> Helper loaded: url_helper
INFO - 2021-05-14 19:07:24 --> Helper loaded: form_helper
INFO - 2021-05-14 19:07:24 --> Helper loaded: common_helper
INFO - 2021-05-14 19:07:24 --> Database Driver Class Initialized
DEBUG - 2021-05-14 19:07:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 19:07:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 19:07:24 --> Controller Class Initialized
INFO - 2021-05-14 19:07:24 --> Form Validation Class Initialized
INFO - 2021-05-14 19:07:24 --> Model "Case_model" initialized
INFO - 2021-05-14 19:07:24 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-05-14 19:07:24 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\transaction/donner_donation.php
INFO - 2021-05-14 19:07:24 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-05-14 19:07:24 --> Final output sent to browser
DEBUG - 2021-05-14 19:07:24 --> Total execution time: 0.0610
ERROR - 2021-05-14 19:07:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 19:07:24 --> Config Class Initialized
INFO - 2021-05-14 19:07:24 --> Hooks Class Initialized
DEBUG - 2021-05-14 19:07:24 --> UTF-8 Support Enabled
INFO - 2021-05-14 19:07:24 --> Utf8 Class Initialized
INFO - 2021-05-14 19:07:24 --> URI Class Initialized
INFO - 2021-05-14 19:07:24 --> Router Class Initialized
INFO - 2021-05-14 19:07:24 --> Output Class Initialized
INFO - 2021-05-14 19:07:24 --> Security Class Initialized
DEBUG - 2021-05-14 19:07:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 19:07:24 --> Input Class Initialized
INFO - 2021-05-14 19:07:24 --> Language Class Initialized
ERROR - 2021-05-14 19:07:24 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-05-14 19:07:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 19:07:47 --> Config Class Initialized
INFO - 2021-05-14 19:07:47 --> Hooks Class Initialized
DEBUG - 2021-05-14 19:07:47 --> UTF-8 Support Enabled
INFO - 2021-05-14 19:07:47 --> Utf8 Class Initialized
INFO - 2021-05-14 19:07:47 --> URI Class Initialized
INFO - 2021-05-14 19:07:47 --> Router Class Initialized
INFO - 2021-05-14 19:07:47 --> Output Class Initialized
INFO - 2021-05-14 19:07:47 --> Security Class Initialized
DEBUG - 2021-05-14 19:07:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 19:07:47 --> Input Class Initialized
INFO - 2021-05-14 19:07:47 --> Language Class Initialized
INFO - 2021-05-14 19:07:47 --> Loader Class Initialized
INFO - 2021-05-14 19:07:47 --> Helper loaded: url_helper
INFO - 2021-05-14 19:07:47 --> Helper loaded: form_helper
INFO - 2021-05-14 19:07:47 --> Helper loaded: common_helper
INFO - 2021-05-14 19:07:48 --> Database Driver Class Initialized
DEBUG - 2021-05-14 19:07:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 19:07:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 19:07:48 --> Controller Class Initialized
INFO - 2021-05-14 19:07:48 --> Form Validation Class Initialized
INFO - 2021-05-14 19:07:48 --> Model "Case_model" initialized
INFO - 2021-05-14 19:07:48 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-05-14 19:07:48 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\transaction/donner_donation.php
INFO - 2021-05-14 19:07:48 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-05-14 19:07:48 --> Final output sent to browser
DEBUG - 2021-05-14 19:07:48 --> Total execution time: 0.0570
ERROR - 2021-05-14 19:07:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 19:07:48 --> Config Class Initialized
INFO - 2021-05-14 19:07:48 --> Hooks Class Initialized
DEBUG - 2021-05-14 19:07:48 --> UTF-8 Support Enabled
INFO - 2021-05-14 19:07:48 --> Utf8 Class Initialized
INFO - 2021-05-14 19:07:48 --> URI Class Initialized
INFO - 2021-05-14 19:07:48 --> Router Class Initialized
INFO - 2021-05-14 19:07:48 --> Output Class Initialized
INFO - 2021-05-14 19:07:48 --> Security Class Initialized
DEBUG - 2021-05-14 19:07:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 19:07:48 --> Input Class Initialized
INFO - 2021-05-14 19:07:48 --> Language Class Initialized
ERROR - 2021-05-14 19:07:48 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-05-14 19:25:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 19:25:10 --> Config Class Initialized
INFO - 2021-05-14 19:25:10 --> Hooks Class Initialized
DEBUG - 2021-05-14 19:25:10 --> UTF-8 Support Enabled
INFO - 2021-05-14 19:25:10 --> Utf8 Class Initialized
INFO - 2021-05-14 19:25:10 --> URI Class Initialized
INFO - 2021-05-14 19:25:10 --> Router Class Initialized
INFO - 2021-05-14 19:25:10 --> Output Class Initialized
INFO - 2021-05-14 19:25:10 --> Security Class Initialized
DEBUG - 2021-05-14 19:25:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 19:25:10 --> Input Class Initialized
INFO - 2021-05-14 19:25:10 --> Language Class Initialized
INFO - 2021-05-14 19:25:10 --> Loader Class Initialized
INFO - 2021-05-14 19:25:10 --> Helper loaded: url_helper
INFO - 2021-05-14 19:25:10 --> Helper loaded: form_helper
INFO - 2021-05-14 19:25:10 --> Helper loaded: common_helper
INFO - 2021-05-14 19:25:10 --> Database Driver Class Initialized
DEBUG - 2021-05-14 19:25:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 19:25:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 19:25:10 --> Controller Class Initialized
INFO - 2021-05-14 19:25:10 --> Form Validation Class Initialized
INFO - 2021-05-14 19:25:10 --> Model "Case_model" initialized
INFO - 2021-05-14 19:25:10 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
ERROR - 2021-05-14 19:25:10 --> Severity: error --> Exception: Cannot pass parameter 2 by reference C:\xampp\htdocs\study\karosoftware\application\helpers\common_helper.php 24
ERROR - 2021-05-14 19:26:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 19:26:02 --> Config Class Initialized
INFO - 2021-05-14 19:26:02 --> Hooks Class Initialized
DEBUG - 2021-05-14 19:26:02 --> UTF-8 Support Enabled
INFO - 2021-05-14 19:26:02 --> Utf8 Class Initialized
INFO - 2021-05-14 19:26:02 --> URI Class Initialized
INFO - 2021-05-14 19:26:02 --> Router Class Initialized
INFO - 2021-05-14 19:26:02 --> Output Class Initialized
INFO - 2021-05-14 19:26:02 --> Security Class Initialized
DEBUG - 2021-05-14 19:26:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 19:26:02 --> Input Class Initialized
INFO - 2021-05-14 19:26:02 --> Language Class Initialized
INFO - 2021-05-14 19:26:02 --> Loader Class Initialized
INFO - 2021-05-14 19:26:02 --> Helper loaded: url_helper
INFO - 2021-05-14 19:26:02 --> Helper loaded: form_helper
ERROR - 2021-05-14 19:26:02 --> Severity: error --> Exception: syntax error, unexpected '&' C:\xampp\htdocs\study\karosoftware\application\helpers\common_helper.php 24
ERROR - 2021-05-14 19:26:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 19:26:10 --> Config Class Initialized
INFO - 2021-05-14 19:26:10 --> Hooks Class Initialized
DEBUG - 2021-05-14 19:26:10 --> UTF-8 Support Enabled
INFO - 2021-05-14 19:26:10 --> Utf8 Class Initialized
INFO - 2021-05-14 19:26:10 --> URI Class Initialized
INFO - 2021-05-14 19:26:10 --> Router Class Initialized
INFO - 2021-05-14 19:26:10 --> Output Class Initialized
INFO - 2021-05-14 19:26:10 --> Security Class Initialized
DEBUG - 2021-05-14 19:26:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 19:26:10 --> Input Class Initialized
INFO - 2021-05-14 19:26:10 --> Language Class Initialized
INFO - 2021-05-14 19:26:10 --> Loader Class Initialized
INFO - 2021-05-14 19:26:10 --> Helper loaded: url_helper
INFO - 2021-05-14 19:26:10 --> Helper loaded: form_helper
INFO - 2021-05-14 19:26:10 --> Helper loaded: common_helper
INFO - 2021-05-14 19:26:10 --> Database Driver Class Initialized
DEBUG - 2021-05-14 19:26:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 19:26:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 19:26:10 --> Controller Class Initialized
INFO - 2021-05-14 19:26:10 --> Form Validation Class Initialized
INFO - 2021-05-14 19:26:10 --> Model "Case_model" initialized
INFO - 2021-05-14 19:26:10 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-05-14 19:26:10 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\transaction/donner_donation.php
INFO - 2021-05-14 19:26:10 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-05-14 19:26:10 --> Final output sent to browser
DEBUG - 2021-05-14 19:26:10 --> Total execution time: 0.0517
ERROR - 2021-05-14 19:26:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 19:26:10 --> Config Class Initialized
INFO - 2021-05-14 19:26:10 --> Hooks Class Initialized
DEBUG - 2021-05-14 19:26:10 --> UTF-8 Support Enabled
INFO - 2021-05-14 19:26:10 --> Utf8 Class Initialized
INFO - 2021-05-14 19:26:10 --> URI Class Initialized
INFO - 2021-05-14 19:26:10 --> Router Class Initialized
INFO - 2021-05-14 19:26:10 --> Output Class Initialized
INFO - 2021-05-14 19:26:10 --> Security Class Initialized
DEBUG - 2021-05-14 19:26:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 19:26:10 --> Input Class Initialized
INFO - 2021-05-14 19:26:10 --> Language Class Initialized
ERROR - 2021-05-14 19:26:10 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-05-14 19:26:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 19:26:37 --> Config Class Initialized
INFO - 2021-05-14 19:26:37 --> Hooks Class Initialized
DEBUG - 2021-05-14 19:26:37 --> UTF-8 Support Enabled
INFO - 2021-05-14 19:26:37 --> Utf8 Class Initialized
INFO - 2021-05-14 19:26:37 --> URI Class Initialized
INFO - 2021-05-14 19:26:37 --> Router Class Initialized
INFO - 2021-05-14 19:26:37 --> Output Class Initialized
INFO - 2021-05-14 19:26:37 --> Security Class Initialized
DEBUG - 2021-05-14 19:26:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 19:26:37 --> Input Class Initialized
INFO - 2021-05-14 19:26:37 --> Language Class Initialized
INFO - 2021-05-14 19:26:37 --> Loader Class Initialized
INFO - 2021-05-14 19:26:37 --> Helper loaded: url_helper
INFO - 2021-05-14 19:26:37 --> Helper loaded: form_helper
INFO - 2021-05-14 19:26:37 --> Helper loaded: common_helper
INFO - 2021-05-14 19:26:37 --> Database Driver Class Initialized
DEBUG - 2021-05-14 19:26:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 19:26:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 19:26:37 --> Controller Class Initialized
INFO - 2021-05-14 19:26:37 --> Form Validation Class Initialized
INFO - 2021-05-14 19:26:37 --> Model "Case_model" initialized
INFO - 2021-05-14 19:26:37 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-05-14 19:26:37 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\transaction/donner_donation.php
INFO - 2021-05-14 19:26:37 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-05-14 19:26:37 --> Final output sent to browser
DEBUG - 2021-05-14 19:26:37 --> Total execution time: 0.0496
ERROR - 2021-05-14 19:26:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 19:26:37 --> Config Class Initialized
INFO - 2021-05-14 19:26:37 --> Hooks Class Initialized
DEBUG - 2021-05-14 19:26:37 --> UTF-8 Support Enabled
INFO - 2021-05-14 19:26:37 --> Utf8 Class Initialized
INFO - 2021-05-14 19:26:37 --> URI Class Initialized
INFO - 2021-05-14 19:26:37 --> Router Class Initialized
INFO - 2021-05-14 19:26:37 --> Output Class Initialized
INFO - 2021-05-14 19:26:37 --> Security Class Initialized
DEBUG - 2021-05-14 19:26:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 19:26:37 --> Input Class Initialized
INFO - 2021-05-14 19:26:37 --> Language Class Initialized
ERROR - 2021-05-14 19:26:37 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-05-14 19:26:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 19:26:54 --> Config Class Initialized
INFO - 2021-05-14 19:26:54 --> Hooks Class Initialized
DEBUG - 2021-05-14 19:26:54 --> UTF-8 Support Enabled
INFO - 2021-05-14 19:26:54 --> Utf8 Class Initialized
INFO - 2021-05-14 19:26:54 --> URI Class Initialized
INFO - 2021-05-14 19:26:54 --> Router Class Initialized
INFO - 2021-05-14 19:26:54 --> Output Class Initialized
INFO - 2021-05-14 19:26:54 --> Security Class Initialized
DEBUG - 2021-05-14 19:26:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 19:26:54 --> Input Class Initialized
INFO - 2021-05-14 19:26:54 --> Language Class Initialized
INFO - 2021-05-14 19:26:54 --> Loader Class Initialized
INFO - 2021-05-14 19:26:54 --> Helper loaded: url_helper
INFO - 2021-05-14 19:26:54 --> Helper loaded: form_helper
INFO - 2021-05-14 19:26:54 --> Helper loaded: common_helper
INFO - 2021-05-14 19:26:54 --> Database Driver Class Initialized
DEBUG - 2021-05-14 19:26:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 19:26:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 19:26:54 --> Controller Class Initialized
INFO - 2021-05-14 19:26:54 --> Form Validation Class Initialized
INFO - 2021-05-14 19:26:54 --> Model "Case_model" initialized
INFO - 2021-05-14 19:26:54 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-05-14 19:26:54 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\transaction/donner_donation.php
INFO - 2021-05-14 19:26:54 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-05-14 19:26:54 --> Final output sent to browser
DEBUG - 2021-05-14 19:26:54 --> Total execution time: 0.0505
ERROR - 2021-05-14 19:26:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 19:26:54 --> Config Class Initialized
INFO - 2021-05-14 19:26:54 --> Hooks Class Initialized
DEBUG - 2021-05-14 19:26:54 --> UTF-8 Support Enabled
INFO - 2021-05-14 19:26:54 --> Utf8 Class Initialized
INFO - 2021-05-14 19:26:54 --> URI Class Initialized
INFO - 2021-05-14 19:26:54 --> Router Class Initialized
INFO - 2021-05-14 19:26:54 --> Output Class Initialized
INFO - 2021-05-14 19:26:54 --> Security Class Initialized
DEBUG - 2021-05-14 19:26:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 19:26:54 --> Input Class Initialized
INFO - 2021-05-14 19:26:54 --> Language Class Initialized
ERROR - 2021-05-14 19:26:54 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-05-14 19:27:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 19:27:09 --> Config Class Initialized
INFO - 2021-05-14 19:27:09 --> Hooks Class Initialized
DEBUG - 2021-05-14 19:27:09 --> UTF-8 Support Enabled
INFO - 2021-05-14 19:27:09 --> Utf8 Class Initialized
INFO - 2021-05-14 19:27:09 --> URI Class Initialized
INFO - 2021-05-14 19:27:09 --> Router Class Initialized
INFO - 2021-05-14 19:27:09 --> Output Class Initialized
INFO - 2021-05-14 19:27:09 --> Security Class Initialized
DEBUG - 2021-05-14 19:27:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 19:27:09 --> Input Class Initialized
INFO - 2021-05-14 19:27:09 --> Language Class Initialized
INFO - 2021-05-14 19:27:09 --> Loader Class Initialized
INFO - 2021-05-14 19:27:09 --> Helper loaded: url_helper
INFO - 2021-05-14 19:27:09 --> Helper loaded: form_helper
INFO - 2021-05-14 19:27:09 --> Helper loaded: common_helper
INFO - 2021-05-14 19:27:09 --> Database Driver Class Initialized
DEBUG - 2021-05-14 19:27:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 19:27:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 19:27:09 --> Controller Class Initialized
INFO - 2021-05-14 19:27:09 --> Form Validation Class Initialized
INFO - 2021-05-14 19:27:09 --> Model "Case_model" initialized
INFO - 2021-05-14 19:27:09 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-05-14 19:27:09 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\transaction/donner_donation.php
INFO - 2021-05-14 19:27:09 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-05-14 19:27:09 --> Final output sent to browser
DEBUG - 2021-05-14 19:27:09 --> Total execution time: 0.0562
ERROR - 2021-05-14 19:27:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 19:27:10 --> Config Class Initialized
INFO - 2021-05-14 19:27:10 --> Hooks Class Initialized
DEBUG - 2021-05-14 19:27:10 --> UTF-8 Support Enabled
INFO - 2021-05-14 19:27:10 --> Utf8 Class Initialized
INFO - 2021-05-14 19:27:10 --> URI Class Initialized
INFO - 2021-05-14 19:27:10 --> Router Class Initialized
INFO - 2021-05-14 19:27:10 --> Output Class Initialized
INFO - 2021-05-14 19:27:10 --> Security Class Initialized
DEBUG - 2021-05-14 19:27:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 19:27:10 --> Input Class Initialized
INFO - 2021-05-14 19:27:10 --> Language Class Initialized
ERROR - 2021-05-14 19:27:10 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-05-14 19:31:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 19:31:27 --> Config Class Initialized
INFO - 2021-05-14 19:31:27 --> Hooks Class Initialized
DEBUG - 2021-05-14 19:31:27 --> UTF-8 Support Enabled
INFO - 2021-05-14 19:31:27 --> Utf8 Class Initialized
INFO - 2021-05-14 19:31:27 --> URI Class Initialized
INFO - 2021-05-14 19:31:27 --> Router Class Initialized
INFO - 2021-05-14 19:31:27 --> Output Class Initialized
INFO - 2021-05-14 19:31:27 --> Security Class Initialized
DEBUG - 2021-05-14 19:31:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 19:31:27 --> Input Class Initialized
INFO - 2021-05-14 19:31:27 --> Language Class Initialized
INFO - 2021-05-14 19:31:27 --> Loader Class Initialized
INFO - 2021-05-14 19:31:27 --> Helper loaded: url_helper
INFO - 2021-05-14 19:31:27 --> Helper loaded: form_helper
INFO - 2021-05-14 19:31:27 --> Helper loaded: common_helper
INFO - 2021-05-14 19:31:27 --> Database Driver Class Initialized
DEBUG - 2021-05-14 19:31:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 19:31:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 19:31:27 --> Controller Class Initialized
INFO - 2021-05-14 19:31:27 --> Form Validation Class Initialized
INFO - 2021-05-14 19:31:27 --> Model "Case_model" initialized
INFO - 2021-05-14 19:31:27 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-05-14 19:31:27 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\transaction/donner_donation.php
INFO - 2021-05-14 19:31:27 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-05-14 19:31:27 --> Final output sent to browser
DEBUG - 2021-05-14 19:31:27 --> Total execution time: 0.0718
ERROR - 2021-05-14 19:31:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 19:31:27 --> Config Class Initialized
INFO - 2021-05-14 19:31:27 --> Hooks Class Initialized
DEBUG - 2021-05-14 19:31:27 --> UTF-8 Support Enabled
INFO - 2021-05-14 19:31:27 --> Utf8 Class Initialized
INFO - 2021-05-14 19:31:27 --> URI Class Initialized
INFO - 2021-05-14 19:31:27 --> Router Class Initialized
INFO - 2021-05-14 19:31:27 --> Output Class Initialized
INFO - 2021-05-14 19:31:27 --> Security Class Initialized
DEBUG - 2021-05-14 19:31:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 19:31:27 --> Input Class Initialized
INFO - 2021-05-14 19:31:27 --> Language Class Initialized
ERROR - 2021-05-14 19:31:27 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-05-14 19:32:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 19:32:30 --> Config Class Initialized
INFO - 2021-05-14 19:32:30 --> Hooks Class Initialized
DEBUG - 2021-05-14 19:32:30 --> UTF-8 Support Enabled
INFO - 2021-05-14 19:32:30 --> Utf8 Class Initialized
INFO - 2021-05-14 19:32:30 --> URI Class Initialized
INFO - 2021-05-14 19:32:30 --> Router Class Initialized
INFO - 2021-05-14 19:32:30 --> Output Class Initialized
INFO - 2021-05-14 19:32:30 --> Security Class Initialized
DEBUG - 2021-05-14 19:32:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 19:32:30 --> Input Class Initialized
INFO - 2021-05-14 19:32:30 --> Language Class Initialized
INFO - 2021-05-14 19:32:30 --> Loader Class Initialized
INFO - 2021-05-14 19:32:30 --> Helper loaded: url_helper
INFO - 2021-05-14 19:32:30 --> Helper loaded: form_helper
INFO - 2021-05-14 19:32:30 --> Helper loaded: common_helper
INFO - 2021-05-14 19:32:30 --> Database Driver Class Initialized
DEBUG - 2021-05-14 19:32:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 19:32:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 19:32:30 --> Controller Class Initialized
INFO - 2021-05-14 19:32:30 --> Form Validation Class Initialized
INFO - 2021-05-14 19:32:30 --> Model "Case_model" initialized
INFO - 2021-05-14 19:32:30 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-05-14 19:32:30 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\transaction/donner_donation.php
INFO - 2021-05-14 19:32:30 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-05-14 19:32:30 --> Final output sent to browser
DEBUG - 2021-05-14 19:32:30 --> Total execution time: 0.0586
ERROR - 2021-05-14 19:32:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 19:32:30 --> Config Class Initialized
INFO - 2021-05-14 19:32:30 --> Hooks Class Initialized
DEBUG - 2021-05-14 19:32:30 --> UTF-8 Support Enabled
INFO - 2021-05-14 19:32:30 --> Utf8 Class Initialized
INFO - 2021-05-14 19:32:30 --> URI Class Initialized
INFO - 2021-05-14 19:32:30 --> Router Class Initialized
INFO - 2021-05-14 19:32:30 --> Output Class Initialized
INFO - 2021-05-14 19:32:30 --> Security Class Initialized
DEBUG - 2021-05-14 19:32:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 19:32:30 --> Input Class Initialized
INFO - 2021-05-14 19:32:30 --> Language Class Initialized
ERROR - 2021-05-14 19:32:30 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-05-14 19:32:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 19:32:50 --> Config Class Initialized
INFO - 2021-05-14 19:32:50 --> Hooks Class Initialized
DEBUG - 2021-05-14 19:32:50 --> UTF-8 Support Enabled
INFO - 2021-05-14 19:32:50 --> Utf8 Class Initialized
INFO - 2021-05-14 19:32:50 --> URI Class Initialized
INFO - 2021-05-14 19:32:50 --> Router Class Initialized
INFO - 2021-05-14 19:32:50 --> Output Class Initialized
INFO - 2021-05-14 19:32:50 --> Security Class Initialized
DEBUG - 2021-05-14 19:32:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 19:32:50 --> Input Class Initialized
INFO - 2021-05-14 19:32:50 --> Language Class Initialized
INFO - 2021-05-14 19:32:50 --> Loader Class Initialized
INFO - 2021-05-14 19:32:50 --> Helper loaded: url_helper
INFO - 2021-05-14 19:32:50 --> Helper loaded: form_helper
INFO - 2021-05-14 19:32:50 --> Helper loaded: common_helper
INFO - 2021-05-14 19:32:50 --> Database Driver Class Initialized
DEBUG - 2021-05-14 19:32:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 19:32:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 19:32:50 --> Controller Class Initialized
INFO - 2021-05-14 19:32:50 --> Form Validation Class Initialized
INFO - 2021-05-14 19:32:50 --> Model "Case_model" initialized
INFO - 2021-05-14 19:32:50 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-05-14 19:32:50 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\transaction/donner_donation.php
INFO - 2021-05-14 19:32:50 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-05-14 19:32:50 --> Final output sent to browser
DEBUG - 2021-05-14 19:32:50 --> Total execution time: 0.0613
ERROR - 2021-05-14 19:32:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 19:32:50 --> Config Class Initialized
INFO - 2021-05-14 19:32:50 --> Hooks Class Initialized
DEBUG - 2021-05-14 19:32:50 --> UTF-8 Support Enabled
INFO - 2021-05-14 19:32:50 --> Utf8 Class Initialized
INFO - 2021-05-14 19:32:50 --> URI Class Initialized
INFO - 2021-05-14 19:32:50 --> Router Class Initialized
INFO - 2021-05-14 19:32:50 --> Output Class Initialized
INFO - 2021-05-14 19:32:50 --> Security Class Initialized
DEBUG - 2021-05-14 19:32:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 19:32:50 --> Input Class Initialized
INFO - 2021-05-14 19:32:50 --> Language Class Initialized
ERROR - 2021-05-14 19:32:50 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-05-14 19:32:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 19:32:53 --> Config Class Initialized
INFO - 2021-05-14 19:32:53 --> Hooks Class Initialized
DEBUG - 2021-05-14 19:32:53 --> UTF-8 Support Enabled
INFO - 2021-05-14 19:32:53 --> Utf8 Class Initialized
INFO - 2021-05-14 19:32:53 --> URI Class Initialized
INFO - 2021-05-14 19:32:53 --> Router Class Initialized
INFO - 2021-05-14 19:32:53 --> Output Class Initialized
INFO - 2021-05-14 19:32:53 --> Security Class Initialized
DEBUG - 2021-05-14 19:32:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 19:32:53 --> Input Class Initialized
INFO - 2021-05-14 19:32:53 --> Language Class Initialized
INFO - 2021-05-14 19:32:53 --> Loader Class Initialized
INFO - 2021-05-14 19:32:53 --> Helper loaded: url_helper
INFO - 2021-05-14 19:32:53 --> Helper loaded: form_helper
INFO - 2021-05-14 19:32:53 --> Helper loaded: common_helper
INFO - 2021-05-14 19:32:53 --> Database Driver Class Initialized
DEBUG - 2021-05-14 19:32:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 19:32:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 19:32:53 --> Controller Class Initialized
INFO - 2021-05-14 19:32:53 --> Form Validation Class Initialized
INFO - 2021-05-14 19:32:53 --> Encrypt Class Initialized
INFO - 2021-05-14 19:32:53 --> Model "Login_model" initialized
INFO - 2021-05-14 19:32:53 --> Model "Dashboard_model" initialized
INFO - 2021-05-14 19:32:53 --> Model "Case_model" initialized
INFO - 2021-05-14 19:32:58 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-05-14 19:33:10 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\dashboard/index.php
INFO - 2021-05-14 19:33:10 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-05-14 19:33:10 --> Final output sent to browser
DEBUG - 2021-05-14 19:33:10 --> Total execution time: 16.4023
ERROR - 2021-05-14 19:33:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 19:33:10 --> Config Class Initialized
INFO - 2021-05-14 19:33:10 --> Hooks Class Initialized
DEBUG - 2021-05-14 19:33:10 --> UTF-8 Support Enabled
INFO - 2021-05-14 19:33:10 --> Utf8 Class Initialized
INFO - 2021-05-14 19:33:10 --> URI Class Initialized
INFO - 2021-05-14 19:33:10 --> Router Class Initialized
INFO - 2021-05-14 19:33:10 --> Output Class Initialized
INFO - 2021-05-14 19:33:10 --> Security Class Initialized
DEBUG - 2021-05-14 19:33:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 19:33:10 --> Input Class Initialized
INFO - 2021-05-14 19:33:10 --> Language Class Initialized
ERROR - 2021-05-14 19:33:10 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-05-14 19:43:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 19:43:25 --> Config Class Initialized
INFO - 2021-05-14 19:43:25 --> Hooks Class Initialized
DEBUG - 2021-05-14 19:43:25 --> UTF-8 Support Enabled
INFO - 2021-05-14 19:43:25 --> Utf8 Class Initialized
INFO - 2021-05-14 19:43:25 --> URI Class Initialized
INFO - 2021-05-14 19:43:25 --> Router Class Initialized
INFO - 2021-05-14 19:43:25 --> Output Class Initialized
INFO - 2021-05-14 19:43:25 --> Security Class Initialized
DEBUG - 2021-05-14 19:43:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 19:43:25 --> Input Class Initialized
INFO - 2021-05-14 19:43:25 --> Language Class Initialized
INFO - 2021-05-14 19:43:25 --> Loader Class Initialized
INFO - 2021-05-14 19:43:25 --> Helper loaded: url_helper
INFO - 2021-05-14 19:43:25 --> Helper loaded: form_helper
INFO - 2021-05-14 19:43:25 --> Helper loaded: common_helper
INFO - 2021-05-14 19:43:25 --> Database Driver Class Initialized
DEBUG - 2021-05-14 19:43:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 19:43:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 19:43:25 --> Controller Class Initialized
INFO - 2021-05-14 19:43:25 --> Form Validation Class Initialized
INFO - 2021-05-14 19:43:25 --> Encrypt Class Initialized
INFO - 2021-05-14 19:43:25 --> Model "Login_model" initialized
INFO - 2021-05-14 19:43:25 --> Model "Dashboard_model" initialized
INFO - 2021-05-14 19:43:25 --> Model "Case_model" initialized
INFO - 2021-05-14 19:43:30 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-05-14 19:43:42 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\dashboard/index.php
INFO - 2021-05-14 19:43:42 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-05-14 19:43:42 --> Final output sent to browser
DEBUG - 2021-05-14 19:43:42 --> Total execution time: 17.2913
ERROR - 2021-05-14 19:43:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 19:43:43 --> Config Class Initialized
INFO - 2021-05-14 19:43:43 --> Hooks Class Initialized
DEBUG - 2021-05-14 19:43:43 --> UTF-8 Support Enabled
INFO - 2021-05-14 19:43:43 --> Utf8 Class Initialized
INFO - 2021-05-14 19:43:43 --> URI Class Initialized
INFO - 2021-05-14 19:43:43 --> Router Class Initialized
INFO - 2021-05-14 19:43:43 --> Output Class Initialized
INFO - 2021-05-14 19:43:43 --> Security Class Initialized
DEBUG - 2021-05-14 19:43:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 19:43:43 --> Input Class Initialized
INFO - 2021-05-14 19:43:43 --> Language Class Initialized
ERROR - 2021-05-14 19:43:43 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-05-14 19:45:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 19:45:07 --> Config Class Initialized
INFO - 2021-05-14 19:45:07 --> Hooks Class Initialized
DEBUG - 2021-05-14 19:45:07 --> UTF-8 Support Enabled
INFO - 2021-05-14 19:45:07 --> Utf8 Class Initialized
INFO - 2021-05-14 19:45:07 --> URI Class Initialized
INFO - 2021-05-14 19:45:07 --> Router Class Initialized
INFO - 2021-05-14 19:45:07 --> Output Class Initialized
INFO - 2021-05-14 19:45:07 --> Security Class Initialized
DEBUG - 2021-05-14 19:45:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 19:45:07 --> Input Class Initialized
INFO - 2021-05-14 19:45:07 --> Language Class Initialized
INFO - 2021-05-14 19:45:07 --> Loader Class Initialized
INFO - 2021-05-14 19:45:07 --> Helper loaded: url_helper
INFO - 2021-05-14 19:45:07 --> Helper loaded: form_helper
INFO - 2021-05-14 19:45:07 --> Helper loaded: common_helper
INFO - 2021-05-14 19:45:07 --> Database Driver Class Initialized
DEBUG - 2021-05-14 19:45:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 19:45:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 19:45:07 --> Controller Class Initialized
INFO - 2021-05-14 19:45:07 --> Form Validation Class Initialized
INFO - 2021-05-14 19:45:07 --> Encrypt Class Initialized
INFO - 2021-05-14 19:45:07 --> Model "Login_model" initialized
INFO - 2021-05-14 19:45:07 --> Model "Dashboard_model" initialized
INFO - 2021-05-14 19:45:07 --> Model "Case_model" initialized
INFO - 2021-05-14 19:45:12 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
ERROR - 2021-05-14 19:45:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 19:45:18 --> Config Class Initialized
INFO - 2021-05-14 19:45:18 --> Hooks Class Initialized
DEBUG - 2021-05-14 19:45:18 --> UTF-8 Support Enabled
INFO - 2021-05-14 19:45:18 --> Utf8 Class Initialized
INFO - 2021-05-14 19:45:18 --> URI Class Initialized
INFO - 2021-05-14 19:45:18 --> Router Class Initialized
INFO - 2021-05-14 19:45:18 --> Output Class Initialized
INFO - 2021-05-14 19:45:18 --> Security Class Initialized
DEBUG - 2021-05-14 19:45:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 19:45:18 --> Input Class Initialized
INFO - 2021-05-14 19:45:18 --> Language Class Initialized
INFO - 2021-05-14 19:45:18 --> Loader Class Initialized
INFO - 2021-05-14 19:45:18 --> Helper loaded: url_helper
INFO - 2021-05-14 19:45:18 --> Helper loaded: form_helper
INFO - 2021-05-14 19:45:18 --> Helper loaded: common_helper
INFO - 2021-05-14 19:45:18 --> Database Driver Class Initialized
DEBUG - 2021-05-14 19:45:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 19:45:24 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\dashboard/index.php
INFO - 2021-05-14 19:45:24 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-05-14 19:45:24 --> Final output sent to browser
DEBUG - 2021-05-14 19:45:24 --> Total execution time: 17.1954
INFO - 2021-05-14 19:45:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 19:45:24 --> Controller Class Initialized
INFO - 2021-05-14 19:45:24 --> Form Validation Class Initialized
INFO - 2021-05-14 19:45:24 --> Encrypt Class Initialized
INFO - 2021-05-14 19:45:24 --> Model "Payment_model" initialized
INFO - 2021-05-14 19:45:24 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-05-14 19:45:24 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\payment/index.php
INFO - 2021-05-14 19:45:24 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-05-14 19:45:24 --> Final output sent to browser
DEBUG - 2021-05-14 19:45:24 --> Total execution time: 5.6660
ERROR - 2021-05-14 19:45:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 19:45:24 --> Config Class Initialized
INFO - 2021-05-14 19:45:24 --> Hooks Class Initialized
DEBUG - 2021-05-14 19:45:24 --> UTF-8 Support Enabled
INFO - 2021-05-14 19:45:24 --> Utf8 Class Initialized
INFO - 2021-05-14 19:45:24 --> URI Class Initialized
INFO - 2021-05-14 19:45:24 --> Router Class Initialized
INFO - 2021-05-14 19:45:24 --> Output Class Initialized
INFO - 2021-05-14 19:45:24 --> Security Class Initialized
DEBUG - 2021-05-14 19:45:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 19:45:24 --> Input Class Initialized
INFO - 2021-05-14 19:45:24 --> Language Class Initialized
ERROR - 2021-05-14 19:45:24 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-05-14 19:45:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 19:45:31 --> Config Class Initialized
INFO - 2021-05-14 19:45:31 --> Hooks Class Initialized
DEBUG - 2021-05-14 19:45:31 --> UTF-8 Support Enabled
INFO - 2021-05-14 19:45:31 --> Utf8 Class Initialized
INFO - 2021-05-14 19:45:31 --> URI Class Initialized
INFO - 2021-05-14 19:45:31 --> Router Class Initialized
INFO - 2021-05-14 19:45:31 --> Output Class Initialized
INFO - 2021-05-14 19:45:31 --> Security Class Initialized
DEBUG - 2021-05-14 19:45:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 19:45:31 --> Input Class Initialized
INFO - 2021-05-14 19:45:31 --> Language Class Initialized
INFO - 2021-05-14 19:45:31 --> Loader Class Initialized
INFO - 2021-05-14 19:45:31 --> Helper loaded: url_helper
INFO - 2021-05-14 19:45:31 --> Helper loaded: form_helper
INFO - 2021-05-14 19:45:31 --> Helper loaded: common_helper
INFO - 2021-05-14 19:45:31 --> Database Driver Class Initialized
DEBUG - 2021-05-14 19:45:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 19:45:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 19:45:31 --> Controller Class Initialized
INFO - 2021-05-14 19:45:31 --> Form Validation Class Initialized
INFO - 2021-05-14 19:45:31 --> Encrypt Class Initialized
INFO - 2021-05-14 19:45:31 --> Model "Referredby_model" initialized
INFO - 2021-05-14 19:45:31 --> Model "Users_model" initialized
INFO - 2021-05-14 19:45:31 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-05-14 19:45:31 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\users/index.php
INFO - 2021-05-14 19:45:31 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-05-14 19:45:31 --> Final output sent to browser
DEBUG - 2021-05-14 19:45:31 --> Total execution time: 0.1112
ERROR - 2021-05-14 19:45:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 19:45:31 --> Config Class Initialized
INFO - 2021-05-14 19:45:31 --> Hooks Class Initialized
DEBUG - 2021-05-14 19:45:31 --> UTF-8 Support Enabled
INFO - 2021-05-14 19:45:31 --> Utf8 Class Initialized
INFO - 2021-05-14 19:45:31 --> URI Class Initialized
INFO - 2021-05-14 19:45:31 --> Router Class Initialized
INFO - 2021-05-14 19:45:31 --> Output Class Initialized
INFO - 2021-05-14 19:45:31 --> Security Class Initialized
DEBUG - 2021-05-14 19:45:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 19:45:31 --> Input Class Initialized
INFO - 2021-05-14 19:45:31 --> Language Class Initialized
ERROR - 2021-05-14 19:45:31 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-05-14 19:45:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 19:45:43 --> Config Class Initialized
INFO - 2021-05-14 19:45:43 --> Hooks Class Initialized
DEBUG - 2021-05-14 19:45:43 --> UTF-8 Support Enabled
INFO - 2021-05-14 19:45:43 --> Utf8 Class Initialized
INFO - 2021-05-14 19:45:43 --> URI Class Initialized
INFO - 2021-05-14 19:45:43 --> Router Class Initialized
INFO - 2021-05-14 19:45:43 --> Output Class Initialized
INFO - 2021-05-14 19:45:43 --> Security Class Initialized
DEBUG - 2021-05-14 19:45:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 19:45:43 --> Input Class Initialized
INFO - 2021-05-14 19:45:43 --> Language Class Initialized
INFO - 2021-05-14 19:45:43 --> Loader Class Initialized
INFO - 2021-05-14 19:45:43 --> Helper loaded: url_helper
INFO - 2021-05-14 19:45:43 --> Helper loaded: form_helper
INFO - 2021-05-14 19:45:43 --> Helper loaded: common_helper
INFO - 2021-05-14 19:45:43 --> Database Driver Class Initialized
DEBUG - 2021-05-14 19:45:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 19:45:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 19:45:43 --> Controller Class Initialized
INFO - 2021-05-14 19:45:43 --> Form Validation Class Initialized
INFO - 2021-05-14 19:45:43 --> Encrypt Class Initialized
INFO - 2021-05-14 19:45:43 --> Model "Referredby_model" initialized
INFO - 2021-05-14 19:45:43 --> Model "Users_model" initialized
INFO - 2021-05-14 19:45:43 --> Final output sent to browser
DEBUG - 2021-05-14 19:45:43 --> Total execution time: 0.0791
ERROR - 2021-05-14 19:45:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 19:45:43 --> Config Class Initialized
INFO - 2021-05-14 19:45:43 --> Hooks Class Initialized
DEBUG - 2021-05-14 19:45:43 --> UTF-8 Support Enabled
INFO - 2021-05-14 19:45:43 --> Utf8 Class Initialized
INFO - 2021-05-14 19:45:43 --> URI Class Initialized
INFO - 2021-05-14 19:45:43 --> Router Class Initialized
INFO - 2021-05-14 19:45:43 --> Output Class Initialized
INFO - 2021-05-14 19:45:43 --> Security Class Initialized
DEBUG - 2021-05-14 19:45:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 19:45:43 --> Input Class Initialized
INFO - 2021-05-14 19:45:43 --> Language Class Initialized
INFO - 2021-05-14 19:45:43 --> Loader Class Initialized
INFO - 2021-05-14 19:45:43 --> Helper loaded: url_helper
INFO - 2021-05-14 19:45:43 --> Helper loaded: form_helper
INFO - 2021-05-14 19:45:43 --> Helper loaded: common_helper
INFO - 2021-05-14 19:45:43 --> Database Driver Class Initialized
DEBUG - 2021-05-14 19:45:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 19:45:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 19:45:43 --> Controller Class Initialized
INFO - 2021-05-14 19:45:43 --> Form Validation Class Initialized
INFO - 2021-05-14 19:45:43 --> Encrypt Class Initialized
INFO - 2021-05-14 19:45:43 --> Model "Hospital_model" initialized
INFO - 2021-05-14 19:45:43 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-05-14 19:45:43 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\hospital/index.php
INFO - 2021-05-14 19:45:43 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-05-14 19:45:43 --> Final output sent to browser
DEBUG - 2021-05-14 19:45:43 --> Total execution time: 0.0693
ERROR - 2021-05-14 19:45:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 19:45:43 --> Config Class Initialized
INFO - 2021-05-14 19:45:43 --> Hooks Class Initialized
DEBUG - 2021-05-14 19:45:43 --> UTF-8 Support Enabled
INFO - 2021-05-14 19:45:43 --> Utf8 Class Initialized
INFO - 2021-05-14 19:45:43 --> URI Class Initialized
INFO - 2021-05-14 19:45:43 --> Router Class Initialized
INFO - 2021-05-14 19:45:43 --> Output Class Initialized
INFO - 2021-05-14 19:45:43 --> Security Class Initialized
DEBUG - 2021-05-14 19:45:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 19:45:43 --> Input Class Initialized
INFO - 2021-05-14 19:45:43 --> Language Class Initialized
ERROR - 2021-05-14 19:45:43 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-05-14 19:46:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 19:46:09 --> Config Class Initialized
INFO - 2021-05-14 19:46:09 --> Hooks Class Initialized
DEBUG - 2021-05-14 19:46:09 --> UTF-8 Support Enabled
INFO - 2021-05-14 19:46:09 --> Utf8 Class Initialized
INFO - 2021-05-14 19:46:09 --> URI Class Initialized
INFO - 2021-05-14 19:46:09 --> Router Class Initialized
INFO - 2021-05-14 19:46:09 --> Output Class Initialized
INFO - 2021-05-14 19:46:09 --> Security Class Initialized
DEBUG - 2021-05-14 19:46:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 19:46:09 --> Input Class Initialized
INFO - 2021-05-14 19:46:09 --> Language Class Initialized
INFO - 2021-05-14 19:46:09 --> Loader Class Initialized
INFO - 2021-05-14 19:46:09 --> Helper loaded: url_helper
INFO - 2021-05-14 19:46:09 --> Helper loaded: form_helper
INFO - 2021-05-14 19:46:09 --> Helper loaded: common_helper
INFO - 2021-05-14 19:46:09 --> Database Driver Class Initialized
DEBUG - 2021-05-14 19:46:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 19:46:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 19:46:09 --> Controller Class Initialized
INFO - 2021-05-14 19:46:09 --> Form Validation Class Initialized
INFO - 2021-05-14 19:46:09 --> Encrypt Class Initialized
INFO - 2021-05-14 19:46:09 --> Model "Referredby_model" initialized
INFO - 2021-05-14 19:46:09 --> Model "Donner_model" initialized
INFO - 2021-05-14 19:46:09 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-05-14 19:46:09 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\donner/index.php
INFO - 2021-05-14 19:46:09 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-05-14 19:46:09 --> Final output sent to browser
DEBUG - 2021-05-14 19:46:09 --> Total execution time: 0.2213
ERROR - 2021-05-14 19:46:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 19:46:09 --> Config Class Initialized
INFO - 2021-05-14 19:46:09 --> Hooks Class Initialized
DEBUG - 2021-05-14 19:46:09 --> UTF-8 Support Enabled
INFO - 2021-05-14 19:46:09 --> Utf8 Class Initialized
INFO - 2021-05-14 19:46:09 --> URI Class Initialized
INFO - 2021-05-14 19:46:09 --> Router Class Initialized
INFO - 2021-05-14 19:46:09 --> Output Class Initialized
INFO - 2021-05-14 19:46:09 --> Security Class Initialized
DEBUG - 2021-05-14 19:46:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 19:46:09 --> Input Class Initialized
INFO - 2021-05-14 19:46:09 --> Language Class Initialized
ERROR - 2021-05-14 19:46:09 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-05-14 19:46:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 19:46:19 --> Config Class Initialized
INFO - 2021-05-14 19:46:19 --> Hooks Class Initialized
DEBUG - 2021-05-14 19:46:19 --> UTF-8 Support Enabled
INFO - 2021-05-14 19:46:19 --> Utf8 Class Initialized
INFO - 2021-05-14 19:46:19 --> URI Class Initialized
INFO - 2021-05-14 19:46:19 --> Router Class Initialized
INFO - 2021-05-14 19:46:19 --> Output Class Initialized
INFO - 2021-05-14 19:46:19 --> Security Class Initialized
DEBUG - 2021-05-14 19:46:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 19:46:19 --> Input Class Initialized
INFO - 2021-05-14 19:46:19 --> Language Class Initialized
INFO - 2021-05-14 19:46:19 --> Loader Class Initialized
INFO - 2021-05-14 19:46:19 --> Helper loaded: url_helper
INFO - 2021-05-14 19:46:19 --> Helper loaded: form_helper
INFO - 2021-05-14 19:46:19 --> Helper loaded: common_helper
INFO - 2021-05-14 19:46:19 --> Database Driver Class Initialized
DEBUG - 2021-05-14 19:46:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 19:46:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 19:46:19 --> Controller Class Initialized
INFO - 2021-05-14 19:46:19 --> Form Validation Class Initialized
INFO - 2021-05-14 19:46:19 --> Encrypt Class Initialized
INFO - 2021-05-14 19:46:19 --> Model "Hospital_model" initialized
INFO - 2021-05-14 19:46:19 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-05-14 19:46:19 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\hospital/depart.php
INFO - 2021-05-14 19:46:19 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-05-14 19:46:19 --> Final output sent to browser
DEBUG - 2021-05-14 19:46:19 --> Total execution time: 0.1194
ERROR - 2021-05-14 19:46:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 19:46:19 --> Config Class Initialized
INFO - 2021-05-14 19:46:19 --> Hooks Class Initialized
DEBUG - 2021-05-14 19:46:19 --> UTF-8 Support Enabled
INFO - 2021-05-14 19:46:19 --> Utf8 Class Initialized
INFO - 2021-05-14 19:46:19 --> URI Class Initialized
INFO - 2021-05-14 19:46:19 --> Router Class Initialized
INFO - 2021-05-14 19:46:19 --> Output Class Initialized
INFO - 2021-05-14 19:46:19 --> Security Class Initialized
DEBUG - 2021-05-14 19:46:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 19:46:19 --> Input Class Initialized
INFO - 2021-05-14 19:46:19 --> Language Class Initialized
ERROR - 2021-05-14 19:46:19 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-05-14 19:46:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 19:46:25 --> Config Class Initialized
INFO - 2021-05-14 19:46:25 --> Hooks Class Initialized
DEBUG - 2021-05-14 19:46:25 --> UTF-8 Support Enabled
INFO - 2021-05-14 19:46:25 --> Utf8 Class Initialized
INFO - 2021-05-14 19:46:25 --> URI Class Initialized
INFO - 2021-05-14 19:46:25 --> Router Class Initialized
INFO - 2021-05-14 19:46:25 --> Output Class Initialized
INFO - 2021-05-14 19:46:25 --> Security Class Initialized
DEBUG - 2021-05-14 19:46:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 19:46:25 --> Input Class Initialized
INFO - 2021-05-14 19:46:25 --> Language Class Initialized
INFO - 2021-05-14 19:46:25 --> Loader Class Initialized
INFO - 2021-05-14 19:46:25 --> Helper loaded: url_helper
INFO - 2021-05-14 19:46:25 --> Helper loaded: form_helper
INFO - 2021-05-14 19:46:25 --> Helper loaded: common_helper
INFO - 2021-05-14 19:46:25 --> Database Driver Class Initialized
DEBUG - 2021-05-14 19:46:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 19:46:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 19:46:26 --> Controller Class Initialized
INFO - 2021-05-14 19:46:26 --> Form Validation Class Initialized
INFO - 2021-05-14 19:46:26 --> Encrypt Class Initialized
INFO - 2021-05-14 19:46:26 --> Model "Patient_model" initialized
INFO - 2021-05-14 19:46:26 --> Model "Patientcase_model" initialized
INFO - 2021-05-14 19:46:26 --> Model "Referredby_model" initialized
INFO - 2021-05-14 19:46:26 --> Model "Prefix_master" initialized
INFO - 2021-05-14 19:46:26 --> Model "Hospital_model" initialized
INFO - 2021-05-14 19:46:26 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-05-14 19:46:26 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\patient/index.php
INFO - 2021-05-14 19:46:26 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-05-14 19:46:26 --> Final output sent to browser
DEBUG - 2021-05-14 19:46:26 --> Total execution time: 0.0967
ERROR - 2021-05-14 19:46:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 19:46:26 --> Config Class Initialized
INFO - 2021-05-14 19:46:26 --> Hooks Class Initialized
DEBUG - 2021-05-14 19:46:26 --> UTF-8 Support Enabled
INFO - 2021-05-14 19:46:26 --> Utf8 Class Initialized
INFO - 2021-05-14 19:46:26 --> URI Class Initialized
INFO - 2021-05-14 19:46:26 --> Router Class Initialized
INFO - 2021-05-14 19:46:26 --> Output Class Initialized
INFO - 2021-05-14 19:46:26 --> Security Class Initialized
DEBUG - 2021-05-14 19:46:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 19:46:26 --> Input Class Initialized
INFO - 2021-05-14 19:46:26 --> Language Class Initialized
ERROR - 2021-05-14 19:46:26 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-05-14 19:46:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 19:46:44 --> Config Class Initialized
INFO - 2021-05-14 19:46:44 --> Hooks Class Initialized
DEBUG - 2021-05-14 19:46:44 --> UTF-8 Support Enabled
INFO - 2021-05-14 19:46:44 --> Utf8 Class Initialized
INFO - 2021-05-14 19:46:44 --> URI Class Initialized
INFO - 2021-05-14 19:46:44 --> Router Class Initialized
INFO - 2021-05-14 19:46:44 --> Output Class Initialized
INFO - 2021-05-14 19:46:44 --> Security Class Initialized
DEBUG - 2021-05-14 19:46:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 19:46:44 --> Input Class Initialized
INFO - 2021-05-14 19:46:44 --> Language Class Initialized
INFO - 2021-05-14 19:46:44 --> Loader Class Initialized
INFO - 2021-05-14 19:46:44 --> Helper loaded: url_helper
INFO - 2021-05-14 19:46:44 --> Helper loaded: form_helper
INFO - 2021-05-14 19:46:44 --> Helper loaded: common_helper
INFO - 2021-05-14 19:46:44 --> Database Driver Class Initialized
DEBUG - 2021-05-14 19:46:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 19:46:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 19:46:44 --> Controller Class Initialized
INFO - 2021-05-14 19:46:44 --> Form Validation Class Initialized
INFO - 2021-05-14 19:46:44 --> Encrypt Class Initialized
INFO - 2021-05-14 19:46:44 --> Model "Patient_model" initialized
INFO - 2021-05-14 19:46:44 --> Model "Patientcase_model" initialized
INFO - 2021-05-14 19:46:44 --> Model "Referredby_model" initialized
INFO - 2021-05-14 19:46:44 --> Model "Prefix_master" initialized
INFO - 2021-05-14 19:46:44 --> Model "Hospital_model" initialized
INFO - 2021-05-14 19:46:44 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-05-14 19:46:51 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\patient/patientview.php
INFO - 2021-05-14 19:46:51 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-05-14 19:46:51 --> Final output sent to browser
DEBUG - 2021-05-14 19:46:51 --> Total execution time: 6.7839
ERROR - 2021-05-14 19:46:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 19:46:51 --> Config Class Initialized
INFO - 2021-05-14 19:46:51 --> Hooks Class Initialized
DEBUG - 2021-05-14 19:46:51 --> UTF-8 Support Enabled
INFO - 2021-05-14 19:46:51 --> Utf8 Class Initialized
INFO - 2021-05-14 19:46:51 --> URI Class Initialized
INFO - 2021-05-14 19:46:51 --> Router Class Initialized
INFO - 2021-05-14 19:46:51 --> Output Class Initialized
INFO - 2021-05-14 19:46:51 --> Security Class Initialized
DEBUG - 2021-05-14 19:46:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 19:46:51 --> Input Class Initialized
INFO - 2021-05-14 19:46:51 --> Language Class Initialized
ERROR - 2021-05-14 19:46:51 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-05-14 19:47:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 19:47:20 --> Config Class Initialized
INFO - 2021-05-14 19:47:20 --> Hooks Class Initialized
DEBUG - 2021-05-14 19:47:20 --> UTF-8 Support Enabled
INFO - 2021-05-14 19:47:20 --> Utf8 Class Initialized
INFO - 2021-05-14 19:47:20 --> URI Class Initialized
INFO - 2021-05-14 19:47:20 --> Router Class Initialized
INFO - 2021-05-14 19:47:20 --> Output Class Initialized
INFO - 2021-05-14 19:47:20 --> Security Class Initialized
DEBUG - 2021-05-14 19:47:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 19:47:20 --> Input Class Initialized
INFO - 2021-05-14 19:47:20 --> Language Class Initialized
INFO - 2021-05-14 19:47:20 --> Loader Class Initialized
INFO - 2021-05-14 19:47:20 --> Helper loaded: url_helper
INFO - 2021-05-14 19:47:20 --> Helper loaded: form_helper
INFO - 2021-05-14 19:47:20 --> Helper loaded: common_helper
INFO - 2021-05-14 19:47:20 --> Database Driver Class Initialized
DEBUG - 2021-05-14 19:47:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 19:47:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 19:47:20 --> Controller Class Initialized
INFO - 2021-05-14 19:47:20 --> Form Validation Class Initialized
INFO - 2021-05-14 19:47:20 --> Encrypt Class Initialized
INFO - 2021-05-14 19:47:20 --> Model "Patient_model" initialized
INFO - 2021-05-14 19:47:20 --> Model "Patientcase_model" initialized
INFO - 2021-05-14 19:47:20 --> Model "Prefix_master" initialized
INFO - 2021-05-14 19:47:20 --> Model "Users_model" initialized
INFO - 2021-05-14 19:47:20 --> Model "Hospital_model" initialized
INFO - 2021-05-14 19:47:21 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-05-14 19:47:21 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\patientcase/index.php
INFO - 2021-05-14 19:47:21 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-05-14 19:47:21 --> Final output sent to browser
DEBUG - 2021-05-14 19:47:21 --> Total execution time: 0.3991
ERROR - 2021-05-14 19:47:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 19:47:21 --> Config Class Initialized
INFO - 2021-05-14 19:47:21 --> Hooks Class Initialized
DEBUG - 2021-05-14 19:47:21 --> UTF-8 Support Enabled
INFO - 2021-05-14 19:47:21 --> Utf8 Class Initialized
INFO - 2021-05-14 19:47:21 --> URI Class Initialized
INFO - 2021-05-14 19:47:21 --> Router Class Initialized
INFO - 2021-05-14 19:47:21 --> Output Class Initialized
INFO - 2021-05-14 19:47:21 --> Security Class Initialized
DEBUG - 2021-05-14 19:47:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 19:47:21 --> Input Class Initialized
INFO - 2021-05-14 19:47:21 --> Language Class Initialized
ERROR - 2021-05-14 19:47:21 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-05-14 19:49:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 19:49:25 --> Config Class Initialized
INFO - 2021-05-14 19:49:25 --> Hooks Class Initialized
DEBUG - 2021-05-14 19:49:25 --> UTF-8 Support Enabled
INFO - 2021-05-14 19:49:25 --> Utf8 Class Initialized
INFO - 2021-05-14 19:49:25 --> URI Class Initialized
INFO - 2021-05-14 19:49:25 --> Router Class Initialized
INFO - 2021-05-14 19:49:25 --> Output Class Initialized
INFO - 2021-05-14 19:49:25 --> Security Class Initialized
DEBUG - 2021-05-14 19:49:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 19:49:25 --> Input Class Initialized
INFO - 2021-05-14 19:49:25 --> Language Class Initialized
INFO - 2021-05-14 19:49:25 --> Loader Class Initialized
INFO - 2021-05-14 19:49:25 --> Helper loaded: url_helper
INFO - 2021-05-14 19:49:25 --> Helper loaded: form_helper
INFO - 2021-05-14 19:49:25 --> Helper loaded: common_helper
INFO - 2021-05-14 19:49:25 --> Database Driver Class Initialized
DEBUG - 2021-05-14 19:49:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 19:49:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 19:49:25 --> Controller Class Initialized
INFO - 2021-05-14 19:49:25 --> Form Validation Class Initialized
INFO - 2021-05-14 19:49:25 --> Model "Case_model" initialized
INFO - 2021-05-14 19:49:25 --> Model "Patientcase_model" initialized
INFO - 2021-05-14 19:49:26 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-05-14 19:49:26 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\cases/new_case.php
INFO - 2021-05-14 19:49:26 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-05-14 19:49:26 --> Final output sent to browser
DEBUG - 2021-05-14 19:49:26 --> Total execution time: 0.5995
ERROR - 2021-05-14 19:49:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 19:49:26 --> Config Class Initialized
INFO - 2021-05-14 19:49:26 --> Hooks Class Initialized
DEBUG - 2021-05-14 19:49:26 --> UTF-8 Support Enabled
INFO - 2021-05-14 19:49:26 --> Utf8 Class Initialized
INFO - 2021-05-14 19:49:26 --> URI Class Initialized
INFO - 2021-05-14 19:49:26 --> Router Class Initialized
INFO - 2021-05-14 19:49:26 --> Output Class Initialized
INFO - 2021-05-14 19:49:26 --> Security Class Initialized
DEBUG - 2021-05-14 19:49:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 19:49:26 --> Input Class Initialized
INFO - 2021-05-14 19:49:26 --> Language Class Initialized
ERROR - 2021-05-14 19:49:26 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-05-14 19:49:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 19:49:39 --> Config Class Initialized
INFO - 2021-05-14 19:49:39 --> Hooks Class Initialized
DEBUG - 2021-05-14 19:49:39 --> UTF-8 Support Enabled
INFO - 2021-05-14 19:49:39 --> Utf8 Class Initialized
INFO - 2021-05-14 19:49:39 --> URI Class Initialized
INFO - 2021-05-14 19:49:39 --> Router Class Initialized
INFO - 2021-05-14 19:49:39 --> Output Class Initialized
INFO - 2021-05-14 19:49:39 --> Security Class Initialized
DEBUG - 2021-05-14 19:49:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 19:49:39 --> Input Class Initialized
INFO - 2021-05-14 19:49:39 --> Language Class Initialized
INFO - 2021-05-14 19:49:39 --> Loader Class Initialized
INFO - 2021-05-14 19:49:39 --> Helper loaded: url_helper
INFO - 2021-05-14 19:49:39 --> Helper loaded: form_helper
INFO - 2021-05-14 19:49:39 --> Helper loaded: common_helper
INFO - 2021-05-14 19:49:39 --> Database Driver Class Initialized
DEBUG - 2021-05-14 19:49:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 19:49:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 19:49:39 --> Controller Class Initialized
INFO - 2021-05-14 19:49:39 --> Form Validation Class Initialized
INFO - 2021-05-14 19:49:39 --> Encrypt Class Initialized
INFO - 2021-05-14 19:49:39 --> Model "Patient_model" initialized
INFO - 2021-05-14 19:49:39 --> Model "Patientcase_model" initialized
INFO - 2021-05-14 19:49:39 --> Model "Prefix_master" initialized
INFO - 2021-05-14 19:49:39 --> Model "Users_model" initialized
INFO - 2021-05-14 19:49:39 --> Model "Hospital_model" initialized
INFO - 2021-05-14 19:49:39 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-05-14 19:49:39 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\patientcase/index.php
INFO - 2021-05-14 19:49:39 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-05-14 19:49:39 --> Final output sent to browser
DEBUG - 2021-05-14 19:49:39 --> Total execution time: 0.3415
ERROR - 2021-05-14 19:49:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 19:49:39 --> Config Class Initialized
INFO - 2021-05-14 19:49:39 --> Hooks Class Initialized
DEBUG - 2021-05-14 19:49:39 --> UTF-8 Support Enabled
INFO - 2021-05-14 19:49:39 --> Utf8 Class Initialized
INFO - 2021-05-14 19:49:39 --> URI Class Initialized
INFO - 2021-05-14 19:49:39 --> Router Class Initialized
INFO - 2021-05-14 19:49:39 --> Output Class Initialized
INFO - 2021-05-14 19:49:39 --> Security Class Initialized
DEBUG - 2021-05-14 19:49:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 19:49:39 --> Input Class Initialized
INFO - 2021-05-14 19:49:39 --> Language Class Initialized
ERROR - 2021-05-14 19:49:39 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-05-14 19:49:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 19:49:49 --> Config Class Initialized
INFO - 2021-05-14 19:49:49 --> Hooks Class Initialized
DEBUG - 2021-05-14 19:49:49 --> UTF-8 Support Enabled
INFO - 2021-05-14 19:49:49 --> Utf8 Class Initialized
INFO - 2021-05-14 19:49:49 --> URI Class Initialized
INFO - 2021-05-14 19:49:49 --> Router Class Initialized
INFO - 2021-05-14 19:49:49 --> Output Class Initialized
INFO - 2021-05-14 19:49:49 --> Security Class Initialized
DEBUG - 2021-05-14 19:49:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 19:49:49 --> Input Class Initialized
INFO - 2021-05-14 19:49:49 --> Language Class Initialized
INFO - 2021-05-14 19:49:49 --> Loader Class Initialized
INFO - 2021-05-14 19:49:49 --> Helper loaded: url_helper
INFO - 2021-05-14 19:49:49 --> Helper loaded: form_helper
INFO - 2021-05-14 19:49:49 --> Helper loaded: common_helper
INFO - 2021-05-14 19:49:49 --> Database Driver Class Initialized
DEBUG - 2021-05-14 19:49:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 19:49:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 19:49:49 --> Controller Class Initialized
INFO - 2021-05-14 19:49:49 --> Form Validation Class Initialized
INFO - 2021-05-14 19:49:49 --> Model "Case_model" initialized
INFO - 2021-05-14 19:49:49 --> Model "Patientcase_model" initialized
INFO - 2021-05-14 19:49:49 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-05-14 19:49:49 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\cases/new_case.php
INFO - 2021-05-14 19:49:49 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-05-14 19:49:49 --> Final output sent to browser
DEBUG - 2021-05-14 19:49:49 --> Total execution time: 0.6059
ERROR - 2021-05-14 19:49:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 19:49:49 --> Config Class Initialized
INFO - 2021-05-14 19:49:49 --> Hooks Class Initialized
DEBUG - 2021-05-14 19:49:49 --> UTF-8 Support Enabled
INFO - 2021-05-14 19:49:49 --> Utf8 Class Initialized
INFO - 2021-05-14 19:49:49 --> URI Class Initialized
INFO - 2021-05-14 19:49:49 --> Router Class Initialized
INFO - 2021-05-14 19:49:49 --> Output Class Initialized
INFO - 2021-05-14 19:49:49 --> Security Class Initialized
DEBUG - 2021-05-14 19:49:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 19:49:49 --> Input Class Initialized
INFO - 2021-05-14 19:49:49 --> Language Class Initialized
ERROR - 2021-05-14 19:49:49 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-05-14 19:50:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 19:50:06 --> Config Class Initialized
INFO - 2021-05-14 19:50:06 --> Hooks Class Initialized
DEBUG - 2021-05-14 19:50:06 --> UTF-8 Support Enabled
INFO - 2021-05-14 19:50:06 --> Utf8 Class Initialized
INFO - 2021-05-14 19:50:06 --> URI Class Initialized
INFO - 2021-05-14 19:50:06 --> Router Class Initialized
INFO - 2021-05-14 19:50:06 --> Output Class Initialized
INFO - 2021-05-14 19:50:06 --> Security Class Initialized
DEBUG - 2021-05-14 19:50:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 19:50:06 --> Input Class Initialized
INFO - 2021-05-14 19:50:06 --> Language Class Initialized
INFO - 2021-05-14 19:50:06 --> Loader Class Initialized
INFO - 2021-05-14 19:50:06 --> Helper loaded: url_helper
INFO - 2021-05-14 19:50:06 --> Helper loaded: form_helper
INFO - 2021-05-14 19:50:06 --> Helper loaded: common_helper
INFO - 2021-05-14 19:50:06 --> Database Driver Class Initialized
DEBUG - 2021-05-14 19:50:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 19:50:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 19:50:06 --> Controller Class Initialized
INFO - 2021-05-14 19:50:06 --> Form Validation Class Initialized
INFO - 2021-05-14 19:50:06 --> Model "Case_model" initialized
INFO - 2021-05-14 19:50:06 --> Model "Patientcase_model" initialized
INFO - 2021-05-14 19:50:09 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-05-14 19:50:09 --> Model "Case_model" initialized
INFO - 2021-05-14 19:50:13 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\cases/open_case.php
INFO - 2021-05-14 19:50:13 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-05-14 19:50:13 --> Final output sent to browser
DEBUG - 2021-05-14 19:50:13 --> Total execution time: 7.4882
ERROR - 2021-05-14 19:50:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 19:50:13 --> Config Class Initialized
INFO - 2021-05-14 19:50:13 --> Hooks Class Initialized
DEBUG - 2021-05-14 19:50:13 --> UTF-8 Support Enabled
INFO - 2021-05-14 19:50:13 --> Utf8 Class Initialized
INFO - 2021-05-14 19:50:13 --> URI Class Initialized
INFO - 2021-05-14 19:50:13 --> Router Class Initialized
INFO - 2021-05-14 19:50:13 --> Output Class Initialized
INFO - 2021-05-14 19:50:13 --> Security Class Initialized
DEBUG - 2021-05-14 19:50:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 19:50:13 --> Input Class Initialized
INFO - 2021-05-14 19:50:13 --> Language Class Initialized
ERROR - 2021-05-14 19:50:13 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-05-14 19:50:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 19:50:21 --> Config Class Initialized
INFO - 2021-05-14 19:50:21 --> Hooks Class Initialized
DEBUG - 2021-05-14 19:50:21 --> UTF-8 Support Enabled
INFO - 2021-05-14 19:50:21 --> Utf8 Class Initialized
INFO - 2021-05-14 19:50:21 --> URI Class Initialized
INFO - 2021-05-14 19:50:21 --> Router Class Initialized
INFO - 2021-05-14 19:50:21 --> Output Class Initialized
INFO - 2021-05-14 19:50:21 --> Security Class Initialized
DEBUG - 2021-05-14 19:50:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 19:50:21 --> Input Class Initialized
INFO - 2021-05-14 19:50:21 --> Language Class Initialized
INFO - 2021-05-14 19:50:21 --> Loader Class Initialized
INFO - 2021-05-14 19:50:21 --> Helper loaded: url_helper
INFO - 2021-05-14 19:50:21 --> Helper loaded: form_helper
INFO - 2021-05-14 19:50:21 --> Helper loaded: common_helper
INFO - 2021-05-14 19:50:21 --> Database Driver Class Initialized
DEBUG - 2021-05-14 19:50:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 19:50:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 19:50:21 --> Controller Class Initialized
INFO - 2021-05-14 19:50:21 --> Form Validation Class Initialized
INFO - 2021-05-14 19:50:21 --> Model "Case_model" initialized
INFO - 2021-05-14 19:50:21 --> Model "Patientcase_model" initialized
INFO - 2021-05-14 19:50:23 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-05-14 19:50:23 --> Model "Case_model" initialized
INFO - 2021-05-14 19:50:26 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\cases/closed_case.php
INFO - 2021-05-14 19:50:26 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-05-14 19:50:26 --> Final output sent to browser
DEBUG - 2021-05-14 19:50:26 --> Total execution time: 5.2080
ERROR - 2021-05-14 19:50:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 19:50:26 --> Config Class Initialized
INFO - 2021-05-14 19:50:26 --> Hooks Class Initialized
DEBUG - 2021-05-14 19:50:26 --> UTF-8 Support Enabled
INFO - 2021-05-14 19:50:26 --> Utf8 Class Initialized
INFO - 2021-05-14 19:50:26 --> URI Class Initialized
INFO - 2021-05-14 19:50:26 --> Router Class Initialized
INFO - 2021-05-14 19:50:26 --> Output Class Initialized
INFO - 2021-05-14 19:50:26 --> Security Class Initialized
DEBUG - 2021-05-14 19:50:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 19:50:26 --> Input Class Initialized
INFO - 2021-05-14 19:50:26 --> Language Class Initialized
ERROR - 2021-05-14 19:50:26 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-05-14 19:50:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 19:50:33 --> Config Class Initialized
INFO - 2021-05-14 19:50:33 --> Hooks Class Initialized
DEBUG - 2021-05-14 19:50:33 --> UTF-8 Support Enabled
INFO - 2021-05-14 19:50:33 --> Utf8 Class Initialized
INFO - 2021-05-14 19:50:33 --> URI Class Initialized
INFO - 2021-05-14 19:50:33 --> Router Class Initialized
INFO - 2021-05-14 19:50:33 --> Output Class Initialized
INFO - 2021-05-14 19:50:33 --> Security Class Initialized
DEBUG - 2021-05-14 19:50:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 19:50:33 --> Input Class Initialized
INFO - 2021-05-14 19:50:33 --> Language Class Initialized
INFO - 2021-05-14 19:50:33 --> Loader Class Initialized
INFO - 2021-05-14 19:50:33 --> Helper loaded: url_helper
INFO - 2021-05-14 19:50:33 --> Helper loaded: form_helper
INFO - 2021-05-14 19:50:33 --> Helper loaded: common_helper
INFO - 2021-05-14 19:50:33 --> Database Driver Class Initialized
DEBUG - 2021-05-14 19:50:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 19:50:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 19:50:33 --> Controller Class Initialized
INFO - 2021-05-14 19:50:33 --> Form Validation Class Initialized
INFO - 2021-05-14 19:50:33 --> Model "Case_model" initialized
INFO - 2021-05-14 19:50:33 --> Model "Patientcase_model" initialized
INFO - 2021-05-14 19:50:33 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-05-14 19:50:33 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\cases/new_case.php
INFO - 2021-05-14 19:50:33 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-05-14 19:50:33 --> Final output sent to browser
DEBUG - 2021-05-14 19:50:33 --> Total execution time: 0.4245
ERROR - 2021-05-14 19:50:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 19:50:33 --> Config Class Initialized
INFO - 2021-05-14 19:50:33 --> Hooks Class Initialized
DEBUG - 2021-05-14 19:50:33 --> UTF-8 Support Enabled
INFO - 2021-05-14 19:50:33 --> Utf8 Class Initialized
INFO - 2021-05-14 19:50:33 --> URI Class Initialized
INFO - 2021-05-14 19:50:33 --> Router Class Initialized
INFO - 2021-05-14 19:50:33 --> Output Class Initialized
INFO - 2021-05-14 19:50:33 --> Security Class Initialized
DEBUG - 2021-05-14 19:50:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 19:50:33 --> Input Class Initialized
INFO - 2021-05-14 19:50:33 --> Language Class Initialized
ERROR - 2021-05-14 19:50:33 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-05-14 19:50:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 19:50:36 --> Config Class Initialized
INFO - 2021-05-14 19:50:36 --> Hooks Class Initialized
DEBUG - 2021-05-14 19:50:36 --> UTF-8 Support Enabled
INFO - 2021-05-14 19:50:36 --> Utf8 Class Initialized
INFO - 2021-05-14 19:50:36 --> URI Class Initialized
INFO - 2021-05-14 19:50:36 --> Router Class Initialized
INFO - 2021-05-14 19:50:36 --> Output Class Initialized
INFO - 2021-05-14 19:50:36 --> Security Class Initialized
DEBUG - 2021-05-14 19:50:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 19:50:36 --> Input Class Initialized
INFO - 2021-05-14 19:50:36 --> Language Class Initialized
INFO - 2021-05-14 19:50:36 --> Loader Class Initialized
INFO - 2021-05-14 19:50:36 --> Helper loaded: url_helper
INFO - 2021-05-14 19:50:36 --> Helper loaded: form_helper
INFO - 2021-05-14 19:50:36 --> Helper loaded: common_helper
INFO - 2021-05-14 19:50:36 --> Database Driver Class Initialized
DEBUG - 2021-05-14 19:50:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 19:50:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 19:50:36 --> Controller Class Initialized
INFO - 2021-05-14 19:50:36 --> Form Validation Class Initialized
INFO - 2021-05-14 19:50:36 --> Model "Case_model" initialized
INFO - 2021-05-14 19:50:36 --> Model "Patientcase_model" initialized
INFO - 2021-05-14 19:50:40 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-05-14 19:50:40 --> Model "Case_model" initialized
INFO - 2021-05-14 19:50:44 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\cases/open_case.php
INFO - 2021-05-14 19:50:44 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-05-14 19:50:44 --> Final output sent to browser
DEBUG - 2021-05-14 19:50:44 --> Total execution time: 8.2513
ERROR - 2021-05-14 19:50:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 19:50:44 --> Config Class Initialized
INFO - 2021-05-14 19:50:44 --> Hooks Class Initialized
DEBUG - 2021-05-14 19:50:44 --> UTF-8 Support Enabled
INFO - 2021-05-14 19:50:44 --> Utf8 Class Initialized
INFO - 2021-05-14 19:50:44 --> URI Class Initialized
INFO - 2021-05-14 19:50:44 --> Router Class Initialized
INFO - 2021-05-14 19:50:44 --> Output Class Initialized
INFO - 2021-05-14 19:50:44 --> Security Class Initialized
DEBUG - 2021-05-14 19:50:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 19:50:44 --> Input Class Initialized
INFO - 2021-05-14 19:50:44 --> Language Class Initialized
ERROR - 2021-05-14 19:50:44 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-05-14 19:53:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 19:53:40 --> Config Class Initialized
INFO - 2021-05-14 19:53:40 --> Hooks Class Initialized
DEBUG - 2021-05-14 19:53:40 --> UTF-8 Support Enabled
INFO - 2021-05-14 19:53:40 --> Utf8 Class Initialized
INFO - 2021-05-14 19:53:40 --> URI Class Initialized
INFO - 2021-05-14 19:53:40 --> Router Class Initialized
INFO - 2021-05-14 19:53:40 --> Output Class Initialized
INFO - 2021-05-14 19:53:40 --> Security Class Initialized
DEBUG - 2021-05-14 19:53:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 19:53:40 --> Input Class Initialized
INFO - 2021-05-14 19:53:40 --> Language Class Initialized
INFO - 2021-05-14 19:53:40 --> Loader Class Initialized
INFO - 2021-05-14 19:53:40 --> Helper loaded: url_helper
INFO - 2021-05-14 19:53:40 --> Helper loaded: form_helper
INFO - 2021-05-14 19:53:40 --> Helper loaded: common_helper
INFO - 2021-05-14 19:53:40 --> Database Driver Class Initialized
DEBUG - 2021-05-14 19:53:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 19:53:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 19:53:40 --> Controller Class Initialized
INFO - 2021-05-14 19:53:40 --> Form Validation Class Initialized
INFO - 2021-05-14 19:53:40 --> Model "Case_model" initialized
INFO - 2021-05-14 19:53:40 --> Model "Patientcase_model" initialized
INFO - 2021-05-14 19:53:43 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-05-14 19:53:43 --> Model "Case_model" initialized
INFO - 2021-05-14 19:53:47 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\cases/open_case.php
INFO - 2021-05-14 19:53:47 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-05-14 19:53:47 --> Final output sent to browser
DEBUG - 2021-05-14 19:53:47 --> Total execution time: 7.1312
ERROR - 2021-05-14 19:53:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 19:53:48 --> Config Class Initialized
INFO - 2021-05-14 19:53:48 --> Hooks Class Initialized
DEBUG - 2021-05-14 19:53:48 --> UTF-8 Support Enabled
INFO - 2021-05-14 19:53:48 --> Utf8 Class Initialized
INFO - 2021-05-14 19:53:48 --> URI Class Initialized
INFO - 2021-05-14 19:53:48 --> Router Class Initialized
INFO - 2021-05-14 19:53:48 --> Output Class Initialized
INFO - 2021-05-14 19:53:48 --> Security Class Initialized
DEBUG - 2021-05-14 19:53:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 19:53:48 --> Input Class Initialized
INFO - 2021-05-14 19:53:48 --> Language Class Initialized
ERROR - 2021-05-14 19:53:48 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-05-14 19:53:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 19:53:58 --> Config Class Initialized
INFO - 2021-05-14 19:53:58 --> Hooks Class Initialized
DEBUG - 2021-05-14 19:53:58 --> UTF-8 Support Enabled
INFO - 2021-05-14 19:53:58 --> Utf8 Class Initialized
INFO - 2021-05-14 19:53:58 --> URI Class Initialized
INFO - 2021-05-14 19:53:58 --> Router Class Initialized
INFO - 2021-05-14 19:53:58 --> Output Class Initialized
INFO - 2021-05-14 19:53:58 --> Security Class Initialized
DEBUG - 2021-05-14 19:53:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 19:53:58 --> Input Class Initialized
INFO - 2021-05-14 19:53:58 --> Language Class Initialized
INFO - 2021-05-14 19:53:58 --> Loader Class Initialized
INFO - 2021-05-14 19:53:58 --> Helper loaded: url_helper
INFO - 2021-05-14 19:53:58 --> Helper loaded: form_helper
INFO - 2021-05-14 19:53:58 --> Helper loaded: common_helper
INFO - 2021-05-14 19:53:58 --> Database Driver Class Initialized
DEBUG - 2021-05-14 19:53:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 19:53:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 19:53:58 --> Controller Class Initialized
INFO - 2021-05-14 19:53:58 --> Form Validation Class Initialized
INFO - 2021-05-14 19:53:58 --> Encrypt Class Initialized
INFO - 2021-05-14 19:53:58 --> Model "Patient_model" initialized
INFO - 2021-05-14 19:53:58 --> Model "Patientcase_model" initialized
INFO - 2021-05-14 19:53:58 --> Model "Prefix_master" initialized
INFO - 2021-05-14 19:53:58 --> Model "Users_model" initialized
INFO - 2021-05-14 19:53:58 --> Model "Hospital_model" initialized
INFO - 2021-05-14 19:53:58 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-05-14 19:53:58 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\patientcase/index.php
INFO - 2021-05-14 19:53:58 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-05-14 19:53:58 --> Final output sent to browser
DEBUG - 2021-05-14 19:53:58 --> Total execution time: 0.3010
ERROR - 2021-05-14 19:53:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 19:53:58 --> Config Class Initialized
INFO - 2021-05-14 19:53:58 --> Hooks Class Initialized
DEBUG - 2021-05-14 19:53:58 --> UTF-8 Support Enabled
INFO - 2021-05-14 19:53:58 --> Utf8 Class Initialized
INFO - 2021-05-14 19:53:58 --> URI Class Initialized
INFO - 2021-05-14 19:53:58 --> Router Class Initialized
INFO - 2021-05-14 19:53:58 --> Output Class Initialized
INFO - 2021-05-14 19:53:58 --> Security Class Initialized
DEBUG - 2021-05-14 19:53:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 19:53:58 --> Input Class Initialized
INFO - 2021-05-14 19:53:58 --> Language Class Initialized
ERROR - 2021-05-14 19:53:58 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-05-14 19:54:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 19:54:09 --> Config Class Initialized
INFO - 2021-05-14 19:54:09 --> Hooks Class Initialized
DEBUG - 2021-05-14 19:54:09 --> UTF-8 Support Enabled
INFO - 2021-05-14 19:54:09 --> Utf8 Class Initialized
INFO - 2021-05-14 19:54:09 --> URI Class Initialized
INFO - 2021-05-14 19:54:09 --> Router Class Initialized
INFO - 2021-05-14 19:54:09 --> Output Class Initialized
INFO - 2021-05-14 19:54:09 --> Security Class Initialized
DEBUG - 2021-05-14 19:54:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 19:54:09 --> Input Class Initialized
INFO - 2021-05-14 19:54:09 --> Language Class Initialized
INFO - 2021-05-14 19:54:09 --> Loader Class Initialized
INFO - 2021-05-14 19:54:09 --> Helper loaded: url_helper
INFO - 2021-05-14 19:54:09 --> Helper loaded: form_helper
INFO - 2021-05-14 19:54:09 --> Helper loaded: common_helper
INFO - 2021-05-14 19:54:09 --> Database Driver Class Initialized
DEBUG - 2021-05-14 19:54:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 19:54:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 19:54:09 --> Controller Class Initialized
INFO - 2021-05-14 19:54:09 --> Form Validation Class Initialized
INFO - 2021-05-14 19:54:09 --> Model "Case_model" initialized
INFO - 2021-05-14 19:54:09 --> Model "Patientcase_model" initialized
INFO - 2021-05-14 19:54:12 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-05-14 19:54:12 --> Model "Case_model" initialized
INFO - 2021-05-14 19:54:16 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\cases/open_case.php
INFO - 2021-05-14 19:54:16 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-05-14 19:54:16 --> Final output sent to browser
DEBUG - 2021-05-14 19:54:16 --> Total execution time: 7.7560
ERROR - 2021-05-14 19:54:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 19:54:25 --> Config Class Initialized
INFO - 2021-05-14 19:54:25 --> Hooks Class Initialized
DEBUG - 2021-05-14 19:54:25 --> UTF-8 Support Enabled
INFO - 2021-05-14 19:54:25 --> Utf8 Class Initialized
INFO - 2021-05-14 19:54:25 --> URI Class Initialized
INFO - 2021-05-14 19:54:25 --> Router Class Initialized
INFO - 2021-05-14 19:54:25 --> Output Class Initialized
INFO - 2021-05-14 19:54:25 --> Security Class Initialized
DEBUG - 2021-05-14 19:54:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 19:54:25 --> Input Class Initialized
INFO - 2021-05-14 19:54:25 --> Language Class Initialized
INFO - 2021-05-14 19:54:25 --> Loader Class Initialized
INFO - 2021-05-14 19:54:25 --> Helper loaded: url_helper
INFO - 2021-05-14 19:54:25 --> Helper loaded: form_helper
INFO - 2021-05-14 19:54:25 --> Helper loaded: common_helper
INFO - 2021-05-14 19:54:25 --> Database Driver Class Initialized
DEBUG - 2021-05-14 19:54:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 19:54:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 19:54:25 --> Controller Class Initialized
INFO - 2021-05-14 19:54:25 --> Form Validation Class Initialized
INFO - 2021-05-14 19:54:25 --> Model "Case_model" initialized
INFO - 2021-05-14 19:54:25 --> Model "Patientcase_model" initialized
INFO - 2021-05-14 19:54:27 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-05-14 19:54:27 --> Model "Case_model" initialized
INFO - 2021-05-14 19:54:30 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\cases/closed_case.php
INFO - 2021-05-14 19:54:30 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-05-14 19:54:30 --> Final output sent to browser
DEBUG - 2021-05-14 19:54:30 --> Total execution time: 5.3649
ERROR - 2021-05-14 19:54:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 19:54:30 --> Config Class Initialized
INFO - 2021-05-14 19:54:30 --> Hooks Class Initialized
DEBUG - 2021-05-14 19:54:30 --> UTF-8 Support Enabled
INFO - 2021-05-14 19:54:30 --> Utf8 Class Initialized
INFO - 2021-05-14 19:54:30 --> URI Class Initialized
INFO - 2021-05-14 19:54:30 --> Router Class Initialized
INFO - 2021-05-14 19:54:30 --> Output Class Initialized
INFO - 2021-05-14 19:54:30 --> Security Class Initialized
DEBUG - 2021-05-14 19:54:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 19:54:30 --> Input Class Initialized
INFO - 2021-05-14 19:54:30 --> Language Class Initialized
ERROR - 2021-05-14 19:54:30 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-05-14 19:54:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 19:54:56 --> Config Class Initialized
INFO - 2021-05-14 19:54:56 --> Hooks Class Initialized
DEBUG - 2021-05-14 19:54:56 --> UTF-8 Support Enabled
INFO - 2021-05-14 19:54:56 --> Utf8 Class Initialized
INFO - 2021-05-14 19:54:56 --> URI Class Initialized
INFO - 2021-05-14 19:54:56 --> Router Class Initialized
INFO - 2021-05-14 19:54:56 --> Output Class Initialized
INFO - 2021-05-14 19:54:56 --> Security Class Initialized
DEBUG - 2021-05-14 19:54:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 19:54:56 --> Input Class Initialized
INFO - 2021-05-14 19:54:56 --> Language Class Initialized
INFO - 2021-05-14 19:54:56 --> Loader Class Initialized
INFO - 2021-05-14 19:54:56 --> Helper loaded: url_helper
INFO - 2021-05-14 19:54:56 --> Helper loaded: form_helper
INFO - 2021-05-14 19:54:56 --> Helper loaded: common_helper
INFO - 2021-05-14 19:54:56 --> Database Driver Class Initialized
DEBUG - 2021-05-14 19:54:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 19:54:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 19:54:57 --> Controller Class Initialized
INFO - 2021-05-14 19:54:57 --> Form Validation Class Initialized
INFO - 2021-05-14 19:54:57 --> Model "Case_model" initialized
INFO - 2021-05-14 19:54:57 --> Model "Patientcase_model" initialized
INFO - 2021-05-14 19:54:59 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-05-14 19:54:59 --> Model "Case_model" initialized
INFO - 2021-05-14 19:55:02 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\cases/closed_case.php
INFO - 2021-05-14 19:55:02 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-05-14 19:55:02 --> Final output sent to browser
DEBUG - 2021-05-14 19:55:02 --> Total execution time: 5.4250
ERROR - 2021-05-14 19:55:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 19:55:02 --> Config Class Initialized
INFO - 2021-05-14 19:55:02 --> Hooks Class Initialized
DEBUG - 2021-05-14 19:55:02 --> UTF-8 Support Enabled
INFO - 2021-05-14 19:55:02 --> Utf8 Class Initialized
INFO - 2021-05-14 19:55:02 --> URI Class Initialized
INFO - 2021-05-14 19:55:02 --> Router Class Initialized
INFO - 2021-05-14 19:55:02 --> Output Class Initialized
INFO - 2021-05-14 19:55:02 --> Security Class Initialized
DEBUG - 2021-05-14 19:55:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 19:55:02 --> Input Class Initialized
INFO - 2021-05-14 19:55:02 --> Language Class Initialized
ERROR - 2021-05-14 19:55:02 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-05-14 19:55:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 19:55:13 --> Config Class Initialized
INFO - 2021-05-14 19:55:13 --> Hooks Class Initialized
DEBUG - 2021-05-14 19:55:13 --> UTF-8 Support Enabled
INFO - 2021-05-14 19:55:13 --> Utf8 Class Initialized
INFO - 2021-05-14 19:55:13 --> URI Class Initialized
INFO - 2021-05-14 19:55:13 --> Router Class Initialized
INFO - 2021-05-14 19:55:13 --> Output Class Initialized
INFO - 2021-05-14 19:55:13 --> Security Class Initialized
DEBUG - 2021-05-14 19:55:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 19:55:13 --> Input Class Initialized
INFO - 2021-05-14 19:55:13 --> Language Class Initialized
INFO - 2021-05-14 19:55:13 --> Loader Class Initialized
INFO - 2021-05-14 19:55:13 --> Helper loaded: url_helper
INFO - 2021-05-14 19:55:13 --> Helper loaded: form_helper
INFO - 2021-05-14 19:55:13 --> Helper loaded: common_helper
INFO - 2021-05-14 19:55:13 --> Database Driver Class Initialized
DEBUG - 2021-05-14 19:55:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 19:55:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 19:55:13 --> Controller Class Initialized
INFO - 2021-05-14 19:55:13 --> Form Validation Class Initialized
INFO - 2021-05-14 19:55:13 --> Model "Case_model" initialized
INFO - 2021-05-14 19:55:13 --> Model "Patientcase_model" initialized
INFO - 2021-05-14 19:55:13 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-05-14 19:55:13 --> Model "Case_model" initialized
INFO - 2021-05-14 19:55:13 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\cases/hold_case.php
INFO - 2021-05-14 19:55:13 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-05-14 19:55:13 --> Final output sent to browser
DEBUG - 2021-05-14 19:55:13 --> Total execution time: 0.3575
ERROR - 2021-05-14 19:55:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 19:55:13 --> Config Class Initialized
INFO - 2021-05-14 19:55:13 --> Hooks Class Initialized
DEBUG - 2021-05-14 19:55:13 --> UTF-8 Support Enabled
INFO - 2021-05-14 19:55:13 --> Utf8 Class Initialized
INFO - 2021-05-14 19:55:13 --> URI Class Initialized
INFO - 2021-05-14 19:55:13 --> Router Class Initialized
INFO - 2021-05-14 19:55:13 --> Output Class Initialized
INFO - 2021-05-14 19:55:13 --> Security Class Initialized
DEBUG - 2021-05-14 19:55:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 19:55:13 --> Input Class Initialized
INFO - 2021-05-14 19:55:13 --> Language Class Initialized
ERROR - 2021-05-14 19:55:13 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-05-14 19:55:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 19:55:31 --> Config Class Initialized
INFO - 2021-05-14 19:55:31 --> Hooks Class Initialized
DEBUG - 2021-05-14 19:55:31 --> UTF-8 Support Enabled
INFO - 2021-05-14 19:55:31 --> Utf8 Class Initialized
INFO - 2021-05-14 19:55:31 --> URI Class Initialized
INFO - 2021-05-14 19:55:31 --> Router Class Initialized
INFO - 2021-05-14 19:55:31 --> Output Class Initialized
INFO - 2021-05-14 19:55:31 --> Security Class Initialized
DEBUG - 2021-05-14 19:55:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 19:55:31 --> Input Class Initialized
INFO - 2021-05-14 19:55:31 --> Language Class Initialized
INFO - 2021-05-14 19:55:31 --> Loader Class Initialized
INFO - 2021-05-14 19:55:31 --> Helper loaded: url_helper
INFO - 2021-05-14 19:55:31 --> Helper loaded: form_helper
INFO - 2021-05-14 19:55:31 --> Helper loaded: common_helper
INFO - 2021-05-14 19:55:31 --> Database Driver Class Initialized
DEBUG - 2021-05-14 19:55:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 19:55:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 19:55:31 --> Controller Class Initialized
INFO - 2021-05-14 19:55:31 --> Form Validation Class Initialized
INFO - 2021-05-14 19:55:31 --> Model "Case_model" initialized
INFO - 2021-05-14 19:55:31 --> Model "Patientcase_model" initialized
INFO - 2021-05-14 19:55:31 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-05-14 19:55:31 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\cases/patient_amount_disbursed.php
INFO - 2021-05-14 19:55:31 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-05-14 19:55:31 --> Final output sent to browser
DEBUG - 2021-05-14 19:55:31 --> Total execution time: 0.4001
ERROR - 2021-05-14 19:55:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 19:55:31 --> Config Class Initialized
INFO - 2021-05-14 19:55:31 --> Hooks Class Initialized
DEBUG - 2021-05-14 19:55:31 --> UTF-8 Support Enabled
INFO - 2021-05-14 19:55:31 --> Utf8 Class Initialized
INFO - 2021-05-14 19:55:31 --> URI Class Initialized
INFO - 2021-05-14 19:55:31 --> Router Class Initialized
INFO - 2021-05-14 19:55:31 --> Output Class Initialized
INFO - 2021-05-14 19:55:31 --> Security Class Initialized
DEBUG - 2021-05-14 19:55:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 19:55:31 --> Input Class Initialized
INFO - 2021-05-14 19:55:31 --> Language Class Initialized
ERROR - 2021-05-14 19:55:31 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-05-14 19:55:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 19:55:45 --> Config Class Initialized
INFO - 2021-05-14 19:55:45 --> Hooks Class Initialized
DEBUG - 2021-05-14 19:55:45 --> UTF-8 Support Enabled
INFO - 2021-05-14 19:55:45 --> Utf8 Class Initialized
INFO - 2021-05-14 19:55:45 --> URI Class Initialized
INFO - 2021-05-14 19:55:45 --> Router Class Initialized
INFO - 2021-05-14 19:55:45 --> Output Class Initialized
INFO - 2021-05-14 19:55:45 --> Security Class Initialized
DEBUG - 2021-05-14 19:55:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 19:55:45 --> Input Class Initialized
INFO - 2021-05-14 19:55:45 --> Language Class Initialized
INFO - 2021-05-14 19:55:45 --> Loader Class Initialized
INFO - 2021-05-14 19:55:45 --> Helper loaded: url_helper
INFO - 2021-05-14 19:55:45 --> Helper loaded: form_helper
INFO - 2021-05-14 19:55:45 --> Helper loaded: common_helper
INFO - 2021-05-14 19:55:45 --> Database Driver Class Initialized
DEBUG - 2021-05-14 19:55:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 19:55:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 19:55:45 --> Controller Class Initialized
INFO - 2021-05-14 19:55:45 --> Form Validation Class Initialized
INFO - 2021-05-14 19:55:45 --> Model "Case_model" initialized
INFO - 2021-05-14 19:55:45 --> Model "Patientcase_model" initialized
INFO - 2021-05-14 19:55:46 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-05-14 19:55:46 --> Model "Case_model" initialized
INFO - 2021-05-14 19:55:46 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\cases/hold_case.php
INFO - 2021-05-14 19:55:46 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-05-14 19:55:46 --> Final output sent to browser
DEBUG - 2021-05-14 19:55:46 --> Total execution time: 0.5128
ERROR - 2021-05-14 19:55:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 19:55:50 --> Config Class Initialized
INFO - 2021-05-14 19:55:50 --> Hooks Class Initialized
DEBUG - 2021-05-14 19:55:50 --> UTF-8 Support Enabled
INFO - 2021-05-14 19:55:50 --> Utf8 Class Initialized
INFO - 2021-05-14 19:55:50 --> URI Class Initialized
INFO - 2021-05-14 19:55:50 --> Router Class Initialized
INFO - 2021-05-14 19:55:50 --> Output Class Initialized
INFO - 2021-05-14 19:55:50 --> Security Class Initialized
DEBUG - 2021-05-14 19:55:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 19:55:50 --> Input Class Initialized
INFO - 2021-05-14 19:55:50 --> Language Class Initialized
INFO - 2021-05-14 19:55:50 --> Loader Class Initialized
INFO - 2021-05-14 19:55:50 --> Helper loaded: url_helper
INFO - 2021-05-14 19:55:50 --> Helper loaded: form_helper
INFO - 2021-05-14 19:55:50 --> Helper loaded: common_helper
INFO - 2021-05-14 19:55:50 --> Database Driver Class Initialized
DEBUG - 2021-05-14 19:55:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 19:55:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 19:55:50 --> Controller Class Initialized
INFO - 2021-05-14 19:55:50 --> Form Validation Class Initialized
INFO - 2021-05-14 19:55:50 --> Model "Case_model" initialized
INFO - 2021-05-14 19:55:50 --> Model "Patientcase_model" initialized
INFO - 2021-05-14 19:55:50 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-05-14 19:55:50 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\cases/patient_amount_disbursed.php
INFO - 2021-05-14 19:55:50 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-05-14 19:55:50 --> Final output sent to browser
DEBUG - 2021-05-14 19:55:50 --> Total execution time: 0.1970
ERROR - 2021-05-14 19:55:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 19:55:50 --> Config Class Initialized
INFO - 2021-05-14 19:55:50 --> Hooks Class Initialized
DEBUG - 2021-05-14 19:55:50 --> UTF-8 Support Enabled
INFO - 2021-05-14 19:55:50 --> Utf8 Class Initialized
INFO - 2021-05-14 19:55:50 --> URI Class Initialized
INFO - 2021-05-14 19:55:50 --> Router Class Initialized
INFO - 2021-05-14 19:55:50 --> Output Class Initialized
INFO - 2021-05-14 19:55:50 --> Security Class Initialized
DEBUG - 2021-05-14 19:55:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 19:55:50 --> Input Class Initialized
INFO - 2021-05-14 19:55:50 --> Language Class Initialized
ERROR - 2021-05-14 19:55:50 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-05-14 19:57:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 19:57:26 --> Config Class Initialized
INFO - 2021-05-14 19:57:26 --> Hooks Class Initialized
DEBUG - 2021-05-14 19:57:26 --> UTF-8 Support Enabled
INFO - 2021-05-14 19:57:26 --> Utf8 Class Initialized
INFO - 2021-05-14 19:57:26 --> URI Class Initialized
INFO - 2021-05-14 19:57:26 --> Router Class Initialized
INFO - 2021-05-14 19:57:26 --> Output Class Initialized
INFO - 2021-05-14 19:57:26 --> Security Class Initialized
DEBUG - 2021-05-14 19:57:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 19:57:26 --> Input Class Initialized
INFO - 2021-05-14 19:57:26 --> Language Class Initialized
INFO - 2021-05-14 19:57:26 --> Loader Class Initialized
INFO - 2021-05-14 19:57:26 --> Helper loaded: url_helper
INFO - 2021-05-14 19:57:26 --> Helper loaded: form_helper
INFO - 2021-05-14 19:57:26 --> Helper loaded: common_helper
INFO - 2021-05-14 19:57:26 --> Database Driver Class Initialized
DEBUG - 2021-05-14 19:57:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 19:57:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 19:57:26 --> Controller Class Initialized
INFO - 2021-05-14 19:57:26 --> Form Validation Class Initialized
INFO - 2021-05-14 19:57:26 --> Model "Case_model" initialized
INFO - 2021-05-14 19:57:26 --> Model "Patientcase_model" initialized
INFO - 2021-05-14 19:57:26 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-05-14 19:57:26 --> Model "Case_model" initialized
INFO - 2021-05-14 19:57:26 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\cases/hold_case.php
INFO - 2021-05-14 19:57:26 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-05-14 19:57:26 --> Final output sent to browser
DEBUG - 2021-05-14 19:57:26 --> Total execution time: 0.4834
ERROR - 2021-05-14 19:57:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 19:57:29 --> Config Class Initialized
INFO - 2021-05-14 19:57:29 --> Hooks Class Initialized
DEBUG - 2021-05-14 19:57:29 --> UTF-8 Support Enabled
INFO - 2021-05-14 19:57:29 --> Utf8 Class Initialized
INFO - 2021-05-14 19:57:29 --> URI Class Initialized
INFO - 2021-05-14 19:57:29 --> Router Class Initialized
INFO - 2021-05-14 19:57:29 --> Output Class Initialized
INFO - 2021-05-14 19:57:29 --> Security Class Initialized
DEBUG - 2021-05-14 19:57:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 19:57:29 --> Input Class Initialized
INFO - 2021-05-14 19:57:29 --> Language Class Initialized
INFO - 2021-05-14 19:57:29 --> Loader Class Initialized
INFO - 2021-05-14 19:57:29 --> Helper loaded: url_helper
INFO - 2021-05-14 19:57:29 --> Helper loaded: form_helper
INFO - 2021-05-14 19:57:29 --> Helper loaded: common_helper
INFO - 2021-05-14 19:57:29 --> Database Driver Class Initialized
DEBUG - 2021-05-14 19:57:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 19:57:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 19:57:29 --> Controller Class Initialized
INFO - 2021-05-14 19:57:29 --> Form Validation Class Initialized
INFO - 2021-05-14 19:57:29 --> Model "Case_model" initialized
INFO - 2021-05-14 19:57:29 --> Model "Patientcase_model" initialized
INFO - 2021-05-14 19:57:29 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-05-14 19:57:29 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\cases/patient_amount_disbursed.php
INFO - 2021-05-14 19:57:29 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-05-14 19:57:29 --> Final output sent to browser
DEBUG - 2021-05-14 19:57:29 --> Total execution time: 0.1446
ERROR - 2021-05-14 19:57:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 19:57:29 --> Config Class Initialized
INFO - 2021-05-14 19:57:29 --> Hooks Class Initialized
DEBUG - 2021-05-14 19:57:29 --> UTF-8 Support Enabled
INFO - 2021-05-14 19:57:29 --> Utf8 Class Initialized
INFO - 2021-05-14 19:57:29 --> URI Class Initialized
INFO - 2021-05-14 19:57:29 --> Router Class Initialized
INFO - 2021-05-14 19:57:29 --> Output Class Initialized
INFO - 2021-05-14 19:57:29 --> Security Class Initialized
DEBUG - 2021-05-14 19:57:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 19:57:29 --> Input Class Initialized
INFO - 2021-05-14 19:57:29 --> Language Class Initialized
ERROR - 2021-05-14 19:57:29 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-05-14 19:57:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 19:57:34 --> Config Class Initialized
INFO - 2021-05-14 19:57:34 --> Hooks Class Initialized
DEBUG - 2021-05-14 19:57:34 --> UTF-8 Support Enabled
INFO - 2021-05-14 19:57:34 --> Utf8 Class Initialized
INFO - 2021-05-14 19:57:34 --> URI Class Initialized
INFO - 2021-05-14 19:57:34 --> Router Class Initialized
INFO - 2021-05-14 19:57:34 --> Output Class Initialized
INFO - 2021-05-14 19:57:34 --> Security Class Initialized
DEBUG - 2021-05-14 19:57:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 19:57:34 --> Input Class Initialized
INFO - 2021-05-14 19:57:34 --> Language Class Initialized
INFO - 2021-05-14 19:57:34 --> Loader Class Initialized
INFO - 2021-05-14 19:57:34 --> Helper loaded: url_helper
INFO - 2021-05-14 19:57:34 --> Helper loaded: form_helper
INFO - 2021-05-14 19:57:34 --> Helper loaded: common_helper
INFO - 2021-05-14 19:57:34 --> Database Driver Class Initialized
DEBUG - 2021-05-14 19:57:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 19:57:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 19:57:34 --> Controller Class Initialized
INFO - 2021-05-14 19:57:34 --> Form Validation Class Initialized
INFO - 2021-05-14 19:57:34 --> Model "Case_model" initialized
INFO - 2021-05-14 19:57:34 --> Model "Patientcase_model" initialized
INFO - 2021-05-14 19:57:35 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-05-14 19:57:35 --> Model "Case_model" initialized
INFO - 2021-05-14 19:57:35 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\cases/hold_case.php
INFO - 2021-05-14 19:57:35 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-05-14 19:57:35 --> Final output sent to browser
DEBUG - 2021-05-14 19:57:35 --> Total execution time: 0.4276
ERROR - 2021-05-14 19:57:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 19:57:37 --> Config Class Initialized
INFO - 2021-05-14 19:57:37 --> Hooks Class Initialized
DEBUG - 2021-05-14 19:57:37 --> UTF-8 Support Enabled
INFO - 2021-05-14 19:57:37 --> Utf8 Class Initialized
INFO - 2021-05-14 19:57:37 --> URI Class Initialized
INFO - 2021-05-14 19:57:37 --> Router Class Initialized
INFO - 2021-05-14 19:57:37 --> Output Class Initialized
INFO - 2021-05-14 19:57:37 --> Security Class Initialized
DEBUG - 2021-05-14 19:57:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 19:57:37 --> Input Class Initialized
INFO - 2021-05-14 19:57:37 --> Language Class Initialized
INFO - 2021-05-14 19:57:37 --> Loader Class Initialized
INFO - 2021-05-14 19:57:37 --> Helper loaded: url_helper
INFO - 2021-05-14 19:57:37 --> Helper loaded: form_helper
INFO - 2021-05-14 19:57:37 --> Helper loaded: common_helper
INFO - 2021-05-14 19:57:37 --> Database Driver Class Initialized
DEBUG - 2021-05-14 19:57:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 19:57:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 19:57:37 --> Controller Class Initialized
INFO - 2021-05-14 19:57:37 --> Form Validation Class Initialized
INFO - 2021-05-14 19:57:37 --> Model "Case_model" initialized
INFO - 2021-05-14 19:57:37 --> Model "Patientcase_model" initialized
INFO - 2021-05-14 19:57:38 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-05-14 19:57:38 --> Model "Case_model" initialized
INFO - 2021-05-14 19:57:38 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\cases/reject_case.php
INFO - 2021-05-14 19:57:38 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-05-14 19:57:38 --> Final output sent to browser
DEBUG - 2021-05-14 19:57:38 --> Total execution time: 0.3995
ERROR - 2021-05-14 19:57:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 19:57:38 --> Config Class Initialized
INFO - 2021-05-14 19:57:38 --> Hooks Class Initialized
DEBUG - 2021-05-14 19:57:38 --> UTF-8 Support Enabled
INFO - 2021-05-14 19:57:38 --> Utf8 Class Initialized
INFO - 2021-05-14 19:57:38 --> URI Class Initialized
INFO - 2021-05-14 19:57:38 --> Router Class Initialized
INFO - 2021-05-14 19:57:38 --> Output Class Initialized
INFO - 2021-05-14 19:57:38 --> Security Class Initialized
DEBUG - 2021-05-14 19:57:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 19:57:38 --> Input Class Initialized
INFO - 2021-05-14 19:57:38 --> Language Class Initialized
ERROR - 2021-05-14 19:57:38 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-05-14 19:57:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 19:57:41 --> Config Class Initialized
INFO - 2021-05-14 19:57:41 --> Hooks Class Initialized
DEBUG - 2021-05-14 19:57:41 --> UTF-8 Support Enabled
INFO - 2021-05-14 19:57:41 --> Utf8 Class Initialized
INFO - 2021-05-14 19:57:41 --> URI Class Initialized
INFO - 2021-05-14 19:57:41 --> Router Class Initialized
INFO - 2021-05-14 19:57:41 --> Output Class Initialized
INFO - 2021-05-14 19:57:41 --> Security Class Initialized
DEBUG - 2021-05-14 19:57:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 19:57:41 --> Input Class Initialized
INFO - 2021-05-14 19:57:41 --> Language Class Initialized
INFO - 2021-05-14 19:57:41 --> Loader Class Initialized
INFO - 2021-05-14 19:57:41 --> Helper loaded: url_helper
INFO - 2021-05-14 19:57:41 --> Helper loaded: form_helper
INFO - 2021-05-14 19:57:41 --> Helper loaded: common_helper
INFO - 2021-05-14 19:57:42 --> Database Driver Class Initialized
DEBUG - 2021-05-14 19:57:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 19:57:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 19:57:42 --> Controller Class Initialized
INFO - 2021-05-14 19:57:42 --> Form Validation Class Initialized
INFO - 2021-05-14 19:57:42 --> Model "Case_model" initialized
INFO - 2021-05-14 19:57:42 --> Model "Patientcase_model" initialized
INFO - 2021-05-14 19:57:42 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-05-14 19:57:42 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\cases/patient_amount_disbursed.php
INFO - 2021-05-14 19:57:42 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-05-14 19:57:42 --> Final output sent to browser
DEBUG - 2021-05-14 19:57:42 --> Total execution time: 0.1978
ERROR - 2021-05-14 19:57:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 19:57:42 --> Config Class Initialized
INFO - 2021-05-14 19:57:42 --> Hooks Class Initialized
DEBUG - 2021-05-14 19:57:42 --> UTF-8 Support Enabled
INFO - 2021-05-14 19:57:42 --> Utf8 Class Initialized
INFO - 2021-05-14 19:57:42 --> URI Class Initialized
INFO - 2021-05-14 19:57:42 --> Router Class Initialized
INFO - 2021-05-14 19:57:42 --> Output Class Initialized
INFO - 2021-05-14 19:57:42 --> Security Class Initialized
DEBUG - 2021-05-14 19:57:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 19:57:42 --> Input Class Initialized
INFO - 2021-05-14 19:57:42 --> Language Class Initialized
ERROR - 2021-05-14 19:57:42 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-05-14 19:57:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 19:57:47 --> Config Class Initialized
INFO - 2021-05-14 19:57:47 --> Hooks Class Initialized
DEBUG - 2021-05-14 19:57:47 --> UTF-8 Support Enabled
INFO - 2021-05-14 19:57:47 --> Utf8 Class Initialized
INFO - 2021-05-14 19:57:47 --> URI Class Initialized
INFO - 2021-05-14 19:57:47 --> Router Class Initialized
INFO - 2021-05-14 19:57:47 --> Output Class Initialized
INFO - 2021-05-14 19:57:47 --> Security Class Initialized
DEBUG - 2021-05-14 19:57:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 19:57:47 --> Input Class Initialized
INFO - 2021-05-14 19:57:47 --> Language Class Initialized
INFO - 2021-05-14 19:57:47 --> Loader Class Initialized
INFO - 2021-05-14 19:57:47 --> Helper loaded: url_helper
INFO - 2021-05-14 19:57:47 --> Helper loaded: form_helper
INFO - 2021-05-14 19:57:47 --> Helper loaded: common_helper
INFO - 2021-05-14 19:57:47 --> Database Driver Class Initialized
DEBUG - 2021-05-14 19:57:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 19:57:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 19:57:47 --> Controller Class Initialized
INFO - 2021-05-14 19:57:47 --> Form Validation Class Initialized
INFO - 2021-05-14 19:57:47 --> Model "Case_model" initialized
INFO - 2021-05-14 19:57:47 --> Model "Patientcase_model" initialized
INFO - 2021-05-14 19:57:52 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-05-14 19:57:52 --> Model "Case_model" initialized
INFO - 2021-05-14 19:58:00 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\cases/all_case.php
INFO - 2021-05-14 19:58:00 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-05-14 19:58:00 --> Final output sent to browser
DEBUG - 2021-05-14 19:58:00 --> Total execution time: 13.5270
ERROR - 2021-05-14 19:58:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 19:58:00 --> Config Class Initialized
INFO - 2021-05-14 19:58:00 --> Hooks Class Initialized
DEBUG - 2021-05-14 19:58:00 --> UTF-8 Support Enabled
INFO - 2021-05-14 19:58:00 --> Utf8 Class Initialized
INFO - 2021-05-14 19:58:00 --> URI Class Initialized
INFO - 2021-05-14 19:58:00 --> Router Class Initialized
INFO - 2021-05-14 19:58:00 --> Output Class Initialized
INFO - 2021-05-14 19:58:00 --> Security Class Initialized
DEBUG - 2021-05-14 19:58:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 19:58:00 --> Input Class Initialized
INFO - 2021-05-14 19:58:00 --> Language Class Initialized
ERROR - 2021-05-14 19:58:00 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-05-14 19:58:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 19:58:18 --> Config Class Initialized
INFO - 2021-05-14 19:58:18 --> Hooks Class Initialized
DEBUG - 2021-05-14 19:58:18 --> UTF-8 Support Enabled
INFO - 2021-05-14 19:58:18 --> Utf8 Class Initialized
INFO - 2021-05-14 19:58:18 --> URI Class Initialized
INFO - 2021-05-14 19:58:18 --> Router Class Initialized
INFO - 2021-05-14 19:58:18 --> Output Class Initialized
INFO - 2021-05-14 19:58:18 --> Security Class Initialized
DEBUG - 2021-05-14 19:58:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 19:58:18 --> Input Class Initialized
INFO - 2021-05-14 19:58:18 --> Language Class Initialized
INFO - 2021-05-14 19:58:18 --> Loader Class Initialized
INFO - 2021-05-14 19:58:18 --> Helper loaded: url_helper
INFO - 2021-05-14 19:58:18 --> Helper loaded: form_helper
INFO - 2021-05-14 19:58:18 --> Helper loaded: common_helper
INFO - 2021-05-14 19:58:18 --> Database Driver Class Initialized
DEBUG - 2021-05-14 19:58:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 19:58:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 19:58:18 --> Controller Class Initialized
INFO - 2021-05-14 19:58:19 --> Form Validation Class Initialized
INFO - 2021-05-14 19:58:19 --> Model "Case_model" initialized
INFO - 2021-05-14 19:58:19 --> Model "Patientcase_model" initialized
INFO - 2021-05-14 19:58:19 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-05-14 19:58:19 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\cases/patient_amount_disbursed.php
INFO - 2021-05-14 19:58:19 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-05-14 19:58:19 --> Final output sent to browser
DEBUG - 2021-05-14 19:58:19 --> Total execution time: 0.1214
ERROR - 2021-05-14 19:58:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 19:58:22 --> Config Class Initialized
INFO - 2021-05-14 19:58:22 --> Hooks Class Initialized
DEBUG - 2021-05-14 19:58:22 --> UTF-8 Support Enabled
INFO - 2021-05-14 19:58:22 --> Utf8 Class Initialized
INFO - 2021-05-14 19:58:22 --> URI Class Initialized
INFO - 2021-05-14 19:58:22 --> Router Class Initialized
INFO - 2021-05-14 19:58:22 --> Output Class Initialized
INFO - 2021-05-14 19:58:22 --> Security Class Initialized
DEBUG - 2021-05-14 19:58:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 19:58:22 --> Input Class Initialized
INFO - 2021-05-14 19:58:22 --> Language Class Initialized
INFO - 2021-05-14 19:58:22 --> Loader Class Initialized
INFO - 2021-05-14 19:58:22 --> Helper loaded: url_helper
INFO - 2021-05-14 19:58:22 --> Helper loaded: form_helper
INFO - 2021-05-14 19:58:22 --> Helper loaded: common_helper
INFO - 2021-05-14 19:58:22 --> Database Driver Class Initialized
DEBUG - 2021-05-14 19:58:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 19:58:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 19:58:22 --> Controller Class Initialized
INFO - 2021-05-14 19:58:22 --> Form Validation Class Initialized
INFO - 2021-05-14 19:58:22 --> Model "Case_model" initialized
INFO - 2021-05-14 19:58:22 --> Model "Patientcase_model" initialized
INFO - 2021-05-14 19:58:22 --> Final output sent to browser
DEBUG - 2021-05-14 19:58:22 --> Total execution time: 0.0749
ERROR - 2021-05-14 19:58:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 19:58:30 --> Config Class Initialized
INFO - 2021-05-14 19:58:30 --> Hooks Class Initialized
DEBUG - 2021-05-14 19:58:30 --> UTF-8 Support Enabled
INFO - 2021-05-14 19:58:30 --> Utf8 Class Initialized
INFO - 2021-05-14 19:58:30 --> URI Class Initialized
INFO - 2021-05-14 19:58:30 --> Router Class Initialized
INFO - 2021-05-14 19:58:30 --> Output Class Initialized
INFO - 2021-05-14 19:58:30 --> Security Class Initialized
DEBUG - 2021-05-14 19:58:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 19:58:30 --> Input Class Initialized
INFO - 2021-05-14 19:58:30 --> Language Class Initialized
INFO - 2021-05-14 19:58:30 --> Loader Class Initialized
INFO - 2021-05-14 19:58:30 --> Helper loaded: url_helper
INFO - 2021-05-14 19:58:30 --> Helper loaded: form_helper
INFO - 2021-05-14 19:58:30 --> Helper loaded: common_helper
INFO - 2021-05-14 19:58:30 --> Database Driver Class Initialized
DEBUG - 2021-05-14 19:58:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 19:58:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 19:58:30 --> Controller Class Initialized
INFO - 2021-05-14 19:58:30 --> Form Validation Class Initialized
INFO - 2021-05-14 19:58:30 --> Model "Case_model" initialized
INFO - 2021-05-14 19:58:30 --> Model "Patientcase_model" initialized
INFO - 2021-05-14 19:58:35 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-05-14 19:58:35 --> Model "Case_model" initialized
INFO - 2021-05-14 19:58:43 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\cases/all_case.php
INFO - 2021-05-14 19:58:43 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-05-14 19:58:43 --> Final output sent to browser
DEBUG - 2021-05-14 19:58:43 --> Total execution time: 13.7116
ERROR - 2021-05-14 19:58:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 19:58:43 --> Config Class Initialized
INFO - 2021-05-14 19:58:43 --> Hooks Class Initialized
DEBUG - 2021-05-14 19:58:43 --> UTF-8 Support Enabled
INFO - 2021-05-14 19:58:43 --> Utf8 Class Initialized
INFO - 2021-05-14 19:58:43 --> URI Class Initialized
INFO - 2021-05-14 19:58:43 --> Router Class Initialized
INFO - 2021-05-14 19:58:43 --> Output Class Initialized
INFO - 2021-05-14 19:58:43 --> Security Class Initialized
DEBUG - 2021-05-14 19:58:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 19:58:43 --> Input Class Initialized
INFO - 2021-05-14 19:58:43 --> Language Class Initialized
ERROR - 2021-05-14 19:58:43 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-05-14 19:59:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 19:59:45 --> Config Class Initialized
INFO - 2021-05-14 19:59:45 --> Hooks Class Initialized
DEBUG - 2021-05-14 19:59:45 --> UTF-8 Support Enabled
INFO - 2021-05-14 19:59:45 --> Utf8 Class Initialized
INFO - 2021-05-14 19:59:45 --> URI Class Initialized
INFO - 2021-05-14 19:59:45 --> Router Class Initialized
INFO - 2021-05-14 19:59:45 --> Output Class Initialized
INFO - 2021-05-14 19:59:45 --> Security Class Initialized
DEBUG - 2021-05-14 19:59:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 19:59:45 --> Input Class Initialized
INFO - 2021-05-14 19:59:45 --> Language Class Initialized
INFO - 2021-05-14 19:59:45 --> Loader Class Initialized
INFO - 2021-05-14 19:59:45 --> Helper loaded: url_helper
INFO - 2021-05-14 19:59:45 --> Helper loaded: form_helper
INFO - 2021-05-14 19:59:45 --> Helper loaded: common_helper
INFO - 2021-05-14 19:59:45 --> Database Driver Class Initialized
DEBUG - 2021-05-14 19:59:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 19:59:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 19:59:45 --> Controller Class Initialized
INFO - 2021-05-14 19:59:45 --> Form Validation Class Initialized
INFO - 2021-05-14 19:59:45 --> Encrypt Class Initialized
INFO - 2021-05-14 19:59:45 --> Model "Patient_model" initialized
INFO - 2021-05-14 19:59:45 --> Model "Patientcase_model" initialized
INFO - 2021-05-14 19:59:45 --> Model "Prefix_master" initialized
INFO - 2021-05-14 19:59:45 --> Model "Users_model" initialized
INFO - 2021-05-14 19:59:45 --> Model "Hospital_model" initialized
INFO - 2021-05-14 19:59:46 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-05-14 19:59:46 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\patientcase/index.php
INFO - 2021-05-14 19:59:46 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-05-14 19:59:46 --> Final output sent to browser
DEBUG - 2021-05-14 19:59:46 --> Total execution time: 0.3996
ERROR - 2021-05-14 19:59:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 19:59:46 --> Config Class Initialized
INFO - 2021-05-14 19:59:46 --> Hooks Class Initialized
DEBUG - 2021-05-14 19:59:46 --> UTF-8 Support Enabled
INFO - 2021-05-14 19:59:46 --> Utf8 Class Initialized
INFO - 2021-05-14 19:59:46 --> URI Class Initialized
INFO - 2021-05-14 19:59:46 --> Router Class Initialized
INFO - 2021-05-14 19:59:46 --> Output Class Initialized
INFO - 2021-05-14 19:59:46 --> Security Class Initialized
DEBUG - 2021-05-14 19:59:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 19:59:46 --> Input Class Initialized
INFO - 2021-05-14 19:59:46 --> Language Class Initialized
ERROR - 2021-05-14 19:59:46 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-05-14 19:59:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 19:59:58 --> Config Class Initialized
INFO - 2021-05-14 19:59:58 --> Hooks Class Initialized
DEBUG - 2021-05-14 19:59:58 --> UTF-8 Support Enabled
INFO - 2021-05-14 19:59:58 --> Utf8 Class Initialized
INFO - 2021-05-14 19:59:58 --> URI Class Initialized
INFO - 2021-05-14 19:59:58 --> Router Class Initialized
INFO - 2021-05-14 19:59:58 --> Output Class Initialized
INFO - 2021-05-14 19:59:58 --> Security Class Initialized
DEBUG - 2021-05-14 19:59:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 19:59:58 --> Input Class Initialized
INFO - 2021-05-14 19:59:58 --> Language Class Initialized
INFO - 2021-05-14 19:59:58 --> Loader Class Initialized
INFO - 2021-05-14 19:59:58 --> Helper loaded: url_helper
INFO - 2021-05-14 19:59:58 --> Helper loaded: form_helper
INFO - 2021-05-14 19:59:58 --> Helper loaded: common_helper
INFO - 2021-05-14 19:59:58 --> Database Driver Class Initialized
DEBUG - 2021-05-14 19:59:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 19:59:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 19:59:58 --> Controller Class Initialized
INFO - 2021-05-14 19:59:58 --> Form Validation Class Initialized
INFO - 2021-05-14 19:59:58 --> Model "Case_model" initialized
INFO - 2021-05-14 19:59:58 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-05-14 19:59:58 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\transaction/donner_donation.php
INFO - 2021-05-14 19:59:58 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-05-14 19:59:58 --> Final output sent to browser
DEBUG - 2021-05-14 19:59:58 --> Total execution time: 0.1274
ERROR - 2021-05-14 19:59:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 19:59:58 --> Config Class Initialized
INFO - 2021-05-14 19:59:58 --> Hooks Class Initialized
DEBUG - 2021-05-14 19:59:58 --> UTF-8 Support Enabled
INFO - 2021-05-14 19:59:58 --> Utf8 Class Initialized
INFO - 2021-05-14 19:59:58 --> URI Class Initialized
INFO - 2021-05-14 19:59:58 --> Router Class Initialized
INFO - 2021-05-14 19:59:58 --> Output Class Initialized
INFO - 2021-05-14 19:59:58 --> Security Class Initialized
DEBUG - 2021-05-14 19:59:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 19:59:58 --> Input Class Initialized
INFO - 2021-05-14 19:59:58 --> Language Class Initialized
ERROR - 2021-05-14 19:59:58 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-05-14 20:00:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 20:00:03 --> Config Class Initialized
INFO - 2021-05-14 20:00:03 --> Hooks Class Initialized
DEBUG - 2021-05-14 20:00:03 --> UTF-8 Support Enabled
INFO - 2021-05-14 20:00:03 --> Utf8 Class Initialized
INFO - 2021-05-14 20:00:03 --> URI Class Initialized
INFO - 2021-05-14 20:00:03 --> Router Class Initialized
INFO - 2021-05-14 20:00:03 --> Output Class Initialized
INFO - 2021-05-14 20:00:03 --> Security Class Initialized
DEBUG - 2021-05-14 20:00:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 20:00:03 --> Input Class Initialized
INFO - 2021-05-14 20:00:03 --> Language Class Initialized
INFO - 2021-05-14 20:00:03 --> Loader Class Initialized
INFO - 2021-05-14 20:00:03 --> Helper loaded: url_helper
INFO - 2021-05-14 20:00:03 --> Helper loaded: form_helper
INFO - 2021-05-14 20:00:03 --> Helper loaded: common_helper
INFO - 2021-05-14 20:00:03 --> Database Driver Class Initialized
DEBUG - 2021-05-14 20:00:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 20:00:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 20:00:03 --> Controller Class Initialized
INFO - 2021-05-14 20:00:03 --> Form Validation Class Initialized
INFO - 2021-05-14 20:00:03 --> Model "Case_model" initialized
INFO - 2021-05-14 20:00:03 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-05-14 20:00:03 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\transaction/refund_amount.php
INFO - 2021-05-14 20:00:03 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-05-14 20:00:03 --> Final output sent to browser
DEBUG - 2021-05-14 20:00:03 --> Total execution time: 0.1840
ERROR - 2021-05-14 20:00:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 20:00:03 --> Config Class Initialized
INFO - 2021-05-14 20:00:03 --> Hooks Class Initialized
DEBUG - 2021-05-14 20:00:03 --> UTF-8 Support Enabled
INFO - 2021-05-14 20:00:03 --> Utf8 Class Initialized
INFO - 2021-05-14 20:00:03 --> URI Class Initialized
INFO - 2021-05-14 20:00:03 --> Router Class Initialized
INFO - 2021-05-14 20:00:03 --> Output Class Initialized
INFO - 2021-05-14 20:00:03 --> Security Class Initialized
DEBUG - 2021-05-14 20:00:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 20:00:03 --> Input Class Initialized
INFO - 2021-05-14 20:00:03 --> Language Class Initialized
ERROR - 2021-05-14 20:00:03 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-05-14 20:01:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 20:01:37 --> Config Class Initialized
INFO - 2021-05-14 20:01:37 --> Hooks Class Initialized
DEBUG - 2021-05-14 20:01:37 --> UTF-8 Support Enabled
INFO - 2021-05-14 20:01:37 --> Utf8 Class Initialized
INFO - 2021-05-14 20:01:37 --> URI Class Initialized
INFO - 2021-05-14 20:01:37 --> Router Class Initialized
INFO - 2021-05-14 20:01:37 --> Output Class Initialized
INFO - 2021-05-14 20:01:37 --> Security Class Initialized
DEBUG - 2021-05-14 20:01:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 20:01:37 --> Input Class Initialized
INFO - 2021-05-14 20:01:37 --> Language Class Initialized
INFO - 2021-05-14 20:01:37 --> Loader Class Initialized
INFO - 2021-05-14 20:01:37 --> Helper loaded: url_helper
INFO - 2021-05-14 20:01:37 --> Helper loaded: form_helper
INFO - 2021-05-14 20:01:37 --> Helper loaded: common_helper
INFO - 2021-05-14 20:01:37 --> Database Driver Class Initialized
DEBUG - 2021-05-14 20:01:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 20:01:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 20:01:38 --> Controller Class Initialized
INFO - 2021-05-14 20:01:38 --> Form Validation Class Initialized
INFO - 2021-05-14 20:01:38 --> Model "Case_model" initialized
INFO - 2021-05-14 20:01:38 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-05-14 20:01:38 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\transaction/refund_amount.php
INFO - 2021-05-14 20:01:38 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-05-14 20:01:38 --> Final output sent to browser
DEBUG - 2021-05-14 20:01:38 --> Total execution time: 0.0426
ERROR - 2021-05-14 20:01:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 20:01:38 --> Config Class Initialized
INFO - 2021-05-14 20:01:38 --> Hooks Class Initialized
DEBUG - 2021-05-14 20:01:38 --> UTF-8 Support Enabled
INFO - 2021-05-14 20:01:38 --> Utf8 Class Initialized
INFO - 2021-05-14 20:01:38 --> URI Class Initialized
INFO - 2021-05-14 20:01:38 --> Router Class Initialized
INFO - 2021-05-14 20:01:38 --> Output Class Initialized
INFO - 2021-05-14 20:01:38 --> Security Class Initialized
DEBUG - 2021-05-14 20:01:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 20:01:38 --> Input Class Initialized
INFO - 2021-05-14 20:01:38 --> Language Class Initialized
ERROR - 2021-05-14 20:01:38 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-05-14 20:01:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 20:01:46 --> Config Class Initialized
INFO - 2021-05-14 20:01:46 --> Hooks Class Initialized
DEBUG - 2021-05-14 20:01:46 --> UTF-8 Support Enabled
INFO - 2021-05-14 20:01:46 --> Utf8 Class Initialized
INFO - 2021-05-14 20:01:46 --> URI Class Initialized
INFO - 2021-05-14 20:01:46 --> Router Class Initialized
INFO - 2021-05-14 20:01:46 --> Output Class Initialized
INFO - 2021-05-14 20:01:46 --> Security Class Initialized
DEBUG - 2021-05-14 20:01:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 20:01:46 --> Input Class Initialized
INFO - 2021-05-14 20:01:46 --> Language Class Initialized
INFO - 2021-05-14 20:01:46 --> Loader Class Initialized
INFO - 2021-05-14 20:01:46 --> Helper loaded: url_helper
INFO - 2021-05-14 20:01:46 --> Helper loaded: form_helper
INFO - 2021-05-14 20:01:46 --> Helper loaded: common_helper
INFO - 2021-05-14 20:01:46 --> Database Driver Class Initialized
DEBUG - 2021-05-14 20:01:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 20:01:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 20:01:46 --> Controller Class Initialized
INFO - 2021-05-14 20:01:46 --> Form Validation Class Initialized
INFO - 2021-05-14 20:01:46 --> Model "Report_model" initialized
INFO - 2021-05-14 20:01:46 --> Model "Case_model" initialized
INFO - 2021-05-14 20:01:46 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-05-14 20:01:46 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\reports/patient_details.php
INFO - 2021-05-14 20:01:46 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-05-14 20:01:46 --> Final output sent to browser
DEBUG - 2021-05-14 20:01:46 --> Total execution time: 0.0573
ERROR - 2021-05-14 20:01:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 20:01:46 --> Config Class Initialized
INFO - 2021-05-14 20:01:46 --> Hooks Class Initialized
DEBUG - 2021-05-14 20:01:46 --> UTF-8 Support Enabled
INFO - 2021-05-14 20:01:46 --> Utf8 Class Initialized
INFO - 2021-05-14 20:01:46 --> URI Class Initialized
INFO - 2021-05-14 20:01:46 --> Router Class Initialized
INFO - 2021-05-14 20:01:46 --> Output Class Initialized
INFO - 2021-05-14 20:01:46 --> Security Class Initialized
DEBUG - 2021-05-14 20:01:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 20:01:46 --> Input Class Initialized
INFO - 2021-05-14 20:01:46 --> Language Class Initialized
ERROR - 2021-05-14 20:01:46 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-05-14 20:01:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 20:01:57 --> Config Class Initialized
INFO - 2021-05-14 20:01:57 --> Hooks Class Initialized
DEBUG - 2021-05-14 20:01:57 --> UTF-8 Support Enabled
INFO - 2021-05-14 20:01:57 --> Utf8 Class Initialized
INFO - 2021-05-14 20:01:57 --> URI Class Initialized
INFO - 2021-05-14 20:01:57 --> Router Class Initialized
INFO - 2021-05-14 20:01:57 --> Output Class Initialized
INFO - 2021-05-14 20:01:57 --> Security Class Initialized
DEBUG - 2021-05-14 20:01:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 20:01:57 --> Input Class Initialized
INFO - 2021-05-14 20:01:57 --> Language Class Initialized
INFO - 2021-05-14 20:01:57 --> Loader Class Initialized
INFO - 2021-05-14 20:01:57 --> Helper loaded: url_helper
INFO - 2021-05-14 20:01:57 --> Helper loaded: form_helper
INFO - 2021-05-14 20:01:57 --> Helper loaded: common_helper
INFO - 2021-05-14 20:01:57 --> Database Driver Class Initialized
DEBUG - 2021-05-14 20:01:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 20:01:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 20:01:57 --> Controller Class Initialized
INFO - 2021-05-14 20:01:57 --> Form Validation Class Initialized
INFO - 2021-05-14 20:01:57 --> Model "Report_model" initialized
INFO - 2021-05-14 20:01:57 --> Model "Case_model" initialized
INFO - 2021-05-14 20:01:57 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-05-14 20:01:57 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\reports/case_wise_patient_details.php
INFO - 2021-05-14 20:01:57 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-05-14 20:01:57 --> Final output sent to browser
DEBUG - 2021-05-14 20:01:57 --> Total execution time: 0.0595
ERROR - 2021-05-14 20:01:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 20:01:57 --> Config Class Initialized
INFO - 2021-05-14 20:01:57 --> Hooks Class Initialized
DEBUG - 2021-05-14 20:01:57 --> UTF-8 Support Enabled
INFO - 2021-05-14 20:01:57 --> Utf8 Class Initialized
INFO - 2021-05-14 20:01:57 --> URI Class Initialized
INFO - 2021-05-14 20:01:57 --> Router Class Initialized
INFO - 2021-05-14 20:01:57 --> Output Class Initialized
INFO - 2021-05-14 20:01:57 --> Security Class Initialized
DEBUG - 2021-05-14 20:01:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 20:01:57 --> Input Class Initialized
INFO - 2021-05-14 20:01:57 --> Language Class Initialized
ERROR - 2021-05-14 20:01:57 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-05-14 20:02:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 20:02:02 --> Config Class Initialized
INFO - 2021-05-14 20:02:02 --> Hooks Class Initialized
DEBUG - 2021-05-14 20:02:02 --> UTF-8 Support Enabled
INFO - 2021-05-14 20:02:02 --> Utf8 Class Initialized
INFO - 2021-05-14 20:02:02 --> URI Class Initialized
INFO - 2021-05-14 20:02:02 --> Router Class Initialized
INFO - 2021-05-14 20:02:02 --> Output Class Initialized
INFO - 2021-05-14 20:02:02 --> Security Class Initialized
DEBUG - 2021-05-14 20:02:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 20:02:02 --> Input Class Initialized
INFO - 2021-05-14 20:02:02 --> Language Class Initialized
INFO - 2021-05-14 20:02:02 --> Loader Class Initialized
INFO - 2021-05-14 20:02:02 --> Helper loaded: url_helper
INFO - 2021-05-14 20:02:02 --> Helper loaded: form_helper
INFO - 2021-05-14 20:02:02 --> Helper loaded: common_helper
INFO - 2021-05-14 20:02:02 --> Database Driver Class Initialized
DEBUG - 2021-05-14 20:02:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 20:02:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 20:02:02 --> Controller Class Initialized
INFO - 2021-05-14 20:02:02 --> Form Validation Class Initialized
INFO - 2021-05-14 20:02:02 --> Model "Report_model" initialized
INFO - 2021-05-14 20:02:02 --> Model "Case_model" initialized
INFO - 2021-05-14 20:02:02 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-05-14 20:02:02 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\reports/donor_wise_patient_details.php
INFO - 2021-05-14 20:02:02 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-05-14 20:02:02 --> Final output sent to browser
DEBUG - 2021-05-14 20:02:02 --> Total execution time: 0.0521
ERROR - 2021-05-14 20:02:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 20:02:02 --> Config Class Initialized
INFO - 2021-05-14 20:02:02 --> Hooks Class Initialized
DEBUG - 2021-05-14 20:02:02 --> UTF-8 Support Enabled
INFO - 2021-05-14 20:02:02 --> Utf8 Class Initialized
INFO - 2021-05-14 20:02:02 --> URI Class Initialized
INFO - 2021-05-14 20:02:02 --> Router Class Initialized
INFO - 2021-05-14 20:02:02 --> Output Class Initialized
INFO - 2021-05-14 20:02:02 --> Security Class Initialized
DEBUG - 2021-05-14 20:02:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 20:02:02 --> Input Class Initialized
INFO - 2021-05-14 20:02:02 --> Language Class Initialized
ERROR - 2021-05-14 20:02:02 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-05-14 20:02:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 20:02:05 --> Config Class Initialized
INFO - 2021-05-14 20:02:05 --> Hooks Class Initialized
DEBUG - 2021-05-14 20:02:05 --> UTF-8 Support Enabled
INFO - 2021-05-14 20:02:05 --> Utf8 Class Initialized
INFO - 2021-05-14 20:02:05 --> URI Class Initialized
INFO - 2021-05-14 20:02:05 --> Router Class Initialized
INFO - 2021-05-14 20:02:05 --> Output Class Initialized
INFO - 2021-05-14 20:02:05 --> Security Class Initialized
DEBUG - 2021-05-14 20:02:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 20:02:05 --> Input Class Initialized
INFO - 2021-05-14 20:02:05 --> Language Class Initialized
INFO - 2021-05-14 20:02:05 --> Loader Class Initialized
INFO - 2021-05-14 20:02:05 --> Helper loaded: url_helper
INFO - 2021-05-14 20:02:05 --> Helper loaded: form_helper
INFO - 2021-05-14 20:02:05 --> Helper loaded: common_helper
INFO - 2021-05-14 20:02:05 --> Database Driver Class Initialized
DEBUG - 2021-05-14 20:02:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 20:02:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 20:02:05 --> Controller Class Initialized
INFO - 2021-05-14 20:02:05 --> Form Validation Class Initialized
INFO - 2021-05-14 20:02:05 --> Model "Report_model" initialized
INFO - 2021-05-14 20:02:05 --> Model "Case_model" initialized
INFO - 2021-05-14 20:02:05 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-05-14 20:02:05 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\reports/patientwise_finacial_details.php
INFO - 2021-05-14 20:02:05 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-05-14 20:02:05 --> Final output sent to browser
DEBUG - 2021-05-14 20:02:05 --> Total execution time: 0.0458
ERROR - 2021-05-14 20:02:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 20:02:05 --> Config Class Initialized
INFO - 2021-05-14 20:02:05 --> Hooks Class Initialized
DEBUG - 2021-05-14 20:02:05 --> UTF-8 Support Enabled
INFO - 2021-05-14 20:02:05 --> Utf8 Class Initialized
INFO - 2021-05-14 20:02:05 --> URI Class Initialized
INFO - 2021-05-14 20:02:05 --> Router Class Initialized
INFO - 2021-05-14 20:02:05 --> Output Class Initialized
INFO - 2021-05-14 20:02:05 --> Security Class Initialized
DEBUG - 2021-05-14 20:02:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 20:02:05 --> Input Class Initialized
INFO - 2021-05-14 20:02:05 --> Language Class Initialized
ERROR - 2021-05-14 20:02:05 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-05-14 20:02:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 20:02:26 --> Config Class Initialized
INFO - 2021-05-14 20:02:26 --> Hooks Class Initialized
DEBUG - 2021-05-14 20:02:26 --> UTF-8 Support Enabled
INFO - 2021-05-14 20:02:26 --> Utf8 Class Initialized
INFO - 2021-05-14 20:02:26 --> URI Class Initialized
INFO - 2021-05-14 20:02:26 --> Router Class Initialized
INFO - 2021-05-14 20:02:26 --> Output Class Initialized
INFO - 2021-05-14 20:02:26 --> Security Class Initialized
DEBUG - 2021-05-14 20:02:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 20:02:26 --> Input Class Initialized
INFO - 2021-05-14 20:02:26 --> Language Class Initialized
INFO - 2021-05-14 20:02:26 --> Loader Class Initialized
INFO - 2021-05-14 20:02:26 --> Helper loaded: url_helper
INFO - 2021-05-14 20:02:26 --> Helper loaded: form_helper
INFO - 2021-05-14 20:02:26 --> Helper loaded: common_helper
INFO - 2021-05-14 20:02:26 --> Database Driver Class Initialized
DEBUG - 2021-05-14 20:02:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 20:02:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 20:02:26 --> Controller Class Initialized
INFO - 2021-05-14 20:02:26 --> Form Validation Class Initialized
INFO - 2021-05-14 20:02:26 --> Model "Report_model" initialized
INFO - 2021-05-14 20:02:26 --> Model "Case_model" initialized
INFO - 2021-05-14 20:02:26 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-05-14 20:02:26 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\reports/patientwise_finacial_details.php
INFO - 2021-05-14 20:02:26 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-05-14 20:02:26 --> Final output sent to browser
DEBUG - 2021-05-14 20:02:26 --> Total execution time: 0.1726
ERROR - 2021-05-14 20:02:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 20:02:26 --> Config Class Initialized
INFO - 2021-05-14 20:02:26 --> Hooks Class Initialized
DEBUG - 2021-05-14 20:02:26 --> UTF-8 Support Enabled
INFO - 2021-05-14 20:02:26 --> Utf8 Class Initialized
INFO - 2021-05-14 20:02:26 --> URI Class Initialized
INFO - 2021-05-14 20:02:26 --> Router Class Initialized
INFO - 2021-05-14 20:02:26 --> Output Class Initialized
INFO - 2021-05-14 20:02:26 --> Security Class Initialized
DEBUG - 2021-05-14 20:02:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 20:02:26 --> Input Class Initialized
INFO - 2021-05-14 20:02:26 --> Language Class Initialized
ERROR - 2021-05-14 20:02:26 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-05-14 20:02:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 20:02:38 --> Config Class Initialized
INFO - 2021-05-14 20:02:38 --> Hooks Class Initialized
DEBUG - 2021-05-14 20:02:38 --> UTF-8 Support Enabled
INFO - 2021-05-14 20:02:38 --> Utf8 Class Initialized
INFO - 2021-05-14 20:02:38 --> URI Class Initialized
INFO - 2021-05-14 20:02:38 --> Router Class Initialized
INFO - 2021-05-14 20:02:38 --> Output Class Initialized
INFO - 2021-05-14 20:02:38 --> Security Class Initialized
DEBUG - 2021-05-14 20:02:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 20:02:38 --> Input Class Initialized
INFO - 2021-05-14 20:02:38 --> Language Class Initialized
INFO - 2021-05-14 20:02:38 --> Loader Class Initialized
INFO - 2021-05-14 20:02:38 --> Helper loaded: url_helper
INFO - 2021-05-14 20:02:38 --> Helper loaded: form_helper
INFO - 2021-05-14 20:02:38 --> Helper loaded: common_helper
INFO - 2021-05-14 20:02:38 --> Database Driver Class Initialized
DEBUG - 2021-05-14 20:02:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 20:02:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 20:02:38 --> Controller Class Initialized
INFO - 2021-05-14 20:02:38 --> Form Validation Class Initialized
INFO - 2021-05-14 20:02:38 --> Model "Report_model" initialized
INFO - 2021-05-14 20:02:38 --> Model "Case_model" initialized
INFO - 2021-05-14 20:02:39 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-05-14 20:02:39 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\reports/patientwise_finacial_details.php
INFO - 2021-05-14 20:02:39 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-05-14 20:02:39 --> Final output sent to browser
DEBUG - 2021-05-14 20:02:39 --> Total execution time: 0.3371
ERROR - 2021-05-14 20:02:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 20:02:39 --> Config Class Initialized
INFO - 2021-05-14 20:02:39 --> Hooks Class Initialized
DEBUG - 2021-05-14 20:02:39 --> UTF-8 Support Enabled
INFO - 2021-05-14 20:02:39 --> Utf8 Class Initialized
INFO - 2021-05-14 20:02:39 --> URI Class Initialized
INFO - 2021-05-14 20:02:39 --> Router Class Initialized
INFO - 2021-05-14 20:02:39 --> Output Class Initialized
INFO - 2021-05-14 20:02:39 --> Security Class Initialized
DEBUG - 2021-05-14 20:02:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 20:02:39 --> Input Class Initialized
INFO - 2021-05-14 20:02:39 --> Language Class Initialized
ERROR - 2021-05-14 20:02:39 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-05-14 20:03:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 20:03:59 --> Config Class Initialized
INFO - 2021-05-14 20:03:59 --> Hooks Class Initialized
DEBUG - 2021-05-14 20:03:59 --> UTF-8 Support Enabled
INFO - 2021-05-14 20:03:59 --> Utf8 Class Initialized
INFO - 2021-05-14 20:03:59 --> URI Class Initialized
INFO - 2021-05-14 20:03:59 --> Router Class Initialized
INFO - 2021-05-14 20:03:59 --> Output Class Initialized
INFO - 2021-05-14 20:03:59 --> Security Class Initialized
DEBUG - 2021-05-14 20:03:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 20:03:59 --> Input Class Initialized
INFO - 2021-05-14 20:03:59 --> Language Class Initialized
INFO - 2021-05-14 20:03:59 --> Loader Class Initialized
INFO - 2021-05-14 20:03:59 --> Helper loaded: url_helper
INFO - 2021-05-14 20:03:59 --> Helper loaded: form_helper
INFO - 2021-05-14 20:03:59 --> Helper loaded: common_helper
INFO - 2021-05-14 20:03:59 --> Database Driver Class Initialized
DEBUG - 2021-05-14 20:03:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 20:03:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 20:03:59 --> Controller Class Initialized
INFO - 2021-05-14 20:03:59 --> Form Validation Class Initialized
INFO - 2021-05-14 20:03:59 --> Model "Report_model" initialized
INFO - 2021-05-14 20:03:59 --> Model "Case_model" initialized
INFO - 2021-05-14 20:04:00 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-05-14 20:04:00 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\reports/patientwise_finacial_details.php
INFO - 2021-05-14 20:04:00 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-05-14 20:04:00 --> Final output sent to browser
DEBUG - 2021-05-14 20:04:00 --> Total execution time: 0.1101
ERROR - 2021-05-14 20:04:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 20:04:00 --> Config Class Initialized
INFO - 2021-05-14 20:04:00 --> Hooks Class Initialized
DEBUG - 2021-05-14 20:04:00 --> UTF-8 Support Enabled
INFO - 2021-05-14 20:04:00 --> Utf8 Class Initialized
INFO - 2021-05-14 20:04:00 --> URI Class Initialized
INFO - 2021-05-14 20:04:00 --> Router Class Initialized
INFO - 2021-05-14 20:04:00 --> Output Class Initialized
INFO - 2021-05-14 20:04:00 --> Security Class Initialized
DEBUG - 2021-05-14 20:04:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 20:04:00 --> Input Class Initialized
INFO - 2021-05-14 20:04:00 --> Language Class Initialized
ERROR - 2021-05-14 20:04:00 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-05-14 20:04:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 20:04:11 --> Config Class Initialized
INFO - 2021-05-14 20:04:11 --> Hooks Class Initialized
DEBUG - 2021-05-14 20:04:11 --> UTF-8 Support Enabled
INFO - 2021-05-14 20:04:11 --> Utf8 Class Initialized
INFO - 2021-05-14 20:04:11 --> URI Class Initialized
INFO - 2021-05-14 20:04:11 --> Router Class Initialized
INFO - 2021-05-14 20:04:11 --> Output Class Initialized
INFO - 2021-05-14 20:04:11 --> Security Class Initialized
DEBUG - 2021-05-14 20:04:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 20:04:11 --> Input Class Initialized
INFO - 2021-05-14 20:04:11 --> Language Class Initialized
INFO - 2021-05-14 20:04:11 --> Loader Class Initialized
INFO - 2021-05-14 20:04:11 --> Helper loaded: url_helper
INFO - 2021-05-14 20:04:11 --> Helper loaded: form_helper
INFO - 2021-05-14 20:04:11 --> Helper loaded: common_helper
INFO - 2021-05-14 20:04:11 --> Database Driver Class Initialized
DEBUG - 2021-05-14 20:04:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 20:04:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 20:04:11 --> Controller Class Initialized
INFO - 2021-05-14 20:04:11 --> Form Validation Class Initialized
INFO - 2021-05-14 20:04:11 --> Model "Report_model" initialized
INFO - 2021-05-14 20:04:11 --> Model "Case_model" initialized
INFO - 2021-05-14 20:04:11 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-05-14 20:04:11 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\reports/donor_wise_patient_details.php
INFO - 2021-05-14 20:04:11 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-05-14 20:04:11 --> Final output sent to browser
DEBUG - 2021-05-14 20:04:11 --> Total execution time: 0.0468
ERROR - 2021-05-14 20:04:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 20:04:11 --> Config Class Initialized
INFO - 2021-05-14 20:04:11 --> Hooks Class Initialized
DEBUG - 2021-05-14 20:04:11 --> UTF-8 Support Enabled
INFO - 2021-05-14 20:04:11 --> Utf8 Class Initialized
INFO - 2021-05-14 20:04:11 --> URI Class Initialized
INFO - 2021-05-14 20:04:11 --> Router Class Initialized
INFO - 2021-05-14 20:04:11 --> Output Class Initialized
INFO - 2021-05-14 20:04:11 --> Security Class Initialized
DEBUG - 2021-05-14 20:04:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 20:04:11 --> Input Class Initialized
INFO - 2021-05-14 20:04:11 --> Language Class Initialized
ERROR - 2021-05-14 20:04:11 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-05-14 20:04:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 20:04:22 --> Config Class Initialized
INFO - 2021-05-14 20:04:22 --> Hooks Class Initialized
DEBUG - 2021-05-14 20:04:22 --> UTF-8 Support Enabled
INFO - 2021-05-14 20:04:22 --> Utf8 Class Initialized
INFO - 2021-05-14 20:04:22 --> URI Class Initialized
INFO - 2021-05-14 20:04:22 --> Router Class Initialized
INFO - 2021-05-14 20:04:22 --> Output Class Initialized
INFO - 2021-05-14 20:04:22 --> Security Class Initialized
DEBUG - 2021-05-14 20:04:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 20:04:22 --> Input Class Initialized
INFO - 2021-05-14 20:04:22 --> Language Class Initialized
INFO - 2021-05-14 20:04:22 --> Loader Class Initialized
INFO - 2021-05-14 20:04:22 --> Helper loaded: url_helper
INFO - 2021-05-14 20:04:22 --> Helper loaded: form_helper
INFO - 2021-05-14 20:04:22 --> Helper loaded: common_helper
INFO - 2021-05-14 20:04:22 --> Database Driver Class Initialized
DEBUG - 2021-05-14 20:04:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 20:04:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 20:04:22 --> Controller Class Initialized
INFO - 2021-05-14 20:04:22 --> Form Validation Class Initialized
INFO - 2021-05-14 20:04:22 --> Model "Report_model" initialized
INFO - 2021-05-14 20:04:22 --> Model "Case_model" initialized
INFO - 2021-05-14 20:04:28 --> Final output sent to browser
DEBUG - 2021-05-14 20:04:28 --> Total execution time: 6.3626
ERROR - 2021-05-14 20:04:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 20:04:33 --> Config Class Initialized
INFO - 2021-05-14 20:04:33 --> Hooks Class Initialized
DEBUG - 2021-05-14 20:04:33 --> UTF-8 Support Enabled
INFO - 2021-05-14 20:04:33 --> Utf8 Class Initialized
INFO - 2021-05-14 20:04:33 --> URI Class Initialized
INFO - 2021-05-14 20:04:33 --> Router Class Initialized
INFO - 2021-05-14 20:04:33 --> Output Class Initialized
INFO - 2021-05-14 20:04:33 --> Security Class Initialized
DEBUG - 2021-05-14 20:04:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 20:04:33 --> Input Class Initialized
INFO - 2021-05-14 20:04:33 --> Language Class Initialized
INFO - 2021-05-14 20:04:33 --> Loader Class Initialized
INFO - 2021-05-14 20:04:33 --> Helper loaded: url_helper
INFO - 2021-05-14 20:04:33 --> Helper loaded: form_helper
INFO - 2021-05-14 20:04:33 --> Helper loaded: common_helper
INFO - 2021-05-14 20:04:33 --> Database Driver Class Initialized
DEBUG - 2021-05-14 20:04:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 20:04:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 20:04:33 --> Controller Class Initialized
INFO - 2021-05-14 20:04:33 --> Form Validation Class Initialized
INFO - 2021-05-14 20:04:33 --> Model "Report_model" initialized
INFO - 2021-05-14 20:04:33 --> Model "Case_model" initialized
INFO - 2021-05-14 20:04:39 --> Final output sent to browser
DEBUG - 2021-05-14 20:04:39 --> Total execution time: 6.2819
ERROR - 2021-05-14 20:10:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 20:10:00 --> Config Class Initialized
INFO - 2021-05-14 20:10:00 --> Hooks Class Initialized
DEBUG - 2021-05-14 20:10:00 --> UTF-8 Support Enabled
INFO - 2021-05-14 20:10:00 --> Utf8 Class Initialized
INFO - 2021-05-14 20:10:00 --> URI Class Initialized
INFO - 2021-05-14 20:10:00 --> Router Class Initialized
INFO - 2021-05-14 20:10:00 --> Output Class Initialized
INFO - 2021-05-14 20:10:00 --> Security Class Initialized
DEBUG - 2021-05-14 20:10:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 20:10:00 --> Input Class Initialized
INFO - 2021-05-14 20:10:00 --> Language Class Initialized
INFO - 2021-05-14 20:10:00 --> Loader Class Initialized
INFO - 2021-05-14 20:10:00 --> Helper loaded: url_helper
INFO - 2021-05-14 20:10:00 --> Helper loaded: form_helper
INFO - 2021-05-14 20:10:00 --> Helper loaded: common_helper
INFO - 2021-05-14 20:10:00 --> Database Driver Class Initialized
DEBUG - 2021-05-14 20:10:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 20:10:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 20:10:00 --> Controller Class Initialized
INFO - 2021-05-14 20:10:00 --> Form Validation Class Initialized
INFO - 2021-05-14 20:10:00 --> Model "Report_model" initialized
INFO - 2021-05-14 20:10:00 --> Model "Case_model" initialized
INFO - 2021-05-14 20:10:00 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-05-14 20:10:00 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\reports/case_wise_patient_details.php
INFO - 2021-05-14 20:10:00 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-05-14 20:10:00 --> Final output sent to browser
DEBUG - 2021-05-14 20:10:00 --> Total execution time: 0.0633
ERROR - 2021-05-14 20:10:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 20:10:00 --> Config Class Initialized
INFO - 2021-05-14 20:10:00 --> Hooks Class Initialized
DEBUG - 2021-05-14 20:10:00 --> UTF-8 Support Enabled
INFO - 2021-05-14 20:10:00 --> Utf8 Class Initialized
INFO - 2021-05-14 20:10:00 --> URI Class Initialized
INFO - 2021-05-14 20:10:00 --> Router Class Initialized
INFO - 2021-05-14 20:10:00 --> Output Class Initialized
INFO - 2021-05-14 20:10:00 --> Security Class Initialized
DEBUG - 2021-05-14 20:10:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 20:10:00 --> Input Class Initialized
INFO - 2021-05-14 20:10:00 --> Language Class Initialized
ERROR - 2021-05-14 20:10:00 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-05-14 20:10:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 20:10:11 --> Config Class Initialized
INFO - 2021-05-14 20:10:11 --> Hooks Class Initialized
DEBUG - 2021-05-14 20:10:11 --> UTF-8 Support Enabled
INFO - 2021-05-14 20:10:11 --> Utf8 Class Initialized
INFO - 2021-05-14 20:10:11 --> URI Class Initialized
INFO - 2021-05-14 20:10:11 --> Router Class Initialized
INFO - 2021-05-14 20:10:11 --> Output Class Initialized
INFO - 2021-05-14 20:10:11 --> Security Class Initialized
DEBUG - 2021-05-14 20:10:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 20:10:11 --> Input Class Initialized
INFO - 2021-05-14 20:10:11 --> Language Class Initialized
INFO - 2021-05-14 20:10:11 --> Loader Class Initialized
INFO - 2021-05-14 20:10:11 --> Helper loaded: url_helper
INFO - 2021-05-14 20:10:11 --> Helper loaded: form_helper
INFO - 2021-05-14 20:10:11 --> Helper loaded: common_helper
INFO - 2021-05-14 20:10:11 --> Database Driver Class Initialized
DEBUG - 2021-05-14 20:10:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 20:10:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 20:10:11 --> Controller Class Initialized
INFO - 2021-05-14 20:10:11 --> Form Validation Class Initialized
INFO - 2021-05-14 20:10:11 --> Model "Report_model" initialized
INFO - 2021-05-14 20:10:11 --> Model "Case_model" initialized
ERROR - 2021-05-14 20:10:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 20:10:17 --> Config Class Initialized
INFO - 2021-05-14 20:10:17 --> Hooks Class Initialized
DEBUG - 2021-05-14 20:10:17 --> UTF-8 Support Enabled
INFO - 2021-05-14 20:10:17 --> Utf8 Class Initialized
INFO - 2021-05-14 20:10:17 --> URI Class Initialized
INFO - 2021-05-14 20:10:17 --> Router Class Initialized
INFO - 2021-05-14 20:10:17 --> Output Class Initialized
INFO - 2021-05-14 20:10:17 --> Security Class Initialized
DEBUG - 2021-05-14 20:10:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 20:10:17 --> Input Class Initialized
INFO - 2021-05-14 20:10:17 --> Language Class Initialized
INFO - 2021-05-14 20:10:17 --> Loader Class Initialized
INFO - 2021-05-14 20:10:17 --> Helper loaded: url_helper
INFO - 2021-05-14 20:10:17 --> Helper loaded: form_helper
INFO - 2021-05-14 20:10:17 --> Helper loaded: common_helper
INFO - 2021-05-14 20:10:17 --> Database Driver Class Initialized
DEBUG - 2021-05-14 20:10:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 20:10:18 --> Final output sent to browser
DEBUG - 2021-05-14 20:10:18 --> Total execution time: 6.6356
INFO - 2021-05-14 20:10:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 20:10:18 --> Controller Class Initialized
INFO - 2021-05-14 20:10:18 --> Form Validation Class Initialized
INFO - 2021-05-14 20:10:18 --> Model "Report_model" initialized
INFO - 2021-05-14 20:10:18 --> Model "Case_model" initialized
INFO - 2021-05-14 20:10:23 --> Final output sent to browser
DEBUG - 2021-05-14 20:10:23 --> Total execution time: 5.8308
ERROR - 2021-05-14 20:10:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 20:10:49 --> Config Class Initialized
INFO - 2021-05-14 20:10:49 --> Hooks Class Initialized
DEBUG - 2021-05-14 20:10:49 --> UTF-8 Support Enabled
INFO - 2021-05-14 20:10:49 --> Utf8 Class Initialized
INFO - 2021-05-14 20:10:49 --> URI Class Initialized
INFO - 2021-05-14 20:10:49 --> Router Class Initialized
INFO - 2021-05-14 20:10:49 --> Output Class Initialized
INFO - 2021-05-14 20:10:49 --> Security Class Initialized
DEBUG - 2021-05-14 20:10:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 20:10:49 --> Input Class Initialized
INFO - 2021-05-14 20:10:49 --> Language Class Initialized
INFO - 2021-05-14 20:10:49 --> Loader Class Initialized
INFO - 2021-05-14 20:10:49 --> Helper loaded: url_helper
INFO - 2021-05-14 20:10:49 --> Helper loaded: form_helper
INFO - 2021-05-14 20:10:49 --> Helper loaded: common_helper
INFO - 2021-05-14 20:10:49 --> Database Driver Class Initialized
DEBUG - 2021-05-14 20:10:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 20:10:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 20:10:49 --> Controller Class Initialized
INFO - 2021-05-14 20:10:49 --> Form Validation Class Initialized
INFO - 2021-05-14 20:10:49 --> Model "Report_model" initialized
INFO - 2021-05-14 20:10:49 --> Model "Case_model" initialized
INFO - 2021-05-14 20:10:49 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-05-14 20:10:49 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\reports/patient_details.php
INFO - 2021-05-14 20:10:49 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-05-14 20:10:49 --> Final output sent to browser
DEBUG - 2021-05-14 20:10:49 --> Total execution time: 0.0439
ERROR - 2021-05-14 20:10:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 20:10:49 --> Config Class Initialized
INFO - 2021-05-14 20:10:49 --> Hooks Class Initialized
DEBUG - 2021-05-14 20:10:49 --> UTF-8 Support Enabled
INFO - 2021-05-14 20:10:49 --> Utf8 Class Initialized
INFO - 2021-05-14 20:10:49 --> URI Class Initialized
INFO - 2021-05-14 20:10:49 --> Router Class Initialized
INFO - 2021-05-14 20:10:49 --> Output Class Initialized
INFO - 2021-05-14 20:10:49 --> Security Class Initialized
DEBUG - 2021-05-14 20:10:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 20:10:49 --> Input Class Initialized
INFO - 2021-05-14 20:10:49 --> Language Class Initialized
ERROR - 2021-05-14 20:10:49 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-05-14 20:10:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 20:10:55 --> Config Class Initialized
INFO - 2021-05-14 20:10:55 --> Hooks Class Initialized
DEBUG - 2021-05-14 20:10:55 --> UTF-8 Support Enabled
INFO - 2021-05-14 20:10:55 --> Utf8 Class Initialized
INFO - 2021-05-14 20:10:55 --> URI Class Initialized
INFO - 2021-05-14 20:10:55 --> Router Class Initialized
INFO - 2021-05-14 20:10:55 --> Output Class Initialized
INFO - 2021-05-14 20:10:55 --> Security Class Initialized
DEBUG - 2021-05-14 20:10:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 20:10:55 --> Input Class Initialized
INFO - 2021-05-14 20:10:55 --> Language Class Initialized
ERROR - 2021-05-14 20:10:55 --> 404 Page Not Found: Karoclient/css
ERROR - 2021-05-14 20:11:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 20:11:00 --> Config Class Initialized
INFO - 2021-05-14 20:11:00 --> Hooks Class Initialized
DEBUG - 2021-05-14 20:11:00 --> UTF-8 Support Enabled
INFO - 2021-05-14 20:11:00 --> Utf8 Class Initialized
INFO - 2021-05-14 20:11:00 --> URI Class Initialized
INFO - 2021-05-14 20:11:00 --> Router Class Initialized
INFO - 2021-05-14 20:11:00 --> Output Class Initialized
INFO - 2021-05-14 20:11:00 --> Security Class Initialized
DEBUG - 2021-05-14 20:11:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 20:11:00 --> Input Class Initialized
INFO - 2021-05-14 20:11:00 --> Language Class Initialized
INFO - 2021-05-14 20:11:00 --> Loader Class Initialized
INFO - 2021-05-14 20:11:00 --> Helper loaded: url_helper
INFO - 2021-05-14 20:11:00 --> Helper loaded: form_helper
INFO - 2021-05-14 20:11:00 --> Helper loaded: common_helper
INFO - 2021-05-14 20:11:00 --> Database Driver Class Initialized
DEBUG - 2021-05-14 20:11:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 20:11:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 20:11:00 --> Controller Class Initialized
INFO - 2021-05-14 20:11:00 --> Form Validation Class Initialized
INFO - 2021-05-14 20:11:00 --> Model "Report_model" initialized
INFO - 2021-05-14 20:11:00 --> Model "Case_model" initialized
ERROR - 2021-05-14 20:11:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 20:11:00 --> Config Class Initialized
INFO - 2021-05-14 20:11:00 --> Hooks Class Initialized
DEBUG - 2021-05-14 20:11:00 --> UTF-8 Support Enabled
INFO - 2021-05-14 20:11:00 --> Utf8 Class Initialized
INFO - 2021-05-14 20:11:00 --> URI Class Initialized
INFO - 2021-05-14 20:11:00 --> Router Class Initialized
INFO - 2021-05-14 20:11:00 --> Output Class Initialized
INFO - 2021-05-14 20:11:00 --> Security Class Initialized
DEBUG - 2021-05-14 20:11:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 20:11:00 --> Input Class Initialized
INFO - 2021-05-14 20:11:00 --> Language Class Initialized
INFO - 2021-05-14 20:11:00 --> Loader Class Initialized
INFO - 2021-05-14 20:11:00 --> Helper loaded: url_helper
INFO - 2021-05-14 20:11:00 --> Helper loaded: form_helper
INFO - 2021-05-14 20:11:00 --> Helper loaded: common_helper
INFO - 2021-05-14 20:11:00 --> Database Driver Class Initialized
DEBUG - 2021-05-14 20:11:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 20:11:01 --> Final output sent to browser
DEBUG - 2021-05-14 20:11:01 --> Total execution time: 0.9078
INFO - 2021-05-14 20:11:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 20:11:01 --> Controller Class Initialized
INFO - 2021-05-14 20:11:01 --> Form Validation Class Initialized
INFO - 2021-05-14 20:11:01 --> Model "Report_model" initialized
INFO - 2021-05-14 20:11:01 --> Model "Case_model" initialized
INFO - 2021-05-14 20:11:02 --> Final output sent to browser
DEBUG - 2021-05-14 20:11:02 --> Total execution time: 1.5649
ERROR - 2021-05-14 20:11:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 20:11:09 --> Config Class Initialized
INFO - 2021-05-14 20:11:09 --> Hooks Class Initialized
DEBUG - 2021-05-14 20:11:09 --> UTF-8 Support Enabled
INFO - 2021-05-14 20:11:09 --> Utf8 Class Initialized
INFO - 2021-05-14 20:11:09 --> URI Class Initialized
INFO - 2021-05-14 20:11:09 --> Router Class Initialized
INFO - 2021-05-14 20:11:09 --> Output Class Initialized
INFO - 2021-05-14 20:11:09 --> Security Class Initialized
DEBUG - 2021-05-14 20:11:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 20:11:09 --> Input Class Initialized
INFO - 2021-05-14 20:11:09 --> Language Class Initialized
INFO - 2021-05-14 20:11:09 --> Loader Class Initialized
INFO - 2021-05-14 20:11:09 --> Helper loaded: url_helper
INFO - 2021-05-14 20:11:09 --> Helper loaded: form_helper
INFO - 2021-05-14 20:11:09 --> Helper loaded: common_helper
INFO - 2021-05-14 20:11:09 --> Database Driver Class Initialized
DEBUG - 2021-05-14 20:11:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 20:11:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 20:11:09 --> Controller Class Initialized
INFO - 2021-05-14 20:11:09 --> Form Validation Class Initialized
INFO - 2021-05-14 20:11:09 --> Model "Report_model" initialized
INFO - 2021-05-14 20:11:09 --> Model "Case_model" initialized
INFO - 2021-05-14 20:11:09 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-05-14 20:11:09 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\reports/patient_donor_wise_details.php
INFO - 2021-05-14 20:11:09 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-05-14 20:11:09 --> Final output sent to browser
DEBUG - 2021-05-14 20:11:09 --> Total execution time: 0.0805
ERROR - 2021-05-14 20:11:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 20:11:09 --> Config Class Initialized
INFO - 2021-05-14 20:11:09 --> Hooks Class Initialized
DEBUG - 2021-05-14 20:11:09 --> UTF-8 Support Enabled
INFO - 2021-05-14 20:11:09 --> Utf8 Class Initialized
INFO - 2021-05-14 20:11:09 --> URI Class Initialized
INFO - 2021-05-14 20:11:09 --> Router Class Initialized
INFO - 2021-05-14 20:11:09 --> Output Class Initialized
INFO - 2021-05-14 20:11:09 --> Security Class Initialized
DEBUG - 2021-05-14 20:11:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 20:11:09 --> Input Class Initialized
INFO - 2021-05-14 20:11:09 --> Language Class Initialized
ERROR - 2021-05-14 20:11:09 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-05-14 20:11:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 20:11:14 --> Config Class Initialized
INFO - 2021-05-14 20:11:14 --> Hooks Class Initialized
DEBUG - 2021-05-14 20:11:14 --> UTF-8 Support Enabled
INFO - 2021-05-14 20:11:14 --> Utf8 Class Initialized
INFO - 2021-05-14 20:11:14 --> URI Class Initialized
INFO - 2021-05-14 20:11:14 --> Router Class Initialized
INFO - 2021-05-14 20:11:14 --> Output Class Initialized
INFO - 2021-05-14 20:11:14 --> Security Class Initialized
DEBUG - 2021-05-14 20:11:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 20:11:14 --> Input Class Initialized
INFO - 2021-05-14 20:11:14 --> Language Class Initialized
INFO - 2021-05-14 20:11:14 --> Loader Class Initialized
INFO - 2021-05-14 20:11:14 --> Helper loaded: url_helper
INFO - 2021-05-14 20:11:14 --> Helper loaded: form_helper
INFO - 2021-05-14 20:11:14 --> Helper loaded: common_helper
INFO - 2021-05-14 20:11:14 --> Database Driver Class Initialized
DEBUG - 2021-05-14 20:11:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 20:11:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 20:11:14 --> Controller Class Initialized
INFO - 2021-05-14 20:11:14 --> Form Validation Class Initialized
INFO - 2021-05-14 20:11:14 --> Model "Report_model" initialized
INFO - 2021-05-14 20:11:14 --> Model "Case_model" initialized
INFO - 2021-05-14 20:11:14 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-05-14 20:11:14 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\reports/delete_disbursal_detail.php
INFO - 2021-05-14 20:11:14 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-05-14 20:11:14 --> Final output sent to browser
DEBUG - 2021-05-14 20:11:14 --> Total execution time: 0.0618
ERROR - 2021-05-14 20:11:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 20:11:14 --> Config Class Initialized
INFO - 2021-05-14 20:11:14 --> Hooks Class Initialized
DEBUG - 2021-05-14 20:11:14 --> UTF-8 Support Enabled
INFO - 2021-05-14 20:11:14 --> Utf8 Class Initialized
INFO - 2021-05-14 20:11:14 --> URI Class Initialized
INFO - 2021-05-14 20:11:14 --> Router Class Initialized
INFO - 2021-05-14 20:11:14 --> Output Class Initialized
INFO - 2021-05-14 20:11:14 --> Security Class Initialized
DEBUG - 2021-05-14 20:11:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 20:11:14 --> Input Class Initialized
INFO - 2021-05-14 20:11:14 --> Language Class Initialized
ERROR - 2021-05-14 20:11:14 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-05-14 20:11:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 20:11:25 --> Config Class Initialized
INFO - 2021-05-14 20:11:25 --> Hooks Class Initialized
DEBUG - 2021-05-14 20:11:25 --> UTF-8 Support Enabled
INFO - 2021-05-14 20:11:25 --> Utf8 Class Initialized
INFO - 2021-05-14 20:11:25 --> URI Class Initialized
INFO - 2021-05-14 20:11:25 --> Router Class Initialized
INFO - 2021-05-14 20:11:25 --> Output Class Initialized
INFO - 2021-05-14 20:11:25 --> Security Class Initialized
DEBUG - 2021-05-14 20:11:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 20:11:25 --> Input Class Initialized
INFO - 2021-05-14 20:11:25 --> Language Class Initialized
INFO - 2021-05-14 20:11:25 --> Loader Class Initialized
INFO - 2021-05-14 20:11:25 --> Helper loaded: url_helper
INFO - 2021-05-14 20:11:25 --> Helper loaded: form_helper
INFO - 2021-05-14 20:11:25 --> Helper loaded: common_helper
INFO - 2021-05-14 20:11:25 --> Database Driver Class Initialized
DEBUG - 2021-05-14 20:11:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 20:11:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 20:11:25 --> Controller Class Initialized
INFO - 2021-05-14 20:11:25 --> Form Validation Class Initialized
INFO - 2021-05-14 20:11:25 --> Model "Report_model" initialized
INFO - 2021-05-14 20:11:25 --> Model "Case_model" initialized
INFO - 2021-05-14 20:11:25 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-05-14 20:11:25 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\reports/delete_disbursal_detail.php
INFO - 2021-05-14 20:11:25 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-05-14 20:11:25 --> Final output sent to browser
DEBUG - 2021-05-14 20:11:25 --> Total execution time: 0.0782
ERROR - 2021-05-14 20:11:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 20:11:25 --> Config Class Initialized
INFO - 2021-05-14 20:11:25 --> Hooks Class Initialized
DEBUG - 2021-05-14 20:11:25 --> UTF-8 Support Enabled
INFO - 2021-05-14 20:11:25 --> Utf8 Class Initialized
INFO - 2021-05-14 20:11:25 --> URI Class Initialized
INFO - 2021-05-14 20:11:25 --> Router Class Initialized
INFO - 2021-05-14 20:11:25 --> Output Class Initialized
INFO - 2021-05-14 20:11:25 --> Security Class Initialized
DEBUG - 2021-05-14 20:11:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 20:11:25 --> Input Class Initialized
INFO - 2021-05-14 20:11:25 --> Language Class Initialized
ERROR - 2021-05-14 20:11:25 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-05-14 20:12:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 20:12:41 --> Config Class Initialized
INFO - 2021-05-14 20:12:41 --> Hooks Class Initialized
DEBUG - 2021-05-14 20:12:41 --> UTF-8 Support Enabled
INFO - 2021-05-14 20:12:41 --> Utf8 Class Initialized
INFO - 2021-05-14 20:12:41 --> URI Class Initialized
INFO - 2021-05-14 20:12:41 --> Router Class Initialized
INFO - 2021-05-14 20:12:41 --> Output Class Initialized
INFO - 2021-05-14 20:12:41 --> Security Class Initialized
DEBUG - 2021-05-14 20:12:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 20:12:41 --> Input Class Initialized
INFO - 2021-05-14 20:12:41 --> Language Class Initialized
INFO - 2021-05-14 20:12:41 --> Loader Class Initialized
INFO - 2021-05-14 20:12:41 --> Helper loaded: url_helper
INFO - 2021-05-14 20:12:41 --> Helper loaded: form_helper
INFO - 2021-05-14 20:12:41 --> Helper loaded: common_helper
INFO - 2021-05-14 20:12:41 --> Database Driver Class Initialized
DEBUG - 2021-05-14 20:12:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 20:12:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 20:12:41 --> Controller Class Initialized
INFO - 2021-05-14 20:12:41 --> Form Validation Class Initialized
INFO - 2021-05-14 20:12:41 --> Model "Report_model" initialized
INFO - 2021-05-14 20:12:41 --> Model "Case_model" initialized
INFO - 2021-05-14 20:12:41 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-05-14 20:12:41 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\reports/delete_disbursal_detail.php
INFO - 2021-05-14 20:12:41 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-05-14 20:12:41 --> Final output sent to browser
DEBUG - 2021-05-14 20:12:41 --> Total execution time: 0.0778
ERROR - 2021-05-14 20:12:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 20:12:41 --> Config Class Initialized
INFO - 2021-05-14 20:12:41 --> Hooks Class Initialized
DEBUG - 2021-05-14 20:12:41 --> UTF-8 Support Enabled
INFO - 2021-05-14 20:12:41 --> Utf8 Class Initialized
INFO - 2021-05-14 20:12:41 --> URI Class Initialized
INFO - 2021-05-14 20:12:41 --> Router Class Initialized
INFO - 2021-05-14 20:12:41 --> Output Class Initialized
INFO - 2021-05-14 20:12:41 --> Security Class Initialized
DEBUG - 2021-05-14 20:12:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 20:12:41 --> Input Class Initialized
INFO - 2021-05-14 20:12:41 --> Language Class Initialized
ERROR - 2021-05-14 20:12:41 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-05-14 20:13:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 20:13:11 --> Config Class Initialized
INFO - 2021-05-14 20:13:11 --> Hooks Class Initialized
DEBUG - 2021-05-14 20:13:11 --> UTF-8 Support Enabled
INFO - 2021-05-14 20:13:11 --> Utf8 Class Initialized
INFO - 2021-05-14 20:13:11 --> URI Class Initialized
INFO - 2021-05-14 20:13:11 --> Router Class Initialized
INFO - 2021-05-14 20:13:11 --> Output Class Initialized
INFO - 2021-05-14 20:13:11 --> Security Class Initialized
DEBUG - 2021-05-14 20:13:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 20:13:11 --> Input Class Initialized
INFO - 2021-05-14 20:13:11 --> Language Class Initialized
INFO - 2021-05-14 20:13:11 --> Loader Class Initialized
INFO - 2021-05-14 20:13:11 --> Helper loaded: url_helper
INFO - 2021-05-14 20:13:11 --> Helper loaded: form_helper
INFO - 2021-05-14 20:13:11 --> Helper loaded: common_helper
INFO - 2021-05-14 20:13:11 --> Database Driver Class Initialized
DEBUG - 2021-05-14 20:13:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 20:13:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 20:13:11 --> Controller Class Initialized
INFO - 2021-05-14 20:13:11 --> Form Validation Class Initialized
INFO - 2021-05-14 20:13:11 --> Model "Report_model" initialized
INFO - 2021-05-14 20:13:11 --> Model "Case_model" initialized
INFO - 2021-05-14 20:13:11 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-05-14 20:13:11 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\reports/delete_disbursal_detail.php
INFO - 2021-05-14 20:13:11 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-05-14 20:13:11 --> Final output sent to browser
DEBUG - 2021-05-14 20:13:11 --> Total execution time: 0.0510
ERROR - 2021-05-14 20:13:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 20:13:16 --> Config Class Initialized
INFO - 2021-05-14 20:13:16 --> Hooks Class Initialized
DEBUG - 2021-05-14 20:13:16 --> UTF-8 Support Enabled
INFO - 2021-05-14 20:13:16 --> Utf8 Class Initialized
INFO - 2021-05-14 20:13:16 --> URI Class Initialized
INFO - 2021-05-14 20:13:16 --> Router Class Initialized
INFO - 2021-05-14 20:13:16 --> Output Class Initialized
INFO - 2021-05-14 20:13:16 --> Security Class Initialized
DEBUG - 2021-05-14 20:13:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 20:13:16 --> Input Class Initialized
INFO - 2021-05-14 20:13:16 --> Language Class Initialized
INFO - 2021-05-14 20:13:16 --> Loader Class Initialized
INFO - 2021-05-14 20:13:16 --> Helper loaded: url_helper
INFO - 2021-05-14 20:13:16 --> Helper loaded: form_helper
INFO - 2021-05-14 20:13:16 --> Helper loaded: common_helper
INFO - 2021-05-14 20:13:16 --> Database Driver Class Initialized
DEBUG - 2021-05-14 20:13:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 20:13:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 20:13:16 --> Controller Class Initialized
INFO - 2021-05-14 20:13:16 --> Form Validation Class Initialized
INFO - 2021-05-14 20:13:16 --> Model "Report_model" initialized
INFO - 2021-05-14 20:13:16 --> Model "Case_model" initialized
INFO - 2021-05-14 20:13:16 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-05-14 20:13:16 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\reports/patient_details.php
INFO - 2021-05-14 20:13:16 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-05-14 20:13:16 --> Final output sent to browser
DEBUG - 2021-05-14 20:13:16 --> Total execution time: 0.0549
ERROR - 2021-05-14 20:13:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 20:13:16 --> Config Class Initialized
INFO - 2021-05-14 20:13:16 --> Hooks Class Initialized
DEBUG - 2021-05-14 20:13:16 --> UTF-8 Support Enabled
INFO - 2021-05-14 20:13:16 --> Utf8 Class Initialized
INFO - 2021-05-14 20:13:16 --> URI Class Initialized
INFO - 2021-05-14 20:13:16 --> Router Class Initialized
INFO - 2021-05-14 20:13:16 --> Output Class Initialized
INFO - 2021-05-14 20:13:16 --> Security Class Initialized
DEBUG - 2021-05-14 20:13:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 20:13:16 --> Input Class Initialized
INFO - 2021-05-14 20:13:16 --> Language Class Initialized
ERROR - 2021-05-14 20:13:16 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-05-14 20:13:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 20:13:25 --> Config Class Initialized
INFO - 2021-05-14 20:13:25 --> Hooks Class Initialized
DEBUG - 2021-05-14 20:13:25 --> UTF-8 Support Enabled
INFO - 2021-05-14 20:13:25 --> Utf8 Class Initialized
INFO - 2021-05-14 20:13:25 --> URI Class Initialized
INFO - 2021-05-14 20:13:25 --> Router Class Initialized
INFO - 2021-05-14 20:13:25 --> Output Class Initialized
INFO - 2021-05-14 20:13:25 --> Security Class Initialized
DEBUG - 2021-05-14 20:13:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 20:13:25 --> Input Class Initialized
INFO - 2021-05-14 20:13:25 --> Language Class Initialized
ERROR - 2021-05-14 20:13:25 --> 404 Page Not Found: Karoclient/css
ERROR - 2021-05-14 20:13:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 20:13:27 --> Config Class Initialized
INFO - 2021-05-14 20:13:27 --> Hooks Class Initialized
DEBUG - 2021-05-14 20:13:27 --> UTF-8 Support Enabled
INFO - 2021-05-14 20:13:27 --> Utf8 Class Initialized
INFO - 2021-05-14 20:13:27 --> URI Class Initialized
INFO - 2021-05-14 20:13:27 --> Router Class Initialized
INFO - 2021-05-14 20:13:27 --> Output Class Initialized
INFO - 2021-05-14 20:13:27 --> Security Class Initialized
DEBUG - 2021-05-14 20:13:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 20:13:27 --> Input Class Initialized
INFO - 2021-05-14 20:13:27 --> Language Class Initialized
INFO - 2021-05-14 20:13:27 --> Loader Class Initialized
INFO - 2021-05-14 20:13:27 --> Helper loaded: url_helper
INFO - 2021-05-14 20:13:27 --> Helper loaded: form_helper
INFO - 2021-05-14 20:13:27 --> Helper loaded: common_helper
INFO - 2021-05-14 20:13:27 --> Database Driver Class Initialized
DEBUG - 2021-05-14 20:13:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 20:13:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 20:13:27 --> Controller Class Initialized
INFO - 2021-05-14 20:13:27 --> Form Validation Class Initialized
INFO - 2021-05-14 20:13:27 --> Model "Report_model" initialized
INFO - 2021-05-14 20:13:27 --> Model "Case_model" initialized
INFO - 2021-05-14 20:13:28 --> Final output sent to browser
DEBUG - 2021-05-14 20:13:28 --> Total execution time: 0.6281
ERROR - 2021-05-14 20:26:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 20:26:39 --> Config Class Initialized
INFO - 2021-05-14 20:26:39 --> Hooks Class Initialized
DEBUG - 2021-05-14 20:26:39 --> UTF-8 Support Enabled
INFO - 2021-05-14 20:26:39 --> Utf8 Class Initialized
INFO - 2021-05-14 20:26:39 --> URI Class Initialized
INFO - 2021-05-14 20:26:39 --> Router Class Initialized
INFO - 2021-05-14 20:26:39 --> Output Class Initialized
INFO - 2021-05-14 20:26:39 --> Security Class Initialized
DEBUG - 2021-05-14 20:26:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 20:26:39 --> Input Class Initialized
INFO - 2021-05-14 20:26:39 --> Language Class Initialized
INFO - 2021-05-14 20:26:39 --> Loader Class Initialized
INFO - 2021-05-14 20:26:39 --> Helper loaded: url_helper
INFO - 2021-05-14 20:26:39 --> Helper loaded: form_helper
INFO - 2021-05-14 20:26:39 --> Helper loaded: common_helper
INFO - 2021-05-14 20:26:39 --> Database Driver Class Initialized
DEBUG - 2021-05-14 20:26:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 20:26:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 20:26:39 --> Controller Class Initialized
INFO - 2021-05-14 20:26:39 --> Form Validation Class Initialized
INFO - 2021-05-14 20:26:40 --> Model "Report_model" initialized
INFO - 2021-05-14 20:26:40 --> Model "Case_model" initialized
INFO - 2021-05-14 20:26:40 --> Final output sent to browser
DEBUG - 2021-05-14 20:26:40 --> Total execution time: 0.6081
ERROR - 2021-05-14 20:26:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 20:26:47 --> Config Class Initialized
INFO - 2021-05-14 20:26:47 --> Hooks Class Initialized
DEBUG - 2021-05-14 20:26:47 --> UTF-8 Support Enabled
INFO - 2021-05-14 20:26:47 --> Utf8 Class Initialized
INFO - 2021-05-14 20:26:47 --> URI Class Initialized
INFO - 2021-05-14 20:26:47 --> Router Class Initialized
INFO - 2021-05-14 20:26:47 --> Output Class Initialized
INFO - 2021-05-14 20:26:47 --> Security Class Initialized
DEBUG - 2021-05-14 20:26:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 20:26:47 --> Input Class Initialized
INFO - 2021-05-14 20:26:47 --> Language Class Initialized
INFO - 2021-05-14 20:26:47 --> Loader Class Initialized
INFO - 2021-05-14 20:26:47 --> Helper loaded: url_helper
INFO - 2021-05-14 20:26:47 --> Helper loaded: form_helper
INFO - 2021-05-14 20:26:47 --> Helper loaded: common_helper
INFO - 2021-05-14 20:26:47 --> Database Driver Class Initialized
DEBUG - 2021-05-14 20:26:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 20:26:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 20:26:47 --> Controller Class Initialized
INFO - 2021-05-14 20:26:47 --> Form Validation Class Initialized
INFO - 2021-05-14 20:26:47 --> Model "Report_model" initialized
INFO - 2021-05-14 20:26:47 --> Model "Case_model" initialized
INFO - 2021-05-14 20:26:47 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-05-14 20:26:47 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\reports/patient_details.php
INFO - 2021-05-14 20:26:47 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-05-14 20:26:47 --> Final output sent to browser
DEBUG - 2021-05-14 20:26:47 --> Total execution time: 0.0545
ERROR - 2021-05-14 20:26:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 20:26:47 --> Config Class Initialized
INFO - 2021-05-14 20:26:47 --> Hooks Class Initialized
DEBUG - 2021-05-14 20:26:47 --> UTF-8 Support Enabled
INFO - 2021-05-14 20:26:47 --> Utf8 Class Initialized
INFO - 2021-05-14 20:26:47 --> URI Class Initialized
INFO - 2021-05-14 20:26:47 --> Router Class Initialized
INFO - 2021-05-14 20:26:47 --> Output Class Initialized
INFO - 2021-05-14 20:26:47 --> Security Class Initialized
DEBUG - 2021-05-14 20:26:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 20:26:47 --> Input Class Initialized
INFO - 2021-05-14 20:26:47 --> Language Class Initialized
ERROR - 2021-05-14 20:26:47 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-05-14 20:26:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 20:26:57 --> Config Class Initialized
INFO - 2021-05-14 20:26:57 --> Hooks Class Initialized
DEBUG - 2021-05-14 20:26:57 --> UTF-8 Support Enabled
INFO - 2021-05-14 20:26:57 --> Utf8 Class Initialized
INFO - 2021-05-14 20:26:57 --> URI Class Initialized
INFO - 2021-05-14 20:26:57 --> Router Class Initialized
INFO - 2021-05-14 20:26:57 --> Output Class Initialized
INFO - 2021-05-14 20:26:57 --> Security Class Initialized
DEBUG - 2021-05-14 20:26:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 20:26:57 --> Input Class Initialized
INFO - 2021-05-14 20:26:57 --> Language Class Initialized
INFO - 2021-05-14 20:26:57 --> Loader Class Initialized
INFO - 2021-05-14 20:26:57 --> Helper loaded: url_helper
INFO - 2021-05-14 20:26:57 --> Helper loaded: form_helper
INFO - 2021-05-14 20:26:57 --> Helper loaded: common_helper
INFO - 2021-05-14 20:26:57 --> Database Driver Class Initialized
DEBUG - 2021-05-14 20:26:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 20:26:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 20:26:57 --> Controller Class Initialized
INFO - 2021-05-14 20:26:57 --> Form Validation Class Initialized
INFO - 2021-05-14 20:26:57 --> Model "Report_model" initialized
INFO - 2021-05-14 20:26:57 --> Model "Case_model" initialized
INFO - 2021-05-14 20:26:57 --> Final output sent to browser
DEBUG - 2021-05-14 20:26:57 --> Total execution time: 0.6984
ERROR - 2021-05-14 20:27:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 20:27:05 --> Config Class Initialized
INFO - 2021-05-14 20:27:05 --> Hooks Class Initialized
DEBUG - 2021-05-14 20:27:05 --> UTF-8 Support Enabled
INFO - 2021-05-14 20:27:05 --> Utf8 Class Initialized
INFO - 2021-05-14 20:27:05 --> URI Class Initialized
INFO - 2021-05-14 20:27:05 --> Router Class Initialized
INFO - 2021-05-14 20:27:05 --> Output Class Initialized
INFO - 2021-05-14 20:27:05 --> Security Class Initialized
DEBUG - 2021-05-14 20:27:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 20:27:05 --> Input Class Initialized
INFO - 2021-05-14 20:27:05 --> Language Class Initialized
INFO - 2021-05-14 20:27:05 --> Loader Class Initialized
INFO - 2021-05-14 20:27:05 --> Helper loaded: url_helper
INFO - 2021-05-14 20:27:05 --> Helper loaded: form_helper
INFO - 2021-05-14 20:27:05 --> Helper loaded: common_helper
INFO - 2021-05-14 20:27:05 --> Database Driver Class Initialized
DEBUG - 2021-05-14 20:27:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 20:27:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 20:27:05 --> Controller Class Initialized
INFO - 2021-05-14 20:27:05 --> Form Validation Class Initialized
INFO - 2021-05-14 20:27:05 --> Model "Report_model" initialized
INFO - 2021-05-14 20:27:05 --> Model "Case_model" initialized
INFO - 2021-05-14 20:27:06 --> Final output sent to browser
DEBUG - 2021-05-14 20:27:06 --> Total execution time: 0.6758
ERROR - 2021-05-14 20:27:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 20:27:54 --> Config Class Initialized
INFO - 2021-05-14 20:27:54 --> Hooks Class Initialized
DEBUG - 2021-05-14 20:27:54 --> UTF-8 Support Enabled
INFO - 2021-05-14 20:27:54 --> Utf8 Class Initialized
INFO - 2021-05-14 20:27:54 --> URI Class Initialized
INFO - 2021-05-14 20:27:54 --> Router Class Initialized
INFO - 2021-05-14 20:27:54 --> Output Class Initialized
INFO - 2021-05-14 20:27:54 --> Security Class Initialized
DEBUG - 2021-05-14 20:27:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 20:27:54 --> Input Class Initialized
INFO - 2021-05-14 20:27:54 --> Language Class Initialized
INFO - 2021-05-14 20:27:54 --> Loader Class Initialized
INFO - 2021-05-14 20:27:54 --> Helper loaded: url_helper
INFO - 2021-05-14 20:27:54 --> Helper loaded: form_helper
INFO - 2021-05-14 20:27:54 --> Helper loaded: common_helper
INFO - 2021-05-14 20:27:54 --> Database Driver Class Initialized
DEBUG - 2021-05-14 20:27:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 20:27:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 20:27:54 --> Controller Class Initialized
INFO - 2021-05-14 20:27:54 --> Form Validation Class Initialized
INFO - 2021-05-14 20:27:54 --> Model "Report_model" initialized
INFO - 2021-05-14 20:27:54 --> Model "Case_model" initialized
INFO - 2021-05-14 20:27:54 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-05-14 20:27:54 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\reports/patient_details.php
INFO - 2021-05-14 20:27:54 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-05-14 20:27:54 --> Final output sent to browser
DEBUG - 2021-05-14 20:27:54 --> Total execution time: 0.0558
ERROR - 2021-05-14 20:27:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 20:27:54 --> Config Class Initialized
INFO - 2021-05-14 20:27:54 --> Hooks Class Initialized
DEBUG - 2021-05-14 20:27:54 --> UTF-8 Support Enabled
INFO - 2021-05-14 20:27:54 --> Utf8 Class Initialized
INFO - 2021-05-14 20:27:54 --> URI Class Initialized
INFO - 2021-05-14 20:27:54 --> Router Class Initialized
INFO - 2021-05-14 20:27:54 --> Output Class Initialized
INFO - 2021-05-14 20:27:54 --> Security Class Initialized
DEBUG - 2021-05-14 20:27:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 20:27:54 --> Input Class Initialized
INFO - 2021-05-14 20:27:54 --> Language Class Initialized
ERROR - 2021-05-14 20:27:54 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-05-14 20:28:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 20:28:10 --> Config Class Initialized
INFO - 2021-05-14 20:28:10 --> Hooks Class Initialized
DEBUG - 2021-05-14 20:28:10 --> UTF-8 Support Enabled
INFO - 2021-05-14 20:28:10 --> Utf8 Class Initialized
INFO - 2021-05-14 20:28:10 --> URI Class Initialized
INFO - 2021-05-14 20:28:10 --> Router Class Initialized
INFO - 2021-05-14 20:28:10 --> Output Class Initialized
INFO - 2021-05-14 20:28:10 --> Security Class Initialized
DEBUG - 2021-05-14 20:28:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 20:28:10 --> Input Class Initialized
INFO - 2021-05-14 20:28:10 --> Language Class Initialized
INFO - 2021-05-14 20:28:10 --> Loader Class Initialized
INFO - 2021-05-14 20:28:10 --> Helper loaded: url_helper
INFO - 2021-05-14 20:28:10 --> Helper loaded: form_helper
INFO - 2021-05-14 20:28:10 --> Helper loaded: common_helper
INFO - 2021-05-14 20:28:10 --> Database Driver Class Initialized
DEBUG - 2021-05-14 20:28:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 20:28:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 20:28:10 --> Controller Class Initialized
INFO - 2021-05-14 20:28:10 --> Form Validation Class Initialized
INFO - 2021-05-14 20:28:10 --> Model "Report_model" initialized
INFO - 2021-05-14 20:28:10 --> Model "Case_model" initialized
INFO - 2021-05-14 20:28:11 --> Final output sent to browser
DEBUG - 2021-05-14 20:28:11 --> Total execution time: 0.7606
ERROR - 2021-05-14 20:28:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 20:28:56 --> Config Class Initialized
INFO - 2021-05-14 20:28:56 --> Hooks Class Initialized
DEBUG - 2021-05-14 20:28:56 --> UTF-8 Support Enabled
INFO - 2021-05-14 20:28:56 --> Utf8 Class Initialized
INFO - 2021-05-14 20:28:56 --> URI Class Initialized
INFO - 2021-05-14 20:28:56 --> Router Class Initialized
INFO - 2021-05-14 20:28:56 --> Output Class Initialized
INFO - 2021-05-14 20:28:56 --> Security Class Initialized
DEBUG - 2021-05-14 20:28:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 20:28:56 --> Input Class Initialized
INFO - 2021-05-14 20:28:56 --> Language Class Initialized
INFO - 2021-05-14 20:28:56 --> Loader Class Initialized
INFO - 2021-05-14 20:28:56 --> Helper loaded: url_helper
INFO - 2021-05-14 20:28:56 --> Helper loaded: form_helper
INFO - 2021-05-14 20:28:56 --> Helper loaded: common_helper
INFO - 2021-05-14 20:28:56 --> Database Driver Class Initialized
DEBUG - 2021-05-14 20:28:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 20:28:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 20:28:56 --> Controller Class Initialized
INFO - 2021-05-14 20:28:56 --> Form Validation Class Initialized
INFO - 2021-05-14 20:28:56 --> Model "Report_model" initialized
INFO - 2021-05-14 20:28:56 --> Model "Case_model" initialized
INFO - 2021-05-14 20:28:56 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-05-14 20:28:56 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\reports/patient_details.php
INFO - 2021-05-14 20:28:56 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-05-14 20:28:56 --> Final output sent to browser
DEBUG - 2021-05-14 20:28:56 --> Total execution time: 0.0606
ERROR - 2021-05-14 20:28:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 20:28:56 --> Config Class Initialized
INFO - 2021-05-14 20:28:56 --> Hooks Class Initialized
DEBUG - 2021-05-14 20:28:56 --> UTF-8 Support Enabled
INFO - 2021-05-14 20:28:56 --> Utf8 Class Initialized
INFO - 2021-05-14 20:28:56 --> URI Class Initialized
INFO - 2021-05-14 20:28:56 --> Router Class Initialized
INFO - 2021-05-14 20:28:56 --> Output Class Initialized
INFO - 2021-05-14 20:28:56 --> Security Class Initialized
DEBUG - 2021-05-14 20:28:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 20:28:56 --> Input Class Initialized
INFO - 2021-05-14 20:28:56 --> Language Class Initialized
ERROR - 2021-05-14 20:28:56 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-05-14 20:29:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 20:29:12 --> Config Class Initialized
INFO - 2021-05-14 20:29:12 --> Hooks Class Initialized
DEBUG - 2021-05-14 20:29:12 --> UTF-8 Support Enabled
INFO - 2021-05-14 20:29:12 --> Utf8 Class Initialized
INFO - 2021-05-14 20:29:12 --> URI Class Initialized
INFO - 2021-05-14 20:29:12 --> Router Class Initialized
INFO - 2021-05-14 20:29:12 --> Output Class Initialized
INFO - 2021-05-14 20:29:12 --> Security Class Initialized
DEBUG - 2021-05-14 20:29:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 20:29:12 --> Input Class Initialized
INFO - 2021-05-14 20:29:12 --> Language Class Initialized
INFO - 2021-05-14 20:29:12 --> Loader Class Initialized
INFO - 2021-05-14 20:29:12 --> Helper loaded: url_helper
INFO - 2021-05-14 20:29:12 --> Helper loaded: form_helper
INFO - 2021-05-14 20:29:12 --> Helper loaded: common_helper
INFO - 2021-05-14 20:29:12 --> Database Driver Class Initialized
DEBUG - 2021-05-14 20:29:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 20:29:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 20:29:13 --> Controller Class Initialized
INFO - 2021-05-14 20:29:13 --> Form Validation Class Initialized
INFO - 2021-05-14 20:29:13 --> Model "Report_model" initialized
INFO - 2021-05-14 20:29:13 --> Model "Case_model" initialized
INFO - 2021-05-14 20:29:13 --> Final output sent to browser
DEBUG - 2021-05-14 20:29:13 --> Total execution time: 0.7204
ERROR - 2021-05-14 20:32:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 20:32:39 --> Config Class Initialized
INFO - 2021-05-14 20:32:39 --> Hooks Class Initialized
DEBUG - 2021-05-14 20:32:39 --> UTF-8 Support Enabled
INFO - 2021-05-14 20:32:39 --> Utf8 Class Initialized
INFO - 2021-05-14 20:32:39 --> URI Class Initialized
INFO - 2021-05-14 20:32:39 --> Router Class Initialized
INFO - 2021-05-14 20:32:39 --> Output Class Initialized
INFO - 2021-05-14 20:32:39 --> Security Class Initialized
DEBUG - 2021-05-14 20:32:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 20:32:39 --> Input Class Initialized
INFO - 2021-05-14 20:32:39 --> Language Class Initialized
INFO - 2021-05-14 20:32:39 --> Loader Class Initialized
INFO - 2021-05-14 20:32:39 --> Helper loaded: url_helper
INFO - 2021-05-14 20:32:39 --> Helper loaded: form_helper
INFO - 2021-05-14 20:32:39 --> Helper loaded: common_helper
INFO - 2021-05-14 20:32:39 --> Database Driver Class Initialized
DEBUG - 2021-05-14 20:32:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 20:32:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 20:32:39 --> Controller Class Initialized
INFO - 2021-05-14 20:32:39 --> Form Validation Class Initialized
INFO - 2021-05-14 20:32:39 --> Model "Report_model" initialized
INFO - 2021-05-14 20:32:39 --> Model "Case_model" initialized
INFO - 2021-05-14 20:32:39 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-05-14 20:32:39 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\reports/patient_details.php
INFO - 2021-05-14 20:32:39 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-05-14 20:32:39 --> Final output sent to browser
DEBUG - 2021-05-14 20:32:39 --> Total execution time: 0.0463
ERROR - 2021-05-14 20:32:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 20:32:39 --> Config Class Initialized
INFO - 2021-05-14 20:32:39 --> Hooks Class Initialized
DEBUG - 2021-05-14 20:32:39 --> UTF-8 Support Enabled
INFO - 2021-05-14 20:32:39 --> Utf8 Class Initialized
INFO - 2021-05-14 20:32:39 --> URI Class Initialized
INFO - 2021-05-14 20:32:39 --> Router Class Initialized
INFO - 2021-05-14 20:32:39 --> Output Class Initialized
INFO - 2021-05-14 20:32:39 --> Security Class Initialized
DEBUG - 2021-05-14 20:32:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 20:32:39 --> Input Class Initialized
INFO - 2021-05-14 20:32:39 --> Language Class Initialized
ERROR - 2021-05-14 20:32:39 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-05-14 20:33:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 20:33:49 --> Config Class Initialized
INFO - 2021-05-14 20:33:49 --> Hooks Class Initialized
DEBUG - 2021-05-14 20:33:49 --> UTF-8 Support Enabled
INFO - 2021-05-14 20:33:49 --> Utf8 Class Initialized
INFO - 2021-05-14 20:33:49 --> URI Class Initialized
INFO - 2021-05-14 20:33:49 --> Router Class Initialized
INFO - 2021-05-14 20:33:49 --> Output Class Initialized
INFO - 2021-05-14 20:33:49 --> Security Class Initialized
DEBUG - 2021-05-14 20:33:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 20:33:49 --> Input Class Initialized
INFO - 2021-05-14 20:33:49 --> Language Class Initialized
INFO - 2021-05-14 20:33:49 --> Loader Class Initialized
INFO - 2021-05-14 20:33:49 --> Helper loaded: url_helper
INFO - 2021-05-14 20:33:49 --> Helper loaded: form_helper
INFO - 2021-05-14 20:33:49 --> Helper loaded: common_helper
INFO - 2021-05-14 20:33:50 --> Database Driver Class Initialized
DEBUG - 2021-05-14 20:33:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 20:33:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 20:33:50 --> Controller Class Initialized
INFO - 2021-05-14 20:33:50 --> Form Validation Class Initialized
INFO - 2021-05-14 20:33:50 --> Model "Report_model" initialized
INFO - 2021-05-14 20:33:50 --> Model "Case_model" initialized
INFO - 2021-05-14 20:33:50 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-05-14 20:33:50 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\reports/patient_details.php
INFO - 2021-05-14 20:33:50 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-05-14 20:33:50 --> Final output sent to browser
DEBUG - 2021-05-14 20:33:50 --> Total execution time: 0.0553
ERROR - 2021-05-14 20:33:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 20:33:50 --> Config Class Initialized
INFO - 2021-05-14 20:33:50 --> Hooks Class Initialized
DEBUG - 2021-05-14 20:33:50 --> UTF-8 Support Enabled
INFO - 2021-05-14 20:33:50 --> Utf8 Class Initialized
INFO - 2021-05-14 20:33:50 --> URI Class Initialized
INFO - 2021-05-14 20:33:50 --> Router Class Initialized
INFO - 2021-05-14 20:33:50 --> Output Class Initialized
INFO - 2021-05-14 20:33:50 --> Security Class Initialized
DEBUG - 2021-05-14 20:33:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 20:33:50 --> Input Class Initialized
INFO - 2021-05-14 20:33:50 --> Language Class Initialized
ERROR - 2021-05-14 20:33:50 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-05-14 20:34:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 20:34:08 --> Config Class Initialized
INFO - 2021-05-14 20:34:08 --> Hooks Class Initialized
DEBUG - 2021-05-14 20:34:08 --> UTF-8 Support Enabled
INFO - 2021-05-14 20:34:08 --> Utf8 Class Initialized
INFO - 2021-05-14 20:34:08 --> URI Class Initialized
INFO - 2021-05-14 20:34:08 --> Router Class Initialized
INFO - 2021-05-14 20:34:08 --> Output Class Initialized
INFO - 2021-05-14 20:34:08 --> Security Class Initialized
DEBUG - 2021-05-14 20:34:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 20:34:08 --> Input Class Initialized
INFO - 2021-05-14 20:34:08 --> Language Class Initialized
INFO - 2021-05-14 20:34:08 --> Loader Class Initialized
INFO - 2021-05-14 20:34:08 --> Helper loaded: url_helper
INFO - 2021-05-14 20:34:08 --> Helper loaded: form_helper
INFO - 2021-05-14 20:34:08 --> Helper loaded: common_helper
INFO - 2021-05-14 20:34:08 --> Database Driver Class Initialized
DEBUG - 2021-05-14 20:34:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 20:34:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 20:34:08 --> Controller Class Initialized
INFO - 2021-05-14 20:34:08 --> Form Validation Class Initialized
INFO - 2021-05-14 20:34:08 --> Model "Report_model" initialized
INFO - 2021-05-14 20:34:08 --> Model "Case_model" initialized
INFO - 2021-05-14 20:34:08 --> Final output sent to browser
DEBUG - 2021-05-14 20:34:08 --> Total execution time: 0.7995
ERROR - 2021-05-14 20:35:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 20:35:08 --> Config Class Initialized
INFO - 2021-05-14 20:35:08 --> Hooks Class Initialized
DEBUG - 2021-05-14 20:35:08 --> UTF-8 Support Enabled
INFO - 2021-05-14 20:35:08 --> Utf8 Class Initialized
INFO - 2021-05-14 20:35:08 --> URI Class Initialized
INFO - 2021-05-14 20:35:08 --> Router Class Initialized
INFO - 2021-05-14 20:35:08 --> Output Class Initialized
INFO - 2021-05-14 20:35:08 --> Security Class Initialized
DEBUG - 2021-05-14 20:35:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 20:35:08 --> Input Class Initialized
INFO - 2021-05-14 20:35:08 --> Language Class Initialized
INFO - 2021-05-14 20:35:08 --> Loader Class Initialized
INFO - 2021-05-14 20:35:08 --> Helper loaded: url_helper
INFO - 2021-05-14 20:35:08 --> Helper loaded: form_helper
INFO - 2021-05-14 20:35:08 --> Helper loaded: common_helper
INFO - 2021-05-14 20:35:08 --> Database Driver Class Initialized
DEBUG - 2021-05-14 20:35:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 20:35:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 20:35:08 --> Controller Class Initialized
INFO - 2021-05-14 20:35:08 --> Form Validation Class Initialized
INFO - 2021-05-14 20:35:08 --> Model "Report_model" initialized
INFO - 2021-05-14 20:35:08 --> Model "Case_model" initialized
INFO - 2021-05-14 20:35:08 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-05-14 20:35:08 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\reports/patient_details.php
INFO - 2021-05-14 20:35:08 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-05-14 20:35:08 --> Final output sent to browser
DEBUG - 2021-05-14 20:35:08 --> Total execution time: 0.0530
ERROR - 2021-05-14 20:35:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 20:35:08 --> Config Class Initialized
INFO - 2021-05-14 20:35:08 --> Hooks Class Initialized
DEBUG - 2021-05-14 20:35:08 --> UTF-8 Support Enabled
INFO - 2021-05-14 20:35:08 --> Utf8 Class Initialized
INFO - 2021-05-14 20:35:08 --> URI Class Initialized
INFO - 2021-05-14 20:35:08 --> Router Class Initialized
INFO - 2021-05-14 20:35:08 --> Output Class Initialized
INFO - 2021-05-14 20:35:08 --> Security Class Initialized
DEBUG - 2021-05-14 20:35:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 20:35:08 --> Input Class Initialized
INFO - 2021-05-14 20:35:08 --> Language Class Initialized
ERROR - 2021-05-14 20:35:08 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-05-14 20:35:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 20:35:25 --> Config Class Initialized
INFO - 2021-05-14 20:35:25 --> Hooks Class Initialized
DEBUG - 2021-05-14 20:35:25 --> UTF-8 Support Enabled
INFO - 2021-05-14 20:35:25 --> Utf8 Class Initialized
INFO - 2021-05-14 20:35:25 --> URI Class Initialized
INFO - 2021-05-14 20:35:25 --> Router Class Initialized
INFO - 2021-05-14 20:35:25 --> Output Class Initialized
INFO - 2021-05-14 20:35:25 --> Security Class Initialized
DEBUG - 2021-05-14 20:35:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 20:35:25 --> Input Class Initialized
INFO - 2021-05-14 20:35:25 --> Language Class Initialized
INFO - 2021-05-14 20:35:25 --> Loader Class Initialized
INFO - 2021-05-14 20:35:25 --> Helper loaded: url_helper
INFO - 2021-05-14 20:35:25 --> Helper loaded: form_helper
INFO - 2021-05-14 20:35:25 --> Helper loaded: common_helper
INFO - 2021-05-14 20:35:25 --> Database Driver Class Initialized
DEBUG - 2021-05-14 20:35:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 20:35:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 20:35:25 --> Controller Class Initialized
INFO - 2021-05-14 20:35:25 --> Form Validation Class Initialized
INFO - 2021-05-14 20:35:25 --> Model "Report_model" initialized
INFO - 2021-05-14 20:35:25 --> Model "Case_model" initialized
INFO - 2021-05-14 20:35:26 --> Final output sent to browser
DEBUG - 2021-05-14 20:35:26 --> Total execution time: 0.6816
ERROR - 2021-05-14 20:36:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 20:36:42 --> Config Class Initialized
INFO - 2021-05-14 20:36:42 --> Hooks Class Initialized
DEBUG - 2021-05-14 20:36:42 --> UTF-8 Support Enabled
INFO - 2021-05-14 20:36:42 --> Utf8 Class Initialized
INFO - 2021-05-14 20:36:42 --> URI Class Initialized
INFO - 2021-05-14 20:36:42 --> Router Class Initialized
INFO - 2021-05-14 20:36:42 --> Output Class Initialized
INFO - 2021-05-14 20:36:42 --> Security Class Initialized
DEBUG - 2021-05-14 20:36:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 20:36:42 --> Input Class Initialized
INFO - 2021-05-14 20:36:42 --> Language Class Initialized
INFO - 2021-05-14 20:36:42 --> Loader Class Initialized
INFO - 2021-05-14 20:36:42 --> Helper loaded: url_helper
INFO - 2021-05-14 20:36:42 --> Helper loaded: form_helper
INFO - 2021-05-14 20:36:42 --> Helper loaded: common_helper
INFO - 2021-05-14 20:36:42 --> Database Driver Class Initialized
DEBUG - 2021-05-14 20:36:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 20:36:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 20:36:42 --> Controller Class Initialized
INFO - 2021-05-14 20:36:42 --> Form Validation Class Initialized
INFO - 2021-05-14 20:36:42 --> Model "Report_model" initialized
INFO - 2021-05-14 20:36:42 --> Model "Case_model" initialized
INFO - 2021-05-14 20:36:42 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-05-14 20:36:42 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\reports/patient_details.php
INFO - 2021-05-14 20:36:42 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-05-14 20:36:42 --> Final output sent to browser
DEBUG - 2021-05-14 20:36:42 --> Total execution time: 0.0525
ERROR - 2021-05-14 20:36:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 20:36:42 --> Config Class Initialized
INFO - 2021-05-14 20:36:42 --> Hooks Class Initialized
DEBUG - 2021-05-14 20:36:42 --> UTF-8 Support Enabled
INFO - 2021-05-14 20:36:42 --> Utf8 Class Initialized
INFO - 2021-05-14 20:36:42 --> URI Class Initialized
INFO - 2021-05-14 20:36:42 --> Router Class Initialized
INFO - 2021-05-14 20:36:42 --> Output Class Initialized
INFO - 2021-05-14 20:36:42 --> Security Class Initialized
DEBUG - 2021-05-14 20:36:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 20:36:42 --> Input Class Initialized
INFO - 2021-05-14 20:36:42 --> Language Class Initialized
ERROR - 2021-05-14 20:36:42 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-05-14 20:36:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 20:36:58 --> Config Class Initialized
INFO - 2021-05-14 20:36:58 --> Hooks Class Initialized
DEBUG - 2021-05-14 20:36:58 --> UTF-8 Support Enabled
INFO - 2021-05-14 20:36:58 --> Utf8 Class Initialized
INFO - 2021-05-14 20:36:58 --> URI Class Initialized
INFO - 2021-05-14 20:36:58 --> Router Class Initialized
INFO - 2021-05-14 20:36:58 --> Output Class Initialized
INFO - 2021-05-14 20:36:58 --> Security Class Initialized
DEBUG - 2021-05-14 20:36:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 20:36:58 --> Input Class Initialized
INFO - 2021-05-14 20:36:58 --> Language Class Initialized
INFO - 2021-05-14 20:36:58 --> Loader Class Initialized
INFO - 2021-05-14 20:36:58 --> Helper loaded: url_helper
INFO - 2021-05-14 20:36:58 --> Helper loaded: form_helper
INFO - 2021-05-14 20:36:58 --> Helper loaded: common_helper
INFO - 2021-05-14 20:36:58 --> Database Driver Class Initialized
DEBUG - 2021-05-14 20:36:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 20:36:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 20:36:58 --> Controller Class Initialized
INFO - 2021-05-14 20:36:58 --> Form Validation Class Initialized
INFO - 2021-05-14 20:36:58 --> Model "Report_model" initialized
INFO - 2021-05-14 20:36:58 --> Model "Case_model" initialized
INFO - 2021-05-14 20:36:58 --> Final output sent to browser
DEBUG - 2021-05-14 20:36:58 --> Total execution time: 0.6837
ERROR - 2021-05-14 20:38:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 20:38:09 --> Config Class Initialized
INFO - 2021-05-14 20:38:09 --> Hooks Class Initialized
DEBUG - 2021-05-14 20:38:09 --> UTF-8 Support Enabled
INFO - 2021-05-14 20:38:09 --> Utf8 Class Initialized
INFO - 2021-05-14 20:38:09 --> URI Class Initialized
INFO - 2021-05-14 20:38:09 --> Router Class Initialized
INFO - 2021-05-14 20:38:09 --> Output Class Initialized
INFO - 2021-05-14 20:38:09 --> Security Class Initialized
DEBUG - 2021-05-14 20:38:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 20:38:09 --> Input Class Initialized
INFO - 2021-05-14 20:38:09 --> Language Class Initialized
INFO - 2021-05-14 20:38:09 --> Loader Class Initialized
INFO - 2021-05-14 20:38:09 --> Helper loaded: url_helper
INFO - 2021-05-14 20:38:09 --> Helper loaded: form_helper
INFO - 2021-05-14 20:38:09 --> Helper loaded: common_helper
INFO - 2021-05-14 20:38:09 --> Database Driver Class Initialized
DEBUG - 2021-05-14 20:38:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 20:38:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 20:38:09 --> Controller Class Initialized
INFO - 2021-05-14 20:38:09 --> Form Validation Class Initialized
INFO - 2021-05-14 20:38:09 --> Model "Report_model" initialized
INFO - 2021-05-14 20:38:09 --> Model "Case_model" initialized
INFO - 2021-05-14 20:38:09 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-05-14 20:38:09 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\reports/patient_details.php
INFO - 2021-05-14 20:38:09 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-05-14 20:38:09 --> Final output sent to browser
DEBUG - 2021-05-14 20:38:09 --> Total execution time: 0.0449
ERROR - 2021-05-14 20:38:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 20:38:09 --> Config Class Initialized
INFO - 2021-05-14 20:38:09 --> Hooks Class Initialized
DEBUG - 2021-05-14 20:38:09 --> UTF-8 Support Enabled
INFO - 2021-05-14 20:38:09 --> Utf8 Class Initialized
INFO - 2021-05-14 20:38:09 --> URI Class Initialized
INFO - 2021-05-14 20:38:09 --> Router Class Initialized
INFO - 2021-05-14 20:38:09 --> Output Class Initialized
INFO - 2021-05-14 20:38:09 --> Security Class Initialized
DEBUG - 2021-05-14 20:38:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 20:38:09 --> Input Class Initialized
INFO - 2021-05-14 20:38:09 --> Language Class Initialized
ERROR - 2021-05-14 20:38:09 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-05-14 20:38:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 20:38:26 --> Config Class Initialized
INFO - 2021-05-14 20:38:26 --> Hooks Class Initialized
DEBUG - 2021-05-14 20:38:26 --> UTF-8 Support Enabled
INFO - 2021-05-14 20:38:26 --> Utf8 Class Initialized
INFO - 2021-05-14 20:38:26 --> URI Class Initialized
INFO - 2021-05-14 20:38:26 --> Router Class Initialized
INFO - 2021-05-14 20:38:26 --> Output Class Initialized
INFO - 2021-05-14 20:38:26 --> Security Class Initialized
DEBUG - 2021-05-14 20:38:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 20:38:26 --> Input Class Initialized
INFO - 2021-05-14 20:38:26 --> Language Class Initialized
INFO - 2021-05-14 20:38:26 --> Loader Class Initialized
INFO - 2021-05-14 20:38:26 --> Helper loaded: url_helper
INFO - 2021-05-14 20:38:26 --> Helper loaded: form_helper
INFO - 2021-05-14 20:38:26 --> Helper loaded: common_helper
INFO - 2021-05-14 20:38:26 --> Database Driver Class Initialized
DEBUG - 2021-05-14 20:38:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 20:38:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 20:38:26 --> Controller Class Initialized
INFO - 2021-05-14 20:38:26 --> Form Validation Class Initialized
INFO - 2021-05-14 20:38:26 --> Model "Report_model" initialized
INFO - 2021-05-14 20:38:26 --> Model "Case_model" initialized
INFO - 2021-05-14 20:38:27 --> Final output sent to browser
DEBUG - 2021-05-14 20:38:27 --> Total execution time: 0.7084
ERROR - 2021-05-14 20:39:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-14 20:39:22 --> Config Class Initialized
INFO - 2021-05-14 20:39:22 --> Hooks Class Initialized
DEBUG - 2021-05-14 20:39:22 --> UTF-8 Support Enabled
INFO - 2021-05-14 20:39:22 --> Utf8 Class Initialized
INFO - 2021-05-14 20:39:22 --> URI Class Initialized
INFO - 2021-05-14 20:39:22 --> Router Class Initialized
INFO - 2021-05-14 20:39:22 --> Output Class Initialized
INFO - 2021-05-14 20:39:22 --> Security Class Initialized
DEBUG - 2021-05-14 20:39:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 20:39:22 --> Input Class Initialized
INFO - 2021-05-14 20:39:22 --> Language Class Initialized
INFO - 2021-05-14 20:39:22 --> Loader Class Initialized
INFO - 2021-05-14 20:39:22 --> Helper loaded: url_helper
INFO - 2021-05-14 20:39:22 --> Helper loaded: form_helper
INFO - 2021-05-14 20:39:22 --> Helper loaded: common_helper
INFO - 2021-05-14 20:39:22 --> Database Driver Class Initialized
DEBUG - 2021-05-14 20:39:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 20:39:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 20:39:22 --> Controller Class Initialized
INFO - 2021-05-14 20:39:22 --> Form Validation Class Initialized
INFO - 2021-05-14 20:39:22 --> Model "Report_model" initialized
INFO - 2021-05-14 20:39:22 --> Model "Case_model" initialized
INFO - 2021-05-14 20:39:22 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-05-14 20:39:22 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\reports/patient_details.php
INFO - 2021-05-14 20:39:22 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-05-14 20:39:22 --> Final output sent to browser
DEBUG - 2021-05-14 20:39:22 --> Total execution time: 0.0554
