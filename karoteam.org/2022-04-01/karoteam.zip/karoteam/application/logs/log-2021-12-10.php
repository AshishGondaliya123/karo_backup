<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-12-10 00:02:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-10 00:02:57 --> Config Class Initialized
INFO - 2021-12-10 00:02:57 --> Hooks Class Initialized
DEBUG - 2021-12-10 00:02:57 --> UTF-8 Support Enabled
INFO - 2021-12-10 00:02:57 --> Utf8 Class Initialized
INFO - 2021-12-10 00:02:57 --> URI Class Initialized
DEBUG - 2021-12-10 00:02:57 --> No URI present. Default controller set.
INFO - 2021-12-10 00:02:57 --> Router Class Initialized
INFO - 2021-12-10 00:02:57 --> Output Class Initialized
INFO - 2021-12-10 00:02:57 --> Security Class Initialized
DEBUG - 2021-12-10 00:02:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 00:02:57 --> Input Class Initialized
INFO - 2021-12-10 00:02:57 --> Language Class Initialized
INFO - 2021-12-10 00:02:57 --> Loader Class Initialized
INFO - 2021-12-10 00:02:57 --> Helper loaded: url_helper
INFO - 2021-12-10 00:02:57 --> Helper loaded: form_helper
INFO - 2021-12-10 00:02:57 --> Helper loaded: common_helper
INFO - 2021-12-10 00:02:57 --> Database Driver Class Initialized
DEBUG - 2021-12-10 00:02:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 00:02:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 00:02:57 --> Controller Class Initialized
INFO - 2021-12-10 00:02:57 --> Form Validation Class Initialized
DEBUG - 2021-12-10 00:02:57 --> Encrypt Class Initialized
DEBUG - 2021-12-10 00:02:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-10 00:02:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-10 00:02:57 --> Email Class Initialized
INFO - 2021-12-10 00:02:57 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-10 00:02:57 --> Calendar Class Initialized
INFO - 2021-12-10 00:02:57 --> Model "Login_model" initialized
INFO - 2021-12-10 00:02:57 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-10 00:02:57 --> Final output sent to browser
DEBUG - 2021-12-10 00:02:57 --> Total execution time: 0.0367
ERROR - 2021-12-10 00:14:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-10 00:14:09 --> Config Class Initialized
INFO - 2021-12-10 00:14:09 --> Hooks Class Initialized
DEBUG - 2021-12-10 00:14:09 --> UTF-8 Support Enabled
INFO - 2021-12-10 00:14:09 --> Utf8 Class Initialized
INFO - 2021-12-10 00:14:09 --> URI Class Initialized
DEBUG - 2021-12-10 00:14:09 --> No URI present. Default controller set.
INFO - 2021-12-10 00:14:09 --> Router Class Initialized
INFO - 2021-12-10 00:14:09 --> Output Class Initialized
INFO - 2021-12-10 00:14:09 --> Security Class Initialized
DEBUG - 2021-12-10 00:14:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 00:14:09 --> Input Class Initialized
INFO - 2021-12-10 00:14:09 --> Language Class Initialized
INFO - 2021-12-10 00:14:09 --> Loader Class Initialized
INFO - 2021-12-10 00:14:09 --> Helper loaded: url_helper
INFO - 2021-12-10 00:14:09 --> Helper loaded: form_helper
INFO - 2021-12-10 00:14:09 --> Helper loaded: common_helper
INFO - 2021-12-10 00:14:09 --> Database Driver Class Initialized
DEBUG - 2021-12-10 00:14:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 00:14:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 00:14:09 --> Controller Class Initialized
INFO - 2021-12-10 00:14:09 --> Form Validation Class Initialized
DEBUG - 2021-12-10 00:14:09 --> Encrypt Class Initialized
DEBUG - 2021-12-10 00:14:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-10 00:14:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-10 00:14:09 --> Email Class Initialized
INFO - 2021-12-10 00:14:09 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-10 00:14:09 --> Calendar Class Initialized
INFO - 2021-12-10 00:14:09 --> Model "Login_model" initialized
INFO - 2021-12-10 00:14:09 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-10 00:14:09 --> Final output sent to browser
DEBUG - 2021-12-10 00:14:09 --> Total execution time: 0.0212
ERROR - 2021-12-10 04:29:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-10 04:29:32 --> Config Class Initialized
INFO - 2021-12-10 04:29:32 --> Hooks Class Initialized
DEBUG - 2021-12-10 04:29:32 --> UTF-8 Support Enabled
INFO - 2021-12-10 04:29:32 --> Utf8 Class Initialized
INFO - 2021-12-10 04:29:32 --> URI Class Initialized
DEBUG - 2021-12-10 04:29:32 --> No URI present. Default controller set.
INFO - 2021-12-10 04:29:32 --> Router Class Initialized
INFO - 2021-12-10 04:29:32 --> Output Class Initialized
INFO - 2021-12-10 04:29:32 --> Security Class Initialized
DEBUG - 2021-12-10 04:29:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 04:29:32 --> Input Class Initialized
INFO - 2021-12-10 04:29:32 --> Language Class Initialized
INFO - 2021-12-10 04:29:32 --> Loader Class Initialized
INFO - 2021-12-10 04:29:32 --> Helper loaded: url_helper
INFO - 2021-12-10 04:29:32 --> Helper loaded: form_helper
INFO - 2021-12-10 04:29:32 --> Helper loaded: common_helper
INFO - 2021-12-10 04:29:32 --> Database Driver Class Initialized
DEBUG - 2021-12-10 04:29:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 04:29:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 04:29:32 --> Controller Class Initialized
INFO - 2021-12-10 04:29:32 --> Form Validation Class Initialized
DEBUG - 2021-12-10 04:29:32 --> Encrypt Class Initialized
DEBUG - 2021-12-10 04:29:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-10 04:29:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-10 04:29:32 --> Email Class Initialized
INFO - 2021-12-10 04:29:32 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-10 04:29:32 --> Calendar Class Initialized
INFO - 2021-12-10 04:29:32 --> Model "Login_model" initialized
INFO - 2021-12-10 04:29:32 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-10 04:29:32 --> Final output sent to browser
DEBUG - 2021-12-10 04:29:32 --> Total execution time: 0.0325
ERROR - 2021-12-10 09:19:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-10 09:19:49 --> Config Class Initialized
INFO - 2021-12-10 09:19:49 --> Hooks Class Initialized
DEBUG - 2021-12-10 09:19:49 --> UTF-8 Support Enabled
INFO - 2021-12-10 09:19:49 --> Utf8 Class Initialized
INFO - 2021-12-10 09:19:49 --> URI Class Initialized
DEBUG - 2021-12-10 09:19:49 --> No URI present. Default controller set.
INFO - 2021-12-10 09:19:49 --> Router Class Initialized
INFO - 2021-12-10 09:19:49 --> Output Class Initialized
INFO - 2021-12-10 09:19:49 --> Security Class Initialized
DEBUG - 2021-12-10 09:19:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 09:19:49 --> Input Class Initialized
INFO - 2021-12-10 09:19:49 --> Language Class Initialized
INFO - 2021-12-10 09:19:49 --> Loader Class Initialized
INFO - 2021-12-10 09:19:49 --> Helper loaded: url_helper
INFO - 2021-12-10 09:19:49 --> Helper loaded: form_helper
INFO - 2021-12-10 09:19:49 --> Helper loaded: common_helper
INFO - 2021-12-10 09:19:49 --> Database Driver Class Initialized
DEBUG - 2021-12-10 09:19:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 09:19:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 09:19:49 --> Controller Class Initialized
INFO - 2021-12-10 09:19:49 --> Form Validation Class Initialized
DEBUG - 2021-12-10 09:19:49 --> Encrypt Class Initialized
DEBUG - 2021-12-10 09:19:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-10 09:19:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-10 09:19:49 --> Email Class Initialized
INFO - 2021-12-10 09:19:49 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-10 09:19:49 --> Calendar Class Initialized
INFO - 2021-12-10 09:19:49 --> Model "Login_model" initialized
INFO - 2021-12-10 09:19:49 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-10 09:19:49 --> Final output sent to browser
DEBUG - 2021-12-10 09:19:49 --> Total execution time: 0.0261
ERROR - 2021-12-10 09:59:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-10 09:59:04 --> Config Class Initialized
INFO - 2021-12-10 09:59:04 --> Hooks Class Initialized
DEBUG - 2021-12-10 09:59:04 --> UTF-8 Support Enabled
INFO - 2021-12-10 09:59:04 --> Utf8 Class Initialized
INFO - 2021-12-10 09:59:04 --> URI Class Initialized
DEBUG - 2021-12-10 09:59:04 --> No URI present. Default controller set.
INFO - 2021-12-10 09:59:04 --> Router Class Initialized
INFO - 2021-12-10 09:59:04 --> Output Class Initialized
INFO - 2021-12-10 09:59:04 --> Security Class Initialized
DEBUG - 2021-12-10 09:59:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 09:59:04 --> Input Class Initialized
INFO - 2021-12-10 09:59:04 --> Language Class Initialized
INFO - 2021-12-10 09:59:04 --> Loader Class Initialized
INFO - 2021-12-10 09:59:04 --> Helper loaded: url_helper
INFO - 2021-12-10 09:59:04 --> Helper loaded: form_helper
INFO - 2021-12-10 09:59:04 --> Helper loaded: common_helper
INFO - 2021-12-10 09:59:04 --> Database Driver Class Initialized
DEBUG - 2021-12-10 09:59:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 09:59:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 09:59:04 --> Controller Class Initialized
INFO - 2021-12-10 09:59:04 --> Form Validation Class Initialized
DEBUG - 2021-12-10 09:59:04 --> Encrypt Class Initialized
DEBUG - 2021-12-10 09:59:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-10 09:59:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-10 09:59:04 --> Email Class Initialized
INFO - 2021-12-10 09:59:04 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-10 09:59:04 --> Calendar Class Initialized
INFO - 2021-12-10 09:59:04 --> Model "Login_model" initialized
INFO - 2021-12-10 09:59:04 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-10 09:59:04 --> Final output sent to browser
DEBUG - 2021-12-10 09:59:04 --> Total execution time: 0.0293
ERROR - 2021-12-10 10:16:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-10 10:16:56 --> Config Class Initialized
INFO - 2021-12-10 10:16:56 --> Hooks Class Initialized
DEBUG - 2021-12-10 10:16:56 --> UTF-8 Support Enabled
INFO - 2021-12-10 10:16:56 --> Utf8 Class Initialized
INFO - 2021-12-10 10:16:56 --> URI Class Initialized
DEBUG - 2021-12-10 10:16:56 --> No URI present. Default controller set.
INFO - 2021-12-10 10:16:56 --> Router Class Initialized
INFO - 2021-12-10 10:16:56 --> Output Class Initialized
INFO - 2021-12-10 10:16:56 --> Security Class Initialized
DEBUG - 2021-12-10 10:16:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 10:16:56 --> Input Class Initialized
INFO - 2021-12-10 10:16:56 --> Language Class Initialized
INFO - 2021-12-10 10:16:56 --> Loader Class Initialized
INFO - 2021-12-10 10:16:56 --> Helper loaded: url_helper
INFO - 2021-12-10 10:16:56 --> Helper loaded: form_helper
INFO - 2021-12-10 10:16:56 --> Helper loaded: common_helper
INFO - 2021-12-10 10:16:56 --> Database Driver Class Initialized
DEBUG - 2021-12-10 10:16:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 10:16:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 10:16:56 --> Controller Class Initialized
INFO - 2021-12-10 10:16:56 --> Form Validation Class Initialized
DEBUG - 2021-12-10 10:16:56 --> Encrypt Class Initialized
DEBUG - 2021-12-10 10:16:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-10 10:16:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-10 10:16:56 --> Email Class Initialized
INFO - 2021-12-10 10:16:56 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-10 10:16:56 --> Calendar Class Initialized
INFO - 2021-12-10 10:16:56 --> Model "Login_model" initialized
INFO - 2021-12-10 10:16:56 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-10 10:16:56 --> Final output sent to browser
DEBUG - 2021-12-10 10:16:56 --> Total execution time: 0.0356
ERROR - 2021-12-10 10:39:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-10 10:39:55 --> Config Class Initialized
INFO - 2021-12-10 10:39:55 --> Hooks Class Initialized
DEBUG - 2021-12-10 10:39:55 --> UTF-8 Support Enabled
INFO - 2021-12-10 10:39:55 --> Utf8 Class Initialized
INFO - 2021-12-10 10:39:55 --> URI Class Initialized
DEBUG - 2021-12-10 10:39:55 --> No URI present. Default controller set.
INFO - 2021-12-10 10:39:55 --> Router Class Initialized
INFO - 2021-12-10 10:39:55 --> Output Class Initialized
INFO - 2021-12-10 10:39:55 --> Security Class Initialized
DEBUG - 2021-12-10 10:39:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 10:39:55 --> Input Class Initialized
INFO - 2021-12-10 10:39:55 --> Language Class Initialized
INFO - 2021-12-10 10:39:55 --> Loader Class Initialized
INFO - 2021-12-10 10:39:55 --> Helper loaded: url_helper
INFO - 2021-12-10 10:39:55 --> Helper loaded: form_helper
INFO - 2021-12-10 10:39:55 --> Helper loaded: common_helper
INFO - 2021-12-10 10:39:55 --> Database Driver Class Initialized
DEBUG - 2021-12-10 10:39:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 10:39:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 10:39:55 --> Controller Class Initialized
INFO - 2021-12-10 10:39:55 --> Form Validation Class Initialized
DEBUG - 2021-12-10 10:39:55 --> Encrypt Class Initialized
DEBUG - 2021-12-10 10:39:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-10 10:39:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-10 10:39:55 --> Email Class Initialized
INFO - 2021-12-10 10:39:55 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-10 10:39:55 --> Calendar Class Initialized
INFO - 2021-12-10 10:39:55 --> Model "Login_model" initialized
INFO - 2021-12-10 10:39:55 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-10 10:39:55 --> Final output sent to browser
DEBUG - 2021-12-10 10:39:55 --> Total execution time: 0.0247
ERROR - 2021-12-10 11:30:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-10 11:30:22 --> Config Class Initialized
INFO - 2021-12-10 11:30:22 --> Hooks Class Initialized
DEBUG - 2021-12-10 11:30:22 --> UTF-8 Support Enabled
INFO - 2021-12-10 11:30:22 --> Utf8 Class Initialized
INFO - 2021-12-10 11:30:22 --> URI Class Initialized
DEBUG - 2021-12-10 11:30:22 --> No URI present. Default controller set.
INFO - 2021-12-10 11:30:22 --> Router Class Initialized
INFO - 2021-12-10 11:30:22 --> Output Class Initialized
INFO - 2021-12-10 11:30:22 --> Security Class Initialized
DEBUG - 2021-12-10 11:30:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 11:30:22 --> Input Class Initialized
INFO - 2021-12-10 11:30:22 --> Language Class Initialized
INFO - 2021-12-10 11:30:22 --> Loader Class Initialized
INFO - 2021-12-10 11:30:22 --> Helper loaded: url_helper
INFO - 2021-12-10 11:30:22 --> Helper loaded: form_helper
INFO - 2021-12-10 11:30:22 --> Helper loaded: common_helper
INFO - 2021-12-10 11:30:22 --> Database Driver Class Initialized
DEBUG - 2021-12-10 11:30:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 11:30:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 11:30:22 --> Controller Class Initialized
INFO - 2021-12-10 11:30:22 --> Form Validation Class Initialized
DEBUG - 2021-12-10 11:30:22 --> Encrypt Class Initialized
DEBUG - 2021-12-10 11:30:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-10 11:30:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-10 11:30:22 --> Email Class Initialized
INFO - 2021-12-10 11:30:22 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-10 11:30:22 --> Calendar Class Initialized
INFO - 2021-12-10 11:30:22 --> Model "Login_model" initialized
INFO - 2021-12-10 11:30:22 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-10 11:30:22 --> Final output sent to browser
DEBUG - 2021-12-10 11:30:22 --> Total execution time: 0.0230
ERROR - 2021-12-10 14:11:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-10 14:11:16 --> Config Class Initialized
INFO - 2021-12-10 14:11:16 --> Hooks Class Initialized
DEBUG - 2021-12-10 14:11:16 --> UTF-8 Support Enabled
INFO - 2021-12-10 14:11:16 --> Utf8 Class Initialized
INFO - 2021-12-10 14:11:16 --> URI Class Initialized
DEBUG - 2021-12-10 14:11:16 --> No URI present. Default controller set.
INFO - 2021-12-10 14:11:16 --> Router Class Initialized
INFO - 2021-12-10 14:11:16 --> Output Class Initialized
INFO - 2021-12-10 14:11:16 --> Security Class Initialized
DEBUG - 2021-12-10 14:11:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 14:11:16 --> Input Class Initialized
INFO - 2021-12-10 14:11:16 --> Language Class Initialized
INFO - 2021-12-10 14:11:16 --> Loader Class Initialized
INFO - 2021-12-10 14:11:16 --> Helper loaded: url_helper
INFO - 2021-12-10 14:11:16 --> Helper loaded: form_helper
INFO - 2021-12-10 14:11:16 --> Helper loaded: common_helper
INFO - 2021-12-10 14:11:16 --> Database Driver Class Initialized
DEBUG - 2021-12-10 14:11:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 14:11:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 14:11:16 --> Controller Class Initialized
INFO - 2021-12-10 14:11:16 --> Form Validation Class Initialized
DEBUG - 2021-12-10 14:11:16 --> Encrypt Class Initialized
DEBUG - 2021-12-10 14:11:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-10 14:11:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-10 14:11:16 --> Email Class Initialized
INFO - 2021-12-10 14:11:16 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-10 14:11:16 --> Calendar Class Initialized
INFO - 2021-12-10 14:11:16 --> Model "Login_model" initialized
INFO - 2021-12-10 14:11:16 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-10 14:11:16 --> Final output sent to browser
DEBUG - 2021-12-10 14:11:16 --> Total execution time: 0.0250
ERROR - 2021-12-10 14:22:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-10 14:22:09 --> Config Class Initialized
INFO - 2021-12-10 14:22:09 --> Hooks Class Initialized
DEBUG - 2021-12-10 14:22:09 --> UTF-8 Support Enabled
INFO - 2021-12-10 14:22:09 --> Utf8 Class Initialized
INFO - 2021-12-10 14:22:09 --> URI Class Initialized
DEBUG - 2021-12-10 14:22:09 --> No URI present. Default controller set.
INFO - 2021-12-10 14:22:09 --> Router Class Initialized
INFO - 2021-12-10 14:22:09 --> Output Class Initialized
INFO - 2021-12-10 14:22:09 --> Security Class Initialized
DEBUG - 2021-12-10 14:22:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 14:22:09 --> Input Class Initialized
INFO - 2021-12-10 14:22:09 --> Language Class Initialized
INFO - 2021-12-10 14:22:09 --> Loader Class Initialized
INFO - 2021-12-10 14:22:10 --> Helper loaded: url_helper
INFO - 2021-12-10 14:22:10 --> Helper loaded: form_helper
INFO - 2021-12-10 14:22:10 --> Helper loaded: common_helper
INFO - 2021-12-10 14:22:10 --> Database Driver Class Initialized
DEBUG - 2021-12-10 14:22:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 14:22:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 14:22:10 --> Controller Class Initialized
INFO - 2021-12-10 14:22:10 --> Form Validation Class Initialized
DEBUG - 2021-12-10 14:22:10 --> Encrypt Class Initialized
DEBUG - 2021-12-10 14:22:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-10 14:22:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-10 14:22:10 --> Email Class Initialized
INFO - 2021-12-10 14:22:10 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-10 14:22:10 --> Calendar Class Initialized
INFO - 2021-12-10 14:22:10 --> Model "Login_model" initialized
INFO - 2021-12-10 14:22:10 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-10 14:22:10 --> Final output sent to browser
DEBUG - 2021-12-10 14:22:10 --> Total execution time: 0.0259
ERROR - 2021-12-10 14:22:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-10 14:22:10 --> Config Class Initialized
INFO - 2021-12-10 14:22:10 --> Hooks Class Initialized
DEBUG - 2021-12-10 14:22:10 --> UTF-8 Support Enabled
INFO - 2021-12-10 14:22:10 --> Utf8 Class Initialized
INFO - 2021-12-10 14:22:10 --> URI Class Initialized
INFO - 2021-12-10 14:22:10 --> Router Class Initialized
INFO - 2021-12-10 14:22:10 --> Output Class Initialized
INFO - 2021-12-10 14:22:10 --> Security Class Initialized
DEBUG - 2021-12-10 14:22:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 14:22:10 --> Input Class Initialized
INFO - 2021-12-10 14:22:10 --> Language Class Initialized
ERROR - 2021-12-10 14:22:10 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2021-12-10 14:22:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-10 14:22:28 --> Config Class Initialized
INFO - 2021-12-10 14:22:28 --> Hooks Class Initialized
DEBUG - 2021-12-10 14:22:28 --> UTF-8 Support Enabled
INFO - 2021-12-10 14:22:28 --> Utf8 Class Initialized
INFO - 2021-12-10 14:22:28 --> URI Class Initialized
INFO - 2021-12-10 14:22:28 --> Router Class Initialized
INFO - 2021-12-10 14:22:28 --> Output Class Initialized
INFO - 2021-12-10 14:22:28 --> Security Class Initialized
DEBUG - 2021-12-10 14:22:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 14:22:28 --> Input Class Initialized
INFO - 2021-12-10 14:22:28 --> Language Class Initialized
INFO - 2021-12-10 14:22:28 --> Loader Class Initialized
INFO - 2021-12-10 14:22:28 --> Helper loaded: url_helper
INFO - 2021-12-10 14:22:28 --> Helper loaded: form_helper
INFO - 2021-12-10 14:22:28 --> Helper loaded: common_helper
INFO - 2021-12-10 14:22:28 --> Database Driver Class Initialized
DEBUG - 2021-12-10 14:22:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 14:22:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 14:22:28 --> Controller Class Initialized
INFO - 2021-12-10 14:22:28 --> Form Validation Class Initialized
DEBUG - 2021-12-10 14:22:28 --> Encrypt Class Initialized
DEBUG - 2021-12-10 14:22:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-10 14:22:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-10 14:22:28 --> Email Class Initialized
INFO - 2021-12-10 14:22:28 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-10 14:22:28 --> Calendar Class Initialized
INFO - 2021-12-10 14:22:28 --> Model "Login_model" initialized
INFO - 2021-12-10 14:22:28 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-10 14:22:28 --> Final output sent to browser
DEBUG - 2021-12-10 14:22:28 --> Total execution time: 0.0239
ERROR - 2021-12-10 14:22:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-10 14:22:29 --> Config Class Initialized
INFO - 2021-12-10 14:22:29 --> Hooks Class Initialized
DEBUG - 2021-12-10 14:22:29 --> UTF-8 Support Enabled
INFO - 2021-12-10 14:22:29 --> Utf8 Class Initialized
INFO - 2021-12-10 14:22:29 --> URI Class Initialized
DEBUG - 2021-12-10 14:22:29 --> No URI present. Default controller set.
INFO - 2021-12-10 14:22:29 --> Router Class Initialized
INFO - 2021-12-10 14:22:29 --> Output Class Initialized
INFO - 2021-12-10 14:22:29 --> Security Class Initialized
DEBUG - 2021-12-10 14:22:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 14:22:29 --> Input Class Initialized
INFO - 2021-12-10 14:22:29 --> Language Class Initialized
INFO - 2021-12-10 14:22:29 --> Loader Class Initialized
INFO - 2021-12-10 14:22:29 --> Helper loaded: url_helper
INFO - 2021-12-10 14:22:29 --> Helper loaded: form_helper
INFO - 2021-12-10 14:22:29 --> Helper loaded: common_helper
INFO - 2021-12-10 14:22:29 --> Database Driver Class Initialized
DEBUG - 2021-12-10 14:22:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 14:22:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 14:22:29 --> Controller Class Initialized
INFO - 2021-12-10 14:22:29 --> Form Validation Class Initialized
DEBUG - 2021-12-10 14:22:29 --> Encrypt Class Initialized
DEBUG - 2021-12-10 14:22:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-10 14:22:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-10 14:22:29 --> Email Class Initialized
INFO - 2021-12-10 14:22:29 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-10 14:22:29 --> Calendar Class Initialized
INFO - 2021-12-10 14:22:29 --> Model "Login_model" initialized
INFO - 2021-12-10 14:22:29 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-10 14:22:29 --> Final output sent to browser
DEBUG - 2021-12-10 14:22:29 --> Total execution time: 0.0525
ERROR - 2021-12-10 14:22:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-10 14:22:29 --> Config Class Initialized
INFO - 2021-12-10 14:22:29 --> Hooks Class Initialized
DEBUG - 2021-12-10 14:22:29 --> UTF-8 Support Enabled
INFO - 2021-12-10 14:22:29 --> Utf8 Class Initialized
INFO - 2021-12-10 14:22:29 --> URI Class Initialized
INFO - 2021-12-10 14:22:29 --> Router Class Initialized
INFO - 2021-12-10 14:22:29 --> Output Class Initialized
INFO - 2021-12-10 14:22:29 --> Security Class Initialized
DEBUG - 2021-12-10 14:22:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 14:22:29 --> Input Class Initialized
INFO - 2021-12-10 14:22:29 --> Language Class Initialized
INFO - 2021-12-10 14:22:29 --> Loader Class Initialized
INFO - 2021-12-10 14:22:29 --> Helper loaded: url_helper
INFO - 2021-12-10 14:22:29 --> Helper loaded: form_helper
INFO - 2021-12-10 14:22:29 --> Helper loaded: common_helper
INFO - 2021-12-10 14:22:29 --> Database Driver Class Initialized
DEBUG - 2021-12-10 14:22:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 14:22:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 14:22:29 --> Controller Class Initialized
INFO - 2021-12-10 14:22:29 --> Form Validation Class Initialized
DEBUG - 2021-12-10 14:22:29 --> Encrypt Class Initialized
DEBUG - 2021-12-10 14:22:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-10 14:22:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-10 14:22:29 --> Email Class Initialized
INFO - 2021-12-10 14:22:29 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-10 14:22:29 --> Calendar Class Initialized
INFO - 2021-12-10 14:22:29 --> Model "Login_model" initialized
ERROR - 2021-12-10 14:22:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-10 14:22:30 --> Config Class Initialized
INFO - 2021-12-10 14:22:30 --> Hooks Class Initialized
DEBUG - 2021-12-10 14:22:30 --> UTF-8 Support Enabled
INFO - 2021-12-10 14:22:30 --> Utf8 Class Initialized
INFO - 2021-12-10 14:22:30 --> URI Class Initialized
INFO - 2021-12-10 14:22:30 --> Router Class Initialized
INFO - 2021-12-10 14:22:30 --> Output Class Initialized
INFO - 2021-12-10 14:22:30 --> Security Class Initialized
DEBUG - 2021-12-10 14:22:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 14:22:30 --> Input Class Initialized
INFO - 2021-12-10 14:22:30 --> Language Class Initialized
INFO - 2021-12-10 14:22:30 --> Loader Class Initialized
INFO - 2021-12-10 14:22:30 --> Helper loaded: url_helper
INFO - 2021-12-10 14:22:30 --> Helper loaded: form_helper
INFO - 2021-12-10 14:22:30 --> Helper loaded: common_helper
INFO - 2021-12-10 14:22:30 --> Database Driver Class Initialized
DEBUG - 2021-12-10 14:22:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 14:22:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 14:22:30 --> Controller Class Initialized
INFO - 2021-12-10 14:22:30 --> Form Validation Class Initialized
DEBUG - 2021-12-10 14:22:30 --> Encrypt Class Initialized
DEBUG - 2021-12-10 14:22:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-10 14:22:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-10 14:22:30 --> Email Class Initialized
INFO - 2021-12-10 14:22:30 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-10 14:22:30 --> Calendar Class Initialized
INFO - 2021-12-10 14:22:30 --> Model "Login_model" initialized
ERROR - 2021-12-10 14:37:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-10 14:37:20 --> Config Class Initialized
INFO - 2021-12-10 14:37:20 --> Hooks Class Initialized
DEBUG - 2021-12-10 14:37:20 --> UTF-8 Support Enabled
INFO - 2021-12-10 14:37:20 --> Utf8 Class Initialized
INFO - 2021-12-10 14:37:20 --> URI Class Initialized
DEBUG - 2021-12-10 14:37:20 --> No URI present. Default controller set.
INFO - 2021-12-10 14:37:20 --> Router Class Initialized
INFO - 2021-12-10 14:37:20 --> Output Class Initialized
INFO - 2021-12-10 14:37:20 --> Security Class Initialized
DEBUG - 2021-12-10 14:37:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 14:37:20 --> Input Class Initialized
INFO - 2021-12-10 14:37:20 --> Language Class Initialized
INFO - 2021-12-10 14:37:20 --> Loader Class Initialized
INFO - 2021-12-10 14:37:20 --> Helper loaded: url_helper
INFO - 2021-12-10 14:37:20 --> Helper loaded: form_helper
INFO - 2021-12-10 14:37:20 --> Helper loaded: common_helper
INFO - 2021-12-10 14:37:20 --> Database Driver Class Initialized
DEBUG - 2021-12-10 14:37:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 14:37:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 14:37:20 --> Controller Class Initialized
INFO - 2021-12-10 14:37:20 --> Form Validation Class Initialized
DEBUG - 2021-12-10 14:37:20 --> Encrypt Class Initialized
DEBUG - 2021-12-10 14:37:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-10 14:37:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-10 14:37:20 --> Email Class Initialized
INFO - 2021-12-10 14:37:20 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-10 14:37:20 --> Calendar Class Initialized
INFO - 2021-12-10 14:37:20 --> Model "Login_model" initialized
INFO - 2021-12-10 14:37:20 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-10 14:37:20 --> Final output sent to browser
DEBUG - 2021-12-10 14:37:20 --> Total execution time: 0.0315
ERROR - 2021-12-10 14:38:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-10 14:38:34 --> Config Class Initialized
INFO - 2021-12-10 14:38:34 --> Hooks Class Initialized
DEBUG - 2021-12-10 14:38:34 --> UTF-8 Support Enabled
INFO - 2021-12-10 14:38:34 --> Utf8 Class Initialized
INFO - 2021-12-10 14:38:34 --> URI Class Initialized
DEBUG - 2021-12-10 14:38:34 --> No URI present. Default controller set.
INFO - 2021-12-10 14:38:34 --> Router Class Initialized
INFO - 2021-12-10 14:38:34 --> Output Class Initialized
INFO - 2021-12-10 14:38:34 --> Security Class Initialized
DEBUG - 2021-12-10 14:38:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 14:38:34 --> Input Class Initialized
INFO - 2021-12-10 14:38:34 --> Language Class Initialized
INFO - 2021-12-10 14:38:34 --> Loader Class Initialized
INFO - 2021-12-10 14:38:34 --> Helper loaded: url_helper
INFO - 2021-12-10 14:38:34 --> Helper loaded: form_helper
INFO - 2021-12-10 14:38:34 --> Helper loaded: common_helper
INFO - 2021-12-10 14:38:34 --> Database Driver Class Initialized
DEBUG - 2021-12-10 14:38:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 14:38:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 14:38:34 --> Controller Class Initialized
INFO - 2021-12-10 14:38:34 --> Form Validation Class Initialized
DEBUG - 2021-12-10 14:38:34 --> Encrypt Class Initialized
DEBUG - 2021-12-10 14:38:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-10 14:38:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-10 14:38:34 --> Email Class Initialized
INFO - 2021-12-10 14:38:34 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-10 14:38:34 --> Calendar Class Initialized
INFO - 2021-12-10 14:38:34 --> Model "Login_model" initialized
INFO - 2021-12-10 14:38:34 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-10 14:38:34 --> Final output sent to browser
DEBUG - 2021-12-10 14:38:34 --> Total execution time: 0.0581
ERROR - 2021-12-10 14:51:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-10 14:51:31 --> Config Class Initialized
INFO - 2021-12-10 14:51:31 --> Hooks Class Initialized
DEBUG - 2021-12-10 14:51:31 --> UTF-8 Support Enabled
INFO - 2021-12-10 14:51:31 --> Utf8 Class Initialized
INFO - 2021-12-10 14:51:31 --> URI Class Initialized
DEBUG - 2021-12-10 14:51:31 --> No URI present. Default controller set.
INFO - 2021-12-10 14:51:31 --> Router Class Initialized
INFO - 2021-12-10 14:51:31 --> Output Class Initialized
INFO - 2021-12-10 14:51:31 --> Security Class Initialized
DEBUG - 2021-12-10 14:51:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 14:51:31 --> Input Class Initialized
INFO - 2021-12-10 14:51:31 --> Language Class Initialized
INFO - 2021-12-10 14:51:31 --> Loader Class Initialized
INFO - 2021-12-10 14:51:31 --> Helper loaded: url_helper
INFO - 2021-12-10 14:51:31 --> Helper loaded: form_helper
INFO - 2021-12-10 14:51:31 --> Helper loaded: common_helper
INFO - 2021-12-10 14:51:31 --> Database Driver Class Initialized
DEBUG - 2021-12-10 14:51:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 14:51:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 14:51:31 --> Controller Class Initialized
INFO - 2021-12-10 14:51:31 --> Form Validation Class Initialized
DEBUG - 2021-12-10 14:51:31 --> Encrypt Class Initialized
DEBUG - 2021-12-10 14:51:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-10 14:51:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-10 14:51:31 --> Email Class Initialized
INFO - 2021-12-10 14:51:31 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-10 14:51:31 --> Calendar Class Initialized
INFO - 2021-12-10 14:51:31 --> Model "Login_model" initialized
INFO - 2021-12-10 14:51:31 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-10 14:51:31 --> Final output sent to browser
DEBUG - 2021-12-10 14:51:31 --> Total execution time: 0.0388
ERROR - 2021-12-10 14:58:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-10 14:58:31 --> Config Class Initialized
INFO - 2021-12-10 14:58:31 --> Hooks Class Initialized
DEBUG - 2021-12-10 14:58:31 --> UTF-8 Support Enabled
INFO - 2021-12-10 14:58:31 --> Utf8 Class Initialized
INFO - 2021-12-10 14:58:31 --> URI Class Initialized
INFO - 2021-12-10 14:58:31 --> Router Class Initialized
INFO - 2021-12-10 14:58:31 --> Output Class Initialized
INFO - 2021-12-10 14:58:31 --> Security Class Initialized
DEBUG - 2021-12-10 14:58:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 14:58:31 --> Input Class Initialized
INFO - 2021-12-10 14:58:31 --> Language Class Initialized
ERROR - 2021-12-10 14:58:31 --> 404 Page Not Found: Humanstxt/index
ERROR - 2021-12-10 14:58:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-10 14:58:32 --> Config Class Initialized
INFO - 2021-12-10 14:58:32 --> Hooks Class Initialized
DEBUG - 2021-12-10 14:58:32 --> UTF-8 Support Enabled
INFO - 2021-12-10 14:58:32 --> Utf8 Class Initialized
INFO - 2021-12-10 14:58:32 --> URI Class Initialized
INFO - 2021-12-10 14:58:32 --> Router Class Initialized
INFO - 2021-12-10 14:58:32 --> Output Class Initialized
INFO - 2021-12-10 14:58:32 --> Security Class Initialized
DEBUG - 2021-12-10 14:58:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 14:58:32 --> Input Class Initialized
INFO - 2021-12-10 14:58:32 --> Language Class Initialized
ERROR - 2021-12-10 14:58:32 --> 404 Page Not Found: Adstxt/index
ERROR - 2021-12-10 14:58:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-10 14:58:33 --> Config Class Initialized
INFO - 2021-12-10 14:58:33 --> Hooks Class Initialized
DEBUG - 2021-12-10 14:58:33 --> UTF-8 Support Enabled
INFO - 2021-12-10 14:58:33 --> Utf8 Class Initialized
INFO - 2021-12-10 14:58:33 --> URI Class Initialized
DEBUG - 2021-12-10 14:58:33 --> No URI present. Default controller set.
INFO - 2021-12-10 14:58:33 --> Router Class Initialized
INFO - 2021-12-10 14:58:33 --> Output Class Initialized
INFO - 2021-12-10 14:58:33 --> Security Class Initialized
DEBUG - 2021-12-10 14:58:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 14:58:33 --> Input Class Initialized
INFO - 2021-12-10 14:58:33 --> Language Class Initialized
INFO - 2021-12-10 14:58:33 --> Loader Class Initialized
INFO - 2021-12-10 14:58:33 --> Helper loaded: url_helper
INFO - 2021-12-10 14:58:33 --> Helper loaded: form_helper
INFO - 2021-12-10 14:58:33 --> Helper loaded: common_helper
INFO - 2021-12-10 14:58:33 --> Database Driver Class Initialized
DEBUG - 2021-12-10 14:58:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 14:58:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 14:58:33 --> Controller Class Initialized
INFO - 2021-12-10 14:58:33 --> Form Validation Class Initialized
DEBUG - 2021-12-10 14:58:33 --> Encrypt Class Initialized
DEBUG - 2021-12-10 14:58:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-10 14:58:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-10 14:58:33 --> Email Class Initialized
INFO - 2021-12-10 14:58:33 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-10 14:58:33 --> Calendar Class Initialized
INFO - 2021-12-10 14:58:33 --> Model "Login_model" initialized
INFO - 2021-12-10 14:58:33 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-10 14:58:33 --> Final output sent to browser
DEBUG - 2021-12-10 14:58:33 --> Total execution time: 0.0406
ERROR - 2021-12-10 15:31:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-10 15:31:14 --> Config Class Initialized
INFO - 2021-12-10 15:31:14 --> Hooks Class Initialized
DEBUG - 2021-12-10 15:31:14 --> UTF-8 Support Enabled
INFO - 2021-12-10 15:31:14 --> Utf8 Class Initialized
INFO - 2021-12-10 15:31:14 --> URI Class Initialized
DEBUG - 2021-12-10 15:31:14 --> No URI present. Default controller set.
INFO - 2021-12-10 15:31:14 --> Router Class Initialized
INFO - 2021-12-10 15:31:14 --> Output Class Initialized
INFO - 2021-12-10 15:31:14 --> Security Class Initialized
DEBUG - 2021-12-10 15:31:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 15:31:14 --> Input Class Initialized
INFO - 2021-12-10 15:31:14 --> Language Class Initialized
INFO - 2021-12-10 15:31:14 --> Loader Class Initialized
INFO - 2021-12-10 15:31:14 --> Helper loaded: url_helper
INFO - 2021-12-10 15:31:14 --> Helper loaded: form_helper
INFO - 2021-12-10 15:31:14 --> Helper loaded: common_helper
INFO - 2021-12-10 15:31:14 --> Database Driver Class Initialized
DEBUG - 2021-12-10 15:31:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 15:31:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 15:31:14 --> Controller Class Initialized
INFO - 2021-12-10 15:31:14 --> Form Validation Class Initialized
DEBUG - 2021-12-10 15:31:14 --> Encrypt Class Initialized
DEBUG - 2021-12-10 15:31:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-10 15:31:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-10 15:31:14 --> Email Class Initialized
INFO - 2021-12-10 15:31:14 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-10 15:31:14 --> Calendar Class Initialized
INFO - 2021-12-10 15:31:14 --> Model "Login_model" initialized
INFO - 2021-12-10 15:31:14 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-10 15:31:14 --> Final output sent to browser
DEBUG - 2021-12-10 15:31:14 --> Total execution time: 0.0234
ERROR - 2021-12-10 20:16:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-10 20:16:39 --> Config Class Initialized
INFO - 2021-12-10 20:16:39 --> Hooks Class Initialized
DEBUG - 2021-12-10 20:16:39 --> UTF-8 Support Enabled
INFO - 2021-12-10 20:16:39 --> Utf8 Class Initialized
INFO - 2021-12-10 20:16:39 --> URI Class Initialized
DEBUG - 2021-12-10 20:16:39 --> No URI present. Default controller set.
INFO - 2021-12-10 20:16:39 --> Router Class Initialized
INFO - 2021-12-10 20:16:39 --> Output Class Initialized
INFO - 2021-12-10 20:16:39 --> Security Class Initialized
DEBUG - 2021-12-10 20:16:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 20:16:39 --> Input Class Initialized
INFO - 2021-12-10 20:16:39 --> Language Class Initialized
INFO - 2021-12-10 20:16:39 --> Loader Class Initialized
INFO - 2021-12-10 20:16:39 --> Helper loaded: url_helper
INFO - 2021-12-10 20:16:39 --> Helper loaded: form_helper
INFO - 2021-12-10 20:16:39 --> Helper loaded: common_helper
INFO - 2021-12-10 20:16:39 --> Database Driver Class Initialized
DEBUG - 2021-12-10 20:16:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 20:16:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 20:16:39 --> Controller Class Initialized
INFO - 2021-12-10 20:16:39 --> Form Validation Class Initialized
DEBUG - 2021-12-10 20:16:39 --> Encrypt Class Initialized
DEBUG - 2021-12-10 20:16:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-10 20:16:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-10 20:16:39 --> Email Class Initialized
INFO - 2021-12-10 20:16:39 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-10 20:16:39 --> Calendar Class Initialized
INFO - 2021-12-10 20:16:39 --> Model "Login_model" initialized
INFO - 2021-12-10 20:16:39 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-10 20:16:39 --> Final output sent to browser
DEBUG - 2021-12-10 20:16:39 --> Total execution time: 0.0245
ERROR - 2021-12-10 20:57:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-10 20:57:13 --> Config Class Initialized
INFO - 2021-12-10 20:57:13 --> Hooks Class Initialized
DEBUG - 2021-12-10 20:57:13 --> UTF-8 Support Enabled
INFO - 2021-12-10 20:57:13 --> Utf8 Class Initialized
INFO - 2021-12-10 20:57:13 --> URI Class Initialized
DEBUG - 2021-12-10 20:57:13 --> No URI present. Default controller set.
INFO - 2021-12-10 20:57:13 --> Router Class Initialized
INFO - 2021-12-10 20:57:13 --> Output Class Initialized
INFO - 2021-12-10 20:57:13 --> Security Class Initialized
DEBUG - 2021-12-10 20:57:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-10 20:57:13 --> Input Class Initialized
INFO - 2021-12-10 20:57:13 --> Language Class Initialized
INFO - 2021-12-10 20:57:13 --> Loader Class Initialized
INFO - 2021-12-10 20:57:13 --> Helper loaded: url_helper
INFO - 2021-12-10 20:57:13 --> Helper loaded: form_helper
INFO - 2021-12-10 20:57:13 --> Helper loaded: common_helper
INFO - 2021-12-10 20:57:13 --> Database Driver Class Initialized
DEBUG - 2021-12-10 20:57:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-10 20:57:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-10 20:57:13 --> Controller Class Initialized
INFO - 2021-12-10 20:57:13 --> Form Validation Class Initialized
DEBUG - 2021-12-10 20:57:13 --> Encrypt Class Initialized
DEBUG - 2021-12-10 20:57:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-10 20:57:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-10 20:57:13 --> Email Class Initialized
INFO - 2021-12-10 20:57:13 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-10 20:57:13 --> Calendar Class Initialized
INFO - 2021-12-10 20:57:13 --> Model "Login_model" initialized
INFO - 2021-12-10 20:57:13 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-10 20:57:13 --> Final output sent to browser
DEBUG - 2021-12-10 20:57:13 --> Total execution time: 0.0368
