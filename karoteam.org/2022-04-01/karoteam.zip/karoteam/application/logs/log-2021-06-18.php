<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-06-18 01:31:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-18 01:31:08 --> Config Class Initialized
INFO - 2021-06-18 01:31:08 --> Hooks Class Initialized
DEBUG - 2021-06-18 01:31:08 --> UTF-8 Support Enabled
INFO - 2021-06-18 01:31:08 --> Utf8 Class Initialized
INFO - 2021-06-18 01:31:08 --> URI Class Initialized
DEBUG - 2021-06-18 01:31:08 --> No URI present. Default controller set.
INFO - 2021-06-18 01:31:08 --> Router Class Initialized
INFO - 2021-06-18 01:31:08 --> Output Class Initialized
INFO - 2021-06-18 01:31:08 --> Security Class Initialized
DEBUG - 2021-06-18 01:31:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-18 01:31:08 --> Input Class Initialized
INFO - 2021-06-18 01:31:08 --> Language Class Initialized
INFO - 2021-06-18 01:31:08 --> Loader Class Initialized
INFO - 2021-06-18 01:31:08 --> Helper loaded: url_helper
INFO - 2021-06-18 01:31:08 --> Helper loaded: form_helper
INFO - 2021-06-18 01:31:08 --> Helper loaded: common_helper
INFO - 2021-06-18 01:31:08 --> Database Driver Class Initialized
DEBUG - 2021-06-18 01:31:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-18 01:31:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-18 01:31:08 --> Controller Class Initialized
INFO - 2021-06-18 01:31:08 --> Form Validation Class Initialized
DEBUG - 2021-06-18 01:31:08 --> Encrypt Class Initialized
DEBUG - 2021-06-18 01:31:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-06-18 01:31:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-06-18 01:31:08 --> Email Class Initialized
INFO - 2021-06-18 01:31:08 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-06-18 01:31:08 --> Calendar Class Initialized
INFO - 2021-06-18 01:31:08 --> Model "Login_model" initialized
INFO - 2021-06-18 01:31:08 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-06-18 01:31:08 --> Final output sent to browser
DEBUG - 2021-06-18 01:31:08 --> Total execution time: 0.0371
ERROR - 2021-06-18 04:30:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-18 04:30:51 --> Config Class Initialized
INFO - 2021-06-18 04:30:51 --> Hooks Class Initialized
DEBUG - 2021-06-18 04:30:51 --> UTF-8 Support Enabled
INFO - 2021-06-18 04:30:51 --> Utf8 Class Initialized
INFO - 2021-06-18 04:30:51 --> URI Class Initialized
DEBUG - 2021-06-18 04:30:51 --> No URI present. Default controller set.
INFO - 2021-06-18 04:30:51 --> Router Class Initialized
INFO - 2021-06-18 04:30:51 --> Output Class Initialized
INFO - 2021-06-18 04:30:51 --> Security Class Initialized
DEBUG - 2021-06-18 04:30:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-18 04:30:51 --> Input Class Initialized
INFO - 2021-06-18 04:30:51 --> Language Class Initialized
INFO - 2021-06-18 04:30:51 --> Loader Class Initialized
INFO - 2021-06-18 04:30:51 --> Helper loaded: url_helper
INFO - 2021-06-18 04:30:51 --> Helper loaded: form_helper
INFO - 2021-06-18 04:30:51 --> Helper loaded: common_helper
INFO - 2021-06-18 04:30:51 --> Database Driver Class Initialized
DEBUG - 2021-06-18 04:30:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-18 04:30:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-18 04:30:51 --> Controller Class Initialized
INFO - 2021-06-18 04:30:51 --> Form Validation Class Initialized
DEBUG - 2021-06-18 04:30:51 --> Encrypt Class Initialized
DEBUG - 2021-06-18 04:30:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-06-18 04:30:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-06-18 04:30:51 --> Email Class Initialized
INFO - 2021-06-18 04:30:51 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-06-18 04:30:51 --> Calendar Class Initialized
INFO - 2021-06-18 04:30:51 --> Model "Login_model" initialized
INFO - 2021-06-18 04:30:51 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-06-18 04:30:51 --> Final output sent to browser
DEBUG - 2021-06-18 04:30:51 --> Total execution time: 0.0397
ERROR - 2021-06-18 11:06:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-18 11:06:08 --> Config Class Initialized
INFO - 2021-06-18 11:06:08 --> Hooks Class Initialized
DEBUG - 2021-06-18 11:06:08 --> UTF-8 Support Enabled
INFO - 2021-06-18 11:06:08 --> Utf8 Class Initialized
INFO - 2021-06-18 11:06:08 --> URI Class Initialized
DEBUG - 2021-06-18 11:06:08 --> No URI present. Default controller set.
INFO - 2021-06-18 11:06:08 --> Router Class Initialized
INFO - 2021-06-18 11:06:08 --> Output Class Initialized
INFO - 2021-06-18 11:06:08 --> Security Class Initialized
DEBUG - 2021-06-18 11:06:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-18 11:06:08 --> Input Class Initialized
INFO - 2021-06-18 11:06:08 --> Language Class Initialized
INFO - 2021-06-18 11:06:08 --> Loader Class Initialized
INFO - 2021-06-18 11:06:08 --> Helper loaded: url_helper
INFO - 2021-06-18 11:06:08 --> Helper loaded: form_helper
INFO - 2021-06-18 11:06:08 --> Helper loaded: common_helper
INFO - 2021-06-18 11:06:08 --> Database Driver Class Initialized
DEBUG - 2021-06-18 11:06:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-18 11:06:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-18 11:06:08 --> Controller Class Initialized
INFO - 2021-06-18 11:06:08 --> Form Validation Class Initialized
DEBUG - 2021-06-18 11:06:08 --> Encrypt Class Initialized
DEBUG - 2021-06-18 11:06:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-06-18 11:06:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-06-18 11:06:08 --> Email Class Initialized
INFO - 2021-06-18 11:06:08 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-06-18 11:06:08 --> Calendar Class Initialized
INFO - 2021-06-18 11:06:08 --> Model "Login_model" initialized
INFO - 2021-06-18 11:06:08 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-06-18 11:06:08 --> Final output sent to browser
DEBUG - 2021-06-18 11:06:08 --> Total execution time: 0.0380
ERROR - 2021-06-18 18:10:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-18 18:10:45 --> Config Class Initialized
INFO - 2021-06-18 18:10:45 --> Hooks Class Initialized
DEBUG - 2021-06-18 18:10:45 --> UTF-8 Support Enabled
INFO - 2021-06-18 18:10:45 --> Utf8 Class Initialized
INFO - 2021-06-18 18:10:45 --> URI Class Initialized
DEBUG - 2021-06-18 18:10:45 --> No URI present. Default controller set.
INFO - 2021-06-18 18:10:45 --> Router Class Initialized
INFO - 2021-06-18 18:10:45 --> Output Class Initialized
INFO - 2021-06-18 18:10:45 --> Security Class Initialized
DEBUG - 2021-06-18 18:10:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-18 18:10:45 --> Input Class Initialized
INFO - 2021-06-18 18:10:45 --> Language Class Initialized
INFO - 2021-06-18 18:10:45 --> Loader Class Initialized
INFO - 2021-06-18 18:10:45 --> Helper loaded: url_helper
INFO - 2021-06-18 18:10:45 --> Helper loaded: form_helper
INFO - 2021-06-18 18:10:45 --> Helper loaded: common_helper
INFO - 2021-06-18 18:10:45 --> Database Driver Class Initialized
DEBUG - 2021-06-18 18:10:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-18 18:10:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-18 18:10:45 --> Controller Class Initialized
INFO - 2021-06-18 18:10:45 --> Form Validation Class Initialized
DEBUG - 2021-06-18 18:10:45 --> Encrypt Class Initialized
DEBUG - 2021-06-18 18:10:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-06-18 18:10:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-06-18 18:10:45 --> Email Class Initialized
INFO - 2021-06-18 18:10:45 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-06-18 18:10:45 --> Calendar Class Initialized
INFO - 2021-06-18 18:10:45 --> Model "Login_model" initialized
INFO - 2021-06-18 18:10:45 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-06-18 18:10:45 --> Final output sent to browser
DEBUG - 2021-06-18 18:10:45 --> Total execution time: 0.0359
ERROR - 2021-06-18 20:56:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-18 20:56:14 --> Config Class Initialized
INFO - 2021-06-18 20:56:14 --> Hooks Class Initialized
DEBUG - 2021-06-18 20:56:14 --> UTF-8 Support Enabled
INFO - 2021-06-18 20:56:14 --> Utf8 Class Initialized
INFO - 2021-06-18 20:56:14 --> URI Class Initialized
DEBUG - 2021-06-18 20:56:14 --> No URI present. Default controller set.
INFO - 2021-06-18 20:56:14 --> Router Class Initialized
INFO - 2021-06-18 20:56:14 --> Output Class Initialized
INFO - 2021-06-18 20:56:14 --> Security Class Initialized
DEBUG - 2021-06-18 20:56:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-18 20:56:14 --> Input Class Initialized
INFO - 2021-06-18 20:56:14 --> Language Class Initialized
INFO - 2021-06-18 20:56:14 --> Loader Class Initialized
INFO - 2021-06-18 20:56:14 --> Helper loaded: url_helper
INFO - 2021-06-18 20:56:14 --> Helper loaded: form_helper
INFO - 2021-06-18 20:56:14 --> Helper loaded: common_helper
INFO - 2021-06-18 20:56:14 --> Database Driver Class Initialized
DEBUG - 2021-06-18 20:56:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-18 20:56:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-18 20:56:14 --> Controller Class Initialized
INFO - 2021-06-18 20:56:14 --> Form Validation Class Initialized
DEBUG - 2021-06-18 20:56:14 --> Encrypt Class Initialized
DEBUG - 2021-06-18 20:56:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-06-18 20:56:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-06-18 20:56:14 --> Email Class Initialized
INFO - 2021-06-18 20:56:14 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-06-18 20:56:14 --> Calendar Class Initialized
INFO - 2021-06-18 20:56:14 --> Model "Login_model" initialized
INFO - 2021-06-18 20:56:14 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-06-18 20:56:14 --> Final output sent to browser
DEBUG - 2021-06-18 20:56:14 --> Total execution time: 0.0333
