<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-01-05 01:47:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-05 01:47:00 --> Config Class Initialized
INFO - 2022-01-05 01:47:00 --> Hooks Class Initialized
DEBUG - 2022-01-05 01:47:00 --> UTF-8 Support Enabled
INFO - 2022-01-05 01:47:00 --> Utf8 Class Initialized
INFO - 2022-01-05 01:47:00 --> URI Class Initialized
DEBUG - 2022-01-05 01:47:00 --> No URI present. Default controller set.
INFO - 2022-01-05 01:47:00 --> Router Class Initialized
INFO - 2022-01-05 01:47:00 --> Output Class Initialized
INFO - 2022-01-05 01:47:00 --> Security Class Initialized
DEBUG - 2022-01-05 01:47:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-05 01:47:00 --> Input Class Initialized
INFO - 2022-01-05 01:47:00 --> Language Class Initialized
INFO - 2022-01-05 01:47:00 --> Loader Class Initialized
INFO - 2022-01-05 01:47:00 --> Helper loaded: url_helper
INFO - 2022-01-05 01:47:00 --> Helper loaded: form_helper
INFO - 2022-01-05 01:47:00 --> Helper loaded: common_helper
INFO - 2022-01-05 01:47:00 --> Database Driver Class Initialized
DEBUG - 2022-01-05 01:47:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-05 01:47:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-05 01:47:00 --> Controller Class Initialized
INFO - 2022-01-05 01:47:00 --> Form Validation Class Initialized
DEBUG - 2022-01-05 01:47:00 --> Encrypt Class Initialized
DEBUG - 2022-01-05 01:47:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 01:47:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-05 01:47:00 --> Email Class Initialized
INFO - 2022-01-05 01:47:00 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-05 01:47:00 --> Calendar Class Initialized
INFO - 2022-01-05 01:47:00 --> Model "Login_model" initialized
INFO - 2022-01-05 01:47:00 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-05 01:47:00 --> Final output sent to browser
DEBUG - 2022-01-05 01:47:00 --> Total execution time: 0.0772
ERROR - 2022-01-05 02:04:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-05 02:04:26 --> Config Class Initialized
INFO - 2022-01-05 02:04:26 --> Hooks Class Initialized
DEBUG - 2022-01-05 02:04:26 --> UTF-8 Support Enabled
INFO - 2022-01-05 02:04:26 --> Utf8 Class Initialized
INFO - 2022-01-05 02:04:26 --> URI Class Initialized
INFO - 2022-01-05 02:04:26 --> Router Class Initialized
INFO - 2022-01-05 02:04:26 --> Output Class Initialized
INFO - 2022-01-05 02:04:26 --> Security Class Initialized
DEBUG - 2022-01-05 02:04:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-05 02:04:26 --> Input Class Initialized
INFO - 2022-01-05 02:04:26 --> Language Class Initialized
ERROR - 2022-01-05 02:04:26 --> 404 Page Not Found: Appjs/index
ERROR - 2022-01-05 02:04:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-05 02:04:27 --> Config Class Initialized
INFO - 2022-01-05 02:04:27 --> Hooks Class Initialized
DEBUG - 2022-01-05 02:04:27 --> UTF-8 Support Enabled
INFO - 2022-01-05 02:04:27 --> Utf8 Class Initialized
INFO - 2022-01-05 02:04:27 --> URI Class Initialized
INFO - 2022-01-05 02:04:27 --> Router Class Initialized
INFO - 2022-01-05 02:04:27 --> Output Class Initialized
INFO - 2022-01-05 02:04:27 --> Security Class Initialized
DEBUG - 2022-01-05 02:04:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-05 02:04:27 --> Input Class Initialized
INFO - 2022-01-05 02:04:27 --> Language Class Initialized
ERROR - 2022-01-05 02:04:27 --> 404 Page Not Found: Appjs/index
ERROR - 2022-01-05 09:33:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-05 09:33:59 --> Config Class Initialized
INFO - 2022-01-05 09:33:59 --> Hooks Class Initialized
DEBUG - 2022-01-05 09:33:59 --> UTF-8 Support Enabled
INFO - 2022-01-05 09:33:59 --> Utf8 Class Initialized
INFO - 2022-01-05 09:33:59 --> URI Class Initialized
DEBUG - 2022-01-05 09:33:59 --> No URI present. Default controller set.
INFO - 2022-01-05 09:33:59 --> Router Class Initialized
INFO - 2022-01-05 09:33:59 --> Output Class Initialized
INFO - 2022-01-05 09:33:59 --> Security Class Initialized
DEBUG - 2022-01-05 09:33:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-05 09:33:59 --> Input Class Initialized
INFO - 2022-01-05 09:33:59 --> Language Class Initialized
INFO - 2022-01-05 09:33:59 --> Loader Class Initialized
INFO - 2022-01-05 09:33:59 --> Helper loaded: url_helper
INFO - 2022-01-05 09:33:59 --> Helper loaded: form_helper
INFO - 2022-01-05 09:33:59 --> Helper loaded: common_helper
INFO - 2022-01-05 09:33:59 --> Database Driver Class Initialized
DEBUG - 2022-01-05 09:33:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-05 09:33:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-05 09:33:59 --> Controller Class Initialized
INFO - 2022-01-05 09:33:59 --> Form Validation Class Initialized
DEBUG - 2022-01-05 09:33:59 --> Encrypt Class Initialized
DEBUG - 2022-01-05 09:33:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 09:33:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-05 09:33:59 --> Email Class Initialized
INFO - 2022-01-05 09:33:59 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-05 09:33:59 --> Calendar Class Initialized
INFO - 2022-01-05 09:33:59 --> Model "Login_model" initialized
INFO - 2022-01-05 09:33:59 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-05 09:33:59 --> Final output sent to browser
DEBUG - 2022-01-05 09:33:59 --> Total execution time: 0.0294
ERROR - 2022-01-05 14:18:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-05 14:18:12 --> Config Class Initialized
INFO - 2022-01-05 14:18:12 --> Hooks Class Initialized
DEBUG - 2022-01-05 14:18:12 --> UTF-8 Support Enabled
INFO - 2022-01-05 14:18:12 --> Utf8 Class Initialized
INFO - 2022-01-05 14:18:12 --> URI Class Initialized
DEBUG - 2022-01-05 14:18:12 --> No URI present. Default controller set.
INFO - 2022-01-05 14:18:12 --> Router Class Initialized
INFO - 2022-01-05 14:18:12 --> Output Class Initialized
INFO - 2022-01-05 14:18:12 --> Security Class Initialized
DEBUG - 2022-01-05 14:18:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-05 14:18:12 --> Input Class Initialized
INFO - 2022-01-05 14:18:12 --> Language Class Initialized
INFO - 2022-01-05 14:18:12 --> Loader Class Initialized
INFO - 2022-01-05 14:18:12 --> Helper loaded: url_helper
INFO - 2022-01-05 14:18:12 --> Helper loaded: form_helper
INFO - 2022-01-05 14:18:12 --> Helper loaded: common_helper
INFO - 2022-01-05 14:18:12 --> Database Driver Class Initialized
DEBUG - 2022-01-05 14:18:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-05 14:18:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-05 14:18:12 --> Controller Class Initialized
INFO - 2022-01-05 14:18:12 --> Form Validation Class Initialized
DEBUG - 2022-01-05 14:18:12 --> Encrypt Class Initialized
DEBUG - 2022-01-05 14:18:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 14:18:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-05 14:18:12 --> Email Class Initialized
INFO - 2022-01-05 14:18:12 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-05 14:18:12 --> Calendar Class Initialized
INFO - 2022-01-05 14:18:12 --> Model "Login_model" initialized
INFO - 2022-01-05 14:18:12 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-05 14:18:12 --> Final output sent to browser
DEBUG - 2022-01-05 14:18:12 --> Total execution time: 0.0314
ERROR - 2022-01-05 14:18:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-05 14:18:14 --> Config Class Initialized
INFO - 2022-01-05 14:18:14 --> Hooks Class Initialized
DEBUG - 2022-01-05 14:18:14 --> UTF-8 Support Enabled
INFO - 2022-01-05 14:18:14 --> Utf8 Class Initialized
INFO - 2022-01-05 14:18:14 --> URI Class Initialized
INFO - 2022-01-05 14:18:14 --> Router Class Initialized
INFO - 2022-01-05 14:18:14 --> Output Class Initialized
INFO - 2022-01-05 14:18:14 --> Security Class Initialized
DEBUG - 2022-01-05 14:18:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-05 14:18:14 --> Input Class Initialized
INFO - 2022-01-05 14:18:14 --> Language Class Initialized
ERROR - 2022-01-05 14:18:14 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2022-01-05 14:18:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-05 14:18:22 --> Config Class Initialized
INFO - 2022-01-05 14:18:22 --> Hooks Class Initialized
DEBUG - 2022-01-05 14:18:22 --> UTF-8 Support Enabled
INFO - 2022-01-05 14:18:22 --> Utf8 Class Initialized
INFO - 2022-01-05 14:18:22 --> URI Class Initialized
INFO - 2022-01-05 14:18:22 --> Router Class Initialized
INFO - 2022-01-05 14:18:22 --> Output Class Initialized
INFO - 2022-01-05 14:18:22 --> Security Class Initialized
DEBUG - 2022-01-05 14:18:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-05 14:18:22 --> Input Class Initialized
INFO - 2022-01-05 14:18:22 --> Language Class Initialized
INFO - 2022-01-05 14:18:22 --> Loader Class Initialized
INFO - 2022-01-05 14:18:22 --> Helper loaded: url_helper
INFO - 2022-01-05 14:18:22 --> Helper loaded: form_helper
INFO - 2022-01-05 14:18:22 --> Helper loaded: common_helper
INFO - 2022-01-05 14:18:22 --> Database Driver Class Initialized
DEBUG - 2022-01-05 14:18:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-05 14:18:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-05 14:18:22 --> Controller Class Initialized
INFO - 2022-01-05 14:18:22 --> Form Validation Class Initialized
DEBUG - 2022-01-05 14:18:22 --> Encrypt Class Initialized
DEBUG - 2022-01-05 14:18:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 14:18:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-05 14:18:22 --> Email Class Initialized
INFO - 2022-01-05 14:18:22 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-05 14:18:22 --> Calendar Class Initialized
INFO - 2022-01-05 14:18:22 --> Model "Login_model" initialized
ERROR - 2022-01-05 14:18:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-05 14:18:22 --> Config Class Initialized
INFO - 2022-01-05 14:18:22 --> Hooks Class Initialized
DEBUG - 2022-01-05 14:18:22 --> UTF-8 Support Enabled
INFO - 2022-01-05 14:18:22 --> Utf8 Class Initialized
INFO - 2022-01-05 14:18:22 --> URI Class Initialized
INFO - 2022-01-05 14:18:22 --> Router Class Initialized
INFO - 2022-01-05 14:18:22 --> Output Class Initialized
INFO - 2022-01-05 14:18:22 --> Security Class Initialized
DEBUG - 2022-01-05 14:18:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-05 14:18:22 --> Input Class Initialized
INFO - 2022-01-05 14:18:22 --> Language Class Initialized
INFO - 2022-01-05 14:18:22 --> Loader Class Initialized
INFO - 2022-01-05 14:18:22 --> Helper loaded: url_helper
INFO - 2022-01-05 14:18:22 --> Helper loaded: form_helper
INFO - 2022-01-05 14:18:22 --> Helper loaded: common_helper
INFO - 2022-01-05 14:18:22 --> Database Driver Class Initialized
DEBUG - 2022-01-05 14:18:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-05 14:18:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-05 14:18:22 --> Controller Class Initialized
INFO - 2022-01-05 14:18:22 --> Form Validation Class Initialized
DEBUG - 2022-01-05 14:18:22 --> Encrypt Class Initialized
DEBUG - 2022-01-05 14:18:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 14:18:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-05 14:18:22 --> Email Class Initialized
INFO - 2022-01-05 14:18:22 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-05 14:18:22 --> Calendar Class Initialized
INFO - 2022-01-05 14:18:22 --> Model "Login_model" initialized
ERROR - 2022-01-05 14:18:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-05 14:18:23 --> Config Class Initialized
INFO - 2022-01-05 14:18:23 --> Hooks Class Initialized
DEBUG - 2022-01-05 14:18:23 --> UTF-8 Support Enabled
INFO - 2022-01-05 14:18:23 --> Utf8 Class Initialized
INFO - 2022-01-05 14:18:23 --> URI Class Initialized
DEBUG - 2022-01-05 14:18:23 --> No URI present. Default controller set.
INFO - 2022-01-05 14:18:23 --> Router Class Initialized
INFO - 2022-01-05 14:18:23 --> Output Class Initialized
INFO - 2022-01-05 14:18:23 --> Security Class Initialized
DEBUG - 2022-01-05 14:18:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-05 14:18:23 --> Input Class Initialized
INFO - 2022-01-05 14:18:23 --> Language Class Initialized
INFO - 2022-01-05 14:18:23 --> Loader Class Initialized
INFO - 2022-01-05 14:18:23 --> Helper loaded: url_helper
INFO - 2022-01-05 14:18:23 --> Helper loaded: form_helper
INFO - 2022-01-05 14:18:23 --> Helper loaded: common_helper
INFO - 2022-01-05 14:18:23 --> Database Driver Class Initialized
DEBUG - 2022-01-05 14:18:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-05 14:18:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-05 14:18:23 --> Controller Class Initialized
INFO - 2022-01-05 14:18:23 --> Form Validation Class Initialized
DEBUG - 2022-01-05 14:18:23 --> Encrypt Class Initialized
DEBUG - 2022-01-05 14:18:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 14:18:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-05 14:18:23 --> Email Class Initialized
INFO - 2022-01-05 14:18:23 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-05 14:18:23 --> Calendar Class Initialized
INFO - 2022-01-05 14:18:23 --> Model "Login_model" initialized
INFO - 2022-01-05 14:18:23 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-05 14:18:23 --> Final output sent to browser
DEBUG - 2022-01-05 14:18:23 --> Total execution time: 0.0312
ERROR - 2022-01-05 14:18:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-05 14:18:23 --> Config Class Initialized
INFO - 2022-01-05 14:18:23 --> Hooks Class Initialized
DEBUG - 2022-01-05 14:18:23 --> UTF-8 Support Enabled
INFO - 2022-01-05 14:18:23 --> Utf8 Class Initialized
INFO - 2022-01-05 14:18:23 --> URI Class Initialized
INFO - 2022-01-05 14:18:23 --> Router Class Initialized
INFO - 2022-01-05 14:18:23 --> Output Class Initialized
INFO - 2022-01-05 14:18:23 --> Security Class Initialized
DEBUG - 2022-01-05 14:18:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-05 14:18:23 --> Input Class Initialized
INFO - 2022-01-05 14:18:23 --> Language Class Initialized
INFO - 2022-01-05 14:18:23 --> Loader Class Initialized
INFO - 2022-01-05 14:18:23 --> Helper loaded: url_helper
INFO - 2022-01-05 14:18:23 --> Helper loaded: form_helper
INFO - 2022-01-05 14:18:23 --> Helper loaded: common_helper
INFO - 2022-01-05 14:18:23 --> Database Driver Class Initialized
DEBUG - 2022-01-05 14:18:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-05 14:18:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-05 14:18:23 --> Controller Class Initialized
INFO - 2022-01-05 14:18:23 --> Form Validation Class Initialized
DEBUG - 2022-01-05 14:18:23 --> Encrypt Class Initialized
DEBUG - 2022-01-05 14:18:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 14:18:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-05 14:18:23 --> Email Class Initialized
INFO - 2022-01-05 14:18:23 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-05 14:18:23 --> Calendar Class Initialized
INFO - 2022-01-05 14:18:23 --> Model "Login_model" initialized
INFO - 2022-01-05 14:18:23 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-05 14:18:23 --> Final output sent to browser
DEBUG - 2022-01-05 14:18:23 --> Total execution time: 0.0328
ERROR - 2022-01-05 17:53:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-05 17:53:28 --> Config Class Initialized
INFO - 2022-01-05 17:53:28 --> Hooks Class Initialized
DEBUG - 2022-01-05 17:53:28 --> UTF-8 Support Enabled
INFO - 2022-01-05 17:53:28 --> Utf8 Class Initialized
INFO - 2022-01-05 17:53:28 --> URI Class Initialized
DEBUG - 2022-01-05 17:53:28 --> No URI present. Default controller set.
INFO - 2022-01-05 17:53:28 --> Router Class Initialized
INFO - 2022-01-05 17:53:28 --> Output Class Initialized
INFO - 2022-01-05 17:53:28 --> Security Class Initialized
DEBUG - 2022-01-05 17:53:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-05 17:53:28 --> Input Class Initialized
INFO - 2022-01-05 17:53:28 --> Language Class Initialized
INFO - 2022-01-05 17:53:28 --> Loader Class Initialized
INFO - 2022-01-05 17:53:28 --> Helper loaded: url_helper
INFO - 2022-01-05 17:53:28 --> Helper loaded: form_helper
INFO - 2022-01-05 17:53:28 --> Helper loaded: common_helper
INFO - 2022-01-05 17:53:28 --> Database Driver Class Initialized
DEBUG - 2022-01-05 17:53:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-05 17:53:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-05 17:53:28 --> Controller Class Initialized
INFO - 2022-01-05 17:53:28 --> Form Validation Class Initialized
DEBUG - 2022-01-05 17:53:28 --> Encrypt Class Initialized
DEBUG - 2022-01-05 17:53:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 17:53:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-05 17:53:28 --> Email Class Initialized
INFO - 2022-01-05 17:53:28 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-05 17:53:28 --> Calendar Class Initialized
INFO - 2022-01-05 17:53:28 --> Model "Login_model" initialized
INFO - 2022-01-05 17:53:28 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-05 17:53:28 --> Final output sent to browser
DEBUG - 2022-01-05 17:53:28 --> Total execution time: 0.0230
ERROR - 2022-01-05 19:49:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-05 19:49:54 --> Config Class Initialized
INFO - 2022-01-05 19:49:54 --> Hooks Class Initialized
DEBUG - 2022-01-05 19:49:54 --> UTF-8 Support Enabled
INFO - 2022-01-05 19:49:54 --> Utf8 Class Initialized
INFO - 2022-01-05 19:49:54 --> URI Class Initialized
DEBUG - 2022-01-05 19:49:54 --> No URI present. Default controller set.
INFO - 2022-01-05 19:49:54 --> Router Class Initialized
INFO - 2022-01-05 19:49:54 --> Output Class Initialized
INFO - 2022-01-05 19:49:54 --> Security Class Initialized
DEBUG - 2022-01-05 19:49:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-05 19:49:54 --> Input Class Initialized
INFO - 2022-01-05 19:49:54 --> Language Class Initialized
INFO - 2022-01-05 19:49:54 --> Loader Class Initialized
INFO - 2022-01-05 19:49:54 --> Helper loaded: url_helper
INFO - 2022-01-05 19:49:54 --> Helper loaded: form_helper
INFO - 2022-01-05 19:49:54 --> Helper loaded: common_helper
INFO - 2022-01-05 19:49:54 --> Database Driver Class Initialized
DEBUG - 2022-01-05 19:49:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-05 19:49:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-05 19:49:54 --> Controller Class Initialized
INFO - 2022-01-05 19:49:54 --> Form Validation Class Initialized
DEBUG - 2022-01-05 19:49:54 --> Encrypt Class Initialized
DEBUG - 2022-01-05 19:49:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 19:49:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-05 19:49:54 --> Email Class Initialized
INFO - 2022-01-05 19:49:54 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-05 19:49:54 --> Calendar Class Initialized
INFO - 2022-01-05 19:49:54 --> Model "Login_model" initialized
INFO - 2022-01-05 19:49:54 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-05 19:49:54 --> Final output sent to browser
DEBUG - 2022-01-05 19:49:54 --> Total execution time: 0.0241
