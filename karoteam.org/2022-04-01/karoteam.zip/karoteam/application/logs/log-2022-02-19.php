<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-02-19 00:32:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-19 00:32:03 --> Config Class Initialized
INFO - 2022-02-19 00:32:03 --> Hooks Class Initialized
DEBUG - 2022-02-19 00:32:03 --> UTF-8 Support Enabled
INFO - 2022-02-19 00:32:03 --> Utf8 Class Initialized
INFO - 2022-02-19 00:32:03 --> URI Class Initialized
INFO - 2022-02-19 00:32:03 --> Router Class Initialized
INFO - 2022-02-19 00:32:03 --> Output Class Initialized
INFO - 2022-02-19 00:32:03 --> Security Class Initialized
DEBUG - 2022-02-19 00:32:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-19 00:32:03 --> Input Class Initialized
INFO - 2022-02-19 00:32:03 --> Language Class Initialized
ERROR - 2022-02-19 00:32:03 --> 404 Page Not Found: Humanstxt/index
ERROR - 2022-02-19 00:32:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-19 00:32:03 --> Config Class Initialized
INFO - 2022-02-19 00:32:03 --> Hooks Class Initialized
DEBUG - 2022-02-19 00:32:03 --> UTF-8 Support Enabled
INFO - 2022-02-19 00:32:03 --> Utf8 Class Initialized
INFO - 2022-02-19 00:32:03 --> URI Class Initialized
INFO - 2022-02-19 00:32:03 --> Router Class Initialized
INFO - 2022-02-19 00:32:03 --> Output Class Initialized
INFO - 2022-02-19 00:32:03 --> Security Class Initialized
DEBUG - 2022-02-19 00:32:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-19 00:32:03 --> Input Class Initialized
INFO - 2022-02-19 00:32:03 --> Language Class Initialized
ERROR - 2022-02-19 00:32:03 --> 404 Page Not Found: Adstxt/index
ERROR - 2022-02-19 00:32:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-19 00:32:05 --> Config Class Initialized
INFO - 2022-02-19 00:32:05 --> Hooks Class Initialized
DEBUG - 2022-02-19 00:32:05 --> UTF-8 Support Enabled
INFO - 2022-02-19 00:32:05 --> Utf8 Class Initialized
INFO - 2022-02-19 00:32:05 --> URI Class Initialized
DEBUG - 2022-02-19 00:32:05 --> No URI present. Default controller set.
INFO - 2022-02-19 00:32:05 --> Router Class Initialized
INFO - 2022-02-19 00:32:05 --> Output Class Initialized
INFO - 2022-02-19 00:32:05 --> Security Class Initialized
DEBUG - 2022-02-19 00:32:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-19 00:32:05 --> Input Class Initialized
INFO - 2022-02-19 00:32:05 --> Language Class Initialized
INFO - 2022-02-19 00:32:05 --> Loader Class Initialized
INFO - 2022-02-19 00:32:05 --> Helper loaded: url_helper
INFO - 2022-02-19 00:32:05 --> Helper loaded: form_helper
INFO - 2022-02-19 00:32:05 --> Helper loaded: common_helper
INFO - 2022-02-19 00:32:05 --> Database Driver Class Initialized
DEBUG - 2022-02-19 00:32:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-19 00:32:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-19 00:32:05 --> Controller Class Initialized
INFO - 2022-02-19 00:32:05 --> Form Validation Class Initialized
DEBUG - 2022-02-19 00:32:05 --> Encrypt Class Initialized
DEBUG - 2022-02-19 00:32:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-19 00:32:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-19 00:32:05 --> Email Class Initialized
INFO - 2022-02-19 00:32:05 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-19 00:32:05 --> Calendar Class Initialized
INFO - 2022-02-19 00:32:05 --> Model "Login_model" initialized
INFO - 2022-02-19 00:32:05 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-19 00:32:05 --> Final output sent to browser
DEBUG - 2022-02-19 00:32:05 --> Total execution time: 0.0276
ERROR - 2022-02-19 02:50:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-19 02:50:06 --> Config Class Initialized
INFO - 2022-02-19 02:50:06 --> Hooks Class Initialized
DEBUG - 2022-02-19 02:50:06 --> UTF-8 Support Enabled
INFO - 2022-02-19 02:50:06 --> Utf8 Class Initialized
INFO - 2022-02-19 02:50:06 --> URI Class Initialized
DEBUG - 2022-02-19 02:50:06 --> No URI present. Default controller set.
INFO - 2022-02-19 02:50:06 --> Router Class Initialized
INFO - 2022-02-19 02:50:06 --> Output Class Initialized
INFO - 2022-02-19 02:50:06 --> Security Class Initialized
DEBUG - 2022-02-19 02:50:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-19 02:50:06 --> Input Class Initialized
INFO - 2022-02-19 02:50:06 --> Language Class Initialized
INFO - 2022-02-19 02:50:06 --> Loader Class Initialized
INFO - 2022-02-19 02:50:06 --> Helper loaded: url_helper
INFO - 2022-02-19 02:50:06 --> Helper loaded: form_helper
INFO - 2022-02-19 02:50:06 --> Helper loaded: common_helper
INFO - 2022-02-19 02:50:06 --> Database Driver Class Initialized
DEBUG - 2022-02-19 02:50:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-19 02:50:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-19 02:50:06 --> Controller Class Initialized
INFO - 2022-02-19 02:50:06 --> Form Validation Class Initialized
DEBUG - 2022-02-19 02:50:06 --> Encrypt Class Initialized
DEBUG - 2022-02-19 02:50:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-19 02:50:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-19 02:50:06 --> Email Class Initialized
INFO - 2022-02-19 02:50:06 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-19 02:50:06 --> Calendar Class Initialized
INFO - 2022-02-19 02:50:06 --> Model "Login_model" initialized
INFO - 2022-02-19 02:50:06 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-19 02:50:06 --> Final output sent to browser
DEBUG - 2022-02-19 02:50:06 --> Total execution time: 0.0254
ERROR - 2022-02-19 09:25:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-19 09:25:41 --> Config Class Initialized
INFO - 2022-02-19 09:25:41 --> Hooks Class Initialized
DEBUG - 2022-02-19 09:25:41 --> UTF-8 Support Enabled
INFO - 2022-02-19 09:25:41 --> Utf8 Class Initialized
INFO - 2022-02-19 09:25:41 --> URI Class Initialized
DEBUG - 2022-02-19 09:25:41 --> No URI present. Default controller set.
INFO - 2022-02-19 09:25:41 --> Router Class Initialized
INFO - 2022-02-19 09:25:41 --> Output Class Initialized
INFO - 2022-02-19 09:25:41 --> Security Class Initialized
DEBUG - 2022-02-19 09:25:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-19 09:25:41 --> Input Class Initialized
INFO - 2022-02-19 09:25:41 --> Language Class Initialized
INFO - 2022-02-19 09:25:41 --> Loader Class Initialized
INFO - 2022-02-19 09:25:41 --> Helper loaded: url_helper
INFO - 2022-02-19 09:25:41 --> Helper loaded: form_helper
INFO - 2022-02-19 09:25:41 --> Helper loaded: common_helper
INFO - 2022-02-19 09:25:41 --> Database Driver Class Initialized
DEBUG - 2022-02-19 09:25:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-19 09:25:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-19 09:25:41 --> Controller Class Initialized
INFO - 2022-02-19 09:25:41 --> Form Validation Class Initialized
DEBUG - 2022-02-19 09:25:41 --> Encrypt Class Initialized
DEBUG - 2022-02-19 09:25:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-19 09:25:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-19 09:25:41 --> Email Class Initialized
INFO - 2022-02-19 09:25:41 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-19 09:25:41 --> Calendar Class Initialized
INFO - 2022-02-19 09:25:41 --> Model "Login_model" initialized
INFO - 2022-02-19 09:25:41 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-19 09:25:41 --> Final output sent to browser
DEBUG - 2022-02-19 09:25:41 --> Total execution time: 0.0322
ERROR - 2022-02-19 10:30:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-19 10:30:18 --> Config Class Initialized
INFO - 2022-02-19 10:30:18 --> Hooks Class Initialized
DEBUG - 2022-02-19 10:30:18 --> UTF-8 Support Enabled
INFO - 2022-02-19 10:30:18 --> Utf8 Class Initialized
INFO - 2022-02-19 10:30:18 --> URI Class Initialized
DEBUG - 2022-02-19 10:30:18 --> No URI present. Default controller set.
INFO - 2022-02-19 10:30:18 --> Router Class Initialized
INFO - 2022-02-19 10:30:18 --> Output Class Initialized
INFO - 2022-02-19 10:30:18 --> Security Class Initialized
DEBUG - 2022-02-19 10:30:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-19 10:30:18 --> Input Class Initialized
INFO - 2022-02-19 10:30:18 --> Language Class Initialized
INFO - 2022-02-19 10:30:18 --> Loader Class Initialized
INFO - 2022-02-19 10:30:18 --> Helper loaded: url_helper
INFO - 2022-02-19 10:30:18 --> Helper loaded: form_helper
INFO - 2022-02-19 10:30:18 --> Helper loaded: common_helper
INFO - 2022-02-19 10:30:18 --> Database Driver Class Initialized
DEBUG - 2022-02-19 10:30:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-19 10:30:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-19 10:30:18 --> Controller Class Initialized
INFO - 2022-02-19 10:30:18 --> Form Validation Class Initialized
DEBUG - 2022-02-19 10:30:18 --> Encrypt Class Initialized
DEBUG - 2022-02-19 10:30:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-19 10:30:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-19 10:30:18 --> Email Class Initialized
INFO - 2022-02-19 10:30:18 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-19 10:30:18 --> Calendar Class Initialized
INFO - 2022-02-19 10:30:18 --> Model "Login_model" initialized
INFO - 2022-02-19 10:30:18 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-19 10:30:18 --> Final output sent to browser
DEBUG - 2022-02-19 10:30:18 --> Total execution time: 0.0252
ERROR - 2022-02-19 10:30:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-19 10:30:36 --> Config Class Initialized
INFO - 2022-02-19 10:30:36 --> Hooks Class Initialized
DEBUG - 2022-02-19 10:30:36 --> UTF-8 Support Enabled
INFO - 2022-02-19 10:30:36 --> Utf8 Class Initialized
INFO - 2022-02-19 10:30:36 --> URI Class Initialized
DEBUG - 2022-02-19 10:30:36 --> No URI present. Default controller set.
INFO - 2022-02-19 10:30:36 --> Router Class Initialized
INFO - 2022-02-19 10:30:36 --> Output Class Initialized
INFO - 2022-02-19 10:30:36 --> Security Class Initialized
DEBUG - 2022-02-19 10:30:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-19 10:30:36 --> Input Class Initialized
INFO - 2022-02-19 10:30:36 --> Language Class Initialized
INFO - 2022-02-19 10:30:36 --> Loader Class Initialized
INFO - 2022-02-19 10:30:36 --> Helper loaded: url_helper
INFO - 2022-02-19 10:30:36 --> Helper loaded: form_helper
INFO - 2022-02-19 10:30:36 --> Helper loaded: common_helper
INFO - 2022-02-19 10:30:36 --> Database Driver Class Initialized
DEBUG - 2022-02-19 10:30:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-19 10:30:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-19 10:30:36 --> Controller Class Initialized
INFO - 2022-02-19 10:30:36 --> Form Validation Class Initialized
DEBUG - 2022-02-19 10:30:36 --> Encrypt Class Initialized
DEBUG - 2022-02-19 10:30:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-19 10:30:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-19 10:30:36 --> Email Class Initialized
INFO - 2022-02-19 10:30:36 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-19 10:30:36 --> Calendar Class Initialized
INFO - 2022-02-19 10:30:36 --> Model "Login_model" initialized
INFO - 2022-02-19 10:30:36 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-19 10:30:36 --> Final output sent to browser
DEBUG - 2022-02-19 10:30:36 --> Total execution time: 0.0220
ERROR - 2022-02-19 14:16:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-19 14:16:08 --> Config Class Initialized
INFO - 2022-02-19 14:16:08 --> Hooks Class Initialized
DEBUG - 2022-02-19 14:16:08 --> UTF-8 Support Enabled
INFO - 2022-02-19 14:16:08 --> Utf8 Class Initialized
INFO - 2022-02-19 14:16:08 --> URI Class Initialized
DEBUG - 2022-02-19 14:16:08 --> No URI present. Default controller set.
INFO - 2022-02-19 14:16:08 --> Router Class Initialized
INFO - 2022-02-19 14:16:08 --> Output Class Initialized
INFO - 2022-02-19 14:16:08 --> Security Class Initialized
DEBUG - 2022-02-19 14:16:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-19 14:16:08 --> Input Class Initialized
INFO - 2022-02-19 14:16:08 --> Language Class Initialized
INFO - 2022-02-19 14:16:08 --> Loader Class Initialized
INFO - 2022-02-19 14:16:08 --> Helper loaded: url_helper
INFO - 2022-02-19 14:16:08 --> Helper loaded: form_helper
INFO - 2022-02-19 14:16:08 --> Helper loaded: common_helper
INFO - 2022-02-19 14:16:09 --> Database Driver Class Initialized
DEBUG - 2022-02-19 14:16:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-19 14:16:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-19 14:16:09 --> Controller Class Initialized
INFO - 2022-02-19 14:16:09 --> Form Validation Class Initialized
DEBUG - 2022-02-19 14:16:09 --> Encrypt Class Initialized
DEBUG - 2022-02-19 14:16:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-19 14:16:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-19 14:16:09 --> Email Class Initialized
INFO - 2022-02-19 14:16:09 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-19 14:16:09 --> Calendar Class Initialized
INFO - 2022-02-19 14:16:09 --> Model "Login_model" initialized
INFO - 2022-02-19 14:16:09 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-19 14:16:09 --> Final output sent to browser
DEBUG - 2022-02-19 14:16:09 --> Total execution time: 0.0371
ERROR - 2022-02-19 14:16:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-19 14:16:11 --> Config Class Initialized
INFO - 2022-02-19 14:16:11 --> Hooks Class Initialized
DEBUG - 2022-02-19 14:16:11 --> UTF-8 Support Enabled
INFO - 2022-02-19 14:16:11 --> Utf8 Class Initialized
INFO - 2022-02-19 14:16:11 --> URI Class Initialized
INFO - 2022-02-19 14:16:11 --> Router Class Initialized
INFO - 2022-02-19 14:16:11 --> Output Class Initialized
INFO - 2022-02-19 14:16:11 --> Security Class Initialized
DEBUG - 2022-02-19 14:16:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-19 14:16:11 --> Input Class Initialized
INFO - 2022-02-19 14:16:11 --> Language Class Initialized
ERROR - 2022-02-19 14:16:11 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2022-02-19 14:17:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-19 14:17:28 --> Config Class Initialized
INFO - 2022-02-19 14:17:28 --> Hooks Class Initialized
DEBUG - 2022-02-19 14:17:28 --> UTF-8 Support Enabled
INFO - 2022-02-19 14:17:28 --> Utf8 Class Initialized
INFO - 2022-02-19 14:17:28 --> URI Class Initialized
INFO - 2022-02-19 14:17:28 --> Router Class Initialized
INFO - 2022-02-19 14:17:28 --> Output Class Initialized
INFO - 2022-02-19 14:17:28 --> Security Class Initialized
DEBUG - 2022-02-19 14:17:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-19 14:17:28 --> Input Class Initialized
INFO - 2022-02-19 14:17:28 --> Language Class Initialized
INFO - 2022-02-19 14:17:28 --> Loader Class Initialized
INFO - 2022-02-19 14:17:28 --> Helper loaded: url_helper
INFO - 2022-02-19 14:17:28 --> Helper loaded: form_helper
INFO - 2022-02-19 14:17:28 --> Helper loaded: common_helper
INFO - 2022-02-19 14:17:28 --> Database Driver Class Initialized
DEBUG - 2022-02-19 14:17:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-19 14:17:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-19 14:17:28 --> Controller Class Initialized
INFO - 2022-02-19 14:17:28 --> Form Validation Class Initialized
DEBUG - 2022-02-19 14:17:28 --> Encrypt Class Initialized
DEBUG - 2022-02-19 14:17:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-19 14:17:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-19 14:17:28 --> Email Class Initialized
INFO - 2022-02-19 14:17:28 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-19 14:17:28 --> Calendar Class Initialized
INFO - 2022-02-19 14:17:28 --> Model "Login_model" initialized
ERROR - 2022-02-19 14:17:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-19 14:17:28 --> Config Class Initialized
INFO - 2022-02-19 14:17:28 --> Hooks Class Initialized
DEBUG - 2022-02-19 14:17:28 --> UTF-8 Support Enabled
INFO - 2022-02-19 14:17:28 --> Utf8 Class Initialized
INFO - 2022-02-19 14:17:28 --> URI Class Initialized
INFO - 2022-02-19 14:17:28 --> Router Class Initialized
INFO - 2022-02-19 14:17:28 --> Output Class Initialized
INFO - 2022-02-19 14:17:28 --> Security Class Initialized
DEBUG - 2022-02-19 14:17:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-19 14:17:28 --> Input Class Initialized
INFO - 2022-02-19 14:17:28 --> Language Class Initialized
INFO - 2022-02-19 14:17:28 --> Loader Class Initialized
INFO - 2022-02-19 14:17:28 --> Helper loaded: url_helper
INFO - 2022-02-19 14:17:28 --> Helper loaded: form_helper
INFO - 2022-02-19 14:17:28 --> Helper loaded: common_helper
INFO - 2022-02-19 14:17:28 --> Database Driver Class Initialized
DEBUG - 2022-02-19 14:17:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-19 14:17:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-19 14:17:28 --> Controller Class Initialized
INFO - 2022-02-19 14:17:28 --> Form Validation Class Initialized
DEBUG - 2022-02-19 14:17:28 --> Encrypt Class Initialized
DEBUG - 2022-02-19 14:17:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-19 14:17:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-19 14:17:28 --> Email Class Initialized
INFO - 2022-02-19 14:17:28 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-19 14:17:28 --> Calendar Class Initialized
INFO - 2022-02-19 14:17:28 --> Model "Login_model" initialized
ERROR - 2022-02-19 14:17:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-19 14:17:29 --> Config Class Initialized
INFO - 2022-02-19 14:17:29 --> Hooks Class Initialized
DEBUG - 2022-02-19 14:17:29 --> UTF-8 Support Enabled
INFO - 2022-02-19 14:17:29 --> Utf8 Class Initialized
INFO - 2022-02-19 14:17:29 --> URI Class Initialized
INFO - 2022-02-19 14:17:29 --> Router Class Initialized
INFO - 2022-02-19 14:17:29 --> Output Class Initialized
INFO - 2022-02-19 14:17:29 --> Security Class Initialized
DEBUG - 2022-02-19 14:17:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-19 14:17:29 --> Input Class Initialized
INFO - 2022-02-19 14:17:29 --> Language Class Initialized
INFO - 2022-02-19 14:17:29 --> Loader Class Initialized
INFO - 2022-02-19 14:17:29 --> Helper loaded: url_helper
INFO - 2022-02-19 14:17:29 --> Helper loaded: form_helper
INFO - 2022-02-19 14:17:29 --> Helper loaded: common_helper
INFO - 2022-02-19 14:17:29 --> Database Driver Class Initialized
DEBUG - 2022-02-19 14:17:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-19 14:17:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-19 14:17:29 --> Controller Class Initialized
INFO - 2022-02-19 14:17:29 --> Form Validation Class Initialized
DEBUG - 2022-02-19 14:17:29 --> Encrypt Class Initialized
DEBUG - 2022-02-19 14:17:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-19 14:17:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-19 14:17:29 --> Email Class Initialized
INFO - 2022-02-19 14:17:29 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-19 14:17:29 --> Calendar Class Initialized
INFO - 2022-02-19 14:17:29 --> Model "Login_model" initialized
INFO - 2022-02-19 14:17:29 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-19 14:17:29 --> Final output sent to browser
DEBUG - 2022-02-19 14:17:29 --> Total execution time: 0.0208
ERROR - 2022-02-19 14:17:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-19 14:17:30 --> Config Class Initialized
INFO - 2022-02-19 14:17:30 --> Hooks Class Initialized
DEBUG - 2022-02-19 14:17:30 --> UTF-8 Support Enabled
INFO - 2022-02-19 14:17:30 --> Utf8 Class Initialized
INFO - 2022-02-19 14:17:30 --> URI Class Initialized
DEBUG - 2022-02-19 14:17:30 --> No URI present. Default controller set.
INFO - 2022-02-19 14:17:30 --> Router Class Initialized
INFO - 2022-02-19 14:17:30 --> Output Class Initialized
INFO - 2022-02-19 14:17:30 --> Security Class Initialized
DEBUG - 2022-02-19 14:17:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-19 14:17:30 --> Input Class Initialized
INFO - 2022-02-19 14:17:30 --> Language Class Initialized
INFO - 2022-02-19 14:17:30 --> Loader Class Initialized
INFO - 2022-02-19 14:17:30 --> Helper loaded: url_helper
INFO - 2022-02-19 14:17:30 --> Helper loaded: form_helper
INFO - 2022-02-19 14:17:30 --> Helper loaded: common_helper
INFO - 2022-02-19 14:17:30 --> Database Driver Class Initialized
DEBUG - 2022-02-19 14:17:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-19 14:17:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-19 14:17:30 --> Controller Class Initialized
INFO - 2022-02-19 14:17:30 --> Form Validation Class Initialized
DEBUG - 2022-02-19 14:17:30 --> Encrypt Class Initialized
DEBUG - 2022-02-19 14:17:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-19 14:17:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-19 14:17:30 --> Email Class Initialized
INFO - 2022-02-19 14:17:30 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-19 14:17:30 --> Calendar Class Initialized
INFO - 2022-02-19 14:17:30 --> Model "Login_model" initialized
INFO - 2022-02-19 14:17:30 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-19 14:17:30 --> Final output sent to browser
DEBUG - 2022-02-19 14:17:30 --> Total execution time: 0.0212
ERROR - 2022-02-19 15:43:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-19 15:43:07 --> Config Class Initialized
INFO - 2022-02-19 15:43:07 --> Hooks Class Initialized
DEBUG - 2022-02-19 15:43:07 --> UTF-8 Support Enabled
INFO - 2022-02-19 15:43:07 --> Utf8 Class Initialized
INFO - 2022-02-19 15:43:07 --> URI Class Initialized
DEBUG - 2022-02-19 15:43:07 --> No URI present. Default controller set.
INFO - 2022-02-19 15:43:07 --> Router Class Initialized
INFO - 2022-02-19 15:43:07 --> Output Class Initialized
INFO - 2022-02-19 15:43:07 --> Security Class Initialized
DEBUG - 2022-02-19 15:43:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-19 15:43:07 --> Input Class Initialized
INFO - 2022-02-19 15:43:07 --> Language Class Initialized
INFO - 2022-02-19 15:43:07 --> Loader Class Initialized
INFO - 2022-02-19 15:43:07 --> Helper loaded: url_helper
INFO - 2022-02-19 15:43:07 --> Helper loaded: form_helper
INFO - 2022-02-19 15:43:07 --> Helper loaded: common_helper
INFO - 2022-02-19 15:43:07 --> Database Driver Class Initialized
DEBUG - 2022-02-19 15:43:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-19 15:43:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-19 15:43:07 --> Controller Class Initialized
INFO - 2022-02-19 15:43:07 --> Form Validation Class Initialized
DEBUG - 2022-02-19 15:43:07 --> Encrypt Class Initialized
DEBUG - 2022-02-19 15:43:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-19 15:43:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-19 15:43:07 --> Email Class Initialized
INFO - 2022-02-19 15:43:07 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-19 15:43:07 --> Calendar Class Initialized
INFO - 2022-02-19 15:43:07 --> Model "Login_model" initialized
INFO - 2022-02-19 15:43:07 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-19 15:43:07 --> Final output sent to browser
DEBUG - 2022-02-19 15:43:07 --> Total execution time: 0.0338
ERROR - 2022-02-19 20:42:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-19 20:42:32 --> Config Class Initialized
INFO - 2022-02-19 20:42:32 --> Hooks Class Initialized
DEBUG - 2022-02-19 20:42:32 --> UTF-8 Support Enabled
INFO - 2022-02-19 20:42:32 --> Utf8 Class Initialized
INFO - 2022-02-19 20:42:32 --> URI Class Initialized
DEBUG - 2022-02-19 20:42:32 --> No URI present. Default controller set.
INFO - 2022-02-19 20:42:32 --> Router Class Initialized
INFO - 2022-02-19 20:42:32 --> Output Class Initialized
INFO - 2022-02-19 20:42:32 --> Security Class Initialized
DEBUG - 2022-02-19 20:42:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-19 20:42:32 --> Input Class Initialized
INFO - 2022-02-19 20:42:32 --> Language Class Initialized
INFO - 2022-02-19 20:42:32 --> Loader Class Initialized
INFO - 2022-02-19 20:42:32 --> Helper loaded: url_helper
INFO - 2022-02-19 20:42:32 --> Helper loaded: form_helper
INFO - 2022-02-19 20:42:32 --> Helper loaded: common_helper
INFO - 2022-02-19 20:42:32 --> Database Driver Class Initialized
DEBUG - 2022-02-19 20:42:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-19 20:42:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-19 20:42:32 --> Controller Class Initialized
INFO - 2022-02-19 20:42:32 --> Form Validation Class Initialized
DEBUG - 2022-02-19 20:42:32 --> Encrypt Class Initialized
DEBUG - 2022-02-19 20:42:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-19 20:42:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-19 20:42:32 --> Email Class Initialized
INFO - 2022-02-19 20:42:32 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-19 20:42:32 --> Calendar Class Initialized
INFO - 2022-02-19 20:42:32 --> Model "Login_model" initialized
INFO - 2022-02-19 20:42:32 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-19 20:42:32 --> Final output sent to browser
DEBUG - 2022-02-19 20:42:32 --> Total execution time: 0.0346
