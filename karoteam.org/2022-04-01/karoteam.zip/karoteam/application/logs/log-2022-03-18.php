<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-03-18 00:55:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-18 00:55:00 --> Config Class Initialized
INFO - 2022-03-18 00:55:00 --> Hooks Class Initialized
DEBUG - 2022-03-18 00:55:00 --> UTF-8 Support Enabled
INFO - 2022-03-18 00:55:00 --> Utf8 Class Initialized
INFO - 2022-03-18 00:55:00 --> URI Class Initialized
DEBUG - 2022-03-18 00:55:00 --> No URI present. Default controller set.
INFO - 2022-03-18 00:55:00 --> Router Class Initialized
INFO - 2022-03-18 00:55:00 --> Output Class Initialized
INFO - 2022-03-18 00:55:00 --> Security Class Initialized
DEBUG - 2022-03-18 00:55:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-18 00:55:00 --> Input Class Initialized
INFO - 2022-03-18 00:55:00 --> Language Class Initialized
INFO - 2022-03-18 00:55:00 --> Loader Class Initialized
INFO - 2022-03-18 00:55:00 --> Helper loaded: url_helper
INFO - 2022-03-18 00:55:00 --> Helper loaded: form_helper
INFO - 2022-03-18 00:55:00 --> Helper loaded: common_helper
INFO - 2022-03-18 00:55:00 --> Database Driver Class Initialized
DEBUG - 2022-03-18 00:55:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-18 00:55:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 00:55:00 --> Controller Class Initialized
INFO - 2022-03-18 00:55:00 --> Form Validation Class Initialized
DEBUG - 2022-03-18 00:55:00 --> Encrypt Class Initialized
DEBUG - 2022-03-18 00:55:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 00:55:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-18 00:55:00 --> Email Class Initialized
INFO - 2022-03-18 00:55:00 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-18 00:55:00 --> Calendar Class Initialized
INFO - 2022-03-18 00:55:00 --> Model "Login_model" initialized
INFO - 2022-03-18 00:55:00 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-18 00:55:00 --> Final output sent to browser
DEBUG - 2022-03-18 00:55:00 --> Total execution time: 0.0290
ERROR - 2022-03-18 08:29:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-18 08:29:11 --> Config Class Initialized
INFO - 2022-03-18 08:29:11 --> Hooks Class Initialized
DEBUG - 2022-03-18 08:29:11 --> UTF-8 Support Enabled
INFO - 2022-03-18 08:29:11 --> Utf8 Class Initialized
INFO - 2022-03-18 08:29:11 --> URI Class Initialized
INFO - 2022-03-18 08:29:11 --> Router Class Initialized
INFO - 2022-03-18 08:29:11 --> Output Class Initialized
INFO - 2022-03-18 08:29:11 --> Security Class Initialized
DEBUG - 2022-03-18 08:29:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-18 08:29:11 --> Input Class Initialized
INFO - 2022-03-18 08:29:11 --> Language Class Initialized
ERROR - 2022-03-18 08:29:11 --> 404 Page Not Found: Aws/.credentials
ERROR - 2022-03-18 08:29:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-18 08:29:11 --> Config Class Initialized
INFO - 2022-03-18 08:29:11 --> Hooks Class Initialized
DEBUG - 2022-03-18 08:29:11 --> UTF-8 Support Enabled
INFO - 2022-03-18 08:29:11 --> Utf8 Class Initialized
INFO - 2022-03-18 08:29:11 --> URI Class Initialized
INFO - 2022-03-18 08:29:11 --> Router Class Initialized
INFO - 2022-03-18 08:29:11 --> Output Class Initialized
INFO - 2022-03-18 08:29:11 --> Security Class Initialized
DEBUG - 2022-03-18 08:29:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-18 08:29:11 --> Input Class Initialized
INFO - 2022-03-18 08:29:11 --> Language Class Initialized
ERROR - 2022-03-18 08:29:11 --> 404 Page Not Found: Aws/.credentials
ERROR - 2022-03-18 09:35:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-18 09:35:47 --> Config Class Initialized
INFO - 2022-03-18 09:35:47 --> Hooks Class Initialized
DEBUG - 2022-03-18 09:35:47 --> UTF-8 Support Enabled
INFO - 2022-03-18 09:35:47 --> Utf8 Class Initialized
INFO - 2022-03-18 09:35:47 --> URI Class Initialized
DEBUG - 2022-03-18 09:35:47 --> No URI present. Default controller set.
INFO - 2022-03-18 09:35:47 --> Router Class Initialized
INFO - 2022-03-18 09:35:47 --> Output Class Initialized
INFO - 2022-03-18 09:35:47 --> Security Class Initialized
DEBUG - 2022-03-18 09:35:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-18 09:35:47 --> Input Class Initialized
INFO - 2022-03-18 09:35:47 --> Language Class Initialized
INFO - 2022-03-18 09:35:47 --> Loader Class Initialized
INFO - 2022-03-18 09:35:47 --> Helper loaded: url_helper
INFO - 2022-03-18 09:35:47 --> Helper loaded: form_helper
INFO - 2022-03-18 09:35:47 --> Helper loaded: common_helper
INFO - 2022-03-18 09:35:47 --> Database Driver Class Initialized
DEBUG - 2022-03-18 09:35:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-18 09:35:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 09:35:47 --> Controller Class Initialized
INFO - 2022-03-18 09:35:47 --> Form Validation Class Initialized
DEBUG - 2022-03-18 09:35:47 --> Encrypt Class Initialized
DEBUG - 2022-03-18 09:35:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 09:35:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-18 09:35:47 --> Email Class Initialized
INFO - 2022-03-18 09:35:47 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-18 09:35:47 --> Calendar Class Initialized
INFO - 2022-03-18 09:35:47 --> Model "Login_model" initialized
INFO - 2022-03-18 09:35:47 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-18 09:35:47 --> Final output sent to browser
DEBUG - 2022-03-18 09:35:47 --> Total execution time: 0.0575
ERROR - 2022-03-18 11:12:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-18 11:12:16 --> Config Class Initialized
INFO - 2022-03-18 11:12:16 --> Hooks Class Initialized
DEBUG - 2022-03-18 11:12:16 --> UTF-8 Support Enabled
INFO - 2022-03-18 11:12:16 --> Utf8 Class Initialized
INFO - 2022-03-18 11:12:16 --> URI Class Initialized
DEBUG - 2022-03-18 11:12:16 --> No URI present. Default controller set.
INFO - 2022-03-18 11:12:16 --> Router Class Initialized
INFO - 2022-03-18 11:12:16 --> Output Class Initialized
INFO - 2022-03-18 11:12:16 --> Security Class Initialized
DEBUG - 2022-03-18 11:12:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-18 11:12:16 --> Input Class Initialized
INFO - 2022-03-18 11:12:16 --> Language Class Initialized
INFO - 2022-03-18 11:12:16 --> Loader Class Initialized
INFO - 2022-03-18 11:12:16 --> Helper loaded: url_helper
INFO - 2022-03-18 11:12:16 --> Helper loaded: form_helper
INFO - 2022-03-18 11:12:16 --> Helper loaded: common_helper
INFO - 2022-03-18 11:12:16 --> Database Driver Class Initialized
DEBUG - 2022-03-18 11:12:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-18 11:12:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 11:12:16 --> Controller Class Initialized
INFO - 2022-03-18 11:12:16 --> Form Validation Class Initialized
DEBUG - 2022-03-18 11:12:16 --> Encrypt Class Initialized
DEBUG - 2022-03-18 11:12:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 11:12:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-18 11:12:16 --> Email Class Initialized
INFO - 2022-03-18 11:12:16 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-18 11:12:16 --> Calendar Class Initialized
INFO - 2022-03-18 11:12:16 --> Model "Login_model" initialized
INFO - 2022-03-18 11:12:16 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-18 11:12:16 --> Final output sent to browser
DEBUG - 2022-03-18 11:12:16 --> Total execution time: 0.0443
ERROR - 2022-03-18 13:46:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-18 13:46:23 --> Config Class Initialized
INFO - 2022-03-18 13:46:23 --> Hooks Class Initialized
DEBUG - 2022-03-18 13:46:23 --> UTF-8 Support Enabled
INFO - 2022-03-18 13:46:23 --> Utf8 Class Initialized
INFO - 2022-03-18 13:46:23 --> URI Class Initialized
DEBUG - 2022-03-18 13:46:23 --> No URI present. Default controller set.
INFO - 2022-03-18 13:46:23 --> Router Class Initialized
INFO - 2022-03-18 13:46:23 --> Output Class Initialized
INFO - 2022-03-18 13:46:23 --> Security Class Initialized
DEBUG - 2022-03-18 13:46:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-18 13:46:23 --> Input Class Initialized
INFO - 2022-03-18 13:46:23 --> Language Class Initialized
INFO - 2022-03-18 13:46:23 --> Loader Class Initialized
INFO - 2022-03-18 13:46:23 --> Helper loaded: url_helper
INFO - 2022-03-18 13:46:23 --> Helper loaded: form_helper
INFO - 2022-03-18 13:46:23 --> Helper loaded: common_helper
INFO - 2022-03-18 13:46:23 --> Database Driver Class Initialized
DEBUG - 2022-03-18 13:46:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-18 13:46:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 13:46:23 --> Controller Class Initialized
INFO - 2022-03-18 13:46:23 --> Form Validation Class Initialized
DEBUG - 2022-03-18 13:46:23 --> Encrypt Class Initialized
DEBUG - 2022-03-18 13:46:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 13:46:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-18 13:46:23 --> Email Class Initialized
INFO - 2022-03-18 13:46:23 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-18 13:46:23 --> Calendar Class Initialized
INFO - 2022-03-18 13:46:23 --> Model "Login_model" initialized
INFO - 2022-03-18 13:46:23 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-18 13:46:23 --> Final output sent to browser
DEBUG - 2022-03-18 13:46:23 --> Total execution time: 0.0781
ERROR - 2022-03-18 14:22:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-18 14:22:33 --> Config Class Initialized
INFO - 2022-03-18 14:22:33 --> Hooks Class Initialized
DEBUG - 2022-03-18 14:22:33 --> UTF-8 Support Enabled
INFO - 2022-03-18 14:22:33 --> Utf8 Class Initialized
INFO - 2022-03-18 14:22:33 --> URI Class Initialized
DEBUG - 2022-03-18 14:22:33 --> No URI present. Default controller set.
INFO - 2022-03-18 14:22:33 --> Router Class Initialized
INFO - 2022-03-18 14:22:33 --> Output Class Initialized
INFO - 2022-03-18 14:22:33 --> Security Class Initialized
DEBUG - 2022-03-18 14:22:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-18 14:22:33 --> Input Class Initialized
INFO - 2022-03-18 14:22:33 --> Language Class Initialized
INFO - 2022-03-18 14:22:33 --> Loader Class Initialized
INFO - 2022-03-18 14:22:33 --> Helper loaded: url_helper
INFO - 2022-03-18 14:22:33 --> Helper loaded: form_helper
INFO - 2022-03-18 14:22:33 --> Helper loaded: common_helper
INFO - 2022-03-18 14:22:33 --> Database Driver Class Initialized
DEBUG - 2022-03-18 14:22:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-18 14:22:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 14:22:33 --> Controller Class Initialized
INFO - 2022-03-18 14:22:33 --> Form Validation Class Initialized
DEBUG - 2022-03-18 14:22:33 --> Encrypt Class Initialized
DEBUG - 2022-03-18 14:22:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 14:22:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-18 14:22:33 --> Email Class Initialized
INFO - 2022-03-18 14:22:33 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-18 14:22:33 --> Calendar Class Initialized
INFO - 2022-03-18 14:22:33 --> Model "Login_model" initialized
INFO - 2022-03-18 14:22:33 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-18 14:22:33 --> Final output sent to browser
DEBUG - 2022-03-18 14:22:33 --> Total execution time: 0.0408
ERROR - 2022-03-18 14:22:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-18 14:22:36 --> Config Class Initialized
INFO - 2022-03-18 14:22:36 --> Hooks Class Initialized
DEBUG - 2022-03-18 14:22:36 --> UTF-8 Support Enabled
INFO - 2022-03-18 14:22:36 --> Utf8 Class Initialized
INFO - 2022-03-18 14:22:36 --> URI Class Initialized
INFO - 2022-03-18 14:22:36 --> Router Class Initialized
INFO - 2022-03-18 14:22:36 --> Output Class Initialized
INFO - 2022-03-18 14:22:36 --> Security Class Initialized
DEBUG - 2022-03-18 14:22:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-18 14:22:36 --> Input Class Initialized
INFO - 2022-03-18 14:22:36 --> Language Class Initialized
ERROR - 2022-03-18 14:22:36 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2022-03-18 14:22:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-18 14:22:51 --> Config Class Initialized
INFO - 2022-03-18 14:22:51 --> Hooks Class Initialized
DEBUG - 2022-03-18 14:22:51 --> UTF-8 Support Enabled
INFO - 2022-03-18 14:22:51 --> Utf8 Class Initialized
INFO - 2022-03-18 14:22:51 --> URI Class Initialized
INFO - 2022-03-18 14:22:51 --> Router Class Initialized
INFO - 2022-03-18 14:22:51 --> Output Class Initialized
INFO - 2022-03-18 14:22:51 --> Security Class Initialized
DEBUG - 2022-03-18 14:22:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-18 14:22:51 --> Input Class Initialized
INFO - 2022-03-18 14:22:51 --> Language Class Initialized
INFO - 2022-03-18 14:22:51 --> Loader Class Initialized
INFO - 2022-03-18 14:22:51 --> Helper loaded: url_helper
INFO - 2022-03-18 14:22:51 --> Helper loaded: form_helper
INFO - 2022-03-18 14:22:51 --> Helper loaded: common_helper
INFO - 2022-03-18 14:22:51 --> Database Driver Class Initialized
DEBUG - 2022-03-18 14:22:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-18 14:22:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 14:22:51 --> Controller Class Initialized
INFO - 2022-03-18 14:22:51 --> Form Validation Class Initialized
DEBUG - 2022-03-18 14:22:51 --> Encrypt Class Initialized
DEBUG - 2022-03-18 14:22:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 14:22:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-18 14:22:51 --> Email Class Initialized
INFO - 2022-03-18 14:22:51 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-18 14:22:51 --> Calendar Class Initialized
INFO - 2022-03-18 14:22:51 --> Model "Login_model" initialized
INFO - 2022-03-18 14:22:51 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-18 14:22:51 --> Final output sent to browser
DEBUG - 2022-03-18 14:22:51 --> Total execution time: 0.0882
ERROR - 2022-03-18 14:22:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-18 14:22:52 --> Config Class Initialized
INFO - 2022-03-18 14:22:52 --> Hooks Class Initialized
DEBUG - 2022-03-18 14:22:52 --> UTF-8 Support Enabled
INFO - 2022-03-18 14:22:52 --> Utf8 Class Initialized
INFO - 2022-03-18 14:22:52 --> URI Class Initialized
INFO - 2022-03-18 14:22:52 --> Router Class Initialized
INFO - 2022-03-18 14:22:52 --> Output Class Initialized
INFO - 2022-03-18 14:22:52 --> Security Class Initialized
DEBUG - 2022-03-18 14:22:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-18 14:22:52 --> Input Class Initialized
INFO - 2022-03-18 14:22:52 --> Language Class Initialized
INFO - 2022-03-18 14:22:52 --> Loader Class Initialized
INFO - 2022-03-18 14:22:52 --> Helper loaded: url_helper
INFO - 2022-03-18 14:22:52 --> Helper loaded: form_helper
INFO - 2022-03-18 14:22:52 --> Helper loaded: common_helper
INFO - 2022-03-18 14:22:52 --> Database Driver Class Initialized
DEBUG - 2022-03-18 14:22:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-18 14:22:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 14:22:52 --> Controller Class Initialized
INFO - 2022-03-18 14:22:52 --> Form Validation Class Initialized
DEBUG - 2022-03-18 14:22:52 --> Encrypt Class Initialized
DEBUG - 2022-03-18 14:22:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 14:22:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-18 14:22:52 --> Email Class Initialized
INFO - 2022-03-18 14:22:52 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-18 14:22:52 --> Calendar Class Initialized
INFO - 2022-03-18 14:22:52 --> Model "Login_model" initialized
ERROR - 2022-03-18 14:22:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-18 14:22:53 --> Config Class Initialized
INFO - 2022-03-18 14:22:53 --> Hooks Class Initialized
DEBUG - 2022-03-18 14:22:53 --> UTF-8 Support Enabled
INFO - 2022-03-18 14:22:53 --> Utf8 Class Initialized
INFO - 2022-03-18 14:22:53 --> URI Class Initialized
INFO - 2022-03-18 14:22:53 --> Router Class Initialized
INFO - 2022-03-18 14:22:53 --> Output Class Initialized
INFO - 2022-03-18 14:22:53 --> Security Class Initialized
DEBUG - 2022-03-18 14:22:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-18 14:22:53 --> Input Class Initialized
INFO - 2022-03-18 14:22:53 --> Language Class Initialized
INFO - 2022-03-18 14:22:53 --> Loader Class Initialized
INFO - 2022-03-18 14:22:53 --> Helper loaded: url_helper
INFO - 2022-03-18 14:22:53 --> Helper loaded: form_helper
INFO - 2022-03-18 14:22:53 --> Helper loaded: common_helper
INFO - 2022-03-18 14:22:53 --> Database Driver Class Initialized
DEBUG - 2022-03-18 14:22:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-18 14:22:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 14:22:53 --> Controller Class Initialized
INFO - 2022-03-18 14:22:53 --> Form Validation Class Initialized
DEBUG - 2022-03-18 14:22:53 --> Encrypt Class Initialized
DEBUG - 2022-03-18 14:22:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 14:22:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-18 14:22:53 --> Email Class Initialized
INFO - 2022-03-18 14:22:53 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-18 14:22:53 --> Calendar Class Initialized
INFO - 2022-03-18 14:22:53 --> Model "Login_model" initialized
ERROR - 2022-03-18 14:22:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-18 14:22:56 --> Config Class Initialized
INFO - 2022-03-18 14:22:56 --> Hooks Class Initialized
DEBUG - 2022-03-18 14:22:56 --> UTF-8 Support Enabled
INFO - 2022-03-18 14:22:56 --> Utf8 Class Initialized
INFO - 2022-03-18 14:22:56 --> URI Class Initialized
DEBUG - 2022-03-18 14:22:56 --> No URI present. Default controller set.
INFO - 2022-03-18 14:22:56 --> Router Class Initialized
INFO - 2022-03-18 14:22:56 --> Output Class Initialized
INFO - 2022-03-18 14:22:56 --> Security Class Initialized
DEBUG - 2022-03-18 14:22:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-18 14:22:56 --> Input Class Initialized
INFO - 2022-03-18 14:22:56 --> Language Class Initialized
INFO - 2022-03-18 14:22:56 --> Loader Class Initialized
INFO - 2022-03-18 14:22:56 --> Helper loaded: url_helper
INFO - 2022-03-18 14:22:56 --> Helper loaded: form_helper
INFO - 2022-03-18 14:22:56 --> Helper loaded: common_helper
INFO - 2022-03-18 14:22:56 --> Database Driver Class Initialized
DEBUG - 2022-03-18 14:22:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-18 14:22:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 14:22:56 --> Controller Class Initialized
INFO - 2022-03-18 14:22:56 --> Form Validation Class Initialized
DEBUG - 2022-03-18 14:22:56 --> Encrypt Class Initialized
DEBUG - 2022-03-18 14:22:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 14:22:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-18 14:22:56 --> Email Class Initialized
INFO - 2022-03-18 14:22:56 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-18 14:22:56 --> Calendar Class Initialized
INFO - 2022-03-18 14:22:56 --> Model "Login_model" initialized
INFO - 2022-03-18 14:22:56 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-18 14:22:56 --> Final output sent to browser
DEBUG - 2022-03-18 14:22:56 --> Total execution time: 0.1299
ERROR - 2022-03-18 16:28:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-18 16:28:47 --> Config Class Initialized
INFO - 2022-03-18 16:28:47 --> Hooks Class Initialized
DEBUG - 2022-03-18 16:28:47 --> UTF-8 Support Enabled
INFO - 2022-03-18 16:28:47 --> Utf8 Class Initialized
INFO - 2022-03-18 16:28:47 --> URI Class Initialized
DEBUG - 2022-03-18 16:28:47 --> No URI present. Default controller set.
INFO - 2022-03-18 16:28:47 --> Router Class Initialized
INFO - 2022-03-18 16:28:47 --> Output Class Initialized
INFO - 2022-03-18 16:28:47 --> Security Class Initialized
DEBUG - 2022-03-18 16:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-18 16:28:47 --> Input Class Initialized
INFO - 2022-03-18 16:28:47 --> Language Class Initialized
INFO - 2022-03-18 16:28:47 --> Loader Class Initialized
INFO - 2022-03-18 16:28:47 --> Helper loaded: url_helper
INFO - 2022-03-18 16:28:47 --> Helper loaded: form_helper
INFO - 2022-03-18 16:28:47 --> Helper loaded: common_helper
INFO - 2022-03-18 16:28:47 --> Database Driver Class Initialized
DEBUG - 2022-03-18 16:28:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-18 16:28:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 16:28:47 --> Controller Class Initialized
INFO - 2022-03-18 16:28:47 --> Form Validation Class Initialized
DEBUG - 2022-03-18 16:28:47 --> Encrypt Class Initialized
DEBUG - 2022-03-18 16:28:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 16:28:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-18 16:28:47 --> Email Class Initialized
INFO - 2022-03-18 16:28:47 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-18 16:28:47 --> Calendar Class Initialized
INFO - 2022-03-18 16:28:47 --> Model "Login_model" initialized
INFO - 2022-03-18 16:28:47 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-18 16:28:47 --> Final output sent to browser
DEBUG - 2022-03-18 16:28:47 --> Total execution time: 0.1022
ERROR - 2022-03-18 16:56:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-18 16:56:05 --> Config Class Initialized
INFO - 2022-03-18 16:56:05 --> Hooks Class Initialized
DEBUG - 2022-03-18 16:56:05 --> UTF-8 Support Enabled
INFO - 2022-03-18 16:56:05 --> Utf8 Class Initialized
INFO - 2022-03-18 16:56:05 --> URI Class Initialized
DEBUG - 2022-03-18 16:56:05 --> No URI present. Default controller set.
INFO - 2022-03-18 16:56:05 --> Router Class Initialized
INFO - 2022-03-18 16:56:05 --> Output Class Initialized
INFO - 2022-03-18 16:56:05 --> Security Class Initialized
DEBUG - 2022-03-18 16:56:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-18 16:56:05 --> Input Class Initialized
INFO - 2022-03-18 16:56:05 --> Language Class Initialized
INFO - 2022-03-18 16:56:05 --> Loader Class Initialized
INFO - 2022-03-18 16:56:05 --> Helper loaded: url_helper
INFO - 2022-03-18 16:56:05 --> Helper loaded: form_helper
INFO - 2022-03-18 16:56:05 --> Helper loaded: common_helper
INFO - 2022-03-18 16:56:05 --> Database Driver Class Initialized
DEBUG - 2022-03-18 16:56:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-18 16:56:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 16:56:05 --> Controller Class Initialized
INFO - 2022-03-18 16:56:05 --> Form Validation Class Initialized
DEBUG - 2022-03-18 16:56:05 --> Encrypt Class Initialized
DEBUG - 2022-03-18 16:56:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 16:56:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-18 16:56:05 --> Email Class Initialized
INFO - 2022-03-18 16:56:05 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-18 16:56:05 --> Calendar Class Initialized
INFO - 2022-03-18 16:56:05 --> Model "Login_model" initialized
INFO - 2022-03-18 16:56:05 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-18 16:56:05 --> Final output sent to browser
DEBUG - 2022-03-18 16:56:05 --> Total execution time: 0.0324
ERROR - 2022-03-18 19:56:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-18 19:56:36 --> Config Class Initialized
INFO - 2022-03-18 19:56:36 --> Hooks Class Initialized
DEBUG - 2022-03-18 19:56:36 --> UTF-8 Support Enabled
INFO - 2022-03-18 19:56:36 --> Utf8 Class Initialized
INFO - 2022-03-18 19:56:36 --> URI Class Initialized
DEBUG - 2022-03-18 19:56:36 --> No URI present. Default controller set.
INFO - 2022-03-18 19:56:36 --> Router Class Initialized
INFO - 2022-03-18 19:56:36 --> Output Class Initialized
INFO - 2022-03-18 19:56:36 --> Security Class Initialized
DEBUG - 2022-03-18 19:56:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-18 19:56:36 --> Input Class Initialized
INFO - 2022-03-18 19:56:36 --> Language Class Initialized
INFO - 2022-03-18 19:56:36 --> Loader Class Initialized
INFO - 2022-03-18 19:56:36 --> Helper loaded: url_helper
INFO - 2022-03-18 19:56:36 --> Helper loaded: form_helper
INFO - 2022-03-18 19:56:36 --> Helper loaded: common_helper
INFO - 2022-03-18 19:56:36 --> Database Driver Class Initialized
DEBUG - 2022-03-18 19:56:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-18 19:56:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-18 19:56:36 --> Controller Class Initialized
INFO - 2022-03-18 19:56:36 --> Form Validation Class Initialized
DEBUG - 2022-03-18 19:56:36 --> Encrypt Class Initialized
DEBUG - 2022-03-18 19:56:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 19:56:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-18 19:56:36 --> Email Class Initialized
INFO - 2022-03-18 19:56:36 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-18 19:56:36 --> Calendar Class Initialized
INFO - 2022-03-18 19:56:36 --> Model "Login_model" initialized
INFO - 2022-03-18 19:56:36 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-18 19:56:36 --> Final output sent to browser
DEBUG - 2022-03-18 19:56:36 --> Total execution time: 0.0400
ERROR - 2022-03-18 21:05:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-18 21:05:44 --> Config Class Initialized
INFO - 2022-03-18 21:05:44 --> Hooks Class Initialized
DEBUG - 2022-03-18 21:05:44 --> UTF-8 Support Enabled
INFO - 2022-03-18 21:05:44 --> Utf8 Class Initialized
INFO - 2022-03-18 21:05:44 --> URI Class Initialized
INFO - 2022-03-18 21:05:44 --> Router Class Initialized
INFO - 2022-03-18 21:05:44 --> Output Class Initialized
INFO - 2022-03-18 21:05:44 --> Security Class Initialized
DEBUG - 2022-03-18 21:05:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-18 21:05:44 --> Input Class Initialized
INFO - 2022-03-18 21:05:44 --> Language Class Initialized
ERROR - 2022-03-18 21:05:44 --> 404 Page Not Found: Class-wp-widget-archivesphp/index
ERROR - 2022-03-18 21:05:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-18 21:05:44 --> Config Class Initialized
INFO - 2022-03-18 21:05:44 --> Hooks Class Initialized
DEBUG - 2022-03-18 21:05:44 --> UTF-8 Support Enabled
INFO - 2022-03-18 21:05:44 --> Utf8 Class Initialized
INFO - 2022-03-18 21:05:44 --> URI Class Initialized
INFO - 2022-03-18 21:05:44 --> Router Class Initialized
INFO - 2022-03-18 21:05:44 --> Output Class Initialized
INFO - 2022-03-18 21:05:44 --> Security Class Initialized
DEBUG - 2022-03-18 21:05:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-18 21:05:44 --> Input Class Initialized
INFO - 2022-03-18 21:05:44 --> Language Class Initialized
ERROR - 2022-03-18 21:05:44 --> 404 Page Not Found: 1indexphp/index
ERROR - 2022-03-18 21:05:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-18 21:05:44 --> Config Class Initialized
INFO - 2022-03-18 21:05:44 --> Hooks Class Initialized
DEBUG - 2022-03-18 21:05:44 --> UTF-8 Support Enabled
INFO - 2022-03-18 21:05:44 --> Utf8 Class Initialized
INFO - 2022-03-18 21:05:44 --> URI Class Initialized
INFO - 2022-03-18 21:05:44 --> Router Class Initialized
INFO - 2022-03-18 21:05:44 --> Output Class Initialized
INFO - 2022-03-18 21:05:44 --> Security Class Initialized
DEBUG - 2022-03-18 21:05:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-18 21:05:44 --> Input Class Initialized
INFO - 2022-03-18 21:05:44 --> Language Class Initialized
ERROR - 2022-03-18 21:05:44 --> 404 Page Not Found: 2indexphp/index
ERROR - 2022-03-18 21:05:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-18 21:05:45 --> Config Class Initialized
INFO - 2022-03-18 21:05:45 --> Hooks Class Initialized
DEBUG - 2022-03-18 21:05:45 --> UTF-8 Support Enabled
INFO - 2022-03-18 21:05:45 --> Utf8 Class Initialized
INFO - 2022-03-18 21:05:45 --> URI Class Initialized
ERROR - 2022-03-18 21:05:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-18 21:05:45 --> Router Class Initialized
INFO - 2022-03-18 21:05:45 --> Config Class Initialized
INFO - 2022-03-18 21:05:45 --> Output Class Initialized
INFO - 2022-03-18 21:05:45 --> Hooks Class Initialized
INFO - 2022-03-18 21:05:45 --> Security Class Initialized
DEBUG - 2022-03-18 21:05:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-18 21:05:45 --> Input Class Initialized
DEBUG - 2022-03-18 21:05:45 --> UTF-8 Support Enabled
INFO - 2022-03-18 21:05:45 --> Utf8 Class Initialized
INFO - 2022-03-18 21:05:45 --> Language Class Initialized
ERROR - 2022-03-18 21:05:45 --> 404 Page Not Found: Adminphp/index
INFO - 2022-03-18 21:05:45 --> URI Class Initialized
INFO - 2022-03-18 21:05:45 --> Router Class Initialized
INFO - 2022-03-18 21:05:45 --> Output Class Initialized
INFO - 2022-03-18 21:05:45 --> Security Class Initialized
DEBUG - 2022-03-18 21:05:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-18 21:05:45 --> Input Class Initialized
INFO - 2022-03-18 21:05:45 --> Language Class Initialized
ERROR - 2022-03-18 21:05:45 --> 404 Page Not Found: 3indexphp/index
