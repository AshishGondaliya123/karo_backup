<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-07-28 03:26:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-28 03:26:38 --> Config Class Initialized
INFO - 2021-07-28 03:26:38 --> Hooks Class Initialized
DEBUG - 2021-07-28 03:26:38 --> UTF-8 Support Enabled
INFO - 2021-07-28 03:26:38 --> Utf8 Class Initialized
INFO - 2021-07-28 03:26:38 --> URI Class Initialized
DEBUG - 2021-07-28 03:26:38 --> No URI present. Default controller set.
INFO - 2021-07-28 03:26:38 --> Router Class Initialized
INFO - 2021-07-28 03:26:38 --> Output Class Initialized
INFO - 2021-07-28 03:26:38 --> Security Class Initialized
DEBUG - 2021-07-28 03:26:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 03:26:38 --> Input Class Initialized
INFO - 2021-07-28 03:26:38 --> Language Class Initialized
INFO - 2021-07-28 03:26:38 --> Loader Class Initialized
INFO - 2021-07-28 03:26:38 --> Helper loaded: url_helper
INFO - 2021-07-28 03:26:38 --> Helper loaded: form_helper
INFO - 2021-07-28 03:26:38 --> Helper loaded: common_helper
INFO - 2021-07-28 03:26:38 --> Database Driver Class Initialized
DEBUG - 2021-07-28 03:26:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 03:26:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 03:26:38 --> Controller Class Initialized
INFO - 2021-07-28 03:26:38 --> Form Validation Class Initialized
DEBUG - 2021-07-28 03:26:38 --> Encrypt Class Initialized
DEBUG - 2021-07-28 03:26:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-07-28 03:26:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-07-28 03:26:38 --> Email Class Initialized
INFO - 2021-07-28 03:26:38 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-07-28 03:26:38 --> Calendar Class Initialized
INFO - 2021-07-28 03:26:38 --> Model "Login_model" initialized
INFO - 2021-07-28 03:26:38 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-07-28 03:26:38 --> Final output sent to browser
DEBUG - 2021-07-28 03:26:38 --> Total execution time: 0.0393
ERROR - 2021-07-28 11:58:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-28 11:58:34 --> Config Class Initialized
INFO - 2021-07-28 11:58:34 --> Hooks Class Initialized
DEBUG - 2021-07-28 11:58:34 --> UTF-8 Support Enabled
INFO - 2021-07-28 11:58:34 --> Utf8 Class Initialized
INFO - 2021-07-28 11:58:34 --> URI Class Initialized
DEBUG - 2021-07-28 11:58:34 --> No URI present. Default controller set.
INFO - 2021-07-28 11:58:34 --> Router Class Initialized
INFO - 2021-07-28 11:58:34 --> Output Class Initialized
INFO - 2021-07-28 11:58:34 --> Security Class Initialized
DEBUG - 2021-07-28 11:58:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 11:58:34 --> Input Class Initialized
INFO - 2021-07-28 11:58:34 --> Language Class Initialized
INFO - 2021-07-28 11:58:34 --> Loader Class Initialized
INFO - 2021-07-28 11:58:34 --> Helper loaded: url_helper
INFO - 2021-07-28 11:58:34 --> Helper loaded: form_helper
INFO - 2021-07-28 11:58:34 --> Helper loaded: common_helper
INFO - 2021-07-28 11:58:34 --> Database Driver Class Initialized
DEBUG - 2021-07-28 11:58:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 11:58:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 11:58:34 --> Controller Class Initialized
INFO - 2021-07-28 11:58:34 --> Form Validation Class Initialized
DEBUG - 2021-07-28 11:58:34 --> Encrypt Class Initialized
DEBUG - 2021-07-28 11:58:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-07-28 11:58:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-07-28 11:58:34 --> Email Class Initialized
INFO - 2021-07-28 11:58:34 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-07-28 11:58:34 --> Calendar Class Initialized
INFO - 2021-07-28 11:58:34 --> Model "Login_model" initialized
INFO - 2021-07-28 11:58:34 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-07-28 11:58:34 --> Final output sent to browser
DEBUG - 2021-07-28 11:58:34 --> Total execution time: 0.1550
ERROR - 2021-07-28 11:59:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-28 11:59:36 --> Config Class Initialized
INFO - 2021-07-28 11:59:36 --> Hooks Class Initialized
DEBUG - 2021-07-28 11:59:36 --> UTF-8 Support Enabled
INFO - 2021-07-28 11:59:36 --> Utf8 Class Initialized
INFO - 2021-07-28 11:59:36 --> URI Class Initialized
DEBUG - 2021-07-28 11:59:36 --> No URI present. Default controller set.
INFO - 2021-07-28 11:59:36 --> Router Class Initialized
INFO - 2021-07-28 11:59:36 --> Output Class Initialized
INFO - 2021-07-28 11:59:36 --> Security Class Initialized
DEBUG - 2021-07-28 11:59:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 11:59:36 --> Input Class Initialized
INFO - 2021-07-28 11:59:36 --> Language Class Initialized
INFO - 2021-07-28 11:59:36 --> Loader Class Initialized
INFO - 2021-07-28 11:59:36 --> Helper loaded: url_helper
INFO - 2021-07-28 11:59:36 --> Helper loaded: form_helper
INFO - 2021-07-28 11:59:36 --> Helper loaded: common_helper
INFO - 2021-07-28 11:59:36 --> Database Driver Class Initialized
DEBUG - 2021-07-28 11:59:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 11:59:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 11:59:36 --> Controller Class Initialized
INFO - 2021-07-28 11:59:36 --> Form Validation Class Initialized
DEBUG - 2021-07-28 11:59:36 --> Encrypt Class Initialized
DEBUG - 2021-07-28 11:59:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-07-28 11:59:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-07-28 11:59:36 --> Email Class Initialized
INFO - 2021-07-28 11:59:36 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-07-28 11:59:36 --> Calendar Class Initialized
INFO - 2021-07-28 11:59:36 --> Model "Login_model" initialized
INFO - 2021-07-28 11:59:36 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-07-28 11:59:36 --> Final output sent to browser
DEBUG - 2021-07-28 11:59:36 --> Total execution time: 0.0187
