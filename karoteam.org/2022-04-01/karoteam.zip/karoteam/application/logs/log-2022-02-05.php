<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-02-05 01:00:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-05 01:00:48 --> Config Class Initialized
INFO - 2022-02-05 01:00:48 --> Hooks Class Initialized
DEBUG - 2022-02-05 01:00:48 --> UTF-8 Support Enabled
INFO - 2022-02-05 01:00:48 --> Utf8 Class Initialized
INFO - 2022-02-05 01:00:48 --> URI Class Initialized
DEBUG - 2022-02-05 01:00:48 --> No URI present. Default controller set.
INFO - 2022-02-05 01:00:48 --> Router Class Initialized
INFO - 2022-02-05 01:00:48 --> Output Class Initialized
INFO - 2022-02-05 01:00:48 --> Security Class Initialized
DEBUG - 2022-02-05 01:00:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-05 01:00:48 --> Input Class Initialized
INFO - 2022-02-05 01:00:48 --> Language Class Initialized
INFO - 2022-02-05 01:00:48 --> Loader Class Initialized
INFO - 2022-02-05 01:00:48 --> Helper loaded: url_helper
INFO - 2022-02-05 01:00:48 --> Helper loaded: form_helper
INFO - 2022-02-05 01:00:48 --> Helper loaded: common_helper
INFO - 2022-02-05 01:00:48 --> Database Driver Class Initialized
DEBUG - 2022-02-05 01:00:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-05 01:00:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-05 01:00:48 --> Controller Class Initialized
INFO - 2022-02-05 01:00:48 --> Form Validation Class Initialized
DEBUG - 2022-02-05 01:00:48 --> Encrypt Class Initialized
DEBUG - 2022-02-05 01:00:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-05 01:00:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-05 01:00:48 --> Email Class Initialized
INFO - 2022-02-05 01:00:48 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-05 01:00:48 --> Calendar Class Initialized
INFO - 2022-02-05 01:00:48 --> Model "Login_model" initialized
INFO - 2022-02-05 01:00:48 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-05 01:00:48 --> Final output sent to browser
DEBUG - 2022-02-05 01:00:48 --> Total execution time: 0.0280
ERROR - 2022-02-05 07:15:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-05 07:15:34 --> Config Class Initialized
INFO - 2022-02-05 07:15:34 --> Hooks Class Initialized
DEBUG - 2022-02-05 07:15:34 --> UTF-8 Support Enabled
INFO - 2022-02-05 07:15:34 --> Utf8 Class Initialized
INFO - 2022-02-05 07:15:34 --> URI Class Initialized
INFO - 2022-02-05 07:15:34 --> Router Class Initialized
INFO - 2022-02-05 07:15:34 --> Output Class Initialized
INFO - 2022-02-05 07:15:34 --> Security Class Initialized
DEBUG - 2022-02-05 07:15:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-05 07:15:34 --> Input Class Initialized
INFO - 2022-02-05 07:15:34 --> Language Class Initialized
ERROR - 2022-02-05 07:15:34 --> 404 Page Not Found: Humanstxt/index
ERROR - 2022-02-05 07:15:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-05 07:15:35 --> Config Class Initialized
INFO - 2022-02-05 07:15:35 --> Hooks Class Initialized
DEBUG - 2022-02-05 07:15:35 --> UTF-8 Support Enabled
INFO - 2022-02-05 07:15:35 --> Utf8 Class Initialized
INFO - 2022-02-05 07:15:35 --> URI Class Initialized
INFO - 2022-02-05 07:15:35 --> Router Class Initialized
INFO - 2022-02-05 07:15:35 --> Output Class Initialized
INFO - 2022-02-05 07:15:35 --> Security Class Initialized
DEBUG - 2022-02-05 07:15:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-05 07:15:35 --> Input Class Initialized
INFO - 2022-02-05 07:15:35 --> Language Class Initialized
ERROR - 2022-02-05 07:15:35 --> 404 Page Not Found: Adstxt/index
ERROR - 2022-02-05 07:15:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-05 07:15:36 --> Config Class Initialized
INFO - 2022-02-05 07:15:36 --> Hooks Class Initialized
DEBUG - 2022-02-05 07:15:36 --> UTF-8 Support Enabled
INFO - 2022-02-05 07:15:36 --> Utf8 Class Initialized
INFO - 2022-02-05 07:15:36 --> URI Class Initialized
DEBUG - 2022-02-05 07:15:36 --> No URI present. Default controller set.
INFO - 2022-02-05 07:15:36 --> Router Class Initialized
INFO - 2022-02-05 07:15:36 --> Output Class Initialized
INFO - 2022-02-05 07:15:36 --> Security Class Initialized
DEBUG - 2022-02-05 07:15:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-05 07:15:36 --> Input Class Initialized
INFO - 2022-02-05 07:15:36 --> Language Class Initialized
INFO - 2022-02-05 07:15:36 --> Loader Class Initialized
INFO - 2022-02-05 07:15:36 --> Helper loaded: url_helper
INFO - 2022-02-05 07:15:36 --> Helper loaded: form_helper
INFO - 2022-02-05 07:15:36 --> Helper loaded: common_helper
INFO - 2022-02-05 07:15:36 --> Database Driver Class Initialized
DEBUG - 2022-02-05 07:15:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-05 07:15:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-05 07:15:36 --> Controller Class Initialized
INFO - 2022-02-05 07:15:36 --> Form Validation Class Initialized
DEBUG - 2022-02-05 07:15:36 --> Encrypt Class Initialized
DEBUG - 2022-02-05 07:15:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-05 07:15:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-05 07:15:36 --> Email Class Initialized
INFO - 2022-02-05 07:15:36 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-05 07:15:36 --> Calendar Class Initialized
INFO - 2022-02-05 07:15:36 --> Model "Login_model" initialized
INFO - 2022-02-05 07:15:36 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-05 07:15:36 --> Final output sent to browser
DEBUG - 2022-02-05 07:15:36 --> Total execution time: 0.0417
ERROR - 2022-02-05 10:23:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-05 10:23:49 --> Config Class Initialized
INFO - 2022-02-05 10:23:49 --> Hooks Class Initialized
DEBUG - 2022-02-05 10:23:49 --> UTF-8 Support Enabled
INFO - 2022-02-05 10:23:49 --> Utf8 Class Initialized
INFO - 2022-02-05 10:23:49 --> URI Class Initialized
DEBUG - 2022-02-05 10:23:49 --> No URI present. Default controller set.
INFO - 2022-02-05 10:23:49 --> Router Class Initialized
INFO - 2022-02-05 10:23:49 --> Output Class Initialized
INFO - 2022-02-05 10:23:49 --> Security Class Initialized
DEBUG - 2022-02-05 10:23:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-05 10:23:49 --> Input Class Initialized
INFO - 2022-02-05 10:23:49 --> Language Class Initialized
INFO - 2022-02-05 10:23:49 --> Loader Class Initialized
INFO - 2022-02-05 10:23:49 --> Helper loaded: url_helper
INFO - 2022-02-05 10:23:49 --> Helper loaded: form_helper
INFO - 2022-02-05 10:23:49 --> Helper loaded: common_helper
INFO - 2022-02-05 10:23:49 --> Database Driver Class Initialized
DEBUG - 2022-02-05 10:23:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-05 10:23:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-05 10:23:49 --> Controller Class Initialized
INFO - 2022-02-05 10:23:49 --> Form Validation Class Initialized
DEBUG - 2022-02-05 10:23:49 --> Encrypt Class Initialized
DEBUG - 2022-02-05 10:23:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-05 10:23:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-05 10:23:49 --> Email Class Initialized
INFO - 2022-02-05 10:23:49 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-05 10:23:49 --> Calendar Class Initialized
INFO - 2022-02-05 10:23:49 --> Model "Login_model" initialized
INFO - 2022-02-05 10:23:49 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-05 10:23:49 --> Final output sent to browser
DEBUG - 2022-02-05 10:23:49 --> Total execution time: 0.0239
ERROR - 2022-02-05 14:19:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-05 14:19:59 --> Config Class Initialized
INFO - 2022-02-05 14:19:59 --> Hooks Class Initialized
DEBUG - 2022-02-05 14:19:59 --> UTF-8 Support Enabled
INFO - 2022-02-05 14:19:59 --> Utf8 Class Initialized
INFO - 2022-02-05 14:19:59 --> URI Class Initialized
DEBUG - 2022-02-05 14:19:59 --> No URI present. Default controller set.
INFO - 2022-02-05 14:19:59 --> Router Class Initialized
INFO - 2022-02-05 14:19:59 --> Output Class Initialized
INFO - 2022-02-05 14:19:59 --> Security Class Initialized
DEBUG - 2022-02-05 14:19:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-05 14:19:59 --> Input Class Initialized
INFO - 2022-02-05 14:19:59 --> Language Class Initialized
INFO - 2022-02-05 14:19:59 --> Loader Class Initialized
INFO - 2022-02-05 14:19:59 --> Helper loaded: url_helper
INFO - 2022-02-05 14:19:59 --> Helper loaded: form_helper
INFO - 2022-02-05 14:19:59 --> Helper loaded: common_helper
INFO - 2022-02-05 14:20:00 --> Database Driver Class Initialized
DEBUG - 2022-02-05 14:20:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-05 14:20:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-05 14:20:00 --> Controller Class Initialized
INFO - 2022-02-05 14:20:00 --> Form Validation Class Initialized
DEBUG - 2022-02-05 14:20:00 --> Encrypt Class Initialized
DEBUG - 2022-02-05 14:20:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-05 14:20:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-05 14:20:00 --> Email Class Initialized
INFO - 2022-02-05 14:20:00 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-05 14:20:00 --> Calendar Class Initialized
INFO - 2022-02-05 14:20:00 --> Model "Login_model" initialized
INFO - 2022-02-05 14:20:00 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-05 14:20:00 --> Final output sent to browser
DEBUG - 2022-02-05 14:20:00 --> Total execution time: 0.0285
ERROR - 2022-02-05 14:20:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-05 14:20:00 --> Config Class Initialized
INFO - 2022-02-05 14:20:00 --> Hooks Class Initialized
DEBUG - 2022-02-05 14:20:00 --> UTF-8 Support Enabled
INFO - 2022-02-05 14:20:00 --> Utf8 Class Initialized
INFO - 2022-02-05 14:20:00 --> URI Class Initialized
INFO - 2022-02-05 14:20:00 --> Router Class Initialized
INFO - 2022-02-05 14:20:00 --> Output Class Initialized
INFO - 2022-02-05 14:20:00 --> Security Class Initialized
DEBUG - 2022-02-05 14:20:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-05 14:20:00 --> Input Class Initialized
INFO - 2022-02-05 14:20:00 --> Language Class Initialized
ERROR - 2022-02-05 14:20:00 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2022-02-05 14:20:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-05 14:20:08 --> Config Class Initialized
INFO - 2022-02-05 14:20:08 --> Hooks Class Initialized
DEBUG - 2022-02-05 14:20:08 --> UTF-8 Support Enabled
INFO - 2022-02-05 14:20:08 --> Utf8 Class Initialized
INFO - 2022-02-05 14:20:08 --> URI Class Initialized
DEBUG - 2022-02-05 14:20:08 --> No URI present. Default controller set.
INFO - 2022-02-05 14:20:08 --> Router Class Initialized
INFO - 2022-02-05 14:20:08 --> Output Class Initialized
INFO - 2022-02-05 14:20:08 --> Security Class Initialized
DEBUG - 2022-02-05 14:20:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-05 14:20:08 --> Input Class Initialized
INFO - 2022-02-05 14:20:08 --> Language Class Initialized
INFO - 2022-02-05 14:20:08 --> Loader Class Initialized
INFO - 2022-02-05 14:20:08 --> Helper loaded: url_helper
INFO - 2022-02-05 14:20:08 --> Helper loaded: form_helper
INFO - 2022-02-05 14:20:08 --> Helper loaded: common_helper
INFO - 2022-02-05 14:20:08 --> Database Driver Class Initialized
DEBUG - 2022-02-05 14:20:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-05 14:20:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-05 14:20:09 --> Controller Class Initialized
INFO - 2022-02-05 14:20:09 --> Form Validation Class Initialized
DEBUG - 2022-02-05 14:20:09 --> Encrypt Class Initialized
DEBUG - 2022-02-05 14:20:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-05 14:20:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-05 14:20:09 --> Email Class Initialized
INFO - 2022-02-05 14:20:09 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-05 14:20:09 --> Calendar Class Initialized
INFO - 2022-02-05 14:20:09 --> Model "Login_model" initialized
INFO - 2022-02-05 14:20:09 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-05 14:20:09 --> Final output sent to browser
DEBUG - 2022-02-05 14:20:09 --> Total execution time: 0.1238
ERROR - 2022-02-05 14:20:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-05 14:20:09 --> Config Class Initialized
INFO - 2022-02-05 14:20:09 --> Hooks Class Initialized
DEBUG - 2022-02-05 14:20:09 --> UTF-8 Support Enabled
INFO - 2022-02-05 14:20:09 --> Utf8 Class Initialized
INFO - 2022-02-05 14:20:09 --> URI Class Initialized
INFO - 2022-02-05 14:20:09 --> Router Class Initialized
INFO - 2022-02-05 14:20:09 --> Output Class Initialized
INFO - 2022-02-05 14:20:09 --> Security Class Initialized
DEBUG - 2022-02-05 14:20:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-05 14:20:09 --> Input Class Initialized
INFO - 2022-02-05 14:20:09 --> Language Class Initialized
INFO - 2022-02-05 14:20:09 --> Loader Class Initialized
INFO - 2022-02-05 14:20:09 --> Helper loaded: url_helper
INFO - 2022-02-05 14:20:09 --> Helper loaded: form_helper
INFO - 2022-02-05 14:20:09 --> Helper loaded: common_helper
INFO - 2022-02-05 14:20:09 --> Database Driver Class Initialized
DEBUG - 2022-02-05 14:20:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-05 14:20:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-05 14:20:09 --> Controller Class Initialized
INFO - 2022-02-05 14:20:09 --> Form Validation Class Initialized
DEBUG - 2022-02-05 14:20:09 --> Encrypt Class Initialized
DEBUG - 2022-02-05 14:20:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-05 14:20:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-05 14:20:09 --> Email Class Initialized
INFO - 2022-02-05 14:20:09 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-05 14:20:09 --> Calendar Class Initialized
INFO - 2022-02-05 14:20:09 --> Model "Login_model" initialized
INFO - 2022-02-05 14:20:09 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-05 14:20:09 --> Final output sent to browser
DEBUG - 2022-02-05 14:20:09 --> Total execution time: 0.0521
ERROR - 2022-02-05 14:20:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-05 14:20:10 --> Config Class Initialized
INFO - 2022-02-05 14:20:10 --> Hooks Class Initialized
DEBUG - 2022-02-05 14:20:10 --> UTF-8 Support Enabled
INFO - 2022-02-05 14:20:10 --> Utf8 Class Initialized
INFO - 2022-02-05 14:20:10 --> URI Class Initialized
INFO - 2022-02-05 14:20:10 --> Router Class Initialized
INFO - 2022-02-05 14:20:10 --> Output Class Initialized
INFO - 2022-02-05 14:20:10 --> Security Class Initialized
DEBUG - 2022-02-05 14:20:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-05 14:20:10 --> Input Class Initialized
INFO - 2022-02-05 14:20:10 --> Language Class Initialized
INFO - 2022-02-05 14:20:10 --> Loader Class Initialized
INFO - 2022-02-05 14:20:10 --> Helper loaded: url_helper
INFO - 2022-02-05 14:20:10 --> Helper loaded: form_helper
INFO - 2022-02-05 14:20:10 --> Helper loaded: common_helper
INFO - 2022-02-05 14:20:10 --> Database Driver Class Initialized
DEBUG - 2022-02-05 14:20:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-05 14:20:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-05 14:20:10 --> Controller Class Initialized
INFO - 2022-02-05 14:20:10 --> Form Validation Class Initialized
DEBUG - 2022-02-05 14:20:10 --> Encrypt Class Initialized
DEBUG - 2022-02-05 14:20:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-05 14:20:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-05 14:20:10 --> Email Class Initialized
INFO - 2022-02-05 14:20:10 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-05 14:20:10 --> Calendar Class Initialized
INFO - 2022-02-05 14:20:10 --> Model "Login_model" initialized
ERROR - 2022-02-05 14:20:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-05 14:20:11 --> Config Class Initialized
INFO - 2022-02-05 14:20:11 --> Hooks Class Initialized
DEBUG - 2022-02-05 14:20:11 --> UTF-8 Support Enabled
INFO - 2022-02-05 14:20:11 --> Utf8 Class Initialized
INFO - 2022-02-05 14:20:11 --> URI Class Initialized
INFO - 2022-02-05 14:20:11 --> Router Class Initialized
INFO - 2022-02-05 14:20:11 --> Output Class Initialized
INFO - 2022-02-05 14:20:11 --> Security Class Initialized
DEBUG - 2022-02-05 14:20:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-05 14:20:11 --> Input Class Initialized
INFO - 2022-02-05 14:20:11 --> Language Class Initialized
INFO - 2022-02-05 14:20:11 --> Loader Class Initialized
INFO - 2022-02-05 14:20:11 --> Helper loaded: url_helper
INFO - 2022-02-05 14:20:11 --> Helper loaded: form_helper
INFO - 2022-02-05 14:20:11 --> Helper loaded: common_helper
INFO - 2022-02-05 14:20:11 --> Database Driver Class Initialized
DEBUG - 2022-02-05 14:20:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-05 14:20:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-05 14:20:11 --> Controller Class Initialized
INFO - 2022-02-05 14:20:11 --> Form Validation Class Initialized
DEBUG - 2022-02-05 14:20:11 --> Encrypt Class Initialized
DEBUG - 2022-02-05 14:20:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-05 14:20:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-05 14:20:11 --> Email Class Initialized
INFO - 2022-02-05 14:20:11 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-05 14:20:11 --> Calendar Class Initialized
INFO - 2022-02-05 14:20:11 --> Model "Login_model" initialized
