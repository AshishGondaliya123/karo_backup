<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-06-19 02:57:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-19 02:57:51 --> Config Class Initialized
INFO - 2021-06-19 02:57:51 --> Hooks Class Initialized
DEBUG - 2021-06-19 02:57:51 --> UTF-8 Support Enabled
INFO - 2021-06-19 02:57:51 --> Utf8 Class Initialized
INFO - 2021-06-19 02:57:51 --> URI Class Initialized
DEBUG - 2021-06-19 02:57:51 --> No URI present. Default controller set.
INFO - 2021-06-19 02:57:51 --> Router Class Initialized
INFO - 2021-06-19 02:57:51 --> Output Class Initialized
INFO - 2021-06-19 02:57:51 --> Security Class Initialized
DEBUG - 2021-06-19 02:57:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-19 02:57:51 --> Input Class Initialized
INFO - 2021-06-19 02:57:51 --> Language Class Initialized
INFO - 2021-06-19 02:57:51 --> Loader Class Initialized
INFO - 2021-06-19 02:57:51 --> Helper loaded: url_helper
INFO - 2021-06-19 02:57:51 --> Helper loaded: form_helper
INFO - 2021-06-19 02:57:51 --> Helper loaded: common_helper
ERROR - 2021-06-19 02:57:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-19 02:57:51 --> Config Class Initialized
INFO - 2021-06-19 02:57:51 --> Hooks Class Initialized
DEBUG - 2021-06-19 02:57:51 --> UTF-8 Support Enabled
INFO - 2021-06-19 02:57:51 --> Utf8 Class Initialized
INFO - 2021-06-19 02:57:51 --> URI Class Initialized
DEBUG - 2021-06-19 02:57:51 --> No URI present. Default controller set.
INFO - 2021-06-19 02:57:51 --> Router Class Initialized
INFO - 2021-06-19 02:57:51 --> Output Class Initialized
INFO - 2021-06-19 02:57:51 --> Security Class Initialized
DEBUG - 2021-06-19 02:57:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-19 02:57:51 --> Input Class Initialized
INFO - 2021-06-19 02:57:51 --> Language Class Initialized
INFO - 2021-06-19 02:57:51 --> Loader Class Initialized
INFO - 2021-06-19 02:57:51 --> Helper loaded: url_helper
INFO - 2021-06-19 02:57:51 --> Helper loaded: form_helper
INFO - 2021-06-19 02:57:51 --> Helper loaded: common_helper
INFO - 2021-06-19 02:57:51 --> Database Driver Class Initialized
INFO - 2021-06-19 02:57:51 --> Database Driver Class Initialized
DEBUG - 2021-06-19 02:57:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-19 02:57:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-19 02:57:51 --> Controller Class Initialized
DEBUG - 2021-06-19 02:57:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-19 02:57:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-19 02:57:51 --> Controller Class Initialized
INFO - 2021-06-19 02:57:51 --> Form Validation Class Initialized
INFO - 2021-06-19 02:57:51 --> Form Validation Class Initialized
DEBUG - 2021-06-19 02:57:51 --> Encrypt Class Initialized
DEBUG - 2021-06-19 02:57:51 --> Encrypt Class Initialized
DEBUG - 2021-06-19 02:57:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-06-19 02:57:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-06-19 02:57:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-06-19 02:57:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-06-19 02:57:51 --> Email Class Initialized
INFO - 2021-06-19 02:57:51 --> Email Class Initialized
INFO - 2021-06-19 02:57:51 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-06-19 02:57:51 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-06-19 02:57:51 --> Calendar Class Initialized
INFO - 2021-06-19 02:57:51 --> Calendar Class Initialized
INFO - 2021-06-19 02:57:51 --> Model "Login_model" initialized
INFO - 2021-06-19 02:57:51 --> Model "Login_model" initialized
INFO - 2021-06-19 02:57:51 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-06-19 02:57:51 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-06-19 02:57:51 --> Final output sent to browser
DEBUG - 2021-06-19 02:57:51 --> Total execution time: 0.0446
INFO - 2021-06-19 02:57:51 --> Final output sent to browser
DEBUG - 2021-06-19 02:57:51 --> Total execution time: 0.0212
ERROR - 2021-06-19 06:00:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-19 06:00:18 --> Config Class Initialized
INFO - 2021-06-19 06:00:18 --> Hooks Class Initialized
DEBUG - 2021-06-19 06:00:18 --> UTF-8 Support Enabled
INFO - 2021-06-19 06:00:18 --> Utf8 Class Initialized
INFO - 2021-06-19 06:00:18 --> URI Class Initialized
DEBUG - 2021-06-19 06:00:18 --> No URI present. Default controller set.
INFO - 2021-06-19 06:00:18 --> Router Class Initialized
INFO - 2021-06-19 06:00:18 --> Output Class Initialized
INFO - 2021-06-19 06:00:18 --> Security Class Initialized
DEBUG - 2021-06-19 06:00:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-19 06:00:18 --> Input Class Initialized
INFO - 2021-06-19 06:00:18 --> Language Class Initialized
INFO - 2021-06-19 06:00:18 --> Loader Class Initialized
INFO - 2021-06-19 06:00:18 --> Helper loaded: url_helper
INFO - 2021-06-19 06:00:18 --> Helper loaded: form_helper
INFO - 2021-06-19 06:00:18 --> Helper loaded: common_helper
INFO - 2021-06-19 06:00:18 --> Database Driver Class Initialized
DEBUG - 2021-06-19 06:00:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-19 06:00:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-19 06:00:18 --> Controller Class Initialized
INFO - 2021-06-19 06:00:18 --> Form Validation Class Initialized
DEBUG - 2021-06-19 06:00:18 --> Encrypt Class Initialized
DEBUG - 2021-06-19 06:00:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-06-19 06:00:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-06-19 06:00:18 --> Email Class Initialized
INFO - 2021-06-19 06:00:18 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-06-19 06:00:18 --> Calendar Class Initialized
INFO - 2021-06-19 06:00:18 --> Model "Login_model" initialized
INFO - 2021-06-19 06:00:18 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-06-19 06:00:18 --> Final output sent to browser
DEBUG - 2021-06-19 06:00:18 --> Total execution time: 0.0455
ERROR - 2021-06-19 10:17:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-19 10:17:42 --> Config Class Initialized
INFO - 2021-06-19 10:17:42 --> Hooks Class Initialized
DEBUG - 2021-06-19 10:17:42 --> UTF-8 Support Enabled
INFO - 2021-06-19 10:17:42 --> Utf8 Class Initialized
INFO - 2021-06-19 10:17:42 --> URI Class Initialized
DEBUG - 2021-06-19 10:17:42 --> No URI present. Default controller set.
INFO - 2021-06-19 10:17:42 --> Router Class Initialized
INFO - 2021-06-19 10:17:42 --> Output Class Initialized
INFO - 2021-06-19 10:17:42 --> Security Class Initialized
DEBUG - 2021-06-19 10:17:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-19 10:17:42 --> Input Class Initialized
INFO - 2021-06-19 10:17:42 --> Language Class Initialized
INFO - 2021-06-19 10:17:42 --> Loader Class Initialized
INFO - 2021-06-19 10:17:42 --> Helper loaded: url_helper
INFO - 2021-06-19 10:17:42 --> Helper loaded: form_helper
INFO - 2021-06-19 10:17:42 --> Helper loaded: common_helper
INFO - 2021-06-19 10:17:42 --> Database Driver Class Initialized
DEBUG - 2021-06-19 10:17:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-19 10:17:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-19 10:17:42 --> Controller Class Initialized
INFO - 2021-06-19 10:17:42 --> Form Validation Class Initialized
DEBUG - 2021-06-19 10:17:42 --> Encrypt Class Initialized
DEBUG - 2021-06-19 10:17:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-06-19 10:17:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-06-19 10:17:42 --> Email Class Initialized
INFO - 2021-06-19 10:17:42 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-06-19 10:17:42 --> Calendar Class Initialized
INFO - 2021-06-19 10:17:42 --> Model "Login_model" initialized
INFO - 2021-06-19 10:17:42 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-06-19 10:17:42 --> Final output sent to browser
DEBUG - 2021-06-19 10:17:42 --> Total execution time: 0.0482
ERROR - 2021-06-19 18:12:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-19 18:12:43 --> Config Class Initialized
INFO - 2021-06-19 18:12:43 --> Hooks Class Initialized
DEBUG - 2021-06-19 18:12:43 --> UTF-8 Support Enabled
INFO - 2021-06-19 18:12:43 --> Utf8 Class Initialized
INFO - 2021-06-19 18:12:43 --> URI Class Initialized
DEBUG - 2021-06-19 18:12:43 --> No URI present. Default controller set.
INFO - 2021-06-19 18:12:43 --> Router Class Initialized
INFO - 2021-06-19 18:12:43 --> Output Class Initialized
INFO - 2021-06-19 18:12:43 --> Security Class Initialized
DEBUG - 2021-06-19 18:12:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-19 18:12:43 --> Input Class Initialized
INFO - 2021-06-19 18:12:43 --> Language Class Initialized
INFO - 2021-06-19 18:12:43 --> Loader Class Initialized
INFO - 2021-06-19 18:12:43 --> Helper loaded: url_helper
INFO - 2021-06-19 18:12:43 --> Helper loaded: form_helper
INFO - 2021-06-19 18:12:43 --> Helper loaded: common_helper
INFO - 2021-06-19 18:12:43 --> Database Driver Class Initialized
DEBUG - 2021-06-19 18:12:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-19 18:12:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-19 18:12:43 --> Controller Class Initialized
INFO - 2021-06-19 18:12:43 --> Form Validation Class Initialized
DEBUG - 2021-06-19 18:12:43 --> Encrypt Class Initialized
DEBUG - 2021-06-19 18:12:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-06-19 18:12:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-06-19 18:12:43 --> Email Class Initialized
INFO - 2021-06-19 18:12:43 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-06-19 18:12:43 --> Calendar Class Initialized
INFO - 2021-06-19 18:12:43 --> Model "Login_model" initialized
INFO - 2021-06-19 18:12:43 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-06-19 18:12:43 --> Final output sent to browser
DEBUG - 2021-06-19 18:12:43 --> Total execution time: 0.0505
