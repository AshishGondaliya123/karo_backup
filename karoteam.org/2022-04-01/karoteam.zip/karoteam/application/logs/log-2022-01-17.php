<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-01-17 01:00:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-17 01:00:59 --> Config Class Initialized
INFO - 2022-01-17 01:00:59 --> Hooks Class Initialized
DEBUG - 2022-01-17 01:00:59 --> UTF-8 Support Enabled
INFO - 2022-01-17 01:00:59 --> Utf8 Class Initialized
INFO - 2022-01-17 01:00:59 --> URI Class Initialized
DEBUG - 2022-01-17 01:00:59 --> No URI present. Default controller set.
INFO - 2022-01-17 01:00:59 --> Router Class Initialized
INFO - 2022-01-17 01:00:59 --> Output Class Initialized
INFO - 2022-01-17 01:00:59 --> Security Class Initialized
DEBUG - 2022-01-17 01:00:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 01:00:59 --> Input Class Initialized
INFO - 2022-01-17 01:00:59 --> Language Class Initialized
INFO - 2022-01-17 01:00:59 --> Loader Class Initialized
INFO - 2022-01-17 01:00:59 --> Helper loaded: url_helper
INFO - 2022-01-17 01:00:59 --> Helper loaded: form_helper
INFO - 2022-01-17 01:00:59 --> Helper loaded: common_helper
INFO - 2022-01-17 01:00:59 --> Database Driver Class Initialized
DEBUG - 2022-01-17 01:00:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 01:00:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 01:00:59 --> Controller Class Initialized
INFO - 2022-01-17 01:00:59 --> Form Validation Class Initialized
DEBUG - 2022-01-17 01:00:59 --> Encrypt Class Initialized
DEBUG - 2022-01-17 01:00:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 01:00:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-17 01:00:59 --> Email Class Initialized
INFO - 2022-01-17 01:00:59 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-17 01:00:59 --> Calendar Class Initialized
INFO - 2022-01-17 01:00:59 --> Model "Login_model" initialized
INFO - 2022-01-17 01:00:59 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-17 01:00:59 --> Final output sent to browser
DEBUG - 2022-01-17 01:00:59 --> Total execution time: 0.0275
ERROR - 2022-01-17 03:45:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-17 03:45:37 --> Config Class Initialized
INFO - 2022-01-17 03:45:37 --> Hooks Class Initialized
DEBUG - 2022-01-17 03:45:37 --> UTF-8 Support Enabled
INFO - 2022-01-17 03:45:37 --> Utf8 Class Initialized
INFO - 2022-01-17 03:45:37 --> URI Class Initialized
DEBUG - 2022-01-17 03:45:37 --> No URI present. Default controller set.
INFO - 2022-01-17 03:45:37 --> Router Class Initialized
INFO - 2022-01-17 03:45:37 --> Output Class Initialized
INFO - 2022-01-17 03:45:37 --> Security Class Initialized
DEBUG - 2022-01-17 03:45:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 03:45:37 --> Input Class Initialized
INFO - 2022-01-17 03:45:37 --> Language Class Initialized
INFO - 2022-01-17 03:45:37 --> Loader Class Initialized
INFO - 2022-01-17 03:45:37 --> Helper loaded: url_helper
INFO - 2022-01-17 03:45:37 --> Helper loaded: form_helper
INFO - 2022-01-17 03:45:37 --> Helper loaded: common_helper
INFO - 2022-01-17 03:45:37 --> Database Driver Class Initialized
DEBUG - 2022-01-17 03:45:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 03:45:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 03:45:37 --> Controller Class Initialized
INFO - 2022-01-17 03:45:37 --> Form Validation Class Initialized
DEBUG - 2022-01-17 03:45:37 --> Encrypt Class Initialized
DEBUG - 2022-01-17 03:45:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 03:45:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-17 03:45:37 --> Email Class Initialized
INFO - 2022-01-17 03:45:37 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-17 03:45:37 --> Calendar Class Initialized
INFO - 2022-01-17 03:45:37 --> Model "Login_model" initialized
INFO - 2022-01-17 03:45:37 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-17 03:45:37 --> Final output sent to browser
DEBUG - 2022-01-17 03:45:37 --> Total execution time: 0.0238
ERROR - 2022-01-17 05:17:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-17 05:17:58 --> Config Class Initialized
INFO - 2022-01-17 05:17:58 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:17:58 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:17:58 --> Utf8 Class Initialized
INFO - 2022-01-17 05:17:58 --> URI Class Initialized
DEBUG - 2022-01-17 05:17:58 --> No URI present. Default controller set.
INFO - 2022-01-17 05:17:58 --> Router Class Initialized
INFO - 2022-01-17 05:17:58 --> Output Class Initialized
INFO - 2022-01-17 05:17:58 --> Security Class Initialized
DEBUG - 2022-01-17 05:17:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:17:58 --> Input Class Initialized
INFO - 2022-01-17 05:17:58 --> Language Class Initialized
INFO - 2022-01-17 05:17:58 --> Loader Class Initialized
INFO - 2022-01-17 05:17:58 --> Helper loaded: url_helper
INFO - 2022-01-17 05:17:58 --> Helper loaded: form_helper
INFO - 2022-01-17 05:17:58 --> Helper loaded: common_helper
INFO - 2022-01-17 05:17:58 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:17:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:17:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:17:58 --> Controller Class Initialized
INFO - 2022-01-17 05:17:58 --> Form Validation Class Initialized
DEBUG - 2022-01-17 05:17:58 --> Encrypt Class Initialized
DEBUG - 2022-01-17 05:17:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 05:17:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-17 05:17:58 --> Email Class Initialized
INFO - 2022-01-17 05:17:58 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-17 05:17:58 --> Calendar Class Initialized
INFO - 2022-01-17 05:17:58 --> Model "Login_model" initialized
INFO - 2022-01-17 05:17:58 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-17 05:17:58 --> Final output sent to browser
DEBUG - 2022-01-17 05:17:58 --> Total execution time: 0.0432
ERROR - 2022-01-17 13:24:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-17 13:24:57 --> Config Class Initialized
INFO - 2022-01-17 13:24:57 --> Hooks Class Initialized
DEBUG - 2022-01-17 13:24:57 --> UTF-8 Support Enabled
INFO - 2022-01-17 13:24:57 --> Utf8 Class Initialized
INFO - 2022-01-17 13:24:57 --> URI Class Initialized
DEBUG - 2022-01-17 13:24:57 --> No URI present. Default controller set.
INFO - 2022-01-17 13:24:57 --> Router Class Initialized
INFO - 2022-01-17 13:24:57 --> Output Class Initialized
INFO - 2022-01-17 13:24:57 --> Security Class Initialized
DEBUG - 2022-01-17 13:24:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 13:24:57 --> Input Class Initialized
INFO - 2022-01-17 13:24:57 --> Language Class Initialized
INFO - 2022-01-17 13:24:57 --> Loader Class Initialized
INFO - 2022-01-17 13:24:57 --> Helper loaded: url_helper
INFO - 2022-01-17 13:24:57 --> Helper loaded: form_helper
INFO - 2022-01-17 13:24:57 --> Helper loaded: common_helper
INFO - 2022-01-17 13:24:57 --> Database Driver Class Initialized
DEBUG - 2022-01-17 13:24:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 13:24:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 13:24:57 --> Controller Class Initialized
INFO - 2022-01-17 13:24:57 --> Form Validation Class Initialized
DEBUG - 2022-01-17 13:24:57 --> Encrypt Class Initialized
DEBUG - 2022-01-17 13:24:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 13:24:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-17 13:24:57 --> Email Class Initialized
INFO - 2022-01-17 13:24:57 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-17 13:24:57 --> Calendar Class Initialized
INFO - 2022-01-17 13:24:57 --> Model "Login_model" initialized
INFO - 2022-01-17 13:24:57 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-17 13:24:57 --> Final output sent to browser
DEBUG - 2022-01-17 13:24:57 --> Total execution time: 0.0874
ERROR - 2022-01-17 14:16:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-17 14:16:23 --> Config Class Initialized
INFO - 2022-01-17 14:16:23 --> Hooks Class Initialized
DEBUG - 2022-01-17 14:16:23 --> UTF-8 Support Enabled
INFO - 2022-01-17 14:16:23 --> Utf8 Class Initialized
INFO - 2022-01-17 14:16:23 --> URI Class Initialized
DEBUG - 2022-01-17 14:16:23 --> No URI present. Default controller set.
INFO - 2022-01-17 14:16:23 --> Router Class Initialized
INFO - 2022-01-17 14:16:23 --> Output Class Initialized
INFO - 2022-01-17 14:16:23 --> Security Class Initialized
DEBUG - 2022-01-17 14:16:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 14:16:23 --> Input Class Initialized
INFO - 2022-01-17 14:16:23 --> Language Class Initialized
INFO - 2022-01-17 14:16:23 --> Loader Class Initialized
INFO - 2022-01-17 14:16:23 --> Helper loaded: url_helper
INFO - 2022-01-17 14:16:23 --> Helper loaded: form_helper
INFO - 2022-01-17 14:16:23 --> Helper loaded: common_helper
INFO - 2022-01-17 14:16:23 --> Database Driver Class Initialized
DEBUG - 2022-01-17 14:16:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 14:16:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 14:16:23 --> Controller Class Initialized
INFO - 2022-01-17 14:16:23 --> Form Validation Class Initialized
DEBUG - 2022-01-17 14:16:23 --> Encrypt Class Initialized
DEBUG - 2022-01-17 14:16:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 14:16:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-17 14:16:23 --> Email Class Initialized
INFO - 2022-01-17 14:16:23 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-17 14:16:23 --> Calendar Class Initialized
INFO - 2022-01-17 14:16:23 --> Model "Login_model" initialized
INFO - 2022-01-17 14:16:23 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-17 14:16:23 --> Final output sent to browser
DEBUG - 2022-01-17 14:16:23 --> Total execution time: 0.0712
ERROR - 2022-01-17 14:16:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-17 14:16:23 --> Config Class Initialized
INFO - 2022-01-17 14:16:23 --> Hooks Class Initialized
DEBUG - 2022-01-17 14:16:23 --> UTF-8 Support Enabled
INFO - 2022-01-17 14:16:23 --> Utf8 Class Initialized
INFO - 2022-01-17 14:16:23 --> URI Class Initialized
INFO - 2022-01-17 14:16:23 --> Router Class Initialized
INFO - 2022-01-17 14:16:23 --> Output Class Initialized
INFO - 2022-01-17 14:16:23 --> Security Class Initialized
DEBUG - 2022-01-17 14:16:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 14:16:23 --> Input Class Initialized
INFO - 2022-01-17 14:16:23 --> Language Class Initialized
ERROR - 2022-01-17 14:16:23 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2022-01-17 14:17:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-17 14:17:28 --> Config Class Initialized
INFO - 2022-01-17 14:17:28 --> Hooks Class Initialized
DEBUG - 2022-01-17 14:17:28 --> UTF-8 Support Enabled
INFO - 2022-01-17 14:17:28 --> Utf8 Class Initialized
INFO - 2022-01-17 14:17:28 --> URI Class Initialized
INFO - 2022-01-17 14:17:28 --> Router Class Initialized
INFO - 2022-01-17 14:17:28 --> Output Class Initialized
INFO - 2022-01-17 14:17:28 --> Security Class Initialized
DEBUG - 2022-01-17 14:17:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 14:17:28 --> Input Class Initialized
INFO - 2022-01-17 14:17:28 --> Language Class Initialized
INFO - 2022-01-17 14:17:28 --> Loader Class Initialized
INFO - 2022-01-17 14:17:28 --> Helper loaded: url_helper
INFO - 2022-01-17 14:17:28 --> Helper loaded: form_helper
INFO - 2022-01-17 14:17:28 --> Helper loaded: common_helper
INFO - 2022-01-17 14:17:28 --> Database Driver Class Initialized
DEBUG - 2022-01-17 14:17:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 14:17:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 14:17:28 --> Controller Class Initialized
INFO - 2022-01-17 14:17:28 --> Form Validation Class Initialized
DEBUG - 2022-01-17 14:17:28 --> Encrypt Class Initialized
DEBUG - 2022-01-17 14:17:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 14:17:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-17 14:17:28 --> Email Class Initialized
INFO - 2022-01-17 14:17:28 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-17 14:17:28 --> Calendar Class Initialized
INFO - 2022-01-17 14:17:28 --> Model "Login_model" initialized
ERROR - 2022-01-17 14:17:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-17 14:17:29 --> Config Class Initialized
INFO - 2022-01-17 14:17:29 --> Hooks Class Initialized
DEBUG - 2022-01-17 14:17:29 --> UTF-8 Support Enabled
INFO - 2022-01-17 14:17:29 --> Utf8 Class Initialized
INFO - 2022-01-17 14:17:29 --> URI Class Initialized
INFO - 2022-01-17 14:17:29 --> Router Class Initialized
INFO - 2022-01-17 14:17:29 --> Output Class Initialized
INFO - 2022-01-17 14:17:29 --> Security Class Initialized
DEBUG - 2022-01-17 14:17:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 14:17:29 --> Input Class Initialized
INFO - 2022-01-17 14:17:29 --> Language Class Initialized
INFO - 2022-01-17 14:17:29 --> Loader Class Initialized
INFO - 2022-01-17 14:17:29 --> Helper loaded: url_helper
INFO - 2022-01-17 14:17:29 --> Helper loaded: form_helper
INFO - 2022-01-17 14:17:29 --> Helper loaded: common_helper
INFO - 2022-01-17 14:17:29 --> Database Driver Class Initialized
DEBUG - 2022-01-17 14:17:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 14:17:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 14:17:29 --> Controller Class Initialized
INFO - 2022-01-17 14:17:29 --> Form Validation Class Initialized
DEBUG - 2022-01-17 14:17:29 --> Encrypt Class Initialized
DEBUG - 2022-01-17 14:17:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 14:17:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-17 14:17:29 --> Email Class Initialized
INFO - 2022-01-17 14:17:29 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-17 14:17:29 --> Calendar Class Initialized
INFO - 2022-01-17 14:17:29 --> Model "Login_model" initialized
ERROR - 2022-01-17 14:17:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-17 14:17:29 --> Config Class Initialized
INFO - 2022-01-17 14:17:29 --> Hooks Class Initialized
DEBUG - 2022-01-17 14:17:29 --> UTF-8 Support Enabled
INFO - 2022-01-17 14:17:29 --> Utf8 Class Initialized
INFO - 2022-01-17 14:17:29 --> URI Class Initialized
INFO - 2022-01-17 14:17:29 --> Router Class Initialized
INFO - 2022-01-17 14:17:29 --> Output Class Initialized
INFO - 2022-01-17 14:17:29 --> Security Class Initialized
DEBUG - 2022-01-17 14:17:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 14:17:29 --> Input Class Initialized
INFO - 2022-01-17 14:17:29 --> Language Class Initialized
INFO - 2022-01-17 14:17:29 --> Loader Class Initialized
INFO - 2022-01-17 14:17:29 --> Helper loaded: url_helper
INFO - 2022-01-17 14:17:29 --> Helper loaded: form_helper
INFO - 2022-01-17 14:17:29 --> Helper loaded: common_helper
INFO - 2022-01-17 14:17:29 --> Database Driver Class Initialized
DEBUG - 2022-01-17 14:17:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 14:17:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 14:17:29 --> Controller Class Initialized
INFO - 2022-01-17 14:17:29 --> Form Validation Class Initialized
DEBUG - 2022-01-17 14:17:29 --> Encrypt Class Initialized
DEBUG - 2022-01-17 14:17:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 14:17:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-17 14:17:29 --> Email Class Initialized
INFO - 2022-01-17 14:17:29 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-17 14:17:29 --> Calendar Class Initialized
INFO - 2022-01-17 14:17:29 --> Model "Login_model" initialized
INFO - 2022-01-17 14:17:29 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-17 14:17:29 --> Final output sent to browser
DEBUG - 2022-01-17 14:17:29 --> Total execution time: 0.0264
ERROR - 2022-01-17 14:17:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-17 14:17:30 --> Config Class Initialized
INFO - 2022-01-17 14:17:30 --> Hooks Class Initialized
DEBUG - 2022-01-17 14:17:30 --> UTF-8 Support Enabled
INFO - 2022-01-17 14:17:30 --> Utf8 Class Initialized
INFO - 2022-01-17 14:17:30 --> URI Class Initialized
DEBUG - 2022-01-17 14:17:30 --> No URI present. Default controller set.
INFO - 2022-01-17 14:17:30 --> Router Class Initialized
INFO - 2022-01-17 14:17:30 --> Output Class Initialized
INFO - 2022-01-17 14:17:30 --> Security Class Initialized
DEBUG - 2022-01-17 14:17:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 14:17:30 --> Input Class Initialized
INFO - 2022-01-17 14:17:30 --> Language Class Initialized
INFO - 2022-01-17 14:17:30 --> Loader Class Initialized
INFO - 2022-01-17 14:17:30 --> Helper loaded: url_helper
INFO - 2022-01-17 14:17:30 --> Helper loaded: form_helper
INFO - 2022-01-17 14:17:30 --> Helper loaded: common_helper
INFO - 2022-01-17 14:17:30 --> Database Driver Class Initialized
DEBUG - 2022-01-17 14:17:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 14:17:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 14:17:30 --> Controller Class Initialized
INFO - 2022-01-17 14:17:30 --> Form Validation Class Initialized
DEBUG - 2022-01-17 14:17:30 --> Encrypt Class Initialized
DEBUG - 2022-01-17 14:17:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 14:17:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-17 14:17:30 --> Email Class Initialized
INFO - 2022-01-17 14:17:30 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-17 14:17:30 --> Calendar Class Initialized
INFO - 2022-01-17 14:17:30 --> Model "Login_model" initialized
INFO - 2022-01-17 14:17:30 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-17 14:17:30 --> Final output sent to browser
DEBUG - 2022-01-17 14:17:30 --> Total execution time: 0.0350
ERROR - 2022-01-17 15:45:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-17 15:45:29 --> Config Class Initialized
INFO - 2022-01-17 15:45:29 --> Hooks Class Initialized
DEBUG - 2022-01-17 15:45:29 --> UTF-8 Support Enabled
INFO - 2022-01-17 15:45:29 --> Utf8 Class Initialized
INFO - 2022-01-17 15:45:29 --> URI Class Initialized
DEBUG - 2022-01-17 15:45:29 --> No URI present. Default controller set.
INFO - 2022-01-17 15:45:29 --> Router Class Initialized
INFO - 2022-01-17 15:45:29 --> Output Class Initialized
INFO - 2022-01-17 15:45:29 --> Security Class Initialized
DEBUG - 2022-01-17 15:45:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 15:45:29 --> Input Class Initialized
INFO - 2022-01-17 15:45:29 --> Language Class Initialized
INFO - 2022-01-17 15:45:29 --> Loader Class Initialized
INFO - 2022-01-17 15:45:29 --> Helper loaded: url_helper
INFO - 2022-01-17 15:45:29 --> Helper loaded: form_helper
INFO - 2022-01-17 15:45:29 --> Helper loaded: common_helper
INFO - 2022-01-17 15:45:29 --> Database Driver Class Initialized
DEBUG - 2022-01-17 15:45:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 15:45:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 15:45:29 --> Controller Class Initialized
INFO - 2022-01-17 15:45:29 --> Form Validation Class Initialized
DEBUG - 2022-01-17 15:45:29 --> Encrypt Class Initialized
DEBUG - 2022-01-17 15:45:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 15:45:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-17 15:45:29 --> Email Class Initialized
INFO - 2022-01-17 15:45:29 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-17 15:45:29 --> Calendar Class Initialized
INFO - 2022-01-17 15:45:29 --> Model "Login_model" initialized
INFO - 2022-01-17 15:45:29 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-17 15:45:29 --> Final output sent to browser
DEBUG - 2022-01-17 15:45:29 --> Total execution time: 0.0370
ERROR - 2022-01-17 19:56:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-17 19:56:28 --> Config Class Initialized
INFO - 2022-01-17 19:56:28 --> Hooks Class Initialized
DEBUG - 2022-01-17 19:56:28 --> UTF-8 Support Enabled
INFO - 2022-01-17 19:56:28 --> Utf8 Class Initialized
INFO - 2022-01-17 19:56:28 --> URI Class Initialized
DEBUG - 2022-01-17 19:56:28 --> No URI present. Default controller set.
INFO - 2022-01-17 19:56:28 --> Router Class Initialized
INFO - 2022-01-17 19:56:28 --> Output Class Initialized
INFO - 2022-01-17 19:56:28 --> Security Class Initialized
DEBUG - 2022-01-17 19:56:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 19:56:28 --> Input Class Initialized
INFO - 2022-01-17 19:56:28 --> Language Class Initialized
INFO - 2022-01-17 19:56:28 --> Loader Class Initialized
INFO - 2022-01-17 19:56:28 --> Helper loaded: url_helper
INFO - 2022-01-17 19:56:28 --> Helper loaded: form_helper
INFO - 2022-01-17 19:56:28 --> Helper loaded: common_helper
INFO - 2022-01-17 19:56:28 --> Database Driver Class Initialized
DEBUG - 2022-01-17 19:56:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 19:56:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 19:56:28 --> Controller Class Initialized
INFO - 2022-01-17 19:56:28 --> Form Validation Class Initialized
DEBUG - 2022-01-17 19:56:28 --> Encrypt Class Initialized
DEBUG - 2022-01-17 19:56:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 19:56:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-17 19:56:28 --> Email Class Initialized
INFO - 2022-01-17 19:56:28 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-17 19:56:28 --> Calendar Class Initialized
INFO - 2022-01-17 19:56:28 --> Model "Login_model" initialized
INFO - 2022-01-17 19:56:28 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-17 19:56:28 --> Final output sent to browser
DEBUG - 2022-01-17 19:56:28 --> Total execution time: 0.0257
ERROR - 2022-01-17 19:56:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-17 19:56:29 --> Config Class Initialized
INFO - 2022-01-17 19:56:29 --> Hooks Class Initialized
DEBUG - 2022-01-17 19:56:29 --> UTF-8 Support Enabled
INFO - 2022-01-17 19:56:29 --> Utf8 Class Initialized
INFO - 2022-01-17 19:56:29 --> URI Class Initialized
INFO - 2022-01-17 19:56:29 --> Router Class Initialized
INFO - 2022-01-17 19:56:29 --> Output Class Initialized
INFO - 2022-01-17 19:56:29 --> Security Class Initialized
DEBUG - 2022-01-17 19:56:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 19:56:29 --> Input Class Initialized
INFO - 2022-01-17 19:56:29 --> Language Class Initialized
ERROR - 2022-01-17 19:56:29 --> 404 Page Not Found: Register/index
ERROR - 2022-01-17 19:56:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-17 19:56:31 --> Config Class Initialized
INFO - 2022-01-17 19:56:31 --> Hooks Class Initialized
DEBUG - 2022-01-17 19:56:31 --> UTF-8 Support Enabled
INFO - 2022-01-17 19:56:31 --> Utf8 Class Initialized
INFO - 2022-01-17 19:56:31 --> URI Class Initialized
INFO - 2022-01-17 19:56:31 --> Router Class Initialized
INFO - 2022-01-17 19:56:31 --> Output Class Initialized
INFO - 2022-01-17 19:56:31 --> Security Class Initialized
DEBUG - 2022-01-17 19:56:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 19:56:31 --> Input Class Initialized
INFO - 2022-01-17 19:56:31 --> Language Class Initialized
INFO - 2022-01-17 19:56:31 --> Loader Class Initialized
INFO - 2022-01-17 19:56:31 --> Helper loaded: url_helper
INFO - 2022-01-17 19:56:31 --> Helper loaded: form_helper
INFO - 2022-01-17 19:56:31 --> Helper loaded: common_helper
INFO - 2022-01-17 19:56:31 --> Database Driver Class Initialized
DEBUG - 2022-01-17 19:56:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 19:56:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 19:56:31 --> Controller Class Initialized
INFO - 2022-01-17 19:56:31 --> Form Validation Class Initialized
DEBUG - 2022-01-17 19:56:31 --> Encrypt Class Initialized
DEBUG - 2022-01-17 19:56:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 19:56:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-17 19:56:31 --> Email Class Initialized
INFO - 2022-01-17 19:56:31 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-17 19:56:31 --> Calendar Class Initialized
INFO - 2022-01-17 19:56:31 --> Model "Login_model" initialized
INFO - 2022-01-17 19:56:31 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-17 19:56:31 --> Final output sent to browser
DEBUG - 2022-01-17 19:56:31 --> Total execution time: 0.0228
ERROR - 2022-01-17 19:56:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-17 19:56:33 --> Config Class Initialized
INFO - 2022-01-17 19:56:33 --> Hooks Class Initialized
DEBUG - 2022-01-17 19:56:33 --> UTF-8 Support Enabled
INFO - 2022-01-17 19:56:33 --> Utf8 Class Initialized
INFO - 2022-01-17 19:56:33 --> URI Class Initialized
DEBUG - 2022-01-17 19:56:33 --> No URI present. Default controller set.
INFO - 2022-01-17 19:56:33 --> Router Class Initialized
INFO - 2022-01-17 19:56:33 --> Output Class Initialized
INFO - 2022-01-17 19:56:33 --> Security Class Initialized
DEBUG - 2022-01-17 19:56:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 19:56:33 --> Input Class Initialized
INFO - 2022-01-17 19:56:33 --> Language Class Initialized
INFO - 2022-01-17 19:56:33 --> Loader Class Initialized
INFO - 2022-01-17 19:56:33 --> Helper loaded: url_helper
INFO - 2022-01-17 19:56:33 --> Helper loaded: form_helper
INFO - 2022-01-17 19:56:33 --> Helper loaded: common_helper
INFO - 2022-01-17 19:56:33 --> Database Driver Class Initialized
DEBUG - 2022-01-17 19:56:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 19:56:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 19:56:33 --> Controller Class Initialized
INFO - 2022-01-17 19:56:33 --> Form Validation Class Initialized
DEBUG - 2022-01-17 19:56:33 --> Encrypt Class Initialized
DEBUG - 2022-01-17 19:56:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 19:56:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-17 19:56:33 --> Email Class Initialized
INFO - 2022-01-17 19:56:33 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-17 19:56:33 --> Calendar Class Initialized
INFO - 2022-01-17 19:56:33 --> Model "Login_model" initialized
INFO - 2022-01-17 19:56:33 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-17 19:56:33 --> Final output sent to browser
DEBUG - 2022-01-17 19:56:33 --> Total execution time: 0.0236
ERROR - 2022-01-17 19:56:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-17 19:56:36 --> Config Class Initialized
INFO - 2022-01-17 19:56:36 --> Hooks Class Initialized
DEBUG - 2022-01-17 19:56:36 --> UTF-8 Support Enabled
INFO - 2022-01-17 19:56:36 --> Utf8 Class Initialized
INFO - 2022-01-17 19:56:36 --> URI Class Initialized
INFO - 2022-01-17 19:56:36 --> Router Class Initialized
INFO - 2022-01-17 19:56:36 --> Output Class Initialized
INFO - 2022-01-17 19:56:36 --> Security Class Initialized
DEBUG - 2022-01-17 19:56:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 19:56:36 --> Input Class Initialized
INFO - 2022-01-17 19:56:36 --> Language Class Initialized
INFO - 2022-01-17 19:56:36 --> Loader Class Initialized
INFO - 2022-01-17 19:56:36 --> Helper loaded: url_helper
INFO - 2022-01-17 19:56:36 --> Helper loaded: form_helper
INFO - 2022-01-17 19:56:36 --> Helper loaded: common_helper
INFO - 2022-01-17 19:56:36 --> Database Driver Class Initialized
DEBUG - 2022-01-17 19:56:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 19:56:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 19:56:36 --> Controller Class Initialized
INFO - 2022-01-17 19:56:36 --> Form Validation Class Initialized
DEBUG - 2022-01-17 19:56:36 --> Encrypt Class Initialized
DEBUG - 2022-01-17 19:56:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 19:56:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-17 19:56:36 --> Email Class Initialized
INFO - 2022-01-17 19:56:36 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-17 19:56:36 --> Calendar Class Initialized
INFO - 2022-01-17 19:56:36 --> Model "Login_model" initialized
ERROR - 2022-01-17 19:56:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-17 19:56:37 --> Config Class Initialized
INFO - 2022-01-17 19:56:37 --> Hooks Class Initialized
DEBUG - 2022-01-17 19:56:37 --> UTF-8 Support Enabled
INFO - 2022-01-17 19:56:37 --> Utf8 Class Initialized
INFO - 2022-01-17 19:56:37 --> URI Class Initialized
INFO - 2022-01-17 19:56:37 --> Router Class Initialized
INFO - 2022-01-17 19:56:37 --> Output Class Initialized
INFO - 2022-01-17 19:56:37 --> Security Class Initialized
DEBUG - 2022-01-17 19:56:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 19:56:37 --> Input Class Initialized
INFO - 2022-01-17 19:56:37 --> Language Class Initialized
INFO - 2022-01-17 19:56:37 --> Loader Class Initialized
INFO - 2022-01-17 19:56:37 --> Helper loaded: url_helper
INFO - 2022-01-17 19:56:37 --> Helper loaded: form_helper
INFO - 2022-01-17 19:56:37 --> Helper loaded: common_helper
INFO - 2022-01-17 19:56:37 --> Database Driver Class Initialized
DEBUG - 2022-01-17 19:56:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 19:56:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 19:56:37 --> Controller Class Initialized
INFO - 2022-01-17 19:56:37 --> Form Validation Class Initialized
DEBUG - 2022-01-17 19:56:37 --> Encrypt Class Initialized
DEBUG - 2022-01-17 19:56:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 19:56:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-17 19:56:37 --> Email Class Initialized
INFO - 2022-01-17 19:56:37 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-17 19:56:37 --> Calendar Class Initialized
INFO - 2022-01-17 19:56:37 --> Model "Login_model" initialized
INFO - 2022-01-17 19:56:37 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-17 19:56:37 --> Final output sent to browser
DEBUG - 2022-01-17 19:56:37 --> Total execution time: 0.0333
ERROR - 2022-01-17 21:16:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-17 21:16:11 --> Config Class Initialized
INFO - 2022-01-17 21:16:11 --> Hooks Class Initialized
DEBUG - 2022-01-17 21:16:11 --> UTF-8 Support Enabled
INFO - 2022-01-17 21:16:11 --> Utf8 Class Initialized
INFO - 2022-01-17 21:16:11 --> URI Class Initialized
DEBUG - 2022-01-17 21:16:11 --> No URI present. Default controller set.
INFO - 2022-01-17 21:16:11 --> Router Class Initialized
INFO - 2022-01-17 21:16:11 --> Output Class Initialized
INFO - 2022-01-17 21:16:11 --> Security Class Initialized
DEBUG - 2022-01-17 21:16:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 21:16:11 --> Input Class Initialized
INFO - 2022-01-17 21:16:11 --> Language Class Initialized
INFO - 2022-01-17 21:16:11 --> Loader Class Initialized
INFO - 2022-01-17 21:16:11 --> Helper loaded: url_helper
INFO - 2022-01-17 21:16:11 --> Helper loaded: form_helper
INFO - 2022-01-17 21:16:11 --> Helper loaded: common_helper
INFO - 2022-01-17 21:16:11 --> Database Driver Class Initialized
DEBUG - 2022-01-17 21:16:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 21:16:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 21:16:11 --> Controller Class Initialized
INFO - 2022-01-17 21:16:11 --> Form Validation Class Initialized
DEBUG - 2022-01-17 21:16:11 --> Encrypt Class Initialized
DEBUG - 2022-01-17 21:16:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 21:16:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-17 21:16:11 --> Email Class Initialized
INFO - 2022-01-17 21:16:11 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-17 21:16:11 --> Calendar Class Initialized
INFO - 2022-01-17 21:16:11 --> Model "Login_model" initialized
INFO - 2022-01-17 21:16:11 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-17 21:16:11 --> Final output sent to browser
DEBUG - 2022-01-17 21:16:11 --> Total execution time: 0.0242
ERROR - 2022-01-17 21:33:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-17 21:33:25 --> Config Class Initialized
INFO - 2022-01-17 21:33:25 --> Hooks Class Initialized
DEBUG - 2022-01-17 21:33:26 --> UTF-8 Support Enabled
INFO - 2022-01-17 21:33:26 --> Utf8 Class Initialized
INFO - 2022-01-17 21:33:26 --> URI Class Initialized
DEBUG - 2022-01-17 21:33:26 --> No URI present. Default controller set.
INFO - 2022-01-17 21:33:26 --> Router Class Initialized
INFO - 2022-01-17 21:33:26 --> Output Class Initialized
INFO - 2022-01-17 21:33:26 --> Security Class Initialized
DEBUG - 2022-01-17 21:33:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 21:33:26 --> Input Class Initialized
INFO - 2022-01-17 21:33:26 --> Language Class Initialized
INFO - 2022-01-17 21:33:26 --> Loader Class Initialized
INFO - 2022-01-17 21:33:26 --> Helper loaded: url_helper
INFO - 2022-01-17 21:33:26 --> Helper loaded: form_helper
INFO - 2022-01-17 21:33:26 --> Helper loaded: common_helper
INFO - 2022-01-17 21:33:26 --> Database Driver Class Initialized
DEBUG - 2022-01-17 21:33:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 21:33:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 21:33:26 --> Controller Class Initialized
INFO - 2022-01-17 21:33:26 --> Form Validation Class Initialized
DEBUG - 2022-01-17 21:33:26 --> Encrypt Class Initialized
DEBUG - 2022-01-17 21:33:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 21:33:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-17 21:33:26 --> Email Class Initialized
INFO - 2022-01-17 21:33:26 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-17 21:33:26 --> Calendar Class Initialized
INFO - 2022-01-17 21:33:26 --> Model "Login_model" initialized
INFO - 2022-01-17 21:33:26 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-17 21:33:26 --> Final output sent to browser
DEBUG - 2022-01-17 21:33:26 --> Total execution time: 0.1330
ERROR - 2022-01-17 21:33:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-17 21:33:27 --> Config Class Initialized
INFO - 2022-01-17 21:33:27 --> Hooks Class Initialized
DEBUG - 2022-01-17 21:33:27 --> UTF-8 Support Enabled
INFO - 2022-01-17 21:33:27 --> Utf8 Class Initialized
INFO - 2022-01-17 21:33:27 --> URI Class Initialized
INFO - 2022-01-17 21:33:27 --> Router Class Initialized
INFO - 2022-01-17 21:33:27 --> Output Class Initialized
INFO - 2022-01-17 21:33:27 --> Security Class Initialized
DEBUG - 2022-01-17 21:33:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 21:33:27 --> Input Class Initialized
INFO - 2022-01-17 21:33:27 --> Language Class Initialized
ERROR - 2022-01-17 21:33:27 --> 404 Page Not Found: Register/index
ERROR - 2022-01-17 21:33:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-17 21:33:29 --> Config Class Initialized
INFO - 2022-01-17 21:33:29 --> Hooks Class Initialized
DEBUG - 2022-01-17 21:33:29 --> UTF-8 Support Enabled
INFO - 2022-01-17 21:33:29 --> Utf8 Class Initialized
INFO - 2022-01-17 21:33:29 --> URI Class Initialized
INFO - 2022-01-17 21:33:29 --> Router Class Initialized
INFO - 2022-01-17 21:33:29 --> Output Class Initialized
INFO - 2022-01-17 21:33:29 --> Security Class Initialized
DEBUG - 2022-01-17 21:33:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 21:33:29 --> Input Class Initialized
INFO - 2022-01-17 21:33:29 --> Language Class Initialized
INFO - 2022-01-17 21:33:29 --> Loader Class Initialized
INFO - 2022-01-17 21:33:29 --> Helper loaded: url_helper
INFO - 2022-01-17 21:33:29 --> Helper loaded: form_helper
INFO - 2022-01-17 21:33:29 --> Helper loaded: common_helper
INFO - 2022-01-17 21:33:29 --> Database Driver Class Initialized
DEBUG - 2022-01-17 21:33:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 21:33:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 21:33:29 --> Controller Class Initialized
INFO - 2022-01-17 21:33:29 --> Form Validation Class Initialized
DEBUG - 2022-01-17 21:33:29 --> Encrypt Class Initialized
DEBUG - 2022-01-17 21:33:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 21:33:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-17 21:33:29 --> Email Class Initialized
INFO - 2022-01-17 21:33:29 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-17 21:33:29 --> Calendar Class Initialized
INFO - 2022-01-17 21:33:29 --> Model "Login_model" initialized
INFO - 2022-01-17 21:33:29 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-17 21:33:29 --> Final output sent to browser
DEBUG - 2022-01-17 21:33:29 --> Total execution time: 0.0236
ERROR - 2022-01-17 21:33:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-17 21:33:30 --> Config Class Initialized
INFO - 2022-01-17 21:33:30 --> Hooks Class Initialized
DEBUG - 2022-01-17 21:33:30 --> UTF-8 Support Enabled
INFO - 2022-01-17 21:33:30 --> Utf8 Class Initialized
INFO - 2022-01-17 21:33:30 --> URI Class Initialized
DEBUG - 2022-01-17 21:33:30 --> No URI present. Default controller set.
INFO - 2022-01-17 21:33:30 --> Router Class Initialized
INFO - 2022-01-17 21:33:30 --> Output Class Initialized
INFO - 2022-01-17 21:33:30 --> Security Class Initialized
DEBUG - 2022-01-17 21:33:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 21:33:30 --> Input Class Initialized
INFO - 2022-01-17 21:33:30 --> Language Class Initialized
INFO - 2022-01-17 21:33:30 --> Loader Class Initialized
INFO - 2022-01-17 21:33:30 --> Helper loaded: url_helper
INFO - 2022-01-17 21:33:30 --> Helper loaded: form_helper
INFO - 2022-01-17 21:33:30 --> Helper loaded: common_helper
INFO - 2022-01-17 21:33:30 --> Database Driver Class Initialized
DEBUG - 2022-01-17 21:33:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 21:33:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 21:33:30 --> Controller Class Initialized
INFO - 2022-01-17 21:33:30 --> Form Validation Class Initialized
DEBUG - 2022-01-17 21:33:30 --> Encrypt Class Initialized
DEBUG - 2022-01-17 21:33:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 21:33:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-17 21:33:30 --> Email Class Initialized
INFO - 2022-01-17 21:33:30 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-17 21:33:30 --> Calendar Class Initialized
INFO - 2022-01-17 21:33:30 --> Model "Login_model" initialized
INFO - 2022-01-17 21:33:30 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-17 21:33:30 --> Final output sent to browser
DEBUG - 2022-01-17 21:33:30 --> Total execution time: 0.0265
ERROR - 2022-01-17 21:33:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-17 21:33:31 --> Config Class Initialized
INFO - 2022-01-17 21:33:31 --> Hooks Class Initialized
DEBUG - 2022-01-17 21:33:31 --> UTF-8 Support Enabled
INFO - 2022-01-17 21:33:31 --> Utf8 Class Initialized
INFO - 2022-01-17 21:33:31 --> URI Class Initialized
INFO - 2022-01-17 21:33:31 --> Router Class Initialized
INFO - 2022-01-17 21:33:31 --> Output Class Initialized
INFO - 2022-01-17 21:33:31 --> Security Class Initialized
DEBUG - 2022-01-17 21:33:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 21:33:31 --> Input Class Initialized
INFO - 2022-01-17 21:33:31 --> Language Class Initialized
INFO - 2022-01-17 21:33:31 --> Loader Class Initialized
INFO - 2022-01-17 21:33:31 --> Helper loaded: url_helper
INFO - 2022-01-17 21:33:31 --> Helper loaded: form_helper
INFO - 2022-01-17 21:33:31 --> Helper loaded: common_helper
INFO - 2022-01-17 21:33:31 --> Database Driver Class Initialized
DEBUG - 2022-01-17 21:33:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 21:33:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 21:33:32 --> Controller Class Initialized
INFO - 2022-01-17 21:33:32 --> Form Validation Class Initialized
DEBUG - 2022-01-17 21:33:32 --> Encrypt Class Initialized
DEBUG - 2022-01-17 21:33:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 21:33:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-17 21:33:32 --> Email Class Initialized
INFO - 2022-01-17 21:33:32 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-17 21:33:32 --> Calendar Class Initialized
INFO - 2022-01-17 21:33:32 --> Model "Login_model" initialized
ERROR - 2022-01-17 21:33:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-17 21:33:33 --> Config Class Initialized
INFO - 2022-01-17 21:33:33 --> Hooks Class Initialized
DEBUG - 2022-01-17 21:33:33 --> UTF-8 Support Enabled
INFO - 2022-01-17 21:33:33 --> Utf8 Class Initialized
INFO - 2022-01-17 21:33:33 --> URI Class Initialized
INFO - 2022-01-17 21:33:33 --> Router Class Initialized
INFO - 2022-01-17 21:33:33 --> Output Class Initialized
INFO - 2022-01-17 21:33:33 --> Security Class Initialized
DEBUG - 2022-01-17 21:33:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 21:33:33 --> Input Class Initialized
INFO - 2022-01-17 21:33:33 --> Language Class Initialized
INFO - 2022-01-17 21:33:33 --> Loader Class Initialized
INFO - 2022-01-17 21:33:33 --> Helper loaded: url_helper
INFO - 2022-01-17 21:33:33 --> Helper loaded: form_helper
INFO - 2022-01-17 21:33:33 --> Helper loaded: common_helper
INFO - 2022-01-17 21:33:33 --> Database Driver Class Initialized
DEBUG - 2022-01-17 21:33:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 21:33:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 21:33:33 --> Controller Class Initialized
INFO - 2022-01-17 21:33:33 --> Form Validation Class Initialized
DEBUG - 2022-01-17 21:33:33 --> Encrypt Class Initialized
DEBUG - 2022-01-17 21:33:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 21:33:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-17 21:33:33 --> Email Class Initialized
INFO - 2022-01-17 21:33:33 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-17 21:33:33 --> Calendar Class Initialized
INFO - 2022-01-17 21:33:33 --> Model "Login_model" initialized
INFO - 2022-01-17 21:33:33 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-17 21:33:33 --> Final output sent to browser
DEBUG - 2022-01-17 21:33:33 --> Total execution time: 0.0234
ERROR - 2022-01-17 21:53:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-17 21:53:10 --> Config Class Initialized
INFO - 2022-01-17 21:53:10 --> Hooks Class Initialized
DEBUG - 2022-01-17 21:53:10 --> UTF-8 Support Enabled
INFO - 2022-01-17 21:53:10 --> Utf8 Class Initialized
INFO - 2022-01-17 21:53:10 --> URI Class Initialized
DEBUG - 2022-01-17 21:53:10 --> No URI present. Default controller set.
INFO - 2022-01-17 21:53:10 --> Router Class Initialized
INFO - 2022-01-17 21:53:10 --> Output Class Initialized
INFO - 2022-01-17 21:53:10 --> Security Class Initialized
DEBUG - 2022-01-17 21:53:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 21:53:10 --> Input Class Initialized
INFO - 2022-01-17 21:53:10 --> Language Class Initialized
INFO - 2022-01-17 21:53:10 --> Loader Class Initialized
INFO - 2022-01-17 21:53:10 --> Helper loaded: url_helper
INFO - 2022-01-17 21:53:10 --> Helper loaded: form_helper
INFO - 2022-01-17 21:53:10 --> Helper loaded: common_helper
INFO - 2022-01-17 21:53:10 --> Database Driver Class Initialized
DEBUG - 2022-01-17 21:53:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 21:53:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 21:53:10 --> Controller Class Initialized
INFO - 2022-01-17 21:53:10 --> Form Validation Class Initialized
DEBUG - 2022-01-17 21:53:10 --> Encrypt Class Initialized
DEBUG - 2022-01-17 21:53:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 21:53:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-17 21:53:10 --> Email Class Initialized
INFO - 2022-01-17 21:53:10 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-17 21:53:10 --> Calendar Class Initialized
INFO - 2022-01-17 21:53:10 --> Model "Login_model" initialized
INFO - 2022-01-17 21:53:10 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-17 21:53:10 --> Final output sent to browser
DEBUG - 2022-01-17 21:53:10 --> Total execution time: 0.0246
ERROR - 2022-01-17 21:53:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-17 21:53:11 --> Config Class Initialized
INFO - 2022-01-17 21:53:11 --> Hooks Class Initialized
DEBUG - 2022-01-17 21:53:11 --> UTF-8 Support Enabled
INFO - 2022-01-17 21:53:11 --> Utf8 Class Initialized
INFO - 2022-01-17 21:53:11 --> URI Class Initialized
INFO - 2022-01-17 21:53:11 --> Router Class Initialized
INFO - 2022-01-17 21:53:11 --> Output Class Initialized
INFO - 2022-01-17 21:53:12 --> Security Class Initialized
DEBUG - 2022-01-17 21:53:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 21:53:12 --> Input Class Initialized
INFO - 2022-01-17 21:53:12 --> Language Class Initialized
ERROR - 2022-01-17 21:53:12 --> 404 Page Not Found: Blog/index
ERROR - 2022-01-17 21:53:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-17 21:53:12 --> Config Class Initialized
INFO - 2022-01-17 21:53:12 --> Hooks Class Initialized
DEBUG - 2022-01-17 21:53:12 --> UTF-8 Support Enabled
INFO - 2022-01-17 21:53:12 --> Utf8 Class Initialized
INFO - 2022-01-17 21:53:12 --> URI Class Initialized
INFO - 2022-01-17 21:53:12 --> Router Class Initialized
INFO - 2022-01-17 21:53:12 --> Output Class Initialized
INFO - 2022-01-17 21:53:12 --> Security Class Initialized
DEBUG - 2022-01-17 21:53:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 21:53:12 --> Input Class Initialized
INFO - 2022-01-17 21:53:12 --> Language Class Initialized
ERROR - 2022-01-17 21:53:12 --> 404 Page Not Found: Wp/index
ERROR - 2022-01-17 21:53:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-17 21:53:13 --> Config Class Initialized
INFO - 2022-01-17 21:53:13 --> Hooks Class Initialized
DEBUG - 2022-01-17 21:53:13 --> UTF-8 Support Enabled
INFO - 2022-01-17 21:53:13 --> Utf8 Class Initialized
INFO - 2022-01-17 21:53:13 --> URI Class Initialized
INFO - 2022-01-17 21:53:13 --> Router Class Initialized
INFO - 2022-01-17 21:53:13 --> Output Class Initialized
INFO - 2022-01-17 21:53:13 --> Security Class Initialized
DEBUG - 2022-01-17 21:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 21:53:13 --> Input Class Initialized
INFO - 2022-01-17 21:53:13 --> Language Class Initialized
ERROR - 2022-01-17 21:53:13 --> 404 Page Not Found: Wordpress/index
ERROR - 2022-01-17 21:53:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-17 21:53:13 --> Config Class Initialized
INFO - 2022-01-17 21:53:13 --> Hooks Class Initialized
DEBUG - 2022-01-17 21:53:13 --> UTF-8 Support Enabled
INFO - 2022-01-17 21:53:13 --> Utf8 Class Initialized
INFO - 2022-01-17 21:53:13 --> URI Class Initialized
INFO - 2022-01-17 21:53:13 --> Router Class Initialized
INFO - 2022-01-17 21:53:13 --> Output Class Initialized
INFO - 2022-01-17 21:53:13 --> Security Class Initialized
DEBUG - 2022-01-17 21:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 21:53:13 --> Input Class Initialized
INFO - 2022-01-17 21:53:13 --> Language Class Initialized
ERROR - 2022-01-17 21:53:13 --> 404 Page Not Found: New/index
ERROR - 2022-01-17 21:53:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-17 21:53:14 --> Config Class Initialized
INFO - 2022-01-17 21:53:14 --> Hooks Class Initialized
DEBUG - 2022-01-17 21:53:14 --> UTF-8 Support Enabled
INFO - 2022-01-17 21:53:14 --> Utf8 Class Initialized
INFO - 2022-01-17 21:53:14 --> URI Class Initialized
INFO - 2022-01-17 21:53:14 --> Router Class Initialized
INFO - 2022-01-17 21:53:14 --> Output Class Initialized
INFO - 2022-01-17 21:53:14 --> Security Class Initialized
DEBUG - 2022-01-17 21:53:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 21:53:14 --> Input Class Initialized
INFO - 2022-01-17 21:53:14 --> Language Class Initialized
ERROR - 2022-01-17 21:53:14 --> 404 Page Not Found: Old/index
ERROR - 2022-01-17 21:53:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-17 21:53:15 --> Config Class Initialized
INFO - 2022-01-17 21:53:15 --> Hooks Class Initialized
DEBUG - 2022-01-17 21:53:15 --> UTF-8 Support Enabled
INFO - 2022-01-17 21:53:15 --> Utf8 Class Initialized
INFO - 2022-01-17 21:53:15 --> URI Class Initialized
INFO - 2022-01-17 21:53:15 --> Router Class Initialized
INFO - 2022-01-17 21:53:15 --> Output Class Initialized
INFO - 2022-01-17 21:53:15 --> Security Class Initialized
DEBUG - 2022-01-17 21:53:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 21:53:15 --> Input Class Initialized
INFO - 2022-01-17 21:53:15 --> Language Class Initialized
ERROR - 2022-01-17 21:53:15 --> 404 Page Not Found: Test/index
ERROR - 2022-01-17 21:53:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-17 21:53:15 --> Config Class Initialized
INFO - 2022-01-17 21:53:15 --> Hooks Class Initialized
DEBUG - 2022-01-17 21:53:15 --> UTF-8 Support Enabled
INFO - 2022-01-17 21:53:15 --> Utf8 Class Initialized
INFO - 2022-01-17 21:53:15 --> URI Class Initialized
INFO - 2022-01-17 21:53:15 --> Router Class Initialized
INFO - 2022-01-17 21:53:15 --> Output Class Initialized
INFO - 2022-01-17 21:53:15 --> Security Class Initialized
DEBUG - 2022-01-17 21:53:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 21:53:15 --> Input Class Initialized
INFO - 2022-01-17 21:53:15 --> Language Class Initialized
ERROR - 2022-01-17 21:53:15 --> 404 Page Not Found: Main/index
ERROR - 2022-01-17 21:53:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-17 21:53:16 --> Config Class Initialized
INFO - 2022-01-17 21:53:16 --> Hooks Class Initialized
DEBUG - 2022-01-17 21:53:16 --> UTF-8 Support Enabled
INFO - 2022-01-17 21:53:16 --> Utf8 Class Initialized
INFO - 2022-01-17 21:53:16 --> URI Class Initialized
INFO - 2022-01-17 21:53:16 --> Router Class Initialized
INFO - 2022-01-17 21:53:16 --> Output Class Initialized
INFO - 2022-01-17 21:53:16 --> Security Class Initialized
DEBUG - 2022-01-17 21:53:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 21:53:16 --> Input Class Initialized
INFO - 2022-01-17 21:53:16 --> Language Class Initialized
ERROR - 2022-01-17 21:53:16 --> 404 Page Not Found: Site/index
ERROR - 2022-01-17 21:53:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-17 21:53:17 --> Config Class Initialized
INFO - 2022-01-17 21:53:17 --> Hooks Class Initialized
DEBUG - 2022-01-17 21:53:17 --> UTF-8 Support Enabled
INFO - 2022-01-17 21:53:17 --> Utf8 Class Initialized
INFO - 2022-01-17 21:53:17 --> URI Class Initialized
INFO - 2022-01-17 21:53:17 --> Router Class Initialized
INFO - 2022-01-17 21:53:17 --> Output Class Initialized
INFO - 2022-01-17 21:53:17 --> Security Class Initialized
DEBUG - 2022-01-17 21:53:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 21:53:17 --> Input Class Initialized
INFO - 2022-01-17 21:53:17 --> Language Class Initialized
ERROR - 2022-01-17 21:53:17 --> 404 Page Not Found: Backup/index
ERROR - 2022-01-17 21:53:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-17 21:53:17 --> Config Class Initialized
INFO - 2022-01-17 21:53:17 --> Hooks Class Initialized
DEBUG - 2022-01-17 21:53:17 --> UTF-8 Support Enabled
INFO - 2022-01-17 21:53:17 --> Utf8 Class Initialized
INFO - 2022-01-17 21:53:17 --> URI Class Initialized
INFO - 2022-01-17 21:53:17 --> Router Class Initialized
INFO - 2022-01-17 21:53:17 --> Output Class Initialized
INFO - 2022-01-17 21:53:17 --> Security Class Initialized
DEBUG - 2022-01-17 21:53:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 21:53:17 --> Input Class Initialized
INFO - 2022-01-17 21:53:17 --> Language Class Initialized
ERROR - 2022-01-17 21:53:17 --> 404 Page Not Found: Demo/index
ERROR - 2022-01-17 21:53:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-17 21:53:18 --> Config Class Initialized
INFO - 2022-01-17 21:53:18 --> Hooks Class Initialized
DEBUG - 2022-01-17 21:53:18 --> UTF-8 Support Enabled
INFO - 2022-01-17 21:53:18 --> Utf8 Class Initialized
INFO - 2022-01-17 21:53:18 --> URI Class Initialized
INFO - 2022-01-17 21:53:18 --> Router Class Initialized
INFO - 2022-01-17 21:53:18 --> Output Class Initialized
INFO - 2022-01-17 21:53:18 --> Security Class Initialized
DEBUG - 2022-01-17 21:53:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 21:53:18 --> Input Class Initialized
INFO - 2022-01-17 21:53:18 --> Language Class Initialized
ERROR - 2022-01-17 21:53:18 --> 404 Page Not Found: Home/index
ERROR - 2022-01-17 21:53:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-17 21:53:19 --> Config Class Initialized
INFO - 2022-01-17 21:53:19 --> Hooks Class Initialized
DEBUG - 2022-01-17 21:53:19 --> UTF-8 Support Enabled
INFO - 2022-01-17 21:53:19 --> Utf8 Class Initialized
INFO - 2022-01-17 21:53:19 --> URI Class Initialized
INFO - 2022-01-17 21:53:19 --> Router Class Initialized
INFO - 2022-01-17 21:53:19 --> Output Class Initialized
INFO - 2022-01-17 21:53:19 --> Security Class Initialized
DEBUG - 2022-01-17 21:53:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 21:53:19 --> Input Class Initialized
INFO - 2022-01-17 21:53:19 --> Language Class Initialized
ERROR - 2022-01-17 21:53:19 --> 404 Page Not Found: Tmp/index
ERROR - 2022-01-17 21:53:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-17 21:53:19 --> Config Class Initialized
INFO - 2022-01-17 21:53:19 --> Hooks Class Initialized
DEBUG - 2022-01-17 21:53:19 --> UTF-8 Support Enabled
INFO - 2022-01-17 21:53:19 --> Utf8 Class Initialized
INFO - 2022-01-17 21:53:19 --> URI Class Initialized
INFO - 2022-01-17 21:53:19 --> Router Class Initialized
INFO - 2022-01-17 21:53:19 --> Output Class Initialized
INFO - 2022-01-17 21:53:19 --> Security Class Initialized
DEBUG - 2022-01-17 21:53:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 21:53:19 --> Input Class Initialized
INFO - 2022-01-17 21:53:19 --> Language Class Initialized
ERROR - 2022-01-17 21:53:19 --> 404 Page Not Found: Cms/index
ERROR - 2022-01-17 21:53:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-17 21:53:20 --> Config Class Initialized
INFO - 2022-01-17 21:53:20 --> Hooks Class Initialized
DEBUG - 2022-01-17 21:53:20 --> UTF-8 Support Enabled
INFO - 2022-01-17 21:53:20 --> Utf8 Class Initialized
INFO - 2022-01-17 21:53:20 --> URI Class Initialized
INFO - 2022-01-17 21:53:20 --> Router Class Initialized
INFO - 2022-01-17 21:53:20 --> Output Class Initialized
INFO - 2022-01-17 21:53:20 --> Security Class Initialized
DEBUG - 2022-01-17 21:53:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 21:53:20 --> Input Class Initialized
INFO - 2022-01-17 21:53:20 --> Language Class Initialized
ERROR - 2022-01-17 21:53:20 --> 404 Page Not Found: Dev/index
ERROR - 2022-01-17 21:53:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-17 21:53:20 --> Config Class Initialized
INFO - 2022-01-17 21:53:20 --> Hooks Class Initialized
DEBUG - 2022-01-17 21:53:20 --> UTF-8 Support Enabled
INFO - 2022-01-17 21:53:20 --> Utf8 Class Initialized
INFO - 2022-01-17 21:53:20 --> URI Class Initialized
INFO - 2022-01-17 21:53:20 --> Router Class Initialized
INFO - 2022-01-17 21:53:20 --> Output Class Initialized
INFO - 2022-01-17 21:53:20 --> Security Class Initialized
DEBUG - 2022-01-17 21:53:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 21:53:20 --> Input Class Initialized
INFO - 2022-01-17 21:53:20 --> Language Class Initialized
ERROR - 2022-01-17 21:53:20 --> 404 Page Not Found: Old-wp/index
ERROR - 2022-01-17 21:53:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-17 21:53:21 --> Config Class Initialized
INFO - 2022-01-17 21:53:21 --> Hooks Class Initialized
DEBUG - 2022-01-17 21:53:21 --> UTF-8 Support Enabled
INFO - 2022-01-17 21:53:21 --> Utf8 Class Initialized
INFO - 2022-01-17 21:53:21 --> URI Class Initialized
INFO - 2022-01-17 21:53:21 --> Router Class Initialized
INFO - 2022-01-17 21:53:21 --> Output Class Initialized
INFO - 2022-01-17 21:53:21 --> Security Class Initialized
DEBUG - 2022-01-17 21:53:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 21:53:21 --> Input Class Initialized
INFO - 2022-01-17 21:53:21 --> Language Class Initialized
ERROR - 2022-01-17 21:53:21 --> 404 Page Not Found: Web/index
ERROR - 2022-01-17 21:53:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-17 21:53:22 --> Config Class Initialized
INFO - 2022-01-17 21:53:22 --> Hooks Class Initialized
DEBUG - 2022-01-17 21:53:22 --> UTF-8 Support Enabled
INFO - 2022-01-17 21:53:22 --> Utf8 Class Initialized
INFO - 2022-01-17 21:53:22 --> URI Class Initialized
INFO - 2022-01-17 21:53:22 --> Router Class Initialized
INFO - 2022-01-17 21:53:22 --> Output Class Initialized
INFO - 2022-01-17 21:53:22 --> Security Class Initialized
DEBUG - 2022-01-17 21:53:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 21:53:22 --> Input Class Initialized
INFO - 2022-01-17 21:53:22 --> Language Class Initialized
ERROR - 2022-01-17 21:53:22 --> 404 Page Not Found: Old-site/index
ERROR - 2022-01-17 21:53:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-17 21:53:23 --> Config Class Initialized
INFO - 2022-01-17 21:53:23 --> Hooks Class Initialized
DEBUG - 2022-01-17 21:53:23 --> UTF-8 Support Enabled
INFO - 2022-01-17 21:53:23 --> Utf8 Class Initialized
INFO - 2022-01-17 21:53:23 --> URI Class Initialized
INFO - 2022-01-17 21:53:23 --> Router Class Initialized
INFO - 2022-01-17 21:53:23 --> Output Class Initialized
INFO - 2022-01-17 21:53:23 --> Security Class Initialized
DEBUG - 2022-01-17 21:53:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 21:53:23 --> Input Class Initialized
INFO - 2022-01-17 21:53:23 --> Language Class Initialized
ERROR - 2022-01-17 21:53:23 --> 404 Page Not Found: Temp/index
ERROR - 2022-01-17 21:53:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-17 21:53:24 --> Config Class Initialized
INFO - 2022-01-17 21:53:24 --> Hooks Class Initialized
DEBUG - 2022-01-17 21:53:24 --> UTF-8 Support Enabled
INFO - 2022-01-17 21:53:24 --> Utf8 Class Initialized
INFO - 2022-01-17 21:53:24 --> URI Class Initialized
INFO - 2022-01-17 21:53:24 --> Router Class Initialized
INFO - 2022-01-17 21:53:24 --> Output Class Initialized
INFO - 2022-01-17 21:53:24 --> Security Class Initialized
DEBUG - 2022-01-17 21:53:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 21:53:24 --> Input Class Initialized
INFO - 2022-01-17 21:53:24 --> Language Class Initialized
ERROR - 2022-01-17 21:53:24 --> 404 Page Not Found: 2018/index
ERROR - 2022-01-17 21:53:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-17 21:53:24 --> Config Class Initialized
INFO - 2022-01-17 21:53:24 --> Hooks Class Initialized
DEBUG - 2022-01-17 21:53:24 --> UTF-8 Support Enabled
INFO - 2022-01-17 21:53:24 --> Utf8 Class Initialized
INFO - 2022-01-17 21:53:24 --> URI Class Initialized
INFO - 2022-01-17 21:53:24 --> Router Class Initialized
INFO - 2022-01-17 21:53:24 --> Output Class Initialized
INFO - 2022-01-17 21:53:24 --> Security Class Initialized
DEBUG - 2022-01-17 21:53:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 21:53:24 --> Input Class Initialized
INFO - 2022-01-17 21:53:24 --> Language Class Initialized
ERROR - 2022-01-17 21:53:24 --> 404 Page Not Found: 2019/index
ERROR - 2022-01-17 21:53:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-17 21:53:25 --> Config Class Initialized
INFO - 2022-01-17 21:53:25 --> Hooks Class Initialized
DEBUG - 2022-01-17 21:53:25 --> UTF-8 Support Enabled
INFO - 2022-01-17 21:53:25 --> Utf8 Class Initialized
INFO - 2022-01-17 21:53:25 --> URI Class Initialized
INFO - 2022-01-17 21:53:25 --> Router Class Initialized
INFO - 2022-01-17 21:53:25 --> Output Class Initialized
INFO - 2022-01-17 21:53:25 --> Security Class Initialized
DEBUG - 2022-01-17 21:53:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 21:53:25 --> Input Class Initialized
INFO - 2022-01-17 21:53:25 --> Language Class Initialized
ERROR - 2022-01-17 21:53:25 --> 404 Page Not Found: Bk/index
ERROR - 2022-01-17 21:53:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-17 21:53:26 --> Config Class Initialized
INFO - 2022-01-17 21:53:26 --> Hooks Class Initialized
DEBUG - 2022-01-17 21:53:26 --> UTF-8 Support Enabled
INFO - 2022-01-17 21:53:26 --> Utf8 Class Initialized
INFO - 2022-01-17 21:53:26 --> URI Class Initialized
INFO - 2022-01-17 21:53:26 --> Router Class Initialized
INFO - 2022-01-17 21:53:26 --> Output Class Initialized
INFO - 2022-01-17 21:53:26 --> Security Class Initialized
DEBUG - 2022-01-17 21:53:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 21:53:26 --> Input Class Initialized
INFO - 2022-01-17 21:53:26 --> Language Class Initialized
ERROR - 2022-01-17 21:53:26 --> 404 Page Not Found: Wp1/index
ERROR - 2022-01-17 21:53:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-17 21:53:26 --> Config Class Initialized
INFO - 2022-01-17 21:53:26 --> Hooks Class Initialized
DEBUG - 2022-01-17 21:53:26 --> UTF-8 Support Enabled
INFO - 2022-01-17 21:53:26 --> Utf8 Class Initialized
INFO - 2022-01-17 21:53:26 --> URI Class Initialized
INFO - 2022-01-17 21:53:26 --> Router Class Initialized
INFO - 2022-01-17 21:53:26 --> Output Class Initialized
INFO - 2022-01-17 21:53:26 --> Security Class Initialized
DEBUG - 2022-01-17 21:53:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 21:53:26 --> Input Class Initialized
INFO - 2022-01-17 21:53:26 --> Language Class Initialized
ERROR - 2022-01-17 21:53:26 --> 404 Page Not Found: Wp2/index
ERROR - 2022-01-17 21:53:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-17 21:53:27 --> Config Class Initialized
INFO - 2022-01-17 21:53:27 --> Hooks Class Initialized
DEBUG - 2022-01-17 21:53:27 --> UTF-8 Support Enabled
INFO - 2022-01-17 21:53:27 --> Utf8 Class Initialized
INFO - 2022-01-17 21:53:27 --> URI Class Initialized
INFO - 2022-01-17 21:53:27 --> Router Class Initialized
INFO - 2022-01-17 21:53:27 --> Output Class Initialized
INFO - 2022-01-17 21:53:27 --> Security Class Initialized
DEBUG - 2022-01-17 21:53:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 21:53:27 --> Input Class Initialized
INFO - 2022-01-17 21:53:27 --> Language Class Initialized
ERROR - 2022-01-17 21:53:27 --> 404 Page Not Found: V1/index
ERROR - 2022-01-17 21:53:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-17 21:53:28 --> Config Class Initialized
INFO - 2022-01-17 21:53:28 --> Hooks Class Initialized
DEBUG - 2022-01-17 21:53:28 --> UTF-8 Support Enabled
INFO - 2022-01-17 21:53:28 --> Utf8 Class Initialized
INFO - 2022-01-17 21:53:28 --> URI Class Initialized
INFO - 2022-01-17 21:53:28 --> Router Class Initialized
INFO - 2022-01-17 21:53:28 --> Output Class Initialized
INFO - 2022-01-17 21:53:28 --> Security Class Initialized
DEBUG - 2022-01-17 21:53:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 21:53:28 --> Input Class Initialized
INFO - 2022-01-17 21:53:28 --> Language Class Initialized
ERROR - 2022-01-17 21:53:28 --> 404 Page Not Found: V2/index
ERROR - 2022-01-17 21:53:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-17 21:53:28 --> Config Class Initialized
INFO - 2022-01-17 21:53:28 --> Hooks Class Initialized
DEBUG - 2022-01-17 21:53:28 --> UTF-8 Support Enabled
INFO - 2022-01-17 21:53:28 --> Utf8 Class Initialized
INFO - 2022-01-17 21:53:28 --> URI Class Initialized
INFO - 2022-01-17 21:53:28 --> Router Class Initialized
INFO - 2022-01-17 21:53:28 --> Output Class Initialized
INFO - 2022-01-17 21:53:28 --> Security Class Initialized
DEBUG - 2022-01-17 21:53:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 21:53:28 --> Input Class Initialized
INFO - 2022-01-17 21:53:28 --> Language Class Initialized
ERROR - 2022-01-17 21:53:28 --> 404 Page Not Found: Bak/index
ERROR - 2022-01-17 21:53:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-17 21:53:29 --> Config Class Initialized
INFO - 2022-01-17 21:53:29 --> Hooks Class Initialized
DEBUG - 2022-01-17 21:53:29 --> UTF-8 Support Enabled
INFO - 2022-01-17 21:53:29 --> Utf8 Class Initialized
INFO - 2022-01-17 21:53:29 --> URI Class Initialized
INFO - 2022-01-17 21:53:29 --> Router Class Initialized
INFO - 2022-01-17 21:53:29 --> Output Class Initialized
INFO - 2022-01-17 21:53:29 --> Security Class Initialized
DEBUG - 2022-01-17 21:53:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 21:53:29 --> Input Class Initialized
INFO - 2022-01-17 21:53:29 --> Language Class Initialized
ERROR - 2022-01-17 21:53:29 --> 404 Page Not Found: Install/index
ERROR - 2022-01-17 21:53:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-17 21:53:29 --> Config Class Initialized
INFO - 2022-01-17 21:53:29 --> Hooks Class Initialized
DEBUG - 2022-01-17 21:53:29 --> UTF-8 Support Enabled
INFO - 2022-01-17 21:53:29 --> Utf8 Class Initialized
INFO - 2022-01-17 21:53:29 --> URI Class Initialized
INFO - 2022-01-17 21:53:29 --> Router Class Initialized
INFO - 2022-01-17 21:53:29 --> Output Class Initialized
INFO - 2022-01-17 21:53:29 --> Security Class Initialized
DEBUG - 2022-01-17 21:53:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 21:53:29 --> Input Class Initialized
INFO - 2022-01-17 21:53:29 --> Language Class Initialized
ERROR - 2022-01-17 21:53:29 --> 404 Page Not Found: 2020/index
ERROR - 2022-01-17 21:53:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-17 21:53:30 --> Config Class Initialized
INFO - 2022-01-17 21:53:30 --> Hooks Class Initialized
DEBUG - 2022-01-17 21:53:30 --> UTF-8 Support Enabled
INFO - 2022-01-17 21:53:30 --> Utf8 Class Initialized
INFO - 2022-01-17 21:53:30 --> URI Class Initialized
INFO - 2022-01-17 21:53:30 --> Router Class Initialized
INFO - 2022-01-17 21:53:30 --> Output Class Initialized
INFO - 2022-01-17 21:53:30 --> Security Class Initialized
DEBUG - 2022-01-17 21:53:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 21:53:30 --> Input Class Initialized
INFO - 2022-01-17 21:53:30 --> Language Class Initialized
ERROR - 2022-01-17 21:53:30 --> 404 Page Not Found: New-site/index
