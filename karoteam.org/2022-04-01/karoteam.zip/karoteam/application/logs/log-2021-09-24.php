<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-09-24 02:20:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-24 02:20:10 --> Config Class Initialized
INFO - 2021-09-24 02:20:10 --> Hooks Class Initialized
DEBUG - 2021-09-24 02:20:10 --> UTF-8 Support Enabled
INFO - 2021-09-24 02:20:10 --> Utf8 Class Initialized
INFO - 2021-09-24 02:20:10 --> URI Class Initialized
DEBUG - 2021-09-24 02:20:10 --> No URI present. Default controller set.
INFO - 2021-09-24 02:20:10 --> Router Class Initialized
INFO - 2021-09-24 02:20:10 --> Output Class Initialized
INFO - 2021-09-24 02:20:10 --> Security Class Initialized
DEBUG - 2021-09-24 02:20:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 02:20:10 --> Input Class Initialized
INFO - 2021-09-24 02:20:10 --> Language Class Initialized
INFO - 2021-09-24 02:20:10 --> Loader Class Initialized
INFO - 2021-09-24 02:20:10 --> Helper loaded: url_helper
INFO - 2021-09-24 02:20:10 --> Helper loaded: form_helper
INFO - 2021-09-24 02:20:10 --> Helper loaded: common_helper
INFO - 2021-09-24 02:20:10 --> Database Driver Class Initialized
DEBUG - 2021-09-24 02:20:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 02:20:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 02:20:10 --> Controller Class Initialized
INFO - 2021-09-24 02:20:10 --> Form Validation Class Initialized
DEBUG - 2021-09-24 02:20:10 --> Encrypt Class Initialized
DEBUG - 2021-09-24 02:20:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-09-24 02:20:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-09-24 02:20:10 --> Email Class Initialized
INFO - 2021-09-24 02:20:10 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-09-24 02:20:10 --> Calendar Class Initialized
INFO - 2021-09-24 02:20:10 --> Model "Login_model" initialized
INFO - 2021-09-24 02:20:10 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-09-24 02:20:10 --> Final output sent to browser
DEBUG - 2021-09-24 02:20:10 --> Total execution time: 0.1104
ERROR - 2021-09-24 06:46:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-24 06:46:34 --> Config Class Initialized
INFO - 2021-09-24 06:46:34 --> Hooks Class Initialized
DEBUG - 2021-09-24 06:46:34 --> UTF-8 Support Enabled
INFO - 2021-09-24 06:46:34 --> Utf8 Class Initialized
INFO - 2021-09-24 06:46:34 --> URI Class Initialized
INFO - 2021-09-24 06:46:34 --> Router Class Initialized
INFO - 2021-09-24 06:46:34 --> Output Class Initialized
INFO - 2021-09-24 06:46:34 --> Security Class Initialized
DEBUG - 2021-09-24 06:46:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 06:46:34 --> Input Class Initialized
INFO - 2021-09-24 06:46:34 --> Language Class Initialized
ERROR - 2021-09-24 06:46:34 --> 404 Page Not Found: Wp-content/index
ERROR - 2021-09-24 08:27:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-24 08:27:32 --> Config Class Initialized
INFO - 2021-09-24 08:27:32 --> Hooks Class Initialized
DEBUG - 2021-09-24 08:27:32 --> UTF-8 Support Enabled
INFO - 2021-09-24 08:27:32 --> Utf8 Class Initialized
INFO - 2021-09-24 08:27:32 --> URI Class Initialized
DEBUG - 2021-09-24 08:27:32 --> No URI present. Default controller set.
INFO - 2021-09-24 08:27:32 --> Router Class Initialized
INFO - 2021-09-24 08:27:32 --> Output Class Initialized
INFO - 2021-09-24 08:27:32 --> Security Class Initialized
DEBUG - 2021-09-24 08:27:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 08:27:32 --> Input Class Initialized
INFO - 2021-09-24 08:27:32 --> Language Class Initialized
INFO - 2021-09-24 08:27:32 --> Loader Class Initialized
INFO - 2021-09-24 08:27:32 --> Helper loaded: url_helper
INFO - 2021-09-24 08:27:32 --> Helper loaded: form_helper
INFO - 2021-09-24 08:27:32 --> Helper loaded: common_helper
INFO - 2021-09-24 08:27:32 --> Database Driver Class Initialized
DEBUG - 2021-09-24 08:27:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 08:27:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 08:27:32 --> Controller Class Initialized
INFO - 2021-09-24 08:27:32 --> Form Validation Class Initialized
DEBUG - 2021-09-24 08:27:32 --> Encrypt Class Initialized
DEBUG - 2021-09-24 08:27:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-09-24 08:27:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-09-24 08:27:32 --> Email Class Initialized
INFO - 2021-09-24 08:27:32 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-09-24 08:27:32 --> Calendar Class Initialized
INFO - 2021-09-24 08:27:32 --> Model "Login_model" initialized
INFO - 2021-09-24 08:27:32 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-09-24 08:27:32 --> Final output sent to browser
DEBUG - 2021-09-24 08:27:32 --> Total execution time: 0.0529
ERROR - 2021-09-24 08:27:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-24 08:27:33 --> Config Class Initialized
INFO - 2021-09-24 08:27:33 --> Hooks Class Initialized
DEBUG - 2021-09-24 08:27:33 --> UTF-8 Support Enabled
INFO - 2021-09-24 08:27:33 --> Utf8 Class Initialized
INFO - 2021-09-24 08:27:33 --> URI Class Initialized
INFO - 2021-09-24 08:27:33 --> Router Class Initialized
INFO - 2021-09-24 08:27:33 --> Output Class Initialized
INFO - 2021-09-24 08:27:33 --> Security Class Initialized
DEBUG - 2021-09-24 08:27:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 08:27:33 --> Input Class Initialized
INFO - 2021-09-24 08:27:33 --> Language Class Initialized
ERROR - 2021-09-24 08:27:33 --> 404 Page Not Found: Blog/wp-includes
ERROR - 2021-09-24 08:27:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-24 08:27:33 --> Config Class Initialized
INFO - 2021-09-24 08:27:33 --> Hooks Class Initialized
DEBUG - 2021-09-24 08:27:33 --> UTF-8 Support Enabled
INFO - 2021-09-24 08:27:33 --> Utf8 Class Initialized
INFO - 2021-09-24 08:27:33 --> URI Class Initialized
INFO - 2021-09-24 08:27:33 --> Router Class Initialized
INFO - 2021-09-24 08:27:33 --> Output Class Initialized
INFO - 2021-09-24 08:27:33 --> Security Class Initialized
DEBUG - 2021-09-24 08:27:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 08:27:33 --> Input Class Initialized
INFO - 2021-09-24 08:27:33 --> Language Class Initialized
ERROR - 2021-09-24 08:27:33 --> 404 Page Not Found: Web/wp-includes
ERROR - 2021-09-24 08:27:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-24 08:27:34 --> Config Class Initialized
INFO - 2021-09-24 08:27:34 --> Hooks Class Initialized
DEBUG - 2021-09-24 08:27:34 --> UTF-8 Support Enabled
INFO - 2021-09-24 08:27:34 --> Utf8 Class Initialized
INFO - 2021-09-24 08:27:34 --> URI Class Initialized
INFO - 2021-09-24 08:27:34 --> Router Class Initialized
INFO - 2021-09-24 08:27:34 --> Output Class Initialized
INFO - 2021-09-24 08:27:34 --> Security Class Initialized
DEBUG - 2021-09-24 08:27:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 08:27:34 --> Input Class Initialized
INFO - 2021-09-24 08:27:34 --> Language Class Initialized
ERROR - 2021-09-24 08:27:34 --> 404 Page Not Found: Wordpress/wp-includes
ERROR - 2021-09-24 08:27:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-24 08:27:34 --> Config Class Initialized
INFO - 2021-09-24 08:27:34 --> Hooks Class Initialized
DEBUG - 2021-09-24 08:27:34 --> UTF-8 Support Enabled
INFO - 2021-09-24 08:27:34 --> Utf8 Class Initialized
INFO - 2021-09-24 08:27:34 --> URI Class Initialized
INFO - 2021-09-24 08:27:34 --> Router Class Initialized
INFO - 2021-09-24 08:27:34 --> Output Class Initialized
INFO - 2021-09-24 08:27:34 --> Security Class Initialized
DEBUG - 2021-09-24 08:27:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 08:27:34 --> Input Class Initialized
INFO - 2021-09-24 08:27:34 --> Language Class Initialized
ERROR - 2021-09-24 08:27:34 --> 404 Page Not Found: Website/wp-includes
ERROR - 2021-09-24 08:27:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-24 08:27:35 --> Config Class Initialized
INFO - 2021-09-24 08:27:35 --> Hooks Class Initialized
DEBUG - 2021-09-24 08:27:35 --> UTF-8 Support Enabled
INFO - 2021-09-24 08:27:35 --> Utf8 Class Initialized
INFO - 2021-09-24 08:27:35 --> URI Class Initialized
INFO - 2021-09-24 08:27:35 --> Router Class Initialized
INFO - 2021-09-24 08:27:35 --> Output Class Initialized
INFO - 2021-09-24 08:27:35 --> Security Class Initialized
DEBUG - 2021-09-24 08:27:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 08:27:35 --> Input Class Initialized
INFO - 2021-09-24 08:27:35 --> Language Class Initialized
ERROR - 2021-09-24 08:27:35 --> 404 Page Not Found: Wp/wp-includes
ERROR - 2021-09-24 08:27:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-24 08:27:35 --> Config Class Initialized
INFO - 2021-09-24 08:27:35 --> Hooks Class Initialized
DEBUG - 2021-09-24 08:27:35 --> UTF-8 Support Enabled
INFO - 2021-09-24 08:27:35 --> Utf8 Class Initialized
INFO - 2021-09-24 08:27:35 --> URI Class Initialized
INFO - 2021-09-24 08:27:35 --> Router Class Initialized
INFO - 2021-09-24 08:27:35 --> Output Class Initialized
INFO - 2021-09-24 08:27:35 --> Security Class Initialized
DEBUG - 2021-09-24 08:27:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 08:27:35 --> Input Class Initialized
INFO - 2021-09-24 08:27:35 --> Language Class Initialized
ERROR - 2021-09-24 08:27:35 --> 404 Page Not Found: News/wp-includes
ERROR - 2021-09-24 08:27:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-24 08:27:36 --> Config Class Initialized
INFO - 2021-09-24 08:27:36 --> Hooks Class Initialized
DEBUG - 2021-09-24 08:27:36 --> UTF-8 Support Enabled
INFO - 2021-09-24 08:27:36 --> Utf8 Class Initialized
INFO - 2021-09-24 08:27:36 --> URI Class Initialized
INFO - 2021-09-24 08:27:36 --> Router Class Initialized
INFO - 2021-09-24 08:27:36 --> Output Class Initialized
INFO - 2021-09-24 08:27:36 --> Security Class Initialized
DEBUG - 2021-09-24 08:27:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 08:27:36 --> Input Class Initialized
INFO - 2021-09-24 08:27:36 --> Language Class Initialized
ERROR - 2021-09-24 08:27:36 --> 404 Page Not Found: Wp1/wp-includes
ERROR - 2021-09-24 08:27:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-24 08:27:36 --> Config Class Initialized
INFO - 2021-09-24 08:27:36 --> Hooks Class Initialized
DEBUG - 2021-09-24 08:27:36 --> UTF-8 Support Enabled
INFO - 2021-09-24 08:27:36 --> Utf8 Class Initialized
INFO - 2021-09-24 08:27:36 --> URI Class Initialized
INFO - 2021-09-24 08:27:36 --> Router Class Initialized
INFO - 2021-09-24 08:27:36 --> Output Class Initialized
INFO - 2021-09-24 08:27:36 --> Security Class Initialized
DEBUG - 2021-09-24 08:27:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 08:27:36 --> Input Class Initialized
INFO - 2021-09-24 08:27:36 --> Language Class Initialized
ERROR - 2021-09-24 08:27:36 --> 404 Page Not Found: Test/wp-includes
ERROR - 2021-09-24 08:27:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-24 08:27:36 --> Config Class Initialized
INFO - 2021-09-24 08:27:36 --> Hooks Class Initialized
DEBUG - 2021-09-24 08:27:36 --> UTF-8 Support Enabled
INFO - 2021-09-24 08:27:36 --> Utf8 Class Initialized
INFO - 2021-09-24 08:27:36 --> URI Class Initialized
INFO - 2021-09-24 08:27:36 --> Router Class Initialized
INFO - 2021-09-24 08:27:36 --> Output Class Initialized
INFO - 2021-09-24 08:27:36 --> Security Class Initialized
DEBUG - 2021-09-24 08:27:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 08:27:36 --> Input Class Initialized
INFO - 2021-09-24 08:27:36 --> Language Class Initialized
ERROR - 2021-09-24 08:27:36 --> 404 Page Not Found: Wp2/wp-includes
ERROR - 2021-09-24 08:27:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-24 08:27:37 --> Config Class Initialized
INFO - 2021-09-24 08:27:37 --> Hooks Class Initialized
DEBUG - 2021-09-24 08:27:37 --> UTF-8 Support Enabled
INFO - 2021-09-24 08:27:37 --> Utf8 Class Initialized
INFO - 2021-09-24 08:27:37 --> URI Class Initialized
INFO - 2021-09-24 08:27:37 --> Router Class Initialized
INFO - 2021-09-24 08:27:37 --> Output Class Initialized
INFO - 2021-09-24 08:27:37 --> Security Class Initialized
DEBUG - 2021-09-24 08:27:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 08:27:37 --> Input Class Initialized
INFO - 2021-09-24 08:27:37 --> Language Class Initialized
ERROR - 2021-09-24 08:27:37 --> 404 Page Not Found: Site/wp-includes
ERROR - 2021-09-24 08:27:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-24 08:27:37 --> Config Class Initialized
INFO - 2021-09-24 08:27:37 --> Hooks Class Initialized
DEBUG - 2021-09-24 08:27:37 --> UTF-8 Support Enabled
INFO - 2021-09-24 08:27:37 --> Utf8 Class Initialized
INFO - 2021-09-24 08:27:37 --> URI Class Initialized
INFO - 2021-09-24 08:27:37 --> Router Class Initialized
INFO - 2021-09-24 08:27:37 --> Output Class Initialized
INFO - 2021-09-24 08:27:37 --> Security Class Initialized
DEBUG - 2021-09-24 08:27:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 08:27:37 --> Input Class Initialized
INFO - 2021-09-24 08:27:37 --> Language Class Initialized
ERROR - 2021-09-24 08:27:37 --> 404 Page Not Found: Cms/wp-includes
ERROR - 2021-09-24 08:27:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-24 08:27:38 --> Config Class Initialized
INFO - 2021-09-24 08:27:38 --> Hooks Class Initialized
DEBUG - 2021-09-24 08:27:38 --> UTF-8 Support Enabled
INFO - 2021-09-24 08:27:38 --> Utf8 Class Initialized
INFO - 2021-09-24 08:27:38 --> URI Class Initialized
INFO - 2021-09-24 08:27:38 --> Router Class Initialized
INFO - 2021-09-24 08:27:38 --> Output Class Initialized
INFO - 2021-09-24 08:27:38 --> Security Class Initialized
DEBUG - 2021-09-24 08:27:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 08:27:38 --> Input Class Initialized
INFO - 2021-09-24 08:27:38 --> Language Class Initialized
ERROR - 2021-09-24 08:27:38 --> 404 Page Not Found: Sito/wp-includes
ERROR - 2021-09-24 09:34:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-24 09:34:28 --> Config Class Initialized
INFO - 2021-09-24 09:34:28 --> Hooks Class Initialized
DEBUG - 2021-09-24 09:34:28 --> UTF-8 Support Enabled
INFO - 2021-09-24 09:34:28 --> Utf8 Class Initialized
INFO - 2021-09-24 09:34:28 --> URI Class Initialized
DEBUG - 2021-09-24 09:34:28 --> No URI present. Default controller set.
INFO - 2021-09-24 09:34:28 --> Router Class Initialized
INFO - 2021-09-24 09:34:28 --> Output Class Initialized
INFO - 2021-09-24 09:34:28 --> Security Class Initialized
DEBUG - 2021-09-24 09:34:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 09:34:28 --> Input Class Initialized
INFO - 2021-09-24 09:34:28 --> Language Class Initialized
INFO - 2021-09-24 09:34:28 --> Loader Class Initialized
INFO - 2021-09-24 09:34:28 --> Helper loaded: url_helper
INFO - 2021-09-24 09:34:28 --> Helper loaded: form_helper
INFO - 2021-09-24 09:34:28 --> Helper loaded: common_helper
INFO - 2021-09-24 09:34:28 --> Database Driver Class Initialized
DEBUG - 2021-09-24 09:34:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 09:34:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 09:34:28 --> Controller Class Initialized
INFO - 2021-09-24 09:34:28 --> Form Validation Class Initialized
DEBUG - 2021-09-24 09:34:28 --> Encrypt Class Initialized
DEBUG - 2021-09-24 09:34:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-09-24 09:34:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-09-24 09:34:28 --> Email Class Initialized
INFO - 2021-09-24 09:34:28 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-09-24 09:34:28 --> Calendar Class Initialized
INFO - 2021-09-24 09:34:28 --> Model "Login_model" initialized
INFO - 2021-09-24 09:34:28 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-09-24 09:34:28 --> Final output sent to browser
DEBUG - 2021-09-24 09:34:28 --> Total execution time: 0.2282
ERROR - 2021-09-24 09:34:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-24 09:34:29 --> Config Class Initialized
INFO - 2021-09-24 09:34:29 --> Hooks Class Initialized
DEBUG - 2021-09-24 09:34:29 --> UTF-8 Support Enabled
INFO - 2021-09-24 09:34:29 --> Utf8 Class Initialized
INFO - 2021-09-24 09:34:29 --> URI Class Initialized
DEBUG - 2021-09-24 09:34:29 --> No URI present. Default controller set.
INFO - 2021-09-24 09:34:29 --> Router Class Initialized
INFO - 2021-09-24 09:34:29 --> Output Class Initialized
INFO - 2021-09-24 09:34:29 --> Security Class Initialized
DEBUG - 2021-09-24 09:34:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 09:34:29 --> Input Class Initialized
INFO - 2021-09-24 09:34:29 --> Language Class Initialized
INFO - 2021-09-24 09:34:29 --> Loader Class Initialized
INFO - 2021-09-24 09:34:29 --> Helper loaded: url_helper
INFO - 2021-09-24 09:34:29 --> Helper loaded: form_helper
INFO - 2021-09-24 09:34:29 --> Helper loaded: common_helper
INFO - 2021-09-24 09:34:29 --> Database Driver Class Initialized
DEBUG - 2021-09-24 09:34:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 09:34:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 09:34:29 --> Controller Class Initialized
INFO - 2021-09-24 09:34:29 --> Form Validation Class Initialized
DEBUG - 2021-09-24 09:34:29 --> Encrypt Class Initialized
DEBUG - 2021-09-24 09:34:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-09-24 09:34:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-09-24 09:34:29 --> Email Class Initialized
INFO - 2021-09-24 09:34:29 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-09-24 09:34:29 --> Calendar Class Initialized
INFO - 2021-09-24 09:34:29 --> Model "Login_model" initialized
INFO - 2021-09-24 09:34:29 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-09-24 09:34:29 --> Final output sent to browser
DEBUG - 2021-09-24 09:34:29 --> Total execution time: 0.0668
ERROR - 2021-09-24 09:34:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-24 09:34:29 --> Config Class Initialized
INFO - 2021-09-24 09:34:29 --> Hooks Class Initialized
DEBUG - 2021-09-24 09:34:29 --> UTF-8 Support Enabled
INFO - 2021-09-24 09:34:29 --> Utf8 Class Initialized
INFO - 2021-09-24 09:34:29 --> URI Class Initialized
INFO - 2021-09-24 09:34:29 --> Router Class Initialized
INFO - 2021-09-24 09:34:29 --> Output Class Initialized
INFO - 2021-09-24 09:34:29 --> Security Class Initialized
DEBUG - 2021-09-24 09:34:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 09:34:29 --> Input Class Initialized
INFO - 2021-09-24 09:34:29 --> Language Class Initialized
ERROR - 2021-09-24 09:34:29 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
ERROR - 2021-09-24 09:34:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-24 09:34:30 --> Config Class Initialized
INFO - 2021-09-24 09:34:30 --> Hooks Class Initialized
DEBUG - 2021-09-24 09:34:30 --> UTF-8 Support Enabled
INFO - 2021-09-24 09:34:30 --> Utf8 Class Initialized
INFO - 2021-09-24 09:34:30 --> URI Class Initialized
DEBUG - 2021-09-24 09:34:30 --> No URI present. Default controller set.
INFO - 2021-09-24 09:34:30 --> Router Class Initialized
INFO - 2021-09-24 09:34:30 --> Output Class Initialized
INFO - 2021-09-24 09:34:30 --> Security Class Initialized
DEBUG - 2021-09-24 09:34:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 09:34:30 --> Input Class Initialized
INFO - 2021-09-24 09:34:30 --> Language Class Initialized
INFO - 2021-09-24 09:34:30 --> Loader Class Initialized
INFO - 2021-09-24 09:34:30 --> Helper loaded: url_helper
INFO - 2021-09-24 09:34:30 --> Helper loaded: form_helper
INFO - 2021-09-24 09:34:30 --> Helper loaded: common_helper
INFO - 2021-09-24 09:34:30 --> Database Driver Class Initialized
DEBUG - 2021-09-24 09:34:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 09:34:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 09:34:30 --> Controller Class Initialized
INFO - 2021-09-24 09:34:30 --> Form Validation Class Initialized
DEBUG - 2021-09-24 09:34:30 --> Encrypt Class Initialized
DEBUG - 2021-09-24 09:34:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-09-24 09:34:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-09-24 09:34:30 --> Email Class Initialized
INFO - 2021-09-24 09:34:30 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-09-24 09:34:30 --> Calendar Class Initialized
INFO - 2021-09-24 09:34:30 --> Model "Login_model" initialized
INFO - 2021-09-24 09:34:30 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-09-24 09:34:30 --> Final output sent to browser
DEBUG - 2021-09-24 09:34:30 --> Total execution time: 0.0801
ERROR - 2021-09-24 09:34:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-24 09:34:31 --> Config Class Initialized
INFO - 2021-09-24 09:34:31 --> Hooks Class Initialized
DEBUG - 2021-09-24 09:34:31 --> UTF-8 Support Enabled
INFO - 2021-09-24 09:34:31 --> Utf8 Class Initialized
INFO - 2021-09-24 09:34:31 --> URI Class Initialized
INFO - 2021-09-24 09:34:31 --> Router Class Initialized
INFO - 2021-09-24 09:34:31 --> Output Class Initialized
INFO - 2021-09-24 09:34:31 --> Security Class Initialized
DEBUG - 2021-09-24 09:34:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 09:34:31 --> Input Class Initialized
INFO - 2021-09-24 09:34:31 --> Language Class Initialized
ERROR - 2021-09-24 09:34:31 --> 404 Page Not Found: Blog/wp-includes
ERROR - 2021-09-24 09:34:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-24 09:34:31 --> Config Class Initialized
INFO - 2021-09-24 09:34:31 --> Hooks Class Initialized
DEBUG - 2021-09-24 09:34:31 --> UTF-8 Support Enabled
INFO - 2021-09-24 09:34:31 --> Utf8 Class Initialized
INFO - 2021-09-24 09:34:31 --> URI Class Initialized
INFO - 2021-09-24 09:34:31 --> Router Class Initialized
INFO - 2021-09-24 09:34:31 --> Output Class Initialized
INFO - 2021-09-24 09:34:31 --> Security Class Initialized
DEBUG - 2021-09-24 09:34:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 09:34:31 --> Input Class Initialized
INFO - 2021-09-24 09:34:31 --> Language Class Initialized
ERROR - 2021-09-24 09:34:31 --> 404 Page Not Found: Web/wp-includes
ERROR - 2021-09-24 09:34:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-24 09:34:32 --> Config Class Initialized
INFO - 2021-09-24 09:34:32 --> Hooks Class Initialized
DEBUG - 2021-09-24 09:34:32 --> UTF-8 Support Enabled
INFO - 2021-09-24 09:34:32 --> Utf8 Class Initialized
INFO - 2021-09-24 09:34:32 --> URI Class Initialized
INFO - 2021-09-24 09:34:32 --> Router Class Initialized
INFO - 2021-09-24 09:34:32 --> Output Class Initialized
INFO - 2021-09-24 09:34:32 --> Security Class Initialized
DEBUG - 2021-09-24 09:34:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 09:34:32 --> Input Class Initialized
INFO - 2021-09-24 09:34:32 --> Language Class Initialized
ERROR - 2021-09-24 09:34:32 --> 404 Page Not Found: Wordpress/wp-includes
ERROR - 2021-09-24 09:34:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-24 09:34:32 --> Config Class Initialized
INFO - 2021-09-24 09:34:32 --> Hooks Class Initialized
DEBUG - 2021-09-24 09:34:32 --> UTF-8 Support Enabled
INFO - 2021-09-24 09:34:32 --> Utf8 Class Initialized
INFO - 2021-09-24 09:34:32 --> URI Class Initialized
INFO - 2021-09-24 09:34:32 --> Router Class Initialized
INFO - 2021-09-24 09:34:32 --> Output Class Initialized
INFO - 2021-09-24 09:34:32 --> Security Class Initialized
DEBUG - 2021-09-24 09:34:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 09:34:32 --> Input Class Initialized
INFO - 2021-09-24 09:34:32 --> Language Class Initialized
ERROR - 2021-09-24 09:34:32 --> 404 Page Not Found: Website/wp-includes
ERROR - 2021-09-24 09:34:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-24 09:34:33 --> Config Class Initialized
INFO - 2021-09-24 09:34:33 --> Hooks Class Initialized
DEBUG - 2021-09-24 09:34:33 --> UTF-8 Support Enabled
INFO - 2021-09-24 09:34:33 --> Utf8 Class Initialized
INFO - 2021-09-24 09:34:33 --> URI Class Initialized
INFO - 2021-09-24 09:34:33 --> Router Class Initialized
INFO - 2021-09-24 09:34:33 --> Output Class Initialized
INFO - 2021-09-24 09:34:33 --> Security Class Initialized
DEBUG - 2021-09-24 09:34:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 09:34:33 --> Input Class Initialized
INFO - 2021-09-24 09:34:33 --> Language Class Initialized
ERROR - 2021-09-24 09:34:33 --> 404 Page Not Found: Wp/wp-includes
ERROR - 2021-09-24 09:34:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-24 09:34:33 --> Config Class Initialized
INFO - 2021-09-24 09:34:33 --> Hooks Class Initialized
DEBUG - 2021-09-24 09:34:33 --> UTF-8 Support Enabled
INFO - 2021-09-24 09:34:33 --> Utf8 Class Initialized
INFO - 2021-09-24 09:34:33 --> URI Class Initialized
INFO - 2021-09-24 09:34:33 --> Router Class Initialized
INFO - 2021-09-24 09:34:33 --> Output Class Initialized
INFO - 2021-09-24 09:34:33 --> Security Class Initialized
DEBUG - 2021-09-24 09:34:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 09:34:33 --> Input Class Initialized
INFO - 2021-09-24 09:34:33 --> Language Class Initialized
ERROR - 2021-09-24 09:34:33 --> 404 Page Not Found: News/wp-includes
ERROR - 2021-09-24 09:34:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-24 09:34:34 --> Config Class Initialized
INFO - 2021-09-24 09:34:34 --> Hooks Class Initialized
DEBUG - 2021-09-24 09:34:34 --> UTF-8 Support Enabled
INFO - 2021-09-24 09:34:34 --> Utf8 Class Initialized
INFO - 2021-09-24 09:34:34 --> URI Class Initialized
INFO - 2021-09-24 09:34:34 --> Router Class Initialized
INFO - 2021-09-24 09:34:34 --> Output Class Initialized
INFO - 2021-09-24 09:34:34 --> Security Class Initialized
DEBUG - 2021-09-24 09:34:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 09:34:34 --> Input Class Initialized
INFO - 2021-09-24 09:34:34 --> Language Class Initialized
ERROR - 2021-09-24 09:34:34 --> 404 Page Not Found: 2020/wp-includes
ERROR - 2021-09-24 09:34:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-24 09:34:34 --> Config Class Initialized
INFO - 2021-09-24 09:34:34 --> Hooks Class Initialized
DEBUG - 2021-09-24 09:34:34 --> UTF-8 Support Enabled
INFO - 2021-09-24 09:34:34 --> Utf8 Class Initialized
INFO - 2021-09-24 09:34:34 --> URI Class Initialized
INFO - 2021-09-24 09:34:34 --> Router Class Initialized
INFO - 2021-09-24 09:34:34 --> Output Class Initialized
INFO - 2021-09-24 09:34:34 --> Security Class Initialized
DEBUG - 2021-09-24 09:34:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 09:34:34 --> Input Class Initialized
INFO - 2021-09-24 09:34:34 --> Language Class Initialized
ERROR - 2021-09-24 09:34:34 --> 404 Page Not Found: 2019/wp-includes
ERROR - 2021-09-24 09:34:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-24 09:34:35 --> Config Class Initialized
INFO - 2021-09-24 09:34:35 --> Hooks Class Initialized
DEBUG - 2021-09-24 09:34:35 --> UTF-8 Support Enabled
INFO - 2021-09-24 09:34:35 --> Utf8 Class Initialized
INFO - 2021-09-24 09:34:35 --> URI Class Initialized
INFO - 2021-09-24 09:34:35 --> Router Class Initialized
INFO - 2021-09-24 09:34:35 --> Output Class Initialized
INFO - 2021-09-24 09:34:35 --> Security Class Initialized
DEBUG - 2021-09-24 09:34:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 09:34:35 --> Input Class Initialized
INFO - 2021-09-24 09:34:35 --> Language Class Initialized
ERROR - 2021-09-24 09:34:35 --> 404 Page Not Found: Shop/wp-includes
ERROR - 2021-09-24 09:34:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-24 09:34:35 --> Config Class Initialized
INFO - 2021-09-24 09:34:35 --> Hooks Class Initialized
DEBUG - 2021-09-24 09:34:35 --> UTF-8 Support Enabled
INFO - 2021-09-24 09:34:35 --> Utf8 Class Initialized
INFO - 2021-09-24 09:34:35 --> URI Class Initialized
INFO - 2021-09-24 09:34:35 --> Router Class Initialized
INFO - 2021-09-24 09:34:35 --> Output Class Initialized
INFO - 2021-09-24 09:34:35 --> Security Class Initialized
DEBUG - 2021-09-24 09:34:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 09:34:35 --> Input Class Initialized
INFO - 2021-09-24 09:34:35 --> Language Class Initialized
ERROR - 2021-09-24 09:34:35 --> 404 Page Not Found: Wp1/wp-includes
ERROR - 2021-09-24 09:34:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-24 09:34:36 --> Config Class Initialized
INFO - 2021-09-24 09:34:36 --> Hooks Class Initialized
DEBUG - 2021-09-24 09:34:36 --> UTF-8 Support Enabled
INFO - 2021-09-24 09:34:36 --> Utf8 Class Initialized
INFO - 2021-09-24 09:34:36 --> URI Class Initialized
INFO - 2021-09-24 09:34:36 --> Router Class Initialized
INFO - 2021-09-24 09:34:36 --> Output Class Initialized
INFO - 2021-09-24 09:34:36 --> Security Class Initialized
DEBUG - 2021-09-24 09:34:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 09:34:36 --> Input Class Initialized
INFO - 2021-09-24 09:34:36 --> Language Class Initialized
ERROR - 2021-09-24 09:34:36 --> 404 Page Not Found: Test/wp-includes
ERROR - 2021-09-24 09:34:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-24 09:34:36 --> Config Class Initialized
INFO - 2021-09-24 09:34:36 --> Hooks Class Initialized
DEBUG - 2021-09-24 09:34:36 --> UTF-8 Support Enabled
INFO - 2021-09-24 09:34:36 --> Utf8 Class Initialized
INFO - 2021-09-24 09:34:36 --> URI Class Initialized
INFO - 2021-09-24 09:34:36 --> Router Class Initialized
INFO - 2021-09-24 09:34:36 --> Output Class Initialized
INFO - 2021-09-24 09:34:36 --> Security Class Initialized
DEBUG - 2021-09-24 09:34:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 09:34:36 --> Input Class Initialized
INFO - 2021-09-24 09:34:36 --> Language Class Initialized
ERROR - 2021-09-24 09:34:36 --> 404 Page Not Found: Wp2/wp-includes
ERROR - 2021-09-24 09:34:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-24 09:34:37 --> Config Class Initialized
INFO - 2021-09-24 09:34:37 --> Hooks Class Initialized
DEBUG - 2021-09-24 09:34:37 --> UTF-8 Support Enabled
INFO - 2021-09-24 09:34:37 --> Utf8 Class Initialized
INFO - 2021-09-24 09:34:37 --> URI Class Initialized
INFO - 2021-09-24 09:34:37 --> Router Class Initialized
INFO - 2021-09-24 09:34:37 --> Output Class Initialized
INFO - 2021-09-24 09:34:37 --> Security Class Initialized
DEBUG - 2021-09-24 09:34:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 09:34:37 --> Input Class Initialized
INFO - 2021-09-24 09:34:37 --> Language Class Initialized
ERROR - 2021-09-24 09:34:37 --> 404 Page Not Found: Site/wp-includes
ERROR - 2021-09-24 09:34:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-24 09:34:37 --> Config Class Initialized
INFO - 2021-09-24 09:34:37 --> Hooks Class Initialized
DEBUG - 2021-09-24 09:34:37 --> UTF-8 Support Enabled
INFO - 2021-09-24 09:34:37 --> Utf8 Class Initialized
INFO - 2021-09-24 09:34:37 --> URI Class Initialized
INFO - 2021-09-24 09:34:37 --> Router Class Initialized
INFO - 2021-09-24 09:34:37 --> Output Class Initialized
INFO - 2021-09-24 09:34:37 --> Security Class Initialized
DEBUG - 2021-09-24 09:34:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 09:34:37 --> Input Class Initialized
INFO - 2021-09-24 09:34:37 --> Language Class Initialized
ERROR - 2021-09-24 09:34:37 --> 404 Page Not Found: Cms/wp-includes
ERROR - 2021-09-24 09:34:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-24 09:34:37 --> Config Class Initialized
INFO - 2021-09-24 09:34:37 --> Hooks Class Initialized
DEBUG - 2021-09-24 09:34:37 --> UTF-8 Support Enabled
INFO - 2021-09-24 09:34:37 --> Utf8 Class Initialized
INFO - 2021-09-24 09:34:37 --> URI Class Initialized
INFO - 2021-09-24 09:34:37 --> Router Class Initialized
INFO - 2021-09-24 09:34:37 --> Output Class Initialized
INFO - 2021-09-24 09:34:37 --> Security Class Initialized
DEBUG - 2021-09-24 09:34:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 09:34:37 --> Input Class Initialized
INFO - 2021-09-24 09:34:37 --> Language Class Initialized
ERROR - 2021-09-24 09:34:37 --> 404 Page Not Found: Sito/wp-includes
ERROR - 2021-09-24 16:17:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-24 16:17:51 --> Config Class Initialized
INFO - 2021-09-24 16:17:51 --> Hooks Class Initialized
DEBUG - 2021-09-24 16:17:51 --> UTF-8 Support Enabled
INFO - 2021-09-24 16:17:51 --> Utf8 Class Initialized
INFO - 2021-09-24 16:17:51 --> URI Class Initialized
DEBUG - 2021-09-24 16:17:51 --> No URI present. Default controller set.
INFO - 2021-09-24 16:17:51 --> Router Class Initialized
INFO - 2021-09-24 16:17:51 --> Output Class Initialized
INFO - 2021-09-24 16:17:51 --> Security Class Initialized
DEBUG - 2021-09-24 16:17:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 16:17:51 --> Input Class Initialized
INFO - 2021-09-24 16:17:51 --> Language Class Initialized
INFO - 2021-09-24 16:17:51 --> Loader Class Initialized
INFO - 2021-09-24 16:17:51 --> Helper loaded: url_helper
INFO - 2021-09-24 16:17:51 --> Helper loaded: form_helper
INFO - 2021-09-24 16:17:51 --> Helper loaded: common_helper
INFO - 2021-09-24 16:17:51 --> Database Driver Class Initialized
DEBUG - 2021-09-24 16:17:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 16:17:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 16:17:51 --> Controller Class Initialized
INFO - 2021-09-24 16:17:51 --> Form Validation Class Initialized
DEBUG - 2021-09-24 16:17:51 --> Encrypt Class Initialized
DEBUG - 2021-09-24 16:17:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-09-24 16:17:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-09-24 16:17:51 --> Email Class Initialized
INFO - 2021-09-24 16:17:51 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-09-24 16:17:51 --> Calendar Class Initialized
INFO - 2021-09-24 16:17:51 --> Model "Login_model" initialized
INFO - 2021-09-24 16:17:51 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-09-24 16:17:51 --> Final output sent to browser
DEBUG - 2021-09-24 16:17:51 --> Total execution time: 0.0461
ERROR - 2021-09-24 20:03:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-24 20:03:34 --> Config Class Initialized
INFO - 2021-09-24 20:03:34 --> Hooks Class Initialized
DEBUG - 2021-09-24 20:03:34 --> UTF-8 Support Enabled
INFO - 2021-09-24 20:03:34 --> Utf8 Class Initialized
INFO - 2021-09-24 20:03:34 --> URI Class Initialized
DEBUG - 2021-09-24 20:03:34 --> No URI present. Default controller set.
INFO - 2021-09-24 20:03:34 --> Router Class Initialized
INFO - 2021-09-24 20:03:34 --> Output Class Initialized
INFO - 2021-09-24 20:03:34 --> Security Class Initialized
DEBUG - 2021-09-24 20:03:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 20:03:34 --> Input Class Initialized
INFO - 2021-09-24 20:03:34 --> Language Class Initialized
INFO - 2021-09-24 20:03:34 --> Loader Class Initialized
INFO - 2021-09-24 20:03:34 --> Helper loaded: url_helper
INFO - 2021-09-24 20:03:34 --> Helper loaded: form_helper
INFO - 2021-09-24 20:03:34 --> Helper loaded: common_helper
INFO - 2021-09-24 20:03:34 --> Database Driver Class Initialized
DEBUG - 2021-09-24 20:03:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 20:03:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 20:03:34 --> Controller Class Initialized
INFO - 2021-09-24 20:03:34 --> Form Validation Class Initialized
DEBUG - 2021-09-24 20:03:34 --> Encrypt Class Initialized
DEBUG - 2021-09-24 20:03:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-09-24 20:03:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-09-24 20:03:34 --> Email Class Initialized
INFO - 2021-09-24 20:03:34 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-09-24 20:03:34 --> Calendar Class Initialized
INFO - 2021-09-24 20:03:34 --> Model "Login_model" initialized
INFO - 2021-09-24 20:03:34 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-09-24 20:03:34 --> Final output sent to browser
DEBUG - 2021-09-24 20:03:34 --> Total execution time: 0.0402
ERROR - 2021-09-24 21:20:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-24 21:20:20 --> Config Class Initialized
INFO - 2021-09-24 21:20:20 --> Hooks Class Initialized
DEBUG - 2021-09-24 21:20:20 --> UTF-8 Support Enabled
INFO - 2021-09-24 21:20:20 --> Utf8 Class Initialized
INFO - 2021-09-24 21:20:20 --> URI Class Initialized
DEBUG - 2021-09-24 21:20:20 --> No URI present. Default controller set.
INFO - 2021-09-24 21:20:20 --> Router Class Initialized
INFO - 2021-09-24 21:20:20 --> Output Class Initialized
INFO - 2021-09-24 21:20:20 --> Security Class Initialized
DEBUG - 2021-09-24 21:20:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 21:20:20 --> Input Class Initialized
INFO - 2021-09-24 21:20:20 --> Language Class Initialized
INFO - 2021-09-24 21:20:20 --> Loader Class Initialized
INFO - 2021-09-24 21:20:20 --> Helper loaded: url_helper
INFO - 2021-09-24 21:20:20 --> Helper loaded: form_helper
INFO - 2021-09-24 21:20:20 --> Helper loaded: common_helper
INFO - 2021-09-24 21:20:20 --> Database Driver Class Initialized
DEBUG - 2021-09-24 21:20:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 21:20:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 21:20:20 --> Controller Class Initialized
INFO - 2021-09-24 21:20:20 --> Form Validation Class Initialized
DEBUG - 2021-09-24 21:20:20 --> Encrypt Class Initialized
DEBUG - 2021-09-24 21:20:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-09-24 21:20:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-09-24 21:20:20 --> Email Class Initialized
INFO - 2021-09-24 21:20:20 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-09-24 21:20:20 --> Calendar Class Initialized
INFO - 2021-09-24 21:20:20 --> Model "Login_model" initialized
INFO - 2021-09-24 21:20:20 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-09-24 21:20:20 --> Final output sent to browser
DEBUG - 2021-09-24 21:20:20 --> Total execution time: 0.0484
