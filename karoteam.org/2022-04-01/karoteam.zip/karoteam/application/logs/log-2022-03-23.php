<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-03-23 00:00:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 00:00:36 --> Config Class Initialized
INFO - 2022-03-23 00:00:36 --> Hooks Class Initialized
DEBUG - 2022-03-23 00:00:36 --> UTF-8 Support Enabled
INFO - 2022-03-23 00:00:36 --> Utf8 Class Initialized
INFO - 2022-03-23 00:00:36 --> URI Class Initialized
INFO - 2022-03-23 00:00:36 --> Router Class Initialized
INFO - 2022-03-23 00:00:36 --> Output Class Initialized
INFO - 2022-03-23 00:00:36 --> Security Class Initialized
DEBUG - 2022-03-23 00:00:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 00:00:36 --> Input Class Initialized
INFO - 2022-03-23 00:00:36 --> Language Class Initialized
INFO - 2022-03-23 00:00:36 --> Loader Class Initialized
INFO - 2022-03-23 00:00:36 --> Helper loaded: url_helper
INFO - 2022-03-23 00:00:36 --> Helper loaded: form_helper
INFO - 2022-03-23 00:00:36 --> Helper loaded: common_helper
INFO - 2022-03-23 00:00:36 --> Database Driver Class Initialized
DEBUG - 2022-03-23 00:00:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 00:00:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 00:00:36 --> Controller Class Initialized
INFO - 2022-03-23 00:00:36 --> Form Validation Class Initialized
DEBUG - 2022-03-23 00:00:36 --> Encrypt Class Initialized
DEBUG - 2022-03-23 00:00:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 00:00:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-23 00:00:36 --> Email Class Initialized
INFO - 2022-03-23 00:00:36 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-23 00:00:36 --> Calendar Class Initialized
INFO - 2022-03-23 00:00:36 --> Model "Login_model" initialized
ERROR - 2022-03-23 00:00:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 00:00:37 --> Config Class Initialized
INFO - 2022-03-23 00:00:37 --> Hooks Class Initialized
DEBUG - 2022-03-23 00:00:37 --> UTF-8 Support Enabled
INFO - 2022-03-23 00:00:37 --> Utf8 Class Initialized
INFO - 2022-03-23 00:00:37 --> URI Class Initialized
INFO - 2022-03-23 00:00:37 --> Router Class Initialized
INFO - 2022-03-23 00:00:37 --> Output Class Initialized
INFO - 2022-03-23 00:00:37 --> Security Class Initialized
DEBUG - 2022-03-23 00:00:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 00:00:37 --> Input Class Initialized
INFO - 2022-03-23 00:00:37 --> Language Class Initialized
INFO - 2022-03-23 00:00:37 --> Loader Class Initialized
INFO - 2022-03-23 00:00:37 --> Helper loaded: url_helper
INFO - 2022-03-23 00:00:37 --> Helper loaded: form_helper
INFO - 2022-03-23 00:00:37 --> Helper loaded: common_helper
INFO - 2022-03-23 00:00:37 --> Database Driver Class Initialized
DEBUG - 2022-03-23 00:00:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 00:00:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 00:00:37 --> Controller Class Initialized
INFO - 2022-03-23 00:00:37 --> Form Validation Class Initialized
DEBUG - 2022-03-23 00:00:37 --> Encrypt Class Initialized
INFO - 2022-03-23 00:00:37 --> Model "Diseases_model" initialized
INFO - 2022-03-23 00:00:37 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 00:00:37 --> File loaded: /home3/karoteam/public_html/application/views/diseases/index.php
INFO - 2022-03-23 00:00:37 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 00:00:37 --> Final output sent to browser
DEBUG - 2022-03-23 00:00:37 --> Total execution time: 0.0124
ERROR - 2022-03-23 00:01:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 00:01:00 --> Config Class Initialized
INFO - 2022-03-23 00:01:00 --> Hooks Class Initialized
DEBUG - 2022-03-23 00:01:00 --> UTF-8 Support Enabled
INFO - 2022-03-23 00:01:00 --> Utf8 Class Initialized
INFO - 2022-03-23 00:01:00 --> URI Class Initialized
INFO - 2022-03-23 00:01:00 --> Router Class Initialized
INFO - 2022-03-23 00:01:00 --> Output Class Initialized
INFO - 2022-03-23 00:01:00 --> Security Class Initialized
DEBUG - 2022-03-23 00:01:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 00:01:00 --> Input Class Initialized
INFO - 2022-03-23 00:01:00 --> Language Class Initialized
INFO - 2022-03-23 00:01:00 --> Loader Class Initialized
INFO - 2022-03-23 00:01:00 --> Helper loaded: url_helper
INFO - 2022-03-23 00:01:00 --> Helper loaded: form_helper
INFO - 2022-03-23 00:01:00 --> Helper loaded: common_helper
INFO - 2022-03-23 00:01:00 --> Database Driver Class Initialized
DEBUG - 2022-03-23 00:01:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 00:01:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 00:01:00 --> Controller Class Initialized
INFO - 2022-03-23 00:01:00 --> Form Validation Class Initialized
DEBUG - 2022-03-23 00:01:00 --> Encrypt Class Initialized
INFO - 2022-03-23 00:01:00 --> Model "Patient_model" initialized
INFO - 2022-03-23 00:01:00 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 00:01:00 --> Model "Referredby_model" initialized
INFO - 2022-03-23 00:01:00 --> Model "Prefix_master" initialized
INFO - 2022-03-23 00:01:00 --> Model "Hospital_model" initialized
INFO - 2022-03-23 00:01:00 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 00:01:00 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-23 00:01:00 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 00:01:00 --> Final output sent to browser
DEBUG - 2022-03-23 00:01:00 --> Total execution time: 0.0610
ERROR - 2022-03-23 00:02:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 00:02:00 --> Config Class Initialized
INFO - 2022-03-23 00:02:00 --> Hooks Class Initialized
DEBUG - 2022-03-23 00:02:00 --> UTF-8 Support Enabled
INFO - 2022-03-23 00:02:00 --> Utf8 Class Initialized
INFO - 2022-03-23 00:02:00 --> URI Class Initialized
INFO - 2022-03-23 00:02:00 --> Router Class Initialized
INFO - 2022-03-23 00:02:00 --> Output Class Initialized
INFO - 2022-03-23 00:02:00 --> Security Class Initialized
DEBUG - 2022-03-23 00:02:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 00:02:00 --> Input Class Initialized
INFO - 2022-03-23 00:02:00 --> Language Class Initialized
INFO - 2022-03-23 00:02:00 --> Loader Class Initialized
INFO - 2022-03-23 00:02:00 --> Helper loaded: url_helper
INFO - 2022-03-23 00:02:00 --> Helper loaded: form_helper
INFO - 2022-03-23 00:02:00 --> Helper loaded: common_helper
INFO - 2022-03-23 00:02:00 --> Database Driver Class Initialized
DEBUG - 2022-03-23 00:02:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 00:02:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 00:02:00 --> Controller Class Initialized
INFO - 2022-03-23 00:02:00 --> Form Validation Class Initialized
DEBUG - 2022-03-23 00:02:00 --> Encrypt Class Initialized
INFO - 2022-03-23 00:02:00 --> Model "Patient_model" initialized
INFO - 2022-03-23 00:02:00 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 00:02:00 --> Model "Referredby_model" initialized
INFO - 2022-03-23 00:02:00 --> Model "Prefix_master" initialized
INFO - 2022-03-23 00:02:00 --> Model "Hospital_model" initialized
INFO - 2022-03-23 00:02:00 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 00:02:00 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-23 00:02:00 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 00:02:00 --> Final output sent to browser
DEBUG - 2022-03-23 00:02:00 --> Total execution time: 0.0272
ERROR - 2022-03-23 00:02:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 00:02:16 --> Config Class Initialized
INFO - 2022-03-23 00:02:16 --> Hooks Class Initialized
DEBUG - 2022-03-23 00:02:16 --> UTF-8 Support Enabled
INFO - 2022-03-23 00:02:16 --> Utf8 Class Initialized
INFO - 2022-03-23 00:02:16 --> URI Class Initialized
INFO - 2022-03-23 00:02:16 --> Router Class Initialized
INFO - 2022-03-23 00:02:16 --> Output Class Initialized
INFO - 2022-03-23 00:02:16 --> Security Class Initialized
DEBUG - 2022-03-23 00:02:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 00:02:16 --> Input Class Initialized
INFO - 2022-03-23 00:02:16 --> Language Class Initialized
INFO - 2022-03-23 00:02:16 --> Loader Class Initialized
INFO - 2022-03-23 00:02:16 --> Helper loaded: url_helper
INFO - 2022-03-23 00:02:16 --> Helper loaded: form_helper
INFO - 2022-03-23 00:02:16 --> Helper loaded: common_helper
INFO - 2022-03-23 00:02:16 --> Database Driver Class Initialized
DEBUG - 2022-03-23 00:02:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 00:02:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 00:02:16 --> Controller Class Initialized
INFO - 2022-03-23 00:02:16 --> Form Validation Class Initialized
DEBUG - 2022-03-23 00:02:16 --> Encrypt Class Initialized
INFO - 2022-03-23 00:02:16 --> Model "Patient_model" initialized
INFO - 2022-03-23 00:02:16 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 00:02:16 --> Model "Referredby_model" initialized
INFO - 2022-03-23 00:02:16 --> Model "Prefix_master" initialized
INFO - 2022-03-23 00:02:16 --> Model "Hospital_model" initialized
ERROR - 2022-03-23 00:02:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 00:02:16 --> Config Class Initialized
INFO - 2022-03-23 00:02:16 --> Hooks Class Initialized
DEBUG - 2022-03-23 00:02:16 --> UTF-8 Support Enabled
INFO - 2022-03-23 00:02:16 --> Utf8 Class Initialized
INFO - 2022-03-23 00:02:16 --> URI Class Initialized
INFO - 2022-03-23 00:02:16 --> Router Class Initialized
INFO - 2022-03-23 00:02:16 --> Output Class Initialized
INFO - 2022-03-23 00:02:16 --> Security Class Initialized
DEBUG - 2022-03-23 00:02:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 00:02:16 --> Input Class Initialized
INFO - 2022-03-23 00:02:16 --> Language Class Initialized
INFO - 2022-03-23 00:02:16 --> Loader Class Initialized
INFO - 2022-03-23 00:02:16 --> Helper loaded: url_helper
INFO - 2022-03-23 00:02:16 --> Helper loaded: form_helper
INFO - 2022-03-23 00:02:16 --> Helper loaded: common_helper
INFO - 2022-03-23 00:02:16 --> Database Driver Class Initialized
DEBUG - 2022-03-23 00:02:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 00:02:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 00:02:16 --> Controller Class Initialized
INFO - 2022-03-23 00:02:16 --> Form Validation Class Initialized
DEBUG - 2022-03-23 00:02:16 --> Encrypt Class Initialized
INFO - 2022-03-23 00:02:16 --> Model "Patient_model" initialized
INFO - 2022-03-23 00:02:16 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 00:02:16 --> Model "Referredby_model" initialized
INFO - 2022-03-23 00:02:16 --> Model "Prefix_master" initialized
INFO - 2022-03-23 00:02:16 --> Model "Hospital_model" initialized
INFO - 2022-03-23 00:02:16 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 00:02:16 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-23 00:02:16 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 00:02:16 --> Final output sent to browser
DEBUG - 2022-03-23 00:02:16 --> Total execution time: 0.0358
ERROR - 2022-03-23 00:02:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 00:02:17 --> Config Class Initialized
INFO - 2022-03-23 00:02:17 --> Hooks Class Initialized
DEBUG - 2022-03-23 00:02:17 --> UTF-8 Support Enabled
INFO - 2022-03-23 00:02:17 --> Utf8 Class Initialized
INFO - 2022-03-23 00:02:17 --> URI Class Initialized
INFO - 2022-03-23 00:02:17 --> Router Class Initialized
INFO - 2022-03-23 00:02:17 --> Output Class Initialized
INFO - 2022-03-23 00:02:17 --> Security Class Initialized
DEBUG - 2022-03-23 00:02:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 00:02:17 --> Input Class Initialized
INFO - 2022-03-23 00:02:17 --> Language Class Initialized
INFO - 2022-03-23 00:02:17 --> Loader Class Initialized
INFO - 2022-03-23 00:02:17 --> Helper loaded: url_helper
INFO - 2022-03-23 00:02:17 --> Helper loaded: form_helper
INFO - 2022-03-23 00:02:17 --> Helper loaded: common_helper
INFO - 2022-03-23 00:02:17 --> Database Driver Class Initialized
DEBUG - 2022-03-23 00:02:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 00:02:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 00:02:17 --> Controller Class Initialized
INFO - 2022-03-23 00:02:17 --> Form Validation Class Initialized
DEBUG - 2022-03-23 00:02:17 --> Encrypt Class Initialized
INFO - 2022-03-23 00:02:17 --> Model "Patient_model" initialized
INFO - 2022-03-23 00:02:17 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 00:02:17 --> Model "Prefix_master" initialized
INFO - 2022-03-23 00:02:17 --> Model "Users_model" initialized
INFO - 2022-03-23 00:02:17 --> Model "Hospital_model" initialized
INFO - 2022-03-23 00:02:17 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 00:02:17 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-23 00:02:17 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 00:02:17 --> Final output sent to browser
DEBUG - 2022-03-23 00:02:17 --> Total execution time: 0.0509
ERROR - 2022-03-23 00:02:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 00:02:30 --> Config Class Initialized
INFO - 2022-03-23 00:02:30 --> Hooks Class Initialized
DEBUG - 2022-03-23 00:02:30 --> UTF-8 Support Enabled
INFO - 2022-03-23 00:02:30 --> Utf8 Class Initialized
INFO - 2022-03-23 00:02:30 --> URI Class Initialized
INFO - 2022-03-23 00:02:30 --> Router Class Initialized
INFO - 2022-03-23 00:02:30 --> Output Class Initialized
INFO - 2022-03-23 00:02:30 --> Security Class Initialized
DEBUG - 2022-03-23 00:02:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 00:02:30 --> Input Class Initialized
INFO - 2022-03-23 00:02:30 --> Language Class Initialized
INFO - 2022-03-23 00:02:30 --> Loader Class Initialized
INFO - 2022-03-23 00:02:30 --> Helper loaded: url_helper
INFO - 2022-03-23 00:02:30 --> Helper loaded: form_helper
INFO - 2022-03-23 00:02:30 --> Helper loaded: common_helper
INFO - 2022-03-23 00:02:30 --> Database Driver Class Initialized
DEBUG - 2022-03-23 00:02:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 00:02:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 00:02:30 --> Controller Class Initialized
INFO - 2022-03-23 00:02:30 --> Form Validation Class Initialized
DEBUG - 2022-03-23 00:02:30 --> Encrypt Class Initialized
INFO - 2022-03-23 00:02:30 --> Model "Patient_model" initialized
INFO - 2022-03-23 00:02:30 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 00:02:30 --> Model "Prefix_master" initialized
INFO - 2022-03-23 00:02:30 --> Model "Users_model" initialized
INFO - 2022-03-23 00:02:30 --> Model "Hospital_model" initialized
ERROR - 2022-03-23 00:02:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 00:02:30 --> Config Class Initialized
INFO - 2022-03-23 00:02:30 --> Hooks Class Initialized
DEBUG - 2022-03-23 00:02:30 --> UTF-8 Support Enabled
INFO - 2022-03-23 00:02:30 --> Utf8 Class Initialized
INFO - 2022-03-23 00:02:30 --> URI Class Initialized
INFO - 2022-03-23 00:02:30 --> Router Class Initialized
INFO - 2022-03-23 00:02:30 --> Output Class Initialized
INFO - 2022-03-23 00:02:30 --> Security Class Initialized
DEBUG - 2022-03-23 00:02:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 00:02:30 --> Input Class Initialized
INFO - 2022-03-23 00:02:30 --> Language Class Initialized
INFO - 2022-03-23 00:02:30 --> Loader Class Initialized
INFO - 2022-03-23 00:02:30 --> Helper loaded: url_helper
INFO - 2022-03-23 00:02:30 --> Helper loaded: form_helper
INFO - 2022-03-23 00:02:30 --> Helper loaded: common_helper
INFO - 2022-03-23 00:02:30 --> Database Driver Class Initialized
DEBUG - 2022-03-23 00:02:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 00:02:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 00:02:30 --> Controller Class Initialized
INFO - 2022-03-23 00:02:30 --> Form Validation Class Initialized
DEBUG - 2022-03-23 00:02:30 --> Encrypt Class Initialized
INFO - 2022-03-23 00:02:30 --> Model "Patient_model" initialized
INFO - 2022-03-23 00:02:30 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 00:02:30 --> Model "Prefix_master" initialized
INFO - 2022-03-23 00:02:30 --> Model "Users_model" initialized
INFO - 2022-03-23 00:02:30 --> Model "Hospital_model" initialized
INFO - 2022-03-23 00:02:30 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 00:02:30 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-23 00:02:30 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 00:02:30 --> Final output sent to browser
DEBUG - 2022-03-23 00:02:30 --> Total execution time: 0.0389
ERROR - 2022-03-23 00:03:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 00:03:07 --> Config Class Initialized
INFO - 2022-03-23 00:03:07 --> Hooks Class Initialized
DEBUG - 2022-03-23 00:03:07 --> UTF-8 Support Enabled
INFO - 2022-03-23 00:03:07 --> Utf8 Class Initialized
INFO - 2022-03-23 00:03:07 --> URI Class Initialized
INFO - 2022-03-23 00:03:07 --> Router Class Initialized
INFO - 2022-03-23 00:03:07 --> Output Class Initialized
INFO - 2022-03-23 00:03:07 --> Security Class Initialized
DEBUG - 2022-03-23 00:03:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 00:03:07 --> Input Class Initialized
INFO - 2022-03-23 00:03:07 --> Language Class Initialized
INFO - 2022-03-23 00:03:07 --> Loader Class Initialized
INFO - 2022-03-23 00:03:07 --> Helper loaded: url_helper
INFO - 2022-03-23 00:03:07 --> Helper loaded: form_helper
INFO - 2022-03-23 00:03:07 --> Helper loaded: common_helper
INFO - 2022-03-23 00:03:07 --> Database Driver Class Initialized
DEBUG - 2022-03-23 00:03:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 00:03:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 00:03:07 --> Controller Class Initialized
INFO - 2022-03-23 00:03:07 --> Form Validation Class Initialized
DEBUG - 2022-03-23 00:03:07 --> Encrypt Class Initialized
INFO - 2022-03-23 00:03:07 --> Model "Patient_model" initialized
INFO - 2022-03-23 00:03:07 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 00:03:07 --> Model "Prefix_master" initialized
INFO - 2022-03-23 00:03:07 --> Model "Users_model" initialized
INFO - 2022-03-23 00:03:07 --> Model "Hospital_model" initialized
ERROR - 2022-03-23 00:03:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 00:03:08 --> Config Class Initialized
INFO - 2022-03-23 00:03:08 --> Hooks Class Initialized
DEBUG - 2022-03-23 00:03:08 --> UTF-8 Support Enabled
INFO - 2022-03-23 00:03:08 --> Utf8 Class Initialized
INFO - 2022-03-23 00:03:08 --> URI Class Initialized
INFO - 2022-03-23 00:03:08 --> Router Class Initialized
INFO - 2022-03-23 00:03:08 --> Output Class Initialized
INFO - 2022-03-23 00:03:08 --> Security Class Initialized
DEBUG - 2022-03-23 00:03:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 00:03:08 --> Input Class Initialized
INFO - 2022-03-23 00:03:08 --> Language Class Initialized
INFO - 2022-03-23 00:03:08 --> Loader Class Initialized
INFO - 2022-03-23 00:03:08 --> Helper loaded: url_helper
INFO - 2022-03-23 00:03:08 --> Helper loaded: form_helper
INFO - 2022-03-23 00:03:08 --> Helper loaded: common_helper
INFO - 2022-03-23 00:03:08 --> Database Driver Class Initialized
DEBUG - 2022-03-23 00:03:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 00:03:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 00:03:08 --> Controller Class Initialized
INFO - 2022-03-23 00:03:08 --> Form Validation Class Initialized
DEBUG - 2022-03-23 00:03:08 --> Encrypt Class Initialized
INFO - 2022-03-23 00:03:08 --> Model "Patient_model" initialized
INFO - 2022-03-23 00:03:08 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 00:03:08 --> Model "Prefix_master" initialized
INFO - 2022-03-23 00:03:08 --> Model "Users_model" initialized
INFO - 2022-03-23 00:03:08 --> Model "Hospital_model" initialized
INFO - 2022-03-23 00:03:08 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 00:03:08 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-23 00:03:08 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 00:03:08 --> Final output sent to browser
DEBUG - 2022-03-23 00:03:08 --> Total execution time: 0.0417
ERROR - 2022-03-23 00:03:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 00:03:26 --> Config Class Initialized
INFO - 2022-03-23 00:03:26 --> Hooks Class Initialized
DEBUG - 2022-03-23 00:03:26 --> UTF-8 Support Enabled
INFO - 2022-03-23 00:03:26 --> Utf8 Class Initialized
INFO - 2022-03-23 00:03:26 --> URI Class Initialized
INFO - 2022-03-23 00:03:26 --> Router Class Initialized
INFO - 2022-03-23 00:03:26 --> Output Class Initialized
INFO - 2022-03-23 00:03:26 --> Security Class Initialized
DEBUG - 2022-03-23 00:03:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 00:03:26 --> Input Class Initialized
INFO - 2022-03-23 00:03:26 --> Language Class Initialized
INFO - 2022-03-23 00:03:26 --> Loader Class Initialized
INFO - 2022-03-23 00:03:26 --> Helper loaded: url_helper
INFO - 2022-03-23 00:03:26 --> Helper loaded: form_helper
INFO - 2022-03-23 00:03:26 --> Helper loaded: common_helper
INFO - 2022-03-23 00:03:26 --> Database Driver Class Initialized
DEBUG - 2022-03-23 00:03:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 00:03:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 00:03:26 --> Controller Class Initialized
INFO - 2022-03-23 00:03:26 --> Form Validation Class Initialized
DEBUG - 2022-03-23 00:03:26 --> Encrypt Class Initialized
INFO - 2022-03-23 00:03:26 --> Model "Patient_model" initialized
INFO - 2022-03-23 00:03:26 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 00:03:26 --> Model "Prefix_master" initialized
INFO - 2022-03-23 00:03:26 --> Model "Users_model" initialized
INFO - 2022-03-23 00:03:26 --> Model "Hospital_model" initialized
ERROR - 2022-03-23 00:03:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 00:03:26 --> Config Class Initialized
INFO - 2022-03-23 00:03:26 --> Hooks Class Initialized
DEBUG - 2022-03-23 00:03:26 --> UTF-8 Support Enabled
INFO - 2022-03-23 00:03:26 --> Utf8 Class Initialized
INFO - 2022-03-23 00:03:26 --> URI Class Initialized
INFO - 2022-03-23 00:03:26 --> Router Class Initialized
INFO - 2022-03-23 00:03:26 --> Output Class Initialized
INFO - 2022-03-23 00:03:26 --> Security Class Initialized
DEBUG - 2022-03-23 00:03:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 00:03:26 --> Input Class Initialized
INFO - 2022-03-23 00:03:26 --> Language Class Initialized
INFO - 2022-03-23 00:03:26 --> Loader Class Initialized
INFO - 2022-03-23 00:03:26 --> Helper loaded: url_helper
INFO - 2022-03-23 00:03:26 --> Helper loaded: form_helper
INFO - 2022-03-23 00:03:26 --> Helper loaded: common_helper
INFO - 2022-03-23 00:03:26 --> Database Driver Class Initialized
DEBUG - 2022-03-23 00:03:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 00:03:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 00:03:26 --> Controller Class Initialized
INFO - 2022-03-23 00:03:26 --> Form Validation Class Initialized
DEBUG - 2022-03-23 00:03:26 --> Encrypt Class Initialized
INFO - 2022-03-23 00:03:26 --> Model "Patient_model" initialized
INFO - 2022-03-23 00:03:26 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 00:03:26 --> Model "Prefix_master" initialized
INFO - 2022-03-23 00:03:26 --> Model "Users_model" initialized
INFO - 2022-03-23 00:03:26 --> Model "Hospital_model" initialized
INFO - 2022-03-23 00:03:26 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 00:03:26 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-23 00:03:26 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 00:03:26 --> Final output sent to browser
DEBUG - 2022-03-23 00:03:26 --> Total execution time: 0.0638
ERROR - 2022-03-23 00:03:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 00:03:44 --> Config Class Initialized
INFO - 2022-03-23 00:03:44 --> Hooks Class Initialized
DEBUG - 2022-03-23 00:03:44 --> UTF-8 Support Enabled
INFO - 2022-03-23 00:03:44 --> Utf8 Class Initialized
INFO - 2022-03-23 00:03:44 --> URI Class Initialized
INFO - 2022-03-23 00:03:44 --> Router Class Initialized
INFO - 2022-03-23 00:03:44 --> Output Class Initialized
INFO - 2022-03-23 00:03:44 --> Security Class Initialized
DEBUG - 2022-03-23 00:03:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 00:03:44 --> Input Class Initialized
INFO - 2022-03-23 00:03:44 --> Language Class Initialized
INFO - 2022-03-23 00:03:44 --> Loader Class Initialized
INFO - 2022-03-23 00:03:44 --> Helper loaded: url_helper
INFO - 2022-03-23 00:03:44 --> Helper loaded: form_helper
INFO - 2022-03-23 00:03:44 --> Helper loaded: common_helper
INFO - 2022-03-23 00:03:44 --> Database Driver Class Initialized
DEBUG - 2022-03-23 00:03:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 00:03:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 00:03:44 --> Controller Class Initialized
INFO - 2022-03-23 00:03:44 --> Form Validation Class Initialized
DEBUG - 2022-03-23 00:03:44 --> Encrypt Class Initialized
INFO - 2022-03-23 00:03:44 --> Model "Patient_model" initialized
INFO - 2022-03-23 00:03:44 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 00:03:44 --> Model "Prefix_master" initialized
INFO - 2022-03-23 00:03:44 --> Model "Users_model" initialized
INFO - 2022-03-23 00:03:44 --> Model "Hospital_model" initialized
ERROR - 2022-03-23 00:03:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 00:03:44 --> Config Class Initialized
INFO - 2022-03-23 00:03:44 --> Hooks Class Initialized
DEBUG - 2022-03-23 00:03:44 --> UTF-8 Support Enabled
INFO - 2022-03-23 00:03:44 --> Utf8 Class Initialized
INFO - 2022-03-23 00:03:44 --> URI Class Initialized
INFO - 2022-03-23 00:03:44 --> Router Class Initialized
INFO - 2022-03-23 00:03:44 --> Output Class Initialized
INFO - 2022-03-23 00:03:44 --> Security Class Initialized
DEBUG - 2022-03-23 00:03:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 00:03:44 --> Input Class Initialized
INFO - 2022-03-23 00:03:44 --> Language Class Initialized
INFO - 2022-03-23 00:03:44 --> Loader Class Initialized
INFO - 2022-03-23 00:03:44 --> Helper loaded: url_helper
INFO - 2022-03-23 00:03:44 --> Helper loaded: form_helper
INFO - 2022-03-23 00:03:44 --> Helper loaded: common_helper
INFO - 2022-03-23 00:03:44 --> Database Driver Class Initialized
DEBUG - 2022-03-23 00:03:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 00:03:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 00:03:44 --> Controller Class Initialized
INFO - 2022-03-23 00:03:44 --> Form Validation Class Initialized
DEBUG - 2022-03-23 00:03:44 --> Encrypt Class Initialized
INFO - 2022-03-23 00:03:44 --> Model "Patient_model" initialized
INFO - 2022-03-23 00:03:44 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 00:03:44 --> Model "Prefix_master" initialized
INFO - 2022-03-23 00:03:44 --> Model "Users_model" initialized
INFO - 2022-03-23 00:03:44 --> Model "Hospital_model" initialized
INFO - 2022-03-23 00:03:44 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 00:03:44 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-23 00:03:44 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 00:03:44 --> Final output sent to browser
DEBUG - 2022-03-23 00:03:44 --> Total execution time: 0.0594
ERROR - 2022-03-23 00:04:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 00:04:02 --> Config Class Initialized
INFO - 2022-03-23 00:04:02 --> Hooks Class Initialized
DEBUG - 2022-03-23 00:04:02 --> UTF-8 Support Enabled
INFO - 2022-03-23 00:04:02 --> Utf8 Class Initialized
INFO - 2022-03-23 00:04:02 --> URI Class Initialized
INFO - 2022-03-23 00:04:02 --> Router Class Initialized
INFO - 2022-03-23 00:04:02 --> Output Class Initialized
INFO - 2022-03-23 00:04:02 --> Security Class Initialized
DEBUG - 2022-03-23 00:04:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 00:04:02 --> Input Class Initialized
INFO - 2022-03-23 00:04:02 --> Language Class Initialized
INFO - 2022-03-23 00:04:02 --> Loader Class Initialized
INFO - 2022-03-23 00:04:02 --> Helper loaded: url_helper
INFO - 2022-03-23 00:04:02 --> Helper loaded: form_helper
INFO - 2022-03-23 00:04:02 --> Helper loaded: common_helper
INFO - 2022-03-23 00:04:02 --> Database Driver Class Initialized
DEBUG - 2022-03-23 00:04:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 00:04:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 00:04:02 --> Controller Class Initialized
INFO - 2022-03-23 00:04:02 --> Form Validation Class Initialized
DEBUG - 2022-03-23 00:04:02 --> Encrypt Class Initialized
INFO - 2022-03-23 00:04:02 --> Model "Patient_model" initialized
INFO - 2022-03-23 00:04:02 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 00:04:02 --> Model "Prefix_master" initialized
INFO - 2022-03-23 00:04:02 --> Model "Users_model" initialized
INFO - 2022-03-23 00:04:02 --> Model "Hospital_model" initialized
ERROR - 2022-03-23 00:04:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 00:04:02 --> Config Class Initialized
INFO - 2022-03-23 00:04:02 --> Hooks Class Initialized
DEBUG - 2022-03-23 00:04:02 --> UTF-8 Support Enabled
INFO - 2022-03-23 00:04:02 --> Utf8 Class Initialized
INFO - 2022-03-23 00:04:02 --> URI Class Initialized
INFO - 2022-03-23 00:04:02 --> Router Class Initialized
INFO - 2022-03-23 00:04:02 --> Output Class Initialized
INFO - 2022-03-23 00:04:02 --> Security Class Initialized
DEBUG - 2022-03-23 00:04:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 00:04:02 --> Input Class Initialized
INFO - 2022-03-23 00:04:02 --> Language Class Initialized
INFO - 2022-03-23 00:04:02 --> Loader Class Initialized
INFO - 2022-03-23 00:04:02 --> Helper loaded: url_helper
INFO - 2022-03-23 00:04:02 --> Helper loaded: form_helper
INFO - 2022-03-23 00:04:02 --> Helper loaded: common_helper
INFO - 2022-03-23 00:04:02 --> Database Driver Class Initialized
DEBUG - 2022-03-23 00:04:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 00:04:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 00:04:02 --> Controller Class Initialized
INFO - 2022-03-23 00:04:02 --> Form Validation Class Initialized
DEBUG - 2022-03-23 00:04:02 --> Encrypt Class Initialized
INFO - 2022-03-23 00:04:02 --> Model "Patient_model" initialized
INFO - 2022-03-23 00:04:02 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 00:04:02 --> Model "Prefix_master" initialized
INFO - 2022-03-23 00:04:02 --> Model "Users_model" initialized
INFO - 2022-03-23 00:04:02 --> Model "Hospital_model" initialized
INFO - 2022-03-23 00:04:02 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 00:04:02 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-23 00:04:02 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 00:04:02 --> Final output sent to browser
DEBUG - 2022-03-23 00:04:02 --> Total execution time: 0.0410
ERROR - 2022-03-23 00:04:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 00:04:20 --> Config Class Initialized
INFO - 2022-03-23 00:04:20 --> Hooks Class Initialized
DEBUG - 2022-03-23 00:04:20 --> UTF-8 Support Enabled
INFO - 2022-03-23 00:04:20 --> Utf8 Class Initialized
INFO - 2022-03-23 00:04:20 --> URI Class Initialized
INFO - 2022-03-23 00:04:20 --> Router Class Initialized
INFO - 2022-03-23 00:04:20 --> Output Class Initialized
INFO - 2022-03-23 00:04:20 --> Security Class Initialized
DEBUG - 2022-03-23 00:04:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 00:04:20 --> Input Class Initialized
INFO - 2022-03-23 00:04:20 --> Language Class Initialized
INFO - 2022-03-23 00:04:20 --> Loader Class Initialized
INFO - 2022-03-23 00:04:20 --> Helper loaded: url_helper
INFO - 2022-03-23 00:04:20 --> Helper loaded: form_helper
INFO - 2022-03-23 00:04:20 --> Helper loaded: common_helper
INFO - 2022-03-23 00:04:20 --> Database Driver Class Initialized
DEBUG - 2022-03-23 00:04:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 00:04:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 00:04:20 --> Controller Class Initialized
INFO - 2022-03-23 00:04:20 --> Form Validation Class Initialized
DEBUG - 2022-03-23 00:04:20 --> Encrypt Class Initialized
INFO - 2022-03-23 00:04:20 --> Model "Patient_model" initialized
INFO - 2022-03-23 00:04:20 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 00:04:20 --> Model "Referredby_model" initialized
INFO - 2022-03-23 00:04:20 --> Model "Prefix_master" initialized
INFO - 2022-03-23 00:04:20 --> Model "Hospital_model" initialized
INFO - 2022-03-23 00:04:20 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 00:04:20 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-23 00:04:20 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 00:04:20 --> Final output sent to browser
DEBUG - 2022-03-23 00:04:20 --> Total execution time: 0.0350
ERROR - 2022-03-23 00:04:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 00:04:25 --> Config Class Initialized
INFO - 2022-03-23 00:04:25 --> Hooks Class Initialized
DEBUG - 2022-03-23 00:04:25 --> UTF-8 Support Enabled
INFO - 2022-03-23 00:04:25 --> Utf8 Class Initialized
INFO - 2022-03-23 00:04:25 --> URI Class Initialized
INFO - 2022-03-23 00:04:25 --> Router Class Initialized
INFO - 2022-03-23 00:04:25 --> Output Class Initialized
INFO - 2022-03-23 00:04:25 --> Security Class Initialized
DEBUG - 2022-03-23 00:04:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 00:04:25 --> Input Class Initialized
INFO - 2022-03-23 00:04:25 --> Language Class Initialized
INFO - 2022-03-23 00:04:25 --> Loader Class Initialized
INFO - 2022-03-23 00:04:25 --> Helper loaded: url_helper
INFO - 2022-03-23 00:04:25 --> Helper loaded: form_helper
INFO - 2022-03-23 00:04:25 --> Helper loaded: common_helper
INFO - 2022-03-23 00:04:25 --> Database Driver Class Initialized
DEBUG - 2022-03-23 00:04:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 00:04:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 00:04:25 --> Controller Class Initialized
INFO - 2022-03-23 00:04:25 --> Form Validation Class Initialized
DEBUG - 2022-03-23 00:04:25 --> Encrypt Class Initialized
INFO - 2022-03-23 00:04:25 --> Model "Patient_model" initialized
INFO - 2022-03-23 00:04:25 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 00:04:25 --> Model "Prefix_master" initialized
INFO - 2022-03-23 00:04:25 --> Model "Users_model" initialized
INFO - 2022-03-23 00:04:25 --> Model "Hospital_model" initialized
ERROR - 2022-03-23 00:04:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 00:04:25 --> Config Class Initialized
INFO - 2022-03-23 00:04:25 --> Hooks Class Initialized
DEBUG - 2022-03-23 00:04:25 --> UTF-8 Support Enabled
INFO - 2022-03-23 00:04:25 --> Utf8 Class Initialized
INFO - 2022-03-23 00:04:25 --> URI Class Initialized
INFO - 2022-03-23 00:04:25 --> Router Class Initialized
INFO - 2022-03-23 00:04:25 --> Output Class Initialized
INFO - 2022-03-23 00:04:25 --> Security Class Initialized
DEBUG - 2022-03-23 00:04:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 00:04:25 --> Input Class Initialized
INFO - 2022-03-23 00:04:25 --> Language Class Initialized
INFO - 2022-03-23 00:04:25 --> Loader Class Initialized
INFO - 2022-03-23 00:04:25 --> Helper loaded: url_helper
INFO - 2022-03-23 00:04:25 --> Helper loaded: form_helper
INFO - 2022-03-23 00:04:25 --> Helper loaded: common_helper
INFO - 2022-03-23 00:04:25 --> Database Driver Class Initialized
DEBUG - 2022-03-23 00:04:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 00:04:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 00:04:25 --> Controller Class Initialized
INFO - 2022-03-23 00:04:25 --> Form Validation Class Initialized
DEBUG - 2022-03-23 00:04:25 --> Encrypt Class Initialized
INFO - 2022-03-23 00:04:25 --> Model "Patient_model" initialized
INFO - 2022-03-23 00:04:25 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 00:04:25 --> Model "Prefix_master" initialized
INFO - 2022-03-23 00:04:25 --> Model "Users_model" initialized
INFO - 2022-03-23 00:04:25 --> Model "Hospital_model" initialized
INFO - 2022-03-23 00:04:25 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 00:04:25 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-23 00:04:25 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 00:04:25 --> Final output sent to browser
DEBUG - 2022-03-23 00:04:25 --> Total execution time: 0.0641
ERROR - 2022-03-23 00:04:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 00:04:32 --> Config Class Initialized
INFO - 2022-03-23 00:04:32 --> Hooks Class Initialized
DEBUG - 2022-03-23 00:04:32 --> UTF-8 Support Enabled
INFO - 2022-03-23 00:04:32 --> Utf8 Class Initialized
INFO - 2022-03-23 00:04:32 --> URI Class Initialized
INFO - 2022-03-23 00:04:32 --> Router Class Initialized
INFO - 2022-03-23 00:04:32 --> Output Class Initialized
INFO - 2022-03-23 00:04:32 --> Security Class Initialized
DEBUG - 2022-03-23 00:04:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 00:04:32 --> Input Class Initialized
INFO - 2022-03-23 00:04:32 --> Language Class Initialized
INFO - 2022-03-23 00:04:32 --> Loader Class Initialized
INFO - 2022-03-23 00:04:32 --> Helper loaded: url_helper
INFO - 2022-03-23 00:04:32 --> Helper loaded: form_helper
INFO - 2022-03-23 00:04:32 --> Helper loaded: common_helper
INFO - 2022-03-23 00:04:32 --> Database Driver Class Initialized
DEBUG - 2022-03-23 00:04:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 00:04:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 00:04:32 --> Controller Class Initialized
INFO - 2022-03-23 00:04:32 --> Form Validation Class Initialized
DEBUG - 2022-03-23 00:04:32 --> Encrypt Class Initialized
INFO - 2022-03-23 00:04:32 --> Model "Patient_model" initialized
INFO - 2022-03-23 00:04:32 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 00:04:32 --> Model "Referredby_model" initialized
INFO - 2022-03-23 00:04:32 --> Model "Prefix_master" initialized
INFO - 2022-03-23 00:04:32 --> Model "Hospital_model" initialized
INFO - 2022-03-23 00:04:32 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 00:04:32 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-23 00:04:32 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 00:04:32 --> Final output sent to browser
DEBUG - 2022-03-23 00:04:32 --> Total execution time: 0.0702
ERROR - 2022-03-23 00:04:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 00:04:44 --> Config Class Initialized
INFO - 2022-03-23 00:04:44 --> Hooks Class Initialized
DEBUG - 2022-03-23 00:04:44 --> UTF-8 Support Enabled
INFO - 2022-03-23 00:04:44 --> Utf8 Class Initialized
INFO - 2022-03-23 00:04:44 --> URI Class Initialized
INFO - 2022-03-23 00:04:44 --> Router Class Initialized
INFO - 2022-03-23 00:04:44 --> Output Class Initialized
INFO - 2022-03-23 00:04:44 --> Security Class Initialized
DEBUG - 2022-03-23 00:04:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 00:04:44 --> Input Class Initialized
INFO - 2022-03-23 00:04:44 --> Language Class Initialized
INFO - 2022-03-23 00:04:44 --> Loader Class Initialized
INFO - 2022-03-23 00:04:44 --> Helper loaded: url_helper
INFO - 2022-03-23 00:04:44 --> Helper loaded: form_helper
INFO - 2022-03-23 00:04:44 --> Helper loaded: common_helper
INFO - 2022-03-23 00:04:44 --> Database Driver Class Initialized
DEBUG - 2022-03-23 00:04:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 00:04:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 00:04:44 --> Controller Class Initialized
INFO - 2022-03-23 00:04:44 --> Form Validation Class Initialized
DEBUG - 2022-03-23 00:04:44 --> Encrypt Class Initialized
INFO - 2022-03-23 00:04:44 --> Model "Patient_model" initialized
INFO - 2022-03-23 00:04:44 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 00:04:44 --> Model "Prefix_master" initialized
INFO - 2022-03-23 00:04:44 --> Model "Users_model" initialized
INFO - 2022-03-23 00:04:44 --> Model "Hospital_model" initialized
INFO - 2022-03-23 00:04:44 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-23 00:04:46 --> Final output sent to browser
DEBUG - 2022-03-23 00:04:46 --> Total execution time: 1.4868
ERROR - 2022-03-23 00:05:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 00:05:07 --> Config Class Initialized
INFO - 2022-03-23 00:05:07 --> Hooks Class Initialized
DEBUG - 2022-03-23 00:05:07 --> UTF-8 Support Enabled
INFO - 2022-03-23 00:05:07 --> Utf8 Class Initialized
INFO - 2022-03-23 00:05:07 --> URI Class Initialized
INFO - 2022-03-23 00:05:07 --> Router Class Initialized
INFO - 2022-03-23 00:05:07 --> Output Class Initialized
INFO - 2022-03-23 00:05:07 --> Security Class Initialized
DEBUG - 2022-03-23 00:05:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 00:05:07 --> Input Class Initialized
INFO - 2022-03-23 00:05:07 --> Language Class Initialized
INFO - 2022-03-23 00:05:07 --> Loader Class Initialized
INFO - 2022-03-23 00:05:07 --> Helper loaded: url_helper
INFO - 2022-03-23 00:05:07 --> Helper loaded: form_helper
INFO - 2022-03-23 00:05:07 --> Helper loaded: common_helper
INFO - 2022-03-23 00:05:07 --> Database Driver Class Initialized
DEBUG - 2022-03-23 00:05:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 00:05:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 00:05:07 --> Controller Class Initialized
INFO - 2022-03-23 00:05:07 --> Form Validation Class Initialized
DEBUG - 2022-03-23 00:05:07 --> Encrypt Class Initialized
INFO - 2022-03-23 00:05:07 --> Model "Patient_model" initialized
INFO - 2022-03-23 00:05:07 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 00:05:07 --> Model "Referredby_model" initialized
INFO - 2022-03-23 00:05:07 --> Model "Prefix_master" initialized
INFO - 2022-03-23 00:05:07 --> Model "Hospital_model" initialized
ERROR - 2022-03-23 00:05:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 00:05:08 --> Config Class Initialized
INFO - 2022-03-23 00:05:08 --> Hooks Class Initialized
DEBUG - 2022-03-23 00:05:08 --> UTF-8 Support Enabled
INFO - 2022-03-23 00:05:08 --> Utf8 Class Initialized
INFO - 2022-03-23 00:05:08 --> URI Class Initialized
INFO - 2022-03-23 00:05:08 --> Router Class Initialized
INFO - 2022-03-23 00:05:08 --> Output Class Initialized
INFO - 2022-03-23 00:05:08 --> Security Class Initialized
DEBUG - 2022-03-23 00:05:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 00:05:08 --> Input Class Initialized
INFO - 2022-03-23 00:05:08 --> Language Class Initialized
INFO - 2022-03-23 00:05:08 --> Loader Class Initialized
INFO - 2022-03-23 00:05:08 --> Helper loaded: url_helper
INFO - 2022-03-23 00:05:08 --> Helper loaded: form_helper
INFO - 2022-03-23 00:05:08 --> Helper loaded: common_helper
INFO - 2022-03-23 00:05:08 --> Database Driver Class Initialized
DEBUG - 2022-03-23 00:05:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 00:05:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 00:05:08 --> Controller Class Initialized
INFO - 2022-03-23 00:05:08 --> Form Validation Class Initialized
DEBUG - 2022-03-23 00:05:08 --> Encrypt Class Initialized
INFO - 2022-03-23 00:05:08 --> Model "Patient_model" initialized
INFO - 2022-03-23 00:05:08 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 00:05:08 --> Model "Referredby_model" initialized
INFO - 2022-03-23 00:05:08 --> Model "Prefix_master" initialized
INFO - 2022-03-23 00:05:08 --> Model "Hospital_model" initialized
INFO - 2022-03-23 00:05:08 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 00:05:08 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-23 00:05:08 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 00:05:08 --> Final output sent to browser
DEBUG - 2022-03-23 00:05:08 --> Total execution time: 0.0535
ERROR - 2022-03-23 00:05:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 00:05:08 --> Config Class Initialized
INFO - 2022-03-23 00:05:08 --> Hooks Class Initialized
DEBUG - 2022-03-23 00:05:08 --> UTF-8 Support Enabled
INFO - 2022-03-23 00:05:08 --> Utf8 Class Initialized
INFO - 2022-03-23 00:05:08 --> URI Class Initialized
INFO - 2022-03-23 00:05:08 --> Router Class Initialized
INFO - 2022-03-23 00:05:08 --> Output Class Initialized
INFO - 2022-03-23 00:05:08 --> Security Class Initialized
DEBUG - 2022-03-23 00:05:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 00:05:08 --> Input Class Initialized
INFO - 2022-03-23 00:05:08 --> Language Class Initialized
INFO - 2022-03-23 00:05:08 --> Loader Class Initialized
INFO - 2022-03-23 00:05:08 --> Helper loaded: url_helper
INFO - 2022-03-23 00:05:08 --> Helper loaded: form_helper
INFO - 2022-03-23 00:05:08 --> Helper loaded: common_helper
INFO - 2022-03-23 00:05:08 --> Database Driver Class Initialized
DEBUG - 2022-03-23 00:05:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 00:05:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 00:05:08 --> Controller Class Initialized
INFO - 2022-03-23 00:05:08 --> Form Validation Class Initialized
DEBUG - 2022-03-23 00:05:08 --> Encrypt Class Initialized
INFO - 2022-03-23 00:05:08 --> Model "Patient_model" initialized
INFO - 2022-03-23 00:05:08 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 00:05:08 --> Model "Prefix_master" initialized
INFO - 2022-03-23 00:05:08 --> Model "Users_model" initialized
INFO - 2022-03-23 00:05:08 --> Model "Hospital_model" initialized
INFO - 2022-03-23 00:05:08 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 00:05:08 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-23 00:05:08 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 00:05:08 --> Final output sent to browser
DEBUG - 2022-03-23 00:05:08 --> Total execution time: 0.0697
ERROR - 2022-03-23 00:11:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 00:11:32 --> Config Class Initialized
INFO - 2022-03-23 00:11:32 --> Hooks Class Initialized
DEBUG - 2022-03-23 00:11:32 --> UTF-8 Support Enabled
INFO - 2022-03-23 00:11:32 --> Utf8 Class Initialized
INFO - 2022-03-23 00:11:32 --> URI Class Initialized
INFO - 2022-03-23 00:11:32 --> Router Class Initialized
INFO - 2022-03-23 00:11:32 --> Output Class Initialized
INFO - 2022-03-23 00:11:32 --> Security Class Initialized
DEBUG - 2022-03-23 00:11:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 00:11:32 --> Input Class Initialized
INFO - 2022-03-23 00:11:32 --> Language Class Initialized
INFO - 2022-03-23 00:11:32 --> Loader Class Initialized
INFO - 2022-03-23 00:11:32 --> Helper loaded: url_helper
INFO - 2022-03-23 00:11:32 --> Helper loaded: form_helper
INFO - 2022-03-23 00:11:32 --> Helper loaded: common_helper
INFO - 2022-03-23 00:11:32 --> Database Driver Class Initialized
DEBUG - 2022-03-23 00:11:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 00:11:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 00:11:32 --> Controller Class Initialized
INFO - 2022-03-23 00:11:32 --> Form Validation Class Initialized
DEBUG - 2022-03-23 00:11:32 --> Encrypt Class Initialized
INFO - 2022-03-23 00:11:32 --> Model "Patient_model" initialized
INFO - 2022-03-23 00:11:32 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 00:11:32 --> Model "Prefix_master" initialized
INFO - 2022-03-23 00:11:32 --> Model "Users_model" initialized
INFO - 2022-03-23 00:11:32 --> Model "Hospital_model" initialized
INFO - 2022-03-23 00:11:32 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 00:11:32 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-23 00:11:32 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 00:11:32 --> Final output sent to browser
DEBUG - 2022-03-23 00:11:32 --> Total execution time: 0.1157
ERROR - 2022-03-23 00:11:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 00:11:37 --> Config Class Initialized
INFO - 2022-03-23 00:11:37 --> Hooks Class Initialized
DEBUG - 2022-03-23 00:11:37 --> UTF-8 Support Enabled
INFO - 2022-03-23 00:11:37 --> Utf8 Class Initialized
INFO - 2022-03-23 00:11:37 --> URI Class Initialized
INFO - 2022-03-23 00:11:37 --> Router Class Initialized
INFO - 2022-03-23 00:11:37 --> Output Class Initialized
INFO - 2022-03-23 00:11:37 --> Security Class Initialized
DEBUG - 2022-03-23 00:11:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 00:11:37 --> Input Class Initialized
INFO - 2022-03-23 00:11:37 --> Language Class Initialized
INFO - 2022-03-23 00:11:37 --> Loader Class Initialized
INFO - 2022-03-23 00:11:37 --> Helper loaded: url_helper
INFO - 2022-03-23 00:11:37 --> Helper loaded: form_helper
INFO - 2022-03-23 00:11:37 --> Helper loaded: common_helper
INFO - 2022-03-23 00:11:37 --> Database Driver Class Initialized
DEBUG - 2022-03-23 00:11:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 00:11:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 00:11:37 --> Controller Class Initialized
INFO - 2022-03-23 00:11:37 --> Form Validation Class Initialized
DEBUG - 2022-03-23 00:11:37 --> Encrypt Class Initialized
INFO - 2022-03-23 00:11:37 --> Model "Patient_model" initialized
INFO - 2022-03-23 00:11:37 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 00:11:37 --> Model "Referredby_model" initialized
INFO - 2022-03-23 00:11:37 --> Model "Prefix_master" initialized
INFO - 2022-03-23 00:11:37 --> Model "Hospital_model" initialized
INFO - 2022-03-23 00:11:37 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 00:11:37 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-23 00:11:37 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 00:11:37 --> Final output sent to browser
DEBUG - 2022-03-23 00:11:37 --> Total execution time: 0.0285
ERROR - 2022-03-23 00:11:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 00:11:57 --> Config Class Initialized
INFO - 2022-03-23 00:11:57 --> Hooks Class Initialized
DEBUG - 2022-03-23 00:11:57 --> UTF-8 Support Enabled
INFO - 2022-03-23 00:11:57 --> Utf8 Class Initialized
INFO - 2022-03-23 00:11:57 --> URI Class Initialized
INFO - 2022-03-23 00:11:57 --> Router Class Initialized
INFO - 2022-03-23 00:11:57 --> Output Class Initialized
INFO - 2022-03-23 00:11:57 --> Security Class Initialized
DEBUG - 2022-03-23 00:11:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 00:11:57 --> Input Class Initialized
INFO - 2022-03-23 00:11:57 --> Language Class Initialized
INFO - 2022-03-23 00:11:57 --> Loader Class Initialized
INFO - 2022-03-23 00:11:57 --> Helper loaded: url_helper
INFO - 2022-03-23 00:11:57 --> Helper loaded: form_helper
INFO - 2022-03-23 00:11:57 --> Helper loaded: common_helper
INFO - 2022-03-23 00:11:57 --> Database Driver Class Initialized
DEBUG - 2022-03-23 00:11:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 00:11:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 00:11:57 --> Controller Class Initialized
INFO - 2022-03-23 00:11:57 --> Form Validation Class Initialized
DEBUG - 2022-03-23 00:11:57 --> Encrypt Class Initialized
INFO - 2022-03-23 00:11:57 --> Model "Patient_model" initialized
INFO - 2022-03-23 00:11:57 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 00:11:57 --> Model "Referredby_model" initialized
INFO - 2022-03-23 00:11:57 --> Model "Prefix_master" initialized
INFO - 2022-03-23 00:11:57 --> Model "Hospital_model" initialized
ERROR - 2022-03-23 00:11:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 00:11:57 --> Config Class Initialized
INFO - 2022-03-23 00:11:57 --> Hooks Class Initialized
DEBUG - 2022-03-23 00:11:57 --> UTF-8 Support Enabled
INFO - 2022-03-23 00:11:57 --> Utf8 Class Initialized
INFO - 2022-03-23 00:11:57 --> URI Class Initialized
INFO - 2022-03-23 00:11:57 --> Router Class Initialized
INFO - 2022-03-23 00:11:57 --> Output Class Initialized
INFO - 2022-03-23 00:11:57 --> Security Class Initialized
DEBUG - 2022-03-23 00:11:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 00:11:57 --> Input Class Initialized
INFO - 2022-03-23 00:11:57 --> Language Class Initialized
INFO - 2022-03-23 00:11:57 --> Loader Class Initialized
INFO - 2022-03-23 00:11:57 --> Helper loaded: url_helper
INFO - 2022-03-23 00:11:57 --> Helper loaded: form_helper
INFO - 2022-03-23 00:11:57 --> Helper loaded: common_helper
INFO - 2022-03-23 00:11:57 --> Database Driver Class Initialized
DEBUG - 2022-03-23 00:11:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 00:11:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 00:11:57 --> Controller Class Initialized
INFO - 2022-03-23 00:11:57 --> Form Validation Class Initialized
DEBUG - 2022-03-23 00:11:57 --> Encrypt Class Initialized
INFO - 2022-03-23 00:11:57 --> Model "Patient_model" initialized
INFO - 2022-03-23 00:11:57 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 00:11:57 --> Model "Referredby_model" initialized
INFO - 2022-03-23 00:11:57 --> Model "Prefix_master" initialized
INFO - 2022-03-23 00:11:57 --> Model "Hospital_model" initialized
INFO - 2022-03-23 00:11:57 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 00:11:57 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-23 00:11:57 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 00:11:57 --> Final output sent to browser
DEBUG - 2022-03-23 00:11:57 --> Total execution time: 0.0250
ERROR - 2022-03-23 00:11:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 00:11:58 --> Config Class Initialized
INFO - 2022-03-23 00:11:58 --> Hooks Class Initialized
DEBUG - 2022-03-23 00:11:58 --> UTF-8 Support Enabled
INFO - 2022-03-23 00:11:58 --> Utf8 Class Initialized
INFO - 2022-03-23 00:11:58 --> URI Class Initialized
INFO - 2022-03-23 00:11:58 --> Router Class Initialized
INFO - 2022-03-23 00:11:58 --> Output Class Initialized
INFO - 2022-03-23 00:11:58 --> Security Class Initialized
DEBUG - 2022-03-23 00:11:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 00:11:58 --> Input Class Initialized
INFO - 2022-03-23 00:11:58 --> Language Class Initialized
INFO - 2022-03-23 00:11:58 --> Loader Class Initialized
INFO - 2022-03-23 00:11:58 --> Helper loaded: url_helper
INFO - 2022-03-23 00:11:58 --> Helper loaded: form_helper
INFO - 2022-03-23 00:11:58 --> Helper loaded: common_helper
INFO - 2022-03-23 00:11:58 --> Database Driver Class Initialized
DEBUG - 2022-03-23 00:11:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 00:11:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 00:11:58 --> Controller Class Initialized
INFO - 2022-03-23 00:11:58 --> Form Validation Class Initialized
DEBUG - 2022-03-23 00:11:58 --> Encrypt Class Initialized
INFO - 2022-03-23 00:11:58 --> Model "Patient_model" initialized
INFO - 2022-03-23 00:11:58 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 00:11:58 --> Model "Prefix_master" initialized
INFO - 2022-03-23 00:11:58 --> Model "Users_model" initialized
INFO - 2022-03-23 00:11:58 --> Model "Hospital_model" initialized
INFO - 2022-03-23 00:11:58 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 00:11:58 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-23 00:11:58 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 00:11:58 --> Final output sent to browser
DEBUG - 2022-03-23 00:11:58 --> Total execution time: 0.0489
ERROR - 2022-03-23 00:14:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 00:14:15 --> Config Class Initialized
INFO - 2022-03-23 00:14:15 --> Hooks Class Initialized
DEBUG - 2022-03-23 00:14:15 --> UTF-8 Support Enabled
INFO - 2022-03-23 00:14:15 --> Utf8 Class Initialized
INFO - 2022-03-23 00:14:15 --> URI Class Initialized
INFO - 2022-03-23 00:14:15 --> Router Class Initialized
INFO - 2022-03-23 00:14:15 --> Output Class Initialized
INFO - 2022-03-23 00:14:15 --> Security Class Initialized
DEBUG - 2022-03-23 00:14:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 00:14:15 --> Input Class Initialized
INFO - 2022-03-23 00:14:15 --> Language Class Initialized
INFO - 2022-03-23 00:14:15 --> Loader Class Initialized
INFO - 2022-03-23 00:14:15 --> Helper loaded: url_helper
INFO - 2022-03-23 00:14:15 --> Helper loaded: form_helper
INFO - 2022-03-23 00:14:15 --> Helper loaded: common_helper
INFO - 2022-03-23 00:14:15 --> Database Driver Class Initialized
DEBUG - 2022-03-23 00:14:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 00:14:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 00:14:15 --> Controller Class Initialized
INFO - 2022-03-23 00:14:15 --> Form Validation Class Initialized
DEBUG - 2022-03-23 00:14:15 --> Encrypt Class Initialized
INFO - 2022-03-23 00:14:15 --> Model "Patient_model" initialized
INFO - 2022-03-23 00:14:15 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 00:14:15 --> Model "Referredby_model" initialized
INFO - 2022-03-23 00:14:15 --> Model "Prefix_master" initialized
INFO - 2022-03-23 00:14:15 --> Model "Hospital_model" initialized
INFO - 2022-03-23 00:14:15 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 00:14:15 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-23 00:14:15 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 00:14:15 --> Final output sent to browser
DEBUG - 2022-03-23 00:14:15 --> Total execution time: 0.0818
ERROR - 2022-03-23 00:14:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 00:14:15 --> Config Class Initialized
INFO - 2022-03-23 00:14:15 --> Hooks Class Initialized
DEBUG - 2022-03-23 00:14:15 --> UTF-8 Support Enabled
INFO - 2022-03-23 00:14:15 --> Utf8 Class Initialized
INFO - 2022-03-23 00:14:15 --> URI Class Initialized
INFO - 2022-03-23 00:14:15 --> Router Class Initialized
INFO - 2022-03-23 00:14:15 --> Output Class Initialized
INFO - 2022-03-23 00:14:15 --> Security Class Initialized
DEBUG - 2022-03-23 00:14:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 00:14:15 --> Input Class Initialized
INFO - 2022-03-23 00:14:15 --> Language Class Initialized
ERROR - 2022-03-23 00:14:15 --> 404 Page Not Found: Karoclient/images
ERROR - 2022-03-23 00:17:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 00:17:27 --> Config Class Initialized
INFO - 2022-03-23 00:17:27 --> Hooks Class Initialized
DEBUG - 2022-03-23 00:17:27 --> UTF-8 Support Enabled
INFO - 2022-03-23 00:17:27 --> Utf8 Class Initialized
INFO - 2022-03-23 00:17:27 --> URI Class Initialized
INFO - 2022-03-23 00:17:27 --> Router Class Initialized
INFO - 2022-03-23 00:17:27 --> Output Class Initialized
INFO - 2022-03-23 00:17:27 --> Security Class Initialized
DEBUG - 2022-03-23 00:17:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 00:17:27 --> Input Class Initialized
INFO - 2022-03-23 00:17:27 --> Language Class Initialized
INFO - 2022-03-23 00:17:27 --> Loader Class Initialized
INFO - 2022-03-23 00:17:27 --> Helper loaded: url_helper
INFO - 2022-03-23 00:17:27 --> Helper loaded: form_helper
INFO - 2022-03-23 00:17:27 --> Helper loaded: common_helper
INFO - 2022-03-23 00:17:27 --> Database Driver Class Initialized
DEBUG - 2022-03-23 00:17:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 00:17:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 00:17:27 --> Controller Class Initialized
INFO - 2022-03-23 00:17:27 --> Form Validation Class Initialized
DEBUG - 2022-03-23 00:17:27 --> Encrypt Class Initialized
INFO - 2022-03-23 00:17:27 --> Model "Patient_model" initialized
INFO - 2022-03-23 00:17:27 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 00:17:27 --> Model "Referredby_model" initialized
INFO - 2022-03-23 00:17:27 --> Model "Prefix_master" initialized
INFO - 2022-03-23 00:17:27 --> Model "Hospital_model" initialized
INFO - 2022-03-23 00:17:27 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 00:17:27 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-23 00:17:27 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 00:17:27 --> Final output sent to browser
DEBUG - 2022-03-23 00:17:27 --> Total execution time: 0.1008
ERROR - 2022-03-23 00:17:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 00:17:28 --> Config Class Initialized
INFO - 2022-03-23 00:17:28 --> Hooks Class Initialized
DEBUG - 2022-03-23 00:17:28 --> UTF-8 Support Enabled
INFO - 2022-03-23 00:17:28 --> Utf8 Class Initialized
INFO - 2022-03-23 00:17:28 --> URI Class Initialized
INFO - 2022-03-23 00:17:28 --> Router Class Initialized
INFO - 2022-03-23 00:17:28 --> Output Class Initialized
INFO - 2022-03-23 00:17:28 --> Security Class Initialized
DEBUG - 2022-03-23 00:17:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 00:17:28 --> Input Class Initialized
INFO - 2022-03-23 00:17:28 --> Language Class Initialized
INFO - 2022-03-23 00:17:28 --> Loader Class Initialized
INFO - 2022-03-23 00:17:28 --> Helper loaded: url_helper
INFO - 2022-03-23 00:17:28 --> Helper loaded: form_helper
INFO - 2022-03-23 00:17:28 --> Helper loaded: common_helper
INFO - 2022-03-23 00:17:28 --> Database Driver Class Initialized
DEBUG - 2022-03-23 00:17:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 00:17:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 00:17:28 --> Controller Class Initialized
INFO - 2022-03-23 00:17:28 --> Form Validation Class Initialized
DEBUG - 2022-03-23 00:17:28 --> Encrypt Class Initialized
INFO - 2022-03-23 00:17:28 --> Model "Patient_model" initialized
INFO - 2022-03-23 00:17:28 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 00:17:28 --> Model "Referredby_model" initialized
INFO - 2022-03-23 00:17:28 --> Model "Prefix_master" initialized
INFO - 2022-03-23 00:17:28 --> Model "Hospital_model" initialized
INFO - 2022-03-23 00:17:28 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 00:17:28 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-23 00:17:28 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 00:17:28 --> Final output sent to browser
DEBUG - 2022-03-23 00:17:28 --> Total execution time: 0.0506
ERROR - 2022-03-23 00:17:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 00:17:34 --> Config Class Initialized
INFO - 2022-03-23 00:17:34 --> Hooks Class Initialized
DEBUG - 2022-03-23 00:17:34 --> UTF-8 Support Enabled
INFO - 2022-03-23 00:17:34 --> Utf8 Class Initialized
INFO - 2022-03-23 00:17:34 --> URI Class Initialized
INFO - 2022-03-23 00:17:34 --> Router Class Initialized
INFO - 2022-03-23 00:17:34 --> Output Class Initialized
INFO - 2022-03-23 00:17:34 --> Security Class Initialized
DEBUG - 2022-03-23 00:17:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 00:17:34 --> Input Class Initialized
INFO - 2022-03-23 00:17:34 --> Language Class Initialized
INFO - 2022-03-23 00:17:34 --> Loader Class Initialized
INFO - 2022-03-23 00:17:34 --> Helper loaded: url_helper
INFO - 2022-03-23 00:17:34 --> Helper loaded: form_helper
INFO - 2022-03-23 00:17:34 --> Helper loaded: common_helper
INFO - 2022-03-23 00:17:34 --> Database Driver Class Initialized
DEBUG - 2022-03-23 00:17:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 00:17:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 00:17:34 --> Controller Class Initialized
INFO - 2022-03-23 00:17:34 --> Form Validation Class Initialized
DEBUG - 2022-03-23 00:17:34 --> Encrypt Class Initialized
INFO - 2022-03-23 00:17:34 --> Model "Patient_model" initialized
INFO - 2022-03-23 00:17:34 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 00:17:34 --> Model "Prefix_master" initialized
INFO - 2022-03-23 00:17:34 --> Model "Users_model" initialized
INFO - 2022-03-23 00:17:34 --> Model "Hospital_model" initialized
INFO - 2022-03-23 00:17:34 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
ERROR - 2022-03-23 00:17:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 00:17:35 --> Config Class Initialized
INFO - 2022-03-23 00:17:35 --> Hooks Class Initialized
DEBUG - 2022-03-23 00:17:35 --> UTF-8 Support Enabled
INFO - 2022-03-23 00:17:35 --> Utf8 Class Initialized
INFO - 2022-03-23 00:17:35 --> URI Class Initialized
INFO - 2022-03-23 00:17:35 --> Router Class Initialized
INFO - 2022-03-23 00:17:35 --> Output Class Initialized
INFO - 2022-03-23 00:17:35 --> Security Class Initialized
DEBUG - 2022-03-23 00:17:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 00:17:35 --> Input Class Initialized
INFO - 2022-03-23 00:17:35 --> Language Class Initialized
ERROR - 2022-03-23 00:17:35 --> 404 Page Not Found: Karoclient/images
ERROR - 2022-03-23 00:17:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 00:17:35 --> Config Class Initialized
INFO - 2022-03-23 00:17:35 --> Hooks Class Initialized
DEBUG - 2022-03-23 00:17:35 --> UTF-8 Support Enabled
INFO - 2022-03-23 00:17:35 --> Utf8 Class Initialized
INFO - 2022-03-23 00:17:35 --> URI Class Initialized
INFO - 2022-03-23 00:17:35 --> Router Class Initialized
INFO - 2022-03-23 00:17:35 --> Output Class Initialized
INFO - 2022-03-23 00:17:35 --> Security Class Initialized
DEBUG - 2022-03-23 00:17:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 00:17:35 --> Input Class Initialized
INFO - 2022-03-23 00:17:35 --> Language Class Initialized
ERROR - 2022-03-23 00:17:35 --> 404 Page Not Found: Karoclient/images
ERROR - 2022-03-23 00:17:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 00:17:35 --> Config Class Initialized
INFO - 2022-03-23 00:17:35 --> Hooks Class Initialized
DEBUG - 2022-03-23 00:17:35 --> UTF-8 Support Enabled
INFO - 2022-03-23 00:17:35 --> Utf8 Class Initialized
INFO - 2022-03-23 00:17:35 --> URI Class Initialized
INFO - 2022-03-23 00:17:35 --> Router Class Initialized
INFO - 2022-03-23 00:17:35 --> Output Class Initialized
INFO - 2022-03-23 00:17:35 --> Security Class Initialized
DEBUG - 2022-03-23 00:17:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 00:17:35 --> Input Class Initialized
INFO - 2022-03-23 00:17:35 --> Language Class Initialized
ERROR - 2022-03-23 00:17:35 --> 404 Page Not Found: Karoclient/images
INFO - 2022-03-23 00:17:35 --> Final output sent to browser
DEBUG - 2022-03-23 00:17:35 --> Total execution time: 1.0117
ERROR - 2022-03-23 00:19:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 00:19:21 --> Config Class Initialized
INFO - 2022-03-23 00:19:21 --> Hooks Class Initialized
DEBUG - 2022-03-23 00:19:21 --> UTF-8 Support Enabled
INFO - 2022-03-23 00:19:21 --> Utf8 Class Initialized
INFO - 2022-03-23 00:19:21 --> URI Class Initialized
INFO - 2022-03-23 00:19:21 --> Router Class Initialized
INFO - 2022-03-23 00:19:21 --> Output Class Initialized
INFO - 2022-03-23 00:19:21 --> Security Class Initialized
DEBUG - 2022-03-23 00:19:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 00:19:21 --> Input Class Initialized
INFO - 2022-03-23 00:19:21 --> Language Class Initialized
INFO - 2022-03-23 00:19:21 --> Loader Class Initialized
INFO - 2022-03-23 00:19:21 --> Helper loaded: url_helper
INFO - 2022-03-23 00:19:21 --> Helper loaded: form_helper
INFO - 2022-03-23 00:19:21 --> Helper loaded: common_helper
INFO - 2022-03-23 00:19:21 --> Database Driver Class Initialized
DEBUG - 2022-03-23 00:19:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 00:19:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 00:19:21 --> Controller Class Initialized
INFO - 2022-03-23 00:19:21 --> Form Validation Class Initialized
DEBUG - 2022-03-23 00:19:21 --> Encrypt Class Initialized
INFO - 2022-03-23 00:19:21 --> Model "Patient_model" initialized
INFO - 2022-03-23 00:19:21 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 00:19:21 --> Model "Prefix_master" initialized
INFO - 2022-03-23 00:19:21 --> Model "Users_model" initialized
INFO - 2022-03-23 00:19:21 --> Model "Hospital_model" initialized
ERROR - 2022-03-23 00:19:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 00:19:22 --> Config Class Initialized
INFO - 2022-03-23 00:19:22 --> Hooks Class Initialized
DEBUG - 2022-03-23 00:19:22 --> UTF-8 Support Enabled
INFO - 2022-03-23 00:19:22 --> Utf8 Class Initialized
INFO - 2022-03-23 00:19:22 --> URI Class Initialized
INFO - 2022-03-23 00:19:22 --> Router Class Initialized
INFO - 2022-03-23 00:19:22 --> Output Class Initialized
INFO - 2022-03-23 00:19:22 --> Security Class Initialized
DEBUG - 2022-03-23 00:19:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 00:19:22 --> Input Class Initialized
INFO - 2022-03-23 00:19:22 --> Language Class Initialized
INFO - 2022-03-23 00:19:22 --> Loader Class Initialized
INFO - 2022-03-23 00:19:22 --> Helper loaded: url_helper
INFO - 2022-03-23 00:19:22 --> Helper loaded: form_helper
INFO - 2022-03-23 00:19:22 --> Helper loaded: common_helper
INFO - 2022-03-23 00:19:22 --> Database Driver Class Initialized
DEBUG - 2022-03-23 00:19:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 00:19:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 00:19:22 --> Controller Class Initialized
INFO - 2022-03-23 00:19:22 --> Form Validation Class Initialized
DEBUG - 2022-03-23 00:19:22 --> Encrypt Class Initialized
INFO - 2022-03-23 00:19:22 --> Model "Patient_model" initialized
INFO - 2022-03-23 00:19:22 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 00:19:22 --> Model "Prefix_master" initialized
INFO - 2022-03-23 00:19:22 --> Model "Users_model" initialized
INFO - 2022-03-23 00:19:22 --> Model "Hospital_model" initialized
INFO - 2022-03-23 00:19:22 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 00:19:22 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-23 00:19:22 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 00:19:22 --> Final output sent to browser
DEBUG - 2022-03-23 00:19:22 --> Total execution time: 0.0436
ERROR - 2022-03-23 00:19:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 00:19:28 --> Config Class Initialized
INFO - 2022-03-23 00:19:28 --> Hooks Class Initialized
DEBUG - 2022-03-23 00:19:28 --> UTF-8 Support Enabled
INFO - 2022-03-23 00:19:28 --> Utf8 Class Initialized
INFO - 2022-03-23 00:19:28 --> URI Class Initialized
INFO - 2022-03-23 00:19:28 --> Router Class Initialized
INFO - 2022-03-23 00:19:28 --> Output Class Initialized
INFO - 2022-03-23 00:19:28 --> Security Class Initialized
DEBUG - 2022-03-23 00:19:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 00:19:28 --> Input Class Initialized
INFO - 2022-03-23 00:19:28 --> Language Class Initialized
INFO - 2022-03-23 00:19:28 --> Loader Class Initialized
INFO - 2022-03-23 00:19:28 --> Helper loaded: url_helper
INFO - 2022-03-23 00:19:28 --> Helper loaded: form_helper
INFO - 2022-03-23 00:19:28 --> Helper loaded: common_helper
INFO - 2022-03-23 00:19:28 --> Database Driver Class Initialized
DEBUG - 2022-03-23 00:19:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 00:19:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 00:19:28 --> Controller Class Initialized
INFO - 2022-03-23 00:19:28 --> Form Validation Class Initialized
DEBUG - 2022-03-23 00:19:28 --> Encrypt Class Initialized
INFO - 2022-03-23 00:19:28 --> Model "Patient_model" initialized
INFO - 2022-03-23 00:19:28 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 00:19:28 --> Model "Referredby_model" initialized
INFO - 2022-03-23 00:19:28 --> Model "Prefix_master" initialized
INFO - 2022-03-23 00:19:28 --> Model "Hospital_model" initialized
INFO - 2022-03-23 00:19:28 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 00:19:28 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-23 00:19:28 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 00:19:28 --> Final output sent to browser
DEBUG - 2022-03-23 00:19:28 --> Total execution time: 0.0276
ERROR - 2022-03-23 00:19:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 00:19:39 --> Config Class Initialized
INFO - 2022-03-23 00:19:39 --> Hooks Class Initialized
DEBUG - 2022-03-23 00:19:39 --> UTF-8 Support Enabled
INFO - 2022-03-23 00:19:39 --> Utf8 Class Initialized
INFO - 2022-03-23 00:19:39 --> URI Class Initialized
INFO - 2022-03-23 00:19:39 --> Router Class Initialized
INFO - 2022-03-23 00:19:39 --> Output Class Initialized
INFO - 2022-03-23 00:19:39 --> Security Class Initialized
DEBUG - 2022-03-23 00:19:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 00:19:39 --> Input Class Initialized
INFO - 2022-03-23 00:19:39 --> Language Class Initialized
INFO - 2022-03-23 00:19:39 --> Loader Class Initialized
INFO - 2022-03-23 00:19:39 --> Helper loaded: url_helper
INFO - 2022-03-23 00:19:39 --> Helper loaded: form_helper
INFO - 2022-03-23 00:19:39 --> Helper loaded: common_helper
INFO - 2022-03-23 00:19:39 --> Database Driver Class Initialized
DEBUG - 2022-03-23 00:19:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 00:19:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 00:19:39 --> Controller Class Initialized
INFO - 2022-03-23 00:19:39 --> Form Validation Class Initialized
DEBUG - 2022-03-23 00:19:39 --> Encrypt Class Initialized
INFO - 2022-03-23 00:19:39 --> Model "Patient_model" initialized
INFO - 2022-03-23 00:19:39 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 00:19:39 --> Model "Referredby_model" initialized
INFO - 2022-03-23 00:19:39 --> Model "Prefix_master" initialized
INFO - 2022-03-23 00:19:39 --> Model "Hospital_model" initialized
ERROR - 2022-03-23 00:19:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 00:19:39 --> Config Class Initialized
INFO - 2022-03-23 00:19:39 --> Hooks Class Initialized
DEBUG - 2022-03-23 00:19:39 --> UTF-8 Support Enabled
INFO - 2022-03-23 00:19:39 --> Utf8 Class Initialized
INFO - 2022-03-23 00:19:39 --> URI Class Initialized
INFO - 2022-03-23 00:19:39 --> Router Class Initialized
INFO - 2022-03-23 00:19:39 --> Output Class Initialized
INFO - 2022-03-23 00:19:39 --> Security Class Initialized
DEBUG - 2022-03-23 00:19:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 00:19:39 --> Input Class Initialized
INFO - 2022-03-23 00:19:39 --> Language Class Initialized
INFO - 2022-03-23 00:19:39 --> Loader Class Initialized
INFO - 2022-03-23 00:19:39 --> Helper loaded: url_helper
INFO - 2022-03-23 00:19:39 --> Helper loaded: form_helper
INFO - 2022-03-23 00:19:39 --> Helper loaded: common_helper
INFO - 2022-03-23 00:19:39 --> Database Driver Class Initialized
DEBUG - 2022-03-23 00:19:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 00:19:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 00:19:39 --> Controller Class Initialized
INFO - 2022-03-23 00:19:39 --> Form Validation Class Initialized
DEBUG - 2022-03-23 00:19:39 --> Encrypt Class Initialized
INFO - 2022-03-23 00:19:39 --> Model "Patient_model" initialized
INFO - 2022-03-23 00:19:39 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 00:19:39 --> Model "Referredby_model" initialized
INFO - 2022-03-23 00:19:39 --> Model "Prefix_master" initialized
INFO - 2022-03-23 00:19:39 --> Model "Hospital_model" initialized
INFO - 2022-03-23 00:19:40 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 00:19:40 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-23 00:19:40 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 00:19:40 --> Final output sent to browser
DEBUG - 2022-03-23 00:19:40 --> Total execution time: 0.0458
ERROR - 2022-03-23 00:19:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 00:19:40 --> Config Class Initialized
INFO - 2022-03-23 00:19:40 --> Hooks Class Initialized
DEBUG - 2022-03-23 00:19:40 --> UTF-8 Support Enabled
INFO - 2022-03-23 00:19:40 --> Utf8 Class Initialized
INFO - 2022-03-23 00:19:40 --> URI Class Initialized
INFO - 2022-03-23 00:19:40 --> Router Class Initialized
INFO - 2022-03-23 00:19:40 --> Output Class Initialized
INFO - 2022-03-23 00:19:40 --> Security Class Initialized
DEBUG - 2022-03-23 00:19:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 00:19:40 --> Input Class Initialized
INFO - 2022-03-23 00:19:40 --> Language Class Initialized
INFO - 2022-03-23 00:19:40 --> Loader Class Initialized
INFO - 2022-03-23 00:19:40 --> Helper loaded: url_helper
INFO - 2022-03-23 00:19:40 --> Helper loaded: form_helper
INFO - 2022-03-23 00:19:40 --> Helper loaded: common_helper
INFO - 2022-03-23 00:19:40 --> Database Driver Class Initialized
DEBUG - 2022-03-23 00:19:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 00:19:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 00:19:40 --> Controller Class Initialized
INFO - 2022-03-23 00:19:40 --> Form Validation Class Initialized
DEBUG - 2022-03-23 00:19:40 --> Encrypt Class Initialized
INFO - 2022-03-23 00:19:40 --> Model "Patient_model" initialized
INFO - 2022-03-23 00:19:40 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 00:19:40 --> Model "Prefix_master" initialized
INFO - 2022-03-23 00:19:40 --> Model "Users_model" initialized
INFO - 2022-03-23 00:19:40 --> Model "Hospital_model" initialized
INFO - 2022-03-23 00:19:40 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 00:19:40 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-23 00:19:40 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 00:19:40 --> Final output sent to browser
DEBUG - 2022-03-23 00:19:40 --> Total execution time: 0.0378
ERROR - 2022-03-23 00:19:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 00:19:52 --> Config Class Initialized
INFO - 2022-03-23 00:19:52 --> Hooks Class Initialized
DEBUG - 2022-03-23 00:19:52 --> UTF-8 Support Enabled
INFO - 2022-03-23 00:19:52 --> Utf8 Class Initialized
INFO - 2022-03-23 00:19:52 --> URI Class Initialized
INFO - 2022-03-23 00:19:52 --> Router Class Initialized
INFO - 2022-03-23 00:19:52 --> Output Class Initialized
INFO - 2022-03-23 00:19:52 --> Security Class Initialized
DEBUG - 2022-03-23 00:19:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 00:19:52 --> Input Class Initialized
INFO - 2022-03-23 00:19:52 --> Language Class Initialized
INFO - 2022-03-23 00:19:52 --> Loader Class Initialized
INFO - 2022-03-23 00:19:52 --> Helper loaded: url_helper
INFO - 2022-03-23 00:19:52 --> Helper loaded: form_helper
INFO - 2022-03-23 00:19:52 --> Helper loaded: common_helper
INFO - 2022-03-23 00:19:52 --> Database Driver Class Initialized
DEBUG - 2022-03-23 00:19:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 00:19:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 00:19:52 --> Controller Class Initialized
INFO - 2022-03-23 00:19:52 --> Form Validation Class Initialized
DEBUG - 2022-03-23 00:19:52 --> Encrypt Class Initialized
INFO - 2022-03-23 00:19:52 --> Model "Patient_model" initialized
INFO - 2022-03-23 00:19:52 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 00:19:52 --> Model "Prefix_master" initialized
INFO - 2022-03-23 00:19:52 --> Model "Users_model" initialized
INFO - 2022-03-23 00:19:52 --> Model "Hospital_model" initialized
ERROR - 2022-03-23 00:19:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 00:19:52 --> Config Class Initialized
INFO - 2022-03-23 00:19:52 --> Hooks Class Initialized
DEBUG - 2022-03-23 00:19:52 --> UTF-8 Support Enabled
INFO - 2022-03-23 00:19:52 --> Utf8 Class Initialized
INFO - 2022-03-23 00:19:52 --> URI Class Initialized
INFO - 2022-03-23 00:19:52 --> Router Class Initialized
INFO - 2022-03-23 00:19:52 --> Output Class Initialized
INFO - 2022-03-23 00:19:52 --> Security Class Initialized
DEBUG - 2022-03-23 00:19:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 00:19:52 --> Input Class Initialized
INFO - 2022-03-23 00:19:52 --> Language Class Initialized
INFO - 2022-03-23 00:19:52 --> Loader Class Initialized
INFO - 2022-03-23 00:19:52 --> Helper loaded: url_helper
INFO - 2022-03-23 00:19:52 --> Helper loaded: form_helper
INFO - 2022-03-23 00:19:52 --> Helper loaded: common_helper
INFO - 2022-03-23 00:19:52 --> Database Driver Class Initialized
DEBUG - 2022-03-23 00:19:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 00:19:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 00:19:52 --> Controller Class Initialized
INFO - 2022-03-23 00:19:52 --> Form Validation Class Initialized
DEBUG - 2022-03-23 00:19:52 --> Encrypt Class Initialized
INFO - 2022-03-23 00:19:52 --> Model "Patient_model" initialized
INFO - 2022-03-23 00:19:52 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 00:19:52 --> Model "Prefix_master" initialized
INFO - 2022-03-23 00:19:52 --> Model "Users_model" initialized
INFO - 2022-03-23 00:19:52 --> Model "Hospital_model" initialized
INFO - 2022-03-23 00:19:52 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 00:19:52 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-23 00:19:52 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 00:19:52 --> Final output sent to browser
DEBUG - 2022-03-23 00:19:52 --> Total execution time: 0.0383
ERROR - 2022-03-23 00:20:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 00:20:06 --> Config Class Initialized
INFO - 2022-03-23 00:20:06 --> Hooks Class Initialized
DEBUG - 2022-03-23 00:20:06 --> UTF-8 Support Enabled
INFO - 2022-03-23 00:20:06 --> Utf8 Class Initialized
INFO - 2022-03-23 00:20:06 --> URI Class Initialized
INFO - 2022-03-23 00:20:06 --> Router Class Initialized
INFO - 2022-03-23 00:20:06 --> Output Class Initialized
INFO - 2022-03-23 00:20:06 --> Security Class Initialized
DEBUG - 2022-03-23 00:20:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 00:20:06 --> Input Class Initialized
INFO - 2022-03-23 00:20:06 --> Language Class Initialized
INFO - 2022-03-23 00:20:06 --> Loader Class Initialized
INFO - 2022-03-23 00:20:06 --> Helper loaded: url_helper
INFO - 2022-03-23 00:20:06 --> Helper loaded: form_helper
INFO - 2022-03-23 00:20:06 --> Helper loaded: common_helper
INFO - 2022-03-23 00:20:06 --> Database Driver Class Initialized
DEBUG - 2022-03-23 00:20:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 00:20:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 00:20:06 --> Controller Class Initialized
INFO - 2022-03-23 00:20:06 --> Form Validation Class Initialized
DEBUG - 2022-03-23 00:20:06 --> Encrypt Class Initialized
INFO - 2022-03-23 00:20:06 --> Model "Patient_model" initialized
INFO - 2022-03-23 00:20:06 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 00:20:06 --> Model "Prefix_master" initialized
INFO - 2022-03-23 00:20:06 --> Model "Users_model" initialized
INFO - 2022-03-23 00:20:06 --> Model "Hospital_model" initialized
ERROR - 2022-03-23 00:20:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 00:20:06 --> Config Class Initialized
INFO - 2022-03-23 00:20:06 --> Hooks Class Initialized
DEBUG - 2022-03-23 00:20:06 --> UTF-8 Support Enabled
INFO - 2022-03-23 00:20:06 --> Utf8 Class Initialized
INFO - 2022-03-23 00:20:06 --> URI Class Initialized
INFO - 2022-03-23 00:20:06 --> Router Class Initialized
INFO - 2022-03-23 00:20:06 --> Output Class Initialized
INFO - 2022-03-23 00:20:06 --> Security Class Initialized
DEBUG - 2022-03-23 00:20:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 00:20:06 --> Input Class Initialized
INFO - 2022-03-23 00:20:06 --> Language Class Initialized
INFO - 2022-03-23 00:20:06 --> Loader Class Initialized
INFO - 2022-03-23 00:20:06 --> Helper loaded: url_helper
INFO - 2022-03-23 00:20:06 --> Helper loaded: form_helper
INFO - 2022-03-23 00:20:06 --> Helper loaded: common_helper
INFO - 2022-03-23 00:20:06 --> Database Driver Class Initialized
DEBUG - 2022-03-23 00:20:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 00:20:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 00:20:06 --> Controller Class Initialized
INFO - 2022-03-23 00:20:06 --> Form Validation Class Initialized
DEBUG - 2022-03-23 00:20:06 --> Encrypt Class Initialized
INFO - 2022-03-23 00:20:06 --> Model "Patient_model" initialized
INFO - 2022-03-23 00:20:06 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 00:20:06 --> Model "Prefix_master" initialized
INFO - 2022-03-23 00:20:06 --> Model "Users_model" initialized
INFO - 2022-03-23 00:20:06 --> Model "Hospital_model" initialized
INFO - 2022-03-23 00:20:06 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 00:20:06 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-23 00:20:06 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 00:20:06 --> Final output sent to browser
DEBUG - 2022-03-23 00:20:06 --> Total execution time: 0.0536
ERROR - 2022-03-23 00:22:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 00:22:33 --> Config Class Initialized
INFO - 2022-03-23 00:22:33 --> Hooks Class Initialized
DEBUG - 2022-03-23 00:22:33 --> UTF-8 Support Enabled
INFO - 2022-03-23 00:22:33 --> Utf8 Class Initialized
INFO - 2022-03-23 00:22:33 --> URI Class Initialized
INFO - 2022-03-23 00:22:33 --> Router Class Initialized
INFO - 2022-03-23 00:22:33 --> Output Class Initialized
INFO - 2022-03-23 00:22:33 --> Security Class Initialized
DEBUG - 2022-03-23 00:22:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 00:22:33 --> Input Class Initialized
INFO - 2022-03-23 00:22:33 --> Language Class Initialized
INFO - 2022-03-23 00:22:33 --> Loader Class Initialized
INFO - 2022-03-23 00:22:33 --> Helper loaded: url_helper
INFO - 2022-03-23 00:22:33 --> Helper loaded: form_helper
INFO - 2022-03-23 00:22:33 --> Helper loaded: common_helper
INFO - 2022-03-23 00:22:33 --> Database Driver Class Initialized
DEBUG - 2022-03-23 00:22:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 00:22:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 00:22:33 --> Controller Class Initialized
INFO - 2022-03-23 00:22:33 --> Form Validation Class Initialized
DEBUG - 2022-03-23 00:22:33 --> Encrypt Class Initialized
INFO - 2022-03-23 00:22:33 --> Model "Patient_model" initialized
INFO - 2022-03-23 00:22:33 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 00:22:33 --> Model "Prefix_master" initialized
INFO - 2022-03-23 00:22:33 --> Model "Users_model" initialized
INFO - 2022-03-23 00:22:33 --> Model "Hospital_model" initialized
ERROR - 2022-03-23 00:22:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 00:22:33 --> Config Class Initialized
INFO - 2022-03-23 00:22:33 --> Hooks Class Initialized
DEBUG - 2022-03-23 00:22:33 --> UTF-8 Support Enabled
INFO - 2022-03-23 00:22:33 --> Utf8 Class Initialized
INFO - 2022-03-23 00:22:33 --> URI Class Initialized
INFO - 2022-03-23 00:22:33 --> Router Class Initialized
INFO - 2022-03-23 00:22:33 --> Output Class Initialized
INFO - 2022-03-23 00:22:33 --> Security Class Initialized
DEBUG - 2022-03-23 00:22:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 00:22:33 --> Input Class Initialized
INFO - 2022-03-23 00:22:33 --> Language Class Initialized
INFO - 2022-03-23 00:22:33 --> Loader Class Initialized
INFO - 2022-03-23 00:22:33 --> Helper loaded: url_helper
INFO - 2022-03-23 00:22:33 --> Helper loaded: form_helper
INFO - 2022-03-23 00:22:33 --> Helper loaded: common_helper
INFO - 2022-03-23 00:22:33 --> Database Driver Class Initialized
DEBUG - 2022-03-23 00:22:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 00:22:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 00:22:33 --> Controller Class Initialized
INFO - 2022-03-23 00:22:33 --> Form Validation Class Initialized
DEBUG - 2022-03-23 00:22:33 --> Encrypt Class Initialized
INFO - 2022-03-23 00:22:33 --> Model "Patient_model" initialized
INFO - 2022-03-23 00:22:33 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 00:22:33 --> Model "Prefix_master" initialized
INFO - 2022-03-23 00:22:33 --> Model "Users_model" initialized
INFO - 2022-03-23 00:22:33 --> Model "Hospital_model" initialized
INFO - 2022-03-23 00:22:33 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 00:22:33 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-23 00:22:33 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 00:22:33 --> Final output sent to browser
DEBUG - 2022-03-23 00:22:33 --> Total execution time: 0.0571
ERROR - 2022-03-23 00:23:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 00:23:42 --> Config Class Initialized
INFO - 2022-03-23 00:23:42 --> Hooks Class Initialized
DEBUG - 2022-03-23 00:23:42 --> UTF-8 Support Enabled
INFO - 2022-03-23 00:23:42 --> Utf8 Class Initialized
INFO - 2022-03-23 00:23:42 --> URI Class Initialized
INFO - 2022-03-23 00:23:42 --> Router Class Initialized
INFO - 2022-03-23 00:23:42 --> Output Class Initialized
INFO - 2022-03-23 00:23:42 --> Security Class Initialized
DEBUG - 2022-03-23 00:23:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 00:23:42 --> Input Class Initialized
INFO - 2022-03-23 00:23:42 --> Language Class Initialized
INFO - 2022-03-23 00:23:42 --> Loader Class Initialized
INFO - 2022-03-23 00:23:42 --> Helper loaded: url_helper
INFO - 2022-03-23 00:23:42 --> Helper loaded: form_helper
INFO - 2022-03-23 00:23:42 --> Helper loaded: common_helper
INFO - 2022-03-23 00:23:42 --> Database Driver Class Initialized
DEBUG - 2022-03-23 00:23:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 00:23:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 00:23:42 --> Controller Class Initialized
INFO - 2022-03-23 00:23:42 --> Form Validation Class Initialized
DEBUG - 2022-03-23 00:23:42 --> Encrypt Class Initialized
INFO - 2022-03-23 00:23:42 --> Model "Patient_model" initialized
INFO - 2022-03-23 00:23:42 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 00:23:42 --> Model "Prefix_master" initialized
INFO - 2022-03-23 00:23:42 --> Model "Users_model" initialized
INFO - 2022-03-23 00:23:42 --> Model "Hospital_model" initialized
ERROR - 2022-03-23 00:23:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 00:23:42 --> Config Class Initialized
INFO - 2022-03-23 00:23:42 --> Hooks Class Initialized
DEBUG - 2022-03-23 00:23:42 --> UTF-8 Support Enabled
INFO - 2022-03-23 00:23:42 --> Utf8 Class Initialized
INFO - 2022-03-23 00:23:42 --> URI Class Initialized
INFO - 2022-03-23 00:23:42 --> Router Class Initialized
INFO - 2022-03-23 00:23:42 --> Output Class Initialized
INFO - 2022-03-23 00:23:42 --> Security Class Initialized
DEBUG - 2022-03-23 00:23:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 00:23:42 --> Input Class Initialized
INFO - 2022-03-23 00:23:42 --> Language Class Initialized
INFO - 2022-03-23 00:23:42 --> Loader Class Initialized
INFO - 2022-03-23 00:23:42 --> Helper loaded: url_helper
INFO - 2022-03-23 00:23:42 --> Helper loaded: form_helper
INFO - 2022-03-23 00:23:42 --> Helper loaded: common_helper
INFO - 2022-03-23 00:23:42 --> Database Driver Class Initialized
DEBUG - 2022-03-23 00:23:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 00:23:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 00:23:42 --> Controller Class Initialized
INFO - 2022-03-23 00:23:42 --> Form Validation Class Initialized
DEBUG - 2022-03-23 00:23:42 --> Encrypt Class Initialized
INFO - 2022-03-23 00:23:42 --> Model "Patient_model" initialized
INFO - 2022-03-23 00:23:42 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 00:23:42 --> Model "Prefix_master" initialized
INFO - 2022-03-23 00:23:42 --> Model "Users_model" initialized
INFO - 2022-03-23 00:23:42 --> Model "Hospital_model" initialized
INFO - 2022-03-23 00:23:43 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 00:23:43 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-23 00:23:43 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 00:23:43 --> Final output sent to browser
DEBUG - 2022-03-23 00:23:43 --> Total execution time: 0.2180
ERROR - 2022-03-23 00:24:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 00:24:00 --> Config Class Initialized
INFO - 2022-03-23 00:24:00 --> Hooks Class Initialized
DEBUG - 2022-03-23 00:24:00 --> UTF-8 Support Enabled
INFO - 2022-03-23 00:24:00 --> Utf8 Class Initialized
INFO - 2022-03-23 00:24:00 --> URI Class Initialized
INFO - 2022-03-23 00:24:00 --> Router Class Initialized
INFO - 2022-03-23 00:24:00 --> Output Class Initialized
INFO - 2022-03-23 00:24:00 --> Security Class Initialized
DEBUG - 2022-03-23 00:24:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 00:24:00 --> Input Class Initialized
INFO - 2022-03-23 00:24:00 --> Language Class Initialized
INFO - 2022-03-23 00:24:00 --> Loader Class Initialized
INFO - 2022-03-23 00:24:00 --> Helper loaded: url_helper
INFO - 2022-03-23 00:24:00 --> Helper loaded: form_helper
INFO - 2022-03-23 00:24:00 --> Helper loaded: common_helper
INFO - 2022-03-23 00:24:00 --> Database Driver Class Initialized
DEBUG - 2022-03-23 00:24:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 00:24:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 00:24:00 --> Controller Class Initialized
INFO - 2022-03-23 00:24:00 --> Form Validation Class Initialized
DEBUG - 2022-03-23 00:24:00 --> Encrypt Class Initialized
INFO - 2022-03-23 00:24:00 --> Model "Patient_model" initialized
INFO - 2022-03-23 00:24:00 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 00:24:00 --> Model "Prefix_master" initialized
INFO - 2022-03-23 00:24:00 --> Model "Users_model" initialized
INFO - 2022-03-23 00:24:00 --> Model "Hospital_model" initialized
INFO - 2022-03-23 00:24:00 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 00:24:00 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-23 00:24:00 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 00:24:00 --> Final output sent to browser
DEBUG - 2022-03-23 00:24:00 --> Total execution time: 0.0562
ERROR - 2022-03-23 00:24:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 00:24:11 --> Config Class Initialized
INFO - 2022-03-23 00:24:11 --> Hooks Class Initialized
DEBUG - 2022-03-23 00:24:11 --> UTF-8 Support Enabled
INFO - 2022-03-23 00:24:11 --> Utf8 Class Initialized
INFO - 2022-03-23 00:24:11 --> URI Class Initialized
INFO - 2022-03-23 00:24:11 --> Router Class Initialized
INFO - 2022-03-23 00:24:11 --> Output Class Initialized
INFO - 2022-03-23 00:24:11 --> Security Class Initialized
DEBUG - 2022-03-23 00:24:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 00:24:11 --> Input Class Initialized
INFO - 2022-03-23 00:24:11 --> Language Class Initialized
INFO - 2022-03-23 00:24:11 --> Loader Class Initialized
INFO - 2022-03-23 00:24:11 --> Helper loaded: url_helper
INFO - 2022-03-23 00:24:11 --> Helper loaded: form_helper
INFO - 2022-03-23 00:24:11 --> Helper loaded: common_helper
INFO - 2022-03-23 00:24:11 --> Database Driver Class Initialized
DEBUG - 2022-03-23 00:24:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 00:24:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 00:24:11 --> Controller Class Initialized
INFO - 2022-03-23 00:24:11 --> Form Validation Class Initialized
DEBUG - 2022-03-23 00:24:11 --> Encrypt Class Initialized
INFO - 2022-03-23 00:24:11 --> Model "Patient_model" initialized
INFO - 2022-03-23 00:24:11 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 00:24:11 --> Model "Referredby_model" initialized
INFO - 2022-03-23 00:24:11 --> Model "Prefix_master" initialized
INFO - 2022-03-23 00:24:11 --> Model "Hospital_model" initialized
INFO - 2022-03-23 00:24:11 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 00:24:11 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-23 00:24:11 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 00:24:11 --> Final output sent to browser
DEBUG - 2022-03-23 00:24:11 --> Total execution time: 0.1007
ERROR - 2022-03-23 00:24:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 00:24:30 --> Config Class Initialized
INFO - 2022-03-23 00:24:30 --> Hooks Class Initialized
DEBUG - 2022-03-23 00:24:30 --> UTF-8 Support Enabled
INFO - 2022-03-23 00:24:30 --> Utf8 Class Initialized
INFO - 2022-03-23 00:24:30 --> URI Class Initialized
INFO - 2022-03-23 00:24:30 --> Router Class Initialized
INFO - 2022-03-23 00:24:30 --> Output Class Initialized
INFO - 2022-03-23 00:24:30 --> Security Class Initialized
DEBUG - 2022-03-23 00:24:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 00:24:30 --> Input Class Initialized
INFO - 2022-03-23 00:24:30 --> Language Class Initialized
INFO - 2022-03-23 00:24:30 --> Loader Class Initialized
INFO - 2022-03-23 00:24:30 --> Helper loaded: url_helper
INFO - 2022-03-23 00:24:30 --> Helper loaded: form_helper
INFO - 2022-03-23 00:24:30 --> Helper loaded: common_helper
INFO - 2022-03-23 00:24:30 --> Database Driver Class Initialized
DEBUG - 2022-03-23 00:24:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 00:24:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 00:24:30 --> Controller Class Initialized
INFO - 2022-03-23 00:24:30 --> Form Validation Class Initialized
DEBUG - 2022-03-23 00:24:30 --> Encrypt Class Initialized
INFO - 2022-03-23 00:24:30 --> Model "Patient_model" initialized
INFO - 2022-03-23 00:24:30 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 00:24:30 --> Model "Referredby_model" initialized
INFO - 2022-03-23 00:24:30 --> Model "Prefix_master" initialized
INFO - 2022-03-23 00:24:30 --> Model "Hospital_model" initialized
ERROR - 2022-03-23 00:24:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 00:24:30 --> Config Class Initialized
INFO - 2022-03-23 00:24:30 --> Hooks Class Initialized
DEBUG - 2022-03-23 00:24:30 --> UTF-8 Support Enabled
INFO - 2022-03-23 00:24:30 --> Utf8 Class Initialized
INFO - 2022-03-23 00:24:30 --> URI Class Initialized
INFO - 2022-03-23 00:24:30 --> Router Class Initialized
INFO - 2022-03-23 00:24:30 --> Output Class Initialized
INFO - 2022-03-23 00:24:30 --> Security Class Initialized
DEBUG - 2022-03-23 00:24:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 00:24:30 --> Input Class Initialized
INFO - 2022-03-23 00:24:30 --> Language Class Initialized
INFO - 2022-03-23 00:24:30 --> Loader Class Initialized
INFO - 2022-03-23 00:24:30 --> Helper loaded: url_helper
INFO - 2022-03-23 00:24:30 --> Helper loaded: form_helper
INFO - 2022-03-23 00:24:30 --> Helper loaded: common_helper
INFO - 2022-03-23 00:24:30 --> Database Driver Class Initialized
DEBUG - 2022-03-23 00:24:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 00:24:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 00:24:30 --> Controller Class Initialized
INFO - 2022-03-23 00:24:30 --> Form Validation Class Initialized
DEBUG - 2022-03-23 00:24:30 --> Encrypt Class Initialized
INFO - 2022-03-23 00:24:30 --> Model "Patient_model" initialized
INFO - 2022-03-23 00:24:30 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 00:24:30 --> Model "Referredby_model" initialized
INFO - 2022-03-23 00:24:30 --> Model "Prefix_master" initialized
INFO - 2022-03-23 00:24:30 --> Model "Hospital_model" initialized
INFO - 2022-03-23 00:24:30 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 00:24:30 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-23 00:24:30 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 00:24:30 --> Final output sent to browser
DEBUG - 2022-03-23 00:24:30 --> Total execution time: 0.0296
ERROR - 2022-03-23 00:24:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 00:24:31 --> Config Class Initialized
INFO - 2022-03-23 00:24:31 --> Hooks Class Initialized
DEBUG - 2022-03-23 00:24:31 --> UTF-8 Support Enabled
INFO - 2022-03-23 00:24:31 --> Utf8 Class Initialized
INFO - 2022-03-23 00:24:31 --> URI Class Initialized
INFO - 2022-03-23 00:24:31 --> Router Class Initialized
INFO - 2022-03-23 00:24:31 --> Output Class Initialized
INFO - 2022-03-23 00:24:31 --> Security Class Initialized
DEBUG - 2022-03-23 00:24:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 00:24:31 --> Input Class Initialized
INFO - 2022-03-23 00:24:31 --> Language Class Initialized
INFO - 2022-03-23 00:24:31 --> Loader Class Initialized
INFO - 2022-03-23 00:24:31 --> Helper loaded: url_helper
INFO - 2022-03-23 00:24:31 --> Helper loaded: form_helper
INFO - 2022-03-23 00:24:31 --> Helper loaded: common_helper
INFO - 2022-03-23 00:24:31 --> Database Driver Class Initialized
DEBUG - 2022-03-23 00:24:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 00:24:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 00:24:31 --> Controller Class Initialized
INFO - 2022-03-23 00:24:31 --> Form Validation Class Initialized
DEBUG - 2022-03-23 00:24:31 --> Encrypt Class Initialized
INFO - 2022-03-23 00:24:31 --> Model "Patient_model" initialized
INFO - 2022-03-23 00:24:31 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 00:24:31 --> Model "Prefix_master" initialized
INFO - 2022-03-23 00:24:31 --> Model "Users_model" initialized
INFO - 2022-03-23 00:24:31 --> Model "Hospital_model" initialized
INFO - 2022-03-23 00:24:31 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 00:24:31 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-23 00:24:31 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 00:24:31 --> Final output sent to browser
DEBUG - 2022-03-23 00:24:31 --> Total execution time: 0.0394
ERROR - 2022-03-23 00:24:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 00:24:53 --> Config Class Initialized
INFO - 2022-03-23 00:24:53 --> Hooks Class Initialized
DEBUG - 2022-03-23 00:24:53 --> UTF-8 Support Enabled
INFO - 2022-03-23 00:24:53 --> Utf8 Class Initialized
INFO - 2022-03-23 00:24:53 --> URI Class Initialized
INFO - 2022-03-23 00:24:53 --> Router Class Initialized
INFO - 2022-03-23 00:24:53 --> Output Class Initialized
INFO - 2022-03-23 00:24:53 --> Security Class Initialized
DEBUG - 2022-03-23 00:24:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 00:24:53 --> Input Class Initialized
INFO - 2022-03-23 00:24:53 --> Language Class Initialized
INFO - 2022-03-23 00:24:53 --> Loader Class Initialized
INFO - 2022-03-23 00:24:53 --> Helper loaded: url_helper
INFO - 2022-03-23 00:24:53 --> Helper loaded: form_helper
INFO - 2022-03-23 00:24:53 --> Helper loaded: common_helper
INFO - 2022-03-23 00:24:53 --> Database Driver Class Initialized
DEBUG - 2022-03-23 00:24:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 00:24:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 00:24:53 --> Controller Class Initialized
INFO - 2022-03-23 00:24:53 --> Form Validation Class Initialized
DEBUG - 2022-03-23 00:24:53 --> Encrypt Class Initialized
INFO - 2022-03-23 00:24:53 --> Model "Patient_model" initialized
INFO - 2022-03-23 00:24:53 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 00:24:53 --> Model "Prefix_master" initialized
INFO - 2022-03-23 00:24:53 --> Model "Users_model" initialized
INFO - 2022-03-23 00:24:53 --> Model "Hospital_model" initialized
ERROR - 2022-03-23 00:24:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 00:24:54 --> Config Class Initialized
INFO - 2022-03-23 00:24:54 --> Hooks Class Initialized
DEBUG - 2022-03-23 00:24:54 --> UTF-8 Support Enabled
INFO - 2022-03-23 00:24:54 --> Utf8 Class Initialized
INFO - 2022-03-23 00:24:54 --> URI Class Initialized
INFO - 2022-03-23 00:24:54 --> Router Class Initialized
INFO - 2022-03-23 00:24:54 --> Output Class Initialized
INFO - 2022-03-23 00:24:54 --> Security Class Initialized
DEBUG - 2022-03-23 00:24:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 00:24:54 --> Input Class Initialized
INFO - 2022-03-23 00:24:54 --> Language Class Initialized
INFO - 2022-03-23 00:24:54 --> Loader Class Initialized
INFO - 2022-03-23 00:24:54 --> Helper loaded: url_helper
INFO - 2022-03-23 00:24:54 --> Helper loaded: form_helper
INFO - 2022-03-23 00:24:54 --> Helper loaded: common_helper
INFO - 2022-03-23 00:24:54 --> Database Driver Class Initialized
DEBUG - 2022-03-23 00:24:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 00:24:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 00:24:54 --> Controller Class Initialized
INFO - 2022-03-23 00:24:54 --> Form Validation Class Initialized
DEBUG - 2022-03-23 00:24:54 --> Encrypt Class Initialized
INFO - 2022-03-23 00:24:54 --> Model "Patient_model" initialized
INFO - 2022-03-23 00:24:54 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 00:24:54 --> Model "Prefix_master" initialized
INFO - 2022-03-23 00:24:54 --> Model "Users_model" initialized
INFO - 2022-03-23 00:24:54 --> Model "Hospital_model" initialized
INFO - 2022-03-23 00:24:54 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 00:24:54 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-23 00:24:54 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 00:24:54 --> Final output sent to browser
DEBUG - 2022-03-23 00:24:54 --> Total execution time: 0.0386
ERROR - 2022-03-23 00:25:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 00:25:38 --> Config Class Initialized
INFO - 2022-03-23 00:25:38 --> Hooks Class Initialized
DEBUG - 2022-03-23 00:25:38 --> UTF-8 Support Enabled
INFO - 2022-03-23 00:25:38 --> Utf8 Class Initialized
INFO - 2022-03-23 00:25:38 --> URI Class Initialized
INFO - 2022-03-23 00:25:38 --> Router Class Initialized
INFO - 2022-03-23 00:25:38 --> Output Class Initialized
INFO - 2022-03-23 00:25:38 --> Security Class Initialized
DEBUG - 2022-03-23 00:25:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 00:25:38 --> Input Class Initialized
INFO - 2022-03-23 00:25:38 --> Language Class Initialized
INFO - 2022-03-23 00:25:38 --> Loader Class Initialized
INFO - 2022-03-23 00:25:38 --> Helper loaded: url_helper
INFO - 2022-03-23 00:25:38 --> Helper loaded: form_helper
INFO - 2022-03-23 00:25:38 --> Helper loaded: common_helper
INFO - 2022-03-23 00:25:38 --> Database Driver Class Initialized
DEBUG - 2022-03-23 00:25:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 00:25:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 00:25:39 --> Controller Class Initialized
INFO - 2022-03-23 00:25:39 --> Form Validation Class Initialized
DEBUG - 2022-03-23 00:25:39 --> Encrypt Class Initialized
INFO - 2022-03-23 00:25:39 --> Model "Patient_model" initialized
INFO - 2022-03-23 00:25:39 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 00:25:39 --> Model "Prefix_master" initialized
INFO - 2022-03-23 00:25:39 --> Model "Users_model" initialized
INFO - 2022-03-23 00:25:39 --> Model "Hospital_model" initialized
ERROR - 2022-03-23 00:25:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 00:25:40 --> Config Class Initialized
INFO - 2022-03-23 00:25:40 --> Hooks Class Initialized
DEBUG - 2022-03-23 00:25:40 --> UTF-8 Support Enabled
INFO - 2022-03-23 00:25:40 --> Utf8 Class Initialized
INFO - 2022-03-23 00:25:40 --> URI Class Initialized
INFO - 2022-03-23 00:25:40 --> Router Class Initialized
INFO - 2022-03-23 00:25:40 --> Output Class Initialized
INFO - 2022-03-23 00:25:40 --> Security Class Initialized
DEBUG - 2022-03-23 00:25:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 00:25:40 --> Input Class Initialized
INFO - 2022-03-23 00:25:40 --> Language Class Initialized
INFO - 2022-03-23 00:25:40 --> Loader Class Initialized
INFO - 2022-03-23 00:25:40 --> Helper loaded: url_helper
INFO - 2022-03-23 00:25:40 --> Helper loaded: form_helper
INFO - 2022-03-23 00:25:40 --> Helper loaded: common_helper
INFO - 2022-03-23 00:25:40 --> Database Driver Class Initialized
DEBUG - 2022-03-23 00:25:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 00:25:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 00:25:40 --> Controller Class Initialized
INFO - 2022-03-23 00:25:40 --> Form Validation Class Initialized
DEBUG - 2022-03-23 00:25:40 --> Encrypt Class Initialized
INFO - 2022-03-23 00:25:40 --> Model "Patient_model" initialized
INFO - 2022-03-23 00:25:40 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 00:25:40 --> Model "Prefix_master" initialized
INFO - 2022-03-23 00:25:40 --> Model "Users_model" initialized
INFO - 2022-03-23 00:25:40 --> Model "Hospital_model" initialized
INFO - 2022-03-23 00:25:40 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 00:25:40 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-23 00:25:40 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 00:25:40 --> Final output sent to browser
DEBUG - 2022-03-23 00:25:40 --> Total execution time: 0.1366
ERROR - 2022-03-23 00:28:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 00:28:46 --> Config Class Initialized
INFO - 2022-03-23 00:28:46 --> Hooks Class Initialized
DEBUG - 2022-03-23 00:28:46 --> UTF-8 Support Enabled
INFO - 2022-03-23 00:28:46 --> Utf8 Class Initialized
INFO - 2022-03-23 00:28:46 --> URI Class Initialized
INFO - 2022-03-23 00:28:46 --> Router Class Initialized
INFO - 2022-03-23 00:28:46 --> Output Class Initialized
INFO - 2022-03-23 00:28:46 --> Security Class Initialized
DEBUG - 2022-03-23 00:28:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 00:28:46 --> Input Class Initialized
INFO - 2022-03-23 00:28:46 --> Language Class Initialized
INFO - 2022-03-23 00:28:46 --> Loader Class Initialized
INFO - 2022-03-23 00:28:46 --> Helper loaded: url_helper
INFO - 2022-03-23 00:28:46 --> Helper loaded: form_helper
INFO - 2022-03-23 00:28:46 --> Helper loaded: common_helper
INFO - 2022-03-23 00:28:46 --> Database Driver Class Initialized
DEBUG - 2022-03-23 00:28:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 00:28:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 00:28:46 --> Controller Class Initialized
INFO - 2022-03-23 00:28:46 --> Form Validation Class Initialized
DEBUG - 2022-03-23 00:28:46 --> Encrypt Class Initialized
INFO - 2022-03-23 00:28:46 --> Model "Patient_model" initialized
INFO - 2022-03-23 00:28:46 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 00:28:46 --> Model "Prefix_master" initialized
INFO - 2022-03-23 00:28:46 --> Model "Users_model" initialized
INFO - 2022-03-23 00:28:46 --> Model "Hospital_model" initialized
ERROR - 2022-03-23 00:28:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 00:28:46 --> Config Class Initialized
INFO - 2022-03-23 00:28:46 --> Hooks Class Initialized
DEBUG - 2022-03-23 00:28:46 --> UTF-8 Support Enabled
INFO - 2022-03-23 00:28:46 --> Utf8 Class Initialized
INFO - 2022-03-23 00:28:46 --> URI Class Initialized
INFO - 2022-03-23 00:28:46 --> Router Class Initialized
INFO - 2022-03-23 00:28:46 --> Output Class Initialized
INFO - 2022-03-23 00:28:46 --> Security Class Initialized
DEBUG - 2022-03-23 00:28:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 00:28:46 --> Input Class Initialized
INFO - 2022-03-23 00:28:46 --> Language Class Initialized
INFO - 2022-03-23 00:28:46 --> Loader Class Initialized
INFO - 2022-03-23 00:28:46 --> Helper loaded: url_helper
INFO - 2022-03-23 00:28:46 --> Helper loaded: form_helper
INFO - 2022-03-23 00:28:46 --> Helper loaded: common_helper
INFO - 2022-03-23 00:28:46 --> Database Driver Class Initialized
DEBUG - 2022-03-23 00:28:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 00:28:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 00:28:46 --> Controller Class Initialized
INFO - 2022-03-23 00:28:46 --> Form Validation Class Initialized
DEBUG - 2022-03-23 00:28:46 --> Encrypt Class Initialized
INFO - 2022-03-23 00:28:46 --> Model "Patient_model" initialized
INFO - 2022-03-23 00:28:46 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 00:28:46 --> Model "Prefix_master" initialized
INFO - 2022-03-23 00:28:46 --> Model "Users_model" initialized
INFO - 2022-03-23 00:28:46 --> Model "Hospital_model" initialized
INFO - 2022-03-23 00:28:46 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 00:28:46 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-23 00:28:46 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 00:28:46 --> Final output sent to browser
DEBUG - 2022-03-23 00:28:46 --> Total execution time: 0.0580
ERROR - 2022-03-23 00:29:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 00:29:11 --> Config Class Initialized
INFO - 2022-03-23 00:29:11 --> Hooks Class Initialized
DEBUG - 2022-03-23 00:29:11 --> UTF-8 Support Enabled
INFO - 2022-03-23 00:29:11 --> Utf8 Class Initialized
INFO - 2022-03-23 00:29:11 --> URI Class Initialized
INFO - 2022-03-23 00:29:11 --> Router Class Initialized
INFO - 2022-03-23 00:29:11 --> Output Class Initialized
INFO - 2022-03-23 00:29:11 --> Security Class Initialized
DEBUG - 2022-03-23 00:29:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 00:29:11 --> Input Class Initialized
INFO - 2022-03-23 00:29:11 --> Language Class Initialized
INFO - 2022-03-23 00:29:11 --> Loader Class Initialized
INFO - 2022-03-23 00:29:11 --> Helper loaded: url_helper
INFO - 2022-03-23 00:29:11 --> Helper loaded: form_helper
INFO - 2022-03-23 00:29:11 --> Helper loaded: common_helper
INFO - 2022-03-23 00:29:11 --> Database Driver Class Initialized
DEBUG - 2022-03-23 00:29:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 00:29:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 00:29:11 --> Controller Class Initialized
INFO - 2022-03-23 00:29:11 --> Form Validation Class Initialized
DEBUG - 2022-03-23 00:29:11 --> Encrypt Class Initialized
INFO - 2022-03-23 00:29:11 --> Model "Patient_model" initialized
INFO - 2022-03-23 00:29:11 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 00:29:11 --> Model "Prefix_master" initialized
INFO - 2022-03-23 00:29:11 --> Model "Users_model" initialized
INFO - 2022-03-23 00:29:11 --> Model "Hospital_model" initialized
ERROR - 2022-03-23 00:29:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 00:29:12 --> Config Class Initialized
INFO - 2022-03-23 00:29:12 --> Hooks Class Initialized
DEBUG - 2022-03-23 00:29:12 --> UTF-8 Support Enabled
INFO - 2022-03-23 00:29:12 --> Utf8 Class Initialized
INFO - 2022-03-23 00:29:12 --> URI Class Initialized
INFO - 2022-03-23 00:29:12 --> Router Class Initialized
INFO - 2022-03-23 00:29:12 --> Output Class Initialized
INFO - 2022-03-23 00:29:12 --> Security Class Initialized
DEBUG - 2022-03-23 00:29:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 00:29:12 --> Input Class Initialized
INFO - 2022-03-23 00:29:12 --> Language Class Initialized
INFO - 2022-03-23 00:29:12 --> Loader Class Initialized
INFO - 2022-03-23 00:29:12 --> Helper loaded: url_helper
INFO - 2022-03-23 00:29:12 --> Helper loaded: form_helper
INFO - 2022-03-23 00:29:12 --> Helper loaded: common_helper
INFO - 2022-03-23 00:29:12 --> Database Driver Class Initialized
DEBUG - 2022-03-23 00:29:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 00:29:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 00:29:12 --> Controller Class Initialized
INFO - 2022-03-23 00:29:12 --> Form Validation Class Initialized
DEBUG - 2022-03-23 00:29:12 --> Encrypt Class Initialized
INFO - 2022-03-23 00:29:12 --> Model "Patient_model" initialized
INFO - 2022-03-23 00:29:12 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 00:29:12 --> Model "Prefix_master" initialized
INFO - 2022-03-23 00:29:12 --> Model "Users_model" initialized
INFO - 2022-03-23 00:29:12 --> Model "Hospital_model" initialized
INFO - 2022-03-23 00:29:12 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 00:29:12 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-23 00:29:12 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 00:29:12 --> Final output sent to browser
DEBUG - 2022-03-23 00:29:12 --> Total execution time: 0.0325
ERROR - 2022-03-23 00:29:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 00:29:32 --> Config Class Initialized
INFO - 2022-03-23 00:29:32 --> Hooks Class Initialized
DEBUG - 2022-03-23 00:29:32 --> UTF-8 Support Enabled
INFO - 2022-03-23 00:29:32 --> Utf8 Class Initialized
INFO - 2022-03-23 00:29:32 --> URI Class Initialized
INFO - 2022-03-23 00:29:32 --> Router Class Initialized
INFO - 2022-03-23 00:29:32 --> Output Class Initialized
INFO - 2022-03-23 00:29:32 --> Security Class Initialized
DEBUG - 2022-03-23 00:29:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 00:29:32 --> Input Class Initialized
INFO - 2022-03-23 00:29:32 --> Language Class Initialized
INFO - 2022-03-23 00:29:32 --> Loader Class Initialized
INFO - 2022-03-23 00:29:32 --> Helper loaded: url_helper
INFO - 2022-03-23 00:29:32 --> Helper loaded: form_helper
INFO - 2022-03-23 00:29:32 --> Helper loaded: common_helper
INFO - 2022-03-23 00:29:32 --> Database Driver Class Initialized
DEBUG - 2022-03-23 00:29:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 00:29:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 00:29:32 --> Controller Class Initialized
INFO - 2022-03-23 00:29:32 --> Form Validation Class Initialized
DEBUG - 2022-03-23 00:29:32 --> Encrypt Class Initialized
INFO - 2022-03-23 00:29:32 --> Model "Patient_model" initialized
INFO - 2022-03-23 00:29:32 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 00:29:32 --> Model "Prefix_master" initialized
INFO - 2022-03-23 00:29:32 --> Model "Users_model" initialized
INFO - 2022-03-23 00:29:32 --> Model "Hospital_model" initialized
INFO - 2022-03-23 00:29:33 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-23 00:29:34 --> Final output sent to browser
DEBUG - 2022-03-23 00:29:34 --> Total execution time: 1.0391
ERROR - 2022-03-23 00:50:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 00:50:59 --> Config Class Initialized
INFO - 2022-03-23 00:50:59 --> Hooks Class Initialized
DEBUG - 2022-03-23 00:50:59 --> UTF-8 Support Enabled
INFO - 2022-03-23 00:50:59 --> Utf8 Class Initialized
INFO - 2022-03-23 00:50:59 --> URI Class Initialized
INFO - 2022-03-23 00:50:59 --> Router Class Initialized
INFO - 2022-03-23 00:50:59 --> Output Class Initialized
INFO - 2022-03-23 00:50:59 --> Security Class Initialized
DEBUG - 2022-03-23 00:50:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 00:50:59 --> Input Class Initialized
INFO - 2022-03-23 00:50:59 --> Language Class Initialized
INFO - 2022-03-23 00:50:59 --> Loader Class Initialized
INFO - 2022-03-23 00:50:59 --> Helper loaded: url_helper
INFO - 2022-03-23 00:50:59 --> Helper loaded: form_helper
INFO - 2022-03-23 00:50:59 --> Helper loaded: common_helper
INFO - 2022-03-23 00:50:59 --> Database Driver Class Initialized
DEBUG - 2022-03-23 00:50:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 00:50:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 00:50:59 --> Controller Class Initialized
INFO - 2022-03-23 00:50:59 --> Form Validation Class Initialized
DEBUG - 2022-03-23 00:50:59 --> Encrypt Class Initialized
INFO - 2022-03-23 00:50:59 --> Model "Patient_model" initialized
INFO - 2022-03-23 00:50:59 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 00:50:59 --> Model "Prefix_master" initialized
INFO - 2022-03-23 00:50:59 --> Model "Users_model" initialized
INFO - 2022-03-23 00:50:59 --> Model "Hospital_model" initialized
INFO - 2022-03-23 00:51:00 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-23 00:51:00 --> Final output sent to browser
DEBUG - 2022-03-23 00:51:00 --> Total execution time: 1.1221
ERROR - 2022-03-23 00:52:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 00:52:16 --> Config Class Initialized
INFO - 2022-03-23 00:52:16 --> Hooks Class Initialized
DEBUG - 2022-03-23 00:52:16 --> UTF-8 Support Enabled
INFO - 2022-03-23 00:52:16 --> Utf8 Class Initialized
INFO - 2022-03-23 00:52:16 --> URI Class Initialized
INFO - 2022-03-23 00:52:16 --> Router Class Initialized
INFO - 2022-03-23 00:52:16 --> Output Class Initialized
INFO - 2022-03-23 00:52:16 --> Security Class Initialized
DEBUG - 2022-03-23 00:52:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 00:52:16 --> Input Class Initialized
INFO - 2022-03-23 00:52:16 --> Language Class Initialized
INFO - 2022-03-23 00:52:16 --> Loader Class Initialized
INFO - 2022-03-23 00:52:16 --> Helper loaded: url_helper
INFO - 2022-03-23 00:52:16 --> Helper loaded: form_helper
INFO - 2022-03-23 00:52:16 --> Helper loaded: common_helper
INFO - 2022-03-23 00:52:16 --> Database Driver Class Initialized
DEBUG - 2022-03-23 00:52:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 00:52:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 00:52:16 --> Controller Class Initialized
INFO - 2022-03-23 00:52:16 --> Form Validation Class Initialized
DEBUG - 2022-03-23 00:52:16 --> Encrypt Class Initialized
INFO - 2022-03-23 00:52:16 --> Model "Patient_model" initialized
INFO - 2022-03-23 00:52:16 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 00:52:16 --> Model "Prefix_master" initialized
INFO - 2022-03-23 00:52:16 --> Model "Users_model" initialized
INFO - 2022-03-23 00:52:16 --> Model "Hospital_model" initialized
INFO - 2022-03-23 00:52:16 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 00:52:16 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-23 00:52:16 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 00:52:16 --> Final output sent to browser
DEBUG - 2022-03-23 00:52:16 --> Total execution time: 0.0441
ERROR - 2022-03-23 00:52:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 00:52:19 --> Config Class Initialized
INFO - 2022-03-23 00:52:19 --> Hooks Class Initialized
DEBUG - 2022-03-23 00:52:19 --> UTF-8 Support Enabled
INFO - 2022-03-23 00:52:19 --> Utf8 Class Initialized
INFO - 2022-03-23 00:52:19 --> URI Class Initialized
INFO - 2022-03-23 00:52:19 --> Router Class Initialized
INFO - 2022-03-23 00:52:19 --> Output Class Initialized
INFO - 2022-03-23 00:52:19 --> Security Class Initialized
DEBUG - 2022-03-23 00:52:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 00:52:19 --> Input Class Initialized
INFO - 2022-03-23 00:52:19 --> Language Class Initialized
INFO - 2022-03-23 00:52:19 --> Loader Class Initialized
INFO - 2022-03-23 00:52:19 --> Helper loaded: url_helper
INFO - 2022-03-23 00:52:19 --> Helper loaded: form_helper
INFO - 2022-03-23 00:52:19 --> Helper loaded: common_helper
INFO - 2022-03-23 00:52:19 --> Database Driver Class Initialized
DEBUG - 2022-03-23 00:52:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 00:52:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 00:52:19 --> Controller Class Initialized
INFO - 2022-03-23 00:52:19 --> Form Validation Class Initialized
DEBUG - 2022-03-23 00:52:19 --> Encrypt Class Initialized
INFO - 2022-03-23 00:52:19 --> Model "Patient_model" initialized
INFO - 2022-03-23 00:52:19 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 00:52:19 --> Model "Referredby_model" initialized
INFO - 2022-03-23 00:52:19 --> Model "Prefix_master" initialized
INFO - 2022-03-23 00:52:19 --> Model "Hospital_model" initialized
INFO - 2022-03-23 00:52:19 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 00:52:19 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-23 00:52:19 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 00:52:19 --> Final output sent to browser
DEBUG - 2022-03-23 00:52:19 --> Total execution time: 0.0271
ERROR - 2022-03-23 00:52:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 00:52:55 --> Config Class Initialized
INFO - 2022-03-23 00:52:55 --> Hooks Class Initialized
DEBUG - 2022-03-23 00:52:55 --> UTF-8 Support Enabled
INFO - 2022-03-23 00:52:55 --> Utf8 Class Initialized
INFO - 2022-03-23 00:52:55 --> URI Class Initialized
INFO - 2022-03-23 00:52:55 --> Router Class Initialized
INFO - 2022-03-23 00:52:55 --> Output Class Initialized
INFO - 2022-03-23 00:52:55 --> Security Class Initialized
DEBUG - 2022-03-23 00:52:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 00:52:55 --> Input Class Initialized
INFO - 2022-03-23 00:52:55 --> Language Class Initialized
INFO - 2022-03-23 00:52:55 --> Loader Class Initialized
INFO - 2022-03-23 00:52:55 --> Helper loaded: url_helper
INFO - 2022-03-23 00:52:55 --> Helper loaded: form_helper
INFO - 2022-03-23 00:52:55 --> Helper loaded: common_helper
INFO - 2022-03-23 00:52:55 --> Database Driver Class Initialized
DEBUG - 2022-03-23 00:52:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 00:52:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 00:52:55 --> Controller Class Initialized
INFO - 2022-03-23 00:52:55 --> Form Validation Class Initialized
DEBUG - 2022-03-23 00:52:55 --> Encrypt Class Initialized
INFO - 2022-03-23 00:52:55 --> Model "Patient_model" initialized
INFO - 2022-03-23 00:52:55 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 00:52:55 --> Model "Referredby_model" initialized
INFO - 2022-03-23 00:52:55 --> Model "Prefix_master" initialized
INFO - 2022-03-23 00:52:55 --> Model "Hospital_model" initialized
ERROR - 2022-03-23 00:52:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 00:52:55 --> Config Class Initialized
INFO - 2022-03-23 00:52:55 --> Hooks Class Initialized
DEBUG - 2022-03-23 00:52:55 --> UTF-8 Support Enabled
INFO - 2022-03-23 00:52:55 --> Utf8 Class Initialized
INFO - 2022-03-23 00:52:55 --> URI Class Initialized
INFO - 2022-03-23 00:52:55 --> Router Class Initialized
INFO - 2022-03-23 00:52:55 --> Output Class Initialized
INFO - 2022-03-23 00:52:55 --> Security Class Initialized
DEBUG - 2022-03-23 00:52:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 00:52:55 --> Input Class Initialized
INFO - 2022-03-23 00:52:55 --> Language Class Initialized
INFO - 2022-03-23 00:52:55 --> Loader Class Initialized
INFO - 2022-03-23 00:52:55 --> Helper loaded: url_helper
INFO - 2022-03-23 00:52:55 --> Helper loaded: form_helper
INFO - 2022-03-23 00:52:55 --> Helper loaded: common_helper
INFO - 2022-03-23 00:52:55 --> Database Driver Class Initialized
DEBUG - 2022-03-23 00:52:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 00:52:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 00:52:55 --> Controller Class Initialized
INFO - 2022-03-23 00:52:55 --> Form Validation Class Initialized
DEBUG - 2022-03-23 00:52:55 --> Encrypt Class Initialized
INFO - 2022-03-23 00:52:55 --> Model "Patient_model" initialized
INFO - 2022-03-23 00:52:55 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 00:52:55 --> Model "Referredby_model" initialized
INFO - 2022-03-23 00:52:55 --> Model "Prefix_master" initialized
INFO - 2022-03-23 00:52:55 --> Model "Hospital_model" initialized
INFO - 2022-03-23 00:52:55 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 00:52:55 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-23 00:52:55 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 00:52:55 --> Final output sent to browser
DEBUG - 2022-03-23 00:52:55 --> Total execution time: 0.0241
ERROR - 2022-03-23 00:52:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 00:52:56 --> Config Class Initialized
INFO - 2022-03-23 00:52:56 --> Hooks Class Initialized
DEBUG - 2022-03-23 00:52:56 --> UTF-8 Support Enabled
INFO - 2022-03-23 00:52:56 --> Utf8 Class Initialized
INFO - 2022-03-23 00:52:56 --> URI Class Initialized
INFO - 2022-03-23 00:52:56 --> Router Class Initialized
INFO - 2022-03-23 00:52:56 --> Output Class Initialized
INFO - 2022-03-23 00:52:56 --> Security Class Initialized
DEBUG - 2022-03-23 00:52:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 00:52:56 --> Input Class Initialized
INFO - 2022-03-23 00:52:56 --> Language Class Initialized
INFO - 2022-03-23 00:52:56 --> Loader Class Initialized
INFO - 2022-03-23 00:52:56 --> Helper loaded: url_helper
INFO - 2022-03-23 00:52:56 --> Helper loaded: form_helper
INFO - 2022-03-23 00:52:56 --> Helper loaded: common_helper
INFO - 2022-03-23 00:52:56 --> Database Driver Class Initialized
DEBUG - 2022-03-23 00:52:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 00:52:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 00:52:56 --> Controller Class Initialized
INFO - 2022-03-23 00:52:56 --> Form Validation Class Initialized
DEBUG - 2022-03-23 00:52:56 --> Encrypt Class Initialized
INFO - 2022-03-23 00:52:56 --> Model "Patient_model" initialized
INFO - 2022-03-23 00:52:56 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 00:52:56 --> Model "Prefix_master" initialized
INFO - 2022-03-23 00:52:56 --> Model "Users_model" initialized
INFO - 2022-03-23 00:52:56 --> Model "Hospital_model" initialized
INFO - 2022-03-23 00:52:56 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 00:52:56 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-23 00:52:56 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 00:52:56 --> Final output sent to browser
DEBUG - 2022-03-23 00:52:56 --> Total execution time: 0.0437
ERROR - 2022-03-23 00:53:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 00:53:07 --> Config Class Initialized
INFO - 2022-03-23 00:53:07 --> Hooks Class Initialized
DEBUG - 2022-03-23 00:53:07 --> UTF-8 Support Enabled
INFO - 2022-03-23 00:53:07 --> Utf8 Class Initialized
INFO - 2022-03-23 00:53:07 --> URI Class Initialized
INFO - 2022-03-23 00:53:07 --> Router Class Initialized
INFO - 2022-03-23 00:53:07 --> Output Class Initialized
INFO - 2022-03-23 00:53:07 --> Security Class Initialized
DEBUG - 2022-03-23 00:53:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 00:53:07 --> Input Class Initialized
INFO - 2022-03-23 00:53:07 --> Language Class Initialized
INFO - 2022-03-23 00:53:07 --> Loader Class Initialized
INFO - 2022-03-23 00:53:07 --> Helper loaded: url_helper
INFO - 2022-03-23 00:53:07 --> Helper loaded: form_helper
INFO - 2022-03-23 00:53:07 --> Helper loaded: common_helper
INFO - 2022-03-23 00:53:07 --> Database Driver Class Initialized
DEBUG - 2022-03-23 00:53:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 00:53:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 00:53:07 --> Controller Class Initialized
INFO - 2022-03-23 00:53:07 --> Form Validation Class Initialized
DEBUG - 2022-03-23 00:53:07 --> Encrypt Class Initialized
INFO - 2022-03-23 00:53:07 --> Model "Patient_model" initialized
INFO - 2022-03-23 00:53:07 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 00:53:07 --> Model "Prefix_master" initialized
INFO - 2022-03-23 00:53:07 --> Model "Users_model" initialized
INFO - 2022-03-23 00:53:07 --> Model "Hospital_model" initialized
INFO - 2022-03-23 00:53:08 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-23 00:53:08 --> Final output sent to browser
DEBUG - 2022-03-23 00:53:08 --> Total execution time: 0.5958
ERROR - 2022-03-23 01:08:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 01:08:31 --> Config Class Initialized
INFO - 2022-03-23 01:08:31 --> Hooks Class Initialized
DEBUG - 2022-03-23 01:08:31 --> UTF-8 Support Enabled
INFO - 2022-03-23 01:08:31 --> Utf8 Class Initialized
INFO - 2022-03-23 01:08:31 --> URI Class Initialized
INFO - 2022-03-23 01:08:31 --> Router Class Initialized
INFO - 2022-03-23 01:08:31 --> Output Class Initialized
INFO - 2022-03-23 01:08:31 --> Security Class Initialized
DEBUG - 2022-03-23 01:08:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 01:08:31 --> Input Class Initialized
INFO - 2022-03-23 01:08:31 --> Language Class Initialized
INFO - 2022-03-23 01:08:31 --> Loader Class Initialized
INFO - 2022-03-23 01:08:31 --> Helper loaded: url_helper
INFO - 2022-03-23 01:08:31 --> Helper loaded: form_helper
INFO - 2022-03-23 01:08:31 --> Helper loaded: common_helper
INFO - 2022-03-23 01:08:31 --> Database Driver Class Initialized
DEBUG - 2022-03-23 01:08:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 01:08:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 01:08:31 --> Controller Class Initialized
INFO - 2022-03-23 01:08:31 --> Form Validation Class Initialized
DEBUG - 2022-03-23 01:08:31 --> Encrypt Class Initialized
DEBUG - 2022-03-23 01:08:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 01:08:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-23 01:08:31 --> Email Class Initialized
INFO - 2022-03-23 01:08:31 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-23 01:08:31 --> Calendar Class Initialized
INFO - 2022-03-23 01:08:31 --> Model "Login_model" initialized
ERROR - 2022-03-23 01:08:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 01:08:31 --> Config Class Initialized
INFO - 2022-03-23 01:08:31 --> Hooks Class Initialized
DEBUG - 2022-03-23 01:08:31 --> UTF-8 Support Enabled
INFO - 2022-03-23 01:08:31 --> Utf8 Class Initialized
INFO - 2022-03-23 01:08:31 --> URI Class Initialized
INFO - 2022-03-23 01:08:31 --> Router Class Initialized
INFO - 2022-03-23 01:08:31 --> Output Class Initialized
INFO - 2022-03-23 01:08:31 --> Security Class Initialized
DEBUG - 2022-03-23 01:08:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 01:08:31 --> Input Class Initialized
INFO - 2022-03-23 01:08:31 --> Language Class Initialized
INFO - 2022-03-23 01:08:31 --> Loader Class Initialized
INFO - 2022-03-23 01:08:31 --> Helper loaded: url_helper
INFO - 2022-03-23 01:08:31 --> Helper loaded: form_helper
INFO - 2022-03-23 01:08:31 --> Helper loaded: common_helper
INFO - 2022-03-23 01:08:31 --> Database Driver Class Initialized
DEBUG - 2022-03-23 01:08:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 01:08:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 01:08:31 --> Controller Class Initialized
INFO - 2022-03-23 01:08:31 --> Form Validation Class Initialized
DEBUG - 2022-03-23 01:08:31 --> Encrypt Class Initialized
INFO - 2022-03-23 01:08:31 --> Model "Diseases_model" initialized
INFO - 2022-03-23 01:08:31 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 01:08:31 --> File loaded: /home3/karoteam/public_html/application/views/diseases/index.php
INFO - 2022-03-23 01:08:31 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 01:08:31 --> Final output sent to browser
DEBUG - 2022-03-23 01:08:31 --> Total execution time: 0.0099
ERROR - 2022-03-23 01:08:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 01:08:36 --> Config Class Initialized
INFO - 2022-03-23 01:08:36 --> Hooks Class Initialized
DEBUG - 2022-03-23 01:08:36 --> UTF-8 Support Enabled
INFO - 2022-03-23 01:08:36 --> Utf8 Class Initialized
INFO - 2022-03-23 01:08:36 --> URI Class Initialized
INFO - 2022-03-23 01:08:36 --> Router Class Initialized
INFO - 2022-03-23 01:08:36 --> Output Class Initialized
INFO - 2022-03-23 01:08:36 --> Security Class Initialized
DEBUG - 2022-03-23 01:08:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 01:08:36 --> Input Class Initialized
INFO - 2022-03-23 01:08:36 --> Language Class Initialized
INFO - 2022-03-23 01:08:36 --> Loader Class Initialized
INFO - 2022-03-23 01:08:36 --> Helper loaded: url_helper
INFO - 2022-03-23 01:08:36 --> Helper loaded: form_helper
INFO - 2022-03-23 01:08:36 --> Helper loaded: common_helper
INFO - 2022-03-23 01:08:36 --> Database Driver Class Initialized
DEBUG - 2022-03-23 01:08:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 01:08:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 01:08:36 --> Controller Class Initialized
INFO - 2022-03-23 01:08:36 --> Form Validation Class Initialized
DEBUG - 2022-03-23 01:08:36 --> Encrypt Class Initialized
INFO - 2022-03-23 01:08:36 --> Model "Patient_model" initialized
INFO - 2022-03-23 01:08:36 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 01:08:36 --> Model "Referredby_model" initialized
INFO - 2022-03-23 01:08:36 --> Model "Prefix_master" initialized
INFO - 2022-03-23 01:08:36 --> Model "Hospital_model" initialized
INFO - 2022-03-23 01:08:36 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 01:08:36 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-23 01:08:36 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 01:08:36 --> Final output sent to browser
DEBUG - 2022-03-23 01:08:36 --> Total execution time: 0.0731
ERROR - 2022-03-23 01:08:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 01:08:51 --> Config Class Initialized
INFO - 2022-03-23 01:08:51 --> Hooks Class Initialized
DEBUG - 2022-03-23 01:08:51 --> UTF-8 Support Enabled
INFO - 2022-03-23 01:08:51 --> Utf8 Class Initialized
INFO - 2022-03-23 01:08:51 --> URI Class Initialized
INFO - 2022-03-23 01:08:51 --> Router Class Initialized
INFO - 2022-03-23 01:08:51 --> Output Class Initialized
INFO - 2022-03-23 01:08:51 --> Security Class Initialized
DEBUG - 2022-03-23 01:08:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 01:08:51 --> Input Class Initialized
INFO - 2022-03-23 01:08:51 --> Language Class Initialized
INFO - 2022-03-23 01:08:51 --> Loader Class Initialized
INFO - 2022-03-23 01:08:51 --> Helper loaded: url_helper
INFO - 2022-03-23 01:08:51 --> Helper loaded: form_helper
INFO - 2022-03-23 01:08:51 --> Helper loaded: common_helper
INFO - 2022-03-23 01:08:51 --> Database Driver Class Initialized
DEBUG - 2022-03-23 01:08:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 01:08:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 01:08:51 --> Controller Class Initialized
INFO - 2022-03-23 01:08:51 --> Form Validation Class Initialized
DEBUG - 2022-03-23 01:08:51 --> Encrypt Class Initialized
INFO - 2022-03-23 01:08:51 --> Model "Patient_model" initialized
INFO - 2022-03-23 01:08:51 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 01:08:51 --> Model "Prefix_master" initialized
INFO - 2022-03-23 01:08:51 --> Model "Users_model" initialized
INFO - 2022-03-23 01:08:51 --> Model "Hospital_model" initialized
INFO - 2022-03-23 01:08:51 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-23 01:08:51 --> Final output sent to browser
DEBUG - 2022-03-23 01:08:51 --> Total execution time: 0.9360
ERROR - 2022-03-23 01:09:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 01:09:40 --> Config Class Initialized
INFO - 2022-03-23 01:09:40 --> Hooks Class Initialized
DEBUG - 2022-03-23 01:09:40 --> UTF-8 Support Enabled
INFO - 2022-03-23 01:09:40 --> Utf8 Class Initialized
INFO - 2022-03-23 01:09:40 --> URI Class Initialized
DEBUG - 2022-03-23 01:09:40 --> No URI present. Default controller set.
INFO - 2022-03-23 01:09:40 --> Router Class Initialized
INFO - 2022-03-23 01:09:40 --> Output Class Initialized
INFO - 2022-03-23 01:09:40 --> Security Class Initialized
DEBUG - 2022-03-23 01:09:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 01:09:40 --> Input Class Initialized
INFO - 2022-03-23 01:09:40 --> Language Class Initialized
INFO - 2022-03-23 01:09:40 --> Loader Class Initialized
INFO - 2022-03-23 01:09:40 --> Helper loaded: url_helper
INFO - 2022-03-23 01:09:40 --> Helper loaded: form_helper
INFO - 2022-03-23 01:09:40 --> Helper loaded: common_helper
INFO - 2022-03-23 01:09:40 --> Database Driver Class Initialized
DEBUG - 2022-03-23 01:09:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 01:09:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 01:09:40 --> Controller Class Initialized
INFO - 2022-03-23 01:09:40 --> Form Validation Class Initialized
DEBUG - 2022-03-23 01:09:40 --> Encrypt Class Initialized
DEBUG - 2022-03-23 01:09:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 01:09:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-23 01:09:40 --> Email Class Initialized
INFO - 2022-03-23 01:09:40 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-23 01:09:40 --> Calendar Class Initialized
INFO - 2022-03-23 01:09:40 --> Model "Login_model" initialized
INFO - 2022-03-23 01:09:40 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-23 01:09:40 --> Final output sent to browser
DEBUG - 2022-03-23 01:09:40 --> Total execution time: 0.0077
ERROR - 2022-03-23 01:09:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 01:09:45 --> Config Class Initialized
INFO - 2022-03-23 01:09:45 --> Hooks Class Initialized
DEBUG - 2022-03-23 01:09:45 --> UTF-8 Support Enabled
INFO - 2022-03-23 01:09:45 --> Utf8 Class Initialized
INFO - 2022-03-23 01:09:45 --> URI Class Initialized
INFO - 2022-03-23 01:09:45 --> Router Class Initialized
INFO - 2022-03-23 01:09:45 --> Output Class Initialized
INFO - 2022-03-23 01:09:45 --> Security Class Initialized
DEBUG - 2022-03-23 01:09:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 01:09:45 --> Input Class Initialized
INFO - 2022-03-23 01:09:45 --> Language Class Initialized
INFO - 2022-03-23 01:09:45 --> Loader Class Initialized
INFO - 2022-03-23 01:09:45 --> Helper loaded: url_helper
INFO - 2022-03-23 01:09:45 --> Helper loaded: form_helper
INFO - 2022-03-23 01:09:45 --> Helper loaded: common_helper
INFO - 2022-03-23 01:09:45 --> Database Driver Class Initialized
DEBUG - 2022-03-23 01:09:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 01:09:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 01:09:45 --> Controller Class Initialized
INFO - 2022-03-23 01:09:45 --> Form Validation Class Initialized
DEBUG - 2022-03-23 01:09:45 --> Encrypt Class Initialized
DEBUG - 2022-03-23 01:09:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 01:09:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-23 01:09:45 --> Email Class Initialized
INFO - 2022-03-23 01:09:45 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-23 01:09:45 --> Calendar Class Initialized
INFO - 2022-03-23 01:09:45 --> Model "Login_model" initialized
INFO - 2022-03-23 01:09:45 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-03-23 01:09:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 01:09:45 --> Config Class Initialized
INFO - 2022-03-23 01:09:45 --> Hooks Class Initialized
DEBUG - 2022-03-23 01:09:45 --> UTF-8 Support Enabled
INFO - 2022-03-23 01:09:45 --> Utf8 Class Initialized
INFO - 2022-03-23 01:09:45 --> URI Class Initialized
INFO - 2022-03-23 01:09:45 --> Router Class Initialized
INFO - 2022-03-23 01:09:45 --> Output Class Initialized
INFO - 2022-03-23 01:09:45 --> Security Class Initialized
DEBUG - 2022-03-23 01:09:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 01:09:45 --> Input Class Initialized
INFO - 2022-03-23 01:09:45 --> Language Class Initialized
INFO - 2022-03-23 01:09:45 --> Loader Class Initialized
INFO - 2022-03-23 01:09:45 --> Helper loaded: url_helper
INFO - 2022-03-23 01:09:45 --> Helper loaded: form_helper
INFO - 2022-03-23 01:09:45 --> Helper loaded: common_helper
INFO - 2022-03-23 01:09:45 --> Database Driver Class Initialized
DEBUG - 2022-03-23 01:09:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 01:09:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 01:09:45 --> Controller Class Initialized
INFO - 2022-03-23 01:09:45 --> Form Validation Class Initialized
DEBUG - 2022-03-23 01:09:45 --> Encrypt Class Initialized
INFO - 2022-03-23 01:09:45 --> Model "Login_model" initialized
INFO - 2022-03-23 01:09:45 --> Model "Dashboard_model" initialized
INFO - 2022-03-23 01:09:45 --> Model "Case_model" initialized
INFO - 2022-03-23 01:09:53 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 01:10:04 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2022-03-23 01:10:04 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 01:10:04 --> Final output sent to browser
DEBUG - 2022-03-23 01:10:04 --> Total execution time: 19.3787
ERROR - 2022-03-23 01:10:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 01:10:40 --> Config Class Initialized
INFO - 2022-03-23 01:10:40 --> Hooks Class Initialized
DEBUG - 2022-03-23 01:10:40 --> UTF-8 Support Enabled
INFO - 2022-03-23 01:10:40 --> Utf8 Class Initialized
INFO - 2022-03-23 01:10:40 --> URI Class Initialized
INFO - 2022-03-23 01:10:40 --> Router Class Initialized
INFO - 2022-03-23 01:10:40 --> Output Class Initialized
INFO - 2022-03-23 01:10:40 --> Security Class Initialized
DEBUG - 2022-03-23 01:10:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 01:10:40 --> Input Class Initialized
INFO - 2022-03-23 01:10:40 --> Language Class Initialized
INFO - 2022-03-23 01:10:40 --> Loader Class Initialized
INFO - 2022-03-23 01:10:40 --> Helper loaded: url_helper
INFO - 2022-03-23 01:10:40 --> Helper loaded: form_helper
INFO - 2022-03-23 01:10:40 --> Helper loaded: common_helper
INFO - 2022-03-23 01:10:40 --> Database Driver Class Initialized
DEBUG - 2022-03-23 01:10:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 01:10:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 01:10:40 --> Controller Class Initialized
INFO - 2022-03-23 01:10:40 --> Form Validation Class Initialized
DEBUG - 2022-03-23 01:10:40 --> Encrypt Class Initialized
INFO - 2022-03-23 01:10:40 --> Model "Patient_model" initialized
INFO - 2022-03-23 01:10:40 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 01:10:40 --> Model "Prefix_master" initialized
INFO - 2022-03-23 01:10:40 --> Model "Users_model" initialized
INFO - 2022-03-23 01:10:40 --> Model "Hospital_model" initialized
INFO - 2022-03-23 01:10:40 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 01:10:40 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-23 01:10:40 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 01:10:40 --> Final output sent to browser
DEBUG - 2022-03-23 01:10:40 --> Total execution time: 0.0800
ERROR - 2022-03-23 01:10:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 01:10:58 --> Config Class Initialized
INFO - 2022-03-23 01:10:58 --> Hooks Class Initialized
DEBUG - 2022-03-23 01:10:58 --> UTF-8 Support Enabled
INFO - 2022-03-23 01:10:58 --> Utf8 Class Initialized
INFO - 2022-03-23 01:10:58 --> URI Class Initialized
INFO - 2022-03-23 01:10:58 --> Router Class Initialized
INFO - 2022-03-23 01:10:58 --> Output Class Initialized
INFO - 2022-03-23 01:10:58 --> Security Class Initialized
DEBUG - 2022-03-23 01:10:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 01:10:58 --> Input Class Initialized
INFO - 2022-03-23 01:10:58 --> Language Class Initialized
INFO - 2022-03-23 01:10:58 --> Loader Class Initialized
INFO - 2022-03-23 01:10:58 --> Helper loaded: url_helper
INFO - 2022-03-23 01:10:58 --> Helper loaded: form_helper
INFO - 2022-03-23 01:10:58 --> Helper loaded: common_helper
INFO - 2022-03-23 01:10:58 --> Database Driver Class Initialized
DEBUG - 2022-03-23 01:10:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 01:10:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 01:10:58 --> Controller Class Initialized
INFO - 2022-03-23 01:10:58 --> Form Validation Class Initialized
DEBUG - 2022-03-23 01:10:58 --> Encrypt Class Initialized
INFO - 2022-03-23 01:10:58 --> Model "Patient_model" initialized
INFO - 2022-03-23 01:10:58 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 01:10:58 --> Model "Referredby_model" initialized
INFO - 2022-03-23 01:10:58 --> Model "Prefix_master" initialized
INFO - 2022-03-23 01:10:58 --> Model "Hospital_model" initialized
INFO - 2022-03-23 01:10:58 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 01:10:58 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-23 01:10:58 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 01:10:58 --> Final output sent to browser
DEBUG - 2022-03-23 01:10:58 --> Total execution time: 0.0275
ERROR - 2022-03-23 01:11:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 01:11:22 --> Config Class Initialized
INFO - 2022-03-23 01:11:22 --> Hooks Class Initialized
DEBUG - 2022-03-23 01:11:22 --> UTF-8 Support Enabled
INFO - 2022-03-23 01:11:22 --> Utf8 Class Initialized
INFO - 2022-03-23 01:11:22 --> URI Class Initialized
INFO - 2022-03-23 01:11:22 --> Router Class Initialized
INFO - 2022-03-23 01:11:22 --> Output Class Initialized
INFO - 2022-03-23 01:11:22 --> Security Class Initialized
DEBUG - 2022-03-23 01:11:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 01:11:22 --> Input Class Initialized
INFO - 2022-03-23 01:11:22 --> Language Class Initialized
INFO - 2022-03-23 01:11:22 --> Loader Class Initialized
INFO - 2022-03-23 01:11:22 --> Helper loaded: url_helper
INFO - 2022-03-23 01:11:22 --> Helper loaded: form_helper
INFO - 2022-03-23 01:11:22 --> Helper loaded: common_helper
INFO - 2022-03-23 01:11:22 --> Database Driver Class Initialized
DEBUG - 2022-03-23 01:11:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 01:11:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 01:11:22 --> Controller Class Initialized
INFO - 2022-03-23 01:11:22 --> Form Validation Class Initialized
DEBUG - 2022-03-23 01:11:22 --> Encrypt Class Initialized
INFO - 2022-03-23 01:11:22 --> Model "Patient_model" initialized
INFO - 2022-03-23 01:11:22 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 01:11:22 --> Model "Referredby_model" initialized
INFO - 2022-03-23 01:11:22 --> Model "Prefix_master" initialized
INFO - 2022-03-23 01:11:22 --> Model "Hospital_model" initialized
INFO - 2022-03-23 01:11:23 --> File loaded: /home3/karoteam/public_html/application/views/header.php
ERROR - 2022-03-23 01:11:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 01:11:23 --> Config Class Initialized
INFO - 2022-03-23 01:11:23 --> Hooks Class Initialized
DEBUG - 2022-03-23 01:11:23 --> UTF-8 Support Enabled
INFO - 2022-03-23 01:11:23 --> Utf8 Class Initialized
INFO - 2022-03-23 01:11:23 --> URI Class Initialized
INFO - 2022-03-23 01:11:23 --> Router Class Initialized
INFO - 2022-03-23 01:11:23 --> Output Class Initialized
INFO - 2022-03-23 01:11:23 --> Security Class Initialized
DEBUG - 2022-03-23 01:11:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 01:11:23 --> Input Class Initialized
INFO - 2022-03-23 01:11:23 --> Language Class Initialized
INFO - 2022-03-23 01:11:23 --> Loader Class Initialized
INFO - 2022-03-23 01:11:23 --> Helper loaded: url_helper
INFO - 2022-03-23 01:11:23 --> Helper loaded: form_helper
INFO - 2022-03-23 01:11:23 --> Helper loaded: common_helper
INFO - 2022-03-23 01:11:23 --> Database Driver Class Initialized
DEBUG - 2022-03-23 01:11:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 01:11:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 01:11:23 --> Controller Class Initialized
INFO - 2022-03-23 01:11:23 --> Form Validation Class Initialized
DEBUG - 2022-03-23 01:11:23 --> Encrypt Class Initialized
INFO - 2022-03-23 01:11:23 --> Model "Patient_model" initialized
INFO - 2022-03-23 01:11:23 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 01:11:23 --> Model "Referredby_model" initialized
INFO - 2022-03-23 01:11:23 --> Model "Prefix_master" initialized
INFO - 2022-03-23 01:11:23 --> Model "Hospital_model" initialized
INFO - 2022-03-23 01:11:23 --> Upload Class Initialized
INFO - 2022-03-23 01:11:23 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2022-03-23 01:11:23 --> The filetype you are attempting to upload is not allowed.
INFO - 2022-03-23 01:11:23 --> Final output sent to browser
DEBUG - 2022-03-23 01:11:23 --> Total execution time: 0.0165
INFO - 2022-03-23 01:11:28 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-23 01:11:28 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
ERROR - 2022-03-23 01:11:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 01:11:30 --> Config Class Initialized
INFO - 2022-03-23 01:11:30 --> Hooks Class Initialized
DEBUG - 2022-03-23 01:11:30 --> UTF-8 Support Enabled
INFO - 2022-03-23 01:11:30 --> Utf8 Class Initialized
INFO - 2022-03-23 01:11:30 --> URI Class Initialized
INFO - 2022-03-23 01:11:30 --> Router Class Initialized
INFO - 2022-03-23 01:11:30 --> Output Class Initialized
INFO - 2022-03-23 01:11:30 --> Security Class Initialized
DEBUG - 2022-03-23 01:11:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 01:11:30 --> Input Class Initialized
INFO - 2022-03-23 01:11:30 --> Language Class Initialized
INFO - 2022-03-23 01:11:30 --> Loader Class Initialized
INFO - 2022-03-23 01:11:30 --> Helper loaded: url_helper
INFO - 2022-03-23 01:11:30 --> Helper loaded: form_helper
INFO - 2022-03-23 01:11:30 --> Helper loaded: common_helper
INFO - 2022-03-23 01:11:30 --> Database Driver Class Initialized
DEBUG - 2022-03-23 01:11:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 01:11:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 01:11:30 --> Controller Class Initialized
INFO - 2022-03-23 01:11:30 --> Form Validation Class Initialized
DEBUG - 2022-03-23 01:11:30 --> Encrypt Class Initialized
INFO - 2022-03-23 01:11:30 --> Model "Patient_model" initialized
INFO - 2022-03-23 01:11:30 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 01:11:30 --> Model "Referredby_model" initialized
INFO - 2022-03-23 01:11:30 --> Model "Prefix_master" initialized
INFO - 2022-03-23 01:11:30 --> Model "Hospital_model" initialized
INFO - 2022-03-23 01:11:30 --> Upload Class Initialized
INFO - 2022-03-23 01:11:30 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2022-03-23 01:11:30 --> The filetype you are attempting to upload is not allowed.
INFO - 2022-03-23 01:11:30 --> Final output sent to browser
DEBUG - 2022-03-23 01:11:30 --> Total execution time: 0.0105
INFO - 2022-03-23 01:11:30 --> Final output sent to browser
DEBUG - 2022-03-23 01:11:30 --> Total execution time: 5.6292
ERROR - 2022-03-23 01:11:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 01:11:53 --> Config Class Initialized
INFO - 2022-03-23 01:11:53 --> Hooks Class Initialized
DEBUG - 2022-03-23 01:11:53 --> UTF-8 Support Enabled
INFO - 2022-03-23 01:11:53 --> Utf8 Class Initialized
INFO - 2022-03-23 01:11:53 --> URI Class Initialized
INFO - 2022-03-23 01:11:53 --> Router Class Initialized
INFO - 2022-03-23 01:11:53 --> Output Class Initialized
INFO - 2022-03-23 01:11:53 --> Security Class Initialized
DEBUG - 2022-03-23 01:11:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 01:11:53 --> Input Class Initialized
INFO - 2022-03-23 01:11:53 --> Language Class Initialized
INFO - 2022-03-23 01:11:53 --> Loader Class Initialized
INFO - 2022-03-23 01:11:53 --> Helper loaded: url_helper
INFO - 2022-03-23 01:11:53 --> Helper loaded: form_helper
INFO - 2022-03-23 01:11:53 --> Helper loaded: common_helper
INFO - 2022-03-23 01:11:53 --> Database Driver Class Initialized
DEBUG - 2022-03-23 01:11:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 01:11:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 01:11:53 --> Controller Class Initialized
INFO - 2022-03-23 01:11:53 --> Form Validation Class Initialized
DEBUG - 2022-03-23 01:11:53 --> Encrypt Class Initialized
DEBUG - 2022-03-23 01:11:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 01:11:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-23 01:11:53 --> Email Class Initialized
INFO - 2022-03-23 01:11:53 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-23 01:11:53 --> Calendar Class Initialized
INFO - 2022-03-23 01:11:53 --> Model "Login_model" initialized
ERROR - 2022-03-23 01:11:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 01:11:54 --> Config Class Initialized
INFO - 2022-03-23 01:11:54 --> Hooks Class Initialized
DEBUG - 2022-03-23 01:11:54 --> UTF-8 Support Enabled
INFO - 2022-03-23 01:11:54 --> Utf8 Class Initialized
INFO - 2022-03-23 01:11:54 --> URI Class Initialized
INFO - 2022-03-23 01:11:54 --> Router Class Initialized
INFO - 2022-03-23 01:11:54 --> Output Class Initialized
INFO - 2022-03-23 01:11:54 --> Security Class Initialized
DEBUG - 2022-03-23 01:11:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 01:11:54 --> Input Class Initialized
INFO - 2022-03-23 01:11:54 --> Language Class Initialized
INFO - 2022-03-23 01:11:54 --> Loader Class Initialized
INFO - 2022-03-23 01:11:54 --> Helper loaded: url_helper
INFO - 2022-03-23 01:11:54 --> Helper loaded: form_helper
INFO - 2022-03-23 01:11:54 --> Helper loaded: common_helper
INFO - 2022-03-23 01:11:54 --> Database Driver Class Initialized
DEBUG - 2022-03-23 01:11:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 01:11:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 01:11:54 --> Controller Class Initialized
INFO - 2022-03-23 01:11:54 --> Form Validation Class Initialized
DEBUG - 2022-03-23 01:11:54 --> Encrypt Class Initialized
INFO - 2022-03-23 01:11:54 --> Model "Diseases_model" initialized
INFO - 2022-03-23 01:11:54 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 01:11:54 --> File loaded: /home3/karoteam/public_html/application/views/diseases/index.php
INFO - 2022-03-23 01:11:54 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 01:11:54 --> Final output sent to browser
DEBUG - 2022-03-23 01:11:54 --> Total execution time: 0.0097
ERROR - 2022-03-23 01:12:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 01:12:02 --> Config Class Initialized
INFO - 2022-03-23 01:12:02 --> Hooks Class Initialized
DEBUG - 2022-03-23 01:12:02 --> UTF-8 Support Enabled
INFO - 2022-03-23 01:12:02 --> Utf8 Class Initialized
INFO - 2022-03-23 01:12:02 --> URI Class Initialized
INFO - 2022-03-23 01:12:02 --> Router Class Initialized
INFO - 2022-03-23 01:12:02 --> Output Class Initialized
INFO - 2022-03-23 01:12:02 --> Security Class Initialized
DEBUG - 2022-03-23 01:12:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 01:12:02 --> Input Class Initialized
INFO - 2022-03-23 01:12:02 --> Language Class Initialized
INFO - 2022-03-23 01:12:02 --> Loader Class Initialized
INFO - 2022-03-23 01:12:02 --> Helper loaded: url_helper
INFO - 2022-03-23 01:12:02 --> Helper loaded: form_helper
INFO - 2022-03-23 01:12:02 --> Helper loaded: common_helper
INFO - 2022-03-23 01:12:02 --> Database Driver Class Initialized
DEBUG - 2022-03-23 01:12:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 01:12:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 01:12:02 --> Controller Class Initialized
INFO - 2022-03-23 01:12:02 --> Form Validation Class Initialized
DEBUG - 2022-03-23 01:12:02 --> Encrypt Class Initialized
INFO - 2022-03-23 01:12:02 --> Model "Patient_model" initialized
INFO - 2022-03-23 01:12:02 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 01:12:02 --> Model "Referredby_model" initialized
INFO - 2022-03-23 01:12:02 --> Model "Prefix_master" initialized
INFO - 2022-03-23 01:12:02 --> Model "Hospital_model" initialized
INFO - 2022-03-23 01:12:02 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 01:12:02 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-23 01:12:02 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 01:12:02 --> Final output sent to browser
DEBUG - 2022-03-23 01:12:02 --> Total execution time: 0.0595
ERROR - 2022-03-23 01:15:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 01:15:16 --> Config Class Initialized
INFO - 2022-03-23 01:15:16 --> Hooks Class Initialized
DEBUG - 2022-03-23 01:15:16 --> UTF-8 Support Enabled
INFO - 2022-03-23 01:15:16 --> Utf8 Class Initialized
INFO - 2022-03-23 01:15:16 --> URI Class Initialized
INFO - 2022-03-23 01:15:16 --> Router Class Initialized
INFO - 2022-03-23 01:15:16 --> Output Class Initialized
INFO - 2022-03-23 01:15:16 --> Security Class Initialized
DEBUG - 2022-03-23 01:15:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 01:15:16 --> Input Class Initialized
INFO - 2022-03-23 01:15:16 --> Language Class Initialized
INFO - 2022-03-23 01:15:16 --> Loader Class Initialized
INFO - 2022-03-23 01:15:16 --> Helper loaded: url_helper
INFO - 2022-03-23 01:15:16 --> Helper loaded: form_helper
INFO - 2022-03-23 01:15:16 --> Helper loaded: common_helper
INFO - 2022-03-23 01:15:16 --> Database Driver Class Initialized
DEBUG - 2022-03-23 01:15:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 01:15:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 01:15:16 --> Controller Class Initialized
INFO - 2022-03-23 01:15:16 --> Form Validation Class Initialized
DEBUG - 2022-03-23 01:15:16 --> Encrypt Class Initialized
INFO - 2022-03-23 01:15:16 --> Model "Patient_model" initialized
INFO - 2022-03-23 01:15:16 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 01:15:16 --> Model "Referredby_model" initialized
INFO - 2022-03-23 01:15:16 --> Model "Prefix_master" initialized
INFO - 2022-03-23 01:15:16 --> Model "Hospital_model" initialized
ERROR - 2022-03-23 01:15:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 01:15:16 --> Config Class Initialized
INFO - 2022-03-23 01:15:16 --> Hooks Class Initialized
DEBUG - 2022-03-23 01:15:16 --> UTF-8 Support Enabled
INFO - 2022-03-23 01:15:16 --> Utf8 Class Initialized
INFO - 2022-03-23 01:15:16 --> URI Class Initialized
INFO - 2022-03-23 01:15:16 --> Router Class Initialized
INFO - 2022-03-23 01:15:16 --> Output Class Initialized
INFO - 2022-03-23 01:15:16 --> Security Class Initialized
DEBUG - 2022-03-23 01:15:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 01:15:16 --> Input Class Initialized
INFO - 2022-03-23 01:15:16 --> Language Class Initialized
INFO - 2022-03-23 01:15:16 --> Loader Class Initialized
INFO - 2022-03-23 01:15:16 --> Helper loaded: url_helper
INFO - 2022-03-23 01:15:16 --> Helper loaded: form_helper
INFO - 2022-03-23 01:15:16 --> Helper loaded: common_helper
INFO - 2022-03-23 01:15:16 --> Database Driver Class Initialized
DEBUG - 2022-03-23 01:15:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 01:15:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 01:15:16 --> Controller Class Initialized
INFO - 2022-03-23 01:15:16 --> Form Validation Class Initialized
DEBUG - 2022-03-23 01:15:16 --> Encrypt Class Initialized
INFO - 2022-03-23 01:15:16 --> Model "Patient_model" initialized
INFO - 2022-03-23 01:15:16 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 01:15:16 --> Model "Referredby_model" initialized
INFO - 2022-03-23 01:15:16 --> Model "Prefix_master" initialized
INFO - 2022-03-23 01:15:16 --> Model "Hospital_model" initialized
INFO - 2022-03-23 01:15:17 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 01:15:17 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-23 01:15:17 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 01:15:17 --> Final output sent to browser
DEBUG - 2022-03-23 01:15:17 --> Total execution time: 0.0391
ERROR - 2022-03-23 01:15:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 01:15:17 --> Config Class Initialized
INFO - 2022-03-23 01:15:17 --> Hooks Class Initialized
DEBUG - 2022-03-23 01:15:17 --> UTF-8 Support Enabled
INFO - 2022-03-23 01:15:17 --> Utf8 Class Initialized
INFO - 2022-03-23 01:15:17 --> URI Class Initialized
INFO - 2022-03-23 01:15:17 --> Router Class Initialized
INFO - 2022-03-23 01:15:17 --> Output Class Initialized
INFO - 2022-03-23 01:15:17 --> Security Class Initialized
DEBUG - 2022-03-23 01:15:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 01:15:17 --> Input Class Initialized
INFO - 2022-03-23 01:15:17 --> Language Class Initialized
INFO - 2022-03-23 01:15:17 --> Loader Class Initialized
INFO - 2022-03-23 01:15:17 --> Helper loaded: url_helper
INFO - 2022-03-23 01:15:17 --> Helper loaded: form_helper
INFO - 2022-03-23 01:15:17 --> Helper loaded: common_helper
INFO - 2022-03-23 01:15:17 --> Database Driver Class Initialized
DEBUG - 2022-03-23 01:15:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 01:15:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 01:15:17 --> Controller Class Initialized
INFO - 2022-03-23 01:15:17 --> Form Validation Class Initialized
DEBUG - 2022-03-23 01:15:17 --> Encrypt Class Initialized
INFO - 2022-03-23 01:15:17 --> Model "Patient_model" initialized
INFO - 2022-03-23 01:15:17 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 01:15:17 --> Model "Prefix_master" initialized
INFO - 2022-03-23 01:15:17 --> Model "Users_model" initialized
INFO - 2022-03-23 01:15:17 --> Model "Hospital_model" initialized
INFO - 2022-03-23 01:15:17 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 01:15:17 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-23 01:15:17 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 01:15:17 --> Final output sent to browser
DEBUG - 2022-03-23 01:15:17 --> Total execution time: 0.0616
ERROR - 2022-03-23 01:16:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 01:16:17 --> Config Class Initialized
INFO - 2022-03-23 01:16:17 --> Hooks Class Initialized
DEBUG - 2022-03-23 01:16:17 --> UTF-8 Support Enabled
INFO - 2022-03-23 01:16:17 --> Utf8 Class Initialized
INFO - 2022-03-23 01:16:17 --> URI Class Initialized
INFO - 2022-03-23 01:16:17 --> Router Class Initialized
INFO - 2022-03-23 01:16:17 --> Output Class Initialized
INFO - 2022-03-23 01:16:17 --> Security Class Initialized
DEBUG - 2022-03-23 01:16:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 01:16:17 --> Input Class Initialized
INFO - 2022-03-23 01:16:17 --> Language Class Initialized
INFO - 2022-03-23 01:16:17 --> Loader Class Initialized
INFO - 2022-03-23 01:16:17 --> Helper loaded: url_helper
INFO - 2022-03-23 01:16:17 --> Helper loaded: form_helper
INFO - 2022-03-23 01:16:17 --> Helper loaded: common_helper
INFO - 2022-03-23 01:16:17 --> Database Driver Class Initialized
DEBUG - 2022-03-23 01:16:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 01:16:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 01:16:17 --> Controller Class Initialized
INFO - 2022-03-23 01:16:17 --> Form Validation Class Initialized
DEBUG - 2022-03-23 01:16:17 --> Encrypt Class Initialized
INFO - 2022-03-23 01:16:17 --> Model "Patient_model" initialized
INFO - 2022-03-23 01:16:17 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 01:16:17 --> Model "Referredby_model" initialized
INFO - 2022-03-23 01:16:17 --> Model "Prefix_master" initialized
INFO - 2022-03-23 01:16:17 --> Model "Hospital_model" initialized
INFO - 2022-03-23 01:16:17 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 01:16:17 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-23 01:16:17 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 01:16:17 --> Final output sent to browser
DEBUG - 2022-03-23 01:16:17 --> Total execution time: 0.1721
ERROR - 2022-03-23 01:16:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 01:16:30 --> Config Class Initialized
INFO - 2022-03-23 01:16:30 --> Hooks Class Initialized
DEBUG - 2022-03-23 01:16:30 --> UTF-8 Support Enabled
INFO - 2022-03-23 01:16:30 --> Utf8 Class Initialized
INFO - 2022-03-23 01:16:30 --> URI Class Initialized
INFO - 2022-03-23 01:16:30 --> Router Class Initialized
INFO - 2022-03-23 01:16:30 --> Output Class Initialized
INFO - 2022-03-23 01:16:30 --> Security Class Initialized
DEBUG - 2022-03-23 01:16:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 01:16:30 --> Input Class Initialized
INFO - 2022-03-23 01:16:30 --> Language Class Initialized
INFO - 2022-03-23 01:16:30 --> Loader Class Initialized
INFO - 2022-03-23 01:16:30 --> Helper loaded: url_helper
INFO - 2022-03-23 01:16:30 --> Helper loaded: form_helper
INFO - 2022-03-23 01:16:30 --> Helper loaded: common_helper
INFO - 2022-03-23 01:16:30 --> Database Driver Class Initialized
DEBUG - 2022-03-23 01:16:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 01:16:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 01:16:30 --> Controller Class Initialized
INFO - 2022-03-23 01:16:30 --> Form Validation Class Initialized
DEBUG - 2022-03-23 01:16:30 --> Encrypt Class Initialized
INFO - 2022-03-23 01:16:30 --> Model "Patient_model" initialized
INFO - 2022-03-23 01:16:30 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 01:16:30 --> Model "Referredby_model" initialized
INFO - 2022-03-23 01:16:30 --> Model "Prefix_master" initialized
INFO - 2022-03-23 01:16:30 --> Model "Hospital_model" initialized
ERROR - 2022-03-23 01:16:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 01:16:31 --> Config Class Initialized
INFO - 2022-03-23 01:16:31 --> Hooks Class Initialized
DEBUG - 2022-03-23 01:16:31 --> UTF-8 Support Enabled
INFO - 2022-03-23 01:16:31 --> Utf8 Class Initialized
INFO - 2022-03-23 01:16:31 --> URI Class Initialized
INFO - 2022-03-23 01:16:31 --> Router Class Initialized
INFO - 2022-03-23 01:16:31 --> Output Class Initialized
INFO - 2022-03-23 01:16:31 --> Security Class Initialized
DEBUG - 2022-03-23 01:16:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 01:16:31 --> Input Class Initialized
INFO - 2022-03-23 01:16:31 --> Language Class Initialized
INFO - 2022-03-23 01:16:31 --> Loader Class Initialized
INFO - 2022-03-23 01:16:31 --> Helper loaded: url_helper
INFO - 2022-03-23 01:16:31 --> Helper loaded: form_helper
INFO - 2022-03-23 01:16:31 --> Helper loaded: common_helper
INFO - 2022-03-23 01:16:31 --> Database Driver Class Initialized
DEBUG - 2022-03-23 01:16:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 01:16:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 01:16:31 --> Controller Class Initialized
INFO - 2022-03-23 01:16:31 --> Form Validation Class Initialized
DEBUG - 2022-03-23 01:16:31 --> Encrypt Class Initialized
INFO - 2022-03-23 01:16:31 --> Model "Patient_model" initialized
INFO - 2022-03-23 01:16:31 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 01:16:31 --> Model "Referredby_model" initialized
INFO - 2022-03-23 01:16:31 --> Model "Prefix_master" initialized
INFO - 2022-03-23 01:16:31 --> Model "Hospital_model" initialized
INFO - 2022-03-23 01:16:31 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 01:16:31 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-23 01:16:31 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 01:16:31 --> Final output sent to browser
DEBUG - 2022-03-23 01:16:31 --> Total execution time: 0.0329
ERROR - 2022-03-23 01:16:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 01:16:31 --> Config Class Initialized
INFO - 2022-03-23 01:16:31 --> Hooks Class Initialized
DEBUG - 2022-03-23 01:16:31 --> UTF-8 Support Enabled
INFO - 2022-03-23 01:16:31 --> Utf8 Class Initialized
INFO - 2022-03-23 01:16:31 --> URI Class Initialized
INFO - 2022-03-23 01:16:31 --> Router Class Initialized
INFO - 2022-03-23 01:16:31 --> Output Class Initialized
INFO - 2022-03-23 01:16:31 --> Security Class Initialized
DEBUG - 2022-03-23 01:16:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 01:16:31 --> Input Class Initialized
INFO - 2022-03-23 01:16:31 --> Language Class Initialized
INFO - 2022-03-23 01:16:31 --> Loader Class Initialized
INFO - 2022-03-23 01:16:31 --> Helper loaded: url_helper
INFO - 2022-03-23 01:16:31 --> Helper loaded: form_helper
INFO - 2022-03-23 01:16:31 --> Helper loaded: common_helper
INFO - 2022-03-23 01:16:31 --> Database Driver Class Initialized
DEBUG - 2022-03-23 01:16:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 01:16:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 01:16:31 --> Controller Class Initialized
INFO - 2022-03-23 01:16:31 --> Form Validation Class Initialized
DEBUG - 2022-03-23 01:16:31 --> Encrypt Class Initialized
INFO - 2022-03-23 01:16:31 --> Model "Patient_model" initialized
INFO - 2022-03-23 01:16:31 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 01:16:31 --> Model "Prefix_master" initialized
INFO - 2022-03-23 01:16:31 --> Model "Users_model" initialized
INFO - 2022-03-23 01:16:31 --> Model "Hospital_model" initialized
INFO - 2022-03-23 01:16:31 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 01:16:31 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-23 01:16:31 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 01:16:31 --> Final output sent to browser
DEBUG - 2022-03-23 01:16:31 --> Total execution time: 0.2762
ERROR - 2022-03-23 01:16:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 01:16:50 --> Config Class Initialized
INFO - 2022-03-23 01:16:50 --> Hooks Class Initialized
DEBUG - 2022-03-23 01:16:50 --> UTF-8 Support Enabled
INFO - 2022-03-23 01:16:50 --> Utf8 Class Initialized
INFO - 2022-03-23 01:16:50 --> URI Class Initialized
INFO - 2022-03-23 01:16:50 --> Router Class Initialized
INFO - 2022-03-23 01:16:50 --> Output Class Initialized
INFO - 2022-03-23 01:16:50 --> Security Class Initialized
DEBUG - 2022-03-23 01:16:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 01:16:50 --> Input Class Initialized
INFO - 2022-03-23 01:16:50 --> Language Class Initialized
INFO - 2022-03-23 01:16:50 --> Loader Class Initialized
INFO - 2022-03-23 01:16:50 --> Helper loaded: url_helper
INFO - 2022-03-23 01:16:50 --> Helper loaded: form_helper
INFO - 2022-03-23 01:16:50 --> Helper loaded: common_helper
INFO - 2022-03-23 01:16:50 --> Database Driver Class Initialized
DEBUG - 2022-03-23 01:16:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 01:16:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 01:16:50 --> Controller Class Initialized
INFO - 2022-03-23 01:16:50 --> Form Validation Class Initialized
DEBUG - 2022-03-23 01:16:50 --> Encrypt Class Initialized
INFO - 2022-03-23 01:16:50 --> Model "Patient_model" initialized
INFO - 2022-03-23 01:16:50 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 01:16:50 --> Model "Prefix_master" initialized
INFO - 2022-03-23 01:16:50 --> Model "Users_model" initialized
INFO - 2022-03-23 01:16:50 --> Model "Hospital_model" initialized
ERROR - 2022-03-23 01:16:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 01:16:50 --> Config Class Initialized
INFO - 2022-03-23 01:16:50 --> Hooks Class Initialized
DEBUG - 2022-03-23 01:16:50 --> UTF-8 Support Enabled
INFO - 2022-03-23 01:16:50 --> Utf8 Class Initialized
INFO - 2022-03-23 01:16:50 --> URI Class Initialized
INFO - 2022-03-23 01:16:50 --> Router Class Initialized
INFO - 2022-03-23 01:16:50 --> Output Class Initialized
INFO - 2022-03-23 01:16:50 --> Security Class Initialized
DEBUG - 2022-03-23 01:16:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 01:16:50 --> Input Class Initialized
INFO - 2022-03-23 01:16:50 --> Language Class Initialized
INFO - 2022-03-23 01:16:50 --> Loader Class Initialized
INFO - 2022-03-23 01:16:50 --> Helper loaded: url_helper
INFO - 2022-03-23 01:16:50 --> Helper loaded: form_helper
INFO - 2022-03-23 01:16:50 --> Helper loaded: common_helper
INFO - 2022-03-23 01:16:50 --> Database Driver Class Initialized
DEBUG - 2022-03-23 01:16:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 01:16:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 01:16:50 --> Controller Class Initialized
INFO - 2022-03-23 01:16:50 --> Form Validation Class Initialized
DEBUG - 2022-03-23 01:16:50 --> Encrypt Class Initialized
INFO - 2022-03-23 01:16:50 --> Model "Patient_model" initialized
INFO - 2022-03-23 01:16:50 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 01:16:50 --> Model "Prefix_master" initialized
INFO - 2022-03-23 01:16:50 --> Model "Users_model" initialized
INFO - 2022-03-23 01:16:50 --> Model "Hospital_model" initialized
INFO - 2022-03-23 01:16:50 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 01:16:50 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-23 01:16:50 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 01:16:50 --> Final output sent to browser
DEBUG - 2022-03-23 01:16:50 --> Total execution time: 0.0728
ERROR - 2022-03-23 01:17:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 01:17:07 --> Config Class Initialized
INFO - 2022-03-23 01:17:07 --> Hooks Class Initialized
DEBUG - 2022-03-23 01:17:07 --> UTF-8 Support Enabled
INFO - 2022-03-23 01:17:07 --> Utf8 Class Initialized
INFO - 2022-03-23 01:17:07 --> URI Class Initialized
INFO - 2022-03-23 01:17:07 --> Router Class Initialized
INFO - 2022-03-23 01:17:07 --> Output Class Initialized
INFO - 2022-03-23 01:17:07 --> Security Class Initialized
DEBUG - 2022-03-23 01:17:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 01:17:07 --> Input Class Initialized
INFO - 2022-03-23 01:17:07 --> Language Class Initialized
INFO - 2022-03-23 01:17:07 --> Loader Class Initialized
INFO - 2022-03-23 01:17:07 --> Helper loaded: url_helper
INFO - 2022-03-23 01:17:07 --> Helper loaded: form_helper
INFO - 2022-03-23 01:17:07 --> Helper loaded: common_helper
INFO - 2022-03-23 01:17:07 --> Database Driver Class Initialized
DEBUG - 2022-03-23 01:17:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 01:17:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 01:17:07 --> Controller Class Initialized
INFO - 2022-03-23 01:17:07 --> Form Validation Class Initialized
DEBUG - 2022-03-23 01:17:07 --> Encrypt Class Initialized
INFO - 2022-03-23 01:17:07 --> Model "Patient_model" initialized
INFO - 2022-03-23 01:17:07 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 01:17:07 --> Model "Prefix_master" initialized
INFO - 2022-03-23 01:17:07 --> Model "Users_model" initialized
INFO - 2022-03-23 01:17:07 --> Model "Hospital_model" initialized
INFO - 2022-03-23 01:17:07 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-23 01:17:08 --> Final output sent to browser
DEBUG - 2022-03-23 01:17:08 --> Total execution time: 1.0344
ERROR - 2022-03-23 01:17:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 01:17:51 --> Config Class Initialized
INFO - 2022-03-23 01:17:51 --> Hooks Class Initialized
DEBUG - 2022-03-23 01:17:51 --> UTF-8 Support Enabled
INFO - 2022-03-23 01:17:51 --> Utf8 Class Initialized
INFO - 2022-03-23 01:17:51 --> URI Class Initialized
INFO - 2022-03-23 01:17:51 --> Router Class Initialized
INFO - 2022-03-23 01:17:51 --> Output Class Initialized
INFO - 2022-03-23 01:17:51 --> Security Class Initialized
DEBUG - 2022-03-23 01:17:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 01:17:51 --> Input Class Initialized
INFO - 2022-03-23 01:17:51 --> Language Class Initialized
INFO - 2022-03-23 01:17:51 --> Loader Class Initialized
INFO - 2022-03-23 01:17:51 --> Helper loaded: url_helper
INFO - 2022-03-23 01:17:51 --> Helper loaded: form_helper
INFO - 2022-03-23 01:17:51 --> Helper loaded: common_helper
INFO - 2022-03-23 01:17:51 --> Database Driver Class Initialized
DEBUG - 2022-03-23 01:17:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 01:17:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 01:17:51 --> Controller Class Initialized
INFO - 2022-03-23 01:17:51 --> Form Validation Class Initialized
DEBUG - 2022-03-23 01:17:51 --> Encrypt Class Initialized
INFO - 2022-03-23 01:17:51 --> Model "Patient_model" initialized
INFO - 2022-03-23 01:17:51 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 01:17:51 --> Model "Prefix_master" initialized
INFO - 2022-03-23 01:17:51 --> Model "Users_model" initialized
INFO - 2022-03-23 01:17:51 --> Model "Hospital_model" initialized
INFO - 2022-03-23 01:17:51 --> Upload Class Initialized
INFO - 2022-03-23 01:17:51 --> Final output sent to browser
DEBUG - 2022-03-23 01:17:51 --> Total execution time: 0.0274
ERROR - 2022-03-23 01:17:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 01:17:53 --> Config Class Initialized
INFO - 2022-03-23 01:17:53 --> Hooks Class Initialized
DEBUG - 2022-03-23 01:17:53 --> UTF-8 Support Enabled
INFO - 2022-03-23 01:17:53 --> Utf8 Class Initialized
INFO - 2022-03-23 01:17:53 --> URI Class Initialized
INFO - 2022-03-23 01:17:53 --> Router Class Initialized
INFO - 2022-03-23 01:17:53 --> Output Class Initialized
INFO - 2022-03-23 01:17:53 --> Security Class Initialized
DEBUG - 2022-03-23 01:17:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 01:17:53 --> Input Class Initialized
INFO - 2022-03-23 01:17:53 --> Language Class Initialized
INFO - 2022-03-23 01:17:53 --> Loader Class Initialized
INFO - 2022-03-23 01:17:53 --> Helper loaded: url_helper
INFO - 2022-03-23 01:17:53 --> Helper loaded: form_helper
INFO - 2022-03-23 01:17:53 --> Helper loaded: common_helper
INFO - 2022-03-23 01:17:53 --> Database Driver Class Initialized
DEBUG - 2022-03-23 01:17:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 01:17:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 01:17:53 --> Controller Class Initialized
INFO - 2022-03-23 01:17:53 --> Form Validation Class Initialized
DEBUG - 2022-03-23 01:17:53 --> Encrypt Class Initialized
INFO - 2022-03-23 01:17:53 --> Model "Patient_model" initialized
INFO - 2022-03-23 01:17:53 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 01:17:53 --> Model "Prefix_master" initialized
INFO - 2022-03-23 01:17:53 --> Model "Users_model" initialized
INFO - 2022-03-23 01:17:53 --> Model "Hospital_model" initialized
ERROR - 2022-03-23 01:17:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 01:17:54 --> Config Class Initialized
INFO - 2022-03-23 01:17:54 --> Hooks Class Initialized
DEBUG - 2022-03-23 01:17:54 --> UTF-8 Support Enabled
INFO - 2022-03-23 01:17:54 --> Utf8 Class Initialized
INFO - 2022-03-23 01:17:54 --> URI Class Initialized
INFO - 2022-03-23 01:17:54 --> Router Class Initialized
INFO - 2022-03-23 01:17:54 --> Output Class Initialized
INFO - 2022-03-23 01:17:54 --> Security Class Initialized
DEBUG - 2022-03-23 01:17:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 01:17:54 --> Input Class Initialized
INFO - 2022-03-23 01:17:54 --> Language Class Initialized
INFO - 2022-03-23 01:17:54 --> Loader Class Initialized
INFO - 2022-03-23 01:17:54 --> Helper loaded: url_helper
INFO - 2022-03-23 01:17:54 --> Helper loaded: form_helper
INFO - 2022-03-23 01:17:54 --> Helper loaded: common_helper
INFO - 2022-03-23 01:17:54 --> Database Driver Class Initialized
DEBUG - 2022-03-23 01:17:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 01:17:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 01:17:54 --> Controller Class Initialized
INFO - 2022-03-23 01:17:54 --> Form Validation Class Initialized
DEBUG - 2022-03-23 01:17:54 --> Encrypt Class Initialized
INFO - 2022-03-23 01:17:54 --> Model "Patient_model" initialized
INFO - 2022-03-23 01:17:54 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 01:17:54 --> Model "Prefix_master" initialized
INFO - 2022-03-23 01:17:54 --> Model "Users_model" initialized
INFO - 2022-03-23 01:17:54 --> Model "Hospital_model" initialized
INFO - 2022-03-23 01:17:54 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 01:17:54 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-23 01:17:54 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 01:17:54 --> Final output sent to browser
DEBUG - 2022-03-23 01:17:54 --> Total execution time: 0.0400
ERROR - 2022-03-23 01:18:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 01:18:48 --> Config Class Initialized
INFO - 2022-03-23 01:18:48 --> Hooks Class Initialized
DEBUG - 2022-03-23 01:18:48 --> UTF-8 Support Enabled
INFO - 2022-03-23 01:18:48 --> Utf8 Class Initialized
INFO - 2022-03-23 01:18:48 --> URI Class Initialized
INFO - 2022-03-23 01:18:48 --> Router Class Initialized
INFO - 2022-03-23 01:18:48 --> Output Class Initialized
INFO - 2022-03-23 01:18:48 --> Security Class Initialized
DEBUG - 2022-03-23 01:18:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 01:18:48 --> Input Class Initialized
INFO - 2022-03-23 01:18:48 --> Language Class Initialized
INFO - 2022-03-23 01:18:48 --> Loader Class Initialized
INFO - 2022-03-23 01:18:48 --> Helper loaded: url_helper
INFO - 2022-03-23 01:18:48 --> Helper loaded: form_helper
INFO - 2022-03-23 01:18:48 --> Helper loaded: common_helper
INFO - 2022-03-23 01:18:48 --> Database Driver Class Initialized
DEBUG - 2022-03-23 01:18:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 01:18:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 01:18:48 --> Controller Class Initialized
INFO - 2022-03-23 01:18:48 --> Form Validation Class Initialized
DEBUG - 2022-03-23 01:18:48 --> Encrypt Class Initialized
INFO - 2022-03-23 01:18:48 --> Model "Patient_model" initialized
INFO - 2022-03-23 01:18:48 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 01:18:48 --> Model "Referredby_model" initialized
INFO - 2022-03-23 01:18:48 --> Model "Prefix_master" initialized
INFO - 2022-03-23 01:18:48 --> Model "Hospital_model" initialized
INFO - 2022-03-23 01:18:48 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 01:18:48 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-23 01:18:48 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 01:18:48 --> Final output sent to browser
DEBUG - 2022-03-23 01:18:48 --> Total execution time: 0.0267
ERROR - 2022-03-23 01:24:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 01:24:43 --> Config Class Initialized
INFO - 2022-03-23 01:24:43 --> Hooks Class Initialized
DEBUG - 2022-03-23 01:24:43 --> UTF-8 Support Enabled
INFO - 2022-03-23 01:24:43 --> Utf8 Class Initialized
INFO - 2022-03-23 01:24:43 --> URI Class Initialized
INFO - 2022-03-23 01:24:43 --> Router Class Initialized
INFO - 2022-03-23 01:24:43 --> Output Class Initialized
INFO - 2022-03-23 01:24:43 --> Security Class Initialized
DEBUG - 2022-03-23 01:24:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 01:24:43 --> Input Class Initialized
INFO - 2022-03-23 01:24:43 --> Language Class Initialized
INFO - 2022-03-23 01:24:43 --> Loader Class Initialized
INFO - 2022-03-23 01:24:43 --> Helper loaded: url_helper
INFO - 2022-03-23 01:24:43 --> Helper loaded: form_helper
INFO - 2022-03-23 01:24:43 --> Helper loaded: common_helper
INFO - 2022-03-23 01:24:43 --> Database Driver Class Initialized
DEBUG - 2022-03-23 01:24:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 01:24:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 01:24:44 --> Controller Class Initialized
INFO - 2022-03-23 01:24:44 --> Form Validation Class Initialized
DEBUG - 2022-03-23 01:24:44 --> Encrypt Class Initialized
INFO - 2022-03-23 01:24:44 --> Model "Patient_model" initialized
INFO - 2022-03-23 01:24:44 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 01:24:44 --> Model "Prefix_master" initialized
INFO - 2022-03-23 01:24:44 --> Model "Users_model" initialized
INFO - 2022-03-23 01:24:44 --> Model "Hospital_model" initialized
INFO - 2022-03-23 01:24:44 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-23 01:24:45 --> Final output sent to browser
DEBUG - 2022-03-23 01:24:45 --> Total execution time: 1.1491
ERROR - 2022-03-23 01:30:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 01:30:15 --> Config Class Initialized
INFO - 2022-03-23 01:30:15 --> Hooks Class Initialized
DEBUG - 2022-03-23 01:30:15 --> UTF-8 Support Enabled
INFO - 2022-03-23 01:30:15 --> Utf8 Class Initialized
INFO - 2022-03-23 01:30:15 --> URI Class Initialized
INFO - 2022-03-23 01:30:15 --> Router Class Initialized
INFO - 2022-03-23 01:30:15 --> Output Class Initialized
INFO - 2022-03-23 01:30:15 --> Security Class Initialized
DEBUG - 2022-03-23 01:30:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 01:30:15 --> Input Class Initialized
INFO - 2022-03-23 01:30:15 --> Language Class Initialized
INFO - 2022-03-23 01:30:15 --> Loader Class Initialized
INFO - 2022-03-23 01:30:15 --> Helper loaded: url_helper
INFO - 2022-03-23 01:30:15 --> Helper loaded: form_helper
INFO - 2022-03-23 01:30:15 --> Helper loaded: common_helper
INFO - 2022-03-23 01:30:15 --> Database Driver Class Initialized
DEBUG - 2022-03-23 01:30:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 01:30:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 01:30:15 --> Controller Class Initialized
INFO - 2022-03-23 01:30:15 --> Form Validation Class Initialized
DEBUG - 2022-03-23 01:30:15 --> Encrypt Class Initialized
INFO - 2022-03-23 01:30:15 --> Model "Patient_model" initialized
INFO - 2022-03-23 01:30:15 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 01:30:15 --> Model "Prefix_master" initialized
INFO - 2022-03-23 01:30:15 --> Model "Users_model" initialized
INFO - 2022-03-23 01:30:15 --> Model "Hospital_model" initialized
ERROR - 2022-03-23 01:30:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 01:30:15 --> Config Class Initialized
INFO - 2022-03-23 01:30:15 --> Hooks Class Initialized
DEBUG - 2022-03-23 01:30:15 --> UTF-8 Support Enabled
INFO - 2022-03-23 01:30:15 --> Utf8 Class Initialized
INFO - 2022-03-23 01:30:15 --> URI Class Initialized
INFO - 2022-03-23 01:30:15 --> Router Class Initialized
INFO - 2022-03-23 01:30:15 --> Output Class Initialized
INFO - 2022-03-23 01:30:15 --> Security Class Initialized
DEBUG - 2022-03-23 01:30:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 01:30:15 --> Input Class Initialized
INFO - 2022-03-23 01:30:15 --> Language Class Initialized
INFO - 2022-03-23 01:30:15 --> Loader Class Initialized
INFO - 2022-03-23 01:30:15 --> Helper loaded: url_helper
INFO - 2022-03-23 01:30:15 --> Helper loaded: form_helper
INFO - 2022-03-23 01:30:15 --> Helper loaded: common_helper
INFO - 2022-03-23 01:30:15 --> Database Driver Class Initialized
DEBUG - 2022-03-23 01:30:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 01:30:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 01:30:15 --> Controller Class Initialized
INFO - 2022-03-23 01:30:15 --> Form Validation Class Initialized
DEBUG - 2022-03-23 01:30:15 --> Encrypt Class Initialized
INFO - 2022-03-23 01:30:15 --> Model "Patient_model" initialized
INFO - 2022-03-23 01:30:15 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 01:30:15 --> Model "Prefix_master" initialized
INFO - 2022-03-23 01:30:15 --> Model "Users_model" initialized
INFO - 2022-03-23 01:30:15 --> Model "Hospital_model" initialized
INFO - 2022-03-23 01:30:15 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 01:30:15 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-23 01:30:15 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 01:30:15 --> Final output sent to browser
DEBUG - 2022-03-23 01:30:15 --> Total execution time: 0.0685
ERROR - 2022-03-23 01:33:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 01:33:03 --> Config Class Initialized
INFO - 2022-03-23 01:33:03 --> Hooks Class Initialized
DEBUG - 2022-03-23 01:33:03 --> UTF-8 Support Enabled
INFO - 2022-03-23 01:33:03 --> Utf8 Class Initialized
INFO - 2022-03-23 01:33:03 --> URI Class Initialized
INFO - 2022-03-23 01:33:03 --> Router Class Initialized
INFO - 2022-03-23 01:33:03 --> Output Class Initialized
INFO - 2022-03-23 01:33:03 --> Security Class Initialized
DEBUG - 2022-03-23 01:33:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 01:33:03 --> Input Class Initialized
INFO - 2022-03-23 01:33:03 --> Language Class Initialized
INFO - 2022-03-23 01:33:03 --> Loader Class Initialized
INFO - 2022-03-23 01:33:03 --> Helper loaded: url_helper
INFO - 2022-03-23 01:33:03 --> Helper loaded: form_helper
INFO - 2022-03-23 01:33:03 --> Helper loaded: common_helper
INFO - 2022-03-23 01:33:03 --> Database Driver Class Initialized
DEBUG - 2022-03-23 01:33:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 01:33:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 01:33:03 --> Controller Class Initialized
INFO - 2022-03-23 01:33:03 --> Form Validation Class Initialized
DEBUG - 2022-03-23 01:33:03 --> Encrypt Class Initialized
INFO - 2022-03-23 01:33:03 --> Model "Patient_model" initialized
INFO - 2022-03-23 01:33:03 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 01:33:03 --> Model "Prefix_master" initialized
INFO - 2022-03-23 01:33:03 --> Model "Users_model" initialized
INFO - 2022-03-23 01:33:03 --> Model "Hospital_model" initialized
ERROR - 2022-03-23 01:33:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 01:33:03 --> Config Class Initialized
INFO - 2022-03-23 01:33:03 --> Hooks Class Initialized
DEBUG - 2022-03-23 01:33:03 --> UTF-8 Support Enabled
INFO - 2022-03-23 01:33:03 --> Utf8 Class Initialized
INFO - 2022-03-23 01:33:03 --> URI Class Initialized
INFO - 2022-03-23 01:33:03 --> Router Class Initialized
INFO - 2022-03-23 01:33:03 --> Output Class Initialized
INFO - 2022-03-23 01:33:03 --> Security Class Initialized
DEBUG - 2022-03-23 01:33:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 01:33:03 --> Input Class Initialized
INFO - 2022-03-23 01:33:03 --> Language Class Initialized
INFO - 2022-03-23 01:33:03 --> Loader Class Initialized
INFO - 2022-03-23 01:33:03 --> Helper loaded: url_helper
INFO - 2022-03-23 01:33:03 --> Helper loaded: form_helper
INFO - 2022-03-23 01:33:03 --> Helper loaded: common_helper
INFO - 2022-03-23 01:33:03 --> Database Driver Class Initialized
DEBUG - 2022-03-23 01:33:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 01:33:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 01:33:03 --> Controller Class Initialized
INFO - 2022-03-23 01:33:03 --> Form Validation Class Initialized
DEBUG - 2022-03-23 01:33:03 --> Encrypt Class Initialized
INFO - 2022-03-23 01:33:03 --> Model "Patient_model" initialized
INFO - 2022-03-23 01:33:03 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 01:33:03 --> Model "Prefix_master" initialized
INFO - 2022-03-23 01:33:03 --> Model "Users_model" initialized
INFO - 2022-03-23 01:33:03 --> Model "Hospital_model" initialized
INFO - 2022-03-23 01:33:03 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 01:33:03 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-23 01:33:03 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 01:33:03 --> Final output sent to browser
DEBUG - 2022-03-23 01:33:03 --> Total execution time: 0.0573
ERROR - 2022-03-23 01:34:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 01:34:34 --> Config Class Initialized
INFO - 2022-03-23 01:34:34 --> Hooks Class Initialized
DEBUG - 2022-03-23 01:34:34 --> UTF-8 Support Enabled
INFO - 2022-03-23 01:34:34 --> Utf8 Class Initialized
INFO - 2022-03-23 01:34:34 --> URI Class Initialized
INFO - 2022-03-23 01:34:34 --> Router Class Initialized
INFO - 2022-03-23 01:34:34 --> Output Class Initialized
INFO - 2022-03-23 01:34:34 --> Security Class Initialized
DEBUG - 2022-03-23 01:34:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 01:34:34 --> Input Class Initialized
INFO - 2022-03-23 01:34:34 --> Language Class Initialized
INFO - 2022-03-23 01:34:34 --> Loader Class Initialized
INFO - 2022-03-23 01:34:34 --> Helper loaded: url_helper
INFO - 2022-03-23 01:34:34 --> Helper loaded: form_helper
INFO - 2022-03-23 01:34:34 --> Helper loaded: common_helper
INFO - 2022-03-23 01:34:34 --> Database Driver Class Initialized
DEBUG - 2022-03-23 01:34:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 01:34:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 01:34:34 --> Controller Class Initialized
INFO - 2022-03-23 01:34:34 --> Form Validation Class Initialized
DEBUG - 2022-03-23 01:34:34 --> Encrypt Class Initialized
INFO - 2022-03-23 01:34:34 --> Model "Patient_model" initialized
INFO - 2022-03-23 01:34:34 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 01:34:34 --> Model "Prefix_master" initialized
INFO - 2022-03-23 01:34:34 --> Model "Users_model" initialized
INFO - 2022-03-23 01:34:34 --> Model "Hospital_model" initialized
ERROR - 2022-03-23 01:34:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 01:34:34 --> Config Class Initialized
INFO - 2022-03-23 01:34:34 --> Hooks Class Initialized
DEBUG - 2022-03-23 01:34:34 --> UTF-8 Support Enabled
INFO - 2022-03-23 01:34:34 --> Utf8 Class Initialized
INFO - 2022-03-23 01:34:34 --> URI Class Initialized
INFO - 2022-03-23 01:34:34 --> Router Class Initialized
INFO - 2022-03-23 01:34:34 --> Output Class Initialized
INFO - 2022-03-23 01:34:34 --> Security Class Initialized
DEBUG - 2022-03-23 01:34:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 01:34:34 --> Input Class Initialized
INFO - 2022-03-23 01:34:34 --> Language Class Initialized
INFO - 2022-03-23 01:34:34 --> Loader Class Initialized
INFO - 2022-03-23 01:34:34 --> Helper loaded: url_helper
INFO - 2022-03-23 01:34:34 --> Helper loaded: form_helper
INFO - 2022-03-23 01:34:34 --> Helper loaded: common_helper
INFO - 2022-03-23 01:34:34 --> Database Driver Class Initialized
DEBUG - 2022-03-23 01:34:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 01:34:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 01:34:34 --> Controller Class Initialized
INFO - 2022-03-23 01:34:34 --> Form Validation Class Initialized
DEBUG - 2022-03-23 01:34:34 --> Encrypt Class Initialized
INFO - 2022-03-23 01:34:34 --> Model "Patient_model" initialized
INFO - 2022-03-23 01:34:34 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 01:34:34 --> Model "Prefix_master" initialized
INFO - 2022-03-23 01:34:34 --> Model "Users_model" initialized
INFO - 2022-03-23 01:34:34 --> Model "Hospital_model" initialized
INFO - 2022-03-23 01:34:34 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 01:34:34 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-23 01:34:34 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 01:34:34 --> Final output sent to browser
DEBUG - 2022-03-23 01:34:34 --> Total execution time: 0.0456
ERROR - 2022-03-23 01:49:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 01:49:02 --> Config Class Initialized
INFO - 2022-03-23 01:49:02 --> Hooks Class Initialized
DEBUG - 2022-03-23 01:49:02 --> UTF-8 Support Enabled
INFO - 2022-03-23 01:49:02 --> Utf8 Class Initialized
INFO - 2022-03-23 01:49:02 --> URI Class Initialized
INFO - 2022-03-23 01:49:02 --> Router Class Initialized
INFO - 2022-03-23 01:49:02 --> Output Class Initialized
INFO - 2022-03-23 01:49:02 --> Security Class Initialized
DEBUG - 2022-03-23 01:49:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 01:49:02 --> Input Class Initialized
INFO - 2022-03-23 01:49:02 --> Language Class Initialized
INFO - 2022-03-23 01:49:02 --> Loader Class Initialized
INFO - 2022-03-23 01:49:02 --> Helper loaded: url_helper
INFO - 2022-03-23 01:49:02 --> Helper loaded: form_helper
INFO - 2022-03-23 01:49:02 --> Helper loaded: common_helper
INFO - 2022-03-23 01:49:02 --> Database Driver Class Initialized
DEBUG - 2022-03-23 01:49:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 01:49:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 01:49:02 --> Controller Class Initialized
INFO - 2022-03-23 01:49:02 --> Form Validation Class Initialized
DEBUG - 2022-03-23 01:49:02 --> Encrypt Class Initialized
INFO - 2022-03-23 01:49:02 --> Model "Patient_model" initialized
INFO - 2022-03-23 01:49:02 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 01:49:02 --> Model "Referredby_model" initialized
INFO - 2022-03-23 01:49:02 --> Model "Prefix_master" initialized
INFO - 2022-03-23 01:49:02 --> Model "Hospital_model" initialized
INFO - 2022-03-23 01:49:02 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 01:49:02 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-23 01:49:02 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 01:49:02 --> Final output sent to browser
DEBUG - 2022-03-23 01:49:02 --> Total execution time: 0.1159
ERROR - 2022-03-23 01:49:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 01:49:16 --> Config Class Initialized
INFO - 2022-03-23 01:49:16 --> Hooks Class Initialized
DEBUG - 2022-03-23 01:49:16 --> UTF-8 Support Enabled
INFO - 2022-03-23 01:49:16 --> Utf8 Class Initialized
INFO - 2022-03-23 01:49:16 --> URI Class Initialized
INFO - 2022-03-23 01:49:16 --> Router Class Initialized
INFO - 2022-03-23 01:49:16 --> Output Class Initialized
INFO - 2022-03-23 01:49:16 --> Security Class Initialized
DEBUG - 2022-03-23 01:49:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 01:49:16 --> Input Class Initialized
INFO - 2022-03-23 01:49:16 --> Language Class Initialized
INFO - 2022-03-23 01:49:16 --> Loader Class Initialized
INFO - 2022-03-23 01:49:16 --> Helper loaded: url_helper
INFO - 2022-03-23 01:49:16 --> Helper loaded: form_helper
INFO - 2022-03-23 01:49:16 --> Helper loaded: common_helper
INFO - 2022-03-23 01:49:16 --> Database Driver Class Initialized
DEBUG - 2022-03-23 01:49:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 01:49:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 01:49:16 --> Controller Class Initialized
INFO - 2022-03-23 01:49:16 --> Form Validation Class Initialized
DEBUG - 2022-03-23 01:49:16 --> Encrypt Class Initialized
INFO - 2022-03-23 01:49:16 --> Model "Patient_model" initialized
INFO - 2022-03-23 01:49:16 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 01:49:16 --> Model "Prefix_master" initialized
INFO - 2022-03-23 01:49:16 --> Model "Users_model" initialized
INFO - 2022-03-23 01:49:16 --> Model "Hospital_model" initialized
INFO - 2022-03-23 01:49:16 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 01:49:16 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-23 01:49:16 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 01:49:16 --> Final output sent to browser
DEBUG - 2022-03-23 01:49:16 --> Total execution time: 0.0434
ERROR - 2022-03-23 01:49:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 01:49:33 --> Config Class Initialized
INFO - 2022-03-23 01:49:33 --> Hooks Class Initialized
DEBUG - 2022-03-23 01:49:33 --> UTF-8 Support Enabled
INFO - 2022-03-23 01:49:33 --> Utf8 Class Initialized
INFO - 2022-03-23 01:49:33 --> URI Class Initialized
INFO - 2022-03-23 01:49:33 --> Router Class Initialized
INFO - 2022-03-23 01:49:33 --> Output Class Initialized
INFO - 2022-03-23 01:49:33 --> Security Class Initialized
DEBUG - 2022-03-23 01:49:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 01:49:33 --> Input Class Initialized
INFO - 2022-03-23 01:49:33 --> Language Class Initialized
INFO - 2022-03-23 01:49:33 --> Loader Class Initialized
INFO - 2022-03-23 01:49:33 --> Helper loaded: url_helper
INFO - 2022-03-23 01:49:33 --> Helper loaded: form_helper
INFO - 2022-03-23 01:49:33 --> Helper loaded: common_helper
INFO - 2022-03-23 01:49:33 --> Database Driver Class Initialized
DEBUG - 2022-03-23 01:49:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 01:49:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 01:49:33 --> Controller Class Initialized
INFO - 2022-03-23 01:49:33 --> Form Validation Class Initialized
DEBUG - 2022-03-23 01:49:33 --> Encrypt Class Initialized
INFO - 2022-03-23 01:49:33 --> Model "Patient_model" initialized
INFO - 2022-03-23 01:49:33 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 01:49:33 --> Model "Referredby_model" initialized
INFO - 2022-03-23 01:49:33 --> Model "Prefix_master" initialized
INFO - 2022-03-23 01:49:33 --> Model "Hospital_model" initialized
INFO - 2022-03-23 01:49:33 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 01:49:33 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-23 01:49:33 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 01:49:33 --> Final output sent to browser
DEBUG - 2022-03-23 01:49:33 --> Total execution time: 0.0450
ERROR - 2022-03-23 01:49:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 01:49:53 --> Config Class Initialized
INFO - 2022-03-23 01:49:53 --> Hooks Class Initialized
DEBUG - 2022-03-23 01:49:53 --> UTF-8 Support Enabled
INFO - 2022-03-23 01:49:53 --> Utf8 Class Initialized
INFO - 2022-03-23 01:49:53 --> URI Class Initialized
INFO - 2022-03-23 01:49:53 --> Router Class Initialized
INFO - 2022-03-23 01:49:53 --> Output Class Initialized
INFO - 2022-03-23 01:49:53 --> Security Class Initialized
DEBUG - 2022-03-23 01:49:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 01:49:53 --> Input Class Initialized
INFO - 2022-03-23 01:49:53 --> Language Class Initialized
INFO - 2022-03-23 01:49:53 --> Loader Class Initialized
INFO - 2022-03-23 01:49:53 --> Helper loaded: url_helper
INFO - 2022-03-23 01:49:53 --> Helper loaded: form_helper
INFO - 2022-03-23 01:49:53 --> Helper loaded: common_helper
INFO - 2022-03-23 01:49:53 --> Database Driver Class Initialized
DEBUG - 2022-03-23 01:49:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 01:49:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 01:49:53 --> Controller Class Initialized
INFO - 2022-03-23 01:49:53 --> Form Validation Class Initialized
DEBUG - 2022-03-23 01:49:53 --> Encrypt Class Initialized
INFO - 2022-03-23 01:49:53 --> Model "Patient_model" initialized
INFO - 2022-03-23 01:49:53 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 01:49:53 --> Model "Referredby_model" initialized
INFO - 2022-03-23 01:49:53 --> Model "Prefix_master" initialized
INFO - 2022-03-23 01:49:53 --> Model "Hospital_model" initialized
ERROR - 2022-03-23 01:49:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 01:49:53 --> Config Class Initialized
INFO - 2022-03-23 01:49:53 --> Hooks Class Initialized
DEBUG - 2022-03-23 01:49:53 --> UTF-8 Support Enabled
INFO - 2022-03-23 01:49:53 --> Utf8 Class Initialized
INFO - 2022-03-23 01:49:53 --> URI Class Initialized
INFO - 2022-03-23 01:49:53 --> Router Class Initialized
INFO - 2022-03-23 01:49:53 --> Output Class Initialized
INFO - 2022-03-23 01:49:53 --> Security Class Initialized
DEBUG - 2022-03-23 01:49:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 01:49:53 --> Input Class Initialized
INFO - 2022-03-23 01:49:53 --> Language Class Initialized
INFO - 2022-03-23 01:49:53 --> Loader Class Initialized
INFO - 2022-03-23 01:49:53 --> Helper loaded: url_helper
INFO - 2022-03-23 01:49:53 --> Helper loaded: form_helper
INFO - 2022-03-23 01:49:53 --> Helper loaded: common_helper
INFO - 2022-03-23 01:49:53 --> Database Driver Class Initialized
DEBUG - 2022-03-23 01:49:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 01:49:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 01:49:53 --> Controller Class Initialized
INFO - 2022-03-23 01:49:53 --> Form Validation Class Initialized
DEBUG - 2022-03-23 01:49:53 --> Encrypt Class Initialized
INFO - 2022-03-23 01:49:53 --> Model "Patient_model" initialized
INFO - 2022-03-23 01:49:53 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 01:49:53 --> Model "Referredby_model" initialized
INFO - 2022-03-23 01:49:53 --> Model "Prefix_master" initialized
INFO - 2022-03-23 01:49:53 --> Model "Hospital_model" initialized
INFO - 2022-03-23 01:49:54 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 01:49:54 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-23 01:49:54 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 01:49:54 --> Final output sent to browser
DEBUG - 2022-03-23 01:49:54 --> Total execution time: 0.0264
ERROR - 2022-03-23 01:49:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 01:49:54 --> Config Class Initialized
INFO - 2022-03-23 01:49:54 --> Hooks Class Initialized
DEBUG - 2022-03-23 01:49:54 --> UTF-8 Support Enabled
INFO - 2022-03-23 01:49:54 --> Utf8 Class Initialized
INFO - 2022-03-23 01:49:54 --> URI Class Initialized
INFO - 2022-03-23 01:49:54 --> Router Class Initialized
INFO - 2022-03-23 01:49:54 --> Output Class Initialized
INFO - 2022-03-23 01:49:54 --> Security Class Initialized
DEBUG - 2022-03-23 01:49:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 01:49:54 --> Input Class Initialized
INFO - 2022-03-23 01:49:54 --> Language Class Initialized
INFO - 2022-03-23 01:49:54 --> Loader Class Initialized
INFO - 2022-03-23 01:49:54 --> Helper loaded: url_helper
INFO - 2022-03-23 01:49:54 --> Helper loaded: form_helper
INFO - 2022-03-23 01:49:54 --> Helper loaded: common_helper
INFO - 2022-03-23 01:49:54 --> Database Driver Class Initialized
DEBUG - 2022-03-23 01:49:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 01:49:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 01:49:54 --> Controller Class Initialized
INFO - 2022-03-23 01:49:54 --> Form Validation Class Initialized
DEBUG - 2022-03-23 01:49:54 --> Encrypt Class Initialized
INFO - 2022-03-23 01:49:54 --> Model "Patient_model" initialized
INFO - 2022-03-23 01:49:54 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 01:49:54 --> Model "Prefix_master" initialized
INFO - 2022-03-23 01:49:54 --> Model "Users_model" initialized
INFO - 2022-03-23 01:49:54 --> Model "Hospital_model" initialized
INFO - 2022-03-23 01:49:54 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 01:49:54 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-23 01:49:54 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 01:49:54 --> Final output sent to browser
DEBUG - 2022-03-23 01:49:54 --> Total execution time: 0.0540
ERROR - 2022-03-23 01:50:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 01:50:06 --> Config Class Initialized
INFO - 2022-03-23 01:50:06 --> Hooks Class Initialized
DEBUG - 2022-03-23 01:50:06 --> UTF-8 Support Enabled
INFO - 2022-03-23 01:50:06 --> Utf8 Class Initialized
INFO - 2022-03-23 01:50:06 --> URI Class Initialized
INFO - 2022-03-23 01:50:06 --> Router Class Initialized
INFO - 2022-03-23 01:50:06 --> Output Class Initialized
INFO - 2022-03-23 01:50:06 --> Security Class Initialized
DEBUG - 2022-03-23 01:50:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 01:50:06 --> Input Class Initialized
INFO - 2022-03-23 01:50:06 --> Language Class Initialized
INFO - 2022-03-23 01:50:06 --> Loader Class Initialized
INFO - 2022-03-23 01:50:06 --> Helper loaded: url_helper
INFO - 2022-03-23 01:50:06 --> Helper loaded: form_helper
INFO - 2022-03-23 01:50:06 --> Helper loaded: common_helper
INFO - 2022-03-23 01:50:06 --> Database Driver Class Initialized
DEBUG - 2022-03-23 01:50:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 01:50:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 01:50:06 --> Controller Class Initialized
INFO - 2022-03-23 01:50:06 --> Form Validation Class Initialized
DEBUG - 2022-03-23 01:50:06 --> Encrypt Class Initialized
INFO - 2022-03-23 01:50:06 --> Model "Patient_model" initialized
INFO - 2022-03-23 01:50:06 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 01:50:06 --> Model "Prefix_master" initialized
INFO - 2022-03-23 01:50:06 --> Model "Users_model" initialized
INFO - 2022-03-23 01:50:06 --> Model "Hospital_model" initialized
ERROR - 2022-03-23 01:50:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 01:50:06 --> Config Class Initialized
INFO - 2022-03-23 01:50:06 --> Hooks Class Initialized
DEBUG - 2022-03-23 01:50:06 --> UTF-8 Support Enabled
INFO - 2022-03-23 01:50:06 --> Utf8 Class Initialized
INFO - 2022-03-23 01:50:06 --> URI Class Initialized
INFO - 2022-03-23 01:50:06 --> Router Class Initialized
INFO - 2022-03-23 01:50:06 --> Output Class Initialized
INFO - 2022-03-23 01:50:06 --> Security Class Initialized
DEBUG - 2022-03-23 01:50:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 01:50:06 --> Input Class Initialized
INFO - 2022-03-23 01:50:06 --> Language Class Initialized
INFO - 2022-03-23 01:50:06 --> Loader Class Initialized
INFO - 2022-03-23 01:50:06 --> Helper loaded: url_helper
INFO - 2022-03-23 01:50:06 --> Helper loaded: form_helper
INFO - 2022-03-23 01:50:06 --> Helper loaded: common_helper
INFO - 2022-03-23 01:50:06 --> Database Driver Class Initialized
DEBUG - 2022-03-23 01:50:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 01:50:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 01:50:06 --> Controller Class Initialized
INFO - 2022-03-23 01:50:06 --> Form Validation Class Initialized
DEBUG - 2022-03-23 01:50:06 --> Encrypt Class Initialized
INFO - 2022-03-23 01:50:06 --> Model "Patient_model" initialized
INFO - 2022-03-23 01:50:06 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 01:50:06 --> Model "Prefix_master" initialized
INFO - 2022-03-23 01:50:06 --> Model "Users_model" initialized
INFO - 2022-03-23 01:50:06 --> Model "Hospital_model" initialized
INFO - 2022-03-23 01:50:06 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 01:50:06 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-23 01:50:06 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 01:50:06 --> Final output sent to browser
DEBUG - 2022-03-23 01:50:06 --> Total execution time: 0.0425
ERROR - 2022-03-23 01:55:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 01:55:29 --> Config Class Initialized
INFO - 2022-03-23 01:55:29 --> Hooks Class Initialized
DEBUG - 2022-03-23 01:55:29 --> UTF-8 Support Enabled
INFO - 2022-03-23 01:55:29 --> Utf8 Class Initialized
INFO - 2022-03-23 01:55:29 --> URI Class Initialized
INFO - 2022-03-23 01:55:29 --> Router Class Initialized
INFO - 2022-03-23 01:55:29 --> Output Class Initialized
INFO - 2022-03-23 01:55:29 --> Security Class Initialized
DEBUG - 2022-03-23 01:55:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 01:55:29 --> Input Class Initialized
INFO - 2022-03-23 01:55:29 --> Language Class Initialized
INFO - 2022-03-23 01:55:29 --> Loader Class Initialized
INFO - 2022-03-23 01:55:29 --> Helper loaded: url_helper
INFO - 2022-03-23 01:55:29 --> Helper loaded: form_helper
INFO - 2022-03-23 01:55:29 --> Helper loaded: common_helper
INFO - 2022-03-23 01:55:29 --> Database Driver Class Initialized
DEBUG - 2022-03-23 01:55:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 01:55:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 01:55:29 --> Controller Class Initialized
INFO - 2022-03-23 01:55:29 --> Form Validation Class Initialized
DEBUG - 2022-03-23 01:55:29 --> Encrypt Class Initialized
INFO - 2022-03-23 01:55:29 --> Model "Patient_model" initialized
INFO - 2022-03-23 01:55:29 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 01:55:29 --> Model "Prefix_master" initialized
INFO - 2022-03-23 01:55:29 --> Model "Users_model" initialized
INFO - 2022-03-23 01:55:29 --> Model "Hospital_model" initialized
INFO - 2022-03-23 01:55:29 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 01:55:29 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-23 01:55:29 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 01:55:29 --> Final output sent to browser
DEBUG - 2022-03-23 01:55:29 --> Total execution time: 0.1045
ERROR - 2022-03-23 01:58:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 01:58:44 --> Config Class Initialized
INFO - 2022-03-23 01:58:44 --> Hooks Class Initialized
DEBUG - 2022-03-23 01:58:44 --> UTF-8 Support Enabled
INFO - 2022-03-23 01:58:44 --> Utf8 Class Initialized
INFO - 2022-03-23 01:58:44 --> URI Class Initialized
INFO - 2022-03-23 01:58:44 --> Router Class Initialized
INFO - 2022-03-23 01:58:44 --> Output Class Initialized
INFO - 2022-03-23 01:58:44 --> Security Class Initialized
DEBUG - 2022-03-23 01:58:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 01:58:44 --> Input Class Initialized
INFO - 2022-03-23 01:58:44 --> Language Class Initialized
INFO - 2022-03-23 01:58:44 --> Loader Class Initialized
INFO - 2022-03-23 01:58:44 --> Helper loaded: url_helper
INFO - 2022-03-23 01:58:44 --> Helper loaded: form_helper
INFO - 2022-03-23 01:58:44 --> Helper loaded: common_helper
INFO - 2022-03-23 01:58:44 --> Database Driver Class Initialized
DEBUG - 2022-03-23 01:58:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 01:58:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 01:58:44 --> Controller Class Initialized
INFO - 2022-03-23 01:58:44 --> Form Validation Class Initialized
DEBUG - 2022-03-23 01:58:44 --> Encrypt Class Initialized
INFO - 2022-03-23 01:58:44 --> Model "Patient_model" initialized
INFO - 2022-03-23 01:58:44 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 01:58:44 --> Model "Referredby_model" initialized
INFO - 2022-03-23 01:58:44 --> Model "Prefix_master" initialized
INFO - 2022-03-23 01:58:44 --> Model "Hospital_model" initialized
INFO - 2022-03-23 01:58:44 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 01:58:44 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-23 01:58:44 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 01:58:44 --> Final output sent to browser
DEBUG - 2022-03-23 01:58:44 --> Total execution time: 0.1060
ERROR - 2022-03-23 01:58:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 01:58:57 --> Config Class Initialized
INFO - 2022-03-23 01:58:57 --> Hooks Class Initialized
DEBUG - 2022-03-23 01:58:57 --> UTF-8 Support Enabled
INFO - 2022-03-23 01:58:57 --> Utf8 Class Initialized
INFO - 2022-03-23 01:58:57 --> URI Class Initialized
INFO - 2022-03-23 01:58:57 --> Router Class Initialized
INFO - 2022-03-23 01:58:57 --> Output Class Initialized
INFO - 2022-03-23 01:58:57 --> Security Class Initialized
DEBUG - 2022-03-23 01:58:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 01:58:57 --> Input Class Initialized
INFO - 2022-03-23 01:58:57 --> Language Class Initialized
INFO - 2022-03-23 01:58:57 --> Loader Class Initialized
INFO - 2022-03-23 01:58:57 --> Helper loaded: url_helper
INFO - 2022-03-23 01:58:57 --> Helper loaded: form_helper
INFO - 2022-03-23 01:58:57 --> Helper loaded: common_helper
INFO - 2022-03-23 01:58:57 --> Database Driver Class Initialized
DEBUG - 2022-03-23 01:58:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 01:58:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 01:58:57 --> Controller Class Initialized
INFO - 2022-03-23 01:58:57 --> Form Validation Class Initialized
DEBUG - 2022-03-23 01:58:57 --> Encrypt Class Initialized
INFO - 2022-03-23 01:58:57 --> Model "Patient_model" initialized
INFO - 2022-03-23 01:58:57 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 01:58:57 --> Model "Referredby_model" initialized
INFO - 2022-03-23 01:58:57 --> Model "Prefix_master" initialized
INFO - 2022-03-23 01:58:57 --> Model "Hospital_model" initialized
INFO - 2022-03-23 01:58:57 --> Upload Class Initialized
INFO - 2022-03-23 01:58:57 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2022-03-23 01:58:57 --> The filetype you are attempting to upload is not allowed.
INFO - 2022-03-23 01:58:57 --> Final output sent to browser
DEBUG - 2022-03-23 01:58:57 --> Total execution time: 0.0121
ERROR - 2022-03-23 01:59:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 01:59:53 --> Config Class Initialized
INFO - 2022-03-23 01:59:53 --> Hooks Class Initialized
DEBUG - 2022-03-23 01:59:53 --> UTF-8 Support Enabled
INFO - 2022-03-23 01:59:53 --> Utf8 Class Initialized
INFO - 2022-03-23 01:59:53 --> URI Class Initialized
INFO - 2022-03-23 01:59:53 --> Router Class Initialized
INFO - 2022-03-23 01:59:53 --> Output Class Initialized
INFO - 2022-03-23 01:59:53 --> Security Class Initialized
DEBUG - 2022-03-23 01:59:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 01:59:53 --> Input Class Initialized
INFO - 2022-03-23 01:59:53 --> Language Class Initialized
INFO - 2022-03-23 01:59:53 --> Loader Class Initialized
INFO - 2022-03-23 01:59:53 --> Helper loaded: url_helper
INFO - 2022-03-23 01:59:53 --> Helper loaded: form_helper
INFO - 2022-03-23 01:59:53 --> Helper loaded: common_helper
INFO - 2022-03-23 01:59:53 --> Database Driver Class Initialized
DEBUG - 2022-03-23 01:59:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 01:59:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 01:59:53 --> Controller Class Initialized
INFO - 2022-03-23 01:59:53 --> Form Validation Class Initialized
DEBUG - 2022-03-23 01:59:53 --> Encrypt Class Initialized
INFO - 2022-03-23 01:59:53 --> Model "Patient_model" initialized
INFO - 2022-03-23 01:59:53 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 01:59:53 --> Model "Referredby_model" initialized
INFO - 2022-03-23 01:59:53 --> Model "Prefix_master" initialized
INFO - 2022-03-23 01:59:53 --> Model "Hospital_model" initialized
ERROR - 2022-03-23 01:59:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 01:59:53 --> Config Class Initialized
INFO - 2022-03-23 01:59:53 --> Hooks Class Initialized
DEBUG - 2022-03-23 01:59:53 --> UTF-8 Support Enabled
INFO - 2022-03-23 01:59:53 --> Utf8 Class Initialized
INFO - 2022-03-23 01:59:53 --> URI Class Initialized
INFO - 2022-03-23 01:59:53 --> Router Class Initialized
INFO - 2022-03-23 01:59:53 --> Output Class Initialized
INFO - 2022-03-23 01:59:53 --> Security Class Initialized
DEBUG - 2022-03-23 01:59:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 01:59:53 --> Input Class Initialized
INFO - 2022-03-23 01:59:53 --> Language Class Initialized
INFO - 2022-03-23 01:59:53 --> Loader Class Initialized
INFO - 2022-03-23 01:59:53 --> Helper loaded: url_helper
INFO - 2022-03-23 01:59:53 --> Helper loaded: form_helper
INFO - 2022-03-23 01:59:53 --> Helper loaded: common_helper
INFO - 2022-03-23 01:59:53 --> Database Driver Class Initialized
DEBUG - 2022-03-23 01:59:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 01:59:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 01:59:53 --> Controller Class Initialized
INFO - 2022-03-23 01:59:53 --> Form Validation Class Initialized
DEBUG - 2022-03-23 01:59:53 --> Encrypt Class Initialized
INFO - 2022-03-23 01:59:53 --> Model "Patient_model" initialized
INFO - 2022-03-23 01:59:53 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 01:59:53 --> Model "Referredby_model" initialized
INFO - 2022-03-23 01:59:53 --> Model "Prefix_master" initialized
INFO - 2022-03-23 01:59:53 --> Model "Hospital_model" initialized
INFO - 2022-03-23 01:59:53 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 01:59:53 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-23 01:59:53 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 01:59:53 --> Final output sent to browser
DEBUG - 2022-03-23 01:59:53 --> Total execution time: 0.0333
ERROR - 2022-03-23 01:59:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 01:59:54 --> Config Class Initialized
INFO - 2022-03-23 01:59:54 --> Hooks Class Initialized
DEBUG - 2022-03-23 01:59:54 --> UTF-8 Support Enabled
INFO - 2022-03-23 01:59:54 --> Utf8 Class Initialized
INFO - 2022-03-23 01:59:54 --> URI Class Initialized
INFO - 2022-03-23 01:59:54 --> Router Class Initialized
INFO - 2022-03-23 01:59:54 --> Output Class Initialized
INFO - 2022-03-23 01:59:54 --> Security Class Initialized
DEBUG - 2022-03-23 01:59:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 01:59:54 --> Input Class Initialized
INFO - 2022-03-23 01:59:54 --> Language Class Initialized
INFO - 2022-03-23 01:59:54 --> Loader Class Initialized
INFO - 2022-03-23 01:59:54 --> Helper loaded: url_helper
INFO - 2022-03-23 01:59:54 --> Helper loaded: form_helper
INFO - 2022-03-23 01:59:54 --> Helper loaded: common_helper
INFO - 2022-03-23 01:59:54 --> Database Driver Class Initialized
DEBUG - 2022-03-23 01:59:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 01:59:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 01:59:54 --> Controller Class Initialized
INFO - 2022-03-23 01:59:54 --> Form Validation Class Initialized
DEBUG - 2022-03-23 01:59:54 --> Encrypt Class Initialized
INFO - 2022-03-23 01:59:54 --> Model "Patient_model" initialized
INFO - 2022-03-23 01:59:54 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 01:59:54 --> Model "Prefix_master" initialized
INFO - 2022-03-23 01:59:54 --> Model "Users_model" initialized
INFO - 2022-03-23 01:59:54 --> Model "Hospital_model" initialized
INFO - 2022-03-23 01:59:54 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 01:59:54 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-23 01:59:54 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 01:59:54 --> Final output sent to browser
DEBUG - 2022-03-23 01:59:54 --> Total execution time: 0.0695
ERROR - 2022-03-23 02:00:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 02:00:38 --> Config Class Initialized
INFO - 2022-03-23 02:00:38 --> Hooks Class Initialized
DEBUG - 2022-03-23 02:00:38 --> UTF-8 Support Enabled
INFO - 2022-03-23 02:00:38 --> Utf8 Class Initialized
INFO - 2022-03-23 02:00:38 --> URI Class Initialized
INFO - 2022-03-23 02:00:38 --> Router Class Initialized
INFO - 2022-03-23 02:00:38 --> Output Class Initialized
INFO - 2022-03-23 02:00:38 --> Security Class Initialized
DEBUG - 2022-03-23 02:00:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 02:00:38 --> Input Class Initialized
INFO - 2022-03-23 02:00:38 --> Language Class Initialized
INFO - 2022-03-23 02:00:38 --> Loader Class Initialized
INFO - 2022-03-23 02:00:38 --> Helper loaded: url_helper
INFO - 2022-03-23 02:00:38 --> Helper loaded: form_helper
INFO - 2022-03-23 02:00:38 --> Helper loaded: common_helper
INFO - 2022-03-23 02:00:38 --> Database Driver Class Initialized
DEBUG - 2022-03-23 02:00:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 02:00:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 02:00:38 --> Controller Class Initialized
INFO - 2022-03-23 02:00:38 --> Form Validation Class Initialized
DEBUG - 2022-03-23 02:00:38 --> Encrypt Class Initialized
INFO - 2022-03-23 02:00:38 --> Model "Patient_model" initialized
INFO - 2022-03-23 02:00:38 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 02:00:38 --> Model "Prefix_master" initialized
INFO - 2022-03-23 02:00:38 --> Model "Users_model" initialized
INFO - 2022-03-23 02:00:38 --> Model "Hospital_model" initialized
INFO - 2022-03-23 02:00:38 --> Upload Class Initialized
INFO - 2022-03-23 02:00:38 --> Final output sent to browser
DEBUG - 2022-03-23 02:00:38 --> Total execution time: 0.0446
ERROR - 2022-03-23 02:00:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 02:00:45 --> Config Class Initialized
INFO - 2022-03-23 02:00:45 --> Hooks Class Initialized
DEBUG - 2022-03-23 02:00:45 --> UTF-8 Support Enabled
INFO - 2022-03-23 02:00:45 --> Utf8 Class Initialized
INFO - 2022-03-23 02:00:45 --> URI Class Initialized
INFO - 2022-03-23 02:00:45 --> Router Class Initialized
INFO - 2022-03-23 02:00:45 --> Output Class Initialized
INFO - 2022-03-23 02:00:45 --> Security Class Initialized
DEBUG - 2022-03-23 02:00:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 02:00:45 --> Input Class Initialized
INFO - 2022-03-23 02:00:45 --> Language Class Initialized
INFO - 2022-03-23 02:00:45 --> Loader Class Initialized
INFO - 2022-03-23 02:00:45 --> Helper loaded: url_helper
INFO - 2022-03-23 02:00:45 --> Helper loaded: form_helper
INFO - 2022-03-23 02:00:45 --> Helper loaded: common_helper
INFO - 2022-03-23 02:00:45 --> Database Driver Class Initialized
DEBUG - 2022-03-23 02:00:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 02:00:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 02:00:45 --> Controller Class Initialized
INFO - 2022-03-23 02:00:45 --> Form Validation Class Initialized
DEBUG - 2022-03-23 02:00:45 --> Encrypt Class Initialized
INFO - 2022-03-23 02:00:45 --> Model "Patient_model" initialized
INFO - 2022-03-23 02:00:45 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 02:00:45 --> Model "Prefix_master" initialized
INFO - 2022-03-23 02:00:45 --> Model "Users_model" initialized
INFO - 2022-03-23 02:00:45 --> Model "Hospital_model" initialized
ERROR - 2022-03-23 02:00:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 02:00:46 --> Config Class Initialized
INFO - 2022-03-23 02:00:46 --> Hooks Class Initialized
DEBUG - 2022-03-23 02:00:46 --> UTF-8 Support Enabled
INFO - 2022-03-23 02:00:46 --> Utf8 Class Initialized
INFO - 2022-03-23 02:00:46 --> URI Class Initialized
INFO - 2022-03-23 02:00:46 --> Router Class Initialized
INFO - 2022-03-23 02:00:46 --> Output Class Initialized
INFO - 2022-03-23 02:00:46 --> Security Class Initialized
DEBUG - 2022-03-23 02:00:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 02:00:46 --> Input Class Initialized
INFO - 2022-03-23 02:00:46 --> Language Class Initialized
INFO - 2022-03-23 02:00:46 --> Loader Class Initialized
INFO - 2022-03-23 02:00:46 --> Helper loaded: url_helper
INFO - 2022-03-23 02:00:46 --> Helper loaded: form_helper
INFO - 2022-03-23 02:00:46 --> Helper loaded: common_helper
INFO - 2022-03-23 02:00:46 --> Database Driver Class Initialized
DEBUG - 2022-03-23 02:00:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 02:00:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 02:00:46 --> Controller Class Initialized
INFO - 2022-03-23 02:00:46 --> Form Validation Class Initialized
DEBUG - 2022-03-23 02:00:46 --> Encrypt Class Initialized
INFO - 2022-03-23 02:00:46 --> Model "Patient_model" initialized
INFO - 2022-03-23 02:00:46 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 02:00:46 --> Model "Prefix_master" initialized
INFO - 2022-03-23 02:00:46 --> Model "Users_model" initialized
INFO - 2022-03-23 02:00:46 --> Model "Hospital_model" initialized
INFO - 2022-03-23 02:00:46 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 02:00:46 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-23 02:00:46 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 02:00:46 --> Final output sent to browser
DEBUG - 2022-03-23 02:00:46 --> Total execution time: 0.0619
ERROR - 2022-03-23 02:07:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 02:07:39 --> Config Class Initialized
INFO - 2022-03-23 02:07:39 --> Hooks Class Initialized
DEBUG - 2022-03-23 02:07:39 --> UTF-8 Support Enabled
INFO - 2022-03-23 02:07:39 --> Utf8 Class Initialized
INFO - 2022-03-23 02:07:39 --> URI Class Initialized
INFO - 2022-03-23 02:07:39 --> Router Class Initialized
INFO - 2022-03-23 02:07:39 --> Output Class Initialized
INFO - 2022-03-23 02:07:39 --> Security Class Initialized
DEBUG - 2022-03-23 02:07:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 02:07:39 --> Input Class Initialized
INFO - 2022-03-23 02:07:39 --> Language Class Initialized
INFO - 2022-03-23 02:07:39 --> Loader Class Initialized
INFO - 2022-03-23 02:07:39 --> Helper loaded: url_helper
INFO - 2022-03-23 02:07:39 --> Helper loaded: form_helper
INFO - 2022-03-23 02:07:39 --> Helper loaded: common_helper
INFO - 2022-03-23 02:07:39 --> Database Driver Class Initialized
DEBUG - 2022-03-23 02:07:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 02:07:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 02:07:39 --> Controller Class Initialized
INFO - 2022-03-23 02:07:39 --> Form Validation Class Initialized
DEBUG - 2022-03-23 02:07:39 --> Encrypt Class Initialized
INFO - 2022-03-23 02:07:39 --> Model "Patient_model" initialized
INFO - 2022-03-23 02:07:39 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 02:07:39 --> Model "Referredby_model" initialized
INFO - 2022-03-23 02:07:39 --> Model "Prefix_master" initialized
INFO - 2022-03-23 02:07:39 --> Model "Hospital_model" initialized
INFO - 2022-03-23 02:07:39 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 02:07:39 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-23 02:07:39 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 02:07:39 --> Final output sent to browser
DEBUG - 2022-03-23 02:07:39 --> Total execution time: 0.1200
ERROR - 2022-03-23 02:07:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 02:07:53 --> Config Class Initialized
INFO - 2022-03-23 02:07:53 --> Hooks Class Initialized
DEBUG - 2022-03-23 02:07:53 --> UTF-8 Support Enabled
INFO - 2022-03-23 02:07:53 --> Utf8 Class Initialized
INFO - 2022-03-23 02:07:53 --> URI Class Initialized
INFO - 2022-03-23 02:07:53 --> Router Class Initialized
INFO - 2022-03-23 02:07:53 --> Output Class Initialized
INFO - 2022-03-23 02:07:53 --> Security Class Initialized
DEBUG - 2022-03-23 02:07:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 02:07:53 --> Input Class Initialized
INFO - 2022-03-23 02:07:53 --> Language Class Initialized
INFO - 2022-03-23 02:07:53 --> Loader Class Initialized
INFO - 2022-03-23 02:07:53 --> Helper loaded: url_helper
INFO - 2022-03-23 02:07:53 --> Helper loaded: form_helper
INFO - 2022-03-23 02:07:53 --> Helper loaded: common_helper
INFO - 2022-03-23 02:07:53 --> Database Driver Class Initialized
DEBUG - 2022-03-23 02:07:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 02:07:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 02:07:53 --> Controller Class Initialized
INFO - 2022-03-23 02:07:53 --> Form Validation Class Initialized
DEBUG - 2022-03-23 02:07:53 --> Encrypt Class Initialized
INFO - 2022-03-23 02:07:53 --> Model "Patient_model" initialized
INFO - 2022-03-23 02:07:53 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 02:07:53 --> Model "Referredby_model" initialized
INFO - 2022-03-23 02:07:53 --> Model "Prefix_master" initialized
INFO - 2022-03-23 02:07:53 --> Model "Hospital_model" initialized
INFO - 2022-03-23 02:07:53 --> Upload Class Initialized
INFO - 2022-03-23 02:07:53 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2022-03-23 02:07:53 --> The filetype you are attempting to upload is not allowed.
INFO - 2022-03-23 02:07:53 --> Final output sent to browser
DEBUG - 2022-03-23 02:07:53 --> Total execution time: 0.0175
ERROR - 2022-03-23 02:08:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 02:08:04 --> Config Class Initialized
INFO - 2022-03-23 02:08:04 --> Hooks Class Initialized
DEBUG - 2022-03-23 02:08:04 --> UTF-8 Support Enabled
INFO - 2022-03-23 02:08:04 --> Utf8 Class Initialized
INFO - 2022-03-23 02:08:04 --> URI Class Initialized
INFO - 2022-03-23 02:08:04 --> Router Class Initialized
INFO - 2022-03-23 02:08:04 --> Output Class Initialized
INFO - 2022-03-23 02:08:04 --> Security Class Initialized
DEBUG - 2022-03-23 02:08:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 02:08:04 --> Input Class Initialized
INFO - 2022-03-23 02:08:04 --> Language Class Initialized
INFO - 2022-03-23 02:08:04 --> Loader Class Initialized
INFO - 2022-03-23 02:08:04 --> Helper loaded: url_helper
INFO - 2022-03-23 02:08:04 --> Helper loaded: form_helper
INFO - 2022-03-23 02:08:04 --> Helper loaded: common_helper
INFO - 2022-03-23 02:08:04 --> Database Driver Class Initialized
DEBUG - 2022-03-23 02:08:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 02:08:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 02:08:04 --> Controller Class Initialized
INFO - 2022-03-23 02:08:04 --> Form Validation Class Initialized
DEBUG - 2022-03-23 02:08:04 --> Encrypt Class Initialized
INFO - 2022-03-23 02:08:04 --> Model "Patient_model" initialized
INFO - 2022-03-23 02:08:04 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 02:08:04 --> Model "Referredby_model" initialized
INFO - 2022-03-23 02:08:04 --> Model "Prefix_master" initialized
INFO - 2022-03-23 02:08:04 --> Model "Hospital_model" initialized
INFO - 2022-03-23 02:08:04 --> Upload Class Initialized
INFO - 2022-03-23 02:08:04 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2022-03-23 02:08:04 --> The filetype you are attempting to upload is not allowed.
INFO - 2022-03-23 02:08:04 --> Final output sent to browser
DEBUG - 2022-03-23 02:08:04 --> Total execution time: 0.0118
ERROR - 2022-03-23 02:09:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 02:09:10 --> Config Class Initialized
INFO - 2022-03-23 02:09:10 --> Hooks Class Initialized
DEBUG - 2022-03-23 02:09:10 --> UTF-8 Support Enabled
INFO - 2022-03-23 02:09:10 --> Utf8 Class Initialized
INFO - 2022-03-23 02:09:10 --> URI Class Initialized
INFO - 2022-03-23 02:09:10 --> Router Class Initialized
INFO - 2022-03-23 02:09:10 --> Output Class Initialized
INFO - 2022-03-23 02:09:10 --> Security Class Initialized
DEBUG - 2022-03-23 02:09:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 02:09:10 --> Input Class Initialized
INFO - 2022-03-23 02:09:10 --> Language Class Initialized
INFO - 2022-03-23 02:09:10 --> Loader Class Initialized
INFO - 2022-03-23 02:09:10 --> Helper loaded: url_helper
INFO - 2022-03-23 02:09:10 --> Helper loaded: form_helper
INFO - 2022-03-23 02:09:10 --> Helper loaded: common_helper
INFO - 2022-03-23 02:09:10 --> Database Driver Class Initialized
DEBUG - 2022-03-23 02:09:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 02:09:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 02:09:10 --> Controller Class Initialized
INFO - 2022-03-23 02:09:10 --> Form Validation Class Initialized
DEBUG - 2022-03-23 02:09:10 --> Encrypt Class Initialized
INFO - 2022-03-23 02:09:10 --> Model "Patient_model" initialized
INFO - 2022-03-23 02:09:10 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 02:09:10 --> Model "Referredby_model" initialized
INFO - 2022-03-23 02:09:10 --> Model "Prefix_master" initialized
INFO - 2022-03-23 02:09:10 --> Model "Hospital_model" initialized
INFO - 2022-03-23 02:09:10 --> Upload Class Initialized
INFO - 2022-03-23 02:09:10 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2022-03-23 02:09:10 --> The filetype you are attempting to upload is not allowed.
INFO - 2022-03-23 02:09:10 --> Final output sent to browser
DEBUG - 2022-03-23 02:09:10 --> Total execution time: 0.0116
ERROR - 2022-03-23 02:15:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 02:15:52 --> Config Class Initialized
INFO - 2022-03-23 02:15:52 --> Hooks Class Initialized
DEBUG - 2022-03-23 02:15:52 --> UTF-8 Support Enabled
INFO - 2022-03-23 02:15:52 --> Utf8 Class Initialized
INFO - 2022-03-23 02:15:52 --> URI Class Initialized
INFO - 2022-03-23 02:15:52 --> Router Class Initialized
INFO - 2022-03-23 02:15:52 --> Output Class Initialized
INFO - 2022-03-23 02:15:52 --> Security Class Initialized
DEBUG - 2022-03-23 02:15:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 02:15:52 --> Input Class Initialized
INFO - 2022-03-23 02:15:52 --> Language Class Initialized
INFO - 2022-03-23 02:15:52 --> Loader Class Initialized
INFO - 2022-03-23 02:15:52 --> Helper loaded: url_helper
INFO - 2022-03-23 02:15:52 --> Helper loaded: form_helper
INFO - 2022-03-23 02:15:52 --> Helper loaded: common_helper
INFO - 2022-03-23 02:15:52 --> Database Driver Class Initialized
DEBUG - 2022-03-23 02:15:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 02:15:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 02:15:52 --> Controller Class Initialized
INFO - 2022-03-23 02:15:52 --> Form Validation Class Initialized
DEBUG - 2022-03-23 02:15:52 --> Encrypt Class Initialized
INFO - 2022-03-23 02:15:52 --> Model "Patient_model" initialized
INFO - 2022-03-23 02:15:52 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 02:15:52 --> Model "Referredby_model" initialized
INFO - 2022-03-23 02:15:52 --> Model "Prefix_master" initialized
INFO - 2022-03-23 02:15:52 --> Model "Hospital_model" initialized
INFO - 2022-03-23 02:15:52 --> Upload Class Initialized
INFO - 2022-03-23 02:15:52 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2022-03-23 02:15:52 --> The filetype you are attempting to upload is not allowed.
INFO - 2022-03-23 02:15:52 --> Final output sent to browser
DEBUG - 2022-03-23 02:15:52 --> Total execution time: 0.0741
ERROR - 2022-03-23 02:17:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 02:17:39 --> Config Class Initialized
INFO - 2022-03-23 02:17:39 --> Hooks Class Initialized
DEBUG - 2022-03-23 02:17:39 --> UTF-8 Support Enabled
INFO - 2022-03-23 02:17:39 --> Utf8 Class Initialized
INFO - 2022-03-23 02:17:39 --> URI Class Initialized
INFO - 2022-03-23 02:17:39 --> Router Class Initialized
INFO - 2022-03-23 02:17:39 --> Output Class Initialized
INFO - 2022-03-23 02:17:39 --> Security Class Initialized
DEBUG - 2022-03-23 02:17:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 02:17:39 --> Input Class Initialized
INFO - 2022-03-23 02:17:39 --> Language Class Initialized
INFO - 2022-03-23 02:17:39 --> Loader Class Initialized
INFO - 2022-03-23 02:17:39 --> Helper loaded: url_helper
INFO - 2022-03-23 02:17:39 --> Helper loaded: form_helper
INFO - 2022-03-23 02:17:39 --> Helper loaded: common_helper
INFO - 2022-03-23 02:17:39 --> Database Driver Class Initialized
DEBUG - 2022-03-23 02:17:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 02:17:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 02:17:40 --> Controller Class Initialized
INFO - 2022-03-23 02:17:40 --> Form Validation Class Initialized
DEBUG - 2022-03-23 02:17:40 --> Encrypt Class Initialized
INFO - 2022-03-23 02:17:40 --> Model "Patient_model" initialized
INFO - 2022-03-23 02:17:40 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 02:17:40 --> Model "Prefix_master" initialized
INFO - 2022-03-23 02:17:40 --> Model "Users_model" initialized
INFO - 2022-03-23 02:17:40 --> Model "Hospital_model" initialized
INFO - 2022-03-23 02:17:40 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 02:17:40 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-23 02:17:40 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 02:17:40 --> Final output sent to browser
DEBUG - 2022-03-23 02:17:40 --> Total execution time: 0.1103
ERROR - 2022-03-23 02:17:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 02:17:51 --> Config Class Initialized
INFO - 2022-03-23 02:17:51 --> Hooks Class Initialized
DEBUG - 2022-03-23 02:17:51 --> UTF-8 Support Enabled
INFO - 2022-03-23 02:17:51 --> Utf8 Class Initialized
INFO - 2022-03-23 02:17:51 --> URI Class Initialized
INFO - 2022-03-23 02:17:51 --> Router Class Initialized
INFO - 2022-03-23 02:17:51 --> Output Class Initialized
INFO - 2022-03-23 02:17:51 --> Security Class Initialized
DEBUG - 2022-03-23 02:17:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 02:17:51 --> Input Class Initialized
INFO - 2022-03-23 02:17:51 --> Language Class Initialized
INFO - 2022-03-23 02:17:51 --> Loader Class Initialized
INFO - 2022-03-23 02:17:51 --> Helper loaded: url_helper
INFO - 2022-03-23 02:17:51 --> Helper loaded: form_helper
INFO - 2022-03-23 02:17:51 --> Helper loaded: common_helper
INFO - 2022-03-23 02:17:51 --> Database Driver Class Initialized
DEBUG - 2022-03-23 02:17:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 02:17:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 02:17:51 --> Controller Class Initialized
INFO - 2022-03-23 02:17:51 --> Form Validation Class Initialized
DEBUG - 2022-03-23 02:17:51 --> Encrypt Class Initialized
INFO - 2022-03-23 02:17:51 --> Model "Patient_model" initialized
INFO - 2022-03-23 02:17:51 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 02:17:51 --> Model "Prefix_master" initialized
INFO - 2022-03-23 02:17:51 --> Model "Users_model" initialized
INFO - 2022-03-23 02:17:51 --> Model "Hospital_model" initialized
INFO - 2022-03-23 02:17:51 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-23 02:17:52 --> Final output sent to browser
DEBUG - 2022-03-23 02:17:52 --> Total execution time: 1.1095
ERROR - 2022-03-23 02:22:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 02:22:58 --> Config Class Initialized
INFO - 2022-03-23 02:22:58 --> Hooks Class Initialized
DEBUG - 2022-03-23 02:22:58 --> UTF-8 Support Enabled
INFO - 2022-03-23 02:22:58 --> Utf8 Class Initialized
INFO - 2022-03-23 02:22:58 --> URI Class Initialized
DEBUG - 2022-03-23 02:22:58 --> No URI present. Default controller set.
INFO - 2022-03-23 02:22:58 --> Router Class Initialized
INFO - 2022-03-23 02:22:58 --> Output Class Initialized
INFO - 2022-03-23 02:22:58 --> Security Class Initialized
DEBUG - 2022-03-23 02:22:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 02:22:58 --> Input Class Initialized
INFO - 2022-03-23 02:22:58 --> Language Class Initialized
INFO - 2022-03-23 02:22:58 --> Loader Class Initialized
INFO - 2022-03-23 02:22:58 --> Helper loaded: url_helper
INFO - 2022-03-23 02:22:58 --> Helper loaded: form_helper
INFO - 2022-03-23 02:22:58 --> Helper loaded: common_helper
INFO - 2022-03-23 02:22:58 --> Database Driver Class Initialized
DEBUG - 2022-03-23 02:22:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 02:22:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 02:22:58 --> Controller Class Initialized
INFO - 2022-03-23 02:22:58 --> Form Validation Class Initialized
DEBUG - 2022-03-23 02:22:58 --> Encrypt Class Initialized
DEBUG - 2022-03-23 02:22:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 02:22:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-23 02:22:58 --> Email Class Initialized
INFO - 2022-03-23 02:22:58 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-23 02:22:58 --> Calendar Class Initialized
INFO - 2022-03-23 02:22:58 --> Model "Login_model" initialized
ERROR - 2022-03-23 02:22:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 02:22:58 --> Config Class Initialized
INFO - 2022-03-23 02:22:58 --> Hooks Class Initialized
DEBUG - 2022-03-23 02:22:58 --> UTF-8 Support Enabled
INFO - 2022-03-23 02:22:58 --> Utf8 Class Initialized
INFO - 2022-03-23 02:22:58 --> URI Class Initialized
INFO - 2022-03-23 02:22:58 --> Router Class Initialized
INFO - 2022-03-23 02:22:58 --> Output Class Initialized
INFO - 2022-03-23 02:22:58 --> Security Class Initialized
DEBUG - 2022-03-23 02:22:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 02:22:58 --> Input Class Initialized
INFO - 2022-03-23 02:22:58 --> Language Class Initialized
INFO - 2022-03-23 02:22:58 --> Loader Class Initialized
INFO - 2022-03-23 02:22:58 --> Helper loaded: url_helper
INFO - 2022-03-23 02:22:58 --> Helper loaded: form_helper
INFO - 2022-03-23 02:22:58 --> Helper loaded: common_helper
INFO - 2022-03-23 02:22:58 --> Database Driver Class Initialized
DEBUG - 2022-03-23 02:22:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 02:22:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 02:22:58 --> Controller Class Initialized
INFO - 2022-03-23 02:22:58 --> Form Validation Class Initialized
DEBUG - 2022-03-23 02:22:58 --> Encrypt Class Initialized
INFO - 2022-03-23 02:22:58 --> Model "Diseases_model" initialized
INFO - 2022-03-23 02:22:58 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 02:22:58 --> File loaded: /home3/karoteam/public_html/application/views/diseases/index.php
INFO - 2022-03-23 02:22:58 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 02:22:58 --> Final output sent to browser
DEBUG - 2022-03-23 02:22:58 --> Total execution time: 0.0115
ERROR - 2022-03-23 02:23:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 02:23:01 --> Config Class Initialized
INFO - 2022-03-23 02:23:01 --> Hooks Class Initialized
DEBUG - 2022-03-23 02:23:01 --> UTF-8 Support Enabled
INFO - 2022-03-23 02:23:01 --> Utf8 Class Initialized
INFO - 2022-03-23 02:23:01 --> URI Class Initialized
DEBUG - 2022-03-23 02:23:01 --> No URI present. Default controller set.
INFO - 2022-03-23 02:23:01 --> Router Class Initialized
INFO - 2022-03-23 02:23:01 --> Output Class Initialized
INFO - 2022-03-23 02:23:01 --> Security Class Initialized
DEBUG - 2022-03-23 02:23:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 02:23:01 --> Input Class Initialized
INFO - 2022-03-23 02:23:01 --> Language Class Initialized
INFO - 2022-03-23 02:23:01 --> Loader Class Initialized
INFO - 2022-03-23 02:23:01 --> Helper loaded: url_helper
INFO - 2022-03-23 02:23:01 --> Helper loaded: form_helper
INFO - 2022-03-23 02:23:01 --> Helper loaded: common_helper
INFO - 2022-03-23 02:23:01 --> Database Driver Class Initialized
DEBUG - 2022-03-23 02:23:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 02:23:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 02:23:01 --> Controller Class Initialized
INFO - 2022-03-23 02:23:01 --> Form Validation Class Initialized
DEBUG - 2022-03-23 02:23:01 --> Encrypt Class Initialized
DEBUG - 2022-03-23 02:23:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 02:23:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-23 02:23:01 --> Email Class Initialized
INFO - 2022-03-23 02:23:01 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-23 02:23:01 --> Calendar Class Initialized
INFO - 2022-03-23 02:23:01 --> Model "Login_model" initialized
ERROR - 2022-03-23 02:23:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 02:23:01 --> Config Class Initialized
INFO - 2022-03-23 02:23:01 --> Hooks Class Initialized
DEBUG - 2022-03-23 02:23:01 --> UTF-8 Support Enabled
INFO - 2022-03-23 02:23:01 --> Utf8 Class Initialized
INFO - 2022-03-23 02:23:01 --> URI Class Initialized
INFO - 2022-03-23 02:23:01 --> Router Class Initialized
INFO - 2022-03-23 02:23:01 --> Output Class Initialized
INFO - 2022-03-23 02:23:01 --> Security Class Initialized
DEBUG - 2022-03-23 02:23:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 02:23:01 --> Input Class Initialized
INFO - 2022-03-23 02:23:01 --> Language Class Initialized
INFO - 2022-03-23 02:23:01 --> Loader Class Initialized
INFO - 2022-03-23 02:23:01 --> Helper loaded: url_helper
INFO - 2022-03-23 02:23:01 --> Helper loaded: form_helper
INFO - 2022-03-23 02:23:01 --> Helper loaded: common_helper
INFO - 2022-03-23 02:23:01 --> Database Driver Class Initialized
DEBUG - 2022-03-23 02:23:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 02:23:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 02:23:01 --> Controller Class Initialized
INFO - 2022-03-23 02:23:01 --> Form Validation Class Initialized
DEBUG - 2022-03-23 02:23:01 --> Encrypt Class Initialized
INFO - 2022-03-23 02:23:01 --> Model "Diseases_model" initialized
INFO - 2022-03-23 02:23:01 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 02:23:01 --> File loaded: /home3/karoteam/public_html/application/views/diseases/index.php
INFO - 2022-03-23 02:23:01 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 02:23:01 --> Final output sent to browser
DEBUG - 2022-03-23 02:23:01 --> Total execution time: 0.0194
ERROR - 2022-03-23 02:23:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 02:23:10 --> Config Class Initialized
INFO - 2022-03-23 02:23:10 --> Hooks Class Initialized
DEBUG - 2022-03-23 02:23:10 --> UTF-8 Support Enabled
INFO - 2022-03-23 02:23:10 --> Utf8 Class Initialized
INFO - 2022-03-23 02:23:10 --> URI Class Initialized
INFO - 2022-03-23 02:23:10 --> Router Class Initialized
INFO - 2022-03-23 02:23:10 --> Output Class Initialized
INFO - 2022-03-23 02:23:10 --> Security Class Initialized
DEBUG - 2022-03-23 02:23:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 02:23:10 --> Input Class Initialized
INFO - 2022-03-23 02:23:10 --> Language Class Initialized
INFO - 2022-03-23 02:23:10 --> Loader Class Initialized
INFO - 2022-03-23 02:23:10 --> Helper loaded: url_helper
INFO - 2022-03-23 02:23:10 --> Helper loaded: form_helper
INFO - 2022-03-23 02:23:10 --> Helper loaded: common_helper
INFO - 2022-03-23 02:23:10 --> Database Driver Class Initialized
DEBUG - 2022-03-23 02:23:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 02:23:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 02:23:10 --> Controller Class Initialized
INFO - 2022-03-23 02:23:10 --> Form Validation Class Initialized
DEBUG - 2022-03-23 02:23:10 --> Encrypt Class Initialized
INFO - 2022-03-23 02:23:10 --> Model "Patient_model" initialized
INFO - 2022-03-23 02:23:10 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 02:23:10 --> Model "Referredby_model" initialized
INFO - 2022-03-23 02:23:10 --> Model "Prefix_master" initialized
INFO - 2022-03-23 02:23:10 --> Model "Hospital_model" initialized
INFO - 2022-03-23 02:23:10 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 02:23:10 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-23 02:23:10 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 02:23:10 --> Final output sent to browser
DEBUG - 2022-03-23 02:23:10 --> Total execution time: 0.0473
ERROR - 2022-03-23 02:23:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 02:23:20 --> Config Class Initialized
INFO - 2022-03-23 02:23:20 --> Hooks Class Initialized
DEBUG - 2022-03-23 02:23:20 --> UTF-8 Support Enabled
INFO - 2022-03-23 02:23:20 --> Utf8 Class Initialized
INFO - 2022-03-23 02:23:20 --> URI Class Initialized
INFO - 2022-03-23 02:23:20 --> Router Class Initialized
INFO - 2022-03-23 02:23:20 --> Output Class Initialized
INFO - 2022-03-23 02:23:20 --> Security Class Initialized
DEBUG - 2022-03-23 02:23:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 02:23:20 --> Input Class Initialized
INFO - 2022-03-23 02:23:20 --> Language Class Initialized
INFO - 2022-03-23 02:23:20 --> Loader Class Initialized
INFO - 2022-03-23 02:23:20 --> Helper loaded: url_helper
INFO - 2022-03-23 02:23:20 --> Helper loaded: form_helper
INFO - 2022-03-23 02:23:20 --> Helper loaded: common_helper
INFO - 2022-03-23 02:23:20 --> Database Driver Class Initialized
DEBUG - 2022-03-23 02:23:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 02:23:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 02:23:20 --> Controller Class Initialized
INFO - 2022-03-23 02:23:20 --> Form Validation Class Initialized
DEBUG - 2022-03-23 02:23:20 --> Encrypt Class Initialized
INFO - 2022-03-23 02:23:20 --> Model "Patient_model" initialized
INFO - 2022-03-23 02:23:20 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 02:23:20 --> Model "Prefix_master" initialized
INFO - 2022-03-23 02:23:20 --> Model "Users_model" initialized
INFO - 2022-03-23 02:23:20 --> Model "Hospital_model" initialized
INFO - 2022-03-23 02:23:20 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 02:23:20 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-23 02:23:20 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 02:23:20 --> Final output sent to browser
DEBUG - 2022-03-23 02:23:20 --> Total execution time: 0.0968
ERROR - 2022-03-23 02:23:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 02:23:29 --> Config Class Initialized
INFO - 2022-03-23 02:23:29 --> Hooks Class Initialized
DEBUG - 2022-03-23 02:23:29 --> UTF-8 Support Enabled
INFO - 2022-03-23 02:23:29 --> Utf8 Class Initialized
INFO - 2022-03-23 02:23:29 --> URI Class Initialized
INFO - 2022-03-23 02:23:29 --> Router Class Initialized
INFO - 2022-03-23 02:23:29 --> Output Class Initialized
INFO - 2022-03-23 02:23:29 --> Security Class Initialized
DEBUG - 2022-03-23 02:23:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 02:23:29 --> Input Class Initialized
INFO - 2022-03-23 02:23:29 --> Language Class Initialized
INFO - 2022-03-23 02:23:29 --> Loader Class Initialized
INFO - 2022-03-23 02:23:29 --> Helper loaded: url_helper
INFO - 2022-03-23 02:23:29 --> Helper loaded: form_helper
INFO - 2022-03-23 02:23:29 --> Helper loaded: common_helper
INFO - 2022-03-23 02:23:29 --> Database Driver Class Initialized
DEBUG - 2022-03-23 02:23:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 02:23:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 02:23:29 --> Controller Class Initialized
INFO - 2022-03-23 02:23:29 --> Form Validation Class Initialized
DEBUG - 2022-03-23 02:23:29 --> Encrypt Class Initialized
INFO - 2022-03-23 02:23:29 --> Model "Patient_model" initialized
INFO - 2022-03-23 02:23:29 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 02:23:29 --> Model "Referredby_model" initialized
INFO - 2022-03-23 02:23:29 --> Model "Prefix_master" initialized
INFO - 2022-03-23 02:23:29 --> Model "Hospital_model" initialized
INFO - 2022-03-23 02:23:29 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 02:23:29 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-23 02:23:29 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 02:23:29 --> Final output sent to browser
DEBUG - 2022-03-23 02:23:29 --> Total execution time: 0.0427
ERROR - 2022-03-23 02:24:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 02:24:06 --> Config Class Initialized
INFO - 2022-03-23 02:24:06 --> Hooks Class Initialized
DEBUG - 2022-03-23 02:24:06 --> UTF-8 Support Enabled
INFO - 2022-03-23 02:24:06 --> Utf8 Class Initialized
INFO - 2022-03-23 02:24:06 --> URI Class Initialized
INFO - 2022-03-23 02:24:06 --> Router Class Initialized
INFO - 2022-03-23 02:24:06 --> Output Class Initialized
INFO - 2022-03-23 02:24:06 --> Security Class Initialized
DEBUG - 2022-03-23 02:24:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 02:24:06 --> Input Class Initialized
INFO - 2022-03-23 02:24:06 --> Language Class Initialized
INFO - 2022-03-23 02:24:06 --> Loader Class Initialized
INFO - 2022-03-23 02:24:06 --> Helper loaded: url_helper
INFO - 2022-03-23 02:24:06 --> Helper loaded: form_helper
INFO - 2022-03-23 02:24:06 --> Helper loaded: common_helper
INFO - 2022-03-23 02:24:06 --> Database Driver Class Initialized
DEBUG - 2022-03-23 02:24:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 02:24:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 02:24:06 --> Controller Class Initialized
INFO - 2022-03-23 02:24:06 --> Form Validation Class Initialized
DEBUG - 2022-03-23 02:24:06 --> Encrypt Class Initialized
INFO - 2022-03-23 02:24:06 --> Model "Patient_model" initialized
INFO - 2022-03-23 02:24:06 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 02:24:06 --> Model "Referredby_model" initialized
INFO - 2022-03-23 02:24:06 --> Model "Prefix_master" initialized
INFO - 2022-03-23 02:24:06 --> Model "Hospital_model" initialized
INFO - 2022-03-23 02:24:06 --> Upload Class Initialized
INFO - 2022-03-23 02:24:06 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2022-03-23 02:24:06 --> The filetype you are attempting to upload is not allowed.
INFO - 2022-03-23 02:24:06 --> Final output sent to browser
DEBUG - 2022-03-23 02:24:06 --> Total execution time: 0.0237
ERROR - 2022-03-23 02:24:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 02:24:13 --> Config Class Initialized
INFO - 2022-03-23 02:24:13 --> Hooks Class Initialized
DEBUG - 2022-03-23 02:24:13 --> UTF-8 Support Enabled
INFO - 2022-03-23 02:24:13 --> Utf8 Class Initialized
INFO - 2022-03-23 02:24:13 --> URI Class Initialized
INFO - 2022-03-23 02:24:13 --> Router Class Initialized
INFO - 2022-03-23 02:24:13 --> Output Class Initialized
INFO - 2022-03-23 02:24:13 --> Security Class Initialized
DEBUG - 2022-03-23 02:24:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 02:24:13 --> Input Class Initialized
INFO - 2022-03-23 02:24:13 --> Language Class Initialized
INFO - 2022-03-23 02:24:13 --> Loader Class Initialized
INFO - 2022-03-23 02:24:13 --> Helper loaded: url_helper
INFO - 2022-03-23 02:24:13 --> Helper loaded: form_helper
INFO - 2022-03-23 02:24:13 --> Helper loaded: common_helper
INFO - 2022-03-23 02:24:13 --> Database Driver Class Initialized
DEBUG - 2022-03-23 02:24:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 02:24:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 02:24:13 --> Controller Class Initialized
INFO - 2022-03-23 02:24:13 --> Form Validation Class Initialized
DEBUG - 2022-03-23 02:24:13 --> Encrypt Class Initialized
INFO - 2022-03-23 02:24:13 --> Model "Patient_model" initialized
INFO - 2022-03-23 02:24:13 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 02:24:13 --> Model "Referredby_model" initialized
INFO - 2022-03-23 02:24:13 --> Model "Prefix_master" initialized
INFO - 2022-03-23 02:24:13 --> Model "Hospital_model" initialized
INFO - 2022-03-23 02:24:13 --> Upload Class Initialized
INFO - 2022-03-23 02:24:13 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2022-03-23 02:24:13 --> The filetype you are attempting to upload is not allowed.
INFO - 2022-03-23 02:24:13 --> Final output sent to browser
DEBUG - 2022-03-23 02:24:13 --> Total execution time: 0.0118
ERROR - 2022-03-23 02:24:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 02:24:14 --> Config Class Initialized
INFO - 2022-03-23 02:24:14 --> Hooks Class Initialized
DEBUG - 2022-03-23 02:24:14 --> UTF-8 Support Enabled
INFO - 2022-03-23 02:24:14 --> Utf8 Class Initialized
INFO - 2022-03-23 02:24:14 --> URI Class Initialized
INFO - 2022-03-23 02:24:14 --> Router Class Initialized
INFO - 2022-03-23 02:24:14 --> Output Class Initialized
INFO - 2022-03-23 02:24:14 --> Security Class Initialized
DEBUG - 2022-03-23 02:24:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 02:24:14 --> Input Class Initialized
INFO - 2022-03-23 02:24:14 --> Language Class Initialized
INFO - 2022-03-23 02:24:14 --> Loader Class Initialized
INFO - 2022-03-23 02:24:14 --> Helper loaded: url_helper
INFO - 2022-03-23 02:24:14 --> Helper loaded: form_helper
INFO - 2022-03-23 02:24:14 --> Helper loaded: common_helper
INFO - 2022-03-23 02:24:14 --> Database Driver Class Initialized
DEBUG - 2022-03-23 02:24:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 02:24:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 02:24:14 --> Controller Class Initialized
INFO - 2022-03-23 02:24:14 --> Form Validation Class Initialized
DEBUG - 2022-03-23 02:24:14 --> Encrypt Class Initialized
INFO - 2022-03-23 02:24:14 --> Model "Patient_model" initialized
INFO - 2022-03-23 02:24:14 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 02:24:14 --> Model "Referredby_model" initialized
INFO - 2022-03-23 02:24:14 --> Model "Prefix_master" initialized
INFO - 2022-03-23 02:24:14 --> Model "Hospital_model" initialized
INFO - 2022-03-23 02:24:14 --> Upload Class Initialized
INFO - 2022-03-23 02:24:14 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2022-03-23 02:24:14 --> The filetype you are attempting to upload is not allowed.
INFO - 2022-03-23 02:24:14 --> Final output sent to browser
DEBUG - 2022-03-23 02:24:14 --> Total execution time: 0.0088
ERROR - 2022-03-23 02:31:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 02:31:02 --> Config Class Initialized
INFO - 2022-03-23 02:31:02 --> Hooks Class Initialized
DEBUG - 2022-03-23 02:31:02 --> UTF-8 Support Enabled
INFO - 2022-03-23 02:31:02 --> Utf8 Class Initialized
INFO - 2022-03-23 02:31:02 --> URI Class Initialized
INFO - 2022-03-23 02:31:02 --> Router Class Initialized
INFO - 2022-03-23 02:31:02 --> Output Class Initialized
INFO - 2022-03-23 02:31:02 --> Security Class Initialized
DEBUG - 2022-03-23 02:31:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 02:31:02 --> Input Class Initialized
INFO - 2022-03-23 02:31:02 --> Language Class Initialized
INFO - 2022-03-23 02:31:02 --> Loader Class Initialized
INFO - 2022-03-23 02:31:02 --> Helper loaded: url_helper
INFO - 2022-03-23 02:31:02 --> Helper loaded: form_helper
INFO - 2022-03-23 02:31:02 --> Helper loaded: common_helper
INFO - 2022-03-23 02:31:02 --> Database Driver Class Initialized
DEBUG - 2022-03-23 02:31:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 02:31:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 02:31:02 --> Controller Class Initialized
INFO - 2022-03-23 02:31:02 --> Form Validation Class Initialized
DEBUG - 2022-03-23 02:31:02 --> Encrypt Class Initialized
INFO - 2022-03-23 02:31:02 --> Model "Patient_model" initialized
INFO - 2022-03-23 02:31:02 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 02:31:02 --> Model "Prefix_master" initialized
INFO - 2022-03-23 02:31:02 --> Model "Users_model" initialized
INFO - 2022-03-23 02:31:02 --> Model "Hospital_model" initialized
INFO - 2022-03-23 02:31:02 --> Upload Class Initialized
INFO - 2022-03-23 02:31:02 --> Final output sent to browser
DEBUG - 2022-03-23 02:31:02 --> Total execution time: 0.0809
ERROR - 2022-03-23 02:31:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 02:31:08 --> Config Class Initialized
INFO - 2022-03-23 02:31:08 --> Hooks Class Initialized
DEBUG - 2022-03-23 02:31:08 --> UTF-8 Support Enabled
INFO - 2022-03-23 02:31:08 --> Utf8 Class Initialized
INFO - 2022-03-23 02:31:08 --> URI Class Initialized
INFO - 2022-03-23 02:31:08 --> Router Class Initialized
INFO - 2022-03-23 02:31:08 --> Output Class Initialized
INFO - 2022-03-23 02:31:08 --> Security Class Initialized
DEBUG - 2022-03-23 02:31:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 02:31:08 --> Input Class Initialized
INFO - 2022-03-23 02:31:08 --> Language Class Initialized
INFO - 2022-03-23 02:31:08 --> Loader Class Initialized
INFO - 2022-03-23 02:31:08 --> Helper loaded: url_helper
INFO - 2022-03-23 02:31:08 --> Helper loaded: form_helper
INFO - 2022-03-23 02:31:08 --> Helper loaded: common_helper
INFO - 2022-03-23 02:31:08 --> Database Driver Class Initialized
DEBUG - 2022-03-23 02:31:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 02:31:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 02:31:08 --> Controller Class Initialized
INFO - 2022-03-23 02:31:08 --> Form Validation Class Initialized
DEBUG - 2022-03-23 02:31:08 --> Encrypt Class Initialized
INFO - 2022-03-23 02:31:08 --> Model "Patient_model" initialized
INFO - 2022-03-23 02:31:08 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 02:31:08 --> Model "Prefix_master" initialized
INFO - 2022-03-23 02:31:08 --> Model "Users_model" initialized
INFO - 2022-03-23 02:31:08 --> Model "Hospital_model" initialized
ERROR - 2022-03-23 02:31:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 02:31:08 --> Config Class Initialized
INFO - 2022-03-23 02:31:08 --> Hooks Class Initialized
DEBUG - 2022-03-23 02:31:08 --> UTF-8 Support Enabled
INFO - 2022-03-23 02:31:08 --> Utf8 Class Initialized
INFO - 2022-03-23 02:31:08 --> URI Class Initialized
INFO - 2022-03-23 02:31:08 --> Router Class Initialized
INFO - 2022-03-23 02:31:08 --> Output Class Initialized
INFO - 2022-03-23 02:31:08 --> Security Class Initialized
DEBUG - 2022-03-23 02:31:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 02:31:08 --> Input Class Initialized
INFO - 2022-03-23 02:31:08 --> Language Class Initialized
INFO - 2022-03-23 02:31:08 --> Loader Class Initialized
INFO - 2022-03-23 02:31:08 --> Helper loaded: url_helper
INFO - 2022-03-23 02:31:08 --> Helper loaded: form_helper
INFO - 2022-03-23 02:31:08 --> Helper loaded: common_helper
INFO - 2022-03-23 02:31:08 --> Database Driver Class Initialized
DEBUG - 2022-03-23 02:31:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 02:31:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 02:31:08 --> Controller Class Initialized
INFO - 2022-03-23 02:31:08 --> Form Validation Class Initialized
DEBUG - 2022-03-23 02:31:08 --> Encrypt Class Initialized
INFO - 2022-03-23 02:31:08 --> Model "Patient_model" initialized
INFO - 2022-03-23 02:31:08 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 02:31:08 --> Model "Prefix_master" initialized
INFO - 2022-03-23 02:31:08 --> Model "Users_model" initialized
INFO - 2022-03-23 02:31:08 --> Model "Hospital_model" initialized
INFO - 2022-03-23 02:31:08 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 02:31:08 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-23 02:31:08 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 02:31:08 --> Final output sent to browser
DEBUG - 2022-03-23 02:31:08 --> Total execution time: 0.0390
ERROR - 2022-03-23 03:15:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 03:15:25 --> Config Class Initialized
INFO - 2022-03-23 03:15:25 --> Hooks Class Initialized
DEBUG - 2022-03-23 03:15:25 --> UTF-8 Support Enabled
INFO - 2022-03-23 03:15:25 --> Utf8 Class Initialized
INFO - 2022-03-23 03:15:25 --> URI Class Initialized
INFO - 2022-03-23 03:15:25 --> Router Class Initialized
INFO - 2022-03-23 03:15:25 --> Output Class Initialized
INFO - 2022-03-23 03:15:25 --> Security Class Initialized
DEBUG - 2022-03-23 03:15:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 03:15:25 --> Input Class Initialized
INFO - 2022-03-23 03:15:25 --> Language Class Initialized
INFO - 2022-03-23 03:15:25 --> Loader Class Initialized
INFO - 2022-03-23 03:15:25 --> Helper loaded: url_helper
INFO - 2022-03-23 03:15:25 --> Helper loaded: form_helper
INFO - 2022-03-23 03:15:25 --> Helper loaded: common_helper
INFO - 2022-03-23 03:15:25 --> Database Driver Class Initialized
DEBUG - 2022-03-23 03:15:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 03:15:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 03:15:25 --> Controller Class Initialized
ERROR - 2022-03-23 03:15:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 03:15:25 --> Config Class Initialized
INFO - 2022-03-23 03:15:25 --> Hooks Class Initialized
DEBUG - 2022-03-23 03:15:25 --> UTF-8 Support Enabled
INFO - 2022-03-23 03:15:25 --> Utf8 Class Initialized
INFO - 2022-03-23 03:15:25 --> URI Class Initialized
INFO - 2022-03-23 03:15:25 --> Router Class Initialized
INFO - 2022-03-23 03:15:25 --> Output Class Initialized
INFO - 2022-03-23 03:15:25 --> Security Class Initialized
DEBUG - 2022-03-23 03:15:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 03:15:25 --> Input Class Initialized
INFO - 2022-03-23 03:15:25 --> Language Class Initialized
INFO - 2022-03-23 03:15:25 --> Loader Class Initialized
INFO - 2022-03-23 03:15:25 --> Helper loaded: url_helper
INFO - 2022-03-23 03:15:25 --> Helper loaded: form_helper
INFO - 2022-03-23 03:15:25 --> Helper loaded: common_helper
INFO - 2022-03-23 03:15:25 --> Database Driver Class Initialized
DEBUG - 2022-03-23 03:15:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 03:15:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 03:15:25 --> Controller Class Initialized
INFO - 2022-03-23 03:15:25 --> Form Validation Class Initialized
DEBUG - 2022-03-23 03:15:25 --> Encrypt Class Initialized
DEBUG - 2022-03-23 03:15:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 03:15:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-23 03:15:25 --> Email Class Initialized
INFO - 2022-03-23 03:15:25 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-23 03:15:25 --> Calendar Class Initialized
INFO - 2022-03-23 03:15:25 --> Model "Login_model" initialized
INFO - 2022-03-23 03:15:25 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-23 03:15:25 --> Final output sent to browser
DEBUG - 2022-03-23 03:15:25 --> Total execution time: 0.1695
ERROR - 2022-03-23 04:13:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 04:13:00 --> Config Class Initialized
INFO - 2022-03-23 04:13:00 --> Hooks Class Initialized
DEBUG - 2022-03-23 04:13:00 --> UTF-8 Support Enabled
INFO - 2022-03-23 04:13:00 --> Utf8 Class Initialized
INFO - 2022-03-23 04:13:00 --> URI Class Initialized
INFO - 2022-03-23 04:13:00 --> Router Class Initialized
INFO - 2022-03-23 04:13:00 --> Output Class Initialized
INFO - 2022-03-23 04:13:00 --> Security Class Initialized
DEBUG - 2022-03-23 04:13:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 04:13:00 --> Input Class Initialized
INFO - 2022-03-23 04:13:00 --> Language Class Initialized
INFO - 2022-03-23 04:13:00 --> Loader Class Initialized
INFO - 2022-03-23 04:13:00 --> Helper loaded: url_helper
INFO - 2022-03-23 04:13:00 --> Helper loaded: form_helper
INFO - 2022-03-23 04:13:00 --> Helper loaded: common_helper
INFO - 2022-03-23 04:13:00 --> Database Driver Class Initialized
DEBUG - 2022-03-23 04:13:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 04:13:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 04:13:00 --> Controller Class Initialized
ERROR - 2022-03-23 04:13:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 04:13:01 --> Config Class Initialized
INFO - 2022-03-23 04:13:01 --> Hooks Class Initialized
DEBUG - 2022-03-23 04:13:01 --> UTF-8 Support Enabled
INFO - 2022-03-23 04:13:01 --> Utf8 Class Initialized
INFO - 2022-03-23 04:13:01 --> URI Class Initialized
INFO - 2022-03-23 04:13:01 --> Router Class Initialized
INFO - 2022-03-23 04:13:01 --> Output Class Initialized
INFO - 2022-03-23 04:13:01 --> Security Class Initialized
DEBUG - 2022-03-23 04:13:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 04:13:01 --> Input Class Initialized
INFO - 2022-03-23 04:13:01 --> Language Class Initialized
INFO - 2022-03-23 04:13:01 --> Loader Class Initialized
INFO - 2022-03-23 04:13:01 --> Helper loaded: url_helper
INFO - 2022-03-23 04:13:01 --> Helper loaded: form_helper
INFO - 2022-03-23 04:13:01 --> Helper loaded: common_helper
INFO - 2022-03-23 04:13:01 --> Database Driver Class Initialized
DEBUG - 2022-03-23 04:13:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 04:13:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 04:13:01 --> Controller Class Initialized
INFO - 2022-03-23 04:13:01 --> Form Validation Class Initialized
DEBUG - 2022-03-23 04:13:01 --> Encrypt Class Initialized
DEBUG - 2022-03-23 04:13:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 04:13:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-23 04:13:01 --> Email Class Initialized
INFO - 2022-03-23 04:13:01 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-23 04:13:01 --> Calendar Class Initialized
INFO - 2022-03-23 04:13:01 --> Model "Login_model" initialized
INFO - 2022-03-23 04:13:01 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-23 04:13:01 --> Final output sent to browser
DEBUG - 2022-03-23 04:13:01 --> Total execution time: 0.0217
ERROR - 2022-03-23 04:13:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 04:13:03 --> Config Class Initialized
INFO - 2022-03-23 04:13:03 --> Hooks Class Initialized
DEBUG - 2022-03-23 04:13:03 --> UTF-8 Support Enabled
INFO - 2022-03-23 04:13:03 --> Utf8 Class Initialized
INFO - 2022-03-23 04:13:03 --> URI Class Initialized
INFO - 2022-03-23 04:13:03 --> Router Class Initialized
INFO - 2022-03-23 04:13:03 --> Output Class Initialized
INFO - 2022-03-23 04:13:03 --> Security Class Initialized
DEBUG - 2022-03-23 04:13:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 04:13:03 --> Input Class Initialized
INFO - 2022-03-23 04:13:03 --> Language Class Initialized
INFO - 2022-03-23 04:13:03 --> Loader Class Initialized
INFO - 2022-03-23 04:13:03 --> Helper loaded: url_helper
INFO - 2022-03-23 04:13:03 --> Helper loaded: form_helper
INFO - 2022-03-23 04:13:03 --> Helper loaded: common_helper
INFO - 2022-03-23 04:13:03 --> Database Driver Class Initialized
DEBUG - 2022-03-23 04:13:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 04:13:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 04:13:03 --> Controller Class Initialized
INFO - 2022-03-23 04:13:03 --> Form Validation Class Initialized
DEBUG - 2022-03-23 04:13:03 --> Encrypt Class Initialized
DEBUG - 2022-03-23 04:13:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 04:13:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-23 04:13:03 --> Email Class Initialized
INFO - 2022-03-23 04:13:03 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-23 04:13:03 --> Calendar Class Initialized
INFO - 2022-03-23 04:13:03 --> Model "Login_model" initialized
INFO - 2022-03-23 04:13:03 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-03-23 04:13:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 04:13:04 --> Config Class Initialized
INFO - 2022-03-23 04:13:04 --> Hooks Class Initialized
DEBUG - 2022-03-23 04:13:04 --> UTF-8 Support Enabled
INFO - 2022-03-23 04:13:04 --> Utf8 Class Initialized
INFO - 2022-03-23 04:13:04 --> URI Class Initialized
INFO - 2022-03-23 04:13:04 --> Router Class Initialized
INFO - 2022-03-23 04:13:04 --> Output Class Initialized
INFO - 2022-03-23 04:13:04 --> Security Class Initialized
DEBUG - 2022-03-23 04:13:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 04:13:04 --> Input Class Initialized
INFO - 2022-03-23 04:13:04 --> Language Class Initialized
INFO - 2022-03-23 04:13:04 --> Loader Class Initialized
INFO - 2022-03-23 04:13:04 --> Helper loaded: url_helper
INFO - 2022-03-23 04:13:04 --> Helper loaded: form_helper
INFO - 2022-03-23 04:13:04 --> Helper loaded: common_helper
INFO - 2022-03-23 04:13:04 --> Database Driver Class Initialized
DEBUG - 2022-03-23 04:13:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 04:13:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 04:13:04 --> Controller Class Initialized
INFO - 2022-03-23 04:13:04 --> Form Validation Class Initialized
DEBUG - 2022-03-23 04:13:04 --> Encrypt Class Initialized
DEBUG - 2022-03-23 04:13:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 04:13:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-23 04:13:04 --> Email Class Initialized
INFO - 2022-03-23 04:13:04 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-23 04:13:04 --> Calendar Class Initialized
INFO - 2022-03-23 04:13:04 --> Model "Login_model" initialized
INFO - 2022-03-23 04:13:04 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-03-23 04:13:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 04:13:04 --> Config Class Initialized
INFO - 2022-03-23 04:13:04 --> Hooks Class Initialized
DEBUG - 2022-03-23 04:13:04 --> UTF-8 Support Enabled
INFO - 2022-03-23 04:13:04 --> Utf8 Class Initialized
INFO - 2022-03-23 04:13:04 --> URI Class Initialized
INFO - 2022-03-23 04:13:04 --> Router Class Initialized
INFO - 2022-03-23 04:13:04 --> Output Class Initialized
INFO - 2022-03-23 04:13:04 --> Security Class Initialized
DEBUG - 2022-03-23 04:13:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 04:13:04 --> Input Class Initialized
INFO - 2022-03-23 04:13:04 --> Language Class Initialized
INFO - 2022-03-23 04:13:04 --> Loader Class Initialized
INFO - 2022-03-23 04:13:04 --> Helper loaded: url_helper
INFO - 2022-03-23 04:13:04 --> Helper loaded: form_helper
INFO - 2022-03-23 04:13:04 --> Helper loaded: common_helper
INFO - 2022-03-23 04:13:04 --> Database Driver Class Initialized
DEBUG - 2022-03-23 04:13:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 04:13:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 04:13:04 --> Controller Class Initialized
INFO - 2022-03-23 04:13:04 --> Form Validation Class Initialized
DEBUG - 2022-03-23 04:13:04 --> Encrypt Class Initialized
INFO - 2022-03-23 04:13:04 --> Model "Login_model" initialized
INFO - 2022-03-23 04:13:04 --> Model "Dashboard_model" initialized
INFO - 2022-03-23 04:13:04 --> Model "Case_model" initialized
INFO - 2022-03-23 04:13:14 --> File loaded: /home3/karoteam/public_html/application/views/header.php
ERROR - 2022-03-23 04:13:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 04:13:24 --> Config Class Initialized
INFO - 2022-03-23 04:13:24 --> Hooks Class Initialized
DEBUG - 2022-03-23 04:13:24 --> UTF-8 Support Enabled
INFO - 2022-03-23 04:13:24 --> Utf8 Class Initialized
INFO - 2022-03-23 04:13:24 --> URI Class Initialized
INFO - 2022-03-23 04:13:24 --> Router Class Initialized
INFO - 2022-03-23 04:13:24 --> Output Class Initialized
INFO - 2022-03-23 04:13:24 --> Security Class Initialized
DEBUG - 2022-03-23 04:13:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 04:13:24 --> Input Class Initialized
INFO - 2022-03-23 04:13:24 --> Language Class Initialized
INFO - 2022-03-23 04:13:24 --> Loader Class Initialized
INFO - 2022-03-23 04:13:24 --> Helper loaded: url_helper
INFO - 2022-03-23 04:13:24 --> Helper loaded: form_helper
INFO - 2022-03-23 04:13:24 --> Helper loaded: common_helper
INFO - 2022-03-23 04:13:24 --> Database Driver Class Initialized
DEBUG - 2022-03-23 04:13:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-03-23 04:13:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 04:13:24 --> Config Class Initialized
INFO - 2022-03-23 04:13:24 --> Hooks Class Initialized
DEBUG - 2022-03-23 04:13:24 --> UTF-8 Support Enabled
INFO - 2022-03-23 04:13:24 --> Utf8 Class Initialized
INFO - 2022-03-23 04:13:24 --> URI Class Initialized
INFO - 2022-03-23 04:13:24 --> Router Class Initialized
INFO - 2022-03-23 04:13:24 --> Output Class Initialized
INFO - 2022-03-23 04:13:24 --> Security Class Initialized
DEBUG - 2022-03-23 04:13:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 04:13:24 --> Input Class Initialized
INFO - 2022-03-23 04:13:24 --> Language Class Initialized
INFO - 2022-03-23 04:13:24 --> Loader Class Initialized
INFO - 2022-03-23 04:13:24 --> Helper loaded: url_helper
INFO - 2022-03-23 04:13:24 --> Helper loaded: form_helper
INFO - 2022-03-23 04:13:24 --> Helper loaded: common_helper
INFO - 2022-03-23 04:13:24 --> Database Driver Class Initialized
DEBUG - 2022-03-23 04:13:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 04:13:25 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2022-03-23 04:13:25 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 04:13:25 --> Final output sent to browser
DEBUG - 2022-03-23 04:13:25 --> Total execution time: 20.5469
INFO - 2022-03-23 04:13:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 04:13:25 --> Controller Class Initialized
INFO - 2022-03-23 04:13:25 --> Form Validation Class Initialized
DEBUG - 2022-03-23 04:13:25 --> Encrypt Class Initialized
DEBUG - 2022-03-23 04:13:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 04:13:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-23 04:13:25 --> Email Class Initialized
INFO - 2022-03-23 04:13:25 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-23 04:13:25 --> Calendar Class Initialized
INFO - 2022-03-23 04:13:25 --> Model "Login_model" initialized
INFO - 2022-03-23 04:13:25 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2022-03-23 04:13:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 04:13:25 --> Controller Class Initialized
INFO - 2022-03-23 04:13:25 --> Form Validation Class Initialized
DEBUG - 2022-03-23 04:13:25 --> Encrypt Class Initialized
DEBUG - 2022-03-23 04:13:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 04:13:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-23 04:13:25 --> Email Class Initialized
INFO - 2022-03-23 04:13:25 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-23 04:13:25 --> Calendar Class Initialized
INFO - 2022-03-23 04:13:25 --> Model "Login_model" initialized
INFO - 2022-03-23 04:13:25 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-03-23 04:13:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 04:13:25 --> Config Class Initialized
INFO - 2022-03-23 04:13:25 --> Hooks Class Initialized
DEBUG - 2022-03-23 04:13:25 --> UTF-8 Support Enabled
INFO - 2022-03-23 04:13:25 --> Utf8 Class Initialized
INFO - 2022-03-23 04:13:25 --> URI Class Initialized
INFO - 2022-03-23 04:13:25 --> Router Class Initialized
INFO - 2022-03-23 04:13:25 --> Output Class Initialized
INFO - 2022-03-23 04:13:25 --> Security Class Initialized
DEBUG - 2022-03-23 04:13:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 04:13:25 --> Input Class Initialized
INFO - 2022-03-23 04:13:25 --> Language Class Initialized
INFO - 2022-03-23 04:13:25 --> Loader Class Initialized
INFO - 2022-03-23 04:13:25 --> Helper loaded: url_helper
INFO - 2022-03-23 04:13:25 --> Helper loaded: form_helper
INFO - 2022-03-23 04:13:25 --> Helper loaded: common_helper
INFO - 2022-03-23 04:13:25 --> Database Driver Class Initialized
DEBUG - 2022-03-23 04:13:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 04:13:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 04:13:25 --> Controller Class Initialized
INFO - 2022-03-23 04:13:25 --> Form Validation Class Initialized
DEBUG - 2022-03-23 04:13:25 --> Encrypt Class Initialized
INFO - 2022-03-23 04:13:25 --> Model "Login_model" initialized
INFO - 2022-03-23 04:13:25 --> Model "Dashboard_model" initialized
INFO - 2022-03-23 04:13:25 --> Model "Case_model" initialized
INFO - 2022-03-23 04:13:34 --> File loaded: /home3/karoteam/public_html/application/views/header.php
ERROR - 2022-03-23 04:13:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 04:13:44 --> Config Class Initialized
INFO - 2022-03-23 04:13:44 --> Hooks Class Initialized
DEBUG - 2022-03-23 04:13:44 --> UTF-8 Support Enabled
INFO - 2022-03-23 04:13:44 --> Utf8 Class Initialized
INFO - 2022-03-23 04:13:44 --> URI Class Initialized
INFO - 2022-03-23 04:13:44 --> Router Class Initialized
INFO - 2022-03-23 04:13:44 --> Output Class Initialized
INFO - 2022-03-23 04:13:44 --> Security Class Initialized
DEBUG - 2022-03-23 04:13:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 04:13:44 --> Input Class Initialized
INFO - 2022-03-23 04:13:44 --> Language Class Initialized
INFO - 2022-03-23 04:13:44 --> Loader Class Initialized
INFO - 2022-03-23 04:13:44 --> Helper loaded: url_helper
INFO - 2022-03-23 04:13:44 --> Helper loaded: form_helper
INFO - 2022-03-23 04:13:44 --> Helper loaded: common_helper
INFO - 2022-03-23 04:13:44 --> Database Driver Class Initialized
DEBUG - 2022-03-23 04:13:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-03-23 04:13:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 04:13:44 --> Config Class Initialized
INFO - 2022-03-23 04:13:44 --> Hooks Class Initialized
DEBUG - 2022-03-23 04:13:44 --> UTF-8 Support Enabled
INFO - 2022-03-23 04:13:44 --> Utf8 Class Initialized
INFO - 2022-03-23 04:13:44 --> URI Class Initialized
INFO - 2022-03-23 04:13:44 --> Router Class Initialized
INFO - 2022-03-23 04:13:44 --> Output Class Initialized
INFO - 2022-03-23 04:13:44 --> Security Class Initialized
DEBUG - 2022-03-23 04:13:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 04:13:44 --> Input Class Initialized
INFO - 2022-03-23 04:13:44 --> Language Class Initialized
INFO - 2022-03-23 04:13:44 --> Loader Class Initialized
INFO - 2022-03-23 04:13:44 --> Helper loaded: url_helper
INFO - 2022-03-23 04:13:44 --> Helper loaded: form_helper
INFO - 2022-03-23 04:13:44 --> Helper loaded: common_helper
INFO - 2022-03-23 04:13:44 --> Database Driver Class Initialized
DEBUG - 2022-03-23 04:13:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-03-23 04:13:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 04:13:45 --> Config Class Initialized
INFO - 2022-03-23 04:13:45 --> Hooks Class Initialized
DEBUG - 2022-03-23 04:13:45 --> UTF-8 Support Enabled
INFO - 2022-03-23 04:13:45 --> Utf8 Class Initialized
INFO - 2022-03-23 04:13:45 --> URI Class Initialized
INFO - 2022-03-23 04:13:45 --> Router Class Initialized
INFO - 2022-03-23 04:13:45 --> Output Class Initialized
INFO - 2022-03-23 04:13:45 --> Security Class Initialized
DEBUG - 2022-03-23 04:13:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 04:13:45 --> Input Class Initialized
INFO - 2022-03-23 04:13:45 --> Language Class Initialized
INFO - 2022-03-23 04:13:45 --> Loader Class Initialized
INFO - 2022-03-23 04:13:45 --> Helper loaded: url_helper
INFO - 2022-03-23 04:13:45 --> Helper loaded: form_helper
INFO - 2022-03-23 04:13:45 --> Helper loaded: common_helper
INFO - 2022-03-23 04:13:45 --> Database Driver Class Initialized
DEBUG - 2022-03-23 04:13:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 04:13:46 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2022-03-23 04:13:46 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 04:13:46 --> Final output sent to browser
DEBUG - 2022-03-23 04:13:46 --> Total execution time: 20.6559
INFO - 2022-03-23 04:13:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 04:13:46 --> Controller Class Initialized
INFO - 2022-03-23 04:13:46 --> Form Validation Class Initialized
DEBUG - 2022-03-23 04:13:46 --> Encrypt Class Initialized
DEBUG - 2022-03-23 04:13:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 04:13:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-23 04:13:46 --> Email Class Initialized
INFO - 2022-03-23 04:13:46 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-23 04:13:46 --> Calendar Class Initialized
INFO - 2022-03-23 04:13:46 --> Model "Login_model" initialized
INFO - 2022-03-23 04:13:46 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2022-03-23 04:13:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 04:13:46 --> Controller Class Initialized
INFO - 2022-03-23 04:13:46 --> Form Validation Class Initialized
DEBUG - 2022-03-23 04:13:46 --> Encrypt Class Initialized
DEBUG - 2022-03-23 04:13:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 04:13:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-23 04:13:46 --> Email Class Initialized
INFO - 2022-03-23 04:13:46 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-23 04:13:46 --> Calendar Class Initialized
INFO - 2022-03-23 04:13:46 --> Model "Login_model" initialized
INFO - 2022-03-23 04:13:46 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2022-03-23 04:13:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 04:13:46 --> Controller Class Initialized
INFO - 2022-03-23 04:13:46 --> Form Validation Class Initialized
DEBUG - 2022-03-23 04:13:46 --> Encrypt Class Initialized
DEBUG - 2022-03-23 04:13:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 04:13:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-23 04:13:46 --> Email Class Initialized
INFO - 2022-03-23 04:13:46 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-23 04:13:46 --> Calendar Class Initialized
INFO - 2022-03-23 04:13:46 --> Model "Login_model" initialized
INFO - 2022-03-23 04:13:46 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-03-23 04:13:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 04:13:46 --> Config Class Initialized
INFO - 2022-03-23 04:13:46 --> Hooks Class Initialized
DEBUG - 2022-03-23 04:13:46 --> UTF-8 Support Enabled
INFO - 2022-03-23 04:13:46 --> Utf8 Class Initialized
INFO - 2022-03-23 04:13:46 --> URI Class Initialized
INFO - 2022-03-23 04:13:46 --> Router Class Initialized
INFO - 2022-03-23 04:13:46 --> Output Class Initialized
INFO - 2022-03-23 04:13:46 --> Security Class Initialized
DEBUG - 2022-03-23 04:13:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 04:13:46 --> Input Class Initialized
INFO - 2022-03-23 04:13:46 --> Language Class Initialized
INFO - 2022-03-23 04:13:46 --> Loader Class Initialized
INFO - 2022-03-23 04:13:46 --> Helper loaded: url_helper
INFO - 2022-03-23 04:13:46 --> Helper loaded: form_helper
INFO - 2022-03-23 04:13:46 --> Helper loaded: common_helper
INFO - 2022-03-23 04:13:46 --> Database Driver Class Initialized
DEBUG - 2022-03-23 04:13:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 04:13:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 04:13:46 --> Controller Class Initialized
INFO - 2022-03-23 04:13:46 --> Form Validation Class Initialized
DEBUG - 2022-03-23 04:13:46 --> Encrypt Class Initialized
INFO - 2022-03-23 04:13:46 --> Model "Login_model" initialized
INFO - 2022-03-23 04:13:46 --> Model "Dashboard_model" initialized
INFO - 2022-03-23 04:13:46 --> Model "Case_model" initialized
ERROR - 2022-03-23 04:13:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 04:13:53 --> Config Class Initialized
INFO - 2022-03-23 04:13:53 --> Hooks Class Initialized
DEBUG - 2022-03-23 04:13:53 --> UTF-8 Support Enabled
INFO - 2022-03-23 04:13:53 --> Utf8 Class Initialized
INFO - 2022-03-23 04:13:53 --> URI Class Initialized
INFO - 2022-03-23 04:13:53 --> Router Class Initialized
INFO - 2022-03-23 04:13:53 --> Output Class Initialized
INFO - 2022-03-23 04:13:53 --> Security Class Initialized
DEBUG - 2022-03-23 04:13:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 04:13:53 --> Input Class Initialized
INFO - 2022-03-23 04:13:53 --> Language Class Initialized
INFO - 2022-03-23 04:13:53 --> Loader Class Initialized
INFO - 2022-03-23 04:13:53 --> Helper loaded: url_helper
INFO - 2022-03-23 04:13:53 --> Helper loaded: form_helper
INFO - 2022-03-23 04:13:53 --> Helper loaded: common_helper
INFO - 2022-03-23 04:13:53 --> Database Driver Class Initialized
DEBUG - 2022-03-23 04:13:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 04:13:55 --> File loaded: /home3/karoteam/public_html/application/views/header.php
ERROR - 2022-03-23 04:13:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 04:13:59 --> Config Class Initialized
INFO - 2022-03-23 04:13:59 --> Hooks Class Initialized
DEBUG - 2022-03-23 04:13:59 --> UTF-8 Support Enabled
INFO - 2022-03-23 04:13:59 --> Utf8 Class Initialized
INFO - 2022-03-23 04:13:59 --> URI Class Initialized
INFO - 2022-03-23 04:13:59 --> Router Class Initialized
INFO - 2022-03-23 04:13:59 --> Output Class Initialized
INFO - 2022-03-23 04:13:59 --> Security Class Initialized
DEBUG - 2022-03-23 04:13:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 04:13:59 --> Input Class Initialized
INFO - 2022-03-23 04:13:59 --> Language Class Initialized
INFO - 2022-03-23 04:13:59 --> Loader Class Initialized
INFO - 2022-03-23 04:13:59 --> Helper loaded: url_helper
INFO - 2022-03-23 04:13:59 --> Helper loaded: form_helper
INFO - 2022-03-23 04:13:59 --> Helper loaded: common_helper
INFO - 2022-03-23 04:13:59 --> Database Driver Class Initialized
DEBUG - 2022-03-23 04:13:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 04:14:05 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2022-03-23 04:14:05 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 04:14:05 --> Final output sent to browser
DEBUG - 2022-03-23 04:14:05 --> Total execution time: 19.4052
INFO - 2022-03-23 04:14:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 04:14:05 --> Controller Class Initialized
INFO - 2022-03-23 04:14:05 --> Form Validation Class Initialized
DEBUG - 2022-03-23 04:14:05 --> Encrypt Class Initialized
INFO - 2022-03-23 04:14:05 --> Model "Patient_model" initialized
INFO - 2022-03-23 04:14:05 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 04:14:05 --> Model "Referredby_model" initialized
INFO - 2022-03-23 04:14:05 --> Model "Prefix_master" initialized
INFO - 2022-03-23 04:14:05 --> Model "Hospital_model" initialized
INFO - 2022-03-23 04:14:05 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 04:14:05 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-23 04:14:05 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 04:14:05 --> Final output sent to browser
DEBUG - 2022-03-23 04:14:05 --> Total execution time: 12.5818
INFO - 2022-03-23 04:14:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 04:14:05 --> Controller Class Initialized
INFO - 2022-03-23 04:14:05 --> Form Validation Class Initialized
DEBUG - 2022-03-23 04:14:05 --> Encrypt Class Initialized
INFO - 2022-03-23 04:14:05 --> Model "Patient_model" initialized
INFO - 2022-03-23 04:14:05 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 04:14:05 --> Model "Prefix_master" initialized
INFO - 2022-03-23 04:14:05 --> Model "Users_model" initialized
INFO - 2022-03-23 04:14:05 --> Model "Hospital_model" initialized
INFO - 2022-03-23 04:14:06 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 04:14:06 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-23 04:14:06 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 04:14:06 --> Final output sent to browser
DEBUG - 2022-03-23 04:14:06 --> Total execution time: 6.5715
ERROR - 2022-03-23 04:14:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 04:14:12 --> Config Class Initialized
INFO - 2022-03-23 04:14:12 --> Hooks Class Initialized
DEBUG - 2022-03-23 04:14:12 --> UTF-8 Support Enabled
INFO - 2022-03-23 04:14:12 --> Utf8 Class Initialized
INFO - 2022-03-23 04:14:12 --> URI Class Initialized
INFO - 2022-03-23 04:14:12 --> Router Class Initialized
INFO - 2022-03-23 04:14:12 --> Output Class Initialized
INFO - 2022-03-23 04:14:12 --> Security Class Initialized
DEBUG - 2022-03-23 04:14:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 04:14:12 --> Input Class Initialized
INFO - 2022-03-23 04:14:12 --> Language Class Initialized
INFO - 2022-03-23 04:14:12 --> Loader Class Initialized
INFO - 2022-03-23 04:14:12 --> Helper loaded: url_helper
INFO - 2022-03-23 04:14:12 --> Helper loaded: form_helper
INFO - 2022-03-23 04:14:12 --> Helper loaded: common_helper
INFO - 2022-03-23 04:14:12 --> Database Driver Class Initialized
DEBUG - 2022-03-23 04:14:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 04:14:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 04:14:12 --> Controller Class Initialized
INFO - 2022-03-23 04:14:12 --> Form Validation Class Initialized
DEBUG - 2022-03-23 04:14:12 --> Encrypt Class Initialized
INFO - 2022-03-23 04:14:12 --> Model "Patient_model" initialized
INFO - 2022-03-23 04:14:12 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 04:14:12 --> Model "Prefix_master" initialized
INFO - 2022-03-23 04:14:12 --> Model "Users_model" initialized
INFO - 2022-03-23 04:14:12 --> Model "Hospital_model" initialized
INFO - 2022-03-23 04:14:12 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 04:14:12 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-23 04:14:12 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 04:14:12 --> Final output sent to browser
DEBUG - 2022-03-23 04:14:12 --> Total execution time: 0.0402
ERROR - 2022-03-23 04:14:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 04:14:16 --> Config Class Initialized
INFO - 2022-03-23 04:14:16 --> Hooks Class Initialized
DEBUG - 2022-03-23 04:14:16 --> UTF-8 Support Enabled
INFO - 2022-03-23 04:14:16 --> Utf8 Class Initialized
INFO - 2022-03-23 04:14:16 --> URI Class Initialized
INFO - 2022-03-23 04:14:16 --> Router Class Initialized
INFO - 2022-03-23 04:14:16 --> Output Class Initialized
INFO - 2022-03-23 04:14:16 --> Security Class Initialized
DEBUG - 2022-03-23 04:14:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 04:14:16 --> Input Class Initialized
INFO - 2022-03-23 04:14:16 --> Language Class Initialized
INFO - 2022-03-23 04:14:16 --> Loader Class Initialized
INFO - 2022-03-23 04:14:16 --> Helper loaded: url_helper
INFO - 2022-03-23 04:14:16 --> Helper loaded: form_helper
INFO - 2022-03-23 04:14:16 --> Helper loaded: common_helper
INFO - 2022-03-23 04:14:16 --> Database Driver Class Initialized
DEBUG - 2022-03-23 04:14:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 04:14:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 04:14:16 --> Controller Class Initialized
INFO - 2022-03-23 04:14:16 --> Form Validation Class Initialized
DEBUG - 2022-03-23 04:14:16 --> Encrypt Class Initialized
INFO - 2022-03-23 04:14:16 --> Model "Patient_model" initialized
INFO - 2022-03-23 04:14:16 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 04:14:16 --> Model "Referredby_model" initialized
INFO - 2022-03-23 04:14:16 --> Model "Prefix_master" initialized
INFO - 2022-03-23 04:14:16 --> Model "Hospital_model" initialized
INFO - 2022-03-23 04:14:16 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 04:14:16 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-23 04:14:16 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 04:14:16 --> Final output sent to browser
DEBUG - 2022-03-23 04:14:16 --> Total execution time: 0.0339
ERROR - 2022-03-23 04:17:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 04:17:23 --> Config Class Initialized
INFO - 2022-03-23 04:17:23 --> Hooks Class Initialized
DEBUG - 2022-03-23 04:17:23 --> UTF-8 Support Enabled
INFO - 2022-03-23 04:17:23 --> Utf8 Class Initialized
INFO - 2022-03-23 04:17:23 --> URI Class Initialized
DEBUG - 2022-03-23 04:17:23 --> No URI present. Default controller set.
INFO - 2022-03-23 04:17:23 --> Router Class Initialized
INFO - 2022-03-23 04:17:23 --> Output Class Initialized
INFO - 2022-03-23 04:17:23 --> Security Class Initialized
DEBUG - 2022-03-23 04:17:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 04:17:23 --> Input Class Initialized
INFO - 2022-03-23 04:17:23 --> Language Class Initialized
INFO - 2022-03-23 04:17:23 --> Loader Class Initialized
INFO - 2022-03-23 04:17:23 --> Helper loaded: url_helper
INFO - 2022-03-23 04:17:23 --> Helper loaded: form_helper
INFO - 2022-03-23 04:17:23 --> Helper loaded: common_helper
INFO - 2022-03-23 04:17:23 --> Database Driver Class Initialized
DEBUG - 2022-03-23 04:17:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 04:17:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 04:17:23 --> Controller Class Initialized
INFO - 2022-03-23 04:17:23 --> Form Validation Class Initialized
DEBUG - 2022-03-23 04:17:23 --> Encrypt Class Initialized
DEBUG - 2022-03-23 04:17:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 04:17:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-23 04:17:23 --> Email Class Initialized
INFO - 2022-03-23 04:17:23 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-23 04:17:23 --> Calendar Class Initialized
INFO - 2022-03-23 04:17:23 --> Model "Login_model" initialized
INFO - 2022-03-23 04:17:23 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-23 04:17:23 --> Final output sent to browser
DEBUG - 2022-03-23 04:17:23 --> Total execution time: 0.0620
ERROR - 2022-03-23 04:21:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 04:21:19 --> Config Class Initialized
INFO - 2022-03-23 04:21:19 --> Hooks Class Initialized
DEBUG - 2022-03-23 04:21:19 --> UTF-8 Support Enabled
INFO - 2022-03-23 04:21:19 --> Utf8 Class Initialized
INFO - 2022-03-23 04:21:19 --> URI Class Initialized
INFO - 2022-03-23 04:21:19 --> Router Class Initialized
INFO - 2022-03-23 04:21:19 --> Output Class Initialized
INFO - 2022-03-23 04:21:19 --> Security Class Initialized
DEBUG - 2022-03-23 04:21:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 04:21:19 --> Input Class Initialized
INFO - 2022-03-23 04:21:19 --> Language Class Initialized
INFO - 2022-03-23 04:21:19 --> Loader Class Initialized
INFO - 2022-03-23 04:21:19 --> Helper loaded: url_helper
INFO - 2022-03-23 04:21:19 --> Helper loaded: form_helper
INFO - 2022-03-23 04:21:19 --> Helper loaded: common_helper
INFO - 2022-03-23 04:21:19 --> Database Driver Class Initialized
DEBUG - 2022-03-23 04:21:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 04:21:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 04:21:19 --> Controller Class Initialized
INFO - 2022-03-23 04:21:19 --> Form Validation Class Initialized
DEBUG - 2022-03-23 04:21:19 --> Encrypt Class Initialized
INFO - 2022-03-23 04:21:19 --> Model "Patient_model" initialized
INFO - 2022-03-23 04:21:19 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 04:21:19 --> Model "Referredby_model" initialized
INFO - 2022-03-23 04:21:19 --> Model "Prefix_master" initialized
INFO - 2022-03-23 04:21:19 --> Model "Hospital_model" initialized
INFO - 2022-03-23 04:21:19 --> File loaded: /home3/karoteam/public_html/application/views/header.php
ERROR - 2022-03-23 04:21:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 04:21:23 --> Config Class Initialized
INFO - 2022-03-23 04:21:23 --> Hooks Class Initialized
DEBUG - 2022-03-23 04:21:23 --> UTF-8 Support Enabled
INFO - 2022-03-23 04:21:23 --> Utf8 Class Initialized
INFO - 2022-03-23 04:21:23 --> URI Class Initialized
INFO - 2022-03-23 04:21:23 --> Router Class Initialized
INFO - 2022-03-23 04:21:23 --> Output Class Initialized
INFO - 2022-03-23 04:21:23 --> Security Class Initialized
DEBUG - 2022-03-23 04:21:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 04:21:23 --> Input Class Initialized
INFO - 2022-03-23 04:21:23 --> Language Class Initialized
INFO - 2022-03-23 04:21:23 --> Loader Class Initialized
INFO - 2022-03-23 04:21:23 --> Helper loaded: url_helper
INFO - 2022-03-23 04:21:23 --> Helper loaded: form_helper
INFO - 2022-03-23 04:21:23 --> Helper loaded: common_helper
INFO - 2022-03-23 04:21:23 --> Database Driver Class Initialized
DEBUG - 2022-03-23 04:21:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 04:21:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 04:21:23 --> Controller Class Initialized
INFO - 2022-03-23 04:21:23 --> Form Validation Class Initialized
DEBUG - 2022-03-23 04:21:23 --> Encrypt Class Initialized
INFO - 2022-03-23 04:21:23 --> Model "Patient_model" initialized
INFO - 2022-03-23 04:21:23 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 04:21:23 --> Model "Referredby_model" initialized
INFO - 2022-03-23 04:21:23 --> Model "Prefix_master" initialized
INFO - 2022-03-23 04:21:23 --> Model "Hospital_model" initialized
INFO - 2022-03-23 04:21:23 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 04:21:25 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-23 04:21:25 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 04:21:25 --> Final output sent to browser
DEBUG - 2022-03-23 04:21:25 --> Total execution time: 6.1996
ERROR - 2022-03-23 04:21:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 04:21:25 --> Config Class Initialized
INFO - 2022-03-23 04:21:25 --> Hooks Class Initialized
DEBUG - 2022-03-23 04:21:25 --> UTF-8 Support Enabled
INFO - 2022-03-23 04:21:25 --> Utf8 Class Initialized
INFO - 2022-03-23 04:21:25 --> URI Class Initialized
INFO - 2022-03-23 04:21:25 --> Router Class Initialized
INFO - 2022-03-23 04:21:25 --> Output Class Initialized
INFO - 2022-03-23 04:21:25 --> Security Class Initialized
DEBUG - 2022-03-23 04:21:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 04:21:25 --> Input Class Initialized
INFO - 2022-03-23 04:21:25 --> Language Class Initialized
INFO - 2022-03-23 04:21:25 --> Loader Class Initialized
INFO - 2022-03-23 04:21:25 --> Helper loaded: url_helper
INFO - 2022-03-23 04:21:25 --> Helper loaded: form_helper
INFO - 2022-03-23 04:21:25 --> Helper loaded: common_helper
INFO - 2022-03-23 04:21:25 --> Database Driver Class Initialized
DEBUG - 2022-03-23 04:21:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 04:21:29 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-23 04:21:29 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 04:21:30 --> Final output sent to browser
DEBUG - 2022-03-23 04:21:30 --> Total execution time: 5.9066
INFO - 2022-03-23 04:21:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 04:21:30 --> Controller Class Initialized
INFO - 2022-03-23 04:21:30 --> Form Validation Class Initialized
DEBUG - 2022-03-23 04:21:30 --> Encrypt Class Initialized
INFO - 2022-03-23 04:21:30 --> Model "Patient_model" initialized
INFO - 2022-03-23 04:21:30 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 04:21:30 --> Model "Referredby_model" initialized
INFO - 2022-03-23 04:21:30 --> Model "Prefix_master" initialized
INFO - 2022-03-23 04:21:30 --> Model "Hospital_model" initialized
ERROR - 2022-03-23 04:21:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 04:21:30 --> Config Class Initialized
INFO - 2022-03-23 04:21:30 --> Hooks Class Initialized
DEBUG - 2022-03-23 04:21:30 --> UTF-8 Support Enabled
INFO - 2022-03-23 04:21:30 --> Utf8 Class Initialized
INFO - 2022-03-23 04:21:30 --> URI Class Initialized
INFO - 2022-03-23 04:21:30 --> Router Class Initialized
INFO - 2022-03-23 04:21:30 --> Output Class Initialized
INFO - 2022-03-23 04:21:30 --> Security Class Initialized
DEBUG - 2022-03-23 04:21:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 04:21:30 --> Input Class Initialized
INFO - 2022-03-23 04:21:30 --> Language Class Initialized
INFO - 2022-03-23 04:21:30 --> Loader Class Initialized
INFO - 2022-03-23 04:21:30 --> Helper loaded: url_helper
INFO - 2022-03-23 04:21:30 --> Helper loaded: form_helper
INFO - 2022-03-23 04:21:30 --> Helper loaded: common_helper
INFO - 2022-03-23 04:21:30 --> Database Driver Class Initialized
DEBUG - 2022-03-23 04:21:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 04:21:30 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 04:21:36 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-23 04:21:36 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 04:21:36 --> Final output sent to browser
DEBUG - 2022-03-23 04:21:36 --> Total execution time: 10.0926
INFO - 2022-03-23 04:21:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 04:21:36 --> Controller Class Initialized
INFO - 2022-03-23 04:21:36 --> Form Validation Class Initialized
DEBUG - 2022-03-23 04:21:36 --> Encrypt Class Initialized
INFO - 2022-03-23 04:21:36 --> Model "Patient_model" initialized
INFO - 2022-03-23 04:21:36 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 04:21:36 --> Model "Referredby_model" initialized
INFO - 2022-03-23 04:21:36 --> Model "Prefix_master" initialized
INFO - 2022-03-23 04:21:36 --> Model "Hospital_model" initialized
ERROR - 2022-03-23 04:21:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 04:21:36 --> Config Class Initialized
INFO - 2022-03-23 04:21:36 --> Hooks Class Initialized
DEBUG - 2022-03-23 04:21:36 --> UTF-8 Support Enabled
INFO - 2022-03-23 04:21:36 --> Utf8 Class Initialized
INFO - 2022-03-23 04:21:36 --> URI Class Initialized
INFO - 2022-03-23 04:21:36 --> Router Class Initialized
INFO - 2022-03-23 04:21:36 --> Output Class Initialized
INFO - 2022-03-23 04:21:36 --> Security Class Initialized
DEBUG - 2022-03-23 04:21:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 04:21:36 --> Input Class Initialized
INFO - 2022-03-23 04:21:36 --> Language Class Initialized
INFO - 2022-03-23 04:21:36 --> Loader Class Initialized
INFO - 2022-03-23 04:21:36 --> Helper loaded: url_helper
INFO - 2022-03-23 04:21:36 --> Helper loaded: form_helper
INFO - 2022-03-23 04:21:36 --> Helper loaded: common_helper
INFO - 2022-03-23 04:21:36 --> Database Driver Class Initialized
DEBUG - 2022-03-23 04:21:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 04:21:36 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 04:21:42 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-23 04:21:42 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 04:21:43 --> Final output sent to browser
DEBUG - 2022-03-23 04:21:43 --> Total execution time: 12.5693
INFO - 2022-03-23 04:21:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 04:21:43 --> Controller Class Initialized
INFO - 2022-03-23 04:21:43 --> Form Validation Class Initialized
DEBUG - 2022-03-23 04:21:43 --> Encrypt Class Initialized
INFO - 2022-03-23 04:21:43 --> Model "Patient_model" initialized
INFO - 2022-03-23 04:21:43 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 04:21:43 --> Model "Referredby_model" initialized
INFO - 2022-03-23 04:21:43 --> Model "Prefix_master" initialized
INFO - 2022-03-23 04:21:43 --> Model "Hospital_model" initialized
INFO - 2022-03-23 04:21:43 --> File loaded: /home3/karoteam/public_html/application/views/header.php
ERROR - 2022-03-23 04:21:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 04:21:44 --> Config Class Initialized
INFO - 2022-03-23 04:21:44 --> Hooks Class Initialized
DEBUG - 2022-03-23 04:21:44 --> UTF-8 Support Enabled
INFO - 2022-03-23 04:21:44 --> Utf8 Class Initialized
INFO - 2022-03-23 04:21:44 --> URI Class Initialized
INFO - 2022-03-23 04:21:44 --> Router Class Initialized
INFO - 2022-03-23 04:21:44 --> Output Class Initialized
INFO - 2022-03-23 04:21:44 --> Security Class Initialized
DEBUG - 2022-03-23 04:21:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 04:21:44 --> Input Class Initialized
INFO - 2022-03-23 04:21:44 --> Language Class Initialized
INFO - 2022-03-23 04:21:44 --> Loader Class Initialized
INFO - 2022-03-23 04:21:44 --> Helper loaded: url_helper
INFO - 2022-03-23 04:21:44 --> Helper loaded: form_helper
INFO - 2022-03-23 04:21:44 --> Helper loaded: common_helper
INFO - 2022-03-23 04:21:44 --> Database Driver Class Initialized
DEBUG - 2022-03-23 04:21:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 04:21:49 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-23 04:21:49 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 04:21:50 --> Final output sent to browser
DEBUG - 2022-03-23 04:21:50 --> Total execution time: 13.0267
INFO - 2022-03-23 04:21:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 04:21:50 --> Controller Class Initialized
INFO - 2022-03-23 04:21:50 --> Form Validation Class Initialized
DEBUG - 2022-03-23 04:21:50 --> Encrypt Class Initialized
INFO - 2022-03-23 04:21:50 --> Model "Patient_model" initialized
INFO - 2022-03-23 04:21:50 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 04:21:50 --> Model "Referredby_model" initialized
INFO - 2022-03-23 04:21:50 --> Model "Prefix_master" initialized
INFO - 2022-03-23 04:21:50 --> Model "Hospital_model" initialized
ERROR - 2022-03-23 04:21:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 04:21:50 --> Config Class Initialized
INFO - 2022-03-23 04:21:50 --> Hooks Class Initialized
DEBUG - 2022-03-23 04:21:50 --> UTF-8 Support Enabled
INFO - 2022-03-23 04:21:50 --> Utf8 Class Initialized
INFO - 2022-03-23 04:21:50 --> URI Class Initialized
INFO - 2022-03-23 04:21:50 --> Router Class Initialized
INFO - 2022-03-23 04:21:50 --> Output Class Initialized
INFO - 2022-03-23 04:21:50 --> Security Class Initialized
DEBUG - 2022-03-23 04:21:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 04:21:50 --> Input Class Initialized
INFO - 2022-03-23 04:21:50 --> Language Class Initialized
INFO - 2022-03-23 04:21:50 --> Loader Class Initialized
INFO - 2022-03-23 04:21:50 --> Helper loaded: url_helper
INFO - 2022-03-23 04:21:50 --> Helper loaded: form_helper
INFO - 2022-03-23 04:21:50 --> Helper loaded: common_helper
INFO - 2022-03-23 04:21:50 --> Database Driver Class Initialized
DEBUG - 2022-03-23 04:21:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 04:21:50 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 04:21:56 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-23 04:21:56 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 04:21:57 --> Final output sent to browser
DEBUG - 2022-03-23 04:21:57 --> Total execution time: 12.3332
INFO - 2022-03-23 04:21:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 04:21:57 --> Controller Class Initialized
INFO - 2022-03-23 04:21:57 --> Form Validation Class Initialized
DEBUG - 2022-03-23 04:21:57 --> Encrypt Class Initialized
INFO - 2022-03-23 04:21:57 --> Model "Patient_model" initialized
INFO - 2022-03-23 04:21:57 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 04:21:57 --> Model "Referredby_model" initialized
INFO - 2022-03-23 04:21:57 --> Model "Prefix_master" initialized
INFO - 2022-03-23 04:21:57 --> Model "Hospital_model" initialized
ERROR - 2022-03-23 04:21:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 04:21:57 --> Config Class Initialized
INFO - 2022-03-23 04:21:57 --> Hooks Class Initialized
DEBUG - 2022-03-23 04:21:57 --> UTF-8 Support Enabled
INFO - 2022-03-23 04:21:57 --> Utf8 Class Initialized
INFO - 2022-03-23 04:21:57 --> URI Class Initialized
INFO - 2022-03-23 04:21:57 --> Router Class Initialized
INFO - 2022-03-23 04:21:57 --> Output Class Initialized
INFO - 2022-03-23 04:21:57 --> Security Class Initialized
DEBUG - 2022-03-23 04:21:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 04:21:57 --> Input Class Initialized
INFO - 2022-03-23 04:21:57 --> Language Class Initialized
INFO - 2022-03-23 04:21:57 --> Loader Class Initialized
INFO - 2022-03-23 04:21:57 --> Helper loaded: url_helper
INFO - 2022-03-23 04:21:57 --> Helper loaded: form_helper
INFO - 2022-03-23 04:21:57 --> Helper loaded: common_helper
INFO - 2022-03-23 04:21:57 --> Database Driver Class Initialized
INFO - 2022-03-23 04:21:57 --> File loaded: /home3/karoteam/public_html/application/views/header.php
DEBUG - 2022-03-23 04:21:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 04:22:04 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-23 04:22:04 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 04:22:05 --> Final output sent to browser
DEBUG - 2022-03-23 04:22:05 --> Total execution time: 14.7672
INFO - 2022-03-23 04:22:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 04:22:05 --> Controller Class Initialized
INFO - 2022-03-23 04:22:05 --> Form Validation Class Initialized
DEBUG - 2022-03-23 04:22:05 --> Encrypt Class Initialized
INFO - 2022-03-23 04:22:05 --> Model "Patient_model" initialized
INFO - 2022-03-23 04:22:05 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 04:22:05 --> Model "Referredby_model" initialized
INFO - 2022-03-23 04:22:05 --> Model "Prefix_master" initialized
INFO - 2022-03-23 04:22:05 --> Model "Hospital_model" initialized
INFO - 2022-03-23 04:22:05 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 04:22:05 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-23 04:22:05 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 04:22:05 --> Final output sent to browser
DEBUG - 2022-03-23 04:22:05 --> Total execution time: 8.3171
ERROR - 2022-03-23 04:22:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 04:22:15 --> Config Class Initialized
INFO - 2022-03-23 04:22:15 --> Hooks Class Initialized
DEBUG - 2022-03-23 04:22:15 --> UTF-8 Support Enabled
INFO - 2022-03-23 04:22:15 --> Utf8 Class Initialized
INFO - 2022-03-23 04:22:15 --> URI Class Initialized
DEBUG - 2022-03-23 04:22:15 --> No URI present. Default controller set.
INFO - 2022-03-23 04:22:15 --> Router Class Initialized
INFO - 2022-03-23 04:22:15 --> Output Class Initialized
INFO - 2022-03-23 04:22:15 --> Security Class Initialized
DEBUG - 2022-03-23 04:22:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 04:22:15 --> Input Class Initialized
INFO - 2022-03-23 04:22:15 --> Language Class Initialized
INFO - 2022-03-23 04:22:15 --> Loader Class Initialized
INFO - 2022-03-23 04:22:15 --> Helper loaded: url_helper
INFO - 2022-03-23 04:22:15 --> Helper loaded: form_helper
INFO - 2022-03-23 04:22:15 --> Helper loaded: common_helper
INFO - 2022-03-23 04:22:15 --> Database Driver Class Initialized
DEBUG - 2022-03-23 04:22:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 04:22:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 04:22:15 --> Controller Class Initialized
INFO - 2022-03-23 04:22:15 --> Form Validation Class Initialized
DEBUG - 2022-03-23 04:22:15 --> Encrypt Class Initialized
DEBUG - 2022-03-23 04:22:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 04:22:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-23 04:22:15 --> Email Class Initialized
INFO - 2022-03-23 04:22:15 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-23 04:22:15 --> Calendar Class Initialized
INFO - 2022-03-23 04:22:15 --> Model "Login_model" initialized
ERROR - 2022-03-23 04:22:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 04:22:16 --> Config Class Initialized
INFO - 2022-03-23 04:22:16 --> Hooks Class Initialized
DEBUG - 2022-03-23 04:22:16 --> UTF-8 Support Enabled
INFO - 2022-03-23 04:22:16 --> Utf8 Class Initialized
INFO - 2022-03-23 04:22:16 --> URI Class Initialized
INFO - 2022-03-23 04:22:16 --> Router Class Initialized
INFO - 2022-03-23 04:22:16 --> Output Class Initialized
INFO - 2022-03-23 04:22:16 --> Security Class Initialized
DEBUG - 2022-03-23 04:22:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 04:22:16 --> Input Class Initialized
INFO - 2022-03-23 04:22:16 --> Language Class Initialized
INFO - 2022-03-23 04:22:16 --> Loader Class Initialized
INFO - 2022-03-23 04:22:16 --> Helper loaded: url_helper
INFO - 2022-03-23 04:22:16 --> Helper loaded: form_helper
INFO - 2022-03-23 04:22:16 --> Helper loaded: common_helper
INFO - 2022-03-23 04:22:16 --> Database Driver Class Initialized
DEBUG - 2022-03-23 04:22:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 04:22:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 04:22:16 --> Controller Class Initialized
INFO - 2022-03-23 04:22:16 --> Form Validation Class Initialized
DEBUG - 2022-03-23 04:22:16 --> Encrypt Class Initialized
INFO - 2022-03-23 04:22:16 --> Model "Diseases_model" initialized
INFO - 2022-03-23 04:22:16 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 04:22:16 --> File loaded: /home3/karoteam/public_html/application/views/diseases/index.php
INFO - 2022-03-23 04:22:16 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 04:22:16 --> Final output sent to browser
DEBUG - 2022-03-23 04:22:16 --> Total execution time: 0.0132
ERROR - 2022-03-23 04:22:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 04:22:22 --> Config Class Initialized
INFO - 2022-03-23 04:22:22 --> Hooks Class Initialized
DEBUG - 2022-03-23 04:22:22 --> UTF-8 Support Enabled
INFO - 2022-03-23 04:22:22 --> Utf8 Class Initialized
INFO - 2022-03-23 04:22:22 --> URI Class Initialized
INFO - 2022-03-23 04:22:22 --> Router Class Initialized
INFO - 2022-03-23 04:22:22 --> Output Class Initialized
INFO - 2022-03-23 04:22:22 --> Security Class Initialized
DEBUG - 2022-03-23 04:22:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 04:22:22 --> Input Class Initialized
INFO - 2022-03-23 04:22:22 --> Language Class Initialized
INFO - 2022-03-23 04:22:22 --> Loader Class Initialized
INFO - 2022-03-23 04:22:22 --> Helper loaded: url_helper
INFO - 2022-03-23 04:22:22 --> Helper loaded: form_helper
INFO - 2022-03-23 04:22:22 --> Helper loaded: common_helper
INFO - 2022-03-23 04:22:22 --> Database Driver Class Initialized
DEBUG - 2022-03-23 04:22:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 04:22:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 04:22:22 --> Controller Class Initialized
INFO - 2022-03-23 04:22:22 --> Form Validation Class Initialized
DEBUG - 2022-03-23 04:22:22 --> Encrypt Class Initialized
INFO - 2022-03-23 04:22:22 --> Model "Patient_model" initialized
INFO - 2022-03-23 04:22:22 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 04:22:22 --> Model "Referredby_model" initialized
INFO - 2022-03-23 04:22:22 --> Model "Prefix_master" initialized
INFO - 2022-03-23 04:22:22 --> Model "Hospital_model" initialized
INFO - 2022-03-23 04:22:23 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 04:22:28 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-23 04:22:28 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 04:22:30 --> Final output sent to browser
DEBUG - 2022-03-23 04:22:30 --> Total execution time: 5.8984
ERROR - 2022-03-23 04:22:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 04:22:55 --> Config Class Initialized
INFO - 2022-03-23 04:22:55 --> Hooks Class Initialized
DEBUG - 2022-03-23 04:22:55 --> UTF-8 Support Enabled
INFO - 2022-03-23 04:22:55 --> Utf8 Class Initialized
INFO - 2022-03-23 04:22:55 --> URI Class Initialized
INFO - 2022-03-23 04:22:55 --> Router Class Initialized
INFO - 2022-03-23 04:22:55 --> Output Class Initialized
INFO - 2022-03-23 04:22:55 --> Security Class Initialized
DEBUG - 2022-03-23 04:22:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 04:22:55 --> Input Class Initialized
INFO - 2022-03-23 04:22:55 --> Language Class Initialized
INFO - 2022-03-23 04:22:55 --> Loader Class Initialized
INFO - 2022-03-23 04:22:55 --> Helper loaded: url_helper
INFO - 2022-03-23 04:22:55 --> Helper loaded: form_helper
INFO - 2022-03-23 04:22:55 --> Helper loaded: common_helper
INFO - 2022-03-23 04:22:55 --> Database Driver Class Initialized
DEBUG - 2022-03-23 04:22:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 04:22:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 04:22:55 --> Controller Class Initialized
INFO - 2022-03-23 04:22:55 --> Form Validation Class Initialized
DEBUG - 2022-03-23 04:22:55 --> Encrypt Class Initialized
INFO - 2022-03-23 04:22:55 --> Model "Patient_model" initialized
INFO - 2022-03-23 04:22:55 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 04:22:55 --> Model "Prefix_master" initialized
INFO - 2022-03-23 04:22:55 --> Model "Users_model" initialized
INFO - 2022-03-23 04:22:55 --> Model "Hospital_model" initialized
INFO - 2022-03-23 04:22:56 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-23 04:22:57 --> Final output sent to browser
DEBUG - 2022-03-23 04:22:57 --> Total execution time: 1.4303
ERROR - 2022-03-23 04:23:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 04:23:10 --> Config Class Initialized
INFO - 2022-03-23 04:23:10 --> Hooks Class Initialized
DEBUG - 2022-03-23 04:23:10 --> UTF-8 Support Enabled
INFO - 2022-03-23 04:23:10 --> Utf8 Class Initialized
INFO - 2022-03-23 04:23:10 --> URI Class Initialized
INFO - 2022-03-23 04:23:10 --> Router Class Initialized
INFO - 2022-03-23 04:23:10 --> Output Class Initialized
INFO - 2022-03-23 04:23:10 --> Security Class Initialized
DEBUG - 2022-03-23 04:23:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 04:23:10 --> Input Class Initialized
INFO - 2022-03-23 04:23:10 --> Language Class Initialized
INFO - 2022-03-23 04:23:10 --> Loader Class Initialized
INFO - 2022-03-23 04:23:10 --> Helper loaded: url_helper
INFO - 2022-03-23 04:23:10 --> Helper loaded: form_helper
INFO - 2022-03-23 04:23:10 --> Helper loaded: common_helper
INFO - 2022-03-23 04:23:10 --> Database Driver Class Initialized
DEBUG - 2022-03-23 04:23:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 04:23:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 04:23:10 --> Controller Class Initialized
INFO - 2022-03-23 04:23:10 --> Form Validation Class Initialized
DEBUG - 2022-03-23 04:23:10 --> Encrypt Class Initialized
INFO - 2022-03-23 04:23:10 --> Model "Patient_model" initialized
INFO - 2022-03-23 04:23:10 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 04:23:10 --> Model "Referredby_model" initialized
INFO - 2022-03-23 04:23:10 --> Model "Prefix_master" initialized
INFO - 2022-03-23 04:23:10 --> Model "Hospital_model" initialized
INFO - 2022-03-23 04:23:10 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 04:23:10 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-23 04:23:10 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 04:23:10 --> Final output sent to browser
DEBUG - 2022-03-23 04:23:10 --> Total execution time: 0.0278
ERROR - 2022-03-23 04:23:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 04:23:40 --> Config Class Initialized
INFO - 2022-03-23 04:23:40 --> Hooks Class Initialized
DEBUG - 2022-03-23 04:23:40 --> UTF-8 Support Enabled
INFO - 2022-03-23 04:23:40 --> Utf8 Class Initialized
INFO - 2022-03-23 04:23:40 --> URI Class Initialized
INFO - 2022-03-23 04:23:40 --> Router Class Initialized
INFO - 2022-03-23 04:23:40 --> Output Class Initialized
INFO - 2022-03-23 04:23:40 --> Security Class Initialized
DEBUG - 2022-03-23 04:23:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 04:23:40 --> Input Class Initialized
INFO - 2022-03-23 04:23:40 --> Language Class Initialized
INFO - 2022-03-23 04:23:40 --> Loader Class Initialized
INFO - 2022-03-23 04:23:40 --> Helper loaded: url_helper
INFO - 2022-03-23 04:23:40 --> Helper loaded: form_helper
INFO - 2022-03-23 04:23:40 --> Helper loaded: common_helper
INFO - 2022-03-23 04:23:40 --> Database Driver Class Initialized
DEBUG - 2022-03-23 04:23:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 04:23:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 04:23:40 --> Controller Class Initialized
INFO - 2022-03-23 04:23:40 --> Form Validation Class Initialized
DEBUG - 2022-03-23 04:23:40 --> Encrypt Class Initialized
INFO - 2022-03-23 04:23:40 --> Model "Patient_model" initialized
INFO - 2022-03-23 04:23:40 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 04:23:40 --> Model "Referredby_model" initialized
INFO - 2022-03-23 04:23:40 --> Model "Prefix_master" initialized
INFO - 2022-03-23 04:23:40 --> Model "Hospital_model" initialized
INFO - 2022-03-23 04:23:40 --> Upload Class Initialized
INFO - 2022-03-23 04:23:40 --> Final output sent to browser
DEBUG - 2022-03-23 04:23:40 --> Total execution time: 0.0631
ERROR - 2022-03-23 04:23:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 04:23:45 --> Config Class Initialized
INFO - 2022-03-23 04:23:45 --> Hooks Class Initialized
DEBUG - 2022-03-23 04:23:45 --> UTF-8 Support Enabled
INFO - 2022-03-23 04:23:45 --> Utf8 Class Initialized
INFO - 2022-03-23 04:23:45 --> URI Class Initialized
INFO - 2022-03-23 04:23:45 --> Router Class Initialized
INFO - 2022-03-23 04:23:45 --> Output Class Initialized
INFO - 2022-03-23 04:23:45 --> Security Class Initialized
DEBUG - 2022-03-23 04:23:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 04:23:45 --> Input Class Initialized
INFO - 2022-03-23 04:23:45 --> Language Class Initialized
INFO - 2022-03-23 04:23:45 --> Loader Class Initialized
INFO - 2022-03-23 04:23:45 --> Helper loaded: url_helper
INFO - 2022-03-23 04:23:45 --> Helper loaded: form_helper
INFO - 2022-03-23 04:23:45 --> Helper loaded: common_helper
INFO - 2022-03-23 04:23:45 --> Database Driver Class Initialized
DEBUG - 2022-03-23 04:23:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 04:23:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 04:23:45 --> Controller Class Initialized
INFO - 2022-03-23 04:23:45 --> Form Validation Class Initialized
DEBUG - 2022-03-23 04:23:45 --> Encrypt Class Initialized
INFO - 2022-03-23 04:23:45 --> Model "Patient_model" initialized
INFO - 2022-03-23 04:23:45 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 04:23:45 --> Model "Referredby_model" initialized
INFO - 2022-03-23 04:23:45 --> Model "Prefix_master" initialized
INFO - 2022-03-23 04:23:45 --> Model "Hospital_model" initialized
ERROR - 2022-03-23 04:23:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 04:23:46 --> Config Class Initialized
INFO - 2022-03-23 04:23:46 --> Hooks Class Initialized
DEBUG - 2022-03-23 04:23:46 --> UTF-8 Support Enabled
INFO - 2022-03-23 04:23:46 --> Utf8 Class Initialized
INFO - 2022-03-23 04:23:46 --> URI Class Initialized
INFO - 2022-03-23 04:23:46 --> Router Class Initialized
INFO - 2022-03-23 04:23:46 --> Output Class Initialized
INFO - 2022-03-23 04:23:46 --> Security Class Initialized
DEBUG - 2022-03-23 04:23:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 04:23:46 --> Input Class Initialized
INFO - 2022-03-23 04:23:46 --> Language Class Initialized
INFO - 2022-03-23 04:23:46 --> Loader Class Initialized
INFO - 2022-03-23 04:23:46 --> Helper loaded: url_helper
INFO - 2022-03-23 04:23:46 --> Helper loaded: form_helper
INFO - 2022-03-23 04:23:46 --> Helper loaded: common_helper
INFO - 2022-03-23 04:23:46 --> Database Driver Class Initialized
DEBUG - 2022-03-23 04:23:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 04:23:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 04:23:46 --> Controller Class Initialized
INFO - 2022-03-23 04:23:46 --> Form Validation Class Initialized
DEBUG - 2022-03-23 04:23:46 --> Encrypt Class Initialized
INFO - 2022-03-23 04:23:46 --> Model "Patient_model" initialized
INFO - 2022-03-23 04:23:46 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 04:23:46 --> Model "Referredby_model" initialized
INFO - 2022-03-23 04:23:46 --> Model "Prefix_master" initialized
INFO - 2022-03-23 04:23:46 --> Model "Hospital_model" initialized
INFO - 2022-03-23 04:23:46 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 04:23:46 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-23 04:23:46 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 04:23:46 --> Final output sent to browser
DEBUG - 2022-03-23 04:23:46 --> Total execution time: 0.0327
ERROR - 2022-03-23 04:23:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 04:23:46 --> Config Class Initialized
INFO - 2022-03-23 04:23:46 --> Hooks Class Initialized
DEBUG - 2022-03-23 04:23:46 --> UTF-8 Support Enabled
INFO - 2022-03-23 04:23:46 --> Utf8 Class Initialized
INFO - 2022-03-23 04:23:46 --> URI Class Initialized
INFO - 2022-03-23 04:23:46 --> Router Class Initialized
INFO - 2022-03-23 04:23:46 --> Output Class Initialized
INFO - 2022-03-23 04:23:46 --> Security Class Initialized
DEBUG - 2022-03-23 04:23:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 04:23:46 --> Input Class Initialized
INFO - 2022-03-23 04:23:46 --> Language Class Initialized
INFO - 2022-03-23 04:23:46 --> Loader Class Initialized
INFO - 2022-03-23 04:23:46 --> Helper loaded: url_helper
INFO - 2022-03-23 04:23:46 --> Helper loaded: form_helper
INFO - 2022-03-23 04:23:46 --> Helper loaded: common_helper
INFO - 2022-03-23 04:23:46 --> Database Driver Class Initialized
DEBUG - 2022-03-23 04:23:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 04:23:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 04:23:46 --> Controller Class Initialized
INFO - 2022-03-23 04:23:46 --> Form Validation Class Initialized
DEBUG - 2022-03-23 04:23:46 --> Encrypt Class Initialized
INFO - 2022-03-23 04:23:46 --> Model "Patient_model" initialized
INFO - 2022-03-23 04:23:46 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 04:23:46 --> Model "Prefix_master" initialized
INFO - 2022-03-23 04:23:46 --> Model "Users_model" initialized
INFO - 2022-03-23 04:23:46 --> Model "Hospital_model" initialized
INFO - 2022-03-23 04:23:46 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 04:23:46 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-23 04:23:46 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 04:23:46 --> Final output sent to browser
DEBUG - 2022-03-23 04:23:46 --> Total execution time: 0.0558
ERROR - 2022-03-23 04:23:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 04:23:50 --> Config Class Initialized
INFO - 2022-03-23 04:23:50 --> Hooks Class Initialized
DEBUG - 2022-03-23 04:23:50 --> UTF-8 Support Enabled
INFO - 2022-03-23 04:23:50 --> Utf8 Class Initialized
INFO - 2022-03-23 04:23:50 --> URI Class Initialized
INFO - 2022-03-23 04:23:50 --> Router Class Initialized
INFO - 2022-03-23 04:23:50 --> Output Class Initialized
INFO - 2022-03-23 04:23:50 --> Security Class Initialized
DEBUG - 2022-03-23 04:23:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 04:23:50 --> Input Class Initialized
INFO - 2022-03-23 04:23:50 --> Language Class Initialized
INFO - 2022-03-23 04:23:50 --> Loader Class Initialized
INFO - 2022-03-23 04:23:50 --> Helper loaded: url_helper
INFO - 2022-03-23 04:23:50 --> Helper loaded: form_helper
INFO - 2022-03-23 04:23:50 --> Helper loaded: common_helper
INFO - 2022-03-23 04:23:50 --> Database Driver Class Initialized
DEBUG - 2022-03-23 04:23:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 04:23:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 04:23:50 --> Controller Class Initialized
INFO - 2022-03-23 04:23:50 --> Form Validation Class Initialized
DEBUG - 2022-03-23 04:23:50 --> Encrypt Class Initialized
INFO - 2022-03-23 04:23:50 --> Model "Patient_model" initialized
INFO - 2022-03-23 04:23:50 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 04:23:50 --> Model "Referredby_model" initialized
INFO - 2022-03-23 04:23:50 --> Model "Prefix_master" initialized
INFO - 2022-03-23 04:23:50 --> Model "Hospital_model" initialized
INFO - 2022-03-23 04:23:50 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 04:23:57 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-23 04:23:57 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 04:23:59 --> Final output sent to browser
DEBUG - 2022-03-23 04:23:59 --> Total execution time: 7.3485
ERROR - 2022-03-23 04:24:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 04:24:28 --> Config Class Initialized
INFO - 2022-03-23 04:24:28 --> Hooks Class Initialized
DEBUG - 2022-03-23 04:24:28 --> UTF-8 Support Enabled
INFO - 2022-03-23 04:24:28 --> Utf8 Class Initialized
INFO - 2022-03-23 04:24:28 --> URI Class Initialized
INFO - 2022-03-23 04:24:28 --> Router Class Initialized
INFO - 2022-03-23 04:24:28 --> Output Class Initialized
INFO - 2022-03-23 04:24:28 --> Security Class Initialized
DEBUG - 2022-03-23 04:24:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 04:24:28 --> Input Class Initialized
INFO - 2022-03-23 04:24:28 --> Language Class Initialized
INFO - 2022-03-23 04:24:28 --> Loader Class Initialized
INFO - 2022-03-23 04:24:28 --> Helper loaded: url_helper
INFO - 2022-03-23 04:24:28 --> Helper loaded: form_helper
INFO - 2022-03-23 04:24:28 --> Helper loaded: common_helper
INFO - 2022-03-23 04:24:28 --> Database Driver Class Initialized
DEBUG - 2022-03-23 04:24:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 04:24:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 04:24:28 --> Controller Class Initialized
INFO - 2022-03-23 04:24:28 --> Form Validation Class Initialized
DEBUG - 2022-03-23 04:24:28 --> Encrypt Class Initialized
INFO - 2022-03-23 04:24:28 --> Model "Patient_model" initialized
INFO - 2022-03-23 04:24:28 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 04:24:28 --> Model "Prefix_master" initialized
INFO - 2022-03-23 04:24:28 --> Model "Users_model" initialized
INFO - 2022-03-23 04:24:28 --> Model "Hospital_model" initialized
INFO - 2022-03-23 04:24:28 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-23 04:24:29 --> Final output sent to browser
DEBUG - 2022-03-23 04:24:29 --> Total execution time: 0.8265
ERROR - 2022-03-23 04:25:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 04:25:06 --> Config Class Initialized
INFO - 2022-03-23 04:25:06 --> Hooks Class Initialized
DEBUG - 2022-03-23 04:25:06 --> UTF-8 Support Enabled
INFO - 2022-03-23 04:25:06 --> Utf8 Class Initialized
INFO - 2022-03-23 04:25:06 --> URI Class Initialized
INFO - 2022-03-23 04:25:06 --> Router Class Initialized
INFO - 2022-03-23 04:25:06 --> Output Class Initialized
INFO - 2022-03-23 04:25:06 --> Security Class Initialized
DEBUG - 2022-03-23 04:25:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 04:25:06 --> Input Class Initialized
INFO - 2022-03-23 04:25:06 --> Language Class Initialized
INFO - 2022-03-23 04:25:06 --> Loader Class Initialized
INFO - 2022-03-23 04:25:06 --> Helper loaded: url_helper
INFO - 2022-03-23 04:25:06 --> Helper loaded: form_helper
INFO - 2022-03-23 04:25:06 --> Helper loaded: common_helper
INFO - 2022-03-23 04:25:06 --> Database Driver Class Initialized
DEBUG - 2022-03-23 04:25:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 04:25:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 04:25:06 --> Controller Class Initialized
INFO - 2022-03-23 04:25:06 --> Form Validation Class Initialized
DEBUG - 2022-03-23 04:25:06 --> Encrypt Class Initialized
INFO - 2022-03-23 04:25:06 --> Model "Patient_model" initialized
INFO - 2022-03-23 04:25:06 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 04:25:06 --> Model "Prefix_master" initialized
INFO - 2022-03-23 04:25:06 --> Model "Users_model" initialized
INFO - 2022-03-23 04:25:06 --> Model "Hospital_model" initialized
INFO - 2022-03-23 04:25:07 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-23 04:25:07 --> Final output sent to browser
DEBUG - 2022-03-23 04:25:07 --> Total execution time: 0.7912
ERROR - 2022-03-23 04:25:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 04:25:13 --> Config Class Initialized
INFO - 2022-03-23 04:25:13 --> Hooks Class Initialized
DEBUG - 2022-03-23 04:25:13 --> UTF-8 Support Enabled
INFO - 2022-03-23 04:25:13 --> Utf8 Class Initialized
INFO - 2022-03-23 04:25:13 --> URI Class Initialized
INFO - 2022-03-23 04:25:13 --> Router Class Initialized
INFO - 2022-03-23 04:25:13 --> Output Class Initialized
INFO - 2022-03-23 04:25:13 --> Security Class Initialized
DEBUG - 2022-03-23 04:25:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 04:25:13 --> Input Class Initialized
INFO - 2022-03-23 04:25:13 --> Language Class Initialized
INFO - 2022-03-23 04:25:13 --> Loader Class Initialized
INFO - 2022-03-23 04:25:13 --> Helper loaded: url_helper
INFO - 2022-03-23 04:25:13 --> Helper loaded: form_helper
INFO - 2022-03-23 04:25:13 --> Helper loaded: common_helper
INFO - 2022-03-23 04:25:13 --> Database Driver Class Initialized
DEBUG - 2022-03-23 04:25:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 04:25:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 04:25:13 --> Controller Class Initialized
INFO - 2022-03-23 04:25:13 --> Form Validation Class Initialized
DEBUG - 2022-03-23 04:25:13 --> Encrypt Class Initialized
INFO - 2022-03-23 04:25:13 --> Model "Patient_model" initialized
INFO - 2022-03-23 04:25:13 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 04:25:13 --> Model "Referredby_model" initialized
INFO - 2022-03-23 04:25:13 --> Model "Prefix_master" initialized
INFO - 2022-03-23 04:25:13 --> Model "Hospital_model" initialized
INFO - 2022-03-23 04:25:13 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 04:25:13 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-23 04:25:13 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 04:25:13 --> Final output sent to browser
DEBUG - 2022-03-23 04:25:13 --> Total execution time: 0.0657
ERROR - 2022-03-23 04:26:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 04:26:50 --> Config Class Initialized
INFO - 2022-03-23 04:26:50 --> Hooks Class Initialized
DEBUG - 2022-03-23 04:26:50 --> UTF-8 Support Enabled
INFO - 2022-03-23 04:26:50 --> Utf8 Class Initialized
INFO - 2022-03-23 04:26:50 --> URI Class Initialized
DEBUG - 2022-03-23 04:26:50 --> No URI present. Default controller set.
INFO - 2022-03-23 04:26:50 --> Router Class Initialized
INFO - 2022-03-23 04:26:50 --> Output Class Initialized
INFO - 2022-03-23 04:26:50 --> Security Class Initialized
DEBUG - 2022-03-23 04:26:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 04:26:50 --> Input Class Initialized
INFO - 2022-03-23 04:26:50 --> Language Class Initialized
INFO - 2022-03-23 04:26:50 --> Loader Class Initialized
INFO - 2022-03-23 04:26:50 --> Helper loaded: url_helper
INFO - 2022-03-23 04:26:50 --> Helper loaded: form_helper
INFO - 2022-03-23 04:26:50 --> Helper loaded: common_helper
INFO - 2022-03-23 04:26:50 --> Database Driver Class Initialized
DEBUG - 2022-03-23 04:26:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 04:26:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 04:26:50 --> Controller Class Initialized
INFO - 2022-03-23 04:26:50 --> Form Validation Class Initialized
DEBUG - 2022-03-23 04:26:50 --> Encrypt Class Initialized
DEBUG - 2022-03-23 04:26:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 04:26:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-23 04:26:50 --> Email Class Initialized
INFO - 2022-03-23 04:26:50 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-23 04:26:50 --> Calendar Class Initialized
INFO - 2022-03-23 04:26:50 --> Model "Login_model" initialized
INFO - 2022-03-23 04:26:50 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-23 04:26:50 --> Final output sent to browser
DEBUG - 2022-03-23 04:26:50 --> Total execution time: 0.0103
ERROR - 2022-03-23 04:26:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 04:26:52 --> Config Class Initialized
INFO - 2022-03-23 04:26:52 --> Hooks Class Initialized
DEBUG - 2022-03-23 04:26:52 --> UTF-8 Support Enabled
INFO - 2022-03-23 04:26:52 --> Utf8 Class Initialized
INFO - 2022-03-23 04:26:52 --> URI Class Initialized
DEBUG - 2022-03-23 04:26:52 --> No URI present. Default controller set.
INFO - 2022-03-23 04:26:52 --> Router Class Initialized
INFO - 2022-03-23 04:26:52 --> Output Class Initialized
INFO - 2022-03-23 04:26:52 --> Security Class Initialized
DEBUG - 2022-03-23 04:26:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 04:26:52 --> Input Class Initialized
INFO - 2022-03-23 04:26:52 --> Language Class Initialized
INFO - 2022-03-23 04:26:52 --> Loader Class Initialized
INFO - 2022-03-23 04:26:52 --> Helper loaded: url_helper
INFO - 2022-03-23 04:26:52 --> Helper loaded: form_helper
INFO - 2022-03-23 04:26:52 --> Helper loaded: common_helper
INFO - 2022-03-23 04:26:52 --> Database Driver Class Initialized
DEBUG - 2022-03-23 04:26:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 04:26:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 04:26:52 --> Controller Class Initialized
INFO - 2022-03-23 04:26:52 --> Form Validation Class Initialized
DEBUG - 2022-03-23 04:26:52 --> Encrypt Class Initialized
DEBUG - 2022-03-23 04:26:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 04:26:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-23 04:26:52 --> Email Class Initialized
INFO - 2022-03-23 04:26:52 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-23 04:26:52 --> Calendar Class Initialized
INFO - 2022-03-23 04:26:52 --> Model "Login_model" initialized
INFO - 2022-03-23 04:26:52 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-23 04:26:52 --> Final output sent to browser
DEBUG - 2022-03-23 04:26:52 --> Total execution time: 0.0095
ERROR - 2022-03-23 04:27:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 04:27:04 --> Config Class Initialized
INFO - 2022-03-23 04:27:04 --> Hooks Class Initialized
DEBUG - 2022-03-23 04:27:04 --> UTF-8 Support Enabled
INFO - 2022-03-23 04:27:04 --> Utf8 Class Initialized
INFO - 2022-03-23 04:27:04 --> URI Class Initialized
INFO - 2022-03-23 04:27:04 --> Router Class Initialized
INFO - 2022-03-23 04:27:04 --> Output Class Initialized
INFO - 2022-03-23 04:27:04 --> Security Class Initialized
DEBUG - 2022-03-23 04:27:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 04:27:04 --> Input Class Initialized
INFO - 2022-03-23 04:27:04 --> Language Class Initialized
INFO - 2022-03-23 04:27:04 --> Loader Class Initialized
INFO - 2022-03-23 04:27:04 --> Helper loaded: url_helper
INFO - 2022-03-23 04:27:04 --> Helper loaded: form_helper
INFO - 2022-03-23 04:27:04 --> Helper loaded: common_helper
INFO - 2022-03-23 04:27:04 --> Database Driver Class Initialized
DEBUG - 2022-03-23 04:27:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 04:27:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 04:27:04 --> Controller Class Initialized
INFO - 2022-03-23 04:27:04 --> Form Validation Class Initialized
DEBUG - 2022-03-23 04:27:04 --> Encrypt Class Initialized
DEBUG - 2022-03-23 04:27:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 04:27:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-23 04:27:04 --> Email Class Initialized
INFO - 2022-03-23 04:27:04 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-23 04:27:04 --> Calendar Class Initialized
INFO - 2022-03-23 04:27:04 --> Model "Login_model" initialized
INFO - 2022-03-23 04:27:04 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-03-23 04:27:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 04:27:04 --> Config Class Initialized
INFO - 2022-03-23 04:27:04 --> Hooks Class Initialized
DEBUG - 2022-03-23 04:27:04 --> UTF-8 Support Enabled
INFO - 2022-03-23 04:27:04 --> Utf8 Class Initialized
INFO - 2022-03-23 04:27:04 --> URI Class Initialized
INFO - 2022-03-23 04:27:04 --> Router Class Initialized
INFO - 2022-03-23 04:27:04 --> Output Class Initialized
INFO - 2022-03-23 04:27:04 --> Security Class Initialized
DEBUG - 2022-03-23 04:27:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 04:27:04 --> Input Class Initialized
INFO - 2022-03-23 04:27:04 --> Language Class Initialized
INFO - 2022-03-23 04:27:04 --> Loader Class Initialized
INFO - 2022-03-23 04:27:04 --> Helper loaded: url_helper
INFO - 2022-03-23 04:27:04 --> Helper loaded: form_helper
INFO - 2022-03-23 04:27:04 --> Helper loaded: common_helper
INFO - 2022-03-23 04:27:04 --> Database Driver Class Initialized
DEBUG - 2022-03-23 04:27:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 04:27:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 04:27:04 --> Controller Class Initialized
INFO - 2022-03-23 04:27:04 --> Form Validation Class Initialized
DEBUG - 2022-03-23 04:27:04 --> Encrypt Class Initialized
INFO - 2022-03-23 04:27:04 --> Model "Login_model" initialized
INFO - 2022-03-23 04:27:04 --> Model "Dashboard_model" initialized
INFO - 2022-03-23 04:27:04 --> Model "Case_model" initialized
INFO - 2022-03-23 04:27:04 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 04:27:04 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2022-03-23 04:27:04 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 04:27:04 --> Final output sent to browser
DEBUG - 2022-03-23 04:27:04 --> Total execution time: 0.1526
ERROR - 2022-03-23 04:27:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 04:27:06 --> Config Class Initialized
INFO - 2022-03-23 04:27:06 --> Hooks Class Initialized
DEBUG - 2022-03-23 04:27:06 --> UTF-8 Support Enabled
INFO - 2022-03-23 04:27:06 --> Utf8 Class Initialized
INFO - 2022-03-23 04:27:06 --> URI Class Initialized
DEBUG - 2022-03-23 04:27:06 --> No URI present. Default controller set.
INFO - 2022-03-23 04:27:06 --> Router Class Initialized
INFO - 2022-03-23 04:27:06 --> Output Class Initialized
INFO - 2022-03-23 04:27:06 --> Security Class Initialized
DEBUG - 2022-03-23 04:27:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 04:27:06 --> Input Class Initialized
INFO - 2022-03-23 04:27:06 --> Language Class Initialized
INFO - 2022-03-23 04:27:06 --> Loader Class Initialized
INFO - 2022-03-23 04:27:06 --> Helper loaded: url_helper
INFO - 2022-03-23 04:27:06 --> Helper loaded: form_helper
INFO - 2022-03-23 04:27:06 --> Helper loaded: common_helper
INFO - 2022-03-23 04:27:06 --> Database Driver Class Initialized
DEBUG - 2022-03-23 04:27:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 04:27:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 04:27:06 --> Controller Class Initialized
INFO - 2022-03-23 04:27:06 --> Form Validation Class Initialized
DEBUG - 2022-03-23 04:27:06 --> Encrypt Class Initialized
DEBUG - 2022-03-23 04:27:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 04:27:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-23 04:27:06 --> Email Class Initialized
INFO - 2022-03-23 04:27:06 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-23 04:27:06 --> Calendar Class Initialized
INFO - 2022-03-23 04:27:06 --> Model "Login_model" initialized
INFO - 2022-03-23 04:27:06 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-23 04:27:06 --> Final output sent to browser
DEBUG - 2022-03-23 04:27:06 --> Total execution time: 0.0081
ERROR - 2022-03-23 04:27:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 04:27:16 --> Config Class Initialized
INFO - 2022-03-23 04:27:16 --> Hooks Class Initialized
DEBUG - 2022-03-23 04:27:16 --> UTF-8 Support Enabled
INFO - 2022-03-23 04:27:16 --> Utf8 Class Initialized
INFO - 2022-03-23 04:27:16 --> URI Class Initialized
INFO - 2022-03-23 04:27:16 --> Router Class Initialized
INFO - 2022-03-23 04:27:16 --> Output Class Initialized
INFO - 2022-03-23 04:27:16 --> Security Class Initialized
DEBUG - 2022-03-23 04:27:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 04:27:16 --> Input Class Initialized
INFO - 2022-03-23 04:27:16 --> Language Class Initialized
INFO - 2022-03-23 04:27:16 --> Loader Class Initialized
INFO - 2022-03-23 04:27:16 --> Helper loaded: url_helper
INFO - 2022-03-23 04:27:16 --> Helper loaded: form_helper
INFO - 2022-03-23 04:27:16 --> Helper loaded: common_helper
INFO - 2022-03-23 04:27:16 --> Database Driver Class Initialized
DEBUG - 2022-03-23 04:27:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 04:27:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 04:27:16 --> Controller Class Initialized
INFO - 2022-03-23 04:27:16 --> Form Validation Class Initialized
DEBUG - 2022-03-23 04:27:16 --> Encrypt Class Initialized
INFO - 2022-03-23 04:27:16 --> Model "Patient_model" initialized
INFO - 2022-03-23 04:27:16 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 04:27:16 --> Model "Referredby_model" initialized
INFO - 2022-03-23 04:27:16 --> Model "Prefix_master" initialized
INFO - 2022-03-23 04:27:16 --> Model "Hospital_model" initialized
INFO - 2022-03-23 04:27:16 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 04:27:16 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-23 04:27:16 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 04:27:16 --> Final output sent to browser
DEBUG - 2022-03-23 04:27:16 --> Total execution time: 0.0418
ERROR - 2022-03-23 04:27:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 04:27:23 --> Config Class Initialized
INFO - 2022-03-23 04:27:23 --> Hooks Class Initialized
DEBUG - 2022-03-23 04:27:23 --> UTF-8 Support Enabled
INFO - 2022-03-23 04:27:23 --> Utf8 Class Initialized
INFO - 2022-03-23 04:27:23 --> URI Class Initialized
INFO - 2022-03-23 04:27:23 --> Router Class Initialized
INFO - 2022-03-23 04:27:23 --> Output Class Initialized
INFO - 2022-03-23 04:27:23 --> Security Class Initialized
DEBUG - 2022-03-23 04:27:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 04:27:23 --> Input Class Initialized
INFO - 2022-03-23 04:27:23 --> Language Class Initialized
INFO - 2022-03-23 04:27:23 --> Loader Class Initialized
INFO - 2022-03-23 04:27:23 --> Helper loaded: url_helper
INFO - 2022-03-23 04:27:23 --> Helper loaded: form_helper
INFO - 2022-03-23 04:27:23 --> Helper loaded: common_helper
INFO - 2022-03-23 04:27:23 --> Database Driver Class Initialized
DEBUG - 2022-03-23 04:27:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 04:27:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 04:27:23 --> Controller Class Initialized
INFO - 2022-03-23 04:27:23 --> Form Validation Class Initialized
DEBUG - 2022-03-23 04:27:23 --> Encrypt Class Initialized
INFO - 2022-03-23 04:27:23 --> Model "Patient_model" initialized
INFO - 2022-03-23 04:27:23 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 04:27:23 --> Model "Prefix_master" initialized
INFO - 2022-03-23 04:27:23 --> Model "Users_model" initialized
INFO - 2022-03-23 04:27:23 --> Model "Hospital_model" initialized
INFO - 2022-03-23 04:27:23 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 04:27:23 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-23 04:27:23 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 04:27:23 --> Final output sent to browser
DEBUG - 2022-03-23 04:27:23 --> Total execution time: 0.5636
ERROR - 2022-03-23 04:27:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 04:27:27 --> Config Class Initialized
INFO - 2022-03-23 04:27:27 --> Hooks Class Initialized
DEBUG - 2022-03-23 04:27:27 --> UTF-8 Support Enabled
INFO - 2022-03-23 04:27:27 --> Utf8 Class Initialized
INFO - 2022-03-23 04:27:27 --> URI Class Initialized
INFO - 2022-03-23 04:27:27 --> Router Class Initialized
INFO - 2022-03-23 04:27:27 --> Output Class Initialized
INFO - 2022-03-23 04:27:27 --> Security Class Initialized
DEBUG - 2022-03-23 04:27:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 04:27:27 --> Input Class Initialized
INFO - 2022-03-23 04:27:27 --> Language Class Initialized
INFO - 2022-03-23 04:27:27 --> Loader Class Initialized
INFO - 2022-03-23 04:27:27 --> Helper loaded: url_helper
INFO - 2022-03-23 04:27:27 --> Helper loaded: form_helper
INFO - 2022-03-23 04:27:27 --> Helper loaded: common_helper
INFO - 2022-03-23 04:27:27 --> Database Driver Class Initialized
DEBUG - 2022-03-23 04:27:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 04:27:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 04:27:27 --> Controller Class Initialized
INFO - 2022-03-23 04:27:27 --> Form Validation Class Initialized
DEBUG - 2022-03-23 04:27:27 --> Encrypt Class Initialized
INFO - 2022-03-23 04:27:27 --> Model "Patient_model" initialized
INFO - 2022-03-23 04:27:27 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 04:27:27 --> Model "Referredby_model" initialized
INFO - 2022-03-23 04:27:27 --> Model "Prefix_master" initialized
INFO - 2022-03-23 04:27:27 --> Model "Hospital_model" initialized
INFO - 2022-03-23 04:27:27 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 04:27:27 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-23 04:27:27 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 04:27:27 --> Final output sent to browser
DEBUG - 2022-03-23 04:27:27 --> Total execution time: 0.0333
ERROR - 2022-03-23 04:27:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 04:27:34 --> Config Class Initialized
INFO - 2022-03-23 04:27:34 --> Hooks Class Initialized
DEBUG - 2022-03-23 04:27:34 --> UTF-8 Support Enabled
INFO - 2022-03-23 04:27:34 --> Utf8 Class Initialized
INFO - 2022-03-23 04:27:34 --> URI Class Initialized
INFO - 2022-03-23 04:27:34 --> Router Class Initialized
INFO - 2022-03-23 04:27:34 --> Output Class Initialized
INFO - 2022-03-23 04:27:34 --> Security Class Initialized
DEBUG - 2022-03-23 04:27:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 04:27:34 --> Input Class Initialized
INFO - 2022-03-23 04:27:34 --> Language Class Initialized
INFO - 2022-03-23 04:27:34 --> Loader Class Initialized
INFO - 2022-03-23 04:27:34 --> Helper loaded: url_helper
INFO - 2022-03-23 04:27:34 --> Helper loaded: form_helper
INFO - 2022-03-23 04:27:34 --> Helper loaded: common_helper
INFO - 2022-03-23 04:27:34 --> Database Driver Class Initialized
DEBUG - 2022-03-23 04:27:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 04:27:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 04:27:34 --> Controller Class Initialized
INFO - 2022-03-23 04:27:34 --> Form Validation Class Initialized
DEBUG - 2022-03-23 04:27:34 --> Encrypt Class Initialized
INFO - 2022-03-23 04:27:34 --> Model "Patient_model" initialized
INFO - 2022-03-23 04:27:34 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 04:27:34 --> Model "Referredby_model" initialized
INFO - 2022-03-23 04:27:34 --> Model "Prefix_master" initialized
INFO - 2022-03-23 04:27:34 --> Model "Hospital_model" initialized
ERROR - 2022-03-23 04:27:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 04:27:35 --> Config Class Initialized
INFO - 2022-03-23 04:27:35 --> Hooks Class Initialized
DEBUG - 2022-03-23 04:27:35 --> UTF-8 Support Enabled
INFO - 2022-03-23 04:27:35 --> Utf8 Class Initialized
INFO - 2022-03-23 04:27:35 --> URI Class Initialized
INFO - 2022-03-23 04:27:35 --> Router Class Initialized
INFO - 2022-03-23 04:27:35 --> Output Class Initialized
INFO - 2022-03-23 04:27:35 --> Security Class Initialized
DEBUG - 2022-03-23 04:27:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 04:27:35 --> Input Class Initialized
INFO - 2022-03-23 04:27:35 --> Language Class Initialized
INFO - 2022-03-23 04:27:35 --> Loader Class Initialized
INFO - 2022-03-23 04:27:35 --> Helper loaded: url_helper
INFO - 2022-03-23 04:27:35 --> Helper loaded: form_helper
INFO - 2022-03-23 04:27:35 --> Helper loaded: common_helper
INFO - 2022-03-23 04:27:35 --> Database Driver Class Initialized
DEBUG - 2022-03-23 04:27:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 04:27:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 04:27:35 --> Controller Class Initialized
INFO - 2022-03-23 04:27:35 --> Form Validation Class Initialized
DEBUG - 2022-03-23 04:27:35 --> Encrypt Class Initialized
INFO - 2022-03-23 04:27:35 --> Model "Patient_model" initialized
INFO - 2022-03-23 04:27:35 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 04:27:35 --> Model "Referredby_model" initialized
INFO - 2022-03-23 04:27:35 --> Model "Prefix_master" initialized
INFO - 2022-03-23 04:27:35 --> Model "Hospital_model" initialized
INFO - 2022-03-23 04:27:35 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 04:27:35 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-23 04:27:35 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 04:27:35 --> Final output sent to browser
DEBUG - 2022-03-23 04:27:35 --> Total execution time: 0.0274
ERROR - 2022-03-23 04:27:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 04:27:35 --> Config Class Initialized
INFO - 2022-03-23 04:27:35 --> Hooks Class Initialized
DEBUG - 2022-03-23 04:27:35 --> UTF-8 Support Enabled
INFO - 2022-03-23 04:27:35 --> Utf8 Class Initialized
INFO - 2022-03-23 04:27:35 --> URI Class Initialized
INFO - 2022-03-23 04:27:35 --> Router Class Initialized
INFO - 2022-03-23 04:27:35 --> Output Class Initialized
INFO - 2022-03-23 04:27:35 --> Security Class Initialized
DEBUG - 2022-03-23 04:27:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 04:27:35 --> Input Class Initialized
INFO - 2022-03-23 04:27:35 --> Language Class Initialized
INFO - 2022-03-23 04:27:35 --> Loader Class Initialized
INFO - 2022-03-23 04:27:35 --> Helper loaded: url_helper
INFO - 2022-03-23 04:27:35 --> Helper loaded: form_helper
INFO - 2022-03-23 04:27:35 --> Helper loaded: common_helper
INFO - 2022-03-23 04:27:35 --> Database Driver Class Initialized
DEBUG - 2022-03-23 04:27:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 04:27:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 04:27:35 --> Controller Class Initialized
INFO - 2022-03-23 04:27:35 --> Form Validation Class Initialized
DEBUG - 2022-03-23 04:27:35 --> Encrypt Class Initialized
INFO - 2022-03-23 04:27:35 --> Model "Patient_model" initialized
INFO - 2022-03-23 04:27:35 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 04:27:35 --> Model "Prefix_master" initialized
INFO - 2022-03-23 04:27:35 --> Model "Users_model" initialized
INFO - 2022-03-23 04:27:35 --> Model "Hospital_model" initialized
INFO - 2022-03-23 04:27:36 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 04:27:36 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-23 04:27:36 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 04:27:36 --> Final output sent to browser
DEBUG - 2022-03-23 04:27:36 --> Total execution time: 0.0399
ERROR - 2022-03-23 04:28:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 04:28:20 --> Config Class Initialized
INFO - 2022-03-23 04:28:20 --> Hooks Class Initialized
DEBUG - 2022-03-23 04:28:20 --> UTF-8 Support Enabled
INFO - 2022-03-23 04:28:20 --> Utf8 Class Initialized
INFO - 2022-03-23 04:28:20 --> URI Class Initialized
INFO - 2022-03-23 04:28:20 --> Router Class Initialized
INFO - 2022-03-23 04:28:20 --> Output Class Initialized
INFO - 2022-03-23 04:28:20 --> Security Class Initialized
DEBUG - 2022-03-23 04:28:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 04:28:20 --> Input Class Initialized
INFO - 2022-03-23 04:28:20 --> Language Class Initialized
INFO - 2022-03-23 04:28:20 --> Loader Class Initialized
INFO - 2022-03-23 04:28:20 --> Helper loaded: url_helper
INFO - 2022-03-23 04:28:20 --> Helper loaded: form_helper
INFO - 2022-03-23 04:28:20 --> Helper loaded: common_helper
INFO - 2022-03-23 04:28:20 --> Database Driver Class Initialized
DEBUG - 2022-03-23 04:28:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 04:28:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 04:28:20 --> Controller Class Initialized
INFO - 2022-03-23 04:28:20 --> Form Validation Class Initialized
DEBUG - 2022-03-23 04:28:20 --> Encrypt Class Initialized
INFO - 2022-03-23 04:28:20 --> Model "Patient_model" initialized
INFO - 2022-03-23 04:28:20 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 04:28:20 --> Model "Referredby_model" initialized
INFO - 2022-03-23 04:28:20 --> Model "Prefix_master" initialized
INFO - 2022-03-23 04:28:20 --> Model "Hospital_model" initialized
INFO - 2022-03-23 04:28:20 --> Upload Class Initialized
INFO - 2022-03-23 04:28:20 --> Final output sent to browser
DEBUG - 2022-03-23 04:28:20 --> Total execution time: 0.0084
ERROR - 2022-03-23 04:28:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 04:28:26 --> Config Class Initialized
INFO - 2022-03-23 04:28:26 --> Hooks Class Initialized
DEBUG - 2022-03-23 04:28:26 --> UTF-8 Support Enabled
INFO - 2022-03-23 04:28:26 --> Utf8 Class Initialized
INFO - 2022-03-23 04:28:26 --> URI Class Initialized
INFO - 2022-03-23 04:28:26 --> Router Class Initialized
INFO - 2022-03-23 04:28:26 --> Output Class Initialized
INFO - 2022-03-23 04:28:26 --> Security Class Initialized
DEBUG - 2022-03-23 04:28:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 04:28:26 --> Input Class Initialized
INFO - 2022-03-23 04:28:26 --> Language Class Initialized
INFO - 2022-03-23 04:28:26 --> Loader Class Initialized
INFO - 2022-03-23 04:28:26 --> Helper loaded: url_helper
INFO - 2022-03-23 04:28:26 --> Helper loaded: form_helper
INFO - 2022-03-23 04:28:26 --> Helper loaded: common_helper
INFO - 2022-03-23 04:28:26 --> Database Driver Class Initialized
DEBUG - 2022-03-23 04:28:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 04:28:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 04:28:26 --> Controller Class Initialized
INFO - 2022-03-23 04:28:26 --> Form Validation Class Initialized
DEBUG - 2022-03-23 04:28:26 --> Encrypt Class Initialized
INFO - 2022-03-23 04:28:26 --> Model "Patient_model" initialized
INFO - 2022-03-23 04:28:26 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 04:28:26 --> Model "Referredby_model" initialized
INFO - 2022-03-23 04:28:26 --> Model "Prefix_master" initialized
INFO - 2022-03-23 04:28:26 --> Model "Hospital_model" initialized
ERROR - 2022-03-23 04:28:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 04:28:26 --> Config Class Initialized
INFO - 2022-03-23 04:28:26 --> Hooks Class Initialized
DEBUG - 2022-03-23 04:28:26 --> UTF-8 Support Enabled
INFO - 2022-03-23 04:28:26 --> Utf8 Class Initialized
INFO - 2022-03-23 04:28:26 --> URI Class Initialized
INFO - 2022-03-23 04:28:26 --> Router Class Initialized
INFO - 2022-03-23 04:28:26 --> Output Class Initialized
INFO - 2022-03-23 04:28:26 --> Security Class Initialized
DEBUG - 2022-03-23 04:28:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 04:28:26 --> Input Class Initialized
INFO - 2022-03-23 04:28:26 --> Language Class Initialized
INFO - 2022-03-23 04:28:26 --> Loader Class Initialized
INFO - 2022-03-23 04:28:26 --> Helper loaded: url_helper
INFO - 2022-03-23 04:28:26 --> Helper loaded: form_helper
INFO - 2022-03-23 04:28:26 --> Helper loaded: common_helper
INFO - 2022-03-23 04:28:26 --> Database Driver Class Initialized
DEBUG - 2022-03-23 04:28:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 04:28:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 04:28:26 --> Controller Class Initialized
INFO - 2022-03-23 04:28:26 --> Form Validation Class Initialized
DEBUG - 2022-03-23 04:28:26 --> Encrypt Class Initialized
INFO - 2022-03-23 04:28:26 --> Model "Patient_model" initialized
INFO - 2022-03-23 04:28:26 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 04:28:26 --> Model "Referredby_model" initialized
INFO - 2022-03-23 04:28:26 --> Model "Prefix_master" initialized
INFO - 2022-03-23 04:28:26 --> Model "Hospital_model" initialized
INFO - 2022-03-23 04:28:26 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 04:28:26 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-23 04:28:26 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 04:28:26 --> Final output sent to browser
DEBUG - 2022-03-23 04:28:26 --> Total execution time: 0.0279
ERROR - 2022-03-23 04:28:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 04:28:27 --> Config Class Initialized
INFO - 2022-03-23 04:28:27 --> Hooks Class Initialized
DEBUG - 2022-03-23 04:28:27 --> UTF-8 Support Enabled
INFO - 2022-03-23 04:28:27 --> Utf8 Class Initialized
INFO - 2022-03-23 04:28:27 --> URI Class Initialized
INFO - 2022-03-23 04:28:27 --> Router Class Initialized
INFO - 2022-03-23 04:28:27 --> Output Class Initialized
INFO - 2022-03-23 04:28:27 --> Security Class Initialized
DEBUG - 2022-03-23 04:28:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 04:28:27 --> Input Class Initialized
INFO - 2022-03-23 04:28:27 --> Language Class Initialized
INFO - 2022-03-23 04:28:27 --> Loader Class Initialized
INFO - 2022-03-23 04:28:27 --> Helper loaded: url_helper
INFO - 2022-03-23 04:28:27 --> Helper loaded: form_helper
INFO - 2022-03-23 04:28:27 --> Helper loaded: common_helper
INFO - 2022-03-23 04:28:27 --> Database Driver Class Initialized
DEBUG - 2022-03-23 04:28:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 04:28:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 04:28:27 --> Controller Class Initialized
INFO - 2022-03-23 04:28:27 --> Form Validation Class Initialized
DEBUG - 2022-03-23 04:28:27 --> Encrypt Class Initialized
INFO - 2022-03-23 04:28:27 --> Model "Patient_model" initialized
INFO - 2022-03-23 04:28:27 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 04:28:27 --> Model "Prefix_master" initialized
INFO - 2022-03-23 04:28:27 --> Model "Users_model" initialized
INFO - 2022-03-23 04:28:27 --> Model "Hospital_model" initialized
INFO - 2022-03-23 04:28:27 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 04:28:27 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-23 04:28:27 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 04:28:27 --> Final output sent to browser
DEBUG - 2022-03-23 04:28:27 --> Total execution time: 0.0434
ERROR - 2022-03-23 04:28:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 04:28:31 --> Config Class Initialized
INFO - 2022-03-23 04:28:31 --> Hooks Class Initialized
DEBUG - 2022-03-23 04:28:31 --> UTF-8 Support Enabled
INFO - 2022-03-23 04:28:31 --> Utf8 Class Initialized
INFO - 2022-03-23 04:28:31 --> URI Class Initialized
INFO - 2022-03-23 04:28:31 --> Router Class Initialized
INFO - 2022-03-23 04:28:31 --> Output Class Initialized
INFO - 2022-03-23 04:28:31 --> Security Class Initialized
DEBUG - 2022-03-23 04:28:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 04:28:31 --> Input Class Initialized
INFO - 2022-03-23 04:28:31 --> Language Class Initialized
INFO - 2022-03-23 04:28:31 --> Loader Class Initialized
INFO - 2022-03-23 04:28:31 --> Helper loaded: url_helper
INFO - 2022-03-23 04:28:31 --> Helper loaded: form_helper
INFO - 2022-03-23 04:28:31 --> Helper loaded: common_helper
INFO - 2022-03-23 04:28:31 --> Database Driver Class Initialized
DEBUG - 2022-03-23 04:28:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 04:28:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 04:28:31 --> Controller Class Initialized
INFO - 2022-03-23 04:28:31 --> Form Validation Class Initialized
DEBUG - 2022-03-23 04:28:31 --> Encrypt Class Initialized
INFO - 2022-03-23 04:28:31 --> Model "Patient_model" initialized
INFO - 2022-03-23 04:28:31 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 04:28:31 --> Model "Referredby_model" initialized
INFO - 2022-03-23 04:28:31 --> Model "Prefix_master" initialized
INFO - 2022-03-23 04:28:31 --> Model "Hospital_model" initialized
INFO - 2022-03-23 04:28:31 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 04:28:38 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-23 04:28:38 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 04:28:39 --> Final output sent to browser
DEBUG - 2022-03-23 04:28:39 --> Total execution time: 7.5965
ERROR - 2022-03-23 04:29:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 04:29:08 --> Config Class Initialized
INFO - 2022-03-23 04:29:08 --> Hooks Class Initialized
DEBUG - 2022-03-23 04:29:08 --> UTF-8 Support Enabled
INFO - 2022-03-23 04:29:08 --> Utf8 Class Initialized
INFO - 2022-03-23 04:29:08 --> URI Class Initialized
INFO - 2022-03-23 04:29:08 --> Router Class Initialized
INFO - 2022-03-23 04:29:08 --> Output Class Initialized
INFO - 2022-03-23 04:29:08 --> Security Class Initialized
DEBUG - 2022-03-23 04:29:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 04:29:08 --> Input Class Initialized
INFO - 2022-03-23 04:29:08 --> Language Class Initialized
INFO - 2022-03-23 04:29:08 --> Loader Class Initialized
INFO - 2022-03-23 04:29:08 --> Helper loaded: url_helper
INFO - 2022-03-23 04:29:08 --> Helper loaded: form_helper
INFO - 2022-03-23 04:29:08 --> Helper loaded: common_helper
INFO - 2022-03-23 04:29:08 --> Database Driver Class Initialized
DEBUG - 2022-03-23 04:29:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 04:29:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 04:29:08 --> Controller Class Initialized
INFO - 2022-03-23 04:29:08 --> Form Validation Class Initialized
DEBUG - 2022-03-23 04:29:08 --> Encrypt Class Initialized
INFO - 2022-03-23 04:29:08 --> Model "Patient_model" initialized
INFO - 2022-03-23 04:29:08 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 04:29:08 --> Model "Prefix_master" initialized
INFO - 2022-03-23 04:29:08 --> Model "Users_model" initialized
INFO - 2022-03-23 04:29:08 --> Model "Hospital_model" initialized
INFO - 2022-03-23 04:29:09 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-23 04:29:09 --> Final output sent to browser
DEBUG - 2022-03-23 04:29:09 --> Total execution time: 0.7846
ERROR - 2022-03-23 04:29:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 04:29:42 --> Config Class Initialized
INFO - 2022-03-23 04:29:42 --> Hooks Class Initialized
DEBUG - 2022-03-23 04:29:42 --> UTF-8 Support Enabled
INFO - 2022-03-23 04:29:42 --> Utf8 Class Initialized
INFO - 2022-03-23 04:29:42 --> URI Class Initialized
INFO - 2022-03-23 04:29:42 --> Router Class Initialized
INFO - 2022-03-23 04:29:42 --> Output Class Initialized
INFO - 2022-03-23 04:29:42 --> Security Class Initialized
DEBUG - 2022-03-23 04:29:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 04:29:42 --> Input Class Initialized
INFO - 2022-03-23 04:29:42 --> Language Class Initialized
INFO - 2022-03-23 04:29:42 --> Loader Class Initialized
INFO - 2022-03-23 04:29:42 --> Helper loaded: url_helper
INFO - 2022-03-23 04:29:42 --> Helper loaded: form_helper
INFO - 2022-03-23 04:29:42 --> Helper loaded: common_helper
INFO - 2022-03-23 04:29:42 --> Database Driver Class Initialized
DEBUG - 2022-03-23 04:29:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 04:29:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 04:29:42 --> Controller Class Initialized
INFO - 2022-03-23 04:29:42 --> Form Validation Class Initialized
DEBUG - 2022-03-23 04:29:42 --> Encrypt Class Initialized
INFO - 2022-03-23 04:29:42 --> Model "Patient_model" initialized
INFO - 2022-03-23 04:29:42 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 04:29:42 --> Model "Referredby_model" initialized
INFO - 2022-03-23 04:29:42 --> Model "Prefix_master" initialized
INFO - 2022-03-23 04:29:42 --> Model "Hospital_model" initialized
INFO - 2022-03-23 04:29:42 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 04:29:42 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-23 04:29:42 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 04:29:42 --> Final output sent to browser
DEBUG - 2022-03-23 04:29:42 --> Total execution time: 0.0486
ERROR - 2022-03-23 04:30:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 04:30:02 --> Config Class Initialized
INFO - 2022-03-23 04:30:02 --> Hooks Class Initialized
DEBUG - 2022-03-23 04:30:02 --> UTF-8 Support Enabled
INFO - 2022-03-23 04:30:02 --> Utf8 Class Initialized
INFO - 2022-03-23 04:30:02 --> URI Class Initialized
INFO - 2022-03-23 04:30:02 --> Router Class Initialized
INFO - 2022-03-23 04:30:02 --> Output Class Initialized
INFO - 2022-03-23 04:30:02 --> Security Class Initialized
DEBUG - 2022-03-23 04:30:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 04:30:02 --> Input Class Initialized
INFO - 2022-03-23 04:30:02 --> Language Class Initialized
INFO - 2022-03-23 04:30:02 --> Loader Class Initialized
INFO - 2022-03-23 04:30:02 --> Helper loaded: url_helper
INFO - 2022-03-23 04:30:02 --> Helper loaded: form_helper
INFO - 2022-03-23 04:30:02 --> Helper loaded: common_helper
INFO - 2022-03-23 04:30:02 --> Database Driver Class Initialized
DEBUG - 2022-03-23 04:30:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 04:30:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 04:30:02 --> Controller Class Initialized
INFO - 2022-03-23 04:30:02 --> Form Validation Class Initialized
DEBUG - 2022-03-23 04:30:02 --> Encrypt Class Initialized
INFO - 2022-03-23 04:30:02 --> Model "Patient_model" initialized
INFO - 2022-03-23 04:30:02 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 04:30:02 --> Model "Referredby_model" initialized
INFO - 2022-03-23 04:30:02 --> Model "Prefix_master" initialized
INFO - 2022-03-23 04:30:02 --> Model "Hospital_model" initialized
INFO - 2022-03-23 04:30:02 --> Upload Class Initialized
INFO - 2022-03-23 04:30:02 --> Final output sent to browser
DEBUG - 2022-03-23 04:30:02 --> Total execution time: 0.0198
ERROR - 2022-03-23 04:30:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 04:30:08 --> Config Class Initialized
INFO - 2022-03-23 04:30:08 --> Hooks Class Initialized
DEBUG - 2022-03-23 04:30:08 --> UTF-8 Support Enabled
INFO - 2022-03-23 04:30:08 --> Utf8 Class Initialized
INFO - 2022-03-23 04:30:08 --> URI Class Initialized
INFO - 2022-03-23 04:30:08 --> Router Class Initialized
INFO - 2022-03-23 04:30:08 --> Output Class Initialized
INFO - 2022-03-23 04:30:08 --> Security Class Initialized
DEBUG - 2022-03-23 04:30:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 04:30:08 --> Input Class Initialized
INFO - 2022-03-23 04:30:08 --> Language Class Initialized
INFO - 2022-03-23 04:30:08 --> Loader Class Initialized
INFO - 2022-03-23 04:30:08 --> Helper loaded: url_helper
INFO - 2022-03-23 04:30:08 --> Helper loaded: form_helper
INFO - 2022-03-23 04:30:08 --> Helper loaded: common_helper
INFO - 2022-03-23 04:30:08 --> Database Driver Class Initialized
DEBUG - 2022-03-23 04:30:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 04:30:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 04:30:08 --> Controller Class Initialized
INFO - 2022-03-23 04:30:08 --> Form Validation Class Initialized
DEBUG - 2022-03-23 04:30:08 --> Encrypt Class Initialized
INFO - 2022-03-23 04:30:08 --> Model "Patient_model" initialized
INFO - 2022-03-23 04:30:08 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 04:30:08 --> Model "Referredby_model" initialized
INFO - 2022-03-23 04:30:08 --> Model "Prefix_master" initialized
INFO - 2022-03-23 04:30:08 --> Model "Hospital_model" initialized
ERROR - 2022-03-23 04:30:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 04:30:08 --> Config Class Initialized
INFO - 2022-03-23 04:30:08 --> Hooks Class Initialized
DEBUG - 2022-03-23 04:30:08 --> UTF-8 Support Enabled
INFO - 2022-03-23 04:30:08 --> Utf8 Class Initialized
INFO - 2022-03-23 04:30:08 --> URI Class Initialized
INFO - 2022-03-23 04:30:08 --> Router Class Initialized
INFO - 2022-03-23 04:30:08 --> Output Class Initialized
INFO - 2022-03-23 04:30:08 --> Security Class Initialized
DEBUG - 2022-03-23 04:30:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 04:30:08 --> Input Class Initialized
INFO - 2022-03-23 04:30:08 --> Language Class Initialized
INFO - 2022-03-23 04:30:08 --> Loader Class Initialized
INFO - 2022-03-23 04:30:08 --> Helper loaded: url_helper
INFO - 2022-03-23 04:30:08 --> Helper loaded: form_helper
INFO - 2022-03-23 04:30:08 --> Helper loaded: common_helper
INFO - 2022-03-23 04:30:08 --> Database Driver Class Initialized
DEBUG - 2022-03-23 04:30:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 04:30:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 04:30:08 --> Controller Class Initialized
INFO - 2022-03-23 04:30:08 --> Form Validation Class Initialized
DEBUG - 2022-03-23 04:30:08 --> Encrypt Class Initialized
INFO - 2022-03-23 04:30:08 --> Model "Patient_model" initialized
INFO - 2022-03-23 04:30:08 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 04:30:08 --> Model "Referredby_model" initialized
INFO - 2022-03-23 04:30:08 --> Model "Prefix_master" initialized
INFO - 2022-03-23 04:30:08 --> Model "Hospital_model" initialized
INFO - 2022-03-23 04:30:08 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 04:30:08 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-23 04:30:08 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 04:30:08 --> Final output sent to browser
DEBUG - 2022-03-23 04:30:08 --> Total execution time: 0.0310
ERROR - 2022-03-23 04:30:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 04:30:09 --> Config Class Initialized
INFO - 2022-03-23 04:30:09 --> Hooks Class Initialized
DEBUG - 2022-03-23 04:30:09 --> UTF-8 Support Enabled
INFO - 2022-03-23 04:30:09 --> Utf8 Class Initialized
INFO - 2022-03-23 04:30:09 --> URI Class Initialized
INFO - 2022-03-23 04:30:09 --> Router Class Initialized
INFO - 2022-03-23 04:30:09 --> Output Class Initialized
INFO - 2022-03-23 04:30:09 --> Security Class Initialized
DEBUG - 2022-03-23 04:30:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 04:30:09 --> Input Class Initialized
INFO - 2022-03-23 04:30:09 --> Language Class Initialized
INFO - 2022-03-23 04:30:09 --> Loader Class Initialized
INFO - 2022-03-23 04:30:09 --> Helper loaded: url_helper
INFO - 2022-03-23 04:30:09 --> Helper loaded: form_helper
INFO - 2022-03-23 04:30:09 --> Helper loaded: common_helper
INFO - 2022-03-23 04:30:09 --> Database Driver Class Initialized
DEBUG - 2022-03-23 04:30:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 04:30:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 04:30:09 --> Controller Class Initialized
INFO - 2022-03-23 04:30:09 --> Form Validation Class Initialized
DEBUG - 2022-03-23 04:30:09 --> Encrypt Class Initialized
INFO - 2022-03-23 04:30:09 --> Model "Patient_model" initialized
INFO - 2022-03-23 04:30:09 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 04:30:09 --> Model "Prefix_master" initialized
INFO - 2022-03-23 04:30:09 --> Model "Users_model" initialized
INFO - 2022-03-23 04:30:09 --> Model "Hospital_model" initialized
INFO - 2022-03-23 04:30:09 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 04:30:09 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-23 04:30:09 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 04:30:09 --> Final output sent to browser
DEBUG - 2022-03-23 04:30:09 --> Total execution time: 0.0373
ERROR - 2022-03-23 04:30:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 04:30:12 --> Config Class Initialized
INFO - 2022-03-23 04:30:12 --> Hooks Class Initialized
DEBUG - 2022-03-23 04:30:12 --> UTF-8 Support Enabled
INFO - 2022-03-23 04:30:12 --> Utf8 Class Initialized
INFO - 2022-03-23 04:30:12 --> URI Class Initialized
INFO - 2022-03-23 04:30:12 --> Router Class Initialized
INFO - 2022-03-23 04:30:12 --> Output Class Initialized
INFO - 2022-03-23 04:30:12 --> Security Class Initialized
DEBUG - 2022-03-23 04:30:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 04:30:12 --> Input Class Initialized
INFO - 2022-03-23 04:30:12 --> Language Class Initialized
INFO - 2022-03-23 04:30:12 --> Loader Class Initialized
INFO - 2022-03-23 04:30:12 --> Helper loaded: url_helper
INFO - 2022-03-23 04:30:12 --> Helper loaded: form_helper
INFO - 2022-03-23 04:30:12 --> Helper loaded: common_helper
INFO - 2022-03-23 04:30:12 --> Database Driver Class Initialized
DEBUG - 2022-03-23 04:30:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 04:30:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 04:30:12 --> Controller Class Initialized
INFO - 2022-03-23 04:30:12 --> Form Validation Class Initialized
DEBUG - 2022-03-23 04:30:12 --> Encrypt Class Initialized
INFO - 2022-03-23 04:30:12 --> Model "Patient_model" initialized
INFO - 2022-03-23 04:30:12 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 04:30:12 --> Model "Referredby_model" initialized
INFO - 2022-03-23 04:30:12 --> Model "Prefix_master" initialized
INFO - 2022-03-23 04:30:12 --> Model "Hospital_model" initialized
INFO - 2022-03-23 04:30:13 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 04:30:19 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-23 04:30:19 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
ERROR - 2022-03-23 04:30:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 04:30:20 --> Config Class Initialized
INFO - 2022-03-23 04:30:20 --> Hooks Class Initialized
DEBUG - 2022-03-23 04:30:20 --> UTF-8 Support Enabled
INFO - 2022-03-23 04:30:20 --> Utf8 Class Initialized
INFO - 2022-03-23 04:30:20 --> URI Class Initialized
INFO - 2022-03-23 04:30:20 --> Router Class Initialized
INFO - 2022-03-23 04:30:20 --> Output Class Initialized
INFO - 2022-03-23 04:30:20 --> Security Class Initialized
DEBUG - 2022-03-23 04:30:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 04:30:20 --> Input Class Initialized
INFO - 2022-03-23 04:30:20 --> Language Class Initialized
INFO - 2022-03-23 04:30:20 --> Loader Class Initialized
INFO - 2022-03-23 04:30:20 --> Helper loaded: url_helper
INFO - 2022-03-23 04:30:20 --> Helper loaded: form_helper
INFO - 2022-03-23 04:30:20 --> Helper loaded: common_helper
INFO - 2022-03-23 04:30:20 --> Database Driver Class Initialized
DEBUG - 2022-03-23 04:30:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 04:30:20 --> Final output sent to browser
DEBUG - 2022-03-23 04:30:20 --> Total execution time: 6.5516
INFO - 2022-03-23 04:30:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 04:30:20 --> Controller Class Initialized
INFO - 2022-03-23 04:30:20 --> Form Validation Class Initialized
DEBUG - 2022-03-23 04:30:20 --> Encrypt Class Initialized
INFO - 2022-03-23 04:30:20 --> Model "Patient_model" initialized
INFO - 2022-03-23 04:30:20 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 04:30:20 --> Model "Referredby_model" initialized
INFO - 2022-03-23 04:30:20 --> Model "Prefix_master" initialized
INFO - 2022-03-23 04:30:20 --> Model "Hospital_model" initialized
INFO - 2022-03-23 04:30:21 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 04:30:27 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-23 04:30:27 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 04:30:28 --> Final output sent to browser
DEBUG - 2022-03-23 04:30:28 --> Total execution time: 6.9083
ERROR - 2022-03-23 04:30:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 04:30:33 --> Config Class Initialized
INFO - 2022-03-23 04:30:33 --> Hooks Class Initialized
DEBUG - 2022-03-23 04:30:33 --> UTF-8 Support Enabled
INFO - 2022-03-23 04:30:33 --> Utf8 Class Initialized
INFO - 2022-03-23 04:30:33 --> URI Class Initialized
INFO - 2022-03-23 04:30:33 --> Router Class Initialized
INFO - 2022-03-23 04:30:33 --> Output Class Initialized
INFO - 2022-03-23 04:30:33 --> Security Class Initialized
DEBUG - 2022-03-23 04:30:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 04:30:33 --> Input Class Initialized
INFO - 2022-03-23 04:30:33 --> Language Class Initialized
INFO - 2022-03-23 04:30:33 --> Loader Class Initialized
INFO - 2022-03-23 04:30:33 --> Helper loaded: url_helper
INFO - 2022-03-23 04:30:33 --> Helper loaded: form_helper
INFO - 2022-03-23 04:30:33 --> Helper loaded: common_helper
INFO - 2022-03-23 04:30:33 --> Database Driver Class Initialized
DEBUG - 2022-03-23 04:30:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 04:30:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 04:30:33 --> Controller Class Initialized
INFO - 2022-03-23 04:30:33 --> Form Validation Class Initialized
DEBUG - 2022-03-23 04:30:33 --> Encrypt Class Initialized
INFO - 2022-03-23 04:30:33 --> Model "Patient_model" initialized
INFO - 2022-03-23 04:30:33 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 04:30:33 --> Model "Prefix_master" initialized
INFO - 2022-03-23 04:30:33 --> Model "Users_model" initialized
INFO - 2022-03-23 04:30:33 --> Model "Hospital_model" initialized
ERROR - 2022-03-23 04:30:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 04:30:33 --> Config Class Initialized
INFO - 2022-03-23 04:30:33 --> Hooks Class Initialized
DEBUG - 2022-03-23 04:30:33 --> UTF-8 Support Enabled
INFO - 2022-03-23 04:30:33 --> Utf8 Class Initialized
INFO - 2022-03-23 04:30:33 --> URI Class Initialized
INFO - 2022-03-23 04:30:33 --> Router Class Initialized
INFO - 2022-03-23 04:30:33 --> Output Class Initialized
INFO - 2022-03-23 04:30:33 --> Security Class Initialized
DEBUG - 2022-03-23 04:30:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 04:30:33 --> Input Class Initialized
INFO - 2022-03-23 04:30:33 --> Language Class Initialized
INFO - 2022-03-23 04:30:33 --> Loader Class Initialized
INFO - 2022-03-23 04:30:33 --> Helper loaded: url_helper
INFO - 2022-03-23 04:30:33 --> Helper loaded: form_helper
INFO - 2022-03-23 04:30:33 --> Helper loaded: common_helper
INFO - 2022-03-23 04:30:33 --> Database Driver Class Initialized
DEBUG - 2022-03-23 04:30:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 04:30:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 04:30:33 --> Controller Class Initialized
INFO - 2022-03-23 04:30:33 --> Form Validation Class Initialized
DEBUG - 2022-03-23 04:30:33 --> Encrypt Class Initialized
INFO - 2022-03-23 04:30:33 --> Model "Patient_model" initialized
INFO - 2022-03-23 04:30:33 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 04:30:33 --> Model "Prefix_master" initialized
INFO - 2022-03-23 04:30:33 --> Model "Users_model" initialized
INFO - 2022-03-23 04:30:33 --> Model "Hospital_model" initialized
INFO - 2022-03-23 04:30:33 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 04:30:33 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-23 04:30:33 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 04:30:33 --> Final output sent to browser
DEBUG - 2022-03-23 04:30:33 --> Total execution time: 0.0615
ERROR - 2022-03-23 04:30:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 04:30:47 --> Config Class Initialized
INFO - 2022-03-23 04:30:47 --> Hooks Class Initialized
DEBUG - 2022-03-23 04:30:47 --> UTF-8 Support Enabled
INFO - 2022-03-23 04:30:47 --> Utf8 Class Initialized
INFO - 2022-03-23 04:30:47 --> URI Class Initialized
INFO - 2022-03-23 04:30:47 --> Router Class Initialized
INFO - 2022-03-23 04:30:47 --> Output Class Initialized
INFO - 2022-03-23 04:30:47 --> Security Class Initialized
DEBUG - 2022-03-23 04:30:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 04:30:47 --> Input Class Initialized
INFO - 2022-03-23 04:30:47 --> Language Class Initialized
INFO - 2022-03-23 04:30:47 --> Loader Class Initialized
INFO - 2022-03-23 04:30:47 --> Helper loaded: url_helper
INFO - 2022-03-23 04:30:47 --> Helper loaded: form_helper
INFO - 2022-03-23 04:30:47 --> Helper loaded: common_helper
INFO - 2022-03-23 04:30:47 --> Database Driver Class Initialized
DEBUG - 2022-03-23 04:30:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 04:30:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 04:30:47 --> Controller Class Initialized
INFO - 2022-03-23 04:30:47 --> Form Validation Class Initialized
DEBUG - 2022-03-23 04:30:47 --> Encrypt Class Initialized
INFO - 2022-03-23 04:30:47 --> Model "Patient_model" initialized
INFO - 2022-03-23 04:30:47 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 04:30:47 --> Model "Prefix_master" initialized
INFO - 2022-03-23 04:30:47 --> Model "Users_model" initialized
INFO - 2022-03-23 04:30:47 --> Model "Hospital_model" initialized
ERROR - 2022-03-23 04:30:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 04:30:47 --> Config Class Initialized
INFO - 2022-03-23 04:30:47 --> Hooks Class Initialized
DEBUG - 2022-03-23 04:30:47 --> UTF-8 Support Enabled
INFO - 2022-03-23 04:30:47 --> Utf8 Class Initialized
INFO - 2022-03-23 04:30:47 --> URI Class Initialized
INFO - 2022-03-23 04:30:47 --> Router Class Initialized
INFO - 2022-03-23 04:30:47 --> Output Class Initialized
INFO - 2022-03-23 04:30:47 --> Security Class Initialized
DEBUG - 2022-03-23 04:30:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 04:30:47 --> Input Class Initialized
INFO - 2022-03-23 04:30:47 --> Language Class Initialized
INFO - 2022-03-23 04:30:47 --> Loader Class Initialized
INFO - 2022-03-23 04:30:47 --> Helper loaded: url_helper
INFO - 2022-03-23 04:30:47 --> Helper loaded: form_helper
INFO - 2022-03-23 04:30:47 --> Helper loaded: common_helper
INFO - 2022-03-23 04:30:47 --> Database Driver Class Initialized
DEBUG - 2022-03-23 04:30:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 04:30:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 04:30:47 --> Controller Class Initialized
INFO - 2022-03-23 04:30:47 --> Form Validation Class Initialized
DEBUG - 2022-03-23 04:30:47 --> Encrypt Class Initialized
INFO - 2022-03-23 04:30:47 --> Model "Patient_model" initialized
INFO - 2022-03-23 04:30:47 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 04:30:47 --> Model "Prefix_master" initialized
INFO - 2022-03-23 04:30:47 --> Model "Users_model" initialized
INFO - 2022-03-23 04:30:47 --> Model "Hospital_model" initialized
INFO - 2022-03-23 04:30:47 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 04:30:47 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-23 04:30:47 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 04:30:47 --> Final output sent to browser
DEBUG - 2022-03-23 04:30:47 --> Total execution time: 0.0576
ERROR - 2022-03-23 04:30:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 04:30:47 --> Config Class Initialized
INFO - 2022-03-23 04:30:47 --> Hooks Class Initialized
DEBUG - 2022-03-23 04:30:47 --> UTF-8 Support Enabled
INFO - 2022-03-23 04:30:47 --> Utf8 Class Initialized
INFO - 2022-03-23 04:30:47 --> URI Class Initialized
INFO - 2022-03-23 04:30:47 --> Router Class Initialized
INFO - 2022-03-23 04:30:47 --> Output Class Initialized
INFO - 2022-03-23 04:30:47 --> Security Class Initialized
DEBUG - 2022-03-23 04:30:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 04:30:47 --> Input Class Initialized
INFO - 2022-03-23 04:30:47 --> Language Class Initialized
INFO - 2022-03-23 04:30:47 --> Loader Class Initialized
INFO - 2022-03-23 04:30:47 --> Helper loaded: url_helper
INFO - 2022-03-23 04:30:47 --> Helper loaded: form_helper
INFO - 2022-03-23 04:30:47 --> Helper loaded: common_helper
INFO - 2022-03-23 04:30:47 --> Database Driver Class Initialized
DEBUG - 2022-03-23 04:30:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 04:30:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 04:30:47 --> Controller Class Initialized
INFO - 2022-03-23 04:30:47 --> Form Validation Class Initialized
DEBUG - 2022-03-23 04:30:47 --> Encrypt Class Initialized
INFO - 2022-03-23 04:30:47 --> Model "Patient_model" initialized
INFO - 2022-03-23 04:30:47 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 04:30:47 --> Model "Prefix_master" initialized
INFO - 2022-03-23 04:30:47 --> Model "Users_model" initialized
INFO - 2022-03-23 04:30:47 --> Model "Hospital_model" initialized
ERROR - 2022-03-23 04:30:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 04:30:48 --> Config Class Initialized
INFO - 2022-03-23 04:30:48 --> Hooks Class Initialized
DEBUG - 2022-03-23 04:30:48 --> UTF-8 Support Enabled
INFO - 2022-03-23 04:30:48 --> Utf8 Class Initialized
INFO - 2022-03-23 04:30:48 --> URI Class Initialized
INFO - 2022-03-23 04:30:48 --> Router Class Initialized
INFO - 2022-03-23 04:30:48 --> Output Class Initialized
INFO - 2022-03-23 04:30:48 --> Security Class Initialized
DEBUG - 2022-03-23 04:30:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 04:30:48 --> Input Class Initialized
INFO - 2022-03-23 04:30:48 --> Language Class Initialized
INFO - 2022-03-23 04:30:48 --> Loader Class Initialized
INFO - 2022-03-23 04:30:48 --> Helper loaded: url_helper
INFO - 2022-03-23 04:30:48 --> Helper loaded: form_helper
INFO - 2022-03-23 04:30:48 --> Helper loaded: common_helper
INFO - 2022-03-23 04:30:48 --> Database Driver Class Initialized
DEBUG - 2022-03-23 04:30:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 04:30:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 04:30:48 --> Controller Class Initialized
INFO - 2022-03-23 04:30:48 --> Form Validation Class Initialized
DEBUG - 2022-03-23 04:30:48 --> Encrypt Class Initialized
INFO - 2022-03-23 04:30:48 --> Model "Patient_model" initialized
INFO - 2022-03-23 04:30:48 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 04:30:48 --> Model "Prefix_master" initialized
INFO - 2022-03-23 04:30:48 --> Model "Users_model" initialized
INFO - 2022-03-23 04:30:48 --> Model "Hospital_model" initialized
INFO - 2022-03-23 04:30:48 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 04:30:48 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-23 04:30:48 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 04:30:48 --> Final output sent to browser
DEBUG - 2022-03-23 04:30:48 --> Total execution time: 0.0575
ERROR - 2022-03-23 04:31:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 04:31:09 --> Config Class Initialized
INFO - 2022-03-23 04:31:09 --> Hooks Class Initialized
DEBUG - 2022-03-23 04:31:09 --> UTF-8 Support Enabled
INFO - 2022-03-23 04:31:09 --> Utf8 Class Initialized
INFO - 2022-03-23 04:31:09 --> URI Class Initialized
INFO - 2022-03-23 04:31:09 --> Router Class Initialized
INFO - 2022-03-23 04:31:09 --> Output Class Initialized
INFO - 2022-03-23 04:31:09 --> Security Class Initialized
DEBUG - 2022-03-23 04:31:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 04:31:09 --> Input Class Initialized
INFO - 2022-03-23 04:31:09 --> Language Class Initialized
INFO - 2022-03-23 04:31:09 --> Loader Class Initialized
INFO - 2022-03-23 04:31:09 --> Helper loaded: url_helper
INFO - 2022-03-23 04:31:09 --> Helper loaded: form_helper
INFO - 2022-03-23 04:31:09 --> Helper loaded: common_helper
INFO - 2022-03-23 04:31:09 --> Database Driver Class Initialized
DEBUG - 2022-03-23 04:31:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 04:31:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 04:31:09 --> Controller Class Initialized
INFO - 2022-03-23 04:31:09 --> Form Validation Class Initialized
DEBUG - 2022-03-23 04:31:09 --> Encrypt Class Initialized
INFO - 2022-03-23 04:31:09 --> Model "Patient_model" initialized
INFO - 2022-03-23 04:31:09 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 04:31:09 --> Model "Prefix_master" initialized
INFO - 2022-03-23 04:31:09 --> Model "Users_model" initialized
INFO - 2022-03-23 04:31:09 --> Model "Hospital_model" initialized
INFO - 2022-03-23 04:31:09 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-23 04:31:10 --> Final output sent to browser
DEBUG - 2022-03-23 04:31:10 --> Total execution time: 0.6693
ERROR - 2022-03-23 04:31:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 04:31:36 --> Config Class Initialized
INFO - 2022-03-23 04:31:36 --> Hooks Class Initialized
DEBUG - 2022-03-23 04:31:36 --> UTF-8 Support Enabled
INFO - 2022-03-23 04:31:36 --> Utf8 Class Initialized
INFO - 2022-03-23 04:31:36 --> URI Class Initialized
INFO - 2022-03-23 04:31:36 --> Router Class Initialized
INFO - 2022-03-23 04:31:36 --> Output Class Initialized
INFO - 2022-03-23 04:31:36 --> Security Class Initialized
DEBUG - 2022-03-23 04:31:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 04:31:36 --> Input Class Initialized
INFO - 2022-03-23 04:31:36 --> Language Class Initialized
INFO - 2022-03-23 04:31:36 --> Loader Class Initialized
INFO - 2022-03-23 04:31:36 --> Helper loaded: url_helper
INFO - 2022-03-23 04:31:36 --> Helper loaded: form_helper
INFO - 2022-03-23 04:31:36 --> Helper loaded: common_helper
INFO - 2022-03-23 04:31:36 --> Database Driver Class Initialized
DEBUG - 2022-03-23 04:31:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 04:31:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 04:31:36 --> Controller Class Initialized
INFO - 2022-03-23 04:31:36 --> Form Validation Class Initialized
DEBUG - 2022-03-23 04:31:36 --> Encrypt Class Initialized
INFO - 2022-03-23 04:31:36 --> Model "Patient_model" initialized
INFO - 2022-03-23 04:31:36 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 04:31:36 --> Model "Prefix_master" initialized
INFO - 2022-03-23 04:31:36 --> Model "Users_model" initialized
INFO - 2022-03-23 04:31:36 --> Model "Hospital_model" initialized
INFO - 2022-03-23 04:31:36 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
ERROR - 2022-03-23 04:31:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 04:31:36 --> Config Class Initialized
INFO - 2022-03-23 04:31:36 --> Hooks Class Initialized
DEBUG - 2022-03-23 04:31:36 --> UTF-8 Support Enabled
INFO - 2022-03-23 04:31:36 --> Utf8 Class Initialized
INFO - 2022-03-23 04:31:36 --> URI Class Initialized
INFO - 2022-03-23 04:31:36 --> Router Class Initialized
INFO - 2022-03-23 04:31:36 --> Output Class Initialized
INFO - 2022-03-23 04:31:36 --> Security Class Initialized
DEBUG - 2022-03-23 04:31:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 04:31:36 --> Input Class Initialized
INFO - 2022-03-23 04:31:36 --> Language Class Initialized
ERROR - 2022-03-23 04:31:36 --> 404 Page Not Found: Karoclient/images
ERROR - 2022-03-23 04:31:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 04:31:36 --> Config Class Initialized
INFO - 2022-03-23 04:31:36 --> Hooks Class Initialized
DEBUG - 2022-03-23 04:31:36 --> UTF-8 Support Enabled
INFO - 2022-03-23 04:31:36 --> Utf8 Class Initialized
INFO - 2022-03-23 04:31:36 --> URI Class Initialized
INFO - 2022-03-23 04:31:36 --> Router Class Initialized
INFO - 2022-03-23 04:31:36 --> Output Class Initialized
INFO - 2022-03-23 04:31:36 --> Security Class Initialized
DEBUG - 2022-03-23 04:31:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 04:31:36 --> Input Class Initialized
INFO - 2022-03-23 04:31:36 --> Language Class Initialized
ERROR - 2022-03-23 04:31:36 --> 404 Page Not Found: Karoclient/images
ERROR - 2022-03-23 04:31:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 04:31:36 --> Config Class Initialized
INFO - 2022-03-23 04:31:36 --> Hooks Class Initialized
DEBUG - 2022-03-23 04:31:36 --> UTF-8 Support Enabled
INFO - 2022-03-23 04:31:36 --> Utf8 Class Initialized
INFO - 2022-03-23 04:31:36 --> URI Class Initialized
INFO - 2022-03-23 04:31:36 --> Router Class Initialized
INFO - 2022-03-23 04:31:36 --> Output Class Initialized
INFO - 2022-03-23 04:31:36 --> Security Class Initialized
DEBUG - 2022-03-23 04:31:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 04:31:36 --> Input Class Initialized
INFO - 2022-03-23 04:31:36 --> Language Class Initialized
ERROR - 2022-03-23 04:31:36 --> 404 Page Not Found: Karoclient/images
INFO - 2022-03-23 04:31:37 --> Final output sent to browser
DEBUG - 2022-03-23 04:31:37 --> Total execution time: 0.7435
ERROR - 2022-03-23 04:31:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 04:31:44 --> Config Class Initialized
INFO - 2022-03-23 04:31:44 --> Hooks Class Initialized
DEBUG - 2022-03-23 04:31:44 --> UTF-8 Support Enabled
INFO - 2022-03-23 04:31:44 --> Utf8 Class Initialized
INFO - 2022-03-23 04:31:44 --> URI Class Initialized
INFO - 2022-03-23 04:31:44 --> Router Class Initialized
INFO - 2022-03-23 04:31:44 --> Output Class Initialized
INFO - 2022-03-23 04:31:44 --> Security Class Initialized
DEBUG - 2022-03-23 04:31:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 04:31:44 --> Input Class Initialized
INFO - 2022-03-23 04:31:44 --> Language Class Initialized
INFO - 2022-03-23 04:31:44 --> Loader Class Initialized
INFO - 2022-03-23 04:31:44 --> Helper loaded: url_helper
INFO - 2022-03-23 04:31:44 --> Helper loaded: form_helper
INFO - 2022-03-23 04:31:44 --> Helper loaded: common_helper
INFO - 2022-03-23 04:31:44 --> Database Driver Class Initialized
DEBUG - 2022-03-23 04:31:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 04:31:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 04:31:44 --> Controller Class Initialized
INFO - 2022-03-23 04:31:44 --> Form Validation Class Initialized
DEBUG - 2022-03-23 04:31:44 --> Encrypt Class Initialized
INFO - 2022-03-23 04:31:44 --> Model "Patient_model" initialized
INFO - 2022-03-23 04:31:44 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 04:31:44 --> Model "Referredby_model" initialized
INFO - 2022-03-23 04:31:44 --> Model "Prefix_master" initialized
INFO - 2022-03-23 04:31:44 --> Model "Hospital_model" initialized
INFO - 2022-03-23 04:31:44 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 04:31:44 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-23 04:31:44 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 04:31:44 --> Final output sent to browser
DEBUG - 2022-03-23 04:31:44 --> Total execution time: 0.0281
ERROR - 2022-03-23 04:31:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 04:31:45 --> Config Class Initialized
INFO - 2022-03-23 04:31:45 --> Hooks Class Initialized
DEBUG - 2022-03-23 04:31:45 --> UTF-8 Support Enabled
INFO - 2022-03-23 04:31:45 --> Utf8 Class Initialized
INFO - 2022-03-23 04:31:45 --> URI Class Initialized
INFO - 2022-03-23 04:31:45 --> Router Class Initialized
INFO - 2022-03-23 04:31:45 --> Output Class Initialized
INFO - 2022-03-23 04:31:45 --> Security Class Initialized
DEBUG - 2022-03-23 04:31:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 04:31:45 --> Input Class Initialized
INFO - 2022-03-23 04:31:45 --> Language Class Initialized
ERROR - 2022-03-23 04:31:45 --> 404 Page Not Found: Karoclient/images
ERROR - 2022-03-23 04:32:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 04:32:01 --> Config Class Initialized
INFO - 2022-03-23 04:32:01 --> Hooks Class Initialized
DEBUG - 2022-03-23 04:32:01 --> UTF-8 Support Enabled
INFO - 2022-03-23 04:32:01 --> Utf8 Class Initialized
INFO - 2022-03-23 04:32:01 --> URI Class Initialized
INFO - 2022-03-23 04:32:01 --> Router Class Initialized
INFO - 2022-03-23 04:32:01 --> Output Class Initialized
INFO - 2022-03-23 04:32:01 --> Security Class Initialized
DEBUG - 2022-03-23 04:32:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 04:32:01 --> Input Class Initialized
INFO - 2022-03-23 04:32:01 --> Language Class Initialized
INFO - 2022-03-23 04:32:01 --> Loader Class Initialized
INFO - 2022-03-23 04:32:01 --> Helper loaded: url_helper
INFO - 2022-03-23 04:32:01 --> Helper loaded: form_helper
INFO - 2022-03-23 04:32:01 --> Helper loaded: common_helper
INFO - 2022-03-23 04:32:01 --> Database Driver Class Initialized
DEBUG - 2022-03-23 04:32:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 04:32:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 04:32:01 --> Controller Class Initialized
INFO - 2022-03-23 04:32:01 --> Form Validation Class Initialized
DEBUG - 2022-03-23 04:32:01 --> Encrypt Class Initialized
INFO - 2022-03-23 04:32:01 --> Model "Patient_model" initialized
INFO - 2022-03-23 04:32:01 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 04:32:01 --> Model "Referredby_model" initialized
INFO - 2022-03-23 04:32:01 --> Model "Prefix_master" initialized
INFO - 2022-03-23 04:32:01 --> Model "Hospital_model" initialized
INFO - 2022-03-23 04:32:01 --> Upload Class Initialized
INFO - 2022-03-23 04:32:01 --> Final output sent to browser
DEBUG - 2022-03-23 04:32:01 --> Total execution time: 0.0102
ERROR - 2022-03-23 04:32:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 04:32:06 --> Config Class Initialized
INFO - 2022-03-23 04:32:06 --> Hooks Class Initialized
DEBUG - 2022-03-23 04:32:06 --> UTF-8 Support Enabled
INFO - 2022-03-23 04:32:06 --> Utf8 Class Initialized
INFO - 2022-03-23 04:32:06 --> URI Class Initialized
INFO - 2022-03-23 04:32:06 --> Router Class Initialized
INFO - 2022-03-23 04:32:06 --> Output Class Initialized
INFO - 2022-03-23 04:32:06 --> Security Class Initialized
DEBUG - 2022-03-23 04:32:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 04:32:06 --> Input Class Initialized
INFO - 2022-03-23 04:32:06 --> Language Class Initialized
INFO - 2022-03-23 04:32:06 --> Loader Class Initialized
INFO - 2022-03-23 04:32:06 --> Helper loaded: url_helper
INFO - 2022-03-23 04:32:06 --> Helper loaded: form_helper
INFO - 2022-03-23 04:32:06 --> Helper loaded: common_helper
INFO - 2022-03-23 04:32:06 --> Database Driver Class Initialized
DEBUG - 2022-03-23 04:32:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 04:32:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 04:32:06 --> Controller Class Initialized
INFO - 2022-03-23 04:32:06 --> Form Validation Class Initialized
DEBUG - 2022-03-23 04:32:06 --> Encrypt Class Initialized
INFO - 2022-03-23 04:32:06 --> Model "Patient_model" initialized
INFO - 2022-03-23 04:32:06 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 04:32:06 --> Model "Referredby_model" initialized
INFO - 2022-03-23 04:32:06 --> Model "Prefix_master" initialized
INFO - 2022-03-23 04:32:06 --> Model "Hospital_model" initialized
ERROR - 2022-03-23 04:32:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 04:32:06 --> Config Class Initialized
INFO - 2022-03-23 04:32:06 --> Hooks Class Initialized
DEBUG - 2022-03-23 04:32:06 --> UTF-8 Support Enabled
INFO - 2022-03-23 04:32:06 --> Utf8 Class Initialized
INFO - 2022-03-23 04:32:06 --> URI Class Initialized
INFO - 2022-03-23 04:32:06 --> Router Class Initialized
INFO - 2022-03-23 04:32:06 --> Output Class Initialized
INFO - 2022-03-23 04:32:06 --> Security Class Initialized
DEBUG - 2022-03-23 04:32:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 04:32:06 --> Input Class Initialized
INFO - 2022-03-23 04:32:06 --> Language Class Initialized
INFO - 2022-03-23 04:32:06 --> Loader Class Initialized
INFO - 2022-03-23 04:32:06 --> Helper loaded: url_helper
INFO - 2022-03-23 04:32:06 --> Helper loaded: form_helper
INFO - 2022-03-23 04:32:06 --> Helper loaded: common_helper
INFO - 2022-03-23 04:32:06 --> Database Driver Class Initialized
DEBUG - 2022-03-23 04:32:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 04:32:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 04:32:06 --> Controller Class Initialized
INFO - 2022-03-23 04:32:06 --> Form Validation Class Initialized
DEBUG - 2022-03-23 04:32:06 --> Encrypt Class Initialized
INFO - 2022-03-23 04:32:06 --> Model "Patient_model" initialized
INFO - 2022-03-23 04:32:06 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 04:32:06 --> Model "Referredby_model" initialized
INFO - 2022-03-23 04:32:06 --> Model "Prefix_master" initialized
INFO - 2022-03-23 04:32:06 --> Model "Hospital_model" initialized
INFO - 2022-03-23 04:32:06 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 04:32:06 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-23 04:32:06 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 04:32:06 --> Final output sent to browser
DEBUG - 2022-03-23 04:32:06 --> Total execution time: 0.1002
ERROR - 2022-03-23 04:32:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 04:32:07 --> Config Class Initialized
INFO - 2022-03-23 04:32:07 --> Hooks Class Initialized
DEBUG - 2022-03-23 04:32:07 --> UTF-8 Support Enabled
INFO - 2022-03-23 04:32:07 --> Utf8 Class Initialized
INFO - 2022-03-23 04:32:07 --> URI Class Initialized
INFO - 2022-03-23 04:32:07 --> Router Class Initialized
INFO - 2022-03-23 04:32:07 --> Output Class Initialized
INFO - 2022-03-23 04:32:07 --> Security Class Initialized
DEBUG - 2022-03-23 04:32:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 04:32:07 --> Input Class Initialized
INFO - 2022-03-23 04:32:07 --> Language Class Initialized
INFO - 2022-03-23 04:32:07 --> Loader Class Initialized
INFO - 2022-03-23 04:32:07 --> Helper loaded: url_helper
INFO - 2022-03-23 04:32:07 --> Helper loaded: form_helper
INFO - 2022-03-23 04:32:07 --> Helper loaded: common_helper
INFO - 2022-03-23 04:32:07 --> Database Driver Class Initialized
DEBUG - 2022-03-23 04:32:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 04:32:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 04:32:07 --> Controller Class Initialized
INFO - 2022-03-23 04:32:07 --> Form Validation Class Initialized
DEBUG - 2022-03-23 04:32:07 --> Encrypt Class Initialized
INFO - 2022-03-23 04:32:07 --> Model "Patient_model" initialized
INFO - 2022-03-23 04:32:07 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 04:32:07 --> Model "Prefix_master" initialized
INFO - 2022-03-23 04:32:07 --> Model "Users_model" initialized
INFO - 2022-03-23 04:32:07 --> Model "Hospital_model" initialized
INFO - 2022-03-23 04:32:07 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 04:32:07 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-23 04:32:07 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 04:32:07 --> Final output sent to browser
DEBUG - 2022-03-23 04:32:07 --> Total execution time: 0.0421
ERROR - 2022-03-23 04:32:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 04:32:10 --> Config Class Initialized
INFO - 2022-03-23 04:32:10 --> Hooks Class Initialized
DEBUG - 2022-03-23 04:32:10 --> UTF-8 Support Enabled
INFO - 2022-03-23 04:32:10 --> Utf8 Class Initialized
INFO - 2022-03-23 04:32:10 --> URI Class Initialized
INFO - 2022-03-23 04:32:10 --> Router Class Initialized
INFO - 2022-03-23 04:32:10 --> Output Class Initialized
INFO - 2022-03-23 04:32:10 --> Security Class Initialized
DEBUG - 2022-03-23 04:32:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 04:32:10 --> Input Class Initialized
INFO - 2022-03-23 04:32:10 --> Language Class Initialized
INFO - 2022-03-23 04:32:10 --> Loader Class Initialized
INFO - 2022-03-23 04:32:10 --> Helper loaded: url_helper
INFO - 2022-03-23 04:32:10 --> Helper loaded: form_helper
INFO - 2022-03-23 04:32:10 --> Helper loaded: common_helper
INFO - 2022-03-23 04:32:10 --> Database Driver Class Initialized
DEBUG - 2022-03-23 04:32:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 04:32:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 04:32:10 --> Controller Class Initialized
INFO - 2022-03-23 04:32:10 --> Form Validation Class Initialized
DEBUG - 2022-03-23 04:32:10 --> Encrypt Class Initialized
INFO - 2022-03-23 04:32:10 --> Model "Patient_model" initialized
INFO - 2022-03-23 04:32:10 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 04:32:10 --> Model "Referredby_model" initialized
INFO - 2022-03-23 04:32:10 --> Model "Prefix_master" initialized
INFO - 2022-03-23 04:32:10 --> Model "Hospital_model" initialized
INFO - 2022-03-23 04:32:10 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 04:32:17 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-23 04:32:17 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 04:32:18 --> Final output sent to browser
DEBUG - 2022-03-23 04:32:18 --> Total execution time: 6.5415
ERROR - 2022-03-23 04:32:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 04:32:41 --> Config Class Initialized
INFO - 2022-03-23 04:32:41 --> Hooks Class Initialized
DEBUG - 2022-03-23 04:32:41 --> UTF-8 Support Enabled
INFO - 2022-03-23 04:32:41 --> Utf8 Class Initialized
INFO - 2022-03-23 04:32:41 --> URI Class Initialized
INFO - 2022-03-23 04:32:41 --> Router Class Initialized
INFO - 2022-03-23 04:32:41 --> Output Class Initialized
INFO - 2022-03-23 04:32:41 --> Security Class Initialized
DEBUG - 2022-03-23 04:32:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 04:32:41 --> Input Class Initialized
INFO - 2022-03-23 04:32:41 --> Language Class Initialized
INFO - 2022-03-23 04:32:41 --> Loader Class Initialized
INFO - 2022-03-23 04:32:41 --> Helper loaded: url_helper
INFO - 2022-03-23 04:32:41 --> Helper loaded: form_helper
INFO - 2022-03-23 04:32:41 --> Helper loaded: common_helper
INFO - 2022-03-23 04:32:41 --> Database Driver Class Initialized
DEBUG - 2022-03-23 04:32:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 04:32:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 04:32:41 --> Controller Class Initialized
INFO - 2022-03-23 04:32:41 --> Form Validation Class Initialized
DEBUG - 2022-03-23 04:32:41 --> Encrypt Class Initialized
INFO - 2022-03-23 04:32:41 --> Model "Patient_model" initialized
INFO - 2022-03-23 04:32:41 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 04:32:41 --> Model "Prefix_master" initialized
INFO - 2022-03-23 04:32:41 --> Model "Users_model" initialized
INFO - 2022-03-23 04:32:41 --> Model "Hospital_model" initialized
INFO - 2022-03-23 04:32:41 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-23 04:32:42 --> Final output sent to browser
DEBUG - 2022-03-23 04:32:42 --> Total execution time: 0.9719
ERROR - 2022-03-23 04:33:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 04:33:19 --> Config Class Initialized
INFO - 2022-03-23 04:33:19 --> Hooks Class Initialized
DEBUG - 2022-03-23 04:33:19 --> UTF-8 Support Enabled
INFO - 2022-03-23 04:33:19 --> Utf8 Class Initialized
INFO - 2022-03-23 04:33:19 --> URI Class Initialized
INFO - 2022-03-23 04:33:19 --> Router Class Initialized
INFO - 2022-03-23 04:33:19 --> Output Class Initialized
INFO - 2022-03-23 04:33:19 --> Security Class Initialized
DEBUG - 2022-03-23 04:33:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 04:33:19 --> Input Class Initialized
INFO - 2022-03-23 04:33:19 --> Language Class Initialized
INFO - 2022-03-23 04:33:19 --> Loader Class Initialized
INFO - 2022-03-23 04:33:19 --> Helper loaded: url_helper
INFO - 2022-03-23 04:33:19 --> Helper loaded: form_helper
INFO - 2022-03-23 04:33:19 --> Helper loaded: common_helper
INFO - 2022-03-23 04:33:19 --> Database Driver Class Initialized
DEBUG - 2022-03-23 04:33:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 04:33:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 04:33:19 --> Controller Class Initialized
INFO - 2022-03-23 04:33:19 --> Form Validation Class Initialized
DEBUG - 2022-03-23 04:33:19 --> Encrypt Class Initialized
INFO - 2022-03-23 04:33:19 --> Model "Patient_model" initialized
INFO - 2022-03-23 04:33:19 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 04:33:19 --> Model "Referredby_model" initialized
INFO - 2022-03-23 04:33:19 --> Model "Prefix_master" initialized
INFO - 2022-03-23 04:33:19 --> Model "Hospital_model" initialized
INFO - 2022-03-23 04:33:19 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 04:33:19 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-23 04:33:19 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 04:33:19 --> Final output sent to browser
DEBUG - 2022-03-23 04:33:19 --> Total execution time: 0.0387
ERROR - 2022-03-23 04:33:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 04:33:37 --> Config Class Initialized
INFO - 2022-03-23 04:33:37 --> Hooks Class Initialized
DEBUG - 2022-03-23 04:33:37 --> UTF-8 Support Enabled
INFO - 2022-03-23 04:33:37 --> Utf8 Class Initialized
INFO - 2022-03-23 04:33:37 --> URI Class Initialized
INFO - 2022-03-23 04:33:37 --> Router Class Initialized
INFO - 2022-03-23 04:33:37 --> Output Class Initialized
INFO - 2022-03-23 04:33:37 --> Security Class Initialized
DEBUG - 2022-03-23 04:33:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 04:33:37 --> Input Class Initialized
INFO - 2022-03-23 04:33:37 --> Language Class Initialized
INFO - 2022-03-23 04:33:37 --> Loader Class Initialized
INFO - 2022-03-23 04:33:37 --> Helper loaded: url_helper
INFO - 2022-03-23 04:33:37 --> Helper loaded: form_helper
INFO - 2022-03-23 04:33:37 --> Helper loaded: common_helper
INFO - 2022-03-23 04:33:37 --> Database Driver Class Initialized
DEBUG - 2022-03-23 04:33:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 04:33:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 04:33:37 --> Controller Class Initialized
INFO - 2022-03-23 04:33:37 --> Form Validation Class Initialized
DEBUG - 2022-03-23 04:33:37 --> Encrypt Class Initialized
INFO - 2022-03-23 04:33:37 --> Model "Patient_model" initialized
INFO - 2022-03-23 04:33:37 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 04:33:37 --> Model "Referredby_model" initialized
INFO - 2022-03-23 04:33:37 --> Model "Prefix_master" initialized
INFO - 2022-03-23 04:33:37 --> Model "Hospital_model" initialized
INFO - 2022-03-23 04:33:37 --> Upload Class Initialized
INFO - 2022-03-23 04:33:37 --> Final output sent to browser
DEBUG - 2022-03-23 04:33:37 --> Total execution time: 0.0093
ERROR - 2022-03-23 04:33:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 04:33:44 --> Config Class Initialized
INFO - 2022-03-23 04:33:44 --> Hooks Class Initialized
DEBUG - 2022-03-23 04:33:44 --> UTF-8 Support Enabled
INFO - 2022-03-23 04:33:44 --> Utf8 Class Initialized
INFO - 2022-03-23 04:33:44 --> URI Class Initialized
INFO - 2022-03-23 04:33:44 --> Router Class Initialized
INFO - 2022-03-23 04:33:44 --> Output Class Initialized
INFO - 2022-03-23 04:33:44 --> Security Class Initialized
DEBUG - 2022-03-23 04:33:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 04:33:44 --> Input Class Initialized
INFO - 2022-03-23 04:33:44 --> Language Class Initialized
INFO - 2022-03-23 04:33:44 --> Loader Class Initialized
INFO - 2022-03-23 04:33:44 --> Helper loaded: url_helper
INFO - 2022-03-23 04:33:44 --> Helper loaded: form_helper
INFO - 2022-03-23 04:33:44 --> Helper loaded: common_helper
INFO - 2022-03-23 04:33:44 --> Database Driver Class Initialized
DEBUG - 2022-03-23 04:33:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 04:33:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 04:33:44 --> Controller Class Initialized
INFO - 2022-03-23 04:33:44 --> Form Validation Class Initialized
DEBUG - 2022-03-23 04:33:44 --> Encrypt Class Initialized
INFO - 2022-03-23 04:33:44 --> Model "Patient_model" initialized
INFO - 2022-03-23 04:33:44 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 04:33:44 --> Model "Referredby_model" initialized
INFO - 2022-03-23 04:33:44 --> Model "Prefix_master" initialized
INFO - 2022-03-23 04:33:44 --> Model "Hospital_model" initialized
ERROR - 2022-03-23 04:33:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 04:33:44 --> Config Class Initialized
INFO - 2022-03-23 04:33:44 --> Hooks Class Initialized
DEBUG - 2022-03-23 04:33:44 --> UTF-8 Support Enabled
INFO - 2022-03-23 04:33:44 --> Utf8 Class Initialized
INFO - 2022-03-23 04:33:44 --> URI Class Initialized
INFO - 2022-03-23 04:33:44 --> Router Class Initialized
INFO - 2022-03-23 04:33:44 --> Output Class Initialized
INFO - 2022-03-23 04:33:44 --> Security Class Initialized
DEBUG - 2022-03-23 04:33:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 04:33:44 --> Input Class Initialized
INFO - 2022-03-23 04:33:44 --> Language Class Initialized
INFO - 2022-03-23 04:33:44 --> Loader Class Initialized
INFO - 2022-03-23 04:33:44 --> Helper loaded: url_helper
INFO - 2022-03-23 04:33:44 --> Helper loaded: form_helper
INFO - 2022-03-23 04:33:44 --> Helper loaded: common_helper
INFO - 2022-03-23 04:33:44 --> Database Driver Class Initialized
DEBUG - 2022-03-23 04:33:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 04:33:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 04:33:44 --> Controller Class Initialized
INFO - 2022-03-23 04:33:44 --> Form Validation Class Initialized
DEBUG - 2022-03-23 04:33:44 --> Encrypt Class Initialized
INFO - 2022-03-23 04:33:44 --> Model "Patient_model" initialized
INFO - 2022-03-23 04:33:44 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 04:33:44 --> Model "Referredby_model" initialized
INFO - 2022-03-23 04:33:44 --> Model "Prefix_master" initialized
INFO - 2022-03-23 04:33:44 --> Model "Hospital_model" initialized
INFO - 2022-03-23 04:33:44 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 04:33:44 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-23 04:33:44 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 04:33:44 --> Final output sent to browser
DEBUG - 2022-03-23 04:33:44 --> Total execution time: 0.0623
ERROR - 2022-03-23 04:33:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 04:33:45 --> Config Class Initialized
INFO - 2022-03-23 04:33:45 --> Hooks Class Initialized
DEBUG - 2022-03-23 04:33:45 --> UTF-8 Support Enabled
INFO - 2022-03-23 04:33:45 --> Utf8 Class Initialized
INFO - 2022-03-23 04:33:45 --> URI Class Initialized
INFO - 2022-03-23 04:33:45 --> Router Class Initialized
INFO - 2022-03-23 04:33:45 --> Output Class Initialized
INFO - 2022-03-23 04:33:45 --> Security Class Initialized
DEBUG - 2022-03-23 04:33:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 04:33:45 --> Input Class Initialized
INFO - 2022-03-23 04:33:45 --> Language Class Initialized
INFO - 2022-03-23 04:33:45 --> Loader Class Initialized
INFO - 2022-03-23 04:33:45 --> Helper loaded: url_helper
INFO - 2022-03-23 04:33:45 --> Helper loaded: form_helper
INFO - 2022-03-23 04:33:45 --> Helper loaded: common_helper
INFO - 2022-03-23 04:33:45 --> Database Driver Class Initialized
DEBUG - 2022-03-23 04:33:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 04:33:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 04:33:45 --> Controller Class Initialized
INFO - 2022-03-23 04:33:45 --> Form Validation Class Initialized
DEBUG - 2022-03-23 04:33:45 --> Encrypt Class Initialized
INFO - 2022-03-23 04:33:45 --> Model "Patient_model" initialized
INFO - 2022-03-23 04:33:45 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 04:33:45 --> Model "Prefix_master" initialized
INFO - 2022-03-23 04:33:45 --> Model "Users_model" initialized
INFO - 2022-03-23 04:33:45 --> Model "Hospital_model" initialized
INFO - 2022-03-23 04:33:45 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 04:33:45 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-23 04:33:45 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 04:33:45 --> Final output sent to browser
DEBUG - 2022-03-23 04:33:45 --> Total execution time: 0.0539
ERROR - 2022-03-23 04:34:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 04:34:04 --> Config Class Initialized
INFO - 2022-03-23 04:34:04 --> Hooks Class Initialized
DEBUG - 2022-03-23 04:34:04 --> UTF-8 Support Enabled
INFO - 2022-03-23 04:34:04 --> Utf8 Class Initialized
INFO - 2022-03-23 04:34:04 --> URI Class Initialized
INFO - 2022-03-23 04:34:04 --> Router Class Initialized
INFO - 2022-03-23 04:34:04 --> Output Class Initialized
INFO - 2022-03-23 04:34:04 --> Security Class Initialized
DEBUG - 2022-03-23 04:34:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 04:34:04 --> Input Class Initialized
INFO - 2022-03-23 04:34:04 --> Language Class Initialized
INFO - 2022-03-23 04:34:04 --> Loader Class Initialized
INFO - 2022-03-23 04:34:04 --> Helper loaded: url_helper
INFO - 2022-03-23 04:34:04 --> Helper loaded: form_helper
INFO - 2022-03-23 04:34:04 --> Helper loaded: common_helper
INFO - 2022-03-23 04:34:04 --> Database Driver Class Initialized
DEBUG - 2022-03-23 04:34:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 04:34:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 04:34:04 --> Controller Class Initialized
INFO - 2022-03-23 04:34:04 --> Form Validation Class Initialized
DEBUG - 2022-03-23 04:34:04 --> Encrypt Class Initialized
INFO - 2022-03-23 04:34:04 --> Model "Patient_model" initialized
INFO - 2022-03-23 04:34:04 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 04:34:04 --> Model "Referredby_model" initialized
INFO - 2022-03-23 04:34:04 --> Model "Prefix_master" initialized
INFO - 2022-03-23 04:34:04 --> Model "Hospital_model" initialized
INFO - 2022-03-23 04:34:04 --> File loaded: /home3/karoteam/public_html/application/views/header.php
ERROR - 2022-03-23 04:34:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 04:34:11 --> Config Class Initialized
INFO - 2022-03-23 04:34:11 --> Hooks Class Initialized
DEBUG - 2022-03-23 04:34:11 --> UTF-8 Support Enabled
INFO - 2022-03-23 04:34:11 --> Utf8 Class Initialized
INFO - 2022-03-23 04:34:11 --> URI Class Initialized
INFO - 2022-03-23 04:34:11 --> Router Class Initialized
INFO - 2022-03-23 04:34:11 --> Output Class Initialized
INFO - 2022-03-23 04:34:11 --> Security Class Initialized
DEBUG - 2022-03-23 04:34:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 04:34:11 --> Input Class Initialized
INFO - 2022-03-23 04:34:11 --> Language Class Initialized
INFO - 2022-03-23 04:34:11 --> Loader Class Initialized
INFO - 2022-03-23 04:34:11 --> Helper loaded: url_helper
INFO - 2022-03-23 04:34:11 --> Helper loaded: form_helper
INFO - 2022-03-23 04:34:11 --> Helper loaded: common_helper
INFO - 2022-03-23 04:34:11 --> Database Driver Class Initialized
DEBUG - 2022-03-23 04:34:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 04:34:11 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-23 04:34:11 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 04:34:12 --> Final output sent to browser
DEBUG - 2022-03-23 04:34:12 --> Total execution time: 7.1995
INFO - 2022-03-23 04:34:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 04:34:12 --> Controller Class Initialized
INFO - 2022-03-23 04:34:12 --> Form Validation Class Initialized
DEBUG - 2022-03-23 04:34:12 --> Encrypt Class Initialized
INFO - 2022-03-23 04:34:12 --> Model "Patient_model" initialized
INFO - 2022-03-23 04:34:12 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 04:34:12 --> Model "Referredby_model" initialized
INFO - 2022-03-23 04:34:12 --> Model "Prefix_master" initialized
INFO - 2022-03-23 04:34:12 --> Model "Hospital_model" initialized
ERROR - 2022-03-23 04:34:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 04:34:12 --> Config Class Initialized
INFO - 2022-03-23 04:34:12 --> Hooks Class Initialized
DEBUG - 2022-03-23 04:34:12 --> UTF-8 Support Enabled
INFO - 2022-03-23 04:34:12 --> Utf8 Class Initialized
INFO - 2022-03-23 04:34:12 --> URI Class Initialized
INFO - 2022-03-23 04:34:12 --> Router Class Initialized
INFO - 2022-03-23 04:34:12 --> Output Class Initialized
INFO - 2022-03-23 04:34:12 --> Security Class Initialized
DEBUG - 2022-03-23 04:34:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 04:34:12 --> Input Class Initialized
INFO - 2022-03-23 04:34:12 --> Language Class Initialized
INFO - 2022-03-23 04:34:12 --> Loader Class Initialized
INFO - 2022-03-23 04:34:12 --> Helper loaded: url_helper
INFO - 2022-03-23 04:34:12 --> Helper loaded: form_helper
INFO - 2022-03-23 04:34:12 --> Helper loaded: common_helper
INFO - 2022-03-23 04:34:12 --> Database Driver Class Initialized
DEBUG - 2022-03-23 04:34:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 04:34:12 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 04:34:19 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-23 04:34:19 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 04:34:20 --> Final output sent to browser
DEBUG - 2022-03-23 04:34:20 --> Total execution time: 8.2255
INFO - 2022-03-23 04:34:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 04:34:20 --> Controller Class Initialized
INFO - 2022-03-23 04:34:20 --> Form Validation Class Initialized
DEBUG - 2022-03-23 04:34:20 --> Encrypt Class Initialized
INFO - 2022-03-23 04:34:20 --> Model "Patient_model" initialized
INFO - 2022-03-23 04:34:20 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 04:34:20 --> Model "Referredby_model" initialized
INFO - 2022-03-23 04:34:20 --> Model "Prefix_master" initialized
INFO - 2022-03-23 04:34:20 --> Model "Hospital_model" initialized
ERROR - 2022-03-23 04:34:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 04:34:20 --> Config Class Initialized
INFO - 2022-03-23 04:34:20 --> Hooks Class Initialized
DEBUG - 2022-03-23 04:34:20 --> UTF-8 Support Enabled
INFO - 2022-03-23 04:34:20 --> Utf8 Class Initialized
INFO - 2022-03-23 04:34:20 --> URI Class Initialized
INFO - 2022-03-23 04:34:20 --> Router Class Initialized
INFO - 2022-03-23 04:34:20 --> Output Class Initialized
INFO - 2022-03-23 04:34:20 --> Security Class Initialized
DEBUG - 2022-03-23 04:34:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 04:34:20 --> Input Class Initialized
INFO - 2022-03-23 04:34:20 --> Language Class Initialized
INFO - 2022-03-23 04:34:20 --> Loader Class Initialized
INFO - 2022-03-23 04:34:20 --> Helper loaded: url_helper
INFO - 2022-03-23 04:34:20 --> Helper loaded: form_helper
INFO - 2022-03-23 04:34:20 --> Helper loaded: common_helper
INFO - 2022-03-23 04:34:20 --> Database Driver Class Initialized
DEBUG - 2022-03-23 04:34:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 04:34:20 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 04:34:27 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-23 04:34:27 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 04:34:28 --> Final output sent to browser
DEBUG - 2022-03-23 04:34:28 --> Total execution time: 15.2698
INFO - 2022-03-23 04:34:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 04:34:28 --> Controller Class Initialized
INFO - 2022-03-23 04:34:28 --> Form Validation Class Initialized
DEBUG - 2022-03-23 04:34:28 --> Encrypt Class Initialized
INFO - 2022-03-23 04:34:28 --> Model "Patient_model" initialized
INFO - 2022-03-23 04:34:28 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 04:34:28 --> Model "Referredby_model" initialized
INFO - 2022-03-23 04:34:28 --> Model "Prefix_master" initialized
INFO - 2022-03-23 04:34:28 --> Model "Hospital_model" initialized
INFO - 2022-03-23 04:34:28 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 04:34:35 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-23 04:34:35 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 04:34:37 --> Final output sent to browser
DEBUG - 2022-03-23 04:34:37 --> Total execution time: 15.6729
ERROR - 2022-03-23 04:35:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 04:35:01 --> Config Class Initialized
INFO - 2022-03-23 04:35:01 --> Hooks Class Initialized
DEBUG - 2022-03-23 04:35:01 --> UTF-8 Support Enabled
INFO - 2022-03-23 04:35:01 --> Utf8 Class Initialized
INFO - 2022-03-23 04:35:01 --> URI Class Initialized
INFO - 2022-03-23 04:35:01 --> Router Class Initialized
INFO - 2022-03-23 04:35:01 --> Output Class Initialized
INFO - 2022-03-23 04:35:01 --> Security Class Initialized
DEBUG - 2022-03-23 04:35:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 04:35:01 --> Input Class Initialized
INFO - 2022-03-23 04:35:01 --> Language Class Initialized
INFO - 2022-03-23 04:35:01 --> Loader Class Initialized
INFO - 2022-03-23 04:35:01 --> Helper loaded: url_helper
INFO - 2022-03-23 04:35:01 --> Helper loaded: form_helper
INFO - 2022-03-23 04:35:01 --> Helper loaded: common_helper
INFO - 2022-03-23 04:35:01 --> Database Driver Class Initialized
DEBUG - 2022-03-23 04:35:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 04:35:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 04:35:01 --> Controller Class Initialized
INFO - 2022-03-23 04:35:01 --> Form Validation Class Initialized
DEBUG - 2022-03-23 04:35:01 --> Encrypt Class Initialized
INFO - 2022-03-23 04:35:01 --> Model "Patient_model" initialized
INFO - 2022-03-23 04:35:01 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 04:35:01 --> Model "Prefix_master" initialized
INFO - 2022-03-23 04:35:01 --> Model "Users_model" initialized
INFO - 2022-03-23 04:35:01 --> Model "Hospital_model" initialized
INFO - 2022-03-23 04:35:01 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-23 04:35:02 --> Final output sent to browser
DEBUG - 2022-03-23 04:35:02 --> Total execution time: 0.8318
ERROR - 2022-03-23 04:35:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 04:35:22 --> Config Class Initialized
INFO - 2022-03-23 04:35:22 --> Hooks Class Initialized
DEBUG - 2022-03-23 04:35:22 --> UTF-8 Support Enabled
INFO - 2022-03-23 04:35:22 --> Utf8 Class Initialized
INFO - 2022-03-23 04:35:22 --> URI Class Initialized
INFO - 2022-03-23 04:35:22 --> Router Class Initialized
INFO - 2022-03-23 04:35:22 --> Output Class Initialized
INFO - 2022-03-23 04:35:22 --> Security Class Initialized
DEBUG - 2022-03-23 04:35:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 04:35:22 --> Input Class Initialized
INFO - 2022-03-23 04:35:22 --> Language Class Initialized
INFO - 2022-03-23 04:35:22 --> Loader Class Initialized
INFO - 2022-03-23 04:35:22 --> Helper loaded: url_helper
INFO - 2022-03-23 04:35:22 --> Helper loaded: form_helper
INFO - 2022-03-23 04:35:22 --> Helper loaded: common_helper
INFO - 2022-03-23 04:35:22 --> Database Driver Class Initialized
DEBUG - 2022-03-23 04:35:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 04:35:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 04:35:22 --> Controller Class Initialized
INFO - 2022-03-23 04:35:22 --> Form Validation Class Initialized
DEBUG - 2022-03-23 04:35:22 --> Encrypt Class Initialized
INFO - 2022-03-23 04:35:22 --> Model "Patient_model" initialized
INFO - 2022-03-23 04:35:22 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 04:35:22 --> Model "Prefix_master" initialized
INFO - 2022-03-23 04:35:22 --> Model "Users_model" initialized
INFO - 2022-03-23 04:35:22 --> Model "Hospital_model" initialized
INFO - 2022-03-23 04:35:22 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-23 04:35:22 --> Final output sent to browser
DEBUG - 2022-03-23 04:35:22 --> Total execution time: 0.8048
ERROR - 2022-03-23 04:35:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 04:35:32 --> Config Class Initialized
INFO - 2022-03-23 04:35:32 --> Hooks Class Initialized
DEBUG - 2022-03-23 04:35:32 --> UTF-8 Support Enabled
INFO - 2022-03-23 04:35:32 --> Utf8 Class Initialized
INFO - 2022-03-23 04:35:32 --> URI Class Initialized
INFO - 2022-03-23 04:35:32 --> Router Class Initialized
INFO - 2022-03-23 04:35:32 --> Output Class Initialized
INFO - 2022-03-23 04:35:32 --> Security Class Initialized
DEBUG - 2022-03-23 04:35:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 04:35:32 --> Input Class Initialized
INFO - 2022-03-23 04:35:32 --> Language Class Initialized
INFO - 2022-03-23 04:35:32 --> Loader Class Initialized
INFO - 2022-03-23 04:35:32 --> Helper loaded: url_helper
INFO - 2022-03-23 04:35:32 --> Helper loaded: form_helper
INFO - 2022-03-23 04:35:32 --> Helper loaded: common_helper
INFO - 2022-03-23 04:35:32 --> Database Driver Class Initialized
DEBUG - 2022-03-23 04:35:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 04:35:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 04:35:32 --> Controller Class Initialized
INFO - 2022-03-23 04:35:32 --> Form Validation Class Initialized
DEBUG - 2022-03-23 04:35:32 --> Encrypt Class Initialized
INFO - 2022-03-23 04:35:32 --> Model "Patient_model" initialized
INFO - 2022-03-23 04:35:32 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 04:35:32 --> Model "Referredby_model" initialized
INFO - 2022-03-23 04:35:32 --> Model "Prefix_master" initialized
INFO - 2022-03-23 04:35:32 --> Model "Hospital_model" initialized
INFO - 2022-03-23 04:35:32 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 04:35:32 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-23 04:35:32 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 04:35:32 --> Final output sent to browser
DEBUG - 2022-03-23 04:35:32 --> Total execution time: 0.0411
ERROR - 2022-03-23 04:35:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 04:35:41 --> Config Class Initialized
INFO - 2022-03-23 04:35:41 --> Hooks Class Initialized
DEBUG - 2022-03-23 04:35:41 --> UTF-8 Support Enabled
INFO - 2022-03-23 04:35:41 --> Utf8 Class Initialized
INFO - 2022-03-23 04:35:41 --> URI Class Initialized
INFO - 2022-03-23 04:35:41 --> Router Class Initialized
INFO - 2022-03-23 04:35:41 --> Output Class Initialized
INFO - 2022-03-23 04:35:41 --> Security Class Initialized
DEBUG - 2022-03-23 04:35:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 04:35:41 --> Input Class Initialized
INFO - 2022-03-23 04:35:41 --> Language Class Initialized
INFO - 2022-03-23 04:35:41 --> Loader Class Initialized
INFO - 2022-03-23 04:35:41 --> Helper loaded: url_helper
INFO - 2022-03-23 04:35:41 --> Helper loaded: form_helper
INFO - 2022-03-23 04:35:41 --> Helper loaded: common_helper
INFO - 2022-03-23 04:35:41 --> Database Driver Class Initialized
DEBUG - 2022-03-23 04:35:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 04:35:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 04:35:41 --> Controller Class Initialized
INFO - 2022-03-23 04:35:41 --> Form Validation Class Initialized
DEBUG - 2022-03-23 04:35:41 --> Encrypt Class Initialized
INFO - 2022-03-23 04:35:41 --> Model "Patient_model" initialized
INFO - 2022-03-23 04:35:41 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 04:35:41 --> Model "Referredby_model" initialized
INFO - 2022-03-23 04:35:41 --> Model "Prefix_master" initialized
INFO - 2022-03-23 04:35:41 --> Model "Hospital_model" initialized
INFO - 2022-03-23 04:35:41 --> File loaded: /home3/karoteam/public_html/application/views/header.php
ERROR - 2022-03-23 04:35:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 04:35:41 --> Config Class Initialized
INFO - 2022-03-23 04:35:41 --> Hooks Class Initialized
DEBUG - 2022-03-23 04:35:41 --> UTF-8 Support Enabled
INFO - 2022-03-23 04:35:41 --> Utf8 Class Initialized
INFO - 2022-03-23 04:35:41 --> URI Class Initialized
INFO - 2022-03-23 04:35:41 --> Router Class Initialized
INFO - 2022-03-23 04:35:41 --> Output Class Initialized
INFO - 2022-03-23 04:35:41 --> Security Class Initialized
DEBUG - 2022-03-23 04:35:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 04:35:41 --> Input Class Initialized
INFO - 2022-03-23 04:35:41 --> Language Class Initialized
INFO - 2022-03-23 04:35:41 --> Loader Class Initialized
INFO - 2022-03-23 04:35:41 --> Helper loaded: url_helper
INFO - 2022-03-23 04:35:41 --> Helper loaded: form_helper
INFO - 2022-03-23 04:35:41 --> Helper loaded: common_helper
INFO - 2022-03-23 04:35:41 --> Database Driver Class Initialized
DEBUG - 2022-03-23 04:35:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 04:35:47 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-23 04:35:47 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 04:35:47 --> Final output sent to browser
DEBUG - 2022-03-23 04:35:47 --> Total execution time: 6.0929
INFO - 2022-03-23 04:35:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 04:35:47 --> Controller Class Initialized
INFO - 2022-03-23 04:35:47 --> Form Validation Class Initialized
DEBUG - 2022-03-23 04:35:47 --> Encrypt Class Initialized
INFO - 2022-03-23 04:35:47 --> Model "Patient_model" initialized
INFO - 2022-03-23 04:35:47 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 04:35:47 --> Model "Referredby_model" initialized
INFO - 2022-03-23 04:35:47 --> Model "Prefix_master" initialized
INFO - 2022-03-23 04:35:47 --> Model "Hospital_model" initialized
INFO - 2022-03-23 04:35:47 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 04:35:53 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-23 04:35:53 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 04:35:55 --> Final output sent to browser
DEBUG - 2022-03-23 04:35:55 --> Total execution time: 12.4379
ERROR - 2022-03-23 04:36:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 04:36:19 --> Config Class Initialized
INFO - 2022-03-23 04:36:19 --> Hooks Class Initialized
DEBUG - 2022-03-23 04:36:19 --> UTF-8 Support Enabled
INFO - 2022-03-23 04:36:19 --> Utf8 Class Initialized
INFO - 2022-03-23 04:36:19 --> URI Class Initialized
INFO - 2022-03-23 04:36:19 --> Router Class Initialized
INFO - 2022-03-23 04:36:19 --> Output Class Initialized
INFO - 2022-03-23 04:36:19 --> Security Class Initialized
DEBUG - 2022-03-23 04:36:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 04:36:19 --> Input Class Initialized
INFO - 2022-03-23 04:36:19 --> Language Class Initialized
INFO - 2022-03-23 04:36:19 --> Loader Class Initialized
INFO - 2022-03-23 04:36:19 --> Helper loaded: url_helper
INFO - 2022-03-23 04:36:19 --> Helper loaded: form_helper
INFO - 2022-03-23 04:36:19 --> Helper loaded: common_helper
INFO - 2022-03-23 04:36:19 --> Database Driver Class Initialized
DEBUG - 2022-03-23 04:36:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 04:36:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 04:36:19 --> Controller Class Initialized
INFO - 2022-03-23 04:36:19 --> Form Validation Class Initialized
DEBUG - 2022-03-23 04:36:19 --> Encrypt Class Initialized
INFO - 2022-03-23 04:36:19 --> Model "Patient_model" initialized
INFO - 2022-03-23 04:36:19 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 04:36:19 --> Model "Prefix_master" initialized
INFO - 2022-03-23 04:36:19 --> Model "Users_model" initialized
INFO - 2022-03-23 04:36:19 --> Model "Hospital_model" initialized
INFO - 2022-03-23 04:36:19 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-23 04:36:19 --> Final output sent to browser
DEBUG - 2022-03-23 04:36:19 --> Total execution time: 0.7297
ERROR - 2022-03-23 04:37:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 04:37:15 --> Config Class Initialized
INFO - 2022-03-23 04:37:15 --> Hooks Class Initialized
DEBUG - 2022-03-23 04:37:15 --> UTF-8 Support Enabled
INFO - 2022-03-23 04:37:15 --> Utf8 Class Initialized
INFO - 2022-03-23 04:37:15 --> URI Class Initialized
INFO - 2022-03-23 04:37:15 --> Router Class Initialized
INFO - 2022-03-23 04:37:15 --> Output Class Initialized
INFO - 2022-03-23 04:37:15 --> Security Class Initialized
DEBUG - 2022-03-23 04:37:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 04:37:15 --> Input Class Initialized
INFO - 2022-03-23 04:37:15 --> Language Class Initialized
INFO - 2022-03-23 04:37:15 --> Loader Class Initialized
INFO - 2022-03-23 04:37:15 --> Helper loaded: url_helper
INFO - 2022-03-23 04:37:15 --> Helper loaded: form_helper
INFO - 2022-03-23 04:37:15 --> Helper loaded: common_helper
INFO - 2022-03-23 04:37:15 --> Database Driver Class Initialized
DEBUG - 2022-03-23 04:37:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 04:37:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 04:37:15 --> Controller Class Initialized
INFO - 2022-03-23 04:37:15 --> Form Validation Class Initialized
DEBUG - 2022-03-23 04:37:15 --> Encrypt Class Initialized
INFO - 2022-03-23 04:37:15 --> Model "Patient_model" initialized
INFO - 2022-03-23 04:37:15 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 04:37:15 --> Model "Referredby_model" initialized
INFO - 2022-03-23 04:37:15 --> Model "Prefix_master" initialized
INFO - 2022-03-23 04:37:15 --> Model "Hospital_model" initialized
INFO - 2022-03-23 04:37:15 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 04:37:15 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-23 04:37:15 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 04:37:15 --> Final output sent to browser
DEBUG - 2022-03-23 04:37:15 --> Total execution time: 0.0279
ERROR - 2022-03-23 04:37:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 04:37:40 --> Config Class Initialized
INFO - 2022-03-23 04:37:40 --> Hooks Class Initialized
DEBUG - 2022-03-23 04:37:40 --> UTF-8 Support Enabled
INFO - 2022-03-23 04:37:40 --> Utf8 Class Initialized
INFO - 2022-03-23 04:37:40 --> URI Class Initialized
INFO - 2022-03-23 04:37:40 --> Router Class Initialized
INFO - 2022-03-23 04:37:40 --> Output Class Initialized
INFO - 2022-03-23 04:37:40 --> Security Class Initialized
DEBUG - 2022-03-23 04:37:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 04:37:40 --> Input Class Initialized
INFO - 2022-03-23 04:37:40 --> Language Class Initialized
INFO - 2022-03-23 04:37:40 --> Loader Class Initialized
INFO - 2022-03-23 04:37:40 --> Helper loaded: url_helper
INFO - 2022-03-23 04:37:40 --> Helper loaded: form_helper
INFO - 2022-03-23 04:37:40 --> Helper loaded: common_helper
INFO - 2022-03-23 04:37:40 --> Database Driver Class Initialized
DEBUG - 2022-03-23 04:37:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 04:37:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 04:37:40 --> Controller Class Initialized
INFO - 2022-03-23 04:37:40 --> Form Validation Class Initialized
DEBUG - 2022-03-23 04:37:40 --> Encrypt Class Initialized
INFO - 2022-03-23 04:37:40 --> Model "Patient_model" initialized
INFO - 2022-03-23 04:37:40 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 04:37:40 --> Model "Referredby_model" initialized
INFO - 2022-03-23 04:37:40 --> Model "Prefix_master" initialized
INFO - 2022-03-23 04:37:40 --> Model "Hospital_model" initialized
INFO - 2022-03-23 04:37:40 --> Upload Class Initialized
INFO - 2022-03-23 04:37:40 --> Final output sent to browser
DEBUG - 2022-03-23 04:37:40 --> Total execution time: 0.0131
ERROR - 2022-03-23 04:37:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 04:37:45 --> Config Class Initialized
INFO - 2022-03-23 04:37:45 --> Hooks Class Initialized
DEBUG - 2022-03-23 04:37:45 --> UTF-8 Support Enabled
INFO - 2022-03-23 04:37:45 --> Utf8 Class Initialized
INFO - 2022-03-23 04:37:45 --> URI Class Initialized
INFO - 2022-03-23 04:37:45 --> Router Class Initialized
INFO - 2022-03-23 04:37:45 --> Output Class Initialized
INFO - 2022-03-23 04:37:45 --> Security Class Initialized
DEBUG - 2022-03-23 04:37:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 04:37:45 --> Input Class Initialized
INFO - 2022-03-23 04:37:45 --> Language Class Initialized
INFO - 2022-03-23 04:37:45 --> Loader Class Initialized
INFO - 2022-03-23 04:37:45 --> Helper loaded: url_helper
INFO - 2022-03-23 04:37:45 --> Helper loaded: form_helper
INFO - 2022-03-23 04:37:45 --> Helper loaded: common_helper
INFO - 2022-03-23 04:37:45 --> Database Driver Class Initialized
DEBUG - 2022-03-23 04:37:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 04:37:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 04:37:45 --> Controller Class Initialized
INFO - 2022-03-23 04:37:45 --> Form Validation Class Initialized
DEBUG - 2022-03-23 04:37:45 --> Encrypt Class Initialized
INFO - 2022-03-23 04:37:45 --> Model "Patient_model" initialized
INFO - 2022-03-23 04:37:45 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 04:37:45 --> Model "Referredby_model" initialized
INFO - 2022-03-23 04:37:45 --> Model "Prefix_master" initialized
INFO - 2022-03-23 04:37:45 --> Model "Hospital_model" initialized
ERROR - 2022-03-23 04:37:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 04:37:45 --> Config Class Initialized
INFO - 2022-03-23 04:37:45 --> Hooks Class Initialized
DEBUG - 2022-03-23 04:37:45 --> UTF-8 Support Enabled
INFO - 2022-03-23 04:37:45 --> Utf8 Class Initialized
INFO - 2022-03-23 04:37:45 --> URI Class Initialized
INFO - 2022-03-23 04:37:45 --> Router Class Initialized
INFO - 2022-03-23 04:37:45 --> Output Class Initialized
INFO - 2022-03-23 04:37:45 --> Security Class Initialized
DEBUG - 2022-03-23 04:37:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 04:37:45 --> Input Class Initialized
INFO - 2022-03-23 04:37:45 --> Language Class Initialized
INFO - 2022-03-23 04:37:45 --> Loader Class Initialized
INFO - 2022-03-23 04:37:45 --> Helper loaded: url_helper
INFO - 2022-03-23 04:37:45 --> Helper loaded: form_helper
INFO - 2022-03-23 04:37:45 --> Helper loaded: common_helper
INFO - 2022-03-23 04:37:45 --> Database Driver Class Initialized
DEBUG - 2022-03-23 04:37:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 04:37:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 04:37:45 --> Controller Class Initialized
INFO - 2022-03-23 04:37:45 --> Form Validation Class Initialized
DEBUG - 2022-03-23 04:37:45 --> Encrypt Class Initialized
INFO - 2022-03-23 04:37:45 --> Model "Patient_model" initialized
INFO - 2022-03-23 04:37:45 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 04:37:45 --> Model "Referredby_model" initialized
INFO - 2022-03-23 04:37:45 --> Model "Prefix_master" initialized
INFO - 2022-03-23 04:37:45 --> Model "Hospital_model" initialized
INFO - 2022-03-23 04:37:45 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 04:37:45 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-23 04:37:45 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 04:37:45 --> Final output sent to browser
DEBUG - 2022-03-23 04:37:45 --> Total execution time: 0.0726
ERROR - 2022-03-23 04:37:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 04:37:46 --> Config Class Initialized
INFO - 2022-03-23 04:37:46 --> Hooks Class Initialized
DEBUG - 2022-03-23 04:37:46 --> UTF-8 Support Enabled
INFO - 2022-03-23 04:37:46 --> Utf8 Class Initialized
INFO - 2022-03-23 04:37:46 --> URI Class Initialized
INFO - 2022-03-23 04:37:46 --> Router Class Initialized
INFO - 2022-03-23 04:37:46 --> Output Class Initialized
INFO - 2022-03-23 04:37:46 --> Security Class Initialized
DEBUG - 2022-03-23 04:37:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 04:37:46 --> Input Class Initialized
INFO - 2022-03-23 04:37:46 --> Language Class Initialized
INFO - 2022-03-23 04:37:46 --> Loader Class Initialized
INFO - 2022-03-23 04:37:46 --> Helper loaded: url_helper
INFO - 2022-03-23 04:37:46 --> Helper loaded: form_helper
INFO - 2022-03-23 04:37:46 --> Helper loaded: common_helper
INFO - 2022-03-23 04:37:46 --> Database Driver Class Initialized
DEBUG - 2022-03-23 04:37:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 04:37:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 04:37:46 --> Controller Class Initialized
INFO - 2022-03-23 04:37:46 --> Form Validation Class Initialized
DEBUG - 2022-03-23 04:37:46 --> Encrypt Class Initialized
INFO - 2022-03-23 04:37:46 --> Model "Patient_model" initialized
INFO - 2022-03-23 04:37:46 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 04:37:46 --> Model "Prefix_master" initialized
INFO - 2022-03-23 04:37:46 --> Model "Users_model" initialized
INFO - 2022-03-23 04:37:46 --> Model "Hospital_model" initialized
INFO - 2022-03-23 04:37:46 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 04:37:46 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-23 04:37:46 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 04:37:46 --> Final output sent to browser
DEBUG - 2022-03-23 04:37:46 --> Total execution time: 0.0612
ERROR - 2022-03-23 04:37:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 04:37:50 --> Config Class Initialized
INFO - 2022-03-23 04:37:50 --> Hooks Class Initialized
DEBUG - 2022-03-23 04:37:50 --> UTF-8 Support Enabled
INFO - 2022-03-23 04:37:50 --> Utf8 Class Initialized
INFO - 2022-03-23 04:37:50 --> URI Class Initialized
INFO - 2022-03-23 04:37:50 --> Router Class Initialized
INFO - 2022-03-23 04:37:50 --> Output Class Initialized
INFO - 2022-03-23 04:37:50 --> Security Class Initialized
DEBUG - 2022-03-23 04:37:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 04:37:50 --> Input Class Initialized
INFO - 2022-03-23 04:37:50 --> Language Class Initialized
INFO - 2022-03-23 04:37:50 --> Loader Class Initialized
INFO - 2022-03-23 04:37:50 --> Helper loaded: url_helper
INFO - 2022-03-23 04:37:50 --> Helper loaded: form_helper
INFO - 2022-03-23 04:37:50 --> Helper loaded: common_helper
INFO - 2022-03-23 04:37:50 --> Database Driver Class Initialized
DEBUG - 2022-03-23 04:37:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 04:37:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 04:37:50 --> Controller Class Initialized
INFO - 2022-03-23 04:37:50 --> Form Validation Class Initialized
DEBUG - 2022-03-23 04:37:50 --> Encrypt Class Initialized
INFO - 2022-03-23 04:37:50 --> Model "Patient_model" initialized
INFO - 2022-03-23 04:37:50 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 04:37:50 --> Model "Referredby_model" initialized
INFO - 2022-03-23 04:37:50 --> Model "Prefix_master" initialized
INFO - 2022-03-23 04:37:50 --> Model "Hospital_model" initialized
INFO - 2022-03-23 04:37:50 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 04:37:57 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-23 04:37:57 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 04:37:59 --> Final output sent to browser
DEBUG - 2022-03-23 04:37:59 --> Total execution time: 6.6997
ERROR - 2022-03-23 04:38:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 04:38:27 --> Config Class Initialized
INFO - 2022-03-23 04:38:27 --> Hooks Class Initialized
DEBUG - 2022-03-23 04:38:27 --> UTF-8 Support Enabled
INFO - 2022-03-23 04:38:27 --> Utf8 Class Initialized
INFO - 2022-03-23 04:38:27 --> URI Class Initialized
INFO - 2022-03-23 04:38:27 --> Router Class Initialized
INFO - 2022-03-23 04:38:27 --> Output Class Initialized
INFO - 2022-03-23 04:38:27 --> Security Class Initialized
DEBUG - 2022-03-23 04:38:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 04:38:27 --> Input Class Initialized
INFO - 2022-03-23 04:38:27 --> Language Class Initialized
INFO - 2022-03-23 04:38:27 --> Loader Class Initialized
INFO - 2022-03-23 04:38:27 --> Helper loaded: url_helper
INFO - 2022-03-23 04:38:27 --> Helper loaded: form_helper
INFO - 2022-03-23 04:38:27 --> Helper loaded: common_helper
INFO - 2022-03-23 04:38:27 --> Database Driver Class Initialized
DEBUG - 2022-03-23 04:38:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 04:38:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 04:38:27 --> Controller Class Initialized
INFO - 2022-03-23 04:38:27 --> Form Validation Class Initialized
DEBUG - 2022-03-23 04:38:27 --> Encrypt Class Initialized
INFO - 2022-03-23 04:38:27 --> Model "Patient_model" initialized
INFO - 2022-03-23 04:38:27 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 04:38:27 --> Model "Prefix_master" initialized
INFO - 2022-03-23 04:38:27 --> Model "Users_model" initialized
INFO - 2022-03-23 04:38:27 --> Model "Hospital_model" initialized
INFO - 2022-03-23 04:38:27 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-23 04:38:27 --> Final output sent to browser
DEBUG - 2022-03-23 04:38:27 --> Total execution time: 0.7010
ERROR - 2022-03-23 04:39:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 04:39:04 --> Config Class Initialized
INFO - 2022-03-23 04:39:04 --> Hooks Class Initialized
DEBUG - 2022-03-23 04:39:04 --> UTF-8 Support Enabled
INFO - 2022-03-23 04:39:04 --> Utf8 Class Initialized
INFO - 2022-03-23 04:39:04 --> URI Class Initialized
INFO - 2022-03-23 04:39:04 --> Router Class Initialized
INFO - 2022-03-23 04:39:04 --> Output Class Initialized
INFO - 2022-03-23 04:39:04 --> Security Class Initialized
DEBUG - 2022-03-23 04:39:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 04:39:04 --> Input Class Initialized
INFO - 2022-03-23 04:39:04 --> Language Class Initialized
INFO - 2022-03-23 04:39:04 --> Loader Class Initialized
INFO - 2022-03-23 04:39:04 --> Helper loaded: url_helper
INFO - 2022-03-23 04:39:04 --> Helper loaded: form_helper
INFO - 2022-03-23 04:39:04 --> Helper loaded: common_helper
INFO - 2022-03-23 04:39:04 --> Database Driver Class Initialized
DEBUG - 2022-03-23 04:39:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 04:39:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 04:39:04 --> Controller Class Initialized
INFO - 2022-03-23 04:39:04 --> Form Validation Class Initialized
DEBUG - 2022-03-23 04:39:04 --> Encrypt Class Initialized
INFO - 2022-03-23 04:39:04 --> Model "Patient_model" initialized
INFO - 2022-03-23 04:39:04 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 04:39:04 --> Model "Prefix_master" initialized
INFO - 2022-03-23 04:39:04 --> Model "Users_model" initialized
INFO - 2022-03-23 04:39:04 --> Model "Hospital_model" initialized
INFO - 2022-03-23 04:39:04 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-23 04:39:05 --> Final output sent to browser
DEBUG - 2022-03-23 04:39:05 --> Total execution time: 0.6855
ERROR - 2022-03-23 04:40:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 04:40:00 --> Config Class Initialized
INFO - 2022-03-23 04:40:00 --> Hooks Class Initialized
DEBUG - 2022-03-23 04:40:00 --> UTF-8 Support Enabled
INFO - 2022-03-23 04:40:00 --> Utf8 Class Initialized
INFO - 2022-03-23 04:40:00 --> URI Class Initialized
INFO - 2022-03-23 04:40:00 --> Router Class Initialized
INFO - 2022-03-23 04:40:00 --> Output Class Initialized
INFO - 2022-03-23 04:40:00 --> Security Class Initialized
DEBUG - 2022-03-23 04:40:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 04:40:00 --> Input Class Initialized
INFO - 2022-03-23 04:40:00 --> Language Class Initialized
INFO - 2022-03-23 04:40:00 --> Loader Class Initialized
INFO - 2022-03-23 04:40:00 --> Helper loaded: url_helper
INFO - 2022-03-23 04:40:00 --> Helper loaded: form_helper
INFO - 2022-03-23 04:40:00 --> Helper loaded: common_helper
INFO - 2022-03-23 04:40:00 --> Database Driver Class Initialized
DEBUG - 2022-03-23 04:40:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 04:40:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 04:40:00 --> Controller Class Initialized
INFO - 2022-03-23 04:40:00 --> Form Validation Class Initialized
DEBUG - 2022-03-23 04:40:00 --> Encrypt Class Initialized
INFO - 2022-03-23 04:40:00 --> Model "Patient_model" initialized
INFO - 2022-03-23 04:40:00 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 04:40:00 --> Model "Prefix_master" initialized
INFO - 2022-03-23 04:40:00 --> Model "Users_model" initialized
INFO - 2022-03-23 04:40:00 --> Model "Hospital_model" initialized
INFO - 2022-03-23 04:40:00 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-23 04:40:01 --> Final output sent to browser
DEBUG - 2022-03-23 04:40:01 --> Total execution time: 0.6664
ERROR - 2022-03-23 04:40:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 04:40:25 --> Config Class Initialized
INFO - 2022-03-23 04:40:25 --> Hooks Class Initialized
DEBUG - 2022-03-23 04:40:25 --> UTF-8 Support Enabled
INFO - 2022-03-23 04:40:25 --> Utf8 Class Initialized
INFO - 2022-03-23 04:40:25 --> URI Class Initialized
INFO - 2022-03-23 04:40:25 --> Router Class Initialized
INFO - 2022-03-23 04:40:25 --> Output Class Initialized
INFO - 2022-03-23 04:40:25 --> Security Class Initialized
DEBUG - 2022-03-23 04:40:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 04:40:25 --> Input Class Initialized
INFO - 2022-03-23 04:40:25 --> Language Class Initialized
INFO - 2022-03-23 04:40:25 --> Loader Class Initialized
INFO - 2022-03-23 04:40:25 --> Helper loaded: url_helper
INFO - 2022-03-23 04:40:25 --> Helper loaded: form_helper
INFO - 2022-03-23 04:40:25 --> Helper loaded: common_helper
INFO - 2022-03-23 04:40:25 --> Database Driver Class Initialized
DEBUG - 2022-03-23 04:40:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 04:40:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 04:40:25 --> Controller Class Initialized
INFO - 2022-03-23 04:40:25 --> Form Validation Class Initialized
DEBUG - 2022-03-23 04:40:25 --> Encrypt Class Initialized
INFO - 2022-03-23 04:40:25 --> Model "Patient_model" initialized
INFO - 2022-03-23 04:40:25 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 04:40:25 --> Model "Referredby_model" initialized
INFO - 2022-03-23 04:40:25 --> Model "Prefix_master" initialized
INFO - 2022-03-23 04:40:25 --> Model "Hospital_model" initialized
INFO - 2022-03-23 04:40:25 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 04:40:25 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-23 04:40:25 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 04:40:25 --> Final output sent to browser
DEBUG - 2022-03-23 04:40:25 --> Total execution time: 0.0490
ERROR - 2022-03-23 04:40:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 04:40:37 --> Config Class Initialized
INFO - 2022-03-23 04:40:37 --> Hooks Class Initialized
DEBUG - 2022-03-23 04:40:37 --> UTF-8 Support Enabled
INFO - 2022-03-23 04:40:37 --> Utf8 Class Initialized
INFO - 2022-03-23 04:40:37 --> URI Class Initialized
INFO - 2022-03-23 04:40:37 --> Router Class Initialized
INFO - 2022-03-23 04:40:37 --> Output Class Initialized
INFO - 2022-03-23 04:40:37 --> Security Class Initialized
DEBUG - 2022-03-23 04:40:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 04:40:37 --> Input Class Initialized
INFO - 2022-03-23 04:40:37 --> Language Class Initialized
INFO - 2022-03-23 04:40:37 --> Loader Class Initialized
INFO - 2022-03-23 04:40:37 --> Helper loaded: url_helper
INFO - 2022-03-23 04:40:37 --> Helper loaded: form_helper
INFO - 2022-03-23 04:40:37 --> Helper loaded: common_helper
INFO - 2022-03-23 04:40:37 --> Database Driver Class Initialized
DEBUG - 2022-03-23 04:40:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 04:40:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 04:40:37 --> Controller Class Initialized
INFO - 2022-03-23 04:40:37 --> Form Validation Class Initialized
DEBUG - 2022-03-23 04:40:37 --> Encrypt Class Initialized
INFO - 2022-03-23 04:40:37 --> Model "Patient_model" initialized
INFO - 2022-03-23 04:40:37 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 04:40:37 --> Model "Referredby_model" initialized
INFO - 2022-03-23 04:40:37 --> Model "Prefix_master" initialized
INFO - 2022-03-23 04:40:37 --> Model "Hospital_model" initialized
ERROR - 2022-03-23 04:40:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 04:40:37 --> Config Class Initialized
INFO - 2022-03-23 04:40:37 --> Hooks Class Initialized
DEBUG - 2022-03-23 04:40:37 --> UTF-8 Support Enabled
INFO - 2022-03-23 04:40:37 --> Utf8 Class Initialized
INFO - 2022-03-23 04:40:37 --> URI Class Initialized
INFO - 2022-03-23 04:40:37 --> Router Class Initialized
INFO - 2022-03-23 04:40:37 --> Output Class Initialized
INFO - 2022-03-23 04:40:37 --> Security Class Initialized
DEBUG - 2022-03-23 04:40:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 04:40:37 --> Input Class Initialized
INFO - 2022-03-23 04:40:37 --> Language Class Initialized
INFO - 2022-03-23 04:40:37 --> Loader Class Initialized
INFO - 2022-03-23 04:40:37 --> Helper loaded: url_helper
INFO - 2022-03-23 04:40:37 --> Helper loaded: form_helper
INFO - 2022-03-23 04:40:37 --> Helper loaded: common_helper
INFO - 2022-03-23 04:40:37 --> Database Driver Class Initialized
DEBUG - 2022-03-23 04:40:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 04:40:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 04:40:37 --> Controller Class Initialized
INFO - 2022-03-23 04:40:37 --> Form Validation Class Initialized
DEBUG - 2022-03-23 04:40:37 --> Encrypt Class Initialized
INFO - 2022-03-23 04:40:37 --> Model "Patient_model" initialized
INFO - 2022-03-23 04:40:37 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 04:40:37 --> Model "Referredby_model" initialized
INFO - 2022-03-23 04:40:37 --> Model "Prefix_master" initialized
INFO - 2022-03-23 04:40:37 --> Model "Hospital_model" initialized
INFO - 2022-03-23 04:40:37 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 04:40:37 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-23 04:40:37 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 04:40:37 --> Final output sent to browser
DEBUG - 2022-03-23 04:40:37 --> Total execution time: 0.0408
ERROR - 2022-03-23 04:40:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 04:40:38 --> Config Class Initialized
INFO - 2022-03-23 04:40:38 --> Hooks Class Initialized
DEBUG - 2022-03-23 04:40:38 --> UTF-8 Support Enabled
INFO - 2022-03-23 04:40:38 --> Utf8 Class Initialized
INFO - 2022-03-23 04:40:38 --> URI Class Initialized
INFO - 2022-03-23 04:40:38 --> Router Class Initialized
INFO - 2022-03-23 04:40:38 --> Output Class Initialized
INFO - 2022-03-23 04:40:38 --> Security Class Initialized
DEBUG - 2022-03-23 04:40:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 04:40:38 --> Input Class Initialized
INFO - 2022-03-23 04:40:38 --> Language Class Initialized
INFO - 2022-03-23 04:40:38 --> Loader Class Initialized
INFO - 2022-03-23 04:40:38 --> Helper loaded: url_helper
INFO - 2022-03-23 04:40:38 --> Helper loaded: form_helper
INFO - 2022-03-23 04:40:38 --> Helper loaded: common_helper
INFO - 2022-03-23 04:40:38 --> Database Driver Class Initialized
DEBUG - 2022-03-23 04:40:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 04:40:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 04:40:38 --> Controller Class Initialized
INFO - 2022-03-23 04:40:38 --> Form Validation Class Initialized
DEBUG - 2022-03-23 04:40:38 --> Encrypt Class Initialized
INFO - 2022-03-23 04:40:38 --> Model "Patient_model" initialized
INFO - 2022-03-23 04:40:38 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 04:40:38 --> Model "Prefix_master" initialized
INFO - 2022-03-23 04:40:38 --> Model "Users_model" initialized
INFO - 2022-03-23 04:40:38 --> Model "Hospital_model" initialized
INFO - 2022-03-23 04:40:38 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 04:40:38 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-23 04:40:38 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 04:40:38 --> Final output sent to browser
DEBUG - 2022-03-23 04:40:38 --> Total execution time: 0.0661
ERROR - 2022-03-23 04:41:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 04:41:09 --> Config Class Initialized
INFO - 2022-03-23 04:41:09 --> Hooks Class Initialized
DEBUG - 2022-03-23 04:41:09 --> UTF-8 Support Enabled
INFO - 2022-03-23 04:41:09 --> Utf8 Class Initialized
INFO - 2022-03-23 04:41:09 --> URI Class Initialized
INFO - 2022-03-23 04:41:09 --> Router Class Initialized
INFO - 2022-03-23 04:41:09 --> Output Class Initialized
INFO - 2022-03-23 04:41:09 --> Security Class Initialized
DEBUG - 2022-03-23 04:41:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 04:41:09 --> Input Class Initialized
INFO - 2022-03-23 04:41:09 --> Language Class Initialized
INFO - 2022-03-23 04:41:09 --> Loader Class Initialized
INFO - 2022-03-23 04:41:09 --> Helper loaded: url_helper
INFO - 2022-03-23 04:41:09 --> Helper loaded: form_helper
INFO - 2022-03-23 04:41:09 --> Helper loaded: common_helper
INFO - 2022-03-23 04:41:09 --> Database Driver Class Initialized
DEBUG - 2022-03-23 04:41:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 04:41:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 04:41:09 --> Controller Class Initialized
INFO - 2022-03-23 04:41:09 --> Form Validation Class Initialized
DEBUG - 2022-03-23 04:41:09 --> Encrypt Class Initialized
INFO - 2022-03-23 04:41:09 --> Model "Patient_model" initialized
INFO - 2022-03-23 04:41:09 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 04:41:09 --> Model "Referredby_model" initialized
INFO - 2022-03-23 04:41:09 --> Model "Prefix_master" initialized
INFO - 2022-03-23 04:41:09 --> Model "Hospital_model" initialized
INFO - 2022-03-23 04:41:09 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 04:41:16 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-23 04:41:16 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 04:41:17 --> Final output sent to browser
DEBUG - 2022-03-23 04:41:17 --> Total execution time: 6.4993
ERROR - 2022-03-23 04:41:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 04:41:42 --> Config Class Initialized
INFO - 2022-03-23 04:41:42 --> Hooks Class Initialized
DEBUG - 2022-03-23 04:41:42 --> UTF-8 Support Enabled
INFO - 2022-03-23 04:41:42 --> Utf8 Class Initialized
INFO - 2022-03-23 04:41:42 --> URI Class Initialized
INFO - 2022-03-23 04:41:42 --> Router Class Initialized
INFO - 2022-03-23 04:41:42 --> Output Class Initialized
INFO - 2022-03-23 04:41:42 --> Security Class Initialized
DEBUG - 2022-03-23 04:41:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 04:41:42 --> Input Class Initialized
INFO - 2022-03-23 04:41:42 --> Language Class Initialized
INFO - 2022-03-23 04:41:42 --> Loader Class Initialized
INFO - 2022-03-23 04:41:42 --> Helper loaded: url_helper
INFO - 2022-03-23 04:41:42 --> Helper loaded: form_helper
INFO - 2022-03-23 04:41:42 --> Helper loaded: common_helper
INFO - 2022-03-23 04:41:42 --> Database Driver Class Initialized
DEBUG - 2022-03-23 04:41:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 04:41:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 04:41:42 --> Controller Class Initialized
INFO - 2022-03-23 04:41:42 --> Form Validation Class Initialized
DEBUG - 2022-03-23 04:41:42 --> Encrypt Class Initialized
INFO - 2022-03-23 04:41:42 --> Model "Patient_model" initialized
INFO - 2022-03-23 04:41:42 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 04:41:42 --> Model "Prefix_master" initialized
INFO - 2022-03-23 04:41:42 --> Model "Users_model" initialized
INFO - 2022-03-23 04:41:42 --> Model "Hospital_model" initialized
INFO - 2022-03-23 04:41:42 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-23 04:41:43 --> Final output sent to browser
DEBUG - 2022-03-23 04:41:43 --> Total execution time: 0.7888
ERROR - 2022-03-23 04:43:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 04:43:42 --> Config Class Initialized
INFO - 2022-03-23 04:43:42 --> Hooks Class Initialized
DEBUG - 2022-03-23 04:43:42 --> UTF-8 Support Enabled
INFO - 2022-03-23 04:43:42 --> Utf8 Class Initialized
INFO - 2022-03-23 04:43:42 --> URI Class Initialized
INFO - 2022-03-23 04:43:42 --> Router Class Initialized
INFO - 2022-03-23 04:43:42 --> Output Class Initialized
INFO - 2022-03-23 04:43:42 --> Security Class Initialized
DEBUG - 2022-03-23 04:43:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 04:43:42 --> Input Class Initialized
INFO - 2022-03-23 04:43:42 --> Language Class Initialized
INFO - 2022-03-23 04:43:42 --> Loader Class Initialized
INFO - 2022-03-23 04:43:42 --> Helper loaded: url_helper
INFO - 2022-03-23 04:43:42 --> Helper loaded: form_helper
INFO - 2022-03-23 04:43:42 --> Helper loaded: common_helper
INFO - 2022-03-23 04:43:42 --> Database Driver Class Initialized
DEBUG - 2022-03-23 04:43:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 04:43:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 04:43:42 --> Controller Class Initialized
INFO - 2022-03-23 04:43:42 --> Form Validation Class Initialized
DEBUG - 2022-03-23 04:43:42 --> Encrypt Class Initialized
DEBUG - 2022-03-23 04:43:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 04:43:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-23 04:43:42 --> Email Class Initialized
INFO - 2022-03-23 04:43:42 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-23 04:43:42 --> Calendar Class Initialized
INFO - 2022-03-23 04:43:42 --> Model "Login_model" initialized
INFO - 2022-03-23 04:43:42 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-23 04:43:42 --> Final output sent to browser
DEBUG - 2022-03-23 04:43:42 --> Total execution time: 0.0101
ERROR - 2022-03-23 04:44:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 04:44:05 --> Config Class Initialized
INFO - 2022-03-23 04:44:05 --> Hooks Class Initialized
DEBUG - 2022-03-23 04:44:05 --> UTF-8 Support Enabled
INFO - 2022-03-23 04:44:05 --> Utf8 Class Initialized
INFO - 2022-03-23 04:44:05 --> URI Class Initialized
INFO - 2022-03-23 04:44:05 --> Router Class Initialized
INFO - 2022-03-23 04:44:05 --> Output Class Initialized
INFO - 2022-03-23 04:44:05 --> Security Class Initialized
DEBUG - 2022-03-23 04:44:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 04:44:05 --> Input Class Initialized
INFO - 2022-03-23 04:44:05 --> Language Class Initialized
INFO - 2022-03-23 04:44:05 --> Loader Class Initialized
INFO - 2022-03-23 04:44:05 --> Helper loaded: url_helper
INFO - 2022-03-23 04:44:05 --> Helper loaded: form_helper
INFO - 2022-03-23 04:44:05 --> Helper loaded: common_helper
INFO - 2022-03-23 04:44:05 --> Database Driver Class Initialized
DEBUG - 2022-03-23 04:44:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 04:44:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 04:44:05 --> Controller Class Initialized
INFO - 2022-03-23 04:44:05 --> Form Validation Class Initialized
DEBUG - 2022-03-23 04:44:05 --> Encrypt Class Initialized
DEBUG - 2022-03-23 04:44:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 04:44:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-23 04:44:05 --> Email Class Initialized
INFO - 2022-03-23 04:44:05 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-23 04:44:05 --> Calendar Class Initialized
INFO - 2022-03-23 04:44:05 --> Model "Login_model" initialized
INFO - 2022-03-23 04:44:05 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-03-23 04:44:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 04:44:06 --> Config Class Initialized
INFO - 2022-03-23 04:44:06 --> Hooks Class Initialized
DEBUG - 2022-03-23 04:44:06 --> UTF-8 Support Enabled
INFO - 2022-03-23 04:44:06 --> Utf8 Class Initialized
INFO - 2022-03-23 04:44:06 --> URI Class Initialized
INFO - 2022-03-23 04:44:06 --> Router Class Initialized
INFO - 2022-03-23 04:44:06 --> Output Class Initialized
INFO - 2022-03-23 04:44:06 --> Security Class Initialized
DEBUG - 2022-03-23 04:44:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 04:44:06 --> Input Class Initialized
INFO - 2022-03-23 04:44:06 --> Language Class Initialized
INFO - 2022-03-23 04:44:06 --> Loader Class Initialized
INFO - 2022-03-23 04:44:06 --> Helper loaded: url_helper
INFO - 2022-03-23 04:44:06 --> Helper loaded: form_helper
INFO - 2022-03-23 04:44:06 --> Helper loaded: common_helper
INFO - 2022-03-23 04:44:06 --> Database Driver Class Initialized
DEBUG - 2022-03-23 04:44:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 04:44:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 04:44:06 --> Controller Class Initialized
INFO - 2022-03-23 04:44:06 --> Form Validation Class Initialized
DEBUG - 2022-03-23 04:44:06 --> Encrypt Class Initialized
INFO - 2022-03-23 04:44:06 --> Model "Login_model" initialized
INFO - 2022-03-23 04:44:06 --> Model "Dashboard_model" initialized
INFO - 2022-03-23 04:44:06 --> Model "Case_model" initialized
INFO - 2022-03-23 04:44:14 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 04:44:26 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2022-03-23 04:44:26 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 04:44:26 --> Final output sent to browser
DEBUG - 2022-03-23 04:44:26 --> Total execution time: 20.3032
ERROR - 2022-03-23 04:44:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 04:44:26 --> Config Class Initialized
INFO - 2022-03-23 04:44:26 --> Hooks Class Initialized
DEBUG - 2022-03-23 04:44:26 --> UTF-8 Support Enabled
INFO - 2022-03-23 04:44:26 --> Utf8 Class Initialized
INFO - 2022-03-23 04:44:26 --> URI Class Initialized
INFO - 2022-03-23 04:44:26 --> Router Class Initialized
INFO - 2022-03-23 04:44:26 --> Output Class Initialized
INFO - 2022-03-23 04:44:26 --> Security Class Initialized
DEBUG - 2022-03-23 04:44:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 04:44:26 --> Input Class Initialized
INFO - 2022-03-23 04:44:26 --> Language Class Initialized
ERROR - 2022-03-23 04:44:26 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-23 04:44:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 04:44:31 --> Config Class Initialized
INFO - 2022-03-23 04:44:31 --> Hooks Class Initialized
DEBUG - 2022-03-23 04:44:31 --> UTF-8 Support Enabled
INFO - 2022-03-23 04:44:31 --> Utf8 Class Initialized
INFO - 2022-03-23 04:44:31 --> URI Class Initialized
INFO - 2022-03-23 04:44:31 --> Router Class Initialized
INFO - 2022-03-23 04:44:31 --> Output Class Initialized
INFO - 2022-03-23 04:44:31 --> Security Class Initialized
DEBUG - 2022-03-23 04:44:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 04:44:31 --> Input Class Initialized
INFO - 2022-03-23 04:44:31 --> Language Class Initialized
INFO - 2022-03-23 04:44:31 --> Loader Class Initialized
INFO - 2022-03-23 04:44:31 --> Helper loaded: url_helper
INFO - 2022-03-23 04:44:31 --> Helper loaded: form_helper
INFO - 2022-03-23 04:44:31 --> Helper loaded: common_helper
INFO - 2022-03-23 04:44:31 --> Database Driver Class Initialized
DEBUG - 2022-03-23 04:44:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 04:44:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 04:44:31 --> Controller Class Initialized
INFO - 2022-03-23 04:44:31 --> Form Validation Class Initialized
DEBUG - 2022-03-23 04:44:31 --> Encrypt Class Initialized
INFO - 2022-03-23 04:44:31 --> Model "Patient_model" initialized
INFO - 2022-03-23 04:44:31 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 04:44:31 --> Model "Referredby_model" initialized
INFO - 2022-03-23 04:44:31 --> Model "Prefix_master" initialized
INFO - 2022-03-23 04:44:31 --> Model "Hospital_model" initialized
INFO - 2022-03-23 04:44:31 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 04:44:37 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-23 04:44:37 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
ERROR - 2022-03-23 04:44:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 04:44:38 --> Config Class Initialized
INFO - 2022-03-23 04:44:38 --> Hooks Class Initialized
DEBUG - 2022-03-23 04:44:38 --> UTF-8 Support Enabled
INFO - 2022-03-23 04:44:38 --> Utf8 Class Initialized
INFO - 2022-03-23 04:44:38 --> URI Class Initialized
INFO - 2022-03-23 04:44:38 --> Router Class Initialized
INFO - 2022-03-23 04:44:38 --> Output Class Initialized
INFO - 2022-03-23 04:44:38 --> Security Class Initialized
DEBUG - 2022-03-23 04:44:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 04:44:38 --> Input Class Initialized
INFO - 2022-03-23 04:44:38 --> Language Class Initialized
ERROR - 2022-03-23 04:44:38 --> 404 Page Not Found: Karoclient/usersprofile
INFO - 2022-03-23 04:44:39 --> Final output sent to browser
DEBUG - 2022-03-23 04:44:39 --> Total execution time: 6.4965
ERROR - 2022-03-23 04:45:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 04:45:05 --> Config Class Initialized
INFO - 2022-03-23 04:45:05 --> Hooks Class Initialized
DEBUG - 2022-03-23 04:45:05 --> UTF-8 Support Enabled
INFO - 2022-03-23 04:45:05 --> Utf8 Class Initialized
INFO - 2022-03-23 04:45:05 --> URI Class Initialized
INFO - 2022-03-23 04:45:05 --> Router Class Initialized
INFO - 2022-03-23 04:45:05 --> Output Class Initialized
INFO - 2022-03-23 04:45:05 --> Security Class Initialized
DEBUG - 2022-03-23 04:45:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 04:45:05 --> Input Class Initialized
INFO - 2022-03-23 04:45:05 --> Language Class Initialized
INFO - 2022-03-23 04:45:05 --> Loader Class Initialized
INFO - 2022-03-23 04:45:05 --> Helper loaded: url_helper
INFO - 2022-03-23 04:45:05 --> Helper loaded: form_helper
INFO - 2022-03-23 04:45:05 --> Helper loaded: common_helper
INFO - 2022-03-23 04:45:05 --> Database Driver Class Initialized
DEBUG - 2022-03-23 04:45:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 04:45:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 04:45:05 --> Controller Class Initialized
INFO - 2022-03-23 04:45:05 --> Form Validation Class Initialized
DEBUG - 2022-03-23 04:45:05 --> Encrypt Class Initialized
INFO - 2022-03-23 04:45:05 --> Model "Patient_model" initialized
INFO - 2022-03-23 04:45:05 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 04:45:05 --> Model "Prefix_master" initialized
INFO - 2022-03-23 04:45:05 --> Model "Users_model" initialized
INFO - 2022-03-23 04:45:05 --> Model "Hospital_model" initialized
INFO - 2022-03-23 04:45:05 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-23 04:45:05 --> Final output sent to browser
DEBUG - 2022-03-23 04:45:05 --> Total execution time: 0.6549
ERROR - 2022-03-23 04:45:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 04:45:36 --> Config Class Initialized
INFO - 2022-03-23 04:45:36 --> Hooks Class Initialized
DEBUG - 2022-03-23 04:45:36 --> UTF-8 Support Enabled
INFO - 2022-03-23 04:45:36 --> Utf8 Class Initialized
INFO - 2022-03-23 04:45:36 --> URI Class Initialized
INFO - 2022-03-23 04:45:36 --> Router Class Initialized
INFO - 2022-03-23 04:45:36 --> Output Class Initialized
INFO - 2022-03-23 04:45:36 --> Security Class Initialized
DEBUG - 2022-03-23 04:45:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 04:45:36 --> Input Class Initialized
INFO - 2022-03-23 04:45:36 --> Language Class Initialized
INFO - 2022-03-23 04:45:36 --> Loader Class Initialized
INFO - 2022-03-23 04:45:36 --> Helper loaded: url_helper
INFO - 2022-03-23 04:45:36 --> Helper loaded: form_helper
INFO - 2022-03-23 04:45:36 --> Helper loaded: common_helper
INFO - 2022-03-23 04:45:36 --> Database Driver Class Initialized
DEBUG - 2022-03-23 04:45:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 04:45:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 04:45:36 --> Controller Class Initialized
INFO - 2022-03-23 04:45:36 --> Form Validation Class Initialized
DEBUG - 2022-03-23 04:45:36 --> Encrypt Class Initialized
INFO - 2022-03-23 04:45:36 --> Model "Patient_model" initialized
INFO - 2022-03-23 04:45:36 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 04:45:36 --> Model "Referredby_model" initialized
INFO - 2022-03-23 04:45:36 --> Model "Prefix_master" initialized
INFO - 2022-03-23 04:45:36 --> Model "Hospital_model" initialized
INFO - 2022-03-23 04:45:36 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 04:45:36 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-23 04:45:36 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 04:45:36 --> Final output sent to browser
DEBUG - 2022-03-23 04:45:36 --> Total execution time: 0.0298
ERROR - 2022-03-23 04:45:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 04:45:36 --> Config Class Initialized
INFO - 2022-03-23 04:45:36 --> Hooks Class Initialized
DEBUG - 2022-03-23 04:45:36 --> UTF-8 Support Enabled
INFO - 2022-03-23 04:45:36 --> Utf8 Class Initialized
INFO - 2022-03-23 04:45:36 --> URI Class Initialized
INFO - 2022-03-23 04:45:36 --> Router Class Initialized
INFO - 2022-03-23 04:45:36 --> Output Class Initialized
INFO - 2022-03-23 04:45:36 --> Security Class Initialized
DEBUG - 2022-03-23 04:45:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 04:45:36 --> Input Class Initialized
INFO - 2022-03-23 04:45:36 --> Language Class Initialized
ERROR - 2022-03-23 04:45:36 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-23 04:46:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 04:46:17 --> Config Class Initialized
INFO - 2022-03-23 04:46:17 --> Hooks Class Initialized
DEBUG - 2022-03-23 04:46:17 --> UTF-8 Support Enabled
INFO - 2022-03-23 04:46:17 --> Utf8 Class Initialized
INFO - 2022-03-23 04:46:17 --> URI Class Initialized
INFO - 2022-03-23 04:46:17 --> Router Class Initialized
INFO - 2022-03-23 04:46:17 --> Output Class Initialized
INFO - 2022-03-23 04:46:17 --> Security Class Initialized
DEBUG - 2022-03-23 04:46:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 04:46:17 --> Input Class Initialized
INFO - 2022-03-23 04:46:17 --> Language Class Initialized
INFO - 2022-03-23 04:46:17 --> Loader Class Initialized
INFO - 2022-03-23 04:46:17 --> Helper loaded: url_helper
INFO - 2022-03-23 04:46:17 --> Helper loaded: form_helper
INFO - 2022-03-23 04:46:17 --> Helper loaded: common_helper
INFO - 2022-03-23 04:46:17 --> Database Driver Class Initialized
DEBUG - 2022-03-23 04:46:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 04:46:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 04:46:17 --> Controller Class Initialized
INFO - 2022-03-23 04:46:17 --> Form Validation Class Initialized
DEBUG - 2022-03-23 04:46:17 --> Encrypt Class Initialized
INFO - 2022-03-23 04:46:17 --> Model "Patient_model" initialized
INFO - 2022-03-23 04:46:17 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 04:46:17 --> Model "Prefix_master" initialized
INFO - 2022-03-23 04:46:17 --> Model "Users_model" initialized
INFO - 2022-03-23 04:46:17 --> Model "Hospital_model" initialized
INFO - 2022-03-23 04:46:17 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-23 04:46:18 --> Final output sent to browser
DEBUG - 2022-03-23 04:46:18 --> Total execution time: 0.8359
ERROR - 2022-03-23 05:00:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 05:00:55 --> Config Class Initialized
INFO - 2022-03-23 05:00:55 --> Hooks Class Initialized
DEBUG - 2022-03-23 05:00:55 --> UTF-8 Support Enabled
INFO - 2022-03-23 05:00:55 --> Utf8 Class Initialized
INFO - 2022-03-23 05:00:55 --> URI Class Initialized
INFO - 2022-03-23 05:00:55 --> Router Class Initialized
INFO - 2022-03-23 05:00:55 --> Output Class Initialized
INFO - 2022-03-23 05:00:55 --> Security Class Initialized
DEBUG - 2022-03-23 05:00:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 05:00:55 --> Input Class Initialized
INFO - 2022-03-23 05:00:55 --> Language Class Initialized
INFO - 2022-03-23 05:00:55 --> Loader Class Initialized
INFO - 2022-03-23 05:00:55 --> Helper loaded: url_helper
INFO - 2022-03-23 05:00:55 --> Helper loaded: form_helper
INFO - 2022-03-23 05:00:55 --> Helper loaded: common_helper
INFO - 2022-03-23 05:00:55 --> Database Driver Class Initialized
DEBUG - 2022-03-23 05:00:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 05:00:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 05:00:55 --> Controller Class Initialized
INFO - 2022-03-23 05:00:55 --> Form Validation Class Initialized
DEBUG - 2022-03-23 05:00:55 --> Encrypt Class Initialized
INFO - 2022-03-23 05:00:55 --> Model "Patient_model" initialized
INFO - 2022-03-23 05:00:55 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 05:00:55 --> Model "Referredby_model" initialized
INFO - 2022-03-23 05:00:55 --> Model "Prefix_master" initialized
INFO - 2022-03-23 05:00:55 --> Model "Hospital_model" initialized
INFO - 2022-03-23 05:00:55 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 05:00:55 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-23 05:00:55 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 05:00:55 --> Final output sent to browser
DEBUG - 2022-03-23 05:00:55 --> Total execution time: 0.0810
ERROR - 2022-03-23 05:13:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 05:13:07 --> Config Class Initialized
INFO - 2022-03-23 05:13:07 --> Hooks Class Initialized
DEBUG - 2022-03-23 05:13:07 --> UTF-8 Support Enabled
INFO - 2022-03-23 05:13:07 --> Utf8 Class Initialized
INFO - 2022-03-23 05:13:07 --> URI Class Initialized
DEBUG - 2022-03-23 05:13:07 --> No URI present. Default controller set.
INFO - 2022-03-23 05:13:07 --> Router Class Initialized
INFO - 2022-03-23 05:13:07 --> Output Class Initialized
INFO - 2022-03-23 05:13:07 --> Security Class Initialized
DEBUG - 2022-03-23 05:13:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 05:13:07 --> Input Class Initialized
INFO - 2022-03-23 05:13:07 --> Language Class Initialized
INFO - 2022-03-23 05:13:07 --> Loader Class Initialized
INFO - 2022-03-23 05:13:07 --> Helper loaded: url_helper
INFO - 2022-03-23 05:13:07 --> Helper loaded: form_helper
INFO - 2022-03-23 05:13:07 --> Helper loaded: common_helper
INFO - 2022-03-23 05:13:07 --> Database Driver Class Initialized
DEBUG - 2022-03-23 05:13:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 05:13:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 05:13:07 --> Controller Class Initialized
INFO - 2022-03-23 05:13:07 --> Form Validation Class Initialized
DEBUG - 2022-03-23 05:13:07 --> Encrypt Class Initialized
DEBUG - 2022-03-23 05:13:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 05:13:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-23 05:13:07 --> Email Class Initialized
INFO - 2022-03-23 05:13:07 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-23 05:13:07 --> Calendar Class Initialized
INFO - 2022-03-23 05:13:07 --> Model "Login_model" initialized
INFO - 2022-03-23 05:13:07 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-23 05:13:07 --> Final output sent to browser
DEBUG - 2022-03-23 05:13:07 --> Total execution time: 0.0685
ERROR - 2022-03-23 05:33:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 05:33:57 --> Config Class Initialized
INFO - 2022-03-23 05:33:57 --> Hooks Class Initialized
DEBUG - 2022-03-23 05:33:57 --> UTF-8 Support Enabled
INFO - 2022-03-23 05:33:57 --> Utf8 Class Initialized
INFO - 2022-03-23 05:33:57 --> URI Class Initialized
INFO - 2022-03-23 05:33:57 --> Router Class Initialized
INFO - 2022-03-23 05:33:57 --> Output Class Initialized
INFO - 2022-03-23 05:33:57 --> Security Class Initialized
DEBUG - 2022-03-23 05:33:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 05:33:57 --> Input Class Initialized
INFO - 2022-03-23 05:33:57 --> Language Class Initialized
INFO - 2022-03-23 05:33:57 --> Loader Class Initialized
INFO - 2022-03-23 05:33:57 --> Helper loaded: url_helper
INFO - 2022-03-23 05:33:57 --> Helper loaded: form_helper
INFO - 2022-03-23 05:33:57 --> Helper loaded: common_helper
INFO - 2022-03-23 05:33:57 --> Database Driver Class Initialized
DEBUG - 2022-03-23 05:33:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 05:33:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 05:33:57 --> Controller Class Initialized
INFO - 2022-03-23 05:33:57 --> Form Validation Class Initialized
DEBUG - 2022-03-23 05:33:57 --> Encrypt Class Initialized
INFO - 2022-03-23 05:33:57 --> Model "Patient_model" initialized
INFO - 2022-03-23 05:33:57 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 05:33:57 --> Model "Referredby_model" initialized
INFO - 2022-03-23 05:33:57 --> Model "Prefix_master" initialized
INFO - 2022-03-23 05:33:57 --> Model "Hospital_model" initialized
INFO - 2022-03-23 05:33:57 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 05:34:03 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-23 05:34:03 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 05:34:05 --> Final output sent to browser
DEBUG - 2022-03-23 05:34:05 --> Total execution time: 5.9452
ERROR - 2022-03-23 06:04:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 06:04:32 --> Config Class Initialized
INFO - 2022-03-23 06:04:32 --> Hooks Class Initialized
DEBUG - 2022-03-23 06:04:32 --> UTF-8 Support Enabled
INFO - 2022-03-23 06:04:32 --> Utf8 Class Initialized
INFO - 2022-03-23 06:04:32 --> URI Class Initialized
INFO - 2022-03-23 06:04:32 --> Router Class Initialized
INFO - 2022-03-23 06:04:32 --> Output Class Initialized
INFO - 2022-03-23 06:04:32 --> Security Class Initialized
DEBUG - 2022-03-23 06:04:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 06:04:32 --> Input Class Initialized
INFO - 2022-03-23 06:04:32 --> Language Class Initialized
INFO - 2022-03-23 06:04:32 --> Loader Class Initialized
INFO - 2022-03-23 06:04:32 --> Helper loaded: url_helper
INFO - 2022-03-23 06:04:32 --> Helper loaded: form_helper
INFO - 2022-03-23 06:04:32 --> Helper loaded: common_helper
INFO - 2022-03-23 06:04:32 --> Database Driver Class Initialized
DEBUG - 2022-03-23 06:04:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 06:04:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 06:04:32 --> Controller Class Initialized
INFO - 2022-03-23 06:04:32 --> Form Validation Class Initialized
DEBUG - 2022-03-23 06:04:32 --> Encrypt Class Initialized
INFO - 2022-03-23 06:04:32 --> Model "Patient_model" initialized
INFO - 2022-03-23 06:04:32 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 06:04:32 --> Model "Prefix_master" initialized
INFO - 2022-03-23 06:04:32 --> Model "Users_model" initialized
INFO - 2022-03-23 06:04:32 --> Model "Hospital_model" initialized
INFO - 2022-03-23 06:04:33 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 06:04:33 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-23 06:04:33 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 06:04:33 --> Final output sent to browser
DEBUG - 2022-03-23 06:04:33 --> Total execution time: 0.1923
ERROR - 2022-03-23 06:04:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 06:04:40 --> Config Class Initialized
INFO - 2022-03-23 06:04:40 --> Hooks Class Initialized
DEBUG - 2022-03-23 06:04:40 --> UTF-8 Support Enabled
INFO - 2022-03-23 06:04:40 --> Utf8 Class Initialized
INFO - 2022-03-23 06:04:40 --> URI Class Initialized
INFO - 2022-03-23 06:04:40 --> Router Class Initialized
INFO - 2022-03-23 06:04:40 --> Output Class Initialized
INFO - 2022-03-23 06:04:40 --> Security Class Initialized
DEBUG - 2022-03-23 06:04:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 06:04:40 --> Input Class Initialized
INFO - 2022-03-23 06:04:40 --> Language Class Initialized
INFO - 2022-03-23 06:04:40 --> Loader Class Initialized
INFO - 2022-03-23 06:04:40 --> Helper loaded: url_helper
INFO - 2022-03-23 06:04:40 --> Helper loaded: form_helper
INFO - 2022-03-23 06:04:40 --> Helper loaded: common_helper
INFO - 2022-03-23 06:04:40 --> Database Driver Class Initialized
DEBUG - 2022-03-23 06:04:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 06:04:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 06:04:40 --> Controller Class Initialized
INFO - 2022-03-23 06:04:40 --> Form Validation Class Initialized
DEBUG - 2022-03-23 06:04:40 --> Encrypt Class Initialized
INFO - 2022-03-23 06:04:40 --> Model "Patient_model" initialized
INFO - 2022-03-23 06:04:40 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 06:04:40 --> Model "Referredby_model" initialized
INFO - 2022-03-23 06:04:40 --> Model "Prefix_master" initialized
INFO - 2022-03-23 06:04:40 --> Model "Hospital_model" initialized
INFO - 2022-03-23 06:04:40 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 06:04:40 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-23 06:04:40 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 06:04:40 --> Final output sent to browser
DEBUG - 2022-03-23 06:04:40 --> Total execution time: 0.0386
ERROR - 2022-03-23 06:04:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 06:04:47 --> Config Class Initialized
INFO - 2022-03-23 06:04:47 --> Hooks Class Initialized
DEBUG - 2022-03-23 06:04:47 --> UTF-8 Support Enabled
INFO - 2022-03-23 06:04:47 --> Utf8 Class Initialized
INFO - 2022-03-23 06:04:47 --> URI Class Initialized
INFO - 2022-03-23 06:04:47 --> Router Class Initialized
INFO - 2022-03-23 06:04:47 --> Output Class Initialized
INFO - 2022-03-23 06:04:47 --> Security Class Initialized
DEBUG - 2022-03-23 06:04:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 06:04:47 --> Input Class Initialized
INFO - 2022-03-23 06:04:47 --> Language Class Initialized
INFO - 2022-03-23 06:04:47 --> Loader Class Initialized
INFO - 2022-03-23 06:04:47 --> Helper loaded: url_helper
INFO - 2022-03-23 06:04:47 --> Helper loaded: form_helper
INFO - 2022-03-23 06:04:47 --> Helper loaded: common_helper
INFO - 2022-03-23 06:04:47 --> Database Driver Class Initialized
DEBUG - 2022-03-23 06:04:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 06:04:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 06:04:47 --> Controller Class Initialized
INFO - 2022-03-23 06:04:47 --> Form Validation Class Initialized
DEBUG - 2022-03-23 06:04:47 --> Encrypt Class Initialized
INFO - 2022-03-23 06:04:47 --> Model "Patient_model" initialized
INFO - 2022-03-23 06:04:47 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 06:04:47 --> Model "Referredby_model" initialized
INFO - 2022-03-23 06:04:47 --> Model "Prefix_master" initialized
INFO - 2022-03-23 06:04:47 --> Model "Hospital_model" initialized
ERROR - 2022-03-23 06:04:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 06:04:47 --> Config Class Initialized
INFO - 2022-03-23 06:04:47 --> Hooks Class Initialized
DEBUG - 2022-03-23 06:04:47 --> UTF-8 Support Enabled
INFO - 2022-03-23 06:04:47 --> Utf8 Class Initialized
INFO - 2022-03-23 06:04:47 --> URI Class Initialized
INFO - 2022-03-23 06:04:47 --> Router Class Initialized
INFO - 2022-03-23 06:04:47 --> Output Class Initialized
INFO - 2022-03-23 06:04:47 --> Security Class Initialized
DEBUG - 2022-03-23 06:04:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 06:04:47 --> Input Class Initialized
INFO - 2022-03-23 06:04:47 --> Language Class Initialized
INFO - 2022-03-23 06:04:47 --> Loader Class Initialized
INFO - 2022-03-23 06:04:47 --> Helper loaded: url_helper
INFO - 2022-03-23 06:04:47 --> Helper loaded: form_helper
INFO - 2022-03-23 06:04:47 --> Helper loaded: common_helper
INFO - 2022-03-23 06:04:47 --> Database Driver Class Initialized
DEBUG - 2022-03-23 06:04:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 06:04:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 06:04:47 --> Controller Class Initialized
INFO - 2022-03-23 06:04:47 --> Form Validation Class Initialized
DEBUG - 2022-03-23 06:04:47 --> Encrypt Class Initialized
INFO - 2022-03-23 06:04:47 --> Model "Patient_model" initialized
INFO - 2022-03-23 06:04:47 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 06:04:47 --> Model "Referredby_model" initialized
INFO - 2022-03-23 06:04:47 --> Model "Prefix_master" initialized
INFO - 2022-03-23 06:04:47 --> Model "Hospital_model" initialized
INFO - 2022-03-23 06:04:47 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 06:04:47 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-23 06:04:47 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 06:04:47 --> Final output sent to browser
DEBUG - 2022-03-23 06:04:47 --> Total execution time: 0.0350
ERROR - 2022-03-23 06:04:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 06:04:48 --> Config Class Initialized
INFO - 2022-03-23 06:04:48 --> Hooks Class Initialized
DEBUG - 2022-03-23 06:04:48 --> UTF-8 Support Enabled
INFO - 2022-03-23 06:04:48 --> Utf8 Class Initialized
INFO - 2022-03-23 06:04:48 --> URI Class Initialized
INFO - 2022-03-23 06:04:48 --> Router Class Initialized
INFO - 2022-03-23 06:04:48 --> Output Class Initialized
INFO - 2022-03-23 06:04:48 --> Security Class Initialized
DEBUG - 2022-03-23 06:04:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 06:04:48 --> Input Class Initialized
INFO - 2022-03-23 06:04:48 --> Language Class Initialized
INFO - 2022-03-23 06:04:48 --> Loader Class Initialized
INFO - 2022-03-23 06:04:48 --> Helper loaded: url_helper
INFO - 2022-03-23 06:04:48 --> Helper loaded: form_helper
INFO - 2022-03-23 06:04:48 --> Helper loaded: common_helper
INFO - 2022-03-23 06:04:48 --> Database Driver Class Initialized
DEBUG - 2022-03-23 06:04:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 06:04:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 06:04:48 --> Controller Class Initialized
INFO - 2022-03-23 06:04:48 --> Form Validation Class Initialized
DEBUG - 2022-03-23 06:04:48 --> Encrypt Class Initialized
INFO - 2022-03-23 06:04:48 --> Model "Patient_model" initialized
INFO - 2022-03-23 06:04:48 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 06:04:48 --> Model "Prefix_master" initialized
INFO - 2022-03-23 06:04:48 --> Model "Users_model" initialized
INFO - 2022-03-23 06:04:48 --> Model "Hospital_model" initialized
INFO - 2022-03-23 06:04:48 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 06:04:48 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-23 06:04:48 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 06:04:48 --> Final output sent to browser
DEBUG - 2022-03-23 06:04:48 --> Total execution time: 0.0582
ERROR - 2022-03-23 06:05:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 06:05:32 --> Config Class Initialized
INFO - 2022-03-23 06:05:32 --> Hooks Class Initialized
DEBUG - 2022-03-23 06:05:32 --> UTF-8 Support Enabled
INFO - 2022-03-23 06:05:32 --> Utf8 Class Initialized
INFO - 2022-03-23 06:05:32 --> URI Class Initialized
INFO - 2022-03-23 06:05:32 --> Router Class Initialized
INFO - 2022-03-23 06:05:32 --> Output Class Initialized
INFO - 2022-03-23 06:05:32 --> Security Class Initialized
DEBUG - 2022-03-23 06:05:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 06:05:32 --> Input Class Initialized
INFO - 2022-03-23 06:05:32 --> Language Class Initialized
INFO - 2022-03-23 06:05:32 --> Loader Class Initialized
INFO - 2022-03-23 06:05:32 --> Helper loaded: url_helper
INFO - 2022-03-23 06:05:32 --> Helper loaded: form_helper
INFO - 2022-03-23 06:05:32 --> Helper loaded: common_helper
INFO - 2022-03-23 06:05:32 --> Database Driver Class Initialized
DEBUG - 2022-03-23 06:05:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 06:05:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 06:05:32 --> Controller Class Initialized
INFO - 2022-03-23 06:05:32 --> Form Validation Class Initialized
DEBUG - 2022-03-23 06:05:32 --> Encrypt Class Initialized
INFO - 2022-03-23 06:05:32 --> Model "Patient_model" initialized
INFO - 2022-03-23 06:05:32 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 06:05:32 --> Model "Prefix_master" initialized
INFO - 2022-03-23 06:05:32 --> Model "Users_model" initialized
INFO - 2022-03-23 06:05:32 --> Model "Hospital_model" initialized
INFO - 2022-03-23 06:05:32 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 06:05:32 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-23 06:05:32 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 06:05:32 --> Final output sent to browser
DEBUG - 2022-03-23 06:05:32 --> Total execution time: 0.0439
ERROR - 2022-03-23 06:05:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 06:05:34 --> Config Class Initialized
INFO - 2022-03-23 06:05:34 --> Hooks Class Initialized
DEBUG - 2022-03-23 06:05:34 --> UTF-8 Support Enabled
INFO - 2022-03-23 06:05:34 --> Utf8 Class Initialized
INFO - 2022-03-23 06:05:34 --> URI Class Initialized
INFO - 2022-03-23 06:05:34 --> Router Class Initialized
INFO - 2022-03-23 06:05:34 --> Output Class Initialized
INFO - 2022-03-23 06:05:34 --> Security Class Initialized
DEBUG - 2022-03-23 06:05:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 06:05:34 --> Input Class Initialized
INFO - 2022-03-23 06:05:34 --> Language Class Initialized
INFO - 2022-03-23 06:05:34 --> Loader Class Initialized
INFO - 2022-03-23 06:05:34 --> Helper loaded: url_helper
INFO - 2022-03-23 06:05:34 --> Helper loaded: form_helper
INFO - 2022-03-23 06:05:34 --> Helper loaded: common_helper
INFO - 2022-03-23 06:05:34 --> Database Driver Class Initialized
DEBUG - 2022-03-23 06:05:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 06:05:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 06:05:34 --> Controller Class Initialized
INFO - 2022-03-23 06:05:34 --> Form Validation Class Initialized
DEBUG - 2022-03-23 06:05:34 --> Encrypt Class Initialized
INFO - 2022-03-23 06:05:34 --> Model "Patient_model" initialized
INFO - 2022-03-23 06:05:34 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 06:05:34 --> Model "Referredby_model" initialized
INFO - 2022-03-23 06:05:34 --> Model "Prefix_master" initialized
INFO - 2022-03-23 06:05:34 --> Model "Hospital_model" initialized
INFO - 2022-03-23 06:05:34 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 06:05:34 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-23 06:05:34 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 06:05:34 --> Final output sent to browser
DEBUG - 2022-03-23 06:05:34 --> Total execution time: 0.0293
ERROR - 2022-03-23 06:06:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 06:06:17 --> Config Class Initialized
INFO - 2022-03-23 06:06:17 --> Hooks Class Initialized
DEBUG - 2022-03-23 06:06:17 --> UTF-8 Support Enabled
INFO - 2022-03-23 06:06:17 --> Utf8 Class Initialized
INFO - 2022-03-23 06:06:17 --> URI Class Initialized
INFO - 2022-03-23 06:06:17 --> Router Class Initialized
INFO - 2022-03-23 06:06:17 --> Output Class Initialized
INFO - 2022-03-23 06:06:17 --> Security Class Initialized
DEBUG - 2022-03-23 06:06:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 06:06:17 --> Input Class Initialized
INFO - 2022-03-23 06:06:17 --> Language Class Initialized
INFO - 2022-03-23 06:06:17 --> Loader Class Initialized
INFO - 2022-03-23 06:06:17 --> Helper loaded: url_helper
INFO - 2022-03-23 06:06:17 --> Helper loaded: form_helper
INFO - 2022-03-23 06:06:17 --> Helper loaded: common_helper
INFO - 2022-03-23 06:06:17 --> Database Driver Class Initialized
DEBUG - 2022-03-23 06:06:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 06:06:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 06:06:17 --> Controller Class Initialized
INFO - 2022-03-23 06:06:17 --> Form Validation Class Initialized
DEBUG - 2022-03-23 06:06:17 --> Encrypt Class Initialized
INFO - 2022-03-23 06:06:17 --> Model "Patient_model" initialized
INFO - 2022-03-23 06:06:17 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 06:06:17 --> Model "Prefix_master" initialized
INFO - 2022-03-23 06:06:17 --> Model "Users_model" initialized
INFO - 2022-03-23 06:06:17 --> Model "Hospital_model" initialized
INFO - 2022-03-23 06:06:17 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 06:06:17 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-23 06:06:17 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 06:06:17 --> Final output sent to browser
DEBUG - 2022-03-23 06:06:17 --> Total execution time: 0.0911
ERROR - 2022-03-23 06:06:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 06:06:47 --> Config Class Initialized
INFO - 2022-03-23 06:06:47 --> Hooks Class Initialized
DEBUG - 2022-03-23 06:06:47 --> UTF-8 Support Enabled
INFO - 2022-03-23 06:06:47 --> Utf8 Class Initialized
INFO - 2022-03-23 06:06:47 --> URI Class Initialized
INFO - 2022-03-23 06:06:47 --> Router Class Initialized
INFO - 2022-03-23 06:06:47 --> Output Class Initialized
INFO - 2022-03-23 06:06:47 --> Security Class Initialized
DEBUG - 2022-03-23 06:06:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 06:06:47 --> Input Class Initialized
INFO - 2022-03-23 06:06:47 --> Language Class Initialized
INFO - 2022-03-23 06:06:47 --> Loader Class Initialized
INFO - 2022-03-23 06:06:47 --> Helper loaded: url_helper
INFO - 2022-03-23 06:06:47 --> Helper loaded: form_helper
INFO - 2022-03-23 06:06:47 --> Helper loaded: common_helper
INFO - 2022-03-23 06:06:47 --> Database Driver Class Initialized
DEBUG - 2022-03-23 06:06:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 06:06:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 06:06:47 --> Controller Class Initialized
INFO - 2022-03-23 06:06:47 --> Form Validation Class Initialized
DEBUG - 2022-03-23 06:06:47 --> Encrypt Class Initialized
INFO - 2022-03-23 06:06:47 --> Model "Patient_model" initialized
INFO - 2022-03-23 06:06:47 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 06:06:47 --> Model "Prefix_master" initialized
INFO - 2022-03-23 06:06:47 --> Model "Users_model" initialized
INFO - 2022-03-23 06:06:47 --> Model "Hospital_model" initialized
ERROR - 2022-03-23 06:06:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 06:06:47 --> Config Class Initialized
INFO - 2022-03-23 06:06:47 --> Hooks Class Initialized
DEBUG - 2022-03-23 06:06:47 --> UTF-8 Support Enabled
INFO - 2022-03-23 06:06:47 --> Utf8 Class Initialized
INFO - 2022-03-23 06:06:47 --> URI Class Initialized
INFO - 2022-03-23 06:06:47 --> Router Class Initialized
INFO - 2022-03-23 06:06:47 --> Output Class Initialized
INFO - 2022-03-23 06:06:47 --> Security Class Initialized
DEBUG - 2022-03-23 06:06:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 06:06:47 --> Input Class Initialized
INFO - 2022-03-23 06:06:47 --> Language Class Initialized
INFO - 2022-03-23 06:06:47 --> Loader Class Initialized
INFO - 2022-03-23 06:06:47 --> Helper loaded: url_helper
INFO - 2022-03-23 06:06:47 --> Helper loaded: form_helper
INFO - 2022-03-23 06:06:47 --> Helper loaded: common_helper
INFO - 2022-03-23 06:06:47 --> Database Driver Class Initialized
DEBUG - 2022-03-23 06:06:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 06:06:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 06:06:47 --> Controller Class Initialized
INFO - 2022-03-23 06:06:47 --> Form Validation Class Initialized
DEBUG - 2022-03-23 06:06:47 --> Encrypt Class Initialized
INFO - 2022-03-23 06:06:47 --> Model "Patient_model" initialized
INFO - 2022-03-23 06:06:47 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 06:06:47 --> Model "Prefix_master" initialized
INFO - 2022-03-23 06:06:47 --> Model "Users_model" initialized
INFO - 2022-03-23 06:06:47 --> Model "Hospital_model" initialized
INFO - 2022-03-23 06:06:48 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 06:06:48 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-23 06:06:48 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 06:06:48 --> Final output sent to browser
DEBUG - 2022-03-23 06:06:48 --> Total execution time: 0.0493
ERROR - 2022-03-23 06:07:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 06:07:30 --> Config Class Initialized
INFO - 2022-03-23 06:07:30 --> Hooks Class Initialized
DEBUG - 2022-03-23 06:07:30 --> UTF-8 Support Enabled
INFO - 2022-03-23 06:07:30 --> Utf8 Class Initialized
INFO - 2022-03-23 06:07:30 --> URI Class Initialized
INFO - 2022-03-23 06:07:30 --> Router Class Initialized
INFO - 2022-03-23 06:07:30 --> Output Class Initialized
INFO - 2022-03-23 06:07:30 --> Security Class Initialized
DEBUG - 2022-03-23 06:07:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 06:07:30 --> Input Class Initialized
INFO - 2022-03-23 06:07:30 --> Language Class Initialized
INFO - 2022-03-23 06:07:30 --> Loader Class Initialized
INFO - 2022-03-23 06:07:30 --> Helper loaded: url_helper
INFO - 2022-03-23 06:07:30 --> Helper loaded: form_helper
INFO - 2022-03-23 06:07:30 --> Helper loaded: common_helper
INFO - 2022-03-23 06:07:30 --> Database Driver Class Initialized
DEBUG - 2022-03-23 06:07:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 06:07:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 06:07:30 --> Controller Class Initialized
INFO - 2022-03-23 06:07:30 --> Form Validation Class Initialized
DEBUG - 2022-03-23 06:07:30 --> Encrypt Class Initialized
INFO - 2022-03-23 06:07:30 --> Model "Patient_model" initialized
INFO - 2022-03-23 06:07:30 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 06:07:30 --> Model "Prefix_master" initialized
INFO - 2022-03-23 06:07:30 --> Model "Users_model" initialized
INFO - 2022-03-23 06:07:30 --> Model "Hospital_model" initialized
INFO - 2022-03-23 06:07:30 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 06:07:30 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-23 06:07:30 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 06:07:30 --> Final output sent to browser
DEBUG - 2022-03-23 06:07:30 --> Total execution time: 0.0644
ERROR - 2022-03-23 06:08:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 06:08:24 --> Config Class Initialized
INFO - 2022-03-23 06:08:24 --> Hooks Class Initialized
DEBUG - 2022-03-23 06:08:24 --> UTF-8 Support Enabled
INFO - 2022-03-23 06:08:24 --> Utf8 Class Initialized
INFO - 2022-03-23 06:08:24 --> URI Class Initialized
INFO - 2022-03-23 06:08:24 --> Router Class Initialized
INFO - 2022-03-23 06:08:24 --> Output Class Initialized
INFO - 2022-03-23 06:08:24 --> Security Class Initialized
DEBUG - 2022-03-23 06:08:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 06:08:24 --> Input Class Initialized
INFO - 2022-03-23 06:08:24 --> Language Class Initialized
INFO - 2022-03-23 06:08:24 --> Loader Class Initialized
INFO - 2022-03-23 06:08:24 --> Helper loaded: url_helper
INFO - 2022-03-23 06:08:24 --> Helper loaded: form_helper
INFO - 2022-03-23 06:08:24 --> Helper loaded: common_helper
INFO - 2022-03-23 06:08:24 --> Database Driver Class Initialized
DEBUG - 2022-03-23 06:08:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 06:08:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 06:08:24 --> Controller Class Initialized
INFO - 2022-03-23 06:08:24 --> Form Validation Class Initialized
DEBUG - 2022-03-23 06:08:24 --> Encrypt Class Initialized
INFO - 2022-03-23 06:08:24 --> Model "Patient_model" initialized
INFO - 2022-03-23 06:08:24 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 06:08:24 --> Model "Prefix_master" initialized
INFO - 2022-03-23 06:08:24 --> Model "Users_model" initialized
INFO - 2022-03-23 06:08:24 --> Model "Hospital_model" initialized
INFO - 2022-03-23 06:08:24 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 06:08:24 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-23 06:08:24 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 06:08:24 --> Final output sent to browser
DEBUG - 2022-03-23 06:08:24 --> Total execution time: 0.0472
ERROR - 2022-03-23 06:09:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 06:09:06 --> Config Class Initialized
INFO - 2022-03-23 06:09:06 --> Hooks Class Initialized
DEBUG - 2022-03-23 06:09:06 --> UTF-8 Support Enabled
INFO - 2022-03-23 06:09:06 --> Utf8 Class Initialized
INFO - 2022-03-23 06:09:06 --> URI Class Initialized
INFO - 2022-03-23 06:09:06 --> Router Class Initialized
INFO - 2022-03-23 06:09:06 --> Output Class Initialized
INFO - 2022-03-23 06:09:06 --> Security Class Initialized
DEBUG - 2022-03-23 06:09:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 06:09:06 --> Input Class Initialized
INFO - 2022-03-23 06:09:06 --> Language Class Initialized
INFO - 2022-03-23 06:09:06 --> Loader Class Initialized
INFO - 2022-03-23 06:09:06 --> Helper loaded: url_helper
INFO - 2022-03-23 06:09:06 --> Helper loaded: form_helper
INFO - 2022-03-23 06:09:06 --> Helper loaded: common_helper
INFO - 2022-03-23 06:09:06 --> Database Driver Class Initialized
DEBUG - 2022-03-23 06:09:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 06:09:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 06:09:06 --> Controller Class Initialized
INFO - 2022-03-23 06:09:06 --> Form Validation Class Initialized
DEBUG - 2022-03-23 06:09:06 --> Encrypt Class Initialized
INFO - 2022-03-23 06:09:06 --> Model "Patient_model" initialized
INFO - 2022-03-23 06:09:06 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 06:09:06 --> Model "Prefix_master" initialized
INFO - 2022-03-23 06:09:06 --> Model "Users_model" initialized
INFO - 2022-03-23 06:09:06 --> Model "Hospital_model" initialized
INFO - 2022-03-23 06:09:06 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 06:09:06 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-23 06:09:06 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 06:09:06 --> Final output sent to browser
DEBUG - 2022-03-23 06:09:06 --> Total execution time: 0.0505
ERROR - 2022-03-23 06:15:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 06:15:42 --> Config Class Initialized
INFO - 2022-03-23 06:15:42 --> Hooks Class Initialized
DEBUG - 2022-03-23 06:15:42 --> UTF-8 Support Enabled
INFO - 2022-03-23 06:15:42 --> Utf8 Class Initialized
INFO - 2022-03-23 06:15:42 --> URI Class Initialized
INFO - 2022-03-23 06:15:42 --> Router Class Initialized
INFO - 2022-03-23 06:15:42 --> Output Class Initialized
INFO - 2022-03-23 06:15:42 --> Security Class Initialized
DEBUG - 2022-03-23 06:15:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 06:15:42 --> Input Class Initialized
INFO - 2022-03-23 06:15:42 --> Language Class Initialized
INFO - 2022-03-23 06:15:42 --> Loader Class Initialized
INFO - 2022-03-23 06:15:42 --> Helper loaded: url_helper
INFO - 2022-03-23 06:15:42 --> Helper loaded: form_helper
INFO - 2022-03-23 06:15:42 --> Helper loaded: common_helper
INFO - 2022-03-23 06:15:42 --> Database Driver Class Initialized
DEBUG - 2022-03-23 06:15:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 06:15:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 06:15:42 --> Controller Class Initialized
INFO - 2022-03-23 06:15:42 --> Form Validation Class Initialized
DEBUG - 2022-03-23 06:15:42 --> Encrypt Class Initialized
INFO - 2022-03-23 06:15:42 --> Model "Patient_model" initialized
INFO - 2022-03-23 06:15:42 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 06:15:42 --> Model "Prefix_master" initialized
INFO - 2022-03-23 06:15:42 --> Model "Users_model" initialized
INFO - 2022-03-23 06:15:42 --> Model "Hospital_model" initialized
INFO - 2022-03-23 06:15:42 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 06:15:42 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-23 06:15:42 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 06:15:42 --> Final output sent to browser
DEBUG - 2022-03-23 06:15:42 --> Total execution time: 0.1477
ERROR - 2022-03-23 06:20:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 06:20:11 --> Config Class Initialized
INFO - 2022-03-23 06:20:11 --> Hooks Class Initialized
DEBUG - 2022-03-23 06:20:11 --> UTF-8 Support Enabled
INFO - 2022-03-23 06:20:11 --> Utf8 Class Initialized
INFO - 2022-03-23 06:20:11 --> URI Class Initialized
INFO - 2022-03-23 06:20:11 --> Router Class Initialized
INFO - 2022-03-23 06:20:11 --> Output Class Initialized
INFO - 2022-03-23 06:20:11 --> Security Class Initialized
DEBUG - 2022-03-23 06:20:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 06:20:11 --> Input Class Initialized
INFO - 2022-03-23 06:20:11 --> Language Class Initialized
INFO - 2022-03-23 06:20:11 --> Loader Class Initialized
INFO - 2022-03-23 06:20:11 --> Helper loaded: url_helper
INFO - 2022-03-23 06:20:11 --> Helper loaded: form_helper
INFO - 2022-03-23 06:20:11 --> Helper loaded: common_helper
INFO - 2022-03-23 06:20:11 --> Database Driver Class Initialized
DEBUG - 2022-03-23 06:20:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 06:20:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 06:20:11 --> Controller Class Initialized
INFO - 2022-03-23 06:20:11 --> Form Validation Class Initialized
DEBUG - 2022-03-23 06:20:11 --> Encrypt Class Initialized
INFO - 2022-03-23 06:20:11 --> Model "Patient_model" initialized
INFO - 2022-03-23 06:20:11 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 06:20:11 --> Model "Prefix_master" initialized
INFO - 2022-03-23 06:20:11 --> Model "Users_model" initialized
INFO - 2022-03-23 06:20:11 --> Model "Hospital_model" initialized
INFO - 2022-03-23 06:20:11 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 06:20:11 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-23 06:20:11 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 06:20:11 --> Final output sent to browser
DEBUG - 2022-03-23 06:20:11 --> Total execution time: 0.1058
ERROR - 2022-03-23 06:24:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 06:24:27 --> Config Class Initialized
INFO - 2022-03-23 06:24:27 --> Hooks Class Initialized
DEBUG - 2022-03-23 06:24:27 --> UTF-8 Support Enabled
INFO - 2022-03-23 06:24:27 --> Utf8 Class Initialized
INFO - 2022-03-23 06:24:27 --> URI Class Initialized
INFO - 2022-03-23 06:24:27 --> Router Class Initialized
INFO - 2022-03-23 06:24:27 --> Output Class Initialized
INFO - 2022-03-23 06:24:27 --> Security Class Initialized
DEBUG - 2022-03-23 06:24:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 06:24:27 --> Input Class Initialized
INFO - 2022-03-23 06:24:27 --> Language Class Initialized
INFO - 2022-03-23 06:24:27 --> Loader Class Initialized
INFO - 2022-03-23 06:24:27 --> Helper loaded: url_helper
INFO - 2022-03-23 06:24:27 --> Helper loaded: form_helper
INFO - 2022-03-23 06:24:27 --> Helper loaded: common_helper
INFO - 2022-03-23 06:24:27 --> Database Driver Class Initialized
DEBUG - 2022-03-23 06:24:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 06:24:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 06:24:27 --> Controller Class Initialized
INFO - 2022-03-23 06:24:27 --> Form Validation Class Initialized
DEBUG - 2022-03-23 06:24:27 --> Encrypt Class Initialized
INFO - 2022-03-23 06:24:27 --> Model "Patient_model" initialized
INFO - 2022-03-23 06:24:27 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 06:24:27 --> Model "Prefix_master" initialized
INFO - 2022-03-23 06:24:27 --> Model "Users_model" initialized
INFO - 2022-03-23 06:24:27 --> Model "Hospital_model" initialized
INFO - 2022-03-23 06:24:27 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 06:24:27 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-23 06:24:27 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 06:24:27 --> Final output sent to browser
DEBUG - 2022-03-23 06:24:27 --> Total execution time: 0.1012
ERROR - 2022-03-23 06:25:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 06:25:01 --> Config Class Initialized
INFO - 2022-03-23 06:25:01 --> Hooks Class Initialized
DEBUG - 2022-03-23 06:25:01 --> UTF-8 Support Enabled
INFO - 2022-03-23 06:25:01 --> Utf8 Class Initialized
INFO - 2022-03-23 06:25:01 --> URI Class Initialized
INFO - 2022-03-23 06:25:01 --> Router Class Initialized
INFO - 2022-03-23 06:25:01 --> Output Class Initialized
INFO - 2022-03-23 06:25:01 --> Security Class Initialized
DEBUG - 2022-03-23 06:25:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 06:25:01 --> Input Class Initialized
INFO - 2022-03-23 06:25:01 --> Language Class Initialized
INFO - 2022-03-23 06:25:01 --> Loader Class Initialized
INFO - 2022-03-23 06:25:01 --> Helper loaded: url_helper
INFO - 2022-03-23 06:25:01 --> Helper loaded: form_helper
INFO - 2022-03-23 06:25:01 --> Helper loaded: common_helper
INFO - 2022-03-23 06:25:01 --> Database Driver Class Initialized
DEBUG - 2022-03-23 06:25:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 06:25:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 06:25:01 --> Controller Class Initialized
INFO - 2022-03-23 06:25:01 --> Form Validation Class Initialized
DEBUG - 2022-03-23 06:25:01 --> Encrypt Class Initialized
INFO - 2022-03-23 06:25:01 --> Model "Patient_model" initialized
INFO - 2022-03-23 06:25:01 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 06:25:01 --> Model "Prefix_master" initialized
INFO - 2022-03-23 06:25:01 --> Model "Users_model" initialized
INFO - 2022-03-23 06:25:01 --> Model "Hospital_model" initialized
INFO - 2022-03-23 06:25:01 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 06:25:01 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-23 06:25:01 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 06:25:01 --> Final output sent to browser
DEBUG - 2022-03-23 06:25:01 --> Total execution time: 0.0457
ERROR - 2022-03-23 06:25:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 06:25:43 --> Config Class Initialized
INFO - 2022-03-23 06:25:43 --> Hooks Class Initialized
DEBUG - 2022-03-23 06:25:43 --> UTF-8 Support Enabled
INFO - 2022-03-23 06:25:43 --> Utf8 Class Initialized
INFO - 2022-03-23 06:25:43 --> URI Class Initialized
INFO - 2022-03-23 06:25:43 --> Router Class Initialized
INFO - 2022-03-23 06:25:43 --> Output Class Initialized
INFO - 2022-03-23 06:25:43 --> Security Class Initialized
DEBUG - 2022-03-23 06:25:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 06:25:43 --> Input Class Initialized
INFO - 2022-03-23 06:25:43 --> Language Class Initialized
INFO - 2022-03-23 06:25:43 --> Loader Class Initialized
INFO - 2022-03-23 06:25:43 --> Helper loaded: url_helper
INFO - 2022-03-23 06:25:43 --> Helper loaded: form_helper
INFO - 2022-03-23 06:25:43 --> Helper loaded: common_helper
INFO - 2022-03-23 06:25:43 --> Database Driver Class Initialized
DEBUG - 2022-03-23 06:25:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 06:25:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 06:25:43 --> Controller Class Initialized
INFO - 2022-03-23 06:25:43 --> Form Validation Class Initialized
DEBUG - 2022-03-23 06:25:43 --> Encrypt Class Initialized
INFO - 2022-03-23 06:25:43 --> Model "Patient_model" initialized
INFO - 2022-03-23 06:25:43 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 06:25:43 --> Model "Prefix_master" initialized
INFO - 2022-03-23 06:25:43 --> Model "Users_model" initialized
INFO - 2022-03-23 06:25:43 --> Model "Hospital_model" initialized
INFO - 2022-03-23 06:25:43 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 06:25:43 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-23 06:25:43 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 06:25:43 --> Final output sent to browser
DEBUG - 2022-03-23 06:25:43 --> Total execution time: 0.0409
ERROR - 2022-03-23 06:26:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 06:26:22 --> Config Class Initialized
INFO - 2022-03-23 06:26:22 --> Hooks Class Initialized
DEBUG - 2022-03-23 06:26:22 --> UTF-8 Support Enabled
INFO - 2022-03-23 06:26:22 --> Utf8 Class Initialized
INFO - 2022-03-23 06:26:22 --> URI Class Initialized
INFO - 2022-03-23 06:26:22 --> Router Class Initialized
INFO - 2022-03-23 06:26:22 --> Output Class Initialized
INFO - 2022-03-23 06:26:22 --> Security Class Initialized
DEBUG - 2022-03-23 06:26:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 06:26:22 --> Input Class Initialized
INFO - 2022-03-23 06:26:22 --> Language Class Initialized
INFO - 2022-03-23 06:26:22 --> Loader Class Initialized
INFO - 2022-03-23 06:26:22 --> Helper loaded: url_helper
INFO - 2022-03-23 06:26:22 --> Helper loaded: form_helper
INFO - 2022-03-23 06:26:22 --> Helper loaded: common_helper
INFO - 2022-03-23 06:26:22 --> Database Driver Class Initialized
DEBUG - 2022-03-23 06:26:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 06:26:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 06:26:22 --> Controller Class Initialized
INFO - 2022-03-23 06:26:22 --> Form Validation Class Initialized
DEBUG - 2022-03-23 06:26:22 --> Encrypt Class Initialized
INFO - 2022-03-23 06:26:22 --> Model "Patient_model" initialized
INFO - 2022-03-23 06:26:22 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 06:26:22 --> Model "Prefix_master" initialized
INFO - 2022-03-23 06:26:22 --> Model "Users_model" initialized
INFO - 2022-03-23 06:26:22 --> Model "Hospital_model" initialized
INFO - 2022-03-23 06:26:22 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 06:26:22 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-23 06:26:22 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 06:26:22 --> Final output sent to browser
DEBUG - 2022-03-23 06:26:22 --> Total execution time: 0.0396
ERROR - 2022-03-23 06:27:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 06:27:10 --> Config Class Initialized
INFO - 2022-03-23 06:27:10 --> Hooks Class Initialized
DEBUG - 2022-03-23 06:27:10 --> UTF-8 Support Enabled
INFO - 2022-03-23 06:27:10 --> Utf8 Class Initialized
INFO - 2022-03-23 06:27:10 --> URI Class Initialized
INFO - 2022-03-23 06:27:10 --> Router Class Initialized
INFO - 2022-03-23 06:27:10 --> Output Class Initialized
INFO - 2022-03-23 06:27:10 --> Security Class Initialized
DEBUG - 2022-03-23 06:27:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 06:27:10 --> Input Class Initialized
INFO - 2022-03-23 06:27:10 --> Language Class Initialized
INFO - 2022-03-23 06:27:10 --> Loader Class Initialized
INFO - 2022-03-23 06:27:10 --> Helper loaded: url_helper
INFO - 2022-03-23 06:27:10 --> Helper loaded: form_helper
INFO - 2022-03-23 06:27:10 --> Helper loaded: common_helper
INFO - 2022-03-23 06:27:10 --> Database Driver Class Initialized
DEBUG - 2022-03-23 06:27:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 06:27:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 06:27:10 --> Controller Class Initialized
INFO - 2022-03-23 06:27:10 --> Form Validation Class Initialized
DEBUG - 2022-03-23 06:27:10 --> Encrypt Class Initialized
INFO - 2022-03-23 06:27:10 --> Model "Patient_model" initialized
INFO - 2022-03-23 06:27:10 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 06:27:10 --> Model "Prefix_master" initialized
INFO - 2022-03-23 06:27:10 --> Model "Users_model" initialized
INFO - 2022-03-23 06:27:10 --> Model "Hospital_model" initialized
INFO - 2022-03-23 06:27:10 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 06:27:10 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-23 06:27:10 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 06:27:10 --> Final output sent to browser
DEBUG - 2022-03-23 06:27:10 --> Total execution time: 0.0579
ERROR - 2022-03-23 06:28:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 06:28:04 --> Config Class Initialized
INFO - 2022-03-23 06:28:04 --> Hooks Class Initialized
DEBUG - 2022-03-23 06:28:04 --> UTF-8 Support Enabled
INFO - 2022-03-23 06:28:04 --> Utf8 Class Initialized
INFO - 2022-03-23 06:28:04 --> URI Class Initialized
INFO - 2022-03-23 06:28:04 --> Router Class Initialized
INFO - 2022-03-23 06:28:04 --> Output Class Initialized
INFO - 2022-03-23 06:28:04 --> Security Class Initialized
DEBUG - 2022-03-23 06:28:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 06:28:04 --> Input Class Initialized
INFO - 2022-03-23 06:28:04 --> Language Class Initialized
INFO - 2022-03-23 06:28:04 --> Loader Class Initialized
INFO - 2022-03-23 06:28:04 --> Helper loaded: url_helper
INFO - 2022-03-23 06:28:04 --> Helper loaded: form_helper
INFO - 2022-03-23 06:28:04 --> Helper loaded: common_helper
INFO - 2022-03-23 06:28:04 --> Database Driver Class Initialized
DEBUG - 2022-03-23 06:28:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 06:28:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 06:28:04 --> Controller Class Initialized
INFO - 2022-03-23 06:28:04 --> Form Validation Class Initialized
DEBUG - 2022-03-23 06:28:04 --> Encrypt Class Initialized
INFO - 2022-03-23 06:28:04 --> Model "Patient_model" initialized
INFO - 2022-03-23 06:28:04 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 06:28:04 --> Model "Prefix_master" initialized
INFO - 2022-03-23 06:28:04 --> Model "Users_model" initialized
INFO - 2022-03-23 06:28:04 --> Model "Hospital_model" initialized
INFO - 2022-03-23 06:28:04 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 06:28:04 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-23 06:28:04 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 06:28:04 --> Final output sent to browser
DEBUG - 2022-03-23 06:28:04 --> Total execution time: 0.0450
ERROR - 2022-03-23 06:28:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 06:28:35 --> Config Class Initialized
INFO - 2022-03-23 06:28:35 --> Hooks Class Initialized
DEBUG - 2022-03-23 06:28:35 --> UTF-8 Support Enabled
INFO - 2022-03-23 06:28:35 --> Utf8 Class Initialized
INFO - 2022-03-23 06:28:35 --> URI Class Initialized
INFO - 2022-03-23 06:28:35 --> Router Class Initialized
INFO - 2022-03-23 06:28:35 --> Output Class Initialized
INFO - 2022-03-23 06:28:35 --> Security Class Initialized
DEBUG - 2022-03-23 06:28:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 06:28:35 --> Input Class Initialized
INFO - 2022-03-23 06:28:35 --> Language Class Initialized
INFO - 2022-03-23 06:28:35 --> Loader Class Initialized
INFO - 2022-03-23 06:28:35 --> Helper loaded: url_helper
INFO - 2022-03-23 06:28:35 --> Helper loaded: form_helper
INFO - 2022-03-23 06:28:35 --> Helper loaded: common_helper
INFO - 2022-03-23 06:28:35 --> Database Driver Class Initialized
DEBUG - 2022-03-23 06:28:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 06:28:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 06:28:35 --> Controller Class Initialized
INFO - 2022-03-23 06:28:35 --> Form Validation Class Initialized
DEBUG - 2022-03-23 06:28:35 --> Encrypt Class Initialized
INFO - 2022-03-23 06:28:35 --> Model "Patient_model" initialized
INFO - 2022-03-23 06:28:35 --> Model "Patientcase_model" initialized
INFO - 2022-03-23 06:28:35 --> Model "Prefix_master" initialized
INFO - 2022-03-23 06:28:35 --> Model "Users_model" initialized
INFO - 2022-03-23 06:28:35 --> Model "Hospital_model" initialized
INFO - 2022-03-23 06:28:35 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-23 06:28:35 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-23 06:28:35 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-23 06:28:35 --> Final output sent to browser
DEBUG - 2022-03-23 06:28:35 --> Total execution time: 0.0392
ERROR - 2022-03-23 07:47:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 07:47:05 --> Config Class Initialized
INFO - 2022-03-23 07:47:05 --> Hooks Class Initialized
DEBUG - 2022-03-23 07:47:05 --> UTF-8 Support Enabled
INFO - 2022-03-23 07:47:05 --> Utf8 Class Initialized
INFO - 2022-03-23 07:47:05 --> URI Class Initialized
INFO - 2022-03-23 07:47:05 --> Router Class Initialized
INFO - 2022-03-23 07:47:05 --> Output Class Initialized
INFO - 2022-03-23 07:47:05 --> Security Class Initialized
DEBUG - 2022-03-23 07:47:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 07:47:05 --> Input Class Initialized
INFO - 2022-03-23 07:47:05 --> Language Class Initialized
INFO - 2022-03-23 07:47:05 --> Loader Class Initialized
INFO - 2022-03-23 07:47:05 --> Helper loaded: url_helper
INFO - 2022-03-23 07:47:05 --> Helper loaded: form_helper
INFO - 2022-03-23 07:47:05 --> Helper loaded: common_helper
INFO - 2022-03-23 07:47:05 --> Database Driver Class Initialized
DEBUG - 2022-03-23 07:47:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 07:47:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 07:47:05 --> Controller Class Initialized
ERROR - 2022-03-23 08:00:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 08:00:43 --> Config Class Initialized
INFO - 2022-03-23 08:00:43 --> Hooks Class Initialized
DEBUG - 2022-03-23 08:00:43 --> UTF-8 Support Enabled
INFO - 2022-03-23 08:00:43 --> Utf8 Class Initialized
INFO - 2022-03-23 08:00:43 --> URI Class Initialized
INFO - 2022-03-23 08:00:43 --> Router Class Initialized
INFO - 2022-03-23 08:00:43 --> Output Class Initialized
INFO - 2022-03-23 08:00:43 --> Security Class Initialized
DEBUG - 2022-03-23 08:00:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 08:00:43 --> Input Class Initialized
INFO - 2022-03-23 08:00:43 --> Language Class Initialized
INFO - 2022-03-23 08:00:43 --> Loader Class Initialized
INFO - 2022-03-23 08:00:43 --> Helper loaded: url_helper
INFO - 2022-03-23 08:00:43 --> Helper loaded: form_helper
INFO - 2022-03-23 08:00:43 --> Helper loaded: common_helper
INFO - 2022-03-23 08:00:43 --> Database Driver Class Initialized
DEBUG - 2022-03-23 08:00:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 08:00:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 08:00:43 --> Controller Class Initialized
ERROR - 2022-03-23 08:00:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 08:00:43 --> Config Class Initialized
INFO - 2022-03-23 08:00:43 --> Hooks Class Initialized
DEBUG - 2022-03-23 08:00:43 --> UTF-8 Support Enabled
INFO - 2022-03-23 08:00:43 --> Utf8 Class Initialized
INFO - 2022-03-23 08:00:43 --> URI Class Initialized
INFO - 2022-03-23 08:00:43 --> Router Class Initialized
INFO - 2022-03-23 08:00:43 --> Output Class Initialized
INFO - 2022-03-23 08:00:43 --> Security Class Initialized
DEBUG - 2022-03-23 08:00:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 08:00:43 --> Input Class Initialized
INFO - 2022-03-23 08:00:43 --> Language Class Initialized
INFO - 2022-03-23 08:00:43 --> Loader Class Initialized
INFO - 2022-03-23 08:00:43 --> Helper loaded: url_helper
INFO - 2022-03-23 08:00:43 --> Helper loaded: form_helper
INFO - 2022-03-23 08:00:43 --> Helper loaded: common_helper
INFO - 2022-03-23 08:00:43 --> Database Driver Class Initialized
DEBUG - 2022-03-23 08:00:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 08:00:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 08:00:43 --> Controller Class Initialized
INFO - 2022-03-23 08:00:43 --> Form Validation Class Initialized
DEBUG - 2022-03-23 08:00:43 --> Encrypt Class Initialized
DEBUG - 2022-03-23 08:00:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 08:00:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-23 08:00:43 --> Email Class Initialized
INFO - 2022-03-23 08:00:43 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-23 08:00:43 --> Calendar Class Initialized
INFO - 2022-03-23 08:00:43 --> Model "Login_model" initialized
INFO - 2022-03-23 08:00:43 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-23 08:00:43 --> Final output sent to browser
DEBUG - 2022-03-23 08:00:43 --> Total execution time: 0.0692
ERROR - 2022-03-23 14:18:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 14:18:22 --> Config Class Initialized
INFO - 2022-03-23 14:18:22 --> Hooks Class Initialized
DEBUG - 2022-03-23 14:18:22 --> UTF-8 Support Enabled
INFO - 2022-03-23 14:18:22 --> Utf8 Class Initialized
INFO - 2022-03-23 14:18:22 --> URI Class Initialized
DEBUG - 2022-03-23 14:18:22 --> No URI present. Default controller set.
INFO - 2022-03-23 14:18:22 --> Router Class Initialized
INFO - 2022-03-23 14:18:22 --> Output Class Initialized
INFO - 2022-03-23 14:18:22 --> Security Class Initialized
DEBUG - 2022-03-23 14:18:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 14:18:22 --> Input Class Initialized
INFO - 2022-03-23 14:18:22 --> Language Class Initialized
INFO - 2022-03-23 14:18:22 --> Loader Class Initialized
INFO - 2022-03-23 14:18:22 --> Helper loaded: url_helper
INFO - 2022-03-23 14:18:22 --> Helper loaded: form_helper
INFO - 2022-03-23 14:18:22 --> Helper loaded: common_helper
INFO - 2022-03-23 14:18:22 --> Database Driver Class Initialized
DEBUG - 2022-03-23 14:18:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 14:18:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 14:18:22 --> Controller Class Initialized
INFO - 2022-03-23 14:18:22 --> Form Validation Class Initialized
DEBUG - 2022-03-23 14:18:22 --> Encrypt Class Initialized
DEBUG - 2022-03-23 14:18:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 14:18:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-23 14:18:22 --> Email Class Initialized
INFO - 2022-03-23 14:18:22 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-23 14:18:22 --> Calendar Class Initialized
INFO - 2022-03-23 14:18:22 --> Model "Login_model" initialized
INFO - 2022-03-23 14:18:22 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-23 14:18:22 --> Final output sent to browser
DEBUG - 2022-03-23 14:18:22 --> Total execution time: 0.1836
ERROR - 2022-03-23 14:18:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 14:18:22 --> Config Class Initialized
INFO - 2022-03-23 14:18:22 --> Hooks Class Initialized
DEBUG - 2022-03-23 14:18:22 --> UTF-8 Support Enabled
INFO - 2022-03-23 14:18:22 --> Utf8 Class Initialized
INFO - 2022-03-23 14:18:22 --> URI Class Initialized
INFO - 2022-03-23 14:18:22 --> Router Class Initialized
INFO - 2022-03-23 14:18:22 --> Output Class Initialized
INFO - 2022-03-23 14:18:22 --> Security Class Initialized
DEBUG - 2022-03-23 14:18:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 14:18:22 --> Input Class Initialized
INFO - 2022-03-23 14:18:22 --> Language Class Initialized
ERROR - 2022-03-23 14:18:22 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2022-03-23 14:18:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 14:18:42 --> Config Class Initialized
INFO - 2022-03-23 14:18:42 --> Hooks Class Initialized
DEBUG - 2022-03-23 14:18:42 --> UTF-8 Support Enabled
INFO - 2022-03-23 14:18:42 --> Utf8 Class Initialized
INFO - 2022-03-23 14:18:42 --> URI Class Initialized
DEBUG - 2022-03-23 14:18:42 --> No URI present. Default controller set.
INFO - 2022-03-23 14:18:42 --> Router Class Initialized
INFO - 2022-03-23 14:18:42 --> Output Class Initialized
INFO - 2022-03-23 14:18:42 --> Security Class Initialized
DEBUG - 2022-03-23 14:18:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 14:18:42 --> Input Class Initialized
INFO - 2022-03-23 14:18:42 --> Language Class Initialized
INFO - 2022-03-23 14:18:42 --> Loader Class Initialized
INFO - 2022-03-23 14:18:42 --> Helper loaded: url_helper
INFO - 2022-03-23 14:18:42 --> Helper loaded: form_helper
INFO - 2022-03-23 14:18:42 --> Helper loaded: common_helper
INFO - 2022-03-23 14:18:42 --> Database Driver Class Initialized
DEBUG - 2022-03-23 14:18:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 14:18:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 14:18:42 --> Controller Class Initialized
INFO - 2022-03-23 14:18:42 --> Form Validation Class Initialized
DEBUG - 2022-03-23 14:18:42 --> Encrypt Class Initialized
DEBUG - 2022-03-23 14:18:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 14:18:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-23 14:18:42 --> Email Class Initialized
INFO - 2022-03-23 14:18:42 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-23 14:18:42 --> Calendar Class Initialized
INFO - 2022-03-23 14:18:42 --> Model "Login_model" initialized
INFO - 2022-03-23 14:18:42 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-23 14:18:42 --> Final output sent to browser
DEBUG - 2022-03-23 14:18:42 --> Total execution time: 0.0075
ERROR - 2022-03-23 14:18:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 14:18:42 --> Config Class Initialized
INFO - 2022-03-23 14:18:42 --> Hooks Class Initialized
DEBUG - 2022-03-23 14:18:42 --> UTF-8 Support Enabled
INFO - 2022-03-23 14:18:42 --> Utf8 Class Initialized
INFO - 2022-03-23 14:18:42 --> URI Class Initialized
INFO - 2022-03-23 14:18:42 --> Router Class Initialized
INFO - 2022-03-23 14:18:42 --> Output Class Initialized
INFO - 2022-03-23 14:18:42 --> Security Class Initialized
DEBUG - 2022-03-23 14:18:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 14:18:42 --> Input Class Initialized
INFO - 2022-03-23 14:18:42 --> Language Class Initialized
INFO - 2022-03-23 14:18:42 --> Loader Class Initialized
INFO - 2022-03-23 14:18:42 --> Helper loaded: url_helper
INFO - 2022-03-23 14:18:42 --> Helper loaded: form_helper
INFO - 2022-03-23 14:18:42 --> Helper loaded: common_helper
INFO - 2022-03-23 14:18:42 --> Database Driver Class Initialized
DEBUG - 2022-03-23 14:18:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 14:18:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 14:18:42 --> Controller Class Initialized
INFO - 2022-03-23 14:18:42 --> Form Validation Class Initialized
DEBUG - 2022-03-23 14:18:42 --> Encrypt Class Initialized
DEBUG - 2022-03-23 14:18:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 14:18:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-23 14:18:42 --> Email Class Initialized
INFO - 2022-03-23 14:18:42 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-23 14:18:42 --> Calendar Class Initialized
INFO - 2022-03-23 14:18:42 --> Model "Login_model" initialized
INFO - 2022-03-23 14:18:42 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-23 14:18:42 --> Final output sent to browser
DEBUG - 2022-03-23 14:18:42 --> Total execution time: 0.0053
ERROR - 2022-03-23 14:18:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 14:18:42 --> Config Class Initialized
INFO - 2022-03-23 14:18:42 --> Hooks Class Initialized
DEBUG - 2022-03-23 14:18:42 --> UTF-8 Support Enabled
INFO - 2022-03-23 14:18:42 --> Utf8 Class Initialized
INFO - 2022-03-23 14:18:42 --> URI Class Initialized
INFO - 2022-03-23 14:18:42 --> Router Class Initialized
INFO - 2022-03-23 14:18:42 --> Output Class Initialized
INFO - 2022-03-23 14:18:42 --> Security Class Initialized
DEBUG - 2022-03-23 14:18:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 14:18:42 --> Input Class Initialized
INFO - 2022-03-23 14:18:42 --> Language Class Initialized
INFO - 2022-03-23 14:18:42 --> Loader Class Initialized
INFO - 2022-03-23 14:18:42 --> Helper loaded: url_helper
INFO - 2022-03-23 14:18:42 --> Helper loaded: form_helper
INFO - 2022-03-23 14:18:42 --> Helper loaded: common_helper
INFO - 2022-03-23 14:18:42 --> Database Driver Class Initialized
DEBUG - 2022-03-23 14:18:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 14:18:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 14:18:42 --> Controller Class Initialized
INFO - 2022-03-23 14:18:42 --> Form Validation Class Initialized
DEBUG - 2022-03-23 14:18:42 --> Encrypt Class Initialized
DEBUG - 2022-03-23 14:18:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 14:18:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-23 14:18:42 --> Email Class Initialized
INFO - 2022-03-23 14:18:42 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-23 14:18:42 --> Calendar Class Initialized
INFO - 2022-03-23 14:18:42 --> Model "Login_model" initialized
ERROR - 2022-03-23 14:18:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 14:18:43 --> Config Class Initialized
INFO - 2022-03-23 14:18:43 --> Hooks Class Initialized
DEBUG - 2022-03-23 14:18:43 --> UTF-8 Support Enabled
INFO - 2022-03-23 14:18:43 --> Utf8 Class Initialized
INFO - 2022-03-23 14:18:43 --> URI Class Initialized
INFO - 2022-03-23 14:18:43 --> Router Class Initialized
INFO - 2022-03-23 14:18:43 --> Output Class Initialized
INFO - 2022-03-23 14:18:43 --> Security Class Initialized
DEBUG - 2022-03-23 14:18:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 14:18:43 --> Input Class Initialized
INFO - 2022-03-23 14:18:43 --> Language Class Initialized
INFO - 2022-03-23 14:18:43 --> Loader Class Initialized
INFO - 2022-03-23 14:18:43 --> Helper loaded: url_helper
INFO - 2022-03-23 14:18:43 --> Helper loaded: form_helper
INFO - 2022-03-23 14:18:43 --> Helper loaded: common_helper
INFO - 2022-03-23 14:18:43 --> Database Driver Class Initialized
DEBUG - 2022-03-23 14:18:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 14:18:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 14:18:43 --> Controller Class Initialized
INFO - 2022-03-23 14:18:43 --> Form Validation Class Initialized
DEBUG - 2022-03-23 14:18:43 --> Encrypt Class Initialized
DEBUG - 2022-03-23 14:18:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 14:18:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-23 14:18:43 --> Email Class Initialized
INFO - 2022-03-23 14:18:43 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-23 14:18:43 --> Calendar Class Initialized
INFO - 2022-03-23 14:18:43 --> Model "Login_model" initialized
ERROR - 2022-03-23 16:13:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 16:13:36 --> Config Class Initialized
INFO - 2022-03-23 16:13:36 --> Hooks Class Initialized
DEBUG - 2022-03-23 16:13:36 --> UTF-8 Support Enabled
INFO - 2022-03-23 16:13:36 --> Utf8 Class Initialized
INFO - 2022-03-23 16:13:36 --> URI Class Initialized
DEBUG - 2022-03-23 16:13:36 --> No URI present. Default controller set.
INFO - 2022-03-23 16:13:36 --> Router Class Initialized
INFO - 2022-03-23 16:13:36 --> Output Class Initialized
INFO - 2022-03-23 16:13:36 --> Security Class Initialized
DEBUG - 2022-03-23 16:13:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 16:13:36 --> Input Class Initialized
INFO - 2022-03-23 16:13:36 --> Language Class Initialized
INFO - 2022-03-23 16:13:36 --> Loader Class Initialized
INFO - 2022-03-23 16:13:36 --> Helper loaded: url_helper
INFO - 2022-03-23 16:13:36 --> Helper loaded: form_helper
INFO - 2022-03-23 16:13:36 --> Helper loaded: common_helper
INFO - 2022-03-23 16:13:36 --> Database Driver Class Initialized
DEBUG - 2022-03-23 16:13:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 16:13:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 16:13:36 --> Controller Class Initialized
INFO - 2022-03-23 16:13:36 --> Form Validation Class Initialized
DEBUG - 2022-03-23 16:13:36 --> Encrypt Class Initialized
DEBUG - 2022-03-23 16:13:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 16:13:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-23 16:13:36 --> Email Class Initialized
INFO - 2022-03-23 16:13:36 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-23 16:13:36 --> Calendar Class Initialized
INFO - 2022-03-23 16:13:36 --> Model "Login_model" initialized
INFO - 2022-03-23 16:13:36 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-23 16:13:36 --> Final output sent to browser
DEBUG - 2022-03-23 16:13:36 --> Total execution time: 0.0640
ERROR - 2022-03-23 17:26:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 17:26:09 --> Config Class Initialized
INFO - 2022-03-23 17:26:09 --> Hooks Class Initialized
DEBUG - 2022-03-23 17:26:09 --> UTF-8 Support Enabled
INFO - 2022-03-23 17:26:09 --> Utf8 Class Initialized
INFO - 2022-03-23 17:26:09 --> URI Class Initialized
DEBUG - 2022-03-23 17:26:09 --> No URI present. Default controller set.
INFO - 2022-03-23 17:26:09 --> Router Class Initialized
INFO - 2022-03-23 17:26:09 --> Output Class Initialized
INFO - 2022-03-23 17:26:09 --> Security Class Initialized
DEBUG - 2022-03-23 17:26:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 17:26:09 --> Input Class Initialized
INFO - 2022-03-23 17:26:09 --> Language Class Initialized
INFO - 2022-03-23 17:26:09 --> Loader Class Initialized
INFO - 2022-03-23 17:26:09 --> Helper loaded: url_helper
INFO - 2022-03-23 17:26:09 --> Helper loaded: form_helper
INFO - 2022-03-23 17:26:09 --> Helper loaded: common_helper
INFO - 2022-03-23 17:26:09 --> Database Driver Class Initialized
DEBUG - 2022-03-23 17:26:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 17:26:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 17:26:09 --> Controller Class Initialized
INFO - 2022-03-23 17:26:09 --> Form Validation Class Initialized
DEBUG - 2022-03-23 17:26:09 --> Encrypt Class Initialized
DEBUG - 2022-03-23 17:26:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 17:26:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-23 17:26:09 --> Email Class Initialized
INFO - 2022-03-23 17:26:09 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-23 17:26:09 --> Calendar Class Initialized
INFO - 2022-03-23 17:26:09 --> Model "Login_model" initialized
INFO - 2022-03-23 17:26:09 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-23 17:26:09 --> Final output sent to browser
DEBUG - 2022-03-23 17:26:09 --> Total execution time: 0.0655
ERROR - 2022-03-23 17:26:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 17:26:09 --> Config Class Initialized
INFO - 2022-03-23 17:26:09 --> Hooks Class Initialized
DEBUG - 2022-03-23 17:26:09 --> UTF-8 Support Enabled
INFO - 2022-03-23 17:26:09 --> Utf8 Class Initialized
INFO - 2022-03-23 17:26:09 --> URI Class Initialized
DEBUG - 2022-03-23 17:26:09 --> No URI present. Default controller set.
INFO - 2022-03-23 17:26:09 --> Router Class Initialized
INFO - 2022-03-23 17:26:09 --> Output Class Initialized
INFO - 2022-03-23 17:26:09 --> Security Class Initialized
DEBUG - 2022-03-23 17:26:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 17:26:09 --> Input Class Initialized
INFO - 2022-03-23 17:26:09 --> Language Class Initialized
INFO - 2022-03-23 17:26:09 --> Loader Class Initialized
INFO - 2022-03-23 17:26:09 --> Helper loaded: url_helper
INFO - 2022-03-23 17:26:09 --> Helper loaded: form_helper
INFO - 2022-03-23 17:26:09 --> Helper loaded: common_helper
INFO - 2022-03-23 17:26:09 --> Database Driver Class Initialized
DEBUG - 2022-03-23 17:26:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 17:26:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 17:26:09 --> Controller Class Initialized
INFO - 2022-03-23 17:26:09 --> Form Validation Class Initialized
DEBUG - 2022-03-23 17:26:09 --> Encrypt Class Initialized
DEBUG - 2022-03-23 17:26:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 17:26:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-23 17:26:09 --> Email Class Initialized
INFO - 2022-03-23 17:26:09 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-23 17:26:09 --> Calendar Class Initialized
INFO - 2022-03-23 17:26:09 --> Model "Login_model" initialized
INFO - 2022-03-23 17:26:09 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-23 17:26:09 --> Final output sent to browser
DEBUG - 2022-03-23 17:26:09 --> Total execution time: 0.0071
ERROR - 2022-03-23 17:26:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 17:26:10 --> Config Class Initialized
INFO - 2022-03-23 17:26:10 --> Hooks Class Initialized
DEBUG - 2022-03-23 17:26:10 --> UTF-8 Support Enabled
INFO - 2022-03-23 17:26:10 --> Utf8 Class Initialized
INFO - 2022-03-23 17:26:10 --> URI Class Initialized
INFO - 2022-03-23 17:26:10 --> Router Class Initialized
INFO - 2022-03-23 17:26:10 --> Output Class Initialized
INFO - 2022-03-23 17:26:10 --> Security Class Initialized
DEBUG - 2022-03-23 17:26:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 17:26:10 --> Input Class Initialized
INFO - 2022-03-23 17:26:10 --> Language Class Initialized
ERROR - 2022-03-23 17:26:10 --> 404 Page Not Found: Blog/wp-includes
ERROR - 2022-03-23 17:26:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 17:26:10 --> Config Class Initialized
INFO - 2022-03-23 17:26:10 --> Hooks Class Initialized
DEBUG - 2022-03-23 17:26:10 --> UTF-8 Support Enabled
INFO - 2022-03-23 17:26:10 --> Utf8 Class Initialized
INFO - 2022-03-23 17:26:10 --> URI Class Initialized
INFO - 2022-03-23 17:26:10 --> Router Class Initialized
INFO - 2022-03-23 17:26:10 --> Output Class Initialized
INFO - 2022-03-23 17:26:10 --> Security Class Initialized
DEBUG - 2022-03-23 17:26:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 17:26:10 --> Input Class Initialized
INFO - 2022-03-23 17:26:10 --> Language Class Initialized
ERROR - 2022-03-23 17:26:10 --> 404 Page Not Found: Web/wp-includes
ERROR - 2022-03-23 17:26:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 17:26:11 --> Config Class Initialized
INFO - 2022-03-23 17:26:11 --> Hooks Class Initialized
DEBUG - 2022-03-23 17:26:11 --> UTF-8 Support Enabled
INFO - 2022-03-23 17:26:11 --> Utf8 Class Initialized
INFO - 2022-03-23 17:26:11 --> URI Class Initialized
INFO - 2022-03-23 17:26:11 --> Router Class Initialized
INFO - 2022-03-23 17:26:11 --> Output Class Initialized
INFO - 2022-03-23 17:26:11 --> Security Class Initialized
DEBUG - 2022-03-23 17:26:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 17:26:11 --> Input Class Initialized
INFO - 2022-03-23 17:26:11 --> Language Class Initialized
ERROR - 2022-03-23 17:26:11 --> 404 Page Not Found: Wordpress/wp-includes
ERROR - 2022-03-23 17:26:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 17:26:11 --> Config Class Initialized
INFO - 2022-03-23 17:26:11 --> Hooks Class Initialized
DEBUG - 2022-03-23 17:26:11 --> UTF-8 Support Enabled
INFO - 2022-03-23 17:26:11 --> Utf8 Class Initialized
INFO - 2022-03-23 17:26:11 --> URI Class Initialized
INFO - 2022-03-23 17:26:11 --> Router Class Initialized
INFO - 2022-03-23 17:26:11 --> Output Class Initialized
INFO - 2022-03-23 17:26:11 --> Security Class Initialized
DEBUG - 2022-03-23 17:26:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 17:26:11 --> Input Class Initialized
INFO - 2022-03-23 17:26:11 --> Language Class Initialized
ERROR - 2022-03-23 17:26:11 --> 404 Page Not Found: Website/wp-includes
ERROR - 2022-03-23 17:26:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 17:26:11 --> Config Class Initialized
INFO - 2022-03-23 17:26:11 --> Hooks Class Initialized
DEBUG - 2022-03-23 17:26:11 --> UTF-8 Support Enabled
INFO - 2022-03-23 17:26:11 --> Utf8 Class Initialized
INFO - 2022-03-23 17:26:11 --> URI Class Initialized
INFO - 2022-03-23 17:26:11 --> Router Class Initialized
INFO - 2022-03-23 17:26:11 --> Output Class Initialized
INFO - 2022-03-23 17:26:11 --> Security Class Initialized
DEBUG - 2022-03-23 17:26:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 17:26:11 --> Input Class Initialized
INFO - 2022-03-23 17:26:11 --> Language Class Initialized
ERROR - 2022-03-23 17:26:11 --> 404 Page Not Found: Wp/wp-includes
ERROR - 2022-03-23 17:26:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 17:26:11 --> Config Class Initialized
INFO - 2022-03-23 17:26:11 --> Hooks Class Initialized
DEBUG - 2022-03-23 17:26:11 --> UTF-8 Support Enabled
INFO - 2022-03-23 17:26:11 --> Utf8 Class Initialized
INFO - 2022-03-23 17:26:11 --> URI Class Initialized
INFO - 2022-03-23 17:26:11 --> Router Class Initialized
INFO - 2022-03-23 17:26:11 --> Output Class Initialized
INFO - 2022-03-23 17:26:11 --> Security Class Initialized
DEBUG - 2022-03-23 17:26:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 17:26:11 --> Input Class Initialized
INFO - 2022-03-23 17:26:11 --> Language Class Initialized
ERROR - 2022-03-23 17:26:11 --> 404 Page Not Found: News/wp-includes
ERROR - 2022-03-23 17:26:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 17:26:12 --> Config Class Initialized
INFO - 2022-03-23 17:26:12 --> Hooks Class Initialized
DEBUG - 2022-03-23 17:26:12 --> UTF-8 Support Enabled
INFO - 2022-03-23 17:26:12 --> Utf8 Class Initialized
INFO - 2022-03-23 17:26:12 --> URI Class Initialized
INFO - 2022-03-23 17:26:12 --> Router Class Initialized
INFO - 2022-03-23 17:26:12 --> Output Class Initialized
INFO - 2022-03-23 17:26:12 --> Security Class Initialized
DEBUG - 2022-03-23 17:26:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 17:26:12 --> Input Class Initialized
INFO - 2022-03-23 17:26:12 --> Language Class Initialized
ERROR - 2022-03-23 17:26:12 --> 404 Page Not Found: 2020/wp-includes
ERROR - 2022-03-23 17:26:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 17:26:12 --> Config Class Initialized
INFO - 2022-03-23 17:26:12 --> Hooks Class Initialized
DEBUG - 2022-03-23 17:26:12 --> UTF-8 Support Enabled
INFO - 2022-03-23 17:26:12 --> Utf8 Class Initialized
INFO - 2022-03-23 17:26:12 --> URI Class Initialized
INFO - 2022-03-23 17:26:12 --> Router Class Initialized
INFO - 2022-03-23 17:26:12 --> Output Class Initialized
INFO - 2022-03-23 17:26:12 --> Security Class Initialized
DEBUG - 2022-03-23 17:26:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 17:26:12 --> Input Class Initialized
INFO - 2022-03-23 17:26:12 --> Language Class Initialized
ERROR - 2022-03-23 17:26:12 --> 404 Page Not Found: 2019/wp-includes
ERROR - 2022-03-23 17:26:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 17:26:12 --> Config Class Initialized
INFO - 2022-03-23 17:26:12 --> Hooks Class Initialized
DEBUG - 2022-03-23 17:26:12 --> UTF-8 Support Enabled
INFO - 2022-03-23 17:26:12 --> Utf8 Class Initialized
INFO - 2022-03-23 17:26:12 --> URI Class Initialized
INFO - 2022-03-23 17:26:12 --> Router Class Initialized
INFO - 2022-03-23 17:26:12 --> Output Class Initialized
INFO - 2022-03-23 17:26:12 --> Security Class Initialized
DEBUG - 2022-03-23 17:26:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 17:26:12 --> Input Class Initialized
INFO - 2022-03-23 17:26:12 --> Language Class Initialized
ERROR - 2022-03-23 17:26:12 --> 404 Page Not Found: Shop/wp-includes
ERROR - 2022-03-23 17:26:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 17:26:12 --> Config Class Initialized
INFO - 2022-03-23 17:26:12 --> Hooks Class Initialized
DEBUG - 2022-03-23 17:26:12 --> UTF-8 Support Enabled
INFO - 2022-03-23 17:26:12 --> Utf8 Class Initialized
INFO - 2022-03-23 17:26:12 --> URI Class Initialized
INFO - 2022-03-23 17:26:12 --> Router Class Initialized
INFO - 2022-03-23 17:26:12 --> Output Class Initialized
INFO - 2022-03-23 17:26:12 --> Security Class Initialized
DEBUG - 2022-03-23 17:26:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 17:26:12 --> Input Class Initialized
INFO - 2022-03-23 17:26:12 --> Language Class Initialized
ERROR - 2022-03-23 17:26:12 --> 404 Page Not Found: Wp1/wp-includes
ERROR - 2022-03-23 17:26:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 17:26:12 --> Config Class Initialized
INFO - 2022-03-23 17:26:12 --> Hooks Class Initialized
DEBUG - 2022-03-23 17:26:12 --> UTF-8 Support Enabled
INFO - 2022-03-23 17:26:12 --> Utf8 Class Initialized
INFO - 2022-03-23 17:26:12 --> URI Class Initialized
INFO - 2022-03-23 17:26:12 --> Router Class Initialized
INFO - 2022-03-23 17:26:12 --> Output Class Initialized
INFO - 2022-03-23 17:26:12 --> Security Class Initialized
DEBUG - 2022-03-23 17:26:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 17:26:12 --> Input Class Initialized
INFO - 2022-03-23 17:26:12 --> Language Class Initialized
ERROR - 2022-03-23 17:26:12 --> 404 Page Not Found: Test/wp-includes
ERROR - 2022-03-23 17:26:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 17:26:13 --> Config Class Initialized
INFO - 2022-03-23 17:26:13 --> Hooks Class Initialized
DEBUG - 2022-03-23 17:26:13 --> UTF-8 Support Enabled
INFO - 2022-03-23 17:26:13 --> Utf8 Class Initialized
INFO - 2022-03-23 17:26:13 --> URI Class Initialized
INFO - 2022-03-23 17:26:13 --> Router Class Initialized
INFO - 2022-03-23 17:26:13 --> Output Class Initialized
INFO - 2022-03-23 17:26:13 --> Security Class Initialized
DEBUG - 2022-03-23 17:26:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 17:26:13 --> Input Class Initialized
INFO - 2022-03-23 17:26:13 --> Language Class Initialized
ERROR - 2022-03-23 17:26:13 --> 404 Page Not Found: Wp2/wp-includes
ERROR - 2022-03-23 17:26:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 17:26:13 --> Config Class Initialized
INFO - 2022-03-23 17:26:13 --> Hooks Class Initialized
DEBUG - 2022-03-23 17:26:13 --> UTF-8 Support Enabled
INFO - 2022-03-23 17:26:13 --> Utf8 Class Initialized
INFO - 2022-03-23 17:26:13 --> URI Class Initialized
INFO - 2022-03-23 17:26:13 --> Router Class Initialized
INFO - 2022-03-23 17:26:13 --> Output Class Initialized
INFO - 2022-03-23 17:26:13 --> Security Class Initialized
DEBUG - 2022-03-23 17:26:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 17:26:13 --> Input Class Initialized
INFO - 2022-03-23 17:26:13 --> Language Class Initialized
ERROR - 2022-03-23 17:26:13 --> 404 Page Not Found: Site/wp-includes
ERROR - 2022-03-23 17:26:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 17:26:13 --> Config Class Initialized
INFO - 2022-03-23 17:26:13 --> Hooks Class Initialized
DEBUG - 2022-03-23 17:26:13 --> UTF-8 Support Enabled
INFO - 2022-03-23 17:26:13 --> Utf8 Class Initialized
INFO - 2022-03-23 17:26:13 --> URI Class Initialized
INFO - 2022-03-23 17:26:13 --> Router Class Initialized
INFO - 2022-03-23 17:26:13 --> Output Class Initialized
INFO - 2022-03-23 17:26:13 --> Security Class Initialized
DEBUG - 2022-03-23 17:26:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 17:26:13 --> Input Class Initialized
INFO - 2022-03-23 17:26:13 --> Language Class Initialized
ERROR - 2022-03-23 17:26:13 --> 404 Page Not Found: Cms/wp-includes
ERROR - 2022-03-23 17:26:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 17:26:13 --> Config Class Initialized
INFO - 2022-03-23 17:26:13 --> Hooks Class Initialized
DEBUG - 2022-03-23 17:26:13 --> UTF-8 Support Enabled
INFO - 2022-03-23 17:26:13 --> Utf8 Class Initialized
INFO - 2022-03-23 17:26:13 --> URI Class Initialized
INFO - 2022-03-23 17:26:13 --> Router Class Initialized
INFO - 2022-03-23 17:26:13 --> Output Class Initialized
INFO - 2022-03-23 17:26:13 --> Security Class Initialized
DEBUG - 2022-03-23 17:26:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 17:26:13 --> Input Class Initialized
INFO - 2022-03-23 17:26:13 --> Language Class Initialized
ERROR - 2022-03-23 17:26:13 --> 404 Page Not Found: Sito/wp-includes
ERROR - 2022-03-23 17:34:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 17:34:01 --> Config Class Initialized
INFO - 2022-03-23 17:34:01 --> Hooks Class Initialized
DEBUG - 2022-03-23 17:34:01 --> UTF-8 Support Enabled
INFO - 2022-03-23 17:34:01 --> Utf8 Class Initialized
INFO - 2022-03-23 17:34:01 --> URI Class Initialized
DEBUG - 2022-03-23 17:34:01 --> No URI present. Default controller set.
INFO - 2022-03-23 17:34:01 --> Router Class Initialized
INFO - 2022-03-23 17:34:01 --> Output Class Initialized
INFO - 2022-03-23 17:34:01 --> Security Class Initialized
DEBUG - 2022-03-23 17:34:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 17:34:01 --> Input Class Initialized
INFO - 2022-03-23 17:34:01 --> Language Class Initialized
INFO - 2022-03-23 17:34:01 --> Loader Class Initialized
INFO - 2022-03-23 17:34:01 --> Helper loaded: url_helper
INFO - 2022-03-23 17:34:01 --> Helper loaded: form_helper
INFO - 2022-03-23 17:34:01 --> Helper loaded: common_helper
INFO - 2022-03-23 17:34:01 --> Database Driver Class Initialized
DEBUG - 2022-03-23 17:34:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 17:34:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 17:34:01 --> Controller Class Initialized
INFO - 2022-03-23 17:34:01 --> Form Validation Class Initialized
DEBUG - 2022-03-23 17:34:01 --> Encrypt Class Initialized
DEBUG - 2022-03-23 17:34:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 17:34:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-23 17:34:01 --> Email Class Initialized
INFO - 2022-03-23 17:34:01 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-23 17:34:01 --> Calendar Class Initialized
INFO - 2022-03-23 17:34:01 --> Model "Login_model" initialized
INFO - 2022-03-23 17:34:01 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-23 17:34:01 --> Final output sent to browser
DEBUG - 2022-03-23 17:34:01 --> Total execution time: 0.0556
ERROR - 2022-03-23 20:48:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 20:48:41 --> Config Class Initialized
INFO - 2022-03-23 20:48:41 --> Hooks Class Initialized
DEBUG - 2022-03-23 20:48:41 --> UTF-8 Support Enabled
INFO - 2022-03-23 20:48:41 --> Utf8 Class Initialized
INFO - 2022-03-23 20:48:41 --> URI Class Initialized
DEBUG - 2022-03-23 20:48:41 --> No URI present. Default controller set.
INFO - 2022-03-23 20:48:41 --> Router Class Initialized
INFO - 2022-03-23 20:48:41 --> Output Class Initialized
INFO - 2022-03-23 20:48:41 --> Security Class Initialized
DEBUG - 2022-03-23 20:48:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 20:48:41 --> Input Class Initialized
INFO - 2022-03-23 20:48:41 --> Language Class Initialized
INFO - 2022-03-23 20:48:41 --> Loader Class Initialized
INFO - 2022-03-23 20:48:41 --> Helper loaded: url_helper
INFO - 2022-03-23 20:48:41 --> Helper loaded: form_helper
INFO - 2022-03-23 20:48:41 --> Helper loaded: common_helper
INFO - 2022-03-23 20:48:41 --> Database Driver Class Initialized
DEBUG - 2022-03-23 20:48:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 20:48:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 20:48:41 --> Controller Class Initialized
INFO - 2022-03-23 20:48:41 --> Form Validation Class Initialized
DEBUG - 2022-03-23 20:48:41 --> Encrypt Class Initialized
DEBUG - 2022-03-23 20:48:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 20:48:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-23 20:48:41 --> Email Class Initialized
INFO - 2022-03-23 20:48:41 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-23 20:48:41 --> Calendar Class Initialized
INFO - 2022-03-23 20:48:41 --> Model "Login_model" initialized
INFO - 2022-03-23 20:48:41 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-23 20:48:41 --> Final output sent to browser
DEBUG - 2022-03-23 20:48:41 --> Total execution time: 0.0685
ERROR - 2022-03-23 20:54:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 20:54:42 --> Config Class Initialized
INFO - 2022-03-23 20:54:42 --> Hooks Class Initialized
DEBUG - 2022-03-23 20:54:42 --> UTF-8 Support Enabled
INFO - 2022-03-23 20:54:42 --> Utf8 Class Initialized
INFO - 2022-03-23 20:54:42 --> URI Class Initialized
DEBUG - 2022-03-23 20:54:42 --> No URI present. Default controller set.
INFO - 2022-03-23 20:54:42 --> Router Class Initialized
INFO - 2022-03-23 20:54:42 --> Output Class Initialized
INFO - 2022-03-23 20:54:42 --> Security Class Initialized
DEBUG - 2022-03-23 20:54:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 20:54:42 --> Input Class Initialized
INFO - 2022-03-23 20:54:42 --> Language Class Initialized
INFO - 2022-03-23 20:54:42 --> Loader Class Initialized
INFO - 2022-03-23 20:54:42 --> Helper loaded: url_helper
INFO - 2022-03-23 20:54:42 --> Helper loaded: form_helper
INFO - 2022-03-23 20:54:42 --> Helper loaded: common_helper
INFO - 2022-03-23 20:54:42 --> Database Driver Class Initialized
DEBUG - 2022-03-23 20:54:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 20:54:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 20:54:42 --> Controller Class Initialized
INFO - 2022-03-23 20:54:42 --> Form Validation Class Initialized
DEBUG - 2022-03-23 20:54:42 --> Encrypt Class Initialized
DEBUG - 2022-03-23 20:54:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 20:54:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-23 20:54:42 --> Email Class Initialized
INFO - 2022-03-23 20:54:42 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-23 20:54:42 --> Calendar Class Initialized
INFO - 2022-03-23 20:54:42 --> Model "Login_model" initialized
INFO - 2022-03-23 20:54:42 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-23 20:54:42 --> Final output sent to browser
DEBUG - 2022-03-23 20:54:42 --> Total execution time: 0.1676
ERROR - 2022-03-23 20:54:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 20:54:42 --> Config Class Initialized
INFO - 2022-03-23 20:54:42 --> Hooks Class Initialized
DEBUG - 2022-03-23 20:54:42 --> UTF-8 Support Enabled
INFO - 2022-03-23 20:54:42 --> Utf8 Class Initialized
INFO - 2022-03-23 20:54:42 --> URI Class Initialized
DEBUG - 2022-03-23 20:54:42 --> No URI present. Default controller set.
INFO - 2022-03-23 20:54:42 --> Router Class Initialized
INFO - 2022-03-23 20:54:42 --> Output Class Initialized
INFO - 2022-03-23 20:54:42 --> Security Class Initialized
DEBUG - 2022-03-23 20:54:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 20:54:42 --> Input Class Initialized
INFO - 2022-03-23 20:54:42 --> Language Class Initialized
INFO - 2022-03-23 20:54:42 --> Loader Class Initialized
INFO - 2022-03-23 20:54:42 --> Helper loaded: url_helper
INFO - 2022-03-23 20:54:42 --> Helper loaded: form_helper
INFO - 2022-03-23 20:54:42 --> Helper loaded: common_helper
INFO - 2022-03-23 20:54:42 --> Database Driver Class Initialized
DEBUG - 2022-03-23 20:54:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-23 20:54:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-23 20:54:42 --> Controller Class Initialized
INFO - 2022-03-23 20:54:42 --> Form Validation Class Initialized
DEBUG - 2022-03-23 20:54:42 --> Encrypt Class Initialized
DEBUG - 2022-03-23 20:54:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 20:54:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-23 20:54:42 --> Email Class Initialized
INFO - 2022-03-23 20:54:42 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-23 20:54:42 --> Calendar Class Initialized
INFO - 2022-03-23 20:54:42 --> Model "Login_model" initialized
INFO - 2022-03-23 20:54:42 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-23 20:54:42 --> Final output sent to browser
DEBUG - 2022-03-23 20:54:42 --> Total execution time: 0.0081
ERROR - 2022-03-23 20:54:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 20:54:43 --> Config Class Initialized
INFO - 2022-03-23 20:54:43 --> Hooks Class Initialized
DEBUG - 2022-03-23 20:54:43 --> UTF-8 Support Enabled
INFO - 2022-03-23 20:54:43 --> Utf8 Class Initialized
INFO - 2022-03-23 20:54:43 --> URI Class Initialized
INFO - 2022-03-23 20:54:43 --> Router Class Initialized
INFO - 2022-03-23 20:54:43 --> Output Class Initialized
INFO - 2022-03-23 20:54:43 --> Security Class Initialized
DEBUG - 2022-03-23 20:54:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 20:54:43 --> Input Class Initialized
INFO - 2022-03-23 20:54:43 --> Language Class Initialized
ERROR - 2022-03-23 20:54:43 --> 404 Page Not Found: Blog/wp-includes
ERROR - 2022-03-23 20:54:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 20:54:44 --> Config Class Initialized
INFO - 2022-03-23 20:54:44 --> Hooks Class Initialized
DEBUG - 2022-03-23 20:54:44 --> UTF-8 Support Enabled
INFO - 2022-03-23 20:54:44 --> Utf8 Class Initialized
INFO - 2022-03-23 20:54:44 --> URI Class Initialized
INFO - 2022-03-23 20:54:44 --> Router Class Initialized
INFO - 2022-03-23 20:54:44 --> Output Class Initialized
INFO - 2022-03-23 20:54:44 --> Security Class Initialized
DEBUG - 2022-03-23 20:54:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 20:54:44 --> Input Class Initialized
INFO - 2022-03-23 20:54:44 --> Language Class Initialized
ERROR - 2022-03-23 20:54:44 --> 404 Page Not Found: Web/wp-includes
ERROR - 2022-03-23 20:54:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 20:54:44 --> Config Class Initialized
INFO - 2022-03-23 20:54:44 --> Hooks Class Initialized
DEBUG - 2022-03-23 20:54:44 --> UTF-8 Support Enabled
INFO - 2022-03-23 20:54:44 --> Utf8 Class Initialized
INFO - 2022-03-23 20:54:44 --> URI Class Initialized
INFO - 2022-03-23 20:54:44 --> Router Class Initialized
INFO - 2022-03-23 20:54:44 --> Output Class Initialized
INFO - 2022-03-23 20:54:44 --> Security Class Initialized
DEBUG - 2022-03-23 20:54:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 20:54:44 --> Input Class Initialized
INFO - 2022-03-23 20:54:44 --> Language Class Initialized
ERROR - 2022-03-23 20:54:44 --> 404 Page Not Found: Wordpress/wp-includes
ERROR - 2022-03-23 20:54:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 20:54:44 --> Config Class Initialized
INFO - 2022-03-23 20:54:44 --> Hooks Class Initialized
DEBUG - 2022-03-23 20:54:44 --> UTF-8 Support Enabled
INFO - 2022-03-23 20:54:44 --> Utf8 Class Initialized
INFO - 2022-03-23 20:54:44 --> URI Class Initialized
INFO - 2022-03-23 20:54:44 --> Router Class Initialized
INFO - 2022-03-23 20:54:44 --> Output Class Initialized
INFO - 2022-03-23 20:54:44 --> Security Class Initialized
DEBUG - 2022-03-23 20:54:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 20:54:44 --> Input Class Initialized
INFO - 2022-03-23 20:54:44 --> Language Class Initialized
ERROR - 2022-03-23 20:54:44 --> 404 Page Not Found: Website/wp-includes
ERROR - 2022-03-23 20:54:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 20:54:44 --> Config Class Initialized
INFO - 2022-03-23 20:54:44 --> Hooks Class Initialized
DEBUG - 2022-03-23 20:54:44 --> UTF-8 Support Enabled
INFO - 2022-03-23 20:54:44 --> Utf8 Class Initialized
INFO - 2022-03-23 20:54:44 --> URI Class Initialized
INFO - 2022-03-23 20:54:44 --> Router Class Initialized
INFO - 2022-03-23 20:54:44 --> Output Class Initialized
INFO - 2022-03-23 20:54:44 --> Security Class Initialized
DEBUG - 2022-03-23 20:54:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 20:54:44 --> Input Class Initialized
INFO - 2022-03-23 20:54:44 --> Language Class Initialized
ERROR - 2022-03-23 20:54:44 --> 404 Page Not Found: Wp/wp-includes
ERROR - 2022-03-23 20:54:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 20:54:44 --> Config Class Initialized
INFO - 2022-03-23 20:54:44 --> Hooks Class Initialized
DEBUG - 2022-03-23 20:54:44 --> UTF-8 Support Enabled
INFO - 2022-03-23 20:54:44 --> Utf8 Class Initialized
INFO - 2022-03-23 20:54:44 --> URI Class Initialized
INFO - 2022-03-23 20:54:44 --> Router Class Initialized
INFO - 2022-03-23 20:54:44 --> Output Class Initialized
INFO - 2022-03-23 20:54:44 --> Security Class Initialized
DEBUG - 2022-03-23 20:54:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 20:54:44 --> Input Class Initialized
INFO - 2022-03-23 20:54:44 --> Language Class Initialized
ERROR - 2022-03-23 20:54:44 --> 404 Page Not Found: News/wp-includes
ERROR - 2022-03-23 20:54:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 20:54:45 --> Config Class Initialized
INFO - 2022-03-23 20:54:45 --> Hooks Class Initialized
DEBUG - 2022-03-23 20:54:45 --> UTF-8 Support Enabled
INFO - 2022-03-23 20:54:45 --> Utf8 Class Initialized
INFO - 2022-03-23 20:54:45 --> URI Class Initialized
INFO - 2022-03-23 20:54:45 --> Router Class Initialized
INFO - 2022-03-23 20:54:45 --> Output Class Initialized
INFO - 2022-03-23 20:54:45 --> Security Class Initialized
DEBUG - 2022-03-23 20:54:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 20:54:45 --> Input Class Initialized
INFO - 2022-03-23 20:54:45 --> Language Class Initialized
ERROR - 2022-03-23 20:54:45 --> 404 Page Not Found: 2018/wp-includes
ERROR - 2022-03-23 20:54:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 20:54:45 --> Config Class Initialized
INFO - 2022-03-23 20:54:45 --> Hooks Class Initialized
DEBUG - 2022-03-23 20:54:45 --> UTF-8 Support Enabled
INFO - 2022-03-23 20:54:45 --> Utf8 Class Initialized
INFO - 2022-03-23 20:54:45 --> URI Class Initialized
INFO - 2022-03-23 20:54:45 --> Router Class Initialized
INFO - 2022-03-23 20:54:45 --> Output Class Initialized
INFO - 2022-03-23 20:54:45 --> Security Class Initialized
DEBUG - 2022-03-23 20:54:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 20:54:45 --> Input Class Initialized
INFO - 2022-03-23 20:54:45 --> Language Class Initialized
ERROR - 2022-03-23 20:54:45 --> 404 Page Not Found: 2019/wp-includes
ERROR - 2022-03-23 20:54:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 20:54:45 --> Config Class Initialized
INFO - 2022-03-23 20:54:45 --> Hooks Class Initialized
DEBUG - 2022-03-23 20:54:45 --> UTF-8 Support Enabled
INFO - 2022-03-23 20:54:45 --> Utf8 Class Initialized
INFO - 2022-03-23 20:54:45 --> URI Class Initialized
INFO - 2022-03-23 20:54:45 --> Router Class Initialized
INFO - 2022-03-23 20:54:45 --> Output Class Initialized
INFO - 2022-03-23 20:54:45 --> Security Class Initialized
DEBUG - 2022-03-23 20:54:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 20:54:45 --> Input Class Initialized
INFO - 2022-03-23 20:54:45 --> Language Class Initialized
ERROR - 2022-03-23 20:54:45 --> 404 Page Not Found: Shop/wp-includes
ERROR - 2022-03-23 20:54:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 20:54:45 --> Config Class Initialized
INFO - 2022-03-23 20:54:45 --> Hooks Class Initialized
DEBUG - 2022-03-23 20:54:45 --> UTF-8 Support Enabled
INFO - 2022-03-23 20:54:45 --> Utf8 Class Initialized
INFO - 2022-03-23 20:54:45 --> URI Class Initialized
INFO - 2022-03-23 20:54:45 --> Router Class Initialized
INFO - 2022-03-23 20:54:45 --> Output Class Initialized
INFO - 2022-03-23 20:54:45 --> Security Class Initialized
DEBUG - 2022-03-23 20:54:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 20:54:45 --> Input Class Initialized
INFO - 2022-03-23 20:54:45 --> Language Class Initialized
ERROR - 2022-03-23 20:54:45 --> 404 Page Not Found: Wp1/wp-includes
ERROR - 2022-03-23 20:54:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 20:54:46 --> Config Class Initialized
INFO - 2022-03-23 20:54:46 --> Hooks Class Initialized
DEBUG - 2022-03-23 20:54:46 --> UTF-8 Support Enabled
INFO - 2022-03-23 20:54:46 --> Utf8 Class Initialized
INFO - 2022-03-23 20:54:46 --> URI Class Initialized
INFO - 2022-03-23 20:54:46 --> Router Class Initialized
INFO - 2022-03-23 20:54:46 --> Output Class Initialized
INFO - 2022-03-23 20:54:46 --> Security Class Initialized
DEBUG - 2022-03-23 20:54:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 20:54:46 --> Input Class Initialized
INFO - 2022-03-23 20:54:46 --> Language Class Initialized
ERROR - 2022-03-23 20:54:46 --> 404 Page Not Found: Test/wp-includes
ERROR - 2022-03-23 20:54:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 20:54:46 --> Config Class Initialized
INFO - 2022-03-23 20:54:46 --> Hooks Class Initialized
DEBUG - 2022-03-23 20:54:46 --> UTF-8 Support Enabled
INFO - 2022-03-23 20:54:46 --> Utf8 Class Initialized
INFO - 2022-03-23 20:54:46 --> URI Class Initialized
INFO - 2022-03-23 20:54:46 --> Router Class Initialized
INFO - 2022-03-23 20:54:46 --> Output Class Initialized
INFO - 2022-03-23 20:54:46 --> Security Class Initialized
DEBUG - 2022-03-23 20:54:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 20:54:46 --> Input Class Initialized
INFO - 2022-03-23 20:54:46 --> Language Class Initialized
ERROR - 2022-03-23 20:54:46 --> 404 Page Not Found: Media/wp-includes
ERROR - 2022-03-23 20:54:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 20:54:46 --> Config Class Initialized
INFO - 2022-03-23 20:54:46 --> Hooks Class Initialized
DEBUG - 2022-03-23 20:54:46 --> UTF-8 Support Enabled
INFO - 2022-03-23 20:54:46 --> Utf8 Class Initialized
INFO - 2022-03-23 20:54:46 --> URI Class Initialized
INFO - 2022-03-23 20:54:46 --> Router Class Initialized
INFO - 2022-03-23 20:54:46 --> Output Class Initialized
INFO - 2022-03-23 20:54:46 --> Security Class Initialized
DEBUG - 2022-03-23 20:54:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 20:54:46 --> Input Class Initialized
INFO - 2022-03-23 20:54:46 --> Language Class Initialized
ERROR - 2022-03-23 20:54:46 --> 404 Page Not Found: Wp2/wp-includes
ERROR - 2022-03-23 20:54:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 20:54:46 --> Config Class Initialized
INFO - 2022-03-23 20:54:46 --> Hooks Class Initialized
DEBUG - 2022-03-23 20:54:46 --> UTF-8 Support Enabled
INFO - 2022-03-23 20:54:46 --> Utf8 Class Initialized
INFO - 2022-03-23 20:54:46 --> URI Class Initialized
INFO - 2022-03-23 20:54:46 --> Router Class Initialized
INFO - 2022-03-23 20:54:46 --> Output Class Initialized
INFO - 2022-03-23 20:54:46 --> Security Class Initialized
DEBUG - 2022-03-23 20:54:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 20:54:46 --> Input Class Initialized
INFO - 2022-03-23 20:54:46 --> Language Class Initialized
ERROR - 2022-03-23 20:54:46 --> 404 Page Not Found: Site/wp-includes
ERROR - 2022-03-23 20:54:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 20:54:46 --> Config Class Initialized
INFO - 2022-03-23 20:54:46 --> Hooks Class Initialized
DEBUG - 2022-03-23 20:54:46 --> UTF-8 Support Enabled
INFO - 2022-03-23 20:54:46 --> Utf8 Class Initialized
INFO - 2022-03-23 20:54:46 --> URI Class Initialized
INFO - 2022-03-23 20:54:46 --> Router Class Initialized
INFO - 2022-03-23 20:54:46 --> Output Class Initialized
INFO - 2022-03-23 20:54:46 --> Security Class Initialized
DEBUG - 2022-03-23 20:54:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 20:54:46 --> Input Class Initialized
INFO - 2022-03-23 20:54:46 --> Language Class Initialized
ERROR - 2022-03-23 20:54:46 --> 404 Page Not Found: Cms/wp-includes
ERROR - 2022-03-23 20:54:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 20:54:47 --> Config Class Initialized
INFO - 2022-03-23 20:54:47 --> Hooks Class Initialized
DEBUG - 2022-03-23 20:54:47 --> UTF-8 Support Enabled
INFO - 2022-03-23 20:54:47 --> Utf8 Class Initialized
INFO - 2022-03-23 20:54:47 --> URI Class Initialized
INFO - 2022-03-23 20:54:47 --> Router Class Initialized
INFO - 2022-03-23 20:54:47 --> Output Class Initialized
INFO - 2022-03-23 20:54:47 --> Security Class Initialized
DEBUG - 2022-03-23 20:54:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 20:54:47 --> Input Class Initialized
INFO - 2022-03-23 20:54:47 --> Language Class Initialized
ERROR - 2022-03-23 20:54:47 --> 404 Page Not Found: Sito/wp-includes
ERROR - 2022-03-23 23:44:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 23:44:52 --> Config Class Initialized
INFO - 2022-03-23 23:44:52 --> Hooks Class Initialized
DEBUG - 2022-03-23 23:44:52 --> UTF-8 Support Enabled
INFO - 2022-03-23 23:44:52 --> Utf8 Class Initialized
INFO - 2022-03-23 23:44:52 --> URI Class Initialized
INFO - 2022-03-23 23:44:52 --> Router Class Initialized
INFO - 2022-03-23 23:44:52 --> Output Class Initialized
INFO - 2022-03-23 23:44:52 --> Security Class Initialized
DEBUG - 2022-03-23 23:44:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 23:44:52 --> Input Class Initialized
INFO - 2022-03-23 23:44:52 --> Language Class Initialized
ERROR - 2022-03-23 23:44:52 --> 404 Page Not Found: DS_Store/index
ERROR - 2022-03-23 23:44:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 23:44:53 --> Config Class Initialized
INFO - 2022-03-23 23:44:53 --> Hooks Class Initialized
DEBUG - 2022-03-23 23:44:53 --> UTF-8 Support Enabled
INFO - 2022-03-23 23:44:53 --> Utf8 Class Initialized
INFO - 2022-03-23 23:44:53 --> URI Class Initialized
INFO - 2022-03-23 23:44:53 --> Router Class Initialized
INFO - 2022-03-23 23:44:53 --> Output Class Initialized
INFO - 2022-03-23 23:44:53 --> Security Class Initialized
DEBUG - 2022-03-23 23:44:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 23:44:53 --> Input Class Initialized
INFO - 2022-03-23 23:44:53 --> Language Class Initialized
ERROR - 2022-03-23 23:44:53 --> 404 Page Not Found: Git/config
ERROR - 2022-03-23 23:44:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 23:44:54 --> Config Class Initialized
INFO - 2022-03-23 23:44:54 --> Hooks Class Initialized
DEBUG - 2022-03-23 23:44:54 --> UTF-8 Support Enabled
INFO - 2022-03-23 23:44:54 --> Utf8 Class Initialized
INFO - 2022-03-23 23:44:54 --> URI Class Initialized
INFO - 2022-03-23 23:44:54 --> Router Class Initialized
INFO - 2022-03-23 23:44:54 --> Output Class Initialized
INFO - 2022-03-23 23:44:54 --> Security Class Initialized
DEBUG - 2022-03-23 23:44:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 23:44:54 --> Input Class Initialized
INFO - 2022-03-23 23:44:54 --> Language Class Initialized
ERROR - 2022-03-23 23:44:54 --> 404 Page Not Found: Git/config
ERROR - 2022-03-23 23:44:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-23 23:44:59 --> Config Class Initialized
INFO - 2022-03-23 23:44:59 --> Hooks Class Initialized
DEBUG - 2022-03-23 23:44:59 --> UTF-8 Support Enabled
INFO - 2022-03-23 23:44:59 --> Utf8 Class Initialized
INFO - 2022-03-23 23:44:59 --> URI Class Initialized
INFO - 2022-03-23 23:44:59 --> Router Class Initialized
INFO - 2022-03-23 23:44:59 --> Output Class Initialized
INFO - 2022-03-23 23:44:59 --> Security Class Initialized
DEBUG - 2022-03-23 23:44:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-23 23:44:59 --> Input Class Initialized
INFO - 2022-03-23 23:44:59 --> Language Class Initialized
ERROR - 2022-03-23 23:44:59 --> 404 Page Not Found: DS_Store/index
