<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-10-09 16:28:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-09 16:28:03 --> Config Class Initialized
INFO - 2021-10-09 16:28:03 --> Hooks Class Initialized
DEBUG - 2021-10-09 16:28:03 --> UTF-8 Support Enabled
INFO - 2021-10-09 16:28:03 --> Utf8 Class Initialized
INFO - 2021-10-09 16:28:03 --> URI Class Initialized
INFO - 2021-10-09 16:28:03 --> Router Class Initialized
INFO - 2021-10-09 16:28:03 --> Output Class Initialized
INFO - 2021-10-09 16:28:03 --> Security Class Initialized
DEBUG - 2021-10-09 16:28:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-09 16:28:03 --> Input Class Initialized
INFO - 2021-10-09 16:28:03 --> Language Class Initialized
ERROR - 2021-10-09 16:28:03 --> 404 Page Not Found: Wp-content/index
ERROR - 2021-10-09 21:49:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-09 21:49:28 --> Config Class Initialized
INFO - 2021-10-09 21:49:28 --> Hooks Class Initialized
DEBUG - 2021-10-09 21:49:28 --> UTF-8 Support Enabled
INFO - 2021-10-09 21:49:28 --> Utf8 Class Initialized
INFO - 2021-10-09 21:49:28 --> URI Class Initialized
DEBUG - 2021-10-09 21:49:28 --> No URI present. Default controller set.
INFO - 2021-10-09 21:49:28 --> Router Class Initialized
INFO - 2021-10-09 21:49:28 --> Output Class Initialized
INFO - 2021-10-09 21:49:28 --> Security Class Initialized
DEBUG - 2021-10-09 21:49:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-09 21:49:28 --> Input Class Initialized
INFO - 2021-10-09 21:49:28 --> Language Class Initialized
INFO - 2021-10-09 21:49:28 --> Loader Class Initialized
INFO - 2021-10-09 21:49:28 --> Helper loaded: url_helper
INFO - 2021-10-09 21:49:28 --> Helper loaded: form_helper
INFO - 2021-10-09 21:49:28 --> Helper loaded: common_helper
INFO - 2021-10-09 21:49:28 --> Database Driver Class Initialized
DEBUG - 2021-10-09 21:49:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-09 21:49:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-09 21:49:28 --> Controller Class Initialized
INFO - 2021-10-09 21:49:28 --> Form Validation Class Initialized
DEBUG - 2021-10-09 21:49:28 --> Encrypt Class Initialized
DEBUG - 2021-10-09 21:49:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-10-09 21:49:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-10-09 21:49:28 --> Email Class Initialized
INFO - 2021-10-09 21:49:28 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-10-09 21:49:28 --> Calendar Class Initialized
INFO - 2021-10-09 21:49:28 --> Model "Login_model" initialized
INFO - 2021-10-09 21:49:28 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-10-09 21:49:28 --> Final output sent to browser
DEBUG - 2021-10-09 21:49:28 --> Total execution time: 0.0386
ERROR - 2021-10-09 21:49:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-09 21:49:28 --> Config Class Initialized
INFO - 2021-10-09 21:49:28 --> Hooks Class Initialized
DEBUG - 2021-10-09 21:49:28 --> UTF-8 Support Enabled
INFO - 2021-10-09 21:49:28 --> Utf8 Class Initialized
INFO - 2021-10-09 21:49:28 --> URI Class Initialized
DEBUG - 2021-10-09 21:49:28 --> No URI present. Default controller set.
INFO - 2021-10-09 21:49:28 --> Router Class Initialized
INFO - 2021-10-09 21:49:28 --> Output Class Initialized
INFO - 2021-10-09 21:49:28 --> Security Class Initialized
DEBUG - 2021-10-09 21:49:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-09 21:49:28 --> Input Class Initialized
INFO - 2021-10-09 21:49:28 --> Language Class Initialized
INFO - 2021-10-09 21:49:28 --> Loader Class Initialized
INFO - 2021-10-09 21:49:28 --> Helper loaded: url_helper
INFO - 2021-10-09 21:49:28 --> Helper loaded: form_helper
INFO - 2021-10-09 21:49:28 --> Helper loaded: common_helper
INFO - 2021-10-09 21:49:28 --> Database Driver Class Initialized
DEBUG - 2021-10-09 21:49:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-09 21:49:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-09 21:49:28 --> Controller Class Initialized
INFO - 2021-10-09 21:49:28 --> Form Validation Class Initialized
DEBUG - 2021-10-09 21:49:28 --> Encrypt Class Initialized
DEBUG - 2021-10-09 21:49:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-10-09 21:49:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-10-09 21:49:28 --> Email Class Initialized
INFO - 2021-10-09 21:49:28 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-10-09 21:49:28 --> Calendar Class Initialized
INFO - 2021-10-09 21:49:28 --> Model "Login_model" initialized
INFO - 2021-10-09 21:49:28 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-10-09 21:49:28 --> Final output sent to browser
DEBUG - 2021-10-09 21:49:28 --> Total execution time: 0.0190
ERROR - 2021-10-09 21:49:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-09 21:49:28 --> Config Class Initialized
INFO - 2021-10-09 21:49:28 --> Hooks Class Initialized
DEBUG - 2021-10-09 21:49:28 --> UTF-8 Support Enabled
INFO - 2021-10-09 21:49:28 --> Utf8 Class Initialized
INFO - 2021-10-09 21:49:28 --> URI Class Initialized
INFO - 2021-10-09 21:49:28 --> Router Class Initialized
INFO - 2021-10-09 21:49:28 --> Output Class Initialized
INFO - 2021-10-09 21:49:28 --> Security Class Initialized
DEBUG - 2021-10-09 21:49:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-09 21:49:28 --> Input Class Initialized
INFO - 2021-10-09 21:49:28 --> Language Class Initialized
ERROR - 2021-10-09 21:49:28 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
ERROR - 2021-10-09 21:49:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-09 21:49:29 --> Config Class Initialized
INFO - 2021-10-09 21:49:29 --> Hooks Class Initialized
DEBUG - 2021-10-09 21:49:29 --> UTF-8 Support Enabled
INFO - 2021-10-09 21:49:29 --> Utf8 Class Initialized
INFO - 2021-10-09 21:49:29 --> URI Class Initialized
DEBUG - 2021-10-09 21:49:29 --> No URI present. Default controller set.
INFO - 2021-10-09 21:49:29 --> Router Class Initialized
INFO - 2021-10-09 21:49:29 --> Output Class Initialized
INFO - 2021-10-09 21:49:29 --> Security Class Initialized
DEBUG - 2021-10-09 21:49:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-09 21:49:29 --> Input Class Initialized
INFO - 2021-10-09 21:49:29 --> Language Class Initialized
INFO - 2021-10-09 21:49:29 --> Loader Class Initialized
INFO - 2021-10-09 21:49:29 --> Helper loaded: url_helper
INFO - 2021-10-09 21:49:29 --> Helper loaded: form_helper
INFO - 2021-10-09 21:49:29 --> Helper loaded: common_helper
INFO - 2021-10-09 21:49:29 --> Database Driver Class Initialized
DEBUG - 2021-10-09 21:49:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-09 21:49:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-09 21:49:29 --> Controller Class Initialized
INFO - 2021-10-09 21:49:29 --> Form Validation Class Initialized
DEBUG - 2021-10-09 21:49:29 --> Encrypt Class Initialized
DEBUG - 2021-10-09 21:49:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-10-09 21:49:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-10-09 21:49:29 --> Email Class Initialized
INFO - 2021-10-09 21:49:29 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-10-09 21:49:29 --> Calendar Class Initialized
INFO - 2021-10-09 21:49:29 --> Model "Login_model" initialized
INFO - 2021-10-09 21:49:29 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-10-09 21:49:29 --> Final output sent to browser
DEBUG - 2021-10-09 21:49:29 --> Total execution time: 0.0342
ERROR - 2021-10-09 21:49:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-09 21:49:29 --> Config Class Initialized
INFO - 2021-10-09 21:49:29 --> Hooks Class Initialized
DEBUG - 2021-10-09 21:49:29 --> UTF-8 Support Enabled
INFO - 2021-10-09 21:49:29 --> Utf8 Class Initialized
INFO - 2021-10-09 21:49:29 --> URI Class Initialized
INFO - 2021-10-09 21:49:29 --> Router Class Initialized
INFO - 2021-10-09 21:49:29 --> Output Class Initialized
INFO - 2021-10-09 21:49:29 --> Security Class Initialized
DEBUG - 2021-10-09 21:49:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-09 21:49:29 --> Input Class Initialized
INFO - 2021-10-09 21:49:29 --> Language Class Initialized
ERROR - 2021-10-09 21:49:29 --> 404 Page Not Found: Blog/wp-includes
ERROR - 2021-10-09 21:49:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-09 21:49:30 --> Config Class Initialized
INFO - 2021-10-09 21:49:30 --> Hooks Class Initialized
DEBUG - 2021-10-09 21:49:30 --> UTF-8 Support Enabled
INFO - 2021-10-09 21:49:30 --> Utf8 Class Initialized
INFO - 2021-10-09 21:49:30 --> URI Class Initialized
INFO - 2021-10-09 21:49:30 --> Router Class Initialized
INFO - 2021-10-09 21:49:30 --> Output Class Initialized
INFO - 2021-10-09 21:49:30 --> Security Class Initialized
DEBUG - 2021-10-09 21:49:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-09 21:49:30 --> Input Class Initialized
INFO - 2021-10-09 21:49:30 --> Language Class Initialized
ERROR - 2021-10-09 21:49:30 --> 404 Page Not Found: Web/wp-includes
ERROR - 2021-10-09 21:49:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-09 21:49:30 --> Config Class Initialized
INFO - 2021-10-09 21:49:30 --> Hooks Class Initialized
DEBUG - 2021-10-09 21:49:30 --> UTF-8 Support Enabled
INFO - 2021-10-09 21:49:30 --> Utf8 Class Initialized
INFO - 2021-10-09 21:49:30 --> URI Class Initialized
INFO - 2021-10-09 21:49:30 --> Router Class Initialized
INFO - 2021-10-09 21:49:30 --> Output Class Initialized
INFO - 2021-10-09 21:49:30 --> Security Class Initialized
DEBUG - 2021-10-09 21:49:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-09 21:49:30 --> Input Class Initialized
INFO - 2021-10-09 21:49:30 --> Language Class Initialized
ERROR - 2021-10-09 21:49:30 --> 404 Page Not Found: Wordpress/wp-includes
ERROR - 2021-10-09 21:49:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-09 21:49:30 --> Config Class Initialized
INFO - 2021-10-09 21:49:30 --> Hooks Class Initialized
DEBUG - 2021-10-09 21:49:30 --> UTF-8 Support Enabled
INFO - 2021-10-09 21:49:30 --> Utf8 Class Initialized
INFO - 2021-10-09 21:49:30 --> URI Class Initialized
INFO - 2021-10-09 21:49:30 --> Router Class Initialized
INFO - 2021-10-09 21:49:30 --> Output Class Initialized
INFO - 2021-10-09 21:49:30 --> Security Class Initialized
DEBUG - 2021-10-09 21:49:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-09 21:49:30 --> Input Class Initialized
INFO - 2021-10-09 21:49:30 --> Language Class Initialized
ERROR - 2021-10-09 21:49:30 --> 404 Page Not Found: Website/wp-includes
ERROR - 2021-10-09 21:49:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-09 21:49:30 --> Config Class Initialized
INFO - 2021-10-09 21:49:30 --> Hooks Class Initialized
DEBUG - 2021-10-09 21:49:30 --> UTF-8 Support Enabled
INFO - 2021-10-09 21:49:30 --> Utf8 Class Initialized
INFO - 2021-10-09 21:49:30 --> URI Class Initialized
INFO - 2021-10-09 21:49:30 --> Router Class Initialized
INFO - 2021-10-09 21:49:30 --> Output Class Initialized
INFO - 2021-10-09 21:49:30 --> Security Class Initialized
DEBUG - 2021-10-09 21:49:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-09 21:49:30 --> Input Class Initialized
INFO - 2021-10-09 21:49:30 --> Language Class Initialized
ERROR - 2021-10-09 21:49:30 --> 404 Page Not Found: Wp/wp-includes
ERROR - 2021-10-09 21:49:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-09 21:49:31 --> Config Class Initialized
INFO - 2021-10-09 21:49:31 --> Hooks Class Initialized
DEBUG - 2021-10-09 21:49:31 --> UTF-8 Support Enabled
INFO - 2021-10-09 21:49:31 --> Utf8 Class Initialized
INFO - 2021-10-09 21:49:31 --> URI Class Initialized
INFO - 2021-10-09 21:49:31 --> Router Class Initialized
INFO - 2021-10-09 21:49:31 --> Output Class Initialized
INFO - 2021-10-09 21:49:31 --> Security Class Initialized
DEBUG - 2021-10-09 21:49:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-09 21:49:31 --> Input Class Initialized
INFO - 2021-10-09 21:49:31 --> Language Class Initialized
ERROR - 2021-10-09 21:49:31 --> 404 Page Not Found: News/wp-includes
ERROR - 2021-10-09 21:49:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-09 21:49:31 --> Config Class Initialized
INFO - 2021-10-09 21:49:31 --> Hooks Class Initialized
DEBUG - 2021-10-09 21:49:31 --> UTF-8 Support Enabled
INFO - 2021-10-09 21:49:31 --> Utf8 Class Initialized
INFO - 2021-10-09 21:49:31 --> URI Class Initialized
INFO - 2021-10-09 21:49:31 --> Router Class Initialized
INFO - 2021-10-09 21:49:31 --> Output Class Initialized
INFO - 2021-10-09 21:49:31 --> Security Class Initialized
DEBUG - 2021-10-09 21:49:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-09 21:49:31 --> Input Class Initialized
INFO - 2021-10-09 21:49:31 --> Language Class Initialized
ERROR - 2021-10-09 21:49:31 --> 404 Page Not Found: 2020/wp-includes
ERROR - 2021-10-09 21:49:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-09 21:49:32 --> Config Class Initialized
INFO - 2021-10-09 21:49:32 --> Hooks Class Initialized
DEBUG - 2021-10-09 21:49:32 --> UTF-8 Support Enabled
INFO - 2021-10-09 21:49:32 --> Utf8 Class Initialized
INFO - 2021-10-09 21:49:32 --> URI Class Initialized
INFO - 2021-10-09 21:49:32 --> Router Class Initialized
INFO - 2021-10-09 21:49:32 --> Output Class Initialized
INFO - 2021-10-09 21:49:32 --> Security Class Initialized
DEBUG - 2021-10-09 21:49:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-09 21:49:32 --> Input Class Initialized
INFO - 2021-10-09 21:49:32 --> Language Class Initialized
ERROR - 2021-10-09 21:49:32 --> 404 Page Not Found: 2019/wp-includes
ERROR - 2021-10-09 21:49:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-09 21:49:32 --> Config Class Initialized
INFO - 2021-10-09 21:49:32 --> Hooks Class Initialized
DEBUG - 2021-10-09 21:49:32 --> UTF-8 Support Enabled
INFO - 2021-10-09 21:49:32 --> Utf8 Class Initialized
INFO - 2021-10-09 21:49:32 --> URI Class Initialized
INFO - 2021-10-09 21:49:32 --> Router Class Initialized
INFO - 2021-10-09 21:49:32 --> Output Class Initialized
INFO - 2021-10-09 21:49:32 --> Security Class Initialized
DEBUG - 2021-10-09 21:49:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-09 21:49:32 --> Input Class Initialized
INFO - 2021-10-09 21:49:32 --> Language Class Initialized
ERROR - 2021-10-09 21:49:32 --> 404 Page Not Found: Shop/wp-includes
ERROR - 2021-10-09 21:49:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-09 21:49:32 --> Config Class Initialized
INFO - 2021-10-09 21:49:32 --> Hooks Class Initialized
DEBUG - 2021-10-09 21:49:32 --> UTF-8 Support Enabled
INFO - 2021-10-09 21:49:32 --> Utf8 Class Initialized
INFO - 2021-10-09 21:49:32 --> URI Class Initialized
INFO - 2021-10-09 21:49:32 --> Router Class Initialized
INFO - 2021-10-09 21:49:32 --> Output Class Initialized
INFO - 2021-10-09 21:49:32 --> Security Class Initialized
DEBUG - 2021-10-09 21:49:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-09 21:49:32 --> Input Class Initialized
INFO - 2021-10-09 21:49:32 --> Language Class Initialized
ERROR - 2021-10-09 21:49:32 --> 404 Page Not Found: Wp1/wp-includes
ERROR - 2021-10-09 21:49:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-09 21:49:33 --> Config Class Initialized
INFO - 2021-10-09 21:49:33 --> Hooks Class Initialized
DEBUG - 2021-10-09 21:49:33 --> UTF-8 Support Enabled
INFO - 2021-10-09 21:49:33 --> Utf8 Class Initialized
INFO - 2021-10-09 21:49:33 --> URI Class Initialized
INFO - 2021-10-09 21:49:33 --> Router Class Initialized
INFO - 2021-10-09 21:49:33 --> Output Class Initialized
INFO - 2021-10-09 21:49:33 --> Security Class Initialized
DEBUG - 2021-10-09 21:49:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-09 21:49:33 --> Input Class Initialized
INFO - 2021-10-09 21:49:33 --> Language Class Initialized
ERROR - 2021-10-09 21:49:33 --> 404 Page Not Found: Test/wp-includes
ERROR - 2021-10-09 21:49:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-09 21:49:33 --> Config Class Initialized
INFO - 2021-10-09 21:49:33 --> Hooks Class Initialized
DEBUG - 2021-10-09 21:49:33 --> UTF-8 Support Enabled
INFO - 2021-10-09 21:49:33 --> Utf8 Class Initialized
INFO - 2021-10-09 21:49:33 --> URI Class Initialized
INFO - 2021-10-09 21:49:33 --> Router Class Initialized
INFO - 2021-10-09 21:49:33 --> Output Class Initialized
INFO - 2021-10-09 21:49:33 --> Security Class Initialized
DEBUG - 2021-10-09 21:49:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-09 21:49:33 --> Input Class Initialized
INFO - 2021-10-09 21:49:33 --> Language Class Initialized
ERROR - 2021-10-09 21:49:33 --> 404 Page Not Found: Wp2/wp-includes
ERROR - 2021-10-09 21:49:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-09 21:49:33 --> Config Class Initialized
INFO - 2021-10-09 21:49:33 --> Hooks Class Initialized
DEBUG - 2021-10-09 21:49:33 --> UTF-8 Support Enabled
INFO - 2021-10-09 21:49:33 --> Utf8 Class Initialized
INFO - 2021-10-09 21:49:33 --> URI Class Initialized
INFO - 2021-10-09 21:49:33 --> Router Class Initialized
INFO - 2021-10-09 21:49:33 --> Output Class Initialized
INFO - 2021-10-09 21:49:33 --> Security Class Initialized
DEBUG - 2021-10-09 21:49:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-09 21:49:33 --> Input Class Initialized
INFO - 2021-10-09 21:49:33 --> Language Class Initialized
ERROR - 2021-10-09 21:49:33 --> 404 Page Not Found: Site/wp-includes
ERROR - 2021-10-09 21:49:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-09 21:49:34 --> Config Class Initialized
INFO - 2021-10-09 21:49:34 --> Hooks Class Initialized
DEBUG - 2021-10-09 21:49:34 --> UTF-8 Support Enabled
INFO - 2021-10-09 21:49:34 --> Utf8 Class Initialized
INFO - 2021-10-09 21:49:34 --> URI Class Initialized
INFO - 2021-10-09 21:49:34 --> Router Class Initialized
INFO - 2021-10-09 21:49:34 --> Output Class Initialized
INFO - 2021-10-09 21:49:34 --> Security Class Initialized
DEBUG - 2021-10-09 21:49:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-09 21:49:34 --> Input Class Initialized
INFO - 2021-10-09 21:49:34 --> Language Class Initialized
ERROR - 2021-10-09 21:49:34 --> 404 Page Not Found: Cms/wp-includes
ERROR - 2021-10-09 21:49:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-09 21:49:34 --> Config Class Initialized
INFO - 2021-10-09 21:49:34 --> Hooks Class Initialized
DEBUG - 2021-10-09 21:49:34 --> UTF-8 Support Enabled
INFO - 2021-10-09 21:49:34 --> Utf8 Class Initialized
INFO - 2021-10-09 21:49:34 --> URI Class Initialized
INFO - 2021-10-09 21:49:34 --> Router Class Initialized
INFO - 2021-10-09 21:49:34 --> Output Class Initialized
INFO - 2021-10-09 21:49:34 --> Security Class Initialized
DEBUG - 2021-10-09 21:49:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-09 21:49:34 --> Input Class Initialized
INFO - 2021-10-09 21:49:34 --> Language Class Initialized
ERROR - 2021-10-09 21:49:34 --> 404 Page Not Found: Sito/wp-includes
