<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-06-02 02:48:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-02 02:48:35 --> Config Class Initialized
INFO - 2021-06-02 02:48:35 --> Hooks Class Initialized
DEBUG - 2021-06-02 02:48:35 --> UTF-8 Support Enabled
INFO - 2021-06-02 02:48:35 --> Utf8 Class Initialized
INFO - 2021-06-02 02:48:35 --> URI Class Initialized
DEBUG - 2021-06-02 02:48:35 --> No URI present. Default controller set.
INFO - 2021-06-02 02:48:35 --> Router Class Initialized
INFO - 2021-06-02 02:48:35 --> Output Class Initialized
INFO - 2021-06-02 02:48:35 --> Security Class Initialized
DEBUG - 2021-06-02 02:48:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 02:48:35 --> Input Class Initialized
INFO - 2021-06-02 02:48:35 --> Language Class Initialized
INFO - 2021-06-02 02:48:35 --> Loader Class Initialized
INFO - 2021-06-02 02:48:35 --> Helper loaded: url_helper
INFO - 2021-06-02 02:48:35 --> Helper loaded: form_helper
INFO - 2021-06-02 02:48:35 --> Helper loaded: common_helper
INFO - 2021-06-02 02:48:35 --> Database Driver Class Initialized
DEBUG - 2021-06-02 02:48:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 02:48:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 02:48:35 --> Controller Class Initialized
INFO - 2021-06-02 02:48:35 --> Form Validation Class Initialized
DEBUG - 2021-06-02 02:48:35 --> Encrypt Class Initialized
DEBUG - 2021-06-02 02:48:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-06-02 02:48:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-06-02 02:48:35 --> Email Class Initialized
INFO - 2021-06-02 02:48:35 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-06-02 02:48:35 --> Calendar Class Initialized
INFO - 2021-06-02 02:48:35 --> Model "Login_model" initialized
INFO - 2021-06-02 02:48:35 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-06-02 02:48:35 --> Final output sent to browser
DEBUG - 2021-06-02 02:48:35 --> Total execution time: 0.0369
ERROR - 2021-06-02 02:48:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-02 02:48:36 --> Config Class Initialized
INFO - 2021-06-02 02:48:36 --> Hooks Class Initialized
DEBUG - 2021-06-02 02:48:36 --> UTF-8 Support Enabled
INFO - 2021-06-02 02:48:36 --> Utf8 Class Initialized
INFO - 2021-06-02 02:48:36 --> URI Class Initialized
DEBUG - 2021-06-02 02:48:36 --> No URI present. Default controller set.
INFO - 2021-06-02 02:48:36 --> Router Class Initialized
INFO - 2021-06-02 02:48:36 --> Output Class Initialized
INFO - 2021-06-02 02:48:36 --> Security Class Initialized
DEBUG - 2021-06-02 02:48:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 02:48:36 --> Input Class Initialized
INFO - 2021-06-02 02:48:36 --> Language Class Initialized
INFO - 2021-06-02 02:48:36 --> Loader Class Initialized
INFO - 2021-06-02 02:48:36 --> Helper loaded: url_helper
INFO - 2021-06-02 02:48:36 --> Helper loaded: form_helper
INFO - 2021-06-02 02:48:36 --> Helper loaded: common_helper
INFO - 2021-06-02 02:48:36 --> Database Driver Class Initialized
DEBUG - 2021-06-02 02:48:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 02:48:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 02:48:36 --> Controller Class Initialized
INFO - 2021-06-02 02:48:36 --> Form Validation Class Initialized
DEBUG - 2021-06-02 02:48:36 --> Encrypt Class Initialized
DEBUG - 2021-06-02 02:48:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-06-02 02:48:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-06-02 02:48:36 --> Email Class Initialized
INFO - 2021-06-02 02:48:36 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-06-02 02:48:36 --> Calendar Class Initialized
INFO - 2021-06-02 02:48:36 --> Model "Login_model" initialized
INFO - 2021-06-02 02:48:36 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-06-02 02:48:36 --> Final output sent to browser
DEBUG - 2021-06-02 02:48:36 --> Total execution time: 0.0183
ERROR - 2021-06-02 02:48:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-02 02:48:37 --> Config Class Initialized
INFO - 2021-06-02 02:48:37 --> Hooks Class Initialized
DEBUG - 2021-06-02 02:48:37 --> UTF-8 Support Enabled
INFO - 2021-06-02 02:48:37 --> Utf8 Class Initialized
INFO - 2021-06-02 02:48:37 --> URI Class Initialized
INFO - 2021-06-02 02:48:37 --> Router Class Initialized
INFO - 2021-06-02 02:48:37 --> Output Class Initialized
INFO - 2021-06-02 02:48:37 --> Security Class Initialized
DEBUG - 2021-06-02 02:48:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 02:48:37 --> Input Class Initialized
INFO - 2021-06-02 02:48:37 --> Language Class Initialized
ERROR - 2021-06-02 02:48:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-02 02:48:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-02 02:48:39 --> Config Class Initialized
INFO - 2021-06-02 02:48:39 --> Hooks Class Initialized
DEBUG - 2021-06-02 02:48:39 --> UTF-8 Support Enabled
INFO - 2021-06-02 02:48:39 --> Utf8 Class Initialized
INFO - 2021-06-02 02:48:39 --> URI Class Initialized
INFO - 2021-06-02 02:48:39 --> Router Class Initialized
INFO - 2021-06-02 02:48:39 --> Output Class Initialized
INFO - 2021-06-02 02:48:39 --> Security Class Initialized
DEBUG - 2021-06-02 02:48:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 02:48:39 --> Input Class Initialized
INFO - 2021-06-02 02:48:39 --> Language Class Initialized
INFO - 2021-06-02 02:48:39 --> Loader Class Initialized
INFO - 2021-06-02 02:48:39 --> Helper loaded: url_helper
INFO - 2021-06-02 02:48:39 --> Helper loaded: form_helper
INFO - 2021-06-02 02:48:39 --> Helper loaded: common_helper
INFO - 2021-06-02 02:48:39 --> Database Driver Class Initialized
DEBUG - 2021-06-02 02:48:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 02:48:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 02:48:39 --> Controller Class Initialized
INFO - 2021-06-02 02:48:39 --> Form Validation Class Initialized
DEBUG - 2021-06-02 02:48:39 --> Encrypt Class Initialized
DEBUG - 2021-06-02 02:48:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-06-02 02:48:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-06-02 02:48:39 --> Email Class Initialized
INFO - 2021-06-02 02:48:39 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-06-02 02:48:39 --> Calendar Class Initialized
INFO - 2021-06-02 02:48:39 --> Model "Login_model" initialized
INFO - 2021-06-02 02:48:39 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2021-06-02 02:48:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-02 02:48:40 --> Config Class Initialized
INFO - 2021-06-02 02:48:40 --> Hooks Class Initialized
DEBUG - 2021-06-02 02:48:40 --> UTF-8 Support Enabled
INFO - 2021-06-02 02:48:40 --> Utf8 Class Initialized
INFO - 2021-06-02 02:48:40 --> URI Class Initialized
INFO - 2021-06-02 02:48:40 --> Router Class Initialized
INFO - 2021-06-02 02:48:40 --> Output Class Initialized
INFO - 2021-06-02 02:48:40 --> Security Class Initialized
DEBUG - 2021-06-02 02:48:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 02:48:40 --> Input Class Initialized
INFO - 2021-06-02 02:48:40 --> Language Class Initialized
INFO - 2021-06-02 02:48:40 --> Loader Class Initialized
INFO - 2021-06-02 02:48:40 --> Helper loaded: url_helper
INFO - 2021-06-02 02:48:40 --> Helper loaded: form_helper
INFO - 2021-06-02 02:48:40 --> Helper loaded: common_helper
INFO - 2021-06-02 02:48:40 --> Database Driver Class Initialized
DEBUG - 2021-06-02 02:48:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 02:48:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 02:48:40 --> Controller Class Initialized
INFO - 2021-06-02 02:48:40 --> Form Validation Class Initialized
DEBUG - 2021-06-02 02:48:40 --> Encrypt Class Initialized
INFO - 2021-06-02 02:48:40 --> Model "Login_model" initialized
INFO - 2021-06-02 02:48:40 --> Model "Dashboard_model" initialized
INFO - 2021-06-02 02:48:40 --> Model "Case_model" initialized
INFO - 2021-06-02 02:48:43 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/header.php
INFO - 2021-06-02 02:48:49 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/dashboard/index.php
INFO - 2021-06-02 02:48:49 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/footer.php
INFO - 2021-06-02 02:48:49 --> Final output sent to browser
DEBUG - 2021-06-02 02:48:49 --> Total execution time: 8.9838
ERROR - 2021-06-02 02:48:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-02 02:48:50 --> Config Class Initialized
INFO - 2021-06-02 02:48:50 --> Hooks Class Initialized
DEBUG - 2021-06-02 02:48:50 --> UTF-8 Support Enabled
INFO - 2021-06-02 02:48:50 --> Utf8 Class Initialized
INFO - 2021-06-02 02:48:50 --> URI Class Initialized
INFO - 2021-06-02 02:48:50 --> Router Class Initialized
INFO - 2021-06-02 02:48:50 --> Output Class Initialized
INFO - 2021-06-02 02:48:50 --> Security Class Initialized
DEBUG - 2021-06-02 02:48:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 02:48:50 --> Input Class Initialized
INFO - 2021-06-02 02:48:50 --> Language Class Initialized
ERROR - 2021-06-02 02:48:50 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-06-02 02:50:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-02 02:50:18 --> Config Class Initialized
INFO - 2021-06-02 02:50:18 --> Hooks Class Initialized
DEBUG - 2021-06-02 02:50:18 --> UTF-8 Support Enabled
INFO - 2021-06-02 02:50:18 --> Utf8 Class Initialized
INFO - 2021-06-02 02:50:18 --> URI Class Initialized
INFO - 2021-06-02 02:50:18 --> Router Class Initialized
INFO - 2021-06-02 02:50:18 --> Output Class Initialized
INFO - 2021-06-02 02:50:18 --> Security Class Initialized
DEBUG - 2021-06-02 02:50:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 02:50:18 --> Input Class Initialized
INFO - 2021-06-02 02:50:18 --> Language Class Initialized
INFO - 2021-06-02 02:50:18 --> Loader Class Initialized
INFO - 2021-06-02 02:50:18 --> Helper loaded: url_helper
INFO - 2021-06-02 02:50:18 --> Helper loaded: form_helper
INFO - 2021-06-02 02:50:18 --> Helper loaded: common_helper
INFO - 2021-06-02 02:50:18 --> Database Driver Class Initialized
DEBUG - 2021-06-02 02:50:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 02:50:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 02:50:18 --> Controller Class Initialized
INFO - 2021-06-02 02:50:18 --> Form Validation Class Initialized
DEBUG - 2021-06-02 02:50:18 --> Encrypt Class Initialized
DEBUG - 2021-06-02 02:50:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-06-02 02:50:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-06-02 02:50:18 --> Email Class Initialized
INFO - 2021-06-02 02:50:18 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-06-02 02:50:18 --> Calendar Class Initialized
INFO - 2021-06-02 02:50:18 --> Model "Login_model" initialized
ERROR - 2021-06-02 02:50:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-02 02:50:18 --> Config Class Initialized
INFO - 2021-06-02 02:50:18 --> Hooks Class Initialized
DEBUG - 2021-06-02 02:50:18 --> UTF-8 Support Enabled
INFO - 2021-06-02 02:50:18 --> Utf8 Class Initialized
INFO - 2021-06-02 02:50:18 --> URI Class Initialized
INFO - 2021-06-02 02:50:18 --> Router Class Initialized
INFO - 2021-06-02 02:50:18 --> Output Class Initialized
INFO - 2021-06-02 02:50:18 --> Security Class Initialized
DEBUG - 2021-06-02 02:50:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 02:50:18 --> Input Class Initialized
INFO - 2021-06-02 02:50:18 --> Language Class Initialized
INFO - 2021-06-02 02:50:18 --> Loader Class Initialized
INFO - 2021-06-02 02:50:18 --> Helper loaded: url_helper
INFO - 2021-06-02 02:50:18 --> Helper loaded: form_helper
INFO - 2021-06-02 02:50:18 --> Helper loaded: common_helper
INFO - 2021-06-02 02:50:18 --> Database Driver Class Initialized
DEBUG - 2021-06-02 02:50:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 02:50:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 02:50:18 --> Controller Class Initialized
INFO - 2021-06-02 02:50:18 --> Form Validation Class Initialized
DEBUG - 2021-06-02 02:50:18 --> Encrypt Class Initialized
DEBUG - 2021-06-02 02:50:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-06-02 02:50:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-06-02 02:50:18 --> Email Class Initialized
INFO - 2021-06-02 02:50:18 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-06-02 02:50:18 --> Calendar Class Initialized
INFO - 2021-06-02 02:50:18 --> Model "Login_model" initialized
INFO - 2021-06-02 02:50:18 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-06-02 02:50:18 --> Final output sent to browser
DEBUG - 2021-06-02 02:50:18 --> Total execution time: 0.0173
ERROR - 2021-06-02 02:50:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-02 02:50:22 --> Config Class Initialized
INFO - 2021-06-02 02:50:22 --> Hooks Class Initialized
DEBUG - 2021-06-02 02:50:22 --> UTF-8 Support Enabled
INFO - 2021-06-02 02:50:22 --> Utf8 Class Initialized
INFO - 2021-06-02 02:50:22 --> URI Class Initialized
INFO - 2021-06-02 02:50:22 --> Router Class Initialized
INFO - 2021-06-02 02:50:22 --> Output Class Initialized
INFO - 2021-06-02 02:50:22 --> Security Class Initialized
DEBUG - 2021-06-02 02:50:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 02:50:22 --> Input Class Initialized
INFO - 2021-06-02 02:50:22 --> Language Class Initialized
INFO - 2021-06-02 02:50:22 --> Loader Class Initialized
INFO - 2021-06-02 02:50:22 --> Helper loaded: url_helper
INFO - 2021-06-02 02:50:22 --> Helper loaded: form_helper
INFO - 2021-06-02 02:50:22 --> Helper loaded: common_helper
INFO - 2021-06-02 02:50:22 --> Database Driver Class Initialized
DEBUG - 2021-06-02 02:50:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 02:50:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 02:50:22 --> Controller Class Initialized
INFO - 2021-06-02 02:50:22 --> Form Validation Class Initialized
DEBUG - 2021-06-02 02:50:22 --> Encrypt Class Initialized
DEBUG - 2021-06-02 02:50:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-06-02 02:50:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-06-02 02:50:22 --> Email Class Initialized
INFO - 2021-06-02 02:50:22 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-06-02 02:50:22 --> Calendar Class Initialized
INFO - 2021-06-02 02:50:22 --> Model "Login_model" initialized
INFO - 2021-06-02 02:50:22 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-06-02 02:50:22 --> Final output sent to browser
DEBUG - 2021-06-02 02:50:22 --> Total execution time: 0.0176
ERROR - 2021-06-02 02:50:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-02 02:50:24 --> Config Class Initialized
INFO - 2021-06-02 02:50:24 --> Hooks Class Initialized
DEBUG - 2021-06-02 02:50:24 --> UTF-8 Support Enabled
INFO - 2021-06-02 02:50:24 --> Utf8 Class Initialized
INFO - 2021-06-02 02:50:24 --> URI Class Initialized
INFO - 2021-06-02 02:50:24 --> Router Class Initialized
INFO - 2021-06-02 02:50:24 --> Output Class Initialized
INFO - 2021-06-02 02:50:24 --> Security Class Initialized
DEBUG - 2021-06-02 02:50:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 02:50:24 --> Input Class Initialized
INFO - 2021-06-02 02:50:24 --> Language Class Initialized
ERROR - 2021-06-02 02:50:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-02 02:50:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-02 02:50:25 --> Config Class Initialized
INFO - 2021-06-02 02:50:25 --> Hooks Class Initialized
DEBUG - 2021-06-02 02:50:25 --> UTF-8 Support Enabled
INFO - 2021-06-02 02:50:25 --> Utf8 Class Initialized
INFO - 2021-06-02 02:50:25 --> URI Class Initialized
INFO - 2021-06-02 02:50:25 --> Router Class Initialized
INFO - 2021-06-02 02:50:25 --> Output Class Initialized
INFO - 2021-06-02 02:50:25 --> Security Class Initialized
DEBUG - 2021-06-02 02:50:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 02:50:25 --> Input Class Initialized
INFO - 2021-06-02 02:50:25 --> Language Class Initialized
INFO - 2021-06-02 02:50:25 --> Loader Class Initialized
INFO - 2021-06-02 02:50:25 --> Helper loaded: url_helper
INFO - 2021-06-02 02:50:25 --> Helper loaded: form_helper
INFO - 2021-06-02 02:50:25 --> Helper loaded: common_helper
INFO - 2021-06-02 02:50:25 --> Database Driver Class Initialized
DEBUG - 2021-06-02 02:50:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 02:50:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 02:50:25 --> Controller Class Initialized
INFO - 2021-06-02 02:50:25 --> Form Validation Class Initialized
DEBUG - 2021-06-02 02:50:25 --> Encrypt Class Initialized
DEBUG - 2021-06-02 02:50:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-06-02 02:50:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-06-02 02:50:25 --> Email Class Initialized
INFO - 2021-06-02 02:50:25 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-06-02 02:50:25 --> Calendar Class Initialized
INFO - 2021-06-02 02:50:25 --> Model "Login_model" initialized
INFO - 2021-06-02 02:50:25 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2021-06-02 02:50:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-02 02:50:26 --> Config Class Initialized
INFO - 2021-06-02 02:50:26 --> Hooks Class Initialized
DEBUG - 2021-06-02 02:50:26 --> UTF-8 Support Enabled
INFO - 2021-06-02 02:50:26 --> Utf8 Class Initialized
INFO - 2021-06-02 02:50:26 --> URI Class Initialized
INFO - 2021-06-02 02:50:26 --> Router Class Initialized
INFO - 2021-06-02 02:50:26 --> Output Class Initialized
INFO - 2021-06-02 02:50:26 --> Security Class Initialized
DEBUG - 2021-06-02 02:50:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 02:50:26 --> Input Class Initialized
INFO - 2021-06-02 02:50:26 --> Language Class Initialized
INFO - 2021-06-02 02:50:26 --> Loader Class Initialized
INFO - 2021-06-02 02:50:26 --> Helper loaded: url_helper
INFO - 2021-06-02 02:50:26 --> Helper loaded: form_helper
INFO - 2021-06-02 02:50:26 --> Helper loaded: common_helper
INFO - 2021-06-02 02:50:26 --> Database Driver Class Initialized
DEBUG - 2021-06-02 02:50:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 02:50:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 02:50:26 --> Controller Class Initialized
INFO - 2021-06-02 02:50:26 --> Form Validation Class Initialized
DEBUG - 2021-06-02 02:50:26 --> Encrypt Class Initialized
INFO - 2021-06-02 02:50:26 --> Model "Login_model" initialized
INFO - 2021-06-02 02:50:26 --> Model "Dashboard_model" initialized
INFO - 2021-06-02 02:50:26 --> Model "Case_model" initialized
INFO - 2021-06-02 02:50:29 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/header.php
INFO - 2021-06-02 02:50:35 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/dashboard/index.php
INFO - 2021-06-02 02:50:35 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/footer.php
INFO - 2021-06-02 02:50:35 --> Final output sent to browser
DEBUG - 2021-06-02 02:50:35 --> Total execution time: 8.8060
ERROR - 2021-06-02 02:50:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-02 02:50:36 --> Config Class Initialized
INFO - 2021-06-02 02:50:36 --> Hooks Class Initialized
DEBUG - 2021-06-02 02:50:36 --> UTF-8 Support Enabled
INFO - 2021-06-02 02:50:36 --> Utf8 Class Initialized
INFO - 2021-06-02 02:50:36 --> URI Class Initialized
INFO - 2021-06-02 02:50:36 --> Router Class Initialized
INFO - 2021-06-02 02:50:36 --> Output Class Initialized
INFO - 2021-06-02 02:50:36 --> Security Class Initialized
DEBUG - 2021-06-02 02:50:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 02:50:36 --> Input Class Initialized
INFO - 2021-06-02 02:50:36 --> Language Class Initialized
ERROR - 2021-06-02 02:50:36 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-06-02 02:50:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-02 02:50:54 --> Config Class Initialized
INFO - 2021-06-02 02:50:54 --> Hooks Class Initialized
DEBUG - 2021-06-02 02:50:54 --> UTF-8 Support Enabled
INFO - 2021-06-02 02:50:54 --> Utf8 Class Initialized
INFO - 2021-06-02 02:50:54 --> URI Class Initialized
INFO - 2021-06-02 02:50:54 --> Router Class Initialized
INFO - 2021-06-02 02:50:54 --> Output Class Initialized
INFO - 2021-06-02 02:50:54 --> Security Class Initialized
DEBUG - 2021-06-02 02:50:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 02:50:54 --> Input Class Initialized
INFO - 2021-06-02 02:50:54 --> Language Class Initialized
INFO - 2021-06-02 02:50:54 --> Loader Class Initialized
INFO - 2021-06-02 02:50:54 --> Helper loaded: url_helper
INFO - 2021-06-02 02:50:54 --> Helper loaded: form_helper
INFO - 2021-06-02 02:50:54 --> Helper loaded: common_helper
INFO - 2021-06-02 02:50:54 --> Database Driver Class Initialized
DEBUG - 2021-06-02 02:50:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 02:50:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 02:50:54 --> Controller Class Initialized
INFO - 2021-06-02 02:50:54 --> Form Validation Class Initialized
INFO - 2021-06-02 02:50:54 --> Model "Report_model" initialized
INFO - 2021-06-02 02:50:54 --> Model "Case_model" initialized
INFO - 2021-06-02 02:50:54 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/header.php
INFO - 2021-06-02 02:50:54 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/reports/patient_details.php
INFO - 2021-06-02 02:50:54 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/footer.php
INFO - 2021-06-02 02:50:54 --> Final output sent to browser
DEBUG - 2021-06-02 02:50:54 --> Total execution time: 0.0162
ERROR - 2021-06-02 02:50:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-02 02:50:54 --> Config Class Initialized
INFO - 2021-06-02 02:50:54 --> Hooks Class Initialized
DEBUG - 2021-06-02 02:50:54 --> UTF-8 Support Enabled
INFO - 2021-06-02 02:50:54 --> Utf8 Class Initialized
INFO - 2021-06-02 02:50:54 --> URI Class Initialized
INFO - 2021-06-02 02:50:54 --> Router Class Initialized
INFO - 2021-06-02 02:50:54 --> Output Class Initialized
INFO - 2021-06-02 02:50:54 --> Security Class Initialized
DEBUG - 2021-06-02 02:50:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 02:50:54 --> Input Class Initialized
INFO - 2021-06-02 02:50:54 --> Language Class Initialized
ERROR - 2021-06-02 02:50:54 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-06-02 02:50:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-02 02:50:57 --> Config Class Initialized
INFO - 2021-06-02 02:50:57 --> Hooks Class Initialized
DEBUG - 2021-06-02 02:50:57 --> UTF-8 Support Enabled
INFO - 2021-06-02 02:50:57 --> Utf8 Class Initialized
INFO - 2021-06-02 02:50:57 --> URI Class Initialized
INFO - 2021-06-02 02:50:57 --> Router Class Initialized
INFO - 2021-06-02 02:50:57 --> Output Class Initialized
INFO - 2021-06-02 02:50:57 --> Security Class Initialized
DEBUG - 2021-06-02 02:50:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 02:50:57 --> Input Class Initialized
INFO - 2021-06-02 02:50:57 --> Language Class Initialized
ERROR - 2021-06-02 02:50:57 --> 404 Page Not Found: Karoclient/css
ERROR - 2021-06-02 02:50:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-02 02:50:59 --> Config Class Initialized
INFO - 2021-06-02 02:50:59 --> Hooks Class Initialized
DEBUG - 2021-06-02 02:50:59 --> UTF-8 Support Enabled
INFO - 2021-06-02 02:50:59 --> Utf8 Class Initialized
INFO - 2021-06-02 02:50:59 --> URI Class Initialized
INFO - 2021-06-02 02:50:59 --> Router Class Initialized
INFO - 2021-06-02 02:50:59 --> Output Class Initialized
INFO - 2021-06-02 02:50:59 --> Security Class Initialized
DEBUG - 2021-06-02 02:50:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 02:50:59 --> Input Class Initialized
INFO - 2021-06-02 02:50:59 --> Language Class Initialized
INFO - 2021-06-02 02:50:59 --> Loader Class Initialized
INFO - 2021-06-02 02:50:59 --> Helper loaded: url_helper
INFO - 2021-06-02 02:50:59 --> Helper loaded: form_helper
INFO - 2021-06-02 02:50:59 --> Helper loaded: common_helper
INFO - 2021-06-02 02:50:59 --> Database Driver Class Initialized
DEBUG - 2021-06-02 02:50:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 02:50:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 02:50:59 --> Controller Class Initialized
INFO - 2021-06-02 02:50:59 --> Form Validation Class Initialized
INFO - 2021-06-02 02:50:59 --> Model "Report_model" initialized
INFO - 2021-06-02 02:50:59 --> Model "Case_model" initialized
INFO - 2021-06-02 02:51:00 --> Final output sent to browser
DEBUG - 2021-06-02 02:51:00 --> Total execution time: 0.2987
ERROR - 2021-06-02 02:51:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-02 02:51:04 --> Config Class Initialized
INFO - 2021-06-02 02:51:04 --> Hooks Class Initialized
DEBUG - 2021-06-02 02:51:04 --> UTF-8 Support Enabled
INFO - 2021-06-02 02:51:04 --> Utf8 Class Initialized
INFO - 2021-06-02 02:51:04 --> URI Class Initialized
INFO - 2021-06-02 02:51:04 --> Router Class Initialized
INFO - 2021-06-02 02:51:04 --> Output Class Initialized
INFO - 2021-06-02 02:51:04 --> Security Class Initialized
DEBUG - 2021-06-02 02:51:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 02:51:04 --> Input Class Initialized
INFO - 2021-06-02 02:51:04 --> Language Class Initialized
INFO - 2021-06-02 02:51:04 --> Loader Class Initialized
INFO - 2021-06-02 02:51:04 --> Helper loaded: url_helper
INFO - 2021-06-02 02:51:04 --> Helper loaded: form_helper
INFO - 2021-06-02 02:51:04 --> Helper loaded: common_helper
INFO - 2021-06-02 02:51:04 --> Database Driver Class Initialized
DEBUG - 2021-06-02 02:51:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 02:51:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 02:51:04 --> Controller Class Initialized
INFO - 2021-06-02 02:51:04 --> Form Validation Class Initialized
INFO - 2021-06-02 02:51:04 --> Model "Report_model" initialized
INFO - 2021-06-02 02:51:04 --> Model "Case_model" initialized
INFO - 2021-06-02 02:51:04 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/header.php
INFO - 2021-06-02 02:51:04 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/reports/case_wise_patient_details.php
INFO - 2021-06-02 02:51:04 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/footer.php
INFO - 2021-06-02 02:51:04 --> Final output sent to browser
DEBUG - 2021-06-02 02:51:04 --> Total execution time: 0.0164
ERROR - 2021-06-02 02:51:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-02 02:51:05 --> Config Class Initialized
INFO - 2021-06-02 02:51:05 --> Hooks Class Initialized
DEBUG - 2021-06-02 02:51:05 --> UTF-8 Support Enabled
INFO - 2021-06-02 02:51:05 --> Utf8 Class Initialized
INFO - 2021-06-02 02:51:05 --> URI Class Initialized
INFO - 2021-06-02 02:51:05 --> Router Class Initialized
INFO - 2021-06-02 02:51:05 --> Output Class Initialized
INFO - 2021-06-02 02:51:05 --> Security Class Initialized
DEBUG - 2021-06-02 02:51:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 02:51:05 --> Input Class Initialized
INFO - 2021-06-02 02:51:05 --> Language Class Initialized
ERROR - 2021-06-02 02:51:05 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-06-02 02:51:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-02 02:51:10 --> Config Class Initialized
INFO - 2021-06-02 02:51:10 --> Hooks Class Initialized
DEBUG - 2021-06-02 02:51:10 --> UTF-8 Support Enabled
INFO - 2021-06-02 02:51:10 --> Utf8 Class Initialized
INFO - 2021-06-02 02:51:10 --> URI Class Initialized
INFO - 2021-06-02 02:51:10 --> Router Class Initialized
INFO - 2021-06-02 02:51:10 --> Output Class Initialized
INFO - 2021-06-02 02:51:10 --> Security Class Initialized
DEBUG - 2021-06-02 02:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 02:51:10 --> Input Class Initialized
INFO - 2021-06-02 02:51:10 --> Language Class Initialized
INFO - 2021-06-02 02:51:10 --> Loader Class Initialized
INFO - 2021-06-02 02:51:10 --> Helper loaded: url_helper
INFO - 2021-06-02 02:51:10 --> Helper loaded: form_helper
INFO - 2021-06-02 02:51:10 --> Helper loaded: common_helper
INFO - 2021-06-02 02:51:10 --> Database Driver Class Initialized
DEBUG - 2021-06-02 02:51:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 02:51:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 02:51:10 --> Controller Class Initialized
INFO - 2021-06-02 02:51:10 --> Form Validation Class Initialized
INFO - 2021-06-02 02:51:10 --> Model "Report_model" initialized
INFO - 2021-06-02 02:51:10 --> Model "Case_model" initialized
INFO - 2021-06-02 02:51:11 --> Final output sent to browser
DEBUG - 2021-06-02 02:51:11 --> Total execution time: 1.5081
ERROR - 2021-06-02 02:51:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-02 02:51:14 --> Config Class Initialized
INFO - 2021-06-02 02:51:14 --> Hooks Class Initialized
DEBUG - 2021-06-02 02:51:14 --> UTF-8 Support Enabled
INFO - 2021-06-02 02:51:14 --> Utf8 Class Initialized
INFO - 2021-06-02 02:51:14 --> URI Class Initialized
INFO - 2021-06-02 02:51:14 --> Router Class Initialized
INFO - 2021-06-02 02:51:14 --> Output Class Initialized
INFO - 2021-06-02 02:51:14 --> Security Class Initialized
DEBUG - 2021-06-02 02:51:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 02:51:14 --> Input Class Initialized
INFO - 2021-06-02 02:51:14 --> Language Class Initialized
INFO - 2021-06-02 02:51:14 --> Loader Class Initialized
INFO - 2021-06-02 02:51:14 --> Helper loaded: url_helper
INFO - 2021-06-02 02:51:14 --> Helper loaded: form_helper
INFO - 2021-06-02 02:51:14 --> Helper loaded: common_helper
INFO - 2021-06-02 02:51:14 --> Database Driver Class Initialized
DEBUG - 2021-06-02 02:51:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 02:51:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 02:51:14 --> Controller Class Initialized
INFO - 2021-06-02 02:51:14 --> Form Validation Class Initialized
INFO - 2021-06-02 02:51:14 --> Model "Report_model" initialized
INFO - 2021-06-02 02:51:14 --> Model "Case_model" initialized
INFO - 2021-06-02 02:51:16 --> Final output sent to browser
DEBUG - 2021-06-02 02:51:16 --> Total execution time: 1.4694
ERROR - 2021-06-02 02:51:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-02 02:51:56 --> Config Class Initialized
INFO - 2021-06-02 02:51:56 --> Hooks Class Initialized
DEBUG - 2021-06-02 02:51:56 --> UTF-8 Support Enabled
INFO - 2021-06-02 02:51:56 --> Utf8 Class Initialized
INFO - 2021-06-02 02:51:56 --> URI Class Initialized
INFO - 2021-06-02 02:51:56 --> Router Class Initialized
INFO - 2021-06-02 02:51:56 --> Output Class Initialized
INFO - 2021-06-02 02:51:56 --> Security Class Initialized
DEBUG - 2021-06-02 02:51:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 02:51:56 --> Input Class Initialized
INFO - 2021-06-02 02:51:56 --> Language Class Initialized
INFO - 2021-06-02 02:51:56 --> Loader Class Initialized
INFO - 2021-06-02 02:51:56 --> Helper loaded: url_helper
INFO - 2021-06-02 02:51:56 --> Helper loaded: form_helper
INFO - 2021-06-02 02:51:56 --> Helper loaded: common_helper
INFO - 2021-06-02 02:51:56 --> Database Driver Class Initialized
DEBUG - 2021-06-02 02:51:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 02:51:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 02:51:56 --> Controller Class Initialized
INFO - 2021-06-02 02:51:56 --> Form Validation Class Initialized
INFO - 2021-06-02 02:51:56 --> Model "Case_model" initialized
INFO - 2021-06-02 02:51:56 --> Model "Patientcase_model" initialized
INFO - 2021-06-02 02:51:56 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/header.php
INFO - 2021-06-02 02:51:56 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/cases/new_case.php
INFO - 2021-06-02 02:51:56 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/footer.php
INFO - 2021-06-02 02:51:56 --> Final output sent to browser
DEBUG - 2021-06-02 02:51:56 --> Total execution time: 0.2076
ERROR - 2021-06-02 02:51:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-02 02:51:57 --> Config Class Initialized
INFO - 2021-06-02 02:51:57 --> Hooks Class Initialized
DEBUG - 2021-06-02 02:51:57 --> UTF-8 Support Enabled
INFO - 2021-06-02 02:51:57 --> Utf8 Class Initialized
INFO - 2021-06-02 02:51:57 --> URI Class Initialized
INFO - 2021-06-02 02:51:57 --> Router Class Initialized
INFO - 2021-06-02 02:51:57 --> Output Class Initialized
INFO - 2021-06-02 02:51:57 --> Security Class Initialized
DEBUG - 2021-06-02 02:51:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 02:51:57 --> Input Class Initialized
INFO - 2021-06-02 02:51:57 --> Language Class Initialized
ERROR - 2021-06-02 02:51:57 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-06-02 02:52:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-02 02:52:08 --> Config Class Initialized
INFO - 2021-06-02 02:52:08 --> Hooks Class Initialized
DEBUG - 2021-06-02 02:52:08 --> UTF-8 Support Enabled
INFO - 2021-06-02 02:52:08 --> Utf8 Class Initialized
INFO - 2021-06-02 02:52:08 --> URI Class Initialized
INFO - 2021-06-02 02:52:08 --> Router Class Initialized
INFO - 2021-06-02 02:52:08 --> Output Class Initialized
INFO - 2021-06-02 02:52:08 --> Security Class Initialized
DEBUG - 2021-06-02 02:52:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 02:52:08 --> Input Class Initialized
INFO - 2021-06-02 02:52:08 --> Language Class Initialized
INFO - 2021-06-02 02:52:08 --> Loader Class Initialized
INFO - 2021-06-02 02:52:08 --> Helper loaded: url_helper
INFO - 2021-06-02 02:52:08 --> Helper loaded: form_helper
INFO - 2021-06-02 02:52:08 --> Helper loaded: common_helper
INFO - 2021-06-02 02:52:08 --> Database Driver Class Initialized
DEBUG - 2021-06-02 02:52:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 02:52:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 02:52:08 --> Controller Class Initialized
INFO - 2021-06-02 02:52:08 --> Form Validation Class Initialized
INFO - 2021-06-02 02:52:08 --> Model "Case_model" initialized
INFO - 2021-06-02 02:52:08 --> Model "Patientcase_model" initialized
INFO - 2021-06-02 02:52:08 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/header.php
INFO - 2021-06-02 02:52:08 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/cases/new_case.php
INFO - 2021-06-02 02:52:08 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/footer.php
INFO - 2021-06-02 02:52:08 --> Final output sent to browser
DEBUG - 2021-06-02 02:52:08 --> Total execution time: 0.2219
ERROR - 2021-06-02 02:52:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-02 02:52:10 --> Config Class Initialized
INFO - 2021-06-02 02:52:10 --> Hooks Class Initialized
DEBUG - 2021-06-02 02:52:10 --> UTF-8 Support Enabled
INFO - 2021-06-02 02:52:10 --> Utf8 Class Initialized
INFO - 2021-06-02 02:52:10 --> URI Class Initialized
INFO - 2021-06-02 02:52:10 --> Router Class Initialized
INFO - 2021-06-02 02:52:10 --> Output Class Initialized
INFO - 2021-06-02 02:52:10 --> Security Class Initialized
DEBUG - 2021-06-02 02:52:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 02:52:10 --> Input Class Initialized
INFO - 2021-06-02 02:52:10 --> Language Class Initialized
ERROR - 2021-06-02 02:52:10 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-06-02 02:52:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-02 02:52:23 --> Config Class Initialized
INFO - 2021-06-02 02:52:23 --> Hooks Class Initialized
DEBUG - 2021-06-02 02:52:23 --> UTF-8 Support Enabled
INFO - 2021-06-02 02:52:23 --> Utf8 Class Initialized
INFO - 2021-06-02 02:52:23 --> URI Class Initialized
INFO - 2021-06-02 02:52:23 --> Router Class Initialized
INFO - 2021-06-02 02:52:23 --> Output Class Initialized
INFO - 2021-06-02 02:52:23 --> Security Class Initialized
DEBUG - 2021-06-02 02:52:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 02:52:23 --> Input Class Initialized
INFO - 2021-06-02 02:52:23 --> Language Class Initialized
INFO - 2021-06-02 02:52:23 --> Loader Class Initialized
INFO - 2021-06-02 02:52:23 --> Helper loaded: url_helper
INFO - 2021-06-02 02:52:23 --> Helper loaded: form_helper
INFO - 2021-06-02 02:52:23 --> Helper loaded: common_helper
INFO - 2021-06-02 02:52:23 --> Database Driver Class Initialized
DEBUG - 2021-06-02 02:52:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 02:52:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 02:52:23 --> Controller Class Initialized
INFO - 2021-06-02 02:52:23 --> Form Validation Class Initialized
DEBUG - 2021-06-02 02:52:23 --> Encrypt Class Initialized
INFO - 2021-06-02 02:52:23 --> Model "Patient_model" initialized
INFO - 2021-06-02 02:52:23 --> Model "Patientcase_model" initialized
INFO - 2021-06-02 02:52:23 --> Model "Referredby_model" initialized
INFO - 2021-06-02 02:52:23 --> Model "Prefix_master" initialized
INFO - 2021-06-02 02:52:23 --> Model "Hospital_model" initialized
INFO - 2021-06-02 02:52:23 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/header.php
INFO - 2021-06-02 02:52:27 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/patient/patientview.php
INFO - 2021-06-02 02:52:27 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/footer.php
ERROR - 2021-06-02 02:52:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-02 02:52:28 --> Config Class Initialized
INFO - 2021-06-02 02:52:28 --> Hooks Class Initialized
DEBUG - 2021-06-02 02:52:28 --> UTF-8 Support Enabled
INFO - 2021-06-02 02:52:28 --> Utf8 Class Initialized
INFO - 2021-06-02 02:52:28 --> URI Class Initialized
INFO - 2021-06-02 02:52:28 --> Router Class Initialized
INFO - 2021-06-02 02:52:28 --> Output Class Initialized
INFO - 2021-06-02 02:52:28 --> Security Class Initialized
DEBUG - 2021-06-02 02:52:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 02:52:28 --> Input Class Initialized
INFO - 2021-06-02 02:52:28 --> Language Class Initialized
ERROR - 2021-06-02 02:52:28 --> 404 Page Not Found: Karoclient/usersprofile
INFO - 2021-06-02 02:52:32 --> Final output sent to browser
DEBUG - 2021-06-02 02:52:32 --> Total execution time: 3.8824
ERROR - 2021-06-02 02:53:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-02 02:53:12 --> Config Class Initialized
INFO - 2021-06-02 02:53:12 --> Hooks Class Initialized
DEBUG - 2021-06-02 02:53:12 --> UTF-8 Support Enabled
INFO - 2021-06-02 02:53:12 --> Utf8 Class Initialized
INFO - 2021-06-02 02:53:12 --> URI Class Initialized
INFO - 2021-06-02 02:53:12 --> Router Class Initialized
INFO - 2021-06-02 02:53:12 --> Output Class Initialized
INFO - 2021-06-02 02:53:12 --> Security Class Initialized
DEBUG - 2021-06-02 02:53:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 02:53:12 --> Input Class Initialized
INFO - 2021-06-02 02:53:12 --> Language Class Initialized
INFO - 2021-06-02 02:53:12 --> Loader Class Initialized
INFO - 2021-06-02 02:53:12 --> Helper loaded: url_helper
INFO - 2021-06-02 02:53:12 --> Helper loaded: form_helper
INFO - 2021-06-02 02:53:12 --> Helper loaded: common_helper
INFO - 2021-06-02 02:53:12 --> Database Driver Class Initialized
DEBUG - 2021-06-02 02:53:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 02:53:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 02:53:12 --> Controller Class Initialized
INFO - 2021-06-02 02:53:13 --> Form Validation Class Initialized
DEBUG - 2021-06-02 02:53:13 --> Encrypt Class Initialized
INFO - 2021-06-02 02:53:13 --> Model "Patient_model" initialized
INFO - 2021-06-02 02:53:13 --> Model "Patientcase_model" initialized
INFO - 2021-06-02 02:53:13 --> Model "Prefix_master" initialized
INFO - 2021-06-02 02:53:13 --> Model "Users_model" initialized
INFO - 2021-06-02 02:53:13 --> Model "Hospital_model" initialized
INFO - 2021-06-02 02:53:13 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views//patientcase/patient_pdf.php
ERROR - 2021-06-02 02:53:13 --> Severity: error --> Exception: Class 'Mpdf\Mpdf' not found /home1/techywbu/karo.notioninfosoft.com/application/controllers/Patientcase.php 492
ERROR - 2021-06-02 02:53:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-02 02:53:14 --> Config Class Initialized
INFO - 2021-06-02 02:53:14 --> Hooks Class Initialized
DEBUG - 2021-06-02 02:53:14 --> UTF-8 Support Enabled
INFO - 2021-06-02 02:53:14 --> Utf8 Class Initialized
INFO - 2021-06-02 02:53:14 --> URI Class Initialized
INFO - 2021-06-02 02:53:14 --> Router Class Initialized
INFO - 2021-06-02 02:53:14 --> Output Class Initialized
INFO - 2021-06-02 02:53:14 --> Security Class Initialized
DEBUG - 2021-06-02 02:53:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 02:53:14 --> Input Class Initialized
INFO - 2021-06-02 02:53:14 --> Language Class Initialized
ERROR - 2021-06-02 02:53:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-02 02:53:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-02 02:53:52 --> Config Class Initialized
INFO - 2021-06-02 02:53:52 --> Hooks Class Initialized
DEBUG - 2021-06-02 02:53:52 --> UTF-8 Support Enabled
INFO - 2021-06-02 02:53:52 --> Utf8 Class Initialized
INFO - 2021-06-02 02:53:52 --> URI Class Initialized
INFO - 2021-06-02 02:53:52 --> Router Class Initialized
INFO - 2021-06-02 02:53:52 --> Output Class Initialized
INFO - 2021-06-02 02:53:52 --> Security Class Initialized
DEBUG - 2021-06-02 02:53:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 02:53:52 --> Input Class Initialized
INFO - 2021-06-02 02:53:52 --> Language Class Initialized
INFO - 2021-06-02 02:53:52 --> Loader Class Initialized
INFO - 2021-06-02 02:53:52 --> Helper loaded: url_helper
INFO - 2021-06-02 02:53:52 --> Helper loaded: form_helper
INFO - 2021-06-02 02:53:52 --> Helper loaded: common_helper
INFO - 2021-06-02 02:53:52 --> Database Driver Class Initialized
DEBUG - 2021-06-02 02:53:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 02:53:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 02:53:52 --> Controller Class Initialized
INFO - 2021-06-02 02:53:52 --> Form Validation Class Initialized
DEBUG - 2021-06-02 02:53:52 --> Encrypt Class Initialized
INFO - 2021-06-02 02:53:52 --> Model "Patient_model" initialized
INFO - 2021-06-02 02:53:52 --> Model "Patientcase_model" initialized
INFO - 2021-06-02 02:53:52 --> Model "Referredby_model" initialized
INFO - 2021-06-02 02:53:52 --> Model "Prefix_master" initialized
INFO - 2021-06-02 02:53:52 --> Model "Hospital_model" initialized
INFO - 2021-06-02 02:53:52 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/header.php
ERROR - 2021-06-02 02:53:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-02 02:53:52 --> Config Class Initialized
INFO - 2021-06-02 02:53:52 --> Hooks Class Initialized
DEBUG - 2021-06-02 02:53:52 --> UTF-8 Support Enabled
INFO - 2021-06-02 02:53:52 --> Utf8 Class Initialized
INFO - 2021-06-02 02:53:52 --> URI Class Initialized
INFO - 2021-06-02 02:53:52 --> Router Class Initialized
INFO - 2021-06-02 02:53:52 --> Output Class Initialized
INFO - 2021-06-02 02:53:52 --> Security Class Initialized
DEBUG - 2021-06-02 02:53:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 02:53:52 --> Input Class Initialized
INFO - 2021-06-02 02:53:52 --> Language Class Initialized
ERROR - 2021-06-02 02:53:52 --> 404 Page Not Found: Robotstxt/index
INFO - 2021-06-02 02:53:56 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/patient/patientview.php
INFO - 2021-06-02 02:53:56 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/footer.php
INFO - 2021-06-02 02:54:01 --> Final output sent to browser
DEBUG - 2021-06-02 02:54:01 --> Total execution time: 3.8433
ERROR - 2021-06-02 02:54:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-02 02:54:37 --> Config Class Initialized
INFO - 2021-06-02 02:54:37 --> Hooks Class Initialized
DEBUG - 2021-06-02 02:54:37 --> UTF-8 Support Enabled
INFO - 2021-06-02 02:54:37 --> Utf8 Class Initialized
INFO - 2021-06-02 02:54:37 --> URI Class Initialized
INFO - 2021-06-02 02:54:37 --> Router Class Initialized
INFO - 2021-06-02 02:54:37 --> Output Class Initialized
INFO - 2021-06-02 02:54:37 --> Security Class Initialized
DEBUG - 2021-06-02 02:54:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 02:54:37 --> Input Class Initialized
INFO - 2021-06-02 02:54:37 --> Language Class Initialized
INFO - 2021-06-02 02:54:37 --> Loader Class Initialized
INFO - 2021-06-02 02:54:37 --> Helper loaded: url_helper
INFO - 2021-06-02 02:54:37 --> Helper loaded: form_helper
INFO - 2021-06-02 02:54:37 --> Helper loaded: common_helper
INFO - 2021-06-02 02:54:37 --> Database Driver Class Initialized
DEBUG - 2021-06-02 02:54:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 02:54:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 02:54:37 --> Controller Class Initialized
INFO - 2021-06-02 02:54:37 --> Form Validation Class Initialized
DEBUG - 2021-06-02 02:54:37 --> Encrypt Class Initialized
INFO - 2021-06-02 02:54:37 --> Model "Patient_model" initialized
INFO - 2021-06-02 02:54:37 --> Model "Patientcase_model" initialized
INFO - 2021-06-02 02:54:37 --> Model "Prefix_master" initialized
INFO - 2021-06-02 02:54:37 --> Model "Users_model" initialized
INFO - 2021-06-02 02:54:37 --> Model "Hospital_model" initialized
INFO - 2021-06-02 02:54:37 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views//patientcase/patient_pdf.php
ERROR - 2021-06-02 02:54:37 --> Severity: error --> Exception: Class 'Mpdf\Mpdf' not found /home1/techywbu/karo.notioninfosoft.com/application/controllers/Patientcase.php 492
ERROR - 2021-06-02 12:53:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-02 12:53:36 --> Config Class Initialized
INFO - 2021-06-02 12:53:36 --> Hooks Class Initialized
DEBUG - 2021-06-02 12:53:36 --> UTF-8 Support Enabled
INFO - 2021-06-02 12:53:36 --> Utf8 Class Initialized
INFO - 2021-06-02 12:53:36 --> URI Class Initialized
DEBUG - 2021-06-02 12:53:36 --> No URI present. Default controller set.
INFO - 2021-06-02 12:53:36 --> Router Class Initialized
INFO - 2021-06-02 12:53:36 --> Output Class Initialized
INFO - 2021-06-02 12:53:36 --> Security Class Initialized
DEBUG - 2021-06-02 12:53:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 12:53:36 --> Input Class Initialized
INFO - 2021-06-02 12:53:36 --> Language Class Initialized
INFO - 2021-06-02 12:53:36 --> Loader Class Initialized
INFO - 2021-06-02 12:53:36 --> Helper loaded: url_helper
INFO - 2021-06-02 12:53:36 --> Helper loaded: form_helper
INFO - 2021-06-02 12:53:36 --> Helper loaded: common_helper
INFO - 2021-06-02 12:53:36 --> Database Driver Class Initialized
DEBUG - 2021-06-02 12:53:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 12:53:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 12:53:36 --> Controller Class Initialized
INFO - 2021-06-02 12:53:36 --> Form Validation Class Initialized
DEBUG - 2021-06-02 12:53:36 --> Encrypt Class Initialized
DEBUG - 2021-06-02 12:53:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-06-02 12:53:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-06-02 12:53:36 --> Email Class Initialized
INFO - 2021-06-02 12:53:36 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-06-02 12:53:36 --> Calendar Class Initialized
INFO - 2021-06-02 12:53:36 --> Model "Login_model" initialized
INFO - 2021-06-02 12:53:36 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-06-02 12:53:36 --> Final output sent to browser
DEBUG - 2021-06-02 12:53:36 --> Total execution time: 0.0330
ERROR - 2021-06-02 16:55:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-02 16:55:08 --> Config Class Initialized
INFO - 2021-06-02 16:55:08 --> Hooks Class Initialized
DEBUG - 2021-06-02 16:55:08 --> UTF-8 Support Enabled
INFO - 2021-06-02 16:55:08 --> Utf8 Class Initialized
INFO - 2021-06-02 16:55:08 --> URI Class Initialized
DEBUG - 2021-06-02 16:55:08 --> No URI present. Default controller set.
INFO - 2021-06-02 16:55:08 --> Router Class Initialized
INFO - 2021-06-02 16:55:08 --> Output Class Initialized
INFO - 2021-06-02 16:55:08 --> Security Class Initialized
DEBUG - 2021-06-02 16:55:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 16:55:08 --> Input Class Initialized
INFO - 2021-06-02 16:55:08 --> Language Class Initialized
INFO - 2021-06-02 16:55:08 --> Loader Class Initialized
INFO - 2021-06-02 16:55:08 --> Helper loaded: url_helper
INFO - 2021-06-02 16:55:08 --> Helper loaded: form_helper
INFO - 2021-06-02 16:55:08 --> Helper loaded: common_helper
INFO - 2021-06-02 16:55:08 --> Database Driver Class Initialized
DEBUG - 2021-06-02 16:55:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 16:55:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 16:55:08 --> Controller Class Initialized
INFO - 2021-06-02 16:55:08 --> Form Validation Class Initialized
DEBUG - 2021-06-02 16:55:08 --> Encrypt Class Initialized
DEBUG - 2021-06-02 16:55:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-06-02 16:55:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-06-02 16:55:08 --> Email Class Initialized
INFO - 2021-06-02 16:55:08 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-06-02 16:55:08 --> Calendar Class Initialized
INFO - 2021-06-02 16:55:08 --> Model "Login_model" initialized
INFO - 2021-06-02 16:55:08 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-06-02 16:55:08 --> Final output sent to browser
DEBUG - 2021-06-02 16:55:08 --> Total execution time: 0.0345
ERROR - 2021-06-02 16:55:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-02 16:55:08 --> Config Class Initialized
INFO - 2021-06-02 16:55:08 --> Hooks Class Initialized
DEBUG - 2021-06-02 16:55:08 --> UTF-8 Support Enabled
INFO - 2021-06-02 16:55:08 --> Utf8 Class Initialized
INFO - 2021-06-02 16:55:08 --> URI Class Initialized
INFO - 2021-06-02 16:55:08 --> Router Class Initialized
INFO - 2021-06-02 16:55:08 --> Output Class Initialized
INFO - 2021-06-02 16:55:08 --> Security Class Initialized
DEBUG - 2021-06-02 16:55:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 16:55:08 --> Input Class Initialized
INFO - 2021-06-02 16:55:08 --> Language Class Initialized
ERROR - 2021-06-02 16:55:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-02 17:20:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-02 17:20:03 --> Config Class Initialized
INFO - 2021-06-02 17:20:03 --> Hooks Class Initialized
DEBUG - 2021-06-02 17:20:03 --> UTF-8 Support Enabled
INFO - 2021-06-02 17:20:03 --> Utf8 Class Initialized
INFO - 2021-06-02 17:20:03 --> URI Class Initialized
DEBUG - 2021-06-02 17:20:03 --> No URI present. Default controller set.
INFO - 2021-06-02 17:20:03 --> Router Class Initialized
INFO - 2021-06-02 17:20:03 --> Output Class Initialized
INFO - 2021-06-02 17:20:03 --> Security Class Initialized
DEBUG - 2021-06-02 17:20:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 17:20:03 --> Input Class Initialized
INFO - 2021-06-02 17:20:03 --> Language Class Initialized
INFO - 2021-06-02 17:20:03 --> Loader Class Initialized
INFO - 2021-06-02 17:20:03 --> Helper loaded: url_helper
INFO - 2021-06-02 17:20:03 --> Helper loaded: form_helper
INFO - 2021-06-02 17:20:03 --> Helper loaded: common_helper
INFO - 2021-06-02 17:20:03 --> Database Driver Class Initialized
DEBUG - 2021-06-02 17:20:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 17:20:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 17:20:03 --> Controller Class Initialized
INFO - 2021-06-02 17:20:03 --> Form Validation Class Initialized
DEBUG - 2021-06-02 17:20:03 --> Encrypt Class Initialized
DEBUG - 2021-06-02 17:20:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-06-02 17:20:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-06-02 17:20:03 --> Email Class Initialized
INFO - 2021-06-02 17:20:03 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-06-02 17:20:03 --> Calendar Class Initialized
INFO - 2021-06-02 17:20:03 --> Model "Login_model" initialized
INFO - 2021-06-02 17:20:03 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-06-02 17:20:03 --> Final output sent to browser
DEBUG - 2021-06-02 17:20:03 --> Total execution time: 0.0446
ERROR - 2021-06-02 17:20:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-02 17:20:07 --> Config Class Initialized
INFO - 2021-06-02 17:20:07 --> Hooks Class Initialized
DEBUG - 2021-06-02 17:20:07 --> UTF-8 Support Enabled
INFO - 2021-06-02 17:20:07 --> Utf8 Class Initialized
INFO - 2021-06-02 17:20:07 --> URI Class Initialized
DEBUG - 2021-06-02 17:20:07 --> No URI present. Default controller set.
INFO - 2021-06-02 17:20:07 --> Router Class Initialized
INFO - 2021-06-02 17:20:07 --> Output Class Initialized
INFO - 2021-06-02 17:20:07 --> Security Class Initialized
DEBUG - 2021-06-02 17:20:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 17:20:07 --> Input Class Initialized
INFO - 2021-06-02 17:20:07 --> Language Class Initialized
INFO - 2021-06-02 17:20:07 --> Loader Class Initialized
INFO - 2021-06-02 17:20:07 --> Helper loaded: url_helper
INFO - 2021-06-02 17:20:07 --> Helper loaded: form_helper
INFO - 2021-06-02 17:20:07 --> Helper loaded: common_helper
INFO - 2021-06-02 17:20:07 --> Database Driver Class Initialized
DEBUG - 2021-06-02 17:20:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 17:20:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 17:20:07 --> Controller Class Initialized
INFO - 2021-06-02 17:20:07 --> Form Validation Class Initialized
DEBUG - 2021-06-02 17:20:07 --> Encrypt Class Initialized
DEBUG - 2021-06-02 17:20:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-06-02 17:20:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-06-02 17:20:07 --> Email Class Initialized
INFO - 2021-06-02 17:20:08 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-06-02 17:20:08 --> Calendar Class Initialized
INFO - 2021-06-02 17:20:08 --> Model "Login_model" initialized
INFO - 2021-06-02 17:20:08 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-06-02 17:20:08 --> Final output sent to browser
DEBUG - 2021-06-02 17:20:08 --> Total execution time: 0.0174
ERROR - 2021-06-02 17:20:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-02 17:20:08 --> Config Class Initialized
INFO - 2021-06-02 17:20:08 --> Hooks Class Initialized
DEBUG - 2021-06-02 17:20:08 --> UTF-8 Support Enabled
INFO - 2021-06-02 17:20:08 --> Utf8 Class Initialized
INFO - 2021-06-02 17:20:08 --> URI Class Initialized
INFO - 2021-06-02 17:20:08 --> Router Class Initialized
INFO - 2021-06-02 17:20:08 --> Output Class Initialized
INFO - 2021-06-02 17:20:08 --> Security Class Initialized
DEBUG - 2021-06-02 17:20:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 17:20:08 --> Input Class Initialized
INFO - 2021-06-02 17:20:08 --> Language Class Initialized
ERROR - 2021-06-02 17:20:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-02 17:20:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-02 17:20:11 --> Config Class Initialized
INFO - 2021-06-02 17:20:11 --> Hooks Class Initialized
DEBUG - 2021-06-02 17:20:11 --> UTF-8 Support Enabled
INFO - 2021-06-02 17:20:11 --> Utf8 Class Initialized
INFO - 2021-06-02 17:20:11 --> URI Class Initialized
INFO - 2021-06-02 17:20:11 --> Router Class Initialized
INFO - 2021-06-02 17:20:11 --> Output Class Initialized
INFO - 2021-06-02 17:20:11 --> Security Class Initialized
DEBUG - 2021-06-02 17:20:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 17:20:11 --> Input Class Initialized
INFO - 2021-06-02 17:20:11 --> Language Class Initialized
INFO - 2021-06-02 17:20:11 --> Loader Class Initialized
INFO - 2021-06-02 17:20:11 --> Helper loaded: url_helper
INFO - 2021-06-02 17:20:11 --> Helper loaded: form_helper
INFO - 2021-06-02 17:20:11 --> Helper loaded: common_helper
INFO - 2021-06-02 17:20:11 --> Database Driver Class Initialized
DEBUG - 2021-06-02 17:20:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 17:20:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 17:20:11 --> Controller Class Initialized
INFO - 2021-06-02 17:20:11 --> Form Validation Class Initialized
DEBUG - 2021-06-02 17:20:11 --> Encrypt Class Initialized
DEBUG - 2021-06-02 17:20:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-06-02 17:20:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-06-02 17:20:11 --> Email Class Initialized
INFO - 2021-06-02 17:20:11 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-06-02 17:20:11 --> Calendar Class Initialized
INFO - 2021-06-02 17:20:11 --> Model "Login_model" initialized
INFO - 2021-06-02 17:20:11 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2021-06-02 17:20:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-02 17:20:12 --> Config Class Initialized
INFO - 2021-06-02 17:20:12 --> Hooks Class Initialized
DEBUG - 2021-06-02 17:20:12 --> UTF-8 Support Enabled
INFO - 2021-06-02 17:20:12 --> Utf8 Class Initialized
INFO - 2021-06-02 17:20:12 --> URI Class Initialized
INFO - 2021-06-02 17:20:12 --> Router Class Initialized
INFO - 2021-06-02 17:20:12 --> Output Class Initialized
INFO - 2021-06-02 17:20:12 --> Security Class Initialized
DEBUG - 2021-06-02 17:20:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 17:20:12 --> Input Class Initialized
INFO - 2021-06-02 17:20:12 --> Language Class Initialized
INFO - 2021-06-02 17:20:12 --> Loader Class Initialized
INFO - 2021-06-02 17:20:12 --> Helper loaded: url_helper
INFO - 2021-06-02 17:20:12 --> Helper loaded: form_helper
INFO - 2021-06-02 17:20:12 --> Helper loaded: common_helper
INFO - 2021-06-02 17:20:12 --> Database Driver Class Initialized
DEBUG - 2021-06-02 17:20:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 17:20:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 17:20:12 --> Controller Class Initialized
INFO - 2021-06-02 17:20:12 --> Form Validation Class Initialized
DEBUG - 2021-06-02 17:20:12 --> Encrypt Class Initialized
INFO - 2021-06-02 17:20:12 --> Model "Login_model" initialized
INFO - 2021-06-02 17:20:12 --> Model "Dashboard_model" initialized
INFO - 2021-06-02 17:20:12 --> Model "Case_model" initialized
INFO - 2021-06-02 17:20:15 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/header.php
INFO - 2021-06-02 17:20:21 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/dashboard/index.php
INFO - 2021-06-02 17:20:21 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/footer.php
INFO - 2021-06-02 17:20:21 --> Final output sent to browser
DEBUG - 2021-06-02 17:20:21 --> Total execution time: 9.2901
ERROR - 2021-06-02 17:20:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-02 17:20:22 --> Config Class Initialized
INFO - 2021-06-02 17:20:22 --> Hooks Class Initialized
DEBUG - 2021-06-02 17:20:22 --> UTF-8 Support Enabled
INFO - 2021-06-02 17:20:22 --> Utf8 Class Initialized
INFO - 2021-06-02 17:20:22 --> URI Class Initialized
INFO - 2021-06-02 17:20:22 --> Router Class Initialized
INFO - 2021-06-02 17:20:22 --> Output Class Initialized
INFO - 2021-06-02 17:20:22 --> Security Class Initialized
DEBUG - 2021-06-02 17:20:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 17:20:22 --> Input Class Initialized
INFO - 2021-06-02 17:20:22 --> Language Class Initialized
ERROR - 2021-06-02 17:20:22 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-06-02 17:20:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-02 17:20:28 --> Config Class Initialized
INFO - 2021-06-02 17:20:28 --> Hooks Class Initialized
DEBUG - 2021-06-02 17:20:28 --> UTF-8 Support Enabled
INFO - 2021-06-02 17:20:28 --> Utf8 Class Initialized
INFO - 2021-06-02 17:20:28 --> URI Class Initialized
INFO - 2021-06-02 17:20:28 --> Router Class Initialized
INFO - 2021-06-02 17:20:28 --> Output Class Initialized
INFO - 2021-06-02 17:20:28 --> Security Class Initialized
DEBUG - 2021-06-02 17:20:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 17:20:28 --> Input Class Initialized
INFO - 2021-06-02 17:20:28 --> Language Class Initialized
INFO - 2021-06-02 17:20:28 --> Loader Class Initialized
INFO - 2021-06-02 17:20:28 --> Helper loaded: url_helper
INFO - 2021-06-02 17:20:28 --> Helper loaded: form_helper
INFO - 2021-06-02 17:20:28 --> Helper loaded: common_helper
INFO - 2021-06-02 17:20:28 --> Database Driver Class Initialized
DEBUG - 2021-06-02 17:20:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 17:20:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 17:20:28 --> Controller Class Initialized
INFO - 2021-06-02 17:20:28 --> Form Validation Class Initialized
INFO - 2021-06-02 17:20:28 --> Model "Case_model" initialized
INFO - 2021-06-02 17:20:28 --> Model "Hospital_model" initialized
INFO - 2021-06-02 17:20:28 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/header.php
INFO - 2021-06-02 17:20:28 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/transaction/upcomingFollowup.php
INFO - 2021-06-02 17:20:28 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/footer.php
INFO - 2021-06-02 17:20:28 --> Final output sent to browser
DEBUG - 2021-06-02 17:20:28 --> Total execution time: 0.0348
ERROR - 2021-06-02 17:20:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-02 17:20:29 --> Config Class Initialized
INFO - 2021-06-02 17:20:29 --> Hooks Class Initialized
DEBUG - 2021-06-02 17:20:29 --> UTF-8 Support Enabled
INFO - 2021-06-02 17:20:29 --> Utf8 Class Initialized
INFO - 2021-06-02 17:20:29 --> URI Class Initialized
INFO - 2021-06-02 17:20:29 --> Router Class Initialized
INFO - 2021-06-02 17:20:29 --> Output Class Initialized
INFO - 2021-06-02 17:20:29 --> Security Class Initialized
DEBUG - 2021-06-02 17:20:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 17:20:29 --> Input Class Initialized
INFO - 2021-06-02 17:20:29 --> Language Class Initialized
ERROR - 2021-06-02 17:20:29 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-06-02 17:20:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-02 17:20:34 --> Config Class Initialized
INFO - 2021-06-02 17:20:34 --> Hooks Class Initialized
DEBUG - 2021-06-02 17:20:34 --> UTF-8 Support Enabled
INFO - 2021-06-02 17:20:34 --> Utf8 Class Initialized
INFO - 2021-06-02 17:20:34 --> URI Class Initialized
INFO - 2021-06-02 17:20:34 --> Router Class Initialized
INFO - 2021-06-02 17:20:34 --> Output Class Initialized
INFO - 2021-06-02 17:20:34 --> Security Class Initialized
DEBUG - 2021-06-02 17:20:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 17:20:34 --> Input Class Initialized
INFO - 2021-06-02 17:20:34 --> Language Class Initialized
INFO - 2021-06-02 17:20:34 --> Loader Class Initialized
INFO - 2021-06-02 17:20:34 --> Helper loaded: url_helper
INFO - 2021-06-02 17:20:34 --> Helper loaded: form_helper
INFO - 2021-06-02 17:20:34 --> Helper loaded: common_helper
INFO - 2021-06-02 17:20:34 --> Database Driver Class Initialized
DEBUG - 2021-06-02 17:20:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 17:20:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 17:20:34 --> Controller Class Initialized
INFO - 2021-06-02 17:20:34 --> Form Validation Class Initialized
DEBUG - 2021-06-02 17:20:34 --> Encrypt Class Initialized
INFO - 2021-06-02 17:20:34 --> Model "Patient_model" initialized
INFO - 2021-06-02 17:20:34 --> Model "Patientcase_model" initialized
INFO - 2021-06-02 17:20:34 --> Model "Referredby_model" initialized
INFO - 2021-06-02 17:20:34 --> Model "Prefix_master" initialized
INFO - 2021-06-02 17:20:34 --> Model "Hospital_model" initialized
INFO - 2021-06-02 17:20:34 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/header.php
INFO - 2021-06-02 17:20:34 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/patient/patientview.php
INFO - 2021-06-02 17:20:34 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/footer.php
INFO - 2021-06-02 17:20:34 --> Final output sent to browser
DEBUG - 2021-06-02 17:20:34 --> Total execution time: 0.0396
ERROR - 2021-06-02 17:20:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-02 17:20:35 --> Config Class Initialized
INFO - 2021-06-02 17:20:35 --> Hooks Class Initialized
DEBUG - 2021-06-02 17:20:35 --> UTF-8 Support Enabled
INFO - 2021-06-02 17:20:35 --> Utf8 Class Initialized
INFO - 2021-06-02 17:20:35 --> URI Class Initialized
INFO - 2021-06-02 17:20:35 --> Router Class Initialized
INFO - 2021-06-02 17:20:35 --> Output Class Initialized
INFO - 2021-06-02 17:20:35 --> Security Class Initialized
DEBUG - 2021-06-02 17:20:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 17:20:35 --> Input Class Initialized
INFO - 2021-06-02 17:20:35 --> Language Class Initialized
ERROR - 2021-06-02 17:20:35 --> 404 Page Not Found: Karoclient/usersprofile
