<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-10-12 09:39:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-12 09:39:42 --> Config Class Initialized
INFO - 2021-10-12 09:39:42 --> Hooks Class Initialized
DEBUG - 2021-10-12 09:39:42 --> UTF-8 Support Enabled
INFO - 2021-10-12 09:39:42 --> Utf8 Class Initialized
INFO - 2021-10-12 09:39:42 --> URI Class Initialized
INFO - 2021-10-12 09:39:42 --> Router Class Initialized
INFO - 2021-10-12 09:39:42 --> Output Class Initialized
INFO - 2021-10-12 09:39:42 --> Security Class Initialized
DEBUG - 2021-10-12 09:39:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-12 09:39:42 --> Input Class Initialized
INFO - 2021-10-12 09:39:42 --> Language Class Initialized
ERROR - 2021-10-12 09:39:42 --> 404 Page Not Found: _profiler/phpinfo
