<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-06-01 08:03:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-01 08:03:07 --> Config Class Initialized
INFO - 2021-06-01 08:03:07 --> Hooks Class Initialized
DEBUG - 2021-06-01 08:03:07 --> UTF-8 Support Enabled
INFO - 2021-06-01 08:03:07 --> Utf8 Class Initialized
ERROR - 2021-06-01 08:03:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-01 08:03:07 --> URI Class Initialized
INFO - 2021-06-01 08:03:07 --> Config Class Initialized
INFO - 2021-06-01 08:03:07 --> Hooks Class Initialized
DEBUG - 2021-06-01 08:03:07 --> UTF-8 Support Enabled
INFO - 2021-06-01 08:03:07 --> Utf8 Class Initialized
INFO - 2021-06-01 08:03:07 --> URI Class Initialized
INFO - 2021-06-01 08:03:07 --> Router Class Initialized
DEBUG - 2021-06-01 08:03:07 --> No URI present. Default controller set.
INFO - 2021-06-01 08:03:07 --> Router Class Initialized
INFO - 2021-06-01 08:03:07 --> Output Class Initialized
INFO - 2021-06-01 08:03:07 --> Output Class Initialized
INFO - 2021-06-01 08:03:07 --> Security Class Initialized
INFO - 2021-06-01 08:03:07 --> Security Class Initialized
DEBUG - 2021-06-01 08:03:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-01 08:03:07 --> Input Class Initialized
DEBUG - 2021-06-01 08:03:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-01 08:03:07 --> Input Class Initialized
INFO - 2021-06-01 08:03:07 --> Language Class Initialized
INFO - 2021-06-01 08:03:07 --> Language Class Initialized
ERROR - 2021-06-01 08:03:07 --> 404 Page Not Found: Robotstxt/index
INFO - 2021-06-01 08:03:07 --> Loader Class Initialized
INFO - 2021-06-01 08:03:07 --> Helper loaded: url_helper
INFO - 2021-06-01 08:03:07 --> Helper loaded: form_helper
INFO - 2021-06-01 08:03:07 --> Helper loaded: common_helper
INFO - 2021-06-01 08:03:07 --> Database Driver Class Initialized
DEBUG - 2021-06-01 08:03:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-01 08:03:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-01 08:03:07 --> Controller Class Initialized
INFO - 2021-06-01 08:03:07 --> Form Validation Class Initialized
DEBUG - 2021-06-01 08:03:07 --> Encrypt Class Initialized
DEBUG - 2021-06-01 08:03:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-06-01 08:03:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-06-01 08:03:07 --> Email Class Initialized
INFO - 2021-06-01 08:03:07 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-06-01 08:03:07 --> Calendar Class Initialized
INFO - 2021-06-01 08:03:07 --> Model "Login_model" initialized
INFO - 2021-06-01 08:03:07 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-06-01 08:03:07 --> Final output sent to browser
DEBUG - 2021-06-01 08:03:07 --> Total execution time: 0.0371
ERROR - 2021-06-01 14:27:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-01 14:27:54 --> Config Class Initialized
INFO - 2021-06-01 14:27:54 --> Hooks Class Initialized
DEBUG - 2021-06-01 14:27:54 --> UTF-8 Support Enabled
INFO - 2021-06-01 14:27:54 --> Utf8 Class Initialized
INFO - 2021-06-01 14:27:54 --> URI Class Initialized
DEBUG - 2021-06-01 14:27:54 --> No URI present. Default controller set.
INFO - 2021-06-01 14:27:54 --> Router Class Initialized
INFO - 2021-06-01 14:27:54 --> Output Class Initialized
INFO - 2021-06-01 14:27:54 --> Security Class Initialized
DEBUG - 2021-06-01 14:27:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-01 14:27:54 --> Input Class Initialized
INFO - 2021-06-01 14:27:54 --> Language Class Initialized
INFO - 2021-06-01 14:27:54 --> Loader Class Initialized
INFO - 2021-06-01 14:27:54 --> Helper loaded: url_helper
INFO - 2021-06-01 14:27:54 --> Helper loaded: form_helper
INFO - 2021-06-01 14:27:54 --> Helper loaded: common_helper
INFO - 2021-06-01 14:27:54 --> Database Driver Class Initialized
DEBUG - 2021-06-01 14:27:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-01 14:27:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-01 14:27:54 --> Controller Class Initialized
INFO - 2021-06-01 14:27:54 --> Form Validation Class Initialized
DEBUG - 2021-06-01 14:27:54 --> Encrypt Class Initialized
DEBUG - 2021-06-01 14:27:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-06-01 14:27:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-06-01 14:27:54 --> Email Class Initialized
INFO - 2021-06-01 14:27:54 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-06-01 14:27:54 --> Calendar Class Initialized
INFO - 2021-06-01 14:27:54 --> Model "Login_model" initialized
INFO - 2021-06-01 14:27:54 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-06-01 14:27:54 --> Final output sent to browser
DEBUG - 2021-06-01 14:27:54 --> Total execution time: 0.0469
ERROR - 2021-06-01 14:27:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-01 14:27:54 --> Config Class Initialized
INFO - 2021-06-01 14:27:54 --> Hooks Class Initialized
DEBUG - 2021-06-01 14:27:54 --> UTF-8 Support Enabled
INFO - 2021-06-01 14:27:54 --> Utf8 Class Initialized
INFO - 2021-06-01 14:27:54 --> URI Class Initialized
DEBUG - 2021-06-01 14:27:54 --> No URI present. Default controller set.
INFO - 2021-06-01 14:27:54 --> Router Class Initialized
INFO - 2021-06-01 14:27:54 --> Output Class Initialized
INFO - 2021-06-01 14:27:54 --> Security Class Initialized
DEBUG - 2021-06-01 14:27:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-01 14:27:54 --> Input Class Initialized
INFO - 2021-06-01 14:27:54 --> Language Class Initialized
INFO - 2021-06-01 14:27:54 --> Loader Class Initialized
INFO - 2021-06-01 14:27:54 --> Helper loaded: url_helper
INFO - 2021-06-01 14:27:54 --> Helper loaded: form_helper
INFO - 2021-06-01 14:27:54 --> Helper loaded: common_helper
INFO - 2021-06-01 14:27:54 --> Database Driver Class Initialized
DEBUG - 2021-06-01 14:27:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-01 14:27:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-01 14:27:54 --> Controller Class Initialized
INFO - 2021-06-01 14:27:54 --> Form Validation Class Initialized
DEBUG - 2021-06-01 14:27:54 --> Encrypt Class Initialized
DEBUG - 2021-06-01 14:27:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-06-01 14:27:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-06-01 14:27:54 --> Email Class Initialized
INFO - 2021-06-01 14:27:54 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-06-01 14:27:54 --> Calendar Class Initialized
INFO - 2021-06-01 14:27:54 --> Model "Login_model" initialized
INFO - 2021-06-01 14:27:54 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-06-01 14:27:54 --> Final output sent to browser
DEBUG - 2021-06-01 14:27:54 --> Total execution time: 0.0178
ERROR - 2021-06-01 14:27:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-01 14:27:54 --> Config Class Initialized
INFO - 2021-06-01 14:27:54 --> Hooks Class Initialized
DEBUG - 2021-06-01 14:27:54 --> UTF-8 Support Enabled
INFO - 2021-06-01 14:27:54 --> Utf8 Class Initialized
INFO - 2021-06-01 14:27:54 --> URI Class Initialized
INFO - 2021-06-01 14:27:54 --> Router Class Initialized
INFO - 2021-06-01 14:27:54 --> Output Class Initialized
INFO - 2021-06-01 14:27:54 --> Security Class Initialized
DEBUG - 2021-06-01 14:27:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-01 14:27:54 --> Input Class Initialized
INFO - 2021-06-01 14:27:54 --> Language Class Initialized
ERROR - 2021-06-01 14:27:54 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
ERROR - 2021-06-01 14:27:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-01 14:27:55 --> Config Class Initialized
INFO - 2021-06-01 14:27:55 --> Hooks Class Initialized
DEBUG - 2021-06-01 14:27:55 --> UTF-8 Support Enabled
INFO - 2021-06-01 14:27:55 --> Utf8 Class Initialized
INFO - 2021-06-01 14:27:55 --> URI Class Initialized
DEBUG - 2021-06-01 14:27:55 --> No URI present. Default controller set.
INFO - 2021-06-01 14:27:55 --> Router Class Initialized
INFO - 2021-06-01 14:27:55 --> Output Class Initialized
INFO - 2021-06-01 14:27:55 --> Security Class Initialized
DEBUG - 2021-06-01 14:27:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-01 14:27:55 --> Input Class Initialized
INFO - 2021-06-01 14:27:55 --> Language Class Initialized
INFO - 2021-06-01 14:27:55 --> Loader Class Initialized
INFO - 2021-06-01 14:27:55 --> Helper loaded: url_helper
INFO - 2021-06-01 14:27:55 --> Helper loaded: form_helper
INFO - 2021-06-01 14:27:55 --> Helper loaded: common_helper
INFO - 2021-06-01 14:27:55 --> Database Driver Class Initialized
DEBUG - 2021-06-01 14:27:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-01 14:27:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-01 14:27:55 --> Controller Class Initialized
INFO - 2021-06-01 14:27:55 --> Form Validation Class Initialized
DEBUG - 2021-06-01 14:27:55 --> Encrypt Class Initialized
DEBUG - 2021-06-01 14:27:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-06-01 14:27:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-06-01 14:27:55 --> Email Class Initialized
INFO - 2021-06-01 14:27:55 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-06-01 14:27:55 --> Calendar Class Initialized
INFO - 2021-06-01 14:27:55 --> Model "Login_model" initialized
INFO - 2021-06-01 14:27:55 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-06-01 14:27:55 --> Final output sent to browser
DEBUG - 2021-06-01 14:27:55 --> Total execution time: 0.0212
ERROR - 2021-06-01 14:27:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-01 14:27:55 --> Config Class Initialized
INFO - 2021-06-01 14:27:55 --> Hooks Class Initialized
DEBUG - 2021-06-01 14:27:55 --> UTF-8 Support Enabled
INFO - 2021-06-01 14:27:55 --> Utf8 Class Initialized
INFO - 2021-06-01 14:27:55 --> URI Class Initialized
INFO - 2021-06-01 14:27:55 --> Router Class Initialized
INFO - 2021-06-01 14:27:55 --> Output Class Initialized
INFO - 2021-06-01 14:27:55 --> Security Class Initialized
DEBUG - 2021-06-01 14:27:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-01 14:27:55 --> Input Class Initialized
INFO - 2021-06-01 14:27:55 --> Language Class Initialized
ERROR - 2021-06-01 14:27:55 --> 404 Page Not Found: Blog/wp-includes
ERROR - 2021-06-01 14:27:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-01 14:27:56 --> Config Class Initialized
INFO - 2021-06-01 14:27:56 --> Hooks Class Initialized
DEBUG - 2021-06-01 14:27:56 --> UTF-8 Support Enabled
INFO - 2021-06-01 14:27:56 --> Utf8 Class Initialized
INFO - 2021-06-01 14:27:56 --> URI Class Initialized
INFO - 2021-06-01 14:27:56 --> Router Class Initialized
INFO - 2021-06-01 14:27:56 --> Output Class Initialized
INFO - 2021-06-01 14:27:56 --> Security Class Initialized
DEBUG - 2021-06-01 14:27:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-01 14:27:56 --> Input Class Initialized
INFO - 2021-06-01 14:27:56 --> Language Class Initialized
ERROR - 2021-06-01 14:27:56 --> 404 Page Not Found: Web/wp-includes
ERROR - 2021-06-01 14:27:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-01 14:27:56 --> Config Class Initialized
INFO - 2021-06-01 14:27:56 --> Hooks Class Initialized
DEBUG - 2021-06-01 14:27:56 --> UTF-8 Support Enabled
INFO - 2021-06-01 14:27:56 --> Utf8 Class Initialized
INFO - 2021-06-01 14:27:56 --> URI Class Initialized
INFO - 2021-06-01 14:27:56 --> Router Class Initialized
INFO - 2021-06-01 14:27:56 --> Output Class Initialized
INFO - 2021-06-01 14:27:56 --> Security Class Initialized
DEBUG - 2021-06-01 14:27:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-01 14:27:56 --> Input Class Initialized
INFO - 2021-06-01 14:27:56 --> Language Class Initialized
ERROR - 2021-06-01 14:27:56 --> 404 Page Not Found: Wordpress/wp-includes
ERROR - 2021-06-01 14:27:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-01 14:27:56 --> Config Class Initialized
INFO - 2021-06-01 14:27:56 --> Hooks Class Initialized
DEBUG - 2021-06-01 14:27:56 --> UTF-8 Support Enabled
INFO - 2021-06-01 14:27:56 --> Utf8 Class Initialized
INFO - 2021-06-01 14:27:56 --> URI Class Initialized
INFO - 2021-06-01 14:27:56 --> Router Class Initialized
INFO - 2021-06-01 14:27:56 --> Output Class Initialized
INFO - 2021-06-01 14:27:56 --> Security Class Initialized
DEBUG - 2021-06-01 14:27:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-01 14:27:56 --> Input Class Initialized
INFO - 2021-06-01 14:27:56 --> Language Class Initialized
ERROR - 2021-06-01 14:27:56 --> 404 Page Not Found: Website/wp-includes
ERROR - 2021-06-01 14:27:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-01 14:27:56 --> Config Class Initialized
INFO - 2021-06-01 14:27:56 --> Hooks Class Initialized
DEBUG - 2021-06-01 14:27:56 --> UTF-8 Support Enabled
INFO - 2021-06-01 14:27:56 --> Utf8 Class Initialized
INFO - 2021-06-01 14:27:56 --> URI Class Initialized
INFO - 2021-06-01 14:27:56 --> Router Class Initialized
INFO - 2021-06-01 14:27:56 --> Output Class Initialized
INFO - 2021-06-01 14:27:56 --> Security Class Initialized
DEBUG - 2021-06-01 14:27:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-01 14:27:56 --> Input Class Initialized
INFO - 2021-06-01 14:27:56 --> Language Class Initialized
ERROR - 2021-06-01 14:27:56 --> 404 Page Not Found: Wp/wp-includes
ERROR - 2021-06-01 14:27:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-01 14:27:57 --> Config Class Initialized
INFO - 2021-06-01 14:27:57 --> Hooks Class Initialized
DEBUG - 2021-06-01 14:27:57 --> UTF-8 Support Enabled
INFO - 2021-06-01 14:27:57 --> Utf8 Class Initialized
INFO - 2021-06-01 14:27:57 --> URI Class Initialized
INFO - 2021-06-01 14:27:57 --> Router Class Initialized
INFO - 2021-06-01 14:27:57 --> Output Class Initialized
INFO - 2021-06-01 14:27:57 --> Security Class Initialized
DEBUG - 2021-06-01 14:27:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-01 14:27:57 --> Input Class Initialized
INFO - 2021-06-01 14:27:57 --> Language Class Initialized
ERROR - 2021-06-01 14:27:57 --> 404 Page Not Found: News/wp-includes
ERROR - 2021-06-01 14:27:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-01 14:27:57 --> Config Class Initialized
INFO - 2021-06-01 14:27:57 --> Hooks Class Initialized
DEBUG - 2021-06-01 14:27:57 --> UTF-8 Support Enabled
INFO - 2021-06-01 14:27:57 --> Utf8 Class Initialized
INFO - 2021-06-01 14:27:57 --> URI Class Initialized
INFO - 2021-06-01 14:27:57 --> Router Class Initialized
INFO - 2021-06-01 14:27:57 --> Output Class Initialized
INFO - 2021-06-01 14:27:57 --> Security Class Initialized
DEBUG - 2021-06-01 14:27:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-01 14:27:57 --> Input Class Initialized
INFO - 2021-06-01 14:27:57 --> Language Class Initialized
ERROR - 2021-06-01 14:27:57 --> 404 Page Not Found: 2020/wp-includes
ERROR - 2021-06-01 14:27:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-01 14:27:57 --> Config Class Initialized
INFO - 2021-06-01 14:27:57 --> Hooks Class Initialized
DEBUG - 2021-06-01 14:27:57 --> UTF-8 Support Enabled
INFO - 2021-06-01 14:27:57 --> Utf8 Class Initialized
INFO - 2021-06-01 14:27:57 --> URI Class Initialized
INFO - 2021-06-01 14:27:57 --> Router Class Initialized
INFO - 2021-06-01 14:27:57 --> Output Class Initialized
INFO - 2021-06-01 14:27:57 --> Security Class Initialized
DEBUG - 2021-06-01 14:27:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-01 14:27:57 --> Input Class Initialized
INFO - 2021-06-01 14:27:57 --> Language Class Initialized
ERROR - 2021-06-01 14:27:57 --> 404 Page Not Found: 2019/wp-includes
ERROR - 2021-06-01 14:27:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-01 14:27:58 --> Config Class Initialized
INFO - 2021-06-01 14:27:58 --> Hooks Class Initialized
DEBUG - 2021-06-01 14:27:58 --> UTF-8 Support Enabled
INFO - 2021-06-01 14:27:58 --> Utf8 Class Initialized
INFO - 2021-06-01 14:27:58 --> URI Class Initialized
INFO - 2021-06-01 14:27:58 --> Router Class Initialized
INFO - 2021-06-01 14:27:58 --> Output Class Initialized
INFO - 2021-06-01 14:27:58 --> Security Class Initialized
DEBUG - 2021-06-01 14:27:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-01 14:27:58 --> Input Class Initialized
INFO - 2021-06-01 14:27:58 --> Language Class Initialized
ERROR - 2021-06-01 14:27:58 --> 404 Page Not Found: Shop/wp-includes
ERROR - 2021-06-01 14:27:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-01 14:27:58 --> Config Class Initialized
INFO - 2021-06-01 14:27:58 --> Hooks Class Initialized
DEBUG - 2021-06-01 14:27:58 --> UTF-8 Support Enabled
INFO - 2021-06-01 14:27:58 --> Utf8 Class Initialized
INFO - 2021-06-01 14:27:58 --> URI Class Initialized
INFO - 2021-06-01 14:27:58 --> Router Class Initialized
INFO - 2021-06-01 14:27:58 --> Output Class Initialized
INFO - 2021-06-01 14:27:58 --> Security Class Initialized
DEBUG - 2021-06-01 14:27:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-01 14:27:58 --> Input Class Initialized
INFO - 2021-06-01 14:27:58 --> Language Class Initialized
ERROR - 2021-06-01 14:27:58 --> 404 Page Not Found: Wp1/wp-includes
ERROR - 2021-06-01 14:27:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-01 14:27:58 --> Config Class Initialized
INFO - 2021-06-01 14:27:58 --> Hooks Class Initialized
DEBUG - 2021-06-01 14:27:58 --> UTF-8 Support Enabled
INFO - 2021-06-01 14:27:58 --> Utf8 Class Initialized
INFO - 2021-06-01 14:27:58 --> URI Class Initialized
INFO - 2021-06-01 14:27:58 --> Router Class Initialized
INFO - 2021-06-01 14:27:58 --> Output Class Initialized
INFO - 2021-06-01 14:27:58 --> Security Class Initialized
DEBUG - 2021-06-01 14:27:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-01 14:27:58 --> Input Class Initialized
INFO - 2021-06-01 14:27:58 --> Language Class Initialized
ERROR - 2021-06-01 14:27:58 --> 404 Page Not Found: Test/wp-includes
ERROR - 2021-06-01 14:27:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-01 14:27:59 --> Config Class Initialized
INFO - 2021-06-01 14:27:59 --> Hooks Class Initialized
DEBUG - 2021-06-01 14:27:59 --> UTF-8 Support Enabled
INFO - 2021-06-01 14:27:59 --> Utf8 Class Initialized
INFO - 2021-06-01 14:27:59 --> URI Class Initialized
INFO - 2021-06-01 14:27:59 --> Router Class Initialized
INFO - 2021-06-01 14:27:59 --> Output Class Initialized
INFO - 2021-06-01 14:27:59 --> Security Class Initialized
DEBUG - 2021-06-01 14:27:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-01 14:27:59 --> Input Class Initialized
INFO - 2021-06-01 14:27:59 --> Language Class Initialized
ERROR - 2021-06-01 14:27:59 --> 404 Page Not Found: Wp2/wp-includes
ERROR - 2021-06-01 14:27:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-01 14:27:59 --> Config Class Initialized
INFO - 2021-06-01 14:27:59 --> Hooks Class Initialized
DEBUG - 2021-06-01 14:27:59 --> UTF-8 Support Enabled
INFO - 2021-06-01 14:27:59 --> Utf8 Class Initialized
INFO - 2021-06-01 14:27:59 --> URI Class Initialized
INFO - 2021-06-01 14:27:59 --> Router Class Initialized
INFO - 2021-06-01 14:27:59 --> Output Class Initialized
INFO - 2021-06-01 14:27:59 --> Security Class Initialized
DEBUG - 2021-06-01 14:27:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-01 14:27:59 --> Input Class Initialized
INFO - 2021-06-01 14:27:59 --> Language Class Initialized
ERROR - 2021-06-01 14:27:59 --> 404 Page Not Found: Site/wp-includes
ERROR - 2021-06-01 14:27:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-01 14:27:59 --> Config Class Initialized
INFO - 2021-06-01 14:27:59 --> Hooks Class Initialized
DEBUG - 2021-06-01 14:27:59 --> UTF-8 Support Enabled
INFO - 2021-06-01 14:27:59 --> Utf8 Class Initialized
INFO - 2021-06-01 14:27:59 --> URI Class Initialized
INFO - 2021-06-01 14:27:59 --> Router Class Initialized
INFO - 2021-06-01 14:27:59 --> Output Class Initialized
INFO - 2021-06-01 14:27:59 --> Security Class Initialized
DEBUG - 2021-06-01 14:27:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-01 14:27:59 --> Input Class Initialized
INFO - 2021-06-01 14:27:59 --> Language Class Initialized
ERROR - 2021-06-01 14:27:59 --> 404 Page Not Found: Cms/wp-includes
ERROR - 2021-06-01 14:27:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-01 14:27:59 --> Config Class Initialized
INFO - 2021-06-01 14:27:59 --> Hooks Class Initialized
DEBUG - 2021-06-01 14:27:59 --> UTF-8 Support Enabled
INFO - 2021-06-01 14:27:59 --> Utf8 Class Initialized
INFO - 2021-06-01 14:27:59 --> URI Class Initialized
INFO - 2021-06-01 14:27:59 --> Router Class Initialized
INFO - 2021-06-01 14:27:59 --> Output Class Initialized
INFO - 2021-06-01 14:27:59 --> Security Class Initialized
DEBUG - 2021-06-01 14:27:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-01 14:27:59 --> Input Class Initialized
INFO - 2021-06-01 14:27:59 --> Language Class Initialized
ERROR - 2021-06-01 14:27:59 --> 404 Page Not Found: Sito/wp-includes
ERROR - 2021-06-01 14:52:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-01 14:52:32 --> Config Class Initialized
INFO - 2021-06-01 14:52:32 --> Hooks Class Initialized
DEBUG - 2021-06-01 14:52:32 --> UTF-8 Support Enabled
INFO - 2021-06-01 14:52:32 --> Utf8 Class Initialized
INFO - 2021-06-01 14:52:32 --> URI Class Initialized
DEBUG - 2021-06-01 14:52:32 --> No URI present. Default controller set.
INFO - 2021-06-01 14:52:32 --> Router Class Initialized
INFO - 2021-06-01 14:52:32 --> Output Class Initialized
INFO - 2021-06-01 14:52:32 --> Security Class Initialized
DEBUG - 2021-06-01 14:52:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-01 14:52:32 --> Input Class Initialized
INFO - 2021-06-01 14:52:32 --> Language Class Initialized
INFO - 2021-06-01 14:52:32 --> Loader Class Initialized
INFO - 2021-06-01 14:52:32 --> Helper loaded: url_helper
INFO - 2021-06-01 14:52:32 --> Helper loaded: form_helper
INFO - 2021-06-01 14:52:32 --> Helper loaded: common_helper
INFO - 2021-06-01 14:52:32 --> Database Driver Class Initialized
DEBUG - 2021-06-01 14:52:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-01 14:52:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-01 14:52:32 --> Controller Class Initialized
INFO - 2021-06-01 14:52:32 --> Form Validation Class Initialized
DEBUG - 2021-06-01 14:52:32 --> Encrypt Class Initialized
DEBUG - 2021-06-01 14:52:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-06-01 14:52:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-06-01 14:52:32 --> Email Class Initialized
INFO - 2021-06-01 14:52:32 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-06-01 14:52:32 --> Calendar Class Initialized
INFO - 2021-06-01 14:52:32 --> Model "Login_model" initialized
INFO - 2021-06-01 14:52:32 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-06-01 14:52:32 --> Final output sent to browser
DEBUG - 2021-06-01 14:52:32 --> Total execution time: 0.0229
ERROR - 2021-06-01 16:02:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-01 16:02:19 --> Config Class Initialized
INFO - 2021-06-01 16:02:19 --> Hooks Class Initialized
DEBUG - 2021-06-01 16:02:19 --> UTF-8 Support Enabled
INFO - 2021-06-01 16:02:19 --> Utf8 Class Initialized
INFO - 2021-06-01 16:02:19 --> URI Class Initialized
DEBUG - 2021-06-01 16:02:19 --> No URI present. Default controller set.
INFO - 2021-06-01 16:02:19 --> Router Class Initialized
INFO - 2021-06-01 16:02:19 --> Output Class Initialized
INFO - 2021-06-01 16:02:19 --> Security Class Initialized
DEBUG - 2021-06-01 16:02:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-01 16:02:19 --> Input Class Initialized
INFO - 2021-06-01 16:02:19 --> Language Class Initialized
INFO - 2021-06-01 16:02:19 --> Loader Class Initialized
INFO - 2021-06-01 16:02:19 --> Helper loaded: url_helper
INFO - 2021-06-01 16:02:19 --> Helper loaded: form_helper
INFO - 2021-06-01 16:02:19 --> Helper loaded: common_helper
INFO - 2021-06-01 16:02:19 --> Database Driver Class Initialized
DEBUG - 2021-06-01 16:02:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-01 16:02:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-01 16:02:19 --> Controller Class Initialized
INFO - 2021-06-01 16:02:19 --> Form Validation Class Initialized
DEBUG - 2021-06-01 16:02:19 --> Encrypt Class Initialized
DEBUG - 2021-06-01 16:02:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-06-01 16:02:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-06-01 16:02:19 --> Email Class Initialized
INFO - 2021-06-01 16:02:19 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-06-01 16:02:19 --> Calendar Class Initialized
INFO - 2021-06-01 16:02:19 --> Model "Login_model" initialized
INFO - 2021-06-01 16:02:19 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-06-01 16:02:19 --> Final output sent to browser
DEBUG - 2021-06-01 16:02:19 --> Total execution time: 0.0373
ERROR - 2021-06-01 16:02:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-01 16:02:20 --> Config Class Initialized
INFO - 2021-06-01 16:02:20 --> Hooks Class Initialized
DEBUG - 2021-06-01 16:02:20 --> UTF-8 Support Enabled
INFO - 2021-06-01 16:02:20 --> Utf8 Class Initialized
INFO - 2021-06-01 16:02:20 --> URI Class Initialized
INFO - 2021-06-01 16:02:20 --> Router Class Initialized
INFO - 2021-06-01 16:02:20 --> Output Class Initialized
INFO - 2021-06-01 16:02:20 --> Security Class Initialized
DEBUG - 2021-06-01 16:02:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-01 16:02:20 --> Input Class Initialized
INFO - 2021-06-01 16:02:20 --> Language Class Initialized
ERROR - 2021-06-01 16:02:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 16:02:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-01 16:02:20 --> Config Class Initialized
INFO - 2021-06-01 16:02:20 --> Hooks Class Initialized
DEBUG - 2021-06-01 16:02:20 --> UTF-8 Support Enabled
INFO - 2021-06-01 16:02:20 --> Utf8 Class Initialized
INFO - 2021-06-01 16:02:20 --> URI Class Initialized
DEBUG - 2021-06-01 16:02:20 --> No URI present. Default controller set.
INFO - 2021-06-01 16:02:20 --> Router Class Initialized
INFO - 2021-06-01 16:02:20 --> Output Class Initialized
INFO - 2021-06-01 16:02:20 --> Security Class Initialized
DEBUG - 2021-06-01 16:02:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-01 16:02:20 --> Input Class Initialized
INFO - 2021-06-01 16:02:20 --> Language Class Initialized
INFO - 2021-06-01 16:02:20 --> Loader Class Initialized
INFO - 2021-06-01 16:02:20 --> Helper loaded: url_helper
INFO - 2021-06-01 16:02:20 --> Helper loaded: form_helper
INFO - 2021-06-01 16:02:20 --> Helper loaded: common_helper
INFO - 2021-06-01 16:02:20 --> Database Driver Class Initialized
DEBUG - 2021-06-01 16:02:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-01 16:02:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-01 16:02:20 --> Controller Class Initialized
INFO - 2021-06-01 16:02:20 --> Form Validation Class Initialized
DEBUG - 2021-06-01 16:02:20 --> Encrypt Class Initialized
DEBUG - 2021-06-01 16:02:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-06-01 16:02:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-06-01 16:02:20 --> Email Class Initialized
INFO - 2021-06-01 16:02:20 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-06-01 16:02:20 --> Calendar Class Initialized
INFO - 2021-06-01 16:02:20 --> Model "Login_model" initialized
INFO - 2021-06-01 16:02:20 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-06-01 16:02:20 --> Final output sent to browser
DEBUG - 2021-06-01 16:02:20 --> Total execution time: 0.0182
ERROR - 2021-06-01 16:02:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-01 16:02:20 --> Config Class Initialized
INFO - 2021-06-01 16:02:20 --> Hooks Class Initialized
DEBUG - 2021-06-01 16:02:20 --> UTF-8 Support Enabled
INFO - 2021-06-01 16:02:20 --> Utf8 Class Initialized
INFO - 2021-06-01 16:02:20 --> URI Class Initialized
INFO - 2021-06-01 16:02:20 --> Router Class Initialized
INFO - 2021-06-01 16:02:20 --> Output Class Initialized
INFO - 2021-06-01 16:02:20 --> Security Class Initialized
DEBUG - 2021-06-01 16:02:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-01 16:02:20 --> Input Class Initialized
INFO - 2021-06-01 16:02:20 --> Language Class Initialized
ERROR - 2021-06-01 16:02:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 16:02:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-01 16:02:22 --> Config Class Initialized
INFO - 2021-06-01 16:02:22 --> Hooks Class Initialized
DEBUG - 2021-06-01 16:02:22 --> UTF-8 Support Enabled
INFO - 2021-06-01 16:02:22 --> Utf8 Class Initialized
INFO - 2021-06-01 16:02:22 --> URI Class Initialized
INFO - 2021-06-01 16:02:22 --> Router Class Initialized
INFO - 2021-06-01 16:02:22 --> Output Class Initialized
INFO - 2021-06-01 16:02:22 --> Security Class Initialized
DEBUG - 2021-06-01 16:02:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-01 16:02:22 --> Input Class Initialized
INFO - 2021-06-01 16:02:22 --> Language Class Initialized
ERROR - 2021-06-01 16:02:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-01 16:02:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-01 16:02:25 --> Config Class Initialized
INFO - 2021-06-01 16:02:25 --> Hooks Class Initialized
DEBUG - 2021-06-01 16:02:25 --> UTF-8 Support Enabled
INFO - 2021-06-01 16:02:25 --> Utf8 Class Initialized
INFO - 2021-06-01 16:02:25 --> URI Class Initialized
INFO - 2021-06-01 16:02:25 --> Router Class Initialized
INFO - 2021-06-01 16:02:25 --> Output Class Initialized
INFO - 2021-06-01 16:02:25 --> Security Class Initialized
DEBUG - 2021-06-01 16:02:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-01 16:02:25 --> Input Class Initialized
INFO - 2021-06-01 16:02:25 --> Language Class Initialized
INFO - 2021-06-01 16:02:25 --> Loader Class Initialized
INFO - 2021-06-01 16:02:25 --> Helper loaded: url_helper
INFO - 2021-06-01 16:02:25 --> Helper loaded: form_helper
INFO - 2021-06-01 16:02:25 --> Helper loaded: common_helper
INFO - 2021-06-01 16:02:25 --> Database Driver Class Initialized
DEBUG - 2021-06-01 16:02:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-01 16:02:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-01 16:02:25 --> Controller Class Initialized
INFO - 2021-06-01 16:02:25 --> Form Validation Class Initialized
DEBUG - 2021-06-01 16:02:25 --> Encrypt Class Initialized
DEBUG - 2021-06-01 16:02:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-06-01 16:02:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-06-01 16:02:25 --> Email Class Initialized
INFO - 2021-06-01 16:02:25 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-06-01 16:02:25 --> Calendar Class Initialized
INFO - 2021-06-01 16:02:25 --> Model "Login_model" initialized
INFO - 2021-06-01 16:02:25 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2021-06-01 16:02:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-01 16:02:26 --> Config Class Initialized
INFO - 2021-06-01 16:02:26 --> Hooks Class Initialized
DEBUG - 2021-06-01 16:02:26 --> UTF-8 Support Enabled
INFO - 2021-06-01 16:02:26 --> Utf8 Class Initialized
INFO - 2021-06-01 16:02:26 --> URI Class Initialized
INFO - 2021-06-01 16:02:26 --> Router Class Initialized
INFO - 2021-06-01 16:02:26 --> Output Class Initialized
INFO - 2021-06-01 16:02:26 --> Security Class Initialized
DEBUG - 2021-06-01 16:02:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-01 16:02:26 --> Input Class Initialized
INFO - 2021-06-01 16:02:26 --> Language Class Initialized
INFO - 2021-06-01 16:02:26 --> Loader Class Initialized
INFO - 2021-06-01 16:02:26 --> Helper loaded: url_helper
INFO - 2021-06-01 16:02:26 --> Helper loaded: form_helper
INFO - 2021-06-01 16:02:26 --> Helper loaded: common_helper
INFO - 2021-06-01 16:02:26 --> Database Driver Class Initialized
DEBUG - 2021-06-01 16:02:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-01 16:02:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-01 16:02:26 --> Controller Class Initialized
INFO - 2021-06-01 16:02:26 --> Form Validation Class Initialized
DEBUG - 2021-06-01 16:02:26 --> Encrypt Class Initialized
INFO - 2021-06-01 16:02:26 --> Model "Login_model" initialized
INFO - 2021-06-01 16:02:26 --> Model "Dashboard_model" initialized
INFO - 2021-06-01 16:02:26 --> Model "Case_model" initialized
INFO - 2021-06-01 16:02:29 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/header.php
INFO - 2021-06-01 16:02:35 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/dashboard/index.php
INFO - 2021-06-01 16:02:35 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/footer.php
INFO - 2021-06-01 16:02:35 --> Final output sent to browser
DEBUG - 2021-06-01 16:02:35 --> Total execution time: 8.9313
ERROR - 2021-06-01 16:02:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-01 16:02:38 --> Config Class Initialized
INFO - 2021-06-01 16:02:38 --> Hooks Class Initialized
DEBUG - 2021-06-01 16:02:38 --> UTF-8 Support Enabled
INFO - 2021-06-01 16:02:38 --> Utf8 Class Initialized
INFO - 2021-06-01 16:02:38 --> URI Class Initialized
INFO - 2021-06-01 16:02:38 --> Router Class Initialized
INFO - 2021-06-01 16:02:38 --> Output Class Initialized
INFO - 2021-06-01 16:02:38 --> Security Class Initialized
DEBUG - 2021-06-01 16:02:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-01 16:02:38 --> Input Class Initialized
INFO - 2021-06-01 16:02:38 --> Language Class Initialized
ERROR - 2021-06-01 16:02:38 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-06-01 16:33:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-01 16:33:32 --> Config Class Initialized
INFO - 2021-06-01 16:33:32 --> Hooks Class Initialized
DEBUG - 2021-06-01 16:33:32 --> UTF-8 Support Enabled
INFO - 2021-06-01 16:33:32 --> Utf8 Class Initialized
INFO - 2021-06-01 16:33:32 --> URI Class Initialized
INFO - 2021-06-01 16:33:32 --> Router Class Initialized
INFO - 2021-06-01 16:33:32 --> Output Class Initialized
INFO - 2021-06-01 16:33:32 --> Security Class Initialized
DEBUG - 2021-06-01 16:33:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-01 16:33:32 --> Input Class Initialized
INFO - 2021-06-01 16:33:32 --> Language Class Initialized
INFO - 2021-06-01 16:33:32 --> Loader Class Initialized
INFO - 2021-06-01 16:33:32 --> Helper loaded: url_helper
INFO - 2021-06-01 16:33:32 --> Helper loaded: form_helper
INFO - 2021-06-01 16:33:32 --> Helper loaded: common_helper
INFO - 2021-06-01 16:33:32 --> Database Driver Class Initialized
DEBUG - 2021-06-01 16:33:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-01 16:33:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-01 16:33:32 --> Controller Class Initialized
INFO - 2021-06-01 16:33:32 --> Form Validation Class Initialized
DEBUG - 2021-06-01 16:33:32 --> Encrypt Class Initialized
INFO - 2021-06-01 16:33:32 --> Model "Login_model" initialized
INFO - 2021-06-01 16:33:32 --> Model "Dashboard_model" initialized
INFO - 2021-06-01 16:33:32 --> Model "Case_model" initialized
INFO - 2021-06-01 16:33:35 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/header.php
INFO - 2021-06-01 16:33:41 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/dashboard/index.php
INFO - 2021-06-01 16:33:41 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/footer.php
INFO - 2021-06-01 16:33:41 --> Final output sent to browser
DEBUG - 2021-06-01 16:33:41 --> Total execution time: 8.7493
ERROR - 2021-06-01 16:33:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-01 16:33:45 --> Config Class Initialized
INFO - 2021-06-01 16:33:45 --> Hooks Class Initialized
DEBUG - 2021-06-01 16:33:45 --> UTF-8 Support Enabled
INFO - 2021-06-01 16:33:45 --> Utf8 Class Initialized
INFO - 2021-06-01 16:33:45 --> URI Class Initialized
INFO - 2021-06-01 16:33:45 --> Router Class Initialized
INFO - 2021-06-01 16:33:45 --> Output Class Initialized
INFO - 2021-06-01 16:33:45 --> Security Class Initialized
DEBUG - 2021-06-01 16:33:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-01 16:33:45 --> Input Class Initialized
INFO - 2021-06-01 16:33:45 --> Language Class Initialized
ERROR - 2021-06-01 16:33:45 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-06-01 16:34:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-01 16:34:33 --> Config Class Initialized
INFO - 2021-06-01 16:34:33 --> Hooks Class Initialized
DEBUG - 2021-06-01 16:34:33 --> UTF-8 Support Enabled
INFO - 2021-06-01 16:34:33 --> Utf8 Class Initialized
INFO - 2021-06-01 16:34:33 --> URI Class Initialized
INFO - 2021-06-01 16:34:33 --> Router Class Initialized
INFO - 2021-06-01 16:34:33 --> Output Class Initialized
INFO - 2021-06-01 16:34:33 --> Security Class Initialized
DEBUG - 2021-06-01 16:34:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-01 16:34:33 --> Input Class Initialized
INFO - 2021-06-01 16:34:33 --> Language Class Initialized
INFO - 2021-06-01 16:34:33 --> Loader Class Initialized
INFO - 2021-06-01 16:34:33 --> Helper loaded: url_helper
INFO - 2021-06-01 16:34:33 --> Helper loaded: form_helper
INFO - 2021-06-01 16:34:33 --> Helper loaded: common_helper
INFO - 2021-06-01 16:34:33 --> Database Driver Class Initialized
DEBUG - 2021-06-01 16:34:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-01 16:34:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-01 16:34:33 --> Controller Class Initialized
INFO - 2021-06-01 16:34:33 --> Form Validation Class Initialized
INFO - 2021-06-01 16:34:33 --> Model "Report_model" initialized
INFO - 2021-06-01 16:34:33 --> Model "Case_model" initialized
INFO - 2021-06-01 16:34:34 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/header.php
INFO - 2021-06-01 16:34:34 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/reports/filterPatientsDonorWiseFinacialReports.php
INFO - 2021-06-01 16:34:34 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/footer.php
ERROR - 2021-06-01 16:34:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-01 16:34:36 --> Config Class Initialized
INFO - 2021-06-01 16:34:36 --> Hooks Class Initialized
DEBUG - 2021-06-01 16:34:36 --> UTF-8 Support Enabled
INFO - 2021-06-01 16:34:36 --> Utf8 Class Initialized
INFO - 2021-06-01 16:34:36 --> URI Class Initialized
INFO - 2021-06-01 16:34:36 --> Router Class Initialized
INFO - 2021-06-01 16:34:36 --> Output Class Initialized
INFO - 2021-06-01 16:34:36 --> Security Class Initialized
DEBUG - 2021-06-01 16:34:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-01 16:34:36 --> Input Class Initialized
INFO - 2021-06-01 16:34:36 --> Language Class Initialized
ERROR - 2021-06-01 16:34:36 --> 404 Page Not Found: Karoclient/usersprofile
INFO - 2021-06-01 16:34:38 --> Final output sent to browser
DEBUG - 2021-06-01 16:34:38 --> Total execution time: 1.0880
ERROR - 2021-06-01 17:06:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-01 17:06:44 --> Config Class Initialized
INFO - 2021-06-01 17:06:44 --> Hooks Class Initialized
DEBUG - 2021-06-01 17:06:44 --> UTF-8 Support Enabled
INFO - 2021-06-01 17:06:44 --> Utf8 Class Initialized
INFO - 2021-06-01 17:06:44 --> URI Class Initialized
DEBUG - 2021-06-01 17:06:44 --> No URI present. Default controller set.
INFO - 2021-06-01 17:06:44 --> Router Class Initialized
INFO - 2021-06-01 17:06:44 --> Output Class Initialized
INFO - 2021-06-01 17:06:44 --> Security Class Initialized
DEBUG - 2021-06-01 17:06:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-01 17:06:44 --> Input Class Initialized
INFO - 2021-06-01 17:06:44 --> Language Class Initialized
INFO - 2021-06-01 17:06:44 --> Loader Class Initialized
INFO - 2021-06-01 17:06:44 --> Helper loaded: url_helper
INFO - 2021-06-01 17:06:44 --> Helper loaded: form_helper
INFO - 2021-06-01 17:06:44 --> Helper loaded: common_helper
INFO - 2021-06-01 17:06:44 --> Database Driver Class Initialized
DEBUG - 2021-06-01 17:06:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-01 17:06:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-01 17:06:44 --> Controller Class Initialized
INFO - 2021-06-01 17:06:44 --> Form Validation Class Initialized
DEBUG - 2021-06-01 17:06:44 --> Encrypt Class Initialized
DEBUG - 2021-06-01 17:06:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-06-01 17:06:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-06-01 17:06:44 --> Email Class Initialized
INFO - 2021-06-01 17:06:44 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-06-01 17:06:44 --> Calendar Class Initialized
INFO - 2021-06-01 17:06:44 --> Model "Login_model" initialized
INFO - 2021-06-01 17:06:44 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-06-01 17:06:44 --> Final output sent to browser
DEBUG - 2021-06-01 17:06:44 --> Total execution time: 0.0478
ERROR - 2021-06-01 18:11:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-01 18:11:05 --> Config Class Initialized
INFO - 2021-06-01 18:11:05 --> Hooks Class Initialized
DEBUG - 2021-06-01 18:11:05 --> UTF-8 Support Enabled
INFO - 2021-06-01 18:11:05 --> Utf8 Class Initialized
INFO - 2021-06-01 18:11:05 --> URI Class Initialized
DEBUG - 2021-06-01 18:11:05 --> No URI present. Default controller set.
INFO - 2021-06-01 18:11:05 --> Router Class Initialized
INFO - 2021-06-01 18:11:05 --> Output Class Initialized
INFO - 2021-06-01 18:11:05 --> Security Class Initialized
DEBUG - 2021-06-01 18:11:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-01 18:11:05 --> Input Class Initialized
INFO - 2021-06-01 18:11:05 --> Language Class Initialized
INFO - 2021-06-01 18:11:05 --> Loader Class Initialized
INFO - 2021-06-01 18:11:05 --> Helper loaded: url_helper
INFO - 2021-06-01 18:11:05 --> Helper loaded: form_helper
INFO - 2021-06-01 18:11:05 --> Helper loaded: common_helper
INFO - 2021-06-01 18:11:05 --> Database Driver Class Initialized
DEBUG - 2021-06-01 18:11:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-01 18:11:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-01 18:11:05 --> Controller Class Initialized
INFO - 2021-06-01 18:11:05 --> Form Validation Class Initialized
DEBUG - 2021-06-01 18:11:05 --> Encrypt Class Initialized
DEBUG - 2021-06-01 18:11:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-06-01 18:11:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-06-01 18:11:05 --> Email Class Initialized
INFO - 2021-06-01 18:11:05 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-06-01 18:11:05 --> Calendar Class Initialized
INFO - 2021-06-01 18:11:05 --> Model "Login_model" initialized
INFO - 2021-06-01 18:11:05 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-06-01 18:11:05 --> Final output sent to browser
DEBUG - 2021-06-01 18:11:05 --> Total execution time: 0.0419
