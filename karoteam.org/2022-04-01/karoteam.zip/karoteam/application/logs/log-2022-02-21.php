<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-02-21 01:51:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-21 01:51:26 --> Config Class Initialized
INFO - 2022-02-21 01:51:26 --> Hooks Class Initialized
DEBUG - 2022-02-21 01:51:26 --> UTF-8 Support Enabled
INFO - 2022-02-21 01:51:26 --> Utf8 Class Initialized
INFO - 2022-02-21 01:51:26 --> URI Class Initialized
DEBUG - 2022-02-21 01:51:26 --> No URI present. Default controller set.
INFO - 2022-02-21 01:51:26 --> Router Class Initialized
INFO - 2022-02-21 01:51:26 --> Output Class Initialized
INFO - 2022-02-21 01:51:26 --> Security Class Initialized
DEBUG - 2022-02-21 01:51:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-21 01:51:26 --> Input Class Initialized
INFO - 2022-02-21 01:51:26 --> Language Class Initialized
INFO - 2022-02-21 01:51:26 --> Loader Class Initialized
INFO - 2022-02-21 01:51:26 --> Helper loaded: url_helper
INFO - 2022-02-21 01:51:26 --> Helper loaded: form_helper
INFO - 2022-02-21 01:51:26 --> Helper loaded: common_helper
INFO - 2022-02-21 01:51:26 --> Database Driver Class Initialized
DEBUG - 2022-02-21 01:51:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-21 01:51:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-21 01:51:26 --> Controller Class Initialized
INFO - 2022-02-21 01:51:26 --> Form Validation Class Initialized
DEBUG - 2022-02-21 01:51:26 --> Encrypt Class Initialized
DEBUG - 2022-02-21 01:51:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-21 01:51:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-21 01:51:26 --> Email Class Initialized
INFO - 2022-02-21 01:51:26 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-21 01:51:26 --> Calendar Class Initialized
INFO - 2022-02-21 01:51:26 --> Model "Login_model" initialized
INFO - 2022-02-21 01:51:26 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-21 01:51:26 --> Final output sent to browser
DEBUG - 2022-02-21 01:51:26 --> Total execution time: 0.0287
ERROR - 2022-02-21 01:51:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-21 01:51:29 --> Config Class Initialized
INFO - 2022-02-21 01:51:29 --> Hooks Class Initialized
DEBUG - 2022-02-21 01:51:29 --> UTF-8 Support Enabled
INFO - 2022-02-21 01:51:29 --> Utf8 Class Initialized
INFO - 2022-02-21 01:51:29 --> URI Class Initialized
INFO - 2022-02-21 01:51:29 --> Router Class Initialized
INFO - 2022-02-21 01:51:29 --> Output Class Initialized
INFO - 2022-02-21 01:51:29 --> Security Class Initialized
DEBUG - 2022-02-21 01:51:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-21 01:51:29 --> Input Class Initialized
INFO - 2022-02-21 01:51:29 --> Language Class Initialized
ERROR - 2022-02-21 01:51:29 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2022-02-21 03:38:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-21 03:38:02 --> Config Class Initialized
INFO - 2022-02-21 03:38:02 --> Hooks Class Initialized
DEBUG - 2022-02-21 03:38:02 --> UTF-8 Support Enabled
INFO - 2022-02-21 03:38:02 --> Utf8 Class Initialized
INFO - 2022-02-21 03:38:02 --> URI Class Initialized
DEBUG - 2022-02-21 03:38:02 --> No URI present. Default controller set.
INFO - 2022-02-21 03:38:02 --> Router Class Initialized
INFO - 2022-02-21 03:38:02 --> Output Class Initialized
INFO - 2022-02-21 03:38:02 --> Security Class Initialized
DEBUG - 2022-02-21 03:38:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-21 03:38:02 --> Input Class Initialized
INFO - 2022-02-21 03:38:02 --> Language Class Initialized
INFO - 2022-02-21 03:38:02 --> Loader Class Initialized
INFO - 2022-02-21 03:38:02 --> Helper loaded: url_helper
INFO - 2022-02-21 03:38:02 --> Helper loaded: form_helper
INFO - 2022-02-21 03:38:02 --> Helper loaded: common_helper
INFO - 2022-02-21 03:38:02 --> Database Driver Class Initialized
DEBUG - 2022-02-21 03:38:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-21 03:38:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-21 03:38:02 --> Controller Class Initialized
INFO - 2022-02-21 03:38:02 --> Form Validation Class Initialized
DEBUG - 2022-02-21 03:38:02 --> Encrypt Class Initialized
DEBUG - 2022-02-21 03:38:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-21 03:38:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-21 03:38:02 --> Email Class Initialized
INFO - 2022-02-21 03:38:02 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-21 03:38:02 --> Calendar Class Initialized
INFO - 2022-02-21 03:38:02 --> Model "Login_model" initialized
INFO - 2022-02-21 03:38:02 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-21 03:38:02 --> Final output sent to browser
DEBUG - 2022-02-21 03:38:02 --> Total execution time: 0.0498
ERROR - 2022-02-21 03:42:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-21 03:42:50 --> Config Class Initialized
INFO - 2022-02-21 03:42:50 --> Hooks Class Initialized
DEBUG - 2022-02-21 03:42:50 --> UTF-8 Support Enabled
INFO - 2022-02-21 03:42:50 --> Utf8 Class Initialized
INFO - 2022-02-21 03:42:50 --> URI Class Initialized
DEBUG - 2022-02-21 03:42:50 --> No URI present. Default controller set.
INFO - 2022-02-21 03:42:50 --> Router Class Initialized
INFO - 2022-02-21 03:42:50 --> Output Class Initialized
INFO - 2022-02-21 03:42:50 --> Security Class Initialized
DEBUG - 2022-02-21 03:42:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-21 03:42:50 --> Input Class Initialized
INFO - 2022-02-21 03:42:50 --> Language Class Initialized
INFO - 2022-02-21 03:42:50 --> Loader Class Initialized
INFO - 2022-02-21 03:42:50 --> Helper loaded: url_helper
INFO - 2022-02-21 03:42:50 --> Helper loaded: form_helper
INFO - 2022-02-21 03:42:50 --> Helper loaded: common_helper
INFO - 2022-02-21 03:42:50 --> Database Driver Class Initialized
DEBUG - 2022-02-21 03:42:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-21 03:42:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-21 03:42:50 --> Controller Class Initialized
INFO - 2022-02-21 03:42:50 --> Form Validation Class Initialized
DEBUG - 2022-02-21 03:42:50 --> Encrypt Class Initialized
DEBUG - 2022-02-21 03:42:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-21 03:42:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-21 03:42:50 --> Email Class Initialized
INFO - 2022-02-21 03:42:50 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-21 03:42:50 --> Calendar Class Initialized
INFO - 2022-02-21 03:42:50 --> Model "Login_model" initialized
INFO - 2022-02-21 03:42:50 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-21 03:42:50 --> Final output sent to browser
DEBUG - 2022-02-21 03:42:50 --> Total execution time: 0.0237
ERROR - 2022-02-21 09:15:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-21 09:15:41 --> Config Class Initialized
INFO - 2022-02-21 09:15:41 --> Hooks Class Initialized
DEBUG - 2022-02-21 09:15:41 --> UTF-8 Support Enabled
INFO - 2022-02-21 09:15:41 --> Utf8 Class Initialized
INFO - 2022-02-21 09:15:41 --> URI Class Initialized
DEBUG - 2022-02-21 09:15:41 --> No URI present. Default controller set.
INFO - 2022-02-21 09:15:41 --> Router Class Initialized
INFO - 2022-02-21 09:15:41 --> Output Class Initialized
INFO - 2022-02-21 09:15:41 --> Security Class Initialized
DEBUG - 2022-02-21 09:15:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-21 09:15:41 --> Input Class Initialized
INFO - 2022-02-21 09:15:41 --> Language Class Initialized
INFO - 2022-02-21 09:15:41 --> Loader Class Initialized
INFO - 2022-02-21 09:15:41 --> Helper loaded: url_helper
INFO - 2022-02-21 09:15:41 --> Helper loaded: form_helper
INFO - 2022-02-21 09:15:41 --> Helper loaded: common_helper
INFO - 2022-02-21 09:15:41 --> Database Driver Class Initialized
DEBUG - 2022-02-21 09:15:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-21 09:15:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-21 09:15:41 --> Controller Class Initialized
INFO - 2022-02-21 09:15:41 --> Form Validation Class Initialized
DEBUG - 2022-02-21 09:15:41 --> Encrypt Class Initialized
DEBUG - 2022-02-21 09:15:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-21 09:15:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-21 09:15:41 --> Email Class Initialized
INFO - 2022-02-21 09:15:41 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-21 09:15:41 --> Calendar Class Initialized
INFO - 2022-02-21 09:15:41 --> Model "Login_model" initialized
INFO - 2022-02-21 09:15:41 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-21 09:15:41 --> Final output sent to browser
DEBUG - 2022-02-21 09:15:41 --> Total execution time: 0.0269
ERROR - 2022-02-21 10:09:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-21 10:09:13 --> Config Class Initialized
INFO - 2022-02-21 10:09:13 --> Hooks Class Initialized
DEBUG - 2022-02-21 10:09:13 --> UTF-8 Support Enabled
INFO - 2022-02-21 10:09:13 --> Utf8 Class Initialized
INFO - 2022-02-21 10:09:13 --> URI Class Initialized
DEBUG - 2022-02-21 10:09:13 --> No URI present. Default controller set.
INFO - 2022-02-21 10:09:13 --> Router Class Initialized
INFO - 2022-02-21 10:09:13 --> Output Class Initialized
INFO - 2022-02-21 10:09:13 --> Security Class Initialized
DEBUG - 2022-02-21 10:09:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-21 10:09:13 --> Input Class Initialized
INFO - 2022-02-21 10:09:13 --> Language Class Initialized
INFO - 2022-02-21 10:09:13 --> Loader Class Initialized
INFO - 2022-02-21 10:09:13 --> Helper loaded: url_helper
INFO - 2022-02-21 10:09:13 --> Helper loaded: form_helper
INFO - 2022-02-21 10:09:13 --> Helper loaded: common_helper
INFO - 2022-02-21 10:09:13 --> Database Driver Class Initialized
DEBUG - 2022-02-21 10:09:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-21 10:09:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-21 10:09:13 --> Controller Class Initialized
INFO - 2022-02-21 10:09:13 --> Form Validation Class Initialized
DEBUG - 2022-02-21 10:09:13 --> Encrypt Class Initialized
DEBUG - 2022-02-21 10:09:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-21 10:09:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-21 10:09:13 --> Email Class Initialized
INFO - 2022-02-21 10:09:13 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-21 10:09:13 --> Calendar Class Initialized
INFO - 2022-02-21 10:09:13 --> Model "Login_model" initialized
INFO - 2022-02-21 10:09:13 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-21 10:09:13 --> Final output sent to browser
DEBUG - 2022-02-21 10:09:13 --> Total execution time: 0.0289
ERROR - 2022-02-21 10:09:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-21 10:09:14 --> Config Class Initialized
INFO - 2022-02-21 10:09:14 --> Hooks Class Initialized
DEBUG - 2022-02-21 10:09:14 --> UTF-8 Support Enabled
INFO - 2022-02-21 10:09:14 --> Utf8 Class Initialized
INFO - 2022-02-21 10:09:14 --> URI Class Initialized
DEBUG - 2022-02-21 10:09:14 --> No URI present. Default controller set.
INFO - 2022-02-21 10:09:14 --> Router Class Initialized
INFO - 2022-02-21 10:09:14 --> Output Class Initialized
INFO - 2022-02-21 10:09:14 --> Security Class Initialized
DEBUG - 2022-02-21 10:09:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-21 10:09:14 --> Input Class Initialized
INFO - 2022-02-21 10:09:14 --> Language Class Initialized
INFO - 2022-02-21 10:09:14 --> Loader Class Initialized
INFO - 2022-02-21 10:09:14 --> Helper loaded: url_helper
INFO - 2022-02-21 10:09:14 --> Helper loaded: form_helper
INFO - 2022-02-21 10:09:14 --> Helper loaded: common_helper
INFO - 2022-02-21 10:09:14 --> Database Driver Class Initialized
DEBUG - 2022-02-21 10:09:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-21 10:09:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-21 10:09:14 --> Controller Class Initialized
INFO - 2022-02-21 10:09:14 --> Form Validation Class Initialized
DEBUG - 2022-02-21 10:09:14 --> Encrypt Class Initialized
DEBUG - 2022-02-21 10:09:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-21 10:09:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-21 10:09:14 --> Email Class Initialized
INFO - 2022-02-21 10:09:14 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-21 10:09:14 --> Calendar Class Initialized
INFO - 2022-02-21 10:09:14 --> Model "Login_model" initialized
INFO - 2022-02-21 10:09:14 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-21 10:09:14 --> Final output sent to browser
DEBUG - 2022-02-21 10:09:14 --> Total execution time: 0.0229
ERROR - 2022-02-21 10:09:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-21 10:09:15 --> Config Class Initialized
INFO - 2022-02-21 10:09:15 --> Hooks Class Initialized
DEBUG - 2022-02-21 10:09:15 --> UTF-8 Support Enabled
INFO - 2022-02-21 10:09:15 --> Utf8 Class Initialized
INFO - 2022-02-21 10:09:15 --> URI Class Initialized
DEBUG - 2022-02-21 10:09:15 --> No URI present. Default controller set.
INFO - 2022-02-21 10:09:15 --> Router Class Initialized
INFO - 2022-02-21 10:09:15 --> Output Class Initialized
INFO - 2022-02-21 10:09:15 --> Security Class Initialized
DEBUG - 2022-02-21 10:09:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-21 10:09:15 --> Input Class Initialized
INFO - 2022-02-21 10:09:15 --> Language Class Initialized
INFO - 2022-02-21 10:09:15 --> Loader Class Initialized
INFO - 2022-02-21 10:09:15 --> Helper loaded: url_helper
INFO - 2022-02-21 10:09:15 --> Helper loaded: form_helper
INFO - 2022-02-21 10:09:15 --> Helper loaded: common_helper
INFO - 2022-02-21 10:09:15 --> Database Driver Class Initialized
DEBUG - 2022-02-21 10:09:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-21 10:09:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-21 10:09:15 --> Controller Class Initialized
INFO - 2022-02-21 10:09:15 --> Form Validation Class Initialized
DEBUG - 2022-02-21 10:09:15 --> Encrypt Class Initialized
DEBUG - 2022-02-21 10:09:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-21 10:09:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-21 10:09:15 --> Email Class Initialized
INFO - 2022-02-21 10:09:15 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-21 10:09:15 --> Calendar Class Initialized
INFO - 2022-02-21 10:09:15 --> Model "Login_model" initialized
INFO - 2022-02-21 10:09:15 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-21 10:09:15 --> Final output sent to browser
DEBUG - 2022-02-21 10:09:15 --> Total execution time: 0.0349
ERROR - 2022-02-21 10:09:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-21 10:09:16 --> Config Class Initialized
INFO - 2022-02-21 10:09:16 --> Hooks Class Initialized
DEBUG - 2022-02-21 10:09:16 --> UTF-8 Support Enabled
INFO - 2022-02-21 10:09:16 --> Utf8 Class Initialized
INFO - 2022-02-21 10:09:16 --> URI Class Initialized
INFO - 2022-02-21 10:09:16 --> Router Class Initialized
INFO - 2022-02-21 10:09:16 --> Output Class Initialized
INFO - 2022-02-21 10:09:16 --> Security Class Initialized
DEBUG - 2022-02-21 10:09:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-21 10:09:16 --> Input Class Initialized
INFO - 2022-02-21 10:09:16 --> Language Class Initialized
ERROR - 2022-02-21 10:09:16 --> 404 Page Not Found: Blog/wp-includes
ERROR - 2022-02-21 10:09:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-21 10:09:16 --> Config Class Initialized
INFO - 2022-02-21 10:09:16 --> Hooks Class Initialized
DEBUG - 2022-02-21 10:09:16 --> UTF-8 Support Enabled
INFO - 2022-02-21 10:09:16 --> Utf8 Class Initialized
INFO - 2022-02-21 10:09:16 --> URI Class Initialized
INFO - 2022-02-21 10:09:16 --> Router Class Initialized
INFO - 2022-02-21 10:09:16 --> Output Class Initialized
INFO - 2022-02-21 10:09:16 --> Security Class Initialized
DEBUG - 2022-02-21 10:09:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-21 10:09:16 --> Input Class Initialized
INFO - 2022-02-21 10:09:16 --> Language Class Initialized
ERROR - 2022-02-21 10:09:16 --> 404 Page Not Found: Web/wp-includes
ERROR - 2022-02-21 10:09:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-21 10:09:17 --> Config Class Initialized
INFO - 2022-02-21 10:09:17 --> Hooks Class Initialized
DEBUG - 2022-02-21 10:09:17 --> UTF-8 Support Enabled
INFO - 2022-02-21 10:09:17 --> Utf8 Class Initialized
INFO - 2022-02-21 10:09:17 --> URI Class Initialized
INFO - 2022-02-21 10:09:17 --> Router Class Initialized
INFO - 2022-02-21 10:09:17 --> Output Class Initialized
INFO - 2022-02-21 10:09:17 --> Security Class Initialized
DEBUG - 2022-02-21 10:09:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-21 10:09:17 --> Input Class Initialized
INFO - 2022-02-21 10:09:17 --> Language Class Initialized
ERROR - 2022-02-21 10:09:17 --> 404 Page Not Found: Wordpress/wp-includes
ERROR - 2022-02-21 10:09:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-21 10:09:18 --> Config Class Initialized
INFO - 2022-02-21 10:09:18 --> Hooks Class Initialized
DEBUG - 2022-02-21 10:09:18 --> UTF-8 Support Enabled
INFO - 2022-02-21 10:09:18 --> Utf8 Class Initialized
INFO - 2022-02-21 10:09:18 --> URI Class Initialized
INFO - 2022-02-21 10:09:18 --> Router Class Initialized
INFO - 2022-02-21 10:09:18 --> Output Class Initialized
INFO - 2022-02-21 10:09:18 --> Security Class Initialized
DEBUG - 2022-02-21 10:09:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-21 10:09:18 --> Input Class Initialized
INFO - 2022-02-21 10:09:18 --> Language Class Initialized
ERROR - 2022-02-21 10:09:18 --> 404 Page Not Found: Website/wp-includes
ERROR - 2022-02-21 10:09:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-21 10:09:18 --> Config Class Initialized
INFO - 2022-02-21 10:09:18 --> Hooks Class Initialized
DEBUG - 2022-02-21 10:09:18 --> UTF-8 Support Enabled
INFO - 2022-02-21 10:09:18 --> Utf8 Class Initialized
INFO - 2022-02-21 10:09:18 --> URI Class Initialized
INFO - 2022-02-21 10:09:18 --> Router Class Initialized
INFO - 2022-02-21 10:09:18 --> Output Class Initialized
INFO - 2022-02-21 10:09:18 --> Security Class Initialized
DEBUG - 2022-02-21 10:09:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-21 10:09:18 --> Input Class Initialized
INFO - 2022-02-21 10:09:18 --> Language Class Initialized
ERROR - 2022-02-21 10:09:18 --> 404 Page Not Found: Wp/wp-includes
ERROR - 2022-02-21 10:09:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-21 10:09:19 --> Config Class Initialized
INFO - 2022-02-21 10:09:19 --> Hooks Class Initialized
DEBUG - 2022-02-21 10:09:19 --> UTF-8 Support Enabled
INFO - 2022-02-21 10:09:19 --> Utf8 Class Initialized
INFO - 2022-02-21 10:09:19 --> URI Class Initialized
INFO - 2022-02-21 10:09:19 --> Router Class Initialized
INFO - 2022-02-21 10:09:19 --> Output Class Initialized
INFO - 2022-02-21 10:09:19 --> Security Class Initialized
DEBUG - 2022-02-21 10:09:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-21 10:09:19 --> Input Class Initialized
INFO - 2022-02-21 10:09:19 --> Language Class Initialized
ERROR - 2022-02-21 10:09:19 --> 404 Page Not Found: News/wp-includes
ERROR - 2022-02-21 10:09:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-21 10:09:19 --> Config Class Initialized
INFO - 2022-02-21 10:09:19 --> Hooks Class Initialized
DEBUG - 2022-02-21 10:09:19 --> UTF-8 Support Enabled
INFO - 2022-02-21 10:09:19 --> Utf8 Class Initialized
INFO - 2022-02-21 10:09:19 --> URI Class Initialized
INFO - 2022-02-21 10:09:19 --> Router Class Initialized
INFO - 2022-02-21 10:09:19 --> Output Class Initialized
INFO - 2022-02-21 10:09:19 --> Security Class Initialized
DEBUG - 2022-02-21 10:09:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-21 10:09:19 --> Input Class Initialized
INFO - 2022-02-21 10:09:19 --> Language Class Initialized
ERROR - 2022-02-21 10:09:19 --> 404 Page Not Found: 2018/wp-includes
ERROR - 2022-02-21 10:09:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-21 10:09:20 --> Config Class Initialized
INFO - 2022-02-21 10:09:20 --> Hooks Class Initialized
DEBUG - 2022-02-21 10:09:20 --> UTF-8 Support Enabled
INFO - 2022-02-21 10:09:20 --> Utf8 Class Initialized
INFO - 2022-02-21 10:09:20 --> URI Class Initialized
INFO - 2022-02-21 10:09:20 --> Router Class Initialized
INFO - 2022-02-21 10:09:20 --> Output Class Initialized
INFO - 2022-02-21 10:09:20 --> Security Class Initialized
DEBUG - 2022-02-21 10:09:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-21 10:09:20 --> Input Class Initialized
INFO - 2022-02-21 10:09:20 --> Language Class Initialized
ERROR - 2022-02-21 10:09:20 --> 404 Page Not Found: 2019/wp-includes
ERROR - 2022-02-21 10:09:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-21 10:09:21 --> Config Class Initialized
INFO - 2022-02-21 10:09:21 --> Hooks Class Initialized
DEBUG - 2022-02-21 10:09:21 --> UTF-8 Support Enabled
INFO - 2022-02-21 10:09:21 --> Utf8 Class Initialized
INFO - 2022-02-21 10:09:21 --> URI Class Initialized
INFO - 2022-02-21 10:09:21 --> Router Class Initialized
INFO - 2022-02-21 10:09:21 --> Output Class Initialized
INFO - 2022-02-21 10:09:21 --> Security Class Initialized
DEBUG - 2022-02-21 10:09:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-21 10:09:21 --> Input Class Initialized
INFO - 2022-02-21 10:09:21 --> Language Class Initialized
ERROR - 2022-02-21 10:09:21 --> 404 Page Not Found: Shop/wp-includes
ERROR - 2022-02-21 10:09:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-21 10:09:21 --> Config Class Initialized
INFO - 2022-02-21 10:09:21 --> Hooks Class Initialized
DEBUG - 2022-02-21 10:09:21 --> UTF-8 Support Enabled
INFO - 2022-02-21 10:09:21 --> Utf8 Class Initialized
INFO - 2022-02-21 10:09:21 --> URI Class Initialized
INFO - 2022-02-21 10:09:21 --> Router Class Initialized
INFO - 2022-02-21 10:09:21 --> Output Class Initialized
INFO - 2022-02-21 10:09:21 --> Security Class Initialized
DEBUG - 2022-02-21 10:09:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-21 10:09:21 --> Input Class Initialized
INFO - 2022-02-21 10:09:21 --> Language Class Initialized
ERROR - 2022-02-21 10:09:21 --> 404 Page Not Found: Wp1/wp-includes
ERROR - 2022-02-21 10:09:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-21 10:09:22 --> Config Class Initialized
INFO - 2022-02-21 10:09:22 --> Hooks Class Initialized
DEBUG - 2022-02-21 10:09:22 --> UTF-8 Support Enabled
INFO - 2022-02-21 10:09:22 --> Utf8 Class Initialized
INFO - 2022-02-21 10:09:22 --> URI Class Initialized
INFO - 2022-02-21 10:09:22 --> Router Class Initialized
INFO - 2022-02-21 10:09:22 --> Output Class Initialized
INFO - 2022-02-21 10:09:22 --> Security Class Initialized
DEBUG - 2022-02-21 10:09:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-21 10:09:22 --> Input Class Initialized
INFO - 2022-02-21 10:09:22 --> Language Class Initialized
ERROR - 2022-02-21 10:09:22 --> 404 Page Not Found: Test/wp-includes
ERROR - 2022-02-21 10:09:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-21 10:09:22 --> Config Class Initialized
INFO - 2022-02-21 10:09:22 --> Hooks Class Initialized
DEBUG - 2022-02-21 10:09:22 --> UTF-8 Support Enabled
INFO - 2022-02-21 10:09:22 --> Utf8 Class Initialized
INFO - 2022-02-21 10:09:22 --> URI Class Initialized
INFO - 2022-02-21 10:09:22 --> Router Class Initialized
INFO - 2022-02-21 10:09:22 --> Output Class Initialized
INFO - 2022-02-21 10:09:22 --> Security Class Initialized
DEBUG - 2022-02-21 10:09:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-21 10:09:22 --> Input Class Initialized
INFO - 2022-02-21 10:09:22 --> Language Class Initialized
ERROR - 2022-02-21 10:09:22 --> 404 Page Not Found: Media/wp-includes
ERROR - 2022-02-21 10:09:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-21 10:09:23 --> Config Class Initialized
INFO - 2022-02-21 10:09:23 --> Hooks Class Initialized
DEBUG - 2022-02-21 10:09:23 --> UTF-8 Support Enabled
INFO - 2022-02-21 10:09:23 --> Utf8 Class Initialized
INFO - 2022-02-21 10:09:23 --> URI Class Initialized
INFO - 2022-02-21 10:09:23 --> Router Class Initialized
INFO - 2022-02-21 10:09:23 --> Output Class Initialized
INFO - 2022-02-21 10:09:23 --> Security Class Initialized
DEBUG - 2022-02-21 10:09:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-21 10:09:23 --> Input Class Initialized
INFO - 2022-02-21 10:09:23 --> Language Class Initialized
ERROR - 2022-02-21 10:09:23 --> 404 Page Not Found: Wp2/wp-includes
ERROR - 2022-02-21 10:09:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-21 10:09:24 --> Config Class Initialized
INFO - 2022-02-21 10:09:24 --> Hooks Class Initialized
DEBUG - 2022-02-21 10:09:24 --> UTF-8 Support Enabled
INFO - 2022-02-21 10:09:24 --> Utf8 Class Initialized
INFO - 2022-02-21 10:09:24 --> URI Class Initialized
INFO - 2022-02-21 10:09:24 --> Router Class Initialized
INFO - 2022-02-21 10:09:24 --> Output Class Initialized
INFO - 2022-02-21 10:09:24 --> Security Class Initialized
DEBUG - 2022-02-21 10:09:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-21 10:09:24 --> Input Class Initialized
INFO - 2022-02-21 10:09:24 --> Language Class Initialized
ERROR - 2022-02-21 10:09:24 --> 404 Page Not Found: Site/wp-includes
ERROR - 2022-02-21 10:09:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-21 10:09:24 --> Config Class Initialized
INFO - 2022-02-21 10:09:24 --> Hooks Class Initialized
DEBUG - 2022-02-21 10:09:24 --> UTF-8 Support Enabled
INFO - 2022-02-21 10:09:24 --> Utf8 Class Initialized
INFO - 2022-02-21 10:09:24 --> URI Class Initialized
INFO - 2022-02-21 10:09:24 --> Router Class Initialized
INFO - 2022-02-21 10:09:24 --> Output Class Initialized
INFO - 2022-02-21 10:09:24 --> Security Class Initialized
DEBUG - 2022-02-21 10:09:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-21 10:09:24 --> Input Class Initialized
INFO - 2022-02-21 10:09:24 --> Language Class Initialized
ERROR - 2022-02-21 10:09:24 --> 404 Page Not Found: Cms/wp-includes
ERROR - 2022-02-21 10:09:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-21 10:09:25 --> Config Class Initialized
INFO - 2022-02-21 10:09:25 --> Hooks Class Initialized
DEBUG - 2022-02-21 10:09:25 --> UTF-8 Support Enabled
INFO - 2022-02-21 10:09:25 --> Utf8 Class Initialized
INFO - 2022-02-21 10:09:25 --> URI Class Initialized
INFO - 2022-02-21 10:09:25 --> Router Class Initialized
INFO - 2022-02-21 10:09:25 --> Output Class Initialized
INFO - 2022-02-21 10:09:25 --> Security Class Initialized
DEBUG - 2022-02-21 10:09:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-21 10:09:25 --> Input Class Initialized
INFO - 2022-02-21 10:09:25 --> Language Class Initialized
ERROR - 2022-02-21 10:09:25 --> 404 Page Not Found: Sito/wp-includes
ERROR - 2022-02-21 10:34:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-21 10:34:48 --> Config Class Initialized
INFO - 2022-02-21 10:34:48 --> Hooks Class Initialized
DEBUG - 2022-02-21 10:34:48 --> UTF-8 Support Enabled
INFO - 2022-02-21 10:34:48 --> Utf8 Class Initialized
INFO - 2022-02-21 10:34:48 --> URI Class Initialized
DEBUG - 2022-02-21 10:34:48 --> No URI present. Default controller set.
INFO - 2022-02-21 10:34:48 --> Router Class Initialized
INFO - 2022-02-21 10:34:48 --> Output Class Initialized
INFO - 2022-02-21 10:34:48 --> Security Class Initialized
DEBUG - 2022-02-21 10:34:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-21 10:34:48 --> Input Class Initialized
INFO - 2022-02-21 10:34:48 --> Language Class Initialized
INFO - 2022-02-21 10:34:48 --> Loader Class Initialized
INFO - 2022-02-21 10:34:48 --> Helper loaded: url_helper
INFO - 2022-02-21 10:34:48 --> Helper loaded: form_helper
INFO - 2022-02-21 10:34:48 --> Helper loaded: common_helper
INFO - 2022-02-21 10:34:48 --> Database Driver Class Initialized
DEBUG - 2022-02-21 10:34:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-21 10:34:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-21 10:34:48 --> Controller Class Initialized
INFO - 2022-02-21 10:34:48 --> Form Validation Class Initialized
DEBUG - 2022-02-21 10:34:48 --> Encrypt Class Initialized
DEBUG - 2022-02-21 10:34:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-21 10:34:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-21 10:34:48 --> Email Class Initialized
INFO - 2022-02-21 10:34:48 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-21 10:34:48 --> Calendar Class Initialized
INFO - 2022-02-21 10:34:48 --> Model "Login_model" initialized
INFO - 2022-02-21 10:34:48 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-21 10:34:48 --> Final output sent to browser
DEBUG - 2022-02-21 10:34:48 --> Total execution time: 0.0254
ERROR - 2022-02-21 10:34:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-21 10:34:51 --> Config Class Initialized
INFO - 2022-02-21 10:34:51 --> Hooks Class Initialized
DEBUG - 2022-02-21 10:34:51 --> UTF-8 Support Enabled
INFO - 2022-02-21 10:34:51 --> Utf8 Class Initialized
INFO - 2022-02-21 10:34:51 --> URI Class Initialized
DEBUG - 2022-02-21 10:34:51 --> No URI present. Default controller set.
INFO - 2022-02-21 10:34:51 --> Router Class Initialized
INFO - 2022-02-21 10:34:51 --> Output Class Initialized
INFO - 2022-02-21 10:34:51 --> Security Class Initialized
DEBUG - 2022-02-21 10:34:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-21 10:34:51 --> Input Class Initialized
INFO - 2022-02-21 10:34:51 --> Language Class Initialized
INFO - 2022-02-21 10:34:51 --> Loader Class Initialized
INFO - 2022-02-21 10:34:51 --> Helper loaded: url_helper
INFO - 2022-02-21 10:34:51 --> Helper loaded: form_helper
INFO - 2022-02-21 10:34:51 --> Helper loaded: common_helper
INFO - 2022-02-21 10:34:51 --> Database Driver Class Initialized
DEBUG - 2022-02-21 10:34:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-21 10:34:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-21 10:34:51 --> Controller Class Initialized
INFO - 2022-02-21 10:34:51 --> Form Validation Class Initialized
DEBUG - 2022-02-21 10:34:51 --> Encrypt Class Initialized
DEBUG - 2022-02-21 10:34:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-21 10:34:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-21 10:34:51 --> Email Class Initialized
INFO - 2022-02-21 10:34:51 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-21 10:34:51 --> Calendar Class Initialized
INFO - 2022-02-21 10:34:51 --> Model "Login_model" initialized
INFO - 2022-02-21 10:34:51 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-21 10:34:51 --> Final output sent to browser
DEBUG - 2022-02-21 10:34:51 --> Total execution time: 0.0255
ERROR - 2022-02-21 14:22:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-21 14:22:47 --> Config Class Initialized
INFO - 2022-02-21 14:22:47 --> Hooks Class Initialized
DEBUG - 2022-02-21 14:22:47 --> UTF-8 Support Enabled
INFO - 2022-02-21 14:22:47 --> Utf8 Class Initialized
INFO - 2022-02-21 14:22:47 --> URI Class Initialized
DEBUG - 2022-02-21 14:22:47 --> No URI present. Default controller set.
INFO - 2022-02-21 14:22:47 --> Router Class Initialized
INFO - 2022-02-21 14:22:47 --> Output Class Initialized
INFO - 2022-02-21 14:22:47 --> Security Class Initialized
DEBUG - 2022-02-21 14:22:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-21 14:22:47 --> Input Class Initialized
INFO - 2022-02-21 14:22:47 --> Language Class Initialized
INFO - 2022-02-21 14:22:47 --> Loader Class Initialized
INFO - 2022-02-21 14:22:47 --> Helper loaded: url_helper
INFO - 2022-02-21 14:22:47 --> Helper loaded: form_helper
INFO - 2022-02-21 14:22:47 --> Helper loaded: common_helper
INFO - 2022-02-21 14:22:47 --> Database Driver Class Initialized
DEBUG - 2022-02-21 14:22:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-21 14:22:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-21 14:22:47 --> Controller Class Initialized
INFO - 2022-02-21 14:22:47 --> Form Validation Class Initialized
DEBUG - 2022-02-21 14:22:47 --> Encrypt Class Initialized
DEBUG - 2022-02-21 14:22:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-21 14:22:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-21 14:22:47 --> Email Class Initialized
INFO - 2022-02-21 14:22:47 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-21 14:22:47 --> Calendar Class Initialized
INFO - 2022-02-21 14:22:47 --> Model "Login_model" initialized
INFO - 2022-02-21 14:22:47 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-21 14:22:47 --> Final output sent to browser
DEBUG - 2022-02-21 14:22:47 --> Total execution time: 0.0243
ERROR - 2022-02-21 14:22:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-21 14:22:47 --> Config Class Initialized
INFO - 2022-02-21 14:22:47 --> Hooks Class Initialized
DEBUG - 2022-02-21 14:22:47 --> UTF-8 Support Enabled
INFO - 2022-02-21 14:22:47 --> Utf8 Class Initialized
INFO - 2022-02-21 14:22:47 --> URI Class Initialized
INFO - 2022-02-21 14:22:47 --> Router Class Initialized
INFO - 2022-02-21 14:22:47 --> Output Class Initialized
INFO - 2022-02-21 14:22:47 --> Security Class Initialized
DEBUG - 2022-02-21 14:22:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-21 14:22:47 --> Input Class Initialized
INFO - 2022-02-21 14:22:47 --> Language Class Initialized
ERROR - 2022-02-21 14:22:47 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2022-02-21 14:22:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-21 14:22:55 --> Config Class Initialized
INFO - 2022-02-21 14:22:55 --> Hooks Class Initialized
DEBUG - 2022-02-21 14:22:55 --> UTF-8 Support Enabled
INFO - 2022-02-21 14:22:55 --> Utf8 Class Initialized
INFO - 2022-02-21 14:22:55 --> URI Class Initialized
INFO - 2022-02-21 14:22:55 --> Router Class Initialized
INFO - 2022-02-21 14:22:55 --> Output Class Initialized
INFO - 2022-02-21 14:22:55 --> Security Class Initialized
DEBUG - 2022-02-21 14:22:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-21 14:22:55 --> Input Class Initialized
INFO - 2022-02-21 14:22:55 --> Language Class Initialized
INFO - 2022-02-21 14:22:55 --> Loader Class Initialized
INFO - 2022-02-21 14:22:55 --> Helper loaded: url_helper
INFO - 2022-02-21 14:22:55 --> Helper loaded: form_helper
INFO - 2022-02-21 14:22:55 --> Helper loaded: common_helper
INFO - 2022-02-21 14:22:55 --> Database Driver Class Initialized
DEBUG - 2022-02-21 14:22:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-21 14:22:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-21 14:22:55 --> Controller Class Initialized
INFO - 2022-02-21 14:22:55 --> Form Validation Class Initialized
DEBUG - 2022-02-21 14:22:55 --> Encrypt Class Initialized
DEBUG - 2022-02-21 14:22:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-21 14:22:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-21 14:22:55 --> Email Class Initialized
INFO - 2022-02-21 14:22:55 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-21 14:22:55 --> Calendar Class Initialized
INFO - 2022-02-21 14:22:55 --> Model "Login_model" initialized
INFO - 2022-02-21 14:22:55 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-21 14:22:55 --> Final output sent to browser
DEBUG - 2022-02-21 14:22:55 --> Total execution time: 0.0381
ERROR - 2022-02-21 14:22:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-21 14:22:56 --> Config Class Initialized
INFO - 2022-02-21 14:22:56 --> Hooks Class Initialized
DEBUG - 2022-02-21 14:22:56 --> UTF-8 Support Enabled
INFO - 2022-02-21 14:22:56 --> Utf8 Class Initialized
INFO - 2022-02-21 14:22:56 --> URI Class Initialized
INFO - 2022-02-21 14:22:56 --> Router Class Initialized
INFO - 2022-02-21 14:22:56 --> Output Class Initialized
INFO - 2022-02-21 14:22:56 --> Security Class Initialized
DEBUG - 2022-02-21 14:22:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-21 14:22:56 --> Input Class Initialized
INFO - 2022-02-21 14:22:56 --> Language Class Initialized
INFO - 2022-02-21 14:22:56 --> Loader Class Initialized
INFO - 2022-02-21 14:22:56 --> Helper loaded: url_helper
INFO - 2022-02-21 14:22:56 --> Helper loaded: form_helper
INFO - 2022-02-21 14:22:56 --> Helper loaded: common_helper
INFO - 2022-02-21 14:22:56 --> Database Driver Class Initialized
DEBUG - 2022-02-21 14:22:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-21 14:22:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-21 14:22:56 --> Controller Class Initialized
INFO - 2022-02-21 14:22:56 --> Form Validation Class Initialized
DEBUG - 2022-02-21 14:22:56 --> Encrypt Class Initialized
DEBUG - 2022-02-21 14:22:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-21 14:22:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-21 14:22:56 --> Email Class Initialized
INFO - 2022-02-21 14:22:56 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-21 14:22:56 --> Calendar Class Initialized
INFO - 2022-02-21 14:22:56 --> Model "Login_model" initialized
ERROR - 2022-02-21 14:22:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-21 14:22:57 --> Config Class Initialized
INFO - 2022-02-21 14:22:57 --> Hooks Class Initialized
DEBUG - 2022-02-21 14:22:57 --> UTF-8 Support Enabled
INFO - 2022-02-21 14:22:57 --> Utf8 Class Initialized
INFO - 2022-02-21 14:22:57 --> URI Class Initialized
INFO - 2022-02-21 14:22:57 --> Router Class Initialized
INFO - 2022-02-21 14:22:57 --> Output Class Initialized
INFO - 2022-02-21 14:22:57 --> Security Class Initialized
DEBUG - 2022-02-21 14:22:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-21 14:22:57 --> Input Class Initialized
INFO - 2022-02-21 14:22:57 --> Language Class Initialized
INFO - 2022-02-21 14:22:57 --> Loader Class Initialized
INFO - 2022-02-21 14:22:57 --> Helper loaded: url_helper
INFO - 2022-02-21 14:22:57 --> Helper loaded: form_helper
INFO - 2022-02-21 14:22:57 --> Helper loaded: common_helper
INFO - 2022-02-21 14:22:57 --> Database Driver Class Initialized
DEBUG - 2022-02-21 14:22:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-21 14:22:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-21 14:22:57 --> Controller Class Initialized
INFO - 2022-02-21 14:22:57 --> Form Validation Class Initialized
DEBUG - 2022-02-21 14:22:57 --> Encrypt Class Initialized
DEBUG - 2022-02-21 14:22:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-21 14:22:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-21 14:22:57 --> Email Class Initialized
INFO - 2022-02-21 14:22:57 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-21 14:22:57 --> Calendar Class Initialized
INFO - 2022-02-21 14:22:57 --> Model "Login_model" initialized
ERROR - 2022-02-21 14:22:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-21 14:22:57 --> Config Class Initialized
INFO - 2022-02-21 14:22:57 --> Hooks Class Initialized
DEBUG - 2022-02-21 14:22:57 --> UTF-8 Support Enabled
INFO - 2022-02-21 14:22:57 --> Utf8 Class Initialized
INFO - 2022-02-21 14:22:57 --> URI Class Initialized
DEBUG - 2022-02-21 14:22:57 --> No URI present. Default controller set.
INFO - 2022-02-21 14:22:57 --> Router Class Initialized
INFO - 2022-02-21 14:22:57 --> Output Class Initialized
INFO - 2022-02-21 14:22:57 --> Security Class Initialized
DEBUG - 2022-02-21 14:22:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-21 14:22:57 --> Input Class Initialized
INFO - 2022-02-21 14:22:57 --> Language Class Initialized
INFO - 2022-02-21 14:22:57 --> Loader Class Initialized
INFO - 2022-02-21 14:22:57 --> Helper loaded: url_helper
INFO - 2022-02-21 14:22:57 --> Helper loaded: form_helper
INFO - 2022-02-21 14:22:57 --> Helper loaded: common_helper
INFO - 2022-02-21 14:22:57 --> Database Driver Class Initialized
DEBUG - 2022-02-21 14:22:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-21 14:22:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-21 14:22:57 --> Controller Class Initialized
INFO - 2022-02-21 14:22:57 --> Form Validation Class Initialized
DEBUG - 2022-02-21 14:22:57 --> Encrypt Class Initialized
DEBUG - 2022-02-21 14:22:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-21 14:22:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-21 14:22:57 --> Email Class Initialized
INFO - 2022-02-21 14:22:57 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-21 14:22:57 --> Calendar Class Initialized
INFO - 2022-02-21 14:22:57 --> Model "Login_model" initialized
INFO - 2022-02-21 14:22:57 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-21 14:22:57 --> Final output sent to browser
DEBUG - 2022-02-21 14:22:57 --> Total execution time: 0.0214
ERROR - 2022-02-21 15:55:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-21 15:55:56 --> Config Class Initialized
INFO - 2022-02-21 15:55:56 --> Hooks Class Initialized
DEBUG - 2022-02-21 15:55:56 --> UTF-8 Support Enabled
INFO - 2022-02-21 15:55:56 --> Utf8 Class Initialized
INFO - 2022-02-21 15:55:56 --> URI Class Initialized
DEBUG - 2022-02-21 15:55:56 --> No URI present. Default controller set.
INFO - 2022-02-21 15:55:56 --> Router Class Initialized
INFO - 2022-02-21 15:55:56 --> Output Class Initialized
INFO - 2022-02-21 15:55:56 --> Security Class Initialized
DEBUG - 2022-02-21 15:55:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-21 15:55:56 --> Input Class Initialized
INFO - 2022-02-21 15:55:56 --> Language Class Initialized
INFO - 2022-02-21 15:55:56 --> Loader Class Initialized
INFO - 2022-02-21 15:55:56 --> Helper loaded: url_helper
INFO - 2022-02-21 15:55:56 --> Helper loaded: form_helper
INFO - 2022-02-21 15:55:56 --> Helper loaded: common_helper
INFO - 2022-02-21 15:55:56 --> Database Driver Class Initialized
DEBUG - 2022-02-21 15:55:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-21 15:55:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-21 15:55:56 --> Controller Class Initialized
INFO - 2022-02-21 15:55:56 --> Form Validation Class Initialized
DEBUG - 2022-02-21 15:55:56 --> Encrypt Class Initialized
DEBUG - 2022-02-21 15:55:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-21 15:55:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-21 15:55:56 --> Email Class Initialized
INFO - 2022-02-21 15:55:56 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-21 15:55:56 --> Calendar Class Initialized
INFO - 2022-02-21 15:55:56 --> Model "Login_model" initialized
INFO - 2022-02-21 15:55:56 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-21 15:55:56 --> Final output sent to browser
DEBUG - 2022-02-21 15:55:56 --> Total execution time: 0.0320
