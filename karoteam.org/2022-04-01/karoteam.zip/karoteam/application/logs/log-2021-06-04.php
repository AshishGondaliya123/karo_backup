<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-06-04 15:32:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-04 15:32:49 --> Config Class Initialized
INFO - 2021-06-04 15:32:49 --> Hooks Class Initialized
DEBUG - 2021-06-04 15:32:49 --> UTF-8 Support Enabled
INFO - 2021-06-04 15:32:49 --> Utf8 Class Initialized
INFO - 2021-06-04 15:32:49 --> URI Class Initialized
DEBUG - 2021-06-04 15:32:49 --> No URI present. Default controller set.
INFO - 2021-06-04 15:32:49 --> Router Class Initialized
INFO - 2021-06-04 15:32:49 --> Output Class Initialized
INFO - 2021-06-04 15:32:49 --> Security Class Initialized
DEBUG - 2021-06-04 15:32:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-04 15:32:49 --> Input Class Initialized
INFO - 2021-06-04 15:32:49 --> Language Class Initialized
INFO - 2021-06-04 15:32:49 --> Loader Class Initialized
INFO - 2021-06-04 15:32:49 --> Helper loaded: url_helper
INFO - 2021-06-04 15:32:49 --> Helper loaded: form_helper
INFO - 2021-06-04 15:32:49 --> Helper loaded: common_helper
INFO - 2021-06-04 15:32:49 --> Database Driver Class Initialized
DEBUG - 2021-06-04 15:32:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-04 15:32:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-04 15:32:49 --> Controller Class Initialized
INFO - 2021-06-04 15:32:49 --> Form Validation Class Initialized
DEBUG - 2021-06-04 15:32:49 --> Encrypt Class Initialized
DEBUG - 2021-06-04 15:32:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-06-04 15:32:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-06-04 15:32:49 --> Email Class Initialized
INFO - 2021-06-04 15:32:49 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-06-04 15:32:49 --> Calendar Class Initialized
INFO - 2021-06-04 15:32:49 --> Model "Login_model" initialized
INFO - 2021-06-04 15:32:49 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-06-04 15:32:49 --> Final output sent to browser
DEBUG - 2021-06-04 15:32:49 --> Total execution time: 0.0341
