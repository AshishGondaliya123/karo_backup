<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-03-05 04:24:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-05 04:24:39 --> Config Class Initialized
INFO - 2022-03-05 04:24:39 --> Hooks Class Initialized
DEBUG - 2022-03-05 04:24:39 --> UTF-8 Support Enabled
INFO - 2022-03-05 04:24:39 --> Utf8 Class Initialized
INFO - 2022-03-05 04:24:39 --> URI Class Initialized
DEBUG - 2022-03-05 04:24:39 --> No URI present. Default controller set.
INFO - 2022-03-05 04:24:39 --> Router Class Initialized
INFO - 2022-03-05 04:24:39 --> Output Class Initialized
INFO - 2022-03-05 04:24:39 --> Security Class Initialized
DEBUG - 2022-03-05 04:24:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-05 04:24:39 --> Input Class Initialized
INFO - 2022-03-05 04:24:39 --> Language Class Initialized
INFO - 2022-03-05 04:24:39 --> Loader Class Initialized
INFO - 2022-03-05 04:24:39 --> Helper loaded: url_helper
INFO - 2022-03-05 04:24:39 --> Helper loaded: form_helper
INFO - 2022-03-05 04:24:39 --> Helper loaded: common_helper
INFO - 2022-03-05 04:24:39 --> Database Driver Class Initialized
DEBUG - 2022-03-05 04:24:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-05 04:24:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-05 04:24:39 --> Controller Class Initialized
INFO - 2022-03-05 04:24:39 --> Form Validation Class Initialized
DEBUG - 2022-03-05 04:24:39 --> Encrypt Class Initialized
DEBUG - 2022-03-05 04:24:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-05 04:24:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-05 04:24:39 --> Email Class Initialized
INFO - 2022-03-05 04:24:39 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-05 04:24:39 --> Calendar Class Initialized
INFO - 2022-03-05 04:24:39 --> Model "Login_model" initialized
INFO - 2022-03-05 04:24:39 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-05 04:24:39 --> Final output sent to browser
DEBUG - 2022-03-05 04:24:39 --> Total execution time: 0.0302
ERROR - 2022-03-05 04:24:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-05 04:24:41 --> Config Class Initialized
INFO - 2022-03-05 04:24:41 --> Hooks Class Initialized
DEBUG - 2022-03-05 04:24:41 --> UTF-8 Support Enabled
INFO - 2022-03-05 04:24:41 --> Utf8 Class Initialized
INFO - 2022-03-05 04:24:41 --> URI Class Initialized
INFO - 2022-03-05 04:24:41 --> Router Class Initialized
INFO - 2022-03-05 04:24:41 --> Output Class Initialized
INFO - 2022-03-05 04:24:41 --> Security Class Initialized
DEBUG - 2022-03-05 04:24:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-05 04:24:41 --> Input Class Initialized
INFO - 2022-03-05 04:24:41 --> Language Class Initialized
ERROR - 2022-03-05 04:24:41 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2022-03-05 04:24:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-05 04:24:41 --> Config Class Initialized
INFO - 2022-03-05 04:24:41 --> Hooks Class Initialized
DEBUG - 2022-03-05 04:24:41 --> UTF-8 Support Enabled
INFO - 2022-03-05 04:24:41 --> Utf8 Class Initialized
INFO - 2022-03-05 04:24:41 --> URI Class Initialized
DEBUG - 2022-03-05 04:24:41 --> No URI present. Default controller set.
INFO - 2022-03-05 04:24:41 --> Router Class Initialized
INFO - 2022-03-05 04:24:41 --> Output Class Initialized
INFO - 2022-03-05 04:24:41 --> Security Class Initialized
DEBUG - 2022-03-05 04:24:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-05 04:24:41 --> Input Class Initialized
INFO - 2022-03-05 04:24:41 --> Language Class Initialized
INFO - 2022-03-05 04:24:41 --> Loader Class Initialized
INFO - 2022-03-05 04:24:41 --> Helper loaded: url_helper
INFO - 2022-03-05 04:24:41 --> Helper loaded: form_helper
INFO - 2022-03-05 04:24:41 --> Helper loaded: common_helper
INFO - 2022-03-05 04:24:41 --> Database Driver Class Initialized
DEBUG - 2022-03-05 04:24:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-05 04:24:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-05 04:24:41 --> Controller Class Initialized
INFO - 2022-03-05 04:24:41 --> Form Validation Class Initialized
DEBUG - 2022-03-05 04:24:41 --> Encrypt Class Initialized
DEBUG - 2022-03-05 04:24:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-05 04:24:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-05 04:24:41 --> Email Class Initialized
INFO - 2022-03-05 04:24:41 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-05 04:24:41 --> Calendar Class Initialized
INFO - 2022-03-05 04:24:41 --> Model "Login_model" initialized
INFO - 2022-03-05 04:24:41 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-05 04:24:41 --> Final output sent to browser
DEBUG - 2022-03-05 04:24:41 --> Total execution time: 0.0259
ERROR - 2022-03-05 04:24:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-05 04:24:44 --> Config Class Initialized
INFO - 2022-03-05 04:24:44 --> Hooks Class Initialized
DEBUG - 2022-03-05 04:24:44 --> UTF-8 Support Enabled
INFO - 2022-03-05 04:24:44 --> Utf8 Class Initialized
INFO - 2022-03-05 04:24:44 --> URI Class Initialized
INFO - 2022-03-05 04:24:44 --> Router Class Initialized
INFO - 2022-03-05 04:24:44 --> Output Class Initialized
INFO - 2022-03-05 04:24:44 --> Security Class Initialized
DEBUG - 2022-03-05 04:24:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-05 04:24:44 --> Input Class Initialized
INFO - 2022-03-05 04:24:44 --> Language Class Initialized
ERROR - 2022-03-05 04:24:44 --> 404 Page Not Found: Adstxt/index
ERROR - 2022-03-05 04:24:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-05 04:24:44 --> Config Class Initialized
INFO - 2022-03-05 04:24:44 --> Hooks Class Initialized
DEBUG - 2022-03-05 04:24:44 --> UTF-8 Support Enabled
INFO - 2022-03-05 04:24:44 --> Utf8 Class Initialized
INFO - 2022-03-05 04:24:44 --> URI Class Initialized
DEBUG - 2022-03-05 04:24:44 --> No URI present. Default controller set.
INFO - 2022-03-05 04:24:44 --> Router Class Initialized
INFO - 2022-03-05 04:24:44 --> Output Class Initialized
INFO - 2022-03-05 04:24:44 --> Security Class Initialized
DEBUG - 2022-03-05 04:24:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-05 04:24:44 --> Input Class Initialized
INFO - 2022-03-05 04:24:44 --> Language Class Initialized
INFO - 2022-03-05 04:24:44 --> Loader Class Initialized
INFO - 2022-03-05 04:24:44 --> Helper loaded: url_helper
INFO - 2022-03-05 04:24:44 --> Helper loaded: form_helper
INFO - 2022-03-05 04:24:44 --> Helper loaded: common_helper
INFO - 2022-03-05 04:24:44 --> Database Driver Class Initialized
DEBUG - 2022-03-05 04:24:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-05 04:24:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-05 04:24:44 --> Controller Class Initialized
INFO - 2022-03-05 04:24:44 --> Form Validation Class Initialized
DEBUG - 2022-03-05 04:24:44 --> Encrypt Class Initialized
DEBUG - 2022-03-05 04:24:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-05 04:24:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-05 04:24:44 --> Email Class Initialized
INFO - 2022-03-05 04:24:44 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-05 04:24:44 --> Calendar Class Initialized
INFO - 2022-03-05 04:24:44 --> Model "Login_model" initialized
INFO - 2022-03-05 04:24:44 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-05 04:24:44 --> Final output sent to browser
DEBUG - 2022-03-05 04:24:44 --> Total execution time: 0.0248
ERROR - 2022-03-05 04:32:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-05 04:32:13 --> Config Class Initialized
INFO - 2022-03-05 04:32:13 --> Hooks Class Initialized
DEBUG - 2022-03-05 04:32:13 --> UTF-8 Support Enabled
INFO - 2022-03-05 04:32:13 --> Utf8 Class Initialized
INFO - 2022-03-05 04:32:13 --> URI Class Initialized
DEBUG - 2022-03-05 04:32:13 --> No URI present. Default controller set.
INFO - 2022-03-05 04:32:13 --> Router Class Initialized
INFO - 2022-03-05 04:32:13 --> Output Class Initialized
INFO - 2022-03-05 04:32:13 --> Security Class Initialized
DEBUG - 2022-03-05 04:32:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-05 04:32:13 --> Input Class Initialized
INFO - 2022-03-05 04:32:13 --> Language Class Initialized
INFO - 2022-03-05 04:32:13 --> Loader Class Initialized
INFO - 2022-03-05 04:32:13 --> Helper loaded: url_helper
INFO - 2022-03-05 04:32:13 --> Helper loaded: form_helper
INFO - 2022-03-05 04:32:13 --> Helper loaded: common_helper
INFO - 2022-03-05 04:32:13 --> Database Driver Class Initialized
DEBUG - 2022-03-05 04:32:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-05 04:32:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-05 04:32:13 --> Controller Class Initialized
INFO - 2022-03-05 04:32:13 --> Form Validation Class Initialized
DEBUG - 2022-03-05 04:32:13 --> Encrypt Class Initialized
DEBUG - 2022-03-05 04:32:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-05 04:32:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-05 04:32:13 --> Email Class Initialized
INFO - 2022-03-05 04:32:13 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-05 04:32:13 --> Calendar Class Initialized
INFO - 2022-03-05 04:32:13 --> Model "Login_model" initialized
INFO - 2022-03-05 04:32:13 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-05 04:32:13 --> Final output sent to browser
DEBUG - 2022-03-05 04:32:13 --> Total execution time: 0.0235
ERROR - 2022-03-05 07:53:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-05 07:53:43 --> Config Class Initialized
INFO - 2022-03-05 07:53:43 --> Hooks Class Initialized
DEBUG - 2022-03-05 07:53:43 --> UTF-8 Support Enabled
INFO - 2022-03-05 07:53:43 --> Utf8 Class Initialized
INFO - 2022-03-05 07:53:43 --> URI Class Initialized
DEBUG - 2022-03-05 07:53:43 --> No URI present. Default controller set.
INFO - 2022-03-05 07:53:43 --> Router Class Initialized
INFO - 2022-03-05 07:53:43 --> Output Class Initialized
INFO - 2022-03-05 07:53:43 --> Security Class Initialized
DEBUG - 2022-03-05 07:53:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-05 07:53:43 --> Input Class Initialized
INFO - 2022-03-05 07:53:43 --> Language Class Initialized
INFO - 2022-03-05 07:53:43 --> Loader Class Initialized
INFO - 2022-03-05 07:53:43 --> Helper loaded: url_helper
INFO - 2022-03-05 07:53:43 --> Helper loaded: form_helper
INFO - 2022-03-05 07:53:43 --> Helper loaded: common_helper
INFO - 2022-03-05 07:53:43 --> Database Driver Class Initialized
DEBUG - 2022-03-05 07:53:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-05 07:53:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-05 07:53:43 --> Controller Class Initialized
INFO - 2022-03-05 07:53:43 --> Form Validation Class Initialized
DEBUG - 2022-03-05 07:53:43 --> Encrypt Class Initialized
DEBUG - 2022-03-05 07:53:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-05 07:53:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-05 07:53:43 --> Email Class Initialized
INFO - 2022-03-05 07:53:43 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-05 07:53:43 --> Calendar Class Initialized
INFO - 2022-03-05 07:53:43 --> Model "Login_model" initialized
INFO - 2022-03-05 07:53:43 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-05 07:53:43 --> Final output sent to browser
DEBUG - 2022-03-05 07:53:43 --> Total execution time: 0.0233
ERROR - 2022-03-05 08:29:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-05 08:29:03 --> Config Class Initialized
INFO - 2022-03-05 08:29:03 --> Hooks Class Initialized
DEBUG - 2022-03-05 08:29:03 --> UTF-8 Support Enabled
INFO - 2022-03-05 08:29:03 --> Utf8 Class Initialized
INFO - 2022-03-05 08:29:03 --> URI Class Initialized
DEBUG - 2022-03-05 08:29:03 --> No URI present. Default controller set.
INFO - 2022-03-05 08:29:03 --> Router Class Initialized
INFO - 2022-03-05 08:29:03 --> Output Class Initialized
INFO - 2022-03-05 08:29:03 --> Security Class Initialized
DEBUG - 2022-03-05 08:29:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-05 08:29:03 --> Input Class Initialized
INFO - 2022-03-05 08:29:03 --> Language Class Initialized
INFO - 2022-03-05 08:29:03 --> Loader Class Initialized
INFO - 2022-03-05 08:29:03 --> Helper loaded: url_helper
INFO - 2022-03-05 08:29:03 --> Helper loaded: form_helper
INFO - 2022-03-05 08:29:03 --> Helper loaded: common_helper
INFO - 2022-03-05 08:29:03 --> Database Driver Class Initialized
DEBUG - 2022-03-05 08:29:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-05 08:29:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-05 08:29:03 --> Controller Class Initialized
INFO - 2022-03-05 08:29:03 --> Form Validation Class Initialized
DEBUG - 2022-03-05 08:29:03 --> Encrypt Class Initialized
DEBUG - 2022-03-05 08:29:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-05 08:29:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-05 08:29:03 --> Email Class Initialized
INFO - 2022-03-05 08:29:03 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-05 08:29:03 --> Calendar Class Initialized
INFO - 2022-03-05 08:29:03 --> Model "Login_model" initialized
INFO - 2022-03-05 08:29:03 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-05 08:29:03 --> Final output sent to browser
DEBUG - 2022-03-05 08:29:03 --> Total execution time: 0.0226
ERROR - 2022-03-05 08:37:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-05 08:37:31 --> Config Class Initialized
INFO - 2022-03-05 08:37:31 --> Hooks Class Initialized
DEBUG - 2022-03-05 08:37:31 --> UTF-8 Support Enabled
INFO - 2022-03-05 08:37:31 --> Utf8 Class Initialized
INFO - 2022-03-05 08:37:31 --> URI Class Initialized
DEBUG - 2022-03-05 08:37:31 --> No URI present. Default controller set.
INFO - 2022-03-05 08:37:31 --> Router Class Initialized
INFO - 2022-03-05 08:37:31 --> Output Class Initialized
INFO - 2022-03-05 08:37:31 --> Security Class Initialized
DEBUG - 2022-03-05 08:37:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-05 08:37:31 --> Input Class Initialized
INFO - 2022-03-05 08:37:31 --> Language Class Initialized
INFO - 2022-03-05 08:37:31 --> Loader Class Initialized
INFO - 2022-03-05 08:37:31 --> Helper loaded: url_helper
INFO - 2022-03-05 08:37:31 --> Helper loaded: form_helper
INFO - 2022-03-05 08:37:31 --> Helper loaded: common_helper
INFO - 2022-03-05 08:37:31 --> Database Driver Class Initialized
DEBUG - 2022-03-05 08:37:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-05 08:37:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-05 08:37:31 --> Controller Class Initialized
INFO - 2022-03-05 08:37:31 --> Form Validation Class Initialized
DEBUG - 2022-03-05 08:37:31 --> Encrypt Class Initialized
DEBUG - 2022-03-05 08:37:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-05 08:37:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-05 08:37:31 --> Email Class Initialized
INFO - 2022-03-05 08:37:31 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-05 08:37:31 --> Calendar Class Initialized
INFO - 2022-03-05 08:37:31 --> Model "Login_model" initialized
INFO - 2022-03-05 08:37:31 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-05 08:37:31 --> Final output sent to browser
DEBUG - 2022-03-05 08:37:31 --> Total execution time: 0.0234
ERROR - 2022-03-05 14:23:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-05 14:23:23 --> Config Class Initialized
INFO - 2022-03-05 14:23:23 --> Hooks Class Initialized
DEBUG - 2022-03-05 14:23:23 --> UTF-8 Support Enabled
INFO - 2022-03-05 14:23:23 --> Utf8 Class Initialized
INFO - 2022-03-05 14:23:23 --> URI Class Initialized
DEBUG - 2022-03-05 14:23:23 --> No URI present. Default controller set.
INFO - 2022-03-05 14:23:23 --> Router Class Initialized
INFO - 2022-03-05 14:23:23 --> Output Class Initialized
INFO - 2022-03-05 14:23:23 --> Security Class Initialized
DEBUG - 2022-03-05 14:23:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-05 14:23:23 --> Input Class Initialized
INFO - 2022-03-05 14:23:23 --> Language Class Initialized
INFO - 2022-03-05 14:23:23 --> Loader Class Initialized
INFO - 2022-03-05 14:23:23 --> Helper loaded: url_helper
INFO - 2022-03-05 14:23:23 --> Helper loaded: form_helper
INFO - 2022-03-05 14:23:23 --> Helper loaded: common_helper
INFO - 2022-03-05 14:23:23 --> Database Driver Class Initialized
DEBUG - 2022-03-05 14:23:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-05 14:23:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-05 14:23:23 --> Controller Class Initialized
INFO - 2022-03-05 14:23:23 --> Form Validation Class Initialized
DEBUG - 2022-03-05 14:23:23 --> Encrypt Class Initialized
DEBUG - 2022-03-05 14:23:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-05 14:23:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-05 14:23:23 --> Email Class Initialized
INFO - 2022-03-05 14:23:23 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-05 14:23:23 --> Calendar Class Initialized
INFO - 2022-03-05 14:23:23 --> Model "Login_model" initialized
INFO - 2022-03-05 14:23:23 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-05 14:23:23 --> Final output sent to browser
DEBUG - 2022-03-05 14:23:23 --> Total execution time: 0.0246
ERROR - 2022-03-05 14:23:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-05 14:23:23 --> Config Class Initialized
INFO - 2022-03-05 14:23:23 --> Hooks Class Initialized
DEBUG - 2022-03-05 14:23:23 --> UTF-8 Support Enabled
INFO - 2022-03-05 14:23:23 --> Utf8 Class Initialized
INFO - 2022-03-05 14:23:23 --> URI Class Initialized
INFO - 2022-03-05 14:23:23 --> Router Class Initialized
INFO - 2022-03-05 14:23:23 --> Output Class Initialized
INFO - 2022-03-05 14:23:23 --> Security Class Initialized
DEBUG - 2022-03-05 14:23:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-05 14:23:23 --> Input Class Initialized
INFO - 2022-03-05 14:23:23 --> Language Class Initialized
ERROR - 2022-03-05 14:23:23 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2022-03-05 14:23:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-05 14:23:30 --> Config Class Initialized
INFO - 2022-03-05 14:23:30 --> Hooks Class Initialized
DEBUG - 2022-03-05 14:23:30 --> UTF-8 Support Enabled
INFO - 2022-03-05 14:23:30 --> Utf8 Class Initialized
INFO - 2022-03-05 14:23:30 --> URI Class Initialized
DEBUG - 2022-03-05 14:23:30 --> No URI present. Default controller set.
INFO - 2022-03-05 14:23:30 --> Router Class Initialized
INFO - 2022-03-05 14:23:30 --> Output Class Initialized
INFO - 2022-03-05 14:23:30 --> Security Class Initialized
DEBUG - 2022-03-05 14:23:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-05 14:23:30 --> Input Class Initialized
INFO - 2022-03-05 14:23:30 --> Language Class Initialized
INFO - 2022-03-05 14:23:30 --> Loader Class Initialized
INFO - 2022-03-05 14:23:30 --> Helper loaded: url_helper
INFO - 2022-03-05 14:23:30 --> Helper loaded: form_helper
INFO - 2022-03-05 14:23:30 --> Helper loaded: common_helper
INFO - 2022-03-05 14:23:30 --> Database Driver Class Initialized
DEBUG - 2022-03-05 14:23:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-05 14:23:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-05 14:23:30 --> Controller Class Initialized
INFO - 2022-03-05 14:23:30 --> Form Validation Class Initialized
DEBUG - 2022-03-05 14:23:30 --> Encrypt Class Initialized
DEBUG - 2022-03-05 14:23:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-05 14:23:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-05 14:23:30 --> Email Class Initialized
INFO - 2022-03-05 14:23:30 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-05 14:23:30 --> Calendar Class Initialized
INFO - 2022-03-05 14:23:30 --> Model "Login_model" initialized
INFO - 2022-03-05 14:23:30 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-05 14:23:30 --> Final output sent to browser
DEBUG - 2022-03-05 14:23:30 --> Total execution time: 0.0224
ERROR - 2022-03-05 14:23:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-05 14:23:31 --> Config Class Initialized
INFO - 2022-03-05 14:23:31 --> Hooks Class Initialized
DEBUG - 2022-03-05 14:23:31 --> UTF-8 Support Enabled
INFO - 2022-03-05 14:23:31 --> Utf8 Class Initialized
INFO - 2022-03-05 14:23:31 --> URI Class Initialized
INFO - 2022-03-05 14:23:31 --> Router Class Initialized
INFO - 2022-03-05 14:23:31 --> Output Class Initialized
INFO - 2022-03-05 14:23:31 --> Security Class Initialized
DEBUG - 2022-03-05 14:23:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-05 14:23:31 --> Input Class Initialized
INFO - 2022-03-05 14:23:31 --> Language Class Initialized
INFO - 2022-03-05 14:23:31 --> Loader Class Initialized
INFO - 2022-03-05 14:23:31 --> Helper loaded: url_helper
INFO - 2022-03-05 14:23:31 --> Helper loaded: form_helper
INFO - 2022-03-05 14:23:31 --> Helper loaded: common_helper
INFO - 2022-03-05 14:23:31 --> Database Driver Class Initialized
DEBUG - 2022-03-05 14:23:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-05 14:23:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-05 14:23:31 --> Controller Class Initialized
INFO - 2022-03-05 14:23:31 --> Form Validation Class Initialized
DEBUG - 2022-03-05 14:23:31 --> Encrypt Class Initialized
DEBUG - 2022-03-05 14:23:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-05 14:23:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-05 14:23:31 --> Email Class Initialized
INFO - 2022-03-05 14:23:31 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-05 14:23:31 --> Calendar Class Initialized
INFO - 2022-03-05 14:23:31 --> Model "Login_model" initialized
INFO - 2022-03-05 14:23:31 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-05 14:23:31 --> Final output sent to browser
DEBUG - 2022-03-05 14:23:31 --> Total execution time: 0.0252
ERROR - 2022-03-05 14:23:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-05 14:23:32 --> Config Class Initialized
INFO - 2022-03-05 14:23:32 --> Hooks Class Initialized
DEBUG - 2022-03-05 14:23:32 --> UTF-8 Support Enabled
INFO - 2022-03-05 14:23:32 --> Utf8 Class Initialized
INFO - 2022-03-05 14:23:32 --> URI Class Initialized
INFO - 2022-03-05 14:23:32 --> Router Class Initialized
INFO - 2022-03-05 14:23:32 --> Output Class Initialized
INFO - 2022-03-05 14:23:32 --> Security Class Initialized
DEBUG - 2022-03-05 14:23:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-05 14:23:32 --> Input Class Initialized
INFO - 2022-03-05 14:23:32 --> Language Class Initialized
INFO - 2022-03-05 14:23:32 --> Loader Class Initialized
INFO - 2022-03-05 14:23:32 --> Helper loaded: url_helper
INFO - 2022-03-05 14:23:32 --> Helper loaded: form_helper
INFO - 2022-03-05 14:23:32 --> Helper loaded: common_helper
INFO - 2022-03-05 14:23:32 --> Database Driver Class Initialized
DEBUG - 2022-03-05 14:23:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-05 14:23:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-05 14:23:32 --> Controller Class Initialized
INFO - 2022-03-05 14:23:32 --> Form Validation Class Initialized
DEBUG - 2022-03-05 14:23:32 --> Encrypt Class Initialized
DEBUG - 2022-03-05 14:23:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-05 14:23:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-05 14:23:32 --> Email Class Initialized
INFO - 2022-03-05 14:23:32 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-05 14:23:32 --> Calendar Class Initialized
INFO - 2022-03-05 14:23:32 --> Model "Login_model" initialized
ERROR - 2022-03-05 14:23:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-05 14:23:32 --> Config Class Initialized
INFO - 2022-03-05 14:23:32 --> Hooks Class Initialized
DEBUG - 2022-03-05 14:23:32 --> UTF-8 Support Enabled
INFO - 2022-03-05 14:23:32 --> Utf8 Class Initialized
INFO - 2022-03-05 14:23:32 --> URI Class Initialized
INFO - 2022-03-05 14:23:32 --> Router Class Initialized
INFO - 2022-03-05 14:23:32 --> Output Class Initialized
INFO - 2022-03-05 14:23:32 --> Security Class Initialized
DEBUG - 2022-03-05 14:23:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-05 14:23:32 --> Input Class Initialized
INFO - 2022-03-05 14:23:32 --> Language Class Initialized
INFO - 2022-03-05 14:23:32 --> Loader Class Initialized
INFO - 2022-03-05 14:23:32 --> Helper loaded: url_helper
INFO - 2022-03-05 14:23:32 --> Helper loaded: form_helper
INFO - 2022-03-05 14:23:32 --> Helper loaded: common_helper
INFO - 2022-03-05 14:23:32 --> Database Driver Class Initialized
DEBUG - 2022-03-05 14:23:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-05 14:23:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-05 14:23:32 --> Controller Class Initialized
INFO - 2022-03-05 14:23:32 --> Form Validation Class Initialized
DEBUG - 2022-03-05 14:23:32 --> Encrypt Class Initialized
DEBUG - 2022-03-05 14:23:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-05 14:23:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-05 14:23:32 --> Email Class Initialized
INFO - 2022-03-05 14:23:32 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-05 14:23:32 --> Calendar Class Initialized
INFO - 2022-03-05 14:23:32 --> Model "Login_model" initialized
ERROR - 2022-03-05 20:27:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-05 20:27:48 --> Config Class Initialized
INFO - 2022-03-05 20:27:48 --> Hooks Class Initialized
DEBUG - 2022-03-05 20:27:48 --> UTF-8 Support Enabled
INFO - 2022-03-05 20:27:48 --> Utf8 Class Initialized
INFO - 2022-03-05 20:27:48 --> URI Class Initialized
DEBUG - 2022-03-05 20:27:48 --> No URI present. Default controller set.
INFO - 2022-03-05 20:27:48 --> Router Class Initialized
INFO - 2022-03-05 20:27:48 --> Output Class Initialized
INFO - 2022-03-05 20:27:48 --> Security Class Initialized
DEBUG - 2022-03-05 20:27:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-05 20:27:48 --> Input Class Initialized
INFO - 2022-03-05 20:27:48 --> Language Class Initialized
INFO - 2022-03-05 20:27:48 --> Loader Class Initialized
INFO - 2022-03-05 20:27:48 --> Helper loaded: url_helper
INFO - 2022-03-05 20:27:48 --> Helper loaded: form_helper
INFO - 2022-03-05 20:27:48 --> Helper loaded: common_helper
INFO - 2022-03-05 20:27:48 --> Database Driver Class Initialized
DEBUG - 2022-03-05 20:27:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-05 20:27:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-05 20:27:48 --> Controller Class Initialized
INFO - 2022-03-05 20:27:48 --> Form Validation Class Initialized
DEBUG - 2022-03-05 20:27:48 --> Encrypt Class Initialized
DEBUG - 2022-03-05 20:27:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-05 20:27:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-05 20:27:48 --> Email Class Initialized
INFO - 2022-03-05 20:27:48 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-05 20:27:48 --> Calendar Class Initialized
INFO - 2022-03-05 20:27:48 --> Model "Login_model" initialized
INFO - 2022-03-05 20:27:48 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-05 20:27:48 --> Final output sent to browser
DEBUG - 2022-03-05 20:27:48 --> Total execution time: 0.0286
