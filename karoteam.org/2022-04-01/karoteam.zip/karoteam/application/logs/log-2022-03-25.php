<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-03-25 00:00:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 00:00:02 --> Config Class Initialized
INFO - 2022-03-25 00:00:02 --> Hooks Class Initialized
DEBUG - 2022-03-25 00:00:02 --> UTF-8 Support Enabled
INFO - 2022-03-25 00:00:02 --> Utf8 Class Initialized
INFO - 2022-03-25 00:00:02 --> URI Class Initialized
INFO - 2022-03-25 00:00:02 --> Router Class Initialized
INFO - 2022-03-25 00:00:02 --> Output Class Initialized
INFO - 2022-03-25 00:00:02 --> Security Class Initialized
DEBUG - 2022-03-25 00:00:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 00:00:02 --> Input Class Initialized
INFO - 2022-03-25 00:00:02 --> Language Class Initialized
INFO - 2022-03-25 00:00:02 --> Loader Class Initialized
INFO - 2022-03-25 00:00:02 --> Helper loaded: url_helper
INFO - 2022-03-25 00:00:02 --> Helper loaded: form_helper
INFO - 2022-03-25 00:00:02 --> Helper loaded: common_helper
INFO - 2022-03-25 00:00:02 --> Database Driver Class Initialized
DEBUG - 2022-03-25 00:00:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 00:00:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 00:00:02 --> Controller Class Initialized
INFO - 2022-03-25 00:00:02 --> Form Validation Class Initialized
DEBUG - 2022-03-25 00:00:02 --> Encrypt Class Initialized
INFO - 2022-03-25 00:00:02 --> Model "Patient_model" initialized
INFO - 2022-03-25 00:00:02 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 00:00:02 --> Model "Referredby_model" initialized
INFO - 2022-03-25 00:00:02 --> Model "Prefix_master" initialized
INFO - 2022-03-25 00:00:02 --> Model "Hospital_model" initialized
INFO - 2022-03-25 00:00:02 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-25 00:00:12 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-25 00:00:12 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
ERROR - 2022-03-25 00:00:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 00:00:13 --> Config Class Initialized
INFO - 2022-03-25 00:00:13 --> Hooks Class Initialized
DEBUG - 2022-03-25 00:00:13 --> UTF-8 Support Enabled
INFO - 2022-03-25 00:00:13 --> Utf8 Class Initialized
INFO - 2022-03-25 00:00:13 --> URI Class Initialized
INFO - 2022-03-25 00:00:13 --> Router Class Initialized
INFO - 2022-03-25 00:00:13 --> Output Class Initialized
INFO - 2022-03-25 00:00:13 --> Security Class Initialized
DEBUG - 2022-03-25 00:00:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 00:00:13 --> Input Class Initialized
INFO - 2022-03-25 00:00:13 --> Language Class Initialized
ERROR - 2022-03-25 00:00:13 --> 404 Page Not Found: Karoclient/usersprofile
INFO - 2022-03-25 00:00:14 --> Final output sent to browser
DEBUG - 2022-03-25 00:00:14 --> Total execution time: 10.0700
ERROR - 2022-03-25 00:00:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 00:00:41 --> Config Class Initialized
INFO - 2022-03-25 00:00:41 --> Hooks Class Initialized
DEBUG - 2022-03-25 00:00:41 --> UTF-8 Support Enabled
INFO - 2022-03-25 00:00:41 --> Utf8 Class Initialized
INFO - 2022-03-25 00:00:41 --> URI Class Initialized
INFO - 2022-03-25 00:00:41 --> Router Class Initialized
INFO - 2022-03-25 00:00:41 --> Output Class Initialized
INFO - 2022-03-25 00:00:41 --> Security Class Initialized
DEBUG - 2022-03-25 00:00:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 00:00:41 --> Input Class Initialized
INFO - 2022-03-25 00:00:41 --> Language Class Initialized
INFO - 2022-03-25 00:00:41 --> Loader Class Initialized
INFO - 2022-03-25 00:00:41 --> Helper loaded: url_helper
INFO - 2022-03-25 00:00:41 --> Helper loaded: form_helper
INFO - 2022-03-25 00:00:41 --> Helper loaded: common_helper
INFO - 2022-03-25 00:00:41 --> Database Driver Class Initialized
DEBUG - 2022-03-25 00:00:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 00:00:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 00:00:41 --> Controller Class Initialized
INFO - 2022-03-25 00:00:41 --> Form Validation Class Initialized
DEBUG - 2022-03-25 00:00:41 --> Encrypt Class Initialized
INFO - 2022-03-25 00:00:41 --> Model "Patient_model" initialized
INFO - 2022-03-25 00:00:41 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 00:00:41 --> Model "Referredby_model" initialized
INFO - 2022-03-25 00:00:41 --> Model "Prefix_master" initialized
INFO - 2022-03-25 00:00:41 --> Model "Hospital_model" initialized
INFO - 2022-03-25 00:00:41 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-25 00:00:41 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-25 00:00:41 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-25 00:00:41 --> Final output sent to browser
DEBUG - 2022-03-25 00:00:41 --> Total execution time: 0.0447
ERROR - 2022-03-25 00:00:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 00:00:41 --> Config Class Initialized
INFO - 2022-03-25 00:00:41 --> Hooks Class Initialized
DEBUG - 2022-03-25 00:00:41 --> UTF-8 Support Enabled
INFO - 2022-03-25 00:00:41 --> Utf8 Class Initialized
INFO - 2022-03-25 00:00:41 --> URI Class Initialized
INFO - 2022-03-25 00:00:41 --> Router Class Initialized
INFO - 2022-03-25 00:00:41 --> Output Class Initialized
INFO - 2022-03-25 00:00:41 --> Security Class Initialized
DEBUG - 2022-03-25 00:00:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 00:00:41 --> Input Class Initialized
INFO - 2022-03-25 00:00:41 --> Language Class Initialized
ERROR - 2022-03-25 00:00:41 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-25 00:00:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 00:00:43 --> Config Class Initialized
INFO - 2022-03-25 00:00:43 --> Hooks Class Initialized
DEBUG - 2022-03-25 00:00:43 --> UTF-8 Support Enabled
INFO - 2022-03-25 00:00:43 --> Utf8 Class Initialized
INFO - 2022-03-25 00:00:43 --> URI Class Initialized
INFO - 2022-03-25 00:00:43 --> Router Class Initialized
INFO - 2022-03-25 00:00:43 --> Output Class Initialized
INFO - 2022-03-25 00:00:43 --> Security Class Initialized
DEBUG - 2022-03-25 00:00:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 00:00:43 --> Input Class Initialized
INFO - 2022-03-25 00:00:43 --> Language Class Initialized
INFO - 2022-03-25 00:00:43 --> Loader Class Initialized
INFO - 2022-03-25 00:00:43 --> Helper loaded: url_helper
INFO - 2022-03-25 00:00:43 --> Helper loaded: form_helper
INFO - 2022-03-25 00:00:43 --> Helper loaded: common_helper
INFO - 2022-03-25 00:00:43 --> Database Driver Class Initialized
DEBUG - 2022-03-25 00:00:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 00:00:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 00:00:43 --> Controller Class Initialized
INFO - 2022-03-25 00:00:43 --> Form Validation Class Initialized
DEBUG - 2022-03-25 00:00:43 --> Encrypt Class Initialized
INFO - 2022-03-25 00:00:43 --> Model "Patient_model" initialized
INFO - 2022-03-25 00:00:43 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 00:00:43 --> Model "Referredby_model" initialized
INFO - 2022-03-25 00:00:43 --> Model "Prefix_master" initialized
INFO - 2022-03-25 00:00:43 --> Model "Hospital_model" initialized
ERROR - 2022-03-25 00:00:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 00:00:43 --> Config Class Initialized
INFO - 2022-03-25 00:00:43 --> Hooks Class Initialized
DEBUG - 2022-03-25 00:00:43 --> UTF-8 Support Enabled
INFO - 2022-03-25 00:00:43 --> Utf8 Class Initialized
INFO - 2022-03-25 00:00:43 --> URI Class Initialized
INFO - 2022-03-25 00:00:43 --> Router Class Initialized
INFO - 2022-03-25 00:00:43 --> Output Class Initialized
INFO - 2022-03-25 00:00:43 --> Security Class Initialized
DEBUG - 2022-03-25 00:00:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 00:00:43 --> Input Class Initialized
INFO - 2022-03-25 00:00:43 --> Language Class Initialized
INFO - 2022-03-25 00:00:43 --> Loader Class Initialized
INFO - 2022-03-25 00:00:43 --> Helper loaded: url_helper
INFO - 2022-03-25 00:00:43 --> Helper loaded: form_helper
INFO - 2022-03-25 00:00:43 --> Helper loaded: common_helper
INFO - 2022-03-25 00:00:43 --> Database Driver Class Initialized
DEBUG - 2022-03-25 00:00:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 00:00:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 00:00:43 --> Controller Class Initialized
INFO - 2022-03-25 00:00:43 --> Form Validation Class Initialized
DEBUG - 2022-03-25 00:00:43 --> Encrypt Class Initialized
INFO - 2022-03-25 00:00:43 --> Model "Patient_model" initialized
INFO - 2022-03-25 00:00:43 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 00:00:43 --> Model "Referredby_model" initialized
INFO - 2022-03-25 00:00:43 --> Model "Prefix_master" initialized
INFO - 2022-03-25 00:00:43 --> Model "Hospital_model" initialized
INFO - 2022-03-25 00:00:44 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-25 00:00:44 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-25 00:00:44 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-25 00:00:44 --> Final output sent to browser
DEBUG - 2022-03-25 00:00:44 --> Total execution time: 0.0281
ERROR - 2022-03-25 00:00:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 00:00:44 --> Config Class Initialized
INFO - 2022-03-25 00:00:44 --> Hooks Class Initialized
DEBUG - 2022-03-25 00:00:44 --> UTF-8 Support Enabled
INFO - 2022-03-25 00:00:44 --> Utf8 Class Initialized
INFO - 2022-03-25 00:00:44 --> URI Class Initialized
INFO - 2022-03-25 00:00:44 --> Router Class Initialized
INFO - 2022-03-25 00:00:44 --> Output Class Initialized
INFO - 2022-03-25 00:00:44 --> Security Class Initialized
DEBUG - 2022-03-25 00:00:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 00:00:44 --> Input Class Initialized
INFO - 2022-03-25 00:00:44 --> Language Class Initialized
INFO - 2022-03-25 00:00:44 --> Loader Class Initialized
INFO - 2022-03-25 00:00:44 --> Helper loaded: url_helper
INFO - 2022-03-25 00:00:44 --> Helper loaded: form_helper
INFO - 2022-03-25 00:00:44 --> Helper loaded: common_helper
INFO - 2022-03-25 00:00:44 --> Database Driver Class Initialized
DEBUG - 2022-03-25 00:00:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 00:00:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 00:00:44 --> Controller Class Initialized
INFO - 2022-03-25 00:00:44 --> Form Validation Class Initialized
DEBUG - 2022-03-25 00:00:44 --> Encrypt Class Initialized
INFO - 2022-03-25 00:00:44 --> Model "Patient_model" initialized
INFO - 2022-03-25 00:00:44 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 00:00:44 --> Model "Prefix_master" initialized
INFO - 2022-03-25 00:00:44 --> Model "Users_model" initialized
INFO - 2022-03-25 00:00:44 --> Model "Hospital_model" initialized
INFO - 2022-03-25 00:00:44 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-25 00:00:44 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-25 00:00:44 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-25 00:00:44 --> Final output sent to browser
DEBUG - 2022-03-25 00:00:44 --> Total execution time: 0.0885
ERROR - 2022-03-25 00:00:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 00:00:58 --> Config Class Initialized
INFO - 2022-03-25 00:00:58 --> Hooks Class Initialized
DEBUG - 2022-03-25 00:00:58 --> UTF-8 Support Enabled
INFO - 2022-03-25 00:00:58 --> Utf8 Class Initialized
INFO - 2022-03-25 00:00:58 --> URI Class Initialized
INFO - 2022-03-25 00:00:58 --> Router Class Initialized
INFO - 2022-03-25 00:00:58 --> Output Class Initialized
INFO - 2022-03-25 00:00:58 --> Security Class Initialized
DEBUG - 2022-03-25 00:00:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 00:00:58 --> Input Class Initialized
INFO - 2022-03-25 00:00:58 --> Language Class Initialized
INFO - 2022-03-25 00:00:58 --> Loader Class Initialized
INFO - 2022-03-25 00:00:58 --> Helper loaded: url_helper
INFO - 2022-03-25 00:00:58 --> Helper loaded: form_helper
INFO - 2022-03-25 00:00:58 --> Helper loaded: common_helper
INFO - 2022-03-25 00:00:58 --> Database Driver Class Initialized
DEBUG - 2022-03-25 00:00:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 00:00:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 00:00:58 --> Controller Class Initialized
INFO - 2022-03-25 00:00:58 --> Form Validation Class Initialized
DEBUG - 2022-03-25 00:00:58 --> Encrypt Class Initialized
INFO - 2022-03-25 00:00:58 --> Model "Patient_model" initialized
INFO - 2022-03-25 00:00:58 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 00:00:58 --> Model "Referredby_model" initialized
INFO - 2022-03-25 00:00:58 --> Model "Prefix_master" initialized
INFO - 2022-03-25 00:00:58 --> Model "Hospital_model" initialized
ERROR - 2022-03-25 00:00:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 00:00:58 --> Config Class Initialized
INFO - 2022-03-25 00:00:58 --> Hooks Class Initialized
DEBUG - 2022-03-25 00:00:58 --> UTF-8 Support Enabled
INFO - 2022-03-25 00:00:58 --> Utf8 Class Initialized
INFO - 2022-03-25 00:00:58 --> URI Class Initialized
INFO - 2022-03-25 00:00:58 --> Router Class Initialized
INFO - 2022-03-25 00:00:58 --> Output Class Initialized
INFO - 2022-03-25 00:00:58 --> Security Class Initialized
DEBUG - 2022-03-25 00:00:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 00:00:58 --> Input Class Initialized
INFO - 2022-03-25 00:00:58 --> Language Class Initialized
INFO - 2022-03-25 00:00:58 --> Loader Class Initialized
INFO - 2022-03-25 00:00:58 --> Helper loaded: url_helper
INFO - 2022-03-25 00:00:58 --> Helper loaded: form_helper
INFO - 2022-03-25 00:00:58 --> Helper loaded: common_helper
INFO - 2022-03-25 00:00:58 --> Database Driver Class Initialized
DEBUG - 2022-03-25 00:00:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 00:00:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 00:00:58 --> Controller Class Initialized
INFO - 2022-03-25 00:00:58 --> Form Validation Class Initialized
DEBUG - 2022-03-25 00:00:58 --> Encrypt Class Initialized
INFO - 2022-03-25 00:00:58 --> Model "Patient_model" initialized
INFO - 2022-03-25 00:00:58 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 00:00:58 --> Model "Referredby_model" initialized
INFO - 2022-03-25 00:00:58 --> Model "Prefix_master" initialized
INFO - 2022-03-25 00:00:58 --> Model "Hospital_model" initialized
INFO - 2022-03-25 00:00:59 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-25 00:01:06 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-25 00:01:06 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
ERROR - 2022-03-25 00:01:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 00:01:07 --> Config Class Initialized
INFO - 2022-03-25 00:01:07 --> Hooks Class Initialized
DEBUG - 2022-03-25 00:01:07 --> UTF-8 Support Enabled
INFO - 2022-03-25 00:01:07 --> Utf8 Class Initialized
INFO - 2022-03-25 00:01:07 --> URI Class Initialized
INFO - 2022-03-25 00:01:07 --> Router Class Initialized
INFO - 2022-03-25 00:01:07 --> Output Class Initialized
INFO - 2022-03-25 00:01:07 --> Security Class Initialized
DEBUG - 2022-03-25 00:01:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 00:01:07 --> Input Class Initialized
INFO - 2022-03-25 00:01:07 --> Language Class Initialized
ERROR - 2022-03-25 00:01:07 --> 404 Page Not Found: Karoclient/usersprofile
INFO - 2022-03-25 00:01:08 --> Final output sent to browser
DEBUG - 2022-03-25 00:01:08 --> Total execution time: 7.3763
ERROR - 2022-03-25 00:01:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 00:01:40 --> Config Class Initialized
INFO - 2022-03-25 00:01:40 --> Hooks Class Initialized
DEBUG - 2022-03-25 00:01:40 --> UTF-8 Support Enabled
INFO - 2022-03-25 00:01:40 --> Utf8 Class Initialized
INFO - 2022-03-25 00:01:40 --> URI Class Initialized
INFO - 2022-03-25 00:01:40 --> Router Class Initialized
INFO - 2022-03-25 00:01:40 --> Output Class Initialized
INFO - 2022-03-25 00:01:40 --> Security Class Initialized
DEBUG - 2022-03-25 00:01:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 00:01:40 --> Input Class Initialized
INFO - 2022-03-25 00:01:40 --> Language Class Initialized
INFO - 2022-03-25 00:01:40 --> Loader Class Initialized
INFO - 2022-03-25 00:01:40 --> Helper loaded: url_helper
INFO - 2022-03-25 00:01:40 --> Helper loaded: form_helper
INFO - 2022-03-25 00:01:40 --> Helper loaded: common_helper
INFO - 2022-03-25 00:01:40 --> Database Driver Class Initialized
DEBUG - 2022-03-25 00:01:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 00:01:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 00:01:40 --> Controller Class Initialized
INFO - 2022-03-25 00:01:40 --> Form Validation Class Initialized
DEBUG - 2022-03-25 00:01:40 --> Encrypt Class Initialized
INFO - 2022-03-25 00:01:40 --> Model "Patient_model" initialized
INFO - 2022-03-25 00:01:40 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 00:01:40 --> Model "Referredby_model" initialized
INFO - 2022-03-25 00:01:40 --> Model "Prefix_master" initialized
INFO - 2022-03-25 00:01:40 --> Model "Hospital_model" initialized
INFO - 2022-03-25 00:01:40 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-25 00:01:40 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-25 00:01:40 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-25 00:01:40 --> Final output sent to browser
DEBUG - 2022-03-25 00:01:40 --> Total execution time: 0.0324
ERROR - 2022-03-25 00:01:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 00:01:41 --> Config Class Initialized
INFO - 2022-03-25 00:01:41 --> Hooks Class Initialized
DEBUG - 2022-03-25 00:01:41 --> UTF-8 Support Enabled
INFO - 2022-03-25 00:01:41 --> Utf8 Class Initialized
INFO - 2022-03-25 00:01:41 --> URI Class Initialized
INFO - 2022-03-25 00:01:41 --> Router Class Initialized
INFO - 2022-03-25 00:01:41 --> Output Class Initialized
INFO - 2022-03-25 00:01:41 --> Security Class Initialized
DEBUG - 2022-03-25 00:01:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 00:01:41 --> Input Class Initialized
INFO - 2022-03-25 00:01:41 --> Language Class Initialized
ERROR - 2022-03-25 00:01:41 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-25 00:02:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 00:02:01 --> Config Class Initialized
INFO - 2022-03-25 00:02:01 --> Hooks Class Initialized
DEBUG - 2022-03-25 00:02:01 --> UTF-8 Support Enabled
INFO - 2022-03-25 00:02:01 --> Utf8 Class Initialized
INFO - 2022-03-25 00:02:01 --> URI Class Initialized
INFO - 2022-03-25 00:02:01 --> Router Class Initialized
INFO - 2022-03-25 00:02:01 --> Output Class Initialized
INFO - 2022-03-25 00:02:01 --> Security Class Initialized
DEBUG - 2022-03-25 00:02:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 00:02:01 --> Input Class Initialized
INFO - 2022-03-25 00:02:01 --> Language Class Initialized
INFO - 2022-03-25 00:02:01 --> Loader Class Initialized
INFO - 2022-03-25 00:02:01 --> Helper loaded: url_helper
INFO - 2022-03-25 00:02:01 --> Helper loaded: form_helper
INFO - 2022-03-25 00:02:01 --> Helper loaded: common_helper
INFO - 2022-03-25 00:02:01 --> Database Driver Class Initialized
DEBUG - 2022-03-25 00:02:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 00:02:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 00:02:01 --> Controller Class Initialized
INFO - 2022-03-25 00:02:01 --> Form Validation Class Initialized
DEBUG - 2022-03-25 00:02:01 --> Encrypt Class Initialized
INFO - 2022-03-25 00:02:01 --> Model "Patient_model" initialized
INFO - 2022-03-25 00:02:01 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 00:02:01 --> Model "Referredby_model" initialized
INFO - 2022-03-25 00:02:01 --> Model "Prefix_master" initialized
INFO - 2022-03-25 00:02:01 --> Model "Hospital_model" initialized
ERROR - 2022-03-25 00:02:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 00:02:02 --> Config Class Initialized
INFO - 2022-03-25 00:02:02 --> Hooks Class Initialized
DEBUG - 2022-03-25 00:02:02 --> UTF-8 Support Enabled
INFO - 2022-03-25 00:02:02 --> Utf8 Class Initialized
INFO - 2022-03-25 00:02:02 --> URI Class Initialized
INFO - 2022-03-25 00:02:02 --> Router Class Initialized
INFO - 2022-03-25 00:02:02 --> Output Class Initialized
INFO - 2022-03-25 00:02:02 --> Security Class Initialized
DEBUG - 2022-03-25 00:02:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 00:02:02 --> Input Class Initialized
INFO - 2022-03-25 00:02:02 --> Language Class Initialized
INFO - 2022-03-25 00:02:02 --> Loader Class Initialized
INFO - 2022-03-25 00:02:02 --> Helper loaded: url_helper
INFO - 2022-03-25 00:02:02 --> Helper loaded: form_helper
INFO - 2022-03-25 00:02:02 --> Helper loaded: common_helper
INFO - 2022-03-25 00:02:02 --> Database Driver Class Initialized
DEBUG - 2022-03-25 00:02:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 00:02:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 00:02:02 --> Controller Class Initialized
INFO - 2022-03-25 00:02:02 --> Form Validation Class Initialized
DEBUG - 2022-03-25 00:02:02 --> Encrypt Class Initialized
INFO - 2022-03-25 00:02:02 --> Model "Patient_model" initialized
INFO - 2022-03-25 00:02:02 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 00:02:02 --> Model "Referredby_model" initialized
INFO - 2022-03-25 00:02:02 --> Model "Prefix_master" initialized
INFO - 2022-03-25 00:02:02 --> Model "Hospital_model" initialized
INFO - 2022-03-25 00:02:02 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-25 00:02:02 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-25 00:02:02 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-25 00:02:02 --> Final output sent to browser
DEBUG - 2022-03-25 00:02:02 --> Total execution time: 0.0344
ERROR - 2022-03-25 00:02:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 00:02:02 --> Config Class Initialized
INFO - 2022-03-25 00:02:02 --> Hooks Class Initialized
DEBUG - 2022-03-25 00:02:02 --> UTF-8 Support Enabled
INFO - 2022-03-25 00:02:02 --> Utf8 Class Initialized
INFO - 2022-03-25 00:02:02 --> URI Class Initialized
INFO - 2022-03-25 00:02:02 --> Router Class Initialized
INFO - 2022-03-25 00:02:02 --> Output Class Initialized
INFO - 2022-03-25 00:02:02 --> Security Class Initialized
DEBUG - 2022-03-25 00:02:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 00:02:02 --> Input Class Initialized
INFO - 2022-03-25 00:02:02 --> Language Class Initialized
ERROR - 2022-03-25 00:02:02 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-25 00:02:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 00:02:03 --> Config Class Initialized
INFO - 2022-03-25 00:02:03 --> Hooks Class Initialized
DEBUG - 2022-03-25 00:02:03 --> UTF-8 Support Enabled
INFO - 2022-03-25 00:02:03 --> Utf8 Class Initialized
INFO - 2022-03-25 00:02:03 --> URI Class Initialized
INFO - 2022-03-25 00:02:03 --> Router Class Initialized
INFO - 2022-03-25 00:02:03 --> Output Class Initialized
INFO - 2022-03-25 00:02:03 --> Security Class Initialized
DEBUG - 2022-03-25 00:02:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 00:02:03 --> Input Class Initialized
INFO - 2022-03-25 00:02:03 --> Language Class Initialized
INFO - 2022-03-25 00:02:03 --> Loader Class Initialized
INFO - 2022-03-25 00:02:03 --> Helper loaded: url_helper
INFO - 2022-03-25 00:02:03 --> Helper loaded: form_helper
INFO - 2022-03-25 00:02:03 --> Helper loaded: common_helper
INFO - 2022-03-25 00:02:03 --> Database Driver Class Initialized
DEBUG - 2022-03-25 00:02:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 00:02:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 00:02:03 --> Controller Class Initialized
INFO - 2022-03-25 00:02:03 --> Form Validation Class Initialized
DEBUG - 2022-03-25 00:02:03 --> Encrypt Class Initialized
INFO - 2022-03-25 00:02:03 --> Model "Patient_model" initialized
INFO - 2022-03-25 00:02:03 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 00:02:03 --> Model "Prefix_master" initialized
INFO - 2022-03-25 00:02:03 --> Model "Users_model" initialized
INFO - 2022-03-25 00:02:03 --> Model "Hospital_model" initialized
INFO - 2022-03-25 00:02:03 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-25 00:02:03 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-25 00:02:03 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-25 00:02:03 --> Final output sent to browser
DEBUG - 2022-03-25 00:02:03 --> Total execution time: 0.0475
ERROR - 2022-03-25 00:02:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 00:02:03 --> Config Class Initialized
INFO - 2022-03-25 00:02:03 --> Hooks Class Initialized
DEBUG - 2022-03-25 00:02:03 --> UTF-8 Support Enabled
INFO - 2022-03-25 00:02:03 --> Utf8 Class Initialized
INFO - 2022-03-25 00:02:03 --> URI Class Initialized
INFO - 2022-03-25 00:02:03 --> Router Class Initialized
INFO - 2022-03-25 00:02:03 --> Output Class Initialized
INFO - 2022-03-25 00:02:03 --> Security Class Initialized
DEBUG - 2022-03-25 00:02:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 00:02:03 --> Input Class Initialized
INFO - 2022-03-25 00:02:03 --> Language Class Initialized
ERROR - 2022-03-25 00:02:03 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-25 00:07:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 00:07:50 --> Config Class Initialized
INFO - 2022-03-25 00:07:50 --> Hooks Class Initialized
DEBUG - 2022-03-25 00:07:50 --> UTF-8 Support Enabled
INFO - 2022-03-25 00:07:50 --> Utf8 Class Initialized
INFO - 2022-03-25 00:07:50 --> URI Class Initialized
INFO - 2022-03-25 00:07:50 --> Router Class Initialized
INFO - 2022-03-25 00:07:50 --> Output Class Initialized
INFO - 2022-03-25 00:07:50 --> Security Class Initialized
DEBUG - 2022-03-25 00:07:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 00:07:50 --> Input Class Initialized
INFO - 2022-03-25 00:07:50 --> Language Class Initialized
INFO - 2022-03-25 00:07:50 --> Loader Class Initialized
INFO - 2022-03-25 00:07:50 --> Helper loaded: url_helper
INFO - 2022-03-25 00:07:50 --> Helper loaded: form_helper
INFO - 2022-03-25 00:07:50 --> Helper loaded: common_helper
INFO - 2022-03-25 00:07:50 --> Database Driver Class Initialized
DEBUG - 2022-03-25 00:07:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 00:07:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 00:07:50 --> Controller Class Initialized
INFO - 2022-03-25 00:07:50 --> Form Validation Class Initialized
DEBUG - 2022-03-25 00:07:50 --> Encrypt Class Initialized
INFO - 2022-03-25 00:07:50 --> Model "Patient_model" initialized
INFO - 2022-03-25 00:07:50 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 00:07:50 --> Model "Prefix_master" initialized
INFO - 2022-03-25 00:07:50 --> Model "Users_model" initialized
INFO - 2022-03-25 00:07:50 --> Model "Hospital_model" initialized
ERROR - 2022-03-25 00:07:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 00:07:51 --> Config Class Initialized
INFO - 2022-03-25 00:07:51 --> Hooks Class Initialized
DEBUG - 2022-03-25 00:07:51 --> UTF-8 Support Enabled
INFO - 2022-03-25 00:07:51 --> Utf8 Class Initialized
INFO - 2022-03-25 00:07:51 --> URI Class Initialized
INFO - 2022-03-25 00:07:51 --> Router Class Initialized
INFO - 2022-03-25 00:07:51 --> Output Class Initialized
INFO - 2022-03-25 00:07:51 --> Security Class Initialized
DEBUG - 2022-03-25 00:07:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 00:07:51 --> Input Class Initialized
INFO - 2022-03-25 00:07:51 --> Language Class Initialized
INFO - 2022-03-25 00:07:51 --> Loader Class Initialized
INFO - 2022-03-25 00:07:51 --> Helper loaded: url_helper
INFO - 2022-03-25 00:07:51 --> Helper loaded: form_helper
INFO - 2022-03-25 00:07:51 --> Helper loaded: common_helper
INFO - 2022-03-25 00:07:51 --> Database Driver Class Initialized
DEBUG - 2022-03-25 00:07:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 00:07:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 00:07:51 --> Controller Class Initialized
INFO - 2022-03-25 00:07:51 --> Form Validation Class Initialized
DEBUG - 2022-03-25 00:07:51 --> Encrypt Class Initialized
INFO - 2022-03-25 00:07:51 --> Model "Patient_model" initialized
INFO - 2022-03-25 00:07:51 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 00:07:51 --> Model "Prefix_master" initialized
INFO - 2022-03-25 00:07:51 --> Model "Users_model" initialized
INFO - 2022-03-25 00:07:51 --> Model "Hospital_model" initialized
INFO - 2022-03-25 00:07:51 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-25 00:07:51 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-25 00:07:51 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-25 00:07:51 --> Final output sent to browser
DEBUG - 2022-03-25 00:07:51 --> Total execution time: 0.0453
ERROR - 2022-03-25 00:07:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 00:07:51 --> Config Class Initialized
INFO - 2022-03-25 00:07:51 --> Hooks Class Initialized
DEBUG - 2022-03-25 00:07:51 --> UTF-8 Support Enabled
INFO - 2022-03-25 00:07:51 --> Utf8 Class Initialized
INFO - 2022-03-25 00:07:51 --> URI Class Initialized
INFO - 2022-03-25 00:07:51 --> Router Class Initialized
INFO - 2022-03-25 00:07:51 --> Output Class Initialized
INFO - 2022-03-25 00:07:51 --> Security Class Initialized
DEBUG - 2022-03-25 00:07:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 00:07:51 --> Input Class Initialized
INFO - 2022-03-25 00:07:51 --> Language Class Initialized
ERROR - 2022-03-25 00:07:51 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-25 00:08:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 00:08:00 --> Config Class Initialized
INFO - 2022-03-25 00:08:00 --> Hooks Class Initialized
DEBUG - 2022-03-25 00:08:00 --> UTF-8 Support Enabled
INFO - 2022-03-25 00:08:00 --> Utf8 Class Initialized
INFO - 2022-03-25 00:08:00 --> URI Class Initialized
INFO - 2022-03-25 00:08:00 --> Router Class Initialized
INFO - 2022-03-25 00:08:00 --> Output Class Initialized
INFO - 2022-03-25 00:08:00 --> Security Class Initialized
DEBUG - 2022-03-25 00:08:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 00:08:00 --> Input Class Initialized
INFO - 2022-03-25 00:08:00 --> Language Class Initialized
INFO - 2022-03-25 00:08:00 --> Loader Class Initialized
INFO - 2022-03-25 00:08:00 --> Helper loaded: url_helper
INFO - 2022-03-25 00:08:00 --> Helper loaded: form_helper
INFO - 2022-03-25 00:08:00 --> Helper loaded: common_helper
INFO - 2022-03-25 00:08:00 --> Database Driver Class Initialized
DEBUG - 2022-03-25 00:08:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 00:08:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 00:08:00 --> Controller Class Initialized
INFO - 2022-03-25 00:08:00 --> Form Validation Class Initialized
DEBUG - 2022-03-25 00:08:00 --> Encrypt Class Initialized
INFO - 2022-03-25 00:08:00 --> Model "Patient_model" initialized
INFO - 2022-03-25 00:08:00 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 00:08:00 --> Model "Referredby_model" initialized
INFO - 2022-03-25 00:08:00 --> Model "Prefix_master" initialized
INFO - 2022-03-25 00:08:00 --> Model "Hospital_model" initialized
INFO - 2022-03-25 00:08:01 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-25 00:08:07 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-25 00:08:07 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
ERROR - 2022-03-25 00:08:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 00:08:08 --> Config Class Initialized
INFO - 2022-03-25 00:08:08 --> Hooks Class Initialized
DEBUG - 2022-03-25 00:08:08 --> UTF-8 Support Enabled
INFO - 2022-03-25 00:08:08 --> Utf8 Class Initialized
INFO - 2022-03-25 00:08:08 --> URI Class Initialized
INFO - 2022-03-25 00:08:08 --> Router Class Initialized
INFO - 2022-03-25 00:08:08 --> Output Class Initialized
INFO - 2022-03-25 00:08:08 --> Security Class Initialized
DEBUG - 2022-03-25 00:08:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 00:08:08 --> Input Class Initialized
INFO - 2022-03-25 00:08:08 --> Language Class Initialized
ERROR - 2022-03-25 00:08:08 --> 404 Page Not Found: Karoclient/usersprofile
INFO - 2022-03-25 00:08:08 --> Final output sent to browser
DEBUG - 2022-03-25 00:08:08 --> Total execution time: 6.3266
ERROR - 2022-03-25 00:08:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 00:08:32 --> Config Class Initialized
INFO - 2022-03-25 00:08:32 --> Hooks Class Initialized
DEBUG - 2022-03-25 00:08:32 --> UTF-8 Support Enabled
INFO - 2022-03-25 00:08:32 --> Utf8 Class Initialized
INFO - 2022-03-25 00:08:32 --> URI Class Initialized
INFO - 2022-03-25 00:08:32 --> Router Class Initialized
INFO - 2022-03-25 00:08:32 --> Output Class Initialized
INFO - 2022-03-25 00:08:32 --> Security Class Initialized
DEBUG - 2022-03-25 00:08:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 00:08:32 --> Input Class Initialized
INFO - 2022-03-25 00:08:32 --> Language Class Initialized
INFO - 2022-03-25 00:08:32 --> Loader Class Initialized
INFO - 2022-03-25 00:08:32 --> Helper loaded: url_helper
INFO - 2022-03-25 00:08:32 --> Helper loaded: form_helper
INFO - 2022-03-25 00:08:32 --> Helper loaded: common_helper
INFO - 2022-03-25 00:08:32 --> Database Driver Class Initialized
DEBUG - 2022-03-25 00:08:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 00:08:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 00:08:32 --> Controller Class Initialized
INFO - 2022-03-25 00:08:32 --> Form Validation Class Initialized
DEBUG - 2022-03-25 00:08:32 --> Encrypt Class Initialized
INFO - 2022-03-25 00:08:32 --> Model "Patient_model" initialized
INFO - 2022-03-25 00:08:32 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 00:08:32 --> Model "Referredby_model" initialized
INFO - 2022-03-25 00:08:32 --> Model "Prefix_master" initialized
INFO - 2022-03-25 00:08:32 --> Model "Hospital_model" initialized
INFO - 2022-03-25 00:08:32 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-25 00:08:32 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-25 00:08:32 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-25 00:08:32 --> Final output sent to browser
DEBUG - 2022-03-25 00:08:32 --> Total execution time: 0.0317
ERROR - 2022-03-25 00:08:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 00:08:33 --> Config Class Initialized
INFO - 2022-03-25 00:08:33 --> Hooks Class Initialized
DEBUG - 2022-03-25 00:08:33 --> UTF-8 Support Enabled
INFO - 2022-03-25 00:08:33 --> Utf8 Class Initialized
INFO - 2022-03-25 00:08:33 --> URI Class Initialized
INFO - 2022-03-25 00:08:33 --> Router Class Initialized
INFO - 2022-03-25 00:08:33 --> Output Class Initialized
INFO - 2022-03-25 00:08:33 --> Security Class Initialized
DEBUG - 2022-03-25 00:08:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 00:08:33 --> Input Class Initialized
INFO - 2022-03-25 00:08:33 --> Language Class Initialized
ERROR - 2022-03-25 00:08:33 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-25 00:13:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 00:13:22 --> Config Class Initialized
INFO - 2022-03-25 00:13:22 --> Hooks Class Initialized
DEBUG - 2022-03-25 00:13:22 --> UTF-8 Support Enabled
INFO - 2022-03-25 00:13:22 --> Utf8 Class Initialized
INFO - 2022-03-25 00:13:22 --> URI Class Initialized
INFO - 2022-03-25 00:13:22 --> Router Class Initialized
INFO - 2022-03-25 00:13:22 --> Output Class Initialized
INFO - 2022-03-25 00:13:22 --> Security Class Initialized
DEBUG - 2022-03-25 00:13:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 00:13:22 --> Input Class Initialized
INFO - 2022-03-25 00:13:22 --> Language Class Initialized
INFO - 2022-03-25 00:13:22 --> Loader Class Initialized
INFO - 2022-03-25 00:13:22 --> Helper loaded: url_helper
INFO - 2022-03-25 00:13:22 --> Helper loaded: form_helper
INFO - 2022-03-25 00:13:22 --> Helper loaded: common_helper
INFO - 2022-03-25 00:13:22 --> Database Driver Class Initialized
DEBUG - 2022-03-25 00:13:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 00:13:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 00:13:22 --> Controller Class Initialized
INFO - 2022-03-25 00:13:22 --> Form Validation Class Initialized
DEBUG - 2022-03-25 00:13:22 --> Encrypt Class Initialized
INFO - 2022-03-25 00:13:22 --> Model "Patient_model" initialized
INFO - 2022-03-25 00:13:22 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 00:13:22 --> Model "Referredby_model" initialized
INFO - 2022-03-25 00:13:22 --> Model "Prefix_master" initialized
INFO - 2022-03-25 00:13:22 --> Model "Hospital_model" initialized
ERROR - 2022-03-25 00:13:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 00:13:23 --> Config Class Initialized
INFO - 2022-03-25 00:13:23 --> Hooks Class Initialized
DEBUG - 2022-03-25 00:13:23 --> UTF-8 Support Enabled
INFO - 2022-03-25 00:13:23 --> Utf8 Class Initialized
INFO - 2022-03-25 00:13:23 --> URI Class Initialized
INFO - 2022-03-25 00:13:23 --> Router Class Initialized
INFO - 2022-03-25 00:13:23 --> Output Class Initialized
INFO - 2022-03-25 00:13:23 --> Security Class Initialized
DEBUG - 2022-03-25 00:13:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 00:13:23 --> Input Class Initialized
INFO - 2022-03-25 00:13:23 --> Language Class Initialized
INFO - 2022-03-25 00:13:23 --> Loader Class Initialized
INFO - 2022-03-25 00:13:23 --> Helper loaded: url_helper
INFO - 2022-03-25 00:13:23 --> Helper loaded: form_helper
INFO - 2022-03-25 00:13:23 --> Helper loaded: common_helper
INFO - 2022-03-25 00:13:23 --> Database Driver Class Initialized
DEBUG - 2022-03-25 00:13:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 00:13:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 00:13:23 --> Controller Class Initialized
INFO - 2022-03-25 00:13:23 --> Form Validation Class Initialized
DEBUG - 2022-03-25 00:13:23 --> Encrypt Class Initialized
INFO - 2022-03-25 00:13:23 --> Model "Patient_model" initialized
INFO - 2022-03-25 00:13:23 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 00:13:23 --> Model "Referredby_model" initialized
INFO - 2022-03-25 00:13:23 --> Model "Prefix_master" initialized
INFO - 2022-03-25 00:13:23 --> Model "Hospital_model" initialized
INFO - 2022-03-25 00:13:23 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-25 00:13:23 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-25 00:13:23 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-25 00:13:23 --> Final output sent to browser
DEBUG - 2022-03-25 00:13:23 --> Total execution time: 0.0280
ERROR - 2022-03-25 00:13:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 00:13:23 --> Config Class Initialized
INFO - 2022-03-25 00:13:23 --> Hooks Class Initialized
DEBUG - 2022-03-25 00:13:23 --> UTF-8 Support Enabled
INFO - 2022-03-25 00:13:23 --> Utf8 Class Initialized
INFO - 2022-03-25 00:13:23 --> URI Class Initialized
INFO - 2022-03-25 00:13:23 --> Router Class Initialized
INFO - 2022-03-25 00:13:23 --> Output Class Initialized
INFO - 2022-03-25 00:13:23 --> Security Class Initialized
DEBUG - 2022-03-25 00:13:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 00:13:23 --> Input Class Initialized
INFO - 2022-03-25 00:13:23 --> Language Class Initialized
ERROR - 2022-03-25 00:13:23 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-25 00:13:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 00:13:23 --> Config Class Initialized
INFO - 2022-03-25 00:13:23 --> Hooks Class Initialized
DEBUG - 2022-03-25 00:13:23 --> UTF-8 Support Enabled
INFO - 2022-03-25 00:13:23 --> Utf8 Class Initialized
INFO - 2022-03-25 00:13:23 --> URI Class Initialized
INFO - 2022-03-25 00:13:23 --> Router Class Initialized
INFO - 2022-03-25 00:13:23 --> Output Class Initialized
INFO - 2022-03-25 00:13:23 --> Security Class Initialized
DEBUG - 2022-03-25 00:13:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 00:13:23 --> Input Class Initialized
INFO - 2022-03-25 00:13:23 --> Language Class Initialized
INFO - 2022-03-25 00:13:23 --> Loader Class Initialized
INFO - 2022-03-25 00:13:23 --> Helper loaded: url_helper
INFO - 2022-03-25 00:13:23 --> Helper loaded: form_helper
INFO - 2022-03-25 00:13:23 --> Helper loaded: common_helper
INFO - 2022-03-25 00:13:23 --> Database Driver Class Initialized
DEBUG - 2022-03-25 00:13:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 00:13:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 00:13:23 --> Controller Class Initialized
INFO - 2022-03-25 00:13:23 --> Form Validation Class Initialized
DEBUG - 2022-03-25 00:13:23 --> Encrypt Class Initialized
INFO - 2022-03-25 00:13:23 --> Model "Patient_model" initialized
INFO - 2022-03-25 00:13:23 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 00:13:23 --> Model "Prefix_master" initialized
INFO - 2022-03-25 00:13:23 --> Model "Users_model" initialized
INFO - 2022-03-25 00:13:23 --> Model "Hospital_model" initialized
INFO - 2022-03-25 00:13:23 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-25 00:13:23 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-25 00:13:23 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-25 00:13:23 --> Final output sent to browser
DEBUG - 2022-03-25 00:13:23 --> Total execution time: 0.1174
ERROR - 2022-03-25 00:13:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 00:13:24 --> Config Class Initialized
INFO - 2022-03-25 00:13:24 --> Hooks Class Initialized
DEBUG - 2022-03-25 00:13:24 --> UTF-8 Support Enabled
INFO - 2022-03-25 00:13:24 --> Utf8 Class Initialized
INFO - 2022-03-25 00:13:24 --> URI Class Initialized
INFO - 2022-03-25 00:13:24 --> Router Class Initialized
INFO - 2022-03-25 00:13:24 --> Output Class Initialized
INFO - 2022-03-25 00:13:24 --> Security Class Initialized
DEBUG - 2022-03-25 00:13:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 00:13:24 --> Input Class Initialized
INFO - 2022-03-25 00:13:24 --> Language Class Initialized
ERROR - 2022-03-25 00:13:24 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-25 00:27:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 00:27:23 --> Config Class Initialized
INFO - 2022-03-25 00:27:23 --> Hooks Class Initialized
DEBUG - 2022-03-25 00:27:23 --> UTF-8 Support Enabled
INFO - 2022-03-25 00:27:23 --> Utf8 Class Initialized
INFO - 2022-03-25 00:27:23 --> URI Class Initialized
DEBUG - 2022-03-25 00:27:23 --> No URI present. Default controller set.
INFO - 2022-03-25 00:27:23 --> Router Class Initialized
INFO - 2022-03-25 00:27:23 --> Output Class Initialized
INFO - 2022-03-25 00:27:23 --> Security Class Initialized
DEBUG - 2022-03-25 00:27:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 00:27:23 --> Input Class Initialized
INFO - 2022-03-25 00:27:23 --> Language Class Initialized
INFO - 2022-03-25 00:27:23 --> Loader Class Initialized
INFO - 2022-03-25 00:27:23 --> Helper loaded: url_helper
INFO - 2022-03-25 00:27:23 --> Helper loaded: form_helper
INFO - 2022-03-25 00:27:23 --> Helper loaded: common_helper
INFO - 2022-03-25 00:27:23 --> Database Driver Class Initialized
DEBUG - 2022-03-25 00:27:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 00:27:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 00:27:24 --> Controller Class Initialized
INFO - 2022-03-25 00:27:24 --> Form Validation Class Initialized
DEBUG - 2022-03-25 00:27:24 --> Encrypt Class Initialized
DEBUG - 2022-03-25 00:27:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 00:27:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-25 00:27:24 --> Email Class Initialized
INFO - 2022-03-25 00:27:24 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-25 00:27:24 --> Calendar Class Initialized
INFO - 2022-03-25 00:27:24 --> Model "Login_model" initialized
INFO - 2022-03-25 00:27:24 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-25 00:27:24 --> Final output sent to browser
DEBUG - 2022-03-25 00:27:24 --> Total execution time: 0.0614
ERROR - 2022-03-25 00:29:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 00:29:39 --> Config Class Initialized
INFO - 2022-03-25 00:29:39 --> Hooks Class Initialized
DEBUG - 2022-03-25 00:29:39 --> UTF-8 Support Enabled
INFO - 2022-03-25 00:29:39 --> Utf8 Class Initialized
INFO - 2022-03-25 00:29:39 --> URI Class Initialized
INFO - 2022-03-25 00:29:39 --> Router Class Initialized
INFO - 2022-03-25 00:29:39 --> Output Class Initialized
INFO - 2022-03-25 00:29:39 --> Security Class Initialized
DEBUG - 2022-03-25 00:29:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 00:29:39 --> Input Class Initialized
INFO - 2022-03-25 00:29:39 --> Language Class Initialized
INFO - 2022-03-25 00:29:39 --> Loader Class Initialized
INFO - 2022-03-25 00:29:39 --> Helper loaded: url_helper
INFO - 2022-03-25 00:29:39 --> Helper loaded: form_helper
INFO - 2022-03-25 00:29:39 --> Helper loaded: common_helper
INFO - 2022-03-25 00:29:39 --> Database Driver Class Initialized
DEBUG - 2022-03-25 00:29:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 00:29:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 00:29:39 --> Controller Class Initialized
INFO - 2022-03-25 00:29:39 --> Form Validation Class Initialized
DEBUG - 2022-03-25 00:29:39 --> Encrypt Class Initialized
DEBUG - 2022-03-25 00:29:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 00:29:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-25 00:29:39 --> Email Class Initialized
INFO - 2022-03-25 00:29:39 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-25 00:29:39 --> Calendar Class Initialized
INFO - 2022-03-25 00:29:39 --> Model "Login_model" initialized
INFO - 2022-03-25 00:29:39 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-03-25 00:29:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 00:29:39 --> Config Class Initialized
INFO - 2022-03-25 00:29:39 --> Hooks Class Initialized
DEBUG - 2022-03-25 00:29:39 --> UTF-8 Support Enabled
INFO - 2022-03-25 00:29:39 --> Utf8 Class Initialized
INFO - 2022-03-25 00:29:39 --> URI Class Initialized
INFO - 2022-03-25 00:29:39 --> Router Class Initialized
INFO - 2022-03-25 00:29:39 --> Output Class Initialized
INFO - 2022-03-25 00:29:39 --> Security Class Initialized
DEBUG - 2022-03-25 00:29:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 00:29:39 --> Input Class Initialized
INFO - 2022-03-25 00:29:39 --> Language Class Initialized
INFO - 2022-03-25 00:29:39 --> Loader Class Initialized
INFO - 2022-03-25 00:29:39 --> Helper loaded: url_helper
INFO - 2022-03-25 00:29:39 --> Helper loaded: form_helper
INFO - 2022-03-25 00:29:39 --> Helper loaded: common_helper
INFO - 2022-03-25 00:29:39 --> Database Driver Class Initialized
DEBUG - 2022-03-25 00:29:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 00:29:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 00:29:39 --> Controller Class Initialized
INFO - 2022-03-25 00:29:39 --> Form Validation Class Initialized
DEBUG - 2022-03-25 00:29:39 --> Encrypt Class Initialized
INFO - 2022-03-25 00:29:39 --> Model "Login_model" initialized
INFO - 2022-03-25 00:29:39 --> Model "Dashboard_model" initialized
INFO - 2022-03-25 00:29:39 --> Model "Case_model" initialized
INFO - 2022-03-25 00:29:47 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-25 00:29:58 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2022-03-25 00:29:58 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-25 00:29:58 --> Final output sent to browser
DEBUG - 2022-03-25 00:29:58 --> Total execution time: 19.0879
ERROR - 2022-03-25 00:50:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 00:50:10 --> Config Class Initialized
INFO - 2022-03-25 00:50:10 --> Hooks Class Initialized
DEBUG - 2022-03-25 00:50:10 --> UTF-8 Support Enabled
INFO - 2022-03-25 00:50:10 --> Utf8 Class Initialized
INFO - 2022-03-25 00:50:10 --> URI Class Initialized
INFO - 2022-03-25 00:50:10 --> Router Class Initialized
INFO - 2022-03-25 00:50:10 --> Output Class Initialized
INFO - 2022-03-25 00:50:10 --> Security Class Initialized
DEBUG - 2022-03-25 00:50:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 00:50:10 --> Input Class Initialized
INFO - 2022-03-25 00:50:10 --> Language Class Initialized
INFO - 2022-03-25 00:50:10 --> Loader Class Initialized
INFO - 2022-03-25 00:50:10 --> Helper loaded: url_helper
INFO - 2022-03-25 00:50:10 --> Helper loaded: form_helper
INFO - 2022-03-25 00:50:10 --> Helper loaded: common_helper
INFO - 2022-03-25 00:50:10 --> Database Driver Class Initialized
DEBUG - 2022-03-25 00:50:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 00:50:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 00:50:10 --> Controller Class Initialized
INFO - 2022-03-25 00:50:10 --> Form Validation Class Initialized
DEBUG - 2022-03-25 00:50:10 --> Encrypt Class Initialized
INFO - 2022-03-25 00:50:10 --> Model "Patient_model" initialized
INFO - 2022-03-25 00:50:10 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 00:50:10 --> Model "Referredby_model" initialized
INFO - 2022-03-25 00:50:10 --> Model "Prefix_master" initialized
INFO - 2022-03-25 00:50:10 --> Model "Hospital_model" initialized
INFO - 2022-03-25 00:50:10 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-25 00:50:16 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-25 00:50:16 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-25 00:50:18 --> Final output sent to browser
DEBUG - 2022-03-25 00:50:18 --> Total execution time: 6.0736
ERROR - 2022-03-25 00:50:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 00:50:47 --> Config Class Initialized
INFO - 2022-03-25 00:50:47 --> Hooks Class Initialized
DEBUG - 2022-03-25 00:50:47 --> UTF-8 Support Enabled
INFO - 2022-03-25 00:50:47 --> Utf8 Class Initialized
INFO - 2022-03-25 00:50:47 --> URI Class Initialized
INFO - 2022-03-25 00:50:47 --> Router Class Initialized
INFO - 2022-03-25 00:50:47 --> Output Class Initialized
INFO - 2022-03-25 00:50:47 --> Security Class Initialized
DEBUG - 2022-03-25 00:50:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 00:50:47 --> Input Class Initialized
INFO - 2022-03-25 00:50:47 --> Language Class Initialized
INFO - 2022-03-25 00:50:47 --> Loader Class Initialized
INFO - 2022-03-25 00:50:47 --> Helper loaded: url_helper
INFO - 2022-03-25 00:50:47 --> Helper loaded: form_helper
INFO - 2022-03-25 00:50:47 --> Helper loaded: common_helper
INFO - 2022-03-25 00:50:47 --> Database Driver Class Initialized
DEBUG - 2022-03-25 00:50:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 00:50:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 00:50:47 --> Controller Class Initialized
INFO - 2022-03-25 00:50:47 --> Form Validation Class Initialized
DEBUG - 2022-03-25 00:50:47 --> Encrypt Class Initialized
INFO - 2022-03-25 00:50:47 --> Model "Patient_model" initialized
INFO - 2022-03-25 00:50:47 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 00:50:47 --> Model "Referredby_model" initialized
INFO - 2022-03-25 00:50:47 --> Model "Prefix_master" initialized
INFO - 2022-03-25 00:50:47 --> Model "Hospital_model" initialized
INFO - 2022-03-25 00:50:47 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-25 00:50:47 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-25 00:50:47 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-25 00:50:47 --> Final output sent to browser
DEBUG - 2022-03-25 00:50:47 --> Total execution time: 0.0498
ERROR - 2022-03-25 00:51:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 00:51:09 --> Config Class Initialized
INFO - 2022-03-25 00:51:09 --> Hooks Class Initialized
DEBUG - 2022-03-25 00:51:09 --> UTF-8 Support Enabled
INFO - 2022-03-25 00:51:09 --> Utf8 Class Initialized
INFO - 2022-03-25 00:51:09 --> URI Class Initialized
INFO - 2022-03-25 00:51:09 --> Router Class Initialized
INFO - 2022-03-25 00:51:09 --> Output Class Initialized
INFO - 2022-03-25 00:51:09 --> Security Class Initialized
DEBUG - 2022-03-25 00:51:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 00:51:09 --> Input Class Initialized
INFO - 2022-03-25 00:51:09 --> Language Class Initialized
INFO - 2022-03-25 00:51:09 --> Loader Class Initialized
INFO - 2022-03-25 00:51:09 --> Helper loaded: url_helper
INFO - 2022-03-25 00:51:09 --> Helper loaded: form_helper
INFO - 2022-03-25 00:51:09 --> Helper loaded: common_helper
INFO - 2022-03-25 00:51:09 --> Database Driver Class Initialized
DEBUG - 2022-03-25 00:51:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 00:51:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 00:51:09 --> Controller Class Initialized
INFO - 2022-03-25 00:51:09 --> Form Validation Class Initialized
DEBUG - 2022-03-25 00:51:09 --> Encrypt Class Initialized
INFO - 2022-03-25 00:51:09 --> Model "Patient_model" initialized
INFO - 2022-03-25 00:51:09 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 00:51:09 --> Model "Referredby_model" initialized
INFO - 2022-03-25 00:51:09 --> Model "Prefix_master" initialized
INFO - 2022-03-25 00:51:09 --> Model "Hospital_model" initialized
ERROR - 2022-03-25 00:51:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 00:51:09 --> Config Class Initialized
INFO - 2022-03-25 00:51:09 --> Hooks Class Initialized
DEBUG - 2022-03-25 00:51:09 --> UTF-8 Support Enabled
INFO - 2022-03-25 00:51:09 --> Utf8 Class Initialized
INFO - 2022-03-25 00:51:09 --> URI Class Initialized
INFO - 2022-03-25 00:51:09 --> Router Class Initialized
INFO - 2022-03-25 00:51:09 --> Output Class Initialized
INFO - 2022-03-25 00:51:09 --> Security Class Initialized
DEBUG - 2022-03-25 00:51:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 00:51:09 --> Input Class Initialized
INFO - 2022-03-25 00:51:09 --> Language Class Initialized
INFO - 2022-03-25 00:51:09 --> Loader Class Initialized
INFO - 2022-03-25 00:51:09 --> Helper loaded: url_helper
INFO - 2022-03-25 00:51:09 --> Helper loaded: form_helper
INFO - 2022-03-25 00:51:09 --> Helper loaded: common_helper
INFO - 2022-03-25 00:51:09 --> Database Driver Class Initialized
DEBUG - 2022-03-25 00:51:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 00:51:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 00:51:09 --> Controller Class Initialized
INFO - 2022-03-25 00:51:09 --> Form Validation Class Initialized
DEBUG - 2022-03-25 00:51:09 --> Encrypt Class Initialized
INFO - 2022-03-25 00:51:09 --> Model "Patient_model" initialized
INFO - 2022-03-25 00:51:09 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 00:51:09 --> Model "Referredby_model" initialized
INFO - 2022-03-25 00:51:09 --> Model "Prefix_master" initialized
INFO - 2022-03-25 00:51:09 --> Model "Hospital_model" initialized
INFO - 2022-03-25 00:51:09 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-25 00:51:09 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-25 00:51:09 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-25 00:51:09 --> Final output sent to browser
DEBUG - 2022-03-25 00:51:09 --> Total execution time: 0.0262
ERROR - 2022-03-25 00:51:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 00:51:10 --> Config Class Initialized
INFO - 2022-03-25 00:51:10 --> Hooks Class Initialized
DEBUG - 2022-03-25 00:51:10 --> UTF-8 Support Enabled
INFO - 2022-03-25 00:51:10 --> Utf8 Class Initialized
INFO - 2022-03-25 00:51:10 --> URI Class Initialized
INFO - 2022-03-25 00:51:10 --> Router Class Initialized
INFO - 2022-03-25 00:51:10 --> Output Class Initialized
INFO - 2022-03-25 00:51:10 --> Security Class Initialized
DEBUG - 2022-03-25 00:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 00:51:10 --> Input Class Initialized
INFO - 2022-03-25 00:51:10 --> Language Class Initialized
INFO - 2022-03-25 00:51:10 --> Loader Class Initialized
INFO - 2022-03-25 00:51:10 --> Helper loaded: url_helper
INFO - 2022-03-25 00:51:10 --> Helper loaded: form_helper
INFO - 2022-03-25 00:51:10 --> Helper loaded: common_helper
INFO - 2022-03-25 00:51:10 --> Database Driver Class Initialized
DEBUG - 2022-03-25 00:51:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 00:51:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 00:51:10 --> Controller Class Initialized
INFO - 2022-03-25 00:51:10 --> Form Validation Class Initialized
DEBUG - 2022-03-25 00:51:10 --> Encrypt Class Initialized
INFO - 2022-03-25 00:51:10 --> Model "Patient_model" initialized
INFO - 2022-03-25 00:51:10 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 00:51:10 --> Model "Prefix_master" initialized
INFO - 2022-03-25 00:51:10 --> Model "Users_model" initialized
INFO - 2022-03-25 00:51:10 --> Model "Hospital_model" initialized
INFO - 2022-03-25 00:51:10 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-25 00:51:10 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-25 00:51:10 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-25 00:51:10 --> Final output sent to browser
DEBUG - 2022-03-25 00:51:10 --> Total execution time: 0.0697
ERROR - 2022-03-25 00:52:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 00:52:27 --> Config Class Initialized
INFO - 2022-03-25 00:52:27 --> Hooks Class Initialized
DEBUG - 2022-03-25 00:52:27 --> UTF-8 Support Enabled
INFO - 2022-03-25 00:52:27 --> Utf8 Class Initialized
INFO - 2022-03-25 00:52:27 --> URI Class Initialized
INFO - 2022-03-25 00:52:27 --> Router Class Initialized
INFO - 2022-03-25 00:52:27 --> Output Class Initialized
INFO - 2022-03-25 00:52:27 --> Security Class Initialized
DEBUG - 2022-03-25 00:52:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 00:52:27 --> Input Class Initialized
INFO - 2022-03-25 00:52:27 --> Language Class Initialized
INFO - 2022-03-25 00:52:27 --> Loader Class Initialized
INFO - 2022-03-25 00:52:27 --> Helper loaded: url_helper
INFO - 2022-03-25 00:52:27 --> Helper loaded: form_helper
INFO - 2022-03-25 00:52:27 --> Helper loaded: common_helper
INFO - 2022-03-25 00:52:27 --> Database Driver Class Initialized
DEBUG - 2022-03-25 00:52:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 00:52:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 00:52:27 --> Controller Class Initialized
INFO - 2022-03-25 00:52:27 --> Form Validation Class Initialized
DEBUG - 2022-03-25 00:52:27 --> Encrypt Class Initialized
INFO - 2022-03-25 00:52:27 --> Model "Patient_model" initialized
INFO - 2022-03-25 00:52:27 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 00:52:27 --> Model "Prefix_master" initialized
INFO - 2022-03-25 00:52:27 --> Model "Users_model" initialized
INFO - 2022-03-25 00:52:27 --> Model "Hospital_model" initialized
ERROR - 2022-03-25 00:52:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 00:52:28 --> Config Class Initialized
INFO - 2022-03-25 00:52:28 --> Hooks Class Initialized
DEBUG - 2022-03-25 00:52:28 --> UTF-8 Support Enabled
INFO - 2022-03-25 00:52:28 --> Utf8 Class Initialized
INFO - 2022-03-25 00:52:28 --> URI Class Initialized
INFO - 2022-03-25 00:52:28 --> Router Class Initialized
INFO - 2022-03-25 00:52:28 --> Output Class Initialized
INFO - 2022-03-25 00:52:28 --> Security Class Initialized
DEBUG - 2022-03-25 00:52:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 00:52:28 --> Input Class Initialized
INFO - 2022-03-25 00:52:28 --> Language Class Initialized
INFO - 2022-03-25 00:52:28 --> Loader Class Initialized
INFO - 2022-03-25 00:52:28 --> Helper loaded: url_helper
INFO - 2022-03-25 00:52:28 --> Helper loaded: form_helper
INFO - 2022-03-25 00:52:28 --> Helper loaded: common_helper
INFO - 2022-03-25 00:52:28 --> Database Driver Class Initialized
DEBUG - 2022-03-25 00:52:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 00:52:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 00:52:28 --> Controller Class Initialized
INFO - 2022-03-25 00:52:28 --> Form Validation Class Initialized
DEBUG - 2022-03-25 00:52:28 --> Encrypt Class Initialized
INFO - 2022-03-25 00:52:28 --> Model "Patient_model" initialized
INFO - 2022-03-25 00:52:28 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 00:52:28 --> Model "Prefix_master" initialized
INFO - 2022-03-25 00:52:28 --> Model "Users_model" initialized
INFO - 2022-03-25 00:52:28 --> Model "Hospital_model" initialized
INFO - 2022-03-25 00:52:28 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-25 00:52:28 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-25 00:52:28 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-25 00:52:28 --> Final output sent to browser
DEBUG - 2022-03-25 00:52:28 --> Total execution time: 0.0561
ERROR - 2022-03-25 00:52:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 00:52:51 --> Config Class Initialized
INFO - 2022-03-25 00:52:51 --> Hooks Class Initialized
DEBUG - 2022-03-25 00:52:51 --> UTF-8 Support Enabled
INFO - 2022-03-25 00:52:51 --> Utf8 Class Initialized
INFO - 2022-03-25 00:52:51 --> URI Class Initialized
INFO - 2022-03-25 00:52:51 --> Router Class Initialized
INFO - 2022-03-25 00:52:51 --> Output Class Initialized
INFO - 2022-03-25 00:52:51 --> Security Class Initialized
DEBUG - 2022-03-25 00:52:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 00:52:51 --> Input Class Initialized
INFO - 2022-03-25 00:52:51 --> Language Class Initialized
INFO - 2022-03-25 00:52:51 --> Loader Class Initialized
INFO - 2022-03-25 00:52:51 --> Helper loaded: url_helper
INFO - 2022-03-25 00:52:51 --> Helper loaded: form_helper
INFO - 2022-03-25 00:52:51 --> Helper loaded: common_helper
INFO - 2022-03-25 00:52:51 --> Database Driver Class Initialized
DEBUG - 2022-03-25 00:52:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 00:52:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 00:52:51 --> Controller Class Initialized
INFO - 2022-03-25 00:52:51 --> Form Validation Class Initialized
DEBUG - 2022-03-25 00:52:51 --> Encrypt Class Initialized
INFO - 2022-03-25 00:52:51 --> Model "Patient_model" initialized
INFO - 2022-03-25 00:52:51 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 00:52:51 --> Model "Prefix_master" initialized
INFO - 2022-03-25 00:52:51 --> Model "Users_model" initialized
INFO - 2022-03-25 00:52:51 --> Model "Hospital_model" initialized
ERROR - 2022-03-25 00:52:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 00:52:51 --> Config Class Initialized
INFO - 2022-03-25 00:52:51 --> Hooks Class Initialized
DEBUG - 2022-03-25 00:52:51 --> UTF-8 Support Enabled
INFO - 2022-03-25 00:52:51 --> Utf8 Class Initialized
INFO - 2022-03-25 00:52:51 --> URI Class Initialized
INFO - 2022-03-25 00:52:51 --> Router Class Initialized
INFO - 2022-03-25 00:52:51 --> Output Class Initialized
INFO - 2022-03-25 00:52:51 --> Security Class Initialized
DEBUG - 2022-03-25 00:52:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 00:52:51 --> Input Class Initialized
INFO - 2022-03-25 00:52:51 --> Language Class Initialized
INFO - 2022-03-25 00:52:51 --> Loader Class Initialized
INFO - 2022-03-25 00:52:51 --> Helper loaded: url_helper
INFO - 2022-03-25 00:52:51 --> Helper loaded: form_helper
INFO - 2022-03-25 00:52:51 --> Helper loaded: common_helper
INFO - 2022-03-25 00:52:51 --> Database Driver Class Initialized
DEBUG - 2022-03-25 00:52:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 00:52:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 00:52:51 --> Controller Class Initialized
INFO - 2022-03-25 00:52:51 --> Form Validation Class Initialized
DEBUG - 2022-03-25 00:52:51 --> Encrypt Class Initialized
INFO - 2022-03-25 00:52:51 --> Model "Patient_model" initialized
INFO - 2022-03-25 00:52:51 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 00:52:51 --> Model "Prefix_master" initialized
INFO - 2022-03-25 00:52:51 --> Model "Users_model" initialized
INFO - 2022-03-25 00:52:51 --> Model "Hospital_model" initialized
INFO - 2022-03-25 00:52:51 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-25 00:52:51 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-25 00:52:51 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-25 00:52:51 --> Final output sent to browser
DEBUG - 2022-03-25 00:52:51 --> Total execution time: 0.0432
ERROR - 2022-03-25 00:52:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 00:52:52 --> Config Class Initialized
INFO - 2022-03-25 00:52:52 --> Hooks Class Initialized
DEBUG - 2022-03-25 00:52:52 --> UTF-8 Support Enabled
INFO - 2022-03-25 00:52:52 --> Utf8 Class Initialized
INFO - 2022-03-25 00:52:52 --> URI Class Initialized
INFO - 2022-03-25 00:52:52 --> Router Class Initialized
INFO - 2022-03-25 00:52:52 --> Output Class Initialized
INFO - 2022-03-25 00:52:52 --> Security Class Initialized
DEBUG - 2022-03-25 00:52:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 00:52:52 --> Input Class Initialized
INFO - 2022-03-25 00:52:52 --> Language Class Initialized
ERROR - 2022-03-25 00:52:52 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-25 00:52:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 00:52:56 --> Config Class Initialized
INFO - 2022-03-25 00:52:56 --> Hooks Class Initialized
DEBUG - 2022-03-25 00:52:56 --> UTF-8 Support Enabled
INFO - 2022-03-25 00:52:56 --> Utf8 Class Initialized
INFO - 2022-03-25 00:52:56 --> URI Class Initialized
INFO - 2022-03-25 00:52:56 --> Router Class Initialized
INFO - 2022-03-25 00:52:56 --> Output Class Initialized
INFO - 2022-03-25 00:52:56 --> Security Class Initialized
DEBUG - 2022-03-25 00:52:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 00:52:56 --> Input Class Initialized
INFO - 2022-03-25 00:52:56 --> Language Class Initialized
INFO - 2022-03-25 00:52:56 --> Loader Class Initialized
INFO - 2022-03-25 00:52:56 --> Helper loaded: url_helper
INFO - 2022-03-25 00:52:56 --> Helper loaded: form_helper
INFO - 2022-03-25 00:52:56 --> Helper loaded: common_helper
INFO - 2022-03-25 00:52:56 --> Database Driver Class Initialized
DEBUG - 2022-03-25 00:52:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 00:52:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 00:52:56 --> Controller Class Initialized
INFO - 2022-03-25 00:52:56 --> Form Validation Class Initialized
DEBUG - 2022-03-25 00:52:56 --> Encrypt Class Initialized
INFO - 2022-03-25 00:52:56 --> Model "Patient_model" initialized
INFO - 2022-03-25 00:52:56 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 00:52:56 --> Model "Referredby_model" initialized
INFO - 2022-03-25 00:52:56 --> Model "Prefix_master" initialized
INFO - 2022-03-25 00:52:56 --> Model "Hospital_model" initialized
INFO - 2022-03-25 00:52:56 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-25 00:53:03 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-25 00:53:03 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
ERROR - 2022-03-25 00:53:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 00:53:04 --> Config Class Initialized
INFO - 2022-03-25 00:53:04 --> Hooks Class Initialized
DEBUG - 2022-03-25 00:53:04 --> UTF-8 Support Enabled
INFO - 2022-03-25 00:53:04 --> Utf8 Class Initialized
INFO - 2022-03-25 00:53:04 --> URI Class Initialized
INFO - 2022-03-25 00:53:04 --> Router Class Initialized
INFO - 2022-03-25 00:53:04 --> Output Class Initialized
INFO - 2022-03-25 00:53:04 --> Security Class Initialized
DEBUG - 2022-03-25 00:53:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 00:53:04 --> Input Class Initialized
INFO - 2022-03-25 00:53:04 --> Language Class Initialized
ERROR - 2022-03-25 00:53:04 --> 404 Page Not Found: Karoclient/usersprofile
INFO - 2022-03-25 00:53:05 --> Final output sent to browser
DEBUG - 2022-03-25 00:53:05 --> Total execution time: 7.4770
ERROR - 2022-03-25 00:53:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 00:53:09 --> Config Class Initialized
INFO - 2022-03-25 00:53:09 --> Hooks Class Initialized
DEBUG - 2022-03-25 00:53:09 --> UTF-8 Support Enabled
INFO - 2022-03-25 00:53:09 --> Utf8 Class Initialized
INFO - 2022-03-25 00:53:09 --> URI Class Initialized
INFO - 2022-03-25 00:53:09 --> Router Class Initialized
INFO - 2022-03-25 00:53:09 --> Output Class Initialized
INFO - 2022-03-25 00:53:09 --> Security Class Initialized
DEBUG - 2022-03-25 00:53:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 00:53:09 --> Input Class Initialized
INFO - 2022-03-25 00:53:09 --> Language Class Initialized
INFO - 2022-03-25 00:53:09 --> Loader Class Initialized
INFO - 2022-03-25 00:53:09 --> Helper loaded: url_helper
INFO - 2022-03-25 00:53:09 --> Helper loaded: form_helper
INFO - 2022-03-25 00:53:09 --> Helper loaded: common_helper
INFO - 2022-03-25 00:53:09 --> Database Driver Class Initialized
DEBUG - 2022-03-25 00:53:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 00:53:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 00:53:09 --> Controller Class Initialized
INFO - 2022-03-25 00:53:09 --> Form Validation Class Initialized
DEBUG - 2022-03-25 00:53:09 --> Encrypt Class Initialized
INFO - 2022-03-25 00:53:09 --> Model "Patient_model" initialized
INFO - 2022-03-25 00:53:09 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 00:53:09 --> Model "Referredby_model" initialized
INFO - 2022-03-25 00:53:09 --> Model "Prefix_master" initialized
INFO - 2022-03-25 00:53:09 --> Model "Hospital_model" initialized
INFO - 2022-03-25 00:53:09 --> File loaded: /home3/karoteam/public_html/application/views/header.php
ERROR - 2022-03-25 00:53:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 00:53:12 --> Config Class Initialized
INFO - 2022-03-25 00:53:12 --> Hooks Class Initialized
DEBUG - 2022-03-25 00:53:12 --> UTF-8 Support Enabled
INFO - 2022-03-25 00:53:12 --> Utf8 Class Initialized
INFO - 2022-03-25 00:53:12 --> URI Class Initialized
INFO - 2022-03-25 00:53:12 --> Router Class Initialized
INFO - 2022-03-25 00:53:12 --> Output Class Initialized
INFO - 2022-03-25 00:53:12 --> Security Class Initialized
DEBUG - 2022-03-25 00:53:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 00:53:12 --> Input Class Initialized
INFO - 2022-03-25 00:53:12 --> Language Class Initialized
INFO - 2022-03-25 00:53:12 --> Loader Class Initialized
INFO - 2022-03-25 00:53:12 --> Helper loaded: url_helper
INFO - 2022-03-25 00:53:12 --> Helper loaded: form_helper
INFO - 2022-03-25 00:53:12 --> Helper loaded: common_helper
INFO - 2022-03-25 00:53:12 --> Database Driver Class Initialized
DEBUG - 2022-03-25 00:53:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 00:53:15 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-25 00:53:15 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-25 00:53:15 --> Final output sent to browser
DEBUG - 2022-03-25 00:53:15 --> Total execution time: 5.7544
INFO - 2022-03-25 00:53:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 00:53:15 --> Controller Class Initialized
INFO - 2022-03-25 00:53:15 --> Form Validation Class Initialized
DEBUG - 2022-03-25 00:53:15 --> Encrypt Class Initialized
INFO - 2022-03-25 00:53:15 --> Model "Patient_model" initialized
INFO - 2022-03-25 00:53:15 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 00:53:15 --> Model "Referredby_model" initialized
INFO - 2022-03-25 00:53:15 --> Model "Prefix_master" initialized
INFO - 2022-03-25 00:53:15 --> Model "Hospital_model" initialized
INFO - 2022-03-25 00:53:15 --> File loaded: /home3/karoteam/public_html/application/views/header.php
ERROR - 2022-03-25 00:53:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 00:53:21 --> Config Class Initialized
INFO - 2022-03-25 00:53:21 --> Hooks Class Initialized
DEBUG - 2022-03-25 00:53:21 --> UTF-8 Support Enabled
INFO - 2022-03-25 00:53:21 --> Utf8 Class Initialized
INFO - 2022-03-25 00:53:21 --> URI Class Initialized
INFO - 2022-03-25 00:53:21 --> Router Class Initialized
INFO - 2022-03-25 00:53:21 --> Output Class Initialized
INFO - 2022-03-25 00:53:21 --> Security Class Initialized
DEBUG - 2022-03-25 00:53:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 00:53:21 --> Input Class Initialized
INFO - 2022-03-25 00:53:21 --> Language Class Initialized
INFO - 2022-03-25 00:53:21 --> Loader Class Initialized
INFO - 2022-03-25 00:53:21 --> Helper loaded: url_helper
INFO - 2022-03-25 00:53:21 --> Helper loaded: form_helper
INFO - 2022-03-25 00:53:21 --> Helper loaded: common_helper
INFO - 2022-03-25 00:53:21 --> Database Driver Class Initialized
DEBUG - 2022-03-25 00:53:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 00:53:22 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-25 00:53:22 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-25 00:53:22 --> Final output sent to browser
DEBUG - 2022-03-25 00:53:22 --> Total execution time: 9.8756
INFO - 2022-03-25 00:53:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 00:53:22 --> Controller Class Initialized
INFO - 2022-03-25 00:53:22 --> Form Validation Class Initialized
DEBUG - 2022-03-25 00:53:22 --> Encrypt Class Initialized
INFO - 2022-03-25 00:53:22 --> Model "Patient_model" initialized
INFO - 2022-03-25 00:53:22 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 00:53:22 --> Model "Referredby_model" initialized
INFO - 2022-03-25 00:53:22 --> Model "Prefix_master" initialized
INFO - 2022-03-25 00:53:22 --> Model "Hospital_model" initialized
INFO - 2022-03-25 00:53:22 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-25 00:53:28 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-25 00:53:28 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-25 00:53:29 --> Final output sent to browser
DEBUG - 2022-03-25 00:53:29 --> Total execution time: 7.6003
ERROR - 2022-03-25 00:53:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 00:53:29 --> Config Class Initialized
INFO - 2022-03-25 00:53:29 --> Hooks Class Initialized
DEBUG - 2022-03-25 00:53:29 --> UTF-8 Support Enabled
INFO - 2022-03-25 00:53:29 --> Utf8 Class Initialized
INFO - 2022-03-25 00:53:29 --> URI Class Initialized
INFO - 2022-03-25 00:53:29 --> Router Class Initialized
INFO - 2022-03-25 00:53:29 --> Output Class Initialized
INFO - 2022-03-25 00:53:29 --> Security Class Initialized
DEBUG - 2022-03-25 00:53:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 00:53:29 --> Input Class Initialized
INFO - 2022-03-25 00:53:29 --> Language Class Initialized
ERROR - 2022-03-25 00:53:29 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-25 00:55:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 00:55:59 --> Config Class Initialized
INFO - 2022-03-25 00:55:59 --> Hooks Class Initialized
DEBUG - 2022-03-25 00:55:59 --> UTF-8 Support Enabled
INFO - 2022-03-25 00:55:59 --> Utf8 Class Initialized
INFO - 2022-03-25 00:55:59 --> URI Class Initialized
INFO - 2022-03-25 00:55:59 --> Router Class Initialized
INFO - 2022-03-25 00:55:59 --> Output Class Initialized
INFO - 2022-03-25 00:55:59 --> Security Class Initialized
DEBUG - 2022-03-25 00:55:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 00:55:59 --> Input Class Initialized
INFO - 2022-03-25 00:55:59 --> Language Class Initialized
INFO - 2022-03-25 00:55:59 --> Loader Class Initialized
INFO - 2022-03-25 00:55:59 --> Helper loaded: url_helper
INFO - 2022-03-25 00:55:59 --> Helper loaded: form_helper
INFO - 2022-03-25 00:55:59 --> Helper loaded: common_helper
INFO - 2022-03-25 00:55:59 --> Database Driver Class Initialized
DEBUG - 2022-03-25 00:55:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 00:55:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 00:55:59 --> Controller Class Initialized
INFO - 2022-03-25 00:55:59 --> Form Validation Class Initialized
DEBUG - 2022-03-25 00:55:59 --> Encrypt Class Initialized
INFO - 2022-03-25 00:55:59 --> Model "Patient_model" initialized
INFO - 2022-03-25 00:55:59 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 00:55:59 --> Model "Prefix_master" initialized
INFO - 2022-03-25 00:55:59 --> Model "Users_model" initialized
INFO - 2022-03-25 00:55:59 --> Model "Hospital_model" initialized
INFO - 2022-03-25 00:55:59 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-25 00:55:59 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-25 00:55:59 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-25 00:55:59 --> Final output sent to browser
DEBUG - 2022-03-25 00:55:59 --> Total execution time: 0.1104
ERROR - 2022-03-25 00:56:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 00:56:00 --> Config Class Initialized
INFO - 2022-03-25 00:56:00 --> Hooks Class Initialized
DEBUG - 2022-03-25 00:56:00 --> UTF-8 Support Enabled
INFO - 2022-03-25 00:56:00 --> Utf8 Class Initialized
INFO - 2022-03-25 00:56:00 --> URI Class Initialized
INFO - 2022-03-25 00:56:00 --> Router Class Initialized
INFO - 2022-03-25 00:56:00 --> Output Class Initialized
INFO - 2022-03-25 00:56:00 --> Security Class Initialized
DEBUG - 2022-03-25 00:56:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 00:56:00 --> Input Class Initialized
INFO - 2022-03-25 00:56:00 --> Language Class Initialized
ERROR - 2022-03-25 00:56:00 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-25 00:58:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 00:58:39 --> Config Class Initialized
INFO - 2022-03-25 00:58:39 --> Hooks Class Initialized
DEBUG - 2022-03-25 00:58:39 --> UTF-8 Support Enabled
INFO - 2022-03-25 00:58:39 --> Utf8 Class Initialized
INFO - 2022-03-25 00:58:39 --> URI Class Initialized
INFO - 2022-03-25 00:58:39 --> Router Class Initialized
INFO - 2022-03-25 00:58:39 --> Output Class Initialized
INFO - 2022-03-25 00:58:39 --> Security Class Initialized
DEBUG - 2022-03-25 00:58:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 00:58:39 --> Input Class Initialized
INFO - 2022-03-25 00:58:39 --> Language Class Initialized
INFO - 2022-03-25 00:58:39 --> Loader Class Initialized
INFO - 2022-03-25 00:58:39 --> Helper loaded: url_helper
INFO - 2022-03-25 00:58:39 --> Helper loaded: form_helper
INFO - 2022-03-25 00:58:39 --> Helper loaded: common_helper
INFO - 2022-03-25 00:58:39 --> Database Driver Class Initialized
DEBUG - 2022-03-25 00:58:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 00:58:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 00:58:39 --> Controller Class Initialized
INFO - 2022-03-25 00:58:39 --> Form Validation Class Initialized
DEBUG - 2022-03-25 00:58:39 --> Encrypt Class Initialized
INFO - 2022-03-25 00:58:39 --> Model "Patient_model" initialized
INFO - 2022-03-25 00:58:39 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 00:58:39 --> Model "Prefix_master" initialized
INFO - 2022-03-25 00:58:39 --> Model "Users_model" initialized
INFO - 2022-03-25 00:58:39 --> Model "Hospital_model" initialized
ERROR - 2022-03-25 00:58:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 00:58:40 --> Config Class Initialized
INFO - 2022-03-25 00:58:40 --> Hooks Class Initialized
DEBUG - 2022-03-25 00:58:40 --> UTF-8 Support Enabled
INFO - 2022-03-25 00:58:40 --> Utf8 Class Initialized
INFO - 2022-03-25 00:58:40 --> URI Class Initialized
INFO - 2022-03-25 00:58:40 --> Router Class Initialized
INFO - 2022-03-25 00:58:40 --> Output Class Initialized
INFO - 2022-03-25 00:58:40 --> Security Class Initialized
DEBUG - 2022-03-25 00:58:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 00:58:40 --> Input Class Initialized
INFO - 2022-03-25 00:58:40 --> Language Class Initialized
INFO - 2022-03-25 00:58:40 --> Loader Class Initialized
INFO - 2022-03-25 00:58:40 --> Helper loaded: url_helper
INFO - 2022-03-25 00:58:40 --> Helper loaded: form_helper
INFO - 2022-03-25 00:58:40 --> Helper loaded: common_helper
INFO - 2022-03-25 00:58:40 --> Database Driver Class Initialized
DEBUG - 2022-03-25 00:58:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 00:58:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 00:58:40 --> Controller Class Initialized
INFO - 2022-03-25 00:58:40 --> Form Validation Class Initialized
DEBUG - 2022-03-25 00:58:40 --> Encrypt Class Initialized
INFO - 2022-03-25 00:58:40 --> Model "Patient_model" initialized
INFO - 2022-03-25 00:58:40 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 00:58:40 --> Model "Prefix_master" initialized
INFO - 2022-03-25 00:58:40 --> Model "Users_model" initialized
INFO - 2022-03-25 00:58:40 --> Model "Hospital_model" initialized
INFO - 2022-03-25 00:58:40 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-25 00:58:40 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-25 00:58:40 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-25 00:58:40 --> Final output sent to browser
DEBUG - 2022-03-25 00:58:40 --> Total execution time: 0.0646
ERROR - 2022-03-25 00:59:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 00:59:23 --> Config Class Initialized
INFO - 2022-03-25 00:59:23 --> Hooks Class Initialized
DEBUG - 2022-03-25 00:59:23 --> UTF-8 Support Enabled
INFO - 2022-03-25 00:59:23 --> Utf8 Class Initialized
INFO - 2022-03-25 00:59:23 --> URI Class Initialized
INFO - 2022-03-25 00:59:23 --> Router Class Initialized
INFO - 2022-03-25 00:59:23 --> Output Class Initialized
INFO - 2022-03-25 00:59:23 --> Security Class Initialized
DEBUG - 2022-03-25 00:59:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 00:59:23 --> Input Class Initialized
INFO - 2022-03-25 00:59:23 --> Language Class Initialized
INFO - 2022-03-25 00:59:23 --> Loader Class Initialized
INFO - 2022-03-25 00:59:23 --> Helper loaded: url_helper
INFO - 2022-03-25 00:59:23 --> Helper loaded: form_helper
INFO - 2022-03-25 00:59:23 --> Helper loaded: common_helper
INFO - 2022-03-25 00:59:23 --> Database Driver Class Initialized
DEBUG - 2022-03-25 00:59:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 00:59:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 00:59:23 --> Controller Class Initialized
INFO - 2022-03-25 00:59:23 --> Form Validation Class Initialized
DEBUG - 2022-03-25 00:59:23 --> Encrypt Class Initialized
INFO - 2022-03-25 00:59:23 --> Model "Patient_model" initialized
INFO - 2022-03-25 00:59:23 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 00:59:23 --> Model "Prefix_master" initialized
INFO - 2022-03-25 00:59:23 --> Model "Users_model" initialized
INFO - 2022-03-25 00:59:23 --> Model "Hospital_model" initialized
ERROR - 2022-03-25 00:59:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 00:59:23 --> Config Class Initialized
INFO - 2022-03-25 00:59:23 --> Hooks Class Initialized
DEBUG - 2022-03-25 00:59:23 --> UTF-8 Support Enabled
INFO - 2022-03-25 00:59:23 --> Utf8 Class Initialized
INFO - 2022-03-25 00:59:23 --> URI Class Initialized
INFO - 2022-03-25 00:59:23 --> Router Class Initialized
INFO - 2022-03-25 00:59:23 --> Output Class Initialized
INFO - 2022-03-25 00:59:23 --> Security Class Initialized
DEBUG - 2022-03-25 00:59:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 00:59:23 --> Input Class Initialized
INFO - 2022-03-25 00:59:23 --> Language Class Initialized
INFO - 2022-03-25 00:59:23 --> Loader Class Initialized
INFO - 2022-03-25 00:59:23 --> Helper loaded: url_helper
INFO - 2022-03-25 00:59:23 --> Helper loaded: form_helper
INFO - 2022-03-25 00:59:23 --> Helper loaded: common_helper
INFO - 2022-03-25 00:59:23 --> Database Driver Class Initialized
DEBUG - 2022-03-25 00:59:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 00:59:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 00:59:23 --> Controller Class Initialized
INFO - 2022-03-25 00:59:23 --> Form Validation Class Initialized
DEBUG - 2022-03-25 00:59:23 --> Encrypt Class Initialized
INFO - 2022-03-25 00:59:23 --> Model "Patient_model" initialized
INFO - 2022-03-25 00:59:23 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 00:59:23 --> Model "Prefix_master" initialized
INFO - 2022-03-25 00:59:23 --> Model "Users_model" initialized
INFO - 2022-03-25 00:59:23 --> Model "Hospital_model" initialized
INFO - 2022-03-25 00:59:23 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-25 00:59:23 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-25 00:59:23 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-25 00:59:23 --> Final output sent to browser
DEBUG - 2022-03-25 00:59:23 --> Total execution time: 0.0428
ERROR - 2022-03-25 01:03:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 01:03:31 --> Config Class Initialized
INFO - 2022-03-25 01:03:31 --> Hooks Class Initialized
DEBUG - 2022-03-25 01:03:31 --> UTF-8 Support Enabled
INFO - 2022-03-25 01:03:31 --> Utf8 Class Initialized
INFO - 2022-03-25 01:03:31 --> URI Class Initialized
INFO - 2022-03-25 01:03:31 --> Router Class Initialized
INFO - 2022-03-25 01:03:31 --> Output Class Initialized
INFO - 2022-03-25 01:03:31 --> Security Class Initialized
DEBUG - 2022-03-25 01:03:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 01:03:31 --> Input Class Initialized
INFO - 2022-03-25 01:03:31 --> Language Class Initialized
INFO - 2022-03-25 01:03:31 --> Loader Class Initialized
INFO - 2022-03-25 01:03:31 --> Helper loaded: url_helper
INFO - 2022-03-25 01:03:31 --> Helper loaded: form_helper
INFO - 2022-03-25 01:03:31 --> Helper loaded: common_helper
INFO - 2022-03-25 01:03:31 --> Database Driver Class Initialized
DEBUG - 2022-03-25 01:03:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 01:03:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 01:03:31 --> Controller Class Initialized
INFO - 2022-03-25 01:03:31 --> Form Validation Class Initialized
DEBUG - 2022-03-25 01:03:31 --> Encrypt Class Initialized
INFO - 2022-03-25 01:03:31 --> Model "Patient_model" initialized
INFO - 2022-03-25 01:03:31 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 01:03:31 --> Model "Prefix_master" initialized
INFO - 2022-03-25 01:03:31 --> Model "Users_model" initialized
INFO - 2022-03-25 01:03:31 --> Model "Hospital_model" initialized
ERROR - 2022-03-25 01:03:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 01:03:32 --> Config Class Initialized
INFO - 2022-03-25 01:03:32 --> Hooks Class Initialized
DEBUG - 2022-03-25 01:03:32 --> UTF-8 Support Enabled
INFO - 2022-03-25 01:03:32 --> Utf8 Class Initialized
INFO - 2022-03-25 01:03:32 --> URI Class Initialized
INFO - 2022-03-25 01:03:32 --> Router Class Initialized
INFO - 2022-03-25 01:03:32 --> Output Class Initialized
INFO - 2022-03-25 01:03:32 --> Security Class Initialized
DEBUG - 2022-03-25 01:03:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 01:03:32 --> Input Class Initialized
INFO - 2022-03-25 01:03:32 --> Language Class Initialized
INFO - 2022-03-25 01:03:32 --> Loader Class Initialized
INFO - 2022-03-25 01:03:32 --> Helper loaded: url_helper
INFO - 2022-03-25 01:03:32 --> Helper loaded: form_helper
INFO - 2022-03-25 01:03:32 --> Helper loaded: common_helper
INFO - 2022-03-25 01:03:32 --> Database Driver Class Initialized
DEBUG - 2022-03-25 01:03:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 01:03:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 01:03:32 --> Controller Class Initialized
INFO - 2022-03-25 01:03:32 --> Form Validation Class Initialized
DEBUG - 2022-03-25 01:03:32 --> Encrypt Class Initialized
INFO - 2022-03-25 01:03:32 --> Model "Patient_model" initialized
INFO - 2022-03-25 01:03:32 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 01:03:32 --> Model "Prefix_master" initialized
INFO - 2022-03-25 01:03:32 --> Model "Users_model" initialized
INFO - 2022-03-25 01:03:32 --> Model "Hospital_model" initialized
INFO - 2022-03-25 01:03:32 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-25 01:03:32 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-25 01:03:32 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-25 01:03:32 --> Final output sent to browser
DEBUG - 2022-03-25 01:03:32 --> Total execution time: 0.0709
ERROR - 2022-03-25 01:06:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 01:06:50 --> Config Class Initialized
INFO - 2022-03-25 01:06:50 --> Hooks Class Initialized
DEBUG - 2022-03-25 01:06:50 --> UTF-8 Support Enabled
INFO - 2022-03-25 01:06:50 --> Utf8 Class Initialized
INFO - 2022-03-25 01:06:50 --> URI Class Initialized
INFO - 2022-03-25 01:06:50 --> Router Class Initialized
INFO - 2022-03-25 01:06:50 --> Output Class Initialized
INFO - 2022-03-25 01:06:50 --> Security Class Initialized
DEBUG - 2022-03-25 01:06:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 01:06:50 --> Input Class Initialized
INFO - 2022-03-25 01:06:50 --> Language Class Initialized
INFO - 2022-03-25 01:06:50 --> Loader Class Initialized
INFO - 2022-03-25 01:06:50 --> Helper loaded: url_helper
INFO - 2022-03-25 01:06:50 --> Helper loaded: form_helper
INFO - 2022-03-25 01:06:50 --> Helper loaded: common_helper
INFO - 2022-03-25 01:06:50 --> Database Driver Class Initialized
DEBUG - 2022-03-25 01:06:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 01:06:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 01:06:50 --> Controller Class Initialized
INFO - 2022-03-25 01:06:50 --> Form Validation Class Initialized
DEBUG - 2022-03-25 01:06:50 --> Encrypt Class Initialized
INFO - 2022-03-25 01:06:50 --> Model "Patient_model" initialized
INFO - 2022-03-25 01:06:50 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 01:06:50 --> Model "Prefix_master" initialized
INFO - 2022-03-25 01:06:50 --> Model "Users_model" initialized
INFO - 2022-03-25 01:06:50 --> Model "Hospital_model" initialized
INFO - 2022-03-25 01:06:50 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-25 01:06:51 --> Final output sent to browser
DEBUG - 2022-03-25 01:06:51 --> Total execution time: 1.5414
ERROR - 2022-03-25 01:10:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 01:10:13 --> Config Class Initialized
INFO - 2022-03-25 01:10:13 --> Hooks Class Initialized
DEBUG - 2022-03-25 01:10:13 --> UTF-8 Support Enabled
INFO - 2022-03-25 01:10:13 --> Utf8 Class Initialized
INFO - 2022-03-25 01:10:13 --> URI Class Initialized
INFO - 2022-03-25 01:10:13 --> Router Class Initialized
INFO - 2022-03-25 01:10:13 --> Output Class Initialized
INFO - 2022-03-25 01:10:13 --> Security Class Initialized
DEBUG - 2022-03-25 01:10:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 01:10:13 --> Input Class Initialized
INFO - 2022-03-25 01:10:13 --> Language Class Initialized
INFO - 2022-03-25 01:10:13 --> Loader Class Initialized
INFO - 2022-03-25 01:10:13 --> Helper loaded: url_helper
INFO - 2022-03-25 01:10:13 --> Helper loaded: form_helper
INFO - 2022-03-25 01:10:13 --> Helper loaded: common_helper
INFO - 2022-03-25 01:10:13 --> Database Driver Class Initialized
DEBUG - 2022-03-25 01:10:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 01:10:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 01:10:13 --> Controller Class Initialized
INFO - 2022-03-25 01:10:13 --> Form Validation Class Initialized
DEBUG - 2022-03-25 01:10:13 --> Encrypt Class Initialized
INFO - 2022-03-25 01:10:13 --> Model "Patient_model" initialized
INFO - 2022-03-25 01:10:13 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 01:10:13 --> Model "Prefix_master" initialized
INFO - 2022-03-25 01:10:13 --> Model "Users_model" initialized
INFO - 2022-03-25 01:10:13 --> Model "Hospital_model" initialized
INFO - 2022-03-25 01:10:13 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-25 01:10:13 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-25 01:10:13 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-25 01:10:13 --> Final output sent to browser
DEBUG - 2022-03-25 01:10:13 --> Total execution time: 0.1267
ERROR - 2022-03-25 01:10:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 01:10:15 --> Config Class Initialized
INFO - 2022-03-25 01:10:15 --> Hooks Class Initialized
DEBUG - 2022-03-25 01:10:15 --> UTF-8 Support Enabled
INFO - 2022-03-25 01:10:15 --> Utf8 Class Initialized
INFO - 2022-03-25 01:10:15 --> URI Class Initialized
INFO - 2022-03-25 01:10:15 --> Router Class Initialized
INFO - 2022-03-25 01:10:15 --> Output Class Initialized
INFO - 2022-03-25 01:10:15 --> Security Class Initialized
DEBUG - 2022-03-25 01:10:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 01:10:15 --> Input Class Initialized
INFO - 2022-03-25 01:10:15 --> Language Class Initialized
INFO - 2022-03-25 01:10:15 --> Loader Class Initialized
INFO - 2022-03-25 01:10:15 --> Helper loaded: url_helper
INFO - 2022-03-25 01:10:15 --> Helper loaded: form_helper
INFO - 2022-03-25 01:10:15 --> Helper loaded: common_helper
INFO - 2022-03-25 01:10:15 --> Database Driver Class Initialized
DEBUG - 2022-03-25 01:10:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 01:10:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 01:10:15 --> Controller Class Initialized
INFO - 2022-03-25 01:10:15 --> Form Validation Class Initialized
DEBUG - 2022-03-25 01:10:15 --> Encrypt Class Initialized
INFO - 2022-03-25 01:10:15 --> Model "Patient_model" initialized
INFO - 2022-03-25 01:10:15 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 01:10:15 --> Model "Referredby_model" initialized
INFO - 2022-03-25 01:10:15 --> Model "Prefix_master" initialized
INFO - 2022-03-25 01:10:15 --> Model "Hospital_model" initialized
INFO - 2022-03-25 01:10:15 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-25 01:10:15 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-25 01:10:15 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-25 01:10:15 --> Final output sent to browser
DEBUG - 2022-03-25 01:10:15 --> Total execution time: 0.0286
ERROR - 2022-03-25 01:10:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 01:10:20 --> Config Class Initialized
INFO - 2022-03-25 01:10:20 --> Hooks Class Initialized
DEBUG - 2022-03-25 01:10:20 --> UTF-8 Support Enabled
INFO - 2022-03-25 01:10:20 --> Utf8 Class Initialized
INFO - 2022-03-25 01:10:20 --> URI Class Initialized
INFO - 2022-03-25 01:10:20 --> Router Class Initialized
INFO - 2022-03-25 01:10:20 --> Output Class Initialized
INFO - 2022-03-25 01:10:20 --> Security Class Initialized
DEBUG - 2022-03-25 01:10:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 01:10:20 --> Input Class Initialized
INFO - 2022-03-25 01:10:20 --> Language Class Initialized
INFO - 2022-03-25 01:10:20 --> Loader Class Initialized
INFO - 2022-03-25 01:10:20 --> Helper loaded: url_helper
INFO - 2022-03-25 01:10:20 --> Helper loaded: form_helper
INFO - 2022-03-25 01:10:20 --> Helper loaded: common_helper
INFO - 2022-03-25 01:10:20 --> Database Driver Class Initialized
DEBUG - 2022-03-25 01:10:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 01:10:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 01:10:20 --> Controller Class Initialized
INFO - 2022-03-25 01:10:20 --> Form Validation Class Initialized
DEBUG - 2022-03-25 01:10:20 --> Encrypt Class Initialized
INFO - 2022-03-25 01:10:20 --> Model "Patient_model" initialized
INFO - 2022-03-25 01:10:20 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 01:10:20 --> Model "Prefix_master" initialized
INFO - 2022-03-25 01:10:20 --> Model "Users_model" initialized
INFO - 2022-03-25 01:10:20 --> Model "Hospital_model" initialized
ERROR - 2022-03-25 01:10:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 01:10:20 --> Config Class Initialized
INFO - 2022-03-25 01:10:20 --> Hooks Class Initialized
DEBUG - 2022-03-25 01:10:20 --> UTF-8 Support Enabled
INFO - 2022-03-25 01:10:20 --> Utf8 Class Initialized
INFO - 2022-03-25 01:10:20 --> URI Class Initialized
INFO - 2022-03-25 01:10:20 --> Router Class Initialized
INFO - 2022-03-25 01:10:20 --> Output Class Initialized
INFO - 2022-03-25 01:10:20 --> Security Class Initialized
DEBUG - 2022-03-25 01:10:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 01:10:20 --> Input Class Initialized
INFO - 2022-03-25 01:10:20 --> Language Class Initialized
INFO - 2022-03-25 01:10:20 --> Loader Class Initialized
INFO - 2022-03-25 01:10:20 --> Helper loaded: url_helper
INFO - 2022-03-25 01:10:20 --> Helper loaded: form_helper
INFO - 2022-03-25 01:10:20 --> Helper loaded: common_helper
INFO - 2022-03-25 01:10:20 --> Database Driver Class Initialized
DEBUG - 2022-03-25 01:10:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 01:10:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 01:10:20 --> Controller Class Initialized
INFO - 2022-03-25 01:10:20 --> Form Validation Class Initialized
DEBUG - 2022-03-25 01:10:20 --> Encrypt Class Initialized
INFO - 2022-03-25 01:10:20 --> Model "Patient_model" initialized
INFO - 2022-03-25 01:10:20 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 01:10:20 --> Model "Prefix_master" initialized
INFO - 2022-03-25 01:10:20 --> Model "Users_model" initialized
INFO - 2022-03-25 01:10:20 --> Model "Hospital_model" initialized
INFO - 2022-03-25 01:10:20 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-25 01:10:20 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-25 01:10:20 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-25 01:10:20 --> Final output sent to browser
DEBUG - 2022-03-25 01:10:20 --> Total execution time: 0.0403
ERROR - 2022-03-25 01:10:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 01:10:20 --> Config Class Initialized
INFO - 2022-03-25 01:10:20 --> Hooks Class Initialized
DEBUG - 2022-03-25 01:10:20 --> UTF-8 Support Enabled
INFO - 2022-03-25 01:10:20 --> Utf8 Class Initialized
INFO - 2022-03-25 01:10:20 --> URI Class Initialized
INFO - 2022-03-25 01:10:20 --> Router Class Initialized
INFO - 2022-03-25 01:10:20 --> Output Class Initialized
INFO - 2022-03-25 01:10:20 --> Security Class Initialized
DEBUG - 2022-03-25 01:10:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 01:10:20 --> Input Class Initialized
INFO - 2022-03-25 01:10:20 --> Language Class Initialized
ERROR - 2022-03-25 01:10:20 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-25 01:10:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 01:10:21 --> Config Class Initialized
INFO - 2022-03-25 01:10:21 --> Hooks Class Initialized
DEBUG - 2022-03-25 01:10:21 --> UTF-8 Support Enabled
INFO - 2022-03-25 01:10:21 --> Utf8 Class Initialized
INFO - 2022-03-25 01:10:21 --> URI Class Initialized
INFO - 2022-03-25 01:10:21 --> Router Class Initialized
INFO - 2022-03-25 01:10:21 --> Output Class Initialized
INFO - 2022-03-25 01:10:21 --> Security Class Initialized
DEBUG - 2022-03-25 01:10:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 01:10:21 --> Input Class Initialized
INFO - 2022-03-25 01:10:21 --> Language Class Initialized
INFO - 2022-03-25 01:10:21 --> Loader Class Initialized
INFO - 2022-03-25 01:10:21 --> Helper loaded: url_helper
INFO - 2022-03-25 01:10:21 --> Helper loaded: form_helper
INFO - 2022-03-25 01:10:21 --> Helper loaded: common_helper
INFO - 2022-03-25 01:10:21 --> Database Driver Class Initialized
DEBUG - 2022-03-25 01:10:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 01:10:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 01:10:21 --> Controller Class Initialized
INFO - 2022-03-25 01:10:21 --> Form Validation Class Initialized
DEBUG - 2022-03-25 01:10:21 --> Encrypt Class Initialized
INFO - 2022-03-25 01:10:21 --> Model "Patient_model" initialized
INFO - 2022-03-25 01:10:21 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 01:10:21 --> Model "Referredby_model" initialized
INFO - 2022-03-25 01:10:21 --> Model "Prefix_master" initialized
INFO - 2022-03-25 01:10:21 --> Model "Hospital_model" initialized
ERROR - 2022-03-25 01:10:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 01:10:21 --> Config Class Initialized
INFO - 2022-03-25 01:10:21 --> Hooks Class Initialized
DEBUG - 2022-03-25 01:10:21 --> UTF-8 Support Enabled
INFO - 2022-03-25 01:10:21 --> Utf8 Class Initialized
INFO - 2022-03-25 01:10:21 --> URI Class Initialized
INFO - 2022-03-25 01:10:21 --> Router Class Initialized
INFO - 2022-03-25 01:10:21 --> Output Class Initialized
INFO - 2022-03-25 01:10:21 --> Security Class Initialized
DEBUG - 2022-03-25 01:10:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 01:10:21 --> Input Class Initialized
INFO - 2022-03-25 01:10:21 --> Language Class Initialized
INFO - 2022-03-25 01:10:21 --> Loader Class Initialized
INFO - 2022-03-25 01:10:21 --> Helper loaded: url_helper
INFO - 2022-03-25 01:10:21 --> Helper loaded: form_helper
INFO - 2022-03-25 01:10:21 --> Helper loaded: common_helper
INFO - 2022-03-25 01:10:21 --> Database Driver Class Initialized
DEBUG - 2022-03-25 01:10:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 01:10:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 01:10:21 --> Controller Class Initialized
INFO - 2022-03-25 01:10:21 --> Form Validation Class Initialized
DEBUG - 2022-03-25 01:10:21 --> Encrypt Class Initialized
INFO - 2022-03-25 01:10:21 --> Model "Patient_model" initialized
INFO - 2022-03-25 01:10:21 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 01:10:21 --> Model "Referredby_model" initialized
INFO - 2022-03-25 01:10:21 --> Model "Prefix_master" initialized
INFO - 2022-03-25 01:10:21 --> Model "Hospital_model" initialized
INFO - 2022-03-25 01:10:21 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-25 01:10:21 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-25 01:10:21 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-25 01:10:21 --> Final output sent to browser
DEBUG - 2022-03-25 01:10:21 --> Total execution time: 0.0309
ERROR - 2022-03-25 01:10:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 01:10:22 --> Config Class Initialized
INFO - 2022-03-25 01:10:22 --> Hooks Class Initialized
DEBUG - 2022-03-25 01:10:22 --> UTF-8 Support Enabled
INFO - 2022-03-25 01:10:22 --> Utf8 Class Initialized
INFO - 2022-03-25 01:10:22 --> URI Class Initialized
INFO - 2022-03-25 01:10:22 --> Router Class Initialized
INFO - 2022-03-25 01:10:22 --> Output Class Initialized
INFO - 2022-03-25 01:10:22 --> Security Class Initialized
DEBUG - 2022-03-25 01:10:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 01:10:22 --> Input Class Initialized
INFO - 2022-03-25 01:10:22 --> Language Class Initialized
INFO - 2022-03-25 01:10:22 --> Loader Class Initialized
INFO - 2022-03-25 01:10:22 --> Helper loaded: url_helper
INFO - 2022-03-25 01:10:22 --> Helper loaded: form_helper
INFO - 2022-03-25 01:10:22 --> Helper loaded: common_helper
INFO - 2022-03-25 01:10:22 --> Database Driver Class Initialized
DEBUG - 2022-03-25 01:10:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 01:10:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 01:10:22 --> Controller Class Initialized
INFO - 2022-03-25 01:10:22 --> Form Validation Class Initialized
DEBUG - 2022-03-25 01:10:22 --> Encrypt Class Initialized
INFO - 2022-03-25 01:10:22 --> Model "Patient_model" initialized
INFO - 2022-03-25 01:10:22 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 01:10:22 --> Model "Prefix_master" initialized
INFO - 2022-03-25 01:10:22 --> Model "Users_model" initialized
INFO - 2022-03-25 01:10:22 --> Model "Hospital_model" initialized
INFO - 2022-03-25 01:10:22 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-25 01:10:22 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-25 01:10:22 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-25 01:10:22 --> Final output sent to browser
DEBUG - 2022-03-25 01:10:22 --> Total execution time: 0.0405
ERROR - 2022-03-25 01:10:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 01:10:36 --> Config Class Initialized
INFO - 2022-03-25 01:10:36 --> Hooks Class Initialized
DEBUG - 2022-03-25 01:10:36 --> UTF-8 Support Enabled
INFO - 2022-03-25 01:10:36 --> Utf8 Class Initialized
INFO - 2022-03-25 01:10:36 --> URI Class Initialized
INFO - 2022-03-25 01:10:36 --> Router Class Initialized
INFO - 2022-03-25 01:10:36 --> Output Class Initialized
INFO - 2022-03-25 01:10:36 --> Security Class Initialized
DEBUG - 2022-03-25 01:10:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 01:10:36 --> Input Class Initialized
INFO - 2022-03-25 01:10:36 --> Language Class Initialized
INFO - 2022-03-25 01:10:36 --> Loader Class Initialized
INFO - 2022-03-25 01:10:36 --> Helper loaded: url_helper
INFO - 2022-03-25 01:10:36 --> Helper loaded: form_helper
INFO - 2022-03-25 01:10:36 --> Helper loaded: common_helper
INFO - 2022-03-25 01:10:36 --> Database Driver Class Initialized
DEBUG - 2022-03-25 01:10:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 01:10:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 01:10:36 --> Controller Class Initialized
INFO - 2022-03-25 01:10:36 --> Form Validation Class Initialized
DEBUG - 2022-03-25 01:10:36 --> Encrypt Class Initialized
INFO - 2022-03-25 01:10:36 --> Model "Patient_model" initialized
INFO - 2022-03-25 01:10:36 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 01:10:36 --> Model "Referredby_model" initialized
INFO - 2022-03-25 01:10:36 --> Model "Prefix_master" initialized
INFO - 2022-03-25 01:10:36 --> Model "Hospital_model" initialized
INFO - 2022-03-25 01:10:36 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-25 01:10:42 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-25 01:10:42 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
ERROR - 2022-03-25 01:10:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 01:10:43 --> Config Class Initialized
INFO - 2022-03-25 01:10:43 --> Hooks Class Initialized
DEBUG - 2022-03-25 01:10:43 --> UTF-8 Support Enabled
INFO - 2022-03-25 01:10:43 --> Utf8 Class Initialized
INFO - 2022-03-25 01:10:43 --> URI Class Initialized
INFO - 2022-03-25 01:10:43 --> Router Class Initialized
INFO - 2022-03-25 01:10:43 --> Output Class Initialized
INFO - 2022-03-25 01:10:43 --> Security Class Initialized
DEBUG - 2022-03-25 01:10:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 01:10:43 --> Input Class Initialized
INFO - 2022-03-25 01:10:43 --> Language Class Initialized
ERROR - 2022-03-25 01:10:43 --> 404 Page Not Found: Karoclient/usersprofile
INFO - 2022-03-25 01:10:44 --> Final output sent to browser
DEBUG - 2022-03-25 01:10:44 --> Total execution time: 6.4620
ERROR - 2022-03-25 01:11:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 01:11:11 --> Config Class Initialized
INFO - 2022-03-25 01:11:11 --> Hooks Class Initialized
DEBUG - 2022-03-25 01:11:11 --> UTF-8 Support Enabled
INFO - 2022-03-25 01:11:11 --> Utf8 Class Initialized
INFO - 2022-03-25 01:11:11 --> URI Class Initialized
INFO - 2022-03-25 01:11:11 --> Router Class Initialized
INFO - 2022-03-25 01:11:11 --> Output Class Initialized
INFO - 2022-03-25 01:11:11 --> Security Class Initialized
DEBUG - 2022-03-25 01:11:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 01:11:11 --> Input Class Initialized
INFO - 2022-03-25 01:11:11 --> Language Class Initialized
INFO - 2022-03-25 01:11:11 --> Loader Class Initialized
INFO - 2022-03-25 01:11:11 --> Helper loaded: url_helper
INFO - 2022-03-25 01:11:11 --> Helper loaded: form_helper
INFO - 2022-03-25 01:11:11 --> Helper loaded: common_helper
INFO - 2022-03-25 01:11:11 --> Database Driver Class Initialized
DEBUG - 2022-03-25 01:11:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 01:11:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 01:11:11 --> Controller Class Initialized
INFO - 2022-03-25 01:11:11 --> Form Validation Class Initialized
DEBUG - 2022-03-25 01:11:11 --> Encrypt Class Initialized
INFO - 2022-03-25 01:11:11 --> Model "Patient_model" initialized
INFO - 2022-03-25 01:11:11 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 01:11:11 --> Model "Referredby_model" initialized
INFO - 2022-03-25 01:11:11 --> Model "Prefix_master" initialized
INFO - 2022-03-25 01:11:11 --> Model "Hospital_model" initialized
INFO - 2022-03-25 01:11:11 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-25 01:11:11 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-25 01:11:11 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-25 01:11:11 --> Final output sent to browser
DEBUG - 2022-03-25 01:11:11 --> Total execution time: 0.0288
ERROR - 2022-03-25 01:11:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 01:11:12 --> Config Class Initialized
INFO - 2022-03-25 01:11:12 --> Hooks Class Initialized
DEBUG - 2022-03-25 01:11:12 --> UTF-8 Support Enabled
INFO - 2022-03-25 01:11:12 --> Utf8 Class Initialized
INFO - 2022-03-25 01:11:12 --> URI Class Initialized
INFO - 2022-03-25 01:11:12 --> Router Class Initialized
INFO - 2022-03-25 01:11:12 --> Output Class Initialized
INFO - 2022-03-25 01:11:12 --> Security Class Initialized
DEBUG - 2022-03-25 01:11:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 01:11:12 --> Input Class Initialized
INFO - 2022-03-25 01:11:12 --> Language Class Initialized
ERROR - 2022-03-25 01:11:12 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-25 01:11:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 01:11:16 --> Config Class Initialized
INFO - 2022-03-25 01:11:16 --> Hooks Class Initialized
DEBUG - 2022-03-25 01:11:16 --> UTF-8 Support Enabled
INFO - 2022-03-25 01:11:16 --> Utf8 Class Initialized
INFO - 2022-03-25 01:11:16 --> URI Class Initialized
INFO - 2022-03-25 01:11:16 --> Router Class Initialized
INFO - 2022-03-25 01:11:16 --> Output Class Initialized
INFO - 2022-03-25 01:11:16 --> Security Class Initialized
DEBUG - 2022-03-25 01:11:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 01:11:16 --> Input Class Initialized
INFO - 2022-03-25 01:11:16 --> Language Class Initialized
INFO - 2022-03-25 01:11:16 --> Loader Class Initialized
INFO - 2022-03-25 01:11:16 --> Helper loaded: url_helper
INFO - 2022-03-25 01:11:16 --> Helper loaded: form_helper
INFO - 2022-03-25 01:11:16 --> Helper loaded: common_helper
INFO - 2022-03-25 01:11:16 --> Database Driver Class Initialized
DEBUG - 2022-03-25 01:11:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 01:11:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 01:11:16 --> Controller Class Initialized
INFO - 2022-03-25 01:11:16 --> Form Validation Class Initialized
DEBUG - 2022-03-25 01:11:16 --> Encrypt Class Initialized
INFO - 2022-03-25 01:11:16 --> Model "Patient_model" initialized
INFO - 2022-03-25 01:11:16 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 01:11:16 --> Model "Prefix_master" initialized
INFO - 2022-03-25 01:11:16 --> Model "Users_model" initialized
INFO - 2022-03-25 01:11:16 --> Model "Hospital_model" initialized
ERROR - 2022-03-25 01:11:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 01:11:16 --> Config Class Initialized
INFO - 2022-03-25 01:11:16 --> Hooks Class Initialized
DEBUG - 2022-03-25 01:11:16 --> UTF-8 Support Enabled
INFO - 2022-03-25 01:11:16 --> Utf8 Class Initialized
INFO - 2022-03-25 01:11:16 --> URI Class Initialized
INFO - 2022-03-25 01:11:16 --> Router Class Initialized
INFO - 2022-03-25 01:11:16 --> Output Class Initialized
INFO - 2022-03-25 01:11:16 --> Security Class Initialized
DEBUG - 2022-03-25 01:11:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 01:11:16 --> Input Class Initialized
INFO - 2022-03-25 01:11:16 --> Language Class Initialized
INFO - 2022-03-25 01:11:16 --> Loader Class Initialized
INFO - 2022-03-25 01:11:16 --> Helper loaded: url_helper
INFO - 2022-03-25 01:11:16 --> Helper loaded: form_helper
INFO - 2022-03-25 01:11:16 --> Helper loaded: common_helper
INFO - 2022-03-25 01:11:16 --> Database Driver Class Initialized
DEBUG - 2022-03-25 01:11:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 01:11:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 01:11:16 --> Controller Class Initialized
INFO - 2022-03-25 01:11:16 --> Form Validation Class Initialized
DEBUG - 2022-03-25 01:11:16 --> Encrypt Class Initialized
INFO - 2022-03-25 01:11:16 --> Model "Patient_model" initialized
INFO - 2022-03-25 01:11:16 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 01:11:16 --> Model "Prefix_master" initialized
INFO - 2022-03-25 01:11:16 --> Model "Users_model" initialized
INFO - 2022-03-25 01:11:16 --> Model "Hospital_model" initialized
INFO - 2022-03-25 01:11:16 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-25 01:11:16 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-25 01:11:16 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-25 01:11:16 --> Final output sent to browser
DEBUG - 2022-03-25 01:11:16 --> Total execution time: 0.0437
ERROR - 2022-03-25 01:11:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 01:11:26 --> Config Class Initialized
INFO - 2022-03-25 01:11:26 --> Hooks Class Initialized
DEBUG - 2022-03-25 01:11:26 --> UTF-8 Support Enabled
INFO - 2022-03-25 01:11:26 --> Utf8 Class Initialized
INFO - 2022-03-25 01:11:26 --> URI Class Initialized
INFO - 2022-03-25 01:11:26 --> Router Class Initialized
INFO - 2022-03-25 01:11:26 --> Output Class Initialized
INFO - 2022-03-25 01:11:26 --> Security Class Initialized
DEBUG - 2022-03-25 01:11:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 01:11:26 --> Input Class Initialized
INFO - 2022-03-25 01:11:26 --> Language Class Initialized
INFO - 2022-03-25 01:11:26 --> Loader Class Initialized
INFO - 2022-03-25 01:11:26 --> Helper loaded: url_helper
INFO - 2022-03-25 01:11:26 --> Helper loaded: form_helper
INFO - 2022-03-25 01:11:26 --> Helper loaded: common_helper
INFO - 2022-03-25 01:11:26 --> Database Driver Class Initialized
DEBUG - 2022-03-25 01:11:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 01:11:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 01:11:26 --> Controller Class Initialized
INFO - 2022-03-25 01:11:26 --> Form Validation Class Initialized
DEBUG - 2022-03-25 01:11:26 --> Encrypt Class Initialized
INFO - 2022-03-25 01:11:26 --> Model "Patient_model" initialized
INFO - 2022-03-25 01:11:26 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 01:11:26 --> Model "Referredby_model" initialized
INFO - 2022-03-25 01:11:26 --> Model "Prefix_master" initialized
INFO - 2022-03-25 01:11:26 --> Model "Hospital_model" initialized
ERROR - 2022-03-25 01:11:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 01:11:26 --> Config Class Initialized
INFO - 2022-03-25 01:11:26 --> Hooks Class Initialized
DEBUG - 2022-03-25 01:11:26 --> UTF-8 Support Enabled
INFO - 2022-03-25 01:11:26 --> Utf8 Class Initialized
INFO - 2022-03-25 01:11:26 --> URI Class Initialized
INFO - 2022-03-25 01:11:26 --> Router Class Initialized
INFO - 2022-03-25 01:11:26 --> Output Class Initialized
INFO - 2022-03-25 01:11:26 --> Security Class Initialized
DEBUG - 2022-03-25 01:11:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 01:11:26 --> Input Class Initialized
INFO - 2022-03-25 01:11:26 --> Language Class Initialized
INFO - 2022-03-25 01:11:26 --> Loader Class Initialized
INFO - 2022-03-25 01:11:26 --> Helper loaded: url_helper
INFO - 2022-03-25 01:11:26 --> Helper loaded: form_helper
INFO - 2022-03-25 01:11:26 --> Helper loaded: common_helper
INFO - 2022-03-25 01:11:26 --> Database Driver Class Initialized
DEBUG - 2022-03-25 01:11:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 01:11:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 01:11:26 --> Controller Class Initialized
INFO - 2022-03-25 01:11:26 --> Form Validation Class Initialized
DEBUG - 2022-03-25 01:11:26 --> Encrypt Class Initialized
INFO - 2022-03-25 01:11:26 --> Model "Patient_model" initialized
INFO - 2022-03-25 01:11:26 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 01:11:26 --> Model "Referredby_model" initialized
INFO - 2022-03-25 01:11:26 --> Model "Prefix_master" initialized
INFO - 2022-03-25 01:11:26 --> Model "Hospital_model" initialized
INFO - 2022-03-25 01:11:26 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-25 01:11:26 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-25 01:11:26 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-25 01:11:26 --> Final output sent to browser
DEBUG - 2022-03-25 01:11:26 --> Total execution time: 0.0469
ERROR - 2022-03-25 01:11:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 01:11:27 --> Config Class Initialized
INFO - 2022-03-25 01:11:27 --> Hooks Class Initialized
DEBUG - 2022-03-25 01:11:27 --> UTF-8 Support Enabled
INFO - 2022-03-25 01:11:27 --> Utf8 Class Initialized
INFO - 2022-03-25 01:11:27 --> URI Class Initialized
INFO - 2022-03-25 01:11:27 --> Router Class Initialized
INFO - 2022-03-25 01:11:27 --> Output Class Initialized
INFO - 2022-03-25 01:11:27 --> Security Class Initialized
DEBUG - 2022-03-25 01:11:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 01:11:27 --> Input Class Initialized
INFO - 2022-03-25 01:11:27 --> Language Class Initialized
ERROR - 2022-03-25 01:11:27 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-25 01:11:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 01:11:27 --> Config Class Initialized
INFO - 2022-03-25 01:11:27 --> Hooks Class Initialized
DEBUG - 2022-03-25 01:11:27 --> UTF-8 Support Enabled
INFO - 2022-03-25 01:11:27 --> Utf8 Class Initialized
INFO - 2022-03-25 01:11:27 --> URI Class Initialized
INFO - 2022-03-25 01:11:27 --> Router Class Initialized
INFO - 2022-03-25 01:11:27 --> Output Class Initialized
INFO - 2022-03-25 01:11:27 --> Security Class Initialized
DEBUG - 2022-03-25 01:11:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 01:11:27 --> Input Class Initialized
INFO - 2022-03-25 01:11:27 --> Language Class Initialized
INFO - 2022-03-25 01:11:27 --> Loader Class Initialized
INFO - 2022-03-25 01:11:27 --> Helper loaded: url_helper
INFO - 2022-03-25 01:11:27 --> Helper loaded: form_helper
INFO - 2022-03-25 01:11:27 --> Helper loaded: common_helper
INFO - 2022-03-25 01:11:27 --> Database Driver Class Initialized
DEBUG - 2022-03-25 01:11:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 01:11:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 01:11:27 --> Controller Class Initialized
INFO - 2022-03-25 01:11:27 --> Form Validation Class Initialized
DEBUG - 2022-03-25 01:11:27 --> Encrypt Class Initialized
INFO - 2022-03-25 01:11:27 --> Model "Patient_model" initialized
INFO - 2022-03-25 01:11:27 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 01:11:27 --> Model "Prefix_master" initialized
INFO - 2022-03-25 01:11:27 --> Model "Users_model" initialized
INFO - 2022-03-25 01:11:27 --> Model "Hospital_model" initialized
INFO - 2022-03-25 01:11:27 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-25 01:11:27 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-25 01:11:27 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-25 01:11:27 --> Final output sent to browser
DEBUG - 2022-03-25 01:11:27 --> Total execution time: 0.0592
ERROR - 2022-03-25 01:11:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 01:11:27 --> Config Class Initialized
INFO - 2022-03-25 01:11:27 --> Hooks Class Initialized
DEBUG - 2022-03-25 01:11:27 --> UTF-8 Support Enabled
INFO - 2022-03-25 01:11:27 --> Utf8 Class Initialized
INFO - 2022-03-25 01:11:27 --> URI Class Initialized
INFO - 2022-03-25 01:11:27 --> Router Class Initialized
INFO - 2022-03-25 01:11:27 --> Output Class Initialized
INFO - 2022-03-25 01:11:27 --> Security Class Initialized
DEBUG - 2022-03-25 01:11:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 01:11:27 --> Input Class Initialized
INFO - 2022-03-25 01:11:27 --> Language Class Initialized
ERROR - 2022-03-25 01:11:27 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-25 01:11:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 01:11:27 --> Config Class Initialized
INFO - 2022-03-25 01:11:27 --> Hooks Class Initialized
DEBUG - 2022-03-25 01:11:27 --> UTF-8 Support Enabled
INFO - 2022-03-25 01:11:27 --> Utf8 Class Initialized
INFO - 2022-03-25 01:11:27 --> URI Class Initialized
INFO - 2022-03-25 01:11:27 --> Router Class Initialized
INFO - 2022-03-25 01:11:27 --> Output Class Initialized
INFO - 2022-03-25 01:11:27 --> Security Class Initialized
DEBUG - 2022-03-25 01:11:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 01:11:27 --> Input Class Initialized
INFO - 2022-03-25 01:11:27 --> Language Class Initialized
INFO - 2022-03-25 01:11:27 --> Loader Class Initialized
INFO - 2022-03-25 01:11:27 --> Helper loaded: url_helper
INFO - 2022-03-25 01:11:27 --> Helper loaded: form_helper
INFO - 2022-03-25 01:11:27 --> Helper loaded: common_helper
INFO - 2022-03-25 01:11:27 --> Database Driver Class Initialized
DEBUG - 2022-03-25 01:11:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 01:11:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 01:11:27 --> Controller Class Initialized
INFO - 2022-03-25 01:11:27 --> Form Validation Class Initialized
DEBUG - 2022-03-25 01:11:27 --> Encrypt Class Initialized
INFO - 2022-03-25 01:11:27 --> Model "Patient_model" initialized
INFO - 2022-03-25 01:11:27 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 01:11:27 --> Model "Referredby_model" initialized
INFO - 2022-03-25 01:11:27 --> Model "Prefix_master" initialized
INFO - 2022-03-25 01:11:27 --> Model "Hospital_model" initialized
ERROR - 2022-03-25 01:11:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 01:11:27 --> Config Class Initialized
INFO - 2022-03-25 01:11:27 --> Hooks Class Initialized
DEBUG - 2022-03-25 01:11:27 --> UTF-8 Support Enabled
INFO - 2022-03-25 01:11:27 --> Utf8 Class Initialized
INFO - 2022-03-25 01:11:27 --> URI Class Initialized
INFO - 2022-03-25 01:11:27 --> Router Class Initialized
INFO - 2022-03-25 01:11:27 --> Output Class Initialized
INFO - 2022-03-25 01:11:27 --> Security Class Initialized
DEBUG - 2022-03-25 01:11:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 01:11:27 --> Input Class Initialized
INFO - 2022-03-25 01:11:27 --> Language Class Initialized
INFO - 2022-03-25 01:11:27 --> Loader Class Initialized
INFO - 2022-03-25 01:11:27 --> Helper loaded: url_helper
INFO - 2022-03-25 01:11:27 --> Helper loaded: form_helper
INFO - 2022-03-25 01:11:27 --> Helper loaded: common_helper
INFO - 2022-03-25 01:11:27 --> Database Driver Class Initialized
DEBUG - 2022-03-25 01:11:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 01:11:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 01:11:27 --> Controller Class Initialized
INFO - 2022-03-25 01:11:27 --> Form Validation Class Initialized
DEBUG - 2022-03-25 01:11:27 --> Encrypt Class Initialized
INFO - 2022-03-25 01:11:27 --> Model "Patient_model" initialized
INFO - 2022-03-25 01:11:27 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 01:11:27 --> Model "Prefix_master" initialized
INFO - 2022-03-25 01:11:27 --> Model "Users_model" initialized
INFO - 2022-03-25 01:11:27 --> Model "Hospital_model" initialized
INFO - 2022-03-25 01:11:27 --> File loaded: /home3/karoteam/public_html/application/views/header.php
ERROR - 2022-03-25 01:11:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 01:11:28 --> Config Class Initialized
INFO - 2022-03-25 01:11:28 --> Hooks Class Initialized
DEBUG - 2022-03-25 01:11:28 --> UTF-8 Support Enabled
INFO - 2022-03-25 01:11:28 --> Utf8 Class Initialized
INFO - 2022-03-25 01:11:28 --> URI Class Initialized
INFO - 2022-03-25 01:11:28 --> Router Class Initialized
INFO - 2022-03-25 01:11:28 --> Output Class Initialized
INFO - 2022-03-25 01:11:28 --> Security Class Initialized
DEBUG - 2022-03-25 01:11:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 01:11:28 --> Input Class Initialized
INFO - 2022-03-25 01:11:28 --> Language Class Initialized
INFO - 2022-03-25 01:11:28 --> Loader Class Initialized
INFO - 2022-03-25 01:11:28 --> Helper loaded: url_helper
INFO - 2022-03-25 01:11:28 --> Helper loaded: form_helper
INFO - 2022-03-25 01:11:28 --> Helper loaded: common_helper
INFO - 2022-03-25 01:11:28 --> Database Driver Class Initialized
DEBUG - 2022-03-25 01:11:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 01:11:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 01:11:28 --> Controller Class Initialized
INFO - 2022-03-25 01:11:28 --> Form Validation Class Initialized
DEBUG - 2022-03-25 01:11:28 --> Encrypt Class Initialized
INFO - 2022-03-25 01:11:28 --> Model "Patient_model" initialized
INFO - 2022-03-25 01:11:28 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 01:11:28 --> Model "Prefix_master" initialized
INFO - 2022-03-25 01:11:28 --> Model "Users_model" initialized
INFO - 2022-03-25 01:11:28 --> Model "Hospital_model" initialized
INFO - 2022-03-25 01:11:28 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-25 01:11:28 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-25 01:11:28 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-25 01:11:28 --> Final output sent to browser
DEBUG - 2022-03-25 01:11:28 --> Total execution time: 0.0757
ERROR - 2022-03-25 01:11:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 01:11:29 --> Config Class Initialized
INFO - 2022-03-25 01:11:29 --> Hooks Class Initialized
DEBUG - 2022-03-25 01:11:29 --> UTF-8 Support Enabled
INFO - 2022-03-25 01:11:29 --> Utf8 Class Initialized
INFO - 2022-03-25 01:11:29 --> URI Class Initialized
INFO - 2022-03-25 01:11:29 --> Router Class Initialized
INFO - 2022-03-25 01:11:29 --> Output Class Initialized
INFO - 2022-03-25 01:11:29 --> Security Class Initialized
DEBUG - 2022-03-25 01:11:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 01:11:29 --> Input Class Initialized
INFO - 2022-03-25 01:11:29 --> Language Class Initialized
INFO - 2022-03-25 01:11:29 --> Loader Class Initialized
INFO - 2022-03-25 01:11:29 --> Helper loaded: url_helper
INFO - 2022-03-25 01:11:29 --> Helper loaded: form_helper
INFO - 2022-03-25 01:11:29 --> Helper loaded: common_helper
INFO - 2022-03-25 01:11:29 --> Database Driver Class Initialized
DEBUG - 2022-03-25 01:11:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 01:11:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 01:11:29 --> Controller Class Initialized
INFO - 2022-03-25 01:11:29 --> Form Validation Class Initialized
DEBUG - 2022-03-25 01:11:29 --> Encrypt Class Initialized
INFO - 2022-03-25 01:11:29 --> Model "Patient_model" initialized
INFO - 2022-03-25 01:11:29 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 01:11:29 --> Model "Referredby_model" initialized
INFO - 2022-03-25 01:11:29 --> Model "Prefix_master" initialized
INFO - 2022-03-25 01:11:29 --> Model "Hospital_model" initialized
INFO - 2022-03-25 01:11:29 --> File loaded: /home3/karoteam/public_html/application/views/header.php
ERROR - 2022-03-25 01:11:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 01:11:36 --> Config Class Initialized
INFO - 2022-03-25 01:11:36 --> Hooks Class Initialized
DEBUG - 2022-03-25 01:11:36 --> UTF-8 Support Enabled
INFO - 2022-03-25 01:11:36 --> Utf8 Class Initialized
INFO - 2022-03-25 01:11:36 --> URI Class Initialized
INFO - 2022-03-25 01:11:36 --> Router Class Initialized
INFO - 2022-03-25 01:11:36 --> Output Class Initialized
INFO - 2022-03-25 01:11:36 --> Security Class Initialized
DEBUG - 2022-03-25 01:11:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 01:11:36 --> Input Class Initialized
INFO - 2022-03-25 01:11:36 --> Language Class Initialized
INFO - 2022-03-25 01:11:36 --> Loader Class Initialized
INFO - 2022-03-25 01:11:36 --> Helper loaded: url_helper
INFO - 2022-03-25 01:11:36 --> Helper loaded: form_helper
INFO - 2022-03-25 01:11:36 --> Helper loaded: common_helper
INFO - 2022-03-25 01:11:36 --> Database Driver Class Initialized
DEBUG - 2022-03-25 01:11:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 01:11:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 01:11:36 --> Controller Class Initialized
INFO - 2022-03-25 01:11:36 --> Form Validation Class Initialized
DEBUG - 2022-03-25 01:11:36 --> Encrypt Class Initialized
INFO - 2022-03-25 01:11:36 --> Model "Patient_model" initialized
INFO - 2022-03-25 01:11:36 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 01:11:36 --> Model "Prefix_master" initialized
INFO - 2022-03-25 01:11:36 --> Model "Users_model" initialized
INFO - 2022-03-25 01:11:36 --> Model "Hospital_model" initialized
INFO - 2022-03-25 01:11:36 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-25 01:11:36 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
ERROR - 2022-03-25 01:11:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 01:11:36 --> Config Class Initialized
INFO - 2022-03-25 01:11:36 --> Hooks Class Initialized
DEBUG - 2022-03-25 01:11:36 --> UTF-8 Support Enabled
INFO - 2022-03-25 01:11:36 --> Utf8 Class Initialized
INFO - 2022-03-25 01:11:36 --> URI Class Initialized
INFO - 2022-03-25 01:11:36 --> Router Class Initialized
INFO - 2022-03-25 01:11:36 --> Output Class Initialized
INFO - 2022-03-25 01:11:36 --> Security Class Initialized
DEBUG - 2022-03-25 01:11:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 01:11:36 --> Input Class Initialized
INFO - 2022-03-25 01:11:36 --> Language Class Initialized
INFO - 2022-03-25 01:11:36 --> Loader Class Initialized
INFO - 2022-03-25 01:11:36 --> Helper loaded: url_helper
INFO - 2022-03-25 01:11:36 --> Helper loaded: form_helper
INFO - 2022-03-25 01:11:36 --> Helper loaded: common_helper
INFO - 2022-03-25 01:11:36 --> Database Driver Class Initialized
DEBUG - 2022-03-25 01:11:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 01:11:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 01:11:36 --> Controller Class Initialized
INFO - 2022-03-25 01:11:36 --> Form Validation Class Initialized
DEBUG - 2022-03-25 01:11:36 --> Encrypt Class Initialized
INFO - 2022-03-25 01:11:36 --> Model "Patient_model" initialized
INFO - 2022-03-25 01:11:36 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 01:11:36 --> Model "Prefix_master" initialized
INFO - 2022-03-25 01:11:36 --> Model "Users_model" initialized
INFO - 2022-03-25 01:11:36 --> Model "Hospital_model" initialized
INFO - 2022-03-25 01:11:36 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-25 01:11:36 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-25 01:11:36 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-25 01:11:36 --> Final output sent to browser
DEBUG - 2022-03-25 01:11:36 --> Total execution time: 0.0715
INFO - 2022-03-25 01:11:36 --> Final output sent to browser
DEBUG - 2022-03-25 01:11:36 --> Total execution time: 8.3870
ERROR - 2022-03-25 01:11:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 01:11:36 --> Config Class Initialized
INFO - 2022-03-25 01:11:36 --> Hooks Class Initialized
DEBUG - 2022-03-25 01:11:36 --> UTF-8 Support Enabled
INFO - 2022-03-25 01:11:36 --> Utf8 Class Initialized
INFO - 2022-03-25 01:11:36 --> URI Class Initialized
INFO - 2022-03-25 01:11:36 --> Router Class Initialized
INFO - 2022-03-25 01:11:36 --> Output Class Initialized
INFO - 2022-03-25 01:11:36 --> Security Class Initialized
DEBUG - 2022-03-25 01:11:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 01:11:36 --> Input Class Initialized
INFO - 2022-03-25 01:11:36 --> Language Class Initialized
INFO - 2022-03-25 01:11:36 --> Loader Class Initialized
INFO - 2022-03-25 01:11:36 --> Helper loaded: url_helper
INFO - 2022-03-25 01:11:36 --> Helper loaded: form_helper
INFO - 2022-03-25 01:11:36 --> Helper loaded: common_helper
INFO - 2022-03-25 01:11:36 --> Database Driver Class Initialized
DEBUG - 2022-03-25 01:11:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 01:11:37 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-25 01:11:37 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-25 01:11:38 --> Final output sent to browser
DEBUG - 2022-03-25 01:11:38 --> Total execution time: 8.0893
INFO - 2022-03-25 01:11:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 01:11:38 --> Controller Class Initialized
INFO - 2022-03-25 01:11:38 --> Form Validation Class Initialized
DEBUG - 2022-03-25 01:11:38 --> Encrypt Class Initialized
INFO - 2022-03-25 01:11:38 --> Model "Patient_model" initialized
INFO - 2022-03-25 01:11:38 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 01:11:38 --> Model "Referredby_model" initialized
INFO - 2022-03-25 01:11:38 --> Model "Prefix_master" initialized
INFO - 2022-03-25 01:11:38 --> Model "Hospital_model" initialized
INFO - 2022-03-25 01:11:38 --> File loaded: /home3/karoteam/public_html/application/views/header.php
ERROR - 2022-03-25 01:11:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 01:11:44 --> Config Class Initialized
INFO - 2022-03-25 01:11:44 --> Hooks Class Initialized
DEBUG - 2022-03-25 01:11:44 --> UTF-8 Support Enabled
INFO - 2022-03-25 01:11:44 --> Utf8 Class Initialized
INFO - 2022-03-25 01:11:44 --> URI Class Initialized
INFO - 2022-03-25 01:11:44 --> Router Class Initialized
INFO - 2022-03-25 01:11:44 --> Output Class Initialized
INFO - 2022-03-25 01:11:44 --> Security Class Initialized
DEBUG - 2022-03-25 01:11:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 01:11:44 --> Input Class Initialized
INFO - 2022-03-25 01:11:44 --> Language Class Initialized
INFO - 2022-03-25 01:11:44 --> Loader Class Initialized
INFO - 2022-03-25 01:11:44 --> Helper loaded: url_helper
INFO - 2022-03-25 01:11:44 --> Helper loaded: form_helper
INFO - 2022-03-25 01:11:44 --> Helper loaded: common_helper
INFO - 2022-03-25 01:11:44 --> Database Driver Class Initialized
DEBUG - 2022-03-25 01:11:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 01:11:46 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-25 01:11:46 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-25 01:11:46 --> Final output sent to browser
DEBUG - 2022-03-25 01:11:46 --> Total execution time: 9.2627
INFO - 2022-03-25 01:11:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 01:11:46 --> Controller Class Initialized
INFO - 2022-03-25 01:11:46 --> Form Validation Class Initialized
DEBUG - 2022-03-25 01:11:46 --> Encrypt Class Initialized
INFO - 2022-03-25 01:11:46 --> Model "Patient_model" initialized
INFO - 2022-03-25 01:11:46 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 01:11:46 --> Model "Referredby_model" initialized
INFO - 2022-03-25 01:11:46 --> Model "Prefix_master" initialized
INFO - 2022-03-25 01:11:46 --> Model "Hospital_model" initialized
ERROR - 2022-03-25 01:11:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 01:11:46 --> Config Class Initialized
INFO - 2022-03-25 01:11:46 --> Hooks Class Initialized
DEBUG - 2022-03-25 01:11:46 --> UTF-8 Support Enabled
INFO - 2022-03-25 01:11:46 --> Utf8 Class Initialized
INFO - 2022-03-25 01:11:46 --> URI Class Initialized
INFO - 2022-03-25 01:11:46 --> Router Class Initialized
INFO - 2022-03-25 01:11:46 --> Output Class Initialized
INFO - 2022-03-25 01:11:46 --> Security Class Initialized
DEBUG - 2022-03-25 01:11:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 01:11:46 --> Input Class Initialized
INFO - 2022-03-25 01:11:46 --> Language Class Initialized
INFO - 2022-03-25 01:11:46 --> Loader Class Initialized
INFO - 2022-03-25 01:11:46 --> Helper loaded: url_helper
INFO - 2022-03-25 01:11:46 --> Helper loaded: form_helper
INFO - 2022-03-25 01:11:46 --> Helper loaded: common_helper
INFO - 2022-03-25 01:11:46 --> Database Driver Class Initialized
DEBUG - 2022-03-25 01:11:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 01:11:46 --> File loaded: /home3/karoteam/public_html/application/views/header.php
ERROR - 2022-03-25 01:11:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 01:11:47 --> Config Class Initialized
INFO - 2022-03-25 01:11:47 --> Hooks Class Initialized
DEBUG - 2022-03-25 01:11:47 --> UTF-8 Support Enabled
INFO - 2022-03-25 01:11:47 --> Utf8 Class Initialized
INFO - 2022-03-25 01:11:47 --> URI Class Initialized
INFO - 2022-03-25 01:11:47 --> Router Class Initialized
INFO - 2022-03-25 01:11:47 --> Output Class Initialized
INFO - 2022-03-25 01:11:47 --> Security Class Initialized
DEBUG - 2022-03-25 01:11:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 01:11:47 --> Input Class Initialized
INFO - 2022-03-25 01:11:47 --> Language Class Initialized
INFO - 2022-03-25 01:11:47 --> Loader Class Initialized
INFO - 2022-03-25 01:11:47 --> Helper loaded: url_helper
INFO - 2022-03-25 01:11:47 --> Helper loaded: form_helper
INFO - 2022-03-25 01:11:47 --> Helper loaded: common_helper
INFO - 2022-03-25 01:11:47 --> Database Driver Class Initialized
DEBUG - 2022-03-25 01:11:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 01:11:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 01:11:47 --> Controller Class Initialized
INFO - 2022-03-25 01:11:47 --> Form Validation Class Initialized
DEBUG - 2022-03-25 01:11:47 --> Encrypt Class Initialized
INFO - 2022-03-25 01:11:47 --> Model "Patient_model" initialized
INFO - 2022-03-25 01:11:47 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 01:11:47 --> Model "Prefix_master" initialized
INFO - 2022-03-25 01:11:47 --> Model "Users_model" initialized
INFO - 2022-03-25 01:11:47 --> Model "Hospital_model" initialized
INFO - 2022-03-25 01:11:48 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-25 01:11:49 --> Final output sent to browser
DEBUG - 2022-03-25 01:11:49 --> Total execution time: 1.2173
INFO - 2022-03-25 01:11:53 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-25 01:11:53 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-25 01:11:54 --> Final output sent to browser
DEBUG - 2022-03-25 01:11:54 --> Total execution time: 9.7832
INFO - 2022-03-25 01:11:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 01:11:54 --> Controller Class Initialized
INFO - 2022-03-25 01:11:54 --> Form Validation Class Initialized
DEBUG - 2022-03-25 01:11:54 --> Encrypt Class Initialized
INFO - 2022-03-25 01:11:54 --> Model "Patient_model" initialized
INFO - 2022-03-25 01:11:54 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 01:11:54 --> Model "Referredby_model" initialized
INFO - 2022-03-25 01:11:54 --> Model "Prefix_master" initialized
INFO - 2022-03-25 01:11:54 --> Model "Hospital_model" initialized
INFO - 2022-03-25 01:11:54 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-25 01:12:02 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-25 01:12:02 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
ERROR - 2022-03-25 01:12:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 01:12:03 --> Config Class Initialized
INFO - 2022-03-25 01:12:03 --> Hooks Class Initialized
DEBUG - 2022-03-25 01:12:03 --> UTF-8 Support Enabled
INFO - 2022-03-25 01:12:03 --> Utf8 Class Initialized
INFO - 2022-03-25 01:12:03 --> URI Class Initialized
INFO - 2022-03-25 01:12:03 --> Router Class Initialized
INFO - 2022-03-25 01:12:03 --> Output Class Initialized
INFO - 2022-03-25 01:12:03 --> Security Class Initialized
DEBUG - 2022-03-25 01:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 01:12:03 --> Input Class Initialized
INFO - 2022-03-25 01:12:03 --> Language Class Initialized
INFO - 2022-03-25 01:12:03 --> Loader Class Initialized
INFO - 2022-03-25 01:12:03 --> Helper loaded: url_helper
INFO - 2022-03-25 01:12:03 --> Helper loaded: form_helper
INFO - 2022-03-25 01:12:03 --> Helper loaded: common_helper
INFO - 2022-03-25 01:12:03 --> Database Driver Class Initialized
DEBUG - 2022-03-25 01:12:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 01:12:04 --> Final output sent to browser
DEBUG - 2022-03-25 01:12:04 --> Total execution time: 15.5409
INFO - 2022-03-25 01:12:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 01:12:04 --> Controller Class Initialized
INFO - 2022-03-25 01:12:04 --> Form Validation Class Initialized
DEBUG - 2022-03-25 01:12:04 --> Encrypt Class Initialized
INFO - 2022-03-25 01:12:04 --> Model "Patient_model" initialized
INFO - 2022-03-25 01:12:04 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 01:12:04 --> Model "Referredby_model" initialized
INFO - 2022-03-25 01:12:04 --> Model "Prefix_master" initialized
INFO - 2022-03-25 01:12:04 --> Model "Hospital_model" initialized
ERROR - 2022-03-25 01:12:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 01:12:04 --> Config Class Initialized
INFO - 2022-03-25 01:12:04 --> Hooks Class Initialized
DEBUG - 2022-03-25 01:12:04 --> UTF-8 Support Enabled
INFO - 2022-03-25 01:12:04 --> Utf8 Class Initialized
INFO - 2022-03-25 01:12:04 --> URI Class Initialized
INFO - 2022-03-25 01:12:04 --> Router Class Initialized
INFO - 2022-03-25 01:12:04 --> Output Class Initialized
INFO - 2022-03-25 01:12:04 --> Security Class Initialized
DEBUG - 2022-03-25 01:12:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 01:12:04 --> Input Class Initialized
INFO - 2022-03-25 01:12:04 --> Language Class Initialized
INFO - 2022-03-25 01:12:04 --> Loader Class Initialized
INFO - 2022-03-25 01:12:04 --> Helper loaded: url_helper
INFO - 2022-03-25 01:12:04 --> Helper loaded: form_helper
INFO - 2022-03-25 01:12:04 --> Helper loaded: common_helper
INFO - 2022-03-25 01:12:04 --> Database Driver Class Initialized
DEBUG - 2022-03-25 01:12:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 01:12:04 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-25 01:12:11 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-25 01:12:11 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-25 01:12:11 --> Final output sent to browser
DEBUG - 2022-03-25 01:12:11 --> Total execution time: 7.8876
INFO - 2022-03-25 01:12:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 01:12:11 --> Controller Class Initialized
INFO - 2022-03-25 01:12:11 --> Form Validation Class Initialized
DEBUG - 2022-03-25 01:12:11 --> Encrypt Class Initialized
INFO - 2022-03-25 01:12:11 --> Model "Patient_model" initialized
INFO - 2022-03-25 01:12:11 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 01:12:11 --> Model "Referredby_model" initialized
INFO - 2022-03-25 01:12:11 --> Model "Prefix_master" initialized
INFO - 2022-03-25 01:12:11 --> Model "Hospital_model" initialized
INFO - 2022-03-25 01:12:11 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-25 01:12:18 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-25 01:12:18 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-25 01:12:19 --> Final output sent to browser
DEBUG - 2022-03-25 01:12:19 --> Total execution time: 14.7993
ERROR - 2022-03-25 01:12:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 01:12:47 --> Config Class Initialized
INFO - 2022-03-25 01:12:47 --> Hooks Class Initialized
DEBUG - 2022-03-25 01:12:47 --> UTF-8 Support Enabled
INFO - 2022-03-25 01:12:47 --> Utf8 Class Initialized
INFO - 2022-03-25 01:12:47 --> URI Class Initialized
INFO - 2022-03-25 01:12:47 --> Router Class Initialized
INFO - 2022-03-25 01:12:47 --> Output Class Initialized
INFO - 2022-03-25 01:12:47 --> Security Class Initialized
DEBUG - 2022-03-25 01:12:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 01:12:47 --> Input Class Initialized
INFO - 2022-03-25 01:12:47 --> Language Class Initialized
INFO - 2022-03-25 01:12:47 --> Loader Class Initialized
INFO - 2022-03-25 01:12:47 --> Helper loaded: url_helper
INFO - 2022-03-25 01:12:47 --> Helper loaded: form_helper
INFO - 2022-03-25 01:12:47 --> Helper loaded: common_helper
INFO - 2022-03-25 01:12:47 --> Database Driver Class Initialized
DEBUG - 2022-03-25 01:12:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 01:12:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 01:12:47 --> Controller Class Initialized
INFO - 2022-03-25 01:12:47 --> Form Validation Class Initialized
DEBUG - 2022-03-25 01:12:47 --> Encrypt Class Initialized
INFO - 2022-03-25 01:12:47 --> Model "Patient_model" initialized
INFO - 2022-03-25 01:12:47 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 01:12:47 --> Model "Prefix_master" initialized
INFO - 2022-03-25 01:12:47 --> Model "Users_model" initialized
INFO - 2022-03-25 01:12:47 --> Model "Hospital_model" initialized
INFO - 2022-03-25 01:12:47 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-25 01:12:47 --> Final output sent to browser
DEBUG - 2022-03-25 01:12:47 --> Total execution time: 0.6258
ERROR - 2022-03-25 01:17:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 01:17:47 --> Config Class Initialized
INFO - 2022-03-25 01:17:47 --> Hooks Class Initialized
DEBUG - 2022-03-25 01:17:47 --> UTF-8 Support Enabled
INFO - 2022-03-25 01:17:47 --> Utf8 Class Initialized
INFO - 2022-03-25 01:17:47 --> URI Class Initialized
INFO - 2022-03-25 01:17:47 --> Router Class Initialized
INFO - 2022-03-25 01:17:47 --> Output Class Initialized
INFO - 2022-03-25 01:17:47 --> Security Class Initialized
DEBUG - 2022-03-25 01:17:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 01:17:47 --> Input Class Initialized
INFO - 2022-03-25 01:17:47 --> Language Class Initialized
INFO - 2022-03-25 01:17:47 --> Loader Class Initialized
INFO - 2022-03-25 01:17:47 --> Helper loaded: url_helper
INFO - 2022-03-25 01:17:47 --> Helper loaded: form_helper
INFO - 2022-03-25 01:17:47 --> Helper loaded: common_helper
INFO - 2022-03-25 01:17:47 --> Database Driver Class Initialized
DEBUG - 2022-03-25 01:17:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 01:17:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 01:17:47 --> Controller Class Initialized
INFO - 2022-03-25 01:17:47 --> Form Validation Class Initialized
DEBUG - 2022-03-25 01:17:47 --> Encrypt Class Initialized
INFO - 2022-03-25 01:17:47 --> Model "Patient_model" initialized
INFO - 2022-03-25 01:17:47 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 01:17:47 --> Model "Prefix_master" initialized
INFO - 2022-03-25 01:17:47 --> Model "Users_model" initialized
INFO - 2022-03-25 01:17:47 --> Model "Hospital_model" initialized
INFO - 2022-03-25 01:17:47 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-25 01:17:48 --> Final output sent to browser
DEBUG - 2022-03-25 01:17:48 --> Total execution time: 1.1076
ERROR - 2022-03-25 01:20:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 01:20:27 --> Config Class Initialized
INFO - 2022-03-25 01:20:27 --> Hooks Class Initialized
DEBUG - 2022-03-25 01:20:27 --> UTF-8 Support Enabled
INFO - 2022-03-25 01:20:27 --> Utf8 Class Initialized
INFO - 2022-03-25 01:20:27 --> URI Class Initialized
INFO - 2022-03-25 01:20:27 --> Router Class Initialized
INFO - 2022-03-25 01:20:27 --> Output Class Initialized
INFO - 2022-03-25 01:20:27 --> Security Class Initialized
DEBUG - 2022-03-25 01:20:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 01:20:27 --> Input Class Initialized
INFO - 2022-03-25 01:20:27 --> Language Class Initialized
INFO - 2022-03-25 01:20:27 --> Loader Class Initialized
INFO - 2022-03-25 01:20:27 --> Helper loaded: url_helper
INFO - 2022-03-25 01:20:27 --> Helper loaded: form_helper
INFO - 2022-03-25 01:20:27 --> Helper loaded: common_helper
INFO - 2022-03-25 01:20:27 --> Database Driver Class Initialized
DEBUG - 2022-03-25 01:20:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 01:20:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 01:20:27 --> Controller Class Initialized
INFO - 2022-03-25 01:20:27 --> Form Validation Class Initialized
DEBUG - 2022-03-25 01:20:27 --> Encrypt Class Initialized
INFO - 2022-03-25 01:20:27 --> Model "Patient_model" initialized
INFO - 2022-03-25 01:20:27 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 01:20:27 --> Model "Prefix_master" initialized
INFO - 2022-03-25 01:20:27 --> Model "Users_model" initialized
INFO - 2022-03-25 01:20:27 --> Model "Hospital_model" initialized
ERROR - 2022-03-25 01:20:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 01:20:27 --> Config Class Initialized
INFO - 2022-03-25 01:20:28 --> Hooks Class Initialized
DEBUG - 2022-03-25 01:20:28 --> UTF-8 Support Enabled
INFO - 2022-03-25 01:20:28 --> Utf8 Class Initialized
INFO - 2022-03-25 01:20:28 --> URI Class Initialized
INFO - 2022-03-25 01:20:28 --> Router Class Initialized
INFO - 2022-03-25 01:20:28 --> Output Class Initialized
INFO - 2022-03-25 01:20:28 --> Security Class Initialized
DEBUG - 2022-03-25 01:20:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 01:20:28 --> Input Class Initialized
INFO - 2022-03-25 01:20:28 --> Language Class Initialized
INFO - 2022-03-25 01:20:28 --> Loader Class Initialized
INFO - 2022-03-25 01:20:28 --> Helper loaded: url_helper
INFO - 2022-03-25 01:20:28 --> Helper loaded: form_helper
INFO - 2022-03-25 01:20:28 --> Helper loaded: common_helper
INFO - 2022-03-25 01:20:28 --> Database Driver Class Initialized
DEBUG - 2022-03-25 01:20:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 01:20:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 01:20:28 --> Controller Class Initialized
INFO - 2022-03-25 01:20:28 --> Form Validation Class Initialized
DEBUG - 2022-03-25 01:20:28 --> Encrypt Class Initialized
INFO - 2022-03-25 01:20:28 --> Model "Patient_model" initialized
INFO - 2022-03-25 01:20:28 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 01:20:28 --> Model "Prefix_master" initialized
INFO - 2022-03-25 01:20:28 --> Model "Users_model" initialized
INFO - 2022-03-25 01:20:28 --> Model "Hospital_model" initialized
INFO - 2022-03-25 01:20:28 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-25 01:20:28 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-25 01:20:28 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-25 01:20:28 --> Final output sent to browser
DEBUG - 2022-03-25 01:20:28 --> Total execution time: 0.1032
ERROR - 2022-03-25 01:20:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 01:20:28 --> Config Class Initialized
INFO - 2022-03-25 01:20:28 --> Hooks Class Initialized
DEBUG - 2022-03-25 01:20:28 --> UTF-8 Support Enabled
INFO - 2022-03-25 01:20:28 --> Utf8 Class Initialized
INFO - 2022-03-25 01:20:28 --> URI Class Initialized
INFO - 2022-03-25 01:20:28 --> Router Class Initialized
INFO - 2022-03-25 01:20:28 --> Output Class Initialized
INFO - 2022-03-25 01:20:28 --> Security Class Initialized
DEBUG - 2022-03-25 01:20:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 01:20:28 --> Input Class Initialized
INFO - 2022-03-25 01:20:28 --> Language Class Initialized
ERROR - 2022-03-25 01:20:28 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-25 01:21:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 01:21:06 --> Config Class Initialized
INFO - 2022-03-25 01:21:06 --> Hooks Class Initialized
DEBUG - 2022-03-25 01:21:06 --> UTF-8 Support Enabled
INFO - 2022-03-25 01:21:06 --> Utf8 Class Initialized
INFO - 2022-03-25 01:21:06 --> URI Class Initialized
INFO - 2022-03-25 01:21:06 --> Router Class Initialized
INFO - 2022-03-25 01:21:06 --> Output Class Initialized
INFO - 2022-03-25 01:21:06 --> Security Class Initialized
DEBUG - 2022-03-25 01:21:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 01:21:06 --> Input Class Initialized
INFO - 2022-03-25 01:21:06 --> Language Class Initialized
INFO - 2022-03-25 01:21:06 --> Loader Class Initialized
INFO - 2022-03-25 01:21:06 --> Helper loaded: url_helper
INFO - 2022-03-25 01:21:06 --> Helper loaded: form_helper
INFO - 2022-03-25 01:21:06 --> Helper loaded: common_helper
INFO - 2022-03-25 01:21:06 --> Database Driver Class Initialized
DEBUG - 2022-03-25 01:21:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 01:21:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 01:21:06 --> Controller Class Initialized
INFO - 2022-03-25 01:21:06 --> Form Validation Class Initialized
DEBUG - 2022-03-25 01:21:06 --> Encrypt Class Initialized
INFO - 2022-03-25 01:21:06 --> Model "Patient_model" initialized
INFO - 2022-03-25 01:21:06 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 01:21:06 --> Model "Referredby_model" initialized
INFO - 2022-03-25 01:21:06 --> Model "Prefix_master" initialized
INFO - 2022-03-25 01:21:06 --> Model "Hospital_model" initialized
INFO - 2022-03-25 01:21:06 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-25 01:21:12 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-25 01:21:12 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
ERROR - 2022-03-25 01:21:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 01:21:13 --> Config Class Initialized
INFO - 2022-03-25 01:21:13 --> Hooks Class Initialized
DEBUG - 2022-03-25 01:21:13 --> UTF-8 Support Enabled
INFO - 2022-03-25 01:21:13 --> Utf8 Class Initialized
INFO - 2022-03-25 01:21:13 --> URI Class Initialized
INFO - 2022-03-25 01:21:13 --> Router Class Initialized
INFO - 2022-03-25 01:21:13 --> Output Class Initialized
INFO - 2022-03-25 01:21:13 --> Security Class Initialized
DEBUG - 2022-03-25 01:21:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 01:21:13 --> Input Class Initialized
INFO - 2022-03-25 01:21:13 --> Language Class Initialized
ERROR - 2022-03-25 01:21:13 --> 404 Page Not Found: Karoclient/usersprofile
INFO - 2022-03-25 01:21:14 --> Final output sent to browser
DEBUG - 2022-03-25 01:21:14 --> Total execution time: 6.1267
ERROR - 2022-03-25 01:21:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 01:21:33 --> Config Class Initialized
INFO - 2022-03-25 01:21:33 --> Hooks Class Initialized
DEBUG - 2022-03-25 01:21:33 --> UTF-8 Support Enabled
INFO - 2022-03-25 01:21:33 --> Utf8 Class Initialized
INFO - 2022-03-25 01:21:33 --> URI Class Initialized
INFO - 2022-03-25 01:21:33 --> Router Class Initialized
INFO - 2022-03-25 01:21:33 --> Output Class Initialized
INFO - 2022-03-25 01:21:33 --> Security Class Initialized
DEBUG - 2022-03-25 01:21:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 01:21:33 --> Input Class Initialized
INFO - 2022-03-25 01:21:33 --> Language Class Initialized
INFO - 2022-03-25 01:21:33 --> Loader Class Initialized
INFO - 2022-03-25 01:21:33 --> Helper loaded: url_helper
INFO - 2022-03-25 01:21:33 --> Helper loaded: form_helper
INFO - 2022-03-25 01:21:33 --> Helper loaded: common_helper
INFO - 2022-03-25 01:21:33 --> Database Driver Class Initialized
DEBUG - 2022-03-25 01:21:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 01:21:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 01:21:33 --> Controller Class Initialized
INFO - 2022-03-25 01:21:33 --> Form Validation Class Initialized
DEBUG - 2022-03-25 01:21:33 --> Encrypt Class Initialized
INFO - 2022-03-25 01:21:33 --> Model "Patient_model" initialized
INFO - 2022-03-25 01:21:33 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 01:21:33 --> Model "Prefix_master" initialized
INFO - 2022-03-25 01:21:33 --> Model "Users_model" initialized
INFO - 2022-03-25 01:21:33 --> Model "Hospital_model" initialized
INFO - 2022-03-25 01:21:33 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-25 01:21:33 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-25 01:21:33 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-25 01:21:33 --> Final output sent to browser
DEBUG - 2022-03-25 01:21:33 --> Total execution time: 0.0504
ERROR - 2022-03-25 01:21:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 01:21:34 --> Config Class Initialized
INFO - 2022-03-25 01:21:34 --> Hooks Class Initialized
DEBUG - 2022-03-25 01:21:34 --> UTF-8 Support Enabled
INFO - 2022-03-25 01:21:34 --> Utf8 Class Initialized
INFO - 2022-03-25 01:21:34 --> URI Class Initialized
INFO - 2022-03-25 01:21:34 --> Router Class Initialized
INFO - 2022-03-25 01:21:34 --> Output Class Initialized
INFO - 2022-03-25 01:21:34 --> Security Class Initialized
DEBUG - 2022-03-25 01:21:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 01:21:34 --> Input Class Initialized
INFO - 2022-03-25 01:21:34 --> Language Class Initialized
ERROR - 2022-03-25 01:21:34 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-25 01:52:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 01:52:12 --> Config Class Initialized
INFO - 2022-03-25 01:52:12 --> Hooks Class Initialized
DEBUG - 2022-03-25 01:52:12 --> UTF-8 Support Enabled
INFO - 2022-03-25 01:52:12 --> Utf8 Class Initialized
INFO - 2022-03-25 01:52:12 --> URI Class Initialized
INFO - 2022-03-25 01:52:12 --> Router Class Initialized
INFO - 2022-03-25 01:52:12 --> Output Class Initialized
INFO - 2022-03-25 01:52:12 --> Security Class Initialized
DEBUG - 2022-03-25 01:52:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 01:52:12 --> Input Class Initialized
INFO - 2022-03-25 01:52:12 --> Language Class Initialized
INFO - 2022-03-25 01:52:12 --> Loader Class Initialized
INFO - 2022-03-25 01:52:12 --> Helper loaded: url_helper
INFO - 2022-03-25 01:52:12 --> Helper loaded: form_helper
INFO - 2022-03-25 01:52:12 --> Helper loaded: common_helper
INFO - 2022-03-25 01:52:12 --> Database Driver Class Initialized
DEBUG - 2022-03-25 01:52:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 01:52:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 01:52:12 --> Controller Class Initialized
INFO - 2022-03-25 01:52:12 --> Form Validation Class Initialized
DEBUG - 2022-03-25 01:52:12 --> Encrypt Class Initialized
INFO - 2022-03-25 01:52:12 --> Model "Patient_model" initialized
INFO - 2022-03-25 01:52:12 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 01:52:12 --> Model "Prefix_master" initialized
INFO - 2022-03-25 01:52:12 --> Model "Users_model" initialized
INFO - 2022-03-25 01:52:12 --> Model "Hospital_model" initialized
ERROR - 2022-03-25 01:52:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 01:52:12 --> Config Class Initialized
INFO - 2022-03-25 01:52:12 --> Hooks Class Initialized
DEBUG - 2022-03-25 01:52:12 --> UTF-8 Support Enabled
INFO - 2022-03-25 01:52:12 --> Utf8 Class Initialized
INFO - 2022-03-25 01:52:12 --> URI Class Initialized
INFO - 2022-03-25 01:52:12 --> Router Class Initialized
INFO - 2022-03-25 01:52:12 --> Output Class Initialized
INFO - 2022-03-25 01:52:12 --> Security Class Initialized
DEBUG - 2022-03-25 01:52:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 01:52:12 --> Input Class Initialized
INFO - 2022-03-25 01:52:12 --> Language Class Initialized
INFO - 2022-03-25 01:52:12 --> Loader Class Initialized
INFO - 2022-03-25 01:52:12 --> Helper loaded: url_helper
INFO - 2022-03-25 01:52:12 --> Helper loaded: form_helper
INFO - 2022-03-25 01:52:12 --> Helper loaded: common_helper
INFO - 2022-03-25 01:52:12 --> Database Driver Class Initialized
DEBUG - 2022-03-25 01:52:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 01:52:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 01:52:12 --> Controller Class Initialized
INFO - 2022-03-25 01:52:12 --> Form Validation Class Initialized
DEBUG - 2022-03-25 01:52:12 --> Encrypt Class Initialized
INFO - 2022-03-25 01:52:12 --> Model "Patient_model" initialized
INFO - 2022-03-25 01:52:12 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 01:52:12 --> Model "Prefix_master" initialized
INFO - 2022-03-25 01:52:12 --> Model "Users_model" initialized
INFO - 2022-03-25 01:52:12 --> Model "Hospital_model" initialized
INFO - 2022-03-25 01:52:12 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-25 01:52:12 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-25 01:52:12 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-25 01:52:12 --> Final output sent to browser
DEBUG - 2022-03-25 01:52:12 --> Total execution time: 0.0975
ERROR - 2022-03-25 01:52:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 01:52:12 --> Config Class Initialized
INFO - 2022-03-25 01:52:12 --> Hooks Class Initialized
DEBUG - 2022-03-25 01:52:12 --> UTF-8 Support Enabled
INFO - 2022-03-25 01:52:12 --> Utf8 Class Initialized
INFO - 2022-03-25 01:52:12 --> URI Class Initialized
INFO - 2022-03-25 01:52:12 --> Router Class Initialized
INFO - 2022-03-25 01:52:12 --> Output Class Initialized
INFO - 2022-03-25 01:52:12 --> Security Class Initialized
DEBUG - 2022-03-25 01:52:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 01:52:12 --> Input Class Initialized
INFO - 2022-03-25 01:52:12 --> Language Class Initialized
ERROR - 2022-03-25 01:52:12 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-25 01:52:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 01:52:25 --> Config Class Initialized
INFO - 2022-03-25 01:52:25 --> Hooks Class Initialized
DEBUG - 2022-03-25 01:52:25 --> UTF-8 Support Enabled
INFO - 2022-03-25 01:52:25 --> Utf8 Class Initialized
INFO - 2022-03-25 01:52:25 --> URI Class Initialized
INFO - 2022-03-25 01:52:25 --> Router Class Initialized
INFO - 2022-03-25 01:52:25 --> Output Class Initialized
INFO - 2022-03-25 01:52:25 --> Security Class Initialized
DEBUG - 2022-03-25 01:52:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 01:52:25 --> Input Class Initialized
INFO - 2022-03-25 01:52:25 --> Language Class Initialized
INFO - 2022-03-25 01:52:25 --> Loader Class Initialized
INFO - 2022-03-25 01:52:25 --> Helper loaded: url_helper
INFO - 2022-03-25 01:52:25 --> Helper loaded: form_helper
INFO - 2022-03-25 01:52:25 --> Helper loaded: common_helper
INFO - 2022-03-25 01:52:25 --> Database Driver Class Initialized
DEBUG - 2022-03-25 01:52:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 01:52:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 01:52:25 --> Controller Class Initialized
INFO - 2022-03-25 01:52:25 --> Form Validation Class Initialized
DEBUG - 2022-03-25 01:52:25 --> Encrypt Class Initialized
INFO - 2022-03-25 01:52:25 --> Model "Patient_model" initialized
INFO - 2022-03-25 01:52:25 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 01:52:25 --> Model "Referredby_model" initialized
INFO - 2022-03-25 01:52:25 --> Model "Prefix_master" initialized
INFO - 2022-03-25 01:52:25 --> Model "Hospital_model" initialized
INFO - 2022-03-25 01:52:25 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-25 01:52:32 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-25 01:52:32 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
ERROR - 2022-03-25 01:52:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 01:52:33 --> Config Class Initialized
INFO - 2022-03-25 01:52:33 --> Hooks Class Initialized
DEBUG - 2022-03-25 01:52:33 --> UTF-8 Support Enabled
INFO - 2022-03-25 01:52:33 --> Utf8 Class Initialized
INFO - 2022-03-25 01:52:33 --> URI Class Initialized
INFO - 2022-03-25 01:52:33 --> Router Class Initialized
INFO - 2022-03-25 01:52:33 --> Output Class Initialized
INFO - 2022-03-25 01:52:33 --> Security Class Initialized
DEBUG - 2022-03-25 01:52:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 01:52:33 --> Input Class Initialized
INFO - 2022-03-25 01:52:33 --> Language Class Initialized
ERROR - 2022-03-25 01:52:33 --> 404 Page Not Found: Karoclient/usersprofile
INFO - 2022-03-25 01:52:33 --> Final output sent to browser
DEBUG - 2022-03-25 01:52:33 --> Total execution time: 6.7417
ERROR - 2022-03-25 01:53:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 01:53:00 --> Config Class Initialized
INFO - 2022-03-25 01:53:00 --> Hooks Class Initialized
DEBUG - 2022-03-25 01:53:00 --> UTF-8 Support Enabled
INFO - 2022-03-25 01:53:00 --> Utf8 Class Initialized
INFO - 2022-03-25 01:53:00 --> URI Class Initialized
INFO - 2022-03-25 01:53:00 --> Router Class Initialized
INFO - 2022-03-25 01:53:00 --> Output Class Initialized
INFO - 2022-03-25 01:53:00 --> Security Class Initialized
DEBUG - 2022-03-25 01:53:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 01:53:00 --> Input Class Initialized
INFO - 2022-03-25 01:53:00 --> Language Class Initialized
INFO - 2022-03-25 01:53:00 --> Loader Class Initialized
INFO - 2022-03-25 01:53:00 --> Helper loaded: url_helper
INFO - 2022-03-25 01:53:00 --> Helper loaded: form_helper
INFO - 2022-03-25 01:53:00 --> Helper loaded: common_helper
INFO - 2022-03-25 01:53:00 --> Database Driver Class Initialized
DEBUG - 2022-03-25 01:53:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 01:53:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 01:53:00 --> Controller Class Initialized
INFO - 2022-03-25 01:53:00 --> Form Validation Class Initialized
DEBUG - 2022-03-25 01:53:00 --> Encrypt Class Initialized
INFO - 2022-03-25 01:53:00 --> Model "Patient_model" initialized
INFO - 2022-03-25 01:53:00 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 01:53:00 --> Model "Prefix_master" initialized
INFO - 2022-03-25 01:53:00 --> Model "Users_model" initialized
INFO - 2022-03-25 01:53:00 --> Model "Hospital_model" initialized
INFO - 2022-03-25 01:53:00 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-25 01:53:00 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-25 01:53:00 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-25 01:53:00 --> Final output sent to browser
DEBUG - 2022-03-25 01:53:00 --> Total execution time: 0.0518
ERROR - 2022-03-25 01:53:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 01:53:01 --> Config Class Initialized
INFO - 2022-03-25 01:53:01 --> Hooks Class Initialized
DEBUG - 2022-03-25 01:53:01 --> UTF-8 Support Enabled
INFO - 2022-03-25 01:53:01 --> Utf8 Class Initialized
INFO - 2022-03-25 01:53:01 --> URI Class Initialized
INFO - 2022-03-25 01:53:01 --> Router Class Initialized
INFO - 2022-03-25 01:53:01 --> Output Class Initialized
INFO - 2022-03-25 01:53:01 --> Security Class Initialized
DEBUG - 2022-03-25 01:53:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 01:53:01 --> Input Class Initialized
INFO - 2022-03-25 01:53:01 --> Language Class Initialized
ERROR - 2022-03-25 01:53:01 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-25 01:54:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 01:54:42 --> Config Class Initialized
INFO - 2022-03-25 01:54:42 --> Hooks Class Initialized
DEBUG - 2022-03-25 01:54:42 --> UTF-8 Support Enabled
INFO - 2022-03-25 01:54:42 --> Utf8 Class Initialized
INFO - 2022-03-25 01:54:42 --> URI Class Initialized
INFO - 2022-03-25 01:54:42 --> Router Class Initialized
INFO - 2022-03-25 01:54:42 --> Output Class Initialized
INFO - 2022-03-25 01:54:42 --> Security Class Initialized
DEBUG - 2022-03-25 01:54:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 01:54:42 --> Input Class Initialized
INFO - 2022-03-25 01:54:42 --> Language Class Initialized
ERROR - 2022-03-25 01:54:42 --> 404 Page Not Found: Aws/.credentials
ERROR - 2022-03-25 01:54:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 01:54:42 --> Config Class Initialized
INFO - 2022-03-25 01:54:42 --> Hooks Class Initialized
DEBUG - 2022-03-25 01:54:42 --> UTF-8 Support Enabled
INFO - 2022-03-25 01:54:42 --> Utf8 Class Initialized
INFO - 2022-03-25 01:54:42 --> URI Class Initialized
INFO - 2022-03-25 01:54:42 --> Router Class Initialized
INFO - 2022-03-25 01:54:42 --> Output Class Initialized
INFO - 2022-03-25 01:54:42 --> Security Class Initialized
DEBUG - 2022-03-25 01:54:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 01:54:42 --> Input Class Initialized
INFO - 2022-03-25 01:54:42 --> Language Class Initialized
ERROR - 2022-03-25 01:54:42 --> 404 Page Not Found: Aws/.credentials
ERROR - 2022-03-25 01:55:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 01:55:49 --> Config Class Initialized
INFO - 2022-03-25 01:55:49 --> Hooks Class Initialized
DEBUG - 2022-03-25 01:55:49 --> UTF-8 Support Enabled
INFO - 2022-03-25 01:55:49 --> Utf8 Class Initialized
INFO - 2022-03-25 01:55:49 --> URI Class Initialized
DEBUG - 2022-03-25 01:55:49 --> No URI present. Default controller set.
INFO - 2022-03-25 01:55:49 --> Router Class Initialized
INFO - 2022-03-25 01:55:49 --> Output Class Initialized
INFO - 2022-03-25 01:55:49 --> Security Class Initialized
DEBUG - 2022-03-25 01:55:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 01:55:49 --> Input Class Initialized
INFO - 2022-03-25 01:55:49 --> Language Class Initialized
INFO - 2022-03-25 01:55:49 --> Loader Class Initialized
INFO - 2022-03-25 01:55:49 --> Helper loaded: url_helper
INFO - 2022-03-25 01:55:49 --> Helper loaded: form_helper
INFO - 2022-03-25 01:55:49 --> Helper loaded: common_helper
INFO - 2022-03-25 01:55:49 --> Database Driver Class Initialized
DEBUG - 2022-03-25 01:55:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 01:55:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 01:55:49 --> Controller Class Initialized
INFO - 2022-03-25 01:55:49 --> Form Validation Class Initialized
DEBUG - 2022-03-25 01:55:49 --> Encrypt Class Initialized
DEBUG - 2022-03-25 01:55:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 01:55:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-25 01:55:49 --> Email Class Initialized
INFO - 2022-03-25 01:55:49 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-25 01:55:49 --> Calendar Class Initialized
INFO - 2022-03-25 01:55:49 --> Model "Login_model" initialized
ERROR - 2022-03-25 01:55:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 01:55:50 --> Config Class Initialized
INFO - 2022-03-25 01:55:50 --> Hooks Class Initialized
DEBUG - 2022-03-25 01:55:50 --> UTF-8 Support Enabled
INFO - 2022-03-25 01:55:50 --> Utf8 Class Initialized
INFO - 2022-03-25 01:55:50 --> URI Class Initialized
INFO - 2022-03-25 01:55:50 --> Router Class Initialized
INFO - 2022-03-25 01:55:50 --> Output Class Initialized
INFO - 2022-03-25 01:55:50 --> Security Class Initialized
DEBUG - 2022-03-25 01:55:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 01:55:50 --> Input Class Initialized
INFO - 2022-03-25 01:55:50 --> Language Class Initialized
INFO - 2022-03-25 01:55:50 --> Loader Class Initialized
INFO - 2022-03-25 01:55:50 --> Helper loaded: url_helper
INFO - 2022-03-25 01:55:50 --> Helper loaded: form_helper
INFO - 2022-03-25 01:55:50 --> Helper loaded: common_helper
INFO - 2022-03-25 01:55:50 --> Database Driver Class Initialized
DEBUG - 2022-03-25 01:55:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 01:55:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 01:55:50 --> Controller Class Initialized
INFO - 2022-03-25 01:55:50 --> Form Validation Class Initialized
DEBUG - 2022-03-25 01:55:50 --> Encrypt Class Initialized
INFO - 2022-03-25 01:55:50 --> Model "Diseases_model" initialized
INFO - 2022-03-25 01:55:50 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-25 01:55:50 --> File loaded: /home3/karoteam/public_html/application/views/diseases/index.php
INFO - 2022-03-25 01:55:50 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-25 01:55:50 --> Final output sent to browser
DEBUG - 2022-03-25 01:55:50 --> Total execution time: 0.0148
ERROR - 2022-03-25 01:55:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 01:55:51 --> Config Class Initialized
INFO - 2022-03-25 01:55:51 --> Hooks Class Initialized
DEBUG - 2022-03-25 01:55:51 --> UTF-8 Support Enabled
INFO - 2022-03-25 01:55:51 --> Utf8 Class Initialized
INFO - 2022-03-25 01:55:51 --> URI Class Initialized
DEBUG - 2022-03-25 01:55:51 --> No URI present. Default controller set.
INFO - 2022-03-25 01:55:51 --> Router Class Initialized
INFO - 2022-03-25 01:55:51 --> Output Class Initialized
INFO - 2022-03-25 01:55:51 --> Security Class Initialized
DEBUG - 2022-03-25 01:55:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 01:55:51 --> Input Class Initialized
INFO - 2022-03-25 01:55:51 --> Language Class Initialized
INFO - 2022-03-25 01:55:51 --> Loader Class Initialized
INFO - 2022-03-25 01:55:51 --> Helper loaded: url_helper
INFO - 2022-03-25 01:55:51 --> Helper loaded: form_helper
INFO - 2022-03-25 01:55:51 --> Helper loaded: common_helper
INFO - 2022-03-25 01:55:51 --> Database Driver Class Initialized
DEBUG - 2022-03-25 01:55:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 01:55:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 01:55:51 --> Controller Class Initialized
INFO - 2022-03-25 01:55:51 --> Form Validation Class Initialized
DEBUG - 2022-03-25 01:55:51 --> Encrypt Class Initialized
DEBUG - 2022-03-25 01:55:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 01:55:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-25 01:55:51 --> Email Class Initialized
INFO - 2022-03-25 01:55:51 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-25 01:55:51 --> Calendar Class Initialized
INFO - 2022-03-25 01:55:51 --> Model "Login_model" initialized
ERROR - 2022-03-25 01:55:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 01:55:52 --> Config Class Initialized
INFO - 2022-03-25 01:55:52 --> Hooks Class Initialized
DEBUG - 2022-03-25 01:55:52 --> UTF-8 Support Enabled
INFO - 2022-03-25 01:55:52 --> Utf8 Class Initialized
INFO - 2022-03-25 01:55:52 --> URI Class Initialized
INFO - 2022-03-25 01:55:52 --> Router Class Initialized
INFO - 2022-03-25 01:55:52 --> Output Class Initialized
INFO - 2022-03-25 01:55:52 --> Security Class Initialized
DEBUG - 2022-03-25 01:55:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 01:55:52 --> Input Class Initialized
INFO - 2022-03-25 01:55:52 --> Language Class Initialized
INFO - 2022-03-25 01:55:52 --> Loader Class Initialized
INFO - 2022-03-25 01:55:52 --> Helper loaded: url_helper
INFO - 2022-03-25 01:55:52 --> Helper loaded: form_helper
INFO - 2022-03-25 01:55:52 --> Helper loaded: common_helper
INFO - 2022-03-25 01:55:52 --> Database Driver Class Initialized
DEBUG - 2022-03-25 01:55:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 01:55:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 01:55:52 --> Controller Class Initialized
INFO - 2022-03-25 01:55:52 --> Form Validation Class Initialized
DEBUG - 2022-03-25 01:55:52 --> Encrypt Class Initialized
INFO - 2022-03-25 01:55:52 --> Model "Diseases_model" initialized
INFO - 2022-03-25 01:55:52 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-25 01:55:52 --> File loaded: /home3/karoteam/public_html/application/views/diseases/index.php
INFO - 2022-03-25 01:55:52 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-25 01:55:52 --> Final output sent to browser
DEBUG - 2022-03-25 01:55:52 --> Total execution time: 0.3397
ERROR - 2022-03-25 01:58:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 01:58:16 --> Config Class Initialized
INFO - 2022-03-25 01:58:16 --> Hooks Class Initialized
DEBUG - 2022-03-25 01:58:16 --> UTF-8 Support Enabled
INFO - 2022-03-25 01:58:16 --> Utf8 Class Initialized
INFO - 2022-03-25 01:58:16 --> URI Class Initialized
INFO - 2022-03-25 01:58:16 --> Router Class Initialized
INFO - 2022-03-25 01:58:16 --> Output Class Initialized
INFO - 2022-03-25 01:58:16 --> Security Class Initialized
DEBUG - 2022-03-25 01:58:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 01:58:16 --> Input Class Initialized
INFO - 2022-03-25 01:58:16 --> Language Class Initialized
INFO - 2022-03-25 01:58:16 --> Loader Class Initialized
INFO - 2022-03-25 01:58:16 --> Helper loaded: url_helper
INFO - 2022-03-25 01:58:16 --> Helper loaded: form_helper
INFO - 2022-03-25 01:58:16 --> Helper loaded: common_helper
INFO - 2022-03-25 01:58:16 --> Database Driver Class Initialized
DEBUG - 2022-03-25 01:58:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 01:58:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 01:58:16 --> Controller Class Initialized
INFO - 2022-03-25 01:58:16 --> Form Validation Class Initialized
DEBUG - 2022-03-25 01:58:16 --> Encrypt Class Initialized
INFO - 2022-03-25 01:58:16 --> Model "Patient_model" initialized
INFO - 2022-03-25 01:58:16 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 01:58:16 --> Model "Prefix_master" initialized
INFO - 2022-03-25 01:58:16 --> Model "Users_model" initialized
INFO - 2022-03-25 01:58:16 --> Model "Hospital_model" initialized
ERROR - 2022-03-25 01:58:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 01:58:16 --> Config Class Initialized
INFO - 2022-03-25 01:58:16 --> Hooks Class Initialized
DEBUG - 2022-03-25 01:58:16 --> UTF-8 Support Enabled
INFO - 2022-03-25 01:58:16 --> Utf8 Class Initialized
INFO - 2022-03-25 01:58:16 --> URI Class Initialized
INFO - 2022-03-25 01:58:16 --> Router Class Initialized
INFO - 2022-03-25 01:58:16 --> Output Class Initialized
INFO - 2022-03-25 01:58:16 --> Security Class Initialized
DEBUG - 2022-03-25 01:58:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 01:58:16 --> Input Class Initialized
INFO - 2022-03-25 01:58:16 --> Language Class Initialized
INFO - 2022-03-25 01:58:16 --> Loader Class Initialized
INFO - 2022-03-25 01:58:16 --> Helper loaded: url_helper
INFO - 2022-03-25 01:58:16 --> Helper loaded: form_helper
INFO - 2022-03-25 01:58:16 --> Helper loaded: common_helper
INFO - 2022-03-25 01:58:16 --> Database Driver Class Initialized
DEBUG - 2022-03-25 01:58:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 01:58:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 01:58:16 --> Controller Class Initialized
INFO - 2022-03-25 01:58:16 --> Form Validation Class Initialized
DEBUG - 2022-03-25 01:58:16 --> Encrypt Class Initialized
INFO - 2022-03-25 01:58:16 --> Model "Patient_model" initialized
INFO - 2022-03-25 01:58:16 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 01:58:16 --> Model "Prefix_master" initialized
INFO - 2022-03-25 01:58:16 --> Model "Users_model" initialized
INFO - 2022-03-25 01:58:16 --> Model "Hospital_model" initialized
INFO - 2022-03-25 01:58:16 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-25 01:58:16 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-25 01:58:16 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-25 01:58:16 --> Final output sent to browser
DEBUG - 2022-03-25 01:58:16 --> Total execution time: 0.0560
ERROR - 2022-03-25 01:58:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 01:58:16 --> Config Class Initialized
INFO - 2022-03-25 01:58:16 --> Hooks Class Initialized
DEBUG - 2022-03-25 01:58:16 --> UTF-8 Support Enabled
INFO - 2022-03-25 01:58:16 --> Utf8 Class Initialized
INFO - 2022-03-25 01:58:16 --> URI Class Initialized
INFO - 2022-03-25 01:58:16 --> Router Class Initialized
INFO - 2022-03-25 01:58:16 --> Output Class Initialized
INFO - 2022-03-25 01:58:16 --> Security Class Initialized
DEBUG - 2022-03-25 01:58:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 01:58:16 --> Input Class Initialized
INFO - 2022-03-25 01:58:16 --> Language Class Initialized
ERROR - 2022-03-25 01:58:16 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-25 01:58:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 01:58:20 --> Config Class Initialized
INFO - 2022-03-25 01:58:20 --> Hooks Class Initialized
DEBUG - 2022-03-25 01:58:20 --> UTF-8 Support Enabled
INFO - 2022-03-25 01:58:20 --> Utf8 Class Initialized
INFO - 2022-03-25 01:58:20 --> URI Class Initialized
INFO - 2022-03-25 01:58:20 --> Router Class Initialized
INFO - 2022-03-25 01:58:20 --> Output Class Initialized
INFO - 2022-03-25 01:58:20 --> Security Class Initialized
DEBUG - 2022-03-25 01:58:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 01:58:20 --> Input Class Initialized
INFO - 2022-03-25 01:58:20 --> Language Class Initialized
INFO - 2022-03-25 01:58:20 --> Loader Class Initialized
INFO - 2022-03-25 01:58:20 --> Helper loaded: url_helper
INFO - 2022-03-25 01:58:20 --> Helper loaded: form_helper
INFO - 2022-03-25 01:58:20 --> Helper loaded: common_helper
INFO - 2022-03-25 01:58:20 --> Database Driver Class Initialized
DEBUG - 2022-03-25 01:58:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 01:58:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 01:58:20 --> Controller Class Initialized
INFO - 2022-03-25 01:58:20 --> Form Validation Class Initialized
DEBUG - 2022-03-25 01:58:20 --> Encrypt Class Initialized
INFO - 2022-03-25 01:58:20 --> Model "Patient_model" initialized
INFO - 2022-03-25 01:58:20 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 01:58:20 --> Model "Referredby_model" initialized
INFO - 2022-03-25 01:58:20 --> Model "Prefix_master" initialized
INFO - 2022-03-25 01:58:20 --> Model "Hospital_model" initialized
INFO - 2022-03-25 01:58:20 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-25 01:58:26 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-25 01:58:26 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
ERROR - 2022-03-25 01:58:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 01:58:26 --> Config Class Initialized
INFO - 2022-03-25 01:58:26 --> Hooks Class Initialized
DEBUG - 2022-03-25 01:58:26 --> UTF-8 Support Enabled
INFO - 2022-03-25 01:58:26 --> Utf8 Class Initialized
INFO - 2022-03-25 01:58:26 --> URI Class Initialized
INFO - 2022-03-25 01:58:26 --> Router Class Initialized
INFO - 2022-03-25 01:58:26 --> Output Class Initialized
INFO - 2022-03-25 01:58:26 --> Security Class Initialized
DEBUG - 2022-03-25 01:58:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 01:58:26 --> Input Class Initialized
INFO - 2022-03-25 01:58:26 --> Language Class Initialized
ERROR - 2022-03-25 01:58:26 --> 404 Page Not Found: Karoclient/usersprofile
INFO - 2022-03-25 01:58:27 --> Final output sent to browser
DEBUG - 2022-03-25 01:58:27 --> Total execution time: 6.0788
ERROR - 2022-03-25 01:59:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 01:59:35 --> Config Class Initialized
INFO - 2022-03-25 01:59:35 --> Hooks Class Initialized
DEBUG - 2022-03-25 01:59:35 --> UTF-8 Support Enabled
INFO - 2022-03-25 01:59:35 --> Utf8 Class Initialized
INFO - 2022-03-25 01:59:35 --> URI Class Initialized
INFO - 2022-03-25 01:59:35 --> Router Class Initialized
INFO - 2022-03-25 01:59:35 --> Output Class Initialized
INFO - 2022-03-25 01:59:35 --> Security Class Initialized
DEBUG - 2022-03-25 01:59:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 01:59:35 --> Input Class Initialized
INFO - 2022-03-25 01:59:35 --> Language Class Initialized
INFO - 2022-03-25 01:59:35 --> Loader Class Initialized
INFO - 2022-03-25 01:59:35 --> Helper loaded: url_helper
INFO - 2022-03-25 01:59:35 --> Helper loaded: form_helper
INFO - 2022-03-25 01:59:35 --> Helper loaded: common_helper
INFO - 2022-03-25 01:59:35 --> Database Driver Class Initialized
DEBUG - 2022-03-25 01:59:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 01:59:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 01:59:35 --> Controller Class Initialized
INFO - 2022-03-25 01:59:35 --> Form Validation Class Initialized
DEBUG - 2022-03-25 01:59:35 --> Encrypt Class Initialized
INFO - 2022-03-25 01:59:35 --> Model "Patient_model" initialized
INFO - 2022-03-25 01:59:35 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 01:59:35 --> Model "Referredby_model" initialized
INFO - 2022-03-25 01:59:35 --> Model "Prefix_master" initialized
INFO - 2022-03-25 01:59:35 --> Model "Hospital_model" initialized
INFO - 2022-03-25 01:59:35 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-25 01:59:35 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-25 01:59:35 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-25 01:59:35 --> Final output sent to browser
DEBUG - 2022-03-25 01:59:35 --> Total execution time: 0.1477
ERROR - 2022-03-25 01:59:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 01:59:35 --> Config Class Initialized
INFO - 2022-03-25 01:59:35 --> Hooks Class Initialized
DEBUG - 2022-03-25 01:59:35 --> UTF-8 Support Enabled
INFO - 2022-03-25 01:59:35 --> Utf8 Class Initialized
INFO - 2022-03-25 01:59:35 --> URI Class Initialized
INFO - 2022-03-25 01:59:35 --> Router Class Initialized
INFO - 2022-03-25 01:59:35 --> Output Class Initialized
INFO - 2022-03-25 01:59:35 --> Security Class Initialized
DEBUG - 2022-03-25 01:59:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 01:59:35 --> Input Class Initialized
INFO - 2022-03-25 01:59:35 --> Language Class Initialized
ERROR - 2022-03-25 01:59:35 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-25 02:00:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 02:00:22 --> Config Class Initialized
INFO - 2022-03-25 02:00:22 --> Hooks Class Initialized
DEBUG - 2022-03-25 02:00:22 --> UTF-8 Support Enabled
INFO - 2022-03-25 02:00:22 --> Utf8 Class Initialized
INFO - 2022-03-25 02:00:22 --> URI Class Initialized
INFO - 2022-03-25 02:00:22 --> Router Class Initialized
INFO - 2022-03-25 02:00:22 --> Output Class Initialized
INFO - 2022-03-25 02:00:22 --> Security Class Initialized
DEBUG - 2022-03-25 02:00:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 02:00:22 --> Input Class Initialized
INFO - 2022-03-25 02:00:22 --> Language Class Initialized
INFO - 2022-03-25 02:00:22 --> Loader Class Initialized
INFO - 2022-03-25 02:00:22 --> Helper loaded: url_helper
INFO - 2022-03-25 02:00:22 --> Helper loaded: form_helper
INFO - 2022-03-25 02:00:22 --> Helper loaded: common_helper
INFO - 2022-03-25 02:00:22 --> Database Driver Class Initialized
DEBUG - 2022-03-25 02:00:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 02:00:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 02:00:22 --> Controller Class Initialized
INFO - 2022-03-25 02:00:22 --> Form Validation Class Initialized
DEBUG - 2022-03-25 02:00:22 --> Encrypt Class Initialized
INFO - 2022-03-25 02:00:22 --> Model "Patient_model" initialized
INFO - 2022-03-25 02:00:22 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 02:00:22 --> Model "Referredby_model" initialized
INFO - 2022-03-25 02:00:22 --> Model "Prefix_master" initialized
INFO - 2022-03-25 02:00:22 --> Model "Hospital_model" initialized
ERROR - 2022-03-25 02:00:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 02:00:23 --> Config Class Initialized
INFO - 2022-03-25 02:00:23 --> Hooks Class Initialized
DEBUG - 2022-03-25 02:00:23 --> UTF-8 Support Enabled
INFO - 2022-03-25 02:00:23 --> Utf8 Class Initialized
INFO - 2022-03-25 02:00:23 --> URI Class Initialized
INFO - 2022-03-25 02:00:23 --> Router Class Initialized
INFO - 2022-03-25 02:00:23 --> Output Class Initialized
INFO - 2022-03-25 02:00:23 --> Security Class Initialized
DEBUG - 2022-03-25 02:00:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 02:00:23 --> Input Class Initialized
INFO - 2022-03-25 02:00:23 --> Language Class Initialized
INFO - 2022-03-25 02:00:23 --> Loader Class Initialized
INFO - 2022-03-25 02:00:23 --> Helper loaded: url_helper
INFO - 2022-03-25 02:00:23 --> Helper loaded: form_helper
INFO - 2022-03-25 02:00:23 --> Helper loaded: common_helper
INFO - 2022-03-25 02:00:23 --> Database Driver Class Initialized
DEBUG - 2022-03-25 02:00:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 02:00:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 02:00:23 --> Controller Class Initialized
INFO - 2022-03-25 02:00:23 --> Form Validation Class Initialized
DEBUG - 2022-03-25 02:00:23 --> Encrypt Class Initialized
INFO - 2022-03-25 02:00:23 --> Model "Patient_model" initialized
INFO - 2022-03-25 02:00:23 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 02:00:23 --> Model "Referredby_model" initialized
INFO - 2022-03-25 02:00:23 --> Model "Prefix_master" initialized
INFO - 2022-03-25 02:00:23 --> Model "Hospital_model" initialized
INFO - 2022-03-25 02:00:23 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-25 02:00:23 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-25 02:00:23 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-25 02:00:23 --> Final output sent to browser
DEBUG - 2022-03-25 02:00:23 --> Total execution time: 0.0273
ERROR - 2022-03-25 02:00:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 02:00:23 --> Config Class Initialized
INFO - 2022-03-25 02:00:23 --> Hooks Class Initialized
DEBUG - 2022-03-25 02:00:23 --> UTF-8 Support Enabled
INFO - 2022-03-25 02:00:23 --> Utf8 Class Initialized
INFO - 2022-03-25 02:00:23 --> URI Class Initialized
INFO - 2022-03-25 02:00:23 --> Router Class Initialized
INFO - 2022-03-25 02:00:23 --> Output Class Initialized
INFO - 2022-03-25 02:00:23 --> Security Class Initialized
DEBUG - 2022-03-25 02:00:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 02:00:23 --> Input Class Initialized
INFO - 2022-03-25 02:00:23 --> Language Class Initialized
ERROR - 2022-03-25 02:00:23 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-25 02:00:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 02:00:23 --> Config Class Initialized
INFO - 2022-03-25 02:00:23 --> Hooks Class Initialized
DEBUG - 2022-03-25 02:00:23 --> UTF-8 Support Enabled
INFO - 2022-03-25 02:00:23 --> Utf8 Class Initialized
INFO - 2022-03-25 02:00:23 --> URI Class Initialized
INFO - 2022-03-25 02:00:23 --> Router Class Initialized
INFO - 2022-03-25 02:00:23 --> Output Class Initialized
INFO - 2022-03-25 02:00:23 --> Security Class Initialized
DEBUG - 2022-03-25 02:00:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 02:00:23 --> Input Class Initialized
INFO - 2022-03-25 02:00:23 --> Language Class Initialized
INFO - 2022-03-25 02:00:23 --> Loader Class Initialized
INFO - 2022-03-25 02:00:23 --> Helper loaded: url_helper
INFO - 2022-03-25 02:00:23 --> Helper loaded: form_helper
INFO - 2022-03-25 02:00:23 --> Helper loaded: common_helper
INFO - 2022-03-25 02:00:23 --> Database Driver Class Initialized
DEBUG - 2022-03-25 02:00:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 02:00:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 02:00:23 --> Controller Class Initialized
INFO - 2022-03-25 02:00:23 --> Form Validation Class Initialized
DEBUG - 2022-03-25 02:00:23 --> Encrypt Class Initialized
INFO - 2022-03-25 02:00:23 --> Model "Patient_model" initialized
INFO - 2022-03-25 02:00:23 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 02:00:23 --> Model "Prefix_master" initialized
INFO - 2022-03-25 02:00:23 --> Model "Users_model" initialized
INFO - 2022-03-25 02:00:23 --> Model "Hospital_model" initialized
INFO - 2022-03-25 02:00:24 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-25 02:00:24 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-25 02:00:24 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-25 02:00:24 --> Final output sent to browser
DEBUG - 2022-03-25 02:00:24 --> Total execution time: 0.0485
ERROR - 2022-03-25 02:00:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 02:00:24 --> Config Class Initialized
INFO - 2022-03-25 02:00:24 --> Hooks Class Initialized
DEBUG - 2022-03-25 02:00:24 --> UTF-8 Support Enabled
INFO - 2022-03-25 02:00:24 --> Utf8 Class Initialized
INFO - 2022-03-25 02:00:24 --> URI Class Initialized
INFO - 2022-03-25 02:00:24 --> Router Class Initialized
INFO - 2022-03-25 02:00:24 --> Output Class Initialized
INFO - 2022-03-25 02:00:24 --> Security Class Initialized
DEBUG - 2022-03-25 02:00:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 02:00:24 --> Input Class Initialized
INFO - 2022-03-25 02:00:24 --> Language Class Initialized
ERROR - 2022-03-25 02:00:24 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-25 02:01:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 02:01:01 --> Config Class Initialized
INFO - 2022-03-25 02:01:01 --> Hooks Class Initialized
DEBUG - 2022-03-25 02:01:01 --> UTF-8 Support Enabled
INFO - 2022-03-25 02:01:01 --> Utf8 Class Initialized
INFO - 2022-03-25 02:01:01 --> URI Class Initialized
INFO - 2022-03-25 02:01:01 --> Router Class Initialized
INFO - 2022-03-25 02:01:01 --> Output Class Initialized
INFO - 2022-03-25 02:01:01 --> Security Class Initialized
DEBUG - 2022-03-25 02:01:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 02:01:01 --> Input Class Initialized
INFO - 2022-03-25 02:01:01 --> Language Class Initialized
INFO - 2022-03-25 02:01:01 --> Loader Class Initialized
INFO - 2022-03-25 02:01:01 --> Helper loaded: url_helper
INFO - 2022-03-25 02:01:01 --> Helper loaded: form_helper
INFO - 2022-03-25 02:01:01 --> Helper loaded: common_helper
INFO - 2022-03-25 02:01:01 --> Database Driver Class Initialized
DEBUG - 2022-03-25 02:01:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 02:01:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 02:01:01 --> Controller Class Initialized
ERROR - 2022-03-25 02:01:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 02:01:02 --> Config Class Initialized
INFO - 2022-03-25 02:01:02 --> Hooks Class Initialized
DEBUG - 2022-03-25 02:01:02 --> UTF-8 Support Enabled
INFO - 2022-03-25 02:01:02 --> Utf8 Class Initialized
INFO - 2022-03-25 02:01:02 --> URI Class Initialized
INFO - 2022-03-25 02:01:02 --> Router Class Initialized
INFO - 2022-03-25 02:01:02 --> Output Class Initialized
INFO - 2022-03-25 02:01:02 --> Security Class Initialized
DEBUG - 2022-03-25 02:01:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 02:01:02 --> Input Class Initialized
INFO - 2022-03-25 02:01:02 --> Language Class Initialized
INFO - 2022-03-25 02:01:02 --> Loader Class Initialized
INFO - 2022-03-25 02:01:02 --> Helper loaded: url_helper
INFO - 2022-03-25 02:01:02 --> Helper loaded: form_helper
INFO - 2022-03-25 02:01:02 --> Helper loaded: common_helper
INFO - 2022-03-25 02:01:02 --> Database Driver Class Initialized
DEBUG - 2022-03-25 02:01:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 02:01:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 02:01:02 --> Controller Class Initialized
INFO - 2022-03-25 02:01:02 --> Form Validation Class Initialized
DEBUG - 2022-03-25 02:01:02 --> Encrypt Class Initialized
DEBUG - 2022-03-25 02:01:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 02:01:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-25 02:01:02 --> Email Class Initialized
INFO - 2022-03-25 02:01:02 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-25 02:01:02 --> Calendar Class Initialized
INFO - 2022-03-25 02:01:02 --> Model "Login_model" initialized
INFO - 2022-03-25 02:01:02 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-25 02:01:02 --> Final output sent to browser
DEBUG - 2022-03-25 02:01:02 --> Total execution time: 0.3996
ERROR - 2022-03-25 02:01:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 02:01:14 --> Config Class Initialized
INFO - 2022-03-25 02:01:14 --> Hooks Class Initialized
DEBUG - 2022-03-25 02:01:14 --> UTF-8 Support Enabled
INFO - 2022-03-25 02:01:14 --> Utf8 Class Initialized
INFO - 2022-03-25 02:01:14 --> URI Class Initialized
INFO - 2022-03-25 02:01:14 --> Router Class Initialized
INFO - 2022-03-25 02:01:14 --> Output Class Initialized
INFO - 2022-03-25 02:01:14 --> Security Class Initialized
DEBUG - 2022-03-25 02:01:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 02:01:14 --> Input Class Initialized
INFO - 2022-03-25 02:01:14 --> Language Class Initialized
INFO - 2022-03-25 02:01:14 --> Loader Class Initialized
INFO - 2022-03-25 02:01:14 --> Helper loaded: url_helper
INFO - 2022-03-25 02:01:14 --> Helper loaded: form_helper
INFO - 2022-03-25 02:01:14 --> Helper loaded: common_helper
INFO - 2022-03-25 02:01:14 --> Database Driver Class Initialized
DEBUG - 2022-03-25 02:01:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 02:01:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 02:01:14 --> Controller Class Initialized
INFO - 2022-03-25 02:01:14 --> Form Validation Class Initialized
DEBUG - 2022-03-25 02:01:14 --> Encrypt Class Initialized
DEBUG - 2022-03-25 02:01:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 02:01:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-25 02:01:14 --> Email Class Initialized
INFO - 2022-03-25 02:01:14 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-25 02:01:14 --> Calendar Class Initialized
INFO - 2022-03-25 02:01:14 --> Model "Login_model" initialized
INFO - 2022-03-25 02:01:14 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-03-25 02:01:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 02:01:14 --> Config Class Initialized
INFO - 2022-03-25 02:01:14 --> Hooks Class Initialized
DEBUG - 2022-03-25 02:01:14 --> UTF-8 Support Enabled
INFO - 2022-03-25 02:01:14 --> Utf8 Class Initialized
INFO - 2022-03-25 02:01:14 --> URI Class Initialized
INFO - 2022-03-25 02:01:14 --> Router Class Initialized
INFO - 2022-03-25 02:01:14 --> Output Class Initialized
INFO - 2022-03-25 02:01:14 --> Security Class Initialized
DEBUG - 2022-03-25 02:01:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 02:01:14 --> Input Class Initialized
INFO - 2022-03-25 02:01:14 --> Language Class Initialized
INFO - 2022-03-25 02:01:14 --> Loader Class Initialized
INFO - 2022-03-25 02:01:14 --> Helper loaded: url_helper
INFO - 2022-03-25 02:01:14 --> Helper loaded: form_helper
INFO - 2022-03-25 02:01:14 --> Helper loaded: common_helper
INFO - 2022-03-25 02:01:14 --> Database Driver Class Initialized
DEBUG - 2022-03-25 02:01:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 02:01:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 02:01:14 --> Controller Class Initialized
INFO - 2022-03-25 02:01:14 --> Form Validation Class Initialized
DEBUG - 2022-03-25 02:01:14 --> Encrypt Class Initialized
INFO - 2022-03-25 02:01:14 --> Model "Login_model" initialized
INFO - 2022-03-25 02:01:14 --> Model "Dashboard_model" initialized
INFO - 2022-03-25 02:01:14 --> Model "Case_model" initialized
INFO - 2022-03-25 02:01:14 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-25 02:01:14 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2022-03-25 02:01:14 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-25 02:01:14 --> Final output sent to browser
DEBUG - 2022-03-25 02:01:14 --> Total execution time: 0.3071
ERROR - 2022-03-25 02:01:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 02:01:21 --> Config Class Initialized
INFO - 2022-03-25 02:01:21 --> Hooks Class Initialized
DEBUG - 2022-03-25 02:01:21 --> UTF-8 Support Enabled
INFO - 2022-03-25 02:01:21 --> Utf8 Class Initialized
INFO - 2022-03-25 02:01:21 --> URI Class Initialized
INFO - 2022-03-25 02:01:21 --> Router Class Initialized
INFO - 2022-03-25 02:01:21 --> Output Class Initialized
INFO - 2022-03-25 02:01:21 --> Security Class Initialized
DEBUG - 2022-03-25 02:01:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 02:01:21 --> Input Class Initialized
INFO - 2022-03-25 02:01:21 --> Language Class Initialized
INFO - 2022-03-25 02:01:21 --> Loader Class Initialized
INFO - 2022-03-25 02:01:21 --> Helper loaded: url_helper
INFO - 2022-03-25 02:01:21 --> Helper loaded: form_helper
INFO - 2022-03-25 02:01:21 --> Helper loaded: common_helper
INFO - 2022-03-25 02:01:21 --> Database Driver Class Initialized
DEBUG - 2022-03-25 02:01:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 02:01:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 02:01:21 --> Controller Class Initialized
INFO - 2022-03-25 02:01:21 --> Form Validation Class Initialized
DEBUG - 2022-03-25 02:01:21 --> Encrypt Class Initialized
INFO - 2022-03-25 02:01:21 --> Model "Patient_model" initialized
INFO - 2022-03-25 02:01:21 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 02:01:21 --> Model "Referredby_model" initialized
INFO - 2022-03-25 02:01:21 --> Model "Prefix_master" initialized
INFO - 2022-03-25 02:01:21 --> Model "Hospital_model" initialized
INFO - 2022-03-25 02:01:21 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-25 02:01:21 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-25 02:01:21 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-25 02:01:21 --> Final output sent to browser
DEBUG - 2022-03-25 02:01:21 --> Total execution time: 0.1536
ERROR - 2022-03-25 02:01:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 02:01:24 --> Config Class Initialized
INFO - 2022-03-25 02:01:24 --> Hooks Class Initialized
DEBUG - 2022-03-25 02:01:24 --> UTF-8 Support Enabled
INFO - 2022-03-25 02:01:24 --> Utf8 Class Initialized
INFO - 2022-03-25 02:01:24 --> URI Class Initialized
INFO - 2022-03-25 02:01:24 --> Router Class Initialized
INFO - 2022-03-25 02:01:24 --> Output Class Initialized
INFO - 2022-03-25 02:01:24 --> Security Class Initialized
DEBUG - 2022-03-25 02:01:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 02:01:24 --> Input Class Initialized
INFO - 2022-03-25 02:01:24 --> Language Class Initialized
INFO - 2022-03-25 02:01:24 --> Loader Class Initialized
INFO - 2022-03-25 02:01:24 --> Helper loaded: url_helper
INFO - 2022-03-25 02:01:24 --> Helper loaded: form_helper
INFO - 2022-03-25 02:01:24 --> Helper loaded: common_helper
INFO - 2022-03-25 02:01:24 --> Database Driver Class Initialized
DEBUG - 2022-03-25 02:01:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 02:01:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 02:01:24 --> Controller Class Initialized
INFO - 2022-03-25 02:01:24 --> Form Validation Class Initialized
DEBUG - 2022-03-25 02:01:24 --> Encrypt Class Initialized
INFO - 2022-03-25 02:01:24 --> Model "Patient_model" initialized
INFO - 2022-03-25 02:01:24 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 02:01:24 --> Model "Referredby_model" initialized
INFO - 2022-03-25 02:01:24 --> Model "Prefix_master" initialized
INFO - 2022-03-25 02:01:24 --> Model "Hospital_model" initialized
INFO - 2022-03-25 02:01:24 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-25 02:01:24 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-25 02:01:24 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-25 02:01:24 --> Final output sent to browser
DEBUG - 2022-03-25 02:01:24 --> Total execution time: 0.0678
ERROR - 2022-03-25 02:01:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 02:01:53 --> Config Class Initialized
INFO - 2022-03-25 02:01:53 --> Hooks Class Initialized
DEBUG - 2022-03-25 02:01:53 --> UTF-8 Support Enabled
INFO - 2022-03-25 02:01:53 --> Utf8 Class Initialized
INFO - 2022-03-25 02:01:53 --> URI Class Initialized
INFO - 2022-03-25 02:01:53 --> Router Class Initialized
INFO - 2022-03-25 02:01:53 --> Output Class Initialized
INFO - 2022-03-25 02:01:53 --> Security Class Initialized
DEBUG - 2022-03-25 02:01:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 02:01:53 --> Input Class Initialized
INFO - 2022-03-25 02:01:53 --> Language Class Initialized
INFO - 2022-03-25 02:01:53 --> Loader Class Initialized
INFO - 2022-03-25 02:01:53 --> Helper loaded: url_helper
INFO - 2022-03-25 02:01:53 --> Helper loaded: form_helper
INFO - 2022-03-25 02:01:53 --> Helper loaded: common_helper
INFO - 2022-03-25 02:01:53 --> Database Driver Class Initialized
DEBUG - 2022-03-25 02:01:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 02:01:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 02:01:53 --> Controller Class Initialized
INFO - 2022-03-25 02:01:53 --> Form Validation Class Initialized
DEBUG - 2022-03-25 02:01:53 --> Encrypt Class Initialized
INFO - 2022-03-25 02:01:53 --> Model "Patient_model" initialized
INFO - 2022-03-25 02:01:53 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 02:01:53 --> Model "Prefix_master" initialized
INFO - 2022-03-25 02:01:53 --> Model "Users_model" initialized
INFO - 2022-03-25 02:01:53 --> Model "Hospital_model" initialized
INFO - 2022-03-25 02:01:53 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-25 02:01:54 --> Final output sent to browser
DEBUG - 2022-03-25 02:01:54 --> Total execution time: 1.2594
ERROR - 2022-03-25 02:06:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 02:06:21 --> Config Class Initialized
INFO - 2022-03-25 02:06:21 --> Hooks Class Initialized
DEBUG - 2022-03-25 02:06:21 --> UTF-8 Support Enabled
INFO - 2022-03-25 02:06:21 --> Utf8 Class Initialized
INFO - 2022-03-25 02:06:21 --> URI Class Initialized
INFO - 2022-03-25 02:06:21 --> Router Class Initialized
INFO - 2022-03-25 02:06:21 --> Output Class Initialized
INFO - 2022-03-25 02:06:21 --> Security Class Initialized
DEBUG - 2022-03-25 02:06:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 02:06:21 --> Input Class Initialized
INFO - 2022-03-25 02:06:21 --> Language Class Initialized
INFO - 2022-03-25 02:06:21 --> Loader Class Initialized
INFO - 2022-03-25 02:06:21 --> Helper loaded: url_helper
INFO - 2022-03-25 02:06:21 --> Helper loaded: form_helper
INFO - 2022-03-25 02:06:21 --> Helper loaded: common_helper
INFO - 2022-03-25 02:06:21 --> Database Driver Class Initialized
DEBUG - 2022-03-25 02:06:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 02:06:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 02:06:21 --> Controller Class Initialized
INFO - 2022-03-25 02:06:21 --> Form Validation Class Initialized
DEBUG - 2022-03-25 02:06:21 --> Encrypt Class Initialized
INFO - 2022-03-25 02:06:21 --> Model "Patient_model" initialized
INFO - 2022-03-25 02:06:21 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 02:06:21 --> Model "Referredby_model" initialized
INFO - 2022-03-25 02:06:21 --> Model "Prefix_master" initialized
INFO - 2022-03-25 02:06:21 --> Model "Hospital_model" initialized
INFO - 2022-03-25 02:06:21 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-25 02:06:21 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-25 02:06:21 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-25 02:06:21 --> Final output sent to browser
DEBUG - 2022-03-25 02:06:21 --> Total execution time: 0.0743
ERROR - 2022-03-25 02:06:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 02:06:34 --> Config Class Initialized
INFO - 2022-03-25 02:06:34 --> Hooks Class Initialized
DEBUG - 2022-03-25 02:06:34 --> UTF-8 Support Enabled
INFO - 2022-03-25 02:06:34 --> Utf8 Class Initialized
INFO - 2022-03-25 02:06:34 --> URI Class Initialized
INFO - 2022-03-25 02:06:34 --> Router Class Initialized
INFO - 2022-03-25 02:06:34 --> Output Class Initialized
INFO - 2022-03-25 02:06:34 --> Security Class Initialized
DEBUG - 2022-03-25 02:06:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 02:06:34 --> Input Class Initialized
INFO - 2022-03-25 02:06:34 --> Language Class Initialized
INFO - 2022-03-25 02:06:34 --> Loader Class Initialized
INFO - 2022-03-25 02:06:34 --> Helper loaded: url_helper
INFO - 2022-03-25 02:06:34 --> Helper loaded: form_helper
INFO - 2022-03-25 02:06:34 --> Helper loaded: common_helper
INFO - 2022-03-25 02:06:34 --> Database Driver Class Initialized
DEBUG - 2022-03-25 02:06:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 02:06:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 02:06:34 --> Controller Class Initialized
INFO - 2022-03-25 02:06:34 --> Form Validation Class Initialized
DEBUG - 2022-03-25 02:06:34 --> Encrypt Class Initialized
INFO - 2022-03-25 02:06:34 --> Model "Patient_model" initialized
INFO - 2022-03-25 02:06:34 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 02:06:34 --> Model "Prefix_master" initialized
INFO - 2022-03-25 02:06:34 --> Model "Users_model" initialized
INFO - 2022-03-25 02:06:34 --> Model "Hospital_model" initialized
ERROR - 2022-03-25 02:06:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 02:06:35 --> Config Class Initialized
INFO - 2022-03-25 02:06:35 --> Hooks Class Initialized
DEBUG - 2022-03-25 02:06:35 --> UTF-8 Support Enabled
INFO - 2022-03-25 02:06:35 --> Utf8 Class Initialized
INFO - 2022-03-25 02:06:35 --> URI Class Initialized
INFO - 2022-03-25 02:06:35 --> Router Class Initialized
INFO - 2022-03-25 02:06:35 --> Output Class Initialized
INFO - 2022-03-25 02:06:35 --> Security Class Initialized
DEBUG - 2022-03-25 02:06:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 02:06:35 --> Input Class Initialized
INFO - 2022-03-25 02:06:35 --> Language Class Initialized
INFO - 2022-03-25 02:06:35 --> Loader Class Initialized
INFO - 2022-03-25 02:06:35 --> Helper loaded: url_helper
INFO - 2022-03-25 02:06:35 --> Helper loaded: form_helper
INFO - 2022-03-25 02:06:35 --> Helper loaded: common_helper
INFO - 2022-03-25 02:06:35 --> Database Driver Class Initialized
DEBUG - 2022-03-25 02:06:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 02:06:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 02:06:35 --> Controller Class Initialized
INFO - 2022-03-25 02:06:35 --> Form Validation Class Initialized
DEBUG - 2022-03-25 02:06:35 --> Encrypt Class Initialized
INFO - 2022-03-25 02:06:35 --> Model "Patient_model" initialized
INFO - 2022-03-25 02:06:35 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 02:06:35 --> Model "Prefix_master" initialized
INFO - 2022-03-25 02:06:35 --> Model "Users_model" initialized
INFO - 2022-03-25 02:06:35 --> Model "Hospital_model" initialized
INFO - 2022-03-25 02:06:35 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-25 02:06:35 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-25 02:06:35 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-25 02:06:35 --> Final output sent to browser
DEBUG - 2022-03-25 02:06:35 --> Total execution time: 0.0705
ERROR - 2022-03-25 02:06:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 02:06:35 --> Config Class Initialized
INFO - 2022-03-25 02:06:35 --> Hooks Class Initialized
DEBUG - 2022-03-25 02:06:35 --> UTF-8 Support Enabled
INFO - 2022-03-25 02:06:35 --> Utf8 Class Initialized
INFO - 2022-03-25 02:06:35 --> URI Class Initialized
INFO - 2022-03-25 02:06:35 --> Router Class Initialized
INFO - 2022-03-25 02:06:35 --> Output Class Initialized
INFO - 2022-03-25 02:06:35 --> Security Class Initialized
DEBUG - 2022-03-25 02:06:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 02:06:35 --> Input Class Initialized
INFO - 2022-03-25 02:06:35 --> Language Class Initialized
ERROR - 2022-03-25 02:06:35 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-25 02:06:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 02:06:37 --> Config Class Initialized
INFO - 2022-03-25 02:06:37 --> Hooks Class Initialized
DEBUG - 2022-03-25 02:06:37 --> UTF-8 Support Enabled
INFO - 2022-03-25 02:06:37 --> Utf8 Class Initialized
INFO - 2022-03-25 02:06:37 --> URI Class Initialized
INFO - 2022-03-25 02:06:37 --> Router Class Initialized
INFO - 2022-03-25 02:06:37 --> Output Class Initialized
INFO - 2022-03-25 02:06:37 --> Security Class Initialized
DEBUG - 2022-03-25 02:06:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 02:06:37 --> Input Class Initialized
INFO - 2022-03-25 02:06:37 --> Language Class Initialized
INFO - 2022-03-25 02:06:37 --> Loader Class Initialized
INFO - 2022-03-25 02:06:37 --> Helper loaded: url_helper
INFO - 2022-03-25 02:06:37 --> Helper loaded: form_helper
INFO - 2022-03-25 02:06:37 --> Helper loaded: common_helper
INFO - 2022-03-25 02:06:37 --> Database Driver Class Initialized
DEBUG - 2022-03-25 02:06:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 02:06:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 02:06:37 --> Controller Class Initialized
INFO - 2022-03-25 02:06:37 --> Form Validation Class Initialized
DEBUG - 2022-03-25 02:06:37 --> Encrypt Class Initialized
INFO - 2022-03-25 02:06:37 --> Model "Patient_model" initialized
INFO - 2022-03-25 02:06:37 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 02:06:37 --> Model "Referredby_model" initialized
INFO - 2022-03-25 02:06:37 --> Model "Prefix_master" initialized
INFO - 2022-03-25 02:06:37 --> Model "Hospital_model" initialized
INFO - 2022-03-25 02:06:37 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-25 02:06:37 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-25 02:06:37 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-25 02:06:37 --> Final output sent to browser
DEBUG - 2022-03-25 02:06:37 --> Total execution time: 0.0348
ERROR - 2022-03-25 02:06:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 02:06:38 --> Config Class Initialized
INFO - 2022-03-25 02:06:38 --> Hooks Class Initialized
DEBUG - 2022-03-25 02:06:38 --> UTF-8 Support Enabled
INFO - 2022-03-25 02:06:38 --> Utf8 Class Initialized
INFO - 2022-03-25 02:06:38 --> URI Class Initialized
INFO - 2022-03-25 02:06:38 --> Router Class Initialized
INFO - 2022-03-25 02:06:38 --> Output Class Initialized
INFO - 2022-03-25 02:06:38 --> Security Class Initialized
DEBUG - 2022-03-25 02:06:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 02:06:38 --> Input Class Initialized
INFO - 2022-03-25 02:06:38 --> Language Class Initialized
ERROR - 2022-03-25 02:06:38 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-25 02:06:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 02:06:41 --> Config Class Initialized
INFO - 2022-03-25 02:06:41 --> Hooks Class Initialized
DEBUG - 2022-03-25 02:06:41 --> UTF-8 Support Enabled
INFO - 2022-03-25 02:06:41 --> Utf8 Class Initialized
INFO - 2022-03-25 02:06:41 --> URI Class Initialized
INFO - 2022-03-25 02:06:41 --> Router Class Initialized
INFO - 2022-03-25 02:06:41 --> Output Class Initialized
INFO - 2022-03-25 02:06:41 --> Security Class Initialized
DEBUG - 2022-03-25 02:06:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 02:06:41 --> Input Class Initialized
INFO - 2022-03-25 02:06:41 --> Language Class Initialized
INFO - 2022-03-25 02:06:41 --> Loader Class Initialized
INFO - 2022-03-25 02:06:41 --> Helper loaded: url_helper
INFO - 2022-03-25 02:06:41 --> Helper loaded: form_helper
INFO - 2022-03-25 02:06:41 --> Helper loaded: common_helper
INFO - 2022-03-25 02:06:41 --> Database Driver Class Initialized
DEBUG - 2022-03-25 02:06:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 02:06:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 02:06:41 --> Controller Class Initialized
INFO - 2022-03-25 02:06:41 --> Form Validation Class Initialized
DEBUG - 2022-03-25 02:06:41 --> Encrypt Class Initialized
INFO - 2022-03-25 02:06:41 --> Model "Patient_model" initialized
INFO - 2022-03-25 02:06:41 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 02:06:41 --> Model "Referredby_model" initialized
INFO - 2022-03-25 02:06:41 --> Model "Prefix_master" initialized
INFO - 2022-03-25 02:06:41 --> Model "Hospital_model" initialized
INFO - 2022-03-25 02:06:41 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-25 02:06:49 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-25 02:06:49 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
ERROR - 2022-03-25 02:06:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 02:06:49 --> Config Class Initialized
INFO - 2022-03-25 02:06:49 --> Hooks Class Initialized
DEBUG - 2022-03-25 02:06:49 --> UTF-8 Support Enabled
INFO - 2022-03-25 02:06:49 --> Utf8 Class Initialized
INFO - 2022-03-25 02:06:49 --> URI Class Initialized
INFO - 2022-03-25 02:06:49 --> Router Class Initialized
INFO - 2022-03-25 02:06:49 --> Output Class Initialized
INFO - 2022-03-25 02:06:49 --> Security Class Initialized
DEBUG - 2022-03-25 02:06:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 02:06:49 --> Input Class Initialized
INFO - 2022-03-25 02:06:49 --> Language Class Initialized
ERROR - 2022-03-25 02:06:49 --> 404 Page Not Found: Karoclient/usersprofile
INFO - 2022-03-25 02:06:50 --> Final output sent to browser
DEBUG - 2022-03-25 02:06:50 --> Total execution time: 7.9864
ERROR - 2022-03-25 02:07:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 02:07:13 --> Config Class Initialized
INFO - 2022-03-25 02:07:13 --> Hooks Class Initialized
DEBUG - 2022-03-25 02:07:13 --> UTF-8 Support Enabled
INFO - 2022-03-25 02:07:13 --> Utf8 Class Initialized
INFO - 2022-03-25 02:07:13 --> URI Class Initialized
INFO - 2022-03-25 02:07:13 --> Router Class Initialized
INFO - 2022-03-25 02:07:13 --> Output Class Initialized
INFO - 2022-03-25 02:07:13 --> Security Class Initialized
DEBUG - 2022-03-25 02:07:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 02:07:13 --> Input Class Initialized
INFO - 2022-03-25 02:07:13 --> Language Class Initialized
INFO - 2022-03-25 02:07:13 --> Loader Class Initialized
INFO - 2022-03-25 02:07:13 --> Helper loaded: url_helper
INFO - 2022-03-25 02:07:13 --> Helper loaded: form_helper
INFO - 2022-03-25 02:07:13 --> Helper loaded: common_helper
INFO - 2022-03-25 02:07:13 --> Database Driver Class Initialized
DEBUG - 2022-03-25 02:07:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 02:07:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 02:07:13 --> Controller Class Initialized
INFO - 2022-03-25 02:07:13 --> Form Validation Class Initialized
DEBUG - 2022-03-25 02:07:13 --> Encrypt Class Initialized
INFO - 2022-03-25 02:07:13 --> Model "Patient_model" initialized
INFO - 2022-03-25 02:07:13 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 02:07:13 --> Model "Prefix_master" initialized
INFO - 2022-03-25 02:07:13 --> Model "Users_model" initialized
INFO - 2022-03-25 02:07:13 --> Model "Hospital_model" initialized
INFO - 2022-03-25 02:07:13 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-25 02:07:14 --> Final output sent to browser
DEBUG - 2022-03-25 02:07:14 --> Total execution time: 1.1969
ERROR - 2022-03-25 02:10:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 02:10:07 --> Config Class Initialized
INFO - 2022-03-25 02:10:07 --> Hooks Class Initialized
DEBUG - 2022-03-25 02:10:07 --> UTF-8 Support Enabled
INFO - 2022-03-25 02:10:07 --> Utf8 Class Initialized
INFO - 2022-03-25 02:10:07 --> URI Class Initialized
INFO - 2022-03-25 02:10:07 --> Router Class Initialized
INFO - 2022-03-25 02:10:07 --> Output Class Initialized
INFO - 2022-03-25 02:10:07 --> Security Class Initialized
DEBUG - 2022-03-25 02:10:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 02:10:07 --> Input Class Initialized
INFO - 2022-03-25 02:10:07 --> Language Class Initialized
INFO - 2022-03-25 02:10:07 --> Loader Class Initialized
INFO - 2022-03-25 02:10:07 --> Helper loaded: url_helper
INFO - 2022-03-25 02:10:07 --> Helper loaded: form_helper
INFO - 2022-03-25 02:10:07 --> Helper loaded: common_helper
INFO - 2022-03-25 02:10:07 --> Database Driver Class Initialized
DEBUG - 2022-03-25 02:10:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 02:10:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 02:10:07 --> Controller Class Initialized
INFO - 2022-03-25 02:10:07 --> Model "Referredby_model" initialized
INFO - 2022-03-25 02:10:07 --> Final output sent to browser
DEBUG - 2022-03-25 02:10:07 --> Total execution time: 0.0438
ERROR - 2022-03-25 02:10:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 02:10:41 --> Config Class Initialized
INFO - 2022-03-25 02:10:41 --> Hooks Class Initialized
DEBUG - 2022-03-25 02:10:41 --> UTF-8 Support Enabled
INFO - 2022-03-25 02:10:41 --> Utf8 Class Initialized
INFO - 2022-03-25 02:10:41 --> URI Class Initialized
INFO - 2022-03-25 02:10:41 --> Router Class Initialized
INFO - 2022-03-25 02:10:41 --> Output Class Initialized
INFO - 2022-03-25 02:10:41 --> Security Class Initialized
DEBUG - 2022-03-25 02:10:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 02:10:41 --> Input Class Initialized
INFO - 2022-03-25 02:10:41 --> Language Class Initialized
INFO - 2022-03-25 02:10:41 --> Loader Class Initialized
INFO - 2022-03-25 02:10:41 --> Helper loaded: url_helper
INFO - 2022-03-25 02:10:41 --> Helper loaded: form_helper
INFO - 2022-03-25 02:10:41 --> Helper loaded: common_helper
INFO - 2022-03-25 02:10:41 --> Database Driver Class Initialized
DEBUG - 2022-03-25 02:10:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 02:10:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 02:10:41 --> Controller Class Initialized
INFO - 2022-03-25 02:10:41 --> Form Validation Class Initialized
DEBUG - 2022-03-25 02:10:41 --> Encrypt Class Initialized
INFO - 2022-03-25 02:10:41 --> Model "Patient_model" initialized
INFO - 2022-03-25 02:10:41 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 02:10:41 --> Model "Referredby_model" initialized
INFO - 2022-03-25 02:10:41 --> Model "Prefix_master" initialized
INFO - 2022-03-25 02:10:41 --> Model "Hospital_model" initialized
INFO - 2022-03-25 02:10:41 --> Final output sent to browser
DEBUG - 2022-03-25 02:10:41 --> Total execution time: 0.0361
ERROR - 2022-03-25 02:10:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 02:10:54 --> Config Class Initialized
INFO - 2022-03-25 02:10:54 --> Hooks Class Initialized
DEBUG - 2022-03-25 02:10:54 --> UTF-8 Support Enabled
INFO - 2022-03-25 02:10:54 --> Utf8 Class Initialized
INFO - 2022-03-25 02:10:54 --> URI Class Initialized
INFO - 2022-03-25 02:10:54 --> Router Class Initialized
INFO - 2022-03-25 02:10:54 --> Output Class Initialized
INFO - 2022-03-25 02:10:54 --> Security Class Initialized
DEBUG - 2022-03-25 02:10:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 02:10:54 --> Input Class Initialized
INFO - 2022-03-25 02:10:54 --> Language Class Initialized
INFO - 2022-03-25 02:10:54 --> Loader Class Initialized
INFO - 2022-03-25 02:10:54 --> Helper loaded: url_helper
INFO - 2022-03-25 02:10:54 --> Helper loaded: form_helper
INFO - 2022-03-25 02:10:54 --> Helper loaded: common_helper
INFO - 2022-03-25 02:10:54 --> Database Driver Class Initialized
DEBUG - 2022-03-25 02:10:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 02:10:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 02:10:54 --> Controller Class Initialized
INFO - 2022-03-25 02:10:54 --> Form Validation Class Initialized
DEBUG - 2022-03-25 02:10:54 --> Encrypt Class Initialized
INFO - 2022-03-25 02:10:54 --> Model "Patient_model" initialized
INFO - 2022-03-25 02:10:54 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 02:10:54 --> Model "Referredby_model" initialized
INFO - 2022-03-25 02:10:54 --> Model "Prefix_master" initialized
INFO - 2022-03-25 02:10:54 --> Model "Hospital_model" initialized
INFO - 2022-03-25 02:10:54 --> Final output sent to browser
DEBUG - 2022-03-25 02:10:54 --> Total execution time: 0.0156
ERROR - 2022-03-25 02:12:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 02:12:03 --> Config Class Initialized
INFO - 2022-03-25 02:12:03 --> Hooks Class Initialized
DEBUG - 2022-03-25 02:12:03 --> UTF-8 Support Enabled
INFO - 2022-03-25 02:12:03 --> Utf8 Class Initialized
INFO - 2022-03-25 02:12:03 --> URI Class Initialized
INFO - 2022-03-25 02:12:03 --> Router Class Initialized
INFO - 2022-03-25 02:12:03 --> Output Class Initialized
INFO - 2022-03-25 02:12:03 --> Security Class Initialized
DEBUG - 2022-03-25 02:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 02:12:03 --> Input Class Initialized
INFO - 2022-03-25 02:12:03 --> Language Class Initialized
INFO - 2022-03-25 02:12:03 --> Loader Class Initialized
INFO - 2022-03-25 02:12:03 --> Helper loaded: url_helper
INFO - 2022-03-25 02:12:03 --> Helper loaded: form_helper
INFO - 2022-03-25 02:12:03 --> Helper loaded: common_helper
INFO - 2022-03-25 02:12:03 --> Database Driver Class Initialized
DEBUG - 2022-03-25 02:12:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 02:12:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 02:12:03 --> Controller Class Initialized
INFO - 2022-03-25 02:12:03 --> Form Validation Class Initialized
DEBUG - 2022-03-25 02:12:03 --> Encrypt Class Initialized
INFO - 2022-03-25 02:12:03 --> Model "Patient_model" initialized
INFO - 2022-03-25 02:12:03 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 02:12:03 --> Model "Prefix_master" initialized
INFO - 2022-03-25 02:12:03 --> Model "Users_model" initialized
INFO - 2022-03-25 02:12:03 --> Model "Hospital_model" initialized
INFO - 2022-03-25 02:12:03 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-25 02:12:04 --> Final output sent to browser
DEBUG - 2022-03-25 02:12:04 --> Total execution time: 1.0238
ERROR - 2022-03-25 02:15:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 02:15:21 --> Config Class Initialized
INFO - 2022-03-25 02:15:21 --> Hooks Class Initialized
DEBUG - 2022-03-25 02:15:21 --> UTF-8 Support Enabled
INFO - 2022-03-25 02:15:21 --> Utf8 Class Initialized
INFO - 2022-03-25 02:15:21 --> URI Class Initialized
INFO - 2022-03-25 02:15:21 --> Router Class Initialized
INFO - 2022-03-25 02:15:21 --> Output Class Initialized
INFO - 2022-03-25 02:15:21 --> Security Class Initialized
DEBUG - 2022-03-25 02:15:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 02:15:21 --> Input Class Initialized
INFO - 2022-03-25 02:15:21 --> Language Class Initialized
INFO - 2022-03-25 02:15:21 --> Loader Class Initialized
INFO - 2022-03-25 02:15:21 --> Helper loaded: url_helper
INFO - 2022-03-25 02:15:21 --> Helper loaded: form_helper
INFO - 2022-03-25 02:15:21 --> Helper loaded: common_helper
INFO - 2022-03-25 02:15:21 --> Database Driver Class Initialized
DEBUG - 2022-03-25 02:15:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 02:15:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 02:15:21 --> Controller Class Initialized
INFO - 2022-03-25 02:15:21 --> Model "Referredby_model" initialized
INFO - 2022-03-25 02:15:21 --> Final output sent to browser
DEBUG - 2022-03-25 02:15:21 --> Total execution time: 0.0518
ERROR - 2022-03-25 02:19:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 02:19:24 --> Config Class Initialized
INFO - 2022-03-25 02:19:24 --> Hooks Class Initialized
DEBUG - 2022-03-25 02:19:24 --> UTF-8 Support Enabled
INFO - 2022-03-25 02:19:24 --> Utf8 Class Initialized
INFO - 2022-03-25 02:19:24 --> URI Class Initialized
INFO - 2022-03-25 02:19:24 --> Router Class Initialized
INFO - 2022-03-25 02:19:24 --> Output Class Initialized
INFO - 2022-03-25 02:19:24 --> Security Class Initialized
DEBUG - 2022-03-25 02:19:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 02:19:24 --> Input Class Initialized
INFO - 2022-03-25 02:19:24 --> Language Class Initialized
INFO - 2022-03-25 02:19:24 --> Loader Class Initialized
INFO - 2022-03-25 02:19:24 --> Helper loaded: url_helper
INFO - 2022-03-25 02:19:24 --> Helper loaded: form_helper
INFO - 2022-03-25 02:19:24 --> Helper loaded: common_helper
INFO - 2022-03-25 02:19:24 --> Database Driver Class Initialized
DEBUG - 2022-03-25 02:19:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 02:19:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 02:19:24 --> Controller Class Initialized
INFO - 2022-03-25 02:19:24 --> Form Validation Class Initialized
DEBUG - 2022-03-25 02:19:24 --> Encrypt Class Initialized
INFO - 2022-03-25 02:19:24 --> Model "Patient_model" initialized
INFO - 2022-03-25 02:19:24 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 02:19:24 --> Model "Referredby_model" initialized
INFO - 2022-03-25 02:19:24 --> Model "Prefix_master" initialized
INFO - 2022-03-25 02:19:24 --> Model "Hospital_model" initialized
ERROR - 2022-03-25 02:19:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 02:19:25 --> Config Class Initialized
INFO - 2022-03-25 02:19:25 --> Hooks Class Initialized
DEBUG - 2022-03-25 02:19:25 --> UTF-8 Support Enabled
INFO - 2022-03-25 02:19:25 --> Utf8 Class Initialized
INFO - 2022-03-25 02:19:25 --> URI Class Initialized
INFO - 2022-03-25 02:19:25 --> Router Class Initialized
INFO - 2022-03-25 02:19:25 --> Output Class Initialized
INFO - 2022-03-25 02:19:25 --> Security Class Initialized
DEBUG - 2022-03-25 02:19:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 02:19:25 --> Input Class Initialized
INFO - 2022-03-25 02:19:25 --> Language Class Initialized
INFO - 2022-03-25 02:19:25 --> Loader Class Initialized
INFO - 2022-03-25 02:19:25 --> Helper loaded: url_helper
INFO - 2022-03-25 02:19:25 --> Helper loaded: form_helper
INFO - 2022-03-25 02:19:25 --> Helper loaded: common_helper
INFO - 2022-03-25 02:19:25 --> Database Driver Class Initialized
DEBUG - 2022-03-25 02:19:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 02:19:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 02:19:25 --> Controller Class Initialized
INFO - 2022-03-25 02:19:25 --> Form Validation Class Initialized
DEBUG - 2022-03-25 02:19:25 --> Encrypt Class Initialized
INFO - 2022-03-25 02:19:25 --> Model "Patient_model" initialized
INFO - 2022-03-25 02:19:25 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 02:19:25 --> Model "Referredby_model" initialized
INFO - 2022-03-25 02:19:25 --> Model "Prefix_master" initialized
INFO - 2022-03-25 02:19:25 --> Model "Hospital_model" initialized
INFO - 2022-03-25 02:19:25 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-25 02:19:25 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-25 02:19:25 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-25 02:19:25 --> Final output sent to browser
DEBUG - 2022-03-25 02:19:25 --> Total execution time: 0.0266
ERROR - 2022-03-25 02:19:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 02:19:25 --> Config Class Initialized
INFO - 2022-03-25 02:19:25 --> Hooks Class Initialized
DEBUG - 2022-03-25 02:19:25 --> UTF-8 Support Enabled
INFO - 2022-03-25 02:19:25 --> Utf8 Class Initialized
INFO - 2022-03-25 02:19:25 --> URI Class Initialized
INFO - 2022-03-25 02:19:25 --> Router Class Initialized
INFO - 2022-03-25 02:19:25 --> Output Class Initialized
INFO - 2022-03-25 02:19:25 --> Security Class Initialized
DEBUG - 2022-03-25 02:19:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 02:19:25 --> Input Class Initialized
INFO - 2022-03-25 02:19:25 --> Language Class Initialized
INFO - 2022-03-25 02:19:25 --> Loader Class Initialized
INFO - 2022-03-25 02:19:25 --> Helper loaded: url_helper
INFO - 2022-03-25 02:19:25 --> Helper loaded: form_helper
INFO - 2022-03-25 02:19:25 --> Helper loaded: common_helper
INFO - 2022-03-25 02:19:25 --> Database Driver Class Initialized
DEBUG - 2022-03-25 02:19:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 02:19:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 02:19:25 --> Controller Class Initialized
INFO - 2022-03-25 02:19:25 --> Form Validation Class Initialized
DEBUG - 2022-03-25 02:19:25 --> Encrypt Class Initialized
INFO - 2022-03-25 02:19:25 --> Model "Patient_model" initialized
INFO - 2022-03-25 02:19:25 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 02:19:25 --> Model "Prefix_master" initialized
INFO - 2022-03-25 02:19:25 --> Model "Users_model" initialized
INFO - 2022-03-25 02:19:25 --> Model "Hospital_model" initialized
INFO - 2022-03-25 02:19:25 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-25 02:19:25 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-25 02:19:25 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-25 02:19:25 --> Final output sent to browser
DEBUG - 2022-03-25 02:19:25 --> Total execution time: 0.0470
ERROR - 2022-03-25 02:23:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 02:23:12 --> Config Class Initialized
INFO - 2022-03-25 02:23:12 --> Hooks Class Initialized
DEBUG - 2022-03-25 02:23:12 --> UTF-8 Support Enabled
INFO - 2022-03-25 02:23:12 --> Utf8 Class Initialized
INFO - 2022-03-25 02:23:12 --> URI Class Initialized
INFO - 2022-03-25 02:23:12 --> Router Class Initialized
INFO - 2022-03-25 02:23:12 --> Output Class Initialized
INFO - 2022-03-25 02:23:12 --> Security Class Initialized
DEBUG - 2022-03-25 02:23:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 02:23:12 --> Input Class Initialized
INFO - 2022-03-25 02:23:12 --> Language Class Initialized
INFO - 2022-03-25 02:23:12 --> Loader Class Initialized
INFO - 2022-03-25 02:23:12 --> Helper loaded: url_helper
INFO - 2022-03-25 02:23:12 --> Helper loaded: form_helper
INFO - 2022-03-25 02:23:12 --> Helper loaded: common_helper
INFO - 2022-03-25 02:23:12 --> Database Driver Class Initialized
DEBUG - 2022-03-25 02:23:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 02:23:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 02:23:12 --> Controller Class Initialized
INFO - 2022-03-25 02:23:12 --> Form Validation Class Initialized
DEBUG - 2022-03-25 02:23:12 --> Encrypt Class Initialized
INFO - 2022-03-25 02:23:12 --> Model "Patient_model" initialized
INFO - 2022-03-25 02:23:12 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 02:23:12 --> Model "Prefix_master" initialized
INFO - 2022-03-25 02:23:12 --> Model "Users_model" initialized
INFO - 2022-03-25 02:23:12 --> Model "Hospital_model" initialized
ERROR - 2022-03-25 02:23:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 02:23:13 --> Config Class Initialized
INFO - 2022-03-25 02:23:13 --> Hooks Class Initialized
DEBUG - 2022-03-25 02:23:13 --> UTF-8 Support Enabled
INFO - 2022-03-25 02:23:13 --> Utf8 Class Initialized
INFO - 2022-03-25 02:23:13 --> URI Class Initialized
INFO - 2022-03-25 02:23:13 --> Router Class Initialized
INFO - 2022-03-25 02:23:13 --> Output Class Initialized
INFO - 2022-03-25 02:23:13 --> Security Class Initialized
DEBUG - 2022-03-25 02:23:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 02:23:13 --> Input Class Initialized
INFO - 2022-03-25 02:23:13 --> Language Class Initialized
INFO - 2022-03-25 02:23:13 --> Loader Class Initialized
INFO - 2022-03-25 02:23:13 --> Helper loaded: url_helper
INFO - 2022-03-25 02:23:13 --> Helper loaded: form_helper
INFO - 2022-03-25 02:23:13 --> Helper loaded: common_helper
INFO - 2022-03-25 02:23:13 --> Database Driver Class Initialized
DEBUG - 2022-03-25 02:23:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 02:23:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 02:23:13 --> Controller Class Initialized
INFO - 2022-03-25 02:23:13 --> Form Validation Class Initialized
DEBUG - 2022-03-25 02:23:13 --> Encrypt Class Initialized
INFO - 2022-03-25 02:23:13 --> Model "Patient_model" initialized
INFO - 2022-03-25 02:23:13 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 02:23:13 --> Model "Prefix_master" initialized
INFO - 2022-03-25 02:23:13 --> Model "Users_model" initialized
INFO - 2022-03-25 02:23:13 --> Model "Hospital_model" initialized
INFO - 2022-03-25 02:23:13 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-25 02:23:13 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-25 02:23:13 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-25 02:23:13 --> Final output sent to browser
DEBUG - 2022-03-25 02:23:13 --> Total execution time: 0.0672
ERROR - 2022-03-25 02:25:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 02:25:38 --> Config Class Initialized
INFO - 2022-03-25 02:25:38 --> Hooks Class Initialized
DEBUG - 2022-03-25 02:25:38 --> UTF-8 Support Enabled
INFO - 2022-03-25 02:25:38 --> Utf8 Class Initialized
INFO - 2022-03-25 02:25:38 --> URI Class Initialized
INFO - 2022-03-25 02:25:38 --> Router Class Initialized
INFO - 2022-03-25 02:25:38 --> Output Class Initialized
INFO - 2022-03-25 02:25:38 --> Security Class Initialized
DEBUG - 2022-03-25 02:25:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 02:25:38 --> Input Class Initialized
INFO - 2022-03-25 02:25:38 --> Language Class Initialized
INFO - 2022-03-25 02:25:38 --> Loader Class Initialized
INFO - 2022-03-25 02:25:38 --> Helper loaded: url_helper
INFO - 2022-03-25 02:25:38 --> Helper loaded: form_helper
INFO - 2022-03-25 02:25:38 --> Helper loaded: common_helper
INFO - 2022-03-25 02:25:38 --> Database Driver Class Initialized
DEBUG - 2022-03-25 02:25:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 02:25:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 02:25:38 --> Controller Class Initialized
INFO - 2022-03-25 02:25:38 --> Form Validation Class Initialized
DEBUG - 2022-03-25 02:25:38 --> Encrypt Class Initialized
INFO - 2022-03-25 02:25:38 --> Model "Patient_model" initialized
INFO - 2022-03-25 02:25:38 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 02:25:38 --> Model "Prefix_master" initialized
INFO - 2022-03-25 02:25:38 --> Model "Users_model" initialized
INFO - 2022-03-25 02:25:38 --> Model "Hospital_model" initialized
ERROR - 2022-03-25 02:25:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 02:25:39 --> Config Class Initialized
INFO - 2022-03-25 02:25:39 --> Hooks Class Initialized
DEBUG - 2022-03-25 02:25:39 --> UTF-8 Support Enabled
INFO - 2022-03-25 02:25:39 --> Utf8 Class Initialized
INFO - 2022-03-25 02:25:39 --> URI Class Initialized
INFO - 2022-03-25 02:25:39 --> Router Class Initialized
INFO - 2022-03-25 02:25:39 --> Output Class Initialized
INFO - 2022-03-25 02:25:39 --> Security Class Initialized
DEBUG - 2022-03-25 02:25:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 02:25:39 --> Input Class Initialized
INFO - 2022-03-25 02:25:39 --> Language Class Initialized
INFO - 2022-03-25 02:25:39 --> Loader Class Initialized
INFO - 2022-03-25 02:25:39 --> Helper loaded: url_helper
INFO - 2022-03-25 02:25:39 --> Helper loaded: form_helper
INFO - 2022-03-25 02:25:39 --> Helper loaded: common_helper
INFO - 2022-03-25 02:25:39 --> Database Driver Class Initialized
DEBUG - 2022-03-25 02:25:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 02:25:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 02:25:39 --> Controller Class Initialized
INFO - 2022-03-25 02:25:39 --> Form Validation Class Initialized
DEBUG - 2022-03-25 02:25:39 --> Encrypt Class Initialized
INFO - 2022-03-25 02:25:39 --> Model "Patient_model" initialized
INFO - 2022-03-25 02:25:39 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 02:25:39 --> Model "Prefix_master" initialized
INFO - 2022-03-25 02:25:39 --> Model "Users_model" initialized
INFO - 2022-03-25 02:25:39 --> Model "Hospital_model" initialized
INFO - 2022-03-25 02:25:39 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-25 02:25:39 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-25 02:25:39 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-25 02:25:39 --> Final output sent to browser
DEBUG - 2022-03-25 02:25:39 --> Total execution time: 0.0454
ERROR - 2022-03-25 02:28:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 02:28:15 --> Config Class Initialized
INFO - 2022-03-25 02:28:15 --> Hooks Class Initialized
DEBUG - 2022-03-25 02:28:15 --> UTF-8 Support Enabled
INFO - 2022-03-25 02:28:15 --> Utf8 Class Initialized
INFO - 2022-03-25 02:28:15 --> URI Class Initialized
INFO - 2022-03-25 02:28:15 --> Router Class Initialized
INFO - 2022-03-25 02:28:15 --> Output Class Initialized
INFO - 2022-03-25 02:28:15 --> Security Class Initialized
DEBUG - 2022-03-25 02:28:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 02:28:15 --> Input Class Initialized
INFO - 2022-03-25 02:28:15 --> Language Class Initialized
INFO - 2022-03-25 02:28:15 --> Loader Class Initialized
INFO - 2022-03-25 02:28:15 --> Helper loaded: url_helper
INFO - 2022-03-25 02:28:15 --> Helper loaded: form_helper
INFO - 2022-03-25 02:28:15 --> Helper loaded: common_helper
INFO - 2022-03-25 02:28:15 --> Database Driver Class Initialized
DEBUG - 2022-03-25 02:28:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 02:28:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 02:28:15 --> Controller Class Initialized
INFO - 2022-03-25 02:28:15 --> Form Validation Class Initialized
DEBUG - 2022-03-25 02:28:15 --> Encrypt Class Initialized
INFO - 2022-03-25 02:28:15 --> Model "Patient_model" initialized
INFO - 2022-03-25 02:28:15 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 02:28:15 --> Model "Prefix_master" initialized
INFO - 2022-03-25 02:28:15 --> Model "Users_model" initialized
INFO - 2022-03-25 02:28:15 --> Model "Hospital_model" initialized
INFO - 2022-03-25 02:28:15 --> Upload Class Initialized
INFO - 2022-03-25 02:28:15 --> Final output sent to browser
DEBUG - 2022-03-25 02:28:15 --> Total execution time: 0.0803
ERROR - 2022-03-25 02:28:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 02:28:19 --> Config Class Initialized
INFO - 2022-03-25 02:28:19 --> Hooks Class Initialized
DEBUG - 2022-03-25 02:28:19 --> UTF-8 Support Enabled
INFO - 2022-03-25 02:28:19 --> Utf8 Class Initialized
INFO - 2022-03-25 02:28:19 --> URI Class Initialized
INFO - 2022-03-25 02:28:19 --> Router Class Initialized
INFO - 2022-03-25 02:28:19 --> Output Class Initialized
INFO - 2022-03-25 02:28:19 --> Security Class Initialized
DEBUG - 2022-03-25 02:28:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 02:28:19 --> Input Class Initialized
INFO - 2022-03-25 02:28:19 --> Language Class Initialized
INFO - 2022-03-25 02:28:19 --> Loader Class Initialized
INFO - 2022-03-25 02:28:19 --> Helper loaded: url_helper
INFO - 2022-03-25 02:28:19 --> Helper loaded: form_helper
INFO - 2022-03-25 02:28:19 --> Helper loaded: common_helper
INFO - 2022-03-25 02:28:19 --> Database Driver Class Initialized
DEBUG - 2022-03-25 02:28:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 02:28:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 02:28:19 --> Controller Class Initialized
INFO - 2022-03-25 02:28:19 --> Form Validation Class Initialized
DEBUG - 2022-03-25 02:28:19 --> Encrypt Class Initialized
INFO - 2022-03-25 02:28:19 --> Model "Patient_model" initialized
INFO - 2022-03-25 02:28:19 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 02:28:19 --> Model "Prefix_master" initialized
INFO - 2022-03-25 02:28:19 --> Model "Users_model" initialized
INFO - 2022-03-25 02:28:19 --> Model "Hospital_model" initialized
ERROR - 2022-03-25 02:28:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 02:28:20 --> Config Class Initialized
INFO - 2022-03-25 02:28:20 --> Hooks Class Initialized
DEBUG - 2022-03-25 02:28:20 --> UTF-8 Support Enabled
INFO - 2022-03-25 02:28:20 --> Utf8 Class Initialized
INFO - 2022-03-25 02:28:20 --> URI Class Initialized
INFO - 2022-03-25 02:28:20 --> Router Class Initialized
INFO - 2022-03-25 02:28:20 --> Output Class Initialized
INFO - 2022-03-25 02:28:20 --> Security Class Initialized
DEBUG - 2022-03-25 02:28:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 02:28:20 --> Input Class Initialized
INFO - 2022-03-25 02:28:20 --> Language Class Initialized
INFO - 2022-03-25 02:28:20 --> Loader Class Initialized
INFO - 2022-03-25 02:28:20 --> Helper loaded: url_helper
INFO - 2022-03-25 02:28:20 --> Helper loaded: form_helper
INFO - 2022-03-25 02:28:20 --> Helper loaded: common_helper
INFO - 2022-03-25 02:28:20 --> Database Driver Class Initialized
DEBUG - 2022-03-25 02:28:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 02:28:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 02:28:20 --> Controller Class Initialized
INFO - 2022-03-25 02:28:20 --> Form Validation Class Initialized
DEBUG - 2022-03-25 02:28:20 --> Encrypt Class Initialized
INFO - 2022-03-25 02:28:20 --> Model "Patient_model" initialized
INFO - 2022-03-25 02:28:20 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 02:28:20 --> Model "Prefix_master" initialized
INFO - 2022-03-25 02:28:20 --> Model "Users_model" initialized
INFO - 2022-03-25 02:28:20 --> Model "Hospital_model" initialized
INFO - 2022-03-25 02:28:20 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-25 02:28:20 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-25 02:28:20 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-25 02:28:20 --> Final output sent to browser
DEBUG - 2022-03-25 02:28:20 --> Total execution time: 0.0480
ERROR - 2022-03-25 02:34:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 02:34:31 --> Config Class Initialized
INFO - 2022-03-25 02:34:31 --> Hooks Class Initialized
DEBUG - 2022-03-25 02:34:31 --> UTF-8 Support Enabled
INFO - 2022-03-25 02:34:31 --> Utf8 Class Initialized
INFO - 2022-03-25 02:34:31 --> URI Class Initialized
INFO - 2022-03-25 02:34:31 --> Router Class Initialized
INFO - 2022-03-25 02:34:31 --> Output Class Initialized
INFO - 2022-03-25 02:34:31 --> Security Class Initialized
DEBUG - 2022-03-25 02:34:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 02:34:31 --> Input Class Initialized
INFO - 2022-03-25 02:34:31 --> Language Class Initialized
INFO - 2022-03-25 02:34:31 --> Loader Class Initialized
INFO - 2022-03-25 02:34:31 --> Helper loaded: url_helper
INFO - 2022-03-25 02:34:31 --> Helper loaded: form_helper
INFO - 2022-03-25 02:34:31 --> Helper loaded: common_helper
INFO - 2022-03-25 02:34:31 --> Database Driver Class Initialized
DEBUG - 2022-03-25 02:34:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 02:34:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 02:34:31 --> Controller Class Initialized
INFO - 2022-03-25 02:34:32 --> Form Validation Class Initialized
DEBUG - 2022-03-25 02:34:32 --> Encrypt Class Initialized
INFO - 2022-03-25 02:34:32 --> Model "Patient_model" initialized
INFO - 2022-03-25 02:34:32 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 02:34:32 --> Model "Referredby_model" initialized
INFO - 2022-03-25 02:34:32 --> Model "Prefix_master" initialized
INFO - 2022-03-25 02:34:32 --> Model "Hospital_model" initialized
INFO - 2022-03-25 02:34:32 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-25 02:34:32 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-25 02:34:32 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-25 02:34:32 --> Final output sent to browser
DEBUG - 2022-03-25 02:34:32 --> Total execution time: 0.1050
ERROR - 2022-03-25 02:34:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 02:34:32 --> Config Class Initialized
INFO - 2022-03-25 02:34:32 --> Hooks Class Initialized
DEBUG - 2022-03-25 02:34:32 --> UTF-8 Support Enabled
INFO - 2022-03-25 02:34:32 --> Utf8 Class Initialized
INFO - 2022-03-25 02:34:32 --> URI Class Initialized
INFO - 2022-03-25 02:34:32 --> Router Class Initialized
INFO - 2022-03-25 02:34:32 --> Output Class Initialized
INFO - 2022-03-25 02:34:32 --> Security Class Initialized
DEBUG - 2022-03-25 02:34:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 02:34:32 --> Input Class Initialized
INFO - 2022-03-25 02:34:32 --> Language Class Initialized
ERROR - 2022-03-25 02:34:32 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-25 02:36:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 02:36:59 --> Config Class Initialized
INFO - 2022-03-25 02:36:59 --> Hooks Class Initialized
DEBUG - 2022-03-25 02:36:59 --> UTF-8 Support Enabled
INFO - 2022-03-25 02:36:59 --> Utf8 Class Initialized
INFO - 2022-03-25 02:36:59 --> URI Class Initialized
INFO - 2022-03-25 02:36:59 --> Router Class Initialized
INFO - 2022-03-25 02:36:59 --> Output Class Initialized
INFO - 2022-03-25 02:36:59 --> Security Class Initialized
DEBUG - 2022-03-25 02:36:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 02:36:59 --> Input Class Initialized
INFO - 2022-03-25 02:36:59 --> Language Class Initialized
INFO - 2022-03-25 02:36:59 --> Loader Class Initialized
INFO - 2022-03-25 02:36:59 --> Helper loaded: url_helper
INFO - 2022-03-25 02:36:59 --> Helper loaded: form_helper
INFO - 2022-03-25 02:36:59 --> Helper loaded: common_helper
INFO - 2022-03-25 02:36:59 --> Database Driver Class Initialized
DEBUG - 2022-03-25 02:36:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 02:36:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 02:36:59 --> Controller Class Initialized
INFO - 2022-03-25 02:36:59 --> Form Validation Class Initialized
DEBUG - 2022-03-25 02:36:59 --> Encrypt Class Initialized
INFO - 2022-03-25 02:36:59 --> Model "Patient_model" initialized
INFO - 2022-03-25 02:36:59 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 02:36:59 --> Model "Prefix_master" initialized
INFO - 2022-03-25 02:36:59 --> Model "Users_model" initialized
INFO - 2022-03-25 02:36:59 --> Model "Hospital_model" initialized
ERROR - 2022-03-25 02:36:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 02:36:59 --> Config Class Initialized
INFO - 2022-03-25 02:36:59 --> Hooks Class Initialized
DEBUG - 2022-03-25 02:36:59 --> UTF-8 Support Enabled
INFO - 2022-03-25 02:36:59 --> Utf8 Class Initialized
INFO - 2022-03-25 02:36:59 --> URI Class Initialized
INFO - 2022-03-25 02:36:59 --> Router Class Initialized
INFO - 2022-03-25 02:36:59 --> Output Class Initialized
INFO - 2022-03-25 02:36:59 --> Security Class Initialized
DEBUG - 2022-03-25 02:36:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 02:36:59 --> Input Class Initialized
INFO - 2022-03-25 02:36:59 --> Language Class Initialized
INFO - 2022-03-25 02:36:59 --> Loader Class Initialized
INFO - 2022-03-25 02:36:59 --> Helper loaded: url_helper
INFO - 2022-03-25 02:36:59 --> Helper loaded: form_helper
INFO - 2022-03-25 02:36:59 --> Helper loaded: common_helper
INFO - 2022-03-25 02:36:59 --> Database Driver Class Initialized
DEBUG - 2022-03-25 02:36:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 02:36:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 02:36:59 --> Controller Class Initialized
INFO - 2022-03-25 02:36:59 --> Form Validation Class Initialized
DEBUG - 2022-03-25 02:36:59 --> Encrypt Class Initialized
INFO - 2022-03-25 02:36:59 --> Model "Patient_model" initialized
INFO - 2022-03-25 02:36:59 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 02:36:59 --> Model "Prefix_master" initialized
INFO - 2022-03-25 02:36:59 --> Model "Users_model" initialized
INFO - 2022-03-25 02:36:59 --> Model "Hospital_model" initialized
INFO - 2022-03-25 02:36:59 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-25 02:36:59 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-25 02:36:59 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-25 02:36:59 --> Final output sent to browser
DEBUG - 2022-03-25 02:36:59 --> Total execution time: 0.0522
ERROR - 2022-03-25 02:46:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 02:46:15 --> Config Class Initialized
INFO - 2022-03-25 02:46:15 --> Hooks Class Initialized
DEBUG - 2022-03-25 02:46:15 --> UTF-8 Support Enabled
INFO - 2022-03-25 02:46:15 --> Utf8 Class Initialized
INFO - 2022-03-25 02:46:15 --> URI Class Initialized
INFO - 2022-03-25 02:46:15 --> Router Class Initialized
INFO - 2022-03-25 02:46:15 --> Output Class Initialized
INFO - 2022-03-25 02:46:15 --> Security Class Initialized
DEBUG - 2022-03-25 02:46:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 02:46:15 --> Input Class Initialized
INFO - 2022-03-25 02:46:15 --> Language Class Initialized
INFO - 2022-03-25 02:46:15 --> Loader Class Initialized
INFO - 2022-03-25 02:46:15 --> Helper loaded: url_helper
INFO - 2022-03-25 02:46:15 --> Helper loaded: form_helper
INFO - 2022-03-25 02:46:15 --> Helper loaded: common_helper
INFO - 2022-03-25 02:46:15 --> Database Driver Class Initialized
DEBUG - 2022-03-25 02:46:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 02:46:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 02:46:15 --> Controller Class Initialized
INFO - 2022-03-25 02:46:15 --> Form Validation Class Initialized
DEBUG - 2022-03-25 02:46:15 --> Encrypt Class Initialized
INFO - 2022-03-25 02:46:15 --> Model "Patient_model" initialized
INFO - 2022-03-25 02:46:15 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 02:46:15 --> Model "Referredby_model" initialized
INFO - 2022-03-25 02:46:15 --> Model "Prefix_master" initialized
INFO - 2022-03-25 02:46:15 --> Model "Hospital_model" initialized
INFO - 2022-03-25 02:46:15 --> Final output sent to browser
DEBUG - 2022-03-25 02:46:15 --> Total execution time: 0.0592
ERROR - 2022-03-25 02:48:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 02:48:14 --> Config Class Initialized
INFO - 2022-03-25 02:48:14 --> Hooks Class Initialized
DEBUG - 2022-03-25 02:48:14 --> UTF-8 Support Enabled
INFO - 2022-03-25 02:48:14 --> Utf8 Class Initialized
INFO - 2022-03-25 02:48:14 --> URI Class Initialized
INFO - 2022-03-25 02:48:14 --> Router Class Initialized
INFO - 2022-03-25 02:48:14 --> Output Class Initialized
INFO - 2022-03-25 02:48:14 --> Security Class Initialized
DEBUG - 2022-03-25 02:48:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 02:48:14 --> Input Class Initialized
INFO - 2022-03-25 02:48:14 --> Language Class Initialized
INFO - 2022-03-25 02:48:14 --> Loader Class Initialized
INFO - 2022-03-25 02:48:14 --> Helper loaded: url_helper
INFO - 2022-03-25 02:48:14 --> Helper loaded: form_helper
INFO - 2022-03-25 02:48:14 --> Helper loaded: common_helper
INFO - 2022-03-25 02:48:14 --> Database Driver Class Initialized
DEBUG - 2022-03-25 02:48:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 02:48:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 02:48:14 --> Controller Class Initialized
INFO - 2022-03-25 02:48:14 --> Form Validation Class Initialized
DEBUG - 2022-03-25 02:48:14 --> Encrypt Class Initialized
INFO - 2022-03-25 02:48:14 --> Model "Patient_model" initialized
INFO - 2022-03-25 02:48:14 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 02:48:14 --> Model "Referredby_model" initialized
INFO - 2022-03-25 02:48:14 --> Model "Prefix_master" initialized
INFO - 2022-03-25 02:48:14 --> Model "Hospital_model" initialized
INFO - 2022-03-25 02:48:14 --> Final output sent to browser
DEBUG - 2022-03-25 02:48:14 --> Total execution time: 0.0180
ERROR - 2022-03-25 02:50:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 02:50:04 --> Config Class Initialized
INFO - 2022-03-25 02:50:04 --> Hooks Class Initialized
DEBUG - 2022-03-25 02:50:04 --> UTF-8 Support Enabled
INFO - 2022-03-25 02:50:04 --> Utf8 Class Initialized
INFO - 2022-03-25 02:50:04 --> URI Class Initialized
INFO - 2022-03-25 02:50:04 --> Router Class Initialized
INFO - 2022-03-25 02:50:04 --> Output Class Initialized
INFO - 2022-03-25 02:50:04 --> Security Class Initialized
DEBUG - 2022-03-25 02:50:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 02:50:04 --> Input Class Initialized
INFO - 2022-03-25 02:50:04 --> Language Class Initialized
INFO - 2022-03-25 02:50:04 --> Loader Class Initialized
INFO - 2022-03-25 02:50:04 --> Helper loaded: url_helper
INFO - 2022-03-25 02:50:04 --> Helper loaded: form_helper
INFO - 2022-03-25 02:50:04 --> Helper loaded: common_helper
INFO - 2022-03-25 02:50:04 --> Database Driver Class Initialized
DEBUG - 2022-03-25 02:50:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 02:50:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 02:50:04 --> Controller Class Initialized
INFO - 2022-03-25 02:50:04 --> Form Validation Class Initialized
DEBUG - 2022-03-25 02:50:04 --> Encrypt Class Initialized
INFO - 2022-03-25 02:50:04 --> Model "Patient_model" initialized
INFO - 2022-03-25 02:50:04 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 02:50:04 --> Model "Referredby_model" initialized
INFO - 2022-03-25 02:50:04 --> Model "Prefix_master" initialized
INFO - 2022-03-25 02:50:04 --> Model "Hospital_model" initialized
INFO - 2022-03-25 02:50:04 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-25 02:50:04 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-25 02:50:04 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-25 02:50:04 --> Final output sent to browser
DEBUG - 2022-03-25 02:50:04 --> Total execution time: 0.1213
ERROR - 2022-03-25 03:02:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 03:02:15 --> Config Class Initialized
INFO - 2022-03-25 03:02:15 --> Hooks Class Initialized
DEBUG - 2022-03-25 03:02:15 --> UTF-8 Support Enabled
INFO - 2022-03-25 03:02:15 --> Utf8 Class Initialized
INFO - 2022-03-25 03:02:15 --> URI Class Initialized
INFO - 2022-03-25 03:02:15 --> Router Class Initialized
INFO - 2022-03-25 03:02:15 --> Output Class Initialized
INFO - 2022-03-25 03:02:15 --> Security Class Initialized
DEBUG - 2022-03-25 03:02:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 03:02:15 --> Input Class Initialized
INFO - 2022-03-25 03:02:15 --> Language Class Initialized
INFO - 2022-03-25 03:02:15 --> Loader Class Initialized
INFO - 2022-03-25 03:02:15 --> Helper loaded: url_helper
INFO - 2022-03-25 03:02:15 --> Helper loaded: form_helper
INFO - 2022-03-25 03:02:15 --> Helper loaded: common_helper
INFO - 2022-03-25 03:02:16 --> Database Driver Class Initialized
DEBUG - 2022-03-25 03:02:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 03:02:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 03:02:16 --> Controller Class Initialized
INFO - 2022-03-25 03:02:16 --> Form Validation Class Initialized
DEBUG - 2022-03-25 03:02:16 --> Encrypt Class Initialized
INFO - 2022-03-25 03:02:16 --> Model "Patient_model" initialized
INFO - 2022-03-25 03:02:16 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 03:02:16 --> Model "Prefix_master" initialized
INFO - 2022-03-25 03:02:16 --> Model "Users_model" initialized
INFO - 2022-03-25 03:02:16 --> Model "Hospital_model" initialized
INFO - 2022-03-25 03:02:16 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-25 03:02:16 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-25 03:02:16 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-25 03:02:16 --> Final output sent to browser
DEBUG - 2022-03-25 03:02:16 --> Total execution time: 0.1811
ERROR - 2022-03-25 03:02:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 03:02:18 --> Config Class Initialized
INFO - 2022-03-25 03:02:18 --> Hooks Class Initialized
DEBUG - 2022-03-25 03:02:18 --> UTF-8 Support Enabled
INFO - 2022-03-25 03:02:18 --> Utf8 Class Initialized
INFO - 2022-03-25 03:02:18 --> URI Class Initialized
INFO - 2022-03-25 03:02:18 --> Router Class Initialized
INFO - 2022-03-25 03:02:18 --> Output Class Initialized
INFO - 2022-03-25 03:02:18 --> Security Class Initialized
DEBUG - 2022-03-25 03:02:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 03:02:18 --> Input Class Initialized
INFO - 2022-03-25 03:02:18 --> Language Class Initialized
ERROR - 2022-03-25 03:02:18 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-25 03:02:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 03:02:25 --> Config Class Initialized
INFO - 2022-03-25 03:02:25 --> Hooks Class Initialized
DEBUG - 2022-03-25 03:02:25 --> UTF-8 Support Enabled
INFO - 2022-03-25 03:02:25 --> Utf8 Class Initialized
INFO - 2022-03-25 03:02:25 --> URI Class Initialized
INFO - 2022-03-25 03:02:25 --> Router Class Initialized
INFO - 2022-03-25 03:02:25 --> Output Class Initialized
INFO - 2022-03-25 03:02:25 --> Security Class Initialized
DEBUG - 2022-03-25 03:02:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 03:02:25 --> Input Class Initialized
INFO - 2022-03-25 03:02:25 --> Language Class Initialized
INFO - 2022-03-25 03:02:25 --> Loader Class Initialized
INFO - 2022-03-25 03:02:25 --> Helper loaded: url_helper
INFO - 2022-03-25 03:02:25 --> Helper loaded: form_helper
INFO - 2022-03-25 03:02:25 --> Helper loaded: common_helper
INFO - 2022-03-25 03:02:25 --> Database Driver Class Initialized
DEBUG - 2022-03-25 03:02:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 03:02:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 03:02:25 --> Controller Class Initialized
INFO - 2022-03-25 03:02:25 --> Form Validation Class Initialized
DEBUG - 2022-03-25 03:02:25 --> Encrypt Class Initialized
INFO - 2022-03-25 03:02:25 --> Model "Patient_model" initialized
INFO - 2022-03-25 03:02:25 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 03:02:25 --> Model "Referredby_model" initialized
INFO - 2022-03-25 03:02:25 --> Model "Prefix_master" initialized
INFO - 2022-03-25 03:02:25 --> Model "Hospital_model" initialized
INFO - 2022-03-25 03:02:25 --> File loaded: /home3/karoteam/public_html/application/views/header.php
ERROR - 2022-03-25 03:02:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 03:02:34 --> Config Class Initialized
INFO - 2022-03-25 03:02:34 --> Hooks Class Initialized
DEBUG - 2022-03-25 03:02:34 --> UTF-8 Support Enabled
INFO - 2022-03-25 03:02:34 --> Utf8 Class Initialized
INFO - 2022-03-25 03:02:34 --> URI Class Initialized
INFO - 2022-03-25 03:02:34 --> Router Class Initialized
INFO - 2022-03-25 03:02:34 --> Output Class Initialized
INFO - 2022-03-25 03:02:34 --> Security Class Initialized
DEBUG - 2022-03-25 03:02:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 03:02:34 --> Input Class Initialized
INFO - 2022-03-25 03:02:34 --> Language Class Initialized
INFO - 2022-03-25 03:02:34 --> Loader Class Initialized
INFO - 2022-03-25 03:02:34 --> Helper loaded: url_helper
INFO - 2022-03-25 03:02:34 --> Helper loaded: form_helper
INFO - 2022-03-25 03:02:34 --> Helper loaded: common_helper
INFO - 2022-03-25 03:02:34 --> Database Driver Class Initialized
DEBUG - 2022-03-25 03:02:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 03:02:34 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-25 03:02:34 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-25 03:02:34 --> Final output sent to browser
DEBUG - 2022-03-25 03:02:34 --> Total execution time: 9.0323
INFO - 2022-03-25 03:02:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 03:02:34 --> Controller Class Initialized
INFO - 2022-03-25 03:02:34 --> Form Validation Class Initialized
DEBUG - 2022-03-25 03:02:34 --> Encrypt Class Initialized
INFO - 2022-03-25 03:02:34 --> Model "Patient_model" initialized
INFO - 2022-03-25 03:02:34 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 03:02:34 --> Model "Referredby_model" initialized
INFO - 2022-03-25 03:02:34 --> Model "Prefix_master" initialized
INFO - 2022-03-25 03:02:34 --> Model "Hospital_model" initialized
INFO - 2022-03-25 03:02:35 --> File loaded: /home3/karoteam/public_html/application/views/header.php
ERROR - 2022-03-25 03:02:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 03:02:43 --> Config Class Initialized
INFO - 2022-03-25 03:02:43 --> Hooks Class Initialized
DEBUG - 2022-03-25 03:02:43 --> UTF-8 Support Enabled
INFO - 2022-03-25 03:02:43 --> Utf8 Class Initialized
INFO - 2022-03-25 03:02:43 --> URI Class Initialized
INFO - 2022-03-25 03:02:43 --> Router Class Initialized
INFO - 2022-03-25 03:02:43 --> Output Class Initialized
INFO - 2022-03-25 03:02:43 --> Security Class Initialized
DEBUG - 2022-03-25 03:02:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 03:02:43 --> Input Class Initialized
INFO - 2022-03-25 03:02:43 --> Language Class Initialized
INFO - 2022-03-25 03:02:43 --> Loader Class Initialized
INFO - 2022-03-25 03:02:43 --> Helper loaded: url_helper
INFO - 2022-03-25 03:02:43 --> Helper loaded: form_helper
INFO - 2022-03-25 03:02:43 --> Helper loaded: common_helper
INFO - 2022-03-25 03:02:43 --> Database Driver Class Initialized
DEBUG - 2022-03-25 03:02:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 03:02:44 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-25 03:02:44 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-25 03:02:45 --> Final output sent to browser
DEBUG - 2022-03-25 03:02:45 --> Total execution time: 10.6852
INFO - 2022-03-25 03:02:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 03:02:45 --> Controller Class Initialized
INFO - 2022-03-25 03:02:45 --> Form Validation Class Initialized
DEBUG - 2022-03-25 03:02:45 --> Encrypt Class Initialized
INFO - 2022-03-25 03:02:45 --> Model "Patient_model" initialized
INFO - 2022-03-25 03:02:45 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 03:02:45 --> Model "Referredby_model" initialized
INFO - 2022-03-25 03:02:45 --> Model "Prefix_master" initialized
INFO - 2022-03-25 03:02:45 --> Model "Hospital_model" initialized
INFO - 2022-03-25 03:02:45 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-25 03:02:54 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-25 03:02:54 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
ERROR - 2022-03-25 03:02:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 03:02:55 --> Config Class Initialized
INFO - 2022-03-25 03:02:55 --> Hooks Class Initialized
DEBUG - 2022-03-25 03:02:55 --> UTF-8 Support Enabled
INFO - 2022-03-25 03:02:55 --> Utf8 Class Initialized
INFO - 2022-03-25 03:02:55 --> URI Class Initialized
INFO - 2022-03-25 03:02:55 --> Router Class Initialized
INFO - 2022-03-25 03:02:55 --> Output Class Initialized
INFO - 2022-03-25 03:02:55 --> Security Class Initialized
DEBUG - 2022-03-25 03:02:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 03:02:55 --> Input Class Initialized
INFO - 2022-03-25 03:02:55 --> Language Class Initialized
ERROR - 2022-03-25 03:02:55 --> 404 Page Not Found: Karoclient/usersprofile
INFO - 2022-03-25 03:02:55 --> Final output sent to browser
DEBUG - 2022-03-25 03:02:55 --> Total execution time: 10.9711
ERROR - 2022-03-25 03:05:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 03:05:13 --> Config Class Initialized
INFO - 2022-03-25 03:05:13 --> Hooks Class Initialized
DEBUG - 2022-03-25 03:05:13 --> UTF-8 Support Enabled
INFO - 2022-03-25 03:05:13 --> Utf8 Class Initialized
INFO - 2022-03-25 03:05:13 --> URI Class Initialized
INFO - 2022-03-25 03:05:13 --> Router Class Initialized
INFO - 2022-03-25 03:05:13 --> Output Class Initialized
INFO - 2022-03-25 03:05:13 --> Security Class Initialized
DEBUG - 2022-03-25 03:05:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 03:05:13 --> Input Class Initialized
INFO - 2022-03-25 03:05:13 --> Language Class Initialized
INFO - 2022-03-25 03:05:13 --> Loader Class Initialized
INFO - 2022-03-25 03:05:13 --> Helper loaded: url_helper
INFO - 2022-03-25 03:05:13 --> Helper loaded: form_helper
INFO - 2022-03-25 03:05:13 --> Helper loaded: common_helper
INFO - 2022-03-25 03:05:13 --> Database Driver Class Initialized
DEBUG - 2022-03-25 03:05:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 03:05:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 03:05:13 --> Controller Class Initialized
INFO - 2022-03-25 03:05:13 --> Form Validation Class Initialized
DEBUG - 2022-03-25 03:05:13 --> Encrypt Class Initialized
INFO - 2022-03-25 03:05:13 --> Model "Patient_model" initialized
INFO - 2022-03-25 03:05:13 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 03:05:13 --> Model "Prefix_master" initialized
INFO - 2022-03-25 03:05:13 --> Model "Users_model" initialized
INFO - 2022-03-25 03:05:13 --> Model "Hospital_model" initialized
INFO - 2022-03-25 03:05:13 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-25 03:05:13 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-25 03:05:13 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-25 03:05:13 --> Final output sent to browser
DEBUG - 2022-03-25 03:05:13 --> Total execution time: 0.0955
ERROR - 2022-03-25 03:05:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 03:05:13 --> Config Class Initialized
INFO - 2022-03-25 03:05:13 --> Hooks Class Initialized
DEBUG - 2022-03-25 03:05:13 --> UTF-8 Support Enabled
INFO - 2022-03-25 03:05:13 --> Utf8 Class Initialized
INFO - 2022-03-25 03:05:13 --> URI Class Initialized
INFO - 2022-03-25 03:05:13 --> Router Class Initialized
INFO - 2022-03-25 03:05:13 --> Output Class Initialized
INFO - 2022-03-25 03:05:13 --> Security Class Initialized
DEBUG - 2022-03-25 03:05:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 03:05:13 --> Input Class Initialized
INFO - 2022-03-25 03:05:13 --> Language Class Initialized
ERROR - 2022-03-25 03:05:13 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-25 03:06:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 03:06:28 --> Config Class Initialized
INFO - 2022-03-25 03:06:28 --> Hooks Class Initialized
DEBUG - 2022-03-25 03:06:28 --> UTF-8 Support Enabled
INFO - 2022-03-25 03:06:28 --> Utf8 Class Initialized
INFO - 2022-03-25 03:06:28 --> URI Class Initialized
DEBUG - 2022-03-25 03:06:28 --> No URI present. Default controller set.
INFO - 2022-03-25 03:06:28 --> Router Class Initialized
INFO - 2022-03-25 03:06:28 --> Output Class Initialized
INFO - 2022-03-25 03:06:28 --> Security Class Initialized
DEBUG - 2022-03-25 03:06:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 03:06:28 --> Input Class Initialized
INFO - 2022-03-25 03:06:28 --> Language Class Initialized
INFO - 2022-03-25 03:06:28 --> Loader Class Initialized
INFO - 2022-03-25 03:06:28 --> Helper loaded: url_helper
INFO - 2022-03-25 03:06:28 --> Helper loaded: form_helper
INFO - 2022-03-25 03:06:28 --> Helper loaded: common_helper
INFO - 2022-03-25 03:06:28 --> Database Driver Class Initialized
DEBUG - 2022-03-25 03:06:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 03:06:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 03:06:28 --> Controller Class Initialized
INFO - 2022-03-25 03:06:28 --> Form Validation Class Initialized
DEBUG - 2022-03-25 03:06:28 --> Encrypt Class Initialized
DEBUG - 2022-03-25 03:06:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 03:06:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-25 03:06:28 --> Email Class Initialized
INFO - 2022-03-25 03:06:28 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-25 03:06:28 --> Calendar Class Initialized
INFO - 2022-03-25 03:06:28 --> Model "Login_model" initialized
INFO - 2022-03-25 03:06:28 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-25 03:06:28 --> Final output sent to browser
DEBUG - 2022-03-25 03:06:28 --> Total execution time: 0.0191
ERROR - 2022-03-25 03:21:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 03:21:21 --> Config Class Initialized
INFO - 2022-03-25 03:21:21 --> Hooks Class Initialized
DEBUG - 2022-03-25 03:21:21 --> UTF-8 Support Enabled
INFO - 2022-03-25 03:21:21 --> Utf8 Class Initialized
INFO - 2022-03-25 03:21:21 --> URI Class Initialized
INFO - 2022-03-25 03:21:21 --> Router Class Initialized
INFO - 2022-03-25 03:21:21 --> Output Class Initialized
INFO - 2022-03-25 03:21:21 --> Security Class Initialized
DEBUG - 2022-03-25 03:21:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 03:21:21 --> Input Class Initialized
INFO - 2022-03-25 03:21:21 --> Language Class Initialized
INFO - 2022-03-25 03:21:21 --> Loader Class Initialized
INFO - 2022-03-25 03:21:21 --> Helper loaded: url_helper
INFO - 2022-03-25 03:21:21 --> Helper loaded: form_helper
INFO - 2022-03-25 03:21:21 --> Helper loaded: common_helper
INFO - 2022-03-25 03:21:21 --> Database Driver Class Initialized
DEBUG - 2022-03-25 03:21:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 03:21:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 03:21:21 --> Controller Class Initialized
INFO - 2022-03-25 03:21:21 --> Form Validation Class Initialized
DEBUG - 2022-03-25 03:21:21 --> Encrypt Class Initialized
INFO - 2022-03-25 03:21:21 --> Model "Patient_model" initialized
INFO - 2022-03-25 03:21:21 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 03:21:21 --> Model "Prefix_master" initialized
INFO - 2022-03-25 03:21:21 --> Model "Users_model" initialized
INFO - 2022-03-25 03:21:21 --> Model "Hospital_model" initialized
INFO - 2022-03-25 03:21:21 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-25 03:21:21 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-25 03:21:21 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-25 03:21:21 --> Final output sent to browser
DEBUG - 2022-03-25 03:21:21 --> Total execution time: 0.1221
ERROR - 2022-03-25 03:21:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 03:21:25 --> Config Class Initialized
INFO - 2022-03-25 03:21:25 --> Hooks Class Initialized
DEBUG - 2022-03-25 03:21:25 --> UTF-8 Support Enabled
INFO - 2022-03-25 03:21:25 --> Utf8 Class Initialized
INFO - 2022-03-25 03:21:25 --> URI Class Initialized
INFO - 2022-03-25 03:21:25 --> Router Class Initialized
INFO - 2022-03-25 03:21:25 --> Output Class Initialized
INFO - 2022-03-25 03:21:25 --> Security Class Initialized
DEBUG - 2022-03-25 03:21:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 03:21:25 --> Input Class Initialized
INFO - 2022-03-25 03:21:25 --> Language Class Initialized
INFO - 2022-03-25 03:21:25 --> Loader Class Initialized
INFO - 2022-03-25 03:21:25 --> Helper loaded: url_helper
INFO - 2022-03-25 03:21:25 --> Helper loaded: form_helper
INFO - 2022-03-25 03:21:25 --> Helper loaded: common_helper
INFO - 2022-03-25 03:21:25 --> Database Driver Class Initialized
DEBUG - 2022-03-25 03:21:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 03:21:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 03:21:25 --> Controller Class Initialized
INFO - 2022-03-25 03:21:25 --> Form Validation Class Initialized
DEBUG - 2022-03-25 03:21:25 --> Encrypt Class Initialized
INFO - 2022-03-25 03:21:25 --> Model "Patient_model" initialized
INFO - 2022-03-25 03:21:25 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 03:21:25 --> Model "Referredby_model" initialized
INFO - 2022-03-25 03:21:25 --> Model "Prefix_master" initialized
INFO - 2022-03-25 03:21:25 --> Model "Hospital_model" initialized
INFO - 2022-03-25 03:21:26 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-25 03:21:32 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-25 03:21:32 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-25 03:21:33 --> Final output sent to browser
DEBUG - 2022-03-25 03:21:33 --> Total execution time: 6.2763
ERROR - 2022-03-25 03:21:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 03:21:58 --> Config Class Initialized
INFO - 2022-03-25 03:21:58 --> Hooks Class Initialized
DEBUG - 2022-03-25 03:21:58 --> UTF-8 Support Enabled
INFO - 2022-03-25 03:21:58 --> Utf8 Class Initialized
INFO - 2022-03-25 03:21:58 --> URI Class Initialized
INFO - 2022-03-25 03:21:58 --> Router Class Initialized
INFO - 2022-03-25 03:21:58 --> Output Class Initialized
INFO - 2022-03-25 03:21:58 --> Security Class Initialized
DEBUG - 2022-03-25 03:21:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 03:21:58 --> Input Class Initialized
INFO - 2022-03-25 03:21:58 --> Language Class Initialized
INFO - 2022-03-25 03:21:58 --> Loader Class Initialized
INFO - 2022-03-25 03:21:58 --> Helper loaded: url_helper
INFO - 2022-03-25 03:21:58 --> Helper loaded: form_helper
INFO - 2022-03-25 03:21:58 --> Helper loaded: common_helper
INFO - 2022-03-25 03:21:58 --> Database Driver Class Initialized
DEBUG - 2022-03-25 03:21:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 03:21:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 03:21:58 --> Controller Class Initialized
INFO - 2022-03-25 03:21:58 --> Form Validation Class Initialized
DEBUG - 2022-03-25 03:21:58 --> Encrypt Class Initialized
INFO - 2022-03-25 03:21:58 --> Model "Patient_model" initialized
INFO - 2022-03-25 03:21:58 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 03:21:58 --> Model "Prefix_master" initialized
INFO - 2022-03-25 03:21:58 --> Model "Users_model" initialized
INFO - 2022-03-25 03:21:58 --> Model "Hospital_model" initialized
INFO - 2022-03-25 03:21:58 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-25 03:22:00 --> Final output sent to browser
DEBUG - 2022-03-25 03:22:00 --> Total execution time: 2.5819
ERROR - 2022-03-25 03:23:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 03:23:34 --> Config Class Initialized
INFO - 2022-03-25 03:23:34 --> Hooks Class Initialized
DEBUG - 2022-03-25 03:23:34 --> UTF-8 Support Enabled
INFO - 2022-03-25 03:23:34 --> Utf8 Class Initialized
INFO - 2022-03-25 03:23:34 --> URI Class Initialized
INFO - 2022-03-25 03:23:34 --> Router Class Initialized
INFO - 2022-03-25 03:23:34 --> Output Class Initialized
INFO - 2022-03-25 03:23:34 --> Security Class Initialized
DEBUG - 2022-03-25 03:23:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 03:23:34 --> Input Class Initialized
INFO - 2022-03-25 03:23:34 --> Language Class Initialized
INFO - 2022-03-25 03:23:34 --> Loader Class Initialized
INFO - 2022-03-25 03:23:34 --> Helper loaded: url_helper
INFO - 2022-03-25 03:23:34 --> Helper loaded: form_helper
INFO - 2022-03-25 03:23:34 --> Helper loaded: common_helper
INFO - 2022-03-25 03:23:34 --> Database Driver Class Initialized
DEBUG - 2022-03-25 03:23:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 03:23:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 03:23:34 --> Controller Class Initialized
INFO - 2022-03-25 03:23:34 --> Form Validation Class Initialized
DEBUG - 2022-03-25 03:23:34 --> Encrypt Class Initialized
INFO - 2022-03-25 03:23:34 --> Model "Patient_model" initialized
INFO - 2022-03-25 03:23:34 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 03:23:34 --> Model "Referredby_model" initialized
INFO - 2022-03-25 03:23:34 --> Model "Prefix_master" initialized
INFO - 2022-03-25 03:23:34 --> Model "Hospital_model" initialized
INFO - 2022-03-25 03:23:34 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-25 03:23:34 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-25 03:23:34 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-25 03:23:34 --> Final output sent to browser
DEBUG - 2022-03-25 03:23:34 --> Total execution time: 0.0385
ERROR - 2022-03-25 03:23:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 03:23:44 --> Config Class Initialized
INFO - 2022-03-25 03:23:44 --> Hooks Class Initialized
DEBUG - 2022-03-25 03:23:44 --> UTF-8 Support Enabled
INFO - 2022-03-25 03:23:44 --> Utf8 Class Initialized
INFO - 2022-03-25 03:23:44 --> URI Class Initialized
INFO - 2022-03-25 03:23:44 --> Router Class Initialized
INFO - 2022-03-25 03:23:44 --> Output Class Initialized
INFO - 2022-03-25 03:23:44 --> Security Class Initialized
DEBUG - 2022-03-25 03:23:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 03:23:44 --> Input Class Initialized
INFO - 2022-03-25 03:23:44 --> Language Class Initialized
INFO - 2022-03-25 03:23:44 --> Loader Class Initialized
INFO - 2022-03-25 03:23:44 --> Helper loaded: url_helper
INFO - 2022-03-25 03:23:44 --> Helper loaded: form_helper
INFO - 2022-03-25 03:23:44 --> Helper loaded: common_helper
INFO - 2022-03-25 03:23:44 --> Database Driver Class Initialized
DEBUG - 2022-03-25 03:23:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 03:23:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 03:23:44 --> Controller Class Initialized
INFO - 2022-03-25 03:23:44 --> Form Validation Class Initialized
DEBUG - 2022-03-25 03:23:44 --> Encrypt Class Initialized
INFO - 2022-03-25 03:23:44 --> Model "Patient_model" initialized
INFO - 2022-03-25 03:23:44 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 03:23:44 --> Model "Referredby_model" initialized
INFO - 2022-03-25 03:23:44 --> Model "Prefix_master" initialized
INFO - 2022-03-25 03:23:44 --> Model "Hospital_model" initialized
INFO - 2022-03-25 03:23:44 --> Upload Class Initialized
INFO - 2022-03-25 03:23:45 --> Final output sent to browser
DEBUG - 2022-03-25 03:23:45 --> Total execution time: 0.0765
ERROR - 2022-03-25 03:23:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 03:23:50 --> Config Class Initialized
INFO - 2022-03-25 03:23:50 --> Hooks Class Initialized
DEBUG - 2022-03-25 03:23:50 --> UTF-8 Support Enabled
INFO - 2022-03-25 03:23:50 --> Utf8 Class Initialized
INFO - 2022-03-25 03:23:50 --> URI Class Initialized
INFO - 2022-03-25 03:23:50 --> Router Class Initialized
INFO - 2022-03-25 03:23:50 --> Output Class Initialized
INFO - 2022-03-25 03:23:50 --> Security Class Initialized
DEBUG - 2022-03-25 03:23:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 03:23:50 --> Input Class Initialized
INFO - 2022-03-25 03:23:50 --> Language Class Initialized
INFO - 2022-03-25 03:23:50 --> Loader Class Initialized
INFO - 2022-03-25 03:23:50 --> Helper loaded: url_helper
INFO - 2022-03-25 03:23:50 --> Helper loaded: form_helper
INFO - 2022-03-25 03:23:50 --> Helper loaded: common_helper
INFO - 2022-03-25 03:23:50 --> Database Driver Class Initialized
DEBUG - 2022-03-25 03:23:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 03:23:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 03:23:50 --> Controller Class Initialized
INFO - 2022-03-25 03:23:50 --> Form Validation Class Initialized
DEBUG - 2022-03-25 03:23:50 --> Encrypt Class Initialized
INFO - 2022-03-25 03:23:50 --> Model "Patient_model" initialized
INFO - 2022-03-25 03:23:50 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 03:23:50 --> Model "Referredby_model" initialized
INFO - 2022-03-25 03:23:50 --> Model "Prefix_master" initialized
INFO - 2022-03-25 03:23:50 --> Model "Hospital_model" initialized
ERROR - 2022-03-25 03:23:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 03:23:51 --> Config Class Initialized
INFO - 2022-03-25 03:23:51 --> Hooks Class Initialized
DEBUG - 2022-03-25 03:23:51 --> UTF-8 Support Enabled
INFO - 2022-03-25 03:23:51 --> Utf8 Class Initialized
INFO - 2022-03-25 03:23:51 --> URI Class Initialized
INFO - 2022-03-25 03:23:51 --> Router Class Initialized
INFO - 2022-03-25 03:23:51 --> Output Class Initialized
INFO - 2022-03-25 03:23:51 --> Security Class Initialized
DEBUG - 2022-03-25 03:23:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 03:23:51 --> Input Class Initialized
INFO - 2022-03-25 03:23:51 --> Language Class Initialized
INFO - 2022-03-25 03:23:51 --> Loader Class Initialized
INFO - 2022-03-25 03:23:51 --> Helper loaded: url_helper
INFO - 2022-03-25 03:23:51 --> Helper loaded: form_helper
INFO - 2022-03-25 03:23:51 --> Helper loaded: common_helper
INFO - 2022-03-25 03:23:51 --> Database Driver Class Initialized
DEBUG - 2022-03-25 03:23:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 03:23:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 03:23:51 --> Controller Class Initialized
INFO - 2022-03-25 03:23:51 --> Form Validation Class Initialized
DEBUG - 2022-03-25 03:23:51 --> Encrypt Class Initialized
INFO - 2022-03-25 03:23:51 --> Model "Patient_model" initialized
INFO - 2022-03-25 03:23:51 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 03:23:51 --> Model "Referredby_model" initialized
INFO - 2022-03-25 03:23:51 --> Model "Prefix_master" initialized
INFO - 2022-03-25 03:23:51 --> Model "Hospital_model" initialized
INFO - 2022-03-25 03:23:51 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-25 03:23:51 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-25 03:23:51 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-25 03:23:51 --> Final output sent to browser
DEBUG - 2022-03-25 03:23:51 --> Total execution time: 0.0401
ERROR - 2022-03-25 03:23:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 03:23:51 --> Config Class Initialized
INFO - 2022-03-25 03:23:51 --> Hooks Class Initialized
DEBUG - 2022-03-25 03:23:51 --> UTF-8 Support Enabled
INFO - 2022-03-25 03:23:51 --> Utf8 Class Initialized
INFO - 2022-03-25 03:23:51 --> URI Class Initialized
INFO - 2022-03-25 03:23:51 --> Router Class Initialized
INFO - 2022-03-25 03:23:51 --> Output Class Initialized
INFO - 2022-03-25 03:23:51 --> Security Class Initialized
DEBUG - 2022-03-25 03:23:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 03:23:51 --> Input Class Initialized
INFO - 2022-03-25 03:23:51 --> Language Class Initialized
INFO - 2022-03-25 03:23:51 --> Loader Class Initialized
INFO - 2022-03-25 03:23:51 --> Helper loaded: url_helper
INFO - 2022-03-25 03:23:51 --> Helper loaded: form_helper
INFO - 2022-03-25 03:23:51 --> Helper loaded: common_helper
INFO - 2022-03-25 03:23:51 --> Database Driver Class Initialized
DEBUG - 2022-03-25 03:23:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 03:23:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 03:23:51 --> Controller Class Initialized
INFO - 2022-03-25 03:23:51 --> Form Validation Class Initialized
DEBUG - 2022-03-25 03:23:51 --> Encrypt Class Initialized
INFO - 2022-03-25 03:23:51 --> Model "Patient_model" initialized
INFO - 2022-03-25 03:23:51 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 03:23:51 --> Model "Prefix_master" initialized
INFO - 2022-03-25 03:23:51 --> Model "Users_model" initialized
INFO - 2022-03-25 03:23:51 --> Model "Hospital_model" initialized
INFO - 2022-03-25 03:23:51 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-25 03:23:51 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-25 03:23:51 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-25 03:23:51 --> Final output sent to browser
DEBUG - 2022-03-25 03:23:51 --> Total execution time: 0.0529
ERROR - 2022-03-25 03:23:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 03:23:58 --> Config Class Initialized
INFO - 2022-03-25 03:23:58 --> Hooks Class Initialized
DEBUG - 2022-03-25 03:23:58 --> UTF-8 Support Enabled
INFO - 2022-03-25 03:23:58 --> Utf8 Class Initialized
INFO - 2022-03-25 03:23:58 --> URI Class Initialized
INFO - 2022-03-25 03:23:58 --> Router Class Initialized
INFO - 2022-03-25 03:23:58 --> Output Class Initialized
INFO - 2022-03-25 03:23:58 --> Security Class Initialized
DEBUG - 2022-03-25 03:23:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 03:23:58 --> Input Class Initialized
INFO - 2022-03-25 03:23:58 --> Language Class Initialized
INFO - 2022-03-25 03:23:58 --> Loader Class Initialized
INFO - 2022-03-25 03:23:58 --> Helper loaded: url_helper
INFO - 2022-03-25 03:23:58 --> Helper loaded: form_helper
INFO - 2022-03-25 03:23:58 --> Helper loaded: common_helper
INFO - 2022-03-25 03:23:58 --> Database Driver Class Initialized
DEBUG - 2022-03-25 03:23:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 03:23:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 03:23:58 --> Controller Class Initialized
INFO - 2022-03-25 03:23:58 --> Form Validation Class Initialized
DEBUG - 2022-03-25 03:23:58 --> Encrypt Class Initialized
INFO - 2022-03-25 03:23:58 --> Model "Patient_model" initialized
INFO - 2022-03-25 03:23:58 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 03:23:58 --> Model "Referredby_model" initialized
INFO - 2022-03-25 03:23:58 --> Model "Prefix_master" initialized
INFO - 2022-03-25 03:23:58 --> Model "Hospital_model" initialized
INFO - 2022-03-25 03:23:58 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-25 03:24:05 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-25 03:24:05 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-25 03:24:07 --> Final output sent to browser
DEBUG - 2022-03-25 03:24:07 --> Total execution time: 7.6614
ERROR - 2022-03-25 03:24:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 03:24:31 --> Config Class Initialized
INFO - 2022-03-25 03:24:31 --> Hooks Class Initialized
DEBUG - 2022-03-25 03:24:31 --> UTF-8 Support Enabled
INFO - 2022-03-25 03:24:31 --> Utf8 Class Initialized
INFO - 2022-03-25 03:24:31 --> URI Class Initialized
INFO - 2022-03-25 03:24:31 --> Router Class Initialized
INFO - 2022-03-25 03:24:31 --> Output Class Initialized
INFO - 2022-03-25 03:24:31 --> Security Class Initialized
DEBUG - 2022-03-25 03:24:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 03:24:31 --> Input Class Initialized
INFO - 2022-03-25 03:24:31 --> Language Class Initialized
INFO - 2022-03-25 03:24:31 --> Loader Class Initialized
INFO - 2022-03-25 03:24:31 --> Helper loaded: url_helper
INFO - 2022-03-25 03:24:31 --> Helper loaded: form_helper
INFO - 2022-03-25 03:24:31 --> Helper loaded: common_helper
INFO - 2022-03-25 03:24:31 --> Database Driver Class Initialized
DEBUG - 2022-03-25 03:24:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 03:24:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 03:24:31 --> Controller Class Initialized
INFO - 2022-03-25 03:24:31 --> Form Validation Class Initialized
DEBUG - 2022-03-25 03:24:31 --> Encrypt Class Initialized
INFO - 2022-03-25 03:24:31 --> Model "Patient_model" initialized
INFO - 2022-03-25 03:24:31 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 03:24:31 --> Model "Prefix_master" initialized
INFO - 2022-03-25 03:24:31 --> Model "Users_model" initialized
INFO - 2022-03-25 03:24:31 --> Model "Hospital_model" initialized
INFO - 2022-03-25 03:24:32 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-25 03:24:32 --> Final output sent to browser
DEBUG - 2022-03-25 03:24:32 --> Total execution time: 0.6499
ERROR - 2022-03-25 03:53:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 03:53:13 --> Config Class Initialized
INFO - 2022-03-25 03:53:13 --> Hooks Class Initialized
DEBUG - 2022-03-25 03:53:13 --> UTF-8 Support Enabled
INFO - 2022-03-25 03:53:13 --> Utf8 Class Initialized
INFO - 2022-03-25 03:53:13 --> URI Class Initialized
INFO - 2022-03-25 03:53:13 --> Router Class Initialized
INFO - 2022-03-25 03:53:13 --> Output Class Initialized
INFO - 2022-03-25 03:53:13 --> Security Class Initialized
DEBUG - 2022-03-25 03:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 03:53:13 --> Input Class Initialized
INFO - 2022-03-25 03:53:13 --> Language Class Initialized
INFO - 2022-03-25 03:53:13 --> Loader Class Initialized
INFO - 2022-03-25 03:53:13 --> Helper loaded: url_helper
INFO - 2022-03-25 03:53:13 --> Helper loaded: form_helper
INFO - 2022-03-25 03:53:13 --> Helper loaded: common_helper
INFO - 2022-03-25 03:53:13 --> Database Driver Class Initialized
DEBUG - 2022-03-25 03:53:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 03:53:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 03:53:13 --> Controller Class Initialized
INFO - 2022-03-25 03:53:13 --> Form Validation Class Initialized
DEBUG - 2022-03-25 03:53:13 --> Encrypt Class Initialized
INFO - 2022-03-25 03:53:13 --> Model "Patient_model" initialized
INFO - 2022-03-25 03:53:13 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 03:53:13 --> Model "Prefix_master" initialized
INFO - 2022-03-25 03:53:13 --> Model "Users_model" initialized
INFO - 2022-03-25 03:53:13 --> Model "Hospital_model" initialized
INFO - 2022-03-25 03:53:13 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-25 03:53:13 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-25 03:53:13 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-25 03:53:13 --> Final output sent to browser
DEBUG - 2022-03-25 03:53:13 --> Total execution time: 0.1868
ERROR - 2022-03-25 03:53:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 03:53:13 --> Config Class Initialized
INFO - 2022-03-25 03:53:13 --> Hooks Class Initialized
DEBUG - 2022-03-25 03:53:13 --> UTF-8 Support Enabled
INFO - 2022-03-25 03:53:13 --> Utf8 Class Initialized
INFO - 2022-03-25 03:53:13 --> URI Class Initialized
INFO - 2022-03-25 03:53:13 --> Router Class Initialized
INFO - 2022-03-25 03:53:13 --> Output Class Initialized
INFO - 2022-03-25 03:53:13 --> Security Class Initialized
DEBUG - 2022-03-25 03:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 03:53:13 --> Input Class Initialized
INFO - 2022-03-25 03:53:13 --> Language Class Initialized
ERROR - 2022-03-25 03:53:13 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-25 03:53:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 03:53:22 --> Config Class Initialized
INFO - 2022-03-25 03:53:22 --> Hooks Class Initialized
DEBUG - 2022-03-25 03:53:22 --> UTF-8 Support Enabled
INFO - 2022-03-25 03:53:22 --> Utf8 Class Initialized
INFO - 2022-03-25 03:53:22 --> URI Class Initialized
INFO - 2022-03-25 03:53:22 --> Router Class Initialized
INFO - 2022-03-25 03:53:22 --> Output Class Initialized
INFO - 2022-03-25 03:53:22 --> Security Class Initialized
DEBUG - 2022-03-25 03:53:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 03:53:22 --> Input Class Initialized
INFO - 2022-03-25 03:53:22 --> Language Class Initialized
INFO - 2022-03-25 03:53:22 --> Loader Class Initialized
INFO - 2022-03-25 03:53:22 --> Helper loaded: url_helper
INFO - 2022-03-25 03:53:22 --> Helper loaded: form_helper
INFO - 2022-03-25 03:53:22 --> Helper loaded: common_helper
INFO - 2022-03-25 03:53:22 --> Database Driver Class Initialized
DEBUG - 2022-03-25 03:53:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 03:53:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 03:53:22 --> Controller Class Initialized
INFO - 2022-03-25 03:53:22 --> Form Validation Class Initialized
DEBUG - 2022-03-25 03:53:22 --> Encrypt Class Initialized
INFO - 2022-03-25 03:53:22 --> Model "Patient_model" initialized
INFO - 2022-03-25 03:53:22 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 03:53:22 --> Model "Referredby_model" initialized
INFO - 2022-03-25 03:53:22 --> Model "Prefix_master" initialized
INFO - 2022-03-25 03:53:22 --> Model "Hospital_model" initialized
INFO - 2022-03-25 03:53:22 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-25 03:53:29 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-25 03:53:29 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
ERROR - 2022-03-25 03:53:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 03:53:30 --> Config Class Initialized
INFO - 2022-03-25 03:53:30 --> Hooks Class Initialized
DEBUG - 2022-03-25 03:53:30 --> UTF-8 Support Enabled
INFO - 2022-03-25 03:53:30 --> Utf8 Class Initialized
INFO - 2022-03-25 03:53:30 --> URI Class Initialized
INFO - 2022-03-25 03:53:30 --> Router Class Initialized
INFO - 2022-03-25 03:53:30 --> Output Class Initialized
INFO - 2022-03-25 03:53:30 --> Security Class Initialized
DEBUG - 2022-03-25 03:53:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 03:53:30 --> Input Class Initialized
INFO - 2022-03-25 03:53:30 --> Language Class Initialized
ERROR - 2022-03-25 03:53:30 --> 404 Page Not Found: Karoclient/usersprofile
INFO - 2022-03-25 03:53:31 --> Final output sent to browser
DEBUG - 2022-03-25 03:53:31 --> Total execution time: 7.0479
ERROR - 2022-03-25 03:58:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 03:58:13 --> Config Class Initialized
INFO - 2022-03-25 03:58:13 --> Hooks Class Initialized
DEBUG - 2022-03-25 03:58:13 --> UTF-8 Support Enabled
INFO - 2022-03-25 03:58:13 --> Utf8 Class Initialized
INFO - 2022-03-25 03:58:13 --> URI Class Initialized
INFO - 2022-03-25 03:58:13 --> Router Class Initialized
INFO - 2022-03-25 03:58:13 --> Output Class Initialized
INFO - 2022-03-25 03:58:13 --> Security Class Initialized
DEBUG - 2022-03-25 03:58:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 03:58:13 --> Input Class Initialized
INFO - 2022-03-25 03:58:13 --> Language Class Initialized
INFO - 2022-03-25 03:58:13 --> Loader Class Initialized
INFO - 2022-03-25 03:58:13 --> Helper loaded: url_helper
INFO - 2022-03-25 03:58:13 --> Helper loaded: form_helper
INFO - 2022-03-25 03:58:13 --> Helper loaded: common_helper
INFO - 2022-03-25 03:58:13 --> Database Driver Class Initialized
DEBUG - 2022-03-25 03:58:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 03:58:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 03:58:13 --> Controller Class Initialized
INFO - 2022-03-25 03:58:13 --> Form Validation Class Initialized
DEBUG - 2022-03-25 03:58:13 --> Encrypt Class Initialized
INFO - 2022-03-25 03:58:13 --> Model "Patient_model" initialized
INFO - 2022-03-25 03:58:13 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 03:58:13 --> Model "Prefix_master" initialized
INFO - 2022-03-25 03:58:13 --> Model "Users_model" initialized
INFO - 2022-03-25 03:58:13 --> Model "Hospital_model" initialized
INFO - 2022-03-25 03:58:13 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-25 03:58:14 --> Final output sent to browser
DEBUG - 2022-03-25 03:58:14 --> Total execution time: 1.1108
ERROR - 2022-03-25 03:58:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 03:58:52 --> Config Class Initialized
INFO - 2022-03-25 03:58:52 --> Hooks Class Initialized
DEBUG - 2022-03-25 03:58:52 --> UTF-8 Support Enabled
INFO - 2022-03-25 03:58:52 --> Utf8 Class Initialized
INFO - 2022-03-25 03:58:52 --> URI Class Initialized
INFO - 2022-03-25 03:58:52 --> Router Class Initialized
INFO - 2022-03-25 03:58:52 --> Output Class Initialized
INFO - 2022-03-25 03:58:52 --> Security Class Initialized
DEBUG - 2022-03-25 03:58:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 03:58:52 --> Input Class Initialized
INFO - 2022-03-25 03:58:52 --> Language Class Initialized
INFO - 2022-03-25 03:58:52 --> Loader Class Initialized
INFO - 2022-03-25 03:58:52 --> Helper loaded: url_helper
INFO - 2022-03-25 03:58:52 --> Helper loaded: form_helper
INFO - 2022-03-25 03:58:52 --> Helper loaded: common_helper
INFO - 2022-03-25 03:58:52 --> Database Driver Class Initialized
DEBUG - 2022-03-25 03:58:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 03:58:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 03:58:52 --> Controller Class Initialized
INFO - 2022-03-25 03:58:52 --> Form Validation Class Initialized
DEBUG - 2022-03-25 03:58:52 --> Encrypt Class Initialized
INFO - 2022-03-25 03:58:52 --> Model "Patient_model" initialized
INFO - 2022-03-25 03:58:52 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 03:58:52 --> Model "Referredby_model" initialized
INFO - 2022-03-25 03:58:52 --> Model "Prefix_master" initialized
INFO - 2022-03-25 03:58:52 --> Model "Hospital_model" initialized
INFO - 2022-03-25 03:58:52 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-25 03:58:52 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-25 03:58:52 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-25 03:58:52 --> Final output sent to browser
DEBUG - 2022-03-25 03:58:52 --> Total execution time: 0.0751
ERROR - 2022-03-25 03:58:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 03:58:52 --> Config Class Initialized
INFO - 2022-03-25 03:58:52 --> Hooks Class Initialized
DEBUG - 2022-03-25 03:58:52 --> UTF-8 Support Enabled
INFO - 2022-03-25 03:58:52 --> Utf8 Class Initialized
INFO - 2022-03-25 03:58:52 --> URI Class Initialized
INFO - 2022-03-25 03:58:52 --> Router Class Initialized
INFO - 2022-03-25 03:58:52 --> Output Class Initialized
INFO - 2022-03-25 03:58:52 --> Security Class Initialized
DEBUG - 2022-03-25 03:58:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 03:58:52 --> Input Class Initialized
INFO - 2022-03-25 03:58:52 --> Language Class Initialized
ERROR - 2022-03-25 03:58:52 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-25 04:04:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 04:04:45 --> Config Class Initialized
INFO - 2022-03-25 04:04:45 --> Hooks Class Initialized
DEBUG - 2022-03-25 04:04:45 --> UTF-8 Support Enabled
INFO - 2022-03-25 04:04:45 --> Utf8 Class Initialized
INFO - 2022-03-25 04:04:45 --> URI Class Initialized
INFO - 2022-03-25 04:04:45 --> Router Class Initialized
INFO - 2022-03-25 04:04:45 --> Output Class Initialized
INFO - 2022-03-25 04:04:45 --> Security Class Initialized
DEBUG - 2022-03-25 04:04:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 04:04:45 --> Input Class Initialized
INFO - 2022-03-25 04:04:45 --> Language Class Initialized
INFO - 2022-03-25 04:04:45 --> Loader Class Initialized
INFO - 2022-03-25 04:04:45 --> Helper loaded: url_helper
INFO - 2022-03-25 04:04:45 --> Helper loaded: form_helper
INFO - 2022-03-25 04:04:45 --> Helper loaded: common_helper
INFO - 2022-03-25 04:04:46 --> Database Driver Class Initialized
DEBUG - 2022-03-25 04:04:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 04:04:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 04:04:46 --> Controller Class Initialized
INFO - 2022-03-25 04:04:46 --> Form Validation Class Initialized
DEBUG - 2022-03-25 04:04:46 --> Encrypt Class Initialized
INFO - 2022-03-25 04:04:46 --> Model "Patient_model" initialized
INFO - 2022-03-25 04:04:46 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 04:04:46 --> Model "Referredby_model" initialized
INFO - 2022-03-25 04:04:46 --> Model "Prefix_master" initialized
INFO - 2022-03-25 04:04:46 --> Model "Hospital_model" initialized
INFO - 2022-03-25 04:04:46 --> Upload Class Initialized
INFO - 2022-03-25 04:04:46 --> Final output sent to browser
DEBUG - 2022-03-25 04:04:46 --> Total execution time: 0.0715
ERROR - 2022-03-25 04:05:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 04:05:03 --> Config Class Initialized
INFO - 2022-03-25 04:05:03 --> Hooks Class Initialized
DEBUG - 2022-03-25 04:05:03 --> UTF-8 Support Enabled
INFO - 2022-03-25 04:05:03 --> Utf8 Class Initialized
INFO - 2022-03-25 04:05:03 --> URI Class Initialized
INFO - 2022-03-25 04:05:03 --> Router Class Initialized
INFO - 2022-03-25 04:05:03 --> Output Class Initialized
INFO - 2022-03-25 04:05:03 --> Security Class Initialized
DEBUG - 2022-03-25 04:05:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 04:05:03 --> Input Class Initialized
INFO - 2022-03-25 04:05:03 --> Language Class Initialized
INFO - 2022-03-25 04:05:03 --> Loader Class Initialized
INFO - 2022-03-25 04:05:03 --> Helper loaded: url_helper
INFO - 2022-03-25 04:05:03 --> Helper loaded: form_helper
INFO - 2022-03-25 04:05:03 --> Helper loaded: common_helper
INFO - 2022-03-25 04:05:03 --> Database Driver Class Initialized
DEBUG - 2022-03-25 04:05:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 04:05:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 04:05:03 --> Controller Class Initialized
INFO - 2022-03-25 04:05:03 --> Form Validation Class Initialized
DEBUG - 2022-03-25 04:05:03 --> Encrypt Class Initialized
INFO - 2022-03-25 04:05:03 --> Model "Patient_model" initialized
INFO - 2022-03-25 04:05:03 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 04:05:03 --> Model "Referredby_model" initialized
INFO - 2022-03-25 04:05:03 --> Model "Prefix_master" initialized
INFO - 2022-03-25 04:05:03 --> Model "Hospital_model" initialized
ERROR - 2022-03-25 04:05:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 04:05:03 --> Config Class Initialized
INFO - 2022-03-25 04:05:03 --> Hooks Class Initialized
DEBUG - 2022-03-25 04:05:03 --> UTF-8 Support Enabled
INFO - 2022-03-25 04:05:03 --> Utf8 Class Initialized
INFO - 2022-03-25 04:05:03 --> URI Class Initialized
INFO - 2022-03-25 04:05:03 --> Router Class Initialized
INFO - 2022-03-25 04:05:03 --> Output Class Initialized
INFO - 2022-03-25 04:05:03 --> Security Class Initialized
DEBUG - 2022-03-25 04:05:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 04:05:03 --> Input Class Initialized
INFO - 2022-03-25 04:05:03 --> Language Class Initialized
INFO - 2022-03-25 04:05:03 --> Loader Class Initialized
INFO - 2022-03-25 04:05:03 --> Helper loaded: url_helper
INFO - 2022-03-25 04:05:03 --> Helper loaded: form_helper
INFO - 2022-03-25 04:05:03 --> Helper loaded: common_helper
INFO - 2022-03-25 04:05:03 --> Database Driver Class Initialized
DEBUG - 2022-03-25 04:05:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 04:05:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 04:05:03 --> Controller Class Initialized
INFO - 2022-03-25 04:05:03 --> Form Validation Class Initialized
DEBUG - 2022-03-25 04:05:03 --> Encrypt Class Initialized
INFO - 2022-03-25 04:05:03 --> Model "Patient_model" initialized
INFO - 2022-03-25 04:05:03 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 04:05:03 --> Model "Referredby_model" initialized
INFO - 2022-03-25 04:05:03 --> Model "Prefix_master" initialized
INFO - 2022-03-25 04:05:03 --> Model "Hospital_model" initialized
INFO - 2022-03-25 04:05:03 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-25 04:05:03 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-25 04:05:03 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-25 04:05:03 --> Final output sent to browser
DEBUG - 2022-03-25 04:05:03 --> Total execution time: 0.0407
ERROR - 2022-03-25 04:05:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 04:05:04 --> Config Class Initialized
INFO - 2022-03-25 04:05:04 --> Hooks Class Initialized
DEBUG - 2022-03-25 04:05:04 --> UTF-8 Support Enabled
INFO - 2022-03-25 04:05:04 --> Utf8 Class Initialized
INFO - 2022-03-25 04:05:04 --> URI Class Initialized
INFO - 2022-03-25 04:05:04 --> Router Class Initialized
INFO - 2022-03-25 04:05:04 --> Output Class Initialized
INFO - 2022-03-25 04:05:04 --> Security Class Initialized
DEBUG - 2022-03-25 04:05:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 04:05:04 --> Input Class Initialized
INFO - 2022-03-25 04:05:04 --> Language Class Initialized
ERROR - 2022-03-25 04:05:04 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-25 04:05:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 04:05:04 --> Config Class Initialized
INFO - 2022-03-25 04:05:04 --> Hooks Class Initialized
DEBUG - 2022-03-25 04:05:04 --> UTF-8 Support Enabled
INFO - 2022-03-25 04:05:04 --> Utf8 Class Initialized
INFO - 2022-03-25 04:05:04 --> URI Class Initialized
INFO - 2022-03-25 04:05:04 --> Router Class Initialized
INFO - 2022-03-25 04:05:04 --> Output Class Initialized
INFO - 2022-03-25 04:05:04 --> Security Class Initialized
DEBUG - 2022-03-25 04:05:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 04:05:04 --> Input Class Initialized
INFO - 2022-03-25 04:05:04 --> Language Class Initialized
INFO - 2022-03-25 04:05:04 --> Loader Class Initialized
INFO - 2022-03-25 04:05:04 --> Helper loaded: url_helper
INFO - 2022-03-25 04:05:04 --> Helper loaded: form_helper
INFO - 2022-03-25 04:05:04 --> Helper loaded: common_helper
INFO - 2022-03-25 04:05:04 --> Database Driver Class Initialized
DEBUG - 2022-03-25 04:05:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 04:05:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 04:05:04 --> Controller Class Initialized
INFO - 2022-03-25 04:05:04 --> Form Validation Class Initialized
DEBUG - 2022-03-25 04:05:04 --> Encrypt Class Initialized
INFO - 2022-03-25 04:05:04 --> Model "Patient_model" initialized
INFO - 2022-03-25 04:05:04 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 04:05:04 --> Model "Prefix_master" initialized
INFO - 2022-03-25 04:05:04 --> Model "Users_model" initialized
INFO - 2022-03-25 04:05:04 --> Model "Hospital_model" initialized
INFO - 2022-03-25 04:05:04 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-25 04:05:04 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-25 04:05:04 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-25 04:05:04 --> Final output sent to browser
DEBUG - 2022-03-25 04:05:04 --> Total execution time: 0.0532
ERROR - 2022-03-25 04:05:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 04:05:04 --> Config Class Initialized
INFO - 2022-03-25 04:05:04 --> Hooks Class Initialized
DEBUG - 2022-03-25 04:05:04 --> UTF-8 Support Enabled
INFO - 2022-03-25 04:05:04 --> Utf8 Class Initialized
INFO - 2022-03-25 04:05:04 --> URI Class Initialized
INFO - 2022-03-25 04:05:04 --> Router Class Initialized
INFO - 2022-03-25 04:05:04 --> Output Class Initialized
INFO - 2022-03-25 04:05:04 --> Security Class Initialized
DEBUG - 2022-03-25 04:05:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 04:05:04 --> Input Class Initialized
INFO - 2022-03-25 04:05:04 --> Language Class Initialized
ERROR - 2022-03-25 04:05:04 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-25 04:05:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 04:05:07 --> Config Class Initialized
INFO - 2022-03-25 04:05:07 --> Hooks Class Initialized
DEBUG - 2022-03-25 04:05:07 --> UTF-8 Support Enabled
INFO - 2022-03-25 04:05:07 --> Utf8 Class Initialized
INFO - 2022-03-25 04:05:07 --> URI Class Initialized
INFO - 2022-03-25 04:05:07 --> Router Class Initialized
INFO - 2022-03-25 04:05:07 --> Output Class Initialized
INFO - 2022-03-25 04:05:07 --> Security Class Initialized
DEBUG - 2022-03-25 04:05:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 04:05:07 --> Input Class Initialized
INFO - 2022-03-25 04:05:07 --> Language Class Initialized
INFO - 2022-03-25 04:05:07 --> Loader Class Initialized
INFO - 2022-03-25 04:05:07 --> Helper loaded: url_helper
INFO - 2022-03-25 04:05:07 --> Helper loaded: form_helper
INFO - 2022-03-25 04:05:07 --> Helper loaded: common_helper
INFO - 2022-03-25 04:05:07 --> Database Driver Class Initialized
DEBUG - 2022-03-25 04:05:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 04:05:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 04:05:07 --> Controller Class Initialized
INFO - 2022-03-25 04:05:07 --> Form Validation Class Initialized
DEBUG - 2022-03-25 04:05:07 --> Encrypt Class Initialized
INFO - 2022-03-25 04:05:07 --> Model "Patient_model" initialized
INFO - 2022-03-25 04:05:07 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 04:05:07 --> Model "Referredby_model" initialized
INFO - 2022-03-25 04:05:07 --> Model "Prefix_master" initialized
INFO - 2022-03-25 04:05:07 --> Model "Hospital_model" initialized
INFO - 2022-03-25 04:05:07 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-25 04:05:07 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-25 04:05:07 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-25 04:05:07 --> Final output sent to browser
DEBUG - 2022-03-25 04:05:07 --> Total execution time: 0.0340
ERROR - 2022-03-25 04:05:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 04:05:08 --> Config Class Initialized
INFO - 2022-03-25 04:05:08 --> Hooks Class Initialized
DEBUG - 2022-03-25 04:05:08 --> UTF-8 Support Enabled
INFO - 2022-03-25 04:05:08 --> Utf8 Class Initialized
INFO - 2022-03-25 04:05:08 --> URI Class Initialized
INFO - 2022-03-25 04:05:08 --> Router Class Initialized
INFO - 2022-03-25 04:05:08 --> Output Class Initialized
INFO - 2022-03-25 04:05:08 --> Security Class Initialized
DEBUG - 2022-03-25 04:05:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 04:05:08 --> Input Class Initialized
INFO - 2022-03-25 04:05:08 --> Language Class Initialized
ERROR - 2022-03-25 04:05:08 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-25 04:05:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 04:05:24 --> Config Class Initialized
INFO - 2022-03-25 04:05:24 --> Hooks Class Initialized
DEBUG - 2022-03-25 04:05:24 --> UTF-8 Support Enabled
INFO - 2022-03-25 04:05:24 --> Utf8 Class Initialized
INFO - 2022-03-25 04:05:24 --> URI Class Initialized
INFO - 2022-03-25 04:05:24 --> Router Class Initialized
INFO - 2022-03-25 04:05:24 --> Output Class Initialized
INFO - 2022-03-25 04:05:24 --> Security Class Initialized
DEBUG - 2022-03-25 04:05:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 04:05:24 --> Input Class Initialized
INFO - 2022-03-25 04:05:24 --> Language Class Initialized
INFO - 2022-03-25 04:05:24 --> Loader Class Initialized
INFO - 2022-03-25 04:05:24 --> Helper loaded: url_helper
INFO - 2022-03-25 04:05:24 --> Helper loaded: form_helper
INFO - 2022-03-25 04:05:24 --> Helper loaded: common_helper
INFO - 2022-03-25 04:05:24 --> Database Driver Class Initialized
DEBUG - 2022-03-25 04:05:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 04:05:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 04:05:24 --> Controller Class Initialized
INFO - 2022-03-25 04:05:24 --> Form Validation Class Initialized
DEBUG - 2022-03-25 04:05:24 --> Encrypt Class Initialized
INFO - 2022-03-25 04:05:24 --> Model "Patient_model" initialized
INFO - 2022-03-25 04:05:24 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 04:05:24 --> Model "Referredby_model" initialized
INFO - 2022-03-25 04:05:24 --> Model "Prefix_master" initialized
INFO - 2022-03-25 04:05:24 --> Model "Hospital_model" initialized
ERROR - 2022-03-25 04:05:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 04:05:25 --> Config Class Initialized
INFO - 2022-03-25 04:05:25 --> Hooks Class Initialized
DEBUG - 2022-03-25 04:05:25 --> UTF-8 Support Enabled
INFO - 2022-03-25 04:05:25 --> Utf8 Class Initialized
INFO - 2022-03-25 04:05:25 --> URI Class Initialized
INFO - 2022-03-25 04:05:25 --> Router Class Initialized
INFO - 2022-03-25 04:05:25 --> Output Class Initialized
INFO - 2022-03-25 04:05:25 --> Security Class Initialized
DEBUG - 2022-03-25 04:05:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 04:05:25 --> Input Class Initialized
INFO - 2022-03-25 04:05:25 --> Language Class Initialized
INFO - 2022-03-25 04:05:25 --> Loader Class Initialized
INFO - 2022-03-25 04:05:25 --> Helper loaded: url_helper
INFO - 2022-03-25 04:05:25 --> Helper loaded: form_helper
INFO - 2022-03-25 04:05:25 --> Helper loaded: common_helper
INFO - 2022-03-25 04:05:25 --> Database Driver Class Initialized
DEBUG - 2022-03-25 04:05:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 04:05:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 04:05:25 --> Controller Class Initialized
INFO - 2022-03-25 04:05:25 --> Form Validation Class Initialized
DEBUG - 2022-03-25 04:05:25 --> Encrypt Class Initialized
INFO - 2022-03-25 04:05:25 --> Model "Patient_model" initialized
INFO - 2022-03-25 04:05:25 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 04:05:25 --> Model "Referredby_model" initialized
INFO - 2022-03-25 04:05:25 --> Model "Prefix_master" initialized
INFO - 2022-03-25 04:05:25 --> Model "Hospital_model" initialized
INFO - 2022-03-25 04:05:25 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-25 04:05:25 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-25 04:05:25 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-25 04:05:25 --> Final output sent to browser
DEBUG - 2022-03-25 04:05:25 --> Total execution time: 0.0552
ERROR - 2022-03-25 04:05:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 04:05:25 --> Config Class Initialized
INFO - 2022-03-25 04:05:25 --> Hooks Class Initialized
DEBUG - 2022-03-25 04:05:25 --> UTF-8 Support Enabled
INFO - 2022-03-25 04:05:25 --> Utf8 Class Initialized
INFO - 2022-03-25 04:05:25 --> URI Class Initialized
INFO - 2022-03-25 04:05:25 --> Router Class Initialized
INFO - 2022-03-25 04:05:25 --> Output Class Initialized
INFO - 2022-03-25 04:05:25 --> Security Class Initialized
DEBUG - 2022-03-25 04:05:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 04:05:25 --> Input Class Initialized
INFO - 2022-03-25 04:05:25 --> Language Class Initialized
ERROR - 2022-03-25 04:05:25 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-25 04:05:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 04:05:26 --> Config Class Initialized
INFO - 2022-03-25 04:05:26 --> Hooks Class Initialized
DEBUG - 2022-03-25 04:05:26 --> UTF-8 Support Enabled
INFO - 2022-03-25 04:05:26 --> Utf8 Class Initialized
INFO - 2022-03-25 04:05:26 --> URI Class Initialized
INFO - 2022-03-25 04:05:26 --> Router Class Initialized
INFO - 2022-03-25 04:05:26 --> Output Class Initialized
INFO - 2022-03-25 04:05:26 --> Security Class Initialized
DEBUG - 2022-03-25 04:05:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 04:05:26 --> Input Class Initialized
INFO - 2022-03-25 04:05:26 --> Language Class Initialized
INFO - 2022-03-25 04:05:26 --> Loader Class Initialized
INFO - 2022-03-25 04:05:26 --> Helper loaded: url_helper
INFO - 2022-03-25 04:05:26 --> Helper loaded: form_helper
INFO - 2022-03-25 04:05:26 --> Helper loaded: common_helper
INFO - 2022-03-25 04:05:26 --> Database Driver Class Initialized
DEBUG - 2022-03-25 04:05:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 04:05:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 04:05:26 --> Controller Class Initialized
INFO - 2022-03-25 04:05:26 --> Form Validation Class Initialized
DEBUG - 2022-03-25 04:05:26 --> Encrypt Class Initialized
INFO - 2022-03-25 04:05:26 --> Model "Patient_model" initialized
INFO - 2022-03-25 04:05:26 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 04:05:26 --> Model "Prefix_master" initialized
INFO - 2022-03-25 04:05:26 --> Model "Users_model" initialized
INFO - 2022-03-25 04:05:26 --> Model "Hospital_model" initialized
INFO - 2022-03-25 04:05:26 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-25 04:05:26 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-25 04:05:26 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-25 04:05:26 --> Final output sent to browser
DEBUG - 2022-03-25 04:05:26 --> Total execution time: 0.0679
ERROR - 2022-03-25 04:05:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 04:05:26 --> Config Class Initialized
INFO - 2022-03-25 04:05:26 --> Hooks Class Initialized
DEBUG - 2022-03-25 04:05:26 --> UTF-8 Support Enabled
INFO - 2022-03-25 04:05:26 --> Utf8 Class Initialized
INFO - 2022-03-25 04:05:26 --> URI Class Initialized
INFO - 2022-03-25 04:05:26 --> Router Class Initialized
INFO - 2022-03-25 04:05:26 --> Output Class Initialized
INFO - 2022-03-25 04:05:26 --> Security Class Initialized
DEBUG - 2022-03-25 04:05:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 04:05:26 --> Input Class Initialized
INFO - 2022-03-25 04:05:26 --> Language Class Initialized
ERROR - 2022-03-25 04:05:26 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-25 04:05:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 04:05:39 --> Config Class Initialized
INFO - 2022-03-25 04:05:39 --> Hooks Class Initialized
DEBUG - 2022-03-25 04:05:39 --> UTF-8 Support Enabled
INFO - 2022-03-25 04:05:39 --> Utf8 Class Initialized
INFO - 2022-03-25 04:05:39 --> URI Class Initialized
INFO - 2022-03-25 04:05:39 --> Router Class Initialized
INFO - 2022-03-25 04:05:39 --> Output Class Initialized
INFO - 2022-03-25 04:05:39 --> Security Class Initialized
DEBUG - 2022-03-25 04:05:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 04:05:39 --> Input Class Initialized
INFO - 2022-03-25 04:05:39 --> Language Class Initialized
INFO - 2022-03-25 04:05:39 --> Loader Class Initialized
INFO - 2022-03-25 04:05:39 --> Helper loaded: url_helper
INFO - 2022-03-25 04:05:39 --> Helper loaded: form_helper
INFO - 2022-03-25 04:05:39 --> Helper loaded: common_helper
INFO - 2022-03-25 04:05:39 --> Database Driver Class Initialized
DEBUG - 2022-03-25 04:05:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 04:05:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 04:05:39 --> Controller Class Initialized
INFO - 2022-03-25 04:05:39 --> Form Validation Class Initialized
DEBUG - 2022-03-25 04:05:39 --> Encrypt Class Initialized
INFO - 2022-03-25 04:05:39 --> Model "Patient_model" initialized
INFO - 2022-03-25 04:05:39 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 04:05:39 --> Model "Referredby_model" initialized
INFO - 2022-03-25 04:05:39 --> Model "Prefix_master" initialized
INFO - 2022-03-25 04:05:39 --> Model "Hospital_model" initialized
INFO - 2022-03-25 04:05:39 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-25 04:05:47 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-25 04:05:47 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
ERROR - 2022-03-25 04:05:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 04:05:48 --> Config Class Initialized
INFO - 2022-03-25 04:05:48 --> Hooks Class Initialized
DEBUG - 2022-03-25 04:05:48 --> UTF-8 Support Enabled
INFO - 2022-03-25 04:05:48 --> Utf8 Class Initialized
INFO - 2022-03-25 04:05:48 --> URI Class Initialized
INFO - 2022-03-25 04:05:48 --> Router Class Initialized
INFO - 2022-03-25 04:05:48 --> Output Class Initialized
INFO - 2022-03-25 04:05:48 --> Security Class Initialized
DEBUG - 2022-03-25 04:05:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 04:05:48 --> Input Class Initialized
INFO - 2022-03-25 04:05:48 --> Language Class Initialized
ERROR - 2022-03-25 04:05:48 --> 404 Page Not Found: Karoclient/usersprofile
INFO - 2022-03-25 04:05:48 --> Final output sent to browser
DEBUG - 2022-03-25 04:05:48 --> Total execution time: 7.3970
ERROR - 2022-03-25 04:06:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 04:06:26 --> Config Class Initialized
INFO - 2022-03-25 04:06:26 --> Hooks Class Initialized
DEBUG - 2022-03-25 04:06:26 --> UTF-8 Support Enabled
INFO - 2022-03-25 04:06:26 --> Utf8 Class Initialized
INFO - 2022-03-25 04:06:26 --> URI Class Initialized
INFO - 2022-03-25 04:06:26 --> Router Class Initialized
INFO - 2022-03-25 04:06:26 --> Output Class Initialized
INFO - 2022-03-25 04:06:26 --> Security Class Initialized
DEBUG - 2022-03-25 04:06:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 04:06:26 --> Input Class Initialized
INFO - 2022-03-25 04:06:26 --> Language Class Initialized
INFO - 2022-03-25 04:06:26 --> Loader Class Initialized
INFO - 2022-03-25 04:06:26 --> Helper loaded: url_helper
INFO - 2022-03-25 04:06:26 --> Helper loaded: form_helper
INFO - 2022-03-25 04:06:26 --> Helper loaded: common_helper
INFO - 2022-03-25 04:06:26 --> Database Driver Class Initialized
DEBUG - 2022-03-25 04:06:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 04:06:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 04:06:26 --> Controller Class Initialized
INFO - 2022-03-25 04:06:26 --> Form Validation Class Initialized
DEBUG - 2022-03-25 04:06:26 --> Encrypt Class Initialized
INFO - 2022-03-25 04:06:26 --> Model "Patient_model" initialized
INFO - 2022-03-25 04:06:26 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 04:06:26 --> Model "Prefix_master" initialized
INFO - 2022-03-25 04:06:26 --> Model "Users_model" initialized
INFO - 2022-03-25 04:06:26 --> Model "Hospital_model" initialized
INFO - 2022-03-25 04:06:26 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-25 04:06:27 --> Final output sent to browser
DEBUG - 2022-03-25 04:06:27 --> Total execution time: 1.0451
ERROR - 2022-03-25 04:08:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 04:08:45 --> Config Class Initialized
INFO - 2022-03-25 04:08:45 --> Hooks Class Initialized
DEBUG - 2022-03-25 04:08:45 --> UTF-8 Support Enabled
INFO - 2022-03-25 04:08:45 --> Utf8 Class Initialized
INFO - 2022-03-25 04:08:45 --> URI Class Initialized
INFO - 2022-03-25 04:08:45 --> Router Class Initialized
INFO - 2022-03-25 04:08:45 --> Output Class Initialized
INFO - 2022-03-25 04:08:45 --> Security Class Initialized
DEBUG - 2022-03-25 04:08:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 04:08:45 --> Input Class Initialized
INFO - 2022-03-25 04:08:45 --> Language Class Initialized
INFO - 2022-03-25 04:08:45 --> Loader Class Initialized
INFO - 2022-03-25 04:08:45 --> Helper loaded: url_helper
INFO - 2022-03-25 04:08:45 --> Helper loaded: form_helper
INFO - 2022-03-25 04:08:45 --> Helper loaded: common_helper
INFO - 2022-03-25 04:08:45 --> Database Driver Class Initialized
DEBUG - 2022-03-25 04:08:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 04:08:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 04:08:45 --> Controller Class Initialized
INFO - 2022-03-25 04:08:45 --> Form Validation Class Initialized
DEBUG - 2022-03-25 04:08:45 --> Encrypt Class Initialized
INFO - 2022-03-25 04:08:45 --> Model "Patient_model" initialized
INFO - 2022-03-25 04:08:45 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 04:08:45 --> Model "Referredby_model" initialized
INFO - 2022-03-25 04:08:45 --> Model "Prefix_master" initialized
INFO - 2022-03-25 04:08:45 --> Model "Hospital_model" initialized
INFO - 2022-03-25 04:08:45 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-25 04:08:45 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-25 04:08:45 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-25 04:08:45 --> Final output sent to browser
DEBUG - 2022-03-25 04:08:45 --> Total execution time: 0.0927
ERROR - 2022-03-25 04:08:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 04:08:46 --> Config Class Initialized
INFO - 2022-03-25 04:08:46 --> Hooks Class Initialized
DEBUG - 2022-03-25 04:08:46 --> UTF-8 Support Enabled
INFO - 2022-03-25 04:08:46 --> Utf8 Class Initialized
INFO - 2022-03-25 04:08:46 --> URI Class Initialized
INFO - 2022-03-25 04:08:46 --> Router Class Initialized
INFO - 2022-03-25 04:08:46 --> Output Class Initialized
INFO - 2022-03-25 04:08:46 --> Security Class Initialized
DEBUG - 2022-03-25 04:08:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 04:08:46 --> Input Class Initialized
INFO - 2022-03-25 04:08:46 --> Language Class Initialized
ERROR - 2022-03-25 04:08:46 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-25 04:11:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 04:11:23 --> Config Class Initialized
INFO - 2022-03-25 04:11:23 --> Hooks Class Initialized
DEBUG - 2022-03-25 04:11:23 --> UTF-8 Support Enabled
INFO - 2022-03-25 04:11:23 --> Utf8 Class Initialized
INFO - 2022-03-25 04:11:23 --> URI Class Initialized
INFO - 2022-03-25 04:11:23 --> Router Class Initialized
INFO - 2022-03-25 04:11:23 --> Output Class Initialized
INFO - 2022-03-25 04:11:23 --> Security Class Initialized
DEBUG - 2022-03-25 04:11:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 04:11:23 --> Input Class Initialized
INFO - 2022-03-25 04:11:23 --> Language Class Initialized
INFO - 2022-03-25 04:11:23 --> Loader Class Initialized
INFO - 2022-03-25 04:11:23 --> Helper loaded: url_helper
INFO - 2022-03-25 04:11:23 --> Helper loaded: form_helper
INFO - 2022-03-25 04:11:23 --> Helper loaded: common_helper
INFO - 2022-03-25 04:11:23 --> Database Driver Class Initialized
DEBUG - 2022-03-25 04:11:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 04:11:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 04:11:23 --> Controller Class Initialized
INFO - 2022-03-25 04:11:23 --> Form Validation Class Initialized
DEBUG - 2022-03-25 04:11:23 --> Encrypt Class Initialized
INFO - 2022-03-25 04:11:23 --> Model "Patient_model" initialized
INFO - 2022-03-25 04:11:23 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 04:11:23 --> Model "Referredby_model" initialized
INFO - 2022-03-25 04:11:23 --> Model "Prefix_master" initialized
INFO - 2022-03-25 04:11:23 --> Model "Hospital_model" initialized
INFO - 2022-03-25 04:11:23 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-25 04:11:23 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-25 04:11:23 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-25 04:11:23 --> Final output sent to browser
DEBUG - 2022-03-25 04:11:23 --> Total execution time: 0.0788
ERROR - 2022-03-25 04:11:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 04:11:23 --> Config Class Initialized
INFO - 2022-03-25 04:11:23 --> Hooks Class Initialized
DEBUG - 2022-03-25 04:11:23 --> UTF-8 Support Enabled
INFO - 2022-03-25 04:11:23 --> Utf8 Class Initialized
INFO - 2022-03-25 04:11:23 --> URI Class Initialized
INFO - 2022-03-25 04:11:23 --> Router Class Initialized
INFO - 2022-03-25 04:11:23 --> Output Class Initialized
INFO - 2022-03-25 04:11:23 --> Security Class Initialized
DEBUG - 2022-03-25 04:11:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 04:11:23 --> Input Class Initialized
INFO - 2022-03-25 04:11:23 --> Language Class Initialized
ERROR - 2022-03-25 04:11:23 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-25 04:13:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 04:13:37 --> Config Class Initialized
INFO - 2022-03-25 04:13:37 --> Hooks Class Initialized
DEBUG - 2022-03-25 04:13:37 --> UTF-8 Support Enabled
INFO - 2022-03-25 04:13:37 --> Utf8 Class Initialized
INFO - 2022-03-25 04:13:37 --> URI Class Initialized
INFO - 2022-03-25 04:13:37 --> Router Class Initialized
INFO - 2022-03-25 04:13:37 --> Output Class Initialized
INFO - 2022-03-25 04:13:37 --> Security Class Initialized
DEBUG - 2022-03-25 04:13:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 04:13:37 --> Input Class Initialized
INFO - 2022-03-25 04:13:37 --> Language Class Initialized
INFO - 2022-03-25 04:13:37 --> Loader Class Initialized
INFO - 2022-03-25 04:13:37 --> Helper loaded: url_helper
INFO - 2022-03-25 04:13:37 --> Helper loaded: form_helper
INFO - 2022-03-25 04:13:37 --> Helper loaded: common_helper
INFO - 2022-03-25 04:13:37 --> Database Driver Class Initialized
DEBUG - 2022-03-25 04:13:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 04:13:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 04:13:37 --> Controller Class Initialized
INFO - 2022-03-25 04:13:37 --> Form Validation Class Initialized
DEBUG - 2022-03-25 04:13:37 --> Encrypt Class Initialized
INFO - 2022-03-25 04:13:37 --> Model "Patient_model" initialized
INFO - 2022-03-25 04:13:37 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 04:13:37 --> Model "Referredby_model" initialized
INFO - 2022-03-25 04:13:37 --> Model "Prefix_master" initialized
INFO - 2022-03-25 04:13:37 --> Model "Hospital_model" initialized
INFO - 2022-03-25 04:13:38 --> Final output sent to browser
DEBUG - 2022-03-25 04:13:38 --> Total execution time: 0.0828
ERROR - 2022-03-25 04:14:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 04:14:49 --> Config Class Initialized
INFO - 2022-03-25 04:14:49 --> Hooks Class Initialized
DEBUG - 2022-03-25 04:14:49 --> UTF-8 Support Enabled
INFO - 2022-03-25 04:14:49 --> Utf8 Class Initialized
INFO - 2022-03-25 04:14:49 --> URI Class Initialized
INFO - 2022-03-25 04:14:49 --> Router Class Initialized
INFO - 2022-03-25 04:14:49 --> Output Class Initialized
INFO - 2022-03-25 04:14:49 --> Security Class Initialized
DEBUG - 2022-03-25 04:14:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 04:14:49 --> Input Class Initialized
INFO - 2022-03-25 04:14:49 --> Language Class Initialized
INFO - 2022-03-25 04:14:49 --> Loader Class Initialized
INFO - 2022-03-25 04:14:49 --> Helper loaded: url_helper
INFO - 2022-03-25 04:14:49 --> Helper loaded: form_helper
INFO - 2022-03-25 04:14:49 --> Helper loaded: common_helper
INFO - 2022-03-25 04:14:49 --> Database Driver Class Initialized
DEBUG - 2022-03-25 04:14:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 04:14:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 04:14:49 --> Controller Class Initialized
INFO - 2022-03-25 04:14:49 --> Form Validation Class Initialized
DEBUG - 2022-03-25 04:14:49 --> Encrypt Class Initialized
INFO - 2022-03-25 04:14:49 --> Model "Patient_model" initialized
INFO - 2022-03-25 04:14:49 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 04:14:49 --> Model "Referredby_model" initialized
INFO - 2022-03-25 04:14:49 --> Model "Prefix_master" initialized
INFO - 2022-03-25 04:14:49 --> Model "Hospital_model" initialized
INFO - 2022-03-25 04:14:49 --> Final output sent to browser
DEBUG - 2022-03-25 04:14:49 --> Total execution time: 0.0181
ERROR - 2022-03-25 04:20:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 04:20:57 --> Config Class Initialized
INFO - 2022-03-25 04:20:57 --> Hooks Class Initialized
DEBUG - 2022-03-25 04:20:57 --> UTF-8 Support Enabled
INFO - 2022-03-25 04:20:57 --> Utf8 Class Initialized
INFO - 2022-03-25 04:20:57 --> URI Class Initialized
INFO - 2022-03-25 04:20:57 --> Router Class Initialized
INFO - 2022-03-25 04:20:57 --> Output Class Initialized
INFO - 2022-03-25 04:20:57 --> Security Class Initialized
DEBUG - 2022-03-25 04:20:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 04:20:57 --> Input Class Initialized
INFO - 2022-03-25 04:20:57 --> Language Class Initialized
INFO - 2022-03-25 04:20:57 --> Loader Class Initialized
INFO - 2022-03-25 04:20:57 --> Helper loaded: url_helper
INFO - 2022-03-25 04:20:57 --> Helper loaded: form_helper
INFO - 2022-03-25 04:20:57 --> Helper loaded: common_helper
INFO - 2022-03-25 04:20:57 --> Database Driver Class Initialized
DEBUG - 2022-03-25 04:20:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 04:20:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 04:20:57 --> Controller Class Initialized
INFO - 2022-03-25 04:20:57 --> Form Validation Class Initialized
DEBUG - 2022-03-25 04:20:57 --> Encrypt Class Initialized
INFO - 2022-03-25 04:20:57 --> Model "Patient_model" initialized
INFO - 2022-03-25 04:20:57 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 04:20:57 --> Model "Prefix_master" initialized
INFO - 2022-03-25 04:20:57 --> Model "Users_model" initialized
INFO - 2022-03-25 04:20:57 --> Model "Hospital_model" initialized
INFO - 2022-03-25 04:20:57 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-25 04:20:57 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-25 04:20:57 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-25 04:20:57 --> Final output sent to browser
DEBUG - 2022-03-25 04:20:57 --> Total execution time: 0.1430
ERROR - 2022-03-25 04:20:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 04:20:57 --> Config Class Initialized
INFO - 2022-03-25 04:20:57 --> Hooks Class Initialized
DEBUG - 2022-03-25 04:20:57 --> UTF-8 Support Enabled
INFO - 2022-03-25 04:20:57 --> Utf8 Class Initialized
INFO - 2022-03-25 04:20:57 --> URI Class Initialized
INFO - 2022-03-25 04:20:57 --> Router Class Initialized
INFO - 2022-03-25 04:20:57 --> Output Class Initialized
INFO - 2022-03-25 04:20:57 --> Security Class Initialized
DEBUG - 2022-03-25 04:20:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 04:20:57 --> Input Class Initialized
INFO - 2022-03-25 04:20:57 --> Language Class Initialized
ERROR - 2022-03-25 04:20:57 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-25 05:02:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 05:02:37 --> Config Class Initialized
INFO - 2022-03-25 05:02:37 --> Hooks Class Initialized
DEBUG - 2022-03-25 05:02:37 --> UTF-8 Support Enabled
INFO - 2022-03-25 05:02:37 --> Utf8 Class Initialized
INFO - 2022-03-25 05:02:37 --> URI Class Initialized
INFO - 2022-03-25 05:02:37 --> Router Class Initialized
INFO - 2022-03-25 05:02:37 --> Output Class Initialized
INFO - 2022-03-25 05:02:37 --> Security Class Initialized
DEBUG - 2022-03-25 05:02:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 05:02:37 --> Input Class Initialized
INFO - 2022-03-25 05:02:37 --> Language Class Initialized
INFO - 2022-03-25 05:02:37 --> Loader Class Initialized
INFO - 2022-03-25 05:02:37 --> Helper loaded: url_helper
INFO - 2022-03-25 05:02:37 --> Helper loaded: form_helper
INFO - 2022-03-25 05:02:37 --> Helper loaded: common_helper
INFO - 2022-03-25 05:02:38 --> Database Driver Class Initialized
DEBUG - 2022-03-25 05:02:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 05:02:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 05:02:38 --> Controller Class Initialized
INFO - 2022-03-25 05:02:38 --> Form Validation Class Initialized
DEBUG - 2022-03-25 05:02:38 --> Encrypt Class Initialized
INFO - 2022-03-25 05:02:38 --> Model "Patient_model" initialized
INFO - 2022-03-25 05:02:38 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 05:02:38 --> Model "Referredby_model" initialized
INFO - 2022-03-25 05:02:38 --> Model "Prefix_master" initialized
INFO - 2022-03-25 05:02:38 --> Model "Hospital_model" initialized
INFO - 2022-03-25 05:02:38 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-25 05:02:38 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-25 05:02:38 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-25 05:02:38 --> Final output sent to browser
DEBUG - 2022-03-25 05:02:38 --> Total execution time: 1.0285
ERROR - 2022-03-25 05:02:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 05:02:44 --> Config Class Initialized
INFO - 2022-03-25 05:02:44 --> Hooks Class Initialized
DEBUG - 2022-03-25 05:02:44 --> UTF-8 Support Enabled
INFO - 2022-03-25 05:02:44 --> Utf8 Class Initialized
INFO - 2022-03-25 05:02:44 --> URI Class Initialized
INFO - 2022-03-25 05:02:44 --> Router Class Initialized
INFO - 2022-03-25 05:02:44 --> Output Class Initialized
INFO - 2022-03-25 05:02:44 --> Security Class Initialized
DEBUG - 2022-03-25 05:02:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 05:02:44 --> Input Class Initialized
INFO - 2022-03-25 05:02:44 --> Language Class Initialized
ERROR - 2022-03-25 05:02:44 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-25 05:37:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 05:37:39 --> Config Class Initialized
INFO - 2022-03-25 05:37:39 --> Hooks Class Initialized
DEBUG - 2022-03-25 05:37:39 --> UTF-8 Support Enabled
INFO - 2022-03-25 05:37:39 --> Utf8 Class Initialized
INFO - 2022-03-25 05:37:39 --> URI Class Initialized
INFO - 2022-03-25 05:37:39 --> Router Class Initialized
INFO - 2022-03-25 05:37:39 --> Output Class Initialized
INFO - 2022-03-25 05:37:39 --> Security Class Initialized
DEBUG - 2022-03-25 05:37:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 05:37:40 --> Input Class Initialized
INFO - 2022-03-25 05:37:40 --> Language Class Initialized
INFO - 2022-03-25 05:37:40 --> Loader Class Initialized
INFO - 2022-03-25 05:37:40 --> Helper loaded: url_helper
INFO - 2022-03-25 05:37:40 --> Helper loaded: form_helper
INFO - 2022-03-25 05:37:40 --> Helper loaded: common_helper
INFO - 2022-03-25 05:37:40 --> Database Driver Class Initialized
DEBUG - 2022-03-25 05:37:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 05:37:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 05:37:40 --> Controller Class Initialized
ERROR - 2022-03-25 05:37:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 05:37:40 --> Config Class Initialized
INFO - 2022-03-25 05:37:40 --> Hooks Class Initialized
DEBUG - 2022-03-25 05:37:40 --> UTF-8 Support Enabled
INFO - 2022-03-25 05:37:40 --> Utf8 Class Initialized
INFO - 2022-03-25 05:37:40 --> URI Class Initialized
INFO - 2022-03-25 05:37:40 --> Router Class Initialized
INFO - 2022-03-25 05:37:40 --> Output Class Initialized
INFO - 2022-03-25 05:37:40 --> Security Class Initialized
DEBUG - 2022-03-25 05:37:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 05:37:40 --> Input Class Initialized
INFO - 2022-03-25 05:37:40 --> Language Class Initialized
INFO - 2022-03-25 05:37:40 --> Loader Class Initialized
INFO - 2022-03-25 05:37:40 --> Helper loaded: url_helper
INFO - 2022-03-25 05:37:40 --> Helper loaded: form_helper
INFO - 2022-03-25 05:37:40 --> Helper loaded: common_helper
INFO - 2022-03-25 05:37:40 --> Database Driver Class Initialized
DEBUG - 2022-03-25 05:37:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 05:37:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 05:37:40 --> Controller Class Initialized
INFO - 2022-03-25 05:37:40 --> Form Validation Class Initialized
DEBUG - 2022-03-25 05:37:40 --> Encrypt Class Initialized
DEBUG - 2022-03-25 05:37:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 05:37:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-25 05:37:40 --> Email Class Initialized
INFO - 2022-03-25 05:37:40 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-25 05:37:40 --> Calendar Class Initialized
INFO - 2022-03-25 05:37:40 --> Model "Login_model" initialized
INFO - 2022-03-25 05:37:40 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-25 05:37:40 --> Final output sent to browser
DEBUG - 2022-03-25 05:37:40 --> Total execution time: 0.0448
ERROR - 2022-03-25 05:38:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 05:38:01 --> Config Class Initialized
INFO - 2022-03-25 05:38:01 --> Hooks Class Initialized
DEBUG - 2022-03-25 05:38:01 --> UTF-8 Support Enabled
INFO - 2022-03-25 05:38:01 --> Utf8 Class Initialized
INFO - 2022-03-25 05:38:01 --> URI Class Initialized
INFO - 2022-03-25 05:38:01 --> Router Class Initialized
INFO - 2022-03-25 05:38:01 --> Output Class Initialized
INFO - 2022-03-25 05:38:01 --> Security Class Initialized
DEBUG - 2022-03-25 05:38:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 05:38:01 --> Input Class Initialized
INFO - 2022-03-25 05:38:01 --> Language Class Initialized
INFO - 2022-03-25 05:38:01 --> Loader Class Initialized
INFO - 2022-03-25 05:38:01 --> Helper loaded: url_helper
INFO - 2022-03-25 05:38:01 --> Helper loaded: form_helper
INFO - 2022-03-25 05:38:01 --> Helper loaded: common_helper
INFO - 2022-03-25 05:38:01 --> Database Driver Class Initialized
DEBUG - 2022-03-25 05:38:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 05:38:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 05:38:01 --> Controller Class Initialized
ERROR - 2022-03-25 05:38:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 05:38:01 --> Config Class Initialized
INFO - 2022-03-25 05:38:01 --> Hooks Class Initialized
DEBUG - 2022-03-25 05:38:01 --> UTF-8 Support Enabled
INFO - 2022-03-25 05:38:01 --> Utf8 Class Initialized
INFO - 2022-03-25 05:38:01 --> URI Class Initialized
INFO - 2022-03-25 05:38:01 --> Router Class Initialized
INFO - 2022-03-25 05:38:01 --> Output Class Initialized
INFO - 2022-03-25 05:38:01 --> Security Class Initialized
DEBUG - 2022-03-25 05:38:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 05:38:01 --> Input Class Initialized
INFO - 2022-03-25 05:38:01 --> Language Class Initialized
INFO - 2022-03-25 05:38:01 --> Loader Class Initialized
INFO - 2022-03-25 05:38:01 --> Helper loaded: url_helper
INFO - 2022-03-25 05:38:01 --> Helper loaded: form_helper
INFO - 2022-03-25 05:38:01 --> Helper loaded: common_helper
INFO - 2022-03-25 05:38:01 --> Database Driver Class Initialized
DEBUG - 2022-03-25 05:38:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 05:38:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 05:38:01 --> Controller Class Initialized
INFO - 2022-03-25 05:38:01 --> Form Validation Class Initialized
DEBUG - 2022-03-25 05:38:01 --> Encrypt Class Initialized
DEBUG - 2022-03-25 05:38:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 05:38:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-25 05:38:01 --> Email Class Initialized
INFO - 2022-03-25 05:38:01 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-25 05:38:01 --> Calendar Class Initialized
INFO - 2022-03-25 05:38:01 --> Model "Login_model" initialized
INFO - 2022-03-25 05:38:01 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-25 05:38:01 --> Final output sent to browser
DEBUG - 2022-03-25 05:38:01 --> Total execution time: 0.0089
ERROR - 2022-03-25 05:38:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 05:38:46 --> Config Class Initialized
INFO - 2022-03-25 05:38:46 --> Hooks Class Initialized
DEBUG - 2022-03-25 05:38:46 --> UTF-8 Support Enabled
INFO - 2022-03-25 05:38:46 --> Utf8 Class Initialized
INFO - 2022-03-25 05:38:46 --> URI Class Initialized
INFO - 2022-03-25 05:38:46 --> Router Class Initialized
INFO - 2022-03-25 05:38:46 --> Output Class Initialized
INFO - 2022-03-25 05:38:46 --> Security Class Initialized
DEBUG - 2022-03-25 05:38:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 05:38:46 --> Input Class Initialized
INFO - 2022-03-25 05:38:46 --> Language Class Initialized
INFO - 2022-03-25 05:38:46 --> Loader Class Initialized
INFO - 2022-03-25 05:38:46 --> Helper loaded: url_helper
INFO - 2022-03-25 05:38:46 --> Helper loaded: form_helper
INFO - 2022-03-25 05:38:46 --> Helper loaded: common_helper
INFO - 2022-03-25 05:38:46 --> Database Driver Class Initialized
DEBUG - 2022-03-25 05:38:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 05:38:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 05:38:46 --> Controller Class Initialized
ERROR - 2022-03-25 05:38:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 05:38:46 --> Config Class Initialized
INFO - 2022-03-25 05:38:46 --> Hooks Class Initialized
DEBUG - 2022-03-25 05:38:46 --> UTF-8 Support Enabled
INFO - 2022-03-25 05:38:46 --> Utf8 Class Initialized
INFO - 2022-03-25 05:38:46 --> URI Class Initialized
INFO - 2022-03-25 05:38:46 --> Router Class Initialized
INFO - 2022-03-25 05:38:46 --> Output Class Initialized
INFO - 2022-03-25 05:38:46 --> Security Class Initialized
DEBUG - 2022-03-25 05:38:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 05:38:46 --> Input Class Initialized
INFO - 2022-03-25 05:38:46 --> Language Class Initialized
INFO - 2022-03-25 05:38:46 --> Loader Class Initialized
INFO - 2022-03-25 05:38:46 --> Helper loaded: url_helper
INFO - 2022-03-25 05:38:46 --> Helper loaded: form_helper
INFO - 2022-03-25 05:38:46 --> Helper loaded: common_helper
INFO - 2022-03-25 05:38:46 --> Database Driver Class Initialized
DEBUG - 2022-03-25 05:38:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 05:38:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 05:38:46 --> Controller Class Initialized
INFO - 2022-03-25 05:38:46 --> Form Validation Class Initialized
DEBUG - 2022-03-25 05:38:46 --> Encrypt Class Initialized
DEBUG - 2022-03-25 05:38:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 05:38:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-25 05:38:46 --> Email Class Initialized
INFO - 2022-03-25 05:38:46 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-25 05:38:46 --> Calendar Class Initialized
INFO - 2022-03-25 05:38:46 --> Model "Login_model" initialized
INFO - 2022-03-25 05:38:46 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-25 05:38:46 --> Final output sent to browser
DEBUG - 2022-03-25 05:38:46 --> Total execution time: 0.0066
ERROR - 2022-03-25 05:53:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 05:53:08 --> Config Class Initialized
INFO - 2022-03-25 05:53:08 --> Hooks Class Initialized
DEBUG - 2022-03-25 05:53:08 --> UTF-8 Support Enabled
INFO - 2022-03-25 05:53:08 --> Utf8 Class Initialized
INFO - 2022-03-25 05:53:08 --> URI Class Initialized
INFO - 2022-03-25 05:53:08 --> Router Class Initialized
INFO - 2022-03-25 05:53:08 --> Output Class Initialized
INFO - 2022-03-25 05:53:08 --> Security Class Initialized
DEBUG - 2022-03-25 05:53:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 05:53:08 --> Input Class Initialized
INFO - 2022-03-25 05:53:08 --> Language Class Initialized
INFO - 2022-03-25 05:53:08 --> Loader Class Initialized
INFO - 2022-03-25 05:53:08 --> Helper loaded: url_helper
INFO - 2022-03-25 05:53:08 --> Helper loaded: form_helper
INFO - 2022-03-25 05:53:08 --> Helper loaded: common_helper
INFO - 2022-03-25 05:53:08 --> Database Driver Class Initialized
DEBUG - 2022-03-25 05:53:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 05:53:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 05:53:08 --> Controller Class Initialized
ERROR - 2022-03-25 05:53:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 05:53:08 --> Config Class Initialized
INFO - 2022-03-25 05:53:08 --> Hooks Class Initialized
DEBUG - 2022-03-25 05:53:08 --> UTF-8 Support Enabled
INFO - 2022-03-25 05:53:08 --> Utf8 Class Initialized
INFO - 2022-03-25 05:53:08 --> URI Class Initialized
INFO - 2022-03-25 05:53:08 --> Router Class Initialized
INFO - 2022-03-25 05:53:08 --> Output Class Initialized
INFO - 2022-03-25 05:53:08 --> Security Class Initialized
DEBUG - 2022-03-25 05:53:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 05:53:08 --> Input Class Initialized
INFO - 2022-03-25 05:53:08 --> Language Class Initialized
INFO - 2022-03-25 05:53:08 --> Loader Class Initialized
INFO - 2022-03-25 05:53:08 --> Helper loaded: url_helper
INFO - 2022-03-25 05:53:08 --> Helper loaded: form_helper
INFO - 2022-03-25 05:53:08 --> Helper loaded: common_helper
INFO - 2022-03-25 05:53:08 --> Database Driver Class Initialized
DEBUG - 2022-03-25 05:53:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 05:53:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 05:53:08 --> Controller Class Initialized
INFO - 2022-03-25 05:53:08 --> Form Validation Class Initialized
DEBUG - 2022-03-25 05:53:08 --> Encrypt Class Initialized
DEBUG - 2022-03-25 05:53:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 05:53:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-25 05:53:08 --> Email Class Initialized
INFO - 2022-03-25 05:53:08 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-25 05:53:08 --> Calendar Class Initialized
INFO - 2022-03-25 05:53:08 --> Model "Login_model" initialized
INFO - 2022-03-25 05:53:08 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-25 05:53:08 --> Final output sent to browser
DEBUG - 2022-03-25 05:53:08 --> Total execution time: 0.0181
ERROR - 2022-03-25 05:53:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 05:53:29 --> Config Class Initialized
INFO - 2022-03-25 05:53:29 --> Hooks Class Initialized
DEBUG - 2022-03-25 05:53:29 --> UTF-8 Support Enabled
INFO - 2022-03-25 05:53:29 --> Utf8 Class Initialized
INFO - 2022-03-25 05:53:29 --> URI Class Initialized
INFO - 2022-03-25 05:53:29 --> Router Class Initialized
INFO - 2022-03-25 05:53:29 --> Output Class Initialized
INFO - 2022-03-25 05:53:29 --> Security Class Initialized
DEBUG - 2022-03-25 05:53:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 05:53:29 --> Input Class Initialized
INFO - 2022-03-25 05:53:29 --> Language Class Initialized
INFO - 2022-03-25 05:53:29 --> Loader Class Initialized
INFO - 2022-03-25 05:53:29 --> Helper loaded: url_helper
INFO - 2022-03-25 05:53:29 --> Helper loaded: form_helper
INFO - 2022-03-25 05:53:29 --> Helper loaded: common_helper
INFO - 2022-03-25 05:53:29 --> Database Driver Class Initialized
DEBUG - 2022-03-25 05:53:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 05:53:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 05:53:29 --> Controller Class Initialized
INFO - 2022-03-25 05:53:29 --> Form Validation Class Initialized
DEBUG - 2022-03-25 05:53:29 --> Encrypt Class Initialized
DEBUG - 2022-03-25 05:53:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 05:53:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-25 05:53:29 --> Email Class Initialized
INFO - 2022-03-25 05:53:29 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-25 05:53:29 --> Calendar Class Initialized
INFO - 2022-03-25 05:53:29 --> Model "Login_model" initialized
INFO - 2022-03-25 05:53:29 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-03-25 05:53:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 05:53:29 --> Config Class Initialized
INFO - 2022-03-25 05:53:29 --> Hooks Class Initialized
DEBUG - 2022-03-25 05:53:29 --> UTF-8 Support Enabled
INFO - 2022-03-25 05:53:29 --> Utf8 Class Initialized
INFO - 2022-03-25 05:53:29 --> URI Class Initialized
INFO - 2022-03-25 05:53:29 --> Router Class Initialized
INFO - 2022-03-25 05:53:29 --> Output Class Initialized
INFO - 2022-03-25 05:53:29 --> Security Class Initialized
DEBUG - 2022-03-25 05:53:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 05:53:29 --> Input Class Initialized
INFO - 2022-03-25 05:53:29 --> Language Class Initialized
INFO - 2022-03-25 05:53:29 --> Loader Class Initialized
INFO - 2022-03-25 05:53:29 --> Helper loaded: url_helper
INFO - 2022-03-25 05:53:29 --> Helper loaded: form_helper
INFO - 2022-03-25 05:53:29 --> Helper loaded: common_helper
INFO - 2022-03-25 05:53:29 --> Database Driver Class Initialized
DEBUG - 2022-03-25 05:53:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 05:53:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 05:53:29 --> Controller Class Initialized
INFO - 2022-03-25 05:53:29 --> Form Validation Class Initialized
DEBUG - 2022-03-25 05:53:29 --> Encrypt Class Initialized
INFO - 2022-03-25 05:53:29 --> Model "Login_model" initialized
INFO - 2022-03-25 05:53:29 --> Model "Dashboard_model" initialized
INFO - 2022-03-25 05:53:29 --> Model "Case_model" initialized
INFO - 2022-03-25 05:53:30 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-25 05:53:30 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2022-03-25 05:53:30 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-25 05:53:30 --> Final output sent to browser
DEBUG - 2022-03-25 05:53:30 --> Total execution time: 0.9387
ERROR - 2022-03-25 05:53:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 05:53:40 --> Config Class Initialized
INFO - 2022-03-25 05:53:40 --> Hooks Class Initialized
DEBUG - 2022-03-25 05:53:40 --> UTF-8 Support Enabled
INFO - 2022-03-25 05:53:40 --> Utf8 Class Initialized
INFO - 2022-03-25 05:53:40 --> URI Class Initialized
INFO - 2022-03-25 05:53:40 --> Router Class Initialized
INFO - 2022-03-25 05:53:40 --> Output Class Initialized
INFO - 2022-03-25 05:53:40 --> Security Class Initialized
DEBUG - 2022-03-25 05:53:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 05:53:40 --> Input Class Initialized
INFO - 2022-03-25 05:53:40 --> Language Class Initialized
INFO - 2022-03-25 05:53:40 --> Loader Class Initialized
INFO - 2022-03-25 05:53:40 --> Helper loaded: url_helper
INFO - 2022-03-25 05:53:40 --> Helper loaded: form_helper
INFO - 2022-03-25 05:53:40 --> Helper loaded: common_helper
INFO - 2022-03-25 05:53:40 --> Database Driver Class Initialized
DEBUG - 2022-03-25 05:53:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 05:53:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 05:53:40 --> Controller Class Initialized
INFO - 2022-03-25 05:53:40 --> Form Validation Class Initialized
DEBUG - 2022-03-25 05:53:40 --> Encrypt Class Initialized
INFO - 2022-03-25 05:53:40 --> Model "Patient_model" initialized
INFO - 2022-03-25 05:53:40 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 05:53:40 --> Model "Referredby_model" initialized
INFO - 2022-03-25 05:53:40 --> Model "Prefix_master" initialized
INFO - 2022-03-25 05:53:40 --> Model "Hospital_model" initialized
INFO - 2022-03-25 05:53:40 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-25 05:53:40 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-25 05:53:40 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-25 05:53:40 --> Final output sent to browser
DEBUG - 2022-03-25 05:53:40 --> Total execution time: 0.0501
ERROR - 2022-03-25 05:53:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 05:53:50 --> Config Class Initialized
INFO - 2022-03-25 05:53:50 --> Hooks Class Initialized
DEBUG - 2022-03-25 05:53:50 --> UTF-8 Support Enabled
INFO - 2022-03-25 05:53:50 --> Utf8 Class Initialized
INFO - 2022-03-25 05:53:50 --> URI Class Initialized
INFO - 2022-03-25 05:53:50 --> Router Class Initialized
INFO - 2022-03-25 05:53:50 --> Output Class Initialized
INFO - 2022-03-25 05:53:50 --> Security Class Initialized
DEBUG - 2022-03-25 05:53:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 05:53:50 --> Input Class Initialized
INFO - 2022-03-25 05:53:50 --> Language Class Initialized
INFO - 2022-03-25 05:53:50 --> Loader Class Initialized
INFO - 2022-03-25 05:53:50 --> Helper loaded: url_helper
INFO - 2022-03-25 05:53:50 --> Helper loaded: form_helper
INFO - 2022-03-25 05:53:50 --> Helper loaded: common_helper
INFO - 2022-03-25 05:53:50 --> Database Driver Class Initialized
DEBUG - 2022-03-25 05:53:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 05:53:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 05:53:50 --> Controller Class Initialized
INFO - 2022-03-25 05:53:50 --> Form Validation Class Initialized
DEBUG - 2022-03-25 05:53:50 --> Encrypt Class Initialized
INFO - 2022-03-25 05:53:50 --> Model "Patient_model" initialized
INFO - 2022-03-25 05:53:50 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 05:53:50 --> Model "Referredby_model" initialized
INFO - 2022-03-25 05:53:50 --> Model "Prefix_master" initialized
INFO - 2022-03-25 05:53:50 --> Model "Hospital_model" initialized
INFO - 2022-03-25 05:53:50 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-25 05:53:50 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-25 05:53:50 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-25 05:53:50 --> Final output sent to browser
DEBUG - 2022-03-25 05:53:50 --> Total execution time: 0.0261
ERROR - 2022-03-25 05:55:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 05:55:13 --> Config Class Initialized
INFO - 2022-03-25 05:55:13 --> Hooks Class Initialized
DEBUG - 2022-03-25 05:55:13 --> UTF-8 Support Enabled
INFO - 2022-03-25 05:55:13 --> Utf8 Class Initialized
INFO - 2022-03-25 05:55:13 --> URI Class Initialized
INFO - 2022-03-25 05:55:13 --> Router Class Initialized
INFO - 2022-03-25 05:55:13 --> Output Class Initialized
INFO - 2022-03-25 05:55:13 --> Security Class Initialized
DEBUG - 2022-03-25 05:55:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 05:55:13 --> Input Class Initialized
INFO - 2022-03-25 05:55:13 --> Language Class Initialized
INFO - 2022-03-25 05:55:13 --> Loader Class Initialized
INFO - 2022-03-25 05:55:13 --> Helper loaded: url_helper
INFO - 2022-03-25 05:55:13 --> Helper loaded: form_helper
INFO - 2022-03-25 05:55:13 --> Helper loaded: common_helper
INFO - 2022-03-25 05:55:13 --> Database Driver Class Initialized
DEBUG - 2022-03-25 05:55:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 05:55:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 05:55:13 --> Controller Class Initialized
INFO - 2022-03-25 05:55:13 --> Model "Referredby_model" initialized
INFO - 2022-03-25 05:55:13 --> Final output sent to browser
DEBUG - 2022-03-25 05:55:13 --> Total execution time: 0.0122
ERROR - 2022-03-25 05:55:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 05:55:19 --> Config Class Initialized
INFO - 2022-03-25 05:55:19 --> Hooks Class Initialized
DEBUG - 2022-03-25 05:55:19 --> UTF-8 Support Enabled
INFO - 2022-03-25 05:55:19 --> Utf8 Class Initialized
INFO - 2022-03-25 05:55:19 --> URI Class Initialized
INFO - 2022-03-25 05:55:19 --> Router Class Initialized
INFO - 2022-03-25 05:55:19 --> Output Class Initialized
INFO - 2022-03-25 05:55:19 --> Security Class Initialized
DEBUG - 2022-03-25 05:55:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 05:55:19 --> Input Class Initialized
INFO - 2022-03-25 05:55:19 --> Language Class Initialized
INFO - 2022-03-25 05:55:19 --> Loader Class Initialized
INFO - 2022-03-25 05:55:19 --> Helper loaded: url_helper
INFO - 2022-03-25 05:55:19 --> Helper loaded: form_helper
INFO - 2022-03-25 05:55:19 --> Helper loaded: common_helper
INFO - 2022-03-25 05:55:19 --> Database Driver Class Initialized
DEBUG - 2022-03-25 05:55:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 05:55:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 05:55:19 --> Controller Class Initialized
INFO - 2022-03-25 05:55:19 --> Model "Referredby_model" initialized
INFO - 2022-03-25 05:55:19 --> Final output sent to browser
DEBUG - 2022-03-25 05:55:19 --> Total execution time: 0.0069
ERROR - 2022-03-25 05:56:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 05:56:11 --> Config Class Initialized
INFO - 2022-03-25 05:56:11 --> Hooks Class Initialized
DEBUG - 2022-03-25 05:56:11 --> UTF-8 Support Enabled
INFO - 2022-03-25 05:56:11 --> Utf8 Class Initialized
INFO - 2022-03-25 05:56:11 --> URI Class Initialized
INFO - 2022-03-25 05:56:11 --> Router Class Initialized
INFO - 2022-03-25 05:56:11 --> Output Class Initialized
INFO - 2022-03-25 05:56:11 --> Security Class Initialized
DEBUG - 2022-03-25 05:56:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 05:56:11 --> Input Class Initialized
INFO - 2022-03-25 05:56:11 --> Language Class Initialized
INFO - 2022-03-25 05:56:11 --> Loader Class Initialized
INFO - 2022-03-25 05:56:11 --> Helper loaded: url_helper
INFO - 2022-03-25 05:56:11 --> Helper loaded: form_helper
INFO - 2022-03-25 05:56:11 --> Helper loaded: common_helper
INFO - 2022-03-25 05:56:11 --> Database Driver Class Initialized
DEBUG - 2022-03-25 05:56:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 05:56:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 05:56:11 --> Controller Class Initialized
INFO - 2022-03-25 05:56:11 --> Form Validation Class Initialized
DEBUG - 2022-03-25 05:56:11 --> Encrypt Class Initialized
INFO - 2022-03-25 05:56:11 --> Model "Patient_model" initialized
INFO - 2022-03-25 05:56:11 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 05:56:11 --> Model "Referredby_model" initialized
INFO - 2022-03-25 05:56:11 --> Model "Prefix_master" initialized
INFO - 2022-03-25 05:56:11 --> Model "Hospital_model" initialized
INFO - 2022-03-25 05:56:11 --> Final output sent to browser
DEBUG - 2022-03-25 05:56:11 --> Total execution time: 0.0179
ERROR - 2022-03-25 06:05:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 06:05:09 --> Config Class Initialized
INFO - 2022-03-25 06:05:09 --> Hooks Class Initialized
DEBUG - 2022-03-25 06:05:09 --> UTF-8 Support Enabled
INFO - 2022-03-25 06:05:09 --> Utf8 Class Initialized
INFO - 2022-03-25 06:05:09 --> URI Class Initialized
INFO - 2022-03-25 06:05:09 --> Router Class Initialized
INFO - 2022-03-25 06:05:09 --> Output Class Initialized
INFO - 2022-03-25 06:05:09 --> Security Class Initialized
DEBUG - 2022-03-25 06:05:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 06:05:09 --> Input Class Initialized
INFO - 2022-03-25 06:05:09 --> Language Class Initialized
INFO - 2022-03-25 06:05:09 --> Loader Class Initialized
INFO - 2022-03-25 06:05:09 --> Helper loaded: url_helper
INFO - 2022-03-25 06:05:09 --> Helper loaded: form_helper
INFO - 2022-03-25 06:05:09 --> Helper loaded: common_helper
INFO - 2022-03-25 06:05:09 --> Database Driver Class Initialized
DEBUG - 2022-03-25 06:05:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 06:05:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 06:05:09 --> Controller Class Initialized
ERROR - 2022-03-25 06:05:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 06:05:10 --> Config Class Initialized
INFO - 2022-03-25 06:05:10 --> Hooks Class Initialized
DEBUG - 2022-03-25 06:05:10 --> UTF-8 Support Enabled
INFO - 2022-03-25 06:05:10 --> Utf8 Class Initialized
INFO - 2022-03-25 06:05:10 --> URI Class Initialized
INFO - 2022-03-25 06:05:10 --> Router Class Initialized
INFO - 2022-03-25 06:05:10 --> Output Class Initialized
INFO - 2022-03-25 06:05:10 --> Security Class Initialized
DEBUG - 2022-03-25 06:05:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 06:05:10 --> Input Class Initialized
INFO - 2022-03-25 06:05:10 --> Language Class Initialized
INFO - 2022-03-25 06:05:10 --> Loader Class Initialized
INFO - 2022-03-25 06:05:10 --> Helper loaded: url_helper
INFO - 2022-03-25 06:05:10 --> Helper loaded: form_helper
INFO - 2022-03-25 06:05:10 --> Helper loaded: common_helper
INFO - 2022-03-25 06:05:10 --> Database Driver Class Initialized
DEBUG - 2022-03-25 06:05:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 06:05:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 06:05:10 --> Controller Class Initialized
INFO - 2022-03-25 06:05:10 --> Form Validation Class Initialized
DEBUG - 2022-03-25 06:05:10 --> Encrypt Class Initialized
DEBUG - 2022-03-25 06:05:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 06:05:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-25 06:05:10 --> Email Class Initialized
INFO - 2022-03-25 06:05:10 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-25 06:05:10 --> Calendar Class Initialized
INFO - 2022-03-25 06:05:10 --> Model "Login_model" initialized
INFO - 2022-03-25 06:05:10 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-25 06:05:10 --> Final output sent to browser
DEBUG - 2022-03-25 06:05:10 --> Total execution time: 0.0284
ERROR - 2022-03-25 06:05:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 06:05:13 --> Config Class Initialized
INFO - 2022-03-25 06:05:13 --> Hooks Class Initialized
DEBUG - 2022-03-25 06:05:13 --> UTF-8 Support Enabled
INFO - 2022-03-25 06:05:13 --> Utf8 Class Initialized
INFO - 2022-03-25 06:05:13 --> URI Class Initialized
INFO - 2022-03-25 06:05:13 --> Router Class Initialized
INFO - 2022-03-25 06:05:13 --> Output Class Initialized
INFO - 2022-03-25 06:05:13 --> Security Class Initialized
DEBUG - 2022-03-25 06:05:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 06:05:13 --> Input Class Initialized
INFO - 2022-03-25 06:05:13 --> Language Class Initialized
INFO - 2022-03-25 06:05:13 --> Loader Class Initialized
INFO - 2022-03-25 06:05:13 --> Helper loaded: url_helper
INFO - 2022-03-25 06:05:13 --> Helper loaded: form_helper
INFO - 2022-03-25 06:05:13 --> Helper loaded: common_helper
INFO - 2022-03-25 06:05:13 --> Database Driver Class Initialized
DEBUG - 2022-03-25 06:05:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 06:05:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 06:05:13 --> Controller Class Initialized
INFO - 2022-03-25 06:05:13 --> Form Validation Class Initialized
DEBUG - 2022-03-25 06:05:13 --> Encrypt Class Initialized
DEBUG - 2022-03-25 06:05:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 06:05:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-25 06:05:13 --> Email Class Initialized
INFO - 2022-03-25 06:05:13 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-25 06:05:13 --> Calendar Class Initialized
INFO - 2022-03-25 06:05:13 --> Model "Login_model" initialized
INFO - 2022-03-25 06:05:13 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-03-25 06:05:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 06:05:14 --> Config Class Initialized
INFO - 2022-03-25 06:05:14 --> Hooks Class Initialized
DEBUG - 2022-03-25 06:05:14 --> UTF-8 Support Enabled
INFO - 2022-03-25 06:05:14 --> Utf8 Class Initialized
INFO - 2022-03-25 06:05:14 --> URI Class Initialized
INFO - 2022-03-25 06:05:14 --> Router Class Initialized
INFO - 2022-03-25 06:05:14 --> Output Class Initialized
INFO - 2022-03-25 06:05:14 --> Security Class Initialized
DEBUG - 2022-03-25 06:05:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 06:05:14 --> Input Class Initialized
INFO - 2022-03-25 06:05:14 --> Language Class Initialized
INFO - 2022-03-25 06:05:14 --> Loader Class Initialized
INFO - 2022-03-25 06:05:14 --> Helper loaded: url_helper
INFO - 2022-03-25 06:05:14 --> Helper loaded: form_helper
INFO - 2022-03-25 06:05:14 --> Helper loaded: common_helper
INFO - 2022-03-25 06:05:14 --> Database Driver Class Initialized
DEBUG - 2022-03-25 06:05:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 06:05:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 06:05:14 --> Controller Class Initialized
INFO - 2022-03-25 06:05:14 --> Form Validation Class Initialized
DEBUG - 2022-03-25 06:05:14 --> Encrypt Class Initialized
INFO - 2022-03-25 06:05:14 --> Model "Login_model" initialized
INFO - 2022-03-25 06:05:14 --> Model "Dashboard_model" initialized
INFO - 2022-03-25 06:05:14 --> Model "Case_model" initialized
INFO - 2022-03-25 06:05:23 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-25 06:05:35 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2022-03-25 06:05:35 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-25 06:05:36 --> Final output sent to browser
DEBUG - 2022-03-25 06:05:36 --> Total execution time: 21.8414
ERROR - 2022-03-25 06:05:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 06:05:48 --> Config Class Initialized
INFO - 2022-03-25 06:05:48 --> Hooks Class Initialized
DEBUG - 2022-03-25 06:05:48 --> UTF-8 Support Enabled
INFO - 2022-03-25 06:05:48 --> Utf8 Class Initialized
INFO - 2022-03-25 06:05:48 --> URI Class Initialized
INFO - 2022-03-25 06:05:48 --> Router Class Initialized
INFO - 2022-03-25 06:05:48 --> Output Class Initialized
INFO - 2022-03-25 06:05:48 --> Security Class Initialized
DEBUG - 2022-03-25 06:05:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 06:05:48 --> Input Class Initialized
INFO - 2022-03-25 06:05:48 --> Language Class Initialized
INFO - 2022-03-25 06:05:48 --> Loader Class Initialized
INFO - 2022-03-25 06:05:48 --> Helper loaded: url_helper
INFO - 2022-03-25 06:05:48 --> Helper loaded: form_helper
INFO - 2022-03-25 06:05:48 --> Helper loaded: common_helper
INFO - 2022-03-25 06:05:48 --> Database Driver Class Initialized
DEBUG - 2022-03-25 06:05:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 06:05:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 06:05:48 --> Controller Class Initialized
INFO - 2022-03-25 06:05:48 --> Form Validation Class Initialized
DEBUG - 2022-03-25 06:05:48 --> Encrypt Class Initialized
INFO - 2022-03-25 06:05:48 --> Model "Patient_model" initialized
INFO - 2022-03-25 06:05:48 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 06:05:48 --> Model "Referredby_model" initialized
INFO - 2022-03-25 06:05:48 --> Model "Prefix_master" initialized
INFO - 2022-03-25 06:05:48 --> Model "Hospital_model" initialized
INFO - 2022-03-25 06:05:48 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-25 06:05:55 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-25 06:05:55 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-25 06:05:57 --> Final output sent to browser
DEBUG - 2022-03-25 06:05:57 --> Total execution time: 7.2277
ERROR - 2022-03-25 06:06:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 06:06:22 --> Config Class Initialized
INFO - 2022-03-25 06:06:22 --> Hooks Class Initialized
DEBUG - 2022-03-25 06:06:22 --> UTF-8 Support Enabled
INFO - 2022-03-25 06:06:22 --> Utf8 Class Initialized
INFO - 2022-03-25 06:06:22 --> URI Class Initialized
INFO - 2022-03-25 06:06:22 --> Router Class Initialized
INFO - 2022-03-25 06:06:22 --> Output Class Initialized
INFO - 2022-03-25 06:06:22 --> Security Class Initialized
DEBUG - 2022-03-25 06:06:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 06:06:22 --> Input Class Initialized
INFO - 2022-03-25 06:06:22 --> Language Class Initialized
INFO - 2022-03-25 06:06:22 --> Loader Class Initialized
INFO - 2022-03-25 06:06:22 --> Helper loaded: url_helper
INFO - 2022-03-25 06:06:22 --> Helper loaded: form_helper
INFO - 2022-03-25 06:06:22 --> Helper loaded: common_helper
INFO - 2022-03-25 06:06:22 --> Database Driver Class Initialized
DEBUG - 2022-03-25 06:06:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 06:06:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 06:06:22 --> Controller Class Initialized
INFO - 2022-03-25 06:06:22 --> Form Validation Class Initialized
DEBUG - 2022-03-25 06:06:22 --> Encrypt Class Initialized
INFO - 2022-03-25 06:06:22 --> Model "Patient_model" initialized
INFO - 2022-03-25 06:06:22 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 06:06:22 --> Model "Referredby_model" initialized
INFO - 2022-03-25 06:06:22 --> Model "Prefix_master" initialized
INFO - 2022-03-25 06:06:22 --> Model "Hospital_model" initialized
ERROR - 2022-03-25 06:06:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 06:06:22 --> Config Class Initialized
INFO - 2022-03-25 06:06:22 --> Hooks Class Initialized
DEBUG - 2022-03-25 06:06:22 --> UTF-8 Support Enabled
INFO - 2022-03-25 06:06:22 --> Utf8 Class Initialized
INFO - 2022-03-25 06:06:22 --> URI Class Initialized
INFO - 2022-03-25 06:06:22 --> Router Class Initialized
INFO - 2022-03-25 06:06:22 --> Output Class Initialized
INFO - 2022-03-25 06:06:22 --> Security Class Initialized
DEBUG - 2022-03-25 06:06:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 06:06:22 --> Input Class Initialized
INFO - 2022-03-25 06:06:22 --> Language Class Initialized
INFO - 2022-03-25 06:06:22 --> Loader Class Initialized
INFO - 2022-03-25 06:06:22 --> Helper loaded: url_helper
INFO - 2022-03-25 06:06:22 --> Helper loaded: form_helper
INFO - 2022-03-25 06:06:22 --> Helper loaded: common_helper
INFO - 2022-03-25 06:06:22 --> Database Driver Class Initialized
DEBUG - 2022-03-25 06:06:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 06:06:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 06:06:22 --> Controller Class Initialized
INFO - 2022-03-25 06:06:22 --> Form Validation Class Initialized
DEBUG - 2022-03-25 06:06:22 --> Encrypt Class Initialized
INFO - 2022-03-25 06:06:22 --> Model "Patient_model" initialized
INFO - 2022-03-25 06:06:22 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 06:06:22 --> Model "Referredby_model" initialized
INFO - 2022-03-25 06:06:22 --> Model "Prefix_master" initialized
INFO - 2022-03-25 06:06:22 --> Model "Hospital_model" initialized
INFO - 2022-03-25 06:06:22 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-25 06:06:22 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-25 06:06:22 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-25 06:06:22 --> Final output sent to browser
DEBUG - 2022-03-25 06:06:22 --> Total execution time: 0.0333
ERROR - 2022-03-25 06:06:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 06:06:23 --> Config Class Initialized
INFO - 2022-03-25 06:06:23 --> Hooks Class Initialized
DEBUG - 2022-03-25 06:06:23 --> UTF-8 Support Enabled
INFO - 2022-03-25 06:06:23 --> Utf8 Class Initialized
INFO - 2022-03-25 06:06:23 --> URI Class Initialized
INFO - 2022-03-25 06:06:23 --> Router Class Initialized
INFO - 2022-03-25 06:06:23 --> Output Class Initialized
INFO - 2022-03-25 06:06:23 --> Security Class Initialized
DEBUG - 2022-03-25 06:06:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 06:06:23 --> Input Class Initialized
INFO - 2022-03-25 06:06:23 --> Language Class Initialized
INFO - 2022-03-25 06:06:23 --> Loader Class Initialized
INFO - 2022-03-25 06:06:23 --> Helper loaded: url_helper
INFO - 2022-03-25 06:06:23 --> Helper loaded: form_helper
INFO - 2022-03-25 06:06:23 --> Helper loaded: common_helper
INFO - 2022-03-25 06:06:23 --> Database Driver Class Initialized
DEBUG - 2022-03-25 06:06:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 06:06:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 06:06:23 --> Controller Class Initialized
INFO - 2022-03-25 06:06:23 --> Form Validation Class Initialized
DEBUG - 2022-03-25 06:06:23 --> Encrypt Class Initialized
INFO - 2022-03-25 06:06:23 --> Model "Patient_model" initialized
INFO - 2022-03-25 06:06:23 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 06:06:23 --> Model "Prefix_master" initialized
INFO - 2022-03-25 06:06:23 --> Model "Users_model" initialized
INFO - 2022-03-25 06:06:23 --> Model "Hospital_model" initialized
INFO - 2022-03-25 06:06:24 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-25 06:06:24 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-25 06:06:24 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-25 06:06:24 --> Final output sent to browser
DEBUG - 2022-03-25 06:06:24 --> Total execution time: 1.0600
ERROR - 2022-03-25 06:07:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 06:07:01 --> Config Class Initialized
INFO - 2022-03-25 06:07:01 --> Hooks Class Initialized
DEBUG - 2022-03-25 06:07:01 --> UTF-8 Support Enabled
INFO - 2022-03-25 06:07:01 --> Utf8 Class Initialized
INFO - 2022-03-25 06:07:01 --> URI Class Initialized
INFO - 2022-03-25 06:07:01 --> Router Class Initialized
INFO - 2022-03-25 06:07:01 --> Output Class Initialized
INFO - 2022-03-25 06:07:01 --> Security Class Initialized
DEBUG - 2022-03-25 06:07:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 06:07:01 --> Input Class Initialized
INFO - 2022-03-25 06:07:01 --> Language Class Initialized
INFO - 2022-03-25 06:07:01 --> Loader Class Initialized
INFO - 2022-03-25 06:07:01 --> Helper loaded: url_helper
INFO - 2022-03-25 06:07:01 --> Helper loaded: form_helper
INFO - 2022-03-25 06:07:01 --> Helper loaded: common_helper
INFO - 2022-03-25 06:07:01 --> Database Driver Class Initialized
DEBUG - 2022-03-25 06:07:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 06:07:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 06:07:01 --> Controller Class Initialized
INFO - 2022-03-25 06:07:01 --> Form Validation Class Initialized
DEBUG - 2022-03-25 06:07:01 --> Encrypt Class Initialized
INFO - 2022-03-25 06:07:01 --> Model "Patient_model" initialized
INFO - 2022-03-25 06:07:01 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 06:07:01 --> Model "Prefix_master" initialized
INFO - 2022-03-25 06:07:01 --> Model "Users_model" initialized
INFO - 2022-03-25 06:07:01 --> Model "Hospital_model" initialized
INFO - 2022-03-25 06:07:01 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-25 06:07:01 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-25 06:07:01 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-25 06:07:01 --> Final output sent to browser
DEBUG - 2022-03-25 06:07:01 --> Total execution time: 0.0646
ERROR - 2022-03-25 06:07:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 06:07:14 --> Config Class Initialized
INFO - 2022-03-25 06:07:14 --> Hooks Class Initialized
DEBUG - 2022-03-25 06:07:14 --> UTF-8 Support Enabled
INFO - 2022-03-25 06:07:14 --> Utf8 Class Initialized
INFO - 2022-03-25 06:07:14 --> URI Class Initialized
INFO - 2022-03-25 06:07:14 --> Router Class Initialized
INFO - 2022-03-25 06:07:14 --> Output Class Initialized
INFO - 2022-03-25 06:07:14 --> Security Class Initialized
DEBUG - 2022-03-25 06:07:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 06:07:14 --> Input Class Initialized
INFO - 2022-03-25 06:07:14 --> Language Class Initialized
ERROR - 2022-03-25 06:07:14 --> 404 Page Not Found: Karoclient/file_uploads
ERROR - 2022-03-25 06:07:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 06:07:25 --> Config Class Initialized
INFO - 2022-03-25 06:07:25 --> Hooks Class Initialized
DEBUG - 2022-03-25 06:07:25 --> UTF-8 Support Enabled
INFO - 2022-03-25 06:07:25 --> Utf8 Class Initialized
INFO - 2022-03-25 06:07:25 --> URI Class Initialized
INFO - 2022-03-25 06:07:25 --> Router Class Initialized
INFO - 2022-03-25 06:07:25 --> Output Class Initialized
INFO - 2022-03-25 06:07:25 --> Security Class Initialized
DEBUG - 2022-03-25 06:07:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 06:07:25 --> Input Class Initialized
INFO - 2022-03-25 06:07:25 --> Language Class Initialized
ERROR - 2022-03-25 06:07:25 --> 404 Page Not Found: Karoclient/file_uploads
ERROR - 2022-03-25 06:07:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 06:07:34 --> Config Class Initialized
INFO - 2022-03-25 06:07:34 --> Hooks Class Initialized
DEBUG - 2022-03-25 06:07:34 --> UTF-8 Support Enabled
INFO - 2022-03-25 06:07:34 --> Utf8 Class Initialized
INFO - 2022-03-25 06:07:34 --> URI Class Initialized
INFO - 2022-03-25 06:07:34 --> Router Class Initialized
INFO - 2022-03-25 06:07:34 --> Output Class Initialized
INFO - 2022-03-25 06:07:34 --> Security Class Initialized
DEBUG - 2022-03-25 06:07:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 06:07:34 --> Input Class Initialized
INFO - 2022-03-25 06:07:34 --> Language Class Initialized
INFO - 2022-03-25 06:07:34 --> Loader Class Initialized
INFO - 2022-03-25 06:07:34 --> Helper loaded: url_helper
INFO - 2022-03-25 06:07:34 --> Helper loaded: form_helper
INFO - 2022-03-25 06:07:34 --> Helper loaded: common_helper
INFO - 2022-03-25 06:07:34 --> Database Driver Class Initialized
DEBUG - 2022-03-25 06:07:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 06:07:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 06:07:34 --> Controller Class Initialized
INFO - 2022-03-25 06:07:34 --> Form Validation Class Initialized
DEBUG - 2022-03-25 06:07:34 --> Encrypt Class Initialized
INFO - 2022-03-25 06:07:34 --> Model "Patient_model" initialized
INFO - 2022-03-25 06:07:34 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 06:07:34 --> Model "Referredby_model" initialized
INFO - 2022-03-25 06:07:34 --> Model "Prefix_master" initialized
INFO - 2022-03-25 06:07:34 --> Model "Hospital_model" initialized
INFO - 2022-03-25 06:07:34 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-25 06:07:34 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-25 06:07:34 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-25 06:07:34 --> Final output sent to browser
DEBUG - 2022-03-25 06:07:34 --> Total execution time: 0.0375
ERROR - 2022-03-25 06:07:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 06:07:35 --> Config Class Initialized
INFO - 2022-03-25 06:07:35 --> Hooks Class Initialized
DEBUG - 2022-03-25 06:07:35 --> UTF-8 Support Enabled
INFO - 2022-03-25 06:07:35 --> Utf8 Class Initialized
INFO - 2022-03-25 06:07:35 --> URI Class Initialized
INFO - 2022-03-25 06:07:35 --> Router Class Initialized
INFO - 2022-03-25 06:07:35 --> Output Class Initialized
INFO - 2022-03-25 06:07:35 --> Security Class Initialized
DEBUG - 2022-03-25 06:07:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 06:07:35 --> Input Class Initialized
INFO - 2022-03-25 06:07:35 --> Language Class Initialized
ERROR - 2022-03-25 06:07:35 --> 404 Page Not Found: Karoclient/images
ERROR - 2022-03-25 06:11:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 06:11:26 --> Config Class Initialized
INFO - 2022-03-25 06:11:26 --> Hooks Class Initialized
DEBUG - 2022-03-25 06:11:26 --> UTF-8 Support Enabled
INFO - 2022-03-25 06:11:26 --> Utf8 Class Initialized
INFO - 2022-03-25 06:11:26 --> URI Class Initialized
INFO - 2022-03-25 06:11:26 --> Router Class Initialized
INFO - 2022-03-25 06:11:26 --> Output Class Initialized
INFO - 2022-03-25 06:11:26 --> Security Class Initialized
DEBUG - 2022-03-25 06:11:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 06:11:26 --> Input Class Initialized
INFO - 2022-03-25 06:11:26 --> Language Class Initialized
INFO - 2022-03-25 06:11:26 --> Loader Class Initialized
INFO - 2022-03-25 06:11:26 --> Helper loaded: url_helper
INFO - 2022-03-25 06:11:26 --> Helper loaded: form_helper
INFO - 2022-03-25 06:11:26 --> Helper loaded: common_helper
INFO - 2022-03-25 06:11:26 --> Database Driver Class Initialized
DEBUG - 2022-03-25 06:11:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 06:11:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 06:11:26 --> Controller Class Initialized
INFO - 2022-03-25 06:11:26 --> Form Validation Class Initialized
DEBUG - 2022-03-25 06:11:26 --> Encrypt Class Initialized
INFO - 2022-03-25 06:11:26 --> Model "Patient_model" initialized
INFO - 2022-03-25 06:11:26 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 06:11:26 --> Model "Referredby_model" initialized
INFO - 2022-03-25 06:11:26 --> Model "Prefix_master" initialized
INFO - 2022-03-25 06:11:26 --> Model "Hospital_model" initialized
INFO - 2022-03-25 06:11:26 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-25 06:11:33 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-25 06:11:33 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-25 06:11:35 --> Final output sent to browser
DEBUG - 2022-03-25 06:11:35 --> Total execution time: 7.2870
ERROR - 2022-03-25 06:13:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 06:13:08 --> Config Class Initialized
INFO - 2022-03-25 06:13:08 --> Hooks Class Initialized
DEBUG - 2022-03-25 06:13:08 --> UTF-8 Support Enabled
INFO - 2022-03-25 06:13:08 --> Utf8 Class Initialized
INFO - 2022-03-25 06:13:08 --> URI Class Initialized
INFO - 2022-03-25 06:13:08 --> Router Class Initialized
INFO - 2022-03-25 06:13:08 --> Output Class Initialized
INFO - 2022-03-25 06:13:08 --> Security Class Initialized
DEBUG - 2022-03-25 06:13:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 06:13:08 --> Input Class Initialized
INFO - 2022-03-25 06:13:08 --> Language Class Initialized
INFO - 2022-03-25 06:13:08 --> Loader Class Initialized
INFO - 2022-03-25 06:13:08 --> Helper loaded: url_helper
INFO - 2022-03-25 06:13:08 --> Helper loaded: form_helper
INFO - 2022-03-25 06:13:08 --> Helper loaded: common_helper
INFO - 2022-03-25 06:13:08 --> Database Driver Class Initialized
DEBUG - 2022-03-25 06:13:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 06:13:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 06:13:08 --> Controller Class Initialized
INFO - 2022-03-25 06:13:08 --> Form Validation Class Initialized
DEBUG - 2022-03-25 06:13:08 --> Encrypt Class Initialized
INFO - 2022-03-25 06:13:08 --> Model "Patient_model" initialized
INFO - 2022-03-25 06:13:08 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 06:13:08 --> Model "Prefix_master" initialized
INFO - 2022-03-25 06:13:08 --> Model "Users_model" initialized
INFO - 2022-03-25 06:13:08 --> Model "Hospital_model" initialized
INFO - 2022-03-25 06:13:09 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-25 06:13:09 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-25 06:13:09 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-25 06:13:09 --> Final output sent to browser
DEBUG - 2022-03-25 06:13:09 --> Total execution time: 0.0451
ERROR - 2022-03-25 06:18:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 06:18:44 --> Config Class Initialized
INFO - 2022-03-25 06:18:44 --> Hooks Class Initialized
DEBUG - 2022-03-25 06:18:44 --> UTF-8 Support Enabled
INFO - 2022-03-25 06:18:44 --> Utf8 Class Initialized
INFO - 2022-03-25 06:18:44 --> URI Class Initialized
INFO - 2022-03-25 06:18:44 --> Router Class Initialized
INFO - 2022-03-25 06:18:44 --> Output Class Initialized
INFO - 2022-03-25 06:18:44 --> Security Class Initialized
DEBUG - 2022-03-25 06:18:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 06:18:44 --> Input Class Initialized
INFO - 2022-03-25 06:18:44 --> Language Class Initialized
INFO - 2022-03-25 06:18:44 --> Loader Class Initialized
INFO - 2022-03-25 06:18:44 --> Helper loaded: url_helper
INFO - 2022-03-25 06:18:44 --> Helper loaded: form_helper
INFO - 2022-03-25 06:18:44 --> Helper loaded: common_helper
INFO - 2022-03-25 06:18:44 --> Database Driver Class Initialized
DEBUG - 2022-03-25 06:18:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 06:18:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 06:18:44 --> Controller Class Initialized
INFO - 2022-03-25 06:18:44 --> Form Validation Class Initialized
DEBUG - 2022-03-25 06:18:44 --> Encrypt Class Initialized
INFO - 2022-03-25 06:18:44 --> Model "Patient_model" initialized
INFO - 2022-03-25 06:18:44 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 06:18:44 --> Model "Prefix_master" initialized
INFO - 2022-03-25 06:18:44 --> Model "Users_model" initialized
INFO - 2022-03-25 06:18:44 --> Model "Hospital_model" initialized
ERROR - 2022-03-25 06:18:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 06:18:44 --> Config Class Initialized
INFO - 2022-03-25 06:18:44 --> Hooks Class Initialized
DEBUG - 2022-03-25 06:18:44 --> UTF-8 Support Enabled
INFO - 2022-03-25 06:18:44 --> Utf8 Class Initialized
INFO - 2022-03-25 06:18:44 --> URI Class Initialized
INFO - 2022-03-25 06:18:44 --> Router Class Initialized
INFO - 2022-03-25 06:18:44 --> Output Class Initialized
INFO - 2022-03-25 06:18:44 --> Security Class Initialized
DEBUG - 2022-03-25 06:18:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 06:18:44 --> Input Class Initialized
INFO - 2022-03-25 06:18:44 --> Language Class Initialized
INFO - 2022-03-25 06:18:44 --> Loader Class Initialized
INFO - 2022-03-25 06:18:44 --> Helper loaded: url_helper
INFO - 2022-03-25 06:18:44 --> Helper loaded: form_helper
INFO - 2022-03-25 06:18:44 --> Helper loaded: common_helper
INFO - 2022-03-25 06:18:44 --> Database Driver Class Initialized
DEBUG - 2022-03-25 06:18:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 06:18:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 06:18:44 --> Controller Class Initialized
INFO - 2022-03-25 06:18:44 --> Form Validation Class Initialized
DEBUG - 2022-03-25 06:18:44 --> Encrypt Class Initialized
INFO - 2022-03-25 06:18:44 --> Model "Patient_model" initialized
INFO - 2022-03-25 06:18:44 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 06:18:44 --> Model "Prefix_master" initialized
INFO - 2022-03-25 06:18:44 --> Model "Users_model" initialized
INFO - 2022-03-25 06:18:44 --> Model "Hospital_model" initialized
INFO - 2022-03-25 06:18:44 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-25 06:18:44 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-25 06:18:44 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-25 06:18:44 --> Final output sent to browser
DEBUG - 2022-03-25 06:18:44 --> Total execution time: 0.0530
ERROR - 2022-03-25 06:23:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 06:23:54 --> Config Class Initialized
INFO - 2022-03-25 06:23:54 --> Hooks Class Initialized
DEBUG - 2022-03-25 06:23:54 --> UTF-8 Support Enabled
INFO - 2022-03-25 06:23:54 --> Utf8 Class Initialized
INFO - 2022-03-25 06:23:54 --> URI Class Initialized
INFO - 2022-03-25 06:23:54 --> Router Class Initialized
INFO - 2022-03-25 06:23:54 --> Output Class Initialized
INFO - 2022-03-25 06:23:54 --> Security Class Initialized
DEBUG - 2022-03-25 06:23:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 06:23:54 --> Input Class Initialized
INFO - 2022-03-25 06:23:54 --> Language Class Initialized
INFO - 2022-03-25 06:23:54 --> Loader Class Initialized
INFO - 2022-03-25 06:23:54 --> Helper loaded: url_helper
INFO - 2022-03-25 06:23:54 --> Helper loaded: form_helper
INFO - 2022-03-25 06:23:54 --> Helper loaded: common_helper
INFO - 2022-03-25 06:23:54 --> Database Driver Class Initialized
DEBUG - 2022-03-25 06:23:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 06:23:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 06:23:54 --> Controller Class Initialized
INFO - 2022-03-25 06:23:54 --> Form Validation Class Initialized
DEBUG - 2022-03-25 06:23:54 --> Encrypt Class Initialized
INFO - 2022-03-25 06:23:54 --> Model "Patient_model" initialized
INFO - 2022-03-25 06:23:54 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 06:23:54 --> Model "Prefix_master" initialized
INFO - 2022-03-25 06:23:54 --> Model "Users_model" initialized
INFO - 2022-03-25 06:23:54 --> Model "Hospital_model" initialized
ERROR - 2022-03-25 06:23:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 06:23:55 --> Config Class Initialized
INFO - 2022-03-25 06:23:55 --> Hooks Class Initialized
DEBUG - 2022-03-25 06:23:55 --> UTF-8 Support Enabled
INFO - 2022-03-25 06:23:55 --> Utf8 Class Initialized
INFO - 2022-03-25 06:23:55 --> URI Class Initialized
INFO - 2022-03-25 06:23:55 --> Router Class Initialized
INFO - 2022-03-25 06:23:55 --> Output Class Initialized
INFO - 2022-03-25 06:23:55 --> Security Class Initialized
DEBUG - 2022-03-25 06:23:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 06:23:55 --> Input Class Initialized
INFO - 2022-03-25 06:23:55 --> Language Class Initialized
INFO - 2022-03-25 06:23:55 --> Loader Class Initialized
INFO - 2022-03-25 06:23:55 --> Helper loaded: url_helper
INFO - 2022-03-25 06:23:55 --> Helper loaded: form_helper
INFO - 2022-03-25 06:23:55 --> Helper loaded: common_helper
INFO - 2022-03-25 06:23:55 --> Database Driver Class Initialized
DEBUG - 2022-03-25 06:23:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 06:23:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 06:23:55 --> Controller Class Initialized
INFO - 2022-03-25 06:23:55 --> Form Validation Class Initialized
DEBUG - 2022-03-25 06:23:55 --> Encrypt Class Initialized
INFO - 2022-03-25 06:23:55 --> Model "Patient_model" initialized
INFO - 2022-03-25 06:23:55 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 06:23:55 --> Model "Prefix_master" initialized
INFO - 2022-03-25 06:23:55 --> Model "Users_model" initialized
INFO - 2022-03-25 06:23:55 --> Model "Hospital_model" initialized
INFO - 2022-03-25 06:23:55 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-25 06:23:55 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-25 06:23:55 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-25 06:23:55 --> Final output sent to browser
DEBUG - 2022-03-25 06:23:55 --> Total execution time: 0.0508
ERROR - 2022-03-25 06:25:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 06:25:57 --> Config Class Initialized
INFO - 2022-03-25 06:25:57 --> Hooks Class Initialized
DEBUG - 2022-03-25 06:25:57 --> UTF-8 Support Enabled
INFO - 2022-03-25 06:25:57 --> Utf8 Class Initialized
INFO - 2022-03-25 06:25:57 --> URI Class Initialized
INFO - 2022-03-25 06:25:57 --> Router Class Initialized
INFO - 2022-03-25 06:25:57 --> Output Class Initialized
INFO - 2022-03-25 06:25:57 --> Security Class Initialized
DEBUG - 2022-03-25 06:25:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 06:25:57 --> Input Class Initialized
INFO - 2022-03-25 06:25:57 --> Language Class Initialized
INFO - 2022-03-25 06:25:57 --> Loader Class Initialized
INFO - 2022-03-25 06:25:57 --> Helper loaded: url_helper
INFO - 2022-03-25 06:25:57 --> Helper loaded: form_helper
INFO - 2022-03-25 06:25:57 --> Helper loaded: common_helper
INFO - 2022-03-25 06:25:57 --> Database Driver Class Initialized
DEBUG - 2022-03-25 06:25:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 06:25:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 06:25:57 --> Controller Class Initialized
INFO - 2022-03-25 06:25:57 --> Form Validation Class Initialized
DEBUG - 2022-03-25 06:25:57 --> Encrypt Class Initialized
INFO - 2022-03-25 06:25:57 --> Model "Patient_model" initialized
INFO - 2022-03-25 06:25:57 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 06:25:57 --> Model "Prefix_master" initialized
INFO - 2022-03-25 06:25:57 --> Model "Users_model" initialized
INFO - 2022-03-25 06:25:57 --> Model "Hospital_model" initialized
INFO - 2022-03-25 06:25:57 --> Upload Class Initialized
INFO - 2022-03-25 06:25:57 --> Final output sent to browser
DEBUG - 2022-03-25 06:25:57 --> Total execution time: 0.0479
ERROR - 2022-03-25 06:26:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 06:26:02 --> Config Class Initialized
INFO - 2022-03-25 06:26:02 --> Hooks Class Initialized
DEBUG - 2022-03-25 06:26:02 --> UTF-8 Support Enabled
INFO - 2022-03-25 06:26:02 --> Utf8 Class Initialized
INFO - 2022-03-25 06:26:02 --> URI Class Initialized
INFO - 2022-03-25 06:26:02 --> Router Class Initialized
INFO - 2022-03-25 06:26:02 --> Output Class Initialized
INFO - 2022-03-25 06:26:02 --> Security Class Initialized
DEBUG - 2022-03-25 06:26:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 06:26:02 --> Input Class Initialized
INFO - 2022-03-25 06:26:02 --> Language Class Initialized
INFO - 2022-03-25 06:26:02 --> Loader Class Initialized
INFO - 2022-03-25 06:26:02 --> Helper loaded: url_helper
INFO - 2022-03-25 06:26:02 --> Helper loaded: form_helper
INFO - 2022-03-25 06:26:02 --> Helper loaded: common_helper
INFO - 2022-03-25 06:26:02 --> Database Driver Class Initialized
DEBUG - 2022-03-25 06:26:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 06:26:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 06:26:02 --> Controller Class Initialized
INFO - 2022-03-25 06:26:02 --> Form Validation Class Initialized
DEBUG - 2022-03-25 06:26:02 --> Encrypt Class Initialized
INFO - 2022-03-25 06:26:02 --> Model "Patient_model" initialized
INFO - 2022-03-25 06:26:02 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 06:26:02 --> Model "Prefix_master" initialized
INFO - 2022-03-25 06:26:02 --> Model "Users_model" initialized
INFO - 2022-03-25 06:26:02 --> Model "Hospital_model" initialized
ERROR - 2022-03-25 06:26:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 06:26:03 --> Config Class Initialized
INFO - 2022-03-25 06:26:03 --> Hooks Class Initialized
DEBUG - 2022-03-25 06:26:03 --> UTF-8 Support Enabled
INFO - 2022-03-25 06:26:03 --> Utf8 Class Initialized
INFO - 2022-03-25 06:26:03 --> URI Class Initialized
INFO - 2022-03-25 06:26:03 --> Router Class Initialized
INFO - 2022-03-25 06:26:03 --> Output Class Initialized
INFO - 2022-03-25 06:26:03 --> Security Class Initialized
DEBUG - 2022-03-25 06:26:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 06:26:03 --> Input Class Initialized
INFO - 2022-03-25 06:26:03 --> Language Class Initialized
INFO - 2022-03-25 06:26:03 --> Loader Class Initialized
INFO - 2022-03-25 06:26:03 --> Helper loaded: url_helper
INFO - 2022-03-25 06:26:03 --> Helper loaded: form_helper
INFO - 2022-03-25 06:26:03 --> Helper loaded: common_helper
INFO - 2022-03-25 06:26:03 --> Database Driver Class Initialized
DEBUG - 2022-03-25 06:26:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 06:26:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 06:26:03 --> Controller Class Initialized
INFO - 2022-03-25 06:26:03 --> Form Validation Class Initialized
DEBUG - 2022-03-25 06:26:03 --> Encrypt Class Initialized
INFO - 2022-03-25 06:26:03 --> Model "Patient_model" initialized
INFO - 2022-03-25 06:26:03 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 06:26:03 --> Model "Prefix_master" initialized
INFO - 2022-03-25 06:26:03 --> Model "Users_model" initialized
INFO - 2022-03-25 06:26:03 --> Model "Hospital_model" initialized
INFO - 2022-03-25 06:26:03 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-25 06:26:03 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-25 06:26:03 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-25 06:26:03 --> Final output sent to browser
DEBUG - 2022-03-25 06:26:03 --> Total execution time: 0.0770
ERROR - 2022-03-25 06:52:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 06:52:20 --> Config Class Initialized
INFO - 2022-03-25 06:52:20 --> Hooks Class Initialized
DEBUG - 2022-03-25 06:52:20 --> UTF-8 Support Enabled
INFO - 2022-03-25 06:52:20 --> Utf8 Class Initialized
INFO - 2022-03-25 06:52:20 --> URI Class Initialized
INFO - 2022-03-25 06:52:20 --> Router Class Initialized
INFO - 2022-03-25 06:52:20 --> Output Class Initialized
INFO - 2022-03-25 06:52:20 --> Security Class Initialized
DEBUG - 2022-03-25 06:52:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 06:52:20 --> Input Class Initialized
INFO - 2022-03-25 06:52:20 --> Language Class Initialized
INFO - 2022-03-25 06:52:20 --> Loader Class Initialized
INFO - 2022-03-25 06:52:20 --> Helper loaded: url_helper
INFO - 2022-03-25 06:52:20 --> Helper loaded: form_helper
INFO - 2022-03-25 06:52:20 --> Helper loaded: common_helper
INFO - 2022-03-25 06:52:20 --> Database Driver Class Initialized
DEBUG - 2022-03-25 06:52:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 06:52:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 06:52:20 --> Controller Class Initialized
INFO - 2022-03-25 06:52:20 --> Form Validation Class Initialized
DEBUG - 2022-03-25 06:52:20 --> Encrypt Class Initialized
INFO - 2022-03-25 06:52:20 --> Model "Patient_model" initialized
INFO - 2022-03-25 06:52:20 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 06:52:20 --> Model "Prefix_master" initialized
INFO - 2022-03-25 06:52:20 --> Model "Users_model" initialized
INFO - 2022-03-25 06:52:20 --> Model "Hospital_model" initialized
ERROR - 2022-03-25 06:52:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 06:52:20 --> Config Class Initialized
INFO - 2022-03-25 06:52:20 --> Hooks Class Initialized
DEBUG - 2022-03-25 06:52:20 --> UTF-8 Support Enabled
INFO - 2022-03-25 06:52:20 --> Utf8 Class Initialized
INFO - 2022-03-25 06:52:20 --> URI Class Initialized
INFO - 2022-03-25 06:52:20 --> Router Class Initialized
INFO - 2022-03-25 06:52:20 --> Output Class Initialized
INFO - 2022-03-25 06:52:20 --> Security Class Initialized
DEBUG - 2022-03-25 06:52:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 06:52:20 --> Input Class Initialized
INFO - 2022-03-25 06:52:20 --> Language Class Initialized
INFO - 2022-03-25 06:52:20 --> Loader Class Initialized
INFO - 2022-03-25 06:52:20 --> Helper loaded: url_helper
INFO - 2022-03-25 06:52:20 --> Helper loaded: form_helper
INFO - 2022-03-25 06:52:20 --> Helper loaded: common_helper
INFO - 2022-03-25 06:52:20 --> Database Driver Class Initialized
DEBUG - 2022-03-25 06:52:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 06:52:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 06:52:20 --> Controller Class Initialized
INFO - 2022-03-25 06:52:20 --> Form Validation Class Initialized
DEBUG - 2022-03-25 06:52:20 --> Encrypt Class Initialized
INFO - 2022-03-25 06:52:20 --> Model "Patient_model" initialized
INFO - 2022-03-25 06:52:20 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 06:52:20 --> Model "Prefix_master" initialized
INFO - 2022-03-25 06:52:20 --> Model "Users_model" initialized
INFO - 2022-03-25 06:52:20 --> Model "Hospital_model" initialized
INFO - 2022-03-25 06:52:20 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-25 06:52:20 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-25 06:52:20 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-25 06:52:20 --> Final output sent to browser
DEBUG - 2022-03-25 06:52:20 --> Total execution time: 0.0578
ERROR - 2022-03-25 06:52:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 06:52:35 --> Config Class Initialized
INFO - 2022-03-25 06:52:35 --> Hooks Class Initialized
DEBUG - 2022-03-25 06:52:35 --> UTF-8 Support Enabled
INFO - 2022-03-25 06:52:35 --> Utf8 Class Initialized
INFO - 2022-03-25 06:52:35 --> URI Class Initialized
INFO - 2022-03-25 06:52:35 --> Router Class Initialized
INFO - 2022-03-25 06:52:35 --> Output Class Initialized
INFO - 2022-03-25 06:52:35 --> Security Class Initialized
DEBUG - 2022-03-25 06:52:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 06:52:35 --> Input Class Initialized
INFO - 2022-03-25 06:52:35 --> Language Class Initialized
INFO - 2022-03-25 06:52:35 --> Loader Class Initialized
INFO - 2022-03-25 06:52:35 --> Helper loaded: url_helper
INFO - 2022-03-25 06:52:35 --> Helper loaded: form_helper
INFO - 2022-03-25 06:52:35 --> Helper loaded: common_helper
INFO - 2022-03-25 06:52:35 --> Database Driver Class Initialized
DEBUG - 2022-03-25 06:52:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 06:52:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 06:52:35 --> Controller Class Initialized
INFO - 2022-03-25 06:52:35 --> Form Validation Class Initialized
DEBUG - 2022-03-25 06:52:35 --> Encrypt Class Initialized
INFO - 2022-03-25 06:52:35 --> Model "Patient_model" initialized
INFO - 2022-03-25 06:52:35 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 06:52:35 --> Model "Referredby_model" initialized
INFO - 2022-03-25 06:52:35 --> Model "Prefix_master" initialized
INFO - 2022-03-25 06:52:35 --> Model "Hospital_model" initialized
INFO - 2022-03-25 06:52:35 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-25 06:52:35 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-25 06:52:35 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-25 06:52:35 --> Final output sent to browser
DEBUG - 2022-03-25 06:52:35 --> Total execution time: 0.0313
ERROR - 2022-03-25 06:52:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 06:52:53 --> Config Class Initialized
INFO - 2022-03-25 06:52:53 --> Hooks Class Initialized
DEBUG - 2022-03-25 06:52:53 --> UTF-8 Support Enabled
INFO - 2022-03-25 06:52:53 --> Utf8 Class Initialized
INFO - 2022-03-25 06:52:53 --> URI Class Initialized
INFO - 2022-03-25 06:52:53 --> Router Class Initialized
INFO - 2022-03-25 06:52:53 --> Output Class Initialized
INFO - 2022-03-25 06:52:53 --> Security Class Initialized
DEBUG - 2022-03-25 06:52:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 06:52:53 --> Input Class Initialized
INFO - 2022-03-25 06:52:53 --> Language Class Initialized
INFO - 2022-03-25 06:52:53 --> Loader Class Initialized
INFO - 2022-03-25 06:52:53 --> Helper loaded: url_helper
INFO - 2022-03-25 06:52:53 --> Helper loaded: form_helper
INFO - 2022-03-25 06:52:53 --> Helper loaded: common_helper
INFO - 2022-03-25 06:52:53 --> Database Driver Class Initialized
DEBUG - 2022-03-25 06:52:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 06:52:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 06:52:53 --> Controller Class Initialized
INFO - 2022-03-25 06:52:53 --> Form Validation Class Initialized
DEBUG - 2022-03-25 06:52:53 --> Encrypt Class Initialized
INFO - 2022-03-25 06:52:53 --> Model "Patient_model" initialized
INFO - 2022-03-25 06:52:53 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 06:52:53 --> Model "Referredby_model" initialized
INFO - 2022-03-25 06:52:53 --> Model "Prefix_master" initialized
INFO - 2022-03-25 06:52:53 --> Model "Hospital_model" initialized
INFO - 2022-03-25 06:52:53 --> Upload Class Initialized
INFO - 2022-03-25 06:52:53 --> Final output sent to browser
DEBUG - 2022-03-25 06:52:53 --> Total execution time: 0.0144
ERROR - 2022-03-25 06:53:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 06:53:04 --> Config Class Initialized
INFO - 2022-03-25 06:53:04 --> Hooks Class Initialized
DEBUG - 2022-03-25 06:53:04 --> UTF-8 Support Enabled
INFO - 2022-03-25 06:53:04 --> Utf8 Class Initialized
INFO - 2022-03-25 06:53:04 --> URI Class Initialized
INFO - 2022-03-25 06:53:04 --> Router Class Initialized
INFO - 2022-03-25 06:53:04 --> Output Class Initialized
INFO - 2022-03-25 06:53:04 --> Security Class Initialized
DEBUG - 2022-03-25 06:53:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 06:53:04 --> Input Class Initialized
INFO - 2022-03-25 06:53:04 --> Language Class Initialized
INFO - 2022-03-25 06:53:04 --> Loader Class Initialized
INFO - 2022-03-25 06:53:04 --> Helper loaded: url_helper
INFO - 2022-03-25 06:53:04 --> Helper loaded: form_helper
INFO - 2022-03-25 06:53:04 --> Helper loaded: common_helper
INFO - 2022-03-25 06:53:04 --> Database Driver Class Initialized
DEBUG - 2022-03-25 06:53:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 06:53:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 06:53:04 --> Controller Class Initialized
INFO - 2022-03-25 06:53:04 --> Form Validation Class Initialized
DEBUG - 2022-03-25 06:53:04 --> Encrypt Class Initialized
INFO - 2022-03-25 06:53:04 --> Model "Patient_model" initialized
INFO - 2022-03-25 06:53:04 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 06:53:04 --> Model "Referredby_model" initialized
INFO - 2022-03-25 06:53:04 --> Model "Prefix_master" initialized
INFO - 2022-03-25 06:53:04 --> Model "Hospital_model" initialized
ERROR - 2022-03-25 06:53:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 06:53:05 --> Config Class Initialized
INFO - 2022-03-25 06:53:05 --> Hooks Class Initialized
DEBUG - 2022-03-25 06:53:05 --> UTF-8 Support Enabled
INFO - 2022-03-25 06:53:05 --> Utf8 Class Initialized
INFO - 2022-03-25 06:53:05 --> URI Class Initialized
INFO - 2022-03-25 06:53:05 --> Router Class Initialized
INFO - 2022-03-25 06:53:05 --> Output Class Initialized
INFO - 2022-03-25 06:53:05 --> Security Class Initialized
DEBUG - 2022-03-25 06:53:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 06:53:05 --> Input Class Initialized
INFO - 2022-03-25 06:53:05 --> Language Class Initialized
INFO - 2022-03-25 06:53:05 --> Loader Class Initialized
INFO - 2022-03-25 06:53:05 --> Helper loaded: url_helper
INFO - 2022-03-25 06:53:05 --> Helper loaded: form_helper
INFO - 2022-03-25 06:53:05 --> Helper loaded: common_helper
INFO - 2022-03-25 06:53:05 --> Database Driver Class Initialized
DEBUG - 2022-03-25 06:53:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 06:53:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 06:53:05 --> Controller Class Initialized
INFO - 2022-03-25 06:53:05 --> Form Validation Class Initialized
DEBUG - 2022-03-25 06:53:05 --> Encrypt Class Initialized
INFO - 2022-03-25 06:53:05 --> Model "Patient_model" initialized
INFO - 2022-03-25 06:53:05 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 06:53:05 --> Model "Referredby_model" initialized
INFO - 2022-03-25 06:53:05 --> Model "Prefix_master" initialized
INFO - 2022-03-25 06:53:05 --> Model "Hospital_model" initialized
INFO - 2022-03-25 06:53:05 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-25 06:53:05 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-25 06:53:05 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-25 06:53:05 --> Final output sent to browser
DEBUG - 2022-03-25 06:53:05 --> Total execution time: 0.0310
ERROR - 2022-03-25 06:53:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 06:53:05 --> Config Class Initialized
INFO - 2022-03-25 06:53:05 --> Hooks Class Initialized
DEBUG - 2022-03-25 06:53:05 --> UTF-8 Support Enabled
INFO - 2022-03-25 06:53:05 --> Utf8 Class Initialized
INFO - 2022-03-25 06:53:05 --> URI Class Initialized
INFO - 2022-03-25 06:53:05 --> Router Class Initialized
INFO - 2022-03-25 06:53:05 --> Output Class Initialized
INFO - 2022-03-25 06:53:05 --> Security Class Initialized
DEBUG - 2022-03-25 06:53:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 06:53:05 --> Input Class Initialized
INFO - 2022-03-25 06:53:05 --> Language Class Initialized
INFO - 2022-03-25 06:53:05 --> Loader Class Initialized
INFO - 2022-03-25 06:53:05 --> Helper loaded: url_helper
INFO - 2022-03-25 06:53:05 --> Helper loaded: form_helper
INFO - 2022-03-25 06:53:05 --> Helper loaded: common_helper
INFO - 2022-03-25 06:53:05 --> Database Driver Class Initialized
DEBUG - 2022-03-25 06:53:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 06:53:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 06:53:05 --> Controller Class Initialized
INFO - 2022-03-25 06:53:05 --> Form Validation Class Initialized
DEBUG - 2022-03-25 06:53:05 --> Encrypt Class Initialized
INFO - 2022-03-25 06:53:05 --> Model "Patient_model" initialized
INFO - 2022-03-25 06:53:05 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 06:53:05 --> Model "Prefix_master" initialized
INFO - 2022-03-25 06:53:05 --> Model "Users_model" initialized
INFO - 2022-03-25 06:53:05 --> Model "Hospital_model" initialized
INFO - 2022-03-25 06:53:05 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-25 06:53:05 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-25 06:53:05 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-25 06:53:05 --> Final output sent to browser
DEBUG - 2022-03-25 06:53:05 --> Total execution time: 0.0408
ERROR - 2022-03-25 06:53:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 06:53:18 --> Config Class Initialized
INFO - 2022-03-25 06:53:18 --> Hooks Class Initialized
DEBUG - 2022-03-25 06:53:18 --> UTF-8 Support Enabled
INFO - 2022-03-25 06:53:18 --> Utf8 Class Initialized
INFO - 2022-03-25 06:53:18 --> URI Class Initialized
INFO - 2022-03-25 06:53:18 --> Router Class Initialized
INFO - 2022-03-25 06:53:18 --> Output Class Initialized
INFO - 2022-03-25 06:53:18 --> Security Class Initialized
DEBUG - 2022-03-25 06:53:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 06:53:18 --> Input Class Initialized
INFO - 2022-03-25 06:53:18 --> Language Class Initialized
INFO - 2022-03-25 06:53:18 --> Loader Class Initialized
INFO - 2022-03-25 06:53:18 --> Helper loaded: url_helper
INFO - 2022-03-25 06:53:18 --> Helper loaded: form_helper
INFO - 2022-03-25 06:53:18 --> Helper loaded: common_helper
INFO - 2022-03-25 06:53:18 --> Database Driver Class Initialized
DEBUG - 2022-03-25 06:53:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 06:53:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 06:53:18 --> Controller Class Initialized
INFO - 2022-03-25 06:53:18 --> Form Validation Class Initialized
DEBUG - 2022-03-25 06:53:18 --> Encrypt Class Initialized
INFO - 2022-03-25 06:53:18 --> Model "Patient_model" initialized
INFO - 2022-03-25 06:53:18 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 06:53:18 --> Model "Prefix_master" initialized
INFO - 2022-03-25 06:53:18 --> Model "Users_model" initialized
INFO - 2022-03-25 06:53:18 --> Model "Hospital_model" initialized
ERROR - 2022-03-25 06:53:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 06:53:18 --> Config Class Initialized
INFO - 2022-03-25 06:53:18 --> Hooks Class Initialized
DEBUG - 2022-03-25 06:53:18 --> UTF-8 Support Enabled
INFO - 2022-03-25 06:53:18 --> Utf8 Class Initialized
INFO - 2022-03-25 06:53:18 --> URI Class Initialized
INFO - 2022-03-25 06:53:18 --> Router Class Initialized
INFO - 2022-03-25 06:53:18 --> Output Class Initialized
INFO - 2022-03-25 06:53:18 --> Security Class Initialized
DEBUG - 2022-03-25 06:53:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 06:53:18 --> Input Class Initialized
INFO - 2022-03-25 06:53:18 --> Language Class Initialized
INFO - 2022-03-25 06:53:18 --> Loader Class Initialized
INFO - 2022-03-25 06:53:18 --> Helper loaded: url_helper
INFO - 2022-03-25 06:53:18 --> Helper loaded: form_helper
INFO - 2022-03-25 06:53:18 --> Helper loaded: common_helper
INFO - 2022-03-25 06:53:18 --> Database Driver Class Initialized
DEBUG - 2022-03-25 06:53:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 06:53:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 06:53:18 --> Controller Class Initialized
INFO - 2022-03-25 06:53:18 --> Form Validation Class Initialized
DEBUG - 2022-03-25 06:53:18 --> Encrypt Class Initialized
INFO - 2022-03-25 06:53:18 --> Model "Patient_model" initialized
INFO - 2022-03-25 06:53:18 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 06:53:18 --> Model "Prefix_master" initialized
INFO - 2022-03-25 06:53:18 --> Model "Users_model" initialized
INFO - 2022-03-25 06:53:18 --> Model "Hospital_model" initialized
INFO - 2022-03-25 06:53:18 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-25 06:53:18 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-25 06:53:18 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-25 06:53:18 --> Final output sent to browser
DEBUG - 2022-03-25 06:53:18 --> Total execution time: 0.0357
ERROR - 2022-03-25 06:55:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 06:55:33 --> Config Class Initialized
INFO - 2022-03-25 06:55:33 --> Hooks Class Initialized
DEBUG - 2022-03-25 06:55:33 --> UTF-8 Support Enabled
INFO - 2022-03-25 06:55:33 --> Utf8 Class Initialized
INFO - 2022-03-25 06:55:33 --> URI Class Initialized
INFO - 2022-03-25 06:55:33 --> Router Class Initialized
INFO - 2022-03-25 06:55:33 --> Output Class Initialized
INFO - 2022-03-25 06:55:33 --> Security Class Initialized
DEBUG - 2022-03-25 06:55:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 06:55:33 --> Input Class Initialized
INFO - 2022-03-25 06:55:33 --> Language Class Initialized
INFO - 2022-03-25 06:55:33 --> Loader Class Initialized
INFO - 2022-03-25 06:55:33 --> Helper loaded: url_helper
INFO - 2022-03-25 06:55:33 --> Helper loaded: form_helper
INFO - 2022-03-25 06:55:33 --> Helper loaded: common_helper
INFO - 2022-03-25 06:55:33 --> Database Driver Class Initialized
DEBUG - 2022-03-25 06:55:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 06:55:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 06:55:33 --> Controller Class Initialized
INFO - 2022-03-25 06:55:33 --> Form Validation Class Initialized
DEBUG - 2022-03-25 06:55:33 --> Encrypt Class Initialized
INFO - 2022-03-25 06:55:33 --> Model "Patient_model" initialized
INFO - 2022-03-25 06:55:33 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 06:55:33 --> Model "Referredby_model" initialized
INFO - 2022-03-25 06:55:33 --> Model "Prefix_master" initialized
INFO - 2022-03-25 06:55:33 --> Model "Hospital_model" initialized
INFO - 2022-03-25 06:55:33 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-25 06:55:33 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-25 06:55:33 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-25 06:55:33 --> Final output sent to browser
DEBUG - 2022-03-25 06:55:33 --> Total execution time: 0.0975
ERROR - 2022-03-25 06:55:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 06:55:46 --> Config Class Initialized
INFO - 2022-03-25 06:55:46 --> Hooks Class Initialized
DEBUG - 2022-03-25 06:55:46 --> UTF-8 Support Enabled
INFO - 2022-03-25 06:55:46 --> Utf8 Class Initialized
INFO - 2022-03-25 06:55:46 --> URI Class Initialized
DEBUG - 2022-03-25 06:55:46 --> No URI present. Default controller set.
INFO - 2022-03-25 06:55:46 --> Router Class Initialized
INFO - 2022-03-25 06:55:46 --> Output Class Initialized
INFO - 2022-03-25 06:55:46 --> Security Class Initialized
DEBUG - 2022-03-25 06:55:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 06:55:46 --> Input Class Initialized
INFO - 2022-03-25 06:55:46 --> Language Class Initialized
INFO - 2022-03-25 06:55:46 --> Loader Class Initialized
INFO - 2022-03-25 06:55:46 --> Helper loaded: url_helper
INFO - 2022-03-25 06:55:46 --> Helper loaded: form_helper
INFO - 2022-03-25 06:55:46 --> Helper loaded: common_helper
INFO - 2022-03-25 06:55:46 --> Database Driver Class Initialized
DEBUG - 2022-03-25 06:55:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 06:55:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 06:55:46 --> Controller Class Initialized
INFO - 2022-03-25 06:55:46 --> Form Validation Class Initialized
DEBUG - 2022-03-25 06:55:46 --> Encrypt Class Initialized
DEBUG - 2022-03-25 06:55:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 06:55:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-25 06:55:46 --> Email Class Initialized
INFO - 2022-03-25 06:55:46 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-25 06:55:46 --> Calendar Class Initialized
INFO - 2022-03-25 06:55:46 --> Model "Login_model" initialized
ERROR - 2022-03-25 06:55:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 06:55:49 --> Config Class Initialized
INFO - 2022-03-25 06:55:49 --> Hooks Class Initialized
DEBUG - 2022-03-25 06:55:49 --> UTF-8 Support Enabled
INFO - 2022-03-25 06:55:49 --> Utf8 Class Initialized
INFO - 2022-03-25 06:55:49 --> URI Class Initialized
INFO - 2022-03-25 06:55:49 --> Router Class Initialized
INFO - 2022-03-25 06:55:49 --> Output Class Initialized
INFO - 2022-03-25 06:55:49 --> Security Class Initialized
DEBUG - 2022-03-25 06:55:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 06:55:49 --> Input Class Initialized
INFO - 2022-03-25 06:55:49 --> Language Class Initialized
INFO - 2022-03-25 06:55:49 --> Loader Class Initialized
INFO - 2022-03-25 06:55:49 --> Helper loaded: url_helper
INFO - 2022-03-25 06:55:49 --> Helper loaded: form_helper
INFO - 2022-03-25 06:55:49 --> Helper loaded: common_helper
INFO - 2022-03-25 06:55:49 --> Database Driver Class Initialized
DEBUG - 2022-03-25 06:55:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 06:55:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 06:55:49 --> Controller Class Initialized
INFO - 2022-03-25 06:55:49 --> Form Validation Class Initialized
DEBUG - 2022-03-25 06:55:49 --> Encrypt Class Initialized
INFO - 2022-03-25 06:55:49 --> Model "Diseases_model" initialized
INFO - 2022-03-25 06:55:49 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-25 06:55:49 --> File loaded: /home3/karoteam/public_html/application/views/diseases/index.php
INFO - 2022-03-25 06:55:49 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-25 06:55:49 --> Final output sent to browser
DEBUG - 2022-03-25 06:55:49 --> Total execution time: 0.0104
ERROR - 2022-03-25 06:55:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 06:55:52 --> Config Class Initialized
INFO - 2022-03-25 06:55:52 --> Hooks Class Initialized
DEBUG - 2022-03-25 06:55:52 --> UTF-8 Support Enabled
INFO - 2022-03-25 06:55:52 --> Utf8 Class Initialized
INFO - 2022-03-25 06:55:52 --> URI Class Initialized
INFO - 2022-03-25 06:55:52 --> Router Class Initialized
INFO - 2022-03-25 06:55:52 --> Output Class Initialized
INFO - 2022-03-25 06:55:52 --> Security Class Initialized
DEBUG - 2022-03-25 06:55:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 06:55:52 --> Input Class Initialized
INFO - 2022-03-25 06:55:52 --> Language Class Initialized
ERROR - 2022-03-25 06:55:52 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-25 06:56:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 06:56:01 --> Config Class Initialized
INFO - 2022-03-25 06:56:01 --> Hooks Class Initialized
DEBUG - 2022-03-25 06:56:01 --> UTF-8 Support Enabled
INFO - 2022-03-25 06:56:01 --> Utf8 Class Initialized
INFO - 2022-03-25 06:56:01 --> URI Class Initialized
INFO - 2022-03-25 06:56:01 --> Router Class Initialized
INFO - 2022-03-25 06:56:01 --> Output Class Initialized
INFO - 2022-03-25 06:56:01 --> Security Class Initialized
DEBUG - 2022-03-25 06:56:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 06:56:01 --> Input Class Initialized
INFO - 2022-03-25 06:56:01 --> Language Class Initialized
INFO - 2022-03-25 06:56:01 --> Loader Class Initialized
INFO - 2022-03-25 06:56:01 --> Helper loaded: url_helper
INFO - 2022-03-25 06:56:01 --> Helper loaded: form_helper
INFO - 2022-03-25 06:56:01 --> Helper loaded: common_helper
INFO - 2022-03-25 06:56:01 --> Database Driver Class Initialized
DEBUG - 2022-03-25 06:56:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 06:56:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 06:56:01 --> Controller Class Initialized
INFO - 2022-03-25 06:56:01 --> Form Validation Class Initialized
DEBUG - 2022-03-25 06:56:01 --> Encrypt Class Initialized
INFO - 2022-03-25 06:56:01 --> Model "Patient_model" initialized
INFO - 2022-03-25 06:56:01 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 06:56:01 --> Model "Prefix_master" initialized
INFO - 2022-03-25 06:56:01 --> Model "Users_model" initialized
INFO - 2022-03-25 06:56:01 --> Model "Hospital_model" initialized
INFO - 2022-03-25 06:56:01 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-25 06:56:01 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-25 06:56:01 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-25 06:56:01 --> Final output sent to browser
DEBUG - 2022-03-25 06:56:01 --> Total execution time: 0.0454
ERROR - 2022-03-25 07:00:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 07:00:01 --> Config Class Initialized
INFO - 2022-03-25 07:00:01 --> Hooks Class Initialized
DEBUG - 2022-03-25 07:00:01 --> UTF-8 Support Enabled
INFO - 2022-03-25 07:00:01 --> Utf8 Class Initialized
INFO - 2022-03-25 07:00:01 --> URI Class Initialized
INFO - 2022-03-25 07:00:01 --> Router Class Initialized
INFO - 2022-03-25 07:00:01 --> Output Class Initialized
INFO - 2022-03-25 07:00:01 --> Security Class Initialized
DEBUG - 2022-03-25 07:00:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 07:00:01 --> Input Class Initialized
INFO - 2022-03-25 07:00:01 --> Language Class Initialized
INFO - 2022-03-25 07:00:01 --> Loader Class Initialized
INFO - 2022-03-25 07:00:01 --> Helper loaded: url_helper
INFO - 2022-03-25 07:00:01 --> Helper loaded: form_helper
INFO - 2022-03-25 07:00:01 --> Helper loaded: common_helper
INFO - 2022-03-25 07:00:01 --> Database Driver Class Initialized
DEBUG - 2022-03-25 07:00:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 07:00:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 07:00:01 --> Controller Class Initialized
INFO - 2022-03-25 07:00:01 --> Form Validation Class Initialized
DEBUG - 2022-03-25 07:00:01 --> Encrypt Class Initialized
INFO - 2022-03-25 07:00:01 --> Model "Patient_model" initialized
INFO - 2022-03-25 07:00:01 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 07:00:01 --> Model "Prefix_master" initialized
INFO - 2022-03-25 07:00:01 --> Model "Users_model" initialized
INFO - 2022-03-25 07:00:01 --> Model "Hospital_model" initialized
INFO - 2022-03-25 07:00:02 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-25 07:00:04 --> Final output sent to browser
DEBUG - 2022-03-25 07:00:04 --> Total execution time: 2.3492
ERROR - 2022-03-25 07:01:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 07:01:31 --> Config Class Initialized
INFO - 2022-03-25 07:01:31 --> Hooks Class Initialized
DEBUG - 2022-03-25 07:01:31 --> UTF-8 Support Enabled
INFO - 2022-03-25 07:01:31 --> Utf8 Class Initialized
INFO - 2022-03-25 07:01:31 --> URI Class Initialized
INFO - 2022-03-25 07:01:31 --> Router Class Initialized
INFO - 2022-03-25 07:01:31 --> Output Class Initialized
INFO - 2022-03-25 07:01:31 --> Security Class Initialized
DEBUG - 2022-03-25 07:01:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 07:01:31 --> Input Class Initialized
INFO - 2022-03-25 07:01:31 --> Language Class Initialized
INFO - 2022-03-25 07:01:32 --> Loader Class Initialized
INFO - 2022-03-25 07:01:32 --> Helper loaded: url_helper
INFO - 2022-03-25 07:01:32 --> Helper loaded: form_helper
INFO - 2022-03-25 07:01:32 --> Helper loaded: common_helper
INFO - 2022-03-25 07:01:32 --> Database Driver Class Initialized
DEBUG - 2022-03-25 07:01:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 07:01:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 07:01:32 --> Controller Class Initialized
INFO - 2022-03-25 07:01:32 --> Form Validation Class Initialized
DEBUG - 2022-03-25 07:01:32 --> Encrypt Class Initialized
INFO - 2022-03-25 07:01:32 --> Model "Patient_model" initialized
INFO - 2022-03-25 07:01:32 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 07:01:32 --> Model "Prefix_master" initialized
INFO - 2022-03-25 07:01:32 --> Model "Users_model" initialized
INFO - 2022-03-25 07:01:32 --> Model "Hospital_model" initialized
ERROR - 2022-03-25 07:01:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 07:01:32 --> Config Class Initialized
INFO - 2022-03-25 07:01:32 --> Hooks Class Initialized
DEBUG - 2022-03-25 07:01:32 --> UTF-8 Support Enabled
INFO - 2022-03-25 07:01:32 --> Utf8 Class Initialized
INFO - 2022-03-25 07:01:32 --> URI Class Initialized
INFO - 2022-03-25 07:01:32 --> Router Class Initialized
INFO - 2022-03-25 07:01:32 --> Output Class Initialized
INFO - 2022-03-25 07:01:32 --> Security Class Initialized
DEBUG - 2022-03-25 07:01:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 07:01:32 --> Input Class Initialized
INFO - 2022-03-25 07:01:32 --> Language Class Initialized
INFO - 2022-03-25 07:01:32 --> Loader Class Initialized
INFO - 2022-03-25 07:01:32 --> Helper loaded: url_helper
INFO - 2022-03-25 07:01:32 --> Helper loaded: form_helper
INFO - 2022-03-25 07:01:32 --> Helper loaded: common_helper
INFO - 2022-03-25 07:01:32 --> Database Driver Class Initialized
DEBUG - 2022-03-25 07:01:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 07:01:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 07:01:32 --> Controller Class Initialized
INFO - 2022-03-25 07:01:32 --> Form Validation Class Initialized
DEBUG - 2022-03-25 07:01:32 --> Encrypt Class Initialized
INFO - 2022-03-25 07:01:32 --> Model "Patient_model" initialized
INFO - 2022-03-25 07:01:32 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 07:01:32 --> Model "Prefix_master" initialized
INFO - 2022-03-25 07:01:32 --> Model "Users_model" initialized
INFO - 2022-03-25 07:01:32 --> Model "Hospital_model" initialized
INFO - 2022-03-25 07:01:32 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-25 07:01:32 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-25 07:01:32 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-25 07:01:32 --> Final output sent to browser
DEBUG - 2022-03-25 07:01:32 --> Total execution time: 0.0551
ERROR - 2022-03-25 07:32:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 07:32:15 --> Config Class Initialized
INFO - 2022-03-25 07:32:15 --> Hooks Class Initialized
DEBUG - 2022-03-25 07:32:15 --> UTF-8 Support Enabled
INFO - 2022-03-25 07:32:15 --> Utf8 Class Initialized
INFO - 2022-03-25 07:32:15 --> URI Class Initialized
INFO - 2022-03-25 07:32:15 --> Router Class Initialized
INFO - 2022-03-25 07:32:15 --> Output Class Initialized
INFO - 2022-03-25 07:32:15 --> Security Class Initialized
DEBUG - 2022-03-25 07:32:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 07:32:15 --> Input Class Initialized
INFO - 2022-03-25 07:32:15 --> Language Class Initialized
INFO - 2022-03-25 07:32:15 --> Loader Class Initialized
INFO - 2022-03-25 07:32:15 --> Helper loaded: url_helper
INFO - 2022-03-25 07:32:15 --> Helper loaded: form_helper
INFO - 2022-03-25 07:32:15 --> Helper loaded: common_helper
INFO - 2022-03-25 07:32:15 --> Database Driver Class Initialized
DEBUG - 2022-03-25 07:32:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 07:32:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 07:32:15 --> Controller Class Initialized
INFO - 2022-03-25 07:32:15 --> Form Validation Class Initialized
DEBUG - 2022-03-25 07:32:15 --> Encrypt Class Initialized
DEBUG - 2022-03-25 07:32:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 07:32:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-25 07:32:15 --> Email Class Initialized
INFO - 2022-03-25 07:32:15 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-25 07:32:15 --> Calendar Class Initialized
INFO - 2022-03-25 07:32:15 --> Model "Login_model" initialized
ERROR - 2022-03-25 07:32:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 07:32:15 --> Config Class Initialized
INFO - 2022-03-25 07:32:15 --> Hooks Class Initialized
DEBUG - 2022-03-25 07:32:15 --> UTF-8 Support Enabled
INFO - 2022-03-25 07:32:15 --> Utf8 Class Initialized
INFO - 2022-03-25 07:32:15 --> URI Class Initialized
INFO - 2022-03-25 07:32:15 --> Router Class Initialized
INFO - 2022-03-25 07:32:15 --> Output Class Initialized
INFO - 2022-03-25 07:32:15 --> Security Class Initialized
DEBUG - 2022-03-25 07:32:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 07:32:15 --> Input Class Initialized
INFO - 2022-03-25 07:32:15 --> Language Class Initialized
INFO - 2022-03-25 07:32:15 --> Loader Class Initialized
INFO - 2022-03-25 07:32:15 --> Helper loaded: url_helper
INFO - 2022-03-25 07:32:15 --> Helper loaded: form_helper
INFO - 2022-03-25 07:32:15 --> Helper loaded: common_helper
INFO - 2022-03-25 07:32:15 --> Database Driver Class Initialized
DEBUG - 2022-03-25 07:32:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 07:32:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 07:32:15 --> Controller Class Initialized
INFO - 2022-03-25 07:32:15 --> Form Validation Class Initialized
DEBUG - 2022-03-25 07:32:15 --> Encrypt Class Initialized
DEBUG - 2022-03-25 07:32:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 07:32:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-25 07:32:15 --> Email Class Initialized
INFO - 2022-03-25 07:32:15 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-25 07:32:15 --> Calendar Class Initialized
INFO - 2022-03-25 07:32:15 --> Model "Login_model" initialized
INFO - 2022-03-25 07:32:15 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-25 07:32:15 --> Final output sent to browser
DEBUG - 2022-03-25 07:32:15 --> Total execution time: 0.0061
ERROR - 2022-03-25 07:32:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 07:32:23 --> Config Class Initialized
INFO - 2022-03-25 07:32:23 --> Hooks Class Initialized
DEBUG - 2022-03-25 07:32:23 --> UTF-8 Support Enabled
INFO - 2022-03-25 07:32:23 --> Utf8 Class Initialized
INFO - 2022-03-25 07:32:23 --> URI Class Initialized
INFO - 2022-03-25 07:32:23 --> Router Class Initialized
INFO - 2022-03-25 07:32:23 --> Output Class Initialized
INFO - 2022-03-25 07:32:23 --> Security Class Initialized
DEBUG - 2022-03-25 07:32:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 07:32:23 --> Input Class Initialized
INFO - 2022-03-25 07:32:23 --> Language Class Initialized
INFO - 2022-03-25 07:32:23 --> Loader Class Initialized
INFO - 2022-03-25 07:32:23 --> Helper loaded: url_helper
INFO - 2022-03-25 07:32:23 --> Helper loaded: form_helper
INFO - 2022-03-25 07:32:23 --> Helper loaded: common_helper
INFO - 2022-03-25 07:32:23 --> Database Driver Class Initialized
DEBUG - 2022-03-25 07:32:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 07:32:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 07:32:23 --> Controller Class Initialized
INFO - 2022-03-25 07:32:23 --> Form Validation Class Initialized
DEBUG - 2022-03-25 07:32:23 --> Encrypt Class Initialized
DEBUG - 2022-03-25 07:32:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 07:32:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-25 07:32:23 --> Email Class Initialized
INFO - 2022-03-25 07:32:23 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-25 07:32:23 --> Calendar Class Initialized
INFO - 2022-03-25 07:32:23 --> Model "Login_model" initialized
ERROR - 2022-03-25 07:32:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 07:32:24 --> Config Class Initialized
INFO - 2022-03-25 07:32:24 --> Hooks Class Initialized
DEBUG - 2022-03-25 07:32:24 --> UTF-8 Support Enabled
INFO - 2022-03-25 07:32:24 --> Utf8 Class Initialized
INFO - 2022-03-25 07:32:24 --> URI Class Initialized
INFO - 2022-03-25 07:32:24 --> Router Class Initialized
INFO - 2022-03-25 07:32:24 --> Output Class Initialized
INFO - 2022-03-25 07:32:24 --> Security Class Initialized
DEBUG - 2022-03-25 07:32:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 07:32:24 --> Input Class Initialized
INFO - 2022-03-25 07:32:24 --> Language Class Initialized
INFO - 2022-03-25 07:32:24 --> Loader Class Initialized
INFO - 2022-03-25 07:32:24 --> Helper loaded: url_helper
INFO - 2022-03-25 07:32:24 --> Helper loaded: form_helper
INFO - 2022-03-25 07:32:24 --> Helper loaded: common_helper
INFO - 2022-03-25 07:32:24 --> Database Driver Class Initialized
DEBUG - 2022-03-25 07:32:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 07:32:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 07:32:24 --> Controller Class Initialized
INFO - 2022-03-25 07:32:24 --> Form Validation Class Initialized
DEBUG - 2022-03-25 07:32:24 --> Encrypt Class Initialized
DEBUG - 2022-03-25 07:32:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 07:32:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-25 07:32:24 --> Email Class Initialized
INFO - 2022-03-25 07:32:24 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-25 07:32:24 --> Calendar Class Initialized
INFO - 2022-03-25 07:32:24 --> Model "Login_model" initialized
INFO - 2022-03-25 07:32:24 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-25 07:32:24 --> Final output sent to browser
DEBUG - 2022-03-25 07:32:24 --> Total execution time: 0.0097
ERROR - 2022-03-25 07:37:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 07:37:49 --> Config Class Initialized
INFO - 2022-03-25 07:37:49 --> Hooks Class Initialized
DEBUG - 2022-03-25 07:37:49 --> UTF-8 Support Enabled
INFO - 2022-03-25 07:37:49 --> Utf8 Class Initialized
INFO - 2022-03-25 07:37:49 --> URI Class Initialized
DEBUG - 2022-03-25 07:37:49 --> No URI present. Default controller set.
INFO - 2022-03-25 07:37:49 --> Router Class Initialized
INFO - 2022-03-25 07:37:49 --> Output Class Initialized
INFO - 2022-03-25 07:37:49 --> Security Class Initialized
DEBUG - 2022-03-25 07:37:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 07:37:49 --> Input Class Initialized
INFO - 2022-03-25 07:37:49 --> Language Class Initialized
INFO - 2022-03-25 07:37:49 --> Loader Class Initialized
INFO - 2022-03-25 07:37:49 --> Helper loaded: url_helper
INFO - 2022-03-25 07:37:49 --> Helper loaded: form_helper
INFO - 2022-03-25 07:37:49 --> Helper loaded: common_helper
INFO - 2022-03-25 07:37:49 --> Database Driver Class Initialized
DEBUG - 2022-03-25 07:37:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 07:37:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 07:37:49 --> Controller Class Initialized
INFO - 2022-03-25 07:37:49 --> Form Validation Class Initialized
DEBUG - 2022-03-25 07:37:49 --> Encrypt Class Initialized
DEBUG - 2022-03-25 07:37:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 07:37:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-25 07:37:49 --> Email Class Initialized
INFO - 2022-03-25 07:37:49 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-25 07:37:49 --> Calendar Class Initialized
INFO - 2022-03-25 07:37:49 --> Model "Login_model" initialized
INFO - 2022-03-25 07:37:49 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-25 07:37:49 --> Final output sent to browser
DEBUG - 2022-03-25 07:37:49 --> Total execution time: 0.0629
ERROR - 2022-03-25 07:37:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 07:37:50 --> Config Class Initialized
INFO - 2022-03-25 07:37:50 --> Hooks Class Initialized
DEBUG - 2022-03-25 07:37:50 --> UTF-8 Support Enabled
INFO - 2022-03-25 07:37:50 --> Utf8 Class Initialized
INFO - 2022-03-25 07:37:50 --> URI Class Initialized
DEBUG - 2022-03-25 07:37:50 --> No URI present. Default controller set.
INFO - 2022-03-25 07:37:50 --> Router Class Initialized
INFO - 2022-03-25 07:37:50 --> Output Class Initialized
INFO - 2022-03-25 07:37:50 --> Security Class Initialized
DEBUG - 2022-03-25 07:37:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 07:37:50 --> Input Class Initialized
INFO - 2022-03-25 07:37:50 --> Language Class Initialized
INFO - 2022-03-25 07:37:50 --> Loader Class Initialized
INFO - 2022-03-25 07:37:50 --> Helper loaded: url_helper
INFO - 2022-03-25 07:37:50 --> Helper loaded: form_helper
INFO - 2022-03-25 07:37:50 --> Helper loaded: common_helper
INFO - 2022-03-25 07:37:50 --> Database Driver Class Initialized
DEBUG - 2022-03-25 07:37:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 07:37:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 07:37:50 --> Controller Class Initialized
INFO - 2022-03-25 07:37:50 --> Form Validation Class Initialized
DEBUG - 2022-03-25 07:37:50 --> Encrypt Class Initialized
DEBUG - 2022-03-25 07:37:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 07:37:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-25 07:37:50 --> Email Class Initialized
INFO - 2022-03-25 07:37:50 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-25 07:37:50 --> Calendar Class Initialized
INFO - 2022-03-25 07:37:50 --> Model "Login_model" initialized
INFO - 2022-03-25 07:37:50 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-25 07:37:50 --> Final output sent to browser
DEBUG - 2022-03-25 07:37:50 --> Total execution time: 0.0073
ERROR - 2022-03-25 07:43:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 07:43:54 --> Config Class Initialized
INFO - 2022-03-25 07:43:54 --> Hooks Class Initialized
DEBUG - 2022-03-25 07:43:54 --> UTF-8 Support Enabled
INFO - 2022-03-25 07:43:54 --> Utf8 Class Initialized
INFO - 2022-03-25 07:43:54 --> URI Class Initialized
INFO - 2022-03-25 07:43:54 --> Router Class Initialized
INFO - 2022-03-25 07:43:54 --> Output Class Initialized
INFO - 2022-03-25 07:43:54 --> Security Class Initialized
DEBUG - 2022-03-25 07:43:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 07:43:54 --> Input Class Initialized
INFO - 2022-03-25 07:43:54 --> Language Class Initialized
INFO - 2022-03-25 07:43:54 --> Loader Class Initialized
INFO - 2022-03-25 07:43:54 --> Helper loaded: url_helper
INFO - 2022-03-25 07:43:54 --> Helper loaded: form_helper
INFO - 2022-03-25 07:43:54 --> Helper loaded: common_helper
INFO - 2022-03-25 07:43:54 --> Database Driver Class Initialized
DEBUG - 2022-03-25 07:43:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 07:43:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 07:43:54 --> Controller Class Initialized
INFO - 2022-03-25 07:43:54 --> Form Validation Class Initialized
DEBUG - 2022-03-25 07:43:54 --> Encrypt Class Initialized
INFO - 2022-03-25 07:43:54 --> Model "Patient_model" initialized
INFO - 2022-03-25 07:43:54 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 07:43:54 --> Model "Prefix_master" initialized
INFO - 2022-03-25 07:43:54 --> Model "Users_model" initialized
INFO - 2022-03-25 07:43:54 --> Model "Hospital_model" initialized
INFO - 2022-03-25 07:43:54 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-25 07:43:54 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-25 07:43:54 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-25 07:43:54 --> Final output sent to browser
DEBUG - 2022-03-25 07:43:54 --> Total execution time: 0.1473
ERROR - 2022-03-25 08:54:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 08:54:21 --> Config Class Initialized
INFO - 2022-03-25 08:54:21 --> Hooks Class Initialized
DEBUG - 2022-03-25 08:54:21 --> UTF-8 Support Enabled
INFO - 2022-03-25 08:54:21 --> Utf8 Class Initialized
INFO - 2022-03-25 08:54:21 --> URI Class Initialized
DEBUG - 2022-03-25 08:54:21 --> No URI present. Default controller set.
INFO - 2022-03-25 08:54:21 --> Router Class Initialized
INFO - 2022-03-25 08:54:21 --> Output Class Initialized
INFO - 2022-03-25 08:54:21 --> Security Class Initialized
DEBUG - 2022-03-25 08:54:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 08:54:21 --> Input Class Initialized
INFO - 2022-03-25 08:54:21 --> Language Class Initialized
INFO - 2022-03-25 08:54:21 --> Loader Class Initialized
INFO - 2022-03-25 08:54:21 --> Helper loaded: url_helper
INFO - 2022-03-25 08:54:21 --> Helper loaded: form_helper
INFO - 2022-03-25 08:54:21 --> Helper loaded: common_helper
INFO - 2022-03-25 08:54:21 --> Database Driver Class Initialized
DEBUG - 2022-03-25 08:54:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 08:54:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 08:54:21 --> Controller Class Initialized
INFO - 2022-03-25 08:54:21 --> Form Validation Class Initialized
DEBUG - 2022-03-25 08:54:21 --> Encrypt Class Initialized
DEBUG - 2022-03-25 08:54:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 08:54:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-25 08:54:21 --> Email Class Initialized
INFO - 2022-03-25 08:54:21 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-25 08:54:21 --> Calendar Class Initialized
INFO - 2022-03-25 08:54:21 --> Model "Login_model" initialized
INFO - 2022-03-25 08:54:21 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-25 08:54:21 --> Final output sent to browser
DEBUG - 2022-03-25 08:54:21 --> Total execution time: 0.0646
ERROR - 2022-03-25 10:03:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 10:03:36 --> Config Class Initialized
INFO - 2022-03-25 10:03:36 --> Hooks Class Initialized
DEBUG - 2022-03-25 10:03:36 --> UTF-8 Support Enabled
INFO - 2022-03-25 10:03:36 --> Utf8 Class Initialized
INFO - 2022-03-25 10:03:36 --> URI Class Initialized
DEBUG - 2022-03-25 10:03:36 --> No URI present. Default controller set.
INFO - 2022-03-25 10:03:36 --> Router Class Initialized
INFO - 2022-03-25 10:03:36 --> Output Class Initialized
INFO - 2022-03-25 10:03:36 --> Security Class Initialized
DEBUG - 2022-03-25 10:03:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 10:03:36 --> Input Class Initialized
INFO - 2022-03-25 10:03:36 --> Language Class Initialized
INFO - 2022-03-25 10:03:36 --> Loader Class Initialized
INFO - 2022-03-25 10:03:36 --> Helper loaded: url_helper
INFO - 2022-03-25 10:03:36 --> Helper loaded: form_helper
INFO - 2022-03-25 10:03:36 --> Helper loaded: common_helper
INFO - 2022-03-25 10:03:36 --> Database Driver Class Initialized
DEBUG - 2022-03-25 10:03:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 10:03:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 10:03:36 --> Controller Class Initialized
INFO - 2022-03-25 10:03:36 --> Form Validation Class Initialized
DEBUG - 2022-03-25 10:03:36 --> Encrypt Class Initialized
DEBUG - 2022-03-25 10:03:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 10:03:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-25 10:03:36 --> Email Class Initialized
INFO - 2022-03-25 10:03:36 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-25 10:03:36 --> Calendar Class Initialized
INFO - 2022-03-25 10:03:36 --> Model "Login_model" initialized
INFO - 2022-03-25 10:03:36 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-25 10:03:36 --> Final output sent to browser
DEBUG - 2022-03-25 10:03:36 --> Total execution time: 0.0923
ERROR - 2022-03-25 10:28:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 10:28:51 --> Config Class Initialized
INFO - 2022-03-25 10:28:51 --> Hooks Class Initialized
DEBUG - 2022-03-25 10:28:51 --> UTF-8 Support Enabled
INFO - 2022-03-25 10:28:51 --> Utf8 Class Initialized
INFO - 2022-03-25 10:28:51 --> URI Class Initialized
DEBUG - 2022-03-25 10:28:51 --> No URI present. Default controller set.
INFO - 2022-03-25 10:28:51 --> Router Class Initialized
INFO - 2022-03-25 10:28:51 --> Output Class Initialized
INFO - 2022-03-25 10:28:51 --> Security Class Initialized
DEBUG - 2022-03-25 10:28:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 10:28:51 --> Input Class Initialized
INFO - 2022-03-25 10:28:51 --> Language Class Initialized
INFO - 2022-03-25 10:28:51 --> Loader Class Initialized
INFO - 2022-03-25 10:28:51 --> Helper loaded: url_helper
INFO - 2022-03-25 10:28:51 --> Helper loaded: form_helper
INFO - 2022-03-25 10:28:51 --> Helper loaded: common_helper
INFO - 2022-03-25 10:28:51 --> Database Driver Class Initialized
DEBUG - 2022-03-25 10:28:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 10:28:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 10:28:51 --> Controller Class Initialized
INFO - 2022-03-25 10:28:51 --> Form Validation Class Initialized
DEBUG - 2022-03-25 10:28:51 --> Encrypt Class Initialized
DEBUG - 2022-03-25 10:28:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 10:28:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-25 10:28:51 --> Email Class Initialized
INFO - 2022-03-25 10:28:51 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-25 10:28:51 --> Calendar Class Initialized
INFO - 2022-03-25 10:28:51 --> Model "Login_model" initialized
INFO - 2022-03-25 10:28:51 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-25 10:28:51 --> Final output sent to browser
DEBUG - 2022-03-25 10:28:51 --> Total execution time: 0.0729
ERROR - 2022-03-25 12:29:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 12:29:38 --> Config Class Initialized
INFO - 2022-03-25 12:29:38 --> Hooks Class Initialized
DEBUG - 2022-03-25 12:29:38 --> UTF-8 Support Enabled
INFO - 2022-03-25 12:29:38 --> Utf8 Class Initialized
INFO - 2022-03-25 12:29:38 --> URI Class Initialized
DEBUG - 2022-03-25 12:29:38 --> No URI present. Default controller set.
INFO - 2022-03-25 12:29:38 --> Router Class Initialized
INFO - 2022-03-25 12:29:38 --> Output Class Initialized
INFO - 2022-03-25 12:29:38 --> Security Class Initialized
DEBUG - 2022-03-25 12:29:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 12:29:38 --> Input Class Initialized
INFO - 2022-03-25 12:29:38 --> Language Class Initialized
INFO - 2022-03-25 12:29:38 --> Loader Class Initialized
INFO - 2022-03-25 12:29:38 --> Helper loaded: url_helper
INFO - 2022-03-25 12:29:38 --> Helper loaded: form_helper
INFO - 2022-03-25 12:29:38 --> Helper loaded: common_helper
INFO - 2022-03-25 12:29:38 --> Database Driver Class Initialized
DEBUG - 2022-03-25 12:29:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 12:29:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 12:29:38 --> Controller Class Initialized
INFO - 2022-03-25 12:29:38 --> Form Validation Class Initialized
DEBUG - 2022-03-25 12:29:38 --> Encrypt Class Initialized
DEBUG - 2022-03-25 12:29:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 12:29:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-25 12:29:38 --> Email Class Initialized
INFO - 2022-03-25 12:29:38 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-25 12:29:38 --> Calendar Class Initialized
INFO - 2022-03-25 12:29:38 --> Model "Login_model" initialized
INFO - 2022-03-25 12:29:38 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-25 12:29:38 --> Final output sent to browser
DEBUG - 2022-03-25 12:29:38 --> Total execution time: 0.1036
ERROR - 2022-03-25 14:20:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 14:20:49 --> Config Class Initialized
INFO - 2022-03-25 14:20:49 --> Hooks Class Initialized
DEBUG - 2022-03-25 14:20:49 --> UTF-8 Support Enabled
INFO - 2022-03-25 14:20:49 --> Utf8 Class Initialized
INFO - 2022-03-25 14:20:49 --> URI Class Initialized
DEBUG - 2022-03-25 14:20:49 --> No URI present. Default controller set.
INFO - 2022-03-25 14:20:49 --> Router Class Initialized
INFO - 2022-03-25 14:20:49 --> Output Class Initialized
INFO - 2022-03-25 14:20:49 --> Security Class Initialized
DEBUG - 2022-03-25 14:20:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 14:20:49 --> Input Class Initialized
INFO - 2022-03-25 14:20:49 --> Language Class Initialized
INFO - 2022-03-25 14:20:49 --> Loader Class Initialized
INFO - 2022-03-25 14:20:49 --> Helper loaded: url_helper
INFO - 2022-03-25 14:20:49 --> Helper loaded: form_helper
INFO - 2022-03-25 14:20:49 --> Helper loaded: common_helper
INFO - 2022-03-25 14:20:49 --> Database Driver Class Initialized
DEBUG - 2022-03-25 14:20:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 14:20:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 14:20:49 --> Controller Class Initialized
INFO - 2022-03-25 14:20:49 --> Form Validation Class Initialized
DEBUG - 2022-03-25 14:20:49 --> Encrypt Class Initialized
DEBUG - 2022-03-25 14:20:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 14:20:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-25 14:20:49 --> Email Class Initialized
INFO - 2022-03-25 14:20:49 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-25 14:20:49 --> Calendar Class Initialized
INFO - 2022-03-25 14:20:49 --> Model "Login_model" initialized
INFO - 2022-03-25 14:20:49 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-25 14:20:49 --> Final output sent to browser
DEBUG - 2022-03-25 14:20:49 --> Total execution time: 0.0712
ERROR - 2022-03-25 14:20:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 14:20:49 --> Config Class Initialized
INFO - 2022-03-25 14:20:49 --> Hooks Class Initialized
DEBUG - 2022-03-25 14:20:49 --> UTF-8 Support Enabled
INFO - 2022-03-25 14:20:49 --> Utf8 Class Initialized
INFO - 2022-03-25 14:20:49 --> URI Class Initialized
INFO - 2022-03-25 14:20:49 --> Router Class Initialized
INFO - 2022-03-25 14:20:49 --> Output Class Initialized
INFO - 2022-03-25 14:20:49 --> Security Class Initialized
DEBUG - 2022-03-25 14:20:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 14:20:49 --> Input Class Initialized
INFO - 2022-03-25 14:20:49 --> Language Class Initialized
ERROR - 2022-03-25 14:20:49 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2022-03-25 14:21:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 14:21:02 --> Config Class Initialized
INFO - 2022-03-25 14:21:02 --> Hooks Class Initialized
DEBUG - 2022-03-25 14:21:02 --> UTF-8 Support Enabled
INFO - 2022-03-25 14:21:02 --> Utf8 Class Initialized
INFO - 2022-03-25 14:21:02 --> URI Class Initialized
INFO - 2022-03-25 14:21:02 --> Router Class Initialized
INFO - 2022-03-25 14:21:02 --> Output Class Initialized
INFO - 2022-03-25 14:21:02 --> Security Class Initialized
DEBUG - 2022-03-25 14:21:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 14:21:02 --> Input Class Initialized
INFO - 2022-03-25 14:21:02 --> Language Class Initialized
INFO - 2022-03-25 14:21:02 --> Loader Class Initialized
INFO - 2022-03-25 14:21:02 --> Helper loaded: url_helper
INFO - 2022-03-25 14:21:02 --> Helper loaded: form_helper
INFO - 2022-03-25 14:21:02 --> Helper loaded: common_helper
INFO - 2022-03-25 14:21:02 --> Database Driver Class Initialized
DEBUG - 2022-03-25 14:21:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 14:21:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 14:21:02 --> Controller Class Initialized
INFO - 2022-03-25 14:21:02 --> Form Validation Class Initialized
DEBUG - 2022-03-25 14:21:02 --> Encrypt Class Initialized
DEBUG - 2022-03-25 14:21:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 14:21:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-25 14:21:02 --> Email Class Initialized
INFO - 2022-03-25 14:21:02 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-25 14:21:02 --> Calendar Class Initialized
INFO - 2022-03-25 14:21:02 --> Model "Login_model" initialized
INFO - 2022-03-25 14:21:02 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-25 14:21:02 --> Final output sent to browser
DEBUG - 2022-03-25 14:21:02 --> Total execution time: 0.0057
ERROR - 2022-03-25 14:21:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 14:21:02 --> Config Class Initialized
INFO - 2022-03-25 14:21:02 --> Hooks Class Initialized
DEBUG - 2022-03-25 14:21:02 --> UTF-8 Support Enabled
INFO - 2022-03-25 14:21:02 --> Utf8 Class Initialized
INFO - 2022-03-25 14:21:02 --> URI Class Initialized
DEBUG - 2022-03-25 14:21:02 --> No URI present. Default controller set.
INFO - 2022-03-25 14:21:02 --> Router Class Initialized
INFO - 2022-03-25 14:21:02 --> Output Class Initialized
INFO - 2022-03-25 14:21:02 --> Security Class Initialized
DEBUG - 2022-03-25 14:21:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 14:21:02 --> Input Class Initialized
INFO - 2022-03-25 14:21:02 --> Language Class Initialized
INFO - 2022-03-25 14:21:02 --> Loader Class Initialized
INFO - 2022-03-25 14:21:02 --> Helper loaded: url_helper
INFO - 2022-03-25 14:21:02 --> Helper loaded: form_helper
INFO - 2022-03-25 14:21:02 --> Helper loaded: common_helper
INFO - 2022-03-25 14:21:02 --> Database Driver Class Initialized
DEBUG - 2022-03-25 14:21:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 14:21:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 14:21:02 --> Controller Class Initialized
INFO - 2022-03-25 14:21:02 --> Form Validation Class Initialized
DEBUG - 2022-03-25 14:21:02 --> Encrypt Class Initialized
DEBUG - 2022-03-25 14:21:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 14:21:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-25 14:21:02 --> Email Class Initialized
INFO - 2022-03-25 14:21:02 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-25 14:21:02 --> Calendar Class Initialized
INFO - 2022-03-25 14:21:02 --> Model "Login_model" initialized
INFO - 2022-03-25 14:21:02 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-25 14:21:02 --> Final output sent to browser
DEBUG - 2022-03-25 14:21:02 --> Total execution time: 0.0046
ERROR - 2022-03-25 14:21:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 14:21:03 --> Config Class Initialized
INFO - 2022-03-25 14:21:03 --> Hooks Class Initialized
DEBUG - 2022-03-25 14:21:03 --> UTF-8 Support Enabled
INFO - 2022-03-25 14:21:03 --> Utf8 Class Initialized
INFO - 2022-03-25 14:21:03 --> URI Class Initialized
INFO - 2022-03-25 14:21:03 --> Router Class Initialized
INFO - 2022-03-25 14:21:03 --> Output Class Initialized
INFO - 2022-03-25 14:21:03 --> Security Class Initialized
DEBUG - 2022-03-25 14:21:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 14:21:03 --> Input Class Initialized
INFO - 2022-03-25 14:21:03 --> Language Class Initialized
INFO - 2022-03-25 14:21:03 --> Loader Class Initialized
INFO - 2022-03-25 14:21:03 --> Helper loaded: url_helper
INFO - 2022-03-25 14:21:03 --> Helper loaded: form_helper
INFO - 2022-03-25 14:21:03 --> Helper loaded: common_helper
INFO - 2022-03-25 14:21:03 --> Database Driver Class Initialized
DEBUG - 2022-03-25 14:21:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 14:21:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 14:21:03 --> Controller Class Initialized
INFO - 2022-03-25 14:21:03 --> Form Validation Class Initialized
DEBUG - 2022-03-25 14:21:03 --> Encrypt Class Initialized
DEBUG - 2022-03-25 14:21:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 14:21:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-25 14:21:03 --> Email Class Initialized
INFO - 2022-03-25 14:21:03 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-25 14:21:03 --> Calendar Class Initialized
INFO - 2022-03-25 14:21:03 --> Model "Login_model" initialized
ERROR - 2022-03-25 14:21:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 14:21:03 --> Config Class Initialized
INFO - 2022-03-25 14:21:03 --> Hooks Class Initialized
DEBUG - 2022-03-25 14:21:03 --> UTF-8 Support Enabled
INFO - 2022-03-25 14:21:03 --> Utf8 Class Initialized
INFO - 2022-03-25 14:21:03 --> URI Class Initialized
INFO - 2022-03-25 14:21:03 --> Router Class Initialized
INFO - 2022-03-25 14:21:03 --> Output Class Initialized
INFO - 2022-03-25 14:21:03 --> Security Class Initialized
DEBUG - 2022-03-25 14:21:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 14:21:03 --> Input Class Initialized
INFO - 2022-03-25 14:21:03 --> Language Class Initialized
INFO - 2022-03-25 14:21:03 --> Loader Class Initialized
INFO - 2022-03-25 14:21:03 --> Helper loaded: url_helper
INFO - 2022-03-25 14:21:03 --> Helper loaded: form_helper
INFO - 2022-03-25 14:21:03 --> Helper loaded: common_helper
INFO - 2022-03-25 14:21:03 --> Database Driver Class Initialized
DEBUG - 2022-03-25 14:21:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 14:21:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 14:21:03 --> Controller Class Initialized
INFO - 2022-03-25 14:21:03 --> Form Validation Class Initialized
DEBUG - 2022-03-25 14:21:03 --> Encrypt Class Initialized
DEBUG - 2022-03-25 14:21:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 14:21:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-25 14:21:03 --> Email Class Initialized
INFO - 2022-03-25 14:21:03 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-25 14:21:03 --> Calendar Class Initialized
INFO - 2022-03-25 14:21:03 --> Model "Login_model" initialized
ERROR - 2022-03-25 18:02:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 18:02:51 --> Config Class Initialized
INFO - 2022-03-25 18:02:51 --> Hooks Class Initialized
DEBUG - 2022-03-25 18:02:51 --> UTF-8 Support Enabled
INFO - 2022-03-25 18:02:51 --> Utf8 Class Initialized
INFO - 2022-03-25 18:02:51 --> URI Class Initialized
DEBUG - 2022-03-25 18:02:51 --> No URI present. Default controller set.
INFO - 2022-03-25 18:02:51 --> Router Class Initialized
INFO - 2022-03-25 18:02:51 --> Output Class Initialized
INFO - 2022-03-25 18:02:51 --> Security Class Initialized
DEBUG - 2022-03-25 18:02:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 18:02:51 --> Input Class Initialized
INFO - 2022-03-25 18:02:51 --> Language Class Initialized
INFO - 2022-03-25 18:02:51 --> Loader Class Initialized
INFO - 2022-03-25 18:02:51 --> Helper loaded: url_helper
INFO - 2022-03-25 18:02:51 --> Helper loaded: form_helper
INFO - 2022-03-25 18:02:51 --> Helper loaded: common_helper
INFO - 2022-03-25 18:02:51 --> Database Driver Class Initialized
DEBUG - 2022-03-25 18:02:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 18:02:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 18:02:51 --> Controller Class Initialized
INFO - 2022-03-25 18:02:51 --> Form Validation Class Initialized
DEBUG - 2022-03-25 18:02:51 --> Encrypt Class Initialized
DEBUG - 2022-03-25 18:02:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 18:02:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-25 18:02:51 --> Email Class Initialized
INFO - 2022-03-25 18:02:51 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-25 18:02:51 --> Calendar Class Initialized
INFO - 2022-03-25 18:02:51 --> Model "Login_model" initialized
INFO - 2022-03-25 18:02:51 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-25 18:02:51 --> Final output sent to browser
DEBUG - 2022-03-25 18:02:51 --> Total execution time: 0.1773
ERROR - 2022-03-25 21:28:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 21:28:59 --> Config Class Initialized
INFO - 2022-03-25 21:28:59 --> Hooks Class Initialized
DEBUG - 2022-03-25 21:28:59 --> UTF-8 Support Enabled
INFO - 2022-03-25 21:28:59 --> Utf8 Class Initialized
INFO - 2022-03-25 21:28:59 --> URI Class Initialized
DEBUG - 2022-03-25 21:28:59 --> No URI present. Default controller set.
INFO - 2022-03-25 21:28:59 --> Router Class Initialized
INFO - 2022-03-25 21:28:59 --> Output Class Initialized
INFO - 2022-03-25 21:28:59 --> Security Class Initialized
DEBUG - 2022-03-25 21:28:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 21:28:59 --> Input Class Initialized
INFO - 2022-03-25 21:28:59 --> Language Class Initialized
INFO - 2022-03-25 21:28:59 --> Loader Class Initialized
INFO - 2022-03-25 21:28:59 --> Helper loaded: url_helper
INFO - 2022-03-25 21:28:59 --> Helper loaded: form_helper
INFO - 2022-03-25 21:28:59 --> Helper loaded: common_helper
INFO - 2022-03-25 21:28:59 --> Database Driver Class Initialized
DEBUG - 2022-03-25 21:28:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 21:28:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 21:28:59 --> Controller Class Initialized
INFO - 2022-03-25 21:28:59 --> Form Validation Class Initialized
DEBUG - 2022-03-25 21:28:59 --> Encrypt Class Initialized
DEBUG - 2022-03-25 21:28:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 21:28:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-25 21:28:59 --> Email Class Initialized
INFO - 2022-03-25 21:28:59 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-25 21:28:59 --> Calendar Class Initialized
INFO - 2022-03-25 21:28:59 --> Model "Login_model" initialized
INFO - 2022-03-25 21:28:59 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-25 21:28:59 --> Final output sent to browser
DEBUG - 2022-03-25 21:28:59 --> Total execution time: 0.0759
ERROR - 2022-03-25 22:57:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 22:57:40 --> Config Class Initialized
INFO - 2022-03-25 22:57:40 --> Hooks Class Initialized
DEBUG - 2022-03-25 22:57:40 --> UTF-8 Support Enabled
INFO - 2022-03-25 22:57:40 --> Utf8 Class Initialized
INFO - 2022-03-25 22:57:40 --> URI Class Initialized
DEBUG - 2022-03-25 22:57:40 --> No URI present. Default controller set.
INFO - 2022-03-25 22:57:40 --> Router Class Initialized
INFO - 2022-03-25 22:57:40 --> Output Class Initialized
INFO - 2022-03-25 22:57:40 --> Security Class Initialized
DEBUG - 2022-03-25 22:57:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 22:57:40 --> Input Class Initialized
INFO - 2022-03-25 22:57:40 --> Language Class Initialized
INFO - 2022-03-25 22:57:40 --> Loader Class Initialized
INFO - 2022-03-25 22:57:40 --> Helper loaded: url_helper
INFO - 2022-03-25 22:57:40 --> Helper loaded: form_helper
INFO - 2022-03-25 22:57:40 --> Helper loaded: common_helper
INFO - 2022-03-25 22:57:40 --> Database Driver Class Initialized
DEBUG - 2022-03-25 22:57:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 22:57:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 22:57:40 --> Controller Class Initialized
INFO - 2022-03-25 22:57:40 --> Form Validation Class Initialized
DEBUG - 2022-03-25 22:57:40 --> Encrypt Class Initialized
DEBUG - 2022-03-25 22:57:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 22:57:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-25 22:57:40 --> Email Class Initialized
INFO - 2022-03-25 22:57:40 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-25 22:57:40 --> Calendar Class Initialized
INFO - 2022-03-25 22:57:40 --> Model "Login_model" initialized
INFO - 2022-03-25 22:57:40 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-25 22:57:40 --> Final output sent to browser
DEBUG - 2022-03-25 22:57:40 --> Total execution time: 0.0580
ERROR - 2022-03-25 23:01:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 23:01:01 --> Config Class Initialized
INFO - 2022-03-25 23:01:01 --> Hooks Class Initialized
DEBUG - 2022-03-25 23:01:01 --> UTF-8 Support Enabled
INFO - 2022-03-25 23:01:01 --> Utf8 Class Initialized
INFO - 2022-03-25 23:01:01 --> URI Class Initialized
DEBUG - 2022-03-25 23:01:01 --> No URI present. Default controller set.
INFO - 2022-03-25 23:01:01 --> Router Class Initialized
INFO - 2022-03-25 23:01:01 --> Output Class Initialized
INFO - 2022-03-25 23:01:01 --> Security Class Initialized
DEBUG - 2022-03-25 23:01:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 23:01:01 --> Input Class Initialized
INFO - 2022-03-25 23:01:01 --> Language Class Initialized
INFO - 2022-03-25 23:01:01 --> Loader Class Initialized
INFO - 2022-03-25 23:01:01 --> Helper loaded: url_helper
INFO - 2022-03-25 23:01:01 --> Helper loaded: form_helper
INFO - 2022-03-25 23:01:01 --> Helper loaded: common_helper
INFO - 2022-03-25 23:01:01 --> Database Driver Class Initialized
DEBUG - 2022-03-25 23:01:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 23:01:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 23:01:01 --> Controller Class Initialized
INFO - 2022-03-25 23:01:01 --> Form Validation Class Initialized
DEBUG - 2022-03-25 23:01:01 --> Encrypt Class Initialized
DEBUG - 2022-03-25 23:01:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 23:01:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-25 23:01:01 --> Email Class Initialized
INFO - 2022-03-25 23:01:01 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-25 23:01:01 --> Calendar Class Initialized
INFO - 2022-03-25 23:01:01 --> Model "Login_model" initialized
INFO - 2022-03-25 23:01:01 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-25 23:01:01 --> Final output sent to browser
DEBUG - 2022-03-25 23:01:01 --> Total execution time: 0.0624
ERROR - 2022-03-25 23:01:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 23:01:18 --> Config Class Initialized
INFO - 2022-03-25 23:01:18 --> Hooks Class Initialized
DEBUG - 2022-03-25 23:01:18 --> UTF-8 Support Enabled
INFO - 2022-03-25 23:01:18 --> Utf8 Class Initialized
INFO - 2022-03-25 23:01:18 --> URI Class Initialized
INFO - 2022-03-25 23:01:18 --> Router Class Initialized
INFO - 2022-03-25 23:01:18 --> Output Class Initialized
INFO - 2022-03-25 23:01:18 --> Security Class Initialized
DEBUG - 2022-03-25 23:01:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 23:01:18 --> Input Class Initialized
INFO - 2022-03-25 23:01:18 --> Language Class Initialized
INFO - 2022-03-25 23:01:18 --> Loader Class Initialized
INFO - 2022-03-25 23:01:18 --> Helper loaded: url_helper
INFO - 2022-03-25 23:01:18 --> Helper loaded: form_helper
INFO - 2022-03-25 23:01:18 --> Helper loaded: common_helper
INFO - 2022-03-25 23:01:18 --> Database Driver Class Initialized
DEBUG - 2022-03-25 23:01:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 23:01:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 23:01:18 --> Controller Class Initialized
INFO - 2022-03-25 23:01:18 --> Form Validation Class Initialized
DEBUG - 2022-03-25 23:01:18 --> Encrypt Class Initialized
DEBUG - 2022-03-25 23:01:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 23:01:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-25 23:01:18 --> Email Class Initialized
INFO - 2022-03-25 23:01:18 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-25 23:01:18 --> Calendar Class Initialized
INFO - 2022-03-25 23:01:18 --> Model "Login_model" initialized
INFO - 2022-03-25 23:01:18 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-03-25 23:01:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 23:01:18 --> Config Class Initialized
INFO - 2022-03-25 23:01:18 --> Hooks Class Initialized
DEBUG - 2022-03-25 23:01:18 --> UTF-8 Support Enabled
INFO - 2022-03-25 23:01:18 --> Utf8 Class Initialized
INFO - 2022-03-25 23:01:18 --> URI Class Initialized
INFO - 2022-03-25 23:01:18 --> Router Class Initialized
INFO - 2022-03-25 23:01:18 --> Output Class Initialized
INFO - 2022-03-25 23:01:18 --> Security Class Initialized
DEBUG - 2022-03-25 23:01:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 23:01:18 --> Input Class Initialized
INFO - 2022-03-25 23:01:18 --> Language Class Initialized
INFO - 2022-03-25 23:01:18 --> Loader Class Initialized
INFO - 2022-03-25 23:01:18 --> Helper loaded: url_helper
INFO - 2022-03-25 23:01:18 --> Helper loaded: form_helper
INFO - 2022-03-25 23:01:18 --> Helper loaded: common_helper
INFO - 2022-03-25 23:01:18 --> Database Driver Class Initialized
DEBUG - 2022-03-25 23:01:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 23:01:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 23:01:18 --> Controller Class Initialized
INFO - 2022-03-25 23:01:18 --> Form Validation Class Initialized
DEBUG - 2022-03-25 23:01:18 --> Encrypt Class Initialized
INFO - 2022-03-25 23:01:18 --> Model "Login_model" initialized
INFO - 2022-03-25 23:01:18 --> Model "Dashboard_model" initialized
INFO - 2022-03-25 23:01:18 --> Model "Case_model" initialized
INFO - 2022-03-25 23:01:19 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-25 23:01:19 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2022-03-25 23:01:19 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-25 23:01:19 --> Final output sent to browser
DEBUG - 2022-03-25 23:01:19 --> Total execution time: 0.9524
ERROR - 2022-03-25 23:01:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-25 23:01:32 --> Config Class Initialized
INFO - 2022-03-25 23:01:32 --> Hooks Class Initialized
DEBUG - 2022-03-25 23:01:32 --> UTF-8 Support Enabled
INFO - 2022-03-25 23:01:32 --> Utf8 Class Initialized
INFO - 2022-03-25 23:01:32 --> URI Class Initialized
INFO - 2022-03-25 23:01:32 --> Router Class Initialized
INFO - 2022-03-25 23:01:32 --> Output Class Initialized
INFO - 2022-03-25 23:01:32 --> Security Class Initialized
DEBUG - 2022-03-25 23:01:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-25 23:01:32 --> Input Class Initialized
INFO - 2022-03-25 23:01:32 --> Language Class Initialized
INFO - 2022-03-25 23:01:32 --> Loader Class Initialized
INFO - 2022-03-25 23:01:32 --> Helper loaded: url_helper
INFO - 2022-03-25 23:01:32 --> Helper loaded: form_helper
INFO - 2022-03-25 23:01:32 --> Helper loaded: common_helper
INFO - 2022-03-25 23:01:32 --> Database Driver Class Initialized
DEBUG - 2022-03-25 23:01:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-25 23:01:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-25 23:01:32 --> Controller Class Initialized
INFO - 2022-03-25 23:01:32 --> Form Validation Class Initialized
DEBUG - 2022-03-25 23:01:32 --> Encrypt Class Initialized
INFO - 2022-03-25 23:01:32 --> Model "Patient_model" initialized
INFO - 2022-03-25 23:01:32 --> Model "Patientcase_model" initialized
INFO - 2022-03-25 23:01:32 --> Model "Referredby_model" initialized
INFO - 2022-03-25 23:01:32 --> Model "Prefix_master" initialized
INFO - 2022-03-25 23:01:32 --> Model "Hospital_model" initialized
INFO - 2022-03-25 23:01:32 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-25 23:01:32 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-25 23:01:32 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-25 23:01:32 --> Final output sent to browser
DEBUG - 2022-03-25 23:01:32 --> Total execution time: 0.1586
