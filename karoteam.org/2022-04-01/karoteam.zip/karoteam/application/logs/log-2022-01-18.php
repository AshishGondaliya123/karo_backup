<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-01-18 03:13:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-18 03:13:01 --> Config Class Initialized
INFO - 2022-01-18 03:13:01 --> Hooks Class Initialized
DEBUG - 2022-01-18 03:13:01 --> UTF-8 Support Enabled
INFO - 2022-01-18 03:13:01 --> Utf8 Class Initialized
INFO - 2022-01-18 03:13:01 --> URI Class Initialized
DEBUG - 2022-01-18 03:13:01 --> No URI present. Default controller set.
INFO - 2022-01-18 03:13:01 --> Router Class Initialized
INFO - 2022-01-18 03:13:01 --> Output Class Initialized
INFO - 2022-01-18 03:13:01 --> Security Class Initialized
DEBUG - 2022-01-18 03:13:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 03:13:01 --> Input Class Initialized
INFO - 2022-01-18 03:13:01 --> Language Class Initialized
INFO - 2022-01-18 03:13:01 --> Loader Class Initialized
INFO - 2022-01-18 03:13:01 --> Helper loaded: url_helper
INFO - 2022-01-18 03:13:01 --> Helper loaded: form_helper
INFO - 2022-01-18 03:13:01 --> Helper loaded: common_helper
INFO - 2022-01-18 03:13:01 --> Database Driver Class Initialized
DEBUG - 2022-01-18 03:13:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 03:13:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 03:13:01 --> Controller Class Initialized
INFO - 2022-01-18 03:13:01 --> Form Validation Class Initialized
DEBUG - 2022-01-18 03:13:01 --> Encrypt Class Initialized
DEBUG - 2022-01-18 03:13:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-18 03:13:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-18 03:13:01 --> Email Class Initialized
INFO - 2022-01-18 03:13:01 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-18 03:13:01 --> Calendar Class Initialized
INFO - 2022-01-18 03:13:01 --> Model "Login_model" initialized
INFO - 2022-01-18 03:13:01 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-18 03:13:01 --> Final output sent to browser
DEBUG - 2022-01-18 03:13:01 --> Total execution time: 0.0271
ERROR - 2022-01-18 07:39:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-18 07:39:41 --> Config Class Initialized
INFO - 2022-01-18 07:39:41 --> Hooks Class Initialized
DEBUG - 2022-01-18 07:39:41 --> UTF-8 Support Enabled
INFO - 2022-01-18 07:39:41 --> Utf8 Class Initialized
INFO - 2022-01-18 07:39:41 --> URI Class Initialized
DEBUG - 2022-01-18 07:39:41 --> No URI present. Default controller set.
INFO - 2022-01-18 07:39:41 --> Router Class Initialized
INFO - 2022-01-18 07:39:41 --> Output Class Initialized
INFO - 2022-01-18 07:39:41 --> Security Class Initialized
DEBUG - 2022-01-18 07:39:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 07:39:41 --> Input Class Initialized
INFO - 2022-01-18 07:39:41 --> Language Class Initialized
INFO - 2022-01-18 07:39:41 --> Loader Class Initialized
INFO - 2022-01-18 07:39:41 --> Helper loaded: url_helper
INFO - 2022-01-18 07:39:41 --> Helper loaded: form_helper
INFO - 2022-01-18 07:39:41 --> Helper loaded: common_helper
INFO - 2022-01-18 07:39:41 --> Database Driver Class Initialized
DEBUG - 2022-01-18 07:39:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 07:39:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 07:39:41 --> Controller Class Initialized
INFO - 2022-01-18 07:39:41 --> Form Validation Class Initialized
DEBUG - 2022-01-18 07:39:41 --> Encrypt Class Initialized
DEBUG - 2022-01-18 07:39:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-18 07:39:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-18 07:39:41 --> Email Class Initialized
INFO - 2022-01-18 07:39:41 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-18 07:39:41 --> Calendar Class Initialized
INFO - 2022-01-18 07:39:41 --> Model "Login_model" initialized
INFO - 2022-01-18 07:39:41 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-18 07:39:41 --> Final output sent to browser
DEBUG - 2022-01-18 07:39:41 --> Total execution time: 0.0267
ERROR - 2022-01-18 09:05:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-18 09:05:09 --> Config Class Initialized
INFO - 2022-01-18 09:05:09 --> Hooks Class Initialized
DEBUG - 2022-01-18 09:05:09 --> UTF-8 Support Enabled
INFO - 2022-01-18 09:05:09 --> Utf8 Class Initialized
INFO - 2022-01-18 09:05:09 --> URI Class Initialized
DEBUG - 2022-01-18 09:05:09 --> No URI present. Default controller set.
INFO - 2022-01-18 09:05:09 --> Router Class Initialized
INFO - 2022-01-18 09:05:09 --> Output Class Initialized
INFO - 2022-01-18 09:05:09 --> Security Class Initialized
DEBUG - 2022-01-18 09:05:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 09:05:09 --> Input Class Initialized
INFO - 2022-01-18 09:05:09 --> Language Class Initialized
INFO - 2022-01-18 09:05:09 --> Loader Class Initialized
INFO - 2022-01-18 09:05:09 --> Helper loaded: url_helper
INFO - 2022-01-18 09:05:09 --> Helper loaded: form_helper
INFO - 2022-01-18 09:05:09 --> Helper loaded: common_helper
INFO - 2022-01-18 09:05:09 --> Database Driver Class Initialized
DEBUG - 2022-01-18 09:05:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 09:05:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 09:05:09 --> Controller Class Initialized
INFO - 2022-01-18 09:05:09 --> Form Validation Class Initialized
DEBUG - 2022-01-18 09:05:09 --> Encrypt Class Initialized
DEBUG - 2022-01-18 09:05:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-18 09:05:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-18 09:05:09 --> Email Class Initialized
INFO - 2022-01-18 09:05:09 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-18 09:05:09 --> Calendar Class Initialized
INFO - 2022-01-18 09:05:09 --> Model "Login_model" initialized
INFO - 2022-01-18 09:05:09 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-18 09:05:09 --> Final output sent to browser
DEBUG - 2022-01-18 09:05:09 --> Total execution time: 0.0235
ERROR - 2022-01-18 10:45:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-18 10:45:44 --> Config Class Initialized
INFO - 2022-01-18 10:45:44 --> Hooks Class Initialized
DEBUG - 2022-01-18 10:45:44 --> UTF-8 Support Enabled
INFO - 2022-01-18 10:45:44 --> Utf8 Class Initialized
INFO - 2022-01-18 10:45:44 --> URI Class Initialized
DEBUG - 2022-01-18 10:45:44 --> No URI present. Default controller set.
INFO - 2022-01-18 10:45:44 --> Router Class Initialized
INFO - 2022-01-18 10:45:44 --> Output Class Initialized
INFO - 2022-01-18 10:45:44 --> Security Class Initialized
DEBUG - 2022-01-18 10:45:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 10:45:44 --> Input Class Initialized
INFO - 2022-01-18 10:45:44 --> Language Class Initialized
INFO - 2022-01-18 10:45:44 --> Loader Class Initialized
INFO - 2022-01-18 10:45:44 --> Helper loaded: url_helper
INFO - 2022-01-18 10:45:44 --> Helper loaded: form_helper
INFO - 2022-01-18 10:45:44 --> Helper loaded: common_helper
INFO - 2022-01-18 10:45:44 --> Database Driver Class Initialized
DEBUG - 2022-01-18 10:45:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 10:45:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 10:45:44 --> Controller Class Initialized
INFO - 2022-01-18 10:45:44 --> Form Validation Class Initialized
DEBUG - 2022-01-18 10:45:44 --> Encrypt Class Initialized
DEBUG - 2022-01-18 10:45:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-18 10:45:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-18 10:45:44 --> Email Class Initialized
INFO - 2022-01-18 10:45:44 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-18 10:45:44 --> Calendar Class Initialized
INFO - 2022-01-18 10:45:44 --> Model "Login_model" initialized
INFO - 2022-01-18 10:45:44 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-18 10:45:44 --> Final output sent to browser
DEBUG - 2022-01-18 10:45:44 --> Total execution time: 0.0513
ERROR - 2022-01-18 13:25:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-18 13:25:03 --> Config Class Initialized
INFO - 2022-01-18 13:25:03 --> Hooks Class Initialized
DEBUG - 2022-01-18 13:25:03 --> UTF-8 Support Enabled
INFO - 2022-01-18 13:25:03 --> Utf8 Class Initialized
INFO - 2022-01-18 13:25:03 --> URI Class Initialized
DEBUG - 2022-01-18 13:25:03 --> No URI present. Default controller set.
INFO - 2022-01-18 13:25:03 --> Router Class Initialized
INFO - 2022-01-18 13:25:03 --> Output Class Initialized
INFO - 2022-01-18 13:25:03 --> Security Class Initialized
DEBUG - 2022-01-18 13:25:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 13:25:03 --> Input Class Initialized
INFO - 2022-01-18 13:25:03 --> Language Class Initialized
INFO - 2022-01-18 13:25:03 --> Loader Class Initialized
INFO - 2022-01-18 13:25:03 --> Helper loaded: url_helper
INFO - 2022-01-18 13:25:03 --> Helper loaded: form_helper
INFO - 2022-01-18 13:25:03 --> Helper loaded: common_helper
INFO - 2022-01-18 13:25:03 --> Database Driver Class Initialized
DEBUG - 2022-01-18 13:25:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 13:25:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 13:25:03 --> Controller Class Initialized
INFO - 2022-01-18 13:25:03 --> Form Validation Class Initialized
DEBUG - 2022-01-18 13:25:03 --> Encrypt Class Initialized
DEBUG - 2022-01-18 13:25:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-18 13:25:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-18 13:25:03 --> Email Class Initialized
INFO - 2022-01-18 13:25:03 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-18 13:25:03 --> Calendar Class Initialized
INFO - 2022-01-18 13:25:03 --> Model "Login_model" initialized
INFO - 2022-01-18 13:25:03 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-18 13:25:03 --> Final output sent to browser
DEBUG - 2022-01-18 13:25:03 --> Total execution time: 0.0275
ERROR - 2022-01-18 14:16:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-18 14:16:38 --> Config Class Initialized
INFO - 2022-01-18 14:16:38 --> Hooks Class Initialized
DEBUG - 2022-01-18 14:16:38 --> UTF-8 Support Enabled
INFO - 2022-01-18 14:16:38 --> Utf8 Class Initialized
INFO - 2022-01-18 14:16:38 --> URI Class Initialized
DEBUG - 2022-01-18 14:16:38 --> No URI present. Default controller set.
INFO - 2022-01-18 14:16:38 --> Router Class Initialized
INFO - 2022-01-18 14:16:38 --> Output Class Initialized
INFO - 2022-01-18 14:16:38 --> Security Class Initialized
DEBUG - 2022-01-18 14:16:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 14:16:38 --> Input Class Initialized
INFO - 2022-01-18 14:16:38 --> Language Class Initialized
INFO - 2022-01-18 14:16:38 --> Loader Class Initialized
INFO - 2022-01-18 14:16:38 --> Helper loaded: url_helper
INFO - 2022-01-18 14:16:38 --> Helper loaded: form_helper
INFO - 2022-01-18 14:16:38 --> Helper loaded: common_helper
INFO - 2022-01-18 14:16:38 --> Database Driver Class Initialized
DEBUG - 2022-01-18 14:16:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 14:16:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 14:16:38 --> Controller Class Initialized
INFO - 2022-01-18 14:16:38 --> Form Validation Class Initialized
DEBUG - 2022-01-18 14:16:38 --> Encrypt Class Initialized
DEBUG - 2022-01-18 14:16:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-18 14:16:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-18 14:16:38 --> Email Class Initialized
INFO - 2022-01-18 14:16:38 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-18 14:16:38 --> Calendar Class Initialized
INFO - 2022-01-18 14:16:38 --> Model "Login_model" initialized
INFO - 2022-01-18 14:16:38 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-18 14:16:38 --> Final output sent to browser
DEBUG - 2022-01-18 14:16:38 --> Total execution time: 0.0236
ERROR - 2022-01-18 14:16:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-18 14:16:39 --> Config Class Initialized
INFO - 2022-01-18 14:16:39 --> Hooks Class Initialized
DEBUG - 2022-01-18 14:16:39 --> UTF-8 Support Enabled
INFO - 2022-01-18 14:16:39 --> Utf8 Class Initialized
INFO - 2022-01-18 14:16:39 --> URI Class Initialized
INFO - 2022-01-18 14:16:39 --> Router Class Initialized
INFO - 2022-01-18 14:16:39 --> Output Class Initialized
INFO - 2022-01-18 14:16:39 --> Security Class Initialized
DEBUG - 2022-01-18 14:16:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 14:16:39 --> Input Class Initialized
INFO - 2022-01-18 14:16:39 --> Language Class Initialized
ERROR - 2022-01-18 14:16:39 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2022-01-18 14:17:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-18 14:17:00 --> Config Class Initialized
INFO - 2022-01-18 14:17:00 --> Hooks Class Initialized
DEBUG - 2022-01-18 14:17:00 --> UTF-8 Support Enabled
INFO - 2022-01-18 14:17:00 --> Utf8 Class Initialized
INFO - 2022-01-18 14:17:00 --> URI Class Initialized
INFO - 2022-01-18 14:17:00 --> Router Class Initialized
INFO - 2022-01-18 14:17:00 --> Output Class Initialized
INFO - 2022-01-18 14:17:00 --> Security Class Initialized
DEBUG - 2022-01-18 14:17:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 14:17:00 --> Input Class Initialized
INFO - 2022-01-18 14:17:00 --> Language Class Initialized
INFO - 2022-01-18 14:17:00 --> Loader Class Initialized
INFO - 2022-01-18 14:17:00 --> Helper loaded: url_helper
INFO - 2022-01-18 14:17:00 --> Helper loaded: form_helper
INFO - 2022-01-18 14:17:00 --> Helper loaded: common_helper
INFO - 2022-01-18 14:17:00 --> Database Driver Class Initialized
DEBUG - 2022-01-18 14:17:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 14:17:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 14:17:00 --> Controller Class Initialized
INFO - 2022-01-18 14:17:00 --> Form Validation Class Initialized
DEBUG - 2022-01-18 14:17:00 --> Encrypt Class Initialized
DEBUG - 2022-01-18 14:17:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-18 14:17:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-18 14:17:00 --> Email Class Initialized
INFO - 2022-01-18 14:17:00 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-18 14:17:00 --> Calendar Class Initialized
INFO - 2022-01-18 14:17:00 --> Model "Login_model" initialized
ERROR - 2022-01-18 14:17:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-18 14:17:01 --> Config Class Initialized
INFO - 2022-01-18 14:17:01 --> Hooks Class Initialized
DEBUG - 2022-01-18 14:17:01 --> UTF-8 Support Enabled
INFO - 2022-01-18 14:17:01 --> Utf8 Class Initialized
INFO - 2022-01-18 14:17:01 --> URI Class Initialized
INFO - 2022-01-18 14:17:01 --> Router Class Initialized
INFO - 2022-01-18 14:17:01 --> Output Class Initialized
INFO - 2022-01-18 14:17:01 --> Security Class Initialized
DEBUG - 2022-01-18 14:17:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 14:17:01 --> Input Class Initialized
INFO - 2022-01-18 14:17:01 --> Language Class Initialized
INFO - 2022-01-18 14:17:01 --> Loader Class Initialized
INFO - 2022-01-18 14:17:01 --> Helper loaded: url_helper
INFO - 2022-01-18 14:17:01 --> Helper loaded: form_helper
INFO - 2022-01-18 14:17:01 --> Helper loaded: common_helper
INFO - 2022-01-18 14:17:01 --> Database Driver Class Initialized
DEBUG - 2022-01-18 14:17:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 14:17:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 14:17:01 --> Controller Class Initialized
INFO - 2022-01-18 14:17:01 --> Form Validation Class Initialized
DEBUG - 2022-01-18 14:17:01 --> Encrypt Class Initialized
DEBUG - 2022-01-18 14:17:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-18 14:17:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-18 14:17:01 --> Email Class Initialized
INFO - 2022-01-18 14:17:01 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-18 14:17:01 --> Calendar Class Initialized
INFO - 2022-01-18 14:17:01 --> Model "Login_model" initialized
ERROR - 2022-01-18 14:17:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-18 14:17:02 --> Config Class Initialized
INFO - 2022-01-18 14:17:02 --> Hooks Class Initialized
DEBUG - 2022-01-18 14:17:02 --> UTF-8 Support Enabled
INFO - 2022-01-18 14:17:02 --> Utf8 Class Initialized
INFO - 2022-01-18 14:17:02 --> URI Class Initialized
INFO - 2022-01-18 14:17:02 --> Router Class Initialized
INFO - 2022-01-18 14:17:02 --> Output Class Initialized
INFO - 2022-01-18 14:17:02 --> Security Class Initialized
DEBUG - 2022-01-18 14:17:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 14:17:02 --> Input Class Initialized
INFO - 2022-01-18 14:17:02 --> Language Class Initialized
INFO - 2022-01-18 14:17:02 --> Loader Class Initialized
INFO - 2022-01-18 14:17:02 --> Helper loaded: url_helper
INFO - 2022-01-18 14:17:02 --> Helper loaded: form_helper
INFO - 2022-01-18 14:17:02 --> Helper loaded: common_helper
INFO - 2022-01-18 14:17:02 --> Database Driver Class Initialized
DEBUG - 2022-01-18 14:17:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 14:17:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 14:17:02 --> Controller Class Initialized
INFO - 2022-01-18 14:17:02 --> Form Validation Class Initialized
DEBUG - 2022-01-18 14:17:02 --> Encrypt Class Initialized
DEBUG - 2022-01-18 14:17:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-18 14:17:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-18 14:17:02 --> Email Class Initialized
INFO - 2022-01-18 14:17:02 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-18 14:17:02 --> Calendar Class Initialized
INFO - 2022-01-18 14:17:02 --> Model "Login_model" initialized
INFO - 2022-01-18 14:17:02 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-18 14:17:02 --> Final output sent to browser
DEBUG - 2022-01-18 14:17:02 --> Total execution time: 0.0270
ERROR - 2022-01-18 14:17:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-18 14:17:02 --> Config Class Initialized
INFO - 2022-01-18 14:17:02 --> Hooks Class Initialized
DEBUG - 2022-01-18 14:17:02 --> UTF-8 Support Enabled
INFO - 2022-01-18 14:17:02 --> Utf8 Class Initialized
INFO - 2022-01-18 14:17:02 --> URI Class Initialized
DEBUG - 2022-01-18 14:17:02 --> No URI present. Default controller set.
INFO - 2022-01-18 14:17:02 --> Router Class Initialized
INFO - 2022-01-18 14:17:02 --> Output Class Initialized
INFO - 2022-01-18 14:17:02 --> Security Class Initialized
DEBUG - 2022-01-18 14:17:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 14:17:02 --> Input Class Initialized
INFO - 2022-01-18 14:17:02 --> Language Class Initialized
INFO - 2022-01-18 14:17:02 --> Loader Class Initialized
INFO - 2022-01-18 14:17:02 --> Helper loaded: url_helper
INFO - 2022-01-18 14:17:02 --> Helper loaded: form_helper
INFO - 2022-01-18 14:17:02 --> Helper loaded: common_helper
INFO - 2022-01-18 14:17:02 --> Database Driver Class Initialized
DEBUG - 2022-01-18 14:17:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 14:17:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 14:17:02 --> Controller Class Initialized
INFO - 2022-01-18 14:17:02 --> Form Validation Class Initialized
DEBUG - 2022-01-18 14:17:02 --> Encrypt Class Initialized
DEBUG - 2022-01-18 14:17:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-18 14:17:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-18 14:17:03 --> Email Class Initialized
INFO - 2022-01-18 14:17:03 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-18 14:17:03 --> Calendar Class Initialized
INFO - 2022-01-18 14:17:03 --> Model "Login_model" initialized
INFO - 2022-01-18 14:17:03 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-18 14:17:03 --> Final output sent to browser
DEBUG - 2022-01-18 14:17:03 --> Total execution time: 0.0221
ERROR - 2022-01-18 15:18:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-18 15:18:37 --> Config Class Initialized
INFO - 2022-01-18 15:18:37 --> Hooks Class Initialized
DEBUG - 2022-01-18 15:18:37 --> UTF-8 Support Enabled
INFO - 2022-01-18 15:18:37 --> Utf8 Class Initialized
INFO - 2022-01-18 15:18:37 --> URI Class Initialized
DEBUG - 2022-01-18 15:18:37 --> No URI present. Default controller set.
INFO - 2022-01-18 15:18:37 --> Router Class Initialized
INFO - 2022-01-18 15:18:37 --> Output Class Initialized
INFO - 2022-01-18 15:18:37 --> Security Class Initialized
DEBUG - 2022-01-18 15:18:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 15:18:37 --> Input Class Initialized
INFO - 2022-01-18 15:18:37 --> Language Class Initialized
INFO - 2022-01-18 15:18:37 --> Loader Class Initialized
INFO - 2022-01-18 15:18:37 --> Helper loaded: url_helper
INFO - 2022-01-18 15:18:37 --> Helper loaded: form_helper
INFO - 2022-01-18 15:18:37 --> Helper loaded: common_helper
INFO - 2022-01-18 15:18:37 --> Database Driver Class Initialized
DEBUG - 2022-01-18 15:18:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 15:18:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 15:18:37 --> Controller Class Initialized
INFO - 2022-01-18 15:18:37 --> Form Validation Class Initialized
DEBUG - 2022-01-18 15:18:37 --> Encrypt Class Initialized
DEBUG - 2022-01-18 15:18:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-18 15:18:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-18 15:18:37 --> Email Class Initialized
INFO - 2022-01-18 15:18:37 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-18 15:18:37 --> Calendar Class Initialized
INFO - 2022-01-18 15:18:37 --> Model "Login_model" initialized
INFO - 2022-01-18 15:18:37 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-18 15:18:37 --> Final output sent to browser
DEBUG - 2022-01-18 15:18:37 --> Total execution time: 0.0239
ERROR - 2022-01-18 16:59:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-18 16:59:00 --> Config Class Initialized
INFO - 2022-01-18 16:59:00 --> Hooks Class Initialized
DEBUG - 2022-01-18 16:59:00 --> UTF-8 Support Enabled
INFO - 2022-01-18 16:59:00 --> Utf8 Class Initialized
INFO - 2022-01-18 16:59:00 --> URI Class Initialized
DEBUG - 2022-01-18 16:59:00 --> No URI present. Default controller set.
INFO - 2022-01-18 16:59:00 --> Router Class Initialized
INFO - 2022-01-18 16:59:00 --> Output Class Initialized
INFO - 2022-01-18 16:59:00 --> Security Class Initialized
DEBUG - 2022-01-18 16:59:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 16:59:00 --> Input Class Initialized
INFO - 2022-01-18 16:59:00 --> Language Class Initialized
INFO - 2022-01-18 16:59:00 --> Loader Class Initialized
INFO - 2022-01-18 16:59:00 --> Helper loaded: url_helper
INFO - 2022-01-18 16:59:00 --> Helper loaded: form_helper
INFO - 2022-01-18 16:59:00 --> Helper loaded: common_helper
INFO - 2022-01-18 16:59:00 --> Database Driver Class Initialized
DEBUG - 2022-01-18 16:59:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 16:59:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 16:59:00 --> Controller Class Initialized
INFO - 2022-01-18 16:59:00 --> Form Validation Class Initialized
DEBUG - 2022-01-18 16:59:00 --> Encrypt Class Initialized
DEBUG - 2022-01-18 16:59:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-18 16:59:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-18 16:59:00 --> Email Class Initialized
INFO - 2022-01-18 16:59:00 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-18 16:59:00 --> Calendar Class Initialized
INFO - 2022-01-18 16:59:00 --> Model "Login_model" initialized
INFO - 2022-01-18 16:59:00 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-18 16:59:00 --> Final output sent to browser
DEBUG - 2022-01-18 16:59:00 --> Total execution time: 0.0240
ERROR - 2022-01-18 18:53:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-18 18:53:45 --> Config Class Initialized
INFO - 2022-01-18 18:53:45 --> Hooks Class Initialized
DEBUG - 2022-01-18 18:53:45 --> UTF-8 Support Enabled
INFO - 2022-01-18 18:53:45 --> Utf8 Class Initialized
INFO - 2022-01-18 18:53:45 --> URI Class Initialized
DEBUG - 2022-01-18 18:53:45 --> No URI present. Default controller set.
INFO - 2022-01-18 18:53:45 --> Router Class Initialized
INFO - 2022-01-18 18:53:45 --> Output Class Initialized
INFO - 2022-01-18 18:53:45 --> Security Class Initialized
DEBUG - 2022-01-18 18:53:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 18:53:45 --> Input Class Initialized
INFO - 2022-01-18 18:53:45 --> Language Class Initialized
INFO - 2022-01-18 18:53:45 --> Loader Class Initialized
INFO - 2022-01-18 18:53:45 --> Helper loaded: url_helper
INFO - 2022-01-18 18:53:45 --> Helper loaded: form_helper
INFO - 2022-01-18 18:53:45 --> Helper loaded: common_helper
INFO - 2022-01-18 18:53:45 --> Database Driver Class Initialized
DEBUG - 2022-01-18 18:53:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 18:53:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 18:53:45 --> Controller Class Initialized
INFO - 2022-01-18 18:53:45 --> Form Validation Class Initialized
DEBUG - 2022-01-18 18:53:45 --> Encrypt Class Initialized
DEBUG - 2022-01-18 18:53:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-18 18:53:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-18 18:53:45 --> Email Class Initialized
INFO - 2022-01-18 18:53:45 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-18 18:53:45 --> Calendar Class Initialized
INFO - 2022-01-18 18:53:45 --> Model "Login_model" initialized
INFO - 2022-01-18 18:53:45 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-18 18:53:45 --> Final output sent to browser
DEBUG - 2022-01-18 18:53:45 --> Total execution time: 0.0215
ERROR - 2022-01-18 23:05:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-18 23:05:37 --> Config Class Initialized
INFO - 2022-01-18 23:05:37 --> Hooks Class Initialized
DEBUG - 2022-01-18 23:05:37 --> UTF-8 Support Enabled
INFO - 2022-01-18 23:05:37 --> Utf8 Class Initialized
INFO - 2022-01-18 23:05:37 --> URI Class Initialized
DEBUG - 2022-01-18 23:05:37 --> No URI present. Default controller set.
INFO - 2022-01-18 23:05:37 --> Router Class Initialized
INFO - 2022-01-18 23:05:37 --> Output Class Initialized
INFO - 2022-01-18 23:05:37 --> Security Class Initialized
DEBUG - 2022-01-18 23:05:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-18 23:05:37 --> Input Class Initialized
INFO - 2022-01-18 23:05:37 --> Language Class Initialized
INFO - 2022-01-18 23:05:37 --> Loader Class Initialized
INFO - 2022-01-18 23:05:37 --> Helper loaded: url_helper
INFO - 2022-01-18 23:05:37 --> Helper loaded: form_helper
INFO - 2022-01-18 23:05:37 --> Helper loaded: common_helper
INFO - 2022-01-18 23:05:37 --> Database Driver Class Initialized
DEBUG - 2022-01-18 23:05:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-18 23:05:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-18 23:05:37 --> Controller Class Initialized
INFO - 2022-01-18 23:05:37 --> Form Validation Class Initialized
DEBUG - 2022-01-18 23:05:37 --> Encrypt Class Initialized
DEBUG - 2022-01-18 23:05:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-18 23:05:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-18 23:05:37 --> Email Class Initialized
INFO - 2022-01-18 23:05:37 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-18 23:05:37 --> Calendar Class Initialized
INFO - 2022-01-18 23:05:37 --> Model "Login_model" initialized
INFO - 2022-01-18 23:05:37 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-18 23:05:37 --> Final output sent to browser
DEBUG - 2022-01-18 23:05:37 --> Total execution time: 0.0370
