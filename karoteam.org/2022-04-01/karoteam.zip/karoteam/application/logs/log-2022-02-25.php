<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-02-25 08:52:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-25 08:52:34 --> Config Class Initialized
INFO - 2022-02-25 08:52:34 --> Hooks Class Initialized
DEBUG - 2022-02-25 08:52:34 --> UTF-8 Support Enabled
INFO - 2022-02-25 08:52:34 --> Utf8 Class Initialized
INFO - 2022-02-25 08:52:34 --> URI Class Initialized
DEBUG - 2022-02-25 08:52:34 --> No URI present. Default controller set.
INFO - 2022-02-25 08:52:34 --> Router Class Initialized
INFO - 2022-02-25 08:52:34 --> Output Class Initialized
INFO - 2022-02-25 08:52:34 --> Security Class Initialized
DEBUG - 2022-02-25 08:52:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-25 08:52:34 --> Input Class Initialized
INFO - 2022-02-25 08:52:34 --> Language Class Initialized
INFO - 2022-02-25 08:52:34 --> Loader Class Initialized
INFO - 2022-02-25 08:52:34 --> Helper loaded: url_helper
INFO - 2022-02-25 08:52:34 --> Helper loaded: form_helper
INFO - 2022-02-25 08:52:34 --> Helper loaded: common_helper
INFO - 2022-02-25 08:52:34 --> Database Driver Class Initialized
DEBUG - 2022-02-25 08:52:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-25 08:52:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-25 08:52:34 --> Controller Class Initialized
INFO - 2022-02-25 08:52:34 --> Form Validation Class Initialized
DEBUG - 2022-02-25 08:52:34 --> Encrypt Class Initialized
DEBUG - 2022-02-25 08:52:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-25 08:52:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-25 08:52:34 --> Email Class Initialized
INFO - 2022-02-25 08:52:34 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-25 08:52:34 --> Calendar Class Initialized
INFO - 2022-02-25 08:52:34 --> Model "Login_model" initialized
INFO - 2022-02-25 08:52:34 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-25 08:52:34 --> Final output sent to browser
DEBUG - 2022-02-25 08:52:34 --> Total execution time: 0.0259
ERROR - 2022-02-25 11:06:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-25 11:06:25 --> Config Class Initialized
INFO - 2022-02-25 11:06:25 --> Hooks Class Initialized
DEBUG - 2022-02-25 11:06:25 --> UTF-8 Support Enabled
INFO - 2022-02-25 11:06:25 --> Utf8 Class Initialized
INFO - 2022-02-25 11:06:25 --> URI Class Initialized
DEBUG - 2022-02-25 11:06:25 --> No URI present. Default controller set.
INFO - 2022-02-25 11:06:25 --> Router Class Initialized
INFO - 2022-02-25 11:06:25 --> Output Class Initialized
INFO - 2022-02-25 11:06:25 --> Security Class Initialized
DEBUG - 2022-02-25 11:06:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-25 11:06:25 --> Input Class Initialized
INFO - 2022-02-25 11:06:25 --> Language Class Initialized
INFO - 2022-02-25 11:06:25 --> Loader Class Initialized
INFO - 2022-02-25 11:06:25 --> Helper loaded: url_helper
INFO - 2022-02-25 11:06:25 --> Helper loaded: form_helper
INFO - 2022-02-25 11:06:25 --> Helper loaded: common_helper
INFO - 2022-02-25 11:06:25 --> Database Driver Class Initialized
DEBUG - 2022-02-25 11:06:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-25 11:06:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-25 11:06:25 --> Controller Class Initialized
INFO - 2022-02-25 11:06:25 --> Form Validation Class Initialized
DEBUG - 2022-02-25 11:06:25 --> Encrypt Class Initialized
DEBUG - 2022-02-25 11:06:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-25 11:06:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-25 11:06:25 --> Email Class Initialized
INFO - 2022-02-25 11:06:25 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-25 11:06:25 --> Calendar Class Initialized
INFO - 2022-02-25 11:06:25 --> Model "Login_model" initialized
INFO - 2022-02-25 11:06:25 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-25 11:06:25 --> Final output sent to browser
DEBUG - 2022-02-25 11:06:25 --> Total execution time: 0.0268
ERROR - 2022-02-25 11:13:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-25 11:13:07 --> Config Class Initialized
INFO - 2022-02-25 11:13:07 --> Hooks Class Initialized
DEBUG - 2022-02-25 11:13:07 --> UTF-8 Support Enabled
INFO - 2022-02-25 11:13:07 --> Utf8 Class Initialized
INFO - 2022-02-25 11:13:07 --> URI Class Initialized
DEBUG - 2022-02-25 11:13:07 --> No URI present. Default controller set.
INFO - 2022-02-25 11:13:07 --> Router Class Initialized
INFO - 2022-02-25 11:13:07 --> Output Class Initialized
INFO - 2022-02-25 11:13:07 --> Security Class Initialized
DEBUG - 2022-02-25 11:13:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-25 11:13:07 --> Input Class Initialized
INFO - 2022-02-25 11:13:07 --> Language Class Initialized
INFO - 2022-02-25 11:13:07 --> Loader Class Initialized
INFO - 2022-02-25 11:13:07 --> Helper loaded: url_helper
INFO - 2022-02-25 11:13:07 --> Helper loaded: form_helper
INFO - 2022-02-25 11:13:07 --> Helper loaded: common_helper
INFO - 2022-02-25 11:13:07 --> Database Driver Class Initialized
DEBUG - 2022-02-25 11:13:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-25 11:13:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-25 11:13:07 --> Controller Class Initialized
INFO - 2022-02-25 11:13:07 --> Form Validation Class Initialized
DEBUG - 2022-02-25 11:13:07 --> Encrypt Class Initialized
DEBUG - 2022-02-25 11:13:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-25 11:13:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-25 11:13:07 --> Email Class Initialized
INFO - 2022-02-25 11:13:07 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-25 11:13:07 --> Calendar Class Initialized
INFO - 2022-02-25 11:13:07 --> Model "Login_model" initialized
INFO - 2022-02-25 11:13:07 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-25 11:13:07 --> Final output sent to browser
DEBUG - 2022-02-25 11:13:07 --> Total execution time: 0.0348
ERROR - 2022-02-25 14:22:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-25 14:22:44 --> Config Class Initialized
INFO - 2022-02-25 14:22:44 --> Hooks Class Initialized
DEBUG - 2022-02-25 14:22:44 --> UTF-8 Support Enabled
INFO - 2022-02-25 14:22:44 --> Utf8 Class Initialized
INFO - 2022-02-25 14:22:44 --> URI Class Initialized
DEBUG - 2022-02-25 14:22:44 --> No URI present. Default controller set.
INFO - 2022-02-25 14:22:44 --> Router Class Initialized
INFO - 2022-02-25 14:22:44 --> Output Class Initialized
INFO - 2022-02-25 14:22:44 --> Security Class Initialized
DEBUG - 2022-02-25 14:22:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-25 14:22:44 --> Input Class Initialized
INFO - 2022-02-25 14:22:44 --> Language Class Initialized
INFO - 2022-02-25 14:22:44 --> Loader Class Initialized
INFO - 2022-02-25 14:22:44 --> Helper loaded: url_helper
INFO - 2022-02-25 14:22:44 --> Helper loaded: form_helper
INFO - 2022-02-25 14:22:44 --> Helper loaded: common_helper
INFO - 2022-02-25 14:22:44 --> Database Driver Class Initialized
DEBUG - 2022-02-25 14:22:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-25 14:22:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-25 14:22:44 --> Controller Class Initialized
INFO - 2022-02-25 14:22:44 --> Form Validation Class Initialized
DEBUG - 2022-02-25 14:22:44 --> Encrypt Class Initialized
DEBUG - 2022-02-25 14:22:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-25 14:22:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-25 14:22:44 --> Email Class Initialized
INFO - 2022-02-25 14:22:44 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-25 14:22:44 --> Calendar Class Initialized
INFO - 2022-02-25 14:22:44 --> Model "Login_model" initialized
INFO - 2022-02-25 14:22:44 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-25 14:22:44 --> Final output sent to browser
DEBUG - 2022-02-25 14:22:44 --> Total execution time: 0.0274
ERROR - 2022-02-25 14:22:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-25 14:22:44 --> Config Class Initialized
INFO - 2022-02-25 14:22:44 --> Hooks Class Initialized
DEBUG - 2022-02-25 14:22:44 --> UTF-8 Support Enabled
INFO - 2022-02-25 14:22:44 --> Utf8 Class Initialized
INFO - 2022-02-25 14:22:44 --> URI Class Initialized
INFO - 2022-02-25 14:22:44 --> Router Class Initialized
INFO - 2022-02-25 14:22:44 --> Output Class Initialized
INFO - 2022-02-25 14:22:44 --> Security Class Initialized
DEBUG - 2022-02-25 14:22:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-25 14:22:44 --> Input Class Initialized
INFO - 2022-02-25 14:22:44 --> Language Class Initialized
ERROR - 2022-02-25 14:22:44 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2022-02-25 14:22:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-25 14:22:52 --> Config Class Initialized
INFO - 2022-02-25 14:22:52 --> Hooks Class Initialized
DEBUG - 2022-02-25 14:22:52 --> UTF-8 Support Enabled
INFO - 2022-02-25 14:22:52 --> Utf8 Class Initialized
INFO - 2022-02-25 14:22:52 --> URI Class Initialized
INFO - 2022-02-25 14:22:52 --> Router Class Initialized
INFO - 2022-02-25 14:22:52 --> Output Class Initialized
INFO - 2022-02-25 14:22:52 --> Security Class Initialized
DEBUG - 2022-02-25 14:22:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-25 14:22:52 --> Input Class Initialized
INFO - 2022-02-25 14:22:52 --> Language Class Initialized
INFO - 2022-02-25 14:22:52 --> Loader Class Initialized
INFO - 2022-02-25 14:22:52 --> Helper loaded: url_helper
INFO - 2022-02-25 14:22:52 --> Helper loaded: form_helper
INFO - 2022-02-25 14:22:52 --> Helper loaded: common_helper
INFO - 2022-02-25 14:22:52 --> Database Driver Class Initialized
DEBUG - 2022-02-25 14:22:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-25 14:22:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-25 14:22:52 --> Controller Class Initialized
INFO - 2022-02-25 14:22:52 --> Form Validation Class Initialized
DEBUG - 2022-02-25 14:22:52 --> Encrypt Class Initialized
DEBUG - 2022-02-25 14:22:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-25 14:22:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-25 14:22:52 --> Email Class Initialized
INFO - 2022-02-25 14:22:52 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-25 14:22:52 --> Calendar Class Initialized
INFO - 2022-02-25 14:22:52 --> Model "Login_model" initialized
INFO - 2022-02-25 14:22:52 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-25 14:22:52 --> Final output sent to browser
DEBUG - 2022-02-25 14:22:52 --> Total execution time: 0.0231
ERROR - 2022-02-25 14:22:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-25 14:22:53 --> Config Class Initialized
INFO - 2022-02-25 14:22:53 --> Hooks Class Initialized
DEBUG - 2022-02-25 14:22:53 --> UTF-8 Support Enabled
INFO - 2022-02-25 14:22:53 --> Utf8 Class Initialized
INFO - 2022-02-25 14:22:53 --> URI Class Initialized
DEBUG - 2022-02-25 14:22:53 --> No URI present. Default controller set.
INFO - 2022-02-25 14:22:53 --> Router Class Initialized
INFO - 2022-02-25 14:22:53 --> Output Class Initialized
INFO - 2022-02-25 14:22:53 --> Security Class Initialized
DEBUG - 2022-02-25 14:22:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-25 14:22:53 --> Input Class Initialized
INFO - 2022-02-25 14:22:53 --> Language Class Initialized
INFO - 2022-02-25 14:22:53 --> Loader Class Initialized
INFO - 2022-02-25 14:22:53 --> Helper loaded: url_helper
INFO - 2022-02-25 14:22:53 --> Helper loaded: form_helper
INFO - 2022-02-25 14:22:53 --> Helper loaded: common_helper
INFO - 2022-02-25 14:22:53 --> Database Driver Class Initialized
DEBUG - 2022-02-25 14:22:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-25 14:22:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-25 14:22:53 --> Controller Class Initialized
INFO - 2022-02-25 14:22:53 --> Form Validation Class Initialized
DEBUG - 2022-02-25 14:22:53 --> Encrypt Class Initialized
DEBUG - 2022-02-25 14:22:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-25 14:22:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-25 14:22:53 --> Email Class Initialized
INFO - 2022-02-25 14:22:53 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-25 14:22:53 --> Calendar Class Initialized
INFO - 2022-02-25 14:22:53 --> Model "Login_model" initialized
INFO - 2022-02-25 14:22:53 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-25 14:22:53 --> Final output sent to browser
DEBUG - 2022-02-25 14:22:53 --> Total execution time: 0.0248
ERROR - 2022-02-25 14:22:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-25 14:22:53 --> Config Class Initialized
INFO - 2022-02-25 14:22:53 --> Hooks Class Initialized
DEBUG - 2022-02-25 14:22:53 --> UTF-8 Support Enabled
INFO - 2022-02-25 14:22:53 --> Utf8 Class Initialized
INFO - 2022-02-25 14:22:53 --> URI Class Initialized
INFO - 2022-02-25 14:22:53 --> Router Class Initialized
INFO - 2022-02-25 14:22:53 --> Output Class Initialized
INFO - 2022-02-25 14:22:53 --> Security Class Initialized
DEBUG - 2022-02-25 14:22:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-25 14:22:53 --> Input Class Initialized
INFO - 2022-02-25 14:22:53 --> Language Class Initialized
INFO - 2022-02-25 14:22:53 --> Loader Class Initialized
INFO - 2022-02-25 14:22:53 --> Helper loaded: url_helper
INFO - 2022-02-25 14:22:53 --> Helper loaded: form_helper
INFO - 2022-02-25 14:22:53 --> Helper loaded: common_helper
INFO - 2022-02-25 14:22:53 --> Database Driver Class Initialized
DEBUG - 2022-02-25 14:22:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-25 14:22:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-25 14:22:53 --> Controller Class Initialized
INFO - 2022-02-25 14:22:53 --> Form Validation Class Initialized
DEBUG - 2022-02-25 14:22:53 --> Encrypt Class Initialized
DEBUG - 2022-02-25 14:22:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-25 14:22:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-25 14:22:53 --> Email Class Initialized
INFO - 2022-02-25 14:22:53 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-25 14:22:53 --> Calendar Class Initialized
INFO - 2022-02-25 14:22:53 --> Model "Login_model" initialized
ERROR - 2022-02-25 14:22:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-25 14:22:54 --> Config Class Initialized
INFO - 2022-02-25 14:22:54 --> Hooks Class Initialized
DEBUG - 2022-02-25 14:22:54 --> UTF-8 Support Enabled
INFO - 2022-02-25 14:22:54 --> Utf8 Class Initialized
INFO - 2022-02-25 14:22:54 --> URI Class Initialized
INFO - 2022-02-25 14:22:54 --> Router Class Initialized
INFO - 2022-02-25 14:22:54 --> Output Class Initialized
INFO - 2022-02-25 14:22:54 --> Security Class Initialized
DEBUG - 2022-02-25 14:22:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-25 14:22:54 --> Input Class Initialized
INFO - 2022-02-25 14:22:54 --> Language Class Initialized
INFO - 2022-02-25 14:22:54 --> Loader Class Initialized
INFO - 2022-02-25 14:22:54 --> Helper loaded: url_helper
INFO - 2022-02-25 14:22:54 --> Helper loaded: form_helper
INFO - 2022-02-25 14:22:54 --> Helper loaded: common_helper
INFO - 2022-02-25 14:22:54 --> Database Driver Class Initialized
DEBUG - 2022-02-25 14:22:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-25 14:22:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-25 14:22:54 --> Controller Class Initialized
INFO - 2022-02-25 14:22:54 --> Form Validation Class Initialized
DEBUG - 2022-02-25 14:22:54 --> Encrypt Class Initialized
DEBUG - 2022-02-25 14:22:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-25 14:22:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-25 14:22:54 --> Email Class Initialized
INFO - 2022-02-25 14:22:54 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-25 14:22:54 --> Calendar Class Initialized
INFO - 2022-02-25 14:22:54 --> Model "Login_model" initialized
ERROR - 2022-02-25 15:31:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-25 15:31:17 --> Config Class Initialized
INFO - 2022-02-25 15:31:17 --> Hooks Class Initialized
DEBUG - 2022-02-25 15:31:17 --> UTF-8 Support Enabled
INFO - 2022-02-25 15:31:17 --> Utf8 Class Initialized
INFO - 2022-02-25 15:31:17 --> URI Class Initialized
DEBUG - 2022-02-25 15:31:17 --> No URI present. Default controller set.
INFO - 2022-02-25 15:31:17 --> Router Class Initialized
INFO - 2022-02-25 15:31:17 --> Output Class Initialized
INFO - 2022-02-25 15:31:17 --> Security Class Initialized
DEBUG - 2022-02-25 15:31:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-25 15:31:17 --> Input Class Initialized
INFO - 2022-02-25 15:31:17 --> Language Class Initialized
INFO - 2022-02-25 15:31:17 --> Loader Class Initialized
INFO - 2022-02-25 15:31:17 --> Helper loaded: url_helper
INFO - 2022-02-25 15:31:17 --> Helper loaded: form_helper
INFO - 2022-02-25 15:31:17 --> Helper loaded: common_helper
INFO - 2022-02-25 15:31:17 --> Database Driver Class Initialized
DEBUG - 2022-02-25 15:31:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-25 15:31:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-25 15:31:17 --> Controller Class Initialized
INFO - 2022-02-25 15:31:17 --> Form Validation Class Initialized
DEBUG - 2022-02-25 15:31:17 --> Encrypt Class Initialized
DEBUG - 2022-02-25 15:31:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-25 15:31:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-25 15:31:17 --> Email Class Initialized
INFO - 2022-02-25 15:31:17 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-25 15:31:17 --> Calendar Class Initialized
INFO - 2022-02-25 15:31:17 --> Model "Login_model" initialized
INFO - 2022-02-25 15:31:17 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-25 15:31:17 --> Final output sent to browser
DEBUG - 2022-02-25 15:31:17 --> Total execution time: 0.0340
ERROR - 2022-02-25 15:37:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-25 15:37:07 --> Config Class Initialized
INFO - 2022-02-25 15:37:07 --> Hooks Class Initialized
DEBUG - 2022-02-25 15:37:07 --> UTF-8 Support Enabled
INFO - 2022-02-25 15:37:07 --> Utf8 Class Initialized
INFO - 2022-02-25 15:37:07 --> URI Class Initialized
DEBUG - 2022-02-25 15:37:07 --> No URI present. Default controller set.
INFO - 2022-02-25 15:37:07 --> Router Class Initialized
INFO - 2022-02-25 15:37:07 --> Output Class Initialized
INFO - 2022-02-25 15:37:07 --> Security Class Initialized
DEBUG - 2022-02-25 15:37:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-25 15:37:07 --> Input Class Initialized
INFO - 2022-02-25 15:37:07 --> Language Class Initialized
INFO - 2022-02-25 15:37:07 --> Loader Class Initialized
INFO - 2022-02-25 15:37:07 --> Helper loaded: url_helper
INFO - 2022-02-25 15:37:07 --> Helper loaded: form_helper
INFO - 2022-02-25 15:37:07 --> Helper loaded: common_helper
INFO - 2022-02-25 15:37:07 --> Database Driver Class Initialized
DEBUG - 2022-02-25 15:37:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-25 15:37:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-25 15:37:07 --> Controller Class Initialized
INFO - 2022-02-25 15:37:07 --> Form Validation Class Initialized
DEBUG - 2022-02-25 15:37:07 --> Encrypt Class Initialized
DEBUG - 2022-02-25 15:37:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-25 15:37:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-25 15:37:07 --> Email Class Initialized
INFO - 2022-02-25 15:37:07 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-25 15:37:07 --> Calendar Class Initialized
INFO - 2022-02-25 15:37:07 --> Model "Login_model" initialized
INFO - 2022-02-25 15:37:07 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-25 15:37:07 --> Final output sent to browser
DEBUG - 2022-02-25 15:37:07 --> Total execution time: 0.0351
ERROR - 2022-02-25 16:52:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-25 16:52:16 --> Config Class Initialized
INFO - 2022-02-25 16:52:16 --> Hooks Class Initialized
DEBUG - 2022-02-25 16:52:16 --> UTF-8 Support Enabled
INFO - 2022-02-25 16:52:16 --> Utf8 Class Initialized
INFO - 2022-02-25 16:52:16 --> URI Class Initialized
DEBUG - 2022-02-25 16:52:16 --> No URI present. Default controller set.
INFO - 2022-02-25 16:52:16 --> Router Class Initialized
INFO - 2022-02-25 16:52:16 --> Output Class Initialized
INFO - 2022-02-25 16:52:16 --> Security Class Initialized
DEBUG - 2022-02-25 16:52:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-25 16:52:16 --> Input Class Initialized
INFO - 2022-02-25 16:52:16 --> Language Class Initialized
INFO - 2022-02-25 16:52:16 --> Loader Class Initialized
INFO - 2022-02-25 16:52:16 --> Helper loaded: url_helper
INFO - 2022-02-25 16:52:16 --> Helper loaded: form_helper
INFO - 2022-02-25 16:52:16 --> Helper loaded: common_helper
INFO - 2022-02-25 16:52:16 --> Database Driver Class Initialized
DEBUG - 2022-02-25 16:52:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-25 16:52:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-25 16:52:16 --> Controller Class Initialized
INFO - 2022-02-25 16:52:16 --> Form Validation Class Initialized
DEBUG - 2022-02-25 16:52:16 --> Encrypt Class Initialized
DEBUG - 2022-02-25 16:52:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-25 16:52:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-25 16:52:16 --> Email Class Initialized
INFO - 2022-02-25 16:52:16 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-25 16:52:16 --> Calendar Class Initialized
INFO - 2022-02-25 16:52:16 --> Model "Login_model" initialized
INFO - 2022-02-25 16:52:16 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-25 16:52:16 --> Final output sent to browser
DEBUG - 2022-02-25 16:52:16 --> Total execution time: 0.0230
ERROR - 2022-02-25 18:30:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-25 18:30:03 --> Config Class Initialized
INFO - 2022-02-25 18:30:03 --> Hooks Class Initialized
DEBUG - 2022-02-25 18:30:03 --> UTF-8 Support Enabled
INFO - 2022-02-25 18:30:03 --> Utf8 Class Initialized
INFO - 2022-02-25 18:30:03 --> URI Class Initialized
DEBUG - 2022-02-25 18:30:03 --> No URI present. Default controller set.
INFO - 2022-02-25 18:30:03 --> Router Class Initialized
INFO - 2022-02-25 18:30:03 --> Output Class Initialized
INFO - 2022-02-25 18:30:03 --> Security Class Initialized
DEBUG - 2022-02-25 18:30:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-25 18:30:03 --> Input Class Initialized
INFO - 2022-02-25 18:30:03 --> Language Class Initialized
INFO - 2022-02-25 18:30:03 --> Loader Class Initialized
INFO - 2022-02-25 18:30:03 --> Helper loaded: url_helper
INFO - 2022-02-25 18:30:03 --> Helper loaded: form_helper
INFO - 2022-02-25 18:30:03 --> Helper loaded: common_helper
INFO - 2022-02-25 18:30:03 --> Database Driver Class Initialized
DEBUG - 2022-02-25 18:30:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-25 18:30:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-25 18:30:03 --> Controller Class Initialized
INFO - 2022-02-25 18:30:03 --> Form Validation Class Initialized
DEBUG - 2022-02-25 18:30:03 --> Encrypt Class Initialized
DEBUG - 2022-02-25 18:30:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-25 18:30:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-25 18:30:03 --> Email Class Initialized
INFO - 2022-02-25 18:30:03 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-25 18:30:03 --> Calendar Class Initialized
INFO - 2022-02-25 18:30:03 --> Model "Login_model" initialized
INFO - 2022-02-25 18:30:03 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-25 18:30:03 --> Final output sent to browser
DEBUG - 2022-02-25 18:30:03 --> Total execution time: 0.0477
ERROR - 2022-02-25 19:48:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-25 19:48:21 --> Config Class Initialized
INFO - 2022-02-25 19:48:21 --> Hooks Class Initialized
DEBUG - 2022-02-25 19:48:21 --> UTF-8 Support Enabled
INFO - 2022-02-25 19:48:21 --> Utf8 Class Initialized
INFO - 2022-02-25 19:48:21 --> URI Class Initialized
DEBUG - 2022-02-25 19:48:21 --> No URI present. Default controller set.
INFO - 2022-02-25 19:48:21 --> Router Class Initialized
INFO - 2022-02-25 19:48:21 --> Output Class Initialized
INFO - 2022-02-25 19:48:21 --> Security Class Initialized
DEBUG - 2022-02-25 19:48:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-25 19:48:21 --> Input Class Initialized
INFO - 2022-02-25 19:48:21 --> Language Class Initialized
INFO - 2022-02-25 19:48:21 --> Loader Class Initialized
INFO - 2022-02-25 19:48:21 --> Helper loaded: url_helper
INFO - 2022-02-25 19:48:21 --> Helper loaded: form_helper
INFO - 2022-02-25 19:48:21 --> Helper loaded: common_helper
INFO - 2022-02-25 19:48:21 --> Database Driver Class Initialized
DEBUG - 2022-02-25 19:48:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-25 19:48:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-25 19:48:21 --> Controller Class Initialized
INFO - 2022-02-25 19:48:21 --> Form Validation Class Initialized
DEBUG - 2022-02-25 19:48:21 --> Encrypt Class Initialized
DEBUG - 2022-02-25 19:48:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-25 19:48:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-25 19:48:21 --> Email Class Initialized
INFO - 2022-02-25 19:48:21 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-25 19:48:21 --> Calendar Class Initialized
INFO - 2022-02-25 19:48:21 --> Model "Login_model" initialized
INFO - 2022-02-25 19:48:21 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-25 19:48:21 --> Final output sent to browser
DEBUG - 2022-02-25 19:48:21 --> Total execution time: 0.0367
