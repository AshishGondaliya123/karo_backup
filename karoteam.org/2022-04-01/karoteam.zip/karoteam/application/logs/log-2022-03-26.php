<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-03-26 00:27:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-26 00:27:35 --> Config Class Initialized
INFO - 2022-03-26 00:27:35 --> Hooks Class Initialized
DEBUG - 2022-03-26 00:27:35 --> UTF-8 Support Enabled
INFO - 2022-03-26 00:27:35 --> Utf8 Class Initialized
INFO - 2022-03-26 00:27:35 --> URI Class Initialized
INFO - 2022-03-26 00:27:35 --> Router Class Initialized
INFO - 2022-03-26 00:27:35 --> Output Class Initialized
INFO - 2022-03-26 00:27:35 --> Security Class Initialized
DEBUG - 2022-03-26 00:27:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-26 00:27:35 --> Input Class Initialized
INFO - 2022-03-26 00:27:35 --> Language Class Initialized
INFO - 2022-03-26 00:27:35 --> Loader Class Initialized
INFO - 2022-03-26 00:27:35 --> Helper loaded: url_helper
INFO - 2022-03-26 00:27:35 --> Helper loaded: form_helper
INFO - 2022-03-26 00:27:35 --> Helper loaded: common_helper
INFO - 2022-03-26 00:27:35 --> Database Driver Class Initialized
DEBUG - 2022-03-26 00:27:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-26 00:27:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-26 00:27:35 --> Controller Class Initialized
INFO - 2022-03-26 00:27:35 --> Form Validation Class Initialized
DEBUG - 2022-03-26 00:27:35 --> Encrypt Class Initialized
INFO - 2022-03-26 00:27:35 --> Model "Patient_model" initialized
INFO - 2022-03-26 00:27:35 --> Model "Patientcase_model" initialized
INFO - 2022-03-26 00:27:35 --> Model "Prefix_master" initialized
INFO - 2022-03-26 00:27:35 --> Model "Users_model" initialized
INFO - 2022-03-26 00:27:35 --> Model "Hospital_model" initialized
INFO - 2022-03-26 00:27:36 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-26 00:27:36 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-26 00:27:36 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-26 00:27:36 --> Final output sent to browser
DEBUG - 2022-03-26 00:27:36 --> Total execution time: 0.4352
ERROR - 2022-03-26 01:27:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-26 01:27:14 --> Config Class Initialized
INFO - 2022-03-26 01:27:14 --> Hooks Class Initialized
DEBUG - 2022-03-26 01:27:14 --> UTF-8 Support Enabled
INFO - 2022-03-26 01:27:14 --> Utf8 Class Initialized
INFO - 2022-03-26 01:27:14 --> URI Class Initialized
DEBUG - 2022-03-26 01:27:14 --> No URI present. Default controller set.
INFO - 2022-03-26 01:27:14 --> Router Class Initialized
INFO - 2022-03-26 01:27:14 --> Output Class Initialized
INFO - 2022-03-26 01:27:14 --> Security Class Initialized
DEBUG - 2022-03-26 01:27:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-26 01:27:14 --> Input Class Initialized
INFO - 2022-03-26 01:27:14 --> Language Class Initialized
INFO - 2022-03-26 01:27:14 --> Loader Class Initialized
INFO - 2022-03-26 01:27:14 --> Helper loaded: url_helper
INFO - 2022-03-26 01:27:14 --> Helper loaded: form_helper
INFO - 2022-03-26 01:27:14 --> Helper loaded: common_helper
INFO - 2022-03-26 01:27:14 --> Database Driver Class Initialized
DEBUG - 2022-03-26 01:27:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-26 01:27:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-26 01:27:15 --> Controller Class Initialized
INFO - 2022-03-26 01:27:15 --> Form Validation Class Initialized
DEBUG - 2022-03-26 01:27:15 --> Encrypt Class Initialized
DEBUG - 2022-03-26 01:27:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-26 01:27:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-26 01:27:15 --> Email Class Initialized
INFO - 2022-03-26 01:27:15 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-26 01:27:15 --> Calendar Class Initialized
INFO - 2022-03-26 01:27:15 --> Model "Login_model" initialized
INFO - 2022-03-26 01:27:15 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-26 01:27:15 --> Final output sent to browser
DEBUG - 2022-03-26 01:27:15 --> Total execution time: 0.0576
ERROR - 2022-03-26 01:27:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-26 01:27:18 --> Config Class Initialized
INFO - 2022-03-26 01:27:18 --> Hooks Class Initialized
DEBUG - 2022-03-26 01:27:18 --> UTF-8 Support Enabled
INFO - 2022-03-26 01:27:18 --> Utf8 Class Initialized
INFO - 2022-03-26 01:27:18 --> URI Class Initialized
INFO - 2022-03-26 01:27:18 --> Router Class Initialized
INFO - 2022-03-26 01:27:18 --> Output Class Initialized
INFO - 2022-03-26 01:27:18 --> Security Class Initialized
DEBUG - 2022-03-26 01:27:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-26 01:27:18 --> Input Class Initialized
INFO - 2022-03-26 01:27:18 --> Language Class Initialized
INFO - 2022-03-26 01:27:18 --> Loader Class Initialized
INFO - 2022-03-26 01:27:18 --> Helper loaded: url_helper
INFO - 2022-03-26 01:27:18 --> Helper loaded: form_helper
INFO - 2022-03-26 01:27:18 --> Helper loaded: common_helper
INFO - 2022-03-26 01:27:18 --> Database Driver Class Initialized
DEBUG - 2022-03-26 01:27:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-26 01:27:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-26 01:27:18 --> Controller Class Initialized
INFO - 2022-03-26 01:27:18 --> Form Validation Class Initialized
DEBUG - 2022-03-26 01:27:18 --> Encrypt Class Initialized
DEBUG - 2022-03-26 01:27:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-26 01:27:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-26 01:27:18 --> Email Class Initialized
INFO - 2022-03-26 01:27:18 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-26 01:27:18 --> Calendar Class Initialized
INFO - 2022-03-26 01:27:18 --> Model "Login_model" initialized
INFO - 2022-03-26 01:27:18 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-03-26 01:27:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-26 01:27:18 --> Config Class Initialized
INFO - 2022-03-26 01:27:18 --> Hooks Class Initialized
DEBUG - 2022-03-26 01:27:18 --> UTF-8 Support Enabled
INFO - 2022-03-26 01:27:18 --> Utf8 Class Initialized
INFO - 2022-03-26 01:27:18 --> URI Class Initialized
INFO - 2022-03-26 01:27:18 --> Router Class Initialized
INFO - 2022-03-26 01:27:18 --> Output Class Initialized
INFO - 2022-03-26 01:27:18 --> Security Class Initialized
DEBUG - 2022-03-26 01:27:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-26 01:27:18 --> Input Class Initialized
INFO - 2022-03-26 01:27:18 --> Language Class Initialized
INFO - 2022-03-26 01:27:18 --> Loader Class Initialized
INFO - 2022-03-26 01:27:18 --> Helper loaded: url_helper
INFO - 2022-03-26 01:27:18 --> Helper loaded: form_helper
INFO - 2022-03-26 01:27:18 --> Helper loaded: common_helper
INFO - 2022-03-26 01:27:18 --> Database Driver Class Initialized
DEBUG - 2022-03-26 01:27:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-26 01:27:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-26 01:27:18 --> Controller Class Initialized
INFO - 2022-03-26 01:27:18 --> Form Validation Class Initialized
DEBUG - 2022-03-26 01:27:18 --> Encrypt Class Initialized
DEBUG - 2022-03-26 01:27:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-26 01:27:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-26 01:27:18 --> Email Class Initialized
INFO - 2022-03-26 01:27:18 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-26 01:27:18 --> Calendar Class Initialized
INFO - 2022-03-26 01:27:18 --> Model "Login_model" initialized
INFO - 2022-03-26 01:27:18 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-03-26 01:27:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-26 01:27:18 --> Config Class Initialized
INFO - 2022-03-26 01:27:18 --> Hooks Class Initialized
DEBUG - 2022-03-26 01:27:18 --> UTF-8 Support Enabled
INFO - 2022-03-26 01:27:18 --> Utf8 Class Initialized
INFO - 2022-03-26 01:27:18 --> URI Class Initialized
INFO - 2022-03-26 01:27:18 --> Router Class Initialized
INFO - 2022-03-26 01:27:18 --> Output Class Initialized
INFO - 2022-03-26 01:27:18 --> Security Class Initialized
DEBUG - 2022-03-26 01:27:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-26 01:27:18 --> Input Class Initialized
INFO - 2022-03-26 01:27:18 --> Language Class Initialized
INFO - 2022-03-26 01:27:18 --> Loader Class Initialized
INFO - 2022-03-26 01:27:18 --> Helper loaded: url_helper
INFO - 2022-03-26 01:27:18 --> Helper loaded: form_helper
INFO - 2022-03-26 01:27:18 --> Helper loaded: common_helper
INFO - 2022-03-26 01:27:18 --> Database Driver Class Initialized
DEBUG - 2022-03-26 01:27:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-26 01:27:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-26 01:27:18 --> Controller Class Initialized
INFO - 2022-03-26 01:27:18 --> Form Validation Class Initialized
DEBUG - 2022-03-26 01:27:18 --> Encrypt Class Initialized
INFO - 2022-03-26 01:27:18 --> Model "Login_model" initialized
INFO - 2022-03-26 01:27:18 --> Model "Dashboard_model" initialized
INFO - 2022-03-26 01:27:18 --> Model "Case_model" initialized
INFO - 2022-03-26 01:27:27 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-26 01:27:37 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2022-03-26 01:27:37 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-26 01:27:37 --> Final output sent to browser
DEBUG - 2022-03-26 01:27:37 --> Total execution time: 18.7477
ERROR - 2022-03-26 01:28:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-26 01:28:45 --> Config Class Initialized
INFO - 2022-03-26 01:28:45 --> Hooks Class Initialized
DEBUG - 2022-03-26 01:28:45 --> UTF-8 Support Enabled
INFO - 2022-03-26 01:28:45 --> Utf8 Class Initialized
INFO - 2022-03-26 01:28:45 --> URI Class Initialized
INFO - 2022-03-26 01:28:45 --> Router Class Initialized
INFO - 2022-03-26 01:28:45 --> Output Class Initialized
INFO - 2022-03-26 01:28:45 --> Security Class Initialized
DEBUG - 2022-03-26 01:28:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-26 01:28:45 --> Input Class Initialized
INFO - 2022-03-26 01:28:45 --> Language Class Initialized
INFO - 2022-03-26 01:28:45 --> Loader Class Initialized
INFO - 2022-03-26 01:28:45 --> Helper loaded: url_helper
INFO - 2022-03-26 01:28:45 --> Helper loaded: form_helper
INFO - 2022-03-26 01:28:45 --> Helper loaded: common_helper
INFO - 2022-03-26 01:28:45 --> Database Driver Class Initialized
DEBUG - 2022-03-26 01:28:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-26 01:28:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-26 01:28:45 --> Controller Class Initialized
INFO - 2022-03-26 01:28:45 --> Form Validation Class Initialized
DEBUG - 2022-03-26 01:28:45 --> Encrypt Class Initialized
INFO - 2022-03-26 01:28:45 --> Model "Patient_model" initialized
INFO - 2022-03-26 01:28:45 --> Model "Patientcase_model" initialized
INFO - 2022-03-26 01:28:45 --> Model "Referredby_model" initialized
INFO - 2022-03-26 01:28:45 --> Model "Prefix_master" initialized
INFO - 2022-03-26 01:28:45 --> Model "Hospital_model" initialized
INFO - 2022-03-26 01:28:45 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-26 01:28:52 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-26 01:28:52 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-26 01:28:53 --> Final output sent to browser
DEBUG - 2022-03-26 01:28:53 --> Total execution time: 7.0266
ERROR - 2022-03-26 01:30:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-26 01:30:09 --> Config Class Initialized
INFO - 2022-03-26 01:30:09 --> Hooks Class Initialized
DEBUG - 2022-03-26 01:30:09 --> UTF-8 Support Enabled
INFO - 2022-03-26 01:30:09 --> Utf8 Class Initialized
INFO - 2022-03-26 01:30:09 --> URI Class Initialized
INFO - 2022-03-26 01:30:09 --> Router Class Initialized
INFO - 2022-03-26 01:30:09 --> Output Class Initialized
INFO - 2022-03-26 01:30:09 --> Security Class Initialized
DEBUG - 2022-03-26 01:30:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-26 01:30:09 --> Input Class Initialized
INFO - 2022-03-26 01:30:09 --> Language Class Initialized
INFO - 2022-03-26 01:30:09 --> Loader Class Initialized
INFO - 2022-03-26 01:30:09 --> Helper loaded: url_helper
INFO - 2022-03-26 01:30:09 --> Helper loaded: form_helper
INFO - 2022-03-26 01:30:09 --> Helper loaded: common_helper
INFO - 2022-03-26 01:30:09 --> Database Driver Class Initialized
DEBUG - 2022-03-26 01:30:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-26 01:30:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-26 01:30:09 --> Controller Class Initialized
INFO - 2022-03-26 01:30:09 --> Form Validation Class Initialized
DEBUG - 2022-03-26 01:30:09 --> Encrypt Class Initialized
INFO - 2022-03-26 01:30:09 --> Model "Patient_model" initialized
INFO - 2022-03-26 01:30:09 --> Model "Patientcase_model" initialized
INFO - 2022-03-26 01:30:09 --> Model "Referredby_model" initialized
INFO - 2022-03-26 01:30:09 --> Model "Prefix_master" initialized
INFO - 2022-03-26 01:30:09 --> Model "Hospital_model" initialized
INFO - 2022-03-26 01:30:09 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-26 01:30:09 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-26 01:30:09 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-26 01:30:09 --> Final output sent to browser
DEBUG - 2022-03-26 01:30:09 --> Total execution time: 0.1166
ERROR - 2022-03-26 01:30:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-26 01:30:09 --> Config Class Initialized
INFO - 2022-03-26 01:30:09 --> Hooks Class Initialized
DEBUG - 2022-03-26 01:30:09 --> UTF-8 Support Enabled
INFO - 2022-03-26 01:30:09 --> Utf8 Class Initialized
INFO - 2022-03-26 01:30:09 --> URI Class Initialized
INFO - 2022-03-26 01:30:09 --> Router Class Initialized
INFO - 2022-03-26 01:30:09 --> Output Class Initialized
INFO - 2022-03-26 01:30:09 --> Security Class Initialized
DEBUG - 2022-03-26 01:30:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-26 01:30:09 --> Input Class Initialized
INFO - 2022-03-26 01:30:09 --> Language Class Initialized
ERROR - 2022-03-26 01:30:09 --> 404 Page Not Found: Karoclient/images
ERROR - 2022-03-26 03:04:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-26 03:04:41 --> Config Class Initialized
INFO - 2022-03-26 03:04:41 --> Hooks Class Initialized
DEBUG - 2022-03-26 03:04:41 --> UTF-8 Support Enabled
INFO - 2022-03-26 03:04:41 --> Utf8 Class Initialized
INFO - 2022-03-26 03:04:41 --> URI Class Initialized
INFO - 2022-03-26 03:04:41 --> Router Class Initialized
INFO - 2022-03-26 03:04:41 --> Output Class Initialized
INFO - 2022-03-26 03:04:41 --> Security Class Initialized
DEBUG - 2022-03-26 03:04:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-26 03:04:41 --> Input Class Initialized
INFO - 2022-03-26 03:04:41 --> Language Class Initialized
INFO - 2022-03-26 03:04:41 --> Loader Class Initialized
INFO - 2022-03-26 03:04:41 --> Helper loaded: url_helper
INFO - 2022-03-26 03:04:41 --> Helper loaded: form_helper
INFO - 2022-03-26 03:04:41 --> Helper loaded: common_helper
INFO - 2022-03-26 03:04:41 --> Database Driver Class Initialized
DEBUG - 2022-03-26 03:04:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-26 03:04:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-26 03:04:41 --> Controller Class Initialized
ERROR - 2022-03-26 03:04:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-26 03:04:42 --> Config Class Initialized
INFO - 2022-03-26 03:04:42 --> Hooks Class Initialized
DEBUG - 2022-03-26 03:04:42 --> UTF-8 Support Enabled
INFO - 2022-03-26 03:04:42 --> Utf8 Class Initialized
INFO - 2022-03-26 03:04:42 --> URI Class Initialized
INFO - 2022-03-26 03:04:42 --> Router Class Initialized
INFO - 2022-03-26 03:04:42 --> Output Class Initialized
INFO - 2022-03-26 03:04:42 --> Security Class Initialized
DEBUG - 2022-03-26 03:04:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-26 03:04:42 --> Input Class Initialized
INFO - 2022-03-26 03:04:42 --> Language Class Initialized
INFO - 2022-03-26 03:04:42 --> Loader Class Initialized
INFO - 2022-03-26 03:04:42 --> Helper loaded: url_helper
INFO - 2022-03-26 03:04:42 --> Helper loaded: form_helper
INFO - 2022-03-26 03:04:42 --> Helper loaded: common_helper
INFO - 2022-03-26 03:04:42 --> Database Driver Class Initialized
DEBUG - 2022-03-26 03:04:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-26 03:04:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-26 03:04:42 --> Controller Class Initialized
INFO - 2022-03-26 03:04:42 --> Form Validation Class Initialized
DEBUG - 2022-03-26 03:04:42 --> Encrypt Class Initialized
DEBUG - 2022-03-26 03:04:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-26 03:04:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-26 03:04:42 --> Email Class Initialized
INFO - 2022-03-26 03:04:42 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-26 03:04:42 --> Calendar Class Initialized
INFO - 2022-03-26 03:04:42 --> Model "Login_model" initialized
INFO - 2022-03-26 03:04:42 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-26 03:04:42 --> Final output sent to browser
DEBUG - 2022-03-26 03:04:42 --> Total execution time: 0.0202
ERROR - 2022-03-26 03:05:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-26 03:05:02 --> Config Class Initialized
INFO - 2022-03-26 03:05:02 --> Hooks Class Initialized
DEBUG - 2022-03-26 03:05:02 --> UTF-8 Support Enabled
INFO - 2022-03-26 03:05:02 --> Utf8 Class Initialized
INFO - 2022-03-26 03:05:02 --> URI Class Initialized
INFO - 2022-03-26 03:05:02 --> Router Class Initialized
INFO - 2022-03-26 03:05:02 --> Output Class Initialized
INFO - 2022-03-26 03:05:02 --> Security Class Initialized
DEBUG - 2022-03-26 03:05:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-26 03:05:02 --> Input Class Initialized
INFO - 2022-03-26 03:05:02 --> Language Class Initialized
INFO - 2022-03-26 03:05:02 --> Loader Class Initialized
INFO - 2022-03-26 03:05:02 --> Helper loaded: url_helper
INFO - 2022-03-26 03:05:02 --> Helper loaded: form_helper
INFO - 2022-03-26 03:05:02 --> Helper loaded: common_helper
INFO - 2022-03-26 03:05:02 --> Database Driver Class Initialized
DEBUG - 2022-03-26 03:05:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-26 03:05:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-26 03:05:02 --> Controller Class Initialized
INFO - 2022-03-26 03:05:02 --> Form Validation Class Initialized
DEBUG - 2022-03-26 03:05:02 --> Encrypt Class Initialized
DEBUG - 2022-03-26 03:05:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-26 03:05:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-26 03:05:02 --> Email Class Initialized
INFO - 2022-03-26 03:05:02 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-26 03:05:02 --> Calendar Class Initialized
INFO - 2022-03-26 03:05:02 --> Model "Login_model" initialized
INFO - 2022-03-26 03:05:02 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-03-26 03:05:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-26 03:05:02 --> Config Class Initialized
INFO - 2022-03-26 03:05:02 --> Hooks Class Initialized
DEBUG - 2022-03-26 03:05:02 --> UTF-8 Support Enabled
INFO - 2022-03-26 03:05:02 --> Utf8 Class Initialized
INFO - 2022-03-26 03:05:02 --> URI Class Initialized
INFO - 2022-03-26 03:05:02 --> Router Class Initialized
INFO - 2022-03-26 03:05:02 --> Output Class Initialized
INFO - 2022-03-26 03:05:02 --> Security Class Initialized
DEBUG - 2022-03-26 03:05:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-26 03:05:02 --> Input Class Initialized
INFO - 2022-03-26 03:05:02 --> Language Class Initialized
INFO - 2022-03-26 03:05:02 --> Loader Class Initialized
INFO - 2022-03-26 03:05:02 --> Helper loaded: url_helper
INFO - 2022-03-26 03:05:02 --> Helper loaded: form_helper
INFO - 2022-03-26 03:05:02 --> Helper loaded: common_helper
INFO - 2022-03-26 03:05:02 --> Database Driver Class Initialized
DEBUG - 2022-03-26 03:05:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-26 03:05:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-26 03:05:02 --> Controller Class Initialized
INFO - 2022-03-26 03:05:02 --> Form Validation Class Initialized
DEBUG - 2022-03-26 03:05:02 --> Encrypt Class Initialized
INFO - 2022-03-26 03:05:02 --> Model "Login_model" initialized
INFO - 2022-03-26 03:05:02 --> Model "Dashboard_model" initialized
INFO - 2022-03-26 03:05:02 --> Model "Case_model" initialized
INFO - 2022-03-26 03:05:02 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-26 03:05:03 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2022-03-26 03:05:03 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-26 03:05:03 --> Final output sent to browser
DEBUG - 2022-03-26 03:05:03 --> Total execution time: 0.2207
ERROR - 2022-03-26 03:05:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-26 03:05:07 --> Config Class Initialized
INFO - 2022-03-26 03:05:07 --> Hooks Class Initialized
DEBUG - 2022-03-26 03:05:07 --> UTF-8 Support Enabled
INFO - 2022-03-26 03:05:07 --> Utf8 Class Initialized
INFO - 2022-03-26 03:05:07 --> URI Class Initialized
INFO - 2022-03-26 03:05:07 --> Router Class Initialized
INFO - 2022-03-26 03:05:07 --> Output Class Initialized
INFO - 2022-03-26 03:05:07 --> Security Class Initialized
DEBUG - 2022-03-26 03:05:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-26 03:05:07 --> Input Class Initialized
INFO - 2022-03-26 03:05:07 --> Language Class Initialized
INFO - 2022-03-26 03:05:07 --> Loader Class Initialized
INFO - 2022-03-26 03:05:07 --> Helper loaded: url_helper
INFO - 2022-03-26 03:05:07 --> Helper loaded: form_helper
INFO - 2022-03-26 03:05:07 --> Helper loaded: common_helper
INFO - 2022-03-26 03:05:07 --> Database Driver Class Initialized
DEBUG - 2022-03-26 03:05:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-26 03:05:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-26 03:05:07 --> Controller Class Initialized
INFO - 2022-03-26 03:05:07 --> Form Validation Class Initialized
DEBUG - 2022-03-26 03:05:07 --> Encrypt Class Initialized
INFO - 2022-03-26 03:05:07 --> Model "Patient_model" initialized
INFO - 2022-03-26 03:05:07 --> Model "Patientcase_model" initialized
INFO - 2022-03-26 03:05:07 --> Model "Referredby_model" initialized
INFO - 2022-03-26 03:05:07 --> Model "Prefix_master" initialized
INFO - 2022-03-26 03:05:07 --> Model "Hospital_model" initialized
INFO - 2022-03-26 03:05:07 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-26 03:05:07 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-26 03:05:07 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-26 03:05:07 --> Final output sent to browser
DEBUG - 2022-03-26 03:05:07 --> Total execution time: 0.0657
ERROR - 2022-03-26 03:05:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-26 03:05:19 --> Config Class Initialized
INFO - 2022-03-26 03:05:19 --> Hooks Class Initialized
DEBUG - 2022-03-26 03:05:19 --> UTF-8 Support Enabled
INFO - 2022-03-26 03:05:19 --> Utf8 Class Initialized
INFO - 2022-03-26 03:05:19 --> URI Class Initialized
INFO - 2022-03-26 03:05:19 --> Router Class Initialized
INFO - 2022-03-26 03:05:19 --> Output Class Initialized
INFO - 2022-03-26 03:05:19 --> Security Class Initialized
DEBUG - 2022-03-26 03:05:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-26 03:05:19 --> Input Class Initialized
INFO - 2022-03-26 03:05:19 --> Language Class Initialized
INFO - 2022-03-26 03:05:19 --> Loader Class Initialized
INFO - 2022-03-26 03:05:19 --> Helper loaded: url_helper
INFO - 2022-03-26 03:05:19 --> Helper loaded: form_helper
INFO - 2022-03-26 03:05:19 --> Helper loaded: common_helper
INFO - 2022-03-26 03:05:19 --> Database Driver Class Initialized
DEBUG - 2022-03-26 03:05:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-26 03:05:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-26 03:05:19 --> Controller Class Initialized
INFO - 2022-03-26 03:05:19 --> Form Validation Class Initialized
DEBUG - 2022-03-26 03:05:19 --> Encrypt Class Initialized
INFO - 2022-03-26 03:05:19 --> Model "Patient_model" initialized
INFO - 2022-03-26 03:05:19 --> Model "Patientcase_model" initialized
INFO - 2022-03-26 03:05:19 --> Model "Prefix_master" initialized
INFO - 2022-03-26 03:05:19 --> Model "Users_model" initialized
INFO - 2022-03-26 03:05:19 --> Model "Hospital_model" initialized
INFO - 2022-03-26 03:05:20 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-26 03:05:20 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-26 03:05:20 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-26 03:05:20 --> Final output sent to browser
DEBUG - 2022-03-26 03:05:20 --> Total execution time: 0.2995
ERROR - 2022-03-26 03:28:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-26 03:28:32 --> Config Class Initialized
INFO - 2022-03-26 03:28:32 --> Hooks Class Initialized
DEBUG - 2022-03-26 03:28:32 --> UTF-8 Support Enabled
INFO - 2022-03-26 03:28:32 --> Utf8 Class Initialized
INFO - 2022-03-26 03:28:32 --> URI Class Initialized
INFO - 2022-03-26 03:28:32 --> Router Class Initialized
INFO - 2022-03-26 03:28:32 --> Output Class Initialized
INFO - 2022-03-26 03:28:32 --> Security Class Initialized
DEBUG - 2022-03-26 03:28:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-26 03:28:32 --> Input Class Initialized
INFO - 2022-03-26 03:28:32 --> Language Class Initialized
INFO - 2022-03-26 03:28:32 --> Loader Class Initialized
INFO - 2022-03-26 03:28:32 --> Helper loaded: url_helper
INFO - 2022-03-26 03:28:32 --> Helper loaded: form_helper
INFO - 2022-03-26 03:28:32 --> Helper loaded: common_helper
INFO - 2022-03-26 03:28:32 --> Database Driver Class Initialized
DEBUG - 2022-03-26 03:28:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-26 03:28:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-26 03:28:32 --> Controller Class Initialized
INFO - 2022-03-26 03:28:32 --> Form Validation Class Initialized
DEBUG - 2022-03-26 03:28:32 --> Encrypt Class Initialized
DEBUG - 2022-03-26 03:28:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-26 03:28:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-26 03:28:32 --> Email Class Initialized
INFO - 2022-03-26 03:28:32 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-26 03:28:32 --> Calendar Class Initialized
INFO - 2022-03-26 03:28:32 --> Model "Login_model" initialized
ERROR - 2022-03-26 03:28:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-26 03:28:32 --> Config Class Initialized
INFO - 2022-03-26 03:28:32 --> Hooks Class Initialized
DEBUG - 2022-03-26 03:28:32 --> UTF-8 Support Enabled
INFO - 2022-03-26 03:28:32 --> Utf8 Class Initialized
INFO - 2022-03-26 03:28:32 --> URI Class Initialized
INFO - 2022-03-26 03:28:32 --> Router Class Initialized
INFO - 2022-03-26 03:28:32 --> Output Class Initialized
INFO - 2022-03-26 03:28:32 --> Security Class Initialized
DEBUG - 2022-03-26 03:28:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-26 03:28:32 --> Input Class Initialized
INFO - 2022-03-26 03:28:32 --> Language Class Initialized
INFO - 2022-03-26 03:28:32 --> Loader Class Initialized
INFO - 2022-03-26 03:28:32 --> Helper loaded: url_helper
INFO - 2022-03-26 03:28:32 --> Helper loaded: form_helper
INFO - 2022-03-26 03:28:32 --> Helper loaded: common_helper
INFO - 2022-03-26 03:28:32 --> Database Driver Class Initialized
DEBUG - 2022-03-26 03:28:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-26 03:28:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-26 03:28:32 --> Controller Class Initialized
INFO - 2022-03-26 03:28:32 --> Form Validation Class Initialized
DEBUG - 2022-03-26 03:28:32 --> Encrypt Class Initialized
DEBUG - 2022-03-26 03:28:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-26 03:28:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-26 03:28:32 --> Email Class Initialized
INFO - 2022-03-26 03:28:32 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-26 03:28:32 --> Calendar Class Initialized
INFO - 2022-03-26 03:28:32 --> Model "Login_model" initialized
INFO - 2022-03-26 03:28:32 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-26 03:28:32 --> Final output sent to browser
DEBUG - 2022-03-26 03:28:32 --> Total execution time: 0.0066
ERROR - 2022-03-26 11:38:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-26 11:38:07 --> Config Class Initialized
INFO - 2022-03-26 11:38:07 --> Hooks Class Initialized
DEBUG - 2022-03-26 11:38:07 --> UTF-8 Support Enabled
INFO - 2022-03-26 11:38:07 --> Utf8 Class Initialized
INFO - 2022-03-26 11:38:07 --> URI Class Initialized
DEBUG - 2022-03-26 11:38:07 --> No URI present. Default controller set.
INFO - 2022-03-26 11:38:07 --> Router Class Initialized
INFO - 2022-03-26 11:38:07 --> Output Class Initialized
INFO - 2022-03-26 11:38:07 --> Security Class Initialized
DEBUG - 2022-03-26 11:38:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-26 11:38:07 --> Input Class Initialized
INFO - 2022-03-26 11:38:07 --> Language Class Initialized
INFO - 2022-03-26 11:38:07 --> Loader Class Initialized
INFO - 2022-03-26 11:38:07 --> Helper loaded: url_helper
INFO - 2022-03-26 11:38:07 --> Helper loaded: form_helper
INFO - 2022-03-26 11:38:07 --> Helper loaded: common_helper
INFO - 2022-03-26 11:38:07 --> Database Driver Class Initialized
DEBUG - 2022-03-26 11:38:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-26 11:38:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-26 11:38:07 --> Controller Class Initialized
INFO - 2022-03-26 11:38:07 --> Form Validation Class Initialized
DEBUG - 2022-03-26 11:38:07 --> Encrypt Class Initialized
DEBUG - 2022-03-26 11:38:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-26 11:38:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-26 11:38:07 --> Email Class Initialized
INFO - 2022-03-26 11:38:07 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-26 11:38:07 --> Calendar Class Initialized
INFO - 2022-03-26 11:38:07 --> Model "Login_model" initialized
INFO - 2022-03-26 11:38:07 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-26 11:38:07 --> Final output sent to browser
DEBUG - 2022-03-26 11:38:07 --> Total execution time: 0.1172
ERROR - 2022-03-26 14:17:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-26 14:17:58 --> Config Class Initialized
INFO - 2022-03-26 14:17:58 --> Hooks Class Initialized
DEBUG - 2022-03-26 14:17:58 --> UTF-8 Support Enabled
INFO - 2022-03-26 14:17:58 --> Utf8 Class Initialized
INFO - 2022-03-26 14:17:58 --> URI Class Initialized
DEBUG - 2022-03-26 14:17:58 --> No URI present. Default controller set.
INFO - 2022-03-26 14:17:58 --> Router Class Initialized
INFO - 2022-03-26 14:17:58 --> Output Class Initialized
INFO - 2022-03-26 14:17:58 --> Security Class Initialized
DEBUG - 2022-03-26 14:17:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-26 14:17:58 --> Input Class Initialized
INFO - 2022-03-26 14:17:58 --> Language Class Initialized
INFO - 2022-03-26 14:17:58 --> Loader Class Initialized
INFO - 2022-03-26 14:17:58 --> Helper loaded: url_helper
INFO - 2022-03-26 14:17:58 --> Helper loaded: form_helper
INFO - 2022-03-26 14:17:58 --> Helper loaded: common_helper
INFO - 2022-03-26 14:17:58 --> Database Driver Class Initialized
DEBUG - 2022-03-26 14:17:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-26 14:17:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-26 14:17:58 --> Controller Class Initialized
INFO - 2022-03-26 14:17:58 --> Form Validation Class Initialized
DEBUG - 2022-03-26 14:17:58 --> Encrypt Class Initialized
DEBUG - 2022-03-26 14:17:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-26 14:17:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-26 14:17:58 --> Email Class Initialized
INFO - 2022-03-26 14:17:58 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-26 14:17:58 --> Calendar Class Initialized
INFO - 2022-03-26 14:17:58 --> Model "Login_model" initialized
INFO - 2022-03-26 14:17:58 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-26 14:17:58 --> Final output sent to browser
DEBUG - 2022-03-26 14:17:58 --> Total execution time: 0.0698
ERROR - 2022-03-26 14:17:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-26 14:17:59 --> Config Class Initialized
INFO - 2022-03-26 14:17:59 --> Hooks Class Initialized
DEBUG - 2022-03-26 14:17:59 --> UTF-8 Support Enabled
INFO - 2022-03-26 14:17:59 --> Utf8 Class Initialized
INFO - 2022-03-26 14:17:59 --> URI Class Initialized
INFO - 2022-03-26 14:17:59 --> Router Class Initialized
INFO - 2022-03-26 14:17:59 --> Output Class Initialized
INFO - 2022-03-26 14:17:59 --> Security Class Initialized
DEBUG - 2022-03-26 14:17:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-26 14:17:59 --> Input Class Initialized
INFO - 2022-03-26 14:17:59 --> Language Class Initialized
ERROR - 2022-03-26 14:17:59 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2022-03-26 14:18:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-26 14:18:19 --> Config Class Initialized
INFO - 2022-03-26 14:18:19 --> Hooks Class Initialized
DEBUG - 2022-03-26 14:18:19 --> UTF-8 Support Enabled
INFO - 2022-03-26 14:18:19 --> Utf8 Class Initialized
INFO - 2022-03-26 14:18:19 --> URI Class Initialized
INFO - 2022-03-26 14:18:19 --> Router Class Initialized
INFO - 2022-03-26 14:18:19 --> Output Class Initialized
INFO - 2022-03-26 14:18:19 --> Security Class Initialized
DEBUG - 2022-03-26 14:18:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-26 14:18:19 --> Input Class Initialized
INFO - 2022-03-26 14:18:19 --> Language Class Initialized
INFO - 2022-03-26 14:18:19 --> Loader Class Initialized
INFO - 2022-03-26 14:18:19 --> Helper loaded: url_helper
INFO - 2022-03-26 14:18:19 --> Helper loaded: form_helper
INFO - 2022-03-26 14:18:19 --> Helper loaded: common_helper
INFO - 2022-03-26 14:18:19 --> Database Driver Class Initialized
DEBUG - 2022-03-26 14:18:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-26 14:18:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-26 14:18:19 --> Controller Class Initialized
INFO - 2022-03-26 14:18:19 --> Form Validation Class Initialized
DEBUG - 2022-03-26 14:18:19 --> Encrypt Class Initialized
DEBUG - 2022-03-26 14:18:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-26 14:18:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-26 14:18:19 --> Email Class Initialized
INFO - 2022-03-26 14:18:19 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-26 14:18:19 --> Calendar Class Initialized
INFO - 2022-03-26 14:18:19 --> Model "Login_model" initialized
ERROR - 2022-03-26 14:18:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-26 14:18:19 --> Config Class Initialized
INFO - 2022-03-26 14:18:19 --> Hooks Class Initialized
DEBUG - 2022-03-26 14:18:19 --> UTF-8 Support Enabled
INFO - 2022-03-26 14:18:19 --> Utf8 Class Initialized
INFO - 2022-03-26 14:18:19 --> URI Class Initialized
INFO - 2022-03-26 14:18:19 --> Router Class Initialized
INFO - 2022-03-26 14:18:19 --> Output Class Initialized
INFO - 2022-03-26 14:18:19 --> Security Class Initialized
DEBUG - 2022-03-26 14:18:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-26 14:18:19 --> Input Class Initialized
INFO - 2022-03-26 14:18:19 --> Language Class Initialized
INFO - 2022-03-26 14:18:19 --> Loader Class Initialized
INFO - 2022-03-26 14:18:19 --> Helper loaded: url_helper
INFO - 2022-03-26 14:18:19 --> Helper loaded: form_helper
INFO - 2022-03-26 14:18:19 --> Helper loaded: common_helper
INFO - 2022-03-26 14:18:19 --> Database Driver Class Initialized
DEBUG - 2022-03-26 14:18:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-26 14:18:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-26 14:18:19 --> Controller Class Initialized
INFO - 2022-03-26 14:18:19 --> Form Validation Class Initialized
DEBUG - 2022-03-26 14:18:19 --> Encrypt Class Initialized
DEBUG - 2022-03-26 14:18:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-26 14:18:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-26 14:18:19 --> Email Class Initialized
INFO - 2022-03-26 14:18:19 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-26 14:18:19 --> Calendar Class Initialized
INFO - 2022-03-26 14:18:19 --> Model "Login_model" initialized
ERROR - 2022-03-26 14:18:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-26 14:18:19 --> Config Class Initialized
INFO - 2022-03-26 14:18:19 --> Hooks Class Initialized
DEBUG - 2022-03-26 14:18:19 --> UTF-8 Support Enabled
INFO - 2022-03-26 14:18:19 --> Utf8 Class Initialized
INFO - 2022-03-26 14:18:19 --> URI Class Initialized
DEBUG - 2022-03-26 14:18:19 --> No URI present. Default controller set.
INFO - 2022-03-26 14:18:19 --> Router Class Initialized
INFO - 2022-03-26 14:18:19 --> Output Class Initialized
INFO - 2022-03-26 14:18:19 --> Security Class Initialized
DEBUG - 2022-03-26 14:18:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-26 14:18:19 --> Input Class Initialized
INFO - 2022-03-26 14:18:19 --> Language Class Initialized
INFO - 2022-03-26 14:18:19 --> Loader Class Initialized
INFO - 2022-03-26 14:18:19 --> Helper loaded: url_helper
INFO - 2022-03-26 14:18:19 --> Helper loaded: form_helper
INFO - 2022-03-26 14:18:19 --> Helper loaded: common_helper
INFO - 2022-03-26 14:18:19 --> Database Driver Class Initialized
DEBUG - 2022-03-26 14:18:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-26 14:18:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-26 14:18:19 --> Controller Class Initialized
INFO - 2022-03-26 14:18:19 --> Form Validation Class Initialized
DEBUG - 2022-03-26 14:18:19 --> Encrypt Class Initialized
DEBUG - 2022-03-26 14:18:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-26 14:18:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-26 14:18:19 --> Email Class Initialized
INFO - 2022-03-26 14:18:19 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-26 14:18:19 --> Calendar Class Initialized
INFO - 2022-03-26 14:18:19 --> Model "Login_model" initialized
INFO - 2022-03-26 14:18:19 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-26 14:18:19 --> Final output sent to browser
DEBUG - 2022-03-26 14:18:19 --> Total execution time: 0.0059
ERROR - 2022-03-26 14:18:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-26 14:18:20 --> Config Class Initialized
INFO - 2022-03-26 14:18:20 --> Hooks Class Initialized
DEBUG - 2022-03-26 14:18:20 --> UTF-8 Support Enabled
INFO - 2022-03-26 14:18:20 --> Utf8 Class Initialized
INFO - 2022-03-26 14:18:20 --> URI Class Initialized
INFO - 2022-03-26 14:18:20 --> Router Class Initialized
INFO - 2022-03-26 14:18:20 --> Output Class Initialized
INFO - 2022-03-26 14:18:20 --> Security Class Initialized
DEBUG - 2022-03-26 14:18:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-26 14:18:20 --> Input Class Initialized
INFO - 2022-03-26 14:18:20 --> Language Class Initialized
INFO - 2022-03-26 14:18:20 --> Loader Class Initialized
INFO - 2022-03-26 14:18:20 --> Helper loaded: url_helper
INFO - 2022-03-26 14:18:20 --> Helper loaded: form_helper
INFO - 2022-03-26 14:18:20 --> Helper loaded: common_helper
INFO - 2022-03-26 14:18:20 --> Database Driver Class Initialized
DEBUG - 2022-03-26 14:18:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-26 14:18:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-26 14:18:20 --> Controller Class Initialized
INFO - 2022-03-26 14:18:20 --> Form Validation Class Initialized
DEBUG - 2022-03-26 14:18:20 --> Encrypt Class Initialized
DEBUG - 2022-03-26 14:18:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-26 14:18:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-26 14:18:20 --> Email Class Initialized
INFO - 2022-03-26 14:18:20 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-26 14:18:20 --> Calendar Class Initialized
INFO - 2022-03-26 14:18:20 --> Model "Login_model" initialized
INFO - 2022-03-26 14:18:20 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-26 14:18:20 --> Final output sent to browser
DEBUG - 2022-03-26 14:18:20 --> Total execution time: 0.0063
ERROR - 2022-03-26 14:26:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-26 14:26:10 --> Config Class Initialized
INFO - 2022-03-26 14:26:10 --> Hooks Class Initialized
DEBUG - 2022-03-26 14:26:10 --> UTF-8 Support Enabled
INFO - 2022-03-26 14:26:10 --> Utf8 Class Initialized
INFO - 2022-03-26 14:26:10 --> URI Class Initialized
DEBUG - 2022-03-26 14:26:10 --> No URI present. Default controller set.
INFO - 2022-03-26 14:26:10 --> Router Class Initialized
INFO - 2022-03-26 14:26:10 --> Output Class Initialized
INFO - 2022-03-26 14:26:10 --> Security Class Initialized
DEBUG - 2022-03-26 14:26:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-26 14:26:10 --> Input Class Initialized
INFO - 2022-03-26 14:26:10 --> Language Class Initialized
INFO - 2022-03-26 14:26:10 --> Loader Class Initialized
INFO - 2022-03-26 14:26:10 --> Helper loaded: url_helper
INFO - 2022-03-26 14:26:10 --> Helper loaded: form_helper
INFO - 2022-03-26 14:26:10 --> Helper loaded: common_helper
INFO - 2022-03-26 14:26:10 --> Database Driver Class Initialized
DEBUG - 2022-03-26 14:26:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-26 14:26:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-26 14:26:10 --> Controller Class Initialized
INFO - 2022-03-26 14:26:10 --> Form Validation Class Initialized
DEBUG - 2022-03-26 14:26:10 --> Encrypt Class Initialized
DEBUG - 2022-03-26 14:26:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-26 14:26:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-26 14:26:10 --> Email Class Initialized
INFO - 2022-03-26 14:26:10 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-26 14:26:10 --> Calendar Class Initialized
INFO - 2022-03-26 14:26:10 --> Model "Login_model" initialized
INFO - 2022-03-26 14:26:10 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-26 14:26:10 --> Final output sent to browser
DEBUG - 2022-03-26 14:26:10 --> Total execution time: 0.0650
ERROR - 2022-03-26 14:26:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-26 14:26:10 --> Config Class Initialized
INFO - 2022-03-26 14:26:10 --> Hooks Class Initialized
DEBUG - 2022-03-26 14:26:10 --> UTF-8 Support Enabled
INFO - 2022-03-26 14:26:10 --> Utf8 Class Initialized
INFO - 2022-03-26 14:26:10 --> URI Class Initialized
DEBUG - 2022-03-26 14:26:10 --> No URI present. Default controller set.
INFO - 2022-03-26 14:26:10 --> Router Class Initialized
INFO - 2022-03-26 14:26:10 --> Output Class Initialized
INFO - 2022-03-26 14:26:10 --> Security Class Initialized
DEBUG - 2022-03-26 14:26:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-26 14:26:10 --> Input Class Initialized
INFO - 2022-03-26 14:26:10 --> Language Class Initialized
INFO - 2022-03-26 14:26:10 --> Loader Class Initialized
INFO - 2022-03-26 14:26:10 --> Helper loaded: url_helper
INFO - 2022-03-26 14:26:10 --> Helper loaded: form_helper
INFO - 2022-03-26 14:26:10 --> Helper loaded: common_helper
INFO - 2022-03-26 14:26:10 --> Database Driver Class Initialized
DEBUG - 2022-03-26 14:26:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-26 14:26:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-26 14:26:10 --> Controller Class Initialized
INFO - 2022-03-26 14:26:10 --> Form Validation Class Initialized
DEBUG - 2022-03-26 14:26:10 --> Encrypt Class Initialized
DEBUG - 2022-03-26 14:26:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-26 14:26:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-26 14:26:10 --> Email Class Initialized
INFO - 2022-03-26 14:26:10 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-26 14:26:10 --> Calendar Class Initialized
INFO - 2022-03-26 14:26:10 --> Model "Login_model" initialized
INFO - 2022-03-26 14:26:10 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-26 14:26:10 --> Final output sent to browser
DEBUG - 2022-03-26 14:26:10 --> Total execution time: 0.0057
ERROR - 2022-03-26 14:26:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-26 14:26:11 --> Config Class Initialized
INFO - 2022-03-26 14:26:11 --> Hooks Class Initialized
DEBUG - 2022-03-26 14:26:11 --> UTF-8 Support Enabled
INFO - 2022-03-26 14:26:11 --> Utf8 Class Initialized
INFO - 2022-03-26 14:26:11 --> URI Class Initialized
DEBUG - 2022-03-26 14:26:11 --> No URI present. Default controller set.
INFO - 2022-03-26 14:26:11 --> Router Class Initialized
INFO - 2022-03-26 14:26:11 --> Output Class Initialized
INFO - 2022-03-26 14:26:11 --> Security Class Initialized
DEBUG - 2022-03-26 14:26:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-26 14:26:11 --> Input Class Initialized
INFO - 2022-03-26 14:26:11 --> Language Class Initialized
INFO - 2022-03-26 14:26:11 --> Loader Class Initialized
INFO - 2022-03-26 14:26:11 --> Helper loaded: url_helper
INFO - 2022-03-26 14:26:11 --> Helper loaded: form_helper
INFO - 2022-03-26 14:26:11 --> Helper loaded: common_helper
INFO - 2022-03-26 14:26:11 --> Database Driver Class Initialized
DEBUG - 2022-03-26 14:26:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-26 14:26:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-26 14:26:11 --> Controller Class Initialized
INFO - 2022-03-26 14:26:11 --> Form Validation Class Initialized
DEBUG - 2022-03-26 14:26:11 --> Encrypt Class Initialized
DEBUG - 2022-03-26 14:26:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-26 14:26:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-26 14:26:11 --> Email Class Initialized
INFO - 2022-03-26 14:26:11 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-26 14:26:11 --> Calendar Class Initialized
INFO - 2022-03-26 14:26:11 --> Model "Login_model" initialized
INFO - 2022-03-26 14:26:11 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-26 14:26:11 --> Final output sent to browser
DEBUG - 2022-03-26 14:26:11 --> Total execution time: 0.0159
ERROR - 2022-03-26 14:26:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-26 14:26:49 --> Config Class Initialized
INFO - 2022-03-26 14:26:49 --> Hooks Class Initialized
DEBUG - 2022-03-26 14:26:49 --> UTF-8 Support Enabled
INFO - 2022-03-26 14:26:49 --> Utf8 Class Initialized
INFO - 2022-03-26 14:26:49 --> URI Class Initialized
DEBUG - 2022-03-26 14:26:49 --> No URI present. Default controller set.
INFO - 2022-03-26 14:26:49 --> Router Class Initialized
INFO - 2022-03-26 14:26:49 --> Output Class Initialized
INFO - 2022-03-26 14:26:49 --> Security Class Initialized
DEBUG - 2022-03-26 14:26:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-26 14:26:49 --> Input Class Initialized
INFO - 2022-03-26 14:26:49 --> Language Class Initialized
INFO - 2022-03-26 14:26:49 --> Loader Class Initialized
INFO - 2022-03-26 14:26:49 --> Helper loaded: url_helper
INFO - 2022-03-26 14:26:49 --> Helper loaded: form_helper
INFO - 2022-03-26 14:26:49 --> Helper loaded: common_helper
INFO - 2022-03-26 14:26:49 --> Database Driver Class Initialized
DEBUG - 2022-03-26 14:26:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-26 14:26:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-26 14:26:49 --> Controller Class Initialized
INFO - 2022-03-26 14:26:49 --> Form Validation Class Initialized
DEBUG - 2022-03-26 14:26:49 --> Encrypt Class Initialized
DEBUG - 2022-03-26 14:26:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-26 14:26:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-26 14:26:49 --> Email Class Initialized
INFO - 2022-03-26 14:26:49 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-26 14:26:49 --> Calendar Class Initialized
INFO - 2022-03-26 14:26:49 --> Model "Login_model" initialized
INFO - 2022-03-26 14:26:49 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-26 14:26:49 --> Final output sent to browser
DEBUG - 2022-03-26 14:26:49 --> Total execution time: 0.0061
ERROR - 2022-03-26 14:26:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-26 14:26:57 --> Config Class Initialized
INFO - 2022-03-26 14:26:57 --> Hooks Class Initialized
DEBUG - 2022-03-26 14:26:57 --> UTF-8 Support Enabled
INFO - 2022-03-26 14:26:57 --> Utf8 Class Initialized
INFO - 2022-03-26 14:26:57 --> URI Class Initialized
DEBUG - 2022-03-26 14:26:57 --> No URI present. Default controller set.
INFO - 2022-03-26 14:26:57 --> Router Class Initialized
INFO - 2022-03-26 14:26:57 --> Output Class Initialized
INFO - 2022-03-26 14:26:57 --> Security Class Initialized
DEBUG - 2022-03-26 14:26:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-26 14:26:57 --> Input Class Initialized
INFO - 2022-03-26 14:26:57 --> Language Class Initialized
INFO - 2022-03-26 14:26:57 --> Loader Class Initialized
INFO - 2022-03-26 14:26:57 --> Helper loaded: url_helper
INFO - 2022-03-26 14:26:57 --> Helper loaded: form_helper
INFO - 2022-03-26 14:26:57 --> Helper loaded: common_helper
INFO - 2022-03-26 14:26:57 --> Database Driver Class Initialized
DEBUG - 2022-03-26 14:26:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-26 14:26:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-26 14:26:57 --> Controller Class Initialized
INFO - 2022-03-26 14:26:57 --> Form Validation Class Initialized
DEBUG - 2022-03-26 14:26:57 --> Encrypt Class Initialized
DEBUG - 2022-03-26 14:26:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-26 14:26:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-26 14:26:57 --> Email Class Initialized
INFO - 2022-03-26 14:26:57 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-26 14:26:57 --> Calendar Class Initialized
INFO - 2022-03-26 14:26:57 --> Model "Login_model" initialized
INFO - 2022-03-26 14:26:57 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-26 14:26:57 --> Final output sent to browser
DEBUG - 2022-03-26 14:26:57 --> Total execution time: 0.0058
ERROR - 2022-03-26 14:27:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-26 14:27:03 --> Config Class Initialized
INFO - 2022-03-26 14:27:03 --> Hooks Class Initialized
DEBUG - 2022-03-26 14:27:03 --> UTF-8 Support Enabled
INFO - 2022-03-26 14:27:03 --> Utf8 Class Initialized
INFO - 2022-03-26 14:27:03 --> URI Class Initialized
DEBUG - 2022-03-26 14:27:03 --> No URI present. Default controller set.
INFO - 2022-03-26 14:27:03 --> Router Class Initialized
INFO - 2022-03-26 14:27:03 --> Output Class Initialized
INFO - 2022-03-26 14:27:03 --> Security Class Initialized
DEBUG - 2022-03-26 14:27:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-26 14:27:03 --> Input Class Initialized
INFO - 2022-03-26 14:27:03 --> Language Class Initialized
INFO - 2022-03-26 14:27:03 --> Loader Class Initialized
INFO - 2022-03-26 14:27:03 --> Helper loaded: url_helper
INFO - 2022-03-26 14:27:03 --> Helper loaded: form_helper
INFO - 2022-03-26 14:27:03 --> Helper loaded: common_helper
INFO - 2022-03-26 14:27:03 --> Database Driver Class Initialized
DEBUG - 2022-03-26 14:27:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-26 14:27:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-26 14:27:03 --> Controller Class Initialized
INFO - 2022-03-26 14:27:03 --> Form Validation Class Initialized
DEBUG - 2022-03-26 14:27:03 --> Encrypt Class Initialized
DEBUG - 2022-03-26 14:27:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-26 14:27:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-26 14:27:03 --> Email Class Initialized
INFO - 2022-03-26 14:27:03 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-26 14:27:03 --> Calendar Class Initialized
INFO - 2022-03-26 14:27:03 --> Model "Login_model" initialized
INFO - 2022-03-26 14:27:03 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-26 14:27:03 --> Final output sent to browser
DEBUG - 2022-03-26 14:27:03 --> Total execution time: 0.0116
ERROR - 2022-03-26 14:27:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-26 14:27:29 --> Config Class Initialized
INFO - 2022-03-26 14:27:29 --> Hooks Class Initialized
DEBUG - 2022-03-26 14:27:29 --> UTF-8 Support Enabled
INFO - 2022-03-26 14:27:29 --> Utf8 Class Initialized
INFO - 2022-03-26 14:27:29 --> URI Class Initialized
DEBUG - 2022-03-26 14:27:29 --> No URI present. Default controller set.
INFO - 2022-03-26 14:27:29 --> Router Class Initialized
INFO - 2022-03-26 14:27:29 --> Output Class Initialized
INFO - 2022-03-26 14:27:29 --> Security Class Initialized
DEBUG - 2022-03-26 14:27:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-26 14:27:29 --> Input Class Initialized
INFO - 2022-03-26 14:27:29 --> Language Class Initialized
INFO - 2022-03-26 14:27:29 --> Loader Class Initialized
INFO - 2022-03-26 14:27:29 --> Helper loaded: url_helper
INFO - 2022-03-26 14:27:29 --> Helper loaded: form_helper
INFO - 2022-03-26 14:27:29 --> Helper loaded: common_helper
INFO - 2022-03-26 14:27:29 --> Database Driver Class Initialized
DEBUG - 2022-03-26 14:27:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-26 14:27:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-26 14:27:29 --> Controller Class Initialized
INFO - 2022-03-26 14:27:29 --> Form Validation Class Initialized
DEBUG - 2022-03-26 14:27:29 --> Encrypt Class Initialized
DEBUG - 2022-03-26 14:27:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-26 14:27:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-26 14:27:29 --> Email Class Initialized
INFO - 2022-03-26 14:27:29 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-26 14:27:29 --> Calendar Class Initialized
INFO - 2022-03-26 14:27:29 --> Model "Login_model" initialized
INFO - 2022-03-26 14:27:29 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-26 14:27:29 --> Final output sent to browser
DEBUG - 2022-03-26 14:27:29 --> Total execution time: 0.0063
ERROR - 2022-03-26 14:28:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-26 14:28:00 --> Config Class Initialized
INFO - 2022-03-26 14:28:00 --> Hooks Class Initialized
DEBUG - 2022-03-26 14:28:00 --> UTF-8 Support Enabled
INFO - 2022-03-26 14:28:00 --> Utf8 Class Initialized
INFO - 2022-03-26 14:28:00 --> URI Class Initialized
DEBUG - 2022-03-26 14:28:00 --> No URI present. Default controller set.
INFO - 2022-03-26 14:28:00 --> Router Class Initialized
INFO - 2022-03-26 14:28:00 --> Output Class Initialized
INFO - 2022-03-26 14:28:00 --> Security Class Initialized
DEBUG - 2022-03-26 14:28:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-26 14:28:00 --> Input Class Initialized
INFO - 2022-03-26 14:28:00 --> Language Class Initialized
INFO - 2022-03-26 14:28:00 --> Loader Class Initialized
INFO - 2022-03-26 14:28:00 --> Helper loaded: url_helper
INFO - 2022-03-26 14:28:00 --> Helper loaded: form_helper
INFO - 2022-03-26 14:28:00 --> Helper loaded: common_helper
INFO - 2022-03-26 14:28:00 --> Database Driver Class Initialized
DEBUG - 2022-03-26 14:28:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-26 14:28:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-26 14:28:00 --> Controller Class Initialized
INFO - 2022-03-26 14:28:00 --> Form Validation Class Initialized
DEBUG - 2022-03-26 14:28:00 --> Encrypt Class Initialized
DEBUG - 2022-03-26 14:28:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-26 14:28:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-26 14:28:00 --> Email Class Initialized
INFO - 2022-03-26 14:28:00 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-26 14:28:00 --> Calendar Class Initialized
INFO - 2022-03-26 14:28:00 --> Model "Login_model" initialized
INFO - 2022-03-26 14:28:00 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-26 14:28:00 --> Final output sent to browser
DEBUG - 2022-03-26 14:28:00 --> Total execution time: 0.0060
ERROR - 2022-03-26 14:28:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-26 14:28:46 --> Config Class Initialized
INFO - 2022-03-26 14:28:46 --> Hooks Class Initialized
DEBUG - 2022-03-26 14:28:46 --> UTF-8 Support Enabled
INFO - 2022-03-26 14:28:46 --> Utf8 Class Initialized
INFO - 2022-03-26 14:28:46 --> URI Class Initialized
DEBUG - 2022-03-26 14:28:46 --> No URI present. Default controller set.
INFO - 2022-03-26 14:28:46 --> Router Class Initialized
INFO - 2022-03-26 14:28:46 --> Output Class Initialized
INFO - 2022-03-26 14:28:46 --> Security Class Initialized
DEBUG - 2022-03-26 14:28:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-26 14:28:46 --> Input Class Initialized
INFO - 2022-03-26 14:28:46 --> Language Class Initialized
INFO - 2022-03-26 14:28:46 --> Loader Class Initialized
INFO - 2022-03-26 14:28:46 --> Helper loaded: url_helper
INFO - 2022-03-26 14:28:46 --> Helper loaded: form_helper
INFO - 2022-03-26 14:28:46 --> Helper loaded: common_helper
INFO - 2022-03-26 14:28:46 --> Database Driver Class Initialized
DEBUG - 2022-03-26 14:28:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-26 14:28:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-26 14:28:46 --> Controller Class Initialized
INFO - 2022-03-26 14:28:46 --> Form Validation Class Initialized
DEBUG - 2022-03-26 14:28:46 --> Encrypt Class Initialized
DEBUG - 2022-03-26 14:28:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-26 14:28:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-26 14:28:46 --> Email Class Initialized
INFO - 2022-03-26 14:28:46 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-26 14:28:46 --> Calendar Class Initialized
INFO - 2022-03-26 14:28:46 --> Model "Login_model" initialized
INFO - 2022-03-26 14:28:46 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-26 14:28:46 --> Final output sent to browser
DEBUG - 2022-03-26 14:28:46 --> Total execution time: 0.0064
ERROR - 2022-03-26 14:29:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-26 14:29:17 --> Config Class Initialized
INFO - 2022-03-26 14:29:17 --> Hooks Class Initialized
DEBUG - 2022-03-26 14:29:17 --> UTF-8 Support Enabled
INFO - 2022-03-26 14:29:17 --> Utf8 Class Initialized
INFO - 2022-03-26 14:29:17 --> URI Class Initialized
DEBUG - 2022-03-26 14:29:17 --> No URI present. Default controller set.
INFO - 2022-03-26 14:29:17 --> Router Class Initialized
INFO - 2022-03-26 14:29:17 --> Output Class Initialized
INFO - 2022-03-26 14:29:17 --> Security Class Initialized
DEBUG - 2022-03-26 14:29:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-26 14:29:17 --> Input Class Initialized
INFO - 2022-03-26 14:29:17 --> Language Class Initialized
INFO - 2022-03-26 14:29:17 --> Loader Class Initialized
INFO - 2022-03-26 14:29:17 --> Helper loaded: url_helper
INFO - 2022-03-26 14:29:17 --> Helper loaded: form_helper
INFO - 2022-03-26 14:29:17 --> Helper loaded: common_helper
INFO - 2022-03-26 14:29:17 --> Database Driver Class Initialized
DEBUG - 2022-03-26 14:29:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-26 14:29:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-26 14:29:17 --> Controller Class Initialized
INFO - 2022-03-26 14:29:17 --> Form Validation Class Initialized
DEBUG - 2022-03-26 14:29:17 --> Encrypt Class Initialized
DEBUG - 2022-03-26 14:29:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-26 14:29:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-26 14:29:17 --> Email Class Initialized
INFO - 2022-03-26 14:29:17 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-26 14:29:17 --> Calendar Class Initialized
INFO - 2022-03-26 14:29:17 --> Model "Login_model" initialized
INFO - 2022-03-26 14:29:17 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-26 14:29:17 --> Final output sent to browser
DEBUG - 2022-03-26 14:29:17 --> Total execution time: 0.0064
ERROR - 2022-03-26 14:29:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-26 14:29:48 --> Config Class Initialized
INFO - 2022-03-26 14:29:48 --> Hooks Class Initialized
DEBUG - 2022-03-26 14:29:48 --> UTF-8 Support Enabled
INFO - 2022-03-26 14:29:48 --> Utf8 Class Initialized
INFO - 2022-03-26 14:29:48 --> URI Class Initialized
DEBUG - 2022-03-26 14:29:48 --> No URI present. Default controller set.
INFO - 2022-03-26 14:29:48 --> Router Class Initialized
INFO - 2022-03-26 14:29:48 --> Output Class Initialized
INFO - 2022-03-26 14:29:48 --> Security Class Initialized
DEBUG - 2022-03-26 14:29:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-26 14:29:48 --> Input Class Initialized
INFO - 2022-03-26 14:29:48 --> Language Class Initialized
INFO - 2022-03-26 14:29:48 --> Loader Class Initialized
INFO - 2022-03-26 14:29:48 --> Helper loaded: url_helper
INFO - 2022-03-26 14:29:48 --> Helper loaded: form_helper
INFO - 2022-03-26 14:29:48 --> Helper loaded: common_helper
INFO - 2022-03-26 14:29:48 --> Database Driver Class Initialized
DEBUG - 2022-03-26 14:29:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-26 14:29:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-26 14:29:48 --> Controller Class Initialized
INFO - 2022-03-26 14:29:48 --> Form Validation Class Initialized
DEBUG - 2022-03-26 14:29:48 --> Encrypt Class Initialized
DEBUG - 2022-03-26 14:29:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-26 14:29:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-26 14:29:48 --> Email Class Initialized
INFO - 2022-03-26 14:29:48 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-26 14:29:48 --> Calendar Class Initialized
INFO - 2022-03-26 14:29:48 --> Model "Login_model" initialized
INFO - 2022-03-26 14:29:48 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-26 14:29:48 --> Final output sent to browser
DEBUG - 2022-03-26 14:29:48 --> Total execution time: 0.0347
ERROR - 2022-03-26 14:30:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-26 14:30:20 --> Config Class Initialized
INFO - 2022-03-26 14:30:20 --> Hooks Class Initialized
DEBUG - 2022-03-26 14:30:20 --> UTF-8 Support Enabled
INFO - 2022-03-26 14:30:20 --> Utf8 Class Initialized
INFO - 2022-03-26 14:30:20 --> URI Class Initialized
DEBUG - 2022-03-26 14:30:20 --> No URI present. Default controller set.
INFO - 2022-03-26 14:30:20 --> Router Class Initialized
INFO - 2022-03-26 14:30:20 --> Output Class Initialized
INFO - 2022-03-26 14:30:20 --> Security Class Initialized
DEBUG - 2022-03-26 14:30:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-26 14:30:20 --> Input Class Initialized
INFO - 2022-03-26 14:30:20 --> Language Class Initialized
INFO - 2022-03-26 14:30:20 --> Loader Class Initialized
INFO - 2022-03-26 14:30:20 --> Helper loaded: url_helper
INFO - 2022-03-26 14:30:20 --> Helper loaded: form_helper
INFO - 2022-03-26 14:30:20 --> Helper loaded: common_helper
INFO - 2022-03-26 14:30:20 --> Database Driver Class Initialized
DEBUG - 2022-03-26 14:30:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-26 14:30:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-26 14:30:20 --> Controller Class Initialized
INFO - 2022-03-26 14:30:20 --> Form Validation Class Initialized
DEBUG - 2022-03-26 14:30:20 --> Encrypt Class Initialized
DEBUG - 2022-03-26 14:30:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-26 14:30:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-26 14:30:20 --> Email Class Initialized
INFO - 2022-03-26 14:30:20 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-26 14:30:20 --> Calendar Class Initialized
INFO - 2022-03-26 14:30:20 --> Model "Login_model" initialized
INFO - 2022-03-26 14:30:20 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-26 14:30:20 --> Final output sent to browser
DEBUG - 2022-03-26 14:30:20 --> Total execution time: 0.0080
ERROR - 2022-03-26 14:30:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-26 14:30:52 --> Config Class Initialized
INFO - 2022-03-26 14:30:52 --> Hooks Class Initialized
DEBUG - 2022-03-26 14:30:52 --> UTF-8 Support Enabled
INFO - 2022-03-26 14:30:52 --> Utf8 Class Initialized
INFO - 2022-03-26 14:30:52 --> URI Class Initialized
DEBUG - 2022-03-26 14:30:52 --> No URI present. Default controller set.
INFO - 2022-03-26 14:30:52 --> Router Class Initialized
INFO - 2022-03-26 14:30:52 --> Output Class Initialized
INFO - 2022-03-26 14:30:52 --> Security Class Initialized
DEBUG - 2022-03-26 14:30:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-26 14:30:52 --> Input Class Initialized
INFO - 2022-03-26 14:30:52 --> Language Class Initialized
INFO - 2022-03-26 14:30:52 --> Loader Class Initialized
INFO - 2022-03-26 14:30:52 --> Helper loaded: url_helper
INFO - 2022-03-26 14:30:52 --> Helper loaded: form_helper
INFO - 2022-03-26 14:30:52 --> Helper loaded: common_helper
INFO - 2022-03-26 14:30:52 --> Database Driver Class Initialized
DEBUG - 2022-03-26 14:30:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-26 14:30:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-26 14:30:52 --> Controller Class Initialized
INFO - 2022-03-26 14:30:52 --> Form Validation Class Initialized
DEBUG - 2022-03-26 14:30:52 --> Encrypt Class Initialized
DEBUG - 2022-03-26 14:30:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-26 14:30:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-26 14:30:52 --> Email Class Initialized
INFO - 2022-03-26 14:30:52 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-26 14:30:52 --> Calendar Class Initialized
INFO - 2022-03-26 14:30:52 --> Model "Login_model" initialized
INFO - 2022-03-26 14:30:52 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-26 14:30:52 --> Final output sent to browser
DEBUG - 2022-03-26 14:30:52 --> Total execution time: 0.0058
ERROR - 2022-03-26 14:32:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-26 14:32:38 --> Config Class Initialized
INFO - 2022-03-26 14:32:38 --> Hooks Class Initialized
DEBUG - 2022-03-26 14:32:38 --> UTF-8 Support Enabled
INFO - 2022-03-26 14:32:38 --> Utf8 Class Initialized
INFO - 2022-03-26 14:32:38 --> URI Class Initialized
DEBUG - 2022-03-26 14:32:38 --> No URI present. Default controller set.
INFO - 2022-03-26 14:32:38 --> Router Class Initialized
INFO - 2022-03-26 14:32:38 --> Output Class Initialized
INFO - 2022-03-26 14:32:38 --> Security Class Initialized
DEBUG - 2022-03-26 14:32:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-26 14:32:38 --> Input Class Initialized
INFO - 2022-03-26 14:32:38 --> Language Class Initialized
INFO - 2022-03-26 14:32:38 --> Loader Class Initialized
INFO - 2022-03-26 14:32:38 --> Helper loaded: url_helper
INFO - 2022-03-26 14:32:38 --> Helper loaded: form_helper
INFO - 2022-03-26 14:32:38 --> Helper loaded: common_helper
INFO - 2022-03-26 14:32:38 --> Database Driver Class Initialized
DEBUG - 2022-03-26 14:32:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-26 14:32:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-26 14:32:38 --> Controller Class Initialized
INFO - 2022-03-26 14:32:38 --> Form Validation Class Initialized
DEBUG - 2022-03-26 14:32:38 --> Encrypt Class Initialized
DEBUG - 2022-03-26 14:32:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-26 14:32:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-26 14:32:38 --> Email Class Initialized
INFO - 2022-03-26 14:32:38 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-26 14:32:38 --> Calendar Class Initialized
INFO - 2022-03-26 14:32:38 --> Model "Login_model" initialized
INFO - 2022-03-26 14:32:38 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-26 14:32:38 --> Final output sent to browser
DEBUG - 2022-03-26 14:32:38 --> Total execution time: 0.1729
ERROR - 2022-03-26 14:33:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-26 14:33:10 --> Config Class Initialized
INFO - 2022-03-26 14:33:10 --> Hooks Class Initialized
DEBUG - 2022-03-26 14:33:10 --> UTF-8 Support Enabled
INFO - 2022-03-26 14:33:10 --> Utf8 Class Initialized
INFO - 2022-03-26 14:33:10 --> URI Class Initialized
DEBUG - 2022-03-26 14:33:10 --> No URI present. Default controller set.
INFO - 2022-03-26 14:33:10 --> Router Class Initialized
INFO - 2022-03-26 14:33:10 --> Output Class Initialized
INFO - 2022-03-26 14:33:10 --> Security Class Initialized
DEBUG - 2022-03-26 14:33:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-26 14:33:10 --> Input Class Initialized
INFO - 2022-03-26 14:33:10 --> Language Class Initialized
INFO - 2022-03-26 14:33:10 --> Loader Class Initialized
INFO - 2022-03-26 14:33:10 --> Helper loaded: url_helper
INFO - 2022-03-26 14:33:10 --> Helper loaded: form_helper
INFO - 2022-03-26 14:33:10 --> Helper loaded: common_helper
INFO - 2022-03-26 14:33:10 --> Database Driver Class Initialized
DEBUG - 2022-03-26 14:33:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-26 14:33:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-26 14:33:10 --> Controller Class Initialized
INFO - 2022-03-26 14:33:10 --> Form Validation Class Initialized
DEBUG - 2022-03-26 14:33:10 --> Encrypt Class Initialized
DEBUG - 2022-03-26 14:33:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-26 14:33:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-26 14:33:10 --> Email Class Initialized
INFO - 2022-03-26 14:33:10 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-26 14:33:10 --> Calendar Class Initialized
INFO - 2022-03-26 14:33:10 --> Model "Login_model" initialized
INFO - 2022-03-26 14:33:10 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-26 14:33:10 --> Final output sent to browser
DEBUG - 2022-03-26 14:33:10 --> Total execution time: 0.0065
ERROR - 2022-03-26 14:33:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-26 14:33:41 --> Config Class Initialized
INFO - 2022-03-26 14:33:41 --> Hooks Class Initialized
DEBUG - 2022-03-26 14:33:41 --> UTF-8 Support Enabled
INFO - 2022-03-26 14:33:41 --> Utf8 Class Initialized
INFO - 2022-03-26 14:33:41 --> URI Class Initialized
DEBUG - 2022-03-26 14:33:41 --> No URI present. Default controller set.
INFO - 2022-03-26 14:33:41 --> Router Class Initialized
INFO - 2022-03-26 14:33:41 --> Output Class Initialized
INFO - 2022-03-26 14:33:41 --> Security Class Initialized
DEBUG - 2022-03-26 14:33:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-26 14:33:41 --> Input Class Initialized
INFO - 2022-03-26 14:33:41 --> Language Class Initialized
INFO - 2022-03-26 14:33:41 --> Loader Class Initialized
INFO - 2022-03-26 14:33:41 --> Helper loaded: url_helper
INFO - 2022-03-26 14:33:41 --> Helper loaded: form_helper
INFO - 2022-03-26 14:33:41 --> Helper loaded: common_helper
INFO - 2022-03-26 14:33:41 --> Database Driver Class Initialized
DEBUG - 2022-03-26 14:33:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-26 14:33:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-26 14:33:41 --> Controller Class Initialized
INFO - 2022-03-26 14:33:41 --> Form Validation Class Initialized
DEBUG - 2022-03-26 14:33:41 --> Encrypt Class Initialized
DEBUG - 2022-03-26 14:33:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-26 14:33:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-26 14:33:41 --> Email Class Initialized
INFO - 2022-03-26 14:33:41 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-26 14:33:41 --> Calendar Class Initialized
INFO - 2022-03-26 14:33:41 --> Model "Login_model" initialized
INFO - 2022-03-26 14:33:41 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-26 14:33:41 --> Final output sent to browser
DEBUG - 2022-03-26 14:33:41 --> Total execution time: 0.0062
ERROR - 2022-03-26 14:33:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-26 14:33:54 --> Config Class Initialized
INFO - 2022-03-26 14:33:54 --> Hooks Class Initialized
DEBUG - 2022-03-26 14:33:54 --> UTF-8 Support Enabled
INFO - 2022-03-26 14:33:54 --> Utf8 Class Initialized
INFO - 2022-03-26 14:33:54 --> URI Class Initialized
DEBUG - 2022-03-26 14:33:54 --> No URI present. Default controller set.
INFO - 2022-03-26 14:33:54 --> Router Class Initialized
INFO - 2022-03-26 14:33:54 --> Output Class Initialized
INFO - 2022-03-26 14:33:54 --> Security Class Initialized
DEBUG - 2022-03-26 14:33:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-26 14:33:54 --> Input Class Initialized
INFO - 2022-03-26 14:33:54 --> Language Class Initialized
INFO - 2022-03-26 14:33:54 --> Loader Class Initialized
INFO - 2022-03-26 14:33:54 --> Helper loaded: url_helper
INFO - 2022-03-26 14:33:54 --> Helper loaded: form_helper
INFO - 2022-03-26 14:33:54 --> Helper loaded: common_helper
INFO - 2022-03-26 14:33:54 --> Database Driver Class Initialized
DEBUG - 2022-03-26 14:33:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-26 14:33:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-26 14:33:54 --> Controller Class Initialized
INFO - 2022-03-26 14:33:54 --> Form Validation Class Initialized
DEBUG - 2022-03-26 14:33:54 --> Encrypt Class Initialized
DEBUG - 2022-03-26 14:33:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-26 14:33:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-26 14:33:54 --> Email Class Initialized
INFO - 2022-03-26 14:33:54 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-26 14:33:54 --> Calendar Class Initialized
INFO - 2022-03-26 14:33:54 --> Model "Login_model" initialized
INFO - 2022-03-26 14:33:54 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-26 14:33:54 --> Final output sent to browser
DEBUG - 2022-03-26 14:33:54 --> Total execution time: 0.0067
ERROR - 2022-03-26 14:34:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-26 14:34:13 --> Config Class Initialized
INFO - 2022-03-26 14:34:13 --> Hooks Class Initialized
DEBUG - 2022-03-26 14:34:13 --> UTF-8 Support Enabled
INFO - 2022-03-26 14:34:13 --> Utf8 Class Initialized
INFO - 2022-03-26 14:34:13 --> URI Class Initialized
DEBUG - 2022-03-26 14:34:13 --> No URI present. Default controller set.
INFO - 2022-03-26 14:34:13 --> Router Class Initialized
INFO - 2022-03-26 14:34:13 --> Output Class Initialized
INFO - 2022-03-26 14:34:13 --> Security Class Initialized
DEBUG - 2022-03-26 14:34:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-26 14:34:13 --> Input Class Initialized
INFO - 2022-03-26 14:34:13 --> Language Class Initialized
INFO - 2022-03-26 14:34:13 --> Loader Class Initialized
INFO - 2022-03-26 14:34:13 --> Helper loaded: url_helper
INFO - 2022-03-26 14:34:13 --> Helper loaded: form_helper
INFO - 2022-03-26 14:34:13 --> Helper loaded: common_helper
INFO - 2022-03-26 14:34:13 --> Database Driver Class Initialized
DEBUG - 2022-03-26 14:34:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-26 14:34:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-26 14:34:13 --> Controller Class Initialized
INFO - 2022-03-26 14:34:13 --> Form Validation Class Initialized
DEBUG - 2022-03-26 14:34:13 --> Encrypt Class Initialized
DEBUG - 2022-03-26 14:34:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-26 14:34:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-26 14:34:13 --> Email Class Initialized
INFO - 2022-03-26 14:34:13 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-26 14:34:13 --> Calendar Class Initialized
INFO - 2022-03-26 14:34:13 --> Model "Login_model" initialized
INFO - 2022-03-26 14:34:13 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-26 14:34:13 --> Final output sent to browser
DEBUG - 2022-03-26 14:34:13 --> Total execution time: 0.0121
ERROR - 2022-03-26 14:34:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-26 14:34:44 --> Config Class Initialized
INFO - 2022-03-26 14:34:44 --> Hooks Class Initialized
DEBUG - 2022-03-26 14:34:44 --> UTF-8 Support Enabled
INFO - 2022-03-26 14:34:44 --> Utf8 Class Initialized
INFO - 2022-03-26 14:34:44 --> URI Class Initialized
DEBUG - 2022-03-26 14:34:44 --> No URI present. Default controller set.
INFO - 2022-03-26 14:34:44 --> Router Class Initialized
INFO - 2022-03-26 14:34:44 --> Output Class Initialized
INFO - 2022-03-26 14:34:44 --> Security Class Initialized
DEBUG - 2022-03-26 14:34:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-26 14:34:44 --> Input Class Initialized
INFO - 2022-03-26 14:34:44 --> Language Class Initialized
INFO - 2022-03-26 14:34:44 --> Loader Class Initialized
INFO - 2022-03-26 14:34:44 --> Helper loaded: url_helper
INFO - 2022-03-26 14:34:44 --> Helper loaded: form_helper
INFO - 2022-03-26 14:34:44 --> Helper loaded: common_helper
INFO - 2022-03-26 14:34:44 --> Database Driver Class Initialized
DEBUG - 2022-03-26 14:34:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-26 14:34:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-26 14:34:44 --> Controller Class Initialized
INFO - 2022-03-26 14:34:44 --> Form Validation Class Initialized
DEBUG - 2022-03-26 14:34:44 --> Encrypt Class Initialized
DEBUG - 2022-03-26 14:34:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-26 14:34:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-26 14:34:44 --> Email Class Initialized
INFO - 2022-03-26 14:34:44 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-26 14:34:44 --> Calendar Class Initialized
INFO - 2022-03-26 14:34:44 --> Model "Login_model" initialized
INFO - 2022-03-26 14:34:44 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-26 14:34:44 --> Final output sent to browser
DEBUG - 2022-03-26 14:34:44 --> Total execution time: 0.0088
ERROR - 2022-03-26 15:44:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-26 15:44:55 --> Config Class Initialized
INFO - 2022-03-26 15:44:55 --> Hooks Class Initialized
DEBUG - 2022-03-26 15:44:55 --> UTF-8 Support Enabled
INFO - 2022-03-26 15:44:55 --> Utf8 Class Initialized
INFO - 2022-03-26 15:44:55 --> URI Class Initialized
DEBUG - 2022-03-26 15:44:55 --> No URI present. Default controller set.
INFO - 2022-03-26 15:44:55 --> Router Class Initialized
INFO - 2022-03-26 15:44:55 --> Output Class Initialized
INFO - 2022-03-26 15:44:55 --> Security Class Initialized
DEBUG - 2022-03-26 15:44:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-26 15:44:55 --> Input Class Initialized
INFO - 2022-03-26 15:44:55 --> Language Class Initialized
INFO - 2022-03-26 15:44:55 --> Loader Class Initialized
INFO - 2022-03-26 15:44:55 --> Helper loaded: url_helper
INFO - 2022-03-26 15:44:55 --> Helper loaded: form_helper
INFO - 2022-03-26 15:44:55 --> Helper loaded: common_helper
INFO - 2022-03-26 15:44:55 --> Database Driver Class Initialized
DEBUG - 2022-03-26 15:44:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-26 15:44:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-26 15:44:55 --> Controller Class Initialized
INFO - 2022-03-26 15:44:55 --> Form Validation Class Initialized
DEBUG - 2022-03-26 15:44:55 --> Encrypt Class Initialized
DEBUG - 2022-03-26 15:44:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-26 15:44:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-26 15:44:55 --> Email Class Initialized
INFO - 2022-03-26 15:44:55 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-26 15:44:55 --> Calendar Class Initialized
INFO - 2022-03-26 15:44:55 --> Model "Login_model" initialized
INFO - 2022-03-26 15:44:55 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-26 15:44:55 --> Final output sent to browser
DEBUG - 2022-03-26 15:44:55 --> Total execution time: 0.0900
ERROR - 2022-03-26 15:44:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-26 15:44:55 --> Config Class Initialized
INFO - 2022-03-26 15:44:55 --> Hooks Class Initialized
DEBUG - 2022-03-26 15:44:55 --> UTF-8 Support Enabled
INFO - 2022-03-26 15:44:55 --> Utf8 Class Initialized
INFO - 2022-03-26 15:44:55 --> URI Class Initialized
DEBUG - 2022-03-26 15:44:55 --> No URI present. Default controller set.
INFO - 2022-03-26 15:44:55 --> Router Class Initialized
INFO - 2022-03-26 15:44:55 --> Output Class Initialized
INFO - 2022-03-26 15:44:55 --> Security Class Initialized
DEBUG - 2022-03-26 15:44:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-26 15:44:55 --> Input Class Initialized
INFO - 2022-03-26 15:44:55 --> Language Class Initialized
INFO - 2022-03-26 15:44:55 --> Loader Class Initialized
INFO - 2022-03-26 15:44:55 --> Helper loaded: url_helper
INFO - 2022-03-26 15:44:55 --> Helper loaded: form_helper
INFO - 2022-03-26 15:44:55 --> Helper loaded: common_helper
INFO - 2022-03-26 15:44:55 --> Database Driver Class Initialized
DEBUG - 2022-03-26 15:44:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-26 15:44:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-26 15:44:55 --> Controller Class Initialized
INFO - 2022-03-26 15:44:55 --> Form Validation Class Initialized
DEBUG - 2022-03-26 15:44:55 --> Encrypt Class Initialized
DEBUG - 2022-03-26 15:44:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-26 15:44:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-26 15:44:55 --> Email Class Initialized
INFO - 2022-03-26 15:44:55 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-26 15:44:55 --> Calendar Class Initialized
INFO - 2022-03-26 15:44:55 --> Model "Login_model" initialized
INFO - 2022-03-26 15:44:55 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-26 15:44:55 --> Final output sent to browser
DEBUG - 2022-03-26 15:44:55 --> Total execution time: 0.0059
ERROR - 2022-03-26 15:44:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-26 15:44:56 --> Config Class Initialized
INFO - 2022-03-26 15:44:56 --> Hooks Class Initialized
DEBUG - 2022-03-26 15:44:56 --> UTF-8 Support Enabled
INFO - 2022-03-26 15:44:56 --> Utf8 Class Initialized
INFO - 2022-03-26 15:44:56 --> URI Class Initialized
DEBUG - 2022-03-26 15:44:56 --> No URI present. Default controller set.
INFO - 2022-03-26 15:44:56 --> Router Class Initialized
INFO - 2022-03-26 15:44:56 --> Output Class Initialized
INFO - 2022-03-26 15:44:56 --> Security Class Initialized
DEBUG - 2022-03-26 15:44:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-26 15:44:56 --> Input Class Initialized
INFO - 2022-03-26 15:44:56 --> Language Class Initialized
INFO - 2022-03-26 15:44:56 --> Loader Class Initialized
INFO - 2022-03-26 15:44:56 --> Helper loaded: url_helper
INFO - 2022-03-26 15:44:56 --> Helper loaded: form_helper
INFO - 2022-03-26 15:44:56 --> Helper loaded: common_helper
INFO - 2022-03-26 15:44:56 --> Database Driver Class Initialized
DEBUG - 2022-03-26 15:44:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-26 15:44:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-26 15:44:56 --> Controller Class Initialized
INFO - 2022-03-26 15:44:56 --> Form Validation Class Initialized
DEBUG - 2022-03-26 15:44:56 --> Encrypt Class Initialized
DEBUG - 2022-03-26 15:44:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-26 15:44:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-26 15:44:56 --> Email Class Initialized
INFO - 2022-03-26 15:44:56 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-26 15:44:56 --> Calendar Class Initialized
INFO - 2022-03-26 15:44:56 --> Model "Login_model" initialized
INFO - 2022-03-26 15:44:56 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-26 15:44:56 --> Final output sent to browser
DEBUG - 2022-03-26 15:44:56 --> Total execution time: 0.0046
ERROR - 2022-03-26 15:44:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-26 15:44:56 --> Config Class Initialized
INFO - 2022-03-26 15:44:56 --> Hooks Class Initialized
DEBUG - 2022-03-26 15:44:56 --> UTF-8 Support Enabled
INFO - 2022-03-26 15:44:56 --> Utf8 Class Initialized
INFO - 2022-03-26 15:44:56 --> URI Class Initialized
INFO - 2022-03-26 15:44:56 --> Router Class Initialized
INFO - 2022-03-26 15:44:56 --> Output Class Initialized
INFO - 2022-03-26 15:44:56 --> Security Class Initialized
DEBUG - 2022-03-26 15:44:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-26 15:44:56 --> Input Class Initialized
INFO - 2022-03-26 15:44:56 --> Language Class Initialized
ERROR - 2022-03-26 15:44:56 --> 404 Page Not Found: Blog/wp-includes
ERROR - 2022-03-26 15:44:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-26 15:44:56 --> Config Class Initialized
INFO - 2022-03-26 15:44:56 --> Hooks Class Initialized
DEBUG - 2022-03-26 15:44:56 --> UTF-8 Support Enabled
INFO - 2022-03-26 15:44:56 --> Utf8 Class Initialized
INFO - 2022-03-26 15:44:56 --> URI Class Initialized
INFO - 2022-03-26 15:44:56 --> Router Class Initialized
INFO - 2022-03-26 15:44:56 --> Output Class Initialized
INFO - 2022-03-26 15:44:56 --> Security Class Initialized
DEBUG - 2022-03-26 15:44:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-26 15:44:56 --> Input Class Initialized
INFO - 2022-03-26 15:44:56 --> Language Class Initialized
ERROR - 2022-03-26 15:44:56 --> 404 Page Not Found: Web/wp-includes
ERROR - 2022-03-26 15:44:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-26 15:44:56 --> Config Class Initialized
INFO - 2022-03-26 15:44:56 --> Hooks Class Initialized
DEBUG - 2022-03-26 15:44:56 --> UTF-8 Support Enabled
INFO - 2022-03-26 15:44:56 --> Utf8 Class Initialized
INFO - 2022-03-26 15:44:56 --> URI Class Initialized
INFO - 2022-03-26 15:44:56 --> Router Class Initialized
INFO - 2022-03-26 15:44:56 --> Output Class Initialized
INFO - 2022-03-26 15:44:56 --> Security Class Initialized
DEBUG - 2022-03-26 15:44:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-26 15:44:56 --> Input Class Initialized
INFO - 2022-03-26 15:44:56 --> Language Class Initialized
ERROR - 2022-03-26 15:44:56 --> 404 Page Not Found: Wordpress/wp-includes
ERROR - 2022-03-26 15:44:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-26 15:44:56 --> Config Class Initialized
INFO - 2022-03-26 15:44:56 --> Hooks Class Initialized
DEBUG - 2022-03-26 15:44:56 --> UTF-8 Support Enabled
INFO - 2022-03-26 15:44:56 --> Utf8 Class Initialized
INFO - 2022-03-26 15:44:56 --> URI Class Initialized
INFO - 2022-03-26 15:44:56 --> Router Class Initialized
INFO - 2022-03-26 15:44:56 --> Output Class Initialized
INFO - 2022-03-26 15:44:56 --> Security Class Initialized
DEBUG - 2022-03-26 15:44:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-26 15:44:56 --> Input Class Initialized
INFO - 2022-03-26 15:44:56 --> Language Class Initialized
ERROR - 2022-03-26 15:44:56 --> 404 Page Not Found: Website/wp-includes
ERROR - 2022-03-26 15:44:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-26 15:44:56 --> Config Class Initialized
INFO - 2022-03-26 15:44:56 --> Hooks Class Initialized
DEBUG - 2022-03-26 15:44:56 --> UTF-8 Support Enabled
INFO - 2022-03-26 15:44:56 --> Utf8 Class Initialized
INFO - 2022-03-26 15:44:56 --> URI Class Initialized
INFO - 2022-03-26 15:44:56 --> Router Class Initialized
INFO - 2022-03-26 15:44:56 --> Output Class Initialized
INFO - 2022-03-26 15:44:56 --> Security Class Initialized
DEBUG - 2022-03-26 15:44:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-26 15:44:56 --> Input Class Initialized
INFO - 2022-03-26 15:44:56 --> Language Class Initialized
ERROR - 2022-03-26 15:44:56 --> 404 Page Not Found: Wp/wp-includes
ERROR - 2022-03-26 15:44:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-26 15:44:56 --> Config Class Initialized
INFO - 2022-03-26 15:44:56 --> Hooks Class Initialized
DEBUG - 2022-03-26 15:44:56 --> UTF-8 Support Enabled
INFO - 2022-03-26 15:44:56 --> Utf8 Class Initialized
INFO - 2022-03-26 15:44:56 --> URI Class Initialized
INFO - 2022-03-26 15:44:56 --> Router Class Initialized
INFO - 2022-03-26 15:44:56 --> Output Class Initialized
INFO - 2022-03-26 15:44:56 --> Security Class Initialized
DEBUG - 2022-03-26 15:44:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-26 15:44:56 --> Input Class Initialized
INFO - 2022-03-26 15:44:56 --> Language Class Initialized
ERROR - 2022-03-26 15:44:56 --> 404 Page Not Found: News/wp-includes
ERROR - 2022-03-26 15:44:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-26 15:44:56 --> Config Class Initialized
INFO - 2022-03-26 15:44:56 --> Hooks Class Initialized
DEBUG - 2022-03-26 15:44:56 --> UTF-8 Support Enabled
INFO - 2022-03-26 15:44:56 --> Utf8 Class Initialized
INFO - 2022-03-26 15:44:56 --> URI Class Initialized
INFO - 2022-03-26 15:44:56 --> Router Class Initialized
INFO - 2022-03-26 15:44:56 --> Output Class Initialized
INFO - 2022-03-26 15:44:56 --> Security Class Initialized
DEBUG - 2022-03-26 15:44:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-26 15:44:56 --> Input Class Initialized
INFO - 2022-03-26 15:44:56 --> Language Class Initialized
ERROR - 2022-03-26 15:44:56 --> 404 Page Not Found: 2020/wp-includes
ERROR - 2022-03-26 15:44:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-26 15:44:56 --> Config Class Initialized
INFO - 2022-03-26 15:44:56 --> Hooks Class Initialized
DEBUG - 2022-03-26 15:44:56 --> UTF-8 Support Enabled
INFO - 2022-03-26 15:44:56 --> Utf8 Class Initialized
INFO - 2022-03-26 15:44:56 --> URI Class Initialized
INFO - 2022-03-26 15:44:56 --> Router Class Initialized
INFO - 2022-03-26 15:44:56 --> Output Class Initialized
INFO - 2022-03-26 15:44:56 --> Security Class Initialized
DEBUG - 2022-03-26 15:44:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-26 15:44:56 --> Input Class Initialized
INFO - 2022-03-26 15:44:56 --> Language Class Initialized
ERROR - 2022-03-26 15:44:56 --> 404 Page Not Found: 2019/wp-includes
ERROR - 2022-03-26 15:44:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-26 15:44:56 --> Config Class Initialized
INFO - 2022-03-26 15:44:56 --> Hooks Class Initialized
DEBUG - 2022-03-26 15:44:56 --> UTF-8 Support Enabled
INFO - 2022-03-26 15:44:56 --> Utf8 Class Initialized
INFO - 2022-03-26 15:44:56 --> URI Class Initialized
INFO - 2022-03-26 15:44:56 --> Router Class Initialized
INFO - 2022-03-26 15:44:56 --> Output Class Initialized
INFO - 2022-03-26 15:44:56 --> Security Class Initialized
DEBUG - 2022-03-26 15:44:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-26 15:44:56 --> Input Class Initialized
INFO - 2022-03-26 15:44:56 --> Language Class Initialized
ERROR - 2022-03-26 15:44:56 --> 404 Page Not Found: Shop/wp-includes
ERROR - 2022-03-26 15:44:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-26 15:44:56 --> Config Class Initialized
INFO - 2022-03-26 15:44:56 --> Hooks Class Initialized
DEBUG - 2022-03-26 15:44:56 --> UTF-8 Support Enabled
INFO - 2022-03-26 15:44:56 --> Utf8 Class Initialized
INFO - 2022-03-26 15:44:56 --> URI Class Initialized
INFO - 2022-03-26 15:44:56 --> Router Class Initialized
INFO - 2022-03-26 15:44:56 --> Output Class Initialized
INFO - 2022-03-26 15:44:56 --> Security Class Initialized
DEBUG - 2022-03-26 15:44:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-26 15:44:56 --> Input Class Initialized
INFO - 2022-03-26 15:44:56 --> Language Class Initialized
ERROR - 2022-03-26 15:44:56 --> 404 Page Not Found: Wp1/wp-includes
ERROR - 2022-03-26 15:44:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-26 15:44:56 --> Config Class Initialized
INFO - 2022-03-26 15:44:56 --> Hooks Class Initialized
DEBUG - 2022-03-26 15:44:56 --> UTF-8 Support Enabled
INFO - 2022-03-26 15:44:56 --> Utf8 Class Initialized
INFO - 2022-03-26 15:44:56 --> URI Class Initialized
INFO - 2022-03-26 15:44:56 --> Router Class Initialized
INFO - 2022-03-26 15:44:56 --> Output Class Initialized
INFO - 2022-03-26 15:44:56 --> Security Class Initialized
DEBUG - 2022-03-26 15:44:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-26 15:44:56 --> Input Class Initialized
INFO - 2022-03-26 15:44:56 --> Language Class Initialized
ERROR - 2022-03-26 15:44:56 --> 404 Page Not Found: Test/wp-includes
ERROR - 2022-03-26 15:44:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-26 15:44:57 --> Config Class Initialized
INFO - 2022-03-26 15:44:57 --> Hooks Class Initialized
DEBUG - 2022-03-26 15:44:57 --> UTF-8 Support Enabled
INFO - 2022-03-26 15:44:57 --> Utf8 Class Initialized
INFO - 2022-03-26 15:44:57 --> URI Class Initialized
INFO - 2022-03-26 15:44:57 --> Router Class Initialized
INFO - 2022-03-26 15:44:57 --> Output Class Initialized
INFO - 2022-03-26 15:44:57 --> Security Class Initialized
DEBUG - 2022-03-26 15:44:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-26 15:44:57 --> Input Class Initialized
INFO - 2022-03-26 15:44:57 --> Language Class Initialized
ERROR - 2022-03-26 15:44:57 --> 404 Page Not Found: Wp2/wp-includes
ERROR - 2022-03-26 15:44:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-26 15:44:57 --> Config Class Initialized
INFO - 2022-03-26 15:44:57 --> Hooks Class Initialized
DEBUG - 2022-03-26 15:44:57 --> UTF-8 Support Enabled
INFO - 2022-03-26 15:44:57 --> Utf8 Class Initialized
INFO - 2022-03-26 15:44:57 --> URI Class Initialized
INFO - 2022-03-26 15:44:57 --> Router Class Initialized
INFO - 2022-03-26 15:44:57 --> Output Class Initialized
INFO - 2022-03-26 15:44:57 --> Security Class Initialized
DEBUG - 2022-03-26 15:44:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-26 15:44:57 --> Input Class Initialized
INFO - 2022-03-26 15:44:57 --> Language Class Initialized
ERROR - 2022-03-26 15:44:57 --> 404 Page Not Found: Site/wp-includes
ERROR - 2022-03-26 15:44:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-26 15:44:57 --> Config Class Initialized
INFO - 2022-03-26 15:44:57 --> Hooks Class Initialized
DEBUG - 2022-03-26 15:44:57 --> UTF-8 Support Enabled
INFO - 2022-03-26 15:44:57 --> Utf8 Class Initialized
INFO - 2022-03-26 15:44:57 --> URI Class Initialized
INFO - 2022-03-26 15:44:57 --> Router Class Initialized
INFO - 2022-03-26 15:44:57 --> Output Class Initialized
INFO - 2022-03-26 15:44:57 --> Security Class Initialized
DEBUG - 2022-03-26 15:44:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-26 15:44:57 --> Input Class Initialized
INFO - 2022-03-26 15:44:57 --> Language Class Initialized
ERROR - 2022-03-26 15:44:57 --> 404 Page Not Found: Cms/wp-includes
ERROR - 2022-03-26 15:44:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-26 15:44:57 --> Config Class Initialized
INFO - 2022-03-26 15:44:57 --> Hooks Class Initialized
DEBUG - 2022-03-26 15:44:57 --> UTF-8 Support Enabled
INFO - 2022-03-26 15:44:57 --> Utf8 Class Initialized
INFO - 2022-03-26 15:44:57 --> URI Class Initialized
INFO - 2022-03-26 15:44:57 --> Router Class Initialized
INFO - 2022-03-26 15:44:57 --> Output Class Initialized
INFO - 2022-03-26 15:44:57 --> Security Class Initialized
DEBUG - 2022-03-26 15:44:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-26 15:44:57 --> Input Class Initialized
INFO - 2022-03-26 15:44:57 --> Language Class Initialized
ERROR - 2022-03-26 15:44:57 --> 404 Page Not Found: Sito/wp-includes
ERROR - 2022-03-26 18:02:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-26 18:02:52 --> Config Class Initialized
INFO - 2022-03-26 18:02:52 --> Hooks Class Initialized
DEBUG - 2022-03-26 18:02:52 --> UTF-8 Support Enabled
INFO - 2022-03-26 18:02:52 --> Utf8 Class Initialized
INFO - 2022-03-26 18:02:52 --> URI Class Initialized
DEBUG - 2022-03-26 18:02:52 --> No URI present. Default controller set.
INFO - 2022-03-26 18:02:52 --> Router Class Initialized
INFO - 2022-03-26 18:02:52 --> Output Class Initialized
INFO - 2022-03-26 18:02:52 --> Security Class Initialized
DEBUG - 2022-03-26 18:02:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-26 18:02:52 --> Input Class Initialized
INFO - 2022-03-26 18:02:52 --> Language Class Initialized
INFO - 2022-03-26 18:02:52 --> Loader Class Initialized
INFO - 2022-03-26 18:02:52 --> Helper loaded: url_helper
INFO - 2022-03-26 18:02:52 --> Helper loaded: form_helper
INFO - 2022-03-26 18:02:52 --> Helper loaded: common_helper
INFO - 2022-03-26 18:02:52 --> Database Driver Class Initialized
DEBUG - 2022-03-26 18:02:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-26 18:02:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-26 18:02:52 --> Controller Class Initialized
INFO - 2022-03-26 18:02:52 --> Form Validation Class Initialized
DEBUG - 2022-03-26 18:02:52 --> Encrypt Class Initialized
DEBUG - 2022-03-26 18:02:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-26 18:02:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-26 18:02:52 --> Email Class Initialized
INFO - 2022-03-26 18:02:52 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-26 18:02:52 --> Calendar Class Initialized
INFO - 2022-03-26 18:02:52 --> Model "Login_model" initialized
INFO - 2022-03-26 18:02:52 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-26 18:02:52 --> Final output sent to browser
DEBUG - 2022-03-26 18:02:52 --> Total execution time: 0.0604
ERROR - 2022-03-26 20:37:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-26 20:37:48 --> Config Class Initialized
INFO - 2022-03-26 20:37:48 --> Hooks Class Initialized
DEBUG - 2022-03-26 20:37:48 --> UTF-8 Support Enabled
INFO - 2022-03-26 20:37:48 --> Utf8 Class Initialized
INFO - 2022-03-26 20:37:48 --> URI Class Initialized
DEBUG - 2022-03-26 20:37:48 --> No URI present. Default controller set.
INFO - 2022-03-26 20:37:48 --> Router Class Initialized
INFO - 2022-03-26 20:37:48 --> Output Class Initialized
INFO - 2022-03-26 20:37:48 --> Security Class Initialized
DEBUG - 2022-03-26 20:37:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-26 20:37:48 --> Input Class Initialized
INFO - 2022-03-26 20:37:48 --> Language Class Initialized
INFO - 2022-03-26 20:37:48 --> Loader Class Initialized
INFO - 2022-03-26 20:37:48 --> Helper loaded: url_helper
INFO - 2022-03-26 20:37:48 --> Helper loaded: form_helper
INFO - 2022-03-26 20:37:48 --> Helper loaded: common_helper
INFO - 2022-03-26 20:37:48 --> Database Driver Class Initialized
DEBUG - 2022-03-26 20:37:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-26 20:37:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-26 20:37:48 --> Controller Class Initialized
INFO - 2022-03-26 20:37:48 --> Form Validation Class Initialized
DEBUG - 2022-03-26 20:37:48 --> Encrypt Class Initialized
DEBUG - 2022-03-26 20:37:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-26 20:37:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-26 20:37:48 --> Email Class Initialized
INFO - 2022-03-26 20:37:48 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-26 20:37:48 --> Calendar Class Initialized
INFO - 2022-03-26 20:37:48 --> Model "Login_model" initialized
INFO - 2022-03-26 20:37:48 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-26 20:37:48 --> Final output sent to browser
DEBUG - 2022-03-26 20:37:48 --> Total execution time: 0.0736
