<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-07-08 16:23:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-08 16:23:15 --> Config Class Initialized
INFO - 2021-07-08 16:23:15 --> Hooks Class Initialized
DEBUG - 2021-07-08 16:23:15 --> UTF-8 Support Enabled
INFO - 2021-07-08 16:23:15 --> Utf8 Class Initialized
INFO - 2021-07-08 16:23:15 --> URI Class Initialized
DEBUG - 2021-07-08 16:23:15 --> No URI present. Default controller set.
INFO - 2021-07-08 16:23:15 --> Router Class Initialized
INFO - 2021-07-08 16:23:15 --> Output Class Initialized
INFO - 2021-07-08 16:23:15 --> Security Class Initialized
DEBUG - 2021-07-08 16:23:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 16:23:15 --> Input Class Initialized
INFO - 2021-07-08 16:23:15 --> Language Class Initialized
INFO - 2021-07-08 16:23:15 --> Loader Class Initialized
INFO - 2021-07-08 16:23:15 --> Helper loaded: url_helper
INFO - 2021-07-08 16:23:15 --> Helper loaded: form_helper
INFO - 2021-07-08 16:23:15 --> Helper loaded: common_helper
INFO - 2021-07-08 16:23:15 --> Database Driver Class Initialized
DEBUG - 2021-07-08 16:23:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-08 16:23:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-08 16:23:15 --> Controller Class Initialized
INFO - 2021-07-08 16:23:15 --> Form Validation Class Initialized
DEBUG - 2021-07-08 16:23:15 --> Encrypt Class Initialized
DEBUG - 2021-07-08 16:23:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-07-08 16:23:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-07-08 16:23:15 --> Email Class Initialized
INFO - 2021-07-08 16:23:15 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-07-08 16:23:15 --> Calendar Class Initialized
INFO - 2021-07-08 16:23:15 --> Model "Login_model" initialized
INFO - 2021-07-08 16:23:15 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-07-08 16:23:15 --> Final output sent to browser
DEBUG - 2021-07-08 16:23:15 --> Total execution time: 0.0366
