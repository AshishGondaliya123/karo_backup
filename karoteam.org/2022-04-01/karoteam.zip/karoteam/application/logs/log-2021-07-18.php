<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-07-18 06:37:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:37:06 --> Config Class Initialized
INFO - 2021-07-18 06:37:06 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:37:06 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:37:06 --> Utf8 Class Initialized
INFO - 2021-07-18 06:37:06 --> URI Class Initialized
INFO - 2021-07-18 06:37:06 --> Router Class Initialized
INFO - 2021-07-18 06:37:06 --> Output Class Initialized
INFO - 2021-07-18 06:37:06 --> Security Class Initialized
DEBUG - 2021-07-18 06:37:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:37:06 --> Input Class Initialized
INFO - 2021-07-18 06:37:06 --> Language Class Initialized
ERROR - 2021-07-18 06:37:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-18 06:37:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:37:06 --> Config Class Initialized
INFO - 2021-07-18 06:37:06 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:37:06 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:37:06 --> Utf8 Class Initialized
INFO - 2021-07-18 06:37:06 --> URI Class Initialized
DEBUG - 2021-07-18 06:37:06 --> No URI present. Default controller set.
INFO - 2021-07-18 06:37:06 --> Router Class Initialized
INFO - 2021-07-18 06:37:06 --> Output Class Initialized
INFO - 2021-07-18 06:37:06 --> Security Class Initialized
DEBUG - 2021-07-18 06:37:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:37:06 --> Input Class Initialized
INFO - 2021-07-18 06:37:06 --> Language Class Initialized
INFO - 2021-07-18 06:37:06 --> Loader Class Initialized
INFO - 2021-07-18 06:37:06 --> Helper loaded: url_helper
INFO - 2021-07-18 06:37:06 --> Helper loaded: form_helper
INFO - 2021-07-18 06:37:06 --> Helper loaded: common_helper
INFO - 2021-07-18 06:37:06 --> Database Driver Class Initialized
DEBUG - 2021-07-18 06:37:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-18 06:37:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-18 06:37:06 --> Controller Class Initialized
INFO - 2021-07-18 06:37:06 --> Form Validation Class Initialized
DEBUG - 2021-07-18 06:37:06 --> Encrypt Class Initialized
DEBUG - 2021-07-18 06:37:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-07-18 06:37:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-07-18 06:37:06 --> Email Class Initialized
INFO - 2021-07-18 06:37:06 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-07-18 06:37:06 --> Calendar Class Initialized
INFO - 2021-07-18 06:37:06 --> Model "Login_model" initialized
INFO - 2021-07-18 06:37:06 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-07-18 06:37:06 --> Final output sent to browser
DEBUG - 2021-07-18 06:37:06 --> Total execution time: 0.0341
ERROR - 2021-07-18 06:37:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:37:07 --> Config Class Initialized
INFO - 2021-07-18 06:37:07 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:37:07 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:37:07 --> Utf8 Class Initialized
INFO - 2021-07-18 06:37:07 --> URI Class Initialized
INFO - 2021-07-18 06:37:07 --> Router Class Initialized
INFO - 2021-07-18 06:37:07 --> Output Class Initialized
INFO - 2021-07-18 06:37:07 --> Security Class Initialized
DEBUG - 2021-07-18 06:37:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:37:07 --> Input Class Initialized
INFO - 2021-07-18 06:37:07 --> Language Class Initialized
ERROR - 2021-07-18 06:37:07 --> 404 Page Not Found: Test_404_page/index
ERROR - 2021-07-18 06:37:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:37:08 --> Config Class Initialized
INFO - 2021-07-18 06:37:08 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:37:08 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:37:08 --> Utf8 Class Initialized
INFO - 2021-07-18 06:37:08 --> URI Class Initialized
INFO - 2021-07-18 06:37:08 --> Router Class Initialized
INFO - 2021-07-18 06:37:08 --> Output Class Initialized
INFO - 2021-07-18 06:37:08 --> Security Class Initialized
DEBUG - 2021-07-18 06:37:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:37:08 --> Input Class Initialized
INFO - 2021-07-18 06:37:08 --> Language Class Initialized
ERROR - 2021-07-18 06:37:08 --> 404 Page Not Found: Issmall/index
ERROR - 2021-07-18 06:37:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:37:13 --> Config Class Initialized
INFO - 2021-07-18 06:37:13 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:37:13 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:37:13 --> Utf8 Class Initialized
INFO - 2021-07-18 06:37:13 --> URI Class Initialized
DEBUG - 2021-07-18 06:37:13 --> No URI present. Default controller set.
INFO - 2021-07-18 06:37:13 --> Router Class Initialized
INFO - 2021-07-18 06:37:13 --> Output Class Initialized
INFO - 2021-07-18 06:37:13 --> Security Class Initialized
DEBUG - 2021-07-18 06:37:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:37:13 --> Input Class Initialized
INFO - 2021-07-18 06:37:13 --> Language Class Initialized
INFO - 2021-07-18 06:37:13 --> Loader Class Initialized
INFO - 2021-07-18 06:37:13 --> Helper loaded: url_helper
INFO - 2021-07-18 06:37:13 --> Helper loaded: form_helper
INFO - 2021-07-18 06:37:13 --> Helper loaded: common_helper
INFO - 2021-07-18 06:37:13 --> Database Driver Class Initialized
DEBUG - 2021-07-18 06:37:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-18 06:37:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-18 06:37:13 --> Controller Class Initialized
INFO - 2021-07-18 06:37:13 --> Form Validation Class Initialized
DEBUG - 2021-07-18 06:37:13 --> Encrypt Class Initialized
DEBUG - 2021-07-18 06:37:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-07-18 06:37:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-07-18 06:37:13 --> Email Class Initialized
INFO - 2021-07-18 06:37:13 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-07-18 06:37:13 --> Calendar Class Initialized
INFO - 2021-07-18 06:37:13 --> Model "Login_model" initialized
INFO - 2021-07-18 06:37:13 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-07-18 06:37:13 --> Final output sent to browser
DEBUG - 2021-07-18 06:37:13 --> Total execution time: 0.0213
ERROR - 2021-07-18 06:37:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:37:14 --> Config Class Initialized
INFO - 2021-07-18 06:37:14 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:37:14 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:37:14 --> Utf8 Class Initialized
INFO - 2021-07-18 06:37:14 --> URI Class Initialized
INFO - 2021-07-18 06:37:14 --> Router Class Initialized
INFO - 2021-07-18 06:37:14 --> Output Class Initialized
INFO - 2021-07-18 06:37:14 --> Security Class Initialized
DEBUG - 2021-07-18 06:37:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:37:14 --> Input Class Initialized
INFO - 2021-07-18 06:37:14 --> Language Class Initialized
ERROR - 2021-07-18 06:37:14 --> 404 Page Not Found: Tpl/user
ERROR - 2021-07-18 06:37:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:37:14 --> Config Class Initialized
INFO - 2021-07-18 06:37:14 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:37:14 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:37:14 --> Utf8 Class Initialized
INFO - 2021-07-18 06:37:14 --> URI Class Initialized
INFO - 2021-07-18 06:37:14 --> Router Class Initialized
INFO - 2021-07-18 06:37:14 --> Output Class Initialized
INFO - 2021-07-18 06:37:14 --> Security Class Initialized
DEBUG - 2021-07-18 06:37:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:37:14 --> Input Class Initialized
INFO - 2021-07-18 06:37:14 --> Language Class Initialized
ERROR - 2021-07-18 06:37:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-18 06:37:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:37:14 --> Config Class Initialized
INFO - 2021-07-18 06:37:14 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:37:14 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:37:14 --> Utf8 Class Initialized
INFO - 2021-07-18 06:37:14 --> URI Class Initialized
INFO - 2021-07-18 06:37:14 --> Router Class Initialized
INFO - 2021-07-18 06:37:14 --> Output Class Initialized
INFO - 2021-07-18 06:37:14 --> Security Class Initialized
DEBUG - 2021-07-18 06:37:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:37:14 --> Input Class Initialized
INFO - 2021-07-18 06:37:14 --> Language Class Initialized
ERROR - 2021-07-18 06:37:14 --> 404 Page Not Found: Images/login
ERROR - 2021-07-18 06:37:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:37:15 --> Config Class Initialized
INFO - 2021-07-18 06:37:15 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:37:15 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:37:15 --> Utf8 Class Initialized
INFO - 2021-07-18 06:37:15 --> URI Class Initialized
INFO - 2021-07-18 06:37:15 --> Router Class Initialized
INFO - 2021-07-18 06:37:15 --> Output Class Initialized
INFO - 2021-07-18 06:37:15 --> Security Class Initialized
DEBUG - 2021-07-18 06:37:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:37:15 --> Input Class Initialized
INFO - 2021-07-18 06:37:15 --> Language Class Initialized
ERROR - 2021-07-18 06:37:15 --> 404 Page Not Found: Images/login
ERROR - 2021-07-18 06:37:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:37:15 --> Config Class Initialized
INFO - 2021-07-18 06:37:15 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:37:15 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:37:15 --> Utf8 Class Initialized
INFO - 2021-07-18 06:37:15 --> URI Class Initialized
INFO - 2021-07-18 06:37:15 --> Router Class Initialized
INFO - 2021-07-18 06:37:15 --> Output Class Initialized
INFO - 2021-07-18 06:37:15 --> Security Class Initialized
DEBUG - 2021-07-18 06:37:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:37:15 --> Input Class Initialized
INFO - 2021-07-18 06:37:15 --> Language Class Initialized
ERROR - 2021-07-18 06:37:15 --> 404 Page Not Found: Tpl/login
ERROR - 2021-07-18 06:37:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:37:15 --> Config Class Initialized
INFO - 2021-07-18 06:37:15 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:37:15 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:37:15 --> Utf8 Class Initialized
INFO - 2021-07-18 06:37:15 --> URI Class Initialized
INFO - 2021-07-18 06:37:15 --> Router Class Initialized
INFO - 2021-07-18 06:37:15 --> Output Class Initialized
INFO - 2021-07-18 06:37:15 --> Security Class Initialized
DEBUG - 2021-07-18 06:37:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:37:15 --> Input Class Initialized
INFO - 2021-07-18 06:37:15 --> Language Class Initialized
ERROR - 2021-07-18 06:37:15 --> 404 Page Not Found: Images/login
ERROR - 2021-07-18 06:37:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:37:16 --> Config Class Initialized
INFO - 2021-07-18 06:37:16 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:37:16 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:37:16 --> Utf8 Class Initialized
INFO - 2021-07-18 06:37:16 --> URI Class Initialized
INFO - 2021-07-18 06:37:16 --> Router Class Initialized
INFO - 2021-07-18 06:37:16 --> Output Class Initialized
INFO - 2021-07-18 06:37:16 --> Security Class Initialized
DEBUG - 2021-07-18 06:37:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:37:16 --> Input Class Initialized
INFO - 2021-07-18 06:37:16 --> Language Class Initialized
ERROR - 2021-07-18 06:37:16 --> 404 Page Not Found: Docscss/index
ERROR - 2021-07-18 06:37:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:37:16 --> Config Class Initialized
INFO - 2021-07-18 06:37:16 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:37:16 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:37:16 --> Utf8 Class Initialized
INFO - 2021-07-18 06:37:16 --> URI Class Initialized
INFO - 2021-07-18 06:37:16 --> Router Class Initialized
INFO - 2021-07-18 06:37:16 --> Output Class Initialized
INFO - 2021-07-18 06:37:16 --> Security Class Initialized
DEBUG - 2021-07-18 06:37:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:37:16 --> Input Class Initialized
INFO - 2021-07-18 06:37:16 --> Language Class Initialized
ERROR - 2021-07-18 06:37:16 --> 404 Page Not Found: Phpmyadmin/themes
ERROR - 2021-07-18 06:37:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:37:17 --> Config Class Initialized
INFO - 2021-07-18 06:37:17 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:37:17 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:37:17 --> Utf8 Class Initialized
INFO - 2021-07-18 06:37:17 --> URI Class Initialized
INFO - 2021-07-18 06:37:17 --> Router Class Initialized
INFO - 2021-07-18 06:37:17 --> Output Class Initialized
INFO - 2021-07-18 06:37:17 --> Security Class Initialized
DEBUG - 2021-07-18 06:37:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:37:17 --> Input Class Initialized
INFO - 2021-07-18 06:37:17 --> Language Class Initialized
ERROR - 2021-07-18 06:37:17 --> 404 Page Not Found: Phpmyadmin/favicon.ico
ERROR - 2021-07-18 06:37:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:37:17 --> Config Class Initialized
INFO - 2021-07-18 06:37:17 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:37:17 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:37:17 --> Utf8 Class Initialized
INFO - 2021-07-18 06:37:17 --> URI Class Initialized
INFO - 2021-07-18 06:37:17 --> Router Class Initialized
INFO - 2021-07-18 06:37:17 --> Output Class Initialized
INFO - 2021-07-18 06:37:17 --> Security Class Initialized
DEBUG - 2021-07-18 06:37:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:37:17 --> Input Class Initialized
INFO - 2021-07-18 06:37:17 --> Language Class Initialized
ERROR - 2021-07-18 06:37:17 --> 404 Page Not Found: Phpmyadmin/docs.css
ERROR - 2021-07-18 06:37:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:37:17 --> Config Class Initialized
INFO - 2021-07-18 06:37:17 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:37:17 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:37:17 --> Utf8 Class Initialized
INFO - 2021-07-18 06:37:17 --> URI Class Initialized
INFO - 2021-07-18 06:37:17 --> Router Class Initialized
INFO - 2021-07-18 06:37:17 --> Output Class Initialized
INFO - 2021-07-18 06:37:17 --> Security Class Initialized
DEBUG - 2021-07-18 06:37:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:37:17 --> Input Class Initialized
INFO - 2021-07-18 06:37:17 --> Language Class Initialized
ERROR - 2021-07-18 06:37:17 --> 404 Page Not Found: Ckeditor/ckeditor.js
ERROR - 2021-07-18 06:37:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:37:18 --> Config Class Initialized
INFO - 2021-07-18 06:37:18 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:37:18 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:37:18 --> Utf8 Class Initialized
INFO - 2021-07-18 06:37:18 --> URI Class Initialized
INFO - 2021-07-18 06:37:18 --> Router Class Initialized
INFO - 2021-07-18 06:37:18 --> Output Class Initialized
INFO - 2021-07-18 06:37:18 --> Security Class Initialized
DEBUG - 2021-07-18 06:37:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:37:18 --> Input Class Initialized
INFO - 2021-07-18 06:37:18 --> Language Class Initialized
ERROR - 2021-07-18 06:37:18 --> 404 Page Not Found: Docs/index
ERROR - 2021-07-18 06:37:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:37:18 --> Config Class Initialized
INFO - 2021-07-18 06:37:18 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:37:18 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:37:18 --> Utf8 Class Initialized
INFO - 2021-07-18 06:37:18 --> URI Class Initialized
INFO - 2021-07-18 06:37:18 --> Router Class Initialized
INFO - 2021-07-18 06:37:18 --> Output Class Initialized
INFO - 2021-07-18 06:37:18 --> Security Class Initialized
DEBUG - 2021-07-18 06:37:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:37:18 --> Input Class Initialized
INFO - 2021-07-18 06:37:18 --> Language Class Initialized
ERROR - 2021-07-18 06:37:18 --> 404 Page Not Found: Fckeditor/fckconfig.js
ERROR - 2021-07-18 06:37:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:37:19 --> Config Class Initialized
INFO - 2021-07-18 06:37:19 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:37:19 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:37:19 --> Utf8 Class Initialized
INFO - 2021-07-18 06:37:19 --> URI Class Initialized
INFO - 2021-07-18 06:37:19 --> Router Class Initialized
INFO - 2021-07-18 06:37:19 --> Output Class Initialized
INFO - 2021-07-18 06:37:19 --> Security Class Initialized
DEBUG - 2021-07-18 06:37:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:37:19 --> Input Class Initialized
INFO - 2021-07-18 06:37:19 --> Language Class Initialized
ERROR - 2021-07-18 06:37:19 --> 404 Page Not Found: Fckeditor/editor
ERROR - 2021-07-18 06:37:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:37:19 --> Config Class Initialized
INFO - 2021-07-18 06:37:19 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:37:19 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:37:19 --> Utf8 Class Initialized
INFO - 2021-07-18 06:37:19 --> URI Class Initialized
INFO - 2021-07-18 06:37:19 --> Router Class Initialized
INFO - 2021-07-18 06:37:19 --> Output Class Initialized
INFO - 2021-07-18 06:37:19 --> Security Class Initialized
DEBUG - 2021-07-18 06:37:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:37:19 --> Input Class Initialized
INFO - 2021-07-18 06:37:19 --> Language Class Initialized
ERROR - 2021-07-18 06:37:19 --> 404 Page Not Found: Fckeditor/license.txt
ERROR - 2021-07-18 06:37:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:37:19 --> Config Class Initialized
INFO - 2021-07-18 06:37:19 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:37:19 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:37:19 --> Utf8 Class Initialized
INFO - 2021-07-18 06:37:19 --> URI Class Initialized
INFO - 2021-07-18 06:37:19 --> Router Class Initialized
INFO - 2021-07-18 06:37:19 --> Output Class Initialized
INFO - 2021-07-18 06:37:19 --> Security Class Initialized
DEBUG - 2021-07-18 06:37:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:37:19 --> Input Class Initialized
INFO - 2021-07-18 06:37:19 --> Language Class Initialized
ERROR - 2021-07-18 06:37:19 --> 404 Page Not Found: Fckeditor/editor
ERROR - 2021-07-18 06:37:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:37:20 --> Config Class Initialized
INFO - 2021-07-18 06:37:20 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:37:20 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:37:20 --> Utf8 Class Initialized
INFO - 2021-07-18 06:37:20 --> URI Class Initialized
INFO - 2021-07-18 06:37:20 --> Router Class Initialized
INFO - 2021-07-18 06:37:20 --> Output Class Initialized
INFO - 2021-07-18 06:37:20 --> Security Class Initialized
DEBUG - 2021-07-18 06:37:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:37:20 --> Input Class Initialized
INFO - 2021-07-18 06:37:20 --> Language Class Initialized
ERROR - 2021-07-18 06:37:20 --> 404 Page Not Found: Fckeditor/fckeditor.js
ERROR - 2021-07-18 06:37:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:37:20 --> Config Class Initialized
INFO - 2021-07-18 06:37:20 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:37:20 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:37:20 --> Utf8 Class Initialized
INFO - 2021-07-18 06:37:20 --> URI Class Initialized
INFO - 2021-07-18 06:37:20 --> Router Class Initialized
INFO - 2021-07-18 06:37:20 --> Output Class Initialized
INFO - 2021-07-18 06:37:20 --> Security Class Initialized
DEBUG - 2021-07-18 06:37:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:37:20 --> Input Class Initialized
INFO - 2021-07-18 06:37:20 --> Language Class Initialized
ERROR - 2021-07-18 06:37:20 --> 404 Page Not Found: FCK/editor
ERROR - 2021-07-18 06:37:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:37:21 --> Config Class Initialized
INFO - 2021-07-18 06:37:21 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:37:21 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:37:21 --> Utf8 Class Initialized
INFO - 2021-07-18 06:37:21 --> URI Class Initialized
INFO - 2021-07-18 06:37:21 --> Router Class Initialized
INFO - 2021-07-18 06:37:21 --> Output Class Initialized
INFO - 2021-07-18 06:37:21 --> Security Class Initialized
DEBUG - 2021-07-18 06:37:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:37:21 --> Input Class Initialized
INFO - 2021-07-18 06:37:21 --> Language Class Initialized
ERROR - 2021-07-18 06:37:21 --> 404 Page Not Found: FCK/fckeditor.js
ERROR - 2021-07-18 06:37:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:37:21 --> Config Class Initialized
INFO - 2021-07-18 06:37:21 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:37:21 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:37:21 --> Utf8 Class Initialized
INFO - 2021-07-18 06:37:21 --> URI Class Initialized
INFO - 2021-07-18 06:37:21 --> Router Class Initialized
INFO - 2021-07-18 06:37:21 --> Output Class Initialized
INFO - 2021-07-18 06:37:21 --> Security Class Initialized
DEBUG - 2021-07-18 06:37:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:37:21 --> Input Class Initialized
INFO - 2021-07-18 06:37:21 --> Language Class Initialized
ERROR - 2021-07-18 06:37:21 --> 404 Page Not Found: Fckeditorjs/index
ERROR - 2021-07-18 06:37:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:37:21 --> Config Class Initialized
INFO - 2021-07-18 06:37:21 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:37:21 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:37:21 --> Utf8 Class Initialized
INFO - 2021-07-18 06:37:21 --> URI Class Initialized
INFO - 2021-07-18 06:37:21 --> Router Class Initialized
INFO - 2021-07-18 06:37:21 --> Output Class Initialized
INFO - 2021-07-18 06:37:21 --> Security Class Initialized
DEBUG - 2021-07-18 06:37:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:37:21 --> Input Class Initialized
INFO - 2021-07-18 06:37:21 --> Language Class Initialized
ERROR - 2021-07-18 06:37:21 --> 404 Page Not Found: Editor/fckeditor.js
ERROR - 2021-07-18 06:37:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:37:22 --> Config Class Initialized
INFO - 2021-07-18 06:37:22 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:37:22 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:37:22 --> Utf8 Class Initialized
INFO - 2021-07-18 06:37:22 --> URI Class Initialized
INFO - 2021-07-18 06:37:22 --> Router Class Initialized
INFO - 2021-07-18 06:37:22 --> Output Class Initialized
INFO - 2021-07-18 06:37:22 --> Security Class Initialized
DEBUG - 2021-07-18 06:37:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:37:22 --> Input Class Initialized
INFO - 2021-07-18 06:37:22 --> Language Class Initialized
ERROR - 2021-07-18 06:37:22 --> 404 Page Not Found: Editor/js
ERROR - 2021-07-18 06:37:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:37:22 --> Config Class Initialized
INFO - 2021-07-18 06:37:22 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:37:22 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:37:22 --> Utf8 Class Initialized
INFO - 2021-07-18 06:37:22 --> URI Class Initialized
INFO - 2021-07-18 06:37:22 --> Router Class Initialized
INFO - 2021-07-18 06:37:22 --> Output Class Initialized
INFO - 2021-07-18 06:37:22 --> Security Class Initialized
DEBUG - 2021-07-18 06:37:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:37:22 --> Input Class Initialized
INFO - 2021-07-18 06:37:22 --> Language Class Initialized
ERROR - 2021-07-18 06:37:22 --> 404 Page Not Found: New_gb/help
ERROR - 2021-07-18 06:37:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:37:23 --> Config Class Initialized
INFO - 2021-07-18 06:37:23 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:37:23 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:37:23 --> Utf8 Class Initialized
INFO - 2021-07-18 06:37:23 --> URI Class Initialized
INFO - 2021-07-18 06:37:23 --> Router Class Initialized
INFO - 2021-07-18 06:37:23 --> Output Class Initialized
INFO - 2021-07-18 06:37:23 --> Security Class Initialized
DEBUG - 2021-07-18 06:37:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:37:23 --> Input Class Initialized
INFO - 2021-07-18 06:37:23 --> Language Class Initialized
ERROR - 2021-07-18 06:37:23 --> 404 Page Not Found: Web2/login_template
ERROR - 2021-07-18 06:37:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:37:23 --> Config Class Initialized
INFO - 2021-07-18 06:37:23 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:37:23 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:37:23 --> Utf8 Class Initialized
INFO - 2021-07-18 06:37:23 --> URI Class Initialized
INFO - 2021-07-18 06:37:23 --> Router Class Initialized
INFO - 2021-07-18 06:37:23 --> Output Class Initialized
INFO - 2021-07-18 06:37:23 --> Security Class Initialized
DEBUG - 2021-07-18 06:37:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:37:23 --> Input Class Initialized
INFO - 2021-07-18 06:37:23 --> Language Class Initialized
ERROR - 2021-07-18 06:37:23 --> 404 Page Not Found: Ckfinder/ckfinder.html
ERROR - 2021-07-18 06:37:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:37:23 --> Config Class Initialized
INFO - 2021-07-18 06:37:23 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:37:23 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:37:23 --> Utf8 Class Initialized
INFO - 2021-07-18 06:37:23 --> URI Class Initialized
INFO - 2021-07-18 06:37:23 --> Router Class Initialized
INFO - 2021-07-18 06:37:23 --> Output Class Initialized
INFO - 2021-07-18 06:37:23 --> Security Class Initialized
DEBUG - 2021-07-18 06:37:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:37:23 --> Input Class Initialized
INFO - 2021-07-18 06:37:23 --> Language Class Initialized
ERROR - 2021-07-18 06:37:23 --> 404 Page Not Found: Ckfinder/install.txt
ERROR - 2021-07-18 06:37:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:37:24 --> Config Class Initialized
INFO - 2021-07-18 06:37:24 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:37:24 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:37:24 --> Utf8 Class Initialized
INFO - 2021-07-18 06:37:24 --> URI Class Initialized
INFO - 2021-07-18 06:37:24 --> Router Class Initialized
INFO - 2021-07-18 06:37:24 --> Output Class Initialized
INFO - 2021-07-18 06:37:24 --> Security Class Initialized
DEBUG - 2021-07-18 06:37:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:37:24 --> Input Class Initialized
INFO - 2021-07-18 06:37:24 --> Language Class Initialized
ERROR - 2021-07-18 06:37:24 --> 404 Page Not Found: Ckeditor/ckfinder
ERROR - 2021-07-18 06:37:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:37:24 --> Config Class Initialized
INFO - 2021-07-18 06:37:24 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:37:24 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:37:24 --> Utf8 Class Initialized
INFO - 2021-07-18 06:37:24 --> URI Class Initialized
INFO - 2021-07-18 06:37:24 --> Router Class Initialized
INFO - 2021-07-18 06:37:24 --> Output Class Initialized
INFO - 2021-07-18 06:37:24 --> Security Class Initialized
DEBUG - 2021-07-18 06:37:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:37:24 --> Input Class Initialized
INFO - 2021-07-18 06:37:24 --> Language Class Initialized
ERROR - 2021-07-18 06:37:24 --> 404 Page Not Found: Ckeditor/ckfinder
ERROR - 2021-07-18 06:37:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:37:25 --> Config Class Initialized
INFO - 2021-07-18 06:37:25 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:37:25 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:37:25 --> Utf8 Class Initialized
INFO - 2021-07-18 06:37:25 --> URI Class Initialized
INFO - 2021-07-18 06:37:25 --> Router Class Initialized
INFO - 2021-07-18 06:37:25 --> Output Class Initialized
INFO - 2021-07-18 06:37:25 --> Security Class Initialized
DEBUG - 2021-07-18 06:37:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:37:25 --> Input Class Initialized
INFO - 2021-07-18 06:37:25 --> Language Class Initialized
ERROR - 2021-07-18 06:37:25 --> 404 Page Not Found: E/master
ERROR - 2021-07-18 06:37:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:37:25 --> Config Class Initialized
INFO - 2021-07-18 06:37:25 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:37:25 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:37:25 --> Utf8 Class Initialized
INFO - 2021-07-18 06:37:25 --> URI Class Initialized
INFO - 2021-07-18 06:37:25 --> Router Class Initialized
INFO - 2021-07-18 06:37:25 --> Output Class Initialized
INFO - 2021-07-18 06:37:25 --> Security Class Initialized
DEBUG - 2021-07-18 06:37:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:37:25 --> Input Class Initialized
INFO - 2021-07-18 06:37:25 --> Language Class Initialized
ERROR - 2021-07-18 06:37:25 --> 404 Page Not Found: Master/login.aspx
ERROR - 2021-07-18 06:37:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:37:26 --> Config Class Initialized
INFO - 2021-07-18 06:37:26 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:37:26 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:37:26 --> Utf8 Class Initialized
INFO - 2021-07-18 06:37:26 --> URI Class Initialized
INFO - 2021-07-18 06:37:26 --> Router Class Initialized
INFO - 2021-07-18 06:37:26 --> Output Class Initialized
INFO - 2021-07-18 06:37:26 --> Security Class Initialized
DEBUG - 2021-07-18 06:37:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:37:26 --> Input Class Initialized
INFO - 2021-07-18 06:37:26 --> Language Class Initialized
ERROR - 2021-07-18 06:37:26 --> 404 Page Not Found: Common/help
ERROR - 2021-07-18 06:37:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:37:26 --> Config Class Initialized
INFO - 2021-07-18 06:37:26 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:37:26 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:37:26 --> Utf8 Class Initialized
INFO - 2021-07-18 06:37:26 --> URI Class Initialized
INFO - 2021-07-18 06:37:26 --> Router Class Initialized
INFO - 2021-07-18 06:37:26 --> Output Class Initialized
INFO - 2021-07-18 06:37:26 --> Security Class Initialized
DEBUG - 2021-07-18 06:37:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:37:26 --> Input Class Initialized
INFO - 2021-07-18 06:37:26 --> Language Class Initialized
ERROR - 2021-07-18 06:37:26 --> 404 Page Not Found: Common/help
ERROR - 2021-07-18 06:37:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:37:27 --> Config Class Initialized
INFO - 2021-07-18 06:37:27 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:37:27 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:37:27 --> Utf8 Class Initialized
INFO - 2021-07-18 06:37:27 --> URI Class Initialized
INFO - 2021-07-18 06:37:27 --> Router Class Initialized
INFO - 2021-07-18 06:37:27 --> Output Class Initialized
INFO - 2021-07-18 06:37:27 --> Security Class Initialized
DEBUG - 2021-07-18 06:37:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:37:27 --> Input Class Initialized
INFO - 2021-07-18 06:37:27 --> Language Class Initialized
ERROR - 2021-07-18 06:37:27 --> 404 Page Not Found: Coremail/common
ERROR - 2021-07-18 06:37:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:37:27 --> Config Class Initialized
INFO - 2021-07-18 06:37:27 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:37:27 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:37:27 --> Utf8 Class Initialized
INFO - 2021-07-18 06:37:27 --> URI Class Initialized
INFO - 2021-07-18 06:37:27 --> Router Class Initialized
INFO - 2021-07-18 06:37:27 --> Output Class Initialized
INFO - 2021-07-18 06:37:27 --> Security Class Initialized
DEBUG - 2021-07-18 06:37:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:37:27 --> Input Class Initialized
INFO - 2021-07-18 06:37:27 --> Language Class Initialized
ERROR - 2021-07-18 06:37:27 --> 404 Page Not Found: Coremail/common
ERROR - 2021-07-18 06:37:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:37:28 --> Config Class Initialized
INFO - 2021-07-18 06:37:28 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:37:28 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:37:28 --> Utf8 Class Initialized
INFO - 2021-07-18 06:37:28 --> URI Class Initialized
INFO - 2021-07-18 06:37:28 --> Router Class Initialized
INFO - 2021-07-18 06:37:28 --> Output Class Initialized
INFO - 2021-07-18 06:37:28 --> Security Class Initialized
DEBUG - 2021-07-18 06:37:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:37:28 --> Input Class Initialized
INFO - 2021-07-18 06:37:28 --> Language Class Initialized
ERROR - 2021-07-18 06:37:28 --> 404 Page Not Found: Images/login
ERROR - 2021-07-18 06:37:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:37:28 --> Config Class Initialized
INFO - 2021-07-18 06:37:28 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:37:28 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:37:28 --> Utf8 Class Initialized
INFO - 2021-07-18 06:37:28 --> URI Class Initialized
INFO - 2021-07-18 06:37:28 --> Router Class Initialized
INFO - 2021-07-18 06:37:28 --> Output Class Initialized
INFO - 2021-07-18 06:37:28 --> Security Class Initialized
DEBUG - 2021-07-18 06:37:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:37:28 --> Input Class Initialized
INFO - 2021-07-18 06:37:28 --> Language Class Initialized
ERROR - 2021-07-18 06:37:28 --> 404 Page Not Found: Images/login
ERROR - 2021-07-18 06:37:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:37:29 --> Config Class Initialized
INFO - 2021-07-18 06:37:29 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:37:29 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:37:29 --> Utf8 Class Initialized
INFO - 2021-07-18 06:37:29 --> URI Class Initialized
INFO - 2021-07-18 06:37:29 --> Router Class Initialized
INFO - 2021-07-18 06:37:29 --> Output Class Initialized
INFO - 2021-07-18 06:37:29 --> Security Class Initialized
DEBUG - 2021-07-18 06:37:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:37:29 --> Input Class Initialized
INFO - 2021-07-18 06:37:29 --> Language Class Initialized
ERROR - 2021-07-18 06:37:29 --> 404 Page Not Found: Images/login
ERROR - 2021-07-18 06:37:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:37:29 --> Config Class Initialized
INFO - 2021-07-18 06:37:29 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:37:29 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:37:29 --> Utf8 Class Initialized
INFO - 2021-07-18 06:37:29 --> URI Class Initialized
INFO - 2021-07-18 06:37:29 --> Router Class Initialized
INFO - 2021-07-18 06:37:29 --> Output Class Initialized
INFO - 2021-07-18 06:37:29 --> Security Class Initialized
DEBUG - 2021-07-18 06:37:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:37:29 --> Input Class Initialized
INFO - 2021-07-18 06:37:29 --> Language Class Initialized
ERROR - 2021-07-18 06:37:29 --> 404 Page Not Found: Next/img
ERROR - 2021-07-18 06:37:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:37:30 --> Config Class Initialized
INFO - 2021-07-18 06:37:30 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:37:30 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:37:30 --> Utf8 Class Initialized
INFO - 2021-07-18 06:37:30 --> URI Class Initialized
INFO - 2021-07-18 06:37:30 --> Router Class Initialized
INFO - 2021-07-18 06:37:30 --> Output Class Initialized
INFO - 2021-07-18 06:37:30 --> Security Class Initialized
DEBUG - 2021-07-18 06:37:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:37:30 --> Input Class Initialized
INFO - 2021-07-18 06:37:30 --> Language Class Initialized
ERROR - 2021-07-18 06:37:30 --> 404 Page Not Found: Maintloginjsp/index
ERROR - 2021-07-18 06:37:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:37:30 --> Config Class Initialized
INFO - 2021-07-18 06:37:30 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:37:30 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:37:30 --> Utf8 Class Initialized
INFO - 2021-07-18 06:37:30 --> URI Class Initialized
INFO - 2021-07-18 06:37:30 --> Router Class Initialized
INFO - 2021-07-18 06:37:30 --> Output Class Initialized
INFO - 2021-07-18 06:37:30 --> Security Class Initialized
DEBUG - 2021-07-18 06:37:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:37:30 --> Input Class Initialized
INFO - 2021-07-18 06:37:30 --> Language Class Initialized
ERROR - 2021-07-18 06:37:30 --> 404 Page Not Found: Auth/login
ERROR - 2021-07-18 06:37:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:37:31 --> Config Class Initialized
INFO - 2021-07-18 06:37:31 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:37:31 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:37:31 --> Utf8 Class Initialized
INFO - 2021-07-18 06:37:31 --> URI Class Initialized
INFO - 2021-07-18 06:37:31 --> Router Class Initialized
INFO - 2021-07-18 06:37:31 --> Output Class Initialized
INFO - 2021-07-18 06:37:31 --> Security Class Initialized
DEBUG - 2021-07-18 06:37:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:37:31 --> Input Class Initialized
INFO - 2021-07-18 06:37:31 --> Language Class Initialized
ERROR - 2021-07-18 06:37:31 --> 404 Page Not Found: Admin/index
ERROR - 2021-07-18 06:37:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:37:31 --> Config Class Initialized
INFO - 2021-07-18 06:37:31 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:37:31 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:37:31 --> Utf8 Class Initialized
INFO - 2021-07-18 06:37:31 --> URI Class Initialized
INFO - 2021-07-18 06:37:31 --> Router Class Initialized
INFO - 2021-07-18 06:37:31 --> Output Class Initialized
INFO - 2021-07-18 06:37:31 --> Security Class Initialized
DEBUG - 2021-07-18 06:37:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:37:31 --> Input Class Initialized
INFO - 2021-07-18 06:37:31 --> Language Class Initialized
ERROR - 2021-07-18 06:37:31 --> 404 Page Not Found: Listphp/index
ERROR - 2021-07-18 06:37:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:37:31 --> Config Class Initialized
INFO - 2021-07-18 06:37:31 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:37:31 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:37:31 --> Utf8 Class Initialized
INFO - 2021-07-18 06:37:31 --> URI Class Initialized
INFO - 2021-07-18 06:37:31 --> Router Class Initialized
INFO - 2021-07-18 06:37:31 --> Output Class Initialized
INFO - 2021-07-18 06:37:31 --> Security Class Initialized
DEBUG - 2021-07-18 06:37:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:37:31 --> Input Class Initialized
INFO - 2021-07-18 06:37:31 --> Language Class Initialized
ERROR - 2021-07-18 06:37:31 --> 404 Page Not Found: Admin/template
ERROR - 2021-07-18 06:37:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:37:32 --> Config Class Initialized
INFO - 2021-07-18 06:37:32 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:37:32 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:37:32 --> Utf8 Class Initialized
INFO - 2021-07-18 06:37:32 --> URI Class Initialized
INFO - 2021-07-18 06:37:32 --> Router Class Initialized
INFO - 2021-07-18 06:37:32 --> Output Class Initialized
INFO - 2021-07-18 06:37:32 --> Security Class Initialized
DEBUG - 2021-07-18 06:37:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:37:32 --> Input Class Initialized
INFO - 2021-07-18 06:37:32 --> Language Class Initialized
ERROR - 2021-07-18 06:37:32 --> 404 Page Not Found: Licensetxt/index
ERROR - 2021-07-18 06:37:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:37:33 --> Config Class Initialized
INFO - 2021-07-18 06:37:33 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:37:33 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:37:33 --> Utf8 Class Initialized
INFO - 2021-07-18 06:37:33 --> URI Class Initialized
INFO - 2021-07-18 06:37:33 --> Router Class Initialized
INFO - 2021-07-18 06:37:33 --> Output Class Initialized
INFO - 2021-07-18 06:37:33 --> Security Class Initialized
DEBUG - 2021-07-18 06:37:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:37:33 --> Input Class Initialized
INFO - 2021-07-18 06:37:33 --> Language Class Initialized
ERROR - 2021-07-18 06:37:33 --> 404 Page Not Found: Dialog/dialog.js
ERROR - 2021-07-18 06:37:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:37:36 --> Config Class Initialized
INFO - 2021-07-18 06:37:36 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:37:36 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:37:36 --> Utf8 Class Initialized
INFO - 2021-07-18 06:37:36 --> URI Class Initialized
INFO - 2021-07-18 06:37:36 --> Router Class Initialized
INFO - 2021-07-18 06:37:36 --> Output Class Initialized
INFO - 2021-07-18 06:37:36 --> Security Class Initialized
DEBUG - 2021-07-18 06:37:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:37:36 --> Input Class Initialized
INFO - 2021-07-18 06:37:36 --> Language Class Initialized
ERROR - 2021-07-18 06:37:36 --> 404 Page Not Found: Editorjs/index
ERROR - 2021-07-18 06:37:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:37:36 --> Config Class Initialized
INFO - 2021-07-18 06:37:36 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:37:36 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:37:36 --> Utf8 Class Initialized
INFO - 2021-07-18 06:37:36 --> URI Class Initialized
INFO - 2021-07-18 06:37:36 --> Router Class Initialized
INFO - 2021-07-18 06:37:36 --> Output Class Initialized
INFO - 2021-07-18 06:37:36 --> Security Class Initialized
DEBUG - 2021-07-18 06:37:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:37:36 --> Input Class Initialized
INFO - 2021-07-18 06:37:36 --> Language Class Initialized
ERROR - 2021-07-18 06:37:36 --> 404 Page Not Found: Images/2_11.gif
ERROR - 2021-07-18 06:37:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:37:37 --> Config Class Initialized
INFO - 2021-07-18 06:37:37 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:37:37 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:37:37 --> Utf8 Class Initialized
INFO - 2021-07-18 06:37:37 --> URI Class Initialized
INFO - 2021-07-18 06:37:37 --> Router Class Initialized
INFO - 2021-07-18 06:37:37 --> Output Class Initialized
INFO - 2021-07-18 06:37:37 --> Security Class Initialized
DEBUG - 2021-07-18 06:37:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:37:37 --> Input Class Initialized
INFO - 2021-07-18 06:37:37 --> Language Class Initialized
ERROR - 2021-07-18 06:37:37 --> 404 Page Not Found: Js/buttons.js
ERROR - 2021-07-18 06:37:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:37:37 --> Config Class Initialized
INFO - 2021-07-18 06:37:37 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:37:37 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:37:37 --> Utf8 Class Initialized
INFO - 2021-07-18 06:37:37 --> URI Class Initialized
INFO - 2021-07-18 06:37:37 --> Router Class Initialized
INFO - 2021-07-18 06:37:37 --> Output Class Initialized
INFO - 2021-07-18 06:37:37 --> Security Class Initialized
DEBUG - 2021-07-18 06:37:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:37:37 --> Input Class Initialized
INFO - 2021-07-18 06:37:37 --> Language Class Initialized
ERROR - 2021-07-18 06:37:37 --> 404 Page Not Found: Images/hwem.css
ERROR - 2021-07-18 06:37:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:37:38 --> Config Class Initialized
INFO - 2021-07-18 06:37:38 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:37:38 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:37:38 --> Utf8 Class Initialized
INFO - 2021-07-18 06:37:38 --> URI Class Initialized
INFO - 2021-07-18 06:37:38 --> Router Class Initialized
INFO - 2021-07-18 06:37:38 --> Output Class Initialized
INFO - 2021-07-18 06:37:38 --> Security Class Initialized
DEBUG - 2021-07-18 06:37:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:37:38 --> Input Class Initialized
INFO - 2021-07-18 06:37:38 --> Language Class Initialized
ERROR - 2021-07-18 06:37:38 --> 404 Page Not Found: CuteSoft_Client/CuteEditor
ERROR - 2021-07-18 06:37:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:37:38 --> Config Class Initialized
INFO - 2021-07-18 06:37:38 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:37:38 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:37:38 --> Utf8 Class Initialized
INFO - 2021-07-18 06:37:38 --> URI Class Initialized
INFO - 2021-07-18 06:37:38 --> Router Class Initialized
INFO - 2021-07-18 06:37:38 --> Output Class Initialized
INFO - 2021-07-18 06:37:38 --> Security Class Initialized
DEBUG - 2021-07-18 06:37:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:37:38 --> Input Class Initialized
INFO - 2021-07-18 06:37:38 --> Language Class Initialized
ERROR - 2021-07-18 06:37:38 --> 404 Page Not Found: CuteSoft_Client/CuteEditor
ERROR - 2021-07-18 06:37:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:37:38 --> Config Class Initialized
INFO - 2021-07-18 06:37:38 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:37:38 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:37:38 --> Utf8 Class Initialized
INFO - 2021-07-18 06:37:39 --> URI Class Initialized
INFO - 2021-07-18 06:37:39 --> Router Class Initialized
INFO - 2021-07-18 06:37:39 --> Output Class Initialized
INFO - 2021-07-18 06:37:39 --> Security Class Initialized
DEBUG - 2021-07-18 06:37:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:37:39 --> Input Class Initialized
INFO - 2021-07-18 06:37:39 --> Language Class Initialized
ERROR - 2021-07-18 06:37:39 --> 404 Page Not Found: CuteSoft_Client/CuteEditor
ERROR - 2021-07-18 06:37:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:37:40 --> Config Class Initialized
INFO - 2021-07-18 06:37:40 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:37:40 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:37:40 --> Utf8 Class Initialized
INFO - 2021-07-18 06:37:40 --> URI Class Initialized
INFO - 2021-07-18 06:37:40 --> Router Class Initialized
INFO - 2021-07-18 06:37:40 --> Output Class Initialized
INFO - 2021-07-18 06:37:40 --> Security Class Initialized
DEBUG - 2021-07-18 06:37:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:37:40 --> Input Class Initialized
INFO - 2021-07-18 06:37:40 --> Language Class Initialized
ERROR - 2021-07-18 06:37:40 --> 404 Page Not Found: CuteSoft_Client/CuteEditor
ERROR - 2021-07-18 06:37:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:37:40 --> Config Class Initialized
INFO - 2021-07-18 06:37:40 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:37:40 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:37:40 --> Utf8 Class Initialized
INFO - 2021-07-18 06:37:40 --> URI Class Initialized
INFO - 2021-07-18 06:37:40 --> Router Class Initialized
INFO - 2021-07-18 06:37:40 --> Output Class Initialized
INFO - 2021-07-18 06:37:40 --> Security Class Initialized
DEBUG - 2021-07-18 06:37:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:37:40 --> Input Class Initialized
INFO - 2021-07-18 06:37:40 --> Language Class Initialized
ERROR - 2021-07-18 06:37:40 --> 404 Page Not Found: Help/ch_gb
ERROR - 2021-07-18 06:37:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:37:40 --> Config Class Initialized
INFO - 2021-07-18 06:37:40 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:37:40 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:37:40 --> Utf8 Class Initialized
INFO - 2021-07-18 06:37:40 --> URI Class Initialized
INFO - 2021-07-18 06:37:40 --> Router Class Initialized
INFO - 2021-07-18 06:37:40 --> Output Class Initialized
INFO - 2021-07-18 06:37:40 --> Security Class Initialized
DEBUG - 2021-07-18 06:37:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:37:40 --> Input Class Initialized
INFO - 2021-07-18 06:37:40 --> Language Class Initialized
ERROR - 2021-07-18 06:37:40 --> 404 Page Not Found: Admin/index.php
ERROR - 2021-07-18 06:37:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:37:41 --> Config Class Initialized
INFO - 2021-07-18 06:37:41 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:37:41 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:37:41 --> Utf8 Class Initialized
INFO - 2021-07-18 06:37:41 --> URI Class Initialized
INFO - 2021-07-18 06:37:41 --> Router Class Initialized
INFO - 2021-07-18 06:37:41 --> Output Class Initialized
INFO - 2021-07-18 06:37:41 --> Security Class Initialized
DEBUG - 2021-07-18 06:37:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:37:41 --> Input Class Initialized
INFO - 2021-07-18 06:37:41 --> Language Class Initialized
ERROR - 2021-07-18 06:37:41 --> 404 Page Not Found: Admin/js
ERROR - 2021-07-18 06:37:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:37:41 --> Config Class Initialized
INFO - 2021-07-18 06:37:41 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:37:41 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:37:41 --> Utf8 Class Initialized
INFO - 2021-07-18 06:37:41 --> URI Class Initialized
INFO - 2021-07-18 06:37:41 --> Router Class Initialized
INFO - 2021-07-18 06:37:41 --> Output Class Initialized
INFO - 2021-07-18 06:37:41 --> Security Class Initialized
DEBUG - 2021-07-18 06:37:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:37:41 --> Input Class Initialized
INFO - 2021-07-18 06:37:41 --> Language Class Initialized
ERROR - 2021-07-18 06:37:41 --> 404 Page Not Found: Ids/admin
ERROR - 2021-07-18 06:37:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:37:42 --> Config Class Initialized
INFO - 2021-07-18 06:37:42 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:37:42 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:37:42 --> Utf8 Class Initialized
INFO - 2021-07-18 06:37:42 --> URI Class Initialized
INFO - 2021-07-18 06:37:42 --> Router Class Initialized
INFO - 2021-07-18 06:37:42 --> Output Class Initialized
INFO - 2021-07-18 06:37:42 --> Security Class Initialized
DEBUG - 2021-07-18 06:37:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:37:42 --> Input Class Initialized
INFO - 2021-07-18 06:37:42 --> Language Class Initialized
ERROR - 2021-07-18 06:37:42 --> 404 Page Not Found: Ids/admin
ERROR - 2021-07-18 06:37:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:37:42 --> Config Class Initialized
INFO - 2021-07-18 06:37:42 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:37:42 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:37:42 --> Utf8 Class Initialized
INFO - 2021-07-18 06:37:42 --> URI Class Initialized
INFO - 2021-07-18 06:37:42 --> Router Class Initialized
INFO - 2021-07-18 06:37:42 --> Output Class Initialized
INFO - 2021-07-18 06:37:42 --> Security Class Initialized
DEBUG - 2021-07-18 06:37:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:37:42 --> Input Class Initialized
INFO - 2021-07-18 06:37:42 --> Language Class Initialized
ERROR - 2021-07-18 06:37:42 --> 404 Page Not Found: Bencandyphp/index
ERROR - 2021-07-18 06:37:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:37:43 --> Config Class Initialized
INFO - 2021-07-18 06:37:43 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:37:43 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:37:43 --> Utf8 Class Initialized
INFO - 2021-07-18 06:37:43 --> URI Class Initialized
INFO - 2021-07-18 06:37:43 --> Router Class Initialized
INFO - 2021-07-18 06:37:43 --> Output Class Initialized
INFO - 2021-07-18 06:37:43 --> Security Class Initialized
DEBUG - 2021-07-18 06:37:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:37:43 --> Input Class Initialized
INFO - 2021-07-18 06:37:43 --> Language Class Initialized
ERROR - 2021-07-18 06:37:43 --> 404 Page Not Found: Images/default
ERROR - 2021-07-18 06:37:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:37:43 --> Config Class Initialized
INFO - 2021-07-18 06:37:43 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:37:43 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:37:43 --> Utf8 Class Initialized
INFO - 2021-07-18 06:37:43 --> URI Class Initialized
INFO - 2021-07-18 06:37:43 --> Router Class Initialized
INFO - 2021-07-18 06:37:43 --> Output Class Initialized
INFO - 2021-07-18 06:37:43 --> Security Class Initialized
DEBUG - 2021-07-18 06:37:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:37:43 --> Input Class Initialized
INFO - 2021-07-18 06:37:43 --> Language Class Initialized
ERROR - 2021-07-18 06:37:43 --> 404 Page Not Found: Siteserver/upgrade
ERROR - 2021-07-18 06:37:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:37:43 --> Config Class Initialized
INFO - 2021-07-18 06:37:43 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:37:43 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:37:43 --> Utf8 Class Initialized
INFO - 2021-07-18 06:37:43 --> URI Class Initialized
INFO - 2021-07-18 06:37:43 --> Router Class Initialized
INFO - 2021-07-18 06:37:43 --> Output Class Initialized
INFO - 2021-07-18 06:37:43 --> Security Class Initialized
DEBUG - 2021-07-18 06:37:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:37:43 --> Input Class Initialized
INFO - 2021-07-18 06:37:43 --> Language Class Initialized
ERROR - 2021-07-18 06:37:43 --> 404 Page Not Found: Siteserver/login.aspx
ERROR - 2021-07-18 06:37:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:37:44 --> Config Class Initialized
INFO - 2021-07-18 06:37:44 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:37:44 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:37:44 --> Utf8 Class Initialized
INFO - 2021-07-18 06:37:44 --> URI Class Initialized
INFO - 2021-07-18 06:37:44 --> Router Class Initialized
INFO - 2021-07-18 06:37:44 --> Output Class Initialized
INFO - 2021-07-18 06:37:44 --> Security Class Initialized
DEBUG - 2021-07-18 06:37:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:37:44 --> Input Class Initialized
INFO - 2021-07-18 06:37:44 --> Language Class Initialized
ERROR - 2021-07-18 06:37:44 --> 404 Page Not Found: UserCenter/css
ERROR - 2021-07-18 06:37:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:37:44 --> Config Class Initialized
INFO - 2021-07-18 06:37:44 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:37:44 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:37:44 --> Utf8 Class Initialized
INFO - 2021-07-18 06:37:44 --> URI Class Initialized
DEBUG - 2021-07-18 06:37:44 --> No URI present. Default controller set.
INFO - 2021-07-18 06:37:44 --> Router Class Initialized
INFO - 2021-07-18 06:37:44 --> Output Class Initialized
INFO - 2021-07-18 06:37:44 --> Security Class Initialized
DEBUG - 2021-07-18 06:37:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:37:44 --> Input Class Initialized
INFO - 2021-07-18 06:37:44 --> Language Class Initialized
INFO - 2021-07-18 06:37:44 --> Loader Class Initialized
INFO - 2021-07-18 06:37:44 --> Helper loaded: url_helper
INFO - 2021-07-18 06:37:44 --> Helper loaded: form_helper
INFO - 2021-07-18 06:37:44 --> Helper loaded: common_helper
INFO - 2021-07-18 06:37:44 --> Database Driver Class Initialized
DEBUG - 2021-07-18 06:37:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-18 06:37:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-18 06:37:44 --> Controller Class Initialized
INFO - 2021-07-18 06:37:44 --> Form Validation Class Initialized
DEBUG - 2021-07-18 06:37:44 --> Encrypt Class Initialized
DEBUG - 2021-07-18 06:37:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-07-18 06:37:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-07-18 06:37:44 --> Email Class Initialized
INFO - 2021-07-18 06:37:44 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-07-18 06:37:44 --> Calendar Class Initialized
INFO - 2021-07-18 06:37:44 --> Model "Login_model" initialized
INFO - 2021-07-18 06:37:44 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-07-18 06:37:44 --> Final output sent to browser
DEBUG - 2021-07-18 06:37:44 --> Total execution time: 0.0189
ERROR - 2021-07-18 06:37:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:37:45 --> Config Class Initialized
INFO - 2021-07-18 06:37:45 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:37:45 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:37:45 --> Utf8 Class Initialized
INFO - 2021-07-18 06:37:45 --> URI Class Initialized
DEBUG - 2021-07-18 06:37:45 --> No URI present. Default controller set.
INFO - 2021-07-18 06:37:45 --> Router Class Initialized
INFO - 2021-07-18 06:37:45 --> Output Class Initialized
INFO - 2021-07-18 06:37:45 --> Security Class Initialized
DEBUG - 2021-07-18 06:37:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:37:45 --> Input Class Initialized
INFO - 2021-07-18 06:37:45 --> Language Class Initialized
INFO - 2021-07-18 06:37:45 --> Loader Class Initialized
INFO - 2021-07-18 06:37:45 --> Helper loaded: url_helper
INFO - 2021-07-18 06:37:45 --> Helper loaded: form_helper
INFO - 2021-07-18 06:37:45 --> Helper loaded: common_helper
INFO - 2021-07-18 06:37:45 --> Database Driver Class Initialized
DEBUG - 2021-07-18 06:37:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-18 06:37:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-18 06:37:45 --> Controller Class Initialized
INFO - 2021-07-18 06:37:45 --> Form Validation Class Initialized
DEBUG - 2021-07-18 06:37:45 --> Encrypt Class Initialized
DEBUG - 2021-07-18 06:37:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-07-18 06:37:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-07-18 06:37:45 --> Email Class Initialized
INFO - 2021-07-18 06:37:45 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-07-18 06:37:45 --> Calendar Class Initialized
INFO - 2021-07-18 06:37:45 --> Model "Login_model" initialized
INFO - 2021-07-18 06:37:45 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-07-18 06:37:45 --> Final output sent to browser
DEBUG - 2021-07-18 06:37:45 --> Total execution time: 0.0177
ERROR - 2021-07-18 06:37:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:37:45 --> Config Class Initialized
INFO - 2021-07-18 06:37:45 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:37:45 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:37:45 --> Utf8 Class Initialized
INFO - 2021-07-18 06:37:45 --> URI Class Initialized
DEBUG - 2021-07-18 06:37:45 --> No URI present. Default controller set.
INFO - 2021-07-18 06:37:45 --> Router Class Initialized
INFO - 2021-07-18 06:37:45 --> Output Class Initialized
INFO - 2021-07-18 06:37:45 --> Security Class Initialized
DEBUG - 2021-07-18 06:37:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:37:45 --> Input Class Initialized
INFO - 2021-07-18 06:37:45 --> Language Class Initialized
INFO - 2021-07-18 06:37:45 --> Loader Class Initialized
INFO - 2021-07-18 06:37:45 --> Helper loaded: url_helper
INFO - 2021-07-18 06:37:45 --> Helper loaded: form_helper
INFO - 2021-07-18 06:37:45 --> Helper loaded: common_helper
INFO - 2021-07-18 06:37:45 --> Database Driver Class Initialized
DEBUG - 2021-07-18 06:37:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-18 06:37:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-18 06:37:45 --> Controller Class Initialized
INFO - 2021-07-18 06:37:45 --> Form Validation Class Initialized
DEBUG - 2021-07-18 06:37:45 --> Encrypt Class Initialized
DEBUG - 2021-07-18 06:37:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-07-18 06:37:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-07-18 06:37:45 --> Email Class Initialized
INFO - 2021-07-18 06:37:45 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-07-18 06:37:45 --> Calendar Class Initialized
INFO - 2021-07-18 06:37:45 --> Model "Login_model" initialized
INFO - 2021-07-18 06:37:45 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-07-18 06:37:45 --> Final output sent to browser
DEBUG - 2021-07-18 06:37:45 --> Total execution time: 0.0214
ERROR - 2021-07-18 06:37:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:37:45 --> Config Class Initialized
INFO - 2021-07-18 06:37:45 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:37:45 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:37:45 --> Utf8 Class Initialized
INFO - 2021-07-18 06:37:45 --> URI Class Initialized
DEBUG - 2021-07-18 06:37:45 --> No URI present. Default controller set.
INFO - 2021-07-18 06:37:45 --> Router Class Initialized
INFO - 2021-07-18 06:37:45 --> Output Class Initialized
INFO - 2021-07-18 06:37:45 --> Security Class Initialized
DEBUG - 2021-07-18 06:37:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:37:45 --> Input Class Initialized
INFO - 2021-07-18 06:37:45 --> Language Class Initialized
INFO - 2021-07-18 06:37:45 --> Loader Class Initialized
INFO - 2021-07-18 06:37:45 --> Helper loaded: url_helper
INFO - 2021-07-18 06:37:45 --> Helper loaded: form_helper
INFO - 2021-07-18 06:37:45 --> Helper loaded: common_helper
INFO - 2021-07-18 06:37:45 --> Database Driver Class Initialized
DEBUG - 2021-07-18 06:37:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-18 06:37:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-18 06:37:45 --> Controller Class Initialized
INFO - 2021-07-18 06:37:45 --> Form Validation Class Initialized
DEBUG - 2021-07-18 06:37:45 --> Encrypt Class Initialized
DEBUG - 2021-07-18 06:37:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-07-18 06:37:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-07-18 06:37:45 --> Email Class Initialized
INFO - 2021-07-18 06:37:45 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-07-18 06:37:45 --> Calendar Class Initialized
INFO - 2021-07-18 06:37:45 --> Model "Login_model" initialized
INFO - 2021-07-18 06:37:45 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-07-18 06:37:45 --> Final output sent to browser
DEBUG - 2021-07-18 06:37:45 --> Total execution time: 0.0172
ERROR - 2021-07-18 06:37:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:37:46 --> Config Class Initialized
INFO - 2021-07-18 06:37:46 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:37:46 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:37:46 --> Utf8 Class Initialized
INFO - 2021-07-18 06:37:46 --> URI Class Initialized
INFO - 2021-07-18 06:37:46 --> Router Class Initialized
INFO - 2021-07-18 06:37:46 --> Output Class Initialized
INFO - 2021-07-18 06:37:46 --> Security Class Initialized
DEBUG - 2021-07-18 06:37:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:37:46 --> Input Class Initialized
INFO - 2021-07-18 06:37:46 --> Language Class Initialized
ERROR - 2021-07-18 06:37:46 --> 404 Page Not Found: Admin/inc
ERROR - 2021-07-18 06:37:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:37:46 --> Config Class Initialized
INFO - 2021-07-18 06:37:46 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:37:46 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:37:46 --> Utf8 Class Initialized
INFO - 2021-07-18 06:37:46 --> URI Class Initialized
INFO - 2021-07-18 06:37:46 --> Router Class Initialized
INFO - 2021-07-18 06:37:46 --> Output Class Initialized
INFO - 2021-07-18 06:37:46 --> Security Class Initialized
DEBUG - 2021-07-18 06:37:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:37:46 --> Input Class Initialized
INFO - 2021-07-18 06:37:46 --> Language Class Initialized
ERROR - 2021-07-18 06:37:46 --> 404 Page Not Found: Indexcgi/index
ERROR - 2021-07-18 06:37:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:37:47 --> Config Class Initialized
INFO - 2021-07-18 06:37:47 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:37:47 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:37:47 --> Utf8 Class Initialized
INFO - 2021-07-18 06:37:47 --> URI Class Initialized
INFO - 2021-07-18 06:37:47 --> Router Class Initialized
INFO - 2021-07-18 06:37:47 --> Output Class Initialized
INFO - 2021-07-18 06:37:47 --> Security Class Initialized
DEBUG - 2021-07-18 06:37:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:37:47 --> Input Class Initialized
INFO - 2021-07-18 06:37:47 --> Language Class Initialized
ERROR - 2021-07-18 06:37:47 --> 404 Page Not Found: Cgi/index.cgi
ERROR - 2021-07-18 06:37:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:37:47 --> Config Class Initialized
INFO - 2021-07-18 06:37:47 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:37:47 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:37:47 --> Utf8 Class Initialized
INFO - 2021-07-18 06:37:47 --> URI Class Initialized
INFO - 2021-07-18 06:37:47 --> Router Class Initialized
INFO - 2021-07-18 06:37:47 --> Output Class Initialized
INFO - 2021-07-18 06:37:47 --> Security Class Initialized
DEBUG - 2021-07-18 06:37:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:37:47 --> Input Class Initialized
INFO - 2021-07-18 06:37:47 --> Language Class Initialized
ERROR - 2021-07-18 06:37:47 --> 404 Page Not Found: Default/images
ERROR - 2021-07-18 06:37:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:37:47 --> Config Class Initialized
INFO - 2021-07-18 06:37:47 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:37:47 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:37:47 --> Utf8 Class Initialized
INFO - 2021-07-18 06:37:47 --> URI Class Initialized
INFO - 2021-07-18 06:37:47 --> Router Class Initialized
INFO - 2021-07-18 06:37:47 --> Output Class Initialized
INFO - 2021-07-18 06:37:47 --> Security Class Initialized
DEBUG - 2021-07-18 06:37:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:37:47 --> Input Class Initialized
INFO - 2021-07-18 06:37:47 --> Language Class Initialized
ERROR - 2021-07-18 06:37:47 --> 404 Page Not Found: Extman/default
ERROR - 2021-07-18 06:37:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:37:48 --> Config Class Initialized
INFO - 2021-07-18 06:37:48 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:37:48 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:37:48 --> Utf8 Class Initialized
INFO - 2021-07-18 06:37:48 --> URI Class Initialized
INFO - 2021-07-18 06:37:48 --> Router Class Initialized
INFO - 2021-07-18 06:37:48 --> Output Class Initialized
INFO - 2021-07-18 06:37:48 --> Security Class Initialized
DEBUG - 2021-07-18 06:37:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:37:48 --> Input Class Initialized
INFO - 2021-07-18 06:37:48 --> Language Class Initialized
ERROR - 2021-07-18 06:37:48 --> 404 Page Not Found: Addons/theme
ERROR - 2021-07-18 06:37:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:37:49 --> Config Class Initialized
INFO - 2021-07-18 06:37:49 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:37:49 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:37:49 --> Utf8 Class Initialized
INFO - 2021-07-18 06:37:49 --> URI Class Initialized
INFO - 2021-07-18 06:37:49 --> Router Class Initialized
INFO - 2021-07-18 06:37:49 --> Output Class Initialized
INFO - 2021-07-18 06:37:49 --> Security Class Initialized
DEBUG - 2021-07-18 06:37:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:37:49 --> Input Class Initialized
INFO - 2021-07-18 06:37:49 --> Language Class Initialized
ERROR - 2021-07-18 06:37:49 --> 404 Page Not Found: Apps/admin
ERROR - 2021-07-18 06:37:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:37:49 --> Config Class Initialized
INFO - 2021-07-18 06:37:49 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:37:49 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:37:49 --> Utf8 Class Initialized
INFO - 2021-07-18 06:37:49 --> URI Class Initialized
INFO - 2021-07-18 06:37:49 --> Router Class Initialized
INFO - 2021-07-18 06:37:49 --> Output Class Initialized
INFO - 2021-07-18 06:37:49 --> Security Class Initialized
DEBUG - 2021-07-18 06:37:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:37:49 --> Input Class Initialized
INFO - 2021-07-18 06:37:49 --> Language Class Initialized
ERROR - 2021-07-18 06:37:49 --> 404 Page Not Found: Addons/theme
ERROR - 2021-07-18 06:37:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:37:59 --> Config Class Initialized
INFO - 2021-07-18 06:37:59 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:37:59 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:37:59 --> Utf8 Class Initialized
INFO - 2021-07-18 06:37:59 --> URI Class Initialized
INFO - 2021-07-18 06:37:59 --> Router Class Initialized
INFO - 2021-07-18 06:37:59 --> Output Class Initialized
INFO - 2021-07-18 06:37:59 --> Security Class Initialized
DEBUG - 2021-07-18 06:37:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:37:59 --> Input Class Initialized
INFO - 2021-07-18 06:37:59 --> Language Class Initialized
ERROR - 2021-07-18 06:37:59 --> 404 Page Not Found: Addons/theme
ERROR - 2021-07-18 06:37:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:37:59 --> Config Class Initialized
INFO - 2021-07-18 06:37:59 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:37:59 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:37:59 --> Utf8 Class Initialized
INFO - 2021-07-18 06:37:59 --> URI Class Initialized
INFO - 2021-07-18 06:37:59 --> Router Class Initialized
INFO - 2021-07-18 06:37:59 --> Output Class Initialized
INFO - 2021-07-18 06:37:59 --> Security Class Initialized
DEBUG - 2021-07-18 06:37:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:37:59 --> Input Class Initialized
INFO - 2021-07-18 06:37:59 --> Language Class Initialized
ERROR - 2021-07-18 06:37:59 --> 404 Page Not Found: Default/css
ERROR - 2021-07-18 06:38:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:38:00 --> Config Class Initialized
INFO - 2021-07-18 06:38:00 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:38:00 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:38:00 --> Utf8 Class Initialized
INFO - 2021-07-18 06:38:00 --> URI Class Initialized
INFO - 2021-07-18 06:38:00 --> Router Class Initialized
INFO - 2021-07-18 06:38:00 --> Output Class Initialized
INFO - 2021-07-18 06:38:00 --> Security Class Initialized
DEBUG - 2021-07-18 06:38:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:38:00 --> Input Class Initialized
INFO - 2021-07-18 06:38:00 --> Language Class Initialized
ERROR - 2021-07-18 06:38:00 --> 404 Page Not Found: App/login.jsp
ERROR - 2021-07-18 06:38:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:38:00 --> Config Class Initialized
INFO - 2021-07-18 06:38:00 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:38:00 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:38:00 --> Utf8 Class Initialized
INFO - 2021-07-18 06:38:00 --> URI Class Initialized
INFO - 2021-07-18 06:38:00 --> Router Class Initialized
INFO - 2021-07-18 06:38:00 --> Output Class Initialized
INFO - 2021-07-18 06:38:00 --> Security Class Initialized
DEBUG - 2021-07-18 06:38:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:38:00 --> Input Class Initialized
INFO - 2021-07-18 06:38:00 --> Language Class Initialized
ERROR - 2021-07-18 06:38:00 --> 404 Page Not Found: App/js
ERROR - 2021-07-18 06:38:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:38:00 --> Config Class Initialized
INFO - 2021-07-18 06:38:00 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:38:00 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:38:00 --> Utf8 Class Initialized
INFO - 2021-07-18 06:38:00 --> URI Class Initialized
INFO - 2021-07-18 06:38:00 --> Router Class Initialized
INFO - 2021-07-18 06:38:00 --> Output Class Initialized
INFO - 2021-07-18 06:38:00 --> Security Class Initialized
DEBUG - 2021-07-18 06:38:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:38:00 --> Input Class Initialized
INFO - 2021-07-18 06:38:00 --> Language Class Initialized
ERROR - 2021-07-18 06:38:00 --> 404 Page Not Found: Console/js
ERROR - 2021-07-18 06:38:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:38:01 --> Config Class Initialized
INFO - 2021-07-18 06:38:01 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:38:01 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:38:01 --> Utf8 Class Initialized
INFO - 2021-07-18 06:38:01 --> URI Class Initialized
INFO - 2021-07-18 06:38:01 --> Router Class Initialized
INFO - 2021-07-18 06:38:01 --> Output Class Initialized
INFO - 2021-07-18 06:38:01 --> Security Class Initialized
DEBUG - 2021-07-18 06:38:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:38:01 --> Input Class Initialized
INFO - 2021-07-18 06:38:01 --> Language Class Initialized
ERROR - 2021-07-18 06:38:01 --> 404 Page Not Found: Console/include
ERROR - 2021-07-18 06:38:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:38:01 --> Config Class Initialized
INFO - 2021-07-18 06:38:01 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:38:01 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:38:01 --> Utf8 Class Initialized
INFO - 2021-07-18 06:38:01 --> URI Class Initialized
INFO - 2021-07-18 06:38:01 --> Router Class Initialized
INFO - 2021-07-18 06:38:01 --> Output Class Initialized
INFO - 2021-07-18 06:38:01 --> Security Class Initialized
DEBUG - 2021-07-18 06:38:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:38:01 --> Input Class Initialized
INFO - 2021-07-18 06:38:01 --> Language Class Initialized
ERROR - 2021-07-18 06:38:01 --> 404 Page Not Found: Console/auth
ERROR - 2021-07-18 06:38:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:38:02 --> Config Class Initialized
INFO - 2021-07-18 06:38:02 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:38:02 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:38:02 --> Utf8 Class Initialized
INFO - 2021-07-18 06:38:02 --> URI Class Initialized
INFO - 2021-07-18 06:38:02 --> Router Class Initialized
INFO - 2021-07-18 06:38:02 --> Output Class Initialized
INFO - 2021-07-18 06:38:02 --> Security Class Initialized
DEBUG - 2021-07-18 06:38:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:38:02 --> Input Class Initialized
INFO - 2021-07-18 06:38:02 --> Language Class Initialized
ERROR - 2021-07-18 06:38:02 --> 404 Page Not Found: Console/js
ERROR - 2021-07-18 06:38:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:38:02 --> Config Class Initialized
INFO - 2021-07-18 06:38:02 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:38:02 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:38:02 --> Utf8 Class Initialized
INFO - 2021-07-18 06:38:02 --> URI Class Initialized
INFO - 2021-07-18 06:38:02 --> Router Class Initialized
INFO - 2021-07-18 06:38:02 --> Output Class Initialized
INFO - 2021-07-18 06:38:02 --> Security Class Initialized
DEBUG - 2021-07-18 06:38:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:38:02 --> Input Class Initialized
INFO - 2021-07-18 06:38:02 --> Language Class Initialized
ERROR - 2021-07-18 06:38:02 --> 404 Page Not Found: App/images
ERROR - 2021-07-18 06:38:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:38:03 --> Config Class Initialized
INFO - 2021-07-18 06:38:03 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:38:03 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:38:03 --> Utf8 Class Initialized
INFO - 2021-07-18 06:38:03 --> URI Class Initialized
INFO - 2021-07-18 06:38:03 --> Router Class Initialized
INFO - 2021-07-18 06:38:03 --> Output Class Initialized
INFO - 2021-07-18 06:38:03 --> Security Class Initialized
DEBUG - 2021-07-18 06:38:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:38:03 --> Input Class Initialized
INFO - 2021-07-18 06:38:03 --> Language Class Initialized
ERROR - 2021-07-18 06:38:03 --> 404 Page Not Found: App/images
ERROR - 2021-07-18 06:38:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:38:03 --> Config Class Initialized
INFO - 2021-07-18 06:38:03 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:38:03 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:38:03 --> Utf8 Class Initialized
INFO - 2021-07-18 06:38:03 --> URI Class Initialized
INFO - 2021-07-18 06:38:03 --> Router Class Initialized
INFO - 2021-07-18 06:38:03 --> Output Class Initialized
INFO - 2021-07-18 06:38:03 --> Security Class Initialized
DEBUG - 2021-07-18 06:38:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:38:03 --> Input Class Initialized
INFO - 2021-07-18 06:38:03 --> Language Class Initialized
ERROR - 2021-07-18 06:38:03 --> 404 Page Not Found: App/home
ERROR - 2021-07-18 06:38:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:38:04 --> Config Class Initialized
INFO - 2021-07-18 06:38:04 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:38:04 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:38:04 --> Utf8 Class Initialized
INFO - 2021-07-18 06:38:04 --> URI Class Initialized
INFO - 2021-07-18 06:38:04 --> Router Class Initialized
INFO - 2021-07-18 06:38:04 --> Output Class Initialized
INFO - 2021-07-18 06:38:04 --> Security Class Initialized
DEBUG - 2021-07-18 06:38:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:38:04 --> Input Class Initialized
INFO - 2021-07-18 06:38:04 --> Language Class Initialized
ERROR - 2021-07-18 06:38:04 --> 404 Page Not Found: Images/login9
ERROR - 2021-07-18 06:38:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:38:04 --> Config Class Initialized
INFO - 2021-07-18 06:38:04 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:38:04 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:38:04 --> Utf8 Class Initialized
INFO - 2021-07-18 06:38:04 --> URI Class Initialized
INFO - 2021-07-18 06:38:04 --> Router Class Initialized
INFO - 2021-07-18 06:38:04 --> Output Class Initialized
INFO - 2021-07-18 06:38:04 --> Security Class Initialized
DEBUG - 2021-07-18 06:38:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:38:04 --> Input Class Initialized
INFO - 2021-07-18 06:38:04 --> Language Class Initialized
ERROR - 2021-07-18 06:38:04 --> 404 Page Not Found: Admin/SouthidcEditor
ERROR - 2021-07-18 06:38:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:38:04 --> Config Class Initialized
INFO - 2021-07-18 06:38:04 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:38:04 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:38:04 --> Utf8 Class Initialized
INFO - 2021-07-18 06:38:04 --> URI Class Initialized
INFO - 2021-07-18 06:38:04 --> Router Class Initialized
INFO - 2021-07-18 06:38:04 --> Output Class Initialized
INFO - 2021-07-18 06:38:04 --> Security Class Initialized
DEBUG - 2021-07-18 06:38:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:38:04 --> Input Class Initialized
INFO - 2021-07-18 06:38:04 --> Language Class Initialized
ERROR - 2021-07-18 06:38:04 --> 404 Page Not Found: Admin/SouthidcEditor
ERROR - 2021-07-18 06:38:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:38:05 --> Config Class Initialized
INFO - 2021-07-18 06:38:05 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:38:05 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:38:05 --> Utf8 Class Initialized
INFO - 2021-07-18 06:38:05 --> URI Class Initialized
INFO - 2021-07-18 06:38:05 --> Router Class Initialized
INFO - 2021-07-18 06:38:05 --> Output Class Initialized
INFO - 2021-07-18 06:38:05 --> Security Class Initialized
DEBUG - 2021-07-18 06:38:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:38:05 --> Input Class Initialized
INFO - 2021-07-18 06:38:05 --> Language Class Initialized
ERROR - 2021-07-18 06:38:05 --> 404 Page Not Found: Admin/SouthidcEditor
ERROR - 2021-07-18 06:38:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:38:05 --> Config Class Initialized
INFO - 2021-07-18 06:38:05 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:38:05 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:38:05 --> Utf8 Class Initialized
INFO - 2021-07-18 06:38:05 --> URI Class Initialized
INFO - 2021-07-18 06:38:05 --> Router Class Initialized
INFO - 2021-07-18 06:38:05 --> Output Class Initialized
INFO - 2021-07-18 06:38:05 --> Security Class Initialized
DEBUG - 2021-07-18 06:38:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:38:05 --> Input Class Initialized
INFO - 2021-07-18 06:38:05 --> Language Class Initialized
ERROR - 2021-07-18 06:38:05 --> 404 Page Not Found: READMEtxt/index
ERROR - 2021-07-18 06:38:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:38:06 --> Config Class Initialized
INFO - 2021-07-18 06:38:06 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:38:06 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:38:06 --> Utf8 Class Initialized
INFO - 2021-07-18 06:38:06 --> URI Class Initialized
INFO - 2021-07-18 06:38:06 --> Router Class Initialized
INFO - 2021-07-18 06:38:06 --> Output Class Initialized
INFO - 2021-07-18 06:38:06 --> Security Class Initialized
DEBUG - 2021-07-18 06:38:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:38:06 --> Input Class Initialized
INFO - 2021-07-18 06:38:06 --> Language Class Initialized
ERROR - 2021-07-18 06:38:06 --> 404 Page Not Found: Pub/guiedit
ERROR - 2021-07-18 06:38:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:38:06 --> Config Class Initialized
INFO - 2021-07-18 06:38:06 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:38:06 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:38:06 --> Utf8 Class Initialized
INFO - 2021-07-18 06:38:06 --> URI Class Initialized
INFO - 2021-07-18 06:38:06 --> Router Class Initialized
INFO - 2021-07-18 06:38:06 --> Output Class Initialized
INFO - 2021-07-18 06:38:06 --> Security Class Initialized
DEBUG - 2021-07-18 06:38:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:38:06 --> Input Class Initialized
INFO - 2021-07-18 06:38:06 --> Language Class Initialized
ERROR - 2021-07-18 06:38:06 --> 404 Page Not Found: Pub/skins
ERROR - 2021-07-18 06:38:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:38:07 --> Config Class Initialized
INFO - 2021-07-18 06:38:07 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:38:07 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:38:07 --> Utf8 Class Initialized
INFO - 2021-07-18 06:38:07 --> URI Class Initialized
INFO - 2021-07-18 06:38:07 --> Router Class Initialized
INFO - 2021-07-18 06:38:07 --> Output Class Initialized
INFO - 2021-07-18 06:38:07 --> Security Class Initialized
DEBUG - 2021-07-18 06:38:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:38:07 --> Input Class Initialized
INFO - 2021-07-18 06:38:07 --> Language Class Initialized
ERROR - 2021-07-18 06:38:07 --> 404 Page Not Found: Docs/DOCUMENTATION.txt
ERROR - 2021-07-18 06:38:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:38:07 --> Config Class Initialized
INFO - 2021-07-18 06:38:07 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:38:07 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:38:07 --> Utf8 Class Initialized
INFO - 2021-07-18 06:38:07 --> URI Class Initialized
INFO - 2021-07-18 06:38:07 --> Router Class Initialized
INFO - 2021-07-18 06:38:07 --> Output Class Initialized
INFO - 2021-07-18 06:38:07 --> Security Class Initialized
DEBUG - 2021-07-18 06:38:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:38:07 --> Input Class Initialized
INFO - 2021-07-18 06:38:07 --> Language Class Initialized
ERROR - 2021-07-18 06:38:07 --> 404 Page Not Found: Skin/frontend
ERROR - 2021-07-18 06:38:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:38:07 --> Config Class Initialized
INFO - 2021-07-18 06:38:07 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:38:07 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:38:07 --> Utf8 Class Initialized
INFO - 2021-07-18 06:38:07 --> URI Class Initialized
INFO - 2021-07-18 06:38:07 --> Router Class Initialized
INFO - 2021-07-18 06:38:07 --> Output Class Initialized
INFO - 2021-07-18 06:38:07 --> Security Class Initialized
DEBUG - 2021-07-18 06:38:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:38:07 --> Input Class Initialized
INFO - 2021-07-18 06:38:07 --> Language Class Initialized
ERROR - 2021-07-18 06:38:07 --> 404 Page Not Found: Helpnew/faq
ERROR - 2021-07-18 06:38:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:38:08 --> Config Class Initialized
INFO - 2021-07-18 06:38:08 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:38:08 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:38:08 --> Utf8 Class Initialized
INFO - 2021-07-18 06:38:08 --> URI Class Initialized
INFO - 2021-07-18 06:38:08 --> Router Class Initialized
INFO - 2021-07-18 06:38:08 --> Output Class Initialized
INFO - 2021-07-18 06:38:08 --> Security Class Initialized
DEBUG - 2021-07-18 06:38:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:38:08 --> Input Class Initialized
INFO - 2021-07-18 06:38:08 --> Language Class Initialized
ERROR - 2021-07-18 06:38:08 --> 404 Page Not Found: Ymail/images
ERROR - 2021-07-18 06:38:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:38:08 --> Config Class Initialized
INFO - 2021-07-18 06:38:08 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:38:08 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:38:08 --> Utf8 Class Initialized
INFO - 2021-07-18 06:38:08 --> URI Class Initialized
INFO - 2021-07-18 06:38:08 --> Router Class Initialized
INFO - 2021-07-18 06:38:08 --> Output Class Initialized
INFO - 2021-07-18 06:38:08 --> Security Class Initialized
DEBUG - 2021-07-18 06:38:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:38:08 --> Input Class Initialized
INFO - 2021-07-18 06:38:08 --> Language Class Initialized
ERROR - 2021-07-18 06:38:08 --> 404 Page Not Found: Advfile/ad12.js
ERROR - 2021-07-18 06:38:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:38:09 --> Config Class Initialized
INFO - 2021-07-18 06:38:09 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:38:09 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:38:09 --> Utf8 Class Initialized
INFO - 2021-07-18 06:38:09 --> URI Class Initialized
INFO - 2021-07-18 06:38:09 --> Router Class Initialized
INFO - 2021-07-18 06:38:09 --> Output Class Initialized
INFO - 2021-07-18 06:38:09 --> Security Class Initialized
DEBUG - 2021-07-18 06:38:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:38:09 --> Input Class Initialized
INFO - 2021-07-18 06:38:09 --> Language Class Initialized
ERROR - 2021-07-18 06:38:09 --> 404 Page Not Found: Wq_StranJFjs/index
ERROR - 2021-07-18 06:38:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:38:09 --> Config Class Initialized
INFO - 2021-07-18 06:38:09 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:38:09 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:38:09 --> Utf8 Class Initialized
INFO - 2021-07-18 06:38:09 --> URI Class Initialized
INFO - 2021-07-18 06:38:09 --> Router Class Initialized
INFO - 2021-07-18 06:38:09 --> Output Class Initialized
INFO - 2021-07-18 06:38:09 --> Security Class Initialized
DEBUG - 2021-07-18 06:38:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:38:09 --> Input Class Initialized
INFO - 2021-07-18 06:38:09 --> Language Class Initialized
ERROR - 2021-07-18 06:38:09 --> 404 Page Not Found: Admin/login.asp
ERROR - 2021-07-18 06:38:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:38:09 --> Config Class Initialized
INFO - 2021-07-18 06:38:09 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:38:09 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:38:09 --> Utf8 Class Initialized
INFO - 2021-07-18 06:38:09 --> URI Class Initialized
INFO - 2021-07-18 06:38:09 --> Router Class Initialized
INFO - 2021-07-18 06:38:09 --> Output Class Initialized
INFO - 2021-07-18 06:38:09 --> Security Class Initialized
DEBUG - 2021-07-18 06:38:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:38:09 --> Input Class Initialized
INFO - 2021-07-18 06:38:09 --> Language Class Initialized
ERROR - 2021-07-18 06:38:09 --> 404 Page Not Found: Pluginphp/index
ERROR - 2021-07-18 06:38:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:38:11 --> Config Class Initialized
INFO - 2021-07-18 06:38:11 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:38:11 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:38:11 --> Utf8 Class Initialized
INFO - 2021-07-18 06:38:11 --> URI Class Initialized
INFO - 2021-07-18 06:38:11 --> Router Class Initialized
INFO - 2021-07-18 06:38:11 --> Output Class Initialized
INFO - 2021-07-18 06:38:11 --> Security Class Initialized
DEBUG - 2021-07-18 06:38:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:38:11 --> Input Class Initialized
INFO - 2021-07-18 06:38:11 --> Language Class Initialized
ERROR - 2021-07-18 06:38:11 --> 404 Page Not Found: Install/index
ERROR - 2021-07-18 06:38:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:38:12 --> Config Class Initialized
INFO - 2021-07-18 06:38:12 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:38:12 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:38:12 --> Utf8 Class Initialized
INFO - 2021-07-18 06:38:12 --> URI Class Initialized
INFO - 2021-07-18 06:38:12 --> Router Class Initialized
INFO - 2021-07-18 06:38:12 --> Output Class Initialized
INFO - 2021-07-18 06:38:12 --> Security Class Initialized
DEBUG - 2021-07-18 06:38:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:38:12 --> Input Class Initialized
INFO - 2021-07-18 06:38:12 --> Language Class Initialized
ERROR - 2021-07-18 06:38:12 --> 404 Page Not Found: Template/1
ERROR - 2021-07-18 06:38:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:38:12 --> Config Class Initialized
INFO - 2021-07-18 06:38:12 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:38:12 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:38:12 --> Utf8 Class Initialized
INFO - 2021-07-18 06:38:12 --> URI Class Initialized
INFO - 2021-07-18 06:38:12 --> Router Class Initialized
INFO - 2021-07-18 06:38:12 --> Output Class Initialized
INFO - 2021-07-18 06:38:12 --> Security Class Initialized
DEBUG - 2021-07-18 06:38:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:38:12 --> Input Class Initialized
INFO - 2021-07-18 06:38:12 --> Language Class Initialized
ERROR - 2021-07-18 06:38:12 --> 404 Page Not Found: Back/scripts
ERROR - 2021-07-18 06:38:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:38:13 --> Config Class Initialized
INFO - 2021-07-18 06:38:13 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:38:13 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:38:13 --> Utf8 Class Initialized
INFO - 2021-07-18 06:38:13 --> URI Class Initialized
INFO - 2021-07-18 06:38:13 --> Router Class Initialized
INFO - 2021-07-18 06:38:13 --> Output Class Initialized
INFO - 2021-07-18 06:38:13 --> Security Class Initialized
DEBUG - 2021-07-18 06:38:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:38:13 --> Input Class Initialized
INFO - 2021-07-18 06:38:13 --> Language Class Initialized
ERROR - 2021-07-18 06:38:13 --> 404 Page Not Found: Admin/login.aspx
ERROR - 2021-07-18 06:38:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:38:13 --> Config Class Initialized
INFO - 2021-07-18 06:38:13 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:38:13 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:38:13 --> Utf8 Class Initialized
INFO - 2021-07-18 06:38:13 --> URI Class Initialized
INFO - 2021-07-18 06:38:13 --> Router Class Initialized
INFO - 2021-07-18 06:38:13 --> Output Class Initialized
INFO - 2021-07-18 06:38:13 --> Security Class Initialized
DEBUG - 2021-07-18 06:38:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:38:13 --> Input Class Initialized
INFO - 2021-07-18 06:38:13 --> Language Class Initialized
ERROR - 2021-07-18 06:38:13 --> 404 Page Not Found: Erroraspx/index
ERROR - 2021-07-18 06:38:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:38:14 --> Config Class Initialized
INFO - 2021-07-18 06:38:14 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:38:14 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:38:14 --> Utf8 Class Initialized
INFO - 2021-07-18 06:38:14 --> URI Class Initialized
INFO - 2021-07-18 06:38:14 --> Router Class Initialized
INFO - 2021-07-18 06:38:14 --> Output Class Initialized
INFO - 2021-07-18 06:38:14 --> Security Class Initialized
DEBUG - 2021-07-18 06:38:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:38:14 --> Input Class Initialized
INFO - 2021-07-18 06:38:14 --> Language Class Initialized
ERROR - 2021-07-18 06:38:14 --> 404 Page Not Found: Inc/playerKinds.xml
ERROR - 2021-07-18 06:38:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:38:14 --> Config Class Initialized
INFO - 2021-07-18 06:38:14 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:38:14 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:38:14 --> Utf8 Class Initialized
INFO - 2021-07-18 06:38:14 --> URI Class Initialized
INFO - 2021-07-18 06:38:14 --> Router Class Initialized
INFO - 2021-07-18 06:38:14 --> Output Class Initialized
INFO - 2021-07-18 06:38:14 --> Security Class Initialized
DEBUG - 2021-07-18 06:38:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:38:14 --> Input Class Initialized
INFO - 2021-07-18 06:38:14 --> Language Class Initialized
ERROR - 2021-07-18 06:38:14 --> 404 Page Not Found: Admin/start
ERROR - 2021-07-18 06:38:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:38:14 --> Config Class Initialized
INFO - 2021-07-18 06:38:14 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:38:14 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:38:14 --> Utf8 Class Initialized
INFO - 2021-07-18 06:38:14 --> URI Class Initialized
INFO - 2021-07-18 06:38:14 --> Router Class Initialized
INFO - 2021-07-18 06:38:14 --> Output Class Initialized
INFO - 2021-07-18 06:38:14 --> Security Class Initialized
DEBUG - 2021-07-18 06:38:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:38:14 --> Input Class Initialized
INFO - 2021-07-18 06:38:14 --> Language Class Initialized
ERROR - 2021-07-18 06:38:14 --> 404 Page Not Found: Kindeditor-minjs/index
ERROR - 2021-07-18 06:38:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:38:15 --> Config Class Initialized
INFO - 2021-07-18 06:38:15 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:38:15 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:38:15 --> Utf8 Class Initialized
INFO - 2021-07-18 06:38:15 --> URI Class Initialized
INFO - 2021-07-18 06:38:15 --> Router Class Initialized
INFO - 2021-07-18 06:38:15 --> Output Class Initialized
INFO - 2021-07-18 06:38:15 --> Security Class Initialized
DEBUG - 2021-07-18 06:38:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:38:15 --> Input Class Initialized
INFO - 2021-07-18 06:38:15 --> Language Class Initialized
ERROR - 2021-07-18 06:38:15 --> 404 Page Not Found: Kindeditorjs/index
ERROR - 2021-07-18 06:38:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:38:15 --> Config Class Initialized
INFO - 2021-07-18 06:38:15 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:38:15 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:38:15 --> Utf8 Class Initialized
INFO - 2021-07-18 06:38:15 --> URI Class Initialized
INFO - 2021-07-18 06:38:15 --> Router Class Initialized
INFO - 2021-07-18 06:38:15 --> Output Class Initialized
INFO - 2021-07-18 06:38:15 --> Security Class Initialized
DEBUG - 2021-07-18 06:38:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:38:15 --> Input Class Initialized
INFO - 2021-07-18 06:38:15 --> Language Class Initialized
ERROR - 2021-07-18 06:38:15 --> 404 Page Not Found: Lang/en.js
ERROR - 2021-07-18 06:38:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:38:16 --> Config Class Initialized
INFO - 2021-07-18 06:38:16 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:38:16 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:38:16 --> Utf8 Class Initialized
INFO - 2021-07-18 06:38:16 --> URI Class Initialized
INFO - 2021-07-18 06:38:16 --> Router Class Initialized
INFO - 2021-07-18 06:38:16 --> Output Class Initialized
INFO - 2021-07-18 06:38:16 --> Security Class Initialized
DEBUG - 2021-07-18 06:38:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:38:16 --> Input Class Initialized
INFO - 2021-07-18 06:38:16 --> Language Class Initialized
ERROR - 2021-07-18 06:38:16 --> 404 Page Not Found: Themes/default
ERROR - 2021-07-18 06:38:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:38:16 --> Config Class Initialized
INFO - 2021-07-18 06:38:16 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:38:16 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:38:16 --> Utf8 Class Initialized
INFO - 2021-07-18 06:38:16 --> URI Class Initialized
INFO - 2021-07-18 06:38:16 --> Router Class Initialized
INFO - 2021-07-18 06:38:16 --> Output Class Initialized
INFO - 2021-07-18 06:38:16 --> Security Class Initialized
DEBUG - 2021-07-18 06:38:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:38:16 --> Input Class Initialized
INFO - 2021-07-18 06:38:16 --> Language Class Initialized
ERROR - 2021-07-18 06:38:16 --> 404 Page Not Found: Examples/index.html
ERROR - 2021-07-18 06:38:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:38:17 --> Config Class Initialized
INFO - 2021-07-18 06:38:17 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:38:17 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:38:17 --> Utf8 Class Initialized
INFO - 2021-07-18 06:38:17 --> URI Class Initialized
INFO - 2021-07-18 06:38:17 --> Router Class Initialized
INFO - 2021-07-18 06:38:17 --> Output Class Initialized
INFO - 2021-07-18 06:38:17 --> Security Class Initialized
DEBUG - 2021-07-18 06:38:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:38:17 --> Input Class Initialized
INFO - 2021-07-18 06:38:17 --> Language Class Initialized
ERROR - 2021-07-18 06:38:17 --> 404 Page Not Found: Examples/file-manager.html
ERROR - 2021-07-18 06:38:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:38:17 --> Config Class Initialized
INFO - 2021-07-18 06:38:17 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:38:17 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:38:17 --> Utf8 Class Initialized
INFO - 2021-07-18 06:38:17 --> URI Class Initialized
INFO - 2021-07-18 06:38:17 --> Router Class Initialized
INFO - 2021-07-18 06:38:17 --> Output Class Initialized
INFO - 2021-07-18 06:38:17 --> Security Class Initialized
DEBUG - 2021-07-18 06:38:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:38:17 --> Input Class Initialized
INFO - 2021-07-18 06:38:17 --> Language Class Initialized
ERROR - 2021-07-18 06:38:17 --> 404 Page Not Found: Plugins/filemanager
ERROR - 2021-07-18 06:38:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:38:17 --> Config Class Initialized
INFO - 2021-07-18 06:38:17 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:38:17 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:38:17 --> Utf8 Class Initialized
INFO - 2021-07-18 06:38:17 --> URI Class Initialized
INFO - 2021-07-18 06:38:17 --> Router Class Initialized
INFO - 2021-07-18 06:38:17 --> Output Class Initialized
INFO - 2021-07-18 06:38:17 --> Security Class Initialized
DEBUG - 2021-07-18 06:38:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:38:17 --> Input Class Initialized
INFO - 2021-07-18 06:38:17 --> Language Class Initialized
ERROR - 2021-07-18 06:38:17 --> 404 Page Not Found: Plugins/anchor
ERROR - 2021-07-18 06:38:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:38:18 --> Config Class Initialized
INFO - 2021-07-18 06:38:18 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:38:18 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:38:18 --> Utf8 Class Initialized
INFO - 2021-07-18 06:38:18 --> URI Class Initialized
INFO - 2021-07-18 06:38:18 --> Router Class Initialized
INFO - 2021-07-18 06:38:18 --> Output Class Initialized
INFO - 2021-07-18 06:38:18 --> Security Class Initialized
DEBUG - 2021-07-18 06:38:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:38:18 --> Input Class Initialized
INFO - 2021-07-18 06:38:18 --> Language Class Initialized
ERROR - 2021-07-18 06:38:18 --> 404 Page Not Found: Aspnet/README.txt
ERROR - 2021-07-18 06:38:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:38:18 --> Config Class Initialized
INFO - 2021-07-18 06:38:18 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:38:18 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:38:18 --> Utf8 Class Initialized
INFO - 2021-07-18 06:38:18 --> URI Class Initialized
INFO - 2021-07-18 06:38:18 --> Router Class Initialized
INFO - 2021-07-18 06:38:18 --> Output Class Initialized
INFO - 2021-07-18 06:38:18 --> Security Class Initialized
DEBUG - 2021-07-18 06:38:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:38:18 --> Input Class Initialized
INFO - 2021-07-18 06:38:18 --> Language Class Initialized
ERROR - 2021-07-18 06:38:18 --> 404 Page Not Found: Examples/readonly.html
ERROR - 2021-07-18 06:38:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:38:19 --> Config Class Initialized
INFO - 2021-07-18 06:38:19 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:38:19 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:38:19 --> Utf8 Class Initialized
INFO - 2021-07-18 06:38:19 --> URI Class Initialized
INFO - 2021-07-18 06:38:19 --> Router Class Initialized
INFO - 2021-07-18 06:38:19 --> Output Class Initialized
INFO - 2021-07-18 06:38:19 --> Security Class Initialized
DEBUG - 2021-07-18 06:38:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:38:19 --> Input Class Initialized
INFO - 2021-07-18 06:38:19 --> Language Class Initialized
ERROR - 2021-07-18 06:38:19 --> 404 Page Not Found: Media/com_hikashop
ERROR - 2021-07-18 06:38:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:38:19 --> Config Class Initialized
INFO - 2021-07-18 06:38:19 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:38:19 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:38:19 --> Utf8 Class Initialized
INFO - 2021-07-18 06:38:19 --> URI Class Initialized
INFO - 2021-07-18 06:38:19 --> Router Class Initialized
INFO - 2021-07-18 06:38:19 --> Output Class Initialized
INFO - 2021-07-18 06:38:19 --> Security Class Initialized
DEBUG - 2021-07-18 06:38:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:38:19 --> Input Class Initialized
INFO - 2021-07-18 06:38:19 --> Language Class Initialized
ERROR - 2021-07-18 06:38:19 --> 404 Page Not Found: Templates/jsn_glass_pro
ERROR - 2021-07-18 06:38:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:38:19 --> Config Class Initialized
INFO - 2021-07-18 06:38:19 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:38:19 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:38:19 --> Utf8 Class Initialized
INFO - 2021-07-18 06:38:19 --> URI Class Initialized
INFO - 2021-07-18 06:38:19 --> Router Class Initialized
INFO - 2021-07-18 06:38:19 --> Output Class Initialized
INFO - 2021-07-18 06:38:19 --> Security Class Initialized
DEBUG - 2021-07-18 06:38:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:38:19 --> Input Class Initialized
INFO - 2021-07-18 06:38:19 --> Language Class Initialized
ERROR - 2021-07-18 06:38:19 --> 404 Page Not Found: Script/valid_formdata.js
ERROR - 2021-07-18 06:38:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:38:20 --> Config Class Initialized
INFO - 2021-07-18 06:38:20 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:38:20 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:38:20 --> Utf8 Class Initialized
INFO - 2021-07-18 06:38:20 --> URI Class Initialized
INFO - 2021-07-18 06:38:20 --> Router Class Initialized
INFO - 2021-07-18 06:38:20 --> Output Class Initialized
INFO - 2021-07-18 06:38:20 --> Security Class Initialized
DEBUG - 2021-07-18 06:38:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:38:20 --> Input Class Initialized
INFO - 2021-07-18 06:38:20 --> Language Class Initialized
ERROR - 2021-07-18 06:38:20 --> 404 Page Not Found: DeptWebsiteActiondo/index
ERROR - 2021-07-18 06:38:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:38:21 --> Config Class Initialized
INFO - 2021-07-18 06:38:21 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:38:21 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:38:21 --> Utf8 Class Initialized
INFO - 2021-07-18 06:38:21 --> URI Class Initialized
INFO - 2021-07-18 06:38:21 --> Router Class Initialized
INFO - 2021-07-18 06:38:21 --> Output Class Initialized
INFO - 2021-07-18 06:38:21 --> Security Class Initialized
DEBUG - 2021-07-18 06:38:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:38:21 --> Input Class Initialized
INFO - 2021-07-18 06:38:21 --> Language Class Initialized
ERROR - 2021-07-18 06:38:21 --> 404 Page Not Found: App/Tpl
ERROR - 2021-07-18 06:38:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:38:22 --> Config Class Initialized
INFO - 2021-07-18 06:38:22 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:38:22 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:38:22 --> Utf8 Class Initialized
INFO - 2021-07-18 06:38:22 --> URI Class Initialized
INFO - 2021-07-18 06:38:22 --> Router Class Initialized
INFO - 2021-07-18 06:38:22 --> Output Class Initialized
INFO - 2021-07-18 06:38:22 --> Security Class Initialized
DEBUG - 2021-07-18 06:38:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:38:22 --> Input Class Initialized
INFO - 2021-07-18 06:38:22 --> Language Class Initialized
ERROR - 2021-07-18 06:38:22 --> 404 Page Not Found: Scripts/jquery
ERROR - 2021-07-18 06:38:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:38:23 --> Config Class Initialized
INFO - 2021-07-18 06:38:23 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:38:23 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:38:23 --> Utf8 Class Initialized
INFO - 2021-07-18 06:38:23 --> URI Class Initialized
INFO - 2021-07-18 06:38:23 --> Router Class Initialized
INFO - 2021-07-18 06:38:23 --> Output Class Initialized
INFO - 2021-07-18 06:38:23 --> Security Class Initialized
DEBUG - 2021-07-18 06:38:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:38:23 --> Input Class Initialized
INFO - 2021-07-18 06:38:23 --> Language Class Initialized
ERROR - 2021-07-18 06:38:23 --> 404 Page Not Found: Public/js
ERROR - 2021-07-18 06:38:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:38:23 --> Config Class Initialized
INFO - 2021-07-18 06:38:23 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:38:23 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:38:23 --> Utf8 Class Initialized
INFO - 2021-07-18 06:38:23 --> URI Class Initialized
INFO - 2021-07-18 06:38:23 --> Router Class Initialized
INFO - 2021-07-18 06:38:23 --> Output Class Initialized
INFO - 2021-07-18 06:38:24 --> Security Class Initialized
DEBUG - 2021-07-18 06:38:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:38:24 --> Input Class Initialized
INFO - 2021-07-18 06:38:24 --> Language Class Initialized
ERROR - 2021-07-18 06:38:24 --> 404 Page Not Found: Themes/graphics
ERROR - 2021-07-18 06:38:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:38:24 --> Config Class Initialized
INFO - 2021-07-18 06:38:24 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:38:24 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:38:24 --> Utf8 Class Initialized
INFO - 2021-07-18 06:38:24 --> URI Class Initialized
INFO - 2021-07-18 06:38:24 --> Router Class Initialized
INFO - 2021-07-18 06:38:24 --> Output Class Initialized
INFO - 2021-07-18 06:38:24 --> Security Class Initialized
DEBUG - 2021-07-18 06:38:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:38:24 --> Input Class Initialized
INFO - 2021-07-18 06:38:24 --> Language Class Initialized
ERROR - 2021-07-18 06:38:24 --> 404 Page Not Found: Themes/default
ERROR - 2021-07-18 06:38:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:38:25 --> Config Class Initialized
INFO - 2021-07-18 06:38:25 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:38:25 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:38:25 --> Utf8 Class Initialized
INFO - 2021-07-18 06:38:25 --> URI Class Initialized
INFO - 2021-07-18 06:38:25 --> Router Class Initialized
INFO - 2021-07-18 06:38:25 --> Output Class Initialized
INFO - 2021-07-18 06:38:25 --> Security Class Initialized
DEBUG - 2021-07-18 06:38:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:38:25 --> Input Class Initialized
INFO - 2021-07-18 06:38:25 --> Language Class Initialized
ERROR - 2021-07-18 06:38:25 --> 404 Page Not Found: Themes/default
ERROR - 2021-07-18 06:38:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:38:25 --> Config Class Initialized
INFO - 2021-07-18 06:38:25 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:38:25 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:38:25 --> Utf8 Class Initialized
INFO - 2021-07-18 06:38:25 --> URI Class Initialized
INFO - 2021-07-18 06:38:25 --> Router Class Initialized
INFO - 2021-07-18 06:38:25 --> Output Class Initialized
INFO - 2021-07-18 06:38:25 --> Security Class Initialized
DEBUG - 2021-07-18 06:38:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:38:25 --> Input Class Initialized
INFO - 2021-07-18 06:38:25 --> Language Class Initialized
ERROR - 2021-07-18 06:38:25 --> 404 Page Not Found: Help/user
ERROR - 2021-07-18 06:38:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:38:25 --> Config Class Initialized
INFO - 2021-07-18 06:38:25 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:38:25 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:38:25 --> Utf8 Class Initialized
INFO - 2021-07-18 06:38:25 --> URI Class Initialized
INFO - 2021-07-18 06:38:25 --> Router Class Initialized
INFO - 2021-07-18 06:38:25 --> Output Class Initialized
INFO - 2021-07-18 06:38:25 --> Security Class Initialized
DEBUG - 2021-07-18 06:38:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:38:25 --> Input Class Initialized
INFO - 2021-07-18 06:38:25 --> Language Class Initialized
ERROR - 2021-07-18 06:38:25 --> 404 Page Not Found: User/Login.aspx
ERROR - 2021-07-18 06:38:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:38:26 --> Config Class Initialized
INFO - 2021-07-18 06:38:26 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:38:26 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:38:26 --> Utf8 Class Initialized
INFO - 2021-07-18 06:38:26 --> URI Class Initialized
INFO - 2021-07-18 06:38:26 --> Router Class Initialized
INFO - 2021-07-18 06:38:26 --> Output Class Initialized
INFO - 2021-07-18 06:38:26 --> Security Class Initialized
DEBUG - 2021-07-18 06:38:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:38:26 --> Input Class Initialized
INFO - 2021-07-18 06:38:26 --> Language Class Initialized
ERROR - 2021-07-18 06:38:26 --> 404 Page Not Found: API/DW
ERROR - 2021-07-18 06:38:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:38:26 --> Config Class Initialized
INFO - 2021-07-18 06:38:26 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:38:26 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:38:26 --> Utf8 Class Initialized
INFO - 2021-07-18 06:38:26 --> URI Class Initialized
INFO - 2021-07-18 06:38:26 --> Router Class Initialized
INFO - 2021-07-18 06:38:26 --> Output Class Initialized
INFO - 2021-07-18 06:38:26 --> Security Class Initialized
DEBUG - 2021-07-18 06:38:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:38:26 --> Input Class Initialized
INFO - 2021-07-18 06:38:26 --> Language Class Initialized
ERROR - 2021-07-18 06:38:26 --> 404 Page Not Found: API/DW
ERROR - 2021-07-18 06:38:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:38:27 --> Config Class Initialized
INFO - 2021-07-18 06:38:27 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:38:27 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:38:27 --> Utf8 Class Initialized
INFO - 2021-07-18 06:38:27 --> URI Class Initialized
INFO - 2021-07-18 06:38:27 --> Router Class Initialized
INFO - 2021-07-18 06:38:27 --> Output Class Initialized
INFO - 2021-07-18 06:38:27 --> Security Class Initialized
DEBUG - 2021-07-18 06:38:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:38:27 --> Input Class Initialized
INFO - 2021-07-18 06:38:27 --> Language Class Initialized
ERROR - 2021-07-18 06:38:27 --> 404 Page Not Found: API/DW
ERROR - 2021-07-18 06:38:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:38:27 --> Config Class Initialized
INFO - 2021-07-18 06:38:27 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:38:27 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:38:27 --> Utf8 Class Initialized
INFO - 2021-07-18 06:38:27 --> URI Class Initialized
INFO - 2021-07-18 06:38:27 --> Router Class Initialized
INFO - 2021-07-18 06:38:27 --> Output Class Initialized
INFO - 2021-07-18 06:38:27 --> Security Class Initialized
DEBUG - 2021-07-18 06:38:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:38:27 --> Input Class Initialized
INFO - 2021-07-18 06:38:27 --> Language Class Initialized
ERROR - 2021-07-18 06:38:27 --> 404 Page Not Found: Admin/Common
ERROR - 2021-07-18 06:38:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:38:27 --> Config Class Initialized
INFO - 2021-07-18 06:38:27 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:38:27 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:38:27 --> Utf8 Class Initialized
INFO - 2021-07-18 06:38:27 --> URI Class Initialized
INFO - 2021-07-18 06:38:27 --> Router Class Initialized
INFO - 2021-07-18 06:38:27 --> Output Class Initialized
INFO - 2021-07-18 06:38:27 --> Security Class Initialized
DEBUG - 2021-07-18 06:38:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:38:27 --> Input Class Initialized
INFO - 2021-07-18 06:38:27 --> Language Class Initialized
ERROR - 2021-07-18 06:38:27 --> 404 Page Not Found: API/DW
ERROR - 2021-07-18 06:38:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:38:28 --> Config Class Initialized
INFO - 2021-07-18 06:38:28 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:38:28 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:38:28 --> Utf8 Class Initialized
INFO - 2021-07-18 06:38:28 --> URI Class Initialized
INFO - 2021-07-18 06:38:28 --> Router Class Initialized
INFO - 2021-07-18 06:38:28 --> Output Class Initialized
INFO - 2021-07-18 06:38:28 --> Security Class Initialized
DEBUG - 2021-07-18 06:38:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:38:28 --> Input Class Initialized
INFO - 2021-07-18 06:38:28 --> Language Class Initialized
ERROR - 2021-07-18 06:38:28 --> 404 Page Not Found: API/DW
ERROR - 2021-07-18 06:38:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:38:28 --> Config Class Initialized
INFO - 2021-07-18 06:38:28 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:38:28 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:38:28 --> Utf8 Class Initialized
INFO - 2021-07-18 06:38:28 --> URI Class Initialized
INFO - 2021-07-18 06:38:28 --> Router Class Initialized
INFO - 2021-07-18 06:38:28 --> Output Class Initialized
INFO - 2021-07-18 06:38:28 --> Security Class Initialized
DEBUG - 2021-07-18 06:38:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:38:28 --> Input Class Initialized
INFO - 2021-07-18 06:38:28 --> Language Class Initialized
ERROR - 2021-07-18 06:38:28 --> 404 Page Not Found: Admin/Login.aspx
ERROR - 2021-07-18 06:38:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:38:29 --> Config Class Initialized
INFO - 2021-07-18 06:38:29 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:38:29 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:38:29 --> Utf8 Class Initialized
INFO - 2021-07-18 06:38:29 --> URI Class Initialized
INFO - 2021-07-18 06:38:29 --> Router Class Initialized
INFO - 2021-07-18 06:38:29 --> Output Class Initialized
INFO - 2021-07-18 06:38:29 --> Security Class Initialized
DEBUG - 2021-07-18 06:38:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:38:29 --> Input Class Initialized
INFO - 2021-07-18 06:38:29 --> Language Class Initialized
ERROR - 2021-07-18 06:38:29 --> 404 Page Not Found: Admin/Images
ERROR - 2021-07-18 06:38:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:38:29 --> Config Class Initialized
INFO - 2021-07-18 06:38:29 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:38:29 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:38:29 --> Utf8 Class Initialized
INFO - 2021-07-18 06:38:29 --> URI Class Initialized
INFO - 2021-07-18 06:38:29 --> Router Class Initialized
INFO - 2021-07-18 06:38:29 --> Output Class Initialized
INFO - 2021-07-18 06:38:29 --> Security Class Initialized
DEBUG - 2021-07-18 06:38:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:38:29 --> Input Class Initialized
INFO - 2021-07-18 06:38:29 --> Language Class Initialized
ERROR - 2021-07-18 06:38:29 --> 404 Page Not Found: Template/Default
ERROR - 2021-07-18 06:38:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:38:29 --> Config Class Initialized
INFO - 2021-07-18 06:38:29 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:38:29 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:38:29 --> Utf8 Class Initialized
INFO - 2021-07-18 06:38:29 --> URI Class Initialized
INFO - 2021-07-18 06:38:29 --> Router Class Initialized
INFO - 2021-07-18 06:38:29 --> Output Class Initialized
INFO - 2021-07-18 06:38:29 --> Security Class Initialized
DEBUG - 2021-07-18 06:38:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:38:29 --> Input Class Initialized
INFO - 2021-07-18 06:38:29 --> Language Class Initialized
ERROR - 2021-07-18 06:38:29 --> 404 Page Not Found: Prompt/images
ERROR - 2021-07-18 06:38:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:38:32 --> Config Class Initialized
INFO - 2021-07-18 06:38:32 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:38:32 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:38:32 --> Utf8 Class Initialized
INFO - 2021-07-18 06:38:32 --> URI Class Initialized
INFO - 2021-07-18 06:38:32 --> Router Class Initialized
INFO - 2021-07-18 06:38:32 --> Output Class Initialized
INFO - 2021-07-18 06:38:32 --> Security Class Initialized
DEBUG - 2021-07-18 06:38:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:38:32 --> Input Class Initialized
INFO - 2021-07-18 06:38:32 --> Language Class Initialized
ERROR - 2021-07-18 06:38:32 --> 404 Page Not Found: Admin/Images
ERROR - 2021-07-18 06:38:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:38:33 --> Config Class Initialized
INFO - 2021-07-18 06:38:33 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:38:33 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:38:33 --> Utf8 Class Initialized
INFO - 2021-07-18 06:38:33 --> URI Class Initialized
INFO - 2021-07-18 06:38:33 --> Router Class Initialized
INFO - 2021-07-18 06:38:33 --> Output Class Initialized
INFO - 2021-07-18 06:38:33 --> Security Class Initialized
DEBUG - 2021-07-18 06:38:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:38:33 --> Input Class Initialized
INFO - 2021-07-18 06:38:33 --> Language Class Initialized
ERROR - 2021-07-18 06:38:33 --> 404 Page Not Found: Style/default
ERROR - 2021-07-18 06:38:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:38:33 --> Config Class Initialized
INFO - 2021-07-18 06:38:33 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:38:33 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:38:33 --> Utf8 Class Initialized
INFO - 2021-07-18 06:38:33 --> URI Class Initialized
INFO - 2021-07-18 06:38:33 --> Router Class Initialized
INFO - 2021-07-18 06:38:33 --> Output Class Initialized
INFO - 2021-07-18 06:38:33 --> Security Class Initialized
DEBUG - 2021-07-18 06:38:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:38:33 --> Input Class Initialized
INFO - 2021-07-18 06:38:33 --> Language Class Initialized
ERROR - 2021-07-18 06:38:33 --> 404 Page Not Found: Dokuphp/index
ERROR - 2021-07-18 06:38:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:38:34 --> Config Class Initialized
INFO - 2021-07-18 06:38:34 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:38:34 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:38:34 --> Utf8 Class Initialized
INFO - 2021-07-18 06:38:34 --> URI Class Initialized
INFO - 2021-07-18 06:38:34 --> Router Class Initialized
INFO - 2021-07-18 06:38:34 --> Output Class Initialized
INFO - 2021-07-18 06:38:34 --> Security Class Initialized
DEBUG - 2021-07-18 06:38:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:38:34 --> Input Class Initialized
INFO - 2021-07-18 06:38:34 --> Language Class Initialized
ERROR - 2021-07-18 06:38:34 --> 404 Page Not Found: Forums/list.page
ERROR - 2021-07-18 06:38:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:38:34 --> Config Class Initialized
INFO - 2021-07-18 06:38:34 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:38:34 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:38:34 --> Utf8 Class Initialized
INFO - 2021-07-18 06:38:34 --> URI Class Initialized
INFO - 2021-07-18 06:38:34 --> Router Class Initialized
INFO - 2021-07-18 06:38:34 --> Output Class Initialized
INFO - 2021-07-18 06:38:34 --> Security Class Initialized
DEBUG - 2021-07-18 06:38:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:38:34 --> Input Class Initialized
INFO - 2021-07-18 06:38:34 --> Language Class Initialized
ERROR - 2021-07-18 06:38:34 --> 404 Page Not Found: Whir_system/login.aspx
ERROR - 2021-07-18 06:38:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:38:35 --> Config Class Initialized
INFO - 2021-07-18 06:38:35 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:38:35 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:38:35 --> Utf8 Class Initialized
INFO - 2021-07-18 06:38:35 --> URI Class Initialized
INFO - 2021-07-18 06:38:35 --> Router Class Initialized
INFO - 2021-07-18 06:38:35 --> Output Class Initialized
INFO - 2021-07-18 06:38:35 --> Security Class Initialized
DEBUG - 2021-07-18 06:38:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:38:35 --> Input Class Initialized
INFO - 2021-07-18 06:38:35 --> Language Class Initialized
ERROR - 2021-07-18 06:38:35 --> 404 Page Not Found: Whir_system/module
ERROR - 2021-07-18 06:38:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:38:35 --> Config Class Initialized
INFO - 2021-07-18 06:38:35 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:38:35 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:38:35 --> Utf8 Class Initialized
INFO - 2021-07-18 06:38:35 --> URI Class Initialized
INFO - 2021-07-18 06:38:35 --> Router Class Initialized
INFO - 2021-07-18 06:38:35 --> Output Class Initialized
INFO - 2021-07-18 06:38:35 --> Security Class Initialized
DEBUG - 2021-07-18 06:38:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:38:35 --> Input Class Initialized
INFO - 2021-07-18 06:38:35 --> Language Class Initialized
ERROR - 2021-07-18 06:38:35 --> 404 Page Not Found: Stylesheetcss/index
ERROR - 2021-07-18 06:38:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:38:36 --> Config Class Initialized
INFO - 2021-07-18 06:38:36 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:38:36 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:38:36 --> Utf8 Class Initialized
INFO - 2021-07-18 06:38:36 --> URI Class Initialized
INFO - 2021-07-18 06:38:36 --> Router Class Initialized
INFO - 2021-07-18 06:38:36 --> Output Class Initialized
INFO - 2021-07-18 06:38:36 --> Security Class Initialized
DEBUG - 2021-07-18 06:38:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:38:36 --> Input Class Initialized
INFO - 2021-07-18 06:38:36 --> Language Class Initialized
ERROR - 2021-07-18 06:38:36 --> 404 Page Not Found: Includes/general.js
ERROR - 2021-07-18 06:38:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:38:36 --> Config Class Initialized
INFO - 2021-07-18 06:38:36 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:38:36 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:38:36 --> Utf8 Class Initialized
INFO - 2021-07-18 06:38:36 --> URI Class Initialized
INFO - 2021-07-18 06:38:36 --> Router Class Initialized
INFO - 2021-07-18 06:38:36 --> Output Class Initialized
INFO - 2021-07-18 06:38:36 --> Security Class Initialized
DEBUG - 2021-07-18 06:38:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:38:36 --> Input Class Initialized
INFO - 2021-07-18 06:38:36 --> Language Class Initialized
ERROR - 2021-07-18 06:38:36 --> 404 Page Not Found: Rssphp/index
ERROR - 2021-07-18 06:38:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:38:37 --> Config Class Initialized
INFO - 2021-07-18 06:38:37 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:38:37 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:38:37 --> Utf8 Class Initialized
INFO - 2021-07-18 06:38:37 --> URI Class Initialized
INFO - 2021-07-18 06:38:37 --> Router Class Initialized
INFO - 2021-07-18 06:38:37 --> Output Class Initialized
INFO - 2021-07-18 06:38:37 --> Security Class Initialized
DEBUG - 2021-07-18 06:38:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:38:37 --> Input Class Initialized
INFO - 2021-07-18 06:38:37 --> Language Class Initialized
ERROR - 2021-07-18 06:38:37 --> 404 Page Not Found: Archiver/index
ERROR - 2021-07-18 06:38:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:38:38 --> Config Class Initialized
INFO - 2021-07-18 06:38:38 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:38:38 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:38:38 --> Utf8 Class Initialized
INFO - 2021-07-18 06:38:38 --> URI Class Initialized
INFO - 2021-07-18 06:38:38 --> Router Class Initialized
INFO - 2021-07-18 06:38:38 --> Output Class Initialized
INFO - 2021-07-18 06:38:38 --> Security Class Initialized
DEBUG - 2021-07-18 06:38:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:38:38 --> Input Class Initialized
INFO - 2021-07-18 06:38:38 --> Language Class Initialized
ERROR - 2021-07-18 06:38:38 --> 404 Page Not Found: Tools/rss.aspx
ERROR - 2021-07-18 06:38:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:38:38 --> Config Class Initialized
INFO - 2021-07-18 06:38:38 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:38:38 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:38:38 --> Utf8 Class Initialized
INFO - 2021-07-18 06:38:38 --> URI Class Initialized
INFO - 2021-07-18 06:38:38 --> Router Class Initialized
INFO - 2021-07-18 06:38:38 --> Output Class Initialized
INFO - 2021-07-18 06:38:38 --> Security Class Initialized
DEBUG - 2021-07-18 06:38:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:38:38 --> Input Class Initialized
INFO - 2021-07-18 06:38:38 --> Language Class Initialized
ERROR - 2021-07-18 06:38:38 --> 404 Page Not Found: Inc/rsd.php
ERROR - 2021-07-18 06:38:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:38:38 --> Config Class Initialized
INFO - 2021-07-18 06:38:38 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:38:38 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:38:38 --> Utf8 Class Initialized
INFO - 2021-07-18 06:38:38 --> URI Class Initialized
INFO - 2021-07-18 06:38:38 --> Router Class Initialized
INFO - 2021-07-18 06:38:38 --> Output Class Initialized
INFO - 2021-07-18 06:38:38 --> Security Class Initialized
DEBUG - 2021-07-18 06:38:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:38:38 --> Input Class Initialized
INFO - 2021-07-18 06:38:38 --> Language Class Initialized
ERROR - 2021-07-18 06:38:38 --> 404 Page Not Found: Archive/archive.css
ERROR - 2021-07-18 06:38:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:38:39 --> Config Class Initialized
INFO - 2021-07-18 06:38:39 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:38:39 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:38:39 --> Utf8 Class Initialized
INFO - 2021-07-18 06:38:39 --> URI Class Initialized
INFO - 2021-07-18 06:38:39 --> Router Class Initialized
INFO - 2021-07-18 06:38:39 --> Output Class Initialized
INFO - 2021-07-18 06:38:39 --> Security Class Initialized
DEBUG - 2021-07-18 06:38:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:38:39 --> Input Class Initialized
INFO - 2021-07-18 06:38:39 --> Language Class Initialized
ERROR - 2021-07-18 06:38:39 --> 404 Page Not Found: Clientscript/vbulletin_ajax_htmlloader.js
ERROR - 2021-07-18 06:38:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:38:39 --> Config Class Initialized
INFO - 2021-07-18 06:38:39 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:38:39 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:38:39 --> Utf8 Class Initialized
INFO - 2021-07-18 06:38:39 --> URI Class Initialized
INFO - 2021-07-18 06:38:39 --> Router Class Initialized
INFO - 2021-07-18 06:38:39 --> Output Class Initialized
INFO - 2021-07-18 06:38:39 --> Security Class Initialized
DEBUG - 2021-07-18 06:38:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:38:39 --> Input Class Initialized
INFO - 2021-07-18 06:38:39 --> Language Class Initialized
ERROR - 2021-07-18 06:38:39 --> 404 Page Not Found: Adminsoft/templates
ERROR - 2021-07-18 06:38:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:38:40 --> Config Class Initialized
INFO - 2021-07-18 06:38:40 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:38:40 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:38:40 --> Utf8 Class Initialized
INFO - 2021-07-18 06:38:40 --> URI Class Initialized
INFO - 2021-07-18 06:38:40 --> Router Class Initialized
INFO - 2021-07-18 06:38:40 --> Output Class Initialized
INFO - 2021-07-18 06:38:40 --> Security Class Initialized
DEBUG - 2021-07-18 06:38:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:38:40 --> Input Class Initialized
INFO - 2021-07-18 06:38:40 --> Language Class Initialized
ERROR - 2021-07-18 06:38:40 --> 404 Page Not Found: Feedasp/index
ERROR - 2021-07-18 06:38:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:38:40 --> Config Class Initialized
INFO - 2021-07-18 06:38:40 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:38:40 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:38:40 --> Utf8 Class Initialized
INFO - 2021-07-18 06:38:40 --> URI Class Initialized
INFO - 2021-07-18 06:38:40 --> Router Class Initialized
INFO - 2021-07-18 06:38:40 --> Output Class Initialized
INFO - 2021-07-18 06:38:40 --> Security Class Initialized
DEBUG - 2021-07-18 06:38:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:38:40 --> Input Class Initialized
INFO - 2021-07-18 06:38:40 --> Language Class Initialized
ERROR - 2021-07-18 06:38:40 --> 404 Page Not Found: Ntalker/lawfirm.aspx
ERROR - 2021-07-18 06:38:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:38:40 --> Config Class Initialized
INFO - 2021-07-18 06:38:40 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:38:40 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:38:40 --> Utf8 Class Initialized
INFO - 2021-07-18 06:38:40 --> URI Class Initialized
INFO - 2021-07-18 06:38:40 --> Router Class Initialized
INFO - 2021-07-18 06:38:40 --> Output Class Initialized
INFO - 2021-07-18 06:38:40 --> Security Class Initialized
DEBUG - 2021-07-18 06:38:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:38:40 --> Input Class Initialized
INFO - 2021-07-18 06:38:40 --> Language Class Initialized
ERROR - 2021-07-18 06:38:40 --> 404 Page Not Found: Searchhtml/index
ERROR - 2021-07-18 06:38:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:38:41 --> Config Class Initialized
INFO - 2021-07-18 06:38:41 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:38:41 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:38:41 --> Utf8 Class Initialized
INFO - 2021-07-18 06:38:41 --> URI Class Initialized
INFO - 2021-07-18 06:38:41 --> Router Class Initialized
INFO - 2021-07-18 06:38:41 --> Output Class Initialized
INFO - 2021-07-18 06:38:41 --> Security Class Initialized
DEBUG - 2021-07-18 06:38:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:38:41 --> Input Class Initialized
INFO - 2021-07-18 06:38:41 --> Language Class Initialized
ERROR - 2021-07-18 06:38:41 --> 404 Page Not Found: Historytxt/index
ERROR - 2021-07-18 06:38:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:38:41 --> Config Class Initialized
INFO - 2021-07-18 06:38:41 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:38:41 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:38:41 --> Utf8 Class Initialized
INFO - 2021-07-18 06:38:41 --> URI Class Initialized
INFO - 2021-07-18 06:38:41 --> Router Class Initialized
INFO - 2021-07-18 06:38:41 --> Output Class Initialized
INFO - 2021-07-18 06:38:41 --> Security Class Initialized
DEBUG - 2021-07-18 06:38:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:38:41 --> Input Class Initialized
INFO - 2021-07-18 06:38:41 --> Language Class Initialized
ERROR - 2021-07-18 06:38:41 --> 404 Page Not Found: Common/common.js
ERROR - 2021-07-18 06:38:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:38:41 --> Config Class Initialized
INFO - 2021-07-18 06:38:41 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:38:41 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:38:41 --> Utf8 Class Initialized
INFO - 2021-07-18 06:38:41 --> URI Class Initialized
INFO - 2021-07-18 06:38:41 --> Router Class Initialized
INFO - 2021-07-18 06:38:41 --> Output Class Initialized
INFO - 2021-07-18 06:38:41 --> Security Class Initialized
DEBUG - 2021-07-18 06:38:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:38:41 --> Input Class Initialized
INFO - 2021-07-18 06:38:41 --> Language Class Initialized
ERROR - 2021-07-18 06:38:41 --> 404 Page Not Found: 404jpg/index
ERROR - 2021-07-18 06:38:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:38:42 --> Config Class Initialized
INFO - 2021-07-18 06:38:42 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:38:42 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:38:42 --> Utf8 Class Initialized
INFO - 2021-07-18 06:38:42 --> URI Class Initialized
INFO - 2021-07-18 06:38:42 --> Router Class Initialized
INFO - 2021-07-18 06:38:42 --> Output Class Initialized
INFO - 2021-07-18 06:38:42 --> Security Class Initialized
DEBUG - 2021-07-18 06:38:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:38:42 --> Input Class Initialized
INFO - 2021-07-18 06:38:42 --> Language Class Initialized
ERROR - 2021-07-18 06:38:42 --> 404 Page Not Found: Inc/Templates
ERROR - 2021-07-18 06:38:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:38:42 --> Config Class Initialized
INFO - 2021-07-18 06:38:42 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:38:42 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:38:42 --> Utf8 Class Initialized
INFO - 2021-07-18 06:38:42 --> URI Class Initialized
INFO - 2021-07-18 06:38:42 --> Router Class Initialized
INFO - 2021-07-18 06:38:42 --> Output Class Initialized
INFO - 2021-07-18 06:38:42 --> Security Class Initialized
DEBUG - 2021-07-18 06:38:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:38:42 --> Input Class Initialized
INFO - 2021-07-18 06:38:42 --> Language Class Initialized
ERROR - 2021-07-18 06:38:42 --> 404 Page Not Found: Externphp/index
ERROR - 2021-07-18 06:38:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:38:43 --> Config Class Initialized
INFO - 2021-07-18 06:38:43 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:38:43 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:38:43 --> Utf8 Class Initialized
INFO - 2021-07-18 06:38:43 --> URI Class Initialized
INFO - 2021-07-18 06:38:43 --> Router Class Initialized
INFO - 2021-07-18 06:38:43 --> Output Class Initialized
INFO - 2021-07-18 06:38:43 --> Security Class Initialized
DEBUG - 2021-07-18 06:38:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:38:43 --> Input Class Initialized
INFO - 2021-07-18 06:38:43 --> Language Class Initialized
ERROR - 2021-07-18 06:38:43 --> 404 Page Not Found: Jcms/index.jsp
ERROR - 2021-07-18 06:38:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:38:43 --> Config Class Initialized
INFO - 2021-07-18 06:38:43 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:38:43 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:38:43 --> Utf8 Class Initialized
INFO - 2021-07-18 06:38:43 --> URI Class Initialized
INFO - 2021-07-18 06:38:43 --> Router Class Initialized
INFO - 2021-07-18 06:38:43 --> Output Class Initialized
INFO - 2021-07-18 06:38:43 --> Security Class Initialized
DEBUG - 2021-07-18 06:38:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:38:43 --> Input Class Initialized
INFO - 2021-07-18 06:38:43 --> Language Class Initialized
ERROR - 2021-07-18 06:38:43 --> 404 Page Not Found: Jcms/index_jcms.jsp
ERROR - 2021-07-18 06:38:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:38:43 --> Config Class Initialized
INFO - 2021-07-18 06:38:43 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:38:43 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:38:43 --> Utf8 Class Initialized
INFO - 2021-07-18 06:38:43 --> URI Class Initialized
INFO - 2021-07-18 06:38:43 --> Router Class Initialized
INFO - 2021-07-18 06:38:43 --> Output Class Initialized
INFO - 2021-07-18 06:38:43 --> Security Class Initialized
DEBUG - 2021-07-18 06:38:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:38:43 --> Input Class Initialized
INFO - 2021-07-18 06:38:43 --> Language Class Initialized
ERROR - 2021-07-18 06:38:43 --> 404 Page Not Found: Ks_inc/ajax.js
ERROR - 2021-07-18 06:38:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:38:44 --> Config Class Initialized
INFO - 2021-07-18 06:38:44 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:38:44 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:38:44 --> Utf8 Class Initialized
INFO - 2021-07-18 06:38:44 --> URI Class Initialized
INFO - 2021-07-18 06:38:44 --> Router Class Initialized
INFO - 2021-07-18 06:38:44 --> Output Class Initialized
INFO - 2021-07-18 06:38:44 --> Security Class Initialized
DEBUG - 2021-07-18 06:38:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:38:44 --> Input Class Initialized
INFO - 2021-07-18 06:38:44 --> Language Class Initialized
ERROR - 2021-07-18 06:38:44 --> 404 Page Not Found: Api/api_user.xml
ERROR - 2021-07-18 06:38:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:38:44 --> Config Class Initialized
INFO - 2021-07-18 06:38:44 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:38:44 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:38:44 --> Utf8 Class Initialized
INFO - 2021-07-18 06:38:44 --> URI Class Initialized
INFO - 2021-07-18 06:38:44 --> Router Class Initialized
INFO - 2021-07-18 06:38:44 --> Output Class Initialized
INFO - 2021-07-18 06:38:44 --> Security Class Initialized
DEBUG - 2021-07-18 06:38:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:38:44 --> Input Class Initialized
INFO - 2021-07-18 06:38:44 --> Language Class Initialized
ERROR - 2021-07-18 06:38:44 --> 404 Page Not Found: Static/hgicon.png
ERROR - 2021-07-18 06:38:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:38:44 --> Config Class Initialized
INFO - 2021-07-18 06:38:44 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:38:44 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:38:44 --> Utf8 Class Initialized
INFO - 2021-07-18 06:38:44 --> URI Class Initialized
INFO - 2021-07-18 06:38:44 --> Router Class Initialized
INFO - 2021-07-18 06:38:44 --> Output Class Initialized
INFO - 2021-07-18 06:38:44 --> Security Class Initialized
DEBUG - 2021-07-18 06:38:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:38:44 --> Input Class Initialized
INFO - 2021-07-18 06:38:44 --> Language Class Initialized
ERROR - 2021-07-18 06:38:44 --> 404 Page Not Found: Base/login
ERROR - 2021-07-18 06:38:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:38:45 --> Config Class Initialized
INFO - 2021-07-18 06:38:45 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:38:45 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:38:45 --> Utf8 Class Initialized
INFO - 2021-07-18 06:38:45 --> URI Class Initialized
INFO - 2021-07-18 06:38:45 --> Router Class Initialized
INFO - 2021-07-18 06:38:45 --> Output Class Initialized
INFO - 2021-07-18 06:38:45 --> Security Class Initialized
DEBUG - 2021-07-18 06:38:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:38:45 --> Input Class Initialized
INFO - 2021-07-18 06:38:45 --> Language Class Initialized
ERROR - 2021-07-18 06:38:45 --> 404 Page Not Found: Js/ajax_x.js
ERROR - 2021-07-18 06:38:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:38:45 --> Config Class Initialized
INFO - 2021-07-18 06:38:45 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:38:45 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:38:45 --> Utf8 Class Initialized
INFO - 2021-07-18 06:38:45 --> URI Class Initialized
INFO - 2021-07-18 06:38:45 --> Router Class Initialized
INFO - 2021-07-18 06:38:45 --> Output Class Initialized
INFO - 2021-07-18 06:38:45 --> Security Class Initialized
DEBUG - 2021-07-18 06:38:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:38:45 --> Input Class Initialized
INFO - 2021-07-18 06:38:45 --> Language Class Initialized
ERROR - 2021-07-18 06:38:45 --> 404 Page Not Found: Template/home.htm
ERROR - 2021-07-18 06:38:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:38:46 --> Config Class Initialized
INFO - 2021-07-18 06:38:46 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:38:46 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:38:46 --> Utf8 Class Initialized
INFO - 2021-07-18 06:38:46 --> URI Class Initialized
INFO - 2021-07-18 06:38:46 --> Router Class Initialized
INFO - 2021-07-18 06:38:46 --> Output Class Initialized
INFO - 2021-07-18 06:38:46 --> Security Class Initialized
DEBUG - 2021-07-18 06:38:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:38:46 --> Input Class Initialized
INFO - 2021-07-18 06:38:46 --> Language Class Initialized
ERROR - 2021-07-18 06:38:46 --> 404 Page Not Found: Rssaspx/index
ERROR - 2021-07-18 06:38:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:38:46 --> Config Class Initialized
INFO - 2021-07-18 06:38:46 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:38:46 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:38:46 --> Utf8 Class Initialized
INFO - 2021-07-18 06:38:46 --> URI Class Initialized
INFO - 2021-07-18 06:38:46 --> Router Class Initialized
INFO - 2021-07-18 06:38:46 --> Output Class Initialized
INFO - 2021-07-18 06:38:46 --> Security Class Initialized
DEBUG - 2021-07-18 06:38:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:38:46 --> Input Class Initialized
INFO - 2021-07-18 06:38:46 --> Language Class Initialized
ERROR - 2021-07-18 06:38:46 --> 404 Page Not Found: Max-templates/classic
ERROR - 2021-07-18 06:38:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:38:47 --> Config Class Initialized
INFO - 2021-07-18 06:38:47 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:38:47 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:38:47 --> Utf8 Class Initialized
INFO - 2021-07-18 06:38:47 --> URI Class Initialized
DEBUG - 2021-07-18 06:38:47 --> No URI present. Default controller set.
INFO - 2021-07-18 06:38:47 --> Router Class Initialized
INFO - 2021-07-18 06:38:47 --> Output Class Initialized
INFO - 2021-07-18 06:38:47 --> Security Class Initialized
DEBUG - 2021-07-18 06:38:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:38:47 --> Input Class Initialized
INFO - 2021-07-18 06:38:47 --> Language Class Initialized
INFO - 2021-07-18 06:38:47 --> Loader Class Initialized
INFO - 2021-07-18 06:38:47 --> Helper loaded: url_helper
INFO - 2021-07-18 06:38:47 --> Helper loaded: form_helper
INFO - 2021-07-18 06:38:47 --> Helper loaded: common_helper
INFO - 2021-07-18 06:38:47 --> Database Driver Class Initialized
DEBUG - 2021-07-18 06:38:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-18 06:38:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-18 06:38:47 --> Controller Class Initialized
INFO - 2021-07-18 06:38:47 --> Form Validation Class Initialized
DEBUG - 2021-07-18 06:38:47 --> Encrypt Class Initialized
DEBUG - 2021-07-18 06:38:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-07-18 06:38:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-07-18 06:38:47 --> Email Class Initialized
INFO - 2021-07-18 06:38:47 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-07-18 06:38:47 --> Calendar Class Initialized
INFO - 2021-07-18 06:38:47 --> Model "Login_model" initialized
INFO - 2021-07-18 06:38:47 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-07-18 06:38:47 --> Final output sent to browser
DEBUG - 2021-07-18 06:38:47 --> Total execution time: 0.0180
ERROR - 2021-07-18 06:38:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:38:48 --> Config Class Initialized
INFO - 2021-07-18 06:38:48 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:38:48 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:38:48 --> Utf8 Class Initialized
INFO - 2021-07-18 06:38:48 --> URI Class Initialized
INFO - 2021-07-18 06:38:48 --> Router Class Initialized
INFO - 2021-07-18 06:38:48 --> Output Class Initialized
INFO - 2021-07-18 06:38:48 --> Security Class Initialized
DEBUG - 2021-07-18 06:38:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:38:48 --> Input Class Initialized
INFO - 2021-07-18 06:38:48 --> Language Class Initialized
ERROR - 2021-07-18 06:38:48 --> 404 Page Not Found: Images/logo_product-cml.png
ERROR - 2021-07-18 06:38:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:38:48 --> Config Class Initialized
INFO - 2021-07-18 06:38:48 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:38:48 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:38:48 --> Utf8 Class Initialized
INFO - 2021-07-18 06:38:48 --> URI Class Initialized
INFO - 2021-07-18 06:38:48 --> Router Class Initialized
INFO - 2021-07-18 06:38:48 --> Output Class Initialized
INFO - 2021-07-18 06:38:48 --> Security Class Initialized
DEBUG - 2021-07-18 06:38:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:38:48 --> Input Class Initialized
INFO - 2021-07-18 06:38:48 --> Language Class Initialized
ERROR - 2021-07-18 06:38:48 --> 404 Page Not Found: Admin/index
ERROR - 2021-07-18 06:38:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:38:48 --> Config Class Initialized
INFO - 2021-07-18 06:38:48 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:38:48 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:38:48 --> Utf8 Class Initialized
INFO - 2021-07-18 06:38:48 --> URI Class Initialized
INFO - 2021-07-18 06:38:48 --> Router Class Initialized
INFO - 2021-07-18 06:38:48 --> Output Class Initialized
INFO - 2021-07-18 06:38:48 --> Security Class Initialized
DEBUG - 2021-07-18 06:38:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:38:48 --> Input Class Initialized
INFO - 2021-07-18 06:38:48 --> Language Class Initialized
ERROR - 2021-07-18 06:38:48 --> 404 Page Not Found: Plug/publish
ERROR - 2021-07-18 06:38:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:38:49 --> Config Class Initialized
INFO - 2021-07-18 06:38:49 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:38:49 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:38:49 --> Utf8 Class Initialized
INFO - 2021-07-18 06:38:49 --> URI Class Initialized
INFO - 2021-07-18 06:38:49 --> Router Class Initialized
INFO - 2021-07-18 06:38:49 --> Output Class Initialized
INFO - 2021-07-18 06:38:49 --> Security Class Initialized
DEBUG - 2021-07-18 06:38:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:38:49 --> Input Class Initialized
INFO - 2021-07-18 06:38:49 --> Language Class Initialized
ERROR - 2021-07-18 06:38:49 --> 404 Page Not Found: Admin/login.php
ERROR - 2021-07-18 06:38:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:38:49 --> Config Class Initialized
INFO - 2021-07-18 06:38:49 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:38:49 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:38:49 --> Utf8 Class Initialized
INFO - 2021-07-18 06:38:49 --> URI Class Initialized
INFO - 2021-07-18 06:38:49 --> Router Class Initialized
INFO - 2021-07-18 06:38:49 --> Output Class Initialized
INFO - 2021-07-18 06:38:49 --> Security Class Initialized
DEBUG - 2021-07-18 06:38:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:38:49 --> Input Class Initialized
INFO - 2021-07-18 06:38:49 --> Language Class Initialized
ERROR - 2021-07-18 06:38:49 --> 404 Page Not Found: Images/logo_88x31.gif
ERROR - 2021-07-18 06:38:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:38:49 --> Config Class Initialized
INFO - 2021-07-18 06:38:49 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:38:49 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:38:49 --> Utf8 Class Initialized
INFO - 2021-07-18 06:38:49 --> URI Class Initialized
INFO - 2021-07-18 06:38:49 --> Router Class Initialized
INFO - 2021-07-18 06:38:49 --> Output Class Initialized
INFO - 2021-07-18 06:38:49 --> Security Class Initialized
DEBUG - 2021-07-18 06:38:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:38:49 --> Input Class Initialized
INFO - 2021-07-18 06:38:49 --> Language Class Initialized
ERROR - 2021-07-18 06:38:49 --> 404 Page Not Found: Adminphp/index
ERROR - 2021-07-18 06:38:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:38:50 --> Config Class Initialized
INFO - 2021-07-18 06:38:50 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:38:50 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:38:50 --> Utf8 Class Initialized
INFO - 2021-07-18 06:38:50 --> URI Class Initialized
INFO - 2021-07-18 06:38:50 --> Router Class Initialized
INFO - 2021-07-18 06:38:50 --> Output Class Initialized
INFO - 2021-07-18 06:38:50 --> Security Class Initialized
DEBUG - 2021-07-18 06:38:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:38:50 --> Input Class Initialized
INFO - 2021-07-18 06:38:50 --> Language Class Initialized
ERROR - 2021-07-18 06:38:50 --> 404 Page Not Found: Licencetxt/index
ERROR - 2021-07-18 06:38:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:38:50 --> Config Class Initialized
INFO - 2021-07-18 06:38:50 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:38:50 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:38:50 --> Utf8 Class Initialized
INFO - 2021-07-18 06:38:50 --> URI Class Initialized
INFO - 2021-07-18 06:38:50 --> Router Class Initialized
INFO - 2021-07-18 06:38:50 --> Output Class Initialized
INFO - 2021-07-18 06:38:50 --> Security Class Initialized
DEBUG - 2021-07-18 06:38:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:38:50 --> Input Class Initialized
INFO - 2021-07-18 06:38:50 --> Language Class Initialized
ERROR - 2021-07-18 06:38:50 --> 404 Page Not Found: Script/login.js
ERROR - 2021-07-18 06:38:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:38:51 --> Config Class Initialized
INFO - 2021-07-18 06:38:51 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:38:51 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:38:51 --> Utf8 Class Initialized
INFO - 2021-07-18 06:38:51 --> URI Class Initialized
INFO - 2021-07-18 06:38:51 --> Router Class Initialized
INFO - 2021-07-18 06:38:51 --> Output Class Initialized
INFO - 2021-07-18 06:38:51 --> Security Class Initialized
DEBUG - 2021-07-18 06:38:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:38:51 --> Input Class Initialized
INFO - 2021-07-18 06:38:51 --> Language Class Initialized
ERROR - 2021-07-18 06:38:51 --> 404 Page Not Found: Public/about.html
ERROR - 2021-07-18 06:38:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:38:51 --> Config Class Initialized
INFO - 2021-07-18 06:38:51 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:38:51 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:38:51 --> Utf8 Class Initialized
INFO - 2021-07-18 06:38:51 --> URI Class Initialized
INFO - 2021-07-18 06:38:51 --> Router Class Initialized
INFO - 2021-07-18 06:38:51 --> Output Class Initialized
INFO - 2021-07-18 06:38:51 --> Security Class Initialized
DEBUG - 2021-07-18 06:38:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:38:51 --> Input Class Initialized
INFO - 2021-07-18 06:38:51 --> Language Class Initialized
ERROR - 2021-07-18 06:38:51 --> 404 Page Not Found: Help/en
ERROR - 2021-07-18 06:38:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:38:51 --> Config Class Initialized
INFO - 2021-07-18 06:38:51 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:38:51 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:38:51 --> Utf8 Class Initialized
INFO - 2021-07-18 06:38:51 --> URI Class Initialized
INFO - 2021-07-18 06:38:51 --> Router Class Initialized
INFO - 2021-07-18 06:38:51 --> Output Class Initialized
INFO - 2021-07-18 06:38:51 --> Security Class Initialized
DEBUG - 2021-07-18 06:38:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:38:51 --> Input Class Initialized
INFO - 2021-07-18 06:38:51 --> Language Class Initialized
ERROR - 2021-07-18 06:38:51 --> 404 Page Not Found: Imagesschool/style1
ERROR - 2021-07-18 06:38:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:38:52 --> Config Class Initialized
INFO - 2021-07-18 06:38:52 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:38:52 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:38:52 --> Utf8 Class Initialized
INFO - 2021-07-18 06:38:52 --> URI Class Initialized
INFO - 2021-07-18 06:38:52 --> Router Class Initialized
INFO - 2021-07-18 06:38:52 --> Output Class Initialized
INFO - 2021-07-18 06:38:52 --> Security Class Initialized
DEBUG - 2021-07-18 06:38:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:38:52 --> Input Class Initialized
INFO - 2021-07-18 06:38:52 --> Language Class Initialized
ERROR - 2021-07-18 06:38:52 --> 404 Page Not Found: Public/Admin
ERROR - 2021-07-18 06:38:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:38:52 --> Config Class Initialized
INFO - 2021-07-18 06:38:52 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:38:52 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:38:52 --> Utf8 Class Initialized
INFO - 2021-07-18 06:38:52 --> URI Class Initialized
INFO - 2021-07-18 06:38:52 --> Router Class Initialized
INFO - 2021-07-18 06:38:52 --> Output Class Initialized
INFO - 2021-07-18 06:38:52 --> Security Class Initialized
DEBUG - 2021-07-18 06:38:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:38:52 --> Input Class Initialized
INFO - 2021-07-18 06:38:52 --> Language Class Initialized
ERROR - 2021-07-18 06:38:52 --> 404 Page Not Found: Customdir/images
ERROR - 2021-07-18 06:38:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:38:53 --> Config Class Initialized
INFO - 2021-07-18 06:38:53 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:38:53 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:38:53 --> Utf8 Class Initialized
INFO - 2021-07-18 06:38:53 --> URI Class Initialized
INFO - 2021-07-18 06:38:53 --> Router Class Initialized
INFO - 2021-07-18 06:38:53 --> Output Class Initialized
INFO - 2021-07-18 06:38:53 --> Security Class Initialized
DEBUG - 2021-07-18 06:38:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:38:53 --> Input Class Initialized
INFO - 2021-07-18 06:38:53 --> Language Class Initialized
ERROR - 2021-07-18 06:38:53 --> 404 Page Not Found: Images/zh-CN
ERROR - 2021-07-18 06:38:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:38:53 --> Config Class Initialized
INFO - 2021-07-18 06:38:53 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:38:53 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:38:53 --> Utf8 Class Initialized
INFO - 2021-07-18 06:38:53 --> URI Class Initialized
INFO - 2021-07-18 06:38:53 --> Router Class Initialized
INFO - 2021-07-18 06:38:53 --> Output Class Initialized
INFO - 2021-07-18 06:38:53 --> Security Class Initialized
DEBUG - 2021-07-18 06:38:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:38:53 --> Input Class Initialized
INFO - 2021-07-18 06:38:53 --> Language Class Initialized
ERROR - 2021-07-18 06:38:53 --> 404 Page Not Found: Images/favicon.ico
ERROR - 2021-07-18 06:38:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:38:54 --> Config Class Initialized
INFO - 2021-07-18 06:38:54 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:38:54 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:38:54 --> Utf8 Class Initialized
INFO - 2021-07-18 06:38:54 --> URI Class Initialized
INFO - 2021-07-18 06:38:54 --> Router Class Initialized
INFO - 2021-07-18 06:38:54 --> Output Class Initialized
INFO - 2021-07-18 06:38:54 --> Security Class Initialized
DEBUG - 2021-07-18 06:38:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:38:54 --> Input Class Initialized
INFO - 2021-07-18 06:38:54 --> Language Class Initialized
ERROR - 2021-07-18 06:38:54 --> 404 Page Not Found: Images/logo-white.png
ERROR - 2021-07-18 06:38:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:38:54 --> Config Class Initialized
INFO - 2021-07-18 06:38:54 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:38:54 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:38:54 --> Utf8 Class Initialized
INFO - 2021-07-18 06:38:54 --> URI Class Initialized
INFO - 2021-07-18 06:38:54 --> Router Class Initialized
INFO - 2021-07-18 06:38:54 --> Output Class Initialized
INFO - 2021-07-18 06:38:54 --> Security Class Initialized
DEBUG - 2021-07-18 06:38:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:38:54 --> Input Class Initialized
INFO - 2021-07-18 06:38:54 --> Language Class Initialized
ERROR - 2021-07-18 06:38:54 --> 404 Page Not Found: Include/dedeajax2.js
ERROR - 2021-07-18 06:38:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:38:54 --> Config Class Initialized
INFO - 2021-07-18 06:38:54 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:38:54 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:38:54 --> Utf8 Class Initialized
INFO - 2021-07-18 06:38:54 --> URI Class Initialized
INFO - 2021-07-18 06:38:54 --> Router Class Initialized
INFO - 2021-07-18 06:38:54 --> Output Class Initialized
INFO - 2021-07-18 06:38:54 --> Security Class Initialized
DEBUG - 2021-07-18 06:38:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:38:54 --> Input Class Initialized
INFO - 2021-07-18 06:38:54 --> Language Class Initialized
ERROR - 2021-07-18 06:38:54 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-18 06:38:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:38:55 --> Config Class Initialized
INFO - 2021-07-18 06:38:55 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:38:55 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:38:55 --> Utf8 Class Initialized
INFO - 2021-07-18 06:38:55 --> URI Class Initialized
INFO - 2021-07-18 06:38:55 --> Router Class Initialized
INFO - 2021-07-18 06:38:55 --> Output Class Initialized
INFO - 2021-07-18 06:38:55 --> Security Class Initialized
DEBUG - 2021-07-18 06:38:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:38:55 --> Input Class Initialized
INFO - 2021-07-18 06:38:55 --> Language Class Initialized
ERROR - 2021-07-18 06:38:55 --> 404 Page Not Found: Include/dialog
ERROR - 2021-07-18 06:38:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:38:55 --> Config Class Initialized
INFO - 2021-07-18 06:38:55 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:38:55 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:38:55 --> Utf8 Class Initialized
INFO - 2021-07-18 06:38:55 --> URI Class Initialized
INFO - 2021-07-18 06:38:55 --> Router Class Initialized
INFO - 2021-07-18 06:38:55 --> Output Class Initialized
INFO - 2021-07-18 06:38:55 --> Security Class Initialized
DEBUG - 2021-07-18 06:38:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:38:55 --> Input Class Initialized
INFO - 2021-07-18 06:38:55 --> Language Class Initialized
ERROR - 2021-07-18 06:38:55 --> 404 Page Not Found: Plus/download.php
ERROR - 2021-07-18 06:38:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:38:56 --> Config Class Initialized
INFO - 2021-07-18 06:38:56 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:38:56 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:38:56 --> Utf8 Class Initialized
INFO - 2021-07-18 06:38:56 --> URI Class Initialized
INFO - 2021-07-18 06:38:56 --> Router Class Initialized
INFO - 2021-07-18 06:38:56 --> Output Class Initialized
INFO - 2021-07-18 06:38:56 --> Security Class Initialized
DEBUG - 2021-07-18 06:38:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:38:56 --> Input Class Initialized
INFO - 2021-07-18 06:38:56 --> Language Class Initialized
ERROR - 2021-07-18 06:38:56 --> 404 Page Not Found: Diggphp/index
ERROR - 2021-07-18 06:38:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:38:56 --> Config Class Initialized
INFO - 2021-07-18 06:38:56 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:38:56 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:38:56 --> Utf8 Class Initialized
INFO - 2021-07-18 06:38:56 --> URI Class Initialized
INFO - 2021-07-18 06:38:56 --> Router Class Initialized
INFO - 2021-07-18 06:38:56 --> Output Class Initialized
INFO - 2021-07-18 06:38:56 --> Security Class Initialized
DEBUG - 2021-07-18 06:38:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:38:56 --> Input Class Initialized
INFO - 2021-07-18 06:38:56 --> Language Class Initialized
ERROR - 2021-07-18 06:38:56 --> 404 Page Not Found: Plus/sitemap.html
ERROR - 2021-07-18 06:38:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:38:56 --> Config Class Initialized
INFO - 2021-07-18 06:38:56 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:38:56 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:38:56 --> Utf8 Class Initialized
INFO - 2021-07-18 06:38:56 --> URI Class Initialized
INFO - 2021-07-18 06:38:56 --> Router Class Initialized
INFO - 2021-07-18 06:38:56 --> Output Class Initialized
INFO - 2021-07-18 06:38:56 --> Security Class Initialized
DEBUG - 2021-07-18 06:38:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:38:56 --> Input Class Initialized
INFO - 2021-07-18 06:38:56 --> Language Class Initialized
ERROR - 2021-07-18 06:38:56 --> 404 Page Not Found: Plus/rssmap.html
ERROR - 2021-07-18 06:38:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:38:57 --> Config Class Initialized
INFO - 2021-07-18 06:38:57 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:38:57 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:38:57 --> Utf8 Class Initialized
INFO - 2021-07-18 06:38:57 --> URI Class Initialized
INFO - 2021-07-18 06:38:57 --> Router Class Initialized
INFO - 2021-07-18 06:38:57 --> Output Class Initialized
INFO - 2021-07-18 06:38:57 --> Security Class Initialized
DEBUG - 2021-07-18 06:38:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:38:57 --> Input Class Initialized
INFO - 2021-07-18 06:38:57 --> Language Class Initialized
ERROR - 2021-07-18 06:38:57 --> 404 Page Not Found: Plus/heightsearch.php
ERROR - 2021-07-18 06:38:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:38:57 --> Config Class Initialized
INFO - 2021-07-18 06:38:57 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:38:57 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:38:57 --> Utf8 Class Initialized
INFO - 2021-07-18 06:38:57 --> URI Class Initialized
INFO - 2021-07-18 06:38:57 --> Router Class Initialized
INFO - 2021-07-18 06:38:57 --> Output Class Initialized
INFO - 2021-07-18 06:38:57 --> Security Class Initialized
DEBUG - 2021-07-18 06:38:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:38:57 --> Input Class Initialized
INFO - 2021-07-18 06:38:57 --> Language Class Initialized
ERROR - 2021-07-18 06:38:57 --> 404 Page Not Found: Member/space
ERROR - 2021-07-18 06:38:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:38:58 --> Config Class Initialized
INFO - 2021-07-18 06:38:58 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:38:58 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:38:58 --> Utf8 Class Initialized
INFO - 2021-07-18 06:38:58 --> URI Class Initialized
INFO - 2021-07-18 06:38:58 --> Router Class Initialized
INFO - 2021-07-18 06:38:58 --> Output Class Initialized
INFO - 2021-07-18 06:38:58 --> Security Class Initialized
DEBUG - 2021-07-18 06:38:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:38:58 --> Input Class Initialized
INFO - 2021-07-18 06:38:58 --> Language Class Initialized
ERROR - 2021-07-18 06:38:58 --> 404 Page Not Found: CHANGELOGtxt/index
ERROR - 2021-07-18 06:38:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:38:58 --> Config Class Initialized
INFO - 2021-07-18 06:38:58 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:38:58 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:38:58 --> Utf8 Class Initialized
INFO - 2021-07-18 06:38:58 --> URI Class Initialized
INFO - 2021-07-18 06:38:58 --> Router Class Initialized
INFO - 2021-07-18 06:38:58 --> Output Class Initialized
INFO - 2021-07-18 06:38:58 --> Security Class Initialized
DEBUG - 2021-07-18 06:38:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:38:58 --> Input Class Initialized
INFO - 2021-07-18 06:38:58 --> Language Class Initialized
ERROR - 2021-07-18 06:38:58 --> 404 Page Not Found: Changelogtxt/index
ERROR - 2021-07-18 06:38:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:38:58 --> Config Class Initialized
INFO - 2021-07-18 06:38:58 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:38:58 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:38:58 --> Utf8 Class Initialized
INFO - 2021-07-18 06:38:58 --> URI Class Initialized
INFO - 2021-07-18 06:38:58 --> Router Class Initialized
INFO - 2021-07-18 06:38:58 --> Output Class Initialized
INFO - 2021-07-18 06:38:58 --> Security Class Initialized
DEBUG - 2021-07-18 06:38:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:38:58 --> Input Class Initialized
INFO - 2021-07-18 06:38:58 --> Language Class Initialized
ERROR - 2021-07-18 06:38:58 --> 404 Page Not Found: Help/index
ERROR - 2021-07-18 06:38:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:38:59 --> Config Class Initialized
INFO - 2021-07-18 06:38:59 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:38:59 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:38:59 --> Utf8 Class Initialized
INFO - 2021-07-18 06:38:59 --> URI Class Initialized
INFO - 2021-07-18 06:38:59 --> Router Class Initialized
INFO - 2021-07-18 06:38:59 --> Output Class Initialized
INFO - 2021-07-18 06:38:59 --> Security Class Initialized
DEBUG - 2021-07-18 06:38:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:38:59 --> Input Class Initialized
INFO - 2021-07-18 06:38:59 --> Language Class Initialized
ERROR - 2021-07-18 06:38:59 --> 404 Page Not Found: Images/branding
ERROR - 2021-07-18 06:38:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:38:59 --> Config Class Initialized
INFO - 2021-07-18 06:38:59 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:38:59 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:38:59 --> Utf8 Class Initialized
INFO - 2021-07-18 06:38:59 --> URI Class Initialized
INFO - 2021-07-18 06:38:59 --> Router Class Initialized
INFO - 2021-07-18 06:38:59 --> Output Class Initialized
INFO - 2021-07-18 06:38:59 --> Security Class Initialized
DEBUG - 2021-07-18 06:38:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:38:59 --> Input Class Initialized
INFO - 2021-07-18 06:38:59 --> Language Class Initialized
ERROR - 2021-07-18 06:38:59 --> 404 Page Not Found: Install/logo.gif
ERROR - 2021-07-18 06:38:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:38:59 --> Config Class Initialized
INFO - 2021-07-18 06:38:59 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:38:59 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:38:59 --> Utf8 Class Initialized
INFO - 2021-07-18 06:38:59 --> URI Class Initialized
INFO - 2021-07-18 06:38:59 --> Router Class Initialized
INFO - 2021-07-18 06:38:59 --> Output Class Initialized
INFO - 2021-07-18 06:38:59 --> Security Class Initialized
DEBUG - 2021-07-18 06:38:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:38:59 --> Input Class Initialized
INFO - 2021-07-18 06:38:59 --> Language Class Initialized
ERROR - 2021-07-18 06:38:59 --> 404 Page Not Found: Adminphp/index
ERROR - 2021-07-18 06:39:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:39:00 --> Config Class Initialized
INFO - 2021-07-18 06:39:00 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:39:00 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:39:00 --> Utf8 Class Initialized
INFO - 2021-07-18 06:39:00 --> URI Class Initialized
INFO - 2021-07-18 06:39:00 --> Router Class Initialized
INFO - 2021-07-18 06:39:00 --> Output Class Initialized
INFO - 2021-07-18 06:39:00 --> Security Class Initialized
DEBUG - 2021-07-18 06:39:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:39:00 --> Input Class Initialized
INFO - 2021-07-18 06:39:00 --> Language Class Initialized
ERROR - 2021-07-18 06:39:00 --> 404 Page Not Found: M/index
ERROR - 2021-07-18 06:39:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:39:00 --> Config Class Initialized
INFO - 2021-07-18 06:39:00 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:39:00 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:39:00 --> Utf8 Class Initialized
INFO - 2021-07-18 06:39:00 --> URI Class Initialized
INFO - 2021-07-18 06:39:00 --> Router Class Initialized
INFO - 2021-07-18 06:39:00 --> Output Class Initialized
INFO - 2021-07-18 06:39:00 --> Security Class Initialized
DEBUG - 2021-07-18 06:39:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:39:00 --> Input Class Initialized
INFO - 2021-07-18 06:39:00 --> Language Class Initialized
ERROR - 2021-07-18 06:39:00 --> 404 Page Not Found: Ycportal/js
ERROR - 2021-07-18 06:39:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:39:01 --> Config Class Initialized
INFO - 2021-07-18 06:39:01 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:39:01 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:39:01 --> Utf8 Class Initialized
INFO - 2021-07-18 06:39:01 --> URI Class Initialized
INFO - 2021-07-18 06:39:01 --> Router Class Initialized
INFO - 2021-07-18 06:39:01 --> Output Class Initialized
INFO - 2021-07-18 06:39:01 --> Security Class Initialized
DEBUG - 2021-07-18 06:39:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:39:01 --> Input Class Initialized
INFO - 2021-07-18 06:39:01 --> Language Class Initialized
ERROR - 2021-07-18 06:39:01 --> 404 Page Not Found: Webbuilder/script
ERROR - 2021-07-18 06:39:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:39:01 --> Config Class Initialized
INFO - 2021-07-18 06:39:01 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:39:01 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:39:01 --> Utf8 Class Initialized
INFO - 2021-07-18 06:39:01 --> URI Class Initialized
INFO - 2021-07-18 06:39:01 --> Router Class Initialized
INFO - 2021-07-18 06:39:01 --> Output Class Initialized
INFO - 2021-07-18 06:39:01 --> Security Class Initialized
DEBUG - 2021-07-18 06:39:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:39:01 --> Input Class Initialized
INFO - 2021-07-18 06:39:01 --> Language Class Initialized
ERROR - 2021-07-18 06:39:01 --> 404 Page Not Found: Datacenter/downloadApp
ERROR - 2021-07-18 06:39:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:39:01 --> Config Class Initialized
INFO - 2021-07-18 06:39:01 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:39:01 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:39:01 --> Utf8 Class Initialized
INFO - 2021-07-18 06:39:01 --> URI Class Initialized
INFO - 2021-07-18 06:39:01 --> Router Class Initialized
INFO - 2021-07-18 06:39:01 --> Output Class Initialized
INFO - 2021-07-18 06:39:01 --> Security Class Initialized
DEBUG - 2021-07-18 06:39:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:39:01 --> Input Class Initialized
INFO - 2021-07-18 06:39:01 --> Language Class Initialized
ERROR - 2021-07-18 06:39:01 --> 404 Page Not Found: Include/install_ocx.aspx
ERROR - 2021-07-18 06:39:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:39:02 --> Config Class Initialized
INFO - 2021-07-18 06:39:02 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:39:02 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:39:02 --> Utf8 Class Initialized
INFO - 2021-07-18 06:39:02 --> URI Class Initialized
INFO - 2021-07-18 06:39:02 --> Router Class Initialized
INFO - 2021-07-18 06:39:02 --> Output Class Initialized
INFO - 2021-07-18 06:39:02 --> Security Class Initialized
DEBUG - 2021-07-18 06:39:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:39:02 --> Input Class Initialized
INFO - 2021-07-18 06:39:02 --> Language Class Initialized
ERROR - 2021-07-18 06:39:02 --> 404 Page Not Found: Login/Jeecms.do
ERROR - 2021-07-18 06:39:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:39:02 --> Config Class Initialized
INFO - 2021-07-18 06:39:02 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:39:02 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:39:02 --> Utf8 Class Initialized
INFO - 2021-07-18 06:39:02 --> URI Class Initialized
INFO - 2021-07-18 06:39:02 --> Router Class Initialized
INFO - 2021-07-18 06:39:02 --> Output Class Initialized
INFO - 2021-07-18 06:39:02 --> Security Class Initialized
DEBUG - 2021-07-18 06:39:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:39:02 --> Input Class Initialized
INFO - 2021-07-18 06:39:02 --> Language Class Initialized
ERROR - 2021-07-18 06:39:02 --> 404 Page Not Found: Images/login_Name.jpg
ERROR - 2021-07-18 06:39:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:39:03 --> Config Class Initialized
INFO - 2021-07-18 06:39:03 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:39:03 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:39:03 --> Utf8 Class Initialized
INFO - 2021-07-18 06:39:03 --> URI Class Initialized
INFO - 2021-07-18 06:39:03 --> Router Class Initialized
INFO - 2021-07-18 06:39:03 --> Output Class Initialized
INFO - 2021-07-18 06:39:03 --> Security Class Initialized
DEBUG - 2021-07-18 06:39:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:39:03 --> Input Class Initialized
INFO - 2021-07-18 06:39:03 --> Language Class Initialized
ERROR - 2021-07-18 06:39:03 --> 404 Page Not Found: Nobody/mobile.htm
ERROR - 2021-07-18 06:39:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:39:03 --> Config Class Initialized
INFO - 2021-07-18 06:39:03 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:39:03 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:39:03 --> Utf8 Class Initialized
INFO - 2021-07-18 06:39:03 --> URI Class Initialized
INFO - 2021-07-18 06:39:03 --> Router Class Initialized
INFO - 2021-07-18 06:39:03 --> Output Class Initialized
INFO - 2021-07-18 06:39:03 --> Security Class Initialized
DEBUG - 2021-07-18 06:39:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:39:03 --> Input Class Initialized
INFO - 2021-07-18 06:39:03 --> Language Class Initialized
ERROR - 2021-07-18 06:39:03 --> 404 Page Not Found: Site/Pages
ERROR - 2021-07-18 06:39:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:39:04 --> Config Class Initialized
INFO - 2021-07-18 06:39:04 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:39:04 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:39:04 --> Utf8 Class Initialized
INFO - 2021-07-18 06:39:04 --> URI Class Initialized
INFO - 2021-07-18 06:39:04 --> Router Class Initialized
INFO - 2021-07-18 06:39:04 --> Output Class Initialized
INFO - 2021-07-18 06:39:04 --> Security Class Initialized
DEBUG - 2021-07-18 06:39:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:39:04 --> Input Class Initialized
INFO - 2021-07-18 06:39:04 --> Language Class Initialized
ERROR - 2021-07-18 06:39:04 --> 404 Page Not Found: Site/SystemThemes
ERROR - 2021-07-18 06:39:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:39:04 --> Config Class Initialized
INFO - 2021-07-18 06:39:04 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:39:04 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:39:04 --> Utf8 Class Initialized
INFO - 2021-07-18 06:39:04 --> URI Class Initialized
INFO - 2021-07-18 06:39:04 --> Router Class Initialized
INFO - 2021-07-18 06:39:04 --> Output Class Initialized
INFO - 2021-07-18 06:39:04 --> Security Class Initialized
DEBUG - 2021-07-18 06:39:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:39:04 --> Input Class Initialized
INFO - 2021-07-18 06:39:04 --> Language Class Initialized
ERROR - 2021-07-18 06:39:04 --> 404 Page Not Found: Forumphp/index
ERROR - 2021-07-18 06:39:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:39:04 --> Config Class Initialized
INFO - 2021-07-18 06:39:04 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:39:04 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:39:04 --> Utf8 Class Initialized
INFO - 2021-07-18 06:39:04 --> URI Class Initialized
INFO - 2021-07-18 06:39:04 --> Router Class Initialized
INFO - 2021-07-18 06:39:04 --> Output Class Initialized
INFO - 2021-07-18 06:39:04 --> Security Class Initialized
DEBUG - 2021-07-18 06:39:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:39:04 --> Input Class Initialized
INFO - 2021-07-18 06:39:04 --> Language Class Initialized
ERROR - 2021-07-18 06:39:04 --> 404 Page Not Found: Archiver/index
ERROR - 2021-07-18 06:39:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:39:05 --> Config Class Initialized
INFO - 2021-07-18 06:39:05 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:39:05 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:39:05 --> Utf8 Class Initialized
INFO - 2021-07-18 06:39:05 --> URI Class Initialized
INFO - 2021-07-18 06:39:05 --> Router Class Initialized
INFO - 2021-07-18 06:39:05 --> Output Class Initialized
INFO - 2021-07-18 06:39:05 --> Security Class Initialized
DEBUG - 2021-07-18 06:39:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:39:05 --> Input Class Initialized
INFO - 2021-07-18 06:39:05 --> Language Class Initialized
ERROR - 2021-07-18 06:39:05 --> 404 Page Not Found: Uc_server/control
ERROR - 2021-07-18 06:39:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:39:05 --> Config Class Initialized
INFO - 2021-07-18 06:39:05 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:39:05 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:39:05 --> Utf8 Class Initialized
INFO - 2021-07-18 06:39:05 --> URI Class Initialized
INFO - 2021-07-18 06:39:05 --> Router Class Initialized
INFO - 2021-07-18 06:39:05 --> Output Class Initialized
INFO - 2021-07-18 06:39:05 --> Security Class Initialized
DEBUG - 2021-07-18 06:39:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:39:05 --> Input Class Initialized
INFO - 2021-07-18 06:39:05 --> Language Class Initialized
ERROR - 2021-07-18 06:39:05 --> 404 Page Not Found: Business/images
ERROR - 2021-07-18 06:39:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:39:05 --> Config Class Initialized
INFO - 2021-07-18 06:39:05 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:39:05 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:39:05 --> Utf8 Class Initialized
INFO - 2021-07-18 06:39:05 --> URI Class Initialized
INFO - 2021-07-18 06:39:05 --> Router Class Initialized
INFO - 2021-07-18 06:39:05 --> Output Class Initialized
INFO - 2021-07-18 06:39:05 --> Security Class Initialized
DEBUG - 2021-07-18 06:39:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:39:05 --> Input Class Initialized
INFO - 2021-07-18 06:39:05 --> Language Class Initialized
ERROR - 2021-07-18 06:39:05 --> 404 Page Not Found: Include/EcsServerApi.js
ERROR - 2021-07-18 06:39:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:39:06 --> Config Class Initialized
INFO - 2021-07-18 06:39:06 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:39:06 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:39:06 --> Utf8 Class Initialized
INFO - 2021-07-18 06:39:06 --> URI Class Initialized
INFO - 2021-07-18 06:39:06 --> Router Class Initialized
INFO - 2021-07-18 06:39:06 --> Output Class Initialized
INFO - 2021-07-18 06:39:06 --> Security Class Initialized
DEBUG - 2021-07-18 06:39:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:39:06 --> Input Class Initialized
INFO - 2021-07-18 06:39:06 --> Language Class Initialized
ERROR - 2021-07-18 06:39:06 --> 404 Page Not Found: Img/pic
ERROR - 2021-07-18 06:39:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:39:06 --> Config Class Initialized
INFO - 2021-07-18 06:39:06 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:39:06 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:39:06 --> Utf8 Class Initialized
INFO - 2021-07-18 06:39:06 --> URI Class Initialized
INFO - 2021-07-18 06:39:06 --> Router Class Initialized
INFO - 2021-07-18 06:39:06 --> Output Class Initialized
INFO - 2021-07-18 06:39:06 --> Security Class Initialized
DEBUG - 2021-07-18 06:39:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:39:06 --> Input Class Initialized
INFO - 2021-07-18 06:39:06 --> Language Class Initialized
ERROR - 2021-07-18 06:39:06 --> 404 Page Not Found: Images/Default_bg_002.gif
ERROR - 2021-07-18 06:39:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:39:07 --> Config Class Initialized
INFO - 2021-07-18 06:39:07 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:39:07 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:39:07 --> Utf8 Class Initialized
INFO - 2021-07-18 06:39:07 --> URI Class Initialized
INFO - 2021-07-18 06:39:07 --> Router Class Initialized
INFO - 2021-07-18 06:39:07 --> Output Class Initialized
INFO - 2021-07-18 06:39:07 --> Security Class Initialized
DEBUG - 2021-07-18 06:39:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:39:07 --> Input Class Initialized
INFO - 2021-07-18 06:39:07 --> Language Class Initialized
ERROR - 2021-07-18 06:39:07 --> 404 Page Not Found: Custom/SkinTemplate
ERROR - 2021-07-18 06:39:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:39:07 --> Config Class Initialized
INFO - 2021-07-18 06:39:07 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:39:07 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:39:07 --> Utf8 Class Initialized
INFO - 2021-07-18 06:39:07 --> URI Class Initialized
INFO - 2021-07-18 06:39:07 --> Router Class Initialized
INFO - 2021-07-18 06:39:07 --> Output Class Initialized
INFO - 2021-07-18 06:39:07 --> Security Class Initialized
DEBUG - 2021-07-18 06:39:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:39:07 --> Input Class Initialized
INFO - 2021-07-18 06:39:07 --> Language Class Initialized
ERROR - 2021-07-18 06:39:07 --> 404 Page Not Found: Eams/static
ERROR - 2021-07-18 06:39:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:39:08 --> Config Class Initialized
INFO - 2021-07-18 06:39:08 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:39:08 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:39:08 --> Utf8 Class Initialized
INFO - 2021-07-18 06:39:08 --> URI Class Initialized
INFO - 2021-07-18 06:39:08 --> Router Class Initialized
INFO - 2021-07-18 06:39:08 --> Output Class Initialized
INFO - 2021-07-18 06:39:08 --> Security Class Initialized
DEBUG - 2021-07-18 06:39:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:39:08 --> Input Class Initialized
INFO - 2021-07-18 06:39:08 --> Language Class Initialized
ERROR - 2021-07-18 06:39:08 --> 404 Page Not Found: Static/images
ERROR - 2021-07-18 06:39:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:39:08 --> Config Class Initialized
INFO - 2021-07-18 06:39:08 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:39:08 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:39:08 --> Utf8 Class Initialized
INFO - 2021-07-18 06:39:08 --> URI Class Initialized
INFO - 2021-07-18 06:39:08 --> Router Class Initialized
INFO - 2021-07-18 06:39:08 --> Output Class Initialized
INFO - 2021-07-18 06:39:08 --> Security Class Initialized
DEBUG - 2021-07-18 06:39:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:39:08 --> Input Class Initialized
INFO - 2021-07-18 06:39:08 --> Language Class Initialized
ERROR - 2021-07-18 06:39:08 --> 404 Page Not Found: Admin/admin_login.php
ERROR - 2021-07-18 06:39:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:39:08 --> Config Class Initialized
INFO - 2021-07-18 06:39:08 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:39:08 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:39:08 --> Utf8 Class Initialized
INFO - 2021-07-18 06:39:08 --> URI Class Initialized
INFO - 2021-07-18 06:39:08 --> Router Class Initialized
INFO - 2021-07-18 06:39:08 --> Output Class Initialized
INFO - 2021-07-18 06:39:08 --> Security Class Initialized
DEBUG - 2021-07-18 06:39:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:39:08 --> Input Class Initialized
INFO - 2021-07-18 06:39:08 --> Language Class Initialized
ERROR - 2021-07-18 06:39:08 --> 404 Page Not Found: Data/images
ERROR - 2021-07-18 06:39:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:39:09 --> Config Class Initialized
INFO - 2021-07-18 06:39:09 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:39:09 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:39:09 --> Utf8 Class Initialized
INFO - 2021-07-18 06:39:09 --> URI Class Initialized
INFO - 2021-07-18 06:39:09 --> Router Class Initialized
INFO - 2021-07-18 06:39:09 --> Output Class Initialized
INFO - 2021-07-18 06:39:09 --> Security Class Initialized
DEBUG - 2021-07-18 06:39:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:39:09 --> Input Class Initialized
INFO - 2021-07-18 06:39:09 --> Language Class Initialized
ERROR - 2021-07-18 06:39:09 --> 404 Page Not Found: Wp-cronphp/index
ERROR - 2021-07-18 06:39:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:39:09 --> Config Class Initialized
INFO - 2021-07-18 06:39:09 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:39:09 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:39:09 --> Utf8 Class Initialized
INFO - 2021-07-18 06:39:09 --> URI Class Initialized
INFO - 2021-07-18 06:39:09 --> Router Class Initialized
INFO - 2021-07-18 06:39:09 --> Output Class Initialized
INFO - 2021-07-18 06:39:09 --> Security Class Initialized
DEBUG - 2021-07-18 06:39:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:39:09 --> Input Class Initialized
INFO - 2021-07-18 06:39:09 --> Language Class Initialized
ERROR - 2021-07-18 06:39:09 --> 404 Page Not Found: Wp-content/index
ERROR - 2021-07-18 06:39:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:39:10 --> Config Class Initialized
INFO - 2021-07-18 06:39:10 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:39:10 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:39:10 --> Utf8 Class Initialized
INFO - 2021-07-18 06:39:10 --> URI Class Initialized
INFO - 2021-07-18 06:39:10 --> Router Class Initialized
INFO - 2021-07-18 06:39:10 --> Output Class Initialized
INFO - 2021-07-18 06:39:10 --> Security Class Initialized
DEBUG - 2021-07-18 06:39:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:39:10 --> Input Class Initialized
INFO - 2021-07-18 06:39:10 --> Language Class Initialized
ERROR - 2021-07-18 06:39:10 --> 404 Page Not Found: Licensetxt/index
ERROR - 2021-07-18 06:39:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:39:11 --> Config Class Initialized
INFO - 2021-07-18 06:39:11 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:39:11 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:39:11 --> Utf8 Class Initialized
INFO - 2021-07-18 06:39:11 --> URI Class Initialized
INFO - 2021-07-18 06:39:11 --> Router Class Initialized
INFO - 2021-07-18 06:39:11 --> Output Class Initialized
INFO - 2021-07-18 06:39:11 --> Security Class Initialized
DEBUG - 2021-07-18 06:39:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:39:11 --> Input Class Initialized
INFO - 2021-07-18 06:39:11 --> Language Class Initialized
ERROR - 2021-07-18 06:39:11 --> 404 Page Not Found: Readmehtml/index
ERROR - 2021-07-18 06:39:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:39:11 --> Config Class Initialized
INFO - 2021-07-18 06:39:11 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:39:11 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:39:11 --> Utf8 Class Initialized
INFO - 2021-07-18 06:39:11 --> URI Class Initialized
INFO - 2021-07-18 06:39:11 --> Router Class Initialized
INFO - 2021-07-18 06:39:11 --> Output Class Initialized
INFO - 2021-07-18 06:39:11 --> Security Class Initialized
DEBUG - 2021-07-18 06:39:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:39:11 --> Input Class Initialized
INFO - 2021-07-18 06:39:11 --> Language Class Initialized
ERROR - 2021-07-18 06:39:11 --> 404 Page Not Found: Was/help.jsp
ERROR - 2021-07-18 06:39:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:39:12 --> Config Class Initialized
INFO - 2021-07-18 06:39:12 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:39:12 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:39:12 --> Utf8 Class Initialized
INFO - 2021-07-18 06:39:12 --> URI Class Initialized
INFO - 2021-07-18 06:39:12 --> Router Class Initialized
INFO - 2021-07-18 06:39:12 --> Output Class Initialized
INFO - 2021-07-18 06:39:12 --> Security Class Initialized
DEBUG - 2021-07-18 06:39:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:39:12 --> Input Class Initialized
INFO - 2021-07-18 06:39:12 --> Language Class Initialized
ERROR - 2021-07-18 06:39:12 --> 404 Page Not Found: Was5/web
ERROR - 2021-07-18 06:39:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:39:12 --> Config Class Initialized
INFO - 2021-07-18 06:39:12 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:39:12 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:39:12 --> Utf8 Class Initialized
INFO - 2021-07-18 06:39:12 --> URI Class Initialized
INFO - 2021-07-18 06:39:12 --> Router Class Initialized
INFO - 2021-07-18 06:39:12 --> Output Class Initialized
INFO - 2021-07-18 06:39:12 --> Security Class Initialized
DEBUG - 2021-07-18 06:39:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:39:12 --> Input Class Initialized
INFO - 2021-07-18 06:39:12 --> Language Class Initialized
ERROR - 2021-07-18 06:39:12 --> 404 Page Not Found: Was/main.html
ERROR - 2021-07-18 06:39:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:39:12 --> Config Class Initialized
INFO - 2021-07-18 06:39:12 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:39:12 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:39:12 --> Utf8 Class Initialized
INFO - 2021-07-18 06:39:12 --> URI Class Initialized
INFO - 2021-07-18 06:39:12 --> Router Class Initialized
INFO - 2021-07-18 06:39:12 --> Output Class Initialized
INFO - 2021-07-18 06:39:12 --> Security Class Initialized
DEBUG - 2021-07-18 06:39:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:39:12 --> Input Class Initialized
INFO - 2021-07-18 06:39:12 --> Language Class Initialized
ERROR - 2021-07-18 06:39:12 --> 404 Page Not Found: Logo/logo_jw.png
ERROR - 2021-07-18 06:39:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:39:13 --> Config Class Initialized
INFO - 2021-07-18 06:39:13 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:39:13 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:39:13 --> Utf8 Class Initialized
INFO - 2021-07-18 06:39:13 --> URI Class Initialized
INFO - 2021-07-18 06:39:13 --> Router Class Initialized
INFO - 2021-07-18 06:39:13 --> Output Class Initialized
INFO - 2021-07-18 06:39:13 --> Security Class Initialized
DEBUG - 2021-07-18 06:39:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:39:13 --> Input Class Initialized
INFO - 2021-07-18 06:39:13 --> Language Class Initialized
ERROR - 2021-07-18 06:39:13 --> 404 Page Not Found: Phpmyadmin/index
ERROR - 2021-07-18 06:39:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:39:13 --> Config Class Initialized
INFO - 2021-07-18 06:39:13 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:39:13 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:39:13 --> Utf8 Class Initialized
INFO - 2021-07-18 06:39:13 --> URI Class Initialized
INFO - 2021-07-18 06:39:13 --> Router Class Initialized
INFO - 2021-07-18 06:39:13 --> Output Class Initialized
INFO - 2021-07-18 06:39:13 --> Security Class Initialized
DEBUG - 2021-07-18 06:39:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:39:13 --> Input Class Initialized
INFO - 2021-07-18 06:39:13 --> Language Class Initialized
ERROR - 2021-07-18 06:39:13 --> 404 Page Not Found: Weblog/index
ERROR - 2021-07-18 06:39:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:39:13 --> Config Class Initialized
INFO - 2021-07-18 06:39:13 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:39:13 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:39:13 --> Utf8 Class Initialized
INFO - 2021-07-18 06:39:13 --> URI Class Initialized
INFO - 2021-07-18 06:39:13 --> Router Class Initialized
INFO - 2021-07-18 06:39:13 --> Output Class Initialized
INFO - 2021-07-18 06:39:13 --> Security Class Initialized
DEBUG - 2021-07-18 06:39:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:39:13 --> Input Class Initialized
INFO - 2021-07-18 06:39:13 --> Language Class Initialized
ERROR - 2021-07-18 06:39:13 --> 404 Page Not Found: Blog/index
ERROR - 2021-07-18 06:39:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:39:14 --> Config Class Initialized
INFO - 2021-07-18 06:39:14 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:39:14 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:39:14 --> Utf8 Class Initialized
INFO - 2021-07-18 06:39:14 --> URI Class Initialized
INFO - 2021-07-18 06:39:14 --> Router Class Initialized
INFO - 2021-07-18 06:39:14 --> Output Class Initialized
INFO - 2021-07-18 06:39:14 --> Security Class Initialized
DEBUG - 2021-07-18 06:39:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:39:14 --> Input Class Initialized
INFO - 2021-07-18 06:39:14 --> Language Class Initialized
ERROR - 2021-07-18 06:39:14 --> 404 Page Not Found: Forum/index
ERROR - 2021-07-18 06:39:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:39:14 --> Config Class Initialized
INFO - 2021-07-18 06:39:14 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:39:14 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:39:14 --> Utf8 Class Initialized
INFO - 2021-07-18 06:39:14 --> URI Class Initialized
INFO - 2021-07-18 06:39:14 --> Router Class Initialized
INFO - 2021-07-18 06:39:14 --> Output Class Initialized
INFO - 2021-07-18 06:39:14 --> Security Class Initialized
DEBUG - 2021-07-18 06:39:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:39:14 --> Input Class Initialized
INFO - 2021-07-18 06:39:14 --> Language Class Initialized
ERROR - 2021-07-18 06:39:14 --> 404 Page Not Found: Bbs/index
ERROR - 2021-07-18 06:39:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:39:15 --> Config Class Initialized
INFO - 2021-07-18 06:39:15 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:39:15 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:39:15 --> Utf8 Class Initialized
INFO - 2021-07-18 06:39:15 --> URI Class Initialized
INFO - 2021-07-18 06:39:15 --> Router Class Initialized
INFO - 2021-07-18 06:39:15 --> Output Class Initialized
INFO - 2021-07-18 06:39:15 --> Security Class Initialized
DEBUG - 2021-07-18 06:39:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:39:15 --> Input Class Initialized
INFO - 2021-07-18 06:39:15 --> Language Class Initialized
ERROR - 2021-07-18 06:39:15 --> 404 Page Not Found: Wcm/index
ERROR - 2021-07-18 06:39:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-18 06:39:15 --> Config Class Initialized
INFO - 2021-07-18 06:39:15 --> Hooks Class Initialized
DEBUG - 2021-07-18 06:39:15 --> UTF-8 Support Enabled
INFO - 2021-07-18 06:39:15 --> Utf8 Class Initialized
INFO - 2021-07-18 06:39:15 --> URI Class Initialized
INFO - 2021-07-18 06:39:15 --> Router Class Initialized
INFO - 2021-07-18 06:39:15 --> Output Class Initialized
INFO - 2021-07-18 06:39:15 --> Security Class Initialized
DEBUG - 2021-07-18 06:39:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 06:39:15 --> Input Class Initialized
INFO - 2021-07-18 06:39:15 --> Language Class Initialized
ERROR - 2021-07-18 06:39:15 --> 404 Page Not Found: Admin/editor
