<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-09-20 16:29:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-20 16:29:47 --> Config Class Initialized
INFO - 2021-09-20 16:29:47 --> Hooks Class Initialized
DEBUG - 2021-09-20 16:29:47 --> UTF-8 Support Enabled
INFO - 2021-09-20 16:29:47 --> Utf8 Class Initialized
INFO - 2021-09-20 16:29:47 --> URI Class Initialized
DEBUG - 2021-09-20 16:29:47 --> No URI present. Default controller set.
INFO - 2021-09-20 16:29:47 --> Router Class Initialized
INFO - 2021-09-20 16:29:47 --> Output Class Initialized
INFO - 2021-09-20 16:29:47 --> Security Class Initialized
DEBUG - 2021-09-20 16:29:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-20 16:29:47 --> Input Class Initialized
INFO - 2021-09-20 16:29:47 --> Language Class Initialized
INFO - 2021-09-20 16:29:47 --> Loader Class Initialized
INFO - 2021-09-20 16:29:47 --> Helper loaded: url_helper
INFO - 2021-09-20 16:29:47 --> Helper loaded: form_helper
INFO - 2021-09-20 16:29:47 --> Helper loaded: common_helper
INFO - 2021-09-20 16:29:47 --> Database Driver Class Initialized
DEBUG - 2021-09-20 16:29:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-20 16:29:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-20 16:29:47 --> Controller Class Initialized
INFO - 2021-09-20 16:29:47 --> Form Validation Class Initialized
DEBUG - 2021-09-20 16:29:47 --> Encrypt Class Initialized
DEBUG - 2021-09-20 16:29:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-09-20 16:29:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-09-20 16:29:47 --> Email Class Initialized
INFO - 2021-09-20 16:29:47 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-09-20 16:29:47 --> Calendar Class Initialized
INFO - 2021-09-20 16:29:47 --> Model "Login_model" initialized
INFO - 2021-09-20 16:29:47 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-09-20 16:29:47 --> Final output sent to browser
DEBUG - 2021-09-20 16:29:47 --> Total execution time: 0.0421
ERROR - 2021-09-20 17:45:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-20 17:45:05 --> Config Class Initialized
INFO - 2021-09-20 17:45:05 --> Hooks Class Initialized
DEBUG - 2021-09-20 17:45:05 --> UTF-8 Support Enabled
INFO - 2021-09-20 17:45:05 --> Utf8 Class Initialized
INFO - 2021-09-20 17:45:05 --> URI Class Initialized
DEBUG - 2021-09-20 17:45:05 --> No URI present. Default controller set.
INFO - 2021-09-20 17:45:05 --> Router Class Initialized
INFO - 2021-09-20 17:45:05 --> Output Class Initialized
INFO - 2021-09-20 17:45:05 --> Security Class Initialized
DEBUG - 2021-09-20 17:45:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-20 17:45:05 --> Input Class Initialized
INFO - 2021-09-20 17:45:05 --> Language Class Initialized
INFO - 2021-09-20 17:45:05 --> Loader Class Initialized
INFO - 2021-09-20 17:45:05 --> Helper loaded: url_helper
INFO - 2021-09-20 17:45:05 --> Helper loaded: form_helper
INFO - 2021-09-20 17:45:05 --> Helper loaded: common_helper
INFO - 2021-09-20 17:45:05 --> Database Driver Class Initialized
DEBUG - 2021-09-20 17:45:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-20 17:45:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-20 17:45:05 --> Controller Class Initialized
INFO - 2021-09-20 17:45:05 --> Form Validation Class Initialized
DEBUG - 2021-09-20 17:45:05 --> Encrypt Class Initialized
DEBUG - 2021-09-20 17:45:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-09-20 17:45:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-09-20 17:45:05 --> Email Class Initialized
INFO - 2021-09-20 17:45:05 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-09-20 17:45:05 --> Calendar Class Initialized
INFO - 2021-09-20 17:45:05 --> Model "Login_model" initialized
INFO - 2021-09-20 17:45:05 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-09-20 17:45:05 --> Final output sent to browser
DEBUG - 2021-09-20 17:45:05 --> Total execution time: 0.0526
