<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-06-21 04:29:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-21 04:29:19 --> Config Class Initialized
INFO - 2021-06-21 04:29:19 --> Hooks Class Initialized
DEBUG - 2021-06-21 04:29:19 --> UTF-8 Support Enabled
INFO - 2021-06-21 04:29:19 --> Utf8 Class Initialized
INFO - 2021-06-21 04:29:19 --> URI Class Initialized
DEBUG - 2021-06-21 04:29:19 --> No URI present. Default controller set.
INFO - 2021-06-21 04:29:19 --> Router Class Initialized
INFO - 2021-06-21 04:29:19 --> Output Class Initialized
INFO - 2021-06-21 04:29:19 --> Security Class Initialized
DEBUG - 2021-06-21 04:29:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-21 04:29:19 --> Input Class Initialized
INFO - 2021-06-21 04:29:19 --> Language Class Initialized
INFO - 2021-06-21 04:29:19 --> Loader Class Initialized
INFO - 2021-06-21 04:29:19 --> Helper loaded: url_helper
INFO - 2021-06-21 04:29:19 --> Helper loaded: form_helper
INFO - 2021-06-21 04:29:19 --> Helper loaded: common_helper
INFO - 2021-06-21 04:29:19 --> Database Driver Class Initialized
DEBUG - 2021-06-21 04:29:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-21 04:29:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-21 04:29:19 --> Controller Class Initialized
INFO - 2021-06-21 04:29:19 --> Form Validation Class Initialized
DEBUG - 2021-06-21 04:29:19 --> Encrypt Class Initialized
DEBUG - 2021-06-21 04:29:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-06-21 04:29:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-06-21 04:29:19 --> Email Class Initialized
INFO - 2021-06-21 04:29:19 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-06-21 04:29:19 --> Calendar Class Initialized
INFO - 2021-06-21 04:29:19 --> Model "Login_model" initialized
INFO - 2021-06-21 04:29:19 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-06-21 04:29:19 --> Final output sent to browser
DEBUG - 2021-06-21 04:29:19 --> Total execution time: 0.0412
ERROR - 2021-06-21 05:17:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-21 05:17:57 --> Config Class Initialized
INFO - 2021-06-21 05:17:57 --> Hooks Class Initialized
DEBUG - 2021-06-21 05:17:57 --> UTF-8 Support Enabled
INFO - 2021-06-21 05:17:57 --> Utf8 Class Initialized
INFO - 2021-06-21 05:17:57 --> URI Class Initialized
DEBUG - 2021-06-21 05:17:57 --> No URI present. Default controller set.
INFO - 2021-06-21 05:17:57 --> Router Class Initialized
INFO - 2021-06-21 05:17:57 --> Output Class Initialized
INFO - 2021-06-21 05:17:57 --> Security Class Initialized
DEBUG - 2021-06-21 05:17:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-21 05:17:57 --> Input Class Initialized
INFO - 2021-06-21 05:17:57 --> Language Class Initialized
INFO - 2021-06-21 05:17:57 --> Loader Class Initialized
INFO - 2021-06-21 05:17:57 --> Helper loaded: url_helper
INFO - 2021-06-21 05:17:57 --> Helper loaded: form_helper
INFO - 2021-06-21 05:17:57 --> Helper loaded: common_helper
INFO - 2021-06-21 05:17:57 --> Database Driver Class Initialized
DEBUG - 2021-06-21 05:17:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-21 05:17:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-21 05:17:57 --> Controller Class Initialized
INFO - 2021-06-21 05:17:57 --> Form Validation Class Initialized
DEBUG - 2021-06-21 05:17:57 --> Encrypt Class Initialized
DEBUG - 2021-06-21 05:17:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-06-21 05:17:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-06-21 05:17:57 --> Email Class Initialized
INFO - 2021-06-21 05:17:57 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-06-21 05:17:57 --> Calendar Class Initialized
INFO - 2021-06-21 05:17:57 --> Model "Login_model" initialized
INFO - 2021-06-21 05:17:57 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-06-21 05:17:57 --> Final output sent to browser
DEBUG - 2021-06-21 05:17:57 --> Total execution time: 0.0411
ERROR - 2021-06-21 20:30:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-21 20:30:51 --> Config Class Initialized
INFO - 2021-06-21 20:30:51 --> Hooks Class Initialized
DEBUG - 2021-06-21 20:30:51 --> UTF-8 Support Enabled
INFO - 2021-06-21 20:30:51 --> Utf8 Class Initialized
INFO - 2021-06-21 20:30:51 --> URI Class Initialized
DEBUG - 2021-06-21 20:30:51 --> No URI present. Default controller set.
INFO - 2021-06-21 20:30:51 --> Router Class Initialized
INFO - 2021-06-21 20:30:51 --> Output Class Initialized
INFO - 2021-06-21 20:30:51 --> Security Class Initialized
DEBUG - 2021-06-21 20:30:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-21 20:30:51 --> Input Class Initialized
INFO - 2021-06-21 20:30:51 --> Language Class Initialized
INFO - 2021-06-21 20:30:51 --> Loader Class Initialized
INFO - 2021-06-21 20:30:51 --> Helper loaded: url_helper
INFO - 2021-06-21 20:30:51 --> Helper loaded: form_helper
INFO - 2021-06-21 20:30:51 --> Helper loaded: common_helper
INFO - 2021-06-21 20:30:51 --> Database Driver Class Initialized
DEBUG - 2021-06-21 20:30:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-21 20:30:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-21 20:30:51 --> Controller Class Initialized
INFO - 2021-06-21 20:30:51 --> Form Validation Class Initialized
DEBUG - 2021-06-21 20:30:51 --> Encrypt Class Initialized
DEBUG - 2021-06-21 20:30:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-06-21 20:30:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-06-21 20:30:51 --> Email Class Initialized
INFO - 2021-06-21 20:30:51 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-06-21 20:30:51 --> Calendar Class Initialized
INFO - 2021-06-21 20:30:51 --> Model "Login_model" initialized
INFO - 2021-06-21 20:30:51 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-06-21 20:30:51 --> Final output sent to browser
DEBUG - 2021-06-21 20:30:51 --> Total execution time: 0.0417
