<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-06-07 15:44:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2021-06-07 15:44:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-07 15:44:52 --> Config Class Initialized
INFO - 2021-06-07 15:44:52 --> Hooks Class Initialized
DEBUG - 2021-06-07 15:44:52 --> UTF-8 Support Enabled
INFO - 2021-06-07 15:44:52 --> Utf8 Class Initialized
INFO - 2021-06-07 15:44:52 --> Config Class Initialized
INFO - 2021-06-07 15:44:52 --> Hooks Class Initialized
INFO - 2021-06-07 15:44:52 --> URI Class Initialized
DEBUG - 2021-06-07 15:44:52 --> UTF-8 Support Enabled
INFO - 2021-06-07 15:44:52 --> Utf8 Class Initialized
INFO - 2021-06-07 15:44:52 --> URI Class Initialized
DEBUG - 2021-06-07 15:44:52 --> No URI present. Default controller set.
INFO - 2021-06-07 15:44:52 --> Router Class Initialized
INFO - 2021-06-07 15:44:52 --> Router Class Initialized
INFO - 2021-06-07 15:44:52 --> Output Class Initialized
INFO - 2021-06-07 15:44:52 --> Output Class Initialized
INFO - 2021-06-07 15:44:52 --> Security Class Initialized
DEBUG - 2021-06-07 15:44:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-07 15:44:52 --> Input Class Initialized
INFO - 2021-06-07 15:44:52 --> Security Class Initialized
DEBUG - 2021-06-07 15:44:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-07 15:44:52 --> Input Class Initialized
INFO - 2021-06-07 15:44:52 --> Language Class Initialized
INFO - 2021-06-07 15:44:52 --> Language Class Initialized
INFO - 2021-06-07 15:44:52 --> Loader Class Initialized
ERROR - 2021-06-07 15:44:52 --> 404 Page Not Found: Robotstxt/index
INFO - 2021-06-07 15:44:52 --> Helper loaded: url_helper
INFO - 2021-06-07 15:44:52 --> Helper loaded: form_helper
INFO - 2021-06-07 15:44:52 --> Helper loaded: common_helper
INFO - 2021-06-07 15:44:52 --> Database Driver Class Initialized
DEBUG - 2021-06-07 15:44:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-07 15:44:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-07 15:44:52 --> Controller Class Initialized
INFO - 2021-06-07 15:44:52 --> Form Validation Class Initialized
DEBUG - 2021-06-07 15:44:52 --> Encrypt Class Initialized
DEBUG - 2021-06-07 15:44:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-06-07 15:44:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-06-07 15:44:52 --> Email Class Initialized
INFO - 2021-06-07 15:44:52 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-06-07 15:44:52 --> Calendar Class Initialized
INFO - 2021-06-07 15:44:52 --> Model "Login_model" initialized
INFO - 2021-06-07 15:44:52 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-06-07 15:44:52 --> Final output sent to browser
DEBUG - 2021-06-07 15:44:52 --> Total execution time: 0.2309
ERROR - 2021-06-07 15:44:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-07 15:44:54 --> Config Class Initialized
INFO - 2021-06-07 15:44:54 --> Hooks Class Initialized
DEBUG - 2021-06-07 15:44:54 --> UTF-8 Support Enabled
INFO - 2021-06-07 15:44:54 --> Utf8 Class Initialized
INFO - 2021-06-07 15:44:54 --> URI Class Initialized
INFO - 2021-06-07 15:44:54 --> Router Class Initialized
INFO - 2021-06-07 15:44:54 --> Output Class Initialized
INFO - 2021-06-07 15:44:54 --> Security Class Initialized
DEBUG - 2021-06-07 15:44:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-07 15:44:54 --> Input Class Initialized
INFO - 2021-06-07 15:44:54 --> Language Class Initialized
ERROR - 2021-06-07 15:44:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-07 15:45:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-07 15:45:09 --> Config Class Initialized
INFO - 2021-06-07 15:45:09 --> Hooks Class Initialized
DEBUG - 2021-06-07 15:45:09 --> UTF-8 Support Enabled
INFO - 2021-06-07 15:45:09 --> Utf8 Class Initialized
INFO - 2021-06-07 15:45:09 --> URI Class Initialized
INFO - 2021-06-07 15:45:09 --> Router Class Initialized
INFO - 2021-06-07 15:45:09 --> Output Class Initialized
INFO - 2021-06-07 15:45:09 --> Security Class Initialized
DEBUG - 2021-06-07 15:45:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-07 15:45:09 --> Input Class Initialized
INFO - 2021-06-07 15:45:09 --> Language Class Initialized
INFO - 2021-06-07 15:45:09 --> Loader Class Initialized
INFO - 2021-06-07 15:45:09 --> Helper loaded: url_helper
INFO - 2021-06-07 15:45:09 --> Helper loaded: form_helper
INFO - 2021-06-07 15:45:09 --> Helper loaded: common_helper
INFO - 2021-06-07 15:45:09 --> Database Driver Class Initialized
DEBUG - 2021-06-07 15:45:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-07 15:45:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-07 15:45:09 --> Controller Class Initialized
INFO - 2021-06-07 15:45:09 --> Form Validation Class Initialized
DEBUG - 2021-06-07 15:45:09 --> Encrypt Class Initialized
DEBUG - 2021-06-07 15:45:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-06-07 15:45:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-06-07 15:45:09 --> Email Class Initialized
INFO - 2021-06-07 15:45:09 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-06-07 15:45:09 --> Calendar Class Initialized
INFO - 2021-06-07 15:45:09 --> Model "Login_model" initialized
INFO - 2021-06-07 15:45:09 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2021-06-07 15:45:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-07 15:45:10 --> Config Class Initialized
INFO - 2021-06-07 15:45:10 --> Hooks Class Initialized
DEBUG - 2021-06-07 15:45:10 --> UTF-8 Support Enabled
INFO - 2021-06-07 15:45:10 --> Utf8 Class Initialized
INFO - 2021-06-07 15:45:10 --> URI Class Initialized
INFO - 2021-06-07 15:45:10 --> Router Class Initialized
INFO - 2021-06-07 15:45:10 --> Output Class Initialized
INFO - 2021-06-07 15:45:10 --> Security Class Initialized
DEBUG - 2021-06-07 15:45:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-07 15:45:10 --> Input Class Initialized
INFO - 2021-06-07 15:45:10 --> Language Class Initialized
INFO - 2021-06-07 15:45:10 --> Loader Class Initialized
INFO - 2021-06-07 15:45:10 --> Helper loaded: url_helper
INFO - 2021-06-07 15:45:10 --> Helper loaded: form_helper
INFO - 2021-06-07 15:45:10 --> Helper loaded: common_helper
INFO - 2021-06-07 15:45:10 --> Database Driver Class Initialized
DEBUG - 2021-06-07 15:45:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-07 15:45:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-07 15:45:10 --> Controller Class Initialized
INFO - 2021-06-07 15:45:10 --> Form Validation Class Initialized
DEBUG - 2021-06-07 15:45:10 --> Encrypt Class Initialized
INFO - 2021-06-07 15:45:10 --> Model "Login_model" initialized
INFO - 2021-06-07 15:45:10 --> Model "Dashboard_model" initialized
INFO - 2021-06-07 15:45:10 --> Model "Case_model" initialized
INFO - 2021-06-07 15:45:13 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/header.php
INFO - 2021-06-07 15:45:19 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/dashboard/index.php
INFO - 2021-06-07 15:45:19 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/footer.php
INFO - 2021-06-07 15:45:19 --> Final output sent to browser
DEBUG - 2021-06-07 15:45:19 --> Total execution time: 9.4730
ERROR - 2021-06-07 15:45:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-07 15:45:21 --> Config Class Initialized
INFO - 2021-06-07 15:45:21 --> Hooks Class Initialized
DEBUG - 2021-06-07 15:45:21 --> UTF-8 Support Enabled
INFO - 2021-06-07 15:45:21 --> Utf8 Class Initialized
INFO - 2021-06-07 15:45:21 --> URI Class Initialized
INFO - 2021-06-07 15:45:21 --> Router Class Initialized
INFO - 2021-06-07 15:45:21 --> Output Class Initialized
INFO - 2021-06-07 15:45:21 --> Security Class Initialized
DEBUG - 2021-06-07 15:45:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-07 15:45:21 --> Input Class Initialized
INFO - 2021-06-07 15:45:21 --> Language Class Initialized
ERROR - 2021-06-07 15:45:21 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-06-07 15:48:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-07 15:48:25 --> Config Class Initialized
INFO - 2021-06-07 15:48:25 --> Hooks Class Initialized
DEBUG - 2021-06-07 15:48:25 --> UTF-8 Support Enabled
INFO - 2021-06-07 15:48:25 --> Utf8 Class Initialized
INFO - 2021-06-07 15:48:25 --> URI Class Initialized
DEBUG - 2021-06-07 15:48:25 --> No URI present. Default controller set.
INFO - 2021-06-07 15:48:25 --> Router Class Initialized
INFO - 2021-06-07 15:48:25 --> Output Class Initialized
INFO - 2021-06-07 15:48:25 --> Security Class Initialized
DEBUG - 2021-06-07 15:48:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-07 15:48:25 --> Input Class Initialized
INFO - 2021-06-07 15:48:25 --> Language Class Initialized
INFO - 2021-06-07 15:48:25 --> Loader Class Initialized
INFO - 2021-06-07 15:48:25 --> Helper loaded: url_helper
INFO - 2021-06-07 15:48:25 --> Helper loaded: form_helper
INFO - 2021-06-07 15:48:25 --> Helper loaded: common_helper
INFO - 2021-06-07 15:48:25 --> Database Driver Class Initialized
DEBUG - 2021-06-07 15:48:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-07 15:48:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-07 15:48:25 --> Controller Class Initialized
INFO - 2021-06-07 15:48:25 --> Form Validation Class Initialized
DEBUG - 2021-06-07 15:48:25 --> Encrypt Class Initialized
DEBUG - 2021-06-07 15:48:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-06-07 15:48:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-06-07 15:48:25 --> Email Class Initialized
INFO - 2021-06-07 15:48:25 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-06-07 15:48:25 --> Calendar Class Initialized
INFO - 2021-06-07 15:48:25 --> Model "Login_model" initialized
INFO - 2021-06-07 15:48:25 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-06-07 15:48:25 --> Final output sent to browser
DEBUG - 2021-06-07 15:48:25 --> Total execution time: 0.0188
ERROR - 2021-06-07 15:55:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-07 15:55:20 --> Config Class Initialized
INFO - 2021-06-07 15:55:20 --> Hooks Class Initialized
DEBUG - 2021-06-07 15:55:20 --> UTF-8 Support Enabled
INFO - 2021-06-07 15:55:20 --> Utf8 Class Initialized
INFO - 2021-06-07 15:55:20 --> URI Class Initialized
INFO - 2021-06-07 15:55:20 --> Router Class Initialized
INFO - 2021-06-07 15:55:20 --> Output Class Initialized
INFO - 2021-06-07 15:55:20 --> Security Class Initialized
DEBUG - 2021-06-07 15:55:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-07 15:55:20 --> Input Class Initialized
INFO - 2021-06-07 15:55:20 --> Language Class Initialized
INFO - 2021-06-07 15:55:20 --> Loader Class Initialized
INFO - 2021-06-07 15:55:20 --> Helper loaded: url_helper
INFO - 2021-06-07 15:55:20 --> Helper loaded: form_helper
INFO - 2021-06-07 15:55:20 --> Helper loaded: common_helper
INFO - 2021-06-07 15:55:20 --> Database Driver Class Initialized
DEBUG - 2021-06-07 15:55:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-07 15:55:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-07 15:55:20 --> Controller Class Initialized
INFO - 2021-06-07 15:55:20 --> Form Validation Class Initialized
INFO - 2021-06-07 15:55:20 --> Model "Case_model" initialized
INFO - 2021-06-07 15:55:20 --> Model "Hospital_model" initialized
INFO - 2021-06-07 15:55:20 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/header.php
INFO - 2021-06-07 15:55:20 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/transaction/upcomingFollowup.php
INFO - 2021-06-07 15:55:20 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/footer.php
INFO - 2021-06-07 15:55:20 --> Final output sent to browser
DEBUG - 2021-06-07 15:55:20 --> Total execution time: 0.0201
ERROR - 2021-06-07 15:55:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-07 15:55:21 --> Config Class Initialized
INFO - 2021-06-07 15:55:21 --> Hooks Class Initialized
DEBUG - 2021-06-07 15:55:21 --> UTF-8 Support Enabled
INFO - 2021-06-07 15:55:21 --> Utf8 Class Initialized
INFO - 2021-06-07 15:55:21 --> URI Class Initialized
INFO - 2021-06-07 15:55:21 --> Router Class Initialized
INFO - 2021-06-07 15:55:21 --> Output Class Initialized
INFO - 2021-06-07 15:55:21 --> Security Class Initialized
DEBUG - 2021-06-07 15:55:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-07 15:55:21 --> Input Class Initialized
INFO - 2021-06-07 15:55:21 --> Language Class Initialized
ERROR - 2021-06-07 15:55:21 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-06-07 15:56:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-07 15:56:32 --> Config Class Initialized
INFO - 2021-06-07 15:56:32 --> Hooks Class Initialized
DEBUG - 2021-06-07 15:56:32 --> UTF-8 Support Enabled
INFO - 2021-06-07 15:56:32 --> Utf8 Class Initialized
INFO - 2021-06-07 15:56:32 --> URI Class Initialized
INFO - 2021-06-07 15:56:32 --> Router Class Initialized
INFO - 2021-06-07 15:56:32 --> Output Class Initialized
INFO - 2021-06-07 15:56:32 --> Security Class Initialized
DEBUG - 2021-06-07 15:56:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-07 15:56:32 --> Input Class Initialized
INFO - 2021-06-07 15:56:32 --> Language Class Initialized
INFO - 2021-06-07 15:56:32 --> Loader Class Initialized
INFO - 2021-06-07 15:56:32 --> Helper loaded: url_helper
INFO - 2021-06-07 15:56:32 --> Helper loaded: form_helper
INFO - 2021-06-07 15:56:32 --> Helper loaded: common_helper
INFO - 2021-06-07 15:56:32 --> Database Driver Class Initialized
DEBUG - 2021-06-07 15:56:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-07 15:56:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-07 15:56:32 --> Controller Class Initialized
INFO - 2021-06-07 15:56:32 --> Form Validation Class Initialized
INFO - 2021-06-07 15:56:32 --> Model "Case_model" initialized
INFO - 2021-06-07 15:56:34 --> Model "Hospital_model" initialized
INFO - 2021-06-07 15:56:34 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/header.php
INFO - 2021-06-07 15:56:34 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/transaction/upcomingFollowup.php
INFO - 2021-06-07 15:56:34 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/footer.php
INFO - 2021-06-07 15:56:34 --> Final output sent to browser
DEBUG - 2021-06-07 15:56:34 --> Total execution time: 2.5098
ERROR - 2021-06-07 15:56:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-07 15:56:35 --> Config Class Initialized
INFO - 2021-06-07 15:56:35 --> Hooks Class Initialized
DEBUG - 2021-06-07 15:56:35 --> UTF-8 Support Enabled
INFO - 2021-06-07 15:56:35 --> Utf8 Class Initialized
INFO - 2021-06-07 15:56:35 --> URI Class Initialized
INFO - 2021-06-07 15:56:35 --> Router Class Initialized
INFO - 2021-06-07 15:56:35 --> Output Class Initialized
INFO - 2021-06-07 15:56:35 --> Security Class Initialized
DEBUG - 2021-06-07 15:56:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-07 15:56:35 --> Input Class Initialized
INFO - 2021-06-07 15:56:35 --> Language Class Initialized
ERROR - 2021-06-07 15:56:35 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-06-07 15:56:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-07 15:56:38 --> Config Class Initialized
INFO - 2021-06-07 15:56:38 --> Hooks Class Initialized
DEBUG - 2021-06-07 15:56:38 --> UTF-8 Support Enabled
INFO - 2021-06-07 15:56:38 --> Utf8 Class Initialized
INFO - 2021-06-07 15:56:38 --> URI Class Initialized
INFO - 2021-06-07 15:56:38 --> Router Class Initialized
INFO - 2021-06-07 15:56:38 --> Output Class Initialized
INFO - 2021-06-07 15:56:38 --> Security Class Initialized
DEBUG - 2021-06-07 15:56:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-07 15:56:38 --> Input Class Initialized
INFO - 2021-06-07 15:56:38 --> Language Class Initialized
INFO - 2021-06-07 15:56:38 --> Loader Class Initialized
INFO - 2021-06-07 15:56:38 --> Helper loaded: url_helper
INFO - 2021-06-07 15:56:38 --> Helper loaded: form_helper
INFO - 2021-06-07 15:56:38 --> Helper loaded: common_helper
INFO - 2021-06-07 15:56:38 --> Database Driver Class Initialized
DEBUG - 2021-06-07 15:56:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-07 15:56:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-07 15:56:38 --> Controller Class Initialized
INFO - 2021-06-07 15:56:38 --> Form Validation Class Initialized
INFO - 2021-06-07 15:56:38 --> Model "Case_model" initialized
INFO - 2021-06-07 15:56:41 --> Model "Hospital_model" initialized
INFO - 2021-06-07 15:56:41 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/header.php
INFO - 2021-06-07 15:56:41 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/transaction/upcomingFollowup.php
INFO - 2021-06-07 15:56:41 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/footer.php
INFO - 2021-06-07 15:56:41 --> Final output sent to browser
DEBUG - 2021-06-07 15:56:41 --> Total execution time: 2.7564
ERROR - 2021-06-07 15:56:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-07 15:56:41 --> Config Class Initialized
INFO - 2021-06-07 15:56:41 --> Hooks Class Initialized
DEBUG - 2021-06-07 15:56:41 --> UTF-8 Support Enabled
INFO - 2021-06-07 15:56:41 --> Utf8 Class Initialized
INFO - 2021-06-07 15:56:41 --> URI Class Initialized
INFO - 2021-06-07 15:56:41 --> Router Class Initialized
INFO - 2021-06-07 15:56:41 --> Output Class Initialized
INFO - 2021-06-07 15:56:41 --> Security Class Initialized
DEBUG - 2021-06-07 15:56:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-07 15:56:41 --> Input Class Initialized
INFO - 2021-06-07 15:56:41 --> Language Class Initialized
ERROR - 2021-06-07 15:56:41 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-06-07 15:56:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-07 15:56:51 --> Config Class Initialized
INFO - 2021-06-07 15:56:51 --> Hooks Class Initialized
DEBUG - 2021-06-07 15:56:51 --> UTF-8 Support Enabled
INFO - 2021-06-07 15:56:51 --> Utf8 Class Initialized
INFO - 2021-06-07 15:56:51 --> URI Class Initialized
INFO - 2021-06-07 15:56:51 --> Router Class Initialized
INFO - 2021-06-07 15:56:51 --> Output Class Initialized
INFO - 2021-06-07 15:56:51 --> Security Class Initialized
DEBUG - 2021-06-07 15:56:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-07 15:56:51 --> Input Class Initialized
INFO - 2021-06-07 15:56:51 --> Language Class Initialized
INFO - 2021-06-07 15:56:51 --> Loader Class Initialized
INFO - 2021-06-07 15:56:51 --> Helper loaded: url_helper
INFO - 2021-06-07 15:56:51 --> Helper loaded: form_helper
INFO - 2021-06-07 15:56:51 --> Helper loaded: common_helper
INFO - 2021-06-07 15:56:51 --> Database Driver Class Initialized
DEBUG - 2021-06-07 15:56:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-07 15:56:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-07 15:56:51 --> Controller Class Initialized
INFO - 2021-06-07 15:56:51 --> Form Validation Class Initialized
INFO - 2021-06-07 15:56:51 --> Model "Case_model" initialized
INFO - 2021-06-07 15:56:54 --> Model "Hospital_model" initialized
INFO - 2021-06-07 15:56:54 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/header.php
INFO - 2021-06-07 15:56:54 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/transaction/upcomingFollowup.php
INFO - 2021-06-07 15:56:54 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/footer.php
INFO - 2021-06-07 15:56:54 --> Final output sent to browser
DEBUG - 2021-06-07 15:56:54 --> Total execution time: 2.5977
ERROR - 2021-06-07 15:56:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-07 15:56:54 --> Config Class Initialized
INFO - 2021-06-07 15:56:54 --> Hooks Class Initialized
DEBUG - 2021-06-07 15:56:54 --> UTF-8 Support Enabled
INFO - 2021-06-07 15:56:54 --> Utf8 Class Initialized
INFO - 2021-06-07 15:56:54 --> URI Class Initialized
INFO - 2021-06-07 15:56:54 --> Router Class Initialized
INFO - 2021-06-07 15:56:54 --> Output Class Initialized
INFO - 2021-06-07 15:56:54 --> Security Class Initialized
DEBUG - 2021-06-07 15:56:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-07 15:56:54 --> Input Class Initialized
INFO - 2021-06-07 15:56:54 --> Language Class Initialized
ERROR - 2021-06-07 15:56:54 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-06-07 16:02:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-07 16:02:49 --> Config Class Initialized
INFO - 2021-06-07 16:02:49 --> Hooks Class Initialized
DEBUG - 2021-06-07 16:02:49 --> UTF-8 Support Enabled
INFO - 2021-06-07 16:02:49 --> Utf8 Class Initialized
INFO - 2021-06-07 16:02:49 --> URI Class Initialized
INFO - 2021-06-07 16:02:49 --> Router Class Initialized
INFO - 2021-06-07 16:02:49 --> Output Class Initialized
INFO - 2021-06-07 16:02:49 --> Security Class Initialized
DEBUG - 2021-06-07 16:02:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-07 16:02:49 --> Input Class Initialized
INFO - 2021-06-07 16:02:49 --> Language Class Initialized
INFO - 2021-06-07 16:02:49 --> Loader Class Initialized
INFO - 2021-06-07 16:02:49 --> Helper loaded: url_helper
INFO - 2021-06-07 16:02:49 --> Helper loaded: form_helper
INFO - 2021-06-07 16:02:49 --> Helper loaded: common_helper
INFO - 2021-06-07 16:02:49 --> Database Driver Class Initialized
DEBUG - 2021-06-07 16:02:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-07 16:02:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-07 16:02:49 --> Controller Class Initialized
INFO - 2021-06-07 16:02:49 --> Form Validation Class Initialized
DEBUG - 2021-06-07 16:02:49 --> Encrypt Class Initialized
INFO - 2021-06-07 16:02:49 --> Model "Patient_model" initialized
INFO - 2021-06-07 16:02:49 --> Model "Patientcase_model" initialized
INFO - 2021-06-07 16:02:49 --> Model "Referredby_model" initialized
INFO - 2021-06-07 16:02:49 --> Model "Prefix_master" initialized
INFO - 2021-06-07 16:02:49 --> Model "Hospital_model" initialized
INFO - 2021-06-07 16:02:49 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/header.php
INFO - 2021-06-07 16:02:49 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/patient/patientview.php
INFO - 2021-06-07 16:02:49 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/footer.php
INFO - 2021-06-07 16:02:49 --> Final output sent to browser
DEBUG - 2021-06-07 16:02:49 --> Total execution time: 0.0504
ERROR - 2021-06-07 16:02:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-07 16:02:50 --> Config Class Initialized
INFO - 2021-06-07 16:02:50 --> Hooks Class Initialized
DEBUG - 2021-06-07 16:02:50 --> UTF-8 Support Enabled
INFO - 2021-06-07 16:02:50 --> Utf8 Class Initialized
INFO - 2021-06-07 16:02:50 --> URI Class Initialized
INFO - 2021-06-07 16:02:50 --> Router Class Initialized
INFO - 2021-06-07 16:02:50 --> Output Class Initialized
INFO - 2021-06-07 16:02:50 --> Security Class Initialized
DEBUG - 2021-06-07 16:02:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-07 16:02:50 --> Input Class Initialized
INFO - 2021-06-07 16:02:50 --> Language Class Initialized
ERROR - 2021-06-07 16:02:50 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-06-07 16:09:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-07 16:09:11 --> Config Class Initialized
INFO - 2021-06-07 16:09:11 --> Hooks Class Initialized
DEBUG - 2021-06-07 16:09:11 --> UTF-8 Support Enabled
INFO - 2021-06-07 16:09:11 --> Utf8 Class Initialized
INFO - 2021-06-07 16:09:11 --> URI Class Initialized
INFO - 2021-06-07 16:09:11 --> Router Class Initialized
INFO - 2021-06-07 16:09:11 --> Output Class Initialized
INFO - 2021-06-07 16:09:11 --> Security Class Initialized
DEBUG - 2021-06-07 16:09:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-07 16:09:11 --> Input Class Initialized
INFO - 2021-06-07 16:09:11 --> Language Class Initialized
INFO - 2021-06-07 16:09:11 --> Loader Class Initialized
INFO - 2021-06-07 16:09:11 --> Helper loaded: url_helper
INFO - 2021-06-07 16:09:11 --> Helper loaded: form_helper
INFO - 2021-06-07 16:09:11 --> Helper loaded: common_helper
INFO - 2021-06-07 16:09:11 --> Database Driver Class Initialized
DEBUG - 2021-06-07 16:09:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-07 16:09:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-07 16:09:11 --> Controller Class Initialized
INFO - 2021-06-07 16:09:11 --> Form Validation Class Initialized
DEBUG - 2021-06-07 16:09:11 --> Encrypt Class Initialized
INFO - 2021-06-07 16:09:11 --> Model "Referredby_model" initialized
INFO - 2021-06-07 16:09:11 --> Model "Users_model" initialized
INFO - 2021-06-07 16:09:11 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/header.php
INFO - 2021-06-07 16:09:11 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/users/index.php
INFO - 2021-06-07 16:09:11 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/footer.php
INFO - 2021-06-07 16:09:11 --> Final output sent to browser
DEBUG - 2021-06-07 16:09:11 --> Total execution time: 0.0837
ERROR - 2021-06-07 16:09:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-07 16:09:12 --> Config Class Initialized
INFO - 2021-06-07 16:09:12 --> Hooks Class Initialized
DEBUG - 2021-06-07 16:09:12 --> UTF-8 Support Enabled
INFO - 2021-06-07 16:09:12 --> Utf8 Class Initialized
INFO - 2021-06-07 16:09:12 --> URI Class Initialized
INFO - 2021-06-07 16:09:12 --> Router Class Initialized
INFO - 2021-06-07 16:09:12 --> Output Class Initialized
INFO - 2021-06-07 16:09:12 --> Security Class Initialized
DEBUG - 2021-06-07 16:09:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-07 16:09:12 --> Input Class Initialized
INFO - 2021-06-07 16:09:12 --> Language Class Initialized
ERROR - 2021-06-07 16:09:12 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-06-07 18:46:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-07 18:46:36 --> Config Class Initialized
INFO - 2021-06-07 18:46:36 --> Hooks Class Initialized
DEBUG - 2021-06-07 18:46:36 --> UTF-8 Support Enabled
INFO - 2021-06-07 18:46:36 --> Utf8 Class Initialized
INFO - 2021-06-07 18:46:36 --> URI Class Initialized
DEBUG - 2021-06-07 18:46:36 --> No URI present. Default controller set.
INFO - 2021-06-07 18:46:36 --> Router Class Initialized
INFO - 2021-06-07 18:46:36 --> Output Class Initialized
INFO - 2021-06-07 18:46:36 --> Security Class Initialized
DEBUG - 2021-06-07 18:46:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-07 18:46:36 --> Input Class Initialized
INFO - 2021-06-07 18:46:36 --> Language Class Initialized
INFO - 2021-06-07 18:46:36 --> Loader Class Initialized
INFO - 2021-06-07 18:46:36 --> Helper loaded: url_helper
INFO - 2021-06-07 18:46:36 --> Helper loaded: form_helper
INFO - 2021-06-07 18:46:36 --> Helper loaded: common_helper
INFO - 2021-06-07 18:46:36 --> Database Driver Class Initialized
DEBUG - 2021-06-07 18:46:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-07 18:46:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-07 18:46:36 --> Controller Class Initialized
INFO - 2021-06-07 18:46:36 --> Form Validation Class Initialized
DEBUG - 2021-06-07 18:46:36 --> Encrypt Class Initialized
DEBUG - 2021-06-07 18:46:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-06-07 18:46:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-06-07 18:46:36 --> Email Class Initialized
INFO - 2021-06-07 18:46:36 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-06-07 18:46:36 --> Calendar Class Initialized
INFO - 2021-06-07 18:46:36 --> Model "Login_model" initialized
INFO - 2021-06-07 18:46:36 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-06-07 18:46:36 --> Final output sent to browser
DEBUG - 2021-06-07 18:46:36 --> Total execution time: 0.0549
ERROR - 2021-06-07 18:46:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-07 18:46:41 --> Config Class Initialized
INFO - 2021-06-07 18:46:41 --> Hooks Class Initialized
DEBUG - 2021-06-07 18:46:41 --> UTF-8 Support Enabled
INFO - 2021-06-07 18:46:41 --> Utf8 Class Initialized
INFO - 2021-06-07 18:46:41 --> URI Class Initialized
DEBUG - 2021-06-07 18:46:41 --> No URI present. Default controller set.
INFO - 2021-06-07 18:46:41 --> Router Class Initialized
INFO - 2021-06-07 18:46:41 --> Output Class Initialized
INFO - 2021-06-07 18:46:41 --> Security Class Initialized
DEBUG - 2021-06-07 18:46:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-07 18:46:41 --> Input Class Initialized
INFO - 2021-06-07 18:46:41 --> Language Class Initialized
INFO - 2021-06-07 18:46:41 --> Loader Class Initialized
INFO - 2021-06-07 18:46:41 --> Helper loaded: url_helper
INFO - 2021-06-07 18:46:41 --> Helper loaded: form_helper
INFO - 2021-06-07 18:46:41 --> Helper loaded: common_helper
INFO - 2021-06-07 18:46:41 --> Database Driver Class Initialized
DEBUG - 2021-06-07 18:46:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-07 18:46:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-07 18:46:41 --> Controller Class Initialized
INFO - 2021-06-07 18:46:41 --> Form Validation Class Initialized
DEBUG - 2021-06-07 18:46:41 --> Encrypt Class Initialized
DEBUG - 2021-06-07 18:46:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-06-07 18:46:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-06-07 18:46:41 --> Email Class Initialized
INFO - 2021-06-07 18:46:41 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-06-07 18:46:41 --> Calendar Class Initialized
INFO - 2021-06-07 18:46:41 --> Model "Login_model" initialized
INFO - 2021-06-07 18:46:41 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-06-07 18:46:41 --> Final output sent to browser
DEBUG - 2021-06-07 18:46:41 --> Total execution time: 0.0227
ERROR - 2021-06-07 18:46:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-07 18:46:42 --> Config Class Initialized
INFO - 2021-06-07 18:46:42 --> Hooks Class Initialized
DEBUG - 2021-06-07 18:46:42 --> UTF-8 Support Enabled
INFO - 2021-06-07 18:46:42 --> Utf8 Class Initialized
INFO - 2021-06-07 18:46:42 --> URI Class Initialized
INFO - 2021-06-07 18:46:42 --> Router Class Initialized
INFO - 2021-06-07 18:46:42 --> Output Class Initialized
INFO - 2021-06-07 18:46:42 --> Security Class Initialized
DEBUG - 2021-06-07 18:46:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-07 18:46:42 --> Input Class Initialized
INFO - 2021-06-07 18:46:42 --> Language Class Initialized
ERROR - 2021-06-07 18:46:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-07 18:46:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-07 18:46:44 --> Config Class Initialized
INFO - 2021-06-07 18:46:44 --> Hooks Class Initialized
DEBUG - 2021-06-07 18:46:44 --> UTF-8 Support Enabled
INFO - 2021-06-07 18:46:44 --> Utf8 Class Initialized
INFO - 2021-06-07 18:46:44 --> URI Class Initialized
INFO - 2021-06-07 18:46:44 --> Router Class Initialized
INFO - 2021-06-07 18:46:44 --> Output Class Initialized
INFO - 2021-06-07 18:46:44 --> Security Class Initialized
DEBUG - 2021-06-07 18:46:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-07 18:46:44 --> Input Class Initialized
INFO - 2021-06-07 18:46:44 --> Language Class Initialized
INFO - 2021-06-07 18:46:44 --> Loader Class Initialized
INFO - 2021-06-07 18:46:44 --> Helper loaded: url_helper
INFO - 2021-06-07 18:46:44 --> Helper loaded: form_helper
INFO - 2021-06-07 18:46:44 --> Helper loaded: common_helper
INFO - 2021-06-07 18:46:44 --> Database Driver Class Initialized
DEBUG - 2021-06-07 18:46:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-07 18:46:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-07 18:46:44 --> Controller Class Initialized
INFO - 2021-06-07 18:46:44 --> Form Validation Class Initialized
DEBUG - 2021-06-07 18:46:44 --> Encrypt Class Initialized
DEBUG - 2021-06-07 18:46:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-06-07 18:46:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-06-07 18:46:44 --> Email Class Initialized
INFO - 2021-06-07 18:46:44 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-06-07 18:46:44 --> Calendar Class Initialized
INFO - 2021-06-07 18:46:44 --> Model "Login_model" initialized
INFO - 2021-06-07 18:46:44 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2021-06-07 18:46:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-07 18:46:44 --> Config Class Initialized
INFO - 2021-06-07 18:46:44 --> Hooks Class Initialized
DEBUG - 2021-06-07 18:46:44 --> UTF-8 Support Enabled
INFO - 2021-06-07 18:46:44 --> Utf8 Class Initialized
INFO - 2021-06-07 18:46:44 --> URI Class Initialized
INFO - 2021-06-07 18:46:44 --> Router Class Initialized
INFO - 2021-06-07 18:46:44 --> Output Class Initialized
INFO - 2021-06-07 18:46:44 --> Security Class Initialized
DEBUG - 2021-06-07 18:46:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-07 18:46:44 --> Input Class Initialized
INFO - 2021-06-07 18:46:44 --> Language Class Initialized
INFO - 2021-06-07 18:46:44 --> Loader Class Initialized
INFO - 2021-06-07 18:46:44 --> Helper loaded: url_helper
INFO - 2021-06-07 18:46:44 --> Helper loaded: form_helper
INFO - 2021-06-07 18:46:44 --> Helper loaded: common_helper
INFO - 2021-06-07 18:46:44 --> Database Driver Class Initialized
DEBUG - 2021-06-07 18:46:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-07 18:46:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-07 18:46:44 --> Controller Class Initialized
INFO - 2021-06-07 18:46:44 --> Form Validation Class Initialized
DEBUG - 2021-06-07 18:46:44 --> Encrypt Class Initialized
INFO - 2021-06-07 18:46:44 --> Model "Login_model" initialized
INFO - 2021-06-07 18:46:44 --> Model "Dashboard_model" initialized
INFO - 2021-06-07 18:46:44 --> Model "Case_model" initialized
INFO - 2021-06-07 18:46:47 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/header.php
INFO - 2021-06-07 18:46:53 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/dashboard/index.php
INFO - 2021-06-07 18:46:53 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/footer.php
INFO - 2021-06-07 18:46:53 --> Final output sent to browser
DEBUG - 2021-06-07 18:46:53 --> Total execution time: 8.9003
ERROR - 2021-06-07 18:46:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-07 18:46:55 --> Config Class Initialized
INFO - 2021-06-07 18:46:55 --> Hooks Class Initialized
DEBUG - 2021-06-07 18:46:55 --> UTF-8 Support Enabled
INFO - 2021-06-07 18:46:55 --> Utf8 Class Initialized
INFO - 2021-06-07 18:46:55 --> URI Class Initialized
INFO - 2021-06-07 18:46:55 --> Router Class Initialized
INFO - 2021-06-07 18:46:55 --> Output Class Initialized
INFO - 2021-06-07 18:46:55 --> Security Class Initialized
DEBUG - 2021-06-07 18:46:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-07 18:46:55 --> Input Class Initialized
INFO - 2021-06-07 18:46:55 --> Language Class Initialized
ERROR - 2021-06-07 18:46:55 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-06-07 18:47:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-07 18:47:06 --> Config Class Initialized
INFO - 2021-06-07 18:47:06 --> Hooks Class Initialized
DEBUG - 2021-06-07 18:47:06 --> UTF-8 Support Enabled
INFO - 2021-06-07 18:47:06 --> Utf8 Class Initialized
INFO - 2021-06-07 18:47:06 --> URI Class Initialized
INFO - 2021-06-07 18:47:06 --> Router Class Initialized
INFO - 2021-06-07 18:47:06 --> Output Class Initialized
INFO - 2021-06-07 18:47:06 --> Security Class Initialized
DEBUG - 2021-06-07 18:47:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-07 18:47:06 --> Input Class Initialized
INFO - 2021-06-07 18:47:06 --> Language Class Initialized
INFO - 2021-06-07 18:47:06 --> Loader Class Initialized
INFO - 2021-06-07 18:47:06 --> Helper loaded: url_helper
INFO - 2021-06-07 18:47:06 --> Helper loaded: form_helper
INFO - 2021-06-07 18:47:06 --> Helper loaded: common_helper
INFO - 2021-06-07 18:47:06 --> Database Driver Class Initialized
DEBUG - 2021-06-07 18:47:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-07 18:47:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-07 18:47:06 --> Controller Class Initialized
INFO - 2021-06-07 18:47:06 --> Form Validation Class Initialized
INFO - 2021-06-07 18:47:06 --> Model "Report_model" initialized
INFO - 2021-06-07 18:47:06 --> Model "Case_model" initialized
INFO - 2021-06-07 18:47:06 --> Model "Hospital_model" initialized
INFO - 2021-06-07 18:47:06 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/header.php
INFO - 2021-06-07 18:47:06 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/reports/patient_details.php
INFO - 2021-06-07 18:47:06 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/footer.php
INFO - 2021-06-07 18:47:06 --> Final output sent to browser
DEBUG - 2021-06-07 18:47:06 --> Total execution time: 0.0228
ERROR - 2021-06-07 18:47:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-07 18:47:07 --> Config Class Initialized
INFO - 2021-06-07 18:47:07 --> Hooks Class Initialized
DEBUG - 2021-06-07 18:47:07 --> UTF-8 Support Enabled
INFO - 2021-06-07 18:47:07 --> Utf8 Class Initialized
INFO - 2021-06-07 18:47:07 --> URI Class Initialized
INFO - 2021-06-07 18:47:07 --> Router Class Initialized
INFO - 2021-06-07 18:47:07 --> Output Class Initialized
INFO - 2021-06-07 18:47:07 --> Security Class Initialized
DEBUG - 2021-06-07 18:47:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-07 18:47:07 --> Input Class Initialized
INFO - 2021-06-07 18:47:07 --> Language Class Initialized
ERROR - 2021-06-07 18:47:07 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-06-07 18:47:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-07 18:47:20 --> Config Class Initialized
INFO - 2021-06-07 18:47:20 --> Hooks Class Initialized
DEBUG - 2021-06-07 18:47:20 --> UTF-8 Support Enabled
INFO - 2021-06-07 18:47:20 --> Utf8 Class Initialized
INFO - 2021-06-07 18:47:20 --> URI Class Initialized
INFO - 2021-06-07 18:47:20 --> Router Class Initialized
INFO - 2021-06-07 18:47:20 --> Output Class Initialized
INFO - 2021-06-07 18:47:20 --> Security Class Initialized
DEBUG - 2021-06-07 18:47:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-07 18:47:20 --> Input Class Initialized
INFO - 2021-06-07 18:47:20 --> Language Class Initialized
INFO - 2021-06-07 18:47:20 --> Loader Class Initialized
INFO - 2021-06-07 18:47:20 --> Helper loaded: url_helper
INFO - 2021-06-07 18:47:20 --> Helper loaded: form_helper
INFO - 2021-06-07 18:47:20 --> Helper loaded: common_helper
INFO - 2021-06-07 18:47:20 --> Database Driver Class Initialized
DEBUG - 2021-06-07 18:47:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-07 18:47:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-07 18:47:20 --> Controller Class Initialized
INFO - 2021-06-07 18:47:20 --> Form Validation Class Initialized
INFO - 2021-06-07 18:47:20 --> Model "Case_model" initialized
INFO - 2021-06-07 18:47:20 --> Model "Hospital_model" initialized
INFO - 2021-06-07 18:47:20 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/header.php
INFO - 2021-06-07 18:47:20 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/transaction/upcomingFollowup.php
INFO - 2021-06-07 18:47:20 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/footer.php
INFO - 2021-06-07 18:47:20 --> Final output sent to browser
DEBUG - 2021-06-07 18:47:20 --> Total execution time: 0.0192
ERROR - 2021-06-07 18:47:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-07 18:47:20 --> Config Class Initialized
INFO - 2021-06-07 18:47:20 --> Hooks Class Initialized
DEBUG - 2021-06-07 18:47:20 --> UTF-8 Support Enabled
INFO - 2021-06-07 18:47:20 --> Utf8 Class Initialized
INFO - 2021-06-07 18:47:20 --> URI Class Initialized
INFO - 2021-06-07 18:47:20 --> Router Class Initialized
INFO - 2021-06-07 18:47:20 --> Output Class Initialized
INFO - 2021-06-07 18:47:20 --> Security Class Initialized
DEBUG - 2021-06-07 18:47:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-07 18:47:20 --> Input Class Initialized
INFO - 2021-06-07 18:47:20 --> Language Class Initialized
ERROR - 2021-06-07 18:47:20 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-06-07 18:47:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-07 18:47:28 --> Config Class Initialized
INFO - 2021-06-07 18:47:28 --> Hooks Class Initialized
DEBUG - 2021-06-07 18:47:28 --> UTF-8 Support Enabled
INFO - 2021-06-07 18:47:28 --> Utf8 Class Initialized
INFO - 2021-06-07 18:47:28 --> URI Class Initialized
INFO - 2021-06-07 18:47:28 --> Router Class Initialized
INFO - 2021-06-07 18:47:28 --> Output Class Initialized
INFO - 2021-06-07 18:47:28 --> Security Class Initialized
DEBUG - 2021-06-07 18:47:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-07 18:47:28 --> Input Class Initialized
INFO - 2021-06-07 18:47:28 --> Language Class Initialized
ERROR - 2021-06-07 18:47:28 --> 404 Page Not Found: Karoclient/css
ERROR - 2021-06-07 18:47:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-07 18:47:32 --> Config Class Initialized
INFO - 2021-06-07 18:47:32 --> Hooks Class Initialized
DEBUG - 2021-06-07 18:47:32 --> UTF-8 Support Enabled
INFO - 2021-06-07 18:47:32 --> Utf8 Class Initialized
INFO - 2021-06-07 18:47:32 --> URI Class Initialized
INFO - 2021-06-07 18:47:32 --> Router Class Initialized
INFO - 2021-06-07 18:47:32 --> Output Class Initialized
INFO - 2021-06-07 18:47:32 --> Security Class Initialized
DEBUG - 2021-06-07 18:47:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-07 18:47:32 --> Input Class Initialized
INFO - 2021-06-07 18:47:32 --> Language Class Initialized
INFO - 2021-06-07 18:47:32 --> Loader Class Initialized
INFO - 2021-06-07 18:47:32 --> Helper loaded: url_helper
INFO - 2021-06-07 18:47:32 --> Helper loaded: form_helper
INFO - 2021-06-07 18:47:32 --> Helper loaded: common_helper
INFO - 2021-06-07 18:47:32 --> Database Driver Class Initialized
DEBUG - 2021-06-07 18:47:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-07 18:47:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-07 18:47:32 --> Controller Class Initialized
INFO - 2021-06-07 18:47:32 --> Form Validation Class Initialized
INFO - 2021-06-07 18:47:32 --> Model "Case_model" initialized
INFO - 2021-06-07 18:47:35 --> Model "Hospital_model" initialized
INFO - 2021-06-07 18:47:35 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/header.php
INFO - 2021-06-07 18:47:35 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/transaction/upcomingFollowup.php
INFO - 2021-06-07 18:47:35 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/footer.php
INFO - 2021-06-07 18:47:35 --> Final output sent to browser
DEBUG - 2021-06-07 18:47:35 --> Total execution time: 2.5230
ERROR - 2021-06-07 18:47:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-07 18:47:35 --> Config Class Initialized
INFO - 2021-06-07 18:47:35 --> Hooks Class Initialized
DEBUG - 2021-06-07 18:47:35 --> UTF-8 Support Enabled
INFO - 2021-06-07 18:47:35 --> Utf8 Class Initialized
INFO - 2021-06-07 18:47:35 --> URI Class Initialized
INFO - 2021-06-07 18:47:35 --> Router Class Initialized
INFO - 2021-06-07 18:47:35 --> Output Class Initialized
INFO - 2021-06-07 18:47:35 --> Security Class Initialized
DEBUG - 2021-06-07 18:47:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-07 18:47:35 --> Input Class Initialized
INFO - 2021-06-07 18:47:35 --> Language Class Initialized
ERROR - 2021-06-07 18:47:35 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-06-07 18:47:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-07 18:47:46 --> Config Class Initialized
INFO - 2021-06-07 18:47:46 --> Hooks Class Initialized
DEBUG - 2021-06-07 18:47:46 --> UTF-8 Support Enabled
INFO - 2021-06-07 18:47:46 --> Utf8 Class Initialized
INFO - 2021-06-07 18:47:46 --> URI Class Initialized
INFO - 2021-06-07 18:47:46 --> Router Class Initialized
INFO - 2021-06-07 18:47:46 --> Output Class Initialized
INFO - 2021-06-07 18:47:46 --> Security Class Initialized
DEBUG - 2021-06-07 18:47:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-07 18:47:46 --> Input Class Initialized
INFO - 2021-06-07 18:47:46 --> Language Class Initialized
INFO - 2021-06-07 18:47:46 --> Loader Class Initialized
INFO - 2021-06-07 18:47:46 --> Helper loaded: url_helper
INFO - 2021-06-07 18:47:46 --> Helper loaded: form_helper
INFO - 2021-06-07 18:47:46 --> Helper loaded: common_helper
INFO - 2021-06-07 18:47:46 --> Database Driver Class Initialized
DEBUG - 2021-06-07 18:47:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-07 18:47:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-07 18:47:46 --> Controller Class Initialized
INFO - 2021-06-07 18:47:46 --> Form Validation Class Initialized
DEBUG - 2021-06-07 18:47:46 --> Encrypt Class Initialized
INFO - 2021-06-07 18:47:46 --> Model "Patient_model" initialized
INFO - 2021-06-07 18:47:46 --> Model "Patientcase_model" initialized
INFO - 2021-06-07 18:47:46 --> Model "Referredby_model" initialized
INFO - 2021-06-07 18:47:46 --> Model "Prefix_master" initialized
INFO - 2021-06-07 18:47:46 --> Model "Hospital_model" initialized
INFO - 2021-06-07 18:47:46 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/header.php
INFO - 2021-06-07 18:47:51 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/patient/patientview.php
INFO - 2021-06-07 18:47:51 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/footer.php
ERROR - 2021-06-07 18:47:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-07 18:47:51 --> Config Class Initialized
INFO - 2021-06-07 18:47:51 --> Hooks Class Initialized
DEBUG - 2021-06-07 18:47:51 --> UTF-8 Support Enabled
INFO - 2021-06-07 18:47:51 --> Utf8 Class Initialized
INFO - 2021-06-07 18:47:51 --> URI Class Initialized
INFO - 2021-06-07 18:47:51 --> Router Class Initialized
INFO - 2021-06-07 18:47:51 --> Output Class Initialized
INFO - 2021-06-07 18:47:51 --> Security Class Initialized
DEBUG - 2021-06-07 18:47:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-07 18:47:51 --> Input Class Initialized
INFO - 2021-06-07 18:47:51 --> Language Class Initialized
ERROR - 2021-06-07 18:47:51 --> 404 Page Not Found: Karoclient/usersprofile
INFO - 2021-06-07 18:47:54 --> Final output sent to browser
DEBUG - 2021-06-07 18:47:54 --> Total execution time: 4.7206
ERROR - 2021-06-07 18:48:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-07 18:48:21 --> Config Class Initialized
INFO - 2021-06-07 18:48:21 --> Hooks Class Initialized
DEBUG - 2021-06-07 18:48:21 --> UTF-8 Support Enabled
INFO - 2021-06-07 18:48:21 --> Utf8 Class Initialized
INFO - 2021-06-07 18:48:21 --> URI Class Initialized
INFO - 2021-06-07 18:48:21 --> Router Class Initialized
INFO - 2021-06-07 18:48:21 --> Output Class Initialized
INFO - 2021-06-07 18:48:21 --> Security Class Initialized
DEBUG - 2021-06-07 18:48:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-07 18:48:21 --> Input Class Initialized
INFO - 2021-06-07 18:48:21 --> Language Class Initialized
INFO - 2021-06-07 18:48:21 --> Loader Class Initialized
INFO - 2021-06-07 18:48:21 --> Helper loaded: url_helper
INFO - 2021-06-07 18:48:21 --> Helper loaded: form_helper
INFO - 2021-06-07 18:48:21 --> Helper loaded: common_helper
INFO - 2021-06-07 18:48:21 --> Database Driver Class Initialized
DEBUG - 2021-06-07 18:48:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-07 18:48:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-07 18:48:21 --> Controller Class Initialized
INFO - 2021-06-07 18:48:21 --> Form Validation Class Initialized
DEBUG - 2021-06-07 18:48:21 --> Encrypt Class Initialized
INFO - 2021-06-07 18:48:21 --> Model "Patient_model" initialized
INFO - 2021-06-07 18:48:21 --> Model "Patientcase_model" initialized
INFO - 2021-06-07 18:48:21 --> Model "Referredby_model" initialized
INFO - 2021-06-07 18:48:21 --> Model "Prefix_master" initialized
INFO - 2021-06-07 18:48:21 --> Model "Hospital_model" initialized
INFO - 2021-06-07 18:48:21 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/header.php
INFO - 2021-06-07 18:48:23 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/patient/patientview.php
INFO - 2021-06-07 18:48:23 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/footer.php
ERROR - 2021-06-07 18:48:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-07 18:48:23 --> Config Class Initialized
INFO - 2021-06-07 18:48:23 --> Hooks Class Initialized
DEBUG - 2021-06-07 18:48:23 --> UTF-8 Support Enabled
INFO - 2021-06-07 18:48:23 --> Utf8 Class Initialized
INFO - 2021-06-07 18:48:23 --> URI Class Initialized
INFO - 2021-06-07 18:48:23 --> Router Class Initialized
INFO - 2021-06-07 18:48:23 --> Output Class Initialized
INFO - 2021-06-07 18:48:23 --> Security Class Initialized
DEBUG - 2021-06-07 18:48:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-07 18:48:23 --> Input Class Initialized
INFO - 2021-06-07 18:48:23 --> Language Class Initialized
ERROR - 2021-06-07 18:48:23 --> 404 Page Not Found: Karoclient/usersprofile
INFO - 2021-06-07 18:48:24 --> Final output sent to browser
DEBUG - 2021-06-07 18:48:24 --> Total execution time: 1.5518
ERROR - 2021-06-07 18:48:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-07 18:48:36 --> Config Class Initialized
INFO - 2021-06-07 18:48:36 --> Hooks Class Initialized
DEBUG - 2021-06-07 18:48:36 --> UTF-8 Support Enabled
INFO - 2021-06-07 18:48:36 --> Utf8 Class Initialized
INFO - 2021-06-07 18:48:36 --> URI Class Initialized
INFO - 2021-06-07 18:48:36 --> Router Class Initialized
INFO - 2021-06-07 18:48:36 --> Output Class Initialized
INFO - 2021-06-07 18:48:36 --> Security Class Initialized
DEBUG - 2021-06-07 18:48:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-07 18:48:36 --> Input Class Initialized
INFO - 2021-06-07 18:48:36 --> Language Class Initialized
INFO - 2021-06-07 18:48:36 --> Loader Class Initialized
INFO - 2021-06-07 18:48:36 --> Helper loaded: url_helper
INFO - 2021-06-07 18:48:36 --> Helper loaded: form_helper
INFO - 2021-06-07 18:48:36 --> Helper loaded: common_helper
INFO - 2021-06-07 18:48:36 --> Database Driver Class Initialized
DEBUG - 2021-06-07 18:48:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-07 18:48:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-07 18:48:36 --> Controller Class Initialized
INFO - 2021-06-07 18:48:36 --> Form Validation Class Initialized
DEBUG - 2021-06-07 18:48:36 --> Encrypt Class Initialized
INFO - 2021-06-07 18:48:36 --> Model "Patient_model" initialized
INFO - 2021-06-07 18:48:36 --> Model "Patientcase_model" initialized
INFO - 2021-06-07 18:48:36 --> Model "Referredby_model" initialized
INFO - 2021-06-07 18:48:36 --> Model "Prefix_master" initialized
INFO - 2021-06-07 18:48:36 --> Model "Hospital_model" initialized
INFO - 2021-06-07 18:48:36 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/header.php
INFO - 2021-06-07 18:48:39 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/patient/patientview.php
INFO - 2021-06-07 18:48:39 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/footer.php
ERROR - 2021-06-07 18:48:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-07 18:48:40 --> Config Class Initialized
INFO - 2021-06-07 18:48:40 --> Hooks Class Initialized
DEBUG - 2021-06-07 18:48:40 --> UTF-8 Support Enabled
INFO - 2021-06-07 18:48:40 --> Utf8 Class Initialized
INFO - 2021-06-07 18:48:40 --> URI Class Initialized
INFO - 2021-06-07 18:48:40 --> Router Class Initialized
INFO - 2021-06-07 18:48:40 --> Output Class Initialized
INFO - 2021-06-07 18:48:40 --> Security Class Initialized
DEBUG - 2021-06-07 18:48:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-07 18:48:40 --> Input Class Initialized
INFO - 2021-06-07 18:48:40 --> Language Class Initialized
ERROR - 2021-06-07 18:48:40 --> 404 Page Not Found: Karoclient/usersprofile
INFO - 2021-06-07 18:48:42 --> Final output sent to browser
DEBUG - 2021-06-07 18:48:42 --> Total execution time: 2.5870
