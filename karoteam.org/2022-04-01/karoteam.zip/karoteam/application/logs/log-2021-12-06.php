<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-12-06 03:04:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-06 03:04:15 --> Config Class Initialized
INFO - 2021-12-06 03:04:15 --> Hooks Class Initialized
DEBUG - 2021-12-06 03:04:15 --> UTF-8 Support Enabled
INFO - 2021-12-06 03:04:15 --> Utf8 Class Initialized
INFO - 2021-12-06 03:04:15 --> URI Class Initialized
DEBUG - 2021-12-06 03:04:15 --> No URI present. Default controller set.
INFO - 2021-12-06 03:04:15 --> Router Class Initialized
INFO - 2021-12-06 03:04:15 --> Output Class Initialized
INFO - 2021-12-06 03:04:15 --> Security Class Initialized
DEBUG - 2021-12-06 03:04:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 03:04:15 --> Input Class Initialized
INFO - 2021-12-06 03:04:15 --> Language Class Initialized
INFO - 2021-12-06 03:04:15 --> Loader Class Initialized
INFO - 2021-12-06 03:04:15 --> Helper loaded: url_helper
INFO - 2021-12-06 03:04:15 --> Helper loaded: form_helper
INFO - 2021-12-06 03:04:15 --> Helper loaded: common_helper
INFO - 2021-12-06 03:04:15 --> Database Driver Class Initialized
DEBUG - 2021-12-06 03:04:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 03:04:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 03:04:15 --> Controller Class Initialized
INFO - 2021-12-06 03:04:15 --> Form Validation Class Initialized
DEBUG - 2021-12-06 03:04:15 --> Encrypt Class Initialized
DEBUG - 2021-12-06 03:04:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-06 03:04:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-06 03:04:15 --> Email Class Initialized
INFO - 2021-12-06 03:04:15 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-06 03:04:15 --> Calendar Class Initialized
INFO - 2021-12-06 03:04:15 --> Model "Login_model" initialized
INFO - 2021-12-06 03:04:15 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-06 03:04:15 --> Final output sent to browser
DEBUG - 2021-12-06 03:04:15 --> Total execution time: 0.0357
ERROR - 2021-12-06 03:11:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-06 03:11:57 --> Config Class Initialized
INFO - 2021-12-06 03:11:57 --> Hooks Class Initialized
DEBUG - 2021-12-06 03:11:57 --> UTF-8 Support Enabled
INFO - 2021-12-06 03:11:57 --> Utf8 Class Initialized
INFO - 2021-12-06 03:11:57 --> URI Class Initialized
DEBUG - 2021-12-06 03:11:57 --> No URI present. Default controller set.
INFO - 2021-12-06 03:11:57 --> Router Class Initialized
INFO - 2021-12-06 03:11:57 --> Output Class Initialized
INFO - 2021-12-06 03:11:57 --> Security Class Initialized
DEBUG - 2021-12-06 03:11:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 03:11:57 --> Input Class Initialized
INFO - 2021-12-06 03:11:57 --> Language Class Initialized
INFO - 2021-12-06 03:11:57 --> Loader Class Initialized
INFO - 2021-12-06 03:11:57 --> Helper loaded: url_helper
INFO - 2021-12-06 03:11:57 --> Helper loaded: form_helper
INFO - 2021-12-06 03:11:57 --> Helper loaded: common_helper
INFO - 2021-12-06 03:11:57 --> Database Driver Class Initialized
DEBUG - 2021-12-06 03:11:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 03:11:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 03:11:57 --> Controller Class Initialized
INFO - 2021-12-06 03:11:57 --> Form Validation Class Initialized
DEBUG - 2021-12-06 03:11:57 --> Encrypt Class Initialized
DEBUG - 2021-12-06 03:11:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-06 03:11:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-06 03:11:57 --> Email Class Initialized
INFO - 2021-12-06 03:11:57 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-06 03:11:57 --> Calendar Class Initialized
INFO - 2021-12-06 03:11:57 --> Model "Login_model" initialized
INFO - 2021-12-06 03:11:57 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-06 03:11:57 --> Final output sent to browser
DEBUG - 2021-12-06 03:11:57 --> Total execution time: 0.0274
ERROR - 2021-12-06 04:39:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-06 04:39:33 --> Config Class Initialized
INFO - 2021-12-06 04:39:33 --> Hooks Class Initialized
DEBUG - 2021-12-06 04:39:33 --> UTF-8 Support Enabled
INFO - 2021-12-06 04:39:33 --> Utf8 Class Initialized
INFO - 2021-12-06 04:39:33 --> URI Class Initialized
DEBUG - 2021-12-06 04:39:33 --> No URI present. Default controller set.
INFO - 2021-12-06 04:39:33 --> Router Class Initialized
INFO - 2021-12-06 04:39:33 --> Output Class Initialized
INFO - 2021-12-06 04:39:33 --> Security Class Initialized
DEBUG - 2021-12-06 04:39:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 04:39:33 --> Input Class Initialized
INFO - 2021-12-06 04:39:33 --> Language Class Initialized
INFO - 2021-12-06 04:39:33 --> Loader Class Initialized
INFO - 2021-12-06 04:39:33 --> Helper loaded: url_helper
INFO - 2021-12-06 04:39:33 --> Helper loaded: form_helper
INFO - 2021-12-06 04:39:33 --> Helper loaded: common_helper
INFO - 2021-12-06 04:39:33 --> Database Driver Class Initialized
DEBUG - 2021-12-06 04:39:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 04:39:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 04:39:33 --> Controller Class Initialized
INFO - 2021-12-06 04:39:33 --> Form Validation Class Initialized
DEBUG - 2021-12-06 04:39:33 --> Encrypt Class Initialized
DEBUG - 2021-12-06 04:39:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-06 04:39:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-06 04:39:33 --> Email Class Initialized
INFO - 2021-12-06 04:39:33 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-06 04:39:33 --> Calendar Class Initialized
INFO - 2021-12-06 04:39:33 --> Model "Login_model" initialized
INFO - 2021-12-06 04:39:33 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-06 04:39:33 --> Final output sent to browser
DEBUG - 2021-12-06 04:39:33 --> Total execution time: 0.0493
ERROR - 2021-12-06 06:23:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-06 06:23:32 --> Config Class Initialized
INFO - 2021-12-06 06:23:32 --> Hooks Class Initialized
DEBUG - 2021-12-06 06:23:32 --> UTF-8 Support Enabled
INFO - 2021-12-06 06:23:32 --> Utf8 Class Initialized
INFO - 2021-12-06 06:23:32 --> URI Class Initialized
DEBUG - 2021-12-06 06:23:32 --> No URI present. Default controller set.
INFO - 2021-12-06 06:23:32 --> Router Class Initialized
INFO - 2021-12-06 06:23:32 --> Output Class Initialized
INFO - 2021-12-06 06:23:32 --> Security Class Initialized
DEBUG - 2021-12-06 06:23:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 06:23:32 --> Input Class Initialized
INFO - 2021-12-06 06:23:32 --> Language Class Initialized
INFO - 2021-12-06 06:23:32 --> Loader Class Initialized
INFO - 2021-12-06 06:23:32 --> Helper loaded: url_helper
INFO - 2021-12-06 06:23:32 --> Helper loaded: form_helper
INFO - 2021-12-06 06:23:32 --> Helper loaded: common_helper
INFO - 2021-12-06 06:23:32 --> Database Driver Class Initialized
DEBUG - 2021-12-06 06:23:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 06:23:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 06:23:32 --> Controller Class Initialized
INFO - 2021-12-06 06:23:32 --> Form Validation Class Initialized
DEBUG - 2021-12-06 06:23:32 --> Encrypt Class Initialized
DEBUG - 2021-12-06 06:23:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-06 06:23:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-06 06:23:32 --> Email Class Initialized
INFO - 2021-12-06 06:23:32 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-06 06:23:32 --> Calendar Class Initialized
INFO - 2021-12-06 06:23:32 --> Model "Login_model" initialized
INFO - 2021-12-06 06:23:32 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-06 06:23:32 --> Final output sent to browser
DEBUG - 2021-12-06 06:23:32 --> Total execution time: 0.0278
ERROR - 2021-12-06 07:46:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-06 07:46:26 --> Config Class Initialized
INFO - 2021-12-06 07:46:26 --> Hooks Class Initialized
DEBUG - 2021-12-06 07:46:26 --> UTF-8 Support Enabled
INFO - 2021-12-06 07:46:26 --> Utf8 Class Initialized
INFO - 2021-12-06 07:46:26 --> URI Class Initialized
DEBUG - 2021-12-06 07:46:26 --> No URI present. Default controller set.
INFO - 2021-12-06 07:46:26 --> Router Class Initialized
INFO - 2021-12-06 07:46:26 --> Output Class Initialized
INFO - 2021-12-06 07:46:26 --> Security Class Initialized
DEBUG - 2021-12-06 07:46:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 07:46:26 --> Input Class Initialized
INFO - 2021-12-06 07:46:26 --> Language Class Initialized
INFO - 2021-12-06 07:46:26 --> Loader Class Initialized
INFO - 2021-12-06 07:46:26 --> Helper loaded: url_helper
INFO - 2021-12-06 07:46:26 --> Helper loaded: form_helper
INFO - 2021-12-06 07:46:26 --> Helper loaded: common_helper
INFO - 2021-12-06 07:46:26 --> Database Driver Class Initialized
DEBUG - 2021-12-06 07:46:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 07:46:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 07:46:26 --> Controller Class Initialized
INFO - 2021-12-06 07:46:26 --> Form Validation Class Initialized
DEBUG - 2021-12-06 07:46:26 --> Encrypt Class Initialized
DEBUG - 2021-12-06 07:46:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-06 07:46:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-06 07:46:26 --> Email Class Initialized
INFO - 2021-12-06 07:46:26 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-06 07:46:26 --> Calendar Class Initialized
INFO - 2021-12-06 07:46:26 --> Model "Login_model" initialized
INFO - 2021-12-06 07:46:26 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-06 07:46:26 --> Final output sent to browser
DEBUG - 2021-12-06 07:46:26 --> Total execution time: 0.0289
ERROR - 2021-12-06 07:46:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-06 07:46:27 --> Config Class Initialized
INFO - 2021-12-06 07:46:27 --> Hooks Class Initialized
DEBUG - 2021-12-06 07:46:27 --> UTF-8 Support Enabled
INFO - 2021-12-06 07:46:27 --> Utf8 Class Initialized
INFO - 2021-12-06 07:46:27 --> URI Class Initialized
DEBUG - 2021-12-06 07:46:27 --> No URI present. Default controller set.
INFO - 2021-12-06 07:46:27 --> Router Class Initialized
INFO - 2021-12-06 07:46:27 --> Output Class Initialized
INFO - 2021-12-06 07:46:27 --> Security Class Initialized
DEBUG - 2021-12-06 07:46:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 07:46:27 --> Input Class Initialized
INFO - 2021-12-06 07:46:27 --> Language Class Initialized
INFO - 2021-12-06 07:46:27 --> Loader Class Initialized
INFO - 2021-12-06 07:46:27 --> Helper loaded: url_helper
INFO - 2021-12-06 07:46:27 --> Helper loaded: form_helper
INFO - 2021-12-06 07:46:27 --> Helper loaded: common_helper
INFO - 2021-12-06 07:46:27 --> Database Driver Class Initialized
DEBUG - 2021-12-06 07:46:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 07:46:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 07:46:27 --> Controller Class Initialized
INFO - 2021-12-06 07:46:27 --> Form Validation Class Initialized
DEBUG - 2021-12-06 07:46:27 --> Encrypt Class Initialized
DEBUG - 2021-12-06 07:46:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-06 07:46:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-06 07:46:27 --> Email Class Initialized
INFO - 2021-12-06 07:46:27 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-06 07:46:27 --> Calendar Class Initialized
INFO - 2021-12-06 07:46:27 --> Model "Login_model" initialized
INFO - 2021-12-06 07:46:27 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-06 07:46:27 --> Final output sent to browser
DEBUG - 2021-12-06 07:46:27 --> Total execution time: 0.0219
ERROR - 2021-12-06 07:46:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-06 07:46:27 --> Config Class Initialized
INFO - 2021-12-06 07:46:27 --> Hooks Class Initialized
DEBUG - 2021-12-06 07:46:27 --> UTF-8 Support Enabled
INFO - 2021-12-06 07:46:27 --> Utf8 Class Initialized
INFO - 2021-12-06 07:46:27 --> URI Class Initialized
INFO - 2021-12-06 07:46:27 --> Router Class Initialized
INFO - 2021-12-06 07:46:27 --> Output Class Initialized
INFO - 2021-12-06 07:46:27 --> Security Class Initialized
DEBUG - 2021-12-06 07:46:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 07:46:27 --> Input Class Initialized
INFO - 2021-12-06 07:46:27 --> Language Class Initialized
ERROR - 2021-12-06 07:46:27 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
ERROR - 2021-12-06 07:46:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-06 07:46:28 --> Config Class Initialized
INFO - 2021-12-06 07:46:28 --> Hooks Class Initialized
DEBUG - 2021-12-06 07:46:28 --> UTF-8 Support Enabled
INFO - 2021-12-06 07:46:28 --> Utf8 Class Initialized
INFO - 2021-12-06 07:46:28 --> URI Class Initialized
INFO - 2021-12-06 07:46:28 --> Router Class Initialized
INFO - 2021-12-06 07:46:28 --> Output Class Initialized
INFO - 2021-12-06 07:46:28 --> Security Class Initialized
DEBUG - 2021-12-06 07:46:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 07:46:28 --> Input Class Initialized
INFO - 2021-12-06 07:46:28 --> Language Class Initialized
ERROR - 2021-12-06 07:46:28 --> 404 Page Not Found: Blog/wp-includes
ERROR - 2021-12-06 07:46:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-06 07:46:29 --> Config Class Initialized
INFO - 2021-12-06 07:46:29 --> Hooks Class Initialized
DEBUG - 2021-12-06 07:46:29 --> UTF-8 Support Enabled
INFO - 2021-12-06 07:46:29 --> Utf8 Class Initialized
INFO - 2021-12-06 07:46:29 --> URI Class Initialized
INFO - 2021-12-06 07:46:29 --> Router Class Initialized
INFO - 2021-12-06 07:46:29 --> Output Class Initialized
INFO - 2021-12-06 07:46:29 --> Security Class Initialized
DEBUG - 2021-12-06 07:46:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 07:46:29 --> Input Class Initialized
INFO - 2021-12-06 07:46:29 --> Language Class Initialized
ERROR - 2021-12-06 07:46:29 --> 404 Page Not Found: Web/wp-includes
ERROR - 2021-12-06 07:46:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-06 07:46:29 --> Config Class Initialized
INFO - 2021-12-06 07:46:29 --> Hooks Class Initialized
DEBUG - 2021-12-06 07:46:29 --> UTF-8 Support Enabled
INFO - 2021-12-06 07:46:29 --> Utf8 Class Initialized
INFO - 2021-12-06 07:46:29 --> URI Class Initialized
INFO - 2021-12-06 07:46:29 --> Router Class Initialized
INFO - 2021-12-06 07:46:29 --> Output Class Initialized
INFO - 2021-12-06 07:46:29 --> Security Class Initialized
DEBUG - 2021-12-06 07:46:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 07:46:29 --> Input Class Initialized
INFO - 2021-12-06 07:46:29 --> Language Class Initialized
ERROR - 2021-12-06 07:46:29 --> 404 Page Not Found: Wordpress/wp-includes
ERROR - 2021-12-06 07:46:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-06 07:46:30 --> Config Class Initialized
INFO - 2021-12-06 07:46:30 --> Hooks Class Initialized
DEBUG - 2021-12-06 07:46:30 --> UTF-8 Support Enabled
INFO - 2021-12-06 07:46:30 --> Utf8 Class Initialized
INFO - 2021-12-06 07:46:30 --> URI Class Initialized
INFO - 2021-12-06 07:46:30 --> Router Class Initialized
INFO - 2021-12-06 07:46:30 --> Output Class Initialized
INFO - 2021-12-06 07:46:30 --> Security Class Initialized
DEBUG - 2021-12-06 07:46:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 07:46:30 --> Input Class Initialized
INFO - 2021-12-06 07:46:30 --> Language Class Initialized
ERROR - 2021-12-06 07:46:30 --> 404 Page Not Found: Website/wp-includes
ERROR - 2021-12-06 07:46:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-06 07:46:31 --> Config Class Initialized
INFO - 2021-12-06 07:46:31 --> Hooks Class Initialized
DEBUG - 2021-12-06 07:46:31 --> UTF-8 Support Enabled
INFO - 2021-12-06 07:46:31 --> Utf8 Class Initialized
INFO - 2021-12-06 07:46:31 --> URI Class Initialized
INFO - 2021-12-06 07:46:31 --> Router Class Initialized
INFO - 2021-12-06 07:46:31 --> Output Class Initialized
INFO - 2021-12-06 07:46:31 --> Security Class Initialized
DEBUG - 2021-12-06 07:46:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 07:46:31 --> Input Class Initialized
INFO - 2021-12-06 07:46:31 --> Language Class Initialized
ERROR - 2021-12-06 07:46:31 --> 404 Page Not Found: Wp/wp-includes
ERROR - 2021-12-06 07:46:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-06 07:46:31 --> Config Class Initialized
INFO - 2021-12-06 07:46:31 --> Hooks Class Initialized
DEBUG - 2021-12-06 07:46:31 --> UTF-8 Support Enabled
INFO - 2021-12-06 07:46:31 --> Utf8 Class Initialized
INFO - 2021-12-06 07:46:31 --> URI Class Initialized
INFO - 2021-12-06 07:46:31 --> Router Class Initialized
INFO - 2021-12-06 07:46:31 --> Output Class Initialized
INFO - 2021-12-06 07:46:31 --> Security Class Initialized
DEBUG - 2021-12-06 07:46:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 07:46:31 --> Input Class Initialized
INFO - 2021-12-06 07:46:31 --> Language Class Initialized
ERROR - 2021-12-06 07:46:31 --> 404 Page Not Found: News/wp-includes
ERROR - 2021-12-06 07:46:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-06 07:46:32 --> Config Class Initialized
INFO - 2021-12-06 07:46:32 --> Hooks Class Initialized
DEBUG - 2021-12-06 07:46:32 --> UTF-8 Support Enabled
INFO - 2021-12-06 07:46:32 --> Utf8 Class Initialized
INFO - 2021-12-06 07:46:32 --> URI Class Initialized
INFO - 2021-12-06 07:46:32 --> Router Class Initialized
INFO - 2021-12-06 07:46:32 --> Output Class Initialized
INFO - 2021-12-06 07:46:32 --> Security Class Initialized
DEBUG - 2021-12-06 07:46:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 07:46:32 --> Input Class Initialized
INFO - 2021-12-06 07:46:32 --> Language Class Initialized
ERROR - 2021-12-06 07:46:32 --> 404 Page Not Found: 2020/wp-includes
ERROR - 2021-12-06 07:46:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-06 07:46:32 --> Config Class Initialized
INFO - 2021-12-06 07:46:32 --> Hooks Class Initialized
DEBUG - 2021-12-06 07:46:32 --> UTF-8 Support Enabled
INFO - 2021-12-06 07:46:32 --> Utf8 Class Initialized
INFO - 2021-12-06 07:46:32 --> URI Class Initialized
INFO - 2021-12-06 07:46:32 --> Router Class Initialized
INFO - 2021-12-06 07:46:32 --> Output Class Initialized
INFO - 2021-12-06 07:46:32 --> Security Class Initialized
DEBUG - 2021-12-06 07:46:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 07:46:32 --> Input Class Initialized
INFO - 2021-12-06 07:46:32 --> Language Class Initialized
ERROR - 2021-12-06 07:46:32 --> 404 Page Not Found: 2019/wp-includes
ERROR - 2021-12-06 07:46:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-06 07:46:33 --> Config Class Initialized
INFO - 2021-12-06 07:46:33 --> Hooks Class Initialized
DEBUG - 2021-12-06 07:46:33 --> UTF-8 Support Enabled
INFO - 2021-12-06 07:46:33 --> Utf8 Class Initialized
INFO - 2021-12-06 07:46:33 --> URI Class Initialized
INFO - 2021-12-06 07:46:33 --> Router Class Initialized
INFO - 2021-12-06 07:46:33 --> Output Class Initialized
INFO - 2021-12-06 07:46:33 --> Security Class Initialized
DEBUG - 2021-12-06 07:46:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 07:46:33 --> Input Class Initialized
INFO - 2021-12-06 07:46:33 --> Language Class Initialized
ERROR - 2021-12-06 07:46:33 --> 404 Page Not Found: Shop/wp-includes
ERROR - 2021-12-06 07:46:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-06 07:46:33 --> Config Class Initialized
INFO - 2021-12-06 07:46:33 --> Hooks Class Initialized
DEBUG - 2021-12-06 07:46:33 --> UTF-8 Support Enabled
INFO - 2021-12-06 07:46:33 --> Utf8 Class Initialized
INFO - 2021-12-06 07:46:33 --> URI Class Initialized
INFO - 2021-12-06 07:46:33 --> Router Class Initialized
INFO - 2021-12-06 07:46:33 --> Output Class Initialized
INFO - 2021-12-06 07:46:33 --> Security Class Initialized
DEBUG - 2021-12-06 07:46:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 07:46:33 --> Input Class Initialized
INFO - 2021-12-06 07:46:33 --> Language Class Initialized
ERROR - 2021-12-06 07:46:33 --> 404 Page Not Found: Wp1/wp-includes
ERROR - 2021-12-06 07:46:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-06 07:46:34 --> Config Class Initialized
INFO - 2021-12-06 07:46:34 --> Hooks Class Initialized
DEBUG - 2021-12-06 07:46:34 --> UTF-8 Support Enabled
INFO - 2021-12-06 07:46:34 --> Utf8 Class Initialized
INFO - 2021-12-06 07:46:34 --> URI Class Initialized
INFO - 2021-12-06 07:46:34 --> Router Class Initialized
INFO - 2021-12-06 07:46:34 --> Output Class Initialized
INFO - 2021-12-06 07:46:34 --> Security Class Initialized
DEBUG - 2021-12-06 07:46:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 07:46:34 --> Input Class Initialized
INFO - 2021-12-06 07:46:34 --> Language Class Initialized
ERROR - 2021-12-06 07:46:34 --> 404 Page Not Found: Test/wp-includes
ERROR - 2021-12-06 07:46:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-06 07:46:34 --> Config Class Initialized
INFO - 2021-12-06 07:46:34 --> Hooks Class Initialized
DEBUG - 2021-12-06 07:46:34 --> UTF-8 Support Enabled
INFO - 2021-12-06 07:46:34 --> Utf8 Class Initialized
INFO - 2021-12-06 07:46:34 --> URI Class Initialized
INFO - 2021-12-06 07:46:34 --> Router Class Initialized
INFO - 2021-12-06 07:46:34 --> Output Class Initialized
INFO - 2021-12-06 07:46:34 --> Security Class Initialized
DEBUG - 2021-12-06 07:46:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 07:46:34 --> Input Class Initialized
INFO - 2021-12-06 07:46:34 --> Language Class Initialized
ERROR - 2021-12-06 07:46:34 --> 404 Page Not Found: Wp2/wp-includes
ERROR - 2021-12-06 07:46:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-06 07:46:35 --> Config Class Initialized
INFO - 2021-12-06 07:46:35 --> Hooks Class Initialized
DEBUG - 2021-12-06 07:46:35 --> UTF-8 Support Enabled
INFO - 2021-12-06 07:46:35 --> Utf8 Class Initialized
INFO - 2021-12-06 07:46:35 --> URI Class Initialized
INFO - 2021-12-06 07:46:35 --> Router Class Initialized
INFO - 2021-12-06 07:46:35 --> Output Class Initialized
INFO - 2021-12-06 07:46:35 --> Security Class Initialized
DEBUG - 2021-12-06 07:46:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 07:46:35 --> Input Class Initialized
INFO - 2021-12-06 07:46:35 --> Language Class Initialized
ERROR - 2021-12-06 07:46:35 --> 404 Page Not Found: Site/wp-includes
ERROR - 2021-12-06 07:46:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-06 07:46:35 --> Config Class Initialized
INFO - 2021-12-06 07:46:35 --> Hooks Class Initialized
DEBUG - 2021-12-06 07:46:35 --> UTF-8 Support Enabled
INFO - 2021-12-06 07:46:35 --> Utf8 Class Initialized
INFO - 2021-12-06 07:46:35 --> URI Class Initialized
INFO - 2021-12-06 07:46:35 --> Router Class Initialized
INFO - 2021-12-06 07:46:35 --> Output Class Initialized
INFO - 2021-12-06 07:46:35 --> Security Class Initialized
DEBUG - 2021-12-06 07:46:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 07:46:35 --> Input Class Initialized
INFO - 2021-12-06 07:46:35 --> Language Class Initialized
ERROR - 2021-12-06 07:46:35 --> 404 Page Not Found: Cms/wp-includes
ERROR - 2021-12-06 07:46:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-06 07:46:36 --> Config Class Initialized
INFO - 2021-12-06 07:46:36 --> Hooks Class Initialized
DEBUG - 2021-12-06 07:46:36 --> UTF-8 Support Enabled
INFO - 2021-12-06 07:46:36 --> Utf8 Class Initialized
INFO - 2021-12-06 07:46:36 --> URI Class Initialized
INFO - 2021-12-06 07:46:36 --> Router Class Initialized
INFO - 2021-12-06 07:46:36 --> Output Class Initialized
INFO - 2021-12-06 07:46:36 --> Security Class Initialized
DEBUG - 2021-12-06 07:46:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 07:46:36 --> Input Class Initialized
INFO - 2021-12-06 07:46:36 --> Language Class Initialized
ERROR - 2021-12-06 07:46:36 --> 404 Page Not Found: Sito/wp-includes
ERROR - 2021-12-06 09:43:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-06 09:43:31 --> Config Class Initialized
INFO - 2021-12-06 09:43:31 --> Hooks Class Initialized
DEBUG - 2021-12-06 09:43:31 --> UTF-8 Support Enabled
INFO - 2021-12-06 09:43:31 --> Utf8 Class Initialized
INFO - 2021-12-06 09:43:31 --> URI Class Initialized
DEBUG - 2021-12-06 09:43:31 --> No URI present. Default controller set.
INFO - 2021-12-06 09:43:31 --> Router Class Initialized
INFO - 2021-12-06 09:43:31 --> Output Class Initialized
INFO - 2021-12-06 09:43:31 --> Security Class Initialized
DEBUG - 2021-12-06 09:43:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 09:43:31 --> Input Class Initialized
INFO - 2021-12-06 09:43:31 --> Language Class Initialized
INFO - 2021-12-06 09:43:31 --> Loader Class Initialized
INFO - 2021-12-06 09:43:31 --> Helper loaded: url_helper
INFO - 2021-12-06 09:43:31 --> Helper loaded: form_helper
INFO - 2021-12-06 09:43:31 --> Helper loaded: common_helper
INFO - 2021-12-06 09:43:31 --> Database Driver Class Initialized
DEBUG - 2021-12-06 09:43:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 09:43:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 09:43:31 --> Controller Class Initialized
INFO - 2021-12-06 09:43:31 --> Form Validation Class Initialized
DEBUG - 2021-12-06 09:43:31 --> Encrypt Class Initialized
DEBUG - 2021-12-06 09:43:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-06 09:43:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-06 09:43:31 --> Email Class Initialized
INFO - 2021-12-06 09:43:31 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-06 09:43:31 --> Calendar Class Initialized
INFO - 2021-12-06 09:43:31 --> Model "Login_model" initialized
INFO - 2021-12-06 09:43:31 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-06 09:43:31 --> Final output sent to browser
DEBUG - 2021-12-06 09:43:31 --> Total execution time: 0.0292
ERROR - 2021-12-06 10:12:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-06 10:12:56 --> Config Class Initialized
INFO - 2021-12-06 10:12:56 --> Hooks Class Initialized
DEBUG - 2021-12-06 10:12:56 --> UTF-8 Support Enabled
INFO - 2021-12-06 10:12:56 --> Utf8 Class Initialized
INFO - 2021-12-06 10:12:56 --> URI Class Initialized
DEBUG - 2021-12-06 10:12:56 --> No URI present. Default controller set.
INFO - 2021-12-06 10:12:56 --> Router Class Initialized
INFO - 2021-12-06 10:12:56 --> Output Class Initialized
INFO - 2021-12-06 10:12:56 --> Security Class Initialized
DEBUG - 2021-12-06 10:12:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 10:12:56 --> Input Class Initialized
INFO - 2021-12-06 10:12:56 --> Language Class Initialized
INFO - 2021-12-06 10:12:56 --> Loader Class Initialized
INFO - 2021-12-06 10:12:56 --> Helper loaded: url_helper
INFO - 2021-12-06 10:12:56 --> Helper loaded: form_helper
INFO - 2021-12-06 10:12:56 --> Helper loaded: common_helper
INFO - 2021-12-06 10:12:56 --> Database Driver Class Initialized
DEBUG - 2021-12-06 10:12:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 10:12:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 10:12:56 --> Controller Class Initialized
INFO - 2021-12-06 10:12:56 --> Form Validation Class Initialized
DEBUG - 2021-12-06 10:12:56 --> Encrypt Class Initialized
DEBUG - 2021-12-06 10:12:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-06 10:12:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-06 10:12:56 --> Email Class Initialized
INFO - 2021-12-06 10:12:56 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-06 10:12:56 --> Calendar Class Initialized
INFO - 2021-12-06 10:12:56 --> Model "Login_model" initialized
INFO - 2021-12-06 10:12:56 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-06 10:12:56 --> Final output sent to browser
DEBUG - 2021-12-06 10:12:56 --> Total execution time: 0.0243
ERROR - 2021-12-06 10:12:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-06 10:12:56 --> Config Class Initialized
INFO - 2021-12-06 10:12:56 --> Hooks Class Initialized
DEBUG - 2021-12-06 10:12:56 --> UTF-8 Support Enabled
INFO - 2021-12-06 10:12:56 --> Utf8 Class Initialized
INFO - 2021-12-06 10:12:56 --> URI Class Initialized
DEBUG - 2021-12-06 10:12:56 --> No URI present. Default controller set.
INFO - 2021-12-06 10:12:56 --> Router Class Initialized
INFO - 2021-12-06 10:12:56 --> Output Class Initialized
INFO - 2021-12-06 10:12:56 --> Security Class Initialized
DEBUG - 2021-12-06 10:12:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 10:12:56 --> Input Class Initialized
INFO - 2021-12-06 10:12:56 --> Language Class Initialized
INFO - 2021-12-06 10:12:56 --> Loader Class Initialized
INFO - 2021-12-06 10:12:56 --> Helper loaded: url_helper
INFO - 2021-12-06 10:12:56 --> Helper loaded: form_helper
INFO - 2021-12-06 10:12:56 --> Helper loaded: common_helper
INFO - 2021-12-06 10:12:56 --> Database Driver Class Initialized
DEBUG - 2021-12-06 10:12:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 10:12:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 10:12:56 --> Controller Class Initialized
INFO - 2021-12-06 10:12:56 --> Form Validation Class Initialized
DEBUG - 2021-12-06 10:12:56 --> Encrypt Class Initialized
DEBUG - 2021-12-06 10:12:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-06 10:12:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-06 10:12:56 --> Email Class Initialized
INFO - 2021-12-06 10:12:56 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-06 10:12:56 --> Calendar Class Initialized
INFO - 2021-12-06 10:12:56 --> Model "Login_model" initialized
INFO - 2021-12-06 10:12:56 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-06 10:12:56 --> Final output sent to browser
DEBUG - 2021-12-06 10:12:56 --> Total execution time: 0.0242
ERROR - 2021-12-06 10:12:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-06 10:12:57 --> Config Class Initialized
INFO - 2021-12-06 10:12:57 --> Hooks Class Initialized
DEBUG - 2021-12-06 10:12:57 --> UTF-8 Support Enabled
INFO - 2021-12-06 10:12:57 --> Utf8 Class Initialized
INFO - 2021-12-06 10:12:57 --> URI Class Initialized
DEBUG - 2021-12-06 10:12:57 --> No URI present. Default controller set.
INFO - 2021-12-06 10:12:57 --> Router Class Initialized
INFO - 2021-12-06 10:12:57 --> Output Class Initialized
INFO - 2021-12-06 10:12:57 --> Security Class Initialized
DEBUG - 2021-12-06 10:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 10:12:57 --> Input Class Initialized
INFO - 2021-12-06 10:12:57 --> Language Class Initialized
INFO - 2021-12-06 10:12:57 --> Loader Class Initialized
INFO - 2021-12-06 10:12:57 --> Helper loaded: url_helper
INFO - 2021-12-06 10:12:57 --> Helper loaded: form_helper
INFO - 2021-12-06 10:12:57 --> Helper loaded: common_helper
INFO - 2021-12-06 10:12:57 --> Database Driver Class Initialized
DEBUG - 2021-12-06 10:12:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 10:12:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 10:12:57 --> Controller Class Initialized
INFO - 2021-12-06 10:12:57 --> Form Validation Class Initialized
DEBUG - 2021-12-06 10:12:57 --> Encrypt Class Initialized
DEBUG - 2021-12-06 10:12:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-06 10:12:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-06 10:12:57 --> Email Class Initialized
INFO - 2021-12-06 10:12:57 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-06 10:12:57 --> Calendar Class Initialized
INFO - 2021-12-06 10:12:57 --> Model "Login_model" initialized
INFO - 2021-12-06 10:12:57 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-06 10:12:57 --> Final output sent to browser
DEBUG - 2021-12-06 10:12:57 --> Total execution time: 0.0221
ERROR - 2021-12-06 10:12:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-06 10:12:57 --> Config Class Initialized
INFO - 2021-12-06 10:12:57 --> Hooks Class Initialized
DEBUG - 2021-12-06 10:12:57 --> UTF-8 Support Enabled
INFO - 2021-12-06 10:12:57 --> Utf8 Class Initialized
INFO - 2021-12-06 10:12:57 --> URI Class Initialized
DEBUG - 2021-12-06 10:12:57 --> No URI present. Default controller set.
INFO - 2021-12-06 10:12:57 --> Router Class Initialized
INFO - 2021-12-06 10:12:57 --> Output Class Initialized
INFO - 2021-12-06 10:12:57 --> Security Class Initialized
DEBUG - 2021-12-06 10:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 10:12:57 --> Input Class Initialized
INFO - 2021-12-06 10:12:57 --> Language Class Initialized
INFO - 2021-12-06 10:12:57 --> Loader Class Initialized
INFO - 2021-12-06 10:12:57 --> Helper loaded: url_helper
INFO - 2021-12-06 10:12:57 --> Helper loaded: form_helper
INFO - 2021-12-06 10:12:57 --> Helper loaded: common_helper
INFO - 2021-12-06 10:12:57 --> Database Driver Class Initialized
DEBUG - 2021-12-06 10:12:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 10:12:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 10:12:57 --> Controller Class Initialized
INFO - 2021-12-06 10:12:57 --> Form Validation Class Initialized
DEBUG - 2021-12-06 10:12:57 --> Encrypt Class Initialized
DEBUG - 2021-12-06 10:12:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-06 10:12:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-06 10:12:57 --> Email Class Initialized
INFO - 2021-12-06 10:12:57 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-06 10:12:57 --> Calendar Class Initialized
INFO - 2021-12-06 10:12:57 --> Model "Login_model" initialized
INFO - 2021-12-06 10:12:57 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-06 10:12:57 --> Final output sent to browser
DEBUG - 2021-12-06 10:12:57 --> Total execution time: 0.0221
ERROR - 2021-12-06 10:12:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-06 10:12:57 --> Config Class Initialized
INFO - 2021-12-06 10:12:57 --> Hooks Class Initialized
DEBUG - 2021-12-06 10:12:57 --> UTF-8 Support Enabled
INFO - 2021-12-06 10:12:57 --> Utf8 Class Initialized
INFO - 2021-12-06 10:12:57 --> URI Class Initialized
DEBUG - 2021-12-06 10:12:57 --> No URI present. Default controller set.
INFO - 2021-12-06 10:12:57 --> Router Class Initialized
INFO - 2021-12-06 10:12:57 --> Output Class Initialized
INFO - 2021-12-06 10:12:57 --> Security Class Initialized
DEBUG - 2021-12-06 10:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 10:12:57 --> Input Class Initialized
INFO - 2021-12-06 10:12:57 --> Language Class Initialized
INFO - 2021-12-06 10:12:57 --> Loader Class Initialized
INFO - 2021-12-06 10:12:57 --> Helper loaded: url_helper
INFO - 2021-12-06 10:12:57 --> Helper loaded: form_helper
INFO - 2021-12-06 10:12:57 --> Helper loaded: common_helper
INFO - 2021-12-06 10:12:57 --> Database Driver Class Initialized
DEBUG - 2021-12-06 10:12:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 10:12:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 10:12:57 --> Controller Class Initialized
INFO - 2021-12-06 10:12:57 --> Form Validation Class Initialized
DEBUG - 2021-12-06 10:12:57 --> Encrypt Class Initialized
DEBUG - 2021-12-06 10:12:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-06 10:12:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-06 10:12:57 --> Email Class Initialized
INFO - 2021-12-06 10:12:57 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-06 10:12:57 --> Calendar Class Initialized
INFO - 2021-12-06 10:12:57 --> Model "Login_model" initialized
INFO - 2021-12-06 10:12:57 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-06 10:12:57 --> Final output sent to browser
DEBUG - 2021-12-06 10:12:57 --> Total execution time: 0.0222
ERROR - 2021-12-06 10:27:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-06 10:27:03 --> Config Class Initialized
INFO - 2021-12-06 10:27:03 --> Hooks Class Initialized
DEBUG - 2021-12-06 10:27:03 --> UTF-8 Support Enabled
INFO - 2021-12-06 10:27:03 --> Utf8 Class Initialized
INFO - 2021-12-06 10:27:03 --> URI Class Initialized
DEBUG - 2021-12-06 10:27:03 --> No URI present. Default controller set.
INFO - 2021-12-06 10:27:03 --> Router Class Initialized
INFO - 2021-12-06 10:27:03 --> Output Class Initialized
INFO - 2021-12-06 10:27:03 --> Security Class Initialized
DEBUG - 2021-12-06 10:27:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 10:27:03 --> Input Class Initialized
INFO - 2021-12-06 10:27:03 --> Language Class Initialized
INFO - 2021-12-06 10:27:03 --> Loader Class Initialized
INFO - 2021-12-06 10:27:03 --> Helper loaded: url_helper
INFO - 2021-12-06 10:27:03 --> Helper loaded: form_helper
INFO - 2021-12-06 10:27:03 --> Helper loaded: common_helper
INFO - 2021-12-06 10:27:03 --> Database Driver Class Initialized
DEBUG - 2021-12-06 10:27:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 10:27:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 10:27:03 --> Controller Class Initialized
INFO - 2021-12-06 10:27:03 --> Form Validation Class Initialized
DEBUG - 2021-12-06 10:27:03 --> Encrypt Class Initialized
DEBUG - 2021-12-06 10:27:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-06 10:27:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-06 10:27:03 --> Email Class Initialized
INFO - 2021-12-06 10:27:03 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-06 10:27:03 --> Calendar Class Initialized
INFO - 2021-12-06 10:27:03 --> Model "Login_model" initialized
INFO - 2021-12-06 10:27:03 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-06 10:27:03 --> Final output sent to browser
DEBUG - 2021-12-06 10:27:03 --> Total execution time: 0.0246
ERROR - 2021-12-06 10:27:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-06 10:27:04 --> Config Class Initialized
INFO - 2021-12-06 10:27:04 --> Hooks Class Initialized
DEBUG - 2021-12-06 10:27:04 --> UTF-8 Support Enabled
INFO - 2021-12-06 10:27:04 --> Utf8 Class Initialized
INFO - 2021-12-06 10:27:04 --> URI Class Initialized
DEBUG - 2021-12-06 10:27:04 --> No URI present. Default controller set.
INFO - 2021-12-06 10:27:04 --> Router Class Initialized
INFO - 2021-12-06 10:27:04 --> Output Class Initialized
INFO - 2021-12-06 10:27:04 --> Security Class Initialized
DEBUG - 2021-12-06 10:27:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 10:27:04 --> Input Class Initialized
INFO - 2021-12-06 10:27:04 --> Language Class Initialized
INFO - 2021-12-06 10:27:04 --> Loader Class Initialized
INFO - 2021-12-06 10:27:04 --> Helper loaded: url_helper
INFO - 2021-12-06 10:27:04 --> Helper loaded: form_helper
INFO - 2021-12-06 10:27:04 --> Helper loaded: common_helper
INFO - 2021-12-06 10:27:04 --> Database Driver Class Initialized
DEBUG - 2021-12-06 10:27:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 10:27:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 10:27:04 --> Controller Class Initialized
INFO - 2021-12-06 10:27:04 --> Form Validation Class Initialized
DEBUG - 2021-12-06 10:27:04 --> Encrypt Class Initialized
DEBUG - 2021-12-06 10:27:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-06 10:27:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-06 10:27:04 --> Email Class Initialized
INFO - 2021-12-06 10:27:04 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-06 10:27:04 --> Calendar Class Initialized
INFO - 2021-12-06 10:27:04 --> Model "Login_model" initialized
INFO - 2021-12-06 10:27:04 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-06 10:27:04 --> Final output sent to browser
DEBUG - 2021-12-06 10:27:04 --> Total execution time: 0.0244
ERROR - 2021-12-06 13:03:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-06 13:03:43 --> Config Class Initialized
INFO - 2021-12-06 13:03:43 --> Hooks Class Initialized
DEBUG - 2021-12-06 13:03:43 --> UTF-8 Support Enabled
INFO - 2021-12-06 13:03:43 --> Utf8 Class Initialized
INFO - 2021-12-06 13:03:43 --> URI Class Initialized
DEBUG - 2021-12-06 13:03:43 --> No URI present. Default controller set.
INFO - 2021-12-06 13:03:43 --> Router Class Initialized
INFO - 2021-12-06 13:03:43 --> Output Class Initialized
INFO - 2021-12-06 13:03:43 --> Security Class Initialized
DEBUG - 2021-12-06 13:03:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 13:03:43 --> Input Class Initialized
INFO - 2021-12-06 13:03:43 --> Language Class Initialized
INFO - 2021-12-06 13:03:43 --> Loader Class Initialized
INFO - 2021-12-06 13:03:43 --> Helper loaded: url_helper
INFO - 2021-12-06 13:03:43 --> Helper loaded: form_helper
INFO - 2021-12-06 13:03:43 --> Helper loaded: common_helper
INFO - 2021-12-06 13:03:43 --> Database Driver Class Initialized
DEBUG - 2021-12-06 13:03:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 13:03:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 13:03:43 --> Controller Class Initialized
INFO - 2021-12-06 13:03:43 --> Form Validation Class Initialized
DEBUG - 2021-12-06 13:03:43 --> Encrypt Class Initialized
DEBUG - 2021-12-06 13:03:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-06 13:03:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-06 13:03:43 --> Email Class Initialized
INFO - 2021-12-06 13:03:43 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-06 13:03:43 --> Calendar Class Initialized
INFO - 2021-12-06 13:03:43 --> Model "Login_model" initialized
INFO - 2021-12-06 13:03:43 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-06 13:03:43 --> Final output sent to browser
DEBUG - 2021-12-06 13:03:43 --> Total execution time: 0.0348
ERROR - 2021-12-06 14:18:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-06 14:18:17 --> Config Class Initialized
INFO - 2021-12-06 14:18:17 --> Hooks Class Initialized
DEBUG - 2021-12-06 14:18:17 --> UTF-8 Support Enabled
INFO - 2021-12-06 14:18:17 --> Utf8 Class Initialized
INFO - 2021-12-06 14:18:17 --> URI Class Initialized
DEBUG - 2021-12-06 14:18:17 --> No URI present. Default controller set.
INFO - 2021-12-06 14:18:17 --> Router Class Initialized
INFO - 2021-12-06 14:18:17 --> Output Class Initialized
INFO - 2021-12-06 14:18:17 --> Security Class Initialized
DEBUG - 2021-12-06 14:18:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 14:18:17 --> Input Class Initialized
INFO - 2021-12-06 14:18:17 --> Language Class Initialized
INFO - 2021-12-06 14:18:17 --> Loader Class Initialized
INFO - 2021-12-06 14:18:17 --> Helper loaded: url_helper
INFO - 2021-12-06 14:18:17 --> Helper loaded: form_helper
INFO - 2021-12-06 14:18:17 --> Helper loaded: common_helper
INFO - 2021-12-06 14:18:17 --> Database Driver Class Initialized
DEBUG - 2021-12-06 14:18:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 14:18:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 14:18:17 --> Controller Class Initialized
INFO - 2021-12-06 14:18:17 --> Form Validation Class Initialized
DEBUG - 2021-12-06 14:18:17 --> Encrypt Class Initialized
DEBUG - 2021-12-06 14:18:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-06 14:18:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-06 14:18:17 --> Email Class Initialized
INFO - 2021-12-06 14:18:17 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-06 14:18:17 --> Calendar Class Initialized
INFO - 2021-12-06 14:18:17 --> Model "Login_model" initialized
INFO - 2021-12-06 14:18:17 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-06 14:18:17 --> Final output sent to browser
DEBUG - 2021-12-06 14:18:17 --> Total execution time: 0.0231
ERROR - 2021-12-06 14:18:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-06 14:18:18 --> Config Class Initialized
INFO - 2021-12-06 14:18:18 --> Hooks Class Initialized
DEBUG - 2021-12-06 14:18:18 --> UTF-8 Support Enabled
INFO - 2021-12-06 14:18:18 --> Utf8 Class Initialized
INFO - 2021-12-06 14:18:18 --> URI Class Initialized
INFO - 2021-12-06 14:18:18 --> Router Class Initialized
INFO - 2021-12-06 14:18:18 --> Output Class Initialized
INFO - 2021-12-06 14:18:18 --> Security Class Initialized
DEBUG - 2021-12-06 14:18:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 14:18:18 --> Input Class Initialized
INFO - 2021-12-06 14:18:18 --> Language Class Initialized
ERROR - 2021-12-06 14:18:18 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2021-12-06 14:18:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-06 14:18:30 --> Config Class Initialized
INFO - 2021-12-06 14:18:30 --> Hooks Class Initialized
DEBUG - 2021-12-06 14:18:30 --> UTF-8 Support Enabled
INFO - 2021-12-06 14:18:30 --> Utf8 Class Initialized
INFO - 2021-12-06 14:18:30 --> URI Class Initialized
INFO - 2021-12-06 14:18:30 --> Router Class Initialized
INFO - 2021-12-06 14:18:30 --> Output Class Initialized
INFO - 2021-12-06 14:18:30 --> Security Class Initialized
DEBUG - 2021-12-06 14:18:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 14:18:30 --> Input Class Initialized
INFO - 2021-12-06 14:18:30 --> Language Class Initialized
INFO - 2021-12-06 14:18:30 --> Loader Class Initialized
INFO - 2021-12-06 14:18:30 --> Helper loaded: url_helper
INFO - 2021-12-06 14:18:30 --> Helper loaded: form_helper
INFO - 2021-12-06 14:18:30 --> Helper loaded: common_helper
INFO - 2021-12-06 14:18:30 --> Database Driver Class Initialized
DEBUG - 2021-12-06 14:18:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 14:18:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 14:18:30 --> Controller Class Initialized
INFO - 2021-12-06 14:18:30 --> Form Validation Class Initialized
DEBUG - 2021-12-06 14:18:30 --> Encrypt Class Initialized
DEBUG - 2021-12-06 14:18:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-06 14:18:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-06 14:18:30 --> Email Class Initialized
INFO - 2021-12-06 14:18:30 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-06 14:18:30 --> Calendar Class Initialized
INFO - 2021-12-06 14:18:30 --> Model "Login_model" initialized
ERROR - 2021-12-06 14:18:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-06 14:18:30 --> Config Class Initialized
INFO - 2021-12-06 14:18:30 --> Hooks Class Initialized
DEBUG - 2021-12-06 14:18:30 --> UTF-8 Support Enabled
INFO - 2021-12-06 14:18:30 --> Utf8 Class Initialized
INFO - 2021-12-06 14:18:30 --> URI Class Initialized
INFO - 2021-12-06 14:18:30 --> Router Class Initialized
INFO - 2021-12-06 14:18:30 --> Output Class Initialized
INFO - 2021-12-06 14:18:30 --> Security Class Initialized
DEBUG - 2021-12-06 14:18:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 14:18:30 --> Input Class Initialized
INFO - 2021-12-06 14:18:30 --> Language Class Initialized
INFO - 2021-12-06 14:18:30 --> Loader Class Initialized
INFO - 2021-12-06 14:18:30 --> Helper loaded: url_helper
INFO - 2021-12-06 14:18:30 --> Helper loaded: form_helper
INFO - 2021-12-06 14:18:30 --> Helper loaded: common_helper
INFO - 2021-12-06 14:18:30 --> Database Driver Class Initialized
DEBUG - 2021-12-06 14:18:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 14:18:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 14:18:30 --> Controller Class Initialized
INFO - 2021-12-06 14:18:30 --> Form Validation Class Initialized
DEBUG - 2021-12-06 14:18:30 --> Encrypt Class Initialized
DEBUG - 2021-12-06 14:18:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-06 14:18:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-06 14:18:30 --> Email Class Initialized
INFO - 2021-12-06 14:18:30 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-06 14:18:30 --> Calendar Class Initialized
INFO - 2021-12-06 14:18:30 --> Model "Login_model" initialized
ERROR - 2021-12-06 14:18:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-06 14:18:31 --> Config Class Initialized
INFO - 2021-12-06 14:18:31 --> Hooks Class Initialized
DEBUG - 2021-12-06 14:18:31 --> UTF-8 Support Enabled
INFO - 2021-12-06 14:18:31 --> Utf8 Class Initialized
INFO - 2021-12-06 14:18:31 --> URI Class Initialized
INFO - 2021-12-06 14:18:31 --> Router Class Initialized
INFO - 2021-12-06 14:18:31 --> Output Class Initialized
INFO - 2021-12-06 14:18:31 --> Security Class Initialized
DEBUG - 2021-12-06 14:18:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 14:18:31 --> Input Class Initialized
INFO - 2021-12-06 14:18:31 --> Language Class Initialized
INFO - 2021-12-06 14:18:31 --> Loader Class Initialized
INFO - 2021-12-06 14:18:31 --> Helper loaded: url_helper
INFO - 2021-12-06 14:18:31 --> Helper loaded: form_helper
INFO - 2021-12-06 14:18:31 --> Helper loaded: common_helper
INFO - 2021-12-06 14:18:31 --> Database Driver Class Initialized
DEBUG - 2021-12-06 14:18:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 14:18:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 14:18:31 --> Controller Class Initialized
INFO - 2021-12-06 14:18:31 --> Form Validation Class Initialized
DEBUG - 2021-12-06 14:18:31 --> Encrypt Class Initialized
DEBUG - 2021-12-06 14:18:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-06 14:18:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-06 14:18:31 --> Email Class Initialized
INFO - 2021-12-06 14:18:31 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-06 14:18:31 --> Calendar Class Initialized
INFO - 2021-12-06 14:18:31 --> Model "Login_model" initialized
INFO - 2021-12-06 14:18:31 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-06 14:18:31 --> Final output sent to browser
DEBUG - 2021-12-06 14:18:31 --> Total execution time: 0.0376
ERROR - 2021-12-06 14:18:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-06 14:18:32 --> Config Class Initialized
INFO - 2021-12-06 14:18:32 --> Hooks Class Initialized
DEBUG - 2021-12-06 14:18:32 --> UTF-8 Support Enabled
INFO - 2021-12-06 14:18:32 --> Utf8 Class Initialized
INFO - 2021-12-06 14:18:32 --> URI Class Initialized
DEBUG - 2021-12-06 14:18:32 --> No URI present. Default controller set.
INFO - 2021-12-06 14:18:32 --> Router Class Initialized
INFO - 2021-12-06 14:18:32 --> Output Class Initialized
INFO - 2021-12-06 14:18:32 --> Security Class Initialized
DEBUG - 2021-12-06 14:18:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 14:18:32 --> Input Class Initialized
INFO - 2021-12-06 14:18:32 --> Language Class Initialized
INFO - 2021-12-06 14:18:32 --> Loader Class Initialized
INFO - 2021-12-06 14:18:32 --> Helper loaded: url_helper
INFO - 2021-12-06 14:18:32 --> Helper loaded: form_helper
INFO - 2021-12-06 14:18:32 --> Helper loaded: common_helper
INFO - 2021-12-06 14:18:32 --> Database Driver Class Initialized
DEBUG - 2021-12-06 14:18:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 14:18:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 14:18:32 --> Controller Class Initialized
INFO - 2021-12-06 14:18:32 --> Form Validation Class Initialized
DEBUG - 2021-12-06 14:18:32 --> Encrypt Class Initialized
DEBUG - 2021-12-06 14:18:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-06 14:18:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-06 14:18:32 --> Email Class Initialized
INFO - 2021-12-06 14:18:32 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-06 14:18:32 --> Calendar Class Initialized
INFO - 2021-12-06 14:18:32 --> Model "Login_model" initialized
INFO - 2021-12-06 14:18:32 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-06 14:18:32 --> Final output sent to browser
DEBUG - 2021-12-06 14:18:32 --> Total execution time: 0.0306
ERROR - 2021-12-06 14:31:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-06 14:31:54 --> Config Class Initialized
INFO - 2021-12-06 14:31:54 --> Hooks Class Initialized
DEBUG - 2021-12-06 14:31:54 --> UTF-8 Support Enabled
INFO - 2021-12-06 14:31:54 --> Utf8 Class Initialized
INFO - 2021-12-06 14:31:54 --> URI Class Initialized
DEBUG - 2021-12-06 14:31:54 --> No URI present. Default controller set.
INFO - 2021-12-06 14:31:54 --> Router Class Initialized
INFO - 2021-12-06 14:31:54 --> Output Class Initialized
INFO - 2021-12-06 14:31:54 --> Security Class Initialized
DEBUG - 2021-12-06 14:31:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 14:31:54 --> Input Class Initialized
INFO - 2021-12-06 14:31:54 --> Language Class Initialized
INFO - 2021-12-06 14:31:54 --> Loader Class Initialized
INFO - 2021-12-06 14:31:54 --> Helper loaded: url_helper
INFO - 2021-12-06 14:31:54 --> Helper loaded: form_helper
INFO - 2021-12-06 14:31:54 --> Helper loaded: common_helper
INFO - 2021-12-06 14:31:54 --> Database Driver Class Initialized
DEBUG - 2021-12-06 14:31:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 14:31:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 14:31:54 --> Controller Class Initialized
INFO - 2021-12-06 14:31:54 --> Form Validation Class Initialized
DEBUG - 2021-12-06 14:31:54 --> Encrypt Class Initialized
DEBUG - 2021-12-06 14:31:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-06 14:31:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-06 14:31:54 --> Email Class Initialized
INFO - 2021-12-06 14:31:54 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-06 14:31:54 --> Calendar Class Initialized
INFO - 2021-12-06 14:31:54 --> Model "Login_model" initialized
INFO - 2021-12-06 14:31:54 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-06 14:31:54 --> Final output sent to browser
DEBUG - 2021-12-06 14:31:54 --> Total execution time: 0.0239
ERROR - 2021-12-06 15:03:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-06 15:03:07 --> Config Class Initialized
INFO - 2021-12-06 15:03:07 --> Hooks Class Initialized
DEBUG - 2021-12-06 15:03:07 --> UTF-8 Support Enabled
INFO - 2021-12-06 15:03:07 --> Utf8 Class Initialized
INFO - 2021-12-06 15:03:07 --> URI Class Initialized
DEBUG - 2021-12-06 15:03:07 --> No URI present. Default controller set.
INFO - 2021-12-06 15:03:07 --> Router Class Initialized
INFO - 2021-12-06 15:03:07 --> Output Class Initialized
INFO - 2021-12-06 15:03:07 --> Security Class Initialized
DEBUG - 2021-12-06 15:03:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 15:03:07 --> Input Class Initialized
INFO - 2021-12-06 15:03:07 --> Language Class Initialized
INFO - 2021-12-06 15:03:07 --> Loader Class Initialized
INFO - 2021-12-06 15:03:07 --> Helper loaded: url_helper
INFO - 2021-12-06 15:03:07 --> Helper loaded: form_helper
INFO - 2021-12-06 15:03:07 --> Helper loaded: common_helper
INFO - 2021-12-06 15:03:07 --> Database Driver Class Initialized
DEBUG - 2021-12-06 15:03:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 15:03:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 15:03:07 --> Controller Class Initialized
INFO - 2021-12-06 15:03:07 --> Form Validation Class Initialized
DEBUG - 2021-12-06 15:03:07 --> Encrypt Class Initialized
DEBUG - 2021-12-06 15:03:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-06 15:03:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-06 15:03:07 --> Email Class Initialized
INFO - 2021-12-06 15:03:07 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-06 15:03:07 --> Calendar Class Initialized
INFO - 2021-12-06 15:03:07 --> Model "Login_model" initialized
INFO - 2021-12-06 15:03:07 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-06 15:03:07 --> Final output sent to browser
DEBUG - 2021-12-06 15:03:07 --> Total execution time: 0.0323
ERROR - 2021-12-06 16:05:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-06 16:05:23 --> Config Class Initialized
INFO - 2021-12-06 16:05:23 --> Hooks Class Initialized
DEBUG - 2021-12-06 16:05:23 --> UTF-8 Support Enabled
INFO - 2021-12-06 16:05:23 --> Utf8 Class Initialized
INFO - 2021-12-06 16:05:23 --> URI Class Initialized
DEBUG - 2021-12-06 16:05:23 --> No URI present. Default controller set.
INFO - 2021-12-06 16:05:23 --> Router Class Initialized
INFO - 2021-12-06 16:05:23 --> Output Class Initialized
INFO - 2021-12-06 16:05:23 --> Security Class Initialized
DEBUG - 2021-12-06 16:05:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 16:05:23 --> Input Class Initialized
INFO - 2021-12-06 16:05:23 --> Language Class Initialized
INFO - 2021-12-06 16:05:23 --> Loader Class Initialized
INFO - 2021-12-06 16:05:23 --> Helper loaded: url_helper
INFO - 2021-12-06 16:05:23 --> Helper loaded: form_helper
INFO - 2021-12-06 16:05:23 --> Helper loaded: common_helper
INFO - 2021-12-06 16:05:23 --> Database Driver Class Initialized
DEBUG - 2021-12-06 16:05:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 16:05:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 16:05:23 --> Controller Class Initialized
INFO - 2021-12-06 16:05:23 --> Form Validation Class Initialized
DEBUG - 2021-12-06 16:05:23 --> Encrypt Class Initialized
DEBUG - 2021-12-06 16:05:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-06 16:05:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-06 16:05:23 --> Email Class Initialized
INFO - 2021-12-06 16:05:23 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-06 16:05:23 --> Calendar Class Initialized
INFO - 2021-12-06 16:05:23 --> Model "Login_model" initialized
INFO - 2021-12-06 16:05:23 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-06 16:05:23 --> Final output sent to browser
DEBUG - 2021-12-06 16:05:23 --> Total execution time: 0.0272
ERROR - 2021-12-06 16:24:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-06 16:24:09 --> Config Class Initialized
INFO - 2021-12-06 16:24:09 --> Hooks Class Initialized
DEBUG - 2021-12-06 16:24:09 --> UTF-8 Support Enabled
INFO - 2021-12-06 16:24:09 --> Utf8 Class Initialized
INFO - 2021-12-06 16:24:09 --> URI Class Initialized
DEBUG - 2021-12-06 16:24:09 --> No URI present. Default controller set.
INFO - 2021-12-06 16:24:09 --> Router Class Initialized
INFO - 2021-12-06 16:24:09 --> Output Class Initialized
INFO - 2021-12-06 16:24:09 --> Security Class Initialized
DEBUG - 2021-12-06 16:24:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 16:24:09 --> Input Class Initialized
INFO - 2021-12-06 16:24:09 --> Language Class Initialized
INFO - 2021-12-06 16:24:09 --> Loader Class Initialized
INFO - 2021-12-06 16:24:09 --> Helper loaded: url_helper
INFO - 2021-12-06 16:24:09 --> Helper loaded: form_helper
INFO - 2021-12-06 16:24:09 --> Helper loaded: common_helper
INFO - 2021-12-06 16:24:09 --> Database Driver Class Initialized
DEBUG - 2021-12-06 16:24:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 16:24:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 16:24:09 --> Controller Class Initialized
INFO - 2021-12-06 16:24:09 --> Form Validation Class Initialized
DEBUG - 2021-12-06 16:24:09 --> Encrypt Class Initialized
DEBUG - 2021-12-06 16:24:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-06 16:24:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-06 16:24:09 --> Email Class Initialized
INFO - 2021-12-06 16:24:09 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-06 16:24:09 --> Calendar Class Initialized
INFO - 2021-12-06 16:24:09 --> Model "Login_model" initialized
INFO - 2021-12-06 16:24:09 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-06 16:24:09 --> Final output sent to browser
DEBUG - 2021-12-06 16:24:09 --> Total execution time: 0.0287
ERROR - 2021-12-06 21:14:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-06 21:14:45 --> Config Class Initialized
INFO - 2021-12-06 21:14:45 --> Hooks Class Initialized
DEBUG - 2021-12-06 21:14:45 --> UTF-8 Support Enabled
INFO - 2021-12-06 21:14:45 --> Utf8 Class Initialized
INFO - 2021-12-06 21:14:45 --> URI Class Initialized
DEBUG - 2021-12-06 21:14:45 --> No URI present. Default controller set.
INFO - 2021-12-06 21:14:45 --> Router Class Initialized
INFO - 2021-12-06 21:14:45 --> Output Class Initialized
INFO - 2021-12-06 21:14:45 --> Security Class Initialized
DEBUG - 2021-12-06 21:14:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 21:14:45 --> Input Class Initialized
INFO - 2021-12-06 21:14:45 --> Language Class Initialized
INFO - 2021-12-06 21:14:45 --> Loader Class Initialized
INFO - 2021-12-06 21:14:45 --> Helper loaded: url_helper
INFO - 2021-12-06 21:14:45 --> Helper loaded: form_helper
INFO - 2021-12-06 21:14:45 --> Helper loaded: common_helper
INFO - 2021-12-06 21:14:45 --> Database Driver Class Initialized
DEBUG - 2021-12-06 21:14:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 21:14:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 21:14:45 --> Controller Class Initialized
INFO - 2021-12-06 21:14:45 --> Form Validation Class Initialized
DEBUG - 2021-12-06 21:14:45 --> Encrypt Class Initialized
DEBUG - 2021-12-06 21:14:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-06 21:14:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-06 21:14:45 --> Email Class Initialized
INFO - 2021-12-06 21:14:45 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-06 21:14:45 --> Calendar Class Initialized
INFO - 2021-12-06 21:14:45 --> Model "Login_model" initialized
INFO - 2021-12-06 21:14:45 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-06 21:14:45 --> Final output sent to browser
DEBUG - 2021-12-06 21:14:45 --> Total execution time: 0.0359
