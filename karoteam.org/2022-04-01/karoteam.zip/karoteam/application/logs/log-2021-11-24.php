<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-11-24 00:32:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-24 00:32:06 --> Config Class Initialized
INFO - 2021-11-24 00:32:06 --> Hooks Class Initialized
DEBUG - 2021-11-24 00:32:06 --> UTF-8 Support Enabled
INFO - 2021-11-24 00:32:06 --> Utf8 Class Initialized
INFO - 2021-11-24 00:32:06 --> URI Class Initialized
DEBUG - 2021-11-24 00:32:06 --> No URI present. Default controller set.
INFO - 2021-11-24 00:32:06 --> Router Class Initialized
INFO - 2021-11-24 00:32:06 --> Output Class Initialized
INFO - 2021-11-24 00:32:06 --> Security Class Initialized
DEBUG - 2021-11-24 00:32:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-24 00:32:06 --> Input Class Initialized
INFO - 2021-11-24 00:32:06 --> Language Class Initialized
INFO - 2021-11-24 00:32:06 --> Loader Class Initialized
INFO - 2021-11-24 00:32:06 --> Helper loaded: url_helper
INFO - 2021-11-24 00:32:06 --> Helper loaded: form_helper
INFO - 2021-11-24 00:32:06 --> Helper loaded: common_helper
INFO - 2021-11-24 00:32:06 --> Database Driver Class Initialized
DEBUG - 2021-11-24 00:32:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-24 00:32:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-24 00:32:07 --> Controller Class Initialized
INFO - 2021-11-24 00:32:07 --> Form Validation Class Initialized
DEBUG - 2021-11-24 00:32:07 --> Encrypt Class Initialized
DEBUG - 2021-11-24 00:32:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-24 00:32:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-24 00:32:07 --> Email Class Initialized
INFO - 2021-11-24 00:32:07 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-24 00:32:07 --> Calendar Class Initialized
INFO - 2021-11-24 00:32:07 --> Model "Login_model" initialized
INFO - 2021-11-24 00:32:07 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-11-24 00:32:07 --> Final output sent to browser
DEBUG - 2021-11-24 00:32:07 --> Total execution time: 0.2020
ERROR - 2021-11-24 00:32:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-24 00:32:16 --> Config Class Initialized
INFO - 2021-11-24 00:32:16 --> Hooks Class Initialized
DEBUG - 2021-11-24 00:32:16 --> UTF-8 Support Enabled
INFO - 2021-11-24 00:32:16 --> Utf8 Class Initialized
INFO - 2021-11-24 00:32:16 --> URI Class Initialized
DEBUG - 2021-11-24 00:32:16 --> No URI present. Default controller set.
INFO - 2021-11-24 00:32:16 --> Router Class Initialized
INFO - 2021-11-24 00:32:16 --> Output Class Initialized
INFO - 2021-11-24 00:32:16 --> Security Class Initialized
DEBUG - 2021-11-24 00:32:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-24 00:32:16 --> Input Class Initialized
INFO - 2021-11-24 00:32:16 --> Language Class Initialized
INFO - 2021-11-24 00:32:16 --> Loader Class Initialized
INFO - 2021-11-24 00:32:16 --> Helper loaded: url_helper
INFO - 2021-11-24 00:32:16 --> Helper loaded: form_helper
INFO - 2021-11-24 00:32:16 --> Helper loaded: common_helper
INFO - 2021-11-24 00:32:16 --> Database Driver Class Initialized
DEBUG - 2021-11-24 00:32:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-24 00:32:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-24 00:32:16 --> Controller Class Initialized
INFO - 2021-11-24 00:32:16 --> Form Validation Class Initialized
DEBUG - 2021-11-24 00:32:16 --> Encrypt Class Initialized
DEBUG - 2021-11-24 00:32:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-24 00:32:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-24 00:32:16 --> Email Class Initialized
INFO - 2021-11-24 00:32:16 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-24 00:32:16 --> Calendar Class Initialized
INFO - 2021-11-24 00:32:16 --> Model "Login_model" initialized
INFO - 2021-11-24 00:32:16 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-11-24 00:32:16 --> Final output sent to browser
DEBUG - 2021-11-24 00:32:16 --> Total execution time: 0.0230
ERROR - 2021-11-24 01:03:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-24 01:03:41 --> Config Class Initialized
INFO - 2021-11-24 01:03:41 --> Hooks Class Initialized
DEBUG - 2021-11-24 01:03:41 --> UTF-8 Support Enabled
INFO - 2021-11-24 01:03:41 --> Utf8 Class Initialized
INFO - 2021-11-24 01:03:41 --> URI Class Initialized
DEBUG - 2021-11-24 01:03:41 --> No URI present. Default controller set.
INFO - 2021-11-24 01:03:41 --> Router Class Initialized
INFO - 2021-11-24 01:03:41 --> Output Class Initialized
INFO - 2021-11-24 01:03:41 --> Security Class Initialized
DEBUG - 2021-11-24 01:03:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-24 01:03:41 --> Input Class Initialized
INFO - 2021-11-24 01:03:41 --> Language Class Initialized
INFO - 2021-11-24 01:03:41 --> Loader Class Initialized
INFO - 2021-11-24 01:03:41 --> Helper loaded: url_helper
INFO - 2021-11-24 01:03:41 --> Helper loaded: form_helper
INFO - 2021-11-24 01:03:41 --> Helper loaded: common_helper
INFO - 2021-11-24 01:03:41 --> Database Driver Class Initialized
DEBUG - 2021-11-24 01:03:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-24 01:03:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-24 01:03:41 --> Controller Class Initialized
INFO - 2021-11-24 01:03:41 --> Form Validation Class Initialized
DEBUG - 2021-11-24 01:03:41 --> Encrypt Class Initialized
DEBUG - 2021-11-24 01:03:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-24 01:03:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-24 01:03:41 --> Email Class Initialized
INFO - 2021-11-24 01:03:41 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-24 01:03:41 --> Calendar Class Initialized
INFO - 2021-11-24 01:03:41 --> Model "Login_model" initialized
INFO - 2021-11-24 01:03:41 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-11-24 01:03:41 --> Final output sent to browser
DEBUG - 2021-11-24 01:03:41 --> Total execution time: 0.0327
ERROR - 2021-11-24 01:16:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-24 01:16:47 --> Config Class Initialized
INFO - 2021-11-24 01:16:47 --> Hooks Class Initialized
DEBUG - 2021-11-24 01:16:47 --> UTF-8 Support Enabled
INFO - 2021-11-24 01:16:47 --> Utf8 Class Initialized
INFO - 2021-11-24 01:16:47 --> URI Class Initialized
DEBUG - 2021-11-24 01:16:47 --> No URI present. Default controller set.
INFO - 2021-11-24 01:16:47 --> Router Class Initialized
INFO - 2021-11-24 01:16:47 --> Output Class Initialized
INFO - 2021-11-24 01:16:47 --> Security Class Initialized
DEBUG - 2021-11-24 01:16:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-24 01:16:47 --> Input Class Initialized
INFO - 2021-11-24 01:16:47 --> Language Class Initialized
INFO - 2021-11-24 01:16:47 --> Loader Class Initialized
INFO - 2021-11-24 01:16:47 --> Helper loaded: url_helper
INFO - 2021-11-24 01:16:47 --> Helper loaded: form_helper
INFO - 2021-11-24 01:16:47 --> Helper loaded: common_helper
INFO - 2021-11-24 01:16:47 --> Database Driver Class Initialized
DEBUG - 2021-11-24 01:16:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-24 01:16:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-24 01:16:47 --> Controller Class Initialized
INFO - 2021-11-24 01:16:47 --> Form Validation Class Initialized
DEBUG - 2021-11-24 01:16:47 --> Encrypt Class Initialized
DEBUG - 2021-11-24 01:16:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-24 01:16:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-24 01:16:47 --> Email Class Initialized
INFO - 2021-11-24 01:16:47 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-24 01:16:47 --> Calendar Class Initialized
INFO - 2021-11-24 01:16:47 --> Model "Login_model" initialized
INFO - 2021-11-24 01:16:47 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-11-24 01:16:47 --> Final output sent to browser
DEBUG - 2021-11-24 01:16:47 --> Total execution time: 0.0355
ERROR - 2021-11-24 05:25:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-24 05:25:13 --> Config Class Initialized
INFO - 2021-11-24 05:25:13 --> Hooks Class Initialized
DEBUG - 2021-11-24 05:25:13 --> UTF-8 Support Enabled
INFO - 2021-11-24 05:25:13 --> Utf8 Class Initialized
INFO - 2021-11-24 05:25:13 --> URI Class Initialized
DEBUG - 2021-11-24 05:25:13 --> No URI present. Default controller set.
INFO - 2021-11-24 05:25:13 --> Router Class Initialized
INFO - 2021-11-24 05:25:13 --> Output Class Initialized
INFO - 2021-11-24 05:25:13 --> Security Class Initialized
DEBUG - 2021-11-24 05:25:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-24 05:25:13 --> Input Class Initialized
INFO - 2021-11-24 05:25:13 --> Language Class Initialized
INFO - 2021-11-24 05:25:13 --> Loader Class Initialized
INFO - 2021-11-24 05:25:13 --> Helper loaded: url_helper
INFO - 2021-11-24 05:25:13 --> Helper loaded: form_helper
INFO - 2021-11-24 05:25:13 --> Helper loaded: common_helper
INFO - 2021-11-24 05:25:13 --> Database Driver Class Initialized
DEBUG - 2021-11-24 05:25:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-24 05:25:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-24 05:25:13 --> Controller Class Initialized
INFO - 2021-11-24 05:25:13 --> Form Validation Class Initialized
DEBUG - 2021-11-24 05:25:13 --> Encrypt Class Initialized
DEBUG - 2021-11-24 05:25:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-24 05:25:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-24 05:25:13 --> Email Class Initialized
INFO - 2021-11-24 05:25:13 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-24 05:25:13 --> Calendar Class Initialized
INFO - 2021-11-24 05:25:13 --> Model "Login_model" initialized
INFO - 2021-11-24 05:25:13 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-11-24 05:25:13 --> Final output sent to browser
DEBUG - 2021-11-24 05:25:13 --> Total execution time: 0.0260
ERROR - 2021-11-24 06:17:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-24 06:17:14 --> Config Class Initialized
INFO - 2021-11-24 06:17:14 --> Hooks Class Initialized
DEBUG - 2021-11-24 06:17:14 --> UTF-8 Support Enabled
INFO - 2021-11-24 06:17:14 --> Utf8 Class Initialized
INFO - 2021-11-24 06:17:14 --> URI Class Initialized
DEBUG - 2021-11-24 06:17:14 --> No URI present. Default controller set.
INFO - 2021-11-24 06:17:14 --> Router Class Initialized
INFO - 2021-11-24 06:17:14 --> Output Class Initialized
INFO - 2021-11-24 06:17:14 --> Security Class Initialized
DEBUG - 2021-11-24 06:17:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-24 06:17:14 --> Input Class Initialized
INFO - 2021-11-24 06:17:14 --> Language Class Initialized
INFO - 2021-11-24 06:17:14 --> Loader Class Initialized
INFO - 2021-11-24 06:17:14 --> Helper loaded: url_helper
INFO - 2021-11-24 06:17:14 --> Helper loaded: form_helper
INFO - 2021-11-24 06:17:14 --> Helper loaded: common_helper
INFO - 2021-11-24 06:17:14 --> Database Driver Class Initialized
DEBUG - 2021-11-24 06:17:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-24 06:17:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-24 06:17:14 --> Controller Class Initialized
INFO - 2021-11-24 06:17:14 --> Form Validation Class Initialized
DEBUG - 2021-11-24 06:17:14 --> Encrypt Class Initialized
DEBUG - 2021-11-24 06:17:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-24 06:17:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-24 06:17:14 --> Email Class Initialized
INFO - 2021-11-24 06:17:14 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-24 06:17:14 --> Calendar Class Initialized
INFO - 2021-11-24 06:17:14 --> Model "Login_model" initialized
INFO - 2021-11-24 06:17:14 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-11-24 06:17:14 --> Final output sent to browser
DEBUG - 2021-11-24 06:17:14 --> Total execution time: 0.0332
ERROR - 2021-11-24 06:18:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-24 06:18:45 --> Config Class Initialized
INFO - 2021-11-24 06:18:45 --> Hooks Class Initialized
DEBUG - 2021-11-24 06:18:45 --> UTF-8 Support Enabled
INFO - 2021-11-24 06:18:45 --> Utf8 Class Initialized
INFO - 2021-11-24 06:18:45 --> URI Class Initialized
DEBUG - 2021-11-24 06:18:45 --> No URI present. Default controller set.
INFO - 2021-11-24 06:18:45 --> Router Class Initialized
INFO - 2021-11-24 06:18:45 --> Output Class Initialized
INFO - 2021-11-24 06:18:45 --> Security Class Initialized
DEBUG - 2021-11-24 06:18:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-24 06:18:45 --> Input Class Initialized
INFO - 2021-11-24 06:18:45 --> Language Class Initialized
INFO - 2021-11-24 06:18:45 --> Loader Class Initialized
INFO - 2021-11-24 06:18:45 --> Helper loaded: url_helper
INFO - 2021-11-24 06:18:45 --> Helper loaded: form_helper
INFO - 2021-11-24 06:18:45 --> Helper loaded: common_helper
INFO - 2021-11-24 06:18:45 --> Database Driver Class Initialized
DEBUG - 2021-11-24 06:18:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-24 06:18:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-24 06:18:45 --> Controller Class Initialized
INFO - 2021-11-24 06:18:45 --> Form Validation Class Initialized
DEBUG - 2021-11-24 06:18:45 --> Encrypt Class Initialized
DEBUG - 2021-11-24 06:18:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-24 06:18:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-24 06:18:45 --> Email Class Initialized
INFO - 2021-11-24 06:18:45 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-24 06:18:45 --> Calendar Class Initialized
INFO - 2021-11-24 06:18:45 --> Model "Login_model" initialized
INFO - 2021-11-24 06:18:45 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-11-24 06:18:45 --> Final output sent to browser
DEBUG - 2021-11-24 06:18:45 --> Total execution time: 0.0260
ERROR - 2021-11-24 06:28:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-24 06:28:50 --> Config Class Initialized
INFO - 2021-11-24 06:28:50 --> Hooks Class Initialized
DEBUG - 2021-11-24 06:28:50 --> UTF-8 Support Enabled
INFO - 2021-11-24 06:28:50 --> Utf8 Class Initialized
INFO - 2021-11-24 06:28:50 --> URI Class Initialized
DEBUG - 2021-11-24 06:28:50 --> No URI present. Default controller set.
INFO - 2021-11-24 06:28:50 --> Router Class Initialized
INFO - 2021-11-24 06:28:50 --> Output Class Initialized
INFO - 2021-11-24 06:28:50 --> Security Class Initialized
DEBUG - 2021-11-24 06:28:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-24 06:28:50 --> Input Class Initialized
INFO - 2021-11-24 06:28:50 --> Language Class Initialized
INFO - 2021-11-24 06:28:50 --> Loader Class Initialized
INFO - 2021-11-24 06:28:50 --> Helper loaded: url_helper
INFO - 2021-11-24 06:28:50 --> Helper loaded: form_helper
INFO - 2021-11-24 06:28:50 --> Helper loaded: common_helper
INFO - 2021-11-24 06:28:50 --> Database Driver Class Initialized
DEBUG - 2021-11-24 06:28:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-24 06:28:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-24 06:28:50 --> Controller Class Initialized
INFO - 2021-11-24 06:28:50 --> Form Validation Class Initialized
DEBUG - 2021-11-24 06:28:50 --> Encrypt Class Initialized
DEBUG - 2021-11-24 06:28:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-24 06:28:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-24 06:28:50 --> Email Class Initialized
INFO - 2021-11-24 06:28:50 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-24 06:28:50 --> Calendar Class Initialized
INFO - 2021-11-24 06:28:50 --> Model "Login_model" initialized
INFO - 2021-11-24 06:28:50 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-11-24 06:28:50 --> Final output sent to browser
DEBUG - 2021-11-24 06:28:50 --> Total execution time: 0.0375
ERROR - 2021-11-24 06:36:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-24 06:36:24 --> Config Class Initialized
INFO - 2021-11-24 06:36:24 --> Hooks Class Initialized
DEBUG - 2021-11-24 06:36:24 --> UTF-8 Support Enabled
INFO - 2021-11-24 06:36:24 --> Utf8 Class Initialized
INFO - 2021-11-24 06:36:24 --> URI Class Initialized
DEBUG - 2021-11-24 06:36:24 --> No URI present. Default controller set.
INFO - 2021-11-24 06:36:24 --> Router Class Initialized
INFO - 2021-11-24 06:36:24 --> Output Class Initialized
INFO - 2021-11-24 06:36:24 --> Security Class Initialized
DEBUG - 2021-11-24 06:36:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-24 06:36:24 --> Input Class Initialized
INFO - 2021-11-24 06:36:24 --> Language Class Initialized
INFO - 2021-11-24 06:36:24 --> Loader Class Initialized
INFO - 2021-11-24 06:36:24 --> Helper loaded: url_helper
INFO - 2021-11-24 06:36:24 --> Helper loaded: form_helper
INFO - 2021-11-24 06:36:24 --> Helper loaded: common_helper
INFO - 2021-11-24 06:36:24 --> Database Driver Class Initialized
DEBUG - 2021-11-24 06:36:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-24 06:36:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-24 06:36:24 --> Controller Class Initialized
INFO - 2021-11-24 06:36:24 --> Form Validation Class Initialized
DEBUG - 2021-11-24 06:36:24 --> Encrypt Class Initialized
DEBUG - 2021-11-24 06:36:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-24 06:36:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-24 06:36:24 --> Email Class Initialized
INFO - 2021-11-24 06:36:24 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-24 06:36:24 --> Calendar Class Initialized
INFO - 2021-11-24 06:36:24 --> Model "Login_model" initialized
INFO - 2021-11-24 06:36:24 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-11-24 06:36:24 --> Final output sent to browser
DEBUG - 2021-11-24 06:36:24 --> Total execution time: 0.0233
ERROR - 2021-11-24 07:11:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-24 07:11:30 --> Config Class Initialized
INFO - 2021-11-24 07:11:30 --> Hooks Class Initialized
DEBUG - 2021-11-24 07:11:30 --> UTF-8 Support Enabled
INFO - 2021-11-24 07:11:30 --> Utf8 Class Initialized
INFO - 2021-11-24 07:11:30 --> URI Class Initialized
DEBUG - 2021-11-24 07:11:30 --> No URI present. Default controller set.
INFO - 2021-11-24 07:11:30 --> Router Class Initialized
INFO - 2021-11-24 07:11:30 --> Output Class Initialized
INFO - 2021-11-24 07:11:30 --> Security Class Initialized
DEBUG - 2021-11-24 07:11:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-24 07:11:30 --> Input Class Initialized
INFO - 2021-11-24 07:11:30 --> Language Class Initialized
INFO - 2021-11-24 07:11:30 --> Loader Class Initialized
INFO - 2021-11-24 07:11:30 --> Helper loaded: url_helper
INFO - 2021-11-24 07:11:30 --> Helper loaded: form_helper
INFO - 2021-11-24 07:11:30 --> Helper loaded: common_helper
INFO - 2021-11-24 07:11:30 --> Database Driver Class Initialized
DEBUG - 2021-11-24 07:11:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-24 07:11:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-24 07:11:30 --> Controller Class Initialized
INFO - 2021-11-24 07:11:30 --> Form Validation Class Initialized
DEBUG - 2021-11-24 07:11:30 --> Encrypt Class Initialized
DEBUG - 2021-11-24 07:11:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-24 07:11:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-24 07:11:30 --> Email Class Initialized
INFO - 2021-11-24 07:11:30 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-24 07:11:30 --> Calendar Class Initialized
INFO - 2021-11-24 07:11:30 --> Model "Login_model" initialized
INFO - 2021-11-24 07:11:30 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-11-24 07:11:30 --> Final output sent to browser
DEBUG - 2021-11-24 07:11:30 --> Total execution time: 0.0266
ERROR - 2021-11-24 08:32:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-24 08:32:02 --> Config Class Initialized
INFO - 2021-11-24 08:32:02 --> Hooks Class Initialized
DEBUG - 2021-11-24 08:32:02 --> UTF-8 Support Enabled
INFO - 2021-11-24 08:32:02 --> Utf8 Class Initialized
INFO - 2021-11-24 08:32:02 --> URI Class Initialized
DEBUG - 2021-11-24 08:32:02 --> No URI present. Default controller set.
INFO - 2021-11-24 08:32:02 --> Router Class Initialized
INFO - 2021-11-24 08:32:02 --> Output Class Initialized
INFO - 2021-11-24 08:32:02 --> Security Class Initialized
DEBUG - 2021-11-24 08:32:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-24 08:32:02 --> Input Class Initialized
INFO - 2021-11-24 08:32:02 --> Language Class Initialized
INFO - 2021-11-24 08:32:02 --> Loader Class Initialized
INFO - 2021-11-24 08:32:02 --> Helper loaded: url_helper
INFO - 2021-11-24 08:32:02 --> Helper loaded: form_helper
INFO - 2021-11-24 08:32:02 --> Helper loaded: common_helper
INFO - 2021-11-24 08:32:02 --> Database Driver Class Initialized
DEBUG - 2021-11-24 08:32:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-24 08:32:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-24 08:32:02 --> Controller Class Initialized
INFO - 2021-11-24 08:32:02 --> Form Validation Class Initialized
DEBUG - 2021-11-24 08:32:02 --> Encrypt Class Initialized
DEBUG - 2021-11-24 08:32:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-24 08:32:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-24 08:32:02 --> Email Class Initialized
INFO - 2021-11-24 08:32:02 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-24 08:32:02 --> Calendar Class Initialized
INFO - 2021-11-24 08:32:02 --> Model "Login_model" initialized
INFO - 2021-11-24 08:32:02 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-11-24 08:32:02 --> Final output sent to browser
DEBUG - 2021-11-24 08:32:02 --> Total execution time: 0.0380
ERROR - 2021-11-24 10:03:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-24 10:03:45 --> Config Class Initialized
INFO - 2021-11-24 10:03:45 --> Hooks Class Initialized
DEBUG - 2021-11-24 10:03:45 --> UTF-8 Support Enabled
INFO - 2021-11-24 10:03:45 --> Utf8 Class Initialized
INFO - 2021-11-24 10:03:45 --> URI Class Initialized
DEBUG - 2021-11-24 10:03:45 --> No URI present. Default controller set.
INFO - 2021-11-24 10:03:45 --> Router Class Initialized
INFO - 2021-11-24 10:03:45 --> Output Class Initialized
INFO - 2021-11-24 10:03:45 --> Security Class Initialized
DEBUG - 2021-11-24 10:03:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-24 10:03:45 --> Input Class Initialized
INFO - 2021-11-24 10:03:45 --> Language Class Initialized
INFO - 2021-11-24 10:03:45 --> Loader Class Initialized
INFO - 2021-11-24 10:03:45 --> Helper loaded: url_helper
INFO - 2021-11-24 10:03:45 --> Helper loaded: form_helper
INFO - 2021-11-24 10:03:45 --> Helper loaded: common_helper
INFO - 2021-11-24 10:03:45 --> Database Driver Class Initialized
DEBUG - 2021-11-24 10:03:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-24 10:03:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-24 10:03:45 --> Controller Class Initialized
INFO - 2021-11-24 10:03:45 --> Form Validation Class Initialized
DEBUG - 2021-11-24 10:03:45 --> Encrypt Class Initialized
DEBUG - 2021-11-24 10:03:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-24 10:03:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-24 10:03:45 --> Email Class Initialized
INFO - 2021-11-24 10:03:45 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-24 10:03:45 --> Calendar Class Initialized
INFO - 2021-11-24 10:03:45 --> Model "Login_model" initialized
INFO - 2021-11-24 10:03:45 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-11-24 10:03:45 --> Final output sent to browser
DEBUG - 2021-11-24 10:03:45 --> Total execution time: 0.0229
ERROR - 2021-11-24 10:09:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-24 10:09:19 --> Config Class Initialized
INFO - 2021-11-24 10:09:19 --> Hooks Class Initialized
DEBUG - 2021-11-24 10:09:19 --> UTF-8 Support Enabled
INFO - 2021-11-24 10:09:19 --> Utf8 Class Initialized
INFO - 2021-11-24 10:09:19 --> URI Class Initialized
DEBUG - 2021-11-24 10:09:19 --> No URI present. Default controller set.
INFO - 2021-11-24 10:09:19 --> Router Class Initialized
INFO - 2021-11-24 10:09:19 --> Output Class Initialized
INFO - 2021-11-24 10:09:19 --> Security Class Initialized
DEBUG - 2021-11-24 10:09:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-24 10:09:19 --> Input Class Initialized
INFO - 2021-11-24 10:09:19 --> Language Class Initialized
INFO - 2021-11-24 10:09:19 --> Loader Class Initialized
INFO - 2021-11-24 10:09:19 --> Helper loaded: url_helper
INFO - 2021-11-24 10:09:19 --> Helper loaded: form_helper
INFO - 2021-11-24 10:09:19 --> Helper loaded: common_helper
INFO - 2021-11-24 10:09:19 --> Database Driver Class Initialized
DEBUG - 2021-11-24 10:09:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-24 10:09:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-24 10:09:19 --> Controller Class Initialized
INFO - 2021-11-24 10:09:19 --> Form Validation Class Initialized
DEBUG - 2021-11-24 10:09:19 --> Encrypt Class Initialized
DEBUG - 2021-11-24 10:09:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-24 10:09:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-24 10:09:19 --> Email Class Initialized
INFO - 2021-11-24 10:09:19 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-24 10:09:19 --> Calendar Class Initialized
INFO - 2021-11-24 10:09:19 --> Model "Login_model" initialized
INFO - 2021-11-24 10:09:19 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-11-24 10:09:19 --> Final output sent to browser
DEBUG - 2021-11-24 10:09:19 --> Total execution time: 0.0228
ERROR - 2021-11-24 10:09:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-24 10:09:31 --> Config Class Initialized
INFO - 2021-11-24 10:09:31 --> Hooks Class Initialized
DEBUG - 2021-11-24 10:09:31 --> UTF-8 Support Enabled
INFO - 2021-11-24 10:09:31 --> Utf8 Class Initialized
INFO - 2021-11-24 10:09:31 --> URI Class Initialized
DEBUG - 2021-11-24 10:09:31 --> No URI present. Default controller set.
INFO - 2021-11-24 10:09:31 --> Router Class Initialized
INFO - 2021-11-24 10:09:31 --> Output Class Initialized
INFO - 2021-11-24 10:09:31 --> Security Class Initialized
DEBUG - 2021-11-24 10:09:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-24 10:09:31 --> Input Class Initialized
INFO - 2021-11-24 10:09:31 --> Language Class Initialized
INFO - 2021-11-24 10:09:31 --> Loader Class Initialized
INFO - 2021-11-24 10:09:31 --> Helper loaded: url_helper
INFO - 2021-11-24 10:09:31 --> Helper loaded: form_helper
INFO - 2021-11-24 10:09:31 --> Helper loaded: common_helper
INFO - 2021-11-24 10:09:31 --> Database Driver Class Initialized
DEBUG - 2021-11-24 10:09:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-24 10:09:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-24 10:09:31 --> Controller Class Initialized
INFO - 2021-11-24 10:09:31 --> Form Validation Class Initialized
DEBUG - 2021-11-24 10:09:31 --> Encrypt Class Initialized
DEBUG - 2021-11-24 10:09:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-24 10:09:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-24 10:09:31 --> Email Class Initialized
INFO - 2021-11-24 10:09:31 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-24 10:09:31 --> Calendar Class Initialized
INFO - 2021-11-24 10:09:31 --> Model "Login_model" initialized
INFO - 2021-11-24 10:09:31 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-11-24 10:09:31 --> Final output sent to browser
DEBUG - 2021-11-24 10:09:31 --> Total execution time: 0.0229
ERROR - 2021-11-24 11:47:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-24 11:47:59 --> Config Class Initialized
INFO - 2021-11-24 11:47:59 --> Hooks Class Initialized
DEBUG - 2021-11-24 11:47:59 --> UTF-8 Support Enabled
INFO - 2021-11-24 11:47:59 --> Utf8 Class Initialized
INFO - 2021-11-24 11:47:59 --> URI Class Initialized
DEBUG - 2021-11-24 11:47:59 --> No URI present. Default controller set.
INFO - 2021-11-24 11:47:59 --> Router Class Initialized
INFO - 2021-11-24 11:47:59 --> Output Class Initialized
INFO - 2021-11-24 11:47:59 --> Security Class Initialized
DEBUG - 2021-11-24 11:47:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-24 11:47:59 --> Input Class Initialized
INFO - 2021-11-24 11:47:59 --> Language Class Initialized
INFO - 2021-11-24 11:47:59 --> Loader Class Initialized
INFO - 2021-11-24 11:47:59 --> Helper loaded: url_helper
INFO - 2021-11-24 11:47:59 --> Helper loaded: form_helper
INFO - 2021-11-24 11:47:59 --> Helper loaded: common_helper
INFO - 2021-11-24 11:47:59 --> Database Driver Class Initialized
DEBUG - 2021-11-24 11:47:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-24 11:47:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-24 11:47:59 --> Controller Class Initialized
INFO - 2021-11-24 11:47:59 --> Form Validation Class Initialized
DEBUG - 2021-11-24 11:47:59 --> Encrypt Class Initialized
DEBUG - 2021-11-24 11:47:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-24 11:47:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-24 11:47:59 --> Email Class Initialized
INFO - 2021-11-24 11:47:59 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-24 11:47:59 --> Calendar Class Initialized
INFO - 2021-11-24 11:47:59 --> Model "Login_model" initialized
INFO - 2021-11-24 11:47:59 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-11-24 11:47:59 --> Final output sent to browser
DEBUG - 2021-11-24 11:47:59 --> Total execution time: 0.0247
ERROR - 2021-11-24 11:48:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-24 11:48:00 --> Config Class Initialized
INFO - 2021-11-24 11:48:00 --> Hooks Class Initialized
DEBUG - 2021-11-24 11:48:00 --> UTF-8 Support Enabled
INFO - 2021-11-24 11:48:00 --> Utf8 Class Initialized
INFO - 2021-11-24 11:48:00 --> URI Class Initialized
DEBUG - 2021-11-24 11:48:00 --> No URI present. Default controller set.
INFO - 2021-11-24 11:48:00 --> Router Class Initialized
INFO - 2021-11-24 11:48:00 --> Output Class Initialized
INFO - 2021-11-24 11:48:00 --> Security Class Initialized
DEBUG - 2021-11-24 11:48:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-24 11:48:00 --> Input Class Initialized
INFO - 2021-11-24 11:48:00 --> Language Class Initialized
INFO - 2021-11-24 11:48:00 --> Loader Class Initialized
INFO - 2021-11-24 11:48:00 --> Helper loaded: url_helper
INFO - 2021-11-24 11:48:00 --> Helper loaded: form_helper
INFO - 2021-11-24 11:48:00 --> Helper loaded: common_helper
INFO - 2021-11-24 11:48:00 --> Database Driver Class Initialized
DEBUG - 2021-11-24 11:48:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-24 11:48:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-24 11:48:00 --> Controller Class Initialized
INFO - 2021-11-24 11:48:00 --> Form Validation Class Initialized
DEBUG - 2021-11-24 11:48:00 --> Encrypt Class Initialized
DEBUG - 2021-11-24 11:48:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-24 11:48:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-24 11:48:00 --> Email Class Initialized
INFO - 2021-11-24 11:48:00 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-24 11:48:00 --> Calendar Class Initialized
INFO - 2021-11-24 11:48:00 --> Model "Login_model" initialized
INFO - 2021-11-24 11:48:00 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-11-24 11:48:00 --> Final output sent to browser
DEBUG - 2021-11-24 11:48:00 --> Total execution time: 0.0231
ERROR - 2021-11-24 14:16:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-24 14:16:20 --> Config Class Initialized
INFO - 2021-11-24 14:16:20 --> Hooks Class Initialized
DEBUG - 2021-11-24 14:16:20 --> UTF-8 Support Enabled
INFO - 2021-11-24 14:16:20 --> Utf8 Class Initialized
INFO - 2021-11-24 14:16:20 --> URI Class Initialized
DEBUG - 2021-11-24 14:16:20 --> No URI present. Default controller set.
INFO - 2021-11-24 14:16:20 --> Router Class Initialized
INFO - 2021-11-24 14:16:20 --> Output Class Initialized
INFO - 2021-11-24 14:16:20 --> Security Class Initialized
DEBUG - 2021-11-24 14:16:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-24 14:16:20 --> Input Class Initialized
INFO - 2021-11-24 14:16:20 --> Language Class Initialized
INFO - 2021-11-24 14:16:20 --> Loader Class Initialized
INFO - 2021-11-24 14:16:20 --> Helper loaded: url_helper
INFO - 2021-11-24 14:16:20 --> Helper loaded: form_helper
INFO - 2021-11-24 14:16:20 --> Helper loaded: common_helper
INFO - 2021-11-24 14:16:20 --> Database Driver Class Initialized
DEBUG - 2021-11-24 14:16:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-24 14:16:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-24 14:16:20 --> Controller Class Initialized
INFO - 2021-11-24 14:16:20 --> Form Validation Class Initialized
DEBUG - 2021-11-24 14:16:20 --> Encrypt Class Initialized
DEBUG - 2021-11-24 14:16:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-24 14:16:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-24 14:16:20 --> Email Class Initialized
INFO - 2021-11-24 14:16:20 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-24 14:16:20 --> Calendar Class Initialized
INFO - 2021-11-24 14:16:20 --> Model "Login_model" initialized
INFO - 2021-11-24 14:16:20 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-11-24 14:16:20 --> Final output sent to browser
DEBUG - 2021-11-24 14:16:20 --> Total execution time: 0.8726
ERROR - 2021-11-24 16:39:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-24 16:39:02 --> Config Class Initialized
INFO - 2021-11-24 16:39:02 --> Hooks Class Initialized
DEBUG - 2021-11-24 16:39:02 --> UTF-8 Support Enabled
INFO - 2021-11-24 16:39:02 --> Utf8 Class Initialized
INFO - 2021-11-24 16:39:02 --> URI Class Initialized
DEBUG - 2021-11-24 16:39:02 --> No URI present. Default controller set.
INFO - 2021-11-24 16:39:02 --> Router Class Initialized
INFO - 2021-11-24 16:39:02 --> Output Class Initialized
INFO - 2021-11-24 16:39:02 --> Security Class Initialized
DEBUG - 2021-11-24 16:39:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-24 16:39:02 --> Input Class Initialized
INFO - 2021-11-24 16:39:02 --> Language Class Initialized
INFO - 2021-11-24 16:39:02 --> Loader Class Initialized
INFO - 2021-11-24 16:39:02 --> Helper loaded: url_helper
INFO - 2021-11-24 16:39:02 --> Helper loaded: form_helper
INFO - 2021-11-24 16:39:02 --> Helper loaded: common_helper
INFO - 2021-11-24 16:39:02 --> Database Driver Class Initialized
DEBUG - 2021-11-24 16:39:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-24 16:39:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-24 16:39:02 --> Controller Class Initialized
INFO - 2021-11-24 16:39:02 --> Form Validation Class Initialized
DEBUG - 2021-11-24 16:39:02 --> Encrypt Class Initialized
DEBUG - 2021-11-24 16:39:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-24 16:39:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-24 16:39:02 --> Email Class Initialized
INFO - 2021-11-24 16:39:02 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-24 16:39:02 --> Calendar Class Initialized
INFO - 2021-11-24 16:39:02 --> Model "Login_model" initialized
INFO - 2021-11-24 16:39:02 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-11-24 16:39:02 --> Final output sent to browser
DEBUG - 2021-11-24 16:39:02 --> Total execution time: 0.0246
ERROR - 2021-11-24 17:29:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-24 17:29:09 --> Config Class Initialized
INFO - 2021-11-24 17:29:09 --> Hooks Class Initialized
DEBUG - 2021-11-24 17:29:09 --> UTF-8 Support Enabled
INFO - 2021-11-24 17:29:09 --> Utf8 Class Initialized
INFO - 2021-11-24 17:29:09 --> URI Class Initialized
DEBUG - 2021-11-24 17:29:09 --> No URI present. Default controller set.
INFO - 2021-11-24 17:29:09 --> Router Class Initialized
INFO - 2021-11-24 17:29:09 --> Output Class Initialized
INFO - 2021-11-24 17:29:09 --> Security Class Initialized
DEBUG - 2021-11-24 17:29:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-24 17:29:09 --> Input Class Initialized
INFO - 2021-11-24 17:29:09 --> Language Class Initialized
INFO - 2021-11-24 17:29:09 --> Loader Class Initialized
INFO - 2021-11-24 17:29:09 --> Helper loaded: url_helper
INFO - 2021-11-24 17:29:09 --> Helper loaded: form_helper
INFO - 2021-11-24 17:29:09 --> Helper loaded: common_helper
INFO - 2021-11-24 17:29:09 --> Database Driver Class Initialized
DEBUG - 2021-11-24 17:29:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-24 17:29:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-24 17:29:09 --> Controller Class Initialized
INFO - 2021-11-24 17:29:09 --> Form Validation Class Initialized
DEBUG - 2021-11-24 17:29:09 --> Encrypt Class Initialized
DEBUG - 2021-11-24 17:29:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-24 17:29:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-24 17:29:09 --> Email Class Initialized
INFO - 2021-11-24 17:29:09 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-24 17:29:09 --> Calendar Class Initialized
INFO - 2021-11-24 17:29:09 --> Model "Login_model" initialized
INFO - 2021-11-24 17:29:09 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-11-24 17:29:09 --> Final output sent to browser
DEBUG - 2021-11-24 17:29:09 --> Total execution time: 0.0234
ERROR - 2021-11-24 18:01:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-24 18:01:04 --> Config Class Initialized
INFO - 2021-11-24 18:01:04 --> Hooks Class Initialized
DEBUG - 2021-11-24 18:01:04 --> UTF-8 Support Enabled
INFO - 2021-11-24 18:01:04 --> Utf8 Class Initialized
INFO - 2021-11-24 18:01:04 --> URI Class Initialized
DEBUG - 2021-11-24 18:01:04 --> No URI present. Default controller set.
INFO - 2021-11-24 18:01:04 --> Router Class Initialized
INFO - 2021-11-24 18:01:04 --> Output Class Initialized
INFO - 2021-11-24 18:01:04 --> Security Class Initialized
DEBUG - 2021-11-24 18:01:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-24 18:01:04 --> Input Class Initialized
INFO - 2021-11-24 18:01:04 --> Language Class Initialized
INFO - 2021-11-24 18:01:04 --> Loader Class Initialized
INFO - 2021-11-24 18:01:04 --> Helper loaded: url_helper
INFO - 2021-11-24 18:01:04 --> Helper loaded: form_helper
INFO - 2021-11-24 18:01:04 --> Helper loaded: common_helper
INFO - 2021-11-24 18:01:04 --> Database Driver Class Initialized
DEBUG - 2021-11-24 18:01:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-24 18:01:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-24 18:01:04 --> Controller Class Initialized
INFO - 2021-11-24 18:01:04 --> Form Validation Class Initialized
DEBUG - 2021-11-24 18:01:04 --> Encrypt Class Initialized
DEBUG - 2021-11-24 18:01:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-24 18:01:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-24 18:01:04 --> Email Class Initialized
INFO - 2021-11-24 18:01:04 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-24 18:01:04 --> Calendar Class Initialized
INFO - 2021-11-24 18:01:04 --> Model "Login_model" initialized
INFO - 2021-11-24 18:01:04 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-11-24 18:01:04 --> Final output sent to browser
DEBUG - 2021-11-24 18:01:04 --> Total execution time: 0.0419
ERROR - 2021-11-24 18:01:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-24 18:01:04 --> Config Class Initialized
INFO - 2021-11-24 18:01:04 --> Hooks Class Initialized
DEBUG - 2021-11-24 18:01:04 --> UTF-8 Support Enabled
INFO - 2021-11-24 18:01:04 --> Utf8 Class Initialized
INFO - 2021-11-24 18:01:04 --> URI Class Initialized
DEBUG - 2021-11-24 18:01:04 --> No URI present. Default controller set.
INFO - 2021-11-24 18:01:04 --> Router Class Initialized
INFO - 2021-11-24 18:01:04 --> Output Class Initialized
INFO - 2021-11-24 18:01:04 --> Security Class Initialized
DEBUG - 2021-11-24 18:01:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-24 18:01:04 --> Input Class Initialized
INFO - 2021-11-24 18:01:04 --> Language Class Initialized
INFO - 2021-11-24 18:01:04 --> Loader Class Initialized
INFO - 2021-11-24 18:01:04 --> Helper loaded: url_helper
INFO - 2021-11-24 18:01:04 --> Helper loaded: form_helper
INFO - 2021-11-24 18:01:04 --> Helper loaded: common_helper
INFO - 2021-11-24 18:01:04 --> Database Driver Class Initialized
DEBUG - 2021-11-24 18:01:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-24 18:01:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-24 18:01:04 --> Controller Class Initialized
INFO - 2021-11-24 18:01:04 --> Form Validation Class Initialized
DEBUG - 2021-11-24 18:01:04 --> Encrypt Class Initialized
DEBUG - 2021-11-24 18:01:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-24 18:01:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-24 18:01:04 --> Email Class Initialized
INFO - 2021-11-24 18:01:04 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-24 18:01:04 --> Calendar Class Initialized
INFO - 2021-11-24 18:01:04 --> Model "Login_model" initialized
INFO - 2021-11-24 18:01:04 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-11-24 18:01:04 --> Final output sent to browser
DEBUG - 2021-11-24 18:01:04 --> Total execution time: 0.0266
ERROR - 2021-11-24 22:21:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-24 22:21:27 --> Config Class Initialized
INFO - 2021-11-24 22:21:27 --> Hooks Class Initialized
DEBUG - 2021-11-24 22:21:27 --> UTF-8 Support Enabled
INFO - 2021-11-24 22:21:27 --> Utf8 Class Initialized
INFO - 2021-11-24 22:21:27 --> URI Class Initialized
DEBUG - 2021-11-24 22:21:27 --> No URI present. Default controller set.
INFO - 2021-11-24 22:21:27 --> Router Class Initialized
INFO - 2021-11-24 22:21:27 --> Output Class Initialized
INFO - 2021-11-24 22:21:27 --> Security Class Initialized
DEBUG - 2021-11-24 22:21:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-24 22:21:27 --> Input Class Initialized
INFO - 2021-11-24 22:21:27 --> Language Class Initialized
INFO - 2021-11-24 22:21:27 --> Loader Class Initialized
INFO - 2021-11-24 22:21:27 --> Helper loaded: url_helper
INFO - 2021-11-24 22:21:27 --> Helper loaded: form_helper
INFO - 2021-11-24 22:21:27 --> Helper loaded: common_helper
INFO - 2021-11-24 22:21:27 --> Database Driver Class Initialized
DEBUG - 2021-11-24 22:21:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-24 22:21:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-24 22:21:27 --> Controller Class Initialized
INFO - 2021-11-24 22:21:27 --> Form Validation Class Initialized
DEBUG - 2021-11-24 22:21:27 --> Encrypt Class Initialized
DEBUG - 2021-11-24 22:21:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-24 22:21:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-24 22:21:27 --> Email Class Initialized
INFO - 2021-11-24 22:21:27 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-24 22:21:27 --> Calendar Class Initialized
INFO - 2021-11-24 22:21:27 --> Model "Login_model" initialized
INFO - 2021-11-24 22:21:27 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-11-24 22:21:27 --> Final output sent to browser
DEBUG - 2021-11-24 22:21:27 --> Total execution time: 0.0300
ERROR - 2021-11-24 22:21:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-24 22:21:38 --> Config Class Initialized
INFO - 2021-11-24 22:21:38 --> Hooks Class Initialized
DEBUG - 2021-11-24 22:21:38 --> UTF-8 Support Enabled
INFO - 2021-11-24 22:21:38 --> Utf8 Class Initialized
INFO - 2021-11-24 22:21:38 --> URI Class Initialized
DEBUG - 2021-11-24 22:21:38 --> No URI present. Default controller set.
INFO - 2021-11-24 22:21:38 --> Router Class Initialized
INFO - 2021-11-24 22:21:38 --> Output Class Initialized
INFO - 2021-11-24 22:21:38 --> Security Class Initialized
DEBUG - 2021-11-24 22:21:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-24 22:21:38 --> Input Class Initialized
INFO - 2021-11-24 22:21:38 --> Language Class Initialized
INFO - 2021-11-24 22:21:38 --> Loader Class Initialized
INFO - 2021-11-24 22:21:38 --> Helper loaded: url_helper
INFO - 2021-11-24 22:21:38 --> Helper loaded: form_helper
INFO - 2021-11-24 22:21:39 --> Helper loaded: common_helper
INFO - 2021-11-24 22:21:39 --> Database Driver Class Initialized
DEBUG - 2021-11-24 22:21:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-24 22:21:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-24 22:21:39 --> Controller Class Initialized
INFO - 2021-11-24 22:21:39 --> Form Validation Class Initialized
DEBUG - 2021-11-24 22:21:39 --> Encrypt Class Initialized
DEBUG - 2021-11-24 22:21:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-24 22:21:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-24 22:21:39 --> Email Class Initialized
INFO - 2021-11-24 22:21:39 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-24 22:21:39 --> Calendar Class Initialized
INFO - 2021-11-24 22:21:39 --> Model "Login_model" initialized
INFO - 2021-11-24 22:21:39 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-11-24 22:21:39 --> Final output sent to browser
DEBUG - 2021-11-24 22:21:39 --> Total execution time: 0.0241
ERROR - 2021-11-24 22:21:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-24 22:21:44 --> Config Class Initialized
INFO - 2021-11-24 22:21:44 --> Hooks Class Initialized
DEBUG - 2021-11-24 22:21:44 --> UTF-8 Support Enabled
INFO - 2021-11-24 22:21:44 --> Utf8 Class Initialized
INFO - 2021-11-24 22:21:44 --> URI Class Initialized
DEBUG - 2021-11-24 22:21:44 --> No URI present. Default controller set.
INFO - 2021-11-24 22:21:44 --> Router Class Initialized
INFO - 2021-11-24 22:21:44 --> Output Class Initialized
INFO - 2021-11-24 22:21:44 --> Security Class Initialized
DEBUG - 2021-11-24 22:21:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-24 22:21:44 --> Input Class Initialized
INFO - 2021-11-24 22:21:44 --> Language Class Initialized
INFO - 2021-11-24 22:21:44 --> Loader Class Initialized
INFO - 2021-11-24 22:21:44 --> Helper loaded: url_helper
INFO - 2021-11-24 22:21:44 --> Helper loaded: form_helper
INFO - 2021-11-24 22:21:44 --> Helper loaded: common_helper
INFO - 2021-11-24 22:21:44 --> Database Driver Class Initialized
DEBUG - 2021-11-24 22:21:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-24 22:21:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-24 22:21:44 --> Controller Class Initialized
INFO - 2021-11-24 22:21:44 --> Form Validation Class Initialized
DEBUG - 2021-11-24 22:21:44 --> Encrypt Class Initialized
DEBUG - 2021-11-24 22:21:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-24 22:21:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-24 22:21:44 --> Email Class Initialized
INFO - 2021-11-24 22:21:44 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-24 22:21:44 --> Calendar Class Initialized
INFO - 2021-11-24 22:21:44 --> Model "Login_model" initialized
INFO - 2021-11-24 22:21:44 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-11-24 22:21:44 --> Final output sent to browser
DEBUG - 2021-11-24 22:21:44 --> Total execution time: 0.0245
ERROR - 2021-11-24 23:20:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-24 23:20:14 --> Config Class Initialized
INFO - 2021-11-24 23:20:14 --> Hooks Class Initialized
DEBUG - 2021-11-24 23:20:14 --> UTF-8 Support Enabled
INFO - 2021-11-24 23:20:14 --> Utf8 Class Initialized
INFO - 2021-11-24 23:20:14 --> URI Class Initialized
DEBUG - 2021-11-24 23:20:14 --> No URI present. Default controller set.
INFO - 2021-11-24 23:20:14 --> Router Class Initialized
INFO - 2021-11-24 23:20:14 --> Output Class Initialized
INFO - 2021-11-24 23:20:14 --> Security Class Initialized
DEBUG - 2021-11-24 23:20:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-24 23:20:14 --> Input Class Initialized
INFO - 2021-11-24 23:20:14 --> Language Class Initialized
INFO - 2021-11-24 23:20:14 --> Loader Class Initialized
INFO - 2021-11-24 23:20:14 --> Helper loaded: url_helper
INFO - 2021-11-24 23:20:14 --> Helper loaded: form_helper
INFO - 2021-11-24 23:20:14 --> Helper loaded: common_helper
INFO - 2021-11-24 23:20:14 --> Database Driver Class Initialized
DEBUG - 2021-11-24 23:20:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-24 23:20:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-24 23:20:14 --> Controller Class Initialized
INFO - 2021-11-24 23:20:14 --> Form Validation Class Initialized
DEBUG - 2021-11-24 23:20:14 --> Encrypt Class Initialized
DEBUG - 2021-11-24 23:20:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-24 23:20:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-24 23:20:14 --> Email Class Initialized
INFO - 2021-11-24 23:20:14 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-24 23:20:14 --> Calendar Class Initialized
INFO - 2021-11-24 23:20:14 --> Model "Login_model" initialized
INFO - 2021-11-24 23:20:14 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-11-24 23:20:14 --> Final output sent to browser
DEBUG - 2021-11-24 23:20:14 --> Total execution time: 0.0353
