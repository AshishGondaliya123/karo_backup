<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-01-23 03:11:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-23 03:11:26 --> Config Class Initialized
INFO - 2022-01-23 03:11:26 --> Hooks Class Initialized
DEBUG - 2022-01-23 03:11:26 --> UTF-8 Support Enabled
INFO - 2022-01-23 03:11:26 --> Utf8 Class Initialized
INFO - 2022-01-23 03:11:26 --> URI Class Initialized
DEBUG - 2022-01-23 03:11:26 --> No URI present. Default controller set.
INFO - 2022-01-23 03:11:26 --> Router Class Initialized
INFO - 2022-01-23 03:11:26 --> Output Class Initialized
INFO - 2022-01-23 03:11:26 --> Security Class Initialized
DEBUG - 2022-01-23 03:11:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-23 03:11:26 --> Input Class Initialized
INFO - 2022-01-23 03:11:26 --> Language Class Initialized
INFO - 2022-01-23 03:11:26 --> Loader Class Initialized
INFO - 2022-01-23 03:11:26 --> Helper loaded: url_helper
INFO - 2022-01-23 03:11:26 --> Helper loaded: form_helper
INFO - 2022-01-23 03:11:26 --> Helper loaded: common_helper
INFO - 2022-01-23 03:11:26 --> Database Driver Class Initialized
DEBUG - 2022-01-23 03:11:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-23 03:11:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-23 03:11:26 --> Controller Class Initialized
INFO - 2022-01-23 03:11:26 --> Form Validation Class Initialized
DEBUG - 2022-01-23 03:11:26 --> Encrypt Class Initialized
DEBUG - 2022-01-23 03:11:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-23 03:11:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-23 03:11:26 --> Email Class Initialized
INFO - 2022-01-23 03:11:26 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-23 03:11:26 --> Calendar Class Initialized
INFO - 2022-01-23 03:11:26 --> Model "Login_model" initialized
INFO - 2022-01-23 03:11:26 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-23 03:11:26 --> Final output sent to browser
DEBUG - 2022-01-23 03:11:26 --> Total execution time: 0.0247
ERROR - 2022-01-23 03:57:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-23 03:57:52 --> Config Class Initialized
INFO - 2022-01-23 03:57:52 --> Hooks Class Initialized
DEBUG - 2022-01-23 03:57:52 --> UTF-8 Support Enabled
INFO - 2022-01-23 03:57:52 --> Utf8 Class Initialized
INFO - 2022-01-23 03:57:52 --> URI Class Initialized
DEBUG - 2022-01-23 03:57:52 --> No URI present. Default controller set.
INFO - 2022-01-23 03:57:52 --> Router Class Initialized
INFO - 2022-01-23 03:57:52 --> Output Class Initialized
INFO - 2022-01-23 03:57:52 --> Security Class Initialized
DEBUG - 2022-01-23 03:57:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-23 03:57:52 --> Input Class Initialized
INFO - 2022-01-23 03:57:52 --> Language Class Initialized
INFO - 2022-01-23 03:57:52 --> Loader Class Initialized
INFO - 2022-01-23 03:57:52 --> Helper loaded: url_helper
INFO - 2022-01-23 03:57:52 --> Helper loaded: form_helper
INFO - 2022-01-23 03:57:52 --> Helper loaded: common_helper
INFO - 2022-01-23 03:57:52 --> Database Driver Class Initialized
DEBUG - 2022-01-23 03:57:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-23 03:57:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-23 03:57:52 --> Controller Class Initialized
INFO - 2022-01-23 03:57:52 --> Form Validation Class Initialized
DEBUG - 2022-01-23 03:57:52 --> Encrypt Class Initialized
DEBUG - 2022-01-23 03:57:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-23 03:57:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-23 03:57:52 --> Email Class Initialized
INFO - 2022-01-23 03:57:52 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-23 03:57:52 --> Calendar Class Initialized
INFO - 2022-01-23 03:57:52 --> Model "Login_model" initialized
INFO - 2022-01-23 03:57:52 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-23 03:57:52 --> Final output sent to browser
DEBUG - 2022-01-23 03:57:52 --> Total execution time: 0.0230
ERROR - 2022-01-23 04:46:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-23 04:46:02 --> Config Class Initialized
INFO - 2022-01-23 04:46:02 --> Hooks Class Initialized
DEBUG - 2022-01-23 04:46:02 --> UTF-8 Support Enabled
INFO - 2022-01-23 04:46:02 --> Utf8 Class Initialized
INFO - 2022-01-23 04:46:02 --> URI Class Initialized
INFO - 2022-01-23 04:46:02 --> Router Class Initialized
INFO - 2022-01-23 04:46:02 --> Output Class Initialized
INFO - 2022-01-23 04:46:02 --> Security Class Initialized
DEBUG - 2022-01-23 04:46:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-23 04:46:02 --> Input Class Initialized
INFO - 2022-01-23 04:46:02 --> Language Class Initialized
ERROR - 2022-01-23 04:46:02 --> 404 Page Not Found: Humanstxt/index
ERROR - 2022-01-23 04:46:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-23 04:46:02 --> Config Class Initialized
INFO - 2022-01-23 04:46:02 --> Hooks Class Initialized
DEBUG - 2022-01-23 04:46:02 --> UTF-8 Support Enabled
INFO - 2022-01-23 04:46:02 --> Utf8 Class Initialized
INFO - 2022-01-23 04:46:02 --> URI Class Initialized
INFO - 2022-01-23 04:46:02 --> Router Class Initialized
INFO - 2022-01-23 04:46:02 --> Output Class Initialized
INFO - 2022-01-23 04:46:02 --> Security Class Initialized
DEBUG - 2022-01-23 04:46:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-23 04:46:02 --> Input Class Initialized
INFO - 2022-01-23 04:46:02 --> Language Class Initialized
ERROR - 2022-01-23 04:46:02 --> 404 Page Not Found: Adstxt/index
ERROR - 2022-01-23 04:46:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-23 04:46:03 --> Config Class Initialized
INFO - 2022-01-23 04:46:03 --> Hooks Class Initialized
DEBUG - 2022-01-23 04:46:03 --> UTF-8 Support Enabled
INFO - 2022-01-23 04:46:03 --> Utf8 Class Initialized
INFO - 2022-01-23 04:46:03 --> URI Class Initialized
DEBUG - 2022-01-23 04:46:03 --> No URI present. Default controller set.
INFO - 2022-01-23 04:46:03 --> Router Class Initialized
INFO - 2022-01-23 04:46:03 --> Output Class Initialized
INFO - 2022-01-23 04:46:03 --> Security Class Initialized
DEBUG - 2022-01-23 04:46:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-23 04:46:03 --> Input Class Initialized
INFO - 2022-01-23 04:46:03 --> Language Class Initialized
INFO - 2022-01-23 04:46:03 --> Loader Class Initialized
INFO - 2022-01-23 04:46:03 --> Helper loaded: url_helper
INFO - 2022-01-23 04:46:03 --> Helper loaded: form_helper
INFO - 2022-01-23 04:46:03 --> Helper loaded: common_helper
INFO - 2022-01-23 04:46:03 --> Database Driver Class Initialized
DEBUG - 2022-01-23 04:46:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-23 04:46:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-23 04:46:03 --> Controller Class Initialized
INFO - 2022-01-23 04:46:03 --> Form Validation Class Initialized
DEBUG - 2022-01-23 04:46:03 --> Encrypt Class Initialized
DEBUG - 2022-01-23 04:46:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-23 04:46:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-23 04:46:03 --> Email Class Initialized
INFO - 2022-01-23 04:46:03 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-23 04:46:03 --> Calendar Class Initialized
INFO - 2022-01-23 04:46:03 --> Model "Login_model" initialized
INFO - 2022-01-23 04:46:03 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-23 04:46:03 --> Final output sent to browser
DEBUG - 2022-01-23 04:46:03 --> Total execution time: 0.0524
ERROR - 2022-01-23 13:19:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-23 13:19:38 --> Config Class Initialized
INFO - 2022-01-23 13:19:38 --> Hooks Class Initialized
DEBUG - 2022-01-23 13:19:38 --> UTF-8 Support Enabled
INFO - 2022-01-23 13:19:38 --> Utf8 Class Initialized
INFO - 2022-01-23 13:19:38 --> URI Class Initialized
DEBUG - 2022-01-23 13:19:38 --> No URI present. Default controller set.
INFO - 2022-01-23 13:19:38 --> Router Class Initialized
INFO - 2022-01-23 13:19:38 --> Output Class Initialized
INFO - 2022-01-23 13:19:38 --> Security Class Initialized
DEBUG - 2022-01-23 13:19:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-23 13:19:38 --> Input Class Initialized
INFO - 2022-01-23 13:19:38 --> Language Class Initialized
INFO - 2022-01-23 13:19:38 --> Loader Class Initialized
INFO - 2022-01-23 13:19:38 --> Helper loaded: url_helper
INFO - 2022-01-23 13:19:38 --> Helper loaded: form_helper
INFO - 2022-01-23 13:19:38 --> Helper loaded: common_helper
INFO - 2022-01-23 13:19:38 --> Database Driver Class Initialized
DEBUG - 2022-01-23 13:19:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-23 13:19:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-23 13:19:38 --> Controller Class Initialized
INFO - 2022-01-23 13:19:38 --> Form Validation Class Initialized
DEBUG - 2022-01-23 13:19:38 --> Encrypt Class Initialized
DEBUG - 2022-01-23 13:19:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-23 13:19:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-23 13:19:38 --> Email Class Initialized
INFO - 2022-01-23 13:19:38 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-23 13:19:38 --> Calendar Class Initialized
INFO - 2022-01-23 13:19:38 --> Model "Login_model" initialized
INFO - 2022-01-23 13:19:38 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-23 13:19:38 --> Final output sent to browser
DEBUG - 2022-01-23 13:19:38 --> Total execution time: 0.0312
ERROR - 2022-01-23 13:19:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-23 13:19:38 --> Config Class Initialized
INFO - 2022-01-23 13:19:38 --> Hooks Class Initialized
DEBUG - 2022-01-23 13:19:38 --> UTF-8 Support Enabled
INFO - 2022-01-23 13:19:38 --> Utf8 Class Initialized
INFO - 2022-01-23 13:19:38 --> URI Class Initialized
DEBUG - 2022-01-23 13:19:38 --> No URI present. Default controller set.
INFO - 2022-01-23 13:19:38 --> Router Class Initialized
INFO - 2022-01-23 13:19:38 --> Output Class Initialized
INFO - 2022-01-23 13:19:38 --> Security Class Initialized
DEBUG - 2022-01-23 13:19:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-23 13:19:38 --> Input Class Initialized
INFO - 2022-01-23 13:19:38 --> Language Class Initialized
INFO - 2022-01-23 13:19:38 --> Loader Class Initialized
INFO - 2022-01-23 13:19:38 --> Helper loaded: url_helper
INFO - 2022-01-23 13:19:38 --> Helper loaded: form_helper
INFO - 2022-01-23 13:19:38 --> Helper loaded: common_helper
INFO - 2022-01-23 13:19:38 --> Database Driver Class Initialized
DEBUG - 2022-01-23 13:19:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-23 13:19:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-23 13:19:38 --> Controller Class Initialized
INFO - 2022-01-23 13:19:38 --> Form Validation Class Initialized
DEBUG - 2022-01-23 13:19:38 --> Encrypt Class Initialized
DEBUG - 2022-01-23 13:19:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-23 13:19:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-23 13:19:38 --> Email Class Initialized
INFO - 2022-01-23 13:19:38 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-23 13:19:38 --> Calendar Class Initialized
INFO - 2022-01-23 13:19:38 --> Model "Login_model" initialized
INFO - 2022-01-23 13:19:38 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-23 13:19:38 --> Final output sent to browser
DEBUG - 2022-01-23 13:19:38 --> Total execution time: 0.0343
ERROR - 2022-01-23 14:17:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-23 14:17:09 --> Config Class Initialized
INFO - 2022-01-23 14:17:09 --> Hooks Class Initialized
DEBUG - 2022-01-23 14:17:09 --> UTF-8 Support Enabled
INFO - 2022-01-23 14:17:09 --> Utf8 Class Initialized
INFO - 2022-01-23 14:17:09 --> URI Class Initialized
DEBUG - 2022-01-23 14:17:09 --> No URI present. Default controller set.
INFO - 2022-01-23 14:17:09 --> Router Class Initialized
INFO - 2022-01-23 14:17:09 --> Output Class Initialized
INFO - 2022-01-23 14:17:09 --> Security Class Initialized
DEBUG - 2022-01-23 14:17:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-23 14:17:09 --> Input Class Initialized
INFO - 2022-01-23 14:17:09 --> Language Class Initialized
INFO - 2022-01-23 14:17:09 --> Loader Class Initialized
INFO - 2022-01-23 14:17:09 --> Helper loaded: url_helper
INFO - 2022-01-23 14:17:09 --> Helper loaded: form_helper
INFO - 2022-01-23 14:17:09 --> Helper loaded: common_helper
INFO - 2022-01-23 14:17:09 --> Database Driver Class Initialized
DEBUG - 2022-01-23 14:17:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-23 14:17:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-23 14:17:09 --> Controller Class Initialized
INFO - 2022-01-23 14:17:09 --> Form Validation Class Initialized
DEBUG - 2022-01-23 14:17:09 --> Encrypt Class Initialized
DEBUG - 2022-01-23 14:17:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-23 14:17:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-23 14:17:09 --> Email Class Initialized
INFO - 2022-01-23 14:17:09 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-23 14:17:09 --> Calendar Class Initialized
INFO - 2022-01-23 14:17:09 --> Model "Login_model" initialized
INFO - 2022-01-23 14:17:09 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-23 14:17:09 --> Final output sent to browser
DEBUG - 2022-01-23 14:17:09 --> Total execution time: 0.0309
ERROR - 2022-01-23 14:17:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-23 14:17:11 --> Config Class Initialized
INFO - 2022-01-23 14:17:11 --> Hooks Class Initialized
DEBUG - 2022-01-23 14:17:11 --> UTF-8 Support Enabled
INFO - 2022-01-23 14:17:11 --> Utf8 Class Initialized
INFO - 2022-01-23 14:17:11 --> URI Class Initialized
INFO - 2022-01-23 14:17:11 --> Router Class Initialized
INFO - 2022-01-23 14:17:11 --> Output Class Initialized
INFO - 2022-01-23 14:17:11 --> Security Class Initialized
DEBUG - 2022-01-23 14:17:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-23 14:17:11 --> Input Class Initialized
INFO - 2022-01-23 14:17:11 --> Language Class Initialized
ERROR - 2022-01-23 14:17:11 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2022-01-23 14:18:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-23 14:18:06 --> Config Class Initialized
INFO - 2022-01-23 14:18:06 --> Hooks Class Initialized
DEBUG - 2022-01-23 14:18:06 --> UTF-8 Support Enabled
INFO - 2022-01-23 14:18:06 --> Utf8 Class Initialized
INFO - 2022-01-23 14:18:06 --> URI Class Initialized
INFO - 2022-01-23 14:18:06 --> Router Class Initialized
INFO - 2022-01-23 14:18:06 --> Output Class Initialized
INFO - 2022-01-23 14:18:06 --> Security Class Initialized
DEBUG - 2022-01-23 14:18:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-23 14:18:06 --> Input Class Initialized
INFO - 2022-01-23 14:18:06 --> Language Class Initialized
INFO - 2022-01-23 14:18:06 --> Loader Class Initialized
INFO - 2022-01-23 14:18:06 --> Helper loaded: url_helper
INFO - 2022-01-23 14:18:06 --> Helper loaded: form_helper
INFO - 2022-01-23 14:18:06 --> Helper loaded: common_helper
INFO - 2022-01-23 14:18:06 --> Database Driver Class Initialized
DEBUG - 2022-01-23 14:18:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-23 14:18:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-23 14:18:06 --> Controller Class Initialized
INFO - 2022-01-23 14:18:06 --> Form Validation Class Initialized
DEBUG - 2022-01-23 14:18:06 --> Encrypt Class Initialized
DEBUG - 2022-01-23 14:18:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-23 14:18:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-23 14:18:06 --> Email Class Initialized
INFO - 2022-01-23 14:18:06 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-23 14:18:06 --> Calendar Class Initialized
INFO - 2022-01-23 14:18:06 --> Model "Login_model" initialized
INFO - 2022-01-23 14:18:06 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-23 14:18:06 --> Final output sent to browser
DEBUG - 2022-01-23 14:18:06 --> Total execution time: 0.0230
ERROR - 2022-01-23 14:18:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-23 14:18:06 --> Config Class Initialized
INFO - 2022-01-23 14:18:06 --> Hooks Class Initialized
DEBUG - 2022-01-23 14:18:06 --> UTF-8 Support Enabled
INFO - 2022-01-23 14:18:06 --> Utf8 Class Initialized
INFO - 2022-01-23 14:18:06 --> URI Class Initialized
DEBUG - 2022-01-23 14:18:06 --> No URI present. Default controller set.
INFO - 2022-01-23 14:18:06 --> Router Class Initialized
INFO - 2022-01-23 14:18:06 --> Output Class Initialized
INFO - 2022-01-23 14:18:06 --> Security Class Initialized
DEBUG - 2022-01-23 14:18:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-23 14:18:06 --> Input Class Initialized
INFO - 2022-01-23 14:18:06 --> Language Class Initialized
INFO - 2022-01-23 14:18:06 --> Loader Class Initialized
INFO - 2022-01-23 14:18:06 --> Helper loaded: url_helper
INFO - 2022-01-23 14:18:06 --> Helper loaded: form_helper
INFO - 2022-01-23 14:18:06 --> Helper loaded: common_helper
INFO - 2022-01-23 14:18:06 --> Database Driver Class Initialized
DEBUG - 2022-01-23 14:18:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-23 14:18:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-23 14:18:06 --> Controller Class Initialized
INFO - 2022-01-23 14:18:06 --> Form Validation Class Initialized
DEBUG - 2022-01-23 14:18:06 --> Encrypt Class Initialized
DEBUG - 2022-01-23 14:18:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-23 14:18:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-23 14:18:06 --> Email Class Initialized
INFO - 2022-01-23 14:18:06 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-23 14:18:06 --> Calendar Class Initialized
INFO - 2022-01-23 14:18:06 --> Model "Login_model" initialized
INFO - 2022-01-23 14:18:06 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-23 14:18:06 --> Final output sent to browser
DEBUG - 2022-01-23 14:18:06 --> Total execution time: 0.0332
ERROR - 2022-01-23 14:18:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-23 14:18:07 --> Config Class Initialized
INFO - 2022-01-23 14:18:07 --> Hooks Class Initialized
DEBUG - 2022-01-23 14:18:07 --> UTF-8 Support Enabled
INFO - 2022-01-23 14:18:07 --> Utf8 Class Initialized
INFO - 2022-01-23 14:18:07 --> URI Class Initialized
INFO - 2022-01-23 14:18:07 --> Router Class Initialized
INFO - 2022-01-23 14:18:07 --> Output Class Initialized
INFO - 2022-01-23 14:18:07 --> Security Class Initialized
DEBUG - 2022-01-23 14:18:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-23 14:18:07 --> Input Class Initialized
INFO - 2022-01-23 14:18:07 --> Language Class Initialized
INFO - 2022-01-23 14:18:07 --> Loader Class Initialized
INFO - 2022-01-23 14:18:07 --> Helper loaded: url_helper
INFO - 2022-01-23 14:18:07 --> Helper loaded: form_helper
INFO - 2022-01-23 14:18:07 --> Helper loaded: common_helper
INFO - 2022-01-23 14:18:07 --> Database Driver Class Initialized
DEBUG - 2022-01-23 14:18:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-23 14:18:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-23 14:18:07 --> Controller Class Initialized
INFO - 2022-01-23 14:18:07 --> Form Validation Class Initialized
DEBUG - 2022-01-23 14:18:07 --> Encrypt Class Initialized
DEBUG - 2022-01-23 14:18:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-23 14:18:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-23 14:18:07 --> Email Class Initialized
INFO - 2022-01-23 14:18:07 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-23 14:18:07 --> Calendar Class Initialized
INFO - 2022-01-23 14:18:07 --> Model "Login_model" initialized
ERROR - 2022-01-23 14:18:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-23 14:18:08 --> Config Class Initialized
INFO - 2022-01-23 14:18:08 --> Hooks Class Initialized
DEBUG - 2022-01-23 14:18:08 --> UTF-8 Support Enabled
INFO - 2022-01-23 14:18:08 --> Utf8 Class Initialized
INFO - 2022-01-23 14:18:08 --> URI Class Initialized
INFO - 2022-01-23 14:18:08 --> Router Class Initialized
INFO - 2022-01-23 14:18:08 --> Output Class Initialized
INFO - 2022-01-23 14:18:08 --> Security Class Initialized
DEBUG - 2022-01-23 14:18:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-23 14:18:08 --> Input Class Initialized
INFO - 2022-01-23 14:18:08 --> Language Class Initialized
INFO - 2022-01-23 14:18:08 --> Loader Class Initialized
INFO - 2022-01-23 14:18:08 --> Helper loaded: url_helper
INFO - 2022-01-23 14:18:08 --> Helper loaded: form_helper
INFO - 2022-01-23 14:18:08 --> Helper loaded: common_helper
INFO - 2022-01-23 14:18:08 --> Database Driver Class Initialized
DEBUG - 2022-01-23 14:18:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-23 14:18:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-23 14:18:08 --> Controller Class Initialized
INFO - 2022-01-23 14:18:08 --> Form Validation Class Initialized
DEBUG - 2022-01-23 14:18:08 --> Encrypt Class Initialized
DEBUG - 2022-01-23 14:18:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-23 14:18:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-23 14:18:08 --> Email Class Initialized
INFO - 2022-01-23 14:18:08 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-23 14:18:08 --> Calendar Class Initialized
INFO - 2022-01-23 14:18:08 --> Model "Login_model" initialized
