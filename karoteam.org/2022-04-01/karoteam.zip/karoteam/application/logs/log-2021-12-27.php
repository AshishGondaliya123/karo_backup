<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-12-27 03:04:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-27 03:04:39 --> Config Class Initialized
INFO - 2021-12-27 03:04:39 --> Hooks Class Initialized
DEBUG - 2021-12-27 03:04:39 --> UTF-8 Support Enabled
INFO - 2021-12-27 03:04:39 --> Utf8 Class Initialized
INFO - 2021-12-27 03:04:39 --> URI Class Initialized
DEBUG - 2021-12-27 03:04:39 --> No URI present. Default controller set.
INFO - 2021-12-27 03:04:39 --> Router Class Initialized
INFO - 2021-12-27 03:04:39 --> Output Class Initialized
INFO - 2021-12-27 03:04:39 --> Security Class Initialized
DEBUG - 2021-12-27 03:04:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-27 03:04:39 --> Input Class Initialized
INFO - 2021-12-27 03:04:39 --> Language Class Initialized
INFO - 2021-12-27 03:04:39 --> Loader Class Initialized
INFO - 2021-12-27 03:04:39 --> Helper loaded: url_helper
INFO - 2021-12-27 03:04:39 --> Helper loaded: form_helper
INFO - 2021-12-27 03:04:39 --> Helper loaded: common_helper
INFO - 2021-12-27 03:04:39 --> Database Driver Class Initialized
DEBUG - 2021-12-27 03:04:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-27 03:04:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-27 03:04:39 --> Controller Class Initialized
INFO - 2021-12-27 03:04:39 --> Form Validation Class Initialized
DEBUG - 2021-12-27 03:04:39 --> Encrypt Class Initialized
DEBUG - 2021-12-27 03:04:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 03:04:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-27 03:04:39 --> Email Class Initialized
INFO - 2021-12-27 03:04:39 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-27 03:04:39 --> Calendar Class Initialized
INFO - 2021-12-27 03:04:39 --> Model "Login_model" initialized
INFO - 2021-12-27 03:04:39 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-27 03:04:39 --> Final output sent to browser
DEBUG - 2021-12-27 03:04:39 --> Total execution time: 0.0228
ERROR - 2021-12-27 10:33:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-27 10:33:17 --> Config Class Initialized
INFO - 2021-12-27 10:33:17 --> Hooks Class Initialized
DEBUG - 2021-12-27 10:33:17 --> UTF-8 Support Enabled
INFO - 2021-12-27 10:33:17 --> Utf8 Class Initialized
INFO - 2021-12-27 10:33:17 --> URI Class Initialized
DEBUG - 2021-12-27 10:33:17 --> No URI present. Default controller set.
INFO - 2021-12-27 10:33:17 --> Router Class Initialized
INFO - 2021-12-27 10:33:17 --> Output Class Initialized
INFO - 2021-12-27 10:33:17 --> Security Class Initialized
DEBUG - 2021-12-27 10:33:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-27 10:33:17 --> Input Class Initialized
INFO - 2021-12-27 10:33:17 --> Language Class Initialized
INFO - 2021-12-27 10:33:17 --> Loader Class Initialized
INFO - 2021-12-27 10:33:17 --> Helper loaded: url_helper
INFO - 2021-12-27 10:33:17 --> Helper loaded: form_helper
INFO - 2021-12-27 10:33:17 --> Helper loaded: common_helper
INFO - 2021-12-27 10:33:17 --> Database Driver Class Initialized
DEBUG - 2021-12-27 10:33:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-27 10:33:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-27 10:33:17 --> Controller Class Initialized
INFO - 2021-12-27 10:33:17 --> Form Validation Class Initialized
DEBUG - 2021-12-27 10:33:17 --> Encrypt Class Initialized
DEBUG - 2021-12-27 10:33:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 10:33:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-27 10:33:17 --> Email Class Initialized
INFO - 2021-12-27 10:33:17 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-27 10:33:17 --> Calendar Class Initialized
INFO - 2021-12-27 10:33:17 --> Model "Login_model" initialized
INFO - 2021-12-27 10:33:17 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-27 10:33:17 --> Final output sent to browser
DEBUG - 2021-12-27 10:33:17 --> Total execution time: 0.0336
ERROR - 2021-12-27 13:21:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-27 13:21:24 --> Config Class Initialized
INFO - 2021-12-27 13:21:24 --> Hooks Class Initialized
DEBUG - 2021-12-27 13:21:24 --> UTF-8 Support Enabled
INFO - 2021-12-27 13:21:24 --> Utf8 Class Initialized
INFO - 2021-12-27 13:21:24 --> URI Class Initialized
DEBUG - 2021-12-27 13:21:24 --> No URI present. Default controller set.
INFO - 2021-12-27 13:21:24 --> Router Class Initialized
INFO - 2021-12-27 13:21:24 --> Output Class Initialized
INFO - 2021-12-27 13:21:24 --> Security Class Initialized
DEBUG - 2021-12-27 13:21:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-27 13:21:24 --> Input Class Initialized
INFO - 2021-12-27 13:21:24 --> Language Class Initialized
INFO - 2021-12-27 13:21:24 --> Loader Class Initialized
INFO - 2021-12-27 13:21:24 --> Helper loaded: url_helper
INFO - 2021-12-27 13:21:24 --> Helper loaded: form_helper
INFO - 2021-12-27 13:21:24 --> Helper loaded: common_helper
INFO - 2021-12-27 13:21:24 --> Database Driver Class Initialized
DEBUG - 2021-12-27 13:21:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-27 13:21:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-27 13:21:24 --> Controller Class Initialized
INFO - 2021-12-27 13:21:24 --> Form Validation Class Initialized
DEBUG - 2021-12-27 13:21:24 --> Encrypt Class Initialized
DEBUG - 2021-12-27 13:21:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 13:21:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-27 13:21:24 --> Email Class Initialized
INFO - 2021-12-27 13:21:24 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-27 13:21:24 --> Calendar Class Initialized
INFO - 2021-12-27 13:21:24 --> Model "Login_model" initialized
INFO - 2021-12-27 13:21:24 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-27 13:21:24 --> Final output sent to browser
DEBUG - 2021-12-27 13:21:24 --> Total execution time: 0.0510
ERROR - 2021-12-27 14:19:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-27 14:19:58 --> Config Class Initialized
INFO - 2021-12-27 14:19:58 --> Hooks Class Initialized
DEBUG - 2021-12-27 14:19:58 --> UTF-8 Support Enabled
INFO - 2021-12-27 14:19:58 --> Utf8 Class Initialized
INFO - 2021-12-27 14:19:58 --> URI Class Initialized
DEBUG - 2021-12-27 14:19:58 --> No URI present. Default controller set.
INFO - 2021-12-27 14:19:58 --> Router Class Initialized
INFO - 2021-12-27 14:19:58 --> Output Class Initialized
INFO - 2021-12-27 14:19:58 --> Security Class Initialized
DEBUG - 2021-12-27 14:19:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-27 14:19:58 --> Input Class Initialized
INFO - 2021-12-27 14:19:58 --> Language Class Initialized
INFO - 2021-12-27 14:19:58 --> Loader Class Initialized
INFO - 2021-12-27 14:19:58 --> Helper loaded: url_helper
INFO - 2021-12-27 14:19:58 --> Helper loaded: form_helper
INFO - 2021-12-27 14:19:58 --> Helper loaded: common_helper
INFO - 2021-12-27 14:19:58 --> Database Driver Class Initialized
DEBUG - 2021-12-27 14:19:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-27 14:19:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-27 14:19:58 --> Controller Class Initialized
INFO - 2021-12-27 14:19:58 --> Form Validation Class Initialized
DEBUG - 2021-12-27 14:19:58 --> Encrypt Class Initialized
DEBUG - 2021-12-27 14:19:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 14:19:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-27 14:19:58 --> Email Class Initialized
INFO - 2021-12-27 14:19:58 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-27 14:19:58 --> Calendar Class Initialized
INFO - 2021-12-27 14:19:58 --> Model "Login_model" initialized
INFO - 2021-12-27 14:19:58 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-27 14:19:58 --> Final output sent to browser
DEBUG - 2021-12-27 14:19:58 --> Total execution time: 0.0308
ERROR - 2021-12-27 14:20:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-27 14:20:00 --> Config Class Initialized
INFO - 2021-12-27 14:20:00 --> Hooks Class Initialized
DEBUG - 2021-12-27 14:20:00 --> UTF-8 Support Enabled
INFO - 2021-12-27 14:20:00 --> Utf8 Class Initialized
INFO - 2021-12-27 14:20:00 --> URI Class Initialized
INFO - 2021-12-27 14:20:00 --> Router Class Initialized
INFO - 2021-12-27 14:20:00 --> Output Class Initialized
INFO - 2021-12-27 14:20:00 --> Security Class Initialized
DEBUG - 2021-12-27 14:20:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-27 14:20:00 --> Input Class Initialized
INFO - 2021-12-27 14:20:00 --> Language Class Initialized
ERROR - 2021-12-27 14:20:00 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2021-12-27 14:20:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-27 14:20:13 --> Config Class Initialized
INFO - 2021-12-27 14:20:13 --> Hooks Class Initialized
DEBUG - 2021-12-27 14:20:13 --> UTF-8 Support Enabled
INFO - 2021-12-27 14:20:13 --> Utf8 Class Initialized
INFO - 2021-12-27 14:20:13 --> URI Class Initialized
INFO - 2021-12-27 14:20:13 --> Router Class Initialized
INFO - 2021-12-27 14:20:13 --> Output Class Initialized
INFO - 2021-12-27 14:20:13 --> Security Class Initialized
DEBUG - 2021-12-27 14:20:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-27 14:20:13 --> Input Class Initialized
INFO - 2021-12-27 14:20:13 --> Language Class Initialized
INFO - 2021-12-27 14:20:13 --> Loader Class Initialized
INFO - 2021-12-27 14:20:13 --> Helper loaded: url_helper
INFO - 2021-12-27 14:20:13 --> Helper loaded: form_helper
INFO - 2021-12-27 14:20:13 --> Helper loaded: common_helper
INFO - 2021-12-27 14:20:13 --> Database Driver Class Initialized
DEBUG - 2021-12-27 14:20:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-27 14:20:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-27 14:20:13 --> Controller Class Initialized
INFO - 2021-12-27 14:20:13 --> Form Validation Class Initialized
DEBUG - 2021-12-27 14:20:13 --> Encrypt Class Initialized
DEBUG - 2021-12-27 14:20:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 14:20:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-27 14:20:13 --> Email Class Initialized
INFO - 2021-12-27 14:20:13 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-27 14:20:13 --> Calendar Class Initialized
INFO - 2021-12-27 14:20:13 --> Model "Login_model" initialized
ERROR - 2021-12-27 14:20:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-27 14:20:13 --> Config Class Initialized
INFO - 2021-12-27 14:20:13 --> Hooks Class Initialized
DEBUG - 2021-12-27 14:20:13 --> UTF-8 Support Enabled
INFO - 2021-12-27 14:20:13 --> Utf8 Class Initialized
INFO - 2021-12-27 14:20:13 --> URI Class Initialized
INFO - 2021-12-27 14:20:13 --> Router Class Initialized
INFO - 2021-12-27 14:20:13 --> Output Class Initialized
INFO - 2021-12-27 14:20:13 --> Security Class Initialized
DEBUG - 2021-12-27 14:20:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-27 14:20:13 --> Input Class Initialized
INFO - 2021-12-27 14:20:13 --> Language Class Initialized
INFO - 2021-12-27 14:20:13 --> Loader Class Initialized
INFO - 2021-12-27 14:20:13 --> Helper loaded: url_helper
INFO - 2021-12-27 14:20:13 --> Helper loaded: form_helper
INFO - 2021-12-27 14:20:13 --> Helper loaded: common_helper
INFO - 2021-12-27 14:20:13 --> Database Driver Class Initialized
DEBUG - 2021-12-27 14:20:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-27 14:20:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-27 14:20:13 --> Controller Class Initialized
INFO - 2021-12-27 14:20:13 --> Form Validation Class Initialized
DEBUG - 2021-12-27 14:20:13 --> Encrypt Class Initialized
DEBUG - 2021-12-27 14:20:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 14:20:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-27 14:20:13 --> Email Class Initialized
INFO - 2021-12-27 14:20:13 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-27 14:20:13 --> Calendar Class Initialized
INFO - 2021-12-27 14:20:13 --> Model "Login_model" initialized
ERROR - 2021-12-27 14:20:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-27 14:20:14 --> Config Class Initialized
INFO - 2021-12-27 14:20:14 --> Hooks Class Initialized
DEBUG - 2021-12-27 14:20:14 --> UTF-8 Support Enabled
INFO - 2021-12-27 14:20:14 --> Utf8 Class Initialized
INFO - 2021-12-27 14:20:14 --> URI Class Initialized
DEBUG - 2021-12-27 14:20:14 --> No URI present. Default controller set.
INFO - 2021-12-27 14:20:14 --> Router Class Initialized
INFO - 2021-12-27 14:20:14 --> Output Class Initialized
INFO - 2021-12-27 14:20:14 --> Security Class Initialized
DEBUG - 2021-12-27 14:20:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-27 14:20:14 --> Input Class Initialized
INFO - 2021-12-27 14:20:14 --> Language Class Initialized
INFO - 2021-12-27 14:20:14 --> Loader Class Initialized
INFO - 2021-12-27 14:20:14 --> Helper loaded: url_helper
INFO - 2021-12-27 14:20:14 --> Helper loaded: form_helper
INFO - 2021-12-27 14:20:14 --> Helper loaded: common_helper
INFO - 2021-12-27 14:20:14 --> Database Driver Class Initialized
DEBUG - 2021-12-27 14:20:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-27 14:20:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-27 14:20:14 --> Controller Class Initialized
INFO - 2021-12-27 14:20:14 --> Form Validation Class Initialized
DEBUG - 2021-12-27 14:20:14 --> Encrypt Class Initialized
DEBUG - 2021-12-27 14:20:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 14:20:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-27 14:20:14 --> Email Class Initialized
INFO - 2021-12-27 14:20:14 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-27 14:20:14 --> Calendar Class Initialized
INFO - 2021-12-27 14:20:14 --> Model "Login_model" initialized
INFO - 2021-12-27 14:20:14 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-27 14:20:14 --> Final output sent to browser
DEBUG - 2021-12-27 14:20:14 --> Total execution time: 0.0314
ERROR - 2021-12-27 14:20:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-27 14:20:15 --> Config Class Initialized
INFO - 2021-12-27 14:20:15 --> Hooks Class Initialized
DEBUG - 2021-12-27 14:20:15 --> UTF-8 Support Enabled
INFO - 2021-12-27 14:20:15 --> Utf8 Class Initialized
INFO - 2021-12-27 14:20:15 --> URI Class Initialized
INFO - 2021-12-27 14:20:15 --> Router Class Initialized
INFO - 2021-12-27 14:20:15 --> Output Class Initialized
INFO - 2021-12-27 14:20:15 --> Security Class Initialized
DEBUG - 2021-12-27 14:20:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-27 14:20:15 --> Input Class Initialized
INFO - 2021-12-27 14:20:15 --> Language Class Initialized
INFO - 2021-12-27 14:20:15 --> Loader Class Initialized
INFO - 2021-12-27 14:20:15 --> Helper loaded: url_helper
INFO - 2021-12-27 14:20:15 --> Helper loaded: form_helper
INFO - 2021-12-27 14:20:15 --> Helper loaded: common_helper
INFO - 2021-12-27 14:20:15 --> Database Driver Class Initialized
DEBUG - 2021-12-27 14:20:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-27 14:20:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-27 14:20:15 --> Controller Class Initialized
INFO - 2021-12-27 14:20:15 --> Form Validation Class Initialized
DEBUG - 2021-12-27 14:20:15 --> Encrypt Class Initialized
DEBUG - 2021-12-27 14:20:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 14:20:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-27 14:20:15 --> Email Class Initialized
INFO - 2021-12-27 14:20:15 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-27 14:20:15 --> Calendar Class Initialized
INFO - 2021-12-27 14:20:15 --> Model "Login_model" initialized
INFO - 2021-12-27 14:20:15 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-27 14:20:15 --> Final output sent to browser
DEBUG - 2021-12-27 14:20:15 --> Total execution time: 0.0222
ERROR - 2021-12-27 15:44:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-27 15:44:11 --> Config Class Initialized
INFO - 2021-12-27 15:44:11 --> Hooks Class Initialized
DEBUG - 2021-12-27 15:44:11 --> UTF-8 Support Enabled
INFO - 2021-12-27 15:44:11 --> Utf8 Class Initialized
INFO - 2021-12-27 15:44:11 --> URI Class Initialized
DEBUG - 2021-12-27 15:44:11 --> No URI present. Default controller set.
INFO - 2021-12-27 15:44:11 --> Router Class Initialized
INFO - 2021-12-27 15:44:11 --> Output Class Initialized
INFO - 2021-12-27 15:44:11 --> Security Class Initialized
DEBUG - 2021-12-27 15:44:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-27 15:44:11 --> Input Class Initialized
INFO - 2021-12-27 15:44:11 --> Language Class Initialized
INFO - 2021-12-27 15:44:11 --> Loader Class Initialized
INFO - 2021-12-27 15:44:11 --> Helper loaded: url_helper
INFO - 2021-12-27 15:44:11 --> Helper loaded: form_helper
INFO - 2021-12-27 15:44:11 --> Helper loaded: common_helper
INFO - 2021-12-27 15:44:11 --> Database Driver Class Initialized
DEBUG - 2021-12-27 15:44:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-27 15:44:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-27 15:44:11 --> Controller Class Initialized
INFO - 2021-12-27 15:44:11 --> Form Validation Class Initialized
DEBUG - 2021-12-27 15:44:11 --> Encrypt Class Initialized
DEBUG - 2021-12-27 15:44:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 15:44:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-27 15:44:11 --> Email Class Initialized
INFO - 2021-12-27 15:44:11 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-27 15:44:11 --> Calendar Class Initialized
INFO - 2021-12-27 15:44:11 --> Model "Login_model" initialized
INFO - 2021-12-27 15:44:11 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-27 15:44:11 --> Final output sent to browser
DEBUG - 2021-12-27 15:44:11 --> Total execution time: 0.0224
ERROR - 2021-12-27 21:23:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-27 21:23:10 --> Config Class Initialized
INFO - 2021-12-27 21:23:10 --> Hooks Class Initialized
DEBUG - 2021-12-27 21:23:10 --> UTF-8 Support Enabled
INFO - 2021-12-27 21:23:10 --> Utf8 Class Initialized
INFO - 2021-12-27 21:23:10 --> URI Class Initialized
DEBUG - 2021-12-27 21:23:10 --> No URI present. Default controller set.
INFO - 2021-12-27 21:23:10 --> Router Class Initialized
INFO - 2021-12-27 21:23:10 --> Output Class Initialized
INFO - 2021-12-27 21:23:10 --> Security Class Initialized
DEBUG - 2021-12-27 21:23:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-27 21:23:10 --> Input Class Initialized
INFO - 2021-12-27 21:23:10 --> Language Class Initialized
INFO - 2021-12-27 21:23:10 --> Loader Class Initialized
INFO - 2021-12-27 21:23:10 --> Helper loaded: url_helper
INFO - 2021-12-27 21:23:10 --> Helper loaded: form_helper
INFO - 2021-12-27 21:23:10 --> Helper loaded: common_helper
INFO - 2021-12-27 21:23:10 --> Database Driver Class Initialized
DEBUG - 2021-12-27 21:23:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-27 21:23:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-27 21:23:10 --> Controller Class Initialized
INFO - 2021-12-27 21:23:10 --> Form Validation Class Initialized
DEBUG - 2021-12-27 21:23:10 --> Encrypt Class Initialized
DEBUG - 2021-12-27 21:23:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 21:23:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-27 21:23:10 --> Email Class Initialized
INFO - 2021-12-27 21:23:10 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-27 21:23:10 --> Calendar Class Initialized
INFO - 2021-12-27 21:23:10 --> Model "Login_model" initialized
INFO - 2021-12-27 21:23:10 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-27 21:23:10 --> Final output sent to browser
DEBUG - 2021-12-27 21:23:10 --> Total execution time: 0.1252
