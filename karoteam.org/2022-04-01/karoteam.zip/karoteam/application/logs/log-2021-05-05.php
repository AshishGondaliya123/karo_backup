<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-05-05 15:29:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-05 15:29:05 --> Config Class Initialized
INFO - 2021-05-05 15:29:05 --> Hooks Class Initialized
DEBUG - 2021-05-05 15:29:05 --> UTF-8 Support Enabled
INFO - 2021-05-05 15:29:05 --> Utf8 Class Initialized
INFO - 2021-05-05 15:29:05 --> URI Class Initialized
DEBUG - 2021-05-05 15:29:05 --> No URI present. Default controller set.
INFO - 2021-05-05 15:29:05 --> Router Class Initialized
INFO - 2021-05-05 15:29:05 --> Output Class Initialized
INFO - 2021-05-05 15:29:05 --> Security Class Initialized
DEBUG - 2021-05-05 15:29:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-05 15:29:05 --> Input Class Initialized
INFO - 2021-05-05 15:29:05 --> Language Class Initialized
INFO - 2021-05-05 15:29:05 --> Loader Class Initialized
INFO - 2021-05-05 15:29:05 --> Helper loaded: url_helper
INFO - 2021-05-05 15:29:05 --> Helper loaded: form_helper
INFO - 2021-05-05 15:29:05 --> Helper loaded: common_helper
INFO - 2021-05-05 15:29:05 --> Database Driver Class Initialized
DEBUG - 2021-05-05 15:29:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-05 15:29:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-05 15:29:05 --> Controller Class Initialized
INFO - 2021-05-05 15:29:05 --> Form Validation Class Initialized
INFO - 2021-05-05 15:29:05 --> Encrypt Class Initialized
DEBUG - 2021-05-05 15:29:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-05-05 15:29:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-05-05 15:29:05 --> Email Class Initialized
INFO - 2021-05-05 15:29:05 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-05-05 15:29:05 --> Calendar Class Initialized
INFO - 2021-05-05 15:29:05 --> Model "Login_model" initialized
INFO - 2021-05-05 15:29:05 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\login/index.php
INFO - 2021-05-05 15:29:05 --> Final output sent to browser
DEBUG - 2021-05-05 15:29:05 --> Total execution time: 0.4829
ERROR - 2021-05-05 15:29:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-05 15:29:08 --> Config Class Initialized
INFO - 2021-05-05 15:29:08 --> Hooks Class Initialized
DEBUG - 2021-05-05 15:29:08 --> UTF-8 Support Enabled
INFO - 2021-05-05 15:29:08 --> Utf8 Class Initialized
INFO - 2021-05-05 15:29:08 --> URI Class Initialized
INFO - 2021-05-05 15:29:08 --> Router Class Initialized
INFO - 2021-05-05 15:29:08 --> Output Class Initialized
INFO - 2021-05-05 15:29:08 --> Security Class Initialized
DEBUG - 2021-05-05 15:29:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-05 15:29:08 --> Input Class Initialized
INFO - 2021-05-05 15:29:08 --> Language Class Initialized
INFO - 2021-05-05 15:29:08 --> Loader Class Initialized
INFO - 2021-05-05 15:29:08 --> Helper loaded: url_helper
INFO - 2021-05-05 15:29:08 --> Helper loaded: form_helper
INFO - 2021-05-05 15:29:08 --> Helper loaded: common_helper
INFO - 2021-05-05 15:29:08 --> Database Driver Class Initialized
DEBUG - 2021-05-05 15:29:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-05 15:29:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-05 15:29:08 --> Controller Class Initialized
INFO - 2021-05-05 15:29:08 --> Form Validation Class Initialized
INFO - 2021-05-05 15:29:08 --> Encrypt Class Initialized
DEBUG - 2021-05-05 15:29:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-05-05 15:29:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-05-05 15:29:08 --> Email Class Initialized
INFO - 2021-05-05 15:29:08 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-05-05 15:29:08 --> Calendar Class Initialized
INFO - 2021-05-05 15:29:08 --> Model "Login_model" initialized
INFO - 2021-05-05 15:29:09 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2021-05-05 15:29:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-05 15:29:09 --> Config Class Initialized
INFO - 2021-05-05 15:29:09 --> Hooks Class Initialized
DEBUG - 2021-05-05 15:29:09 --> UTF-8 Support Enabled
INFO - 2021-05-05 15:29:09 --> Utf8 Class Initialized
INFO - 2021-05-05 15:29:09 --> URI Class Initialized
INFO - 2021-05-05 15:29:09 --> Router Class Initialized
INFO - 2021-05-05 15:29:09 --> Output Class Initialized
INFO - 2021-05-05 15:29:09 --> Security Class Initialized
DEBUG - 2021-05-05 15:29:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-05 15:29:09 --> Input Class Initialized
INFO - 2021-05-05 15:29:09 --> Language Class Initialized
INFO - 2021-05-05 15:29:09 --> Loader Class Initialized
INFO - 2021-05-05 15:29:09 --> Helper loaded: url_helper
INFO - 2021-05-05 15:29:09 --> Helper loaded: form_helper
INFO - 2021-05-05 15:29:09 --> Helper loaded: common_helper
INFO - 2021-05-05 15:29:09 --> Database Driver Class Initialized
DEBUG - 2021-05-05 15:29:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-05 15:29:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-05 15:29:09 --> Controller Class Initialized
INFO - 2021-05-05 15:29:09 --> Form Validation Class Initialized
INFO - 2021-05-05 15:29:09 --> Encrypt Class Initialized
DEBUG - 2021-05-05 15:29:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-05-05 15:29:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-05-05 15:29:09 --> Email Class Initialized
INFO - 2021-05-05 15:29:09 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-05-05 15:29:09 --> Calendar Class Initialized
INFO - 2021-05-05 15:29:09 --> Model "Login_model" initialized
INFO - 2021-05-05 15:29:09 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\login/index.php
INFO - 2021-05-05 15:29:09 --> Final output sent to browser
DEBUG - 2021-05-05 15:29:09 --> Total execution time: 0.0570
ERROR - 2021-05-05 17:12:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-05 17:12:13 --> Config Class Initialized
INFO - 2021-05-05 17:12:13 --> Hooks Class Initialized
DEBUG - 2021-05-05 17:12:13 --> UTF-8 Support Enabled
INFO - 2021-05-05 17:12:13 --> Utf8 Class Initialized
INFO - 2021-05-05 17:12:13 --> URI Class Initialized
INFO - 2021-05-05 17:12:13 --> Router Class Initialized
INFO - 2021-05-05 17:12:13 --> Output Class Initialized
INFO - 2021-05-05 17:12:13 --> Security Class Initialized
DEBUG - 2021-05-05 17:12:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-05 17:12:13 --> Input Class Initialized
INFO - 2021-05-05 17:12:13 --> Language Class Initialized
INFO - 2021-05-05 17:12:13 --> Loader Class Initialized
INFO - 2021-05-05 17:12:13 --> Helper loaded: url_helper
INFO - 2021-05-05 17:12:13 --> Helper loaded: form_helper
INFO - 2021-05-05 17:12:13 --> Helper loaded: common_helper
INFO - 2021-05-05 17:12:13 --> Database Driver Class Initialized
DEBUG - 2021-05-05 17:12:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-05 17:12:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-05 17:12:13 --> Controller Class Initialized
INFO - 2021-05-05 17:12:13 --> Form Validation Class Initialized
INFO - 2021-05-05 17:12:13 --> Encrypt Class Initialized
DEBUG - 2021-05-05 17:12:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-05-05 17:12:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-05-05 17:12:13 --> Email Class Initialized
INFO - 2021-05-05 17:12:13 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-05-05 17:12:13 --> Calendar Class Initialized
INFO - 2021-05-05 17:12:13 --> Model "Login_model" initialized
INFO - 2021-05-05 17:12:13 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2021-05-05 17:12:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-05 17:12:14 --> Config Class Initialized
INFO - 2021-05-05 17:12:14 --> Hooks Class Initialized
DEBUG - 2021-05-05 17:12:14 --> UTF-8 Support Enabled
INFO - 2021-05-05 17:12:14 --> Utf8 Class Initialized
INFO - 2021-05-05 17:12:14 --> URI Class Initialized
INFO - 2021-05-05 17:12:14 --> Router Class Initialized
INFO - 2021-05-05 17:12:14 --> Output Class Initialized
INFO - 2021-05-05 17:12:14 --> Security Class Initialized
DEBUG - 2021-05-05 17:12:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-05 17:12:14 --> Input Class Initialized
INFO - 2021-05-05 17:12:14 --> Language Class Initialized
INFO - 2021-05-05 17:12:14 --> Loader Class Initialized
INFO - 2021-05-05 17:12:14 --> Helper loaded: url_helper
INFO - 2021-05-05 17:12:14 --> Helper loaded: form_helper
INFO - 2021-05-05 17:12:14 --> Helper loaded: common_helper
INFO - 2021-05-05 17:12:14 --> Database Driver Class Initialized
DEBUG - 2021-05-05 17:12:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-05 17:12:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-05 17:12:14 --> Controller Class Initialized
INFO - 2021-05-05 17:12:14 --> Form Validation Class Initialized
INFO - 2021-05-05 17:12:14 --> Encrypt Class Initialized
INFO - 2021-05-05 17:12:14 --> Model "Login_model" initialized
INFO - 2021-05-05 17:12:14 --> Model "Dashboard_model" initialized
INFO - 2021-05-05 17:12:14 --> Model "Case_model" initialized
INFO - 2021-05-05 17:12:18 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-05-05 17:12:30 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\dashboard/index.php
INFO - 2021-05-05 17:12:30 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-05-05 17:12:30 --> Final output sent to browser
DEBUG - 2021-05-05 17:12:30 --> Total execution time: 16.0858
ERROR - 2021-05-05 17:12:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-05 17:12:31 --> Config Class Initialized
INFO - 2021-05-05 17:12:31 --> Hooks Class Initialized
DEBUG - 2021-05-05 17:12:31 --> UTF-8 Support Enabled
INFO - 2021-05-05 17:12:31 --> Utf8 Class Initialized
INFO - 2021-05-05 17:12:31 --> URI Class Initialized
INFO - 2021-05-05 17:12:31 --> Router Class Initialized
INFO - 2021-05-05 17:12:31 --> Output Class Initialized
INFO - 2021-05-05 17:12:31 --> Security Class Initialized
DEBUG - 2021-05-05 17:12:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-05 17:12:31 --> Input Class Initialized
INFO - 2021-05-05 17:12:31 --> Language Class Initialized
ERROR - 2021-05-05 17:12:31 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-05-05 17:17:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-05 17:17:00 --> Config Class Initialized
INFO - 2021-05-05 17:17:00 --> Hooks Class Initialized
DEBUG - 2021-05-05 17:17:00 --> UTF-8 Support Enabled
INFO - 2021-05-05 17:17:00 --> Utf8 Class Initialized
INFO - 2021-05-05 17:17:00 --> URI Class Initialized
INFO - 2021-05-05 17:17:00 --> Router Class Initialized
INFO - 2021-05-05 17:17:00 --> Output Class Initialized
INFO - 2021-05-05 17:17:00 --> Security Class Initialized
DEBUG - 2021-05-05 17:17:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-05 17:17:00 --> Input Class Initialized
INFO - 2021-05-05 17:17:00 --> Language Class Initialized
INFO - 2021-05-05 17:17:00 --> Loader Class Initialized
INFO - 2021-05-05 17:17:00 --> Helper loaded: url_helper
INFO - 2021-05-05 17:17:00 --> Helper loaded: form_helper
INFO - 2021-05-05 17:17:00 --> Helper loaded: common_helper
INFO - 2021-05-05 17:17:00 --> Database Driver Class Initialized
DEBUG - 2021-05-05 17:17:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-05 17:17:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-05 17:17:00 --> Controller Class Initialized
INFO - 2021-05-05 17:17:00 --> Form Validation Class Initialized
INFO - 2021-05-05 17:17:00 --> Encrypt Class Initialized
INFO - 2021-05-05 17:17:00 --> Model "Login_model" initialized
INFO - 2021-05-05 17:17:00 --> Model "Dashboard_model" initialized
INFO - 2021-05-05 17:17:00 --> Model "Case_model" initialized
INFO - 2021-05-05 17:17:05 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-05-05 17:17:16 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\dashboard/index.php
INFO - 2021-05-05 17:17:16 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-05-05 17:17:16 --> Final output sent to browser
DEBUG - 2021-05-05 17:17:16 --> Total execution time: 15.4253
ERROR - 2021-05-05 17:17:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-05 17:17:16 --> Config Class Initialized
INFO - 2021-05-05 17:17:16 --> Hooks Class Initialized
DEBUG - 2021-05-05 17:17:16 --> UTF-8 Support Enabled
INFO - 2021-05-05 17:17:16 --> Utf8 Class Initialized
INFO - 2021-05-05 17:17:16 --> URI Class Initialized
INFO - 2021-05-05 17:17:16 --> Router Class Initialized
INFO - 2021-05-05 17:17:16 --> Output Class Initialized
INFO - 2021-05-05 17:17:16 --> Security Class Initialized
DEBUG - 2021-05-05 17:17:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-05 17:17:16 --> Input Class Initialized
INFO - 2021-05-05 17:17:16 --> Language Class Initialized
ERROR - 2021-05-05 17:17:16 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-05-05 17:18:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-05 17:18:13 --> Config Class Initialized
INFO - 2021-05-05 17:18:13 --> Hooks Class Initialized
DEBUG - 2021-05-05 17:18:13 --> UTF-8 Support Enabled
INFO - 2021-05-05 17:18:13 --> Utf8 Class Initialized
INFO - 2021-05-05 17:18:13 --> URI Class Initialized
INFO - 2021-05-05 17:18:13 --> Router Class Initialized
INFO - 2021-05-05 17:18:13 --> Output Class Initialized
INFO - 2021-05-05 17:18:13 --> Security Class Initialized
DEBUG - 2021-05-05 17:18:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-05 17:18:13 --> Input Class Initialized
INFO - 2021-05-05 17:18:13 --> Language Class Initialized
INFO - 2021-05-05 17:18:13 --> Loader Class Initialized
INFO - 2021-05-05 17:18:13 --> Helper loaded: url_helper
INFO - 2021-05-05 17:18:13 --> Helper loaded: form_helper
INFO - 2021-05-05 17:18:13 --> Helper loaded: common_helper
INFO - 2021-05-05 17:18:13 --> Database Driver Class Initialized
DEBUG - 2021-05-05 17:18:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-05 17:18:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-05 17:18:14 --> Controller Class Initialized
INFO - 2021-05-05 17:18:14 --> Form Validation Class Initialized
INFO - 2021-05-05 17:18:14 --> Encrypt Class Initialized
INFO - 2021-05-05 17:18:14 --> Model "Login_model" initialized
INFO - 2021-05-05 17:18:14 --> Model "Dashboard_model" initialized
INFO - 2021-05-05 17:18:14 --> Model "Case_model" initialized
INFO - 2021-05-05 17:18:19 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-05-05 17:18:30 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\dashboard/index.php
INFO - 2021-05-05 17:18:30 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-05-05 17:18:30 --> Final output sent to browser
DEBUG - 2021-05-05 17:18:30 --> Total execution time: 16.3905
ERROR - 2021-05-05 17:18:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-05 17:18:30 --> Config Class Initialized
INFO - 2021-05-05 17:18:30 --> Hooks Class Initialized
DEBUG - 2021-05-05 17:18:30 --> UTF-8 Support Enabled
INFO - 2021-05-05 17:18:30 --> Utf8 Class Initialized
INFO - 2021-05-05 17:18:30 --> URI Class Initialized
INFO - 2021-05-05 17:18:30 --> Router Class Initialized
INFO - 2021-05-05 17:18:30 --> Output Class Initialized
INFO - 2021-05-05 17:18:30 --> Security Class Initialized
DEBUG - 2021-05-05 17:18:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-05 17:18:30 --> Input Class Initialized
INFO - 2021-05-05 17:18:30 --> Language Class Initialized
ERROR - 2021-05-05 17:18:30 --> 404 Page Not Found: Karoclient/usersprofile
