<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-01-28 03:12:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-28 03:12:30 --> Config Class Initialized
INFO - 2022-01-28 03:12:30 --> Hooks Class Initialized
DEBUG - 2022-01-28 03:12:30 --> UTF-8 Support Enabled
INFO - 2022-01-28 03:12:30 --> Utf8 Class Initialized
INFO - 2022-01-28 03:12:30 --> URI Class Initialized
DEBUG - 2022-01-28 03:12:30 --> No URI present. Default controller set.
INFO - 2022-01-28 03:12:30 --> Router Class Initialized
INFO - 2022-01-28 03:12:30 --> Output Class Initialized
INFO - 2022-01-28 03:12:30 --> Security Class Initialized
DEBUG - 2022-01-28 03:12:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-28 03:12:30 --> Input Class Initialized
INFO - 2022-01-28 03:12:30 --> Language Class Initialized
INFO - 2022-01-28 03:12:30 --> Loader Class Initialized
INFO - 2022-01-28 03:12:30 --> Helper loaded: url_helper
INFO - 2022-01-28 03:12:30 --> Helper loaded: form_helper
INFO - 2022-01-28 03:12:30 --> Helper loaded: common_helper
INFO - 2022-01-28 03:12:30 --> Database Driver Class Initialized
DEBUG - 2022-01-28 03:12:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-28 03:12:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-28 03:12:30 --> Controller Class Initialized
INFO - 2022-01-28 03:12:30 --> Form Validation Class Initialized
DEBUG - 2022-01-28 03:12:30 --> Encrypt Class Initialized
DEBUG - 2022-01-28 03:12:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-28 03:12:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-28 03:12:30 --> Email Class Initialized
INFO - 2022-01-28 03:12:30 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-28 03:12:30 --> Calendar Class Initialized
INFO - 2022-01-28 03:12:30 --> Model "Login_model" initialized
INFO - 2022-01-28 03:12:30 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-28 03:12:30 --> Final output sent to browser
DEBUG - 2022-01-28 03:12:30 --> Total execution time: 0.0384
ERROR - 2022-01-28 08:42:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-28 08:42:40 --> Config Class Initialized
INFO - 2022-01-28 08:42:40 --> Hooks Class Initialized
DEBUG - 2022-01-28 08:42:40 --> UTF-8 Support Enabled
INFO - 2022-01-28 08:42:40 --> Utf8 Class Initialized
INFO - 2022-01-28 08:42:40 --> URI Class Initialized
DEBUG - 2022-01-28 08:42:40 --> No URI present. Default controller set.
INFO - 2022-01-28 08:42:40 --> Router Class Initialized
INFO - 2022-01-28 08:42:40 --> Output Class Initialized
INFO - 2022-01-28 08:42:40 --> Security Class Initialized
DEBUG - 2022-01-28 08:42:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-28 08:42:40 --> Input Class Initialized
INFO - 2022-01-28 08:42:40 --> Language Class Initialized
INFO - 2022-01-28 08:42:40 --> Loader Class Initialized
INFO - 2022-01-28 08:42:40 --> Helper loaded: url_helper
INFO - 2022-01-28 08:42:40 --> Helper loaded: form_helper
INFO - 2022-01-28 08:42:40 --> Helper loaded: common_helper
INFO - 2022-01-28 08:42:40 --> Database Driver Class Initialized
DEBUG - 2022-01-28 08:42:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-28 08:42:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-28 08:42:40 --> Controller Class Initialized
INFO - 2022-01-28 08:42:40 --> Form Validation Class Initialized
DEBUG - 2022-01-28 08:42:40 --> Encrypt Class Initialized
DEBUG - 2022-01-28 08:42:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-28 08:42:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-28 08:42:40 --> Email Class Initialized
INFO - 2022-01-28 08:42:40 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-28 08:42:40 --> Calendar Class Initialized
INFO - 2022-01-28 08:42:40 --> Model "Login_model" initialized
INFO - 2022-01-28 08:42:40 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-28 08:42:40 --> Final output sent to browser
DEBUG - 2022-01-28 08:42:40 --> Total execution time: 0.0303
ERROR - 2022-01-28 08:48:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-28 08:48:54 --> Config Class Initialized
INFO - 2022-01-28 08:48:54 --> Hooks Class Initialized
DEBUG - 2022-01-28 08:48:54 --> UTF-8 Support Enabled
INFO - 2022-01-28 08:48:54 --> Utf8 Class Initialized
INFO - 2022-01-28 08:48:54 --> URI Class Initialized
INFO - 2022-01-28 08:48:54 --> Router Class Initialized
INFO - 2022-01-28 08:48:54 --> Output Class Initialized
INFO - 2022-01-28 08:48:54 --> Security Class Initialized
DEBUG - 2022-01-28 08:48:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-28 08:48:54 --> Input Class Initialized
INFO - 2022-01-28 08:48:54 --> Language Class Initialized
ERROR - 2022-01-28 08:48:54 --> 404 Page Not Found: _profiler/phpinfo
ERROR - 2022-01-28 12:33:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-28 12:33:12 --> Config Class Initialized
INFO - 2022-01-28 12:33:12 --> Hooks Class Initialized
DEBUG - 2022-01-28 12:33:12 --> UTF-8 Support Enabled
INFO - 2022-01-28 12:33:12 --> Utf8 Class Initialized
INFO - 2022-01-28 12:33:12 --> URI Class Initialized
DEBUG - 2022-01-28 12:33:12 --> No URI present. Default controller set.
INFO - 2022-01-28 12:33:12 --> Router Class Initialized
INFO - 2022-01-28 12:33:12 --> Output Class Initialized
INFO - 2022-01-28 12:33:12 --> Security Class Initialized
DEBUG - 2022-01-28 12:33:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-28 12:33:12 --> Input Class Initialized
INFO - 2022-01-28 12:33:12 --> Language Class Initialized
INFO - 2022-01-28 12:33:12 --> Loader Class Initialized
INFO - 2022-01-28 12:33:12 --> Helper loaded: url_helper
INFO - 2022-01-28 12:33:12 --> Helper loaded: form_helper
INFO - 2022-01-28 12:33:12 --> Helper loaded: common_helper
INFO - 2022-01-28 12:33:12 --> Database Driver Class Initialized
DEBUG - 2022-01-28 12:33:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-28 12:33:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-28 12:33:12 --> Controller Class Initialized
INFO - 2022-01-28 12:33:12 --> Form Validation Class Initialized
DEBUG - 2022-01-28 12:33:12 --> Encrypt Class Initialized
DEBUG - 2022-01-28 12:33:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-28 12:33:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-28 12:33:12 --> Email Class Initialized
INFO - 2022-01-28 12:33:12 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-28 12:33:12 --> Calendar Class Initialized
INFO - 2022-01-28 12:33:12 --> Model "Login_model" initialized
INFO - 2022-01-28 12:33:12 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-28 12:33:12 --> Final output sent to browser
DEBUG - 2022-01-28 12:33:12 --> Total execution time: 0.0308
ERROR - 2022-01-28 14:17:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-28 14:17:57 --> Config Class Initialized
INFO - 2022-01-28 14:17:57 --> Hooks Class Initialized
DEBUG - 2022-01-28 14:17:57 --> UTF-8 Support Enabled
INFO - 2022-01-28 14:17:57 --> Utf8 Class Initialized
INFO - 2022-01-28 14:17:57 --> URI Class Initialized
DEBUG - 2022-01-28 14:17:57 --> No URI present. Default controller set.
INFO - 2022-01-28 14:17:57 --> Router Class Initialized
INFO - 2022-01-28 14:17:57 --> Output Class Initialized
INFO - 2022-01-28 14:17:57 --> Security Class Initialized
DEBUG - 2022-01-28 14:17:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-28 14:17:57 --> Input Class Initialized
INFO - 2022-01-28 14:17:57 --> Language Class Initialized
INFO - 2022-01-28 14:17:57 --> Loader Class Initialized
INFO - 2022-01-28 14:17:57 --> Helper loaded: url_helper
INFO - 2022-01-28 14:17:57 --> Helper loaded: form_helper
INFO - 2022-01-28 14:17:57 --> Helper loaded: common_helper
INFO - 2022-01-28 14:17:57 --> Database Driver Class Initialized
DEBUG - 2022-01-28 14:17:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-28 14:17:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-28 14:17:57 --> Controller Class Initialized
INFO - 2022-01-28 14:17:57 --> Form Validation Class Initialized
DEBUG - 2022-01-28 14:17:57 --> Encrypt Class Initialized
DEBUG - 2022-01-28 14:17:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-28 14:17:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-28 14:17:57 --> Email Class Initialized
INFO - 2022-01-28 14:17:57 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-28 14:17:57 --> Calendar Class Initialized
INFO - 2022-01-28 14:17:57 --> Model "Login_model" initialized
INFO - 2022-01-28 14:17:57 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-28 14:17:57 --> Final output sent to browser
DEBUG - 2022-01-28 14:17:57 --> Total execution time: 0.0384
ERROR - 2022-01-28 14:17:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-28 14:17:58 --> Config Class Initialized
INFO - 2022-01-28 14:17:58 --> Hooks Class Initialized
DEBUG - 2022-01-28 14:17:58 --> UTF-8 Support Enabled
INFO - 2022-01-28 14:17:58 --> Utf8 Class Initialized
INFO - 2022-01-28 14:17:58 --> URI Class Initialized
INFO - 2022-01-28 14:17:58 --> Router Class Initialized
INFO - 2022-01-28 14:17:58 --> Output Class Initialized
INFO - 2022-01-28 14:17:58 --> Security Class Initialized
DEBUG - 2022-01-28 14:17:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-28 14:17:58 --> Input Class Initialized
INFO - 2022-01-28 14:17:58 --> Language Class Initialized
ERROR - 2022-01-28 14:17:58 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2022-01-28 14:18:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-28 14:18:26 --> Config Class Initialized
INFO - 2022-01-28 14:18:26 --> Hooks Class Initialized
DEBUG - 2022-01-28 14:18:26 --> UTF-8 Support Enabled
INFO - 2022-01-28 14:18:26 --> Utf8 Class Initialized
INFO - 2022-01-28 14:18:26 --> URI Class Initialized
INFO - 2022-01-28 14:18:26 --> Router Class Initialized
INFO - 2022-01-28 14:18:26 --> Output Class Initialized
INFO - 2022-01-28 14:18:26 --> Security Class Initialized
DEBUG - 2022-01-28 14:18:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-28 14:18:26 --> Input Class Initialized
INFO - 2022-01-28 14:18:26 --> Language Class Initialized
INFO - 2022-01-28 14:18:26 --> Loader Class Initialized
INFO - 2022-01-28 14:18:26 --> Helper loaded: url_helper
INFO - 2022-01-28 14:18:26 --> Helper loaded: form_helper
INFO - 2022-01-28 14:18:26 --> Helper loaded: common_helper
INFO - 2022-01-28 14:18:26 --> Database Driver Class Initialized
DEBUG - 2022-01-28 14:18:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-28 14:18:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-28 14:18:26 --> Controller Class Initialized
INFO - 2022-01-28 14:18:26 --> Form Validation Class Initialized
DEBUG - 2022-01-28 14:18:26 --> Encrypt Class Initialized
DEBUG - 2022-01-28 14:18:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-28 14:18:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-28 14:18:26 --> Email Class Initialized
INFO - 2022-01-28 14:18:26 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-28 14:18:26 --> Calendar Class Initialized
INFO - 2022-01-28 14:18:26 --> Model "Login_model" initialized
ERROR - 2022-01-28 14:18:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-28 14:18:27 --> Config Class Initialized
INFO - 2022-01-28 14:18:27 --> Hooks Class Initialized
DEBUG - 2022-01-28 14:18:27 --> UTF-8 Support Enabled
INFO - 2022-01-28 14:18:27 --> Utf8 Class Initialized
INFO - 2022-01-28 14:18:27 --> URI Class Initialized
INFO - 2022-01-28 14:18:27 --> Router Class Initialized
INFO - 2022-01-28 14:18:27 --> Output Class Initialized
INFO - 2022-01-28 14:18:27 --> Security Class Initialized
DEBUG - 2022-01-28 14:18:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-28 14:18:27 --> Input Class Initialized
INFO - 2022-01-28 14:18:27 --> Language Class Initialized
INFO - 2022-01-28 14:18:27 --> Loader Class Initialized
INFO - 2022-01-28 14:18:27 --> Helper loaded: url_helper
INFO - 2022-01-28 14:18:27 --> Helper loaded: form_helper
INFO - 2022-01-28 14:18:27 --> Helper loaded: common_helper
INFO - 2022-01-28 14:18:27 --> Database Driver Class Initialized
DEBUG - 2022-01-28 14:18:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-28 14:18:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-28 14:18:27 --> Controller Class Initialized
INFO - 2022-01-28 14:18:27 --> Form Validation Class Initialized
DEBUG - 2022-01-28 14:18:27 --> Encrypt Class Initialized
DEBUG - 2022-01-28 14:18:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-28 14:18:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-28 14:18:27 --> Email Class Initialized
INFO - 2022-01-28 14:18:27 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-28 14:18:27 --> Calendar Class Initialized
INFO - 2022-01-28 14:18:27 --> Model "Login_model" initialized
ERROR - 2022-01-28 14:18:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-28 14:18:27 --> Config Class Initialized
INFO - 2022-01-28 14:18:27 --> Hooks Class Initialized
DEBUG - 2022-01-28 14:18:27 --> UTF-8 Support Enabled
INFO - 2022-01-28 14:18:27 --> Utf8 Class Initialized
INFO - 2022-01-28 14:18:27 --> URI Class Initialized
DEBUG - 2022-01-28 14:18:27 --> No URI present. Default controller set.
INFO - 2022-01-28 14:18:27 --> Router Class Initialized
INFO - 2022-01-28 14:18:27 --> Output Class Initialized
INFO - 2022-01-28 14:18:27 --> Security Class Initialized
DEBUG - 2022-01-28 14:18:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-28 14:18:27 --> Input Class Initialized
INFO - 2022-01-28 14:18:27 --> Language Class Initialized
INFO - 2022-01-28 14:18:27 --> Loader Class Initialized
INFO - 2022-01-28 14:18:27 --> Helper loaded: url_helper
INFO - 2022-01-28 14:18:27 --> Helper loaded: form_helper
INFO - 2022-01-28 14:18:27 --> Helper loaded: common_helper
INFO - 2022-01-28 14:18:27 --> Database Driver Class Initialized
DEBUG - 2022-01-28 14:18:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-28 14:18:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-28 14:18:27 --> Controller Class Initialized
INFO - 2022-01-28 14:18:27 --> Form Validation Class Initialized
DEBUG - 2022-01-28 14:18:27 --> Encrypt Class Initialized
DEBUG - 2022-01-28 14:18:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-28 14:18:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-28 14:18:27 --> Email Class Initialized
INFO - 2022-01-28 14:18:27 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-28 14:18:27 --> Calendar Class Initialized
INFO - 2022-01-28 14:18:27 --> Model "Login_model" initialized
INFO - 2022-01-28 14:18:27 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-28 14:18:27 --> Final output sent to browser
DEBUG - 2022-01-28 14:18:27 --> Total execution time: 0.0334
ERROR - 2022-01-28 14:18:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-28 14:18:28 --> Config Class Initialized
INFO - 2022-01-28 14:18:28 --> Hooks Class Initialized
DEBUG - 2022-01-28 14:18:28 --> UTF-8 Support Enabled
INFO - 2022-01-28 14:18:28 --> Utf8 Class Initialized
INFO - 2022-01-28 14:18:28 --> URI Class Initialized
INFO - 2022-01-28 14:18:28 --> Router Class Initialized
INFO - 2022-01-28 14:18:28 --> Output Class Initialized
INFO - 2022-01-28 14:18:28 --> Security Class Initialized
DEBUG - 2022-01-28 14:18:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-28 14:18:28 --> Input Class Initialized
INFO - 2022-01-28 14:18:28 --> Language Class Initialized
INFO - 2022-01-28 14:18:28 --> Loader Class Initialized
INFO - 2022-01-28 14:18:28 --> Helper loaded: url_helper
INFO - 2022-01-28 14:18:28 --> Helper loaded: form_helper
INFO - 2022-01-28 14:18:28 --> Helper loaded: common_helper
INFO - 2022-01-28 14:18:28 --> Database Driver Class Initialized
DEBUG - 2022-01-28 14:18:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-28 14:18:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-28 14:18:28 --> Controller Class Initialized
INFO - 2022-01-28 14:18:28 --> Form Validation Class Initialized
DEBUG - 2022-01-28 14:18:28 --> Encrypt Class Initialized
DEBUG - 2022-01-28 14:18:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-28 14:18:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-28 14:18:28 --> Email Class Initialized
INFO - 2022-01-28 14:18:28 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-28 14:18:28 --> Calendar Class Initialized
INFO - 2022-01-28 14:18:28 --> Model "Login_model" initialized
INFO - 2022-01-28 14:18:28 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-28 14:18:28 --> Final output sent to browser
DEBUG - 2022-01-28 14:18:28 --> Total execution time: 0.0329
ERROR - 2022-01-28 15:33:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-28 15:33:17 --> Config Class Initialized
INFO - 2022-01-28 15:33:17 --> Hooks Class Initialized
DEBUG - 2022-01-28 15:33:17 --> UTF-8 Support Enabled
INFO - 2022-01-28 15:33:17 --> Utf8 Class Initialized
INFO - 2022-01-28 15:33:17 --> URI Class Initialized
DEBUG - 2022-01-28 15:33:17 --> No URI present. Default controller set.
INFO - 2022-01-28 15:33:17 --> Router Class Initialized
INFO - 2022-01-28 15:33:17 --> Output Class Initialized
INFO - 2022-01-28 15:33:17 --> Security Class Initialized
DEBUG - 2022-01-28 15:33:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-28 15:33:17 --> Input Class Initialized
INFO - 2022-01-28 15:33:17 --> Language Class Initialized
INFO - 2022-01-28 15:33:17 --> Loader Class Initialized
INFO - 2022-01-28 15:33:17 --> Helper loaded: url_helper
INFO - 2022-01-28 15:33:17 --> Helper loaded: form_helper
INFO - 2022-01-28 15:33:17 --> Helper loaded: common_helper
INFO - 2022-01-28 15:33:17 --> Database Driver Class Initialized
DEBUG - 2022-01-28 15:33:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-28 15:33:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-28 15:33:17 --> Controller Class Initialized
INFO - 2022-01-28 15:33:17 --> Form Validation Class Initialized
DEBUG - 2022-01-28 15:33:17 --> Encrypt Class Initialized
DEBUG - 2022-01-28 15:33:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-28 15:33:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-28 15:33:17 --> Email Class Initialized
INFO - 2022-01-28 15:33:17 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-28 15:33:17 --> Calendar Class Initialized
INFO - 2022-01-28 15:33:17 --> Model "Login_model" initialized
INFO - 2022-01-28 15:33:17 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-28 15:33:17 --> Final output sent to browser
DEBUG - 2022-01-28 15:33:17 --> Total execution time: 0.0372
ERROR - 2022-01-28 19:33:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-28 19:33:23 --> Config Class Initialized
INFO - 2022-01-28 19:33:23 --> Hooks Class Initialized
DEBUG - 2022-01-28 19:33:23 --> UTF-8 Support Enabled
INFO - 2022-01-28 19:33:23 --> Utf8 Class Initialized
INFO - 2022-01-28 19:33:23 --> URI Class Initialized
DEBUG - 2022-01-28 19:33:23 --> No URI present. Default controller set.
INFO - 2022-01-28 19:33:23 --> Router Class Initialized
INFO - 2022-01-28 19:33:23 --> Output Class Initialized
INFO - 2022-01-28 19:33:23 --> Security Class Initialized
DEBUG - 2022-01-28 19:33:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-28 19:33:23 --> Input Class Initialized
INFO - 2022-01-28 19:33:23 --> Language Class Initialized
INFO - 2022-01-28 19:33:23 --> Loader Class Initialized
INFO - 2022-01-28 19:33:23 --> Helper loaded: url_helper
INFO - 2022-01-28 19:33:23 --> Helper loaded: form_helper
INFO - 2022-01-28 19:33:23 --> Helper loaded: common_helper
INFO - 2022-01-28 19:33:23 --> Database Driver Class Initialized
DEBUG - 2022-01-28 19:33:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-28 19:33:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-28 19:33:23 --> Controller Class Initialized
INFO - 2022-01-28 19:33:23 --> Form Validation Class Initialized
DEBUG - 2022-01-28 19:33:23 --> Encrypt Class Initialized
DEBUG - 2022-01-28 19:33:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-28 19:33:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-28 19:33:23 --> Email Class Initialized
INFO - 2022-01-28 19:33:23 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-28 19:33:23 --> Calendar Class Initialized
INFO - 2022-01-28 19:33:23 --> Model "Login_model" initialized
INFO - 2022-01-28 19:33:23 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-28 19:33:23 --> Final output sent to browser
DEBUG - 2022-01-28 19:33:23 --> Total execution time: 0.0262
ERROR - 2022-01-28 19:37:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-28 19:37:57 --> Config Class Initialized
INFO - 2022-01-28 19:37:57 --> Hooks Class Initialized
DEBUG - 2022-01-28 19:37:57 --> UTF-8 Support Enabled
INFO - 2022-01-28 19:37:57 --> Utf8 Class Initialized
INFO - 2022-01-28 19:37:57 --> URI Class Initialized
DEBUG - 2022-01-28 19:37:57 --> No URI present. Default controller set.
INFO - 2022-01-28 19:37:57 --> Router Class Initialized
INFO - 2022-01-28 19:37:57 --> Output Class Initialized
INFO - 2022-01-28 19:37:57 --> Security Class Initialized
DEBUG - 2022-01-28 19:37:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-28 19:37:57 --> Input Class Initialized
INFO - 2022-01-28 19:37:57 --> Language Class Initialized
INFO - 2022-01-28 19:37:57 --> Loader Class Initialized
INFO - 2022-01-28 19:37:57 --> Helper loaded: url_helper
INFO - 2022-01-28 19:37:57 --> Helper loaded: form_helper
INFO - 2022-01-28 19:37:57 --> Helper loaded: common_helper
INFO - 2022-01-28 19:37:57 --> Database Driver Class Initialized
DEBUG - 2022-01-28 19:37:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-28 19:37:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-28 19:37:57 --> Controller Class Initialized
INFO - 2022-01-28 19:37:57 --> Form Validation Class Initialized
DEBUG - 2022-01-28 19:37:57 --> Encrypt Class Initialized
DEBUG - 2022-01-28 19:37:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-28 19:37:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-28 19:37:57 --> Email Class Initialized
INFO - 2022-01-28 19:37:57 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-28 19:37:57 --> Calendar Class Initialized
INFO - 2022-01-28 19:37:57 --> Model "Login_model" initialized
INFO - 2022-01-28 19:37:57 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-28 19:37:57 --> Final output sent to browser
DEBUG - 2022-01-28 19:37:57 --> Total execution time: 0.0291
ERROR - 2022-01-28 21:06:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-28 21:06:55 --> Config Class Initialized
INFO - 2022-01-28 21:06:55 --> Hooks Class Initialized
DEBUG - 2022-01-28 21:06:55 --> UTF-8 Support Enabled
INFO - 2022-01-28 21:06:55 --> Utf8 Class Initialized
INFO - 2022-01-28 21:06:55 --> URI Class Initialized
DEBUG - 2022-01-28 21:06:55 --> No URI present. Default controller set.
INFO - 2022-01-28 21:06:55 --> Router Class Initialized
INFO - 2022-01-28 21:06:55 --> Output Class Initialized
INFO - 2022-01-28 21:06:55 --> Security Class Initialized
DEBUG - 2022-01-28 21:06:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-28 21:06:55 --> Input Class Initialized
INFO - 2022-01-28 21:06:55 --> Language Class Initialized
INFO - 2022-01-28 21:06:55 --> Loader Class Initialized
INFO - 2022-01-28 21:06:55 --> Helper loaded: url_helper
INFO - 2022-01-28 21:06:55 --> Helper loaded: form_helper
INFO - 2022-01-28 21:06:55 --> Helper loaded: common_helper
INFO - 2022-01-28 21:06:55 --> Database Driver Class Initialized
DEBUG - 2022-01-28 21:06:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-28 21:06:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-28 21:06:55 --> Controller Class Initialized
INFO - 2022-01-28 21:06:55 --> Form Validation Class Initialized
DEBUG - 2022-01-28 21:06:55 --> Encrypt Class Initialized
DEBUG - 2022-01-28 21:06:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-28 21:06:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-28 21:06:55 --> Email Class Initialized
INFO - 2022-01-28 21:06:55 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-28 21:06:55 --> Calendar Class Initialized
INFO - 2022-01-28 21:06:55 --> Model "Login_model" initialized
INFO - 2022-01-28 21:06:55 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-28 21:06:55 --> Final output sent to browser
DEBUG - 2022-01-28 21:06:55 --> Total execution time: 0.0273
ERROR - 2022-01-28 21:06:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-28 21:06:58 --> Config Class Initialized
INFO - 2022-01-28 21:06:58 --> Hooks Class Initialized
DEBUG - 2022-01-28 21:06:58 --> UTF-8 Support Enabled
INFO - 2022-01-28 21:06:58 --> Utf8 Class Initialized
INFO - 2022-01-28 21:06:58 --> URI Class Initialized
INFO - 2022-01-28 21:06:58 --> Router Class Initialized
INFO - 2022-01-28 21:06:58 --> Output Class Initialized
INFO - 2022-01-28 21:06:58 --> Security Class Initialized
DEBUG - 2022-01-28 21:06:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-28 21:06:58 --> Input Class Initialized
INFO - 2022-01-28 21:06:58 --> Language Class Initialized
INFO - 2022-01-28 21:06:58 --> Loader Class Initialized
INFO - 2022-01-28 21:06:58 --> Helper loaded: url_helper
INFO - 2022-01-28 21:06:58 --> Helper loaded: form_helper
INFO - 2022-01-28 21:06:58 --> Helper loaded: common_helper
INFO - 2022-01-28 21:06:58 --> Database Driver Class Initialized
DEBUG - 2022-01-28 21:06:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-28 21:06:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-28 21:06:58 --> Controller Class Initialized
INFO - 2022-01-28 21:06:58 --> Form Validation Class Initialized
DEBUG - 2022-01-28 21:06:58 --> Encrypt Class Initialized
DEBUG - 2022-01-28 21:06:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-28 21:06:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-28 21:06:58 --> Email Class Initialized
INFO - 2022-01-28 21:06:58 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-28 21:06:58 --> Calendar Class Initialized
INFO - 2022-01-28 21:06:58 --> Model "Login_model" initialized
INFO - 2022-01-28 21:06:58 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-28 21:06:58 --> Final output sent to browser
DEBUG - 2022-01-28 21:06:58 --> Total execution time: 0.0233
ERROR - 2022-01-28 21:06:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-28 21:06:58 --> Config Class Initialized
INFO - 2022-01-28 21:06:58 --> Hooks Class Initialized
DEBUG - 2022-01-28 21:06:58 --> UTF-8 Support Enabled
INFO - 2022-01-28 21:06:58 --> Utf8 Class Initialized
INFO - 2022-01-28 21:06:58 --> URI Class Initialized
DEBUG - 2022-01-28 21:06:58 --> No URI present. Default controller set.
INFO - 2022-01-28 21:06:58 --> Router Class Initialized
INFO - 2022-01-28 21:06:58 --> Output Class Initialized
INFO - 2022-01-28 21:06:58 --> Security Class Initialized
DEBUG - 2022-01-28 21:06:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-28 21:06:58 --> Input Class Initialized
INFO - 2022-01-28 21:06:58 --> Language Class Initialized
INFO - 2022-01-28 21:06:58 --> Loader Class Initialized
INFO - 2022-01-28 21:06:58 --> Helper loaded: url_helper
INFO - 2022-01-28 21:06:58 --> Helper loaded: form_helper
INFO - 2022-01-28 21:06:58 --> Helper loaded: common_helper
INFO - 2022-01-28 21:06:58 --> Database Driver Class Initialized
DEBUG - 2022-01-28 21:06:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-28 21:06:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-28 21:06:58 --> Controller Class Initialized
INFO - 2022-01-28 21:06:58 --> Form Validation Class Initialized
DEBUG - 2022-01-28 21:06:58 --> Encrypt Class Initialized
DEBUG - 2022-01-28 21:06:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-28 21:06:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-28 21:06:58 --> Email Class Initialized
INFO - 2022-01-28 21:06:58 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-28 21:06:58 --> Calendar Class Initialized
INFO - 2022-01-28 21:06:58 --> Model "Login_model" initialized
INFO - 2022-01-28 21:06:58 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-28 21:06:58 --> Final output sent to browser
DEBUG - 2022-01-28 21:06:58 --> Total execution time: 0.0219
ERROR - 2022-01-28 21:07:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-28 21:07:00 --> Config Class Initialized
INFO - 2022-01-28 21:07:00 --> Hooks Class Initialized
DEBUG - 2022-01-28 21:07:00 --> UTF-8 Support Enabled
INFO - 2022-01-28 21:07:00 --> Utf8 Class Initialized
INFO - 2022-01-28 21:07:00 --> URI Class Initialized
INFO - 2022-01-28 21:07:00 --> Router Class Initialized
INFO - 2022-01-28 21:07:00 --> Output Class Initialized
INFO - 2022-01-28 21:07:00 --> Security Class Initialized
DEBUG - 2022-01-28 21:07:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-28 21:07:00 --> Input Class Initialized
INFO - 2022-01-28 21:07:00 --> Language Class Initialized
INFO - 2022-01-28 21:07:00 --> Loader Class Initialized
INFO - 2022-01-28 21:07:00 --> Helper loaded: url_helper
INFO - 2022-01-28 21:07:00 --> Helper loaded: form_helper
INFO - 2022-01-28 21:07:00 --> Helper loaded: common_helper
INFO - 2022-01-28 21:07:00 --> Database Driver Class Initialized
DEBUG - 2022-01-28 21:07:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-28 21:07:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-28 21:07:00 --> Controller Class Initialized
INFO - 2022-01-28 21:07:00 --> Form Validation Class Initialized
DEBUG - 2022-01-28 21:07:00 --> Encrypt Class Initialized
DEBUG - 2022-01-28 21:07:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-28 21:07:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-28 21:07:00 --> Email Class Initialized
INFO - 2022-01-28 21:07:00 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-28 21:07:00 --> Calendar Class Initialized
INFO - 2022-01-28 21:07:00 --> Model "Login_model" initialized
ERROR - 2022-01-28 21:07:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-28 21:07:01 --> Config Class Initialized
INFO - 2022-01-28 21:07:01 --> Hooks Class Initialized
DEBUG - 2022-01-28 21:07:01 --> UTF-8 Support Enabled
INFO - 2022-01-28 21:07:01 --> Utf8 Class Initialized
INFO - 2022-01-28 21:07:01 --> URI Class Initialized
INFO - 2022-01-28 21:07:01 --> Router Class Initialized
INFO - 2022-01-28 21:07:01 --> Output Class Initialized
INFO - 2022-01-28 21:07:01 --> Security Class Initialized
DEBUG - 2022-01-28 21:07:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-28 21:07:01 --> Input Class Initialized
INFO - 2022-01-28 21:07:01 --> Language Class Initialized
INFO - 2022-01-28 21:07:01 --> Loader Class Initialized
INFO - 2022-01-28 21:07:01 --> Helper loaded: url_helper
INFO - 2022-01-28 21:07:02 --> Helper loaded: form_helper
INFO - 2022-01-28 21:07:02 --> Helper loaded: common_helper
INFO - 2022-01-28 21:07:02 --> Database Driver Class Initialized
DEBUG - 2022-01-28 21:07:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-28 21:07:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-28 21:07:02 --> Controller Class Initialized
INFO - 2022-01-28 21:07:02 --> Form Validation Class Initialized
DEBUG - 2022-01-28 21:07:02 --> Encrypt Class Initialized
DEBUG - 2022-01-28 21:07:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-28 21:07:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-28 21:07:02 --> Email Class Initialized
INFO - 2022-01-28 21:07:02 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-28 21:07:02 --> Calendar Class Initialized
INFO - 2022-01-28 21:07:02 --> Model "Login_model" initialized
INFO - 2022-01-28 21:07:02 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-28 21:07:02 --> Final output sent to browser
DEBUG - 2022-01-28 21:07:02 --> Total execution time: 0.0295
