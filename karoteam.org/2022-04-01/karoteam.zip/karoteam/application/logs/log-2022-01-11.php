<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-01-11 04:34:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-11 04:34:28 --> Config Class Initialized
INFO - 2022-01-11 04:34:28 --> Hooks Class Initialized
DEBUG - 2022-01-11 04:34:28 --> UTF-8 Support Enabled
INFO - 2022-01-11 04:34:28 --> Utf8 Class Initialized
INFO - 2022-01-11 04:34:28 --> URI Class Initialized
DEBUG - 2022-01-11 04:34:28 --> No URI present. Default controller set.
INFO - 2022-01-11 04:34:28 --> Router Class Initialized
INFO - 2022-01-11 04:34:28 --> Output Class Initialized
INFO - 2022-01-11 04:34:28 --> Security Class Initialized
DEBUG - 2022-01-11 04:34:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-11 04:34:28 --> Input Class Initialized
INFO - 2022-01-11 04:34:28 --> Language Class Initialized
INFO - 2022-01-11 04:34:28 --> Loader Class Initialized
INFO - 2022-01-11 04:34:28 --> Helper loaded: url_helper
INFO - 2022-01-11 04:34:28 --> Helper loaded: form_helper
INFO - 2022-01-11 04:34:28 --> Helper loaded: common_helper
INFO - 2022-01-11 04:34:28 --> Database Driver Class Initialized
DEBUG - 2022-01-11 04:34:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-11 04:34:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-11 04:34:28 --> Controller Class Initialized
INFO - 2022-01-11 04:34:28 --> Form Validation Class Initialized
DEBUG - 2022-01-11 04:34:28 --> Encrypt Class Initialized
DEBUG - 2022-01-11 04:34:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-11 04:34:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-11 04:34:28 --> Email Class Initialized
INFO - 2022-01-11 04:34:28 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-11 04:34:28 --> Calendar Class Initialized
INFO - 2022-01-11 04:34:28 --> Model "Login_model" initialized
INFO - 2022-01-11 04:34:28 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-11 04:34:28 --> Final output sent to browser
DEBUG - 2022-01-11 04:34:28 --> Total execution time: 0.0243
ERROR - 2022-01-11 07:13:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-11 07:13:42 --> Config Class Initialized
INFO - 2022-01-11 07:13:42 --> Hooks Class Initialized
DEBUG - 2022-01-11 07:13:42 --> UTF-8 Support Enabled
INFO - 2022-01-11 07:13:42 --> Utf8 Class Initialized
INFO - 2022-01-11 07:13:42 --> URI Class Initialized
DEBUG - 2022-01-11 07:13:42 --> No URI present. Default controller set.
INFO - 2022-01-11 07:13:42 --> Router Class Initialized
INFO - 2022-01-11 07:13:42 --> Output Class Initialized
INFO - 2022-01-11 07:13:42 --> Security Class Initialized
DEBUG - 2022-01-11 07:13:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-11 07:13:42 --> Input Class Initialized
INFO - 2022-01-11 07:13:42 --> Language Class Initialized
INFO - 2022-01-11 07:13:42 --> Loader Class Initialized
INFO - 2022-01-11 07:13:42 --> Helper loaded: url_helper
INFO - 2022-01-11 07:13:42 --> Helper loaded: form_helper
INFO - 2022-01-11 07:13:42 --> Helper loaded: common_helper
INFO - 2022-01-11 07:13:42 --> Database Driver Class Initialized
DEBUG - 2022-01-11 07:13:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-11 07:13:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-11 07:13:42 --> Controller Class Initialized
INFO - 2022-01-11 07:13:42 --> Form Validation Class Initialized
DEBUG - 2022-01-11 07:13:42 --> Encrypt Class Initialized
DEBUG - 2022-01-11 07:13:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-11 07:13:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-11 07:13:42 --> Email Class Initialized
INFO - 2022-01-11 07:13:42 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-11 07:13:42 --> Calendar Class Initialized
INFO - 2022-01-11 07:13:42 --> Model "Login_model" initialized
INFO - 2022-01-11 07:13:42 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-11 07:13:42 --> Final output sent to browser
DEBUG - 2022-01-11 07:13:42 --> Total execution time: 0.0378
ERROR - 2022-01-11 09:18:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-11 09:18:28 --> Config Class Initialized
INFO - 2022-01-11 09:18:28 --> Hooks Class Initialized
DEBUG - 2022-01-11 09:18:28 --> UTF-8 Support Enabled
INFO - 2022-01-11 09:18:28 --> Utf8 Class Initialized
INFO - 2022-01-11 09:18:28 --> URI Class Initialized
DEBUG - 2022-01-11 09:18:28 --> No URI present. Default controller set.
INFO - 2022-01-11 09:18:28 --> Router Class Initialized
INFO - 2022-01-11 09:18:28 --> Output Class Initialized
INFO - 2022-01-11 09:18:28 --> Security Class Initialized
DEBUG - 2022-01-11 09:18:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-11 09:18:28 --> Input Class Initialized
INFO - 2022-01-11 09:18:28 --> Language Class Initialized
INFO - 2022-01-11 09:18:28 --> Loader Class Initialized
INFO - 2022-01-11 09:18:28 --> Helper loaded: url_helper
INFO - 2022-01-11 09:18:28 --> Helper loaded: form_helper
INFO - 2022-01-11 09:18:28 --> Helper loaded: common_helper
INFO - 2022-01-11 09:18:28 --> Database Driver Class Initialized
DEBUG - 2022-01-11 09:18:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-11 09:18:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-11 09:18:28 --> Controller Class Initialized
INFO - 2022-01-11 09:18:28 --> Form Validation Class Initialized
DEBUG - 2022-01-11 09:18:28 --> Encrypt Class Initialized
DEBUG - 2022-01-11 09:18:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-11 09:18:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-11 09:18:28 --> Email Class Initialized
INFO - 2022-01-11 09:18:28 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-11 09:18:28 --> Calendar Class Initialized
INFO - 2022-01-11 09:18:28 --> Model "Login_model" initialized
INFO - 2022-01-11 09:18:28 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-11 09:18:28 --> Final output sent to browser
DEBUG - 2022-01-11 09:18:28 --> Total execution time: 0.0323
ERROR - 2022-01-11 14:16:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-11 14:16:26 --> Config Class Initialized
INFO - 2022-01-11 14:16:26 --> Hooks Class Initialized
DEBUG - 2022-01-11 14:16:26 --> UTF-8 Support Enabled
INFO - 2022-01-11 14:16:26 --> Utf8 Class Initialized
INFO - 2022-01-11 14:16:26 --> URI Class Initialized
DEBUG - 2022-01-11 14:16:26 --> No URI present. Default controller set.
INFO - 2022-01-11 14:16:26 --> Router Class Initialized
INFO - 2022-01-11 14:16:26 --> Output Class Initialized
INFO - 2022-01-11 14:16:26 --> Security Class Initialized
DEBUG - 2022-01-11 14:16:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-11 14:16:26 --> Input Class Initialized
INFO - 2022-01-11 14:16:26 --> Language Class Initialized
INFO - 2022-01-11 14:16:26 --> Loader Class Initialized
INFO - 2022-01-11 14:16:26 --> Helper loaded: url_helper
INFO - 2022-01-11 14:16:26 --> Helper loaded: form_helper
INFO - 2022-01-11 14:16:26 --> Helper loaded: common_helper
INFO - 2022-01-11 14:16:26 --> Database Driver Class Initialized
DEBUG - 2022-01-11 14:16:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-11 14:16:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-11 14:16:26 --> Controller Class Initialized
INFO - 2022-01-11 14:16:26 --> Form Validation Class Initialized
DEBUG - 2022-01-11 14:16:26 --> Encrypt Class Initialized
DEBUG - 2022-01-11 14:16:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-11 14:16:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-11 14:16:26 --> Email Class Initialized
INFO - 2022-01-11 14:16:26 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-11 14:16:26 --> Calendar Class Initialized
INFO - 2022-01-11 14:16:26 --> Model "Login_model" initialized
INFO - 2022-01-11 14:16:26 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-11 14:16:26 --> Final output sent to browser
DEBUG - 2022-01-11 14:16:26 --> Total execution time: 0.0258
ERROR - 2022-01-11 14:16:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-11 14:16:30 --> Config Class Initialized
INFO - 2022-01-11 14:16:30 --> Hooks Class Initialized
DEBUG - 2022-01-11 14:16:30 --> UTF-8 Support Enabled
INFO - 2022-01-11 14:16:30 --> Utf8 Class Initialized
INFO - 2022-01-11 14:16:30 --> URI Class Initialized
INFO - 2022-01-11 14:16:30 --> Router Class Initialized
INFO - 2022-01-11 14:16:30 --> Output Class Initialized
INFO - 2022-01-11 14:16:30 --> Security Class Initialized
DEBUG - 2022-01-11 14:16:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-11 14:16:30 --> Input Class Initialized
INFO - 2022-01-11 14:16:30 --> Language Class Initialized
ERROR - 2022-01-11 14:16:30 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2022-01-11 14:17:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-11 14:17:47 --> Config Class Initialized
INFO - 2022-01-11 14:17:47 --> Hooks Class Initialized
DEBUG - 2022-01-11 14:17:47 --> UTF-8 Support Enabled
INFO - 2022-01-11 14:17:47 --> Utf8 Class Initialized
INFO - 2022-01-11 14:17:47 --> URI Class Initialized
DEBUG - 2022-01-11 14:17:47 --> No URI present. Default controller set.
INFO - 2022-01-11 14:17:47 --> Router Class Initialized
INFO - 2022-01-11 14:17:47 --> Output Class Initialized
INFO - 2022-01-11 14:17:47 --> Security Class Initialized
DEBUG - 2022-01-11 14:17:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-11 14:17:47 --> Input Class Initialized
INFO - 2022-01-11 14:17:47 --> Language Class Initialized
INFO - 2022-01-11 14:17:47 --> Loader Class Initialized
INFO - 2022-01-11 14:17:47 --> Helper loaded: url_helper
INFO - 2022-01-11 14:17:47 --> Helper loaded: form_helper
INFO - 2022-01-11 14:17:47 --> Helper loaded: common_helper
INFO - 2022-01-11 14:17:47 --> Database Driver Class Initialized
DEBUG - 2022-01-11 14:17:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-11 14:17:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-11 14:17:47 --> Controller Class Initialized
INFO - 2022-01-11 14:17:47 --> Form Validation Class Initialized
DEBUG - 2022-01-11 14:17:47 --> Encrypt Class Initialized
DEBUG - 2022-01-11 14:17:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-11 14:17:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-11 14:17:47 --> Email Class Initialized
INFO - 2022-01-11 14:17:47 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-11 14:17:47 --> Calendar Class Initialized
INFO - 2022-01-11 14:17:47 --> Model "Login_model" initialized
INFO - 2022-01-11 14:17:47 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-11 14:17:47 --> Final output sent to browser
DEBUG - 2022-01-11 14:17:47 --> Total execution time: 0.0374
ERROR - 2022-01-11 14:17:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-11 14:17:48 --> Config Class Initialized
INFO - 2022-01-11 14:17:48 --> Hooks Class Initialized
DEBUG - 2022-01-11 14:17:48 --> UTF-8 Support Enabled
INFO - 2022-01-11 14:17:48 --> Utf8 Class Initialized
INFO - 2022-01-11 14:17:48 --> URI Class Initialized
INFO - 2022-01-11 14:17:48 --> Router Class Initialized
INFO - 2022-01-11 14:17:48 --> Output Class Initialized
INFO - 2022-01-11 14:17:48 --> Security Class Initialized
DEBUG - 2022-01-11 14:17:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-11 14:17:48 --> Input Class Initialized
INFO - 2022-01-11 14:17:48 --> Language Class Initialized
INFO - 2022-01-11 14:17:48 --> Loader Class Initialized
INFO - 2022-01-11 14:17:48 --> Helper loaded: url_helper
INFO - 2022-01-11 14:17:48 --> Helper loaded: form_helper
INFO - 2022-01-11 14:17:48 --> Helper loaded: common_helper
INFO - 2022-01-11 14:17:48 --> Database Driver Class Initialized
DEBUG - 2022-01-11 14:17:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-11 14:17:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-11 14:17:48 --> Controller Class Initialized
INFO - 2022-01-11 14:17:48 --> Form Validation Class Initialized
DEBUG - 2022-01-11 14:17:48 --> Encrypt Class Initialized
DEBUG - 2022-01-11 14:17:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-11 14:17:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-11 14:17:48 --> Email Class Initialized
INFO - 2022-01-11 14:17:48 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-11 14:17:48 --> Calendar Class Initialized
INFO - 2022-01-11 14:17:48 --> Model "Login_model" initialized
ERROR - 2022-01-11 14:17:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-11 14:17:48 --> Config Class Initialized
INFO - 2022-01-11 14:17:48 --> Hooks Class Initialized
DEBUG - 2022-01-11 14:17:48 --> UTF-8 Support Enabled
INFO - 2022-01-11 14:17:48 --> Utf8 Class Initialized
INFO - 2022-01-11 14:17:48 --> URI Class Initialized
INFO - 2022-01-11 14:17:48 --> Router Class Initialized
INFO - 2022-01-11 14:17:48 --> Output Class Initialized
INFO - 2022-01-11 14:17:48 --> Security Class Initialized
DEBUG - 2022-01-11 14:17:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-11 14:17:48 --> Input Class Initialized
INFO - 2022-01-11 14:17:48 --> Language Class Initialized
INFO - 2022-01-11 14:17:48 --> Loader Class Initialized
INFO - 2022-01-11 14:17:48 --> Helper loaded: url_helper
INFO - 2022-01-11 14:17:48 --> Helper loaded: form_helper
INFO - 2022-01-11 14:17:48 --> Helper loaded: common_helper
INFO - 2022-01-11 14:17:48 --> Database Driver Class Initialized
DEBUG - 2022-01-11 14:17:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-11 14:17:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-11 14:17:48 --> Controller Class Initialized
INFO - 2022-01-11 14:17:48 --> Form Validation Class Initialized
DEBUG - 2022-01-11 14:17:48 --> Encrypt Class Initialized
DEBUG - 2022-01-11 14:17:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-11 14:17:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-11 14:17:48 --> Email Class Initialized
INFO - 2022-01-11 14:17:48 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-11 14:17:48 --> Calendar Class Initialized
INFO - 2022-01-11 14:17:48 --> Model "Login_model" initialized
ERROR - 2022-01-11 14:17:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-11 14:17:49 --> Config Class Initialized
INFO - 2022-01-11 14:17:49 --> Hooks Class Initialized
DEBUG - 2022-01-11 14:17:49 --> UTF-8 Support Enabled
INFO - 2022-01-11 14:17:49 --> Utf8 Class Initialized
INFO - 2022-01-11 14:17:49 --> URI Class Initialized
INFO - 2022-01-11 14:17:49 --> Router Class Initialized
INFO - 2022-01-11 14:17:49 --> Output Class Initialized
INFO - 2022-01-11 14:17:49 --> Security Class Initialized
DEBUG - 2022-01-11 14:17:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-11 14:17:49 --> Input Class Initialized
INFO - 2022-01-11 14:17:49 --> Language Class Initialized
INFO - 2022-01-11 14:17:49 --> Loader Class Initialized
INFO - 2022-01-11 14:17:49 --> Helper loaded: url_helper
INFO - 2022-01-11 14:17:49 --> Helper loaded: form_helper
INFO - 2022-01-11 14:17:49 --> Helper loaded: common_helper
INFO - 2022-01-11 14:17:49 --> Database Driver Class Initialized
DEBUG - 2022-01-11 14:17:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-11 14:17:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-11 14:17:49 --> Controller Class Initialized
INFO - 2022-01-11 14:17:49 --> Form Validation Class Initialized
DEBUG - 2022-01-11 14:17:49 --> Encrypt Class Initialized
DEBUG - 2022-01-11 14:17:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-11 14:17:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-11 14:17:49 --> Email Class Initialized
INFO - 2022-01-11 14:17:49 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-11 14:17:49 --> Calendar Class Initialized
INFO - 2022-01-11 14:17:49 --> Model "Login_model" initialized
INFO - 2022-01-11 14:17:49 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-11 14:17:49 --> Final output sent to browser
DEBUG - 2022-01-11 14:17:49 --> Total execution time: 0.0249
ERROR - 2022-01-11 15:46:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-11 15:46:59 --> Config Class Initialized
INFO - 2022-01-11 15:46:59 --> Hooks Class Initialized
DEBUG - 2022-01-11 15:46:59 --> UTF-8 Support Enabled
INFO - 2022-01-11 15:46:59 --> Utf8 Class Initialized
INFO - 2022-01-11 15:46:59 --> URI Class Initialized
DEBUG - 2022-01-11 15:46:59 --> No URI present. Default controller set.
INFO - 2022-01-11 15:46:59 --> Router Class Initialized
INFO - 2022-01-11 15:46:59 --> Output Class Initialized
INFO - 2022-01-11 15:46:59 --> Security Class Initialized
DEBUG - 2022-01-11 15:46:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-11 15:46:59 --> Input Class Initialized
INFO - 2022-01-11 15:46:59 --> Language Class Initialized
INFO - 2022-01-11 15:46:59 --> Loader Class Initialized
INFO - 2022-01-11 15:46:59 --> Helper loaded: url_helper
INFO - 2022-01-11 15:46:59 --> Helper loaded: form_helper
INFO - 2022-01-11 15:46:59 --> Helper loaded: common_helper
INFO - 2022-01-11 15:46:59 --> Database Driver Class Initialized
DEBUG - 2022-01-11 15:46:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-11 15:46:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-11 15:46:59 --> Controller Class Initialized
INFO - 2022-01-11 15:46:59 --> Form Validation Class Initialized
DEBUG - 2022-01-11 15:46:59 --> Encrypt Class Initialized
DEBUG - 2022-01-11 15:46:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-11 15:46:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-11 15:46:59 --> Email Class Initialized
INFO - 2022-01-11 15:46:59 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-11 15:46:59 --> Calendar Class Initialized
INFO - 2022-01-11 15:46:59 --> Model "Login_model" initialized
INFO - 2022-01-11 15:46:59 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-11 15:46:59 --> Final output sent to browser
DEBUG - 2022-01-11 15:46:59 --> Total execution time: 0.0232
ERROR - 2022-01-11 23:09:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-11 23:09:32 --> Config Class Initialized
INFO - 2022-01-11 23:09:32 --> Hooks Class Initialized
DEBUG - 2022-01-11 23:09:32 --> UTF-8 Support Enabled
INFO - 2022-01-11 23:09:32 --> Utf8 Class Initialized
INFO - 2022-01-11 23:09:32 --> URI Class Initialized
DEBUG - 2022-01-11 23:09:32 --> No URI present. Default controller set.
INFO - 2022-01-11 23:09:32 --> Router Class Initialized
INFO - 2022-01-11 23:09:32 --> Output Class Initialized
INFO - 2022-01-11 23:09:32 --> Security Class Initialized
DEBUG - 2022-01-11 23:09:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-11 23:09:32 --> Input Class Initialized
INFO - 2022-01-11 23:09:32 --> Language Class Initialized
INFO - 2022-01-11 23:09:32 --> Loader Class Initialized
INFO - 2022-01-11 23:09:32 --> Helper loaded: url_helper
INFO - 2022-01-11 23:09:32 --> Helper loaded: form_helper
INFO - 2022-01-11 23:09:32 --> Helper loaded: common_helper
INFO - 2022-01-11 23:09:32 --> Database Driver Class Initialized
DEBUG - 2022-01-11 23:09:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-11 23:09:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-11 23:09:32 --> Controller Class Initialized
INFO - 2022-01-11 23:09:32 --> Form Validation Class Initialized
DEBUG - 2022-01-11 23:09:32 --> Encrypt Class Initialized
DEBUG - 2022-01-11 23:09:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-11 23:09:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-11 23:09:32 --> Email Class Initialized
INFO - 2022-01-11 23:09:32 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-11 23:09:32 --> Calendar Class Initialized
INFO - 2022-01-11 23:09:32 --> Model "Login_model" initialized
INFO - 2022-01-11 23:09:32 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-11 23:09:32 --> Final output sent to browser
DEBUG - 2022-01-11 23:09:32 --> Total execution time: 0.0513
