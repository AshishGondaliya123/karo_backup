<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-10-05 05:00:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-05 05:00:43 --> Config Class Initialized
INFO - 2021-10-05 05:00:43 --> Hooks Class Initialized
DEBUG - 2021-10-05 05:00:43 --> UTF-8 Support Enabled
INFO - 2021-10-05 05:00:43 --> Utf8 Class Initialized
INFO - 2021-10-05 05:00:43 --> URI Class Initialized
INFO - 2021-10-05 05:00:43 --> Router Class Initialized
INFO - 2021-10-05 05:00:43 --> Output Class Initialized
INFO - 2021-10-05 05:00:43 --> Security Class Initialized
DEBUG - 2021-10-05 05:00:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-05 05:00:43 --> Input Class Initialized
INFO - 2021-10-05 05:00:43 --> Language Class Initialized
ERROR - 2021-10-05 05:00:43 --> 404 Page Not Found: Wp-content/index
ERROR - 2021-10-05 12:03:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-05 12:03:48 --> Config Class Initialized
INFO - 2021-10-05 12:03:48 --> Hooks Class Initialized
DEBUG - 2021-10-05 12:03:48 --> UTF-8 Support Enabled
INFO - 2021-10-05 12:03:48 --> Utf8 Class Initialized
INFO - 2021-10-05 12:03:48 --> URI Class Initialized
DEBUG - 2021-10-05 12:03:48 --> No URI present. Default controller set.
INFO - 2021-10-05 12:03:48 --> Router Class Initialized
INFO - 2021-10-05 12:03:48 --> Output Class Initialized
INFO - 2021-10-05 12:03:48 --> Security Class Initialized
DEBUG - 2021-10-05 12:03:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-05 12:03:48 --> Input Class Initialized
INFO - 2021-10-05 12:03:48 --> Language Class Initialized
INFO - 2021-10-05 12:03:48 --> Loader Class Initialized
INFO - 2021-10-05 12:03:48 --> Helper loaded: url_helper
INFO - 2021-10-05 12:03:48 --> Helper loaded: form_helper
INFO - 2021-10-05 12:03:48 --> Helper loaded: common_helper
INFO - 2021-10-05 12:03:48 --> Database Driver Class Initialized
DEBUG - 2021-10-05 12:03:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-05 12:03:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-05 12:03:48 --> Controller Class Initialized
INFO - 2021-10-05 12:03:48 --> Form Validation Class Initialized
DEBUG - 2021-10-05 12:03:48 --> Encrypt Class Initialized
DEBUG - 2021-10-05 12:03:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-10-05 12:03:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-10-05 12:03:48 --> Email Class Initialized
INFO - 2021-10-05 12:03:48 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-10-05 12:03:48 --> Calendar Class Initialized
INFO - 2021-10-05 12:03:48 --> Model "Login_model" initialized
INFO - 2021-10-05 12:03:48 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-10-05 12:03:48 --> Final output sent to browser
DEBUG - 2021-10-05 12:03:48 --> Total execution time: 0.0558
ERROR - 2021-10-05 12:03:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-05 12:03:49 --> Config Class Initialized
INFO - 2021-10-05 12:03:49 --> Hooks Class Initialized
DEBUG - 2021-10-05 12:03:49 --> UTF-8 Support Enabled
INFO - 2021-10-05 12:03:49 --> Utf8 Class Initialized
INFO - 2021-10-05 12:03:49 --> URI Class Initialized
DEBUG - 2021-10-05 12:03:49 --> No URI present. Default controller set.
INFO - 2021-10-05 12:03:49 --> Router Class Initialized
INFO - 2021-10-05 12:03:49 --> Output Class Initialized
INFO - 2021-10-05 12:03:49 --> Security Class Initialized
DEBUG - 2021-10-05 12:03:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-05 12:03:49 --> Input Class Initialized
INFO - 2021-10-05 12:03:49 --> Language Class Initialized
INFO - 2021-10-05 12:03:49 --> Loader Class Initialized
INFO - 2021-10-05 12:03:49 --> Helper loaded: url_helper
INFO - 2021-10-05 12:03:49 --> Helper loaded: form_helper
INFO - 2021-10-05 12:03:49 --> Helper loaded: common_helper
INFO - 2021-10-05 12:03:49 --> Database Driver Class Initialized
DEBUG - 2021-10-05 12:03:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-05 12:03:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-05 12:03:49 --> Controller Class Initialized
INFO - 2021-10-05 12:03:49 --> Form Validation Class Initialized
DEBUG - 2021-10-05 12:03:49 --> Encrypt Class Initialized
DEBUG - 2021-10-05 12:03:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-10-05 12:03:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-10-05 12:03:49 --> Email Class Initialized
INFO - 2021-10-05 12:03:49 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-10-05 12:03:49 --> Calendar Class Initialized
INFO - 2021-10-05 12:03:49 --> Model "Login_model" initialized
INFO - 2021-10-05 12:03:49 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-10-05 12:03:49 --> Final output sent to browser
DEBUG - 2021-10-05 12:03:49 --> Total execution time: 0.0278
ERROR - 2021-10-05 12:03:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-05 12:03:49 --> Config Class Initialized
INFO - 2021-10-05 12:03:49 --> Hooks Class Initialized
DEBUG - 2021-10-05 12:03:49 --> UTF-8 Support Enabled
INFO - 2021-10-05 12:03:49 --> Utf8 Class Initialized
INFO - 2021-10-05 12:03:49 --> URI Class Initialized
INFO - 2021-10-05 12:03:49 --> Router Class Initialized
INFO - 2021-10-05 12:03:49 --> Output Class Initialized
INFO - 2021-10-05 12:03:49 --> Security Class Initialized
DEBUG - 2021-10-05 12:03:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-05 12:03:49 --> Input Class Initialized
INFO - 2021-10-05 12:03:49 --> Language Class Initialized
ERROR - 2021-10-05 12:03:49 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
ERROR - 2021-10-05 12:03:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-05 12:03:50 --> Config Class Initialized
INFO - 2021-10-05 12:03:50 --> Hooks Class Initialized
DEBUG - 2021-10-05 12:03:50 --> UTF-8 Support Enabled
INFO - 2021-10-05 12:03:50 --> Utf8 Class Initialized
INFO - 2021-10-05 12:03:50 --> URI Class Initialized
DEBUG - 2021-10-05 12:03:50 --> No URI present. Default controller set.
INFO - 2021-10-05 12:03:50 --> Router Class Initialized
INFO - 2021-10-05 12:03:50 --> Output Class Initialized
INFO - 2021-10-05 12:03:50 --> Security Class Initialized
DEBUG - 2021-10-05 12:03:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-05 12:03:50 --> Input Class Initialized
INFO - 2021-10-05 12:03:50 --> Language Class Initialized
INFO - 2021-10-05 12:03:50 --> Loader Class Initialized
INFO - 2021-10-05 12:03:50 --> Helper loaded: url_helper
INFO - 2021-10-05 12:03:50 --> Helper loaded: form_helper
INFO - 2021-10-05 12:03:50 --> Helper loaded: common_helper
INFO - 2021-10-05 12:03:50 --> Database Driver Class Initialized
DEBUG - 2021-10-05 12:03:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-05 12:03:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-05 12:03:50 --> Controller Class Initialized
INFO - 2021-10-05 12:03:50 --> Form Validation Class Initialized
DEBUG - 2021-10-05 12:03:50 --> Encrypt Class Initialized
DEBUG - 2021-10-05 12:03:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-10-05 12:03:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-10-05 12:03:50 --> Email Class Initialized
INFO - 2021-10-05 12:03:50 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-10-05 12:03:50 --> Calendar Class Initialized
INFO - 2021-10-05 12:03:50 --> Model "Login_model" initialized
INFO - 2021-10-05 12:03:50 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-10-05 12:03:50 --> Final output sent to browser
DEBUG - 2021-10-05 12:03:50 --> Total execution time: 0.0245
ERROR - 2021-10-05 12:03:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-05 12:03:50 --> Config Class Initialized
INFO - 2021-10-05 12:03:50 --> Hooks Class Initialized
DEBUG - 2021-10-05 12:03:50 --> UTF-8 Support Enabled
INFO - 2021-10-05 12:03:50 --> Utf8 Class Initialized
INFO - 2021-10-05 12:03:50 --> URI Class Initialized
INFO - 2021-10-05 12:03:50 --> Router Class Initialized
INFO - 2021-10-05 12:03:50 --> Output Class Initialized
INFO - 2021-10-05 12:03:50 --> Security Class Initialized
DEBUG - 2021-10-05 12:03:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-05 12:03:50 --> Input Class Initialized
INFO - 2021-10-05 12:03:50 --> Language Class Initialized
ERROR - 2021-10-05 12:03:50 --> 404 Page Not Found: Blog/wp-includes
ERROR - 2021-10-05 12:03:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-05 12:03:50 --> Config Class Initialized
INFO - 2021-10-05 12:03:50 --> Hooks Class Initialized
DEBUG - 2021-10-05 12:03:50 --> UTF-8 Support Enabled
INFO - 2021-10-05 12:03:50 --> Utf8 Class Initialized
INFO - 2021-10-05 12:03:50 --> URI Class Initialized
INFO - 2021-10-05 12:03:50 --> Router Class Initialized
INFO - 2021-10-05 12:03:50 --> Output Class Initialized
INFO - 2021-10-05 12:03:50 --> Security Class Initialized
DEBUG - 2021-10-05 12:03:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-05 12:03:50 --> Input Class Initialized
INFO - 2021-10-05 12:03:50 --> Language Class Initialized
ERROR - 2021-10-05 12:03:50 --> 404 Page Not Found: Web/wp-includes
ERROR - 2021-10-05 12:03:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-05 12:03:51 --> Config Class Initialized
INFO - 2021-10-05 12:03:51 --> Hooks Class Initialized
DEBUG - 2021-10-05 12:03:51 --> UTF-8 Support Enabled
INFO - 2021-10-05 12:03:51 --> Utf8 Class Initialized
INFO - 2021-10-05 12:03:51 --> URI Class Initialized
INFO - 2021-10-05 12:03:51 --> Router Class Initialized
INFO - 2021-10-05 12:03:51 --> Output Class Initialized
INFO - 2021-10-05 12:03:51 --> Security Class Initialized
DEBUG - 2021-10-05 12:03:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-05 12:03:51 --> Input Class Initialized
INFO - 2021-10-05 12:03:51 --> Language Class Initialized
ERROR - 2021-10-05 12:03:51 --> 404 Page Not Found: Wordpress/wp-includes
ERROR - 2021-10-05 12:03:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-05 12:03:51 --> Config Class Initialized
INFO - 2021-10-05 12:03:51 --> Hooks Class Initialized
DEBUG - 2021-10-05 12:03:51 --> UTF-8 Support Enabled
INFO - 2021-10-05 12:03:51 --> Utf8 Class Initialized
INFO - 2021-10-05 12:03:51 --> URI Class Initialized
INFO - 2021-10-05 12:03:51 --> Router Class Initialized
INFO - 2021-10-05 12:03:51 --> Output Class Initialized
INFO - 2021-10-05 12:03:51 --> Security Class Initialized
DEBUG - 2021-10-05 12:03:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-05 12:03:51 --> Input Class Initialized
INFO - 2021-10-05 12:03:51 --> Language Class Initialized
ERROR - 2021-10-05 12:03:51 --> 404 Page Not Found: Website/wp-includes
ERROR - 2021-10-05 12:03:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-05 12:03:52 --> Config Class Initialized
INFO - 2021-10-05 12:03:52 --> Hooks Class Initialized
DEBUG - 2021-10-05 12:03:52 --> UTF-8 Support Enabled
INFO - 2021-10-05 12:03:52 --> Utf8 Class Initialized
INFO - 2021-10-05 12:03:52 --> URI Class Initialized
INFO - 2021-10-05 12:03:52 --> Router Class Initialized
INFO - 2021-10-05 12:03:52 --> Output Class Initialized
INFO - 2021-10-05 12:03:52 --> Security Class Initialized
DEBUG - 2021-10-05 12:03:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-05 12:03:52 --> Input Class Initialized
INFO - 2021-10-05 12:03:52 --> Language Class Initialized
ERROR - 2021-10-05 12:03:52 --> 404 Page Not Found: Wp/wp-includes
ERROR - 2021-10-05 12:03:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-05 12:03:52 --> Config Class Initialized
INFO - 2021-10-05 12:03:52 --> Hooks Class Initialized
DEBUG - 2021-10-05 12:03:52 --> UTF-8 Support Enabled
INFO - 2021-10-05 12:03:52 --> Utf8 Class Initialized
INFO - 2021-10-05 12:03:52 --> URI Class Initialized
INFO - 2021-10-05 12:03:52 --> Router Class Initialized
INFO - 2021-10-05 12:03:52 --> Output Class Initialized
INFO - 2021-10-05 12:03:52 --> Security Class Initialized
DEBUG - 2021-10-05 12:03:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-05 12:03:52 --> Input Class Initialized
INFO - 2021-10-05 12:03:52 --> Language Class Initialized
ERROR - 2021-10-05 12:03:52 --> 404 Page Not Found: News/wp-includes
ERROR - 2021-10-05 12:03:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-05 12:03:52 --> Config Class Initialized
INFO - 2021-10-05 12:03:52 --> Hooks Class Initialized
DEBUG - 2021-10-05 12:03:52 --> UTF-8 Support Enabled
INFO - 2021-10-05 12:03:52 --> Utf8 Class Initialized
INFO - 2021-10-05 12:03:52 --> URI Class Initialized
INFO - 2021-10-05 12:03:52 --> Router Class Initialized
INFO - 2021-10-05 12:03:52 --> Output Class Initialized
INFO - 2021-10-05 12:03:52 --> Security Class Initialized
DEBUG - 2021-10-05 12:03:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-05 12:03:52 --> Input Class Initialized
INFO - 2021-10-05 12:03:52 --> Language Class Initialized
ERROR - 2021-10-05 12:03:52 --> 404 Page Not Found: 2018/wp-includes
ERROR - 2021-10-05 12:03:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-05 12:03:53 --> Config Class Initialized
INFO - 2021-10-05 12:03:53 --> Hooks Class Initialized
DEBUG - 2021-10-05 12:03:53 --> UTF-8 Support Enabled
INFO - 2021-10-05 12:03:53 --> Utf8 Class Initialized
INFO - 2021-10-05 12:03:53 --> URI Class Initialized
INFO - 2021-10-05 12:03:53 --> Router Class Initialized
INFO - 2021-10-05 12:03:53 --> Output Class Initialized
INFO - 2021-10-05 12:03:53 --> Security Class Initialized
DEBUG - 2021-10-05 12:03:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-05 12:03:53 --> Input Class Initialized
INFO - 2021-10-05 12:03:53 --> Language Class Initialized
ERROR - 2021-10-05 12:03:53 --> 404 Page Not Found: 2019/wp-includes
ERROR - 2021-10-05 12:03:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-05 12:03:53 --> Config Class Initialized
INFO - 2021-10-05 12:03:53 --> Hooks Class Initialized
DEBUG - 2021-10-05 12:03:53 --> UTF-8 Support Enabled
INFO - 2021-10-05 12:03:53 --> Utf8 Class Initialized
INFO - 2021-10-05 12:03:53 --> URI Class Initialized
INFO - 2021-10-05 12:03:53 --> Router Class Initialized
INFO - 2021-10-05 12:03:53 --> Output Class Initialized
INFO - 2021-10-05 12:03:53 --> Security Class Initialized
DEBUG - 2021-10-05 12:03:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-05 12:03:53 --> Input Class Initialized
INFO - 2021-10-05 12:03:53 --> Language Class Initialized
ERROR - 2021-10-05 12:03:53 --> 404 Page Not Found: Shop/wp-includes
ERROR - 2021-10-05 12:03:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-05 12:03:53 --> Config Class Initialized
INFO - 2021-10-05 12:03:53 --> Hooks Class Initialized
DEBUG - 2021-10-05 12:03:53 --> UTF-8 Support Enabled
INFO - 2021-10-05 12:03:53 --> Utf8 Class Initialized
INFO - 2021-10-05 12:03:53 --> URI Class Initialized
INFO - 2021-10-05 12:03:53 --> Router Class Initialized
INFO - 2021-10-05 12:03:53 --> Output Class Initialized
INFO - 2021-10-05 12:03:53 --> Security Class Initialized
DEBUG - 2021-10-05 12:03:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-05 12:03:53 --> Input Class Initialized
INFO - 2021-10-05 12:03:53 --> Language Class Initialized
ERROR - 2021-10-05 12:03:53 --> 404 Page Not Found: Wp1/wp-includes
ERROR - 2021-10-05 12:03:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-05 12:03:54 --> Config Class Initialized
INFO - 2021-10-05 12:03:54 --> Hooks Class Initialized
DEBUG - 2021-10-05 12:03:54 --> UTF-8 Support Enabled
INFO - 2021-10-05 12:03:54 --> Utf8 Class Initialized
INFO - 2021-10-05 12:03:54 --> URI Class Initialized
INFO - 2021-10-05 12:03:54 --> Router Class Initialized
INFO - 2021-10-05 12:03:54 --> Output Class Initialized
INFO - 2021-10-05 12:03:54 --> Security Class Initialized
DEBUG - 2021-10-05 12:03:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-05 12:03:54 --> Input Class Initialized
INFO - 2021-10-05 12:03:54 --> Language Class Initialized
ERROR - 2021-10-05 12:03:54 --> 404 Page Not Found: Test/wp-includes
ERROR - 2021-10-05 12:03:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-05 12:03:54 --> Config Class Initialized
INFO - 2021-10-05 12:03:54 --> Hooks Class Initialized
DEBUG - 2021-10-05 12:03:54 --> UTF-8 Support Enabled
INFO - 2021-10-05 12:03:54 --> Utf8 Class Initialized
INFO - 2021-10-05 12:03:54 --> URI Class Initialized
INFO - 2021-10-05 12:03:54 --> Router Class Initialized
INFO - 2021-10-05 12:03:54 --> Output Class Initialized
INFO - 2021-10-05 12:03:54 --> Security Class Initialized
DEBUG - 2021-10-05 12:03:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-05 12:03:54 --> Input Class Initialized
INFO - 2021-10-05 12:03:54 --> Language Class Initialized
ERROR - 2021-10-05 12:03:54 --> 404 Page Not Found: Media/wp-includes
ERROR - 2021-10-05 12:03:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-05 12:03:54 --> Config Class Initialized
INFO - 2021-10-05 12:03:54 --> Hooks Class Initialized
DEBUG - 2021-10-05 12:03:54 --> UTF-8 Support Enabled
INFO - 2021-10-05 12:03:54 --> Utf8 Class Initialized
INFO - 2021-10-05 12:03:54 --> URI Class Initialized
INFO - 2021-10-05 12:03:54 --> Router Class Initialized
INFO - 2021-10-05 12:03:54 --> Output Class Initialized
INFO - 2021-10-05 12:03:54 --> Security Class Initialized
DEBUG - 2021-10-05 12:03:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-05 12:03:54 --> Input Class Initialized
INFO - 2021-10-05 12:03:54 --> Language Class Initialized
ERROR - 2021-10-05 12:03:54 --> 404 Page Not Found: Wp2/wp-includes
ERROR - 2021-10-05 12:03:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-05 12:03:55 --> Config Class Initialized
INFO - 2021-10-05 12:03:55 --> Hooks Class Initialized
DEBUG - 2021-10-05 12:03:55 --> UTF-8 Support Enabled
INFO - 2021-10-05 12:03:55 --> Utf8 Class Initialized
INFO - 2021-10-05 12:03:55 --> URI Class Initialized
INFO - 2021-10-05 12:03:55 --> Router Class Initialized
INFO - 2021-10-05 12:03:55 --> Output Class Initialized
INFO - 2021-10-05 12:03:55 --> Security Class Initialized
DEBUG - 2021-10-05 12:03:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-05 12:03:55 --> Input Class Initialized
INFO - 2021-10-05 12:03:55 --> Language Class Initialized
ERROR - 2021-10-05 12:03:55 --> 404 Page Not Found: Site/wp-includes
ERROR - 2021-10-05 12:03:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-05 12:03:55 --> Config Class Initialized
INFO - 2021-10-05 12:03:55 --> Hooks Class Initialized
DEBUG - 2021-10-05 12:03:55 --> UTF-8 Support Enabled
INFO - 2021-10-05 12:03:55 --> Utf8 Class Initialized
INFO - 2021-10-05 12:03:55 --> URI Class Initialized
INFO - 2021-10-05 12:03:55 --> Router Class Initialized
INFO - 2021-10-05 12:03:55 --> Output Class Initialized
INFO - 2021-10-05 12:03:55 --> Security Class Initialized
DEBUG - 2021-10-05 12:03:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-05 12:03:55 --> Input Class Initialized
INFO - 2021-10-05 12:03:55 --> Language Class Initialized
ERROR - 2021-10-05 12:03:55 --> 404 Page Not Found: Cms/wp-includes
ERROR - 2021-10-05 12:03:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-05 12:03:55 --> Config Class Initialized
INFO - 2021-10-05 12:03:55 --> Hooks Class Initialized
DEBUG - 2021-10-05 12:03:55 --> UTF-8 Support Enabled
INFO - 2021-10-05 12:03:55 --> Utf8 Class Initialized
INFO - 2021-10-05 12:03:55 --> URI Class Initialized
INFO - 2021-10-05 12:03:55 --> Router Class Initialized
INFO - 2021-10-05 12:03:55 --> Output Class Initialized
INFO - 2021-10-05 12:03:55 --> Security Class Initialized
DEBUG - 2021-10-05 12:03:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-05 12:03:55 --> Input Class Initialized
INFO - 2021-10-05 12:03:55 --> Language Class Initialized
ERROR - 2021-10-05 12:03:55 --> 404 Page Not Found: Sito/wp-includes
ERROR - 2021-10-05 14:50:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-05 14:50:07 --> Config Class Initialized
INFO - 2021-10-05 14:50:07 --> Hooks Class Initialized
DEBUG - 2021-10-05 14:50:07 --> UTF-8 Support Enabled
INFO - 2021-10-05 14:50:07 --> Utf8 Class Initialized
INFO - 2021-10-05 14:50:07 --> URI Class Initialized
DEBUG - 2021-10-05 14:50:07 --> No URI present. Default controller set.
INFO - 2021-10-05 14:50:07 --> Router Class Initialized
INFO - 2021-10-05 14:50:07 --> Output Class Initialized
INFO - 2021-10-05 14:50:07 --> Security Class Initialized
DEBUG - 2021-10-05 14:50:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-05 14:50:07 --> Input Class Initialized
INFO - 2021-10-05 14:50:07 --> Language Class Initialized
INFO - 2021-10-05 14:50:07 --> Loader Class Initialized
INFO - 2021-10-05 14:50:07 --> Helper loaded: url_helper
INFO - 2021-10-05 14:50:07 --> Helper loaded: form_helper
INFO - 2021-10-05 14:50:07 --> Helper loaded: common_helper
INFO - 2021-10-05 14:50:07 --> Database Driver Class Initialized
DEBUG - 2021-10-05 14:50:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-05 14:50:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-05 14:50:07 --> Controller Class Initialized
INFO - 2021-10-05 14:50:07 --> Form Validation Class Initialized
DEBUG - 2021-10-05 14:50:07 --> Encrypt Class Initialized
DEBUG - 2021-10-05 14:50:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-10-05 14:50:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-10-05 14:50:07 --> Email Class Initialized
INFO - 2021-10-05 14:50:07 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-10-05 14:50:07 --> Calendar Class Initialized
INFO - 2021-10-05 14:50:07 --> Model "Login_model" initialized
INFO - 2021-10-05 14:50:07 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-10-05 14:50:07 --> Final output sent to browser
DEBUG - 2021-10-05 14:50:07 --> Total execution time: 0.0441
ERROR - 2021-10-05 14:50:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-05 14:50:07 --> Config Class Initialized
INFO - 2021-10-05 14:50:07 --> Hooks Class Initialized
DEBUG - 2021-10-05 14:50:07 --> UTF-8 Support Enabled
INFO - 2021-10-05 14:50:07 --> Utf8 Class Initialized
INFO - 2021-10-05 14:50:07 --> URI Class Initialized
DEBUG - 2021-10-05 14:50:07 --> No URI present. Default controller set.
INFO - 2021-10-05 14:50:07 --> Router Class Initialized
INFO - 2021-10-05 14:50:07 --> Output Class Initialized
INFO - 2021-10-05 14:50:07 --> Security Class Initialized
DEBUG - 2021-10-05 14:50:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-05 14:50:07 --> Input Class Initialized
INFO - 2021-10-05 14:50:07 --> Language Class Initialized
INFO - 2021-10-05 14:50:07 --> Loader Class Initialized
INFO - 2021-10-05 14:50:07 --> Helper loaded: url_helper
INFO - 2021-10-05 14:50:07 --> Helper loaded: form_helper
INFO - 2021-10-05 14:50:07 --> Helper loaded: common_helper
INFO - 2021-10-05 14:50:07 --> Database Driver Class Initialized
DEBUG - 2021-10-05 14:50:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-05 14:50:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-05 14:50:07 --> Controller Class Initialized
INFO - 2021-10-05 14:50:07 --> Form Validation Class Initialized
DEBUG - 2021-10-05 14:50:07 --> Encrypt Class Initialized
DEBUG - 2021-10-05 14:50:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-10-05 14:50:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-10-05 14:50:07 --> Email Class Initialized
INFO - 2021-10-05 14:50:07 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-10-05 14:50:07 --> Calendar Class Initialized
INFO - 2021-10-05 14:50:07 --> Model "Login_model" initialized
INFO - 2021-10-05 14:50:07 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-10-05 14:50:07 --> Final output sent to browser
DEBUG - 2021-10-05 14:50:07 --> Total execution time: 0.0292
ERROR - 2021-10-05 14:50:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-05 14:50:08 --> Config Class Initialized
INFO - 2021-10-05 14:50:08 --> Hooks Class Initialized
DEBUG - 2021-10-05 14:50:08 --> UTF-8 Support Enabled
INFO - 2021-10-05 14:50:08 --> Utf8 Class Initialized
INFO - 2021-10-05 14:50:08 --> URI Class Initialized
INFO - 2021-10-05 14:50:08 --> Router Class Initialized
INFO - 2021-10-05 14:50:08 --> Output Class Initialized
INFO - 2021-10-05 14:50:08 --> Security Class Initialized
DEBUG - 2021-10-05 14:50:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-05 14:50:08 --> Input Class Initialized
INFO - 2021-10-05 14:50:08 --> Language Class Initialized
ERROR - 2021-10-05 14:50:08 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
ERROR - 2021-10-05 14:50:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-05 14:50:08 --> Config Class Initialized
INFO - 2021-10-05 14:50:08 --> Hooks Class Initialized
DEBUG - 2021-10-05 14:50:08 --> UTF-8 Support Enabled
INFO - 2021-10-05 14:50:08 --> Utf8 Class Initialized
INFO - 2021-10-05 14:50:08 --> URI Class Initialized
DEBUG - 2021-10-05 14:50:08 --> No URI present. Default controller set.
INFO - 2021-10-05 14:50:08 --> Router Class Initialized
INFO - 2021-10-05 14:50:08 --> Output Class Initialized
INFO - 2021-10-05 14:50:08 --> Security Class Initialized
DEBUG - 2021-10-05 14:50:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-05 14:50:08 --> Input Class Initialized
INFO - 2021-10-05 14:50:08 --> Language Class Initialized
INFO - 2021-10-05 14:50:08 --> Loader Class Initialized
INFO - 2021-10-05 14:50:08 --> Helper loaded: url_helper
INFO - 2021-10-05 14:50:08 --> Helper loaded: form_helper
INFO - 2021-10-05 14:50:08 --> Helper loaded: common_helper
INFO - 2021-10-05 14:50:08 --> Database Driver Class Initialized
DEBUG - 2021-10-05 14:50:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-05 14:50:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-05 14:50:08 --> Controller Class Initialized
INFO - 2021-10-05 14:50:08 --> Form Validation Class Initialized
DEBUG - 2021-10-05 14:50:08 --> Encrypt Class Initialized
DEBUG - 2021-10-05 14:50:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-10-05 14:50:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-10-05 14:50:08 --> Email Class Initialized
INFO - 2021-10-05 14:50:08 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-10-05 14:50:08 --> Calendar Class Initialized
INFO - 2021-10-05 14:50:08 --> Model "Login_model" initialized
INFO - 2021-10-05 14:50:08 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-10-05 14:50:08 --> Final output sent to browser
DEBUG - 2021-10-05 14:50:08 --> Total execution time: 0.0245
ERROR - 2021-10-05 14:50:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-05 14:50:08 --> Config Class Initialized
INFO - 2021-10-05 14:50:08 --> Hooks Class Initialized
DEBUG - 2021-10-05 14:50:08 --> UTF-8 Support Enabled
INFO - 2021-10-05 14:50:08 --> Utf8 Class Initialized
INFO - 2021-10-05 14:50:08 --> URI Class Initialized
INFO - 2021-10-05 14:50:08 --> Router Class Initialized
INFO - 2021-10-05 14:50:08 --> Output Class Initialized
INFO - 2021-10-05 14:50:08 --> Security Class Initialized
DEBUG - 2021-10-05 14:50:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-05 14:50:08 --> Input Class Initialized
INFO - 2021-10-05 14:50:08 --> Language Class Initialized
ERROR - 2021-10-05 14:50:08 --> 404 Page Not Found: Blog/wp-includes
ERROR - 2021-10-05 14:50:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-05 14:50:09 --> Config Class Initialized
INFO - 2021-10-05 14:50:09 --> Hooks Class Initialized
DEBUG - 2021-10-05 14:50:09 --> UTF-8 Support Enabled
INFO - 2021-10-05 14:50:09 --> Utf8 Class Initialized
INFO - 2021-10-05 14:50:09 --> URI Class Initialized
INFO - 2021-10-05 14:50:09 --> Router Class Initialized
INFO - 2021-10-05 14:50:09 --> Output Class Initialized
INFO - 2021-10-05 14:50:09 --> Security Class Initialized
DEBUG - 2021-10-05 14:50:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-05 14:50:09 --> Input Class Initialized
INFO - 2021-10-05 14:50:09 --> Language Class Initialized
ERROR - 2021-10-05 14:50:09 --> 404 Page Not Found: Web/wp-includes
ERROR - 2021-10-05 14:50:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-05 14:50:09 --> Config Class Initialized
INFO - 2021-10-05 14:50:09 --> Hooks Class Initialized
DEBUG - 2021-10-05 14:50:09 --> UTF-8 Support Enabled
INFO - 2021-10-05 14:50:09 --> Utf8 Class Initialized
INFO - 2021-10-05 14:50:09 --> URI Class Initialized
INFO - 2021-10-05 14:50:09 --> Router Class Initialized
INFO - 2021-10-05 14:50:09 --> Output Class Initialized
INFO - 2021-10-05 14:50:09 --> Security Class Initialized
DEBUG - 2021-10-05 14:50:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-05 14:50:09 --> Input Class Initialized
INFO - 2021-10-05 14:50:09 --> Language Class Initialized
ERROR - 2021-10-05 14:50:09 --> 404 Page Not Found: Wordpress/wp-includes
ERROR - 2021-10-05 14:50:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-05 14:50:10 --> Config Class Initialized
INFO - 2021-10-05 14:50:10 --> Hooks Class Initialized
DEBUG - 2021-10-05 14:50:10 --> UTF-8 Support Enabled
INFO - 2021-10-05 14:50:10 --> Utf8 Class Initialized
INFO - 2021-10-05 14:50:10 --> URI Class Initialized
INFO - 2021-10-05 14:50:10 --> Router Class Initialized
INFO - 2021-10-05 14:50:10 --> Output Class Initialized
INFO - 2021-10-05 14:50:10 --> Security Class Initialized
DEBUG - 2021-10-05 14:50:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-05 14:50:10 --> Input Class Initialized
INFO - 2021-10-05 14:50:10 --> Language Class Initialized
ERROR - 2021-10-05 14:50:10 --> 404 Page Not Found: Website/wp-includes
ERROR - 2021-10-05 14:50:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-05 14:50:10 --> Config Class Initialized
INFO - 2021-10-05 14:50:10 --> Hooks Class Initialized
DEBUG - 2021-10-05 14:50:10 --> UTF-8 Support Enabled
INFO - 2021-10-05 14:50:10 --> Utf8 Class Initialized
INFO - 2021-10-05 14:50:10 --> URI Class Initialized
INFO - 2021-10-05 14:50:10 --> Router Class Initialized
INFO - 2021-10-05 14:50:10 --> Output Class Initialized
INFO - 2021-10-05 14:50:10 --> Security Class Initialized
DEBUG - 2021-10-05 14:50:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-05 14:50:10 --> Input Class Initialized
INFO - 2021-10-05 14:50:10 --> Language Class Initialized
ERROR - 2021-10-05 14:50:10 --> 404 Page Not Found: Wp/wp-includes
ERROR - 2021-10-05 14:50:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-05 14:50:10 --> Config Class Initialized
INFO - 2021-10-05 14:50:10 --> Hooks Class Initialized
DEBUG - 2021-10-05 14:50:10 --> UTF-8 Support Enabled
INFO - 2021-10-05 14:50:10 --> Utf8 Class Initialized
INFO - 2021-10-05 14:50:10 --> URI Class Initialized
INFO - 2021-10-05 14:50:10 --> Router Class Initialized
INFO - 2021-10-05 14:50:10 --> Output Class Initialized
INFO - 2021-10-05 14:50:10 --> Security Class Initialized
DEBUG - 2021-10-05 14:50:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-05 14:50:10 --> Input Class Initialized
INFO - 2021-10-05 14:50:10 --> Language Class Initialized
ERROR - 2021-10-05 14:50:10 --> 404 Page Not Found: News/wp-includes
ERROR - 2021-10-05 14:50:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-05 14:50:11 --> Config Class Initialized
INFO - 2021-10-05 14:50:11 --> Hooks Class Initialized
DEBUG - 2021-10-05 14:50:11 --> UTF-8 Support Enabled
INFO - 2021-10-05 14:50:11 --> Utf8 Class Initialized
INFO - 2021-10-05 14:50:11 --> URI Class Initialized
INFO - 2021-10-05 14:50:11 --> Router Class Initialized
INFO - 2021-10-05 14:50:11 --> Output Class Initialized
INFO - 2021-10-05 14:50:11 --> Security Class Initialized
DEBUG - 2021-10-05 14:50:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-05 14:50:11 --> Input Class Initialized
INFO - 2021-10-05 14:50:11 --> Language Class Initialized
ERROR - 2021-10-05 14:50:11 --> 404 Page Not Found: 2018/wp-includes
ERROR - 2021-10-05 14:50:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-05 14:50:11 --> Config Class Initialized
INFO - 2021-10-05 14:50:11 --> Hooks Class Initialized
DEBUG - 2021-10-05 14:50:11 --> UTF-8 Support Enabled
INFO - 2021-10-05 14:50:11 --> Utf8 Class Initialized
INFO - 2021-10-05 14:50:11 --> URI Class Initialized
INFO - 2021-10-05 14:50:11 --> Router Class Initialized
INFO - 2021-10-05 14:50:11 --> Output Class Initialized
INFO - 2021-10-05 14:50:11 --> Security Class Initialized
DEBUG - 2021-10-05 14:50:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-05 14:50:11 --> Input Class Initialized
INFO - 2021-10-05 14:50:11 --> Language Class Initialized
ERROR - 2021-10-05 14:50:11 --> 404 Page Not Found: 2019/wp-includes
ERROR - 2021-10-05 14:50:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-05 14:50:12 --> Config Class Initialized
INFO - 2021-10-05 14:50:12 --> Hooks Class Initialized
DEBUG - 2021-10-05 14:50:12 --> UTF-8 Support Enabled
INFO - 2021-10-05 14:50:12 --> Utf8 Class Initialized
INFO - 2021-10-05 14:50:12 --> URI Class Initialized
INFO - 2021-10-05 14:50:12 --> Router Class Initialized
INFO - 2021-10-05 14:50:12 --> Output Class Initialized
INFO - 2021-10-05 14:50:12 --> Security Class Initialized
DEBUG - 2021-10-05 14:50:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-05 14:50:12 --> Input Class Initialized
INFO - 2021-10-05 14:50:12 --> Language Class Initialized
ERROR - 2021-10-05 14:50:12 --> 404 Page Not Found: Shop/wp-includes
ERROR - 2021-10-05 14:50:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-05 14:50:12 --> Config Class Initialized
INFO - 2021-10-05 14:50:12 --> Hooks Class Initialized
DEBUG - 2021-10-05 14:50:12 --> UTF-8 Support Enabled
INFO - 2021-10-05 14:50:12 --> Utf8 Class Initialized
INFO - 2021-10-05 14:50:12 --> URI Class Initialized
INFO - 2021-10-05 14:50:12 --> Router Class Initialized
INFO - 2021-10-05 14:50:12 --> Output Class Initialized
INFO - 2021-10-05 14:50:12 --> Security Class Initialized
DEBUG - 2021-10-05 14:50:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-05 14:50:12 --> Input Class Initialized
INFO - 2021-10-05 14:50:12 --> Language Class Initialized
ERROR - 2021-10-05 14:50:12 --> 404 Page Not Found: Wp1/wp-includes
ERROR - 2021-10-05 14:50:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-05 14:50:12 --> Config Class Initialized
INFO - 2021-10-05 14:50:12 --> Hooks Class Initialized
DEBUG - 2021-10-05 14:50:12 --> UTF-8 Support Enabled
INFO - 2021-10-05 14:50:12 --> Utf8 Class Initialized
INFO - 2021-10-05 14:50:12 --> URI Class Initialized
INFO - 2021-10-05 14:50:12 --> Router Class Initialized
INFO - 2021-10-05 14:50:12 --> Output Class Initialized
INFO - 2021-10-05 14:50:12 --> Security Class Initialized
DEBUG - 2021-10-05 14:50:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-05 14:50:12 --> Input Class Initialized
INFO - 2021-10-05 14:50:12 --> Language Class Initialized
ERROR - 2021-10-05 14:50:12 --> 404 Page Not Found: Test/wp-includes
ERROR - 2021-10-05 14:50:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-05 14:50:13 --> Config Class Initialized
INFO - 2021-10-05 14:50:13 --> Hooks Class Initialized
DEBUG - 2021-10-05 14:50:13 --> UTF-8 Support Enabled
INFO - 2021-10-05 14:50:13 --> Utf8 Class Initialized
INFO - 2021-10-05 14:50:13 --> URI Class Initialized
INFO - 2021-10-05 14:50:13 --> Router Class Initialized
INFO - 2021-10-05 14:50:13 --> Output Class Initialized
INFO - 2021-10-05 14:50:13 --> Security Class Initialized
DEBUG - 2021-10-05 14:50:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-05 14:50:13 --> Input Class Initialized
INFO - 2021-10-05 14:50:13 --> Language Class Initialized
ERROR - 2021-10-05 14:50:13 --> 404 Page Not Found: Media/wp-includes
ERROR - 2021-10-05 14:50:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-05 14:50:13 --> Config Class Initialized
INFO - 2021-10-05 14:50:13 --> Hooks Class Initialized
DEBUG - 2021-10-05 14:50:13 --> UTF-8 Support Enabled
INFO - 2021-10-05 14:50:13 --> Utf8 Class Initialized
INFO - 2021-10-05 14:50:13 --> URI Class Initialized
INFO - 2021-10-05 14:50:13 --> Router Class Initialized
INFO - 2021-10-05 14:50:13 --> Output Class Initialized
INFO - 2021-10-05 14:50:13 --> Security Class Initialized
DEBUG - 2021-10-05 14:50:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-05 14:50:13 --> Input Class Initialized
INFO - 2021-10-05 14:50:13 --> Language Class Initialized
ERROR - 2021-10-05 14:50:13 --> 404 Page Not Found: Wp2/wp-includes
ERROR - 2021-10-05 14:50:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-05 14:50:14 --> Config Class Initialized
INFO - 2021-10-05 14:50:14 --> Hooks Class Initialized
DEBUG - 2021-10-05 14:50:14 --> UTF-8 Support Enabled
INFO - 2021-10-05 14:50:14 --> Utf8 Class Initialized
INFO - 2021-10-05 14:50:14 --> URI Class Initialized
INFO - 2021-10-05 14:50:14 --> Router Class Initialized
INFO - 2021-10-05 14:50:14 --> Output Class Initialized
INFO - 2021-10-05 14:50:14 --> Security Class Initialized
DEBUG - 2021-10-05 14:50:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-05 14:50:14 --> Input Class Initialized
INFO - 2021-10-05 14:50:14 --> Language Class Initialized
ERROR - 2021-10-05 14:50:14 --> 404 Page Not Found: Site/wp-includes
ERROR - 2021-10-05 14:50:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-05 14:50:14 --> Config Class Initialized
INFO - 2021-10-05 14:50:14 --> Hooks Class Initialized
DEBUG - 2021-10-05 14:50:14 --> UTF-8 Support Enabled
INFO - 2021-10-05 14:50:14 --> Utf8 Class Initialized
INFO - 2021-10-05 14:50:14 --> URI Class Initialized
INFO - 2021-10-05 14:50:14 --> Router Class Initialized
INFO - 2021-10-05 14:50:14 --> Output Class Initialized
INFO - 2021-10-05 14:50:14 --> Security Class Initialized
DEBUG - 2021-10-05 14:50:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-05 14:50:14 --> Input Class Initialized
INFO - 2021-10-05 14:50:14 --> Language Class Initialized
ERROR - 2021-10-05 14:50:14 --> 404 Page Not Found: Cms/wp-includes
ERROR - 2021-10-05 14:50:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-05 14:50:14 --> Config Class Initialized
INFO - 2021-10-05 14:50:14 --> Hooks Class Initialized
DEBUG - 2021-10-05 14:50:14 --> UTF-8 Support Enabled
INFO - 2021-10-05 14:50:14 --> Utf8 Class Initialized
INFO - 2021-10-05 14:50:14 --> URI Class Initialized
INFO - 2021-10-05 14:50:14 --> Router Class Initialized
INFO - 2021-10-05 14:50:14 --> Output Class Initialized
INFO - 2021-10-05 14:50:14 --> Security Class Initialized
DEBUG - 2021-10-05 14:50:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-05 14:50:14 --> Input Class Initialized
INFO - 2021-10-05 14:50:14 --> Language Class Initialized
ERROR - 2021-10-05 14:50:14 --> 404 Page Not Found: Sito/wp-includes
