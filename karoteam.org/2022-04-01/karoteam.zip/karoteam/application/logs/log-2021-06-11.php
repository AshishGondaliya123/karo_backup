<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-06-11 06:07:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-11 06:07:36 --> Config Class Initialized
INFO - 2021-06-11 06:07:36 --> Hooks Class Initialized
DEBUG - 2021-06-11 06:07:36 --> UTF-8 Support Enabled
INFO - 2021-06-11 06:07:36 --> Utf8 Class Initialized
INFO - 2021-06-11 06:07:36 --> URI Class Initialized
DEBUG - 2021-06-11 06:07:36 --> No URI present. Default controller set.
INFO - 2021-06-11 06:07:36 --> Router Class Initialized
INFO - 2021-06-11 06:07:36 --> Output Class Initialized
INFO - 2021-06-11 06:07:36 --> Security Class Initialized
DEBUG - 2021-06-11 06:07:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-11 06:07:36 --> Input Class Initialized
INFO - 2021-06-11 06:07:36 --> Language Class Initialized
INFO - 2021-06-11 06:07:36 --> Loader Class Initialized
INFO - 2021-06-11 06:07:36 --> Helper loaded: url_helper
INFO - 2021-06-11 06:07:36 --> Helper loaded: form_helper
INFO - 2021-06-11 06:07:36 --> Helper loaded: common_helper
INFO - 2021-06-11 06:07:36 --> Database Driver Class Initialized
DEBUG - 2021-06-11 06:07:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-11 06:07:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-11 06:07:36 --> Controller Class Initialized
INFO - 2021-06-11 06:07:36 --> Form Validation Class Initialized
DEBUG - 2021-06-11 06:07:36 --> Encrypt Class Initialized
DEBUG - 2021-06-11 06:07:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-06-11 06:07:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-06-11 06:07:36 --> Email Class Initialized
INFO - 2021-06-11 06:07:36 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-06-11 06:07:36 --> Calendar Class Initialized
INFO - 2021-06-11 06:07:36 --> Model "Login_model" initialized
INFO - 2021-06-11 06:07:36 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-06-11 06:07:36 --> Final output sent to browser
DEBUG - 2021-06-11 06:07:36 --> Total execution time: 0.0413
ERROR - 2021-06-11 23:23:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-11 23:23:01 --> Config Class Initialized
INFO - 2021-06-11 23:23:01 --> Hooks Class Initialized
DEBUG - 2021-06-11 23:23:01 --> UTF-8 Support Enabled
INFO - 2021-06-11 23:23:01 --> Utf8 Class Initialized
INFO - 2021-06-11 23:23:01 --> URI Class Initialized
DEBUG - 2021-06-11 23:23:01 --> No URI present. Default controller set.
INFO - 2021-06-11 23:23:01 --> Router Class Initialized
INFO - 2021-06-11 23:23:01 --> Output Class Initialized
INFO - 2021-06-11 23:23:01 --> Security Class Initialized
DEBUG - 2021-06-11 23:23:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-11 23:23:01 --> Input Class Initialized
INFO - 2021-06-11 23:23:01 --> Language Class Initialized
INFO - 2021-06-11 23:23:01 --> Loader Class Initialized
INFO - 2021-06-11 23:23:01 --> Helper loaded: url_helper
INFO - 2021-06-11 23:23:01 --> Helper loaded: form_helper
INFO - 2021-06-11 23:23:01 --> Helper loaded: common_helper
INFO - 2021-06-11 23:23:01 --> Database Driver Class Initialized
DEBUG - 2021-06-11 23:23:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-11 23:23:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-11 23:23:01 --> Controller Class Initialized
INFO - 2021-06-11 23:23:01 --> Form Validation Class Initialized
DEBUG - 2021-06-11 23:23:01 --> Encrypt Class Initialized
DEBUG - 2021-06-11 23:23:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-06-11 23:23:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-06-11 23:23:01 --> Email Class Initialized
INFO - 2021-06-11 23:23:01 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-06-11 23:23:01 --> Calendar Class Initialized
INFO - 2021-06-11 23:23:01 --> Model "Login_model" initialized
INFO - 2021-06-11 23:23:01 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-06-11 23:23:01 --> Final output sent to browser
DEBUG - 2021-06-11 23:23:01 --> Total execution time: 0.0458
