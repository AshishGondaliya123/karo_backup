<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-06-03 03:22:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-03 03:22:52 --> Config Class Initialized
INFO - 2021-06-03 03:22:52 --> Hooks Class Initialized
DEBUG - 2021-06-03 03:22:52 --> UTF-8 Support Enabled
INFO - 2021-06-03 03:22:52 --> Utf8 Class Initialized
INFO - 2021-06-03 03:22:52 --> URI Class Initialized
DEBUG - 2021-06-03 03:22:52 --> No URI present. Default controller set.
INFO - 2021-06-03 03:22:52 --> Router Class Initialized
INFO - 2021-06-03 03:22:52 --> Output Class Initialized
INFO - 2021-06-03 03:22:52 --> Security Class Initialized
DEBUG - 2021-06-03 03:22:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 03:22:52 --> Input Class Initialized
INFO - 2021-06-03 03:22:52 --> Language Class Initialized
INFO - 2021-06-03 03:22:52 --> Loader Class Initialized
INFO - 2021-06-03 03:22:52 --> Helper loaded: url_helper
INFO - 2021-06-03 03:22:52 --> Helper loaded: form_helper
INFO - 2021-06-03 03:22:52 --> Helper loaded: common_helper
INFO - 2021-06-03 03:22:52 --> Database Driver Class Initialized
DEBUG - 2021-06-03 03:22:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 03:22:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 03:22:52 --> Controller Class Initialized
INFO - 2021-06-03 03:22:52 --> Form Validation Class Initialized
DEBUG - 2021-06-03 03:22:52 --> Encrypt Class Initialized
DEBUG - 2021-06-03 03:22:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-06-03 03:22:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-06-03 03:22:52 --> Email Class Initialized
INFO - 2021-06-03 03:22:52 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-06-03 03:22:52 --> Calendar Class Initialized
INFO - 2021-06-03 03:22:52 --> Model "Login_model" initialized
INFO - 2021-06-03 03:22:52 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-06-03 03:22:52 --> Final output sent to browser
DEBUG - 2021-06-03 03:22:52 --> Total execution time: 0.0343
ERROR - 2021-06-03 03:22:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-03 03:22:53 --> Config Class Initialized
INFO - 2021-06-03 03:22:53 --> Hooks Class Initialized
DEBUG - 2021-06-03 03:22:53 --> UTF-8 Support Enabled
INFO - 2021-06-03 03:22:53 --> Utf8 Class Initialized
INFO - 2021-06-03 03:22:53 --> URI Class Initialized
DEBUG - 2021-06-03 03:22:53 --> No URI present. Default controller set.
INFO - 2021-06-03 03:22:53 --> Router Class Initialized
INFO - 2021-06-03 03:22:53 --> Output Class Initialized
INFO - 2021-06-03 03:22:53 --> Security Class Initialized
DEBUG - 2021-06-03 03:22:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 03:22:53 --> Input Class Initialized
INFO - 2021-06-03 03:22:53 --> Language Class Initialized
INFO - 2021-06-03 03:22:53 --> Loader Class Initialized
INFO - 2021-06-03 03:22:53 --> Helper loaded: url_helper
INFO - 2021-06-03 03:22:53 --> Helper loaded: form_helper
INFO - 2021-06-03 03:22:53 --> Helper loaded: common_helper
INFO - 2021-06-03 03:22:53 --> Database Driver Class Initialized
DEBUG - 2021-06-03 03:22:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 03:22:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 03:22:53 --> Controller Class Initialized
INFO - 2021-06-03 03:22:53 --> Form Validation Class Initialized
DEBUG - 2021-06-03 03:22:53 --> Encrypt Class Initialized
DEBUG - 2021-06-03 03:22:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-06-03 03:22:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-06-03 03:22:53 --> Email Class Initialized
INFO - 2021-06-03 03:22:53 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-06-03 03:22:53 --> Calendar Class Initialized
INFO - 2021-06-03 03:22:53 --> Model "Login_model" initialized
INFO - 2021-06-03 03:22:53 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-06-03 03:22:53 --> Final output sent to browser
DEBUG - 2021-06-03 03:22:53 --> Total execution time: 0.0174
ERROR - 2021-06-03 03:22:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-03 03:22:54 --> Config Class Initialized
INFO - 2021-06-03 03:22:54 --> Hooks Class Initialized
DEBUG - 2021-06-03 03:22:54 --> UTF-8 Support Enabled
INFO - 2021-06-03 03:22:54 --> Utf8 Class Initialized
INFO - 2021-06-03 03:22:54 --> URI Class Initialized
INFO - 2021-06-03 03:22:54 --> Router Class Initialized
INFO - 2021-06-03 03:22:54 --> Output Class Initialized
INFO - 2021-06-03 03:22:54 --> Security Class Initialized
DEBUG - 2021-06-03 03:22:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 03:22:54 --> Input Class Initialized
INFO - 2021-06-03 03:22:54 --> Language Class Initialized
ERROR - 2021-06-03 03:22:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-03 03:22:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-03 03:22:55 --> Config Class Initialized
INFO - 2021-06-03 03:22:55 --> Hooks Class Initialized
DEBUG - 2021-06-03 03:22:55 --> UTF-8 Support Enabled
INFO - 2021-06-03 03:22:55 --> Utf8 Class Initialized
INFO - 2021-06-03 03:22:55 --> URI Class Initialized
INFO - 2021-06-03 03:22:55 --> Router Class Initialized
INFO - 2021-06-03 03:22:55 --> Output Class Initialized
INFO - 2021-06-03 03:22:55 --> Security Class Initialized
DEBUG - 2021-06-03 03:22:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 03:22:55 --> Input Class Initialized
INFO - 2021-06-03 03:22:55 --> Language Class Initialized
INFO - 2021-06-03 03:22:55 --> Loader Class Initialized
INFO - 2021-06-03 03:22:55 --> Helper loaded: url_helper
INFO - 2021-06-03 03:22:55 --> Helper loaded: form_helper
INFO - 2021-06-03 03:22:55 --> Helper loaded: common_helper
INFO - 2021-06-03 03:22:55 --> Database Driver Class Initialized
DEBUG - 2021-06-03 03:22:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 03:22:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 03:22:55 --> Controller Class Initialized
INFO - 2021-06-03 03:22:55 --> Form Validation Class Initialized
DEBUG - 2021-06-03 03:22:55 --> Encrypt Class Initialized
DEBUG - 2021-06-03 03:22:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-06-03 03:22:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-06-03 03:22:55 --> Email Class Initialized
INFO - 2021-06-03 03:22:55 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-06-03 03:22:55 --> Calendar Class Initialized
INFO - 2021-06-03 03:22:55 --> Model "Login_model" initialized
INFO - 2021-06-03 03:22:55 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2021-06-03 03:22:55 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-06-03 03:22:55 --> Final output sent to browser
DEBUG - 2021-06-03 03:22:55 --> Total execution time: 0.0183
ERROR - 2021-06-03 03:23:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-03 03:23:00 --> Config Class Initialized
INFO - 2021-06-03 03:23:00 --> Hooks Class Initialized
DEBUG - 2021-06-03 03:23:00 --> UTF-8 Support Enabled
INFO - 2021-06-03 03:23:00 --> Utf8 Class Initialized
INFO - 2021-06-03 03:23:00 --> URI Class Initialized
INFO - 2021-06-03 03:23:00 --> Router Class Initialized
INFO - 2021-06-03 03:23:00 --> Output Class Initialized
INFO - 2021-06-03 03:23:00 --> Security Class Initialized
DEBUG - 2021-06-03 03:23:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 03:23:00 --> Input Class Initialized
INFO - 2021-06-03 03:23:00 --> Language Class Initialized
INFO - 2021-06-03 03:23:00 --> Loader Class Initialized
INFO - 2021-06-03 03:23:00 --> Helper loaded: url_helper
INFO - 2021-06-03 03:23:00 --> Helper loaded: form_helper
INFO - 2021-06-03 03:23:00 --> Helper loaded: common_helper
INFO - 2021-06-03 03:23:00 --> Database Driver Class Initialized
DEBUG - 2021-06-03 03:23:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 03:23:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 03:23:00 --> Controller Class Initialized
INFO - 2021-06-03 03:23:00 --> Form Validation Class Initialized
DEBUG - 2021-06-03 03:23:00 --> Encrypt Class Initialized
DEBUG - 2021-06-03 03:23:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-06-03 03:23:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-06-03 03:23:00 --> Email Class Initialized
INFO - 2021-06-03 03:23:00 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-06-03 03:23:00 --> Calendar Class Initialized
INFO - 2021-06-03 03:23:00 --> Model "Login_model" initialized
INFO - 2021-06-03 03:23:00 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2021-06-03 03:23:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-03 03:23:00 --> Config Class Initialized
INFO - 2021-06-03 03:23:00 --> Hooks Class Initialized
DEBUG - 2021-06-03 03:23:00 --> UTF-8 Support Enabled
INFO - 2021-06-03 03:23:00 --> Utf8 Class Initialized
INFO - 2021-06-03 03:23:00 --> URI Class Initialized
INFO - 2021-06-03 03:23:00 --> Router Class Initialized
INFO - 2021-06-03 03:23:00 --> Output Class Initialized
INFO - 2021-06-03 03:23:00 --> Security Class Initialized
DEBUG - 2021-06-03 03:23:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 03:23:00 --> Input Class Initialized
INFO - 2021-06-03 03:23:00 --> Language Class Initialized
INFO - 2021-06-03 03:23:00 --> Loader Class Initialized
INFO - 2021-06-03 03:23:00 --> Helper loaded: url_helper
INFO - 2021-06-03 03:23:00 --> Helper loaded: form_helper
INFO - 2021-06-03 03:23:00 --> Helper loaded: common_helper
INFO - 2021-06-03 03:23:00 --> Database Driver Class Initialized
DEBUG - 2021-06-03 03:23:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 03:23:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 03:23:00 --> Controller Class Initialized
INFO - 2021-06-03 03:23:00 --> Form Validation Class Initialized
DEBUG - 2021-06-03 03:23:00 --> Encrypt Class Initialized
INFO - 2021-06-03 03:23:00 --> Model "Login_model" initialized
INFO - 2021-06-03 03:23:00 --> Model "Dashboard_model" initialized
INFO - 2021-06-03 03:23:00 --> Model "Case_model" initialized
INFO - 2021-06-03 03:23:03 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/header.php
INFO - 2021-06-03 03:23:09 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/dashboard/index.php
INFO - 2021-06-03 03:23:09 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/footer.php
INFO - 2021-06-03 03:23:09 --> Final output sent to browser
DEBUG - 2021-06-03 03:23:09 --> Total execution time: 8.8551
ERROR - 2021-06-03 03:23:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-03 03:23:10 --> Config Class Initialized
INFO - 2021-06-03 03:23:10 --> Hooks Class Initialized
DEBUG - 2021-06-03 03:23:10 --> UTF-8 Support Enabled
INFO - 2021-06-03 03:23:10 --> Utf8 Class Initialized
INFO - 2021-06-03 03:23:10 --> URI Class Initialized
INFO - 2021-06-03 03:23:10 --> Router Class Initialized
INFO - 2021-06-03 03:23:10 --> Output Class Initialized
INFO - 2021-06-03 03:23:10 --> Security Class Initialized
DEBUG - 2021-06-03 03:23:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 03:23:10 --> Input Class Initialized
INFO - 2021-06-03 03:23:10 --> Language Class Initialized
ERROR - 2021-06-03 03:23:10 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-06-03 03:23:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-03 03:23:17 --> Config Class Initialized
INFO - 2021-06-03 03:23:17 --> Hooks Class Initialized
DEBUG - 2021-06-03 03:23:17 --> UTF-8 Support Enabled
INFO - 2021-06-03 03:23:17 --> Utf8 Class Initialized
INFO - 2021-06-03 03:23:17 --> URI Class Initialized
INFO - 2021-06-03 03:23:17 --> Router Class Initialized
INFO - 2021-06-03 03:23:17 --> Output Class Initialized
INFO - 2021-06-03 03:23:17 --> Security Class Initialized
DEBUG - 2021-06-03 03:23:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 03:23:17 --> Input Class Initialized
INFO - 2021-06-03 03:23:17 --> Language Class Initialized
INFO - 2021-06-03 03:23:17 --> Loader Class Initialized
INFO - 2021-06-03 03:23:17 --> Helper loaded: url_helper
INFO - 2021-06-03 03:23:17 --> Helper loaded: form_helper
INFO - 2021-06-03 03:23:17 --> Helper loaded: common_helper
INFO - 2021-06-03 03:23:17 --> Database Driver Class Initialized
DEBUG - 2021-06-03 03:23:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 03:23:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 03:23:17 --> Controller Class Initialized
INFO - 2021-06-03 03:23:17 --> Form Validation Class Initialized
DEBUG - 2021-06-03 03:23:17 --> Encrypt Class Initialized
INFO - 2021-06-03 03:23:17 --> Model "Patient_model" initialized
INFO - 2021-06-03 03:23:17 --> Model "Patientcase_model" initialized
INFO - 2021-06-03 03:23:17 --> Model "Referredby_model" initialized
INFO - 2021-06-03 03:23:17 --> Model "Prefix_master" initialized
INFO - 2021-06-03 03:23:17 --> Model "Hospital_model" initialized
INFO - 2021-06-03 03:23:17 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/header.php
INFO - 2021-06-03 03:23:17 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/patient/patientview.php
INFO - 2021-06-03 03:23:17 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/footer.php
INFO - 2021-06-03 03:23:17 --> Final output sent to browser
DEBUG - 2021-06-03 03:23:17 --> Total execution time: 0.0471
ERROR - 2021-06-03 03:23:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-03 03:23:18 --> Config Class Initialized
INFO - 2021-06-03 03:23:18 --> Hooks Class Initialized
DEBUG - 2021-06-03 03:23:18 --> UTF-8 Support Enabled
INFO - 2021-06-03 03:23:18 --> Utf8 Class Initialized
INFO - 2021-06-03 03:23:18 --> URI Class Initialized
INFO - 2021-06-03 03:23:18 --> Router Class Initialized
INFO - 2021-06-03 03:23:18 --> Output Class Initialized
INFO - 2021-06-03 03:23:18 --> Security Class Initialized
DEBUG - 2021-06-03 03:23:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 03:23:18 --> Input Class Initialized
INFO - 2021-06-03 03:23:18 --> Language Class Initialized
ERROR - 2021-06-03 03:23:18 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-06-03 03:23:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-03 03:23:21 --> Config Class Initialized
INFO - 2021-06-03 03:23:21 --> Hooks Class Initialized
DEBUG - 2021-06-03 03:23:21 --> UTF-8 Support Enabled
INFO - 2021-06-03 03:23:21 --> Utf8 Class Initialized
INFO - 2021-06-03 03:23:21 --> URI Class Initialized
INFO - 2021-06-03 03:23:21 --> Router Class Initialized
INFO - 2021-06-03 03:23:21 --> Output Class Initialized
INFO - 2021-06-03 03:23:21 --> Security Class Initialized
DEBUG - 2021-06-03 03:23:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 03:23:21 --> Input Class Initialized
INFO - 2021-06-03 03:23:21 --> Language Class Initialized
INFO - 2021-06-03 03:23:21 --> Loader Class Initialized
INFO - 2021-06-03 03:23:21 --> Helper loaded: url_helper
INFO - 2021-06-03 03:23:21 --> Helper loaded: form_helper
INFO - 2021-06-03 03:23:21 --> Helper loaded: common_helper
INFO - 2021-06-03 03:23:21 --> Database Driver Class Initialized
DEBUG - 2021-06-03 03:23:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 03:23:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 03:23:21 --> Controller Class Initialized
INFO - 2021-06-03 03:23:21 --> Form Validation Class Initialized
DEBUG - 2021-06-03 03:23:21 --> Encrypt Class Initialized
INFO - 2021-06-03 03:23:21 --> Model "Patient_model" initialized
INFO - 2021-06-03 03:23:21 --> Model "Patientcase_model" initialized
INFO - 2021-06-03 03:23:21 --> Model "Referredby_model" initialized
INFO - 2021-06-03 03:23:21 --> Model "Prefix_master" initialized
INFO - 2021-06-03 03:23:21 --> Model "Hospital_model" initialized
INFO - 2021-06-03 03:23:21 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/header.php
INFO - 2021-06-03 03:23:21 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/patient/index.php
INFO - 2021-06-03 03:23:21 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/footer.php
INFO - 2021-06-03 03:23:21 --> Final output sent to browser
DEBUG - 2021-06-03 03:23:21 --> Total execution time: 0.0386
ERROR - 2021-06-03 03:23:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-03 03:23:22 --> Config Class Initialized
INFO - 2021-06-03 03:23:22 --> Hooks Class Initialized
DEBUG - 2021-06-03 03:23:22 --> UTF-8 Support Enabled
INFO - 2021-06-03 03:23:22 --> Utf8 Class Initialized
INFO - 2021-06-03 03:23:22 --> URI Class Initialized
INFO - 2021-06-03 03:23:22 --> Router Class Initialized
INFO - 2021-06-03 03:23:22 --> Output Class Initialized
INFO - 2021-06-03 03:23:22 --> Security Class Initialized
DEBUG - 2021-06-03 03:23:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 03:23:22 --> Input Class Initialized
INFO - 2021-06-03 03:23:22 --> Language Class Initialized
ERROR - 2021-06-03 03:23:22 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-06-03 03:23:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-03 03:23:23 --> Config Class Initialized
INFO - 2021-06-03 03:23:23 --> Hooks Class Initialized
DEBUG - 2021-06-03 03:23:23 --> UTF-8 Support Enabled
INFO - 2021-06-03 03:23:23 --> Utf8 Class Initialized
INFO - 2021-06-03 03:23:23 --> URI Class Initialized
INFO - 2021-06-03 03:23:23 --> Router Class Initialized
INFO - 2021-06-03 03:23:23 --> Output Class Initialized
INFO - 2021-06-03 03:23:23 --> Security Class Initialized
DEBUG - 2021-06-03 03:23:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 03:23:23 --> Input Class Initialized
INFO - 2021-06-03 03:23:23 --> Language Class Initialized
INFO - 2021-06-03 03:23:23 --> Loader Class Initialized
INFO - 2021-06-03 03:23:23 --> Helper loaded: url_helper
INFO - 2021-06-03 03:23:23 --> Helper loaded: form_helper
INFO - 2021-06-03 03:23:23 --> Helper loaded: common_helper
INFO - 2021-06-03 03:23:23 --> Database Driver Class Initialized
DEBUG - 2021-06-03 03:23:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 03:23:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 03:23:23 --> Controller Class Initialized
INFO - 2021-06-03 03:23:23 --> Form Validation Class Initialized
DEBUG - 2021-06-03 03:23:23 --> Encrypt Class Initialized
INFO - 2021-06-03 03:23:23 --> Model "Patient_model" initialized
INFO - 2021-06-03 03:23:23 --> Model "Patientcase_model" initialized
INFO - 2021-06-03 03:23:23 --> Model "Referredby_model" initialized
INFO - 2021-06-03 03:23:23 --> Model "Prefix_master" initialized
INFO - 2021-06-03 03:23:23 --> Model "Hospital_model" initialized
INFO - 2021-06-03 03:23:23 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/header.php
INFO - 2021-06-03 03:23:23 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/patient/patientview.php
INFO - 2021-06-03 03:23:23 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/footer.php
INFO - 2021-06-03 03:23:23 --> Final output sent to browser
DEBUG - 2021-06-03 03:23:23 --> Total execution time: 0.0393
ERROR - 2021-06-03 03:23:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-03 03:23:24 --> Config Class Initialized
INFO - 2021-06-03 03:23:24 --> Hooks Class Initialized
DEBUG - 2021-06-03 03:23:24 --> UTF-8 Support Enabled
INFO - 2021-06-03 03:23:24 --> Utf8 Class Initialized
INFO - 2021-06-03 03:23:24 --> URI Class Initialized
INFO - 2021-06-03 03:23:24 --> Router Class Initialized
INFO - 2021-06-03 03:23:24 --> Output Class Initialized
INFO - 2021-06-03 03:23:24 --> Security Class Initialized
DEBUG - 2021-06-03 03:23:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 03:23:24 --> Input Class Initialized
INFO - 2021-06-03 03:23:24 --> Language Class Initialized
ERROR - 2021-06-03 03:23:24 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-06-03 03:23:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-03 03:23:27 --> Config Class Initialized
INFO - 2021-06-03 03:23:27 --> Hooks Class Initialized
DEBUG - 2021-06-03 03:23:27 --> UTF-8 Support Enabled
INFO - 2021-06-03 03:23:27 --> Utf8 Class Initialized
INFO - 2021-06-03 03:23:27 --> URI Class Initialized
INFO - 2021-06-03 03:23:27 --> Router Class Initialized
INFO - 2021-06-03 03:23:27 --> Output Class Initialized
INFO - 2021-06-03 03:23:27 --> Security Class Initialized
DEBUG - 2021-06-03 03:23:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 03:23:27 --> Input Class Initialized
INFO - 2021-06-03 03:23:27 --> Language Class Initialized
INFO - 2021-06-03 03:23:27 --> Loader Class Initialized
INFO - 2021-06-03 03:23:27 --> Helper loaded: url_helper
INFO - 2021-06-03 03:23:27 --> Helper loaded: form_helper
INFO - 2021-06-03 03:23:27 --> Helper loaded: common_helper
INFO - 2021-06-03 03:23:27 --> Database Driver Class Initialized
DEBUG - 2021-06-03 03:23:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 03:23:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 03:23:27 --> Controller Class Initialized
INFO - 2021-06-03 03:23:27 --> Form Validation Class Initialized
DEBUG - 2021-06-03 03:23:27 --> Encrypt Class Initialized
INFO - 2021-06-03 03:23:27 --> Model "Patient_model" initialized
INFO - 2021-06-03 03:23:27 --> Model "Patientcase_model" initialized
INFO - 2021-06-03 03:23:27 --> Model "Prefix_master" initialized
INFO - 2021-06-03 03:23:27 --> Model "Users_model" initialized
INFO - 2021-06-03 03:23:27 --> Model "Hospital_model" initialized
INFO - 2021-06-03 03:23:27 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/header.php
INFO - 2021-06-03 03:23:27 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/patientcase/index.php
INFO - 2021-06-03 03:23:27 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/footer.php
INFO - 2021-06-03 03:23:27 --> Final output sent to browser
DEBUG - 2021-06-03 03:23:27 --> Total execution time: 0.1347
ERROR - 2021-06-03 03:23:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-03 03:23:27 --> Config Class Initialized
INFO - 2021-06-03 03:23:27 --> Hooks Class Initialized
DEBUG - 2021-06-03 03:23:27 --> UTF-8 Support Enabled
INFO - 2021-06-03 03:23:27 --> Utf8 Class Initialized
INFO - 2021-06-03 03:23:27 --> URI Class Initialized
INFO - 2021-06-03 03:23:27 --> Router Class Initialized
INFO - 2021-06-03 03:23:27 --> Output Class Initialized
INFO - 2021-06-03 03:23:27 --> Security Class Initialized
DEBUG - 2021-06-03 03:23:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 03:23:27 --> Input Class Initialized
INFO - 2021-06-03 03:23:27 --> Language Class Initialized
INFO - 2021-06-03 03:23:27 --> Loader Class Initialized
INFO - 2021-06-03 03:23:27 --> Helper loaded: url_helper
INFO - 2021-06-03 03:23:27 --> Helper loaded: form_helper
INFO - 2021-06-03 03:23:27 --> Helper loaded: common_helper
INFO - 2021-06-03 03:23:27 --> Database Driver Class Initialized
DEBUG - 2021-06-03 03:23:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 03:23:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 03:23:27 --> Controller Class Initialized
INFO - 2021-06-03 03:23:27 --> Form Validation Class Initialized
DEBUG - 2021-06-03 03:23:27 --> Encrypt Class Initialized
INFO - 2021-06-03 03:23:27 --> Model "Patient_model" initialized
INFO - 2021-06-03 03:23:27 --> Model "Patientcase_model" initialized
INFO - 2021-06-03 03:23:27 --> Model "Prefix_master" initialized
INFO - 2021-06-03 03:23:27 --> Model "Users_model" initialized
INFO - 2021-06-03 03:23:27 --> Model "Hospital_model" initialized
INFO - 2021-06-03 03:23:27 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/header.php
INFO - 2021-06-03 03:23:27 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/patientcase/index.php
INFO - 2021-06-03 03:23:27 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/footer.php
INFO - 2021-06-03 03:23:27 --> Final output sent to browser
DEBUG - 2021-06-03 03:23:27 --> Total execution time: 0.0596
ERROR - 2021-06-03 03:23:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-03 03:23:28 --> Config Class Initialized
INFO - 2021-06-03 03:23:28 --> Hooks Class Initialized
DEBUG - 2021-06-03 03:23:28 --> UTF-8 Support Enabled
INFO - 2021-06-03 03:23:28 --> Utf8 Class Initialized
INFO - 2021-06-03 03:23:28 --> URI Class Initialized
INFO - 2021-06-03 03:23:28 --> Router Class Initialized
INFO - 2021-06-03 03:23:28 --> Output Class Initialized
INFO - 2021-06-03 03:23:28 --> Security Class Initialized
DEBUG - 2021-06-03 03:23:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 03:23:28 --> Input Class Initialized
INFO - 2021-06-03 03:23:28 --> Language Class Initialized
ERROR - 2021-06-03 03:23:28 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-06-03 03:23:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-03 03:23:45 --> Config Class Initialized
INFO - 2021-06-03 03:23:45 --> Hooks Class Initialized
DEBUG - 2021-06-03 03:23:45 --> UTF-8 Support Enabled
INFO - 2021-06-03 03:23:45 --> Utf8 Class Initialized
INFO - 2021-06-03 03:23:45 --> URI Class Initialized
INFO - 2021-06-03 03:23:45 --> Router Class Initialized
INFO - 2021-06-03 03:23:45 --> Output Class Initialized
INFO - 2021-06-03 03:23:45 --> Security Class Initialized
DEBUG - 2021-06-03 03:23:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 03:23:45 --> Input Class Initialized
INFO - 2021-06-03 03:23:45 --> Language Class Initialized
INFO - 2021-06-03 03:23:45 --> Loader Class Initialized
INFO - 2021-06-03 03:23:45 --> Helper loaded: url_helper
INFO - 2021-06-03 03:23:45 --> Helper loaded: form_helper
INFO - 2021-06-03 03:23:45 --> Helper loaded: common_helper
INFO - 2021-06-03 03:23:45 --> Database Driver Class Initialized
DEBUG - 2021-06-03 03:23:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 03:23:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 03:23:45 --> Controller Class Initialized
INFO - 2021-06-03 03:23:45 --> Form Validation Class Initialized
INFO - 2021-06-03 03:23:45 --> Model "Case_model" initialized
INFO - 2021-06-03 03:23:45 --> Model "Hospital_model" initialized
INFO - 2021-06-03 03:23:45 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/header.php
INFO - 2021-06-03 03:23:45 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/transaction/upcomingFollowup.php
INFO - 2021-06-03 03:23:45 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/footer.php
INFO - 2021-06-03 03:23:45 --> Final output sent to browser
DEBUG - 2021-06-03 03:23:45 --> Total execution time: 0.0177
ERROR - 2021-06-03 03:23:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-03 03:23:45 --> Config Class Initialized
INFO - 2021-06-03 03:23:45 --> Hooks Class Initialized
DEBUG - 2021-06-03 03:23:45 --> UTF-8 Support Enabled
INFO - 2021-06-03 03:23:45 --> Utf8 Class Initialized
INFO - 2021-06-03 03:23:45 --> URI Class Initialized
INFO - 2021-06-03 03:23:45 --> Router Class Initialized
INFO - 2021-06-03 03:23:45 --> Output Class Initialized
INFO - 2021-06-03 03:23:45 --> Security Class Initialized
DEBUG - 2021-06-03 03:23:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 03:23:45 --> Input Class Initialized
INFO - 2021-06-03 03:23:45 --> Language Class Initialized
ERROR - 2021-06-03 03:23:45 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-06-03 03:23:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-03 03:23:49 --> Config Class Initialized
INFO - 2021-06-03 03:23:49 --> Hooks Class Initialized
DEBUG - 2021-06-03 03:23:49 --> UTF-8 Support Enabled
INFO - 2021-06-03 03:23:49 --> Utf8 Class Initialized
INFO - 2021-06-03 03:23:49 --> URI Class Initialized
INFO - 2021-06-03 03:23:49 --> Router Class Initialized
INFO - 2021-06-03 03:23:49 --> Output Class Initialized
INFO - 2021-06-03 03:23:49 --> Security Class Initialized
DEBUG - 2021-06-03 03:23:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 03:23:49 --> Input Class Initialized
INFO - 2021-06-03 03:23:49 --> Language Class Initialized
ERROR - 2021-06-03 03:23:49 --> 404 Page Not Found: Karoclient/css
ERROR - 2021-06-03 03:23:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-03 03:23:53 --> Config Class Initialized
INFO - 2021-06-03 03:23:53 --> Hooks Class Initialized
DEBUG - 2021-06-03 03:23:53 --> UTF-8 Support Enabled
INFO - 2021-06-03 03:23:53 --> Utf8 Class Initialized
INFO - 2021-06-03 03:23:53 --> URI Class Initialized
INFO - 2021-06-03 03:23:53 --> Router Class Initialized
INFO - 2021-06-03 03:23:53 --> Output Class Initialized
INFO - 2021-06-03 03:23:53 --> Security Class Initialized
DEBUG - 2021-06-03 03:23:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 03:23:53 --> Input Class Initialized
INFO - 2021-06-03 03:23:53 --> Language Class Initialized
INFO - 2021-06-03 03:23:53 --> Loader Class Initialized
INFO - 2021-06-03 03:23:53 --> Helper loaded: url_helper
INFO - 2021-06-03 03:23:53 --> Helper loaded: form_helper
INFO - 2021-06-03 03:23:53 --> Helper loaded: common_helper
INFO - 2021-06-03 03:23:53 --> Database Driver Class Initialized
DEBUG - 2021-06-03 03:23:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 03:23:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 03:23:53 --> Controller Class Initialized
INFO - 2021-06-03 03:23:53 --> Form Validation Class Initialized
INFO - 2021-06-03 03:23:53 --> Model "Case_model" initialized
INFO - 2021-06-03 03:23:55 --> Model "Hospital_model" initialized
INFO - 2021-06-03 03:23:55 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/header.php
INFO - 2021-06-03 03:23:55 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/transaction/upcomingFollowup.php
INFO - 2021-06-03 03:23:55 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/footer.php
INFO - 2021-06-03 03:23:55 --> Final output sent to browser
DEBUG - 2021-06-03 03:23:55 --> Total execution time: 2.4771
ERROR - 2021-06-03 03:23:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-03 03:23:56 --> Config Class Initialized
INFO - 2021-06-03 03:23:56 --> Hooks Class Initialized
DEBUG - 2021-06-03 03:23:56 --> UTF-8 Support Enabled
INFO - 2021-06-03 03:23:56 --> Utf8 Class Initialized
INFO - 2021-06-03 03:23:56 --> URI Class Initialized
INFO - 2021-06-03 03:23:56 --> Router Class Initialized
INFO - 2021-06-03 03:23:56 --> Output Class Initialized
INFO - 2021-06-03 03:23:56 --> Security Class Initialized
DEBUG - 2021-06-03 03:23:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 03:23:56 --> Input Class Initialized
INFO - 2021-06-03 03:23:56 --> Language Class Initialized
ERROR - 2021-06-03 03:23:56 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-06-03 07:52:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-03 07:52:20 --> Config Class Initialized
INFO - 2021-06-03 07:52:20 --> Hooks Class Initialized
DEBUG - 2021-06-03 07:52:20 --> UTF-8 Support Enabled
INFO - 2021-06-03 07:52:20 --> Utf8 Class Initialized
INFO - 2021-06-03 07:52:20 --> URI Class Initialized
DEBUG - 2021-06-03 07:52:20 --> No URI present. Default controller set.
INFO - 2021-06-03 07:52:20 --> Router Class Initialized
INFO - 2021-06-03 07:52:20 --> Output Class Initialized
INFO - 2021-06-03 07:52:20 --> Security Class Initialized
DEBUG - 2021-06-03 07:52:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 07:52:20 --> Input Class Initialized
INFO - 2021-06-03 07:52:20 --> Language Class Initialized
INFO - 2021-06-03 07:52:20 --> Loader Class Initialized
INFO - 2021-06-03 07:52:20 --> Helper loaded: url_helper
INFO - 2021-06-03 07:52:20 --> Helper loaded: form_helper
INFO - 2021-06-03 07:52:20 --> Helper loaded: common_helper
INFO - 2021-06-03 07:52:20 --> Database Driver Class Initialized
DEBUG - 2021-06-03 07:52:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 07:52:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 07:52:20 --> Controller Class Initialized
INFO - 2021-06-03 07:52:20 --> Form Validation Class Initialized
DEBUG - 2021-06-03 07:52:20 --> Encrypt Class Initialized
DEBUG - 2021-06-03 07:52:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-06-03 07:52:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-06-03 07:52:20 --> Email Class Initialized
INFO - 2021-06-03 07:52:20 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-06-03 07:52:20 --> Calendar Class Initialized
INFO - 2021-06-03 07:52:20 --> Model "Login_model" initialized
INFO - 2021-06-03 07:52:20 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-06-03 07:52:20 --> Final output sent to browser
DEBUG - 2021-06-03 07:52:20 --> Total execution time: 0.0367
ERROR - 2021-06-03 15:19:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-03 15:19:37 --> Config Class Initialized
INFO - 2021-06-03 15:19:37 --> Hooks Class Initialized
DEBUG - 2021-06-03 15:19:37 --> UTF-8 Support Enabled
INFO - 2021-06-03 15:19:37 --> Utf8 Class Initialized
INFO - 2021-06-03 15:19:37 --> URI Class Initialized
DEBUG - 2021-06-03 15:19:37 --> No URI present. Default controller set.
INFO - 2021-06-03 15:19:37 --> Router Class Initialized
INFO - 2021-06-03 15:19:37 --> Output Class Initialized
INFO - 2021-06-03 15:19:37 --> Security Class Initialized
DEBUG - 2021-06-03 15:19:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 15:19:37 --> Input Class Initialized
INFO - 2021-06-03 15:19:37 --> Language Class Initialized
INFO - 2021-06-03 15:19:37 --> Loader Class Initialized
INFO - 2021-06-03 15:19:37 --> Helper loaded: url_helper
INFO - 2021-06-03 15:19:37 --> Helper loaded: form_helper
INFO - 2021-06-03 15:19:37 --> Helper loaded: common_helper
INFO - 2021-06-03 15:19:37 --> Database Driver Class Initialized
DEBUG - 2021-06-03 15:19:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 15:19:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 15:19:37 --> Controller Class Initialized
INFO - 2021-06-03 15:19:37 --> Form Validation Class Initialized
DEBUG - 2021-06-03 15:19:37 --> Encrypt Class Initialized
DEBUG - 2021-06-03 15:19:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-06-03 15:19:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-06-03 15:19:37 --> Email Class Initialized
INFO - 2021-06-03 15:19:37 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-06-03 15:19:37 --> Calendar Class Initialized
INFO - 2021-06-03 15:19:37 --> Model "Login_model" initialized
INFO - 2021-06-03 15:19:37 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-06-03 15:19:37 --> Final output sent to browser
DEBUG - 2021-06-03 15:19:37 --> Total execution time: 0.0415
ERROR - 2021-06-03 15:19:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-03 15:19:38 --> Config Class Initialized
INFO - 2021-06-03 15:19:38 --> Hooks Class Initialized
DEBUG - 2021-06-03 15:19:38 --> UTF-8 Support Enabled
INFO - 2021-06-03 15:19:38 --> Utf8 Class Initialized
INFO - 2021-06-03 15:19:38 --> URI Class Initialized
DEBUG - 2021-06-03 15:19:38 --> No URI present. Default controller set.
INFO - 2021-06-03 15:19:38 --> Router Class Initialized
INFO - 2021-06-03 15:19:38 --> Output Class Initialized
INFO - 2021-06-03 15:19:38 --> Security Class Initialized
DEBUG - 2021-06-03 15:19:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 15:19:38 --> Input Class Initialized
INFO - 2021-06-03 15:19:38 --> Language Class Initialized
INFO - 2021-06-03 15:19:38 --> Loader Class Initialized
INFO - 2021-06-03 15:19:38 --> Helper loaded: url_helper
INFO - 2021-06-03 15:19:38 --> Helper loaded: form_helper
INFO - 2021-06-03 15:19:38 --> Helper loaded: common_helper
INFO - 2021-06-03 15:19:38 --> Database Driver Class Initialized
DEBUG - 2021-06-03 15:19:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 15:19:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 15:19:38 --> Controller Class Initialized
INFO - 2021-06-03 15:19:38 --> Form Validation Class Initialized
DEBUG - 2021-06-03 15:19:38 --> Encrypt Class Initialized
DEBUG - 2021-06-03 15:19:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-06-03 15:19:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-06-03 15:19:38 --> Email Class Initialized
INFO - 2021-06-03 15:19:38 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-06-03 15:19:38 --> Calendar Class Initialized
INFO - 2021-06-03 15:19:38 --> Model "Login_model" initialized
INFO - 2021-06-03 15:19:38 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-06-03 15:19:38 --> Final output sent to browser
DEBUG - 2021-06-03 15:19:38 --> Total execution time: 0.0177
ERROR - 2021-06-03 15:19:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-03 15:19:39 --> Config Class Initialized
INFO - 2021-06-03 15:19:39 --> Hooks Class Initialized
DEBUG - 2021-06-03 15:19:39 --> UTF-8 Support Enabled
INFO - 2021-06-03 15:19:39 --> Utf8 Class Initialized
INFO - 2021-06-03 15:19:39 --> URI Class Initialized
INFO - 2021-06-03 15:19:39 --> Router Class Initialized
INFO - 2021-06-03 15:19:39 --> Output Class Initialized
INFO - 2021-06-03 15:19:39 --> Security Class Initialized
DEBUG - 2021-06-03 15:19:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 15:19:39 --> Input Class Initialized
INFO - 2021-06-03 15:19:39 --> Language Class Initialized
ERROR - 2021-06-03 15:19:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-03 15:19:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-03 15:19:42 --> Config Class Initialized
INFO - 2021-06-03 15:19:42 --> Hooks Class Initialized
DEBUG - 2021-06-03 15:19:42 --> UTF-8 Support Enabled
INFO - 2021-06-03 15:19:42 --> Utf8 Class Initialized
INFO - 2021-06-03 15:19:42 --> URI Class Initialized
INFO - 2021-06-03 15:19:42 --> Router Class Initialized
INFO - 2021-06-03 15:19:42 --> Output Class Initialized
INFO - 2021-06-03 15:19:42 --> Security Class Initialized
DEBUG - 2021-06-03 15:19:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 15:19:42 --> Input Class Initialized
INFO - 2021-06-03 15:19:42 --> Language Class Initialized
INFO - 2021-06-03 15:19:42 --> Loader Class Initialized
INFO - 2021-06-03 15:19:42 --> Helper loaded: url_helper
INFO - 2021-06-03 15:19:42 --> Helper loaded: form_helper
INFO - 2021-06-03 15:19:42 --> Helper loaded: common_helper
INFO - 2021-06-03 15:19:42 --> Database Driver Class Initialized
DEBUG - 2021-06-03 15:19:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 15:19:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 15:19:42 --> Controller Class Initialized
INFO - 2021-06-03 15:19:42 --> Form Validation Class Initialized
DEBUG - 2021-06-03 15:19:42 --> Encrypt Class Initialized
DEBUG - 2021-06-03 15:19:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-06-03 15:19:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-06-03 15:19:42 --> Email Class Initialized
INFO - 2021-06-03 15:19:42 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-06-03 15:19:42 --> Calendar Class Initialized
INFO - 2021-06-03 15:19:42 --> Model "Login_model" initialized
INFO - 2021-06-03 15:19:42 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2021-06-03 15:19:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-03 15:19:42 --> Config Class Initialized
INFO - 2021-06-03 15:19:42 --> Hooks Class Initialized
DEBUG - 2021-06-03 15:19:42 --> UTF-8 Support Enabled
INFO - 2021-06-03 15:19:42 --> Utf8 Class Initialized
INFO - 2021-06-03 15:19:42 --> URI Class Initialized
INFO - 2021-06-03 15:19:42 --> Router Class Initialized
INFO - 2021-06-03 15:19:42 --> Output Class Initialized
INFO - 2021-06-03 15:19:42 --> Security Class Initialized
DEBUG - 2021-06-03 15:19:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 15:19:42 --> Input Class Initialized
INFO - 2021-06-03 15:19:42 --> Language Class Initialized
INFO - 2021-06-03 15:19:42 --> Loader Class Initialized
INFO - 2021-06-03 15:19:42 --> Helper loaded: url_helper
INFO - 2021-06-03 15:19:42 --> Helper loaded: form_helper
INFO - 2021-06-03 15:19:42 --> Helper loaded: common_helper
INFO - 2021-06-03 15:19:42 --> Database Driver Class Initialized
DEBUG - 2021-06-03 15:19:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 15:19:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 15:19:42 --> Controller Class Initialized
INFO - 2021-06-03 15:19:42 --> Form Validation Class Initialized
DEBUG - 2021-06-03 15:19:42 --> Encrypt Class Initialized
INFO - 2021-06-03 15:19:42 --> Model "Login_model" initialized
INFO - 2021-06-03 15:19:42 --> Model "Dashboard_model" initialized
INFO - 2021-06-03 15:19:42 --> Model "Case_model" initialized
INFO - 2021-06-03 15:19:45 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/header.php
INFO - 2021-06-03 15:19:51 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/dashboard/index.php
INFO - 2021-06-03 15:19:51 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/footer.php
INFO - 2021-06-03 15:19:51 --> Final output sent to browser
DEBUG - 2021-06-03 15:19:51 --> Total execution time: 8.8656
ERROR - 2021-06-03 15:19:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-03 15:19:52 --> Config Class Initialized
INFO - 2021-06-03 15:19:52 --> Hooks Class Initialized
DEBUG - 2021-06-03 15:19:52 --> UTF-8 Support Enabled
INFO - 2021-06-03 15:19:52 --> Utf8 Class Initialized
INFO - 2021-06-03 15:19:52 --> URI Class Initialized
INFO - 2021-06-03 15:19:52 --> Router Class Initialized
INFO - 2021-06-03 15:19:52 --> Output Class Initialized
INFO - 2021-06-03 15:19:52 --> Security Class Initialized
DEBUG - 2021-06-03 15:19:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 15:19:52 --> Input Class Initialized
INFO - 2021-06-03 15:19:52 --> Language Class Initialized
ERROR - 2021-06-03 15:19:52 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-06-03 15:24:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-03 15:24:19 --> Config Class Initialized
INFO - 2021-06-03 15:24:19 --> Hooks Class Initialized
DEBUG - 2021-06-03 15:24:19 --> UTF-8 Support Enabled
INFO - 2021-06-03 15:24:19 --> Utf8 Class Initialized
INFO - 2021-06-03 15:24:19 --> URI Class Initialized
INFO - 2021-06-03 15:24:19 --> Router Class Initialized
INFO - 2021-06-03 15:24:19 --> Output Class Initialized
INFO - 2021-06-03 15:24:19 --> Security Class Initialized
DEBUG - 2021-06-03 15:24:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 15:24:19 --> Input Class Initialized
INFO - 2021-06-03 15:24:19 --> Language Class Initialized
INFO - 2021-06-03 15:24:19 --> Loader Class Initialized
INFO - 2021-06-03 15:24:19 --> Helper loaded: url_helper
INFO - 2021-06-03 15:24:19 --> Helper loaded: form_helper
INFO - 2021-06-03 15:24:19 --> Helper loaded: common_helper
INFO - 2021-06-03 15:24:19 --> Database Driver Class Initialized
DEBUG - 2021-06-03 15:24:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 15:24:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 15:24:19 --> Controller Class Initialized
INFO - 2021-06-03 15:24:19 --> Form Validation Class Initialized
DEBUG - 2021-06-03 15:24:19 --> Encrypt Class Initialized
INFO - 2021-06-03 15:24:19 --> Model "Login_model" initialized
INFO - 2021-06-03 15:24:19 --> Model "Dashboard_model" initialized
INFO - 2021-06-03 15:24:19 --> Model "Case_model" initialized
INFO - 2021-06-03 15:24:22 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/header.php
INFO - 2021-06-03 15:24:28 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/dashboard/index.php
INFO - 2021-06-03 15:24:28 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/footer.php
INFO - 2021-06-03 15:24:28 --> Final output sent to browser
DEBUG - 2021-06-03 15:24:28 --> Total execution time: 8.7861
ERROR - 2021-06-03 15:24:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-03 15:24:30 --> Config Class Initialized
INFO - 2021-06-03 15:24:30 --> Hooks Class Initialized
DEBUG - 2021-06-03 15:24:30 --> UTF-8 Support Enabled
INFO - 2021-06-03 15:24:30 --> Utf8 Class Initialized
INFO - 2021-06-03 15:24:30 --> URI Class Initialized
INFO - 2021-06-03 15:24:30 --> Router Class Initialized
INFO - 2021-06-03 15:24:30 --> Output Class Initialized
INFO - 2021-06-03 15:24:30 --> Security Class Initialized
DEBUG - 2021-06-03 15:24:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 15:24:30 --> Input Class Initialized
INFO - 2021-06-03 15:24:30 --> Language Class Initialized
ERROR - 2021-06-03 15:24:30 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-06-03 15:54:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-03 15:54:05 --> Config Class Initialized
INFO - 2021-06-03 15:54:05 --> Hooks Class Initialized
DEBUG - 2021-06-03 15:54:05 --> UTF-8 Support Enabled
INFO - 2021-06-03 15:54:05 --> Utf8 Class Initialized
INFO - 2021-06-03 15:54:05 --> URI Class Initialized
DEBUG - 2021-06-03 15:54:05 --> No URI present. Default controller set.
INFO - 2021-06-03 15:54:05 --> Router Class Initialized
INFO - 2021-06-03 15:54:05 --> Output Class Initialized
INFO - 2021-06-03 15:54:05 --> Security Class Initialized
DEBUG - 2021-06-03 15:54:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 15:54:05 --> Input Class Initialized
INFO - 2021-06-03 15:54:05 --> Language Class Initialized
INFO - 2021-06-03 15:54:05 --> Loader Class Initialized
INFO - 2021-06-03 15:54:05 --> Helper loaded: url_helper
INFO - 2021-06-03 15:54:05 --> Helper loaded: form_helper
INFO - 2021-06-03 15:54:05 --> Helper loaded: common_helper
INFO - 2021-06-03 15:54:05 --> Database Driver Class Initialized
DEBUG - 2021-06-03 15:54:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 15:54:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 15:54:05 --> Controller Class Initialized
INFO - 2021-06-03 15:54:05 --> Form Validation Class Initialized
DEBUG - 2021-06-03 15:54:05 --> Encrypt Class Initialized
DEBUG - 2021-06-03 15:54:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-06-03 15:54:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-06-03 15:54:05 --> Email Class Initialized
INFO - 2021-06-03 15:54:05 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-06-03 15:54:05 --> Calendar Class Initialized
INFO - 2021-06-03 15:54:05 --> Model "Login_model" initialized
ERROR - 2021-06-03 15:54:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-03 15:54:06 --> Config Class Initialized
INFO - 2021-06-03 15:54:06 --> Hooks Class Initialized
DEBUG - 2021-06-03 15:54:06 --> UTF-8 Support Enabled
INFO - 2021-06-03 15:54:06 --> Utf8 Class Initialized
INFO - 2021-06-03 15:54:06 --> URI Class Initialized
INFO - 2021-06-03 15:54:06 --> Router Class Initialized
INFO - 2021-06-03 15:54:06 --> Output Class Initialized
INFO - 2021-06-03 15:54:06 --> Security Class Initialized
DEBUG - 2021-06-03 15:54:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 15:54:06 --> Input Class Initialized
INFO - 2021-06-03 15:54:06 --> Language Class Initialized
INFO - 2021-06-03 15:54:06 --> Loader Class Initialized
INFO - 2021-06-03 15:54:06 --> Helper loaded: url_helper
INFO - 2021-06-03 15:54:06 --> Helper loaded: form_helper
INFO - 2021-06-03 15:54:06 --> Helper loaded: common_helper
INFO - 2021-06-03 15:54:06 --> Database Driver Class Initialized
DEBUG - 2021-06-03 15:54:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 15:54:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 15:54:06 --> Controller Class Initialized
INFO - 2021-06-03 15:54:06 --> Form Validation Class Initialized
DEBUG - 2021-06-03 15:54:06 --> Encrypt Class Initialized
INFO - 2021-06-03 15:54:06 --> Model "Diseases_model" initialized
INFO - 2021-06-03 15:54:06 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/header.php
INFO - 2021-06-03 15:54:06 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/diseases/index.php
INFO - 2021-06-03 15:54:06 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/footer.php
INFO - 2021-06-03 15:54:06 --> Final output sent to browser
DEBUG - 2021-06-03 15:54:06 --> Total execution time: 0.0186
ERROR - 2021-06-03 15:54:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-03 15:54:06 --> Config Class Initialized
INFO - 2021-06-03 15:54:06 --> Hooks Class Initialized
DEBUG - 2021-06-03 15:54:06 --> UTF-8 Support Enabled
INFO - 2021-06-03 15:54:06 --> Utf8 Class Initialized
INFO - 2021-06-03 15:54:06 --> URI Class Initialized
INFO - 2021-06-03 15:54:06 --> Router Class Initialized
INFO - 2021-06-03 15:54:06 --> Output Class Initialized
INFO - 2021-06-03 15:54:06 --> Security Class Initialized
DEBUG - 2021-06-03 15:54:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 15:54:06 --> Input Class Initialized
INFO - 2021-06-03 15:54:06 --> Language Class Initialized
ERROR - 2021-06-03 15:54:06 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-06-03 15:54:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-03 15:54:11 --> Config Class Initialized
INFO - 2021-06-03 15:54:11 --> Hooks Class Initialized
DEBUG - 2021-06-03 15:54:11 --> UTF-8 Support Enabled
INFO - 2021-06-03 15:54:11 --> Utf8 Class Initialized
INFO - 2021-06-03 15:54:11 --> URI Class Initialized
DEBUG - 2021-06-03 15:54:11 --> No URI present. Default controller set.
INFO - 2021-06-03 15:54:11 --> Router Class Initialized
INFO - 2021-06-03 15:54:11 --> Output Class Initialized
INFO - 2021-06-03 15:54:11 --> Security Class Initialized
DEBUG - 2021-06-03 15:54:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 15:54:11 --> Input Class Initialized
INFO - 2021-06-03 15:54:11 --> Language Class Initialized
INFO - 2021-06-03 15:54:11 --> Loader Class Initialized
INFO - 2021-06-03 15:54:11 --> Helper loaded: url_helper
INFO - 2021-06-03 15:54:11 --> Helper loaded: form_helper
INFO - 2021-06-03 15:54:11 --> Helper loaded: common_helper
INFO - 2021-06-03 15:54:11 --> Database Driver Class Initialized
DEBUG - 2021-06-03 15:54:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 15:54:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 15:54:11 --> Controller Class Initialized
INFO - 2021-06-03 15:54:11 --> Form Validation Class Initialized
DEBUG - 2021-06-03 15:54:11 --> Encrypt Class Initialized
DEBUG - 2021-06-03 15:54:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-06-03 15:54:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-06-03 15:54:11 --> Email Class Initialized
INFO - 2021-06-03 15:54:11 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-06-03 15:54:11 --> Calendar Class Initialized
INFO - 2021-06-03 15:54:11 --> Model "Login_model" initialized
ERROR - 2021-06-03 15:54:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-03 15:54:11 --> Config Class Initialized
INFO - 2021-06-03 15:54:11 --> Hooks Class Initialized
DEBUG - 2021-06-03 15:54:11 --> UTF-8 Support Enabled
INFO - 2021-06-03 15:54:11 --> Utf8 Class Initialized
INFO - 2021-06-03 15:54:11 --> URI Class Initialized
INFO - 2021-06-03 15:54:11 --> Router Class Initialized
INFO - 2021-06-03 15:54:11 --> Output Class Initialized
INFO - 2021-06-03 15:54:11 --> Security Class Initialized
DEBUG - 2021-06-03 15:54:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 15:54:11 --> Input Class Initialized
INFO - 2021-06-03 15:54:11 --> Language Class Initialized
ERROR - 2021-06-03 15:54:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 15:54:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-03 15:54:12 --> Config Class Initialized
INFO - 2021-06-03 15:54:12 --> Hooks Class Initialized
DEBUG - 2021-06-03 15:54:12 --> UTF-8 Support Enabled
INFO - 2021-06-03 15:54:12 --> Utf8 Class Initialized
INFO - 2021-06-03 15:54:12 --> URI Class Initialized
INFO - 2021-06-03 15:54:12 --> Router Class Initialized
INFO - 2021-06-03 15:54:12 --> Output Class Initialized
INFO - 2021-06-03 15:54:12 --> Security Class Initialized
DEBUG - 2021-06-03 15:54:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 15:54:12 --> Input Class Initialized
INFO - 2021-06-03 15:54:12 --> Language Class Initialized
INFO - 2021-06-03 15:54:12 --> Loader Class Initialized
INFO - 2021-06-03 15:54:12 --> Helper loaded: url_helper
INFO - 2021-06-03 15:54:12 --> Helper loaded: form_helper
INFO - 2021-06-03 15:54:12 --> Helper loaded: common_helper
INFO - 2021-06-03 15:54:12 --> Database Driver Class Initialized
DEBUG - 2021-06-03 15:54:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 15:54:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 15:54:12 --> Controller Class Initialized
INFO - 2021-06-03 15:54:12 --> Form Validation Class Initialized
DEBUG - 2021-06-03 15:54:12 --> Encrypt Class Initialized
INFO - 2021-06-03 15:54:12 --> Model "Diseases_model" initialized
INFO - 2021-06-03 15:54:12 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/header.php
INFO - 2021-06-03 15:54:12 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/diseases/index.php
INFO - 2021-06-03 15:54:12 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/footer.php
INFO - 2021-06-03 15:54:12 --> Final output sent to browser
DEBUG - 2021-06-03 15:54:12 --> Total execution time: 0.0241
ERROR - 2021-06-03 15:54:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-03 15:54:24 --> Config Class Initialized
INFO - 2021-06-03 15:54:24 --> Hooks Class Initialized
DEBUG - 2021-06-03 15:54:24 --> UTF-8 Support Enabled
INFO - 2021-06-03 15:54:24 --> Utf8 Class Initialized
INFO - 2021-06-03 15:54:24 --> URI Class Initialized
INFO - 2021-06-03 15:54:24 --> Router Class Initialized
INFO - 2021-06-03 15:54:24 --> Output Class Initialized
INFO - 2021-06-03 15:54:24 --> Security Class Initialized
DEBUG - 2021-06-03 15:54:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 15:54:24 --> Input Class Initialized
INFO - 2021-06-03 15:54:24 --> Language Class Initialized
INFO - 2021-06-03 15:54:24 --> Loader Class Initialized
INFO - 2021-06-03 15:54:24 --> Helper loaded: url_helper
INFO - 2021-06-03 15:54:24 --> Helper loaded: form_helper
INFO - 2021-06-03 15:54:24 --> Helper loaded: common_helper
INFO - 2021-06-03 15:54:24 --> Database Driver Class Initialized
DEBUG - 2021-06-03 15:54:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 15:54:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 15:54:24 --> Controller Class Initialized
INFO - 2021-06-03 15:54:24 --> Form Validation Class Initialized
INFO - 2021-06-03 15:54:24 --> Model "Case_model" initialized
INFO - 2021-06-03 15:54:24 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/header.php
INFO - 2021-06-03 15:54:24 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/transaction/refund_amount.php
INFO - 2021-06-03 15:54:24 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/footer.php
INFO - 2021-06-03 15:54:24 --> Final output sent to browser
DEBUG - 2021-06-03 15:54:24 --> Total execution time: 0.0259
ERROR - 2021-06-03 15:54:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-03 15:54:25 --> Config Class Initialized
INFO - 2021-06-03 15:54:25 --> Hooks Class Initialized
DEBUG - 2021-06-03 15:54:25 --> UTF-8 Support Enabled
INFO - 2021-06-03 15:54:25 --> Utf8 Class Initialized
INFO - 2021-06-03 15:54:25 --> URI Class Initialized
INFO - 2021-06-03 15:54:25 --> Router Class Initialized
INFO - 2021-06-03 15:54:25 --> Output Class Initialized
INFO - 2021-06-03 15:54:25 --> Security Class Initialized
DEBUG - 2021-06-03 15:54:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 15:54:25 --> Input Class Initialized
INFO - 2021-06-03 15:54:25 --> Language Class Initialized
ERROR - 2021-06-03 15:54:25 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-06-03 15:54:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-03 15:54:35 --> Config Class Initialized
INFO - 2021-06-03 15:54:35 --> Hooks Class Initialized
DEBUG - 2021-06-03 15:54:35 --> UTF-8 Support Enabled
INFO - 2021-06-03 15:54:35 --> Utf8 Class Initialized
INFO - 2021-06-03 15:54:35 --> URI Class Initialized
INFO - 2021-06-03 15:54:35 --> Router Class Initialized
INFO - 2021-06-03 15:54:35 --> Output Class Initialized
INFO - 2021-06-03 15:54:35 --> Security Class Initialized
DEBUG - 2021-06-03 15:54:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 15:54:35 --> Input Class Initialized
INFO - 2021-06-03 15:54:35 --> Language Class Initialized
INFO - 2021-06-03 15:54:35 --> Loader Class Initialized
INFO - 2021-06-03 15:54:35 --> Helper loaded: url_helper
INFO - 2021-06-03 15:54:35 --> Helper loaded: form_helper
INFO - 2021-06-03 15:54:35 --> Helper loaded: common_helper
INFO - 2021-06-03 15:54:35 --> Database Driver Class Initialized
DEBUG - 2021-06-03 15:54:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 15:54:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 15:54:35 --> Controller Class Initialized
INFO - 2021-06-03 15:54:35 --> Form Validation Class Initialized
INFO - 2021-06-03 15:54:35 --> Model "Report_model" initialized
INFO - 2021-06-03 15:54:35 --> Model "Case_model" initialized
INFO - 2021-06-03 15:54:35 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/header.php
INFO - 2021-06-03 15:54:35 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/reports/patient_details.php
INFO - 2021-06-03 15:54:35 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/footer.php
INFO - 2021-06-03 15:54:35 --> Final output sent to browser
DEBUG - 2021-06-03 15:54:35 --> Total execution time: 0.0193
ERROR - 2021-06-03 15:54:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-03 15:54:36 --> Config Class Initialized
INFO - 2021-06-03 15:54:36 --> Hooks Class Initialized
DEBUG - 2021-06-03 15:54:36 --> UTF-8 Support Enabled
INFO - 2021-06-03 15:54:36 --> Utf8 Class Initialized
INFO - 2021-06-03 15:54:36 --> URI Class Initialized
INFO - 2021-06-03 15:54:36 --> Router Class Initialized
INFO - 2021-06-03 15:54:36 --> Output Class Initialized
INFO - 2021-06-03 15:54:36 --> Security Class Initialized
DEBUG - 2021-06-03 15:54:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 15:54:36 --> Input Class Initialized
INFO - 2021-06-03 15:54:36 --> Language Class Initialized
ERROR - 2021-06-03 15:54:36 --> 404 Page Not Found: Karoclient/usersprofile
