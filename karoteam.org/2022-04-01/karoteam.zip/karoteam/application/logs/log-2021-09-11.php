<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-09-11 16:41:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-11 16:41:51 --> Config Class Initialized
INFO - 2021-09-11 16:41:51 --> Hooks Class Initialized
DEBUG - 2021-09-11 16:41:51 --> UTF-8 Support Enabled
INFO - 2021-09-11 16:41:51 --> Utf8 Class Initialized
INFO - 2021-09-11 16:41:51 --> URI Class Initialized
DEBUG - 2021-09-11 16:41:51 --> No URI present. Default controller set.
INFO - 2021-09-11 16:41:51 --> Router Class Initialized
INFO - 2021-09-11 16:41:51 --> Output Class Initialized
INFO - 2021-09-11 16:41:51 --> Security Class Initialized
DEBUG - 2021-09-11 16:41:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-11 16:41:51 --> Input Class Initialized
INFO - 2021-09-11 16:41:51 --> Language Class Initialized
INFO - 2021-09-11 16:41:51 --> Loader Class Initialized
INFO - 2021-09-11 16:41:51 --> Helper loaded: url_helper
INFO - 2021-09-11 16:41:51 --> Helper loaded: form_helper
INFO - 2021-09-11 16:41:51 --> Helper loaded: common_helper
INFO - 2021-09-11 16:41:52 --> Database Driver Class Initialized
DEBUG - 2021-09-11 16:41:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-11 16:41:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-11 16:41:52 --> Controller Class Initialized
INFO - 2021-09-11 16:41:52 --> Form Validation Class Initialized
DEBUG - 2021-09-11 16:41:52 --> Encrypt Class Initialized
DEBUG - 2021-09-11 16:41:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-09-11 16:41:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-09-11 16:41:52 --> Email Class Initialized
INFO - 2021-09-11 16:41:52 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-09-11 16:41:52 --> Calendar Class Initialized
INFO - 2021-09-11 16:41:52 --> Model "Login_model" initialized
INFO - 2021-09-11 16:41:52 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-09-11 16:41:52 --> Final output sent to browser
DEBUG - 2021-09-11 16:41:52 --> Total execution time: 0.0439
ERROR - 2021-09-11 16:41:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-11 16:41:52 --> Config Class Initialized
INFO - 2021-09-11 16:41:52 --> Hooks Class Initialized
DEBUG - 2021-09-11 16:41:52 --> UTF-8 Support Enabled
INFO - 2021-09-11 16:41:52 --> Utf8 Class Initialized
INFO - 2021-09-11 16:41:52 --> URI Class Initialized
DEBUG - 2021-09-11 16:41:52 --> No URI present. Default controller set.
INFO - 2021-09-11 16:41:52 --> Router Class Initialized
INFO - 2021-09-11 16:41:52 --> Output Class Initialized
INFO - 2021-09-11 16:41:52 --> Security Class Initialized
DEBUG - 2021-09-11 16:41:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-11 16:41:52 --> Input Class Initialized
INFO - 2021-09-11 16:41:52 --> Language Class Initialized
INFO - 2021-09-11 16:41:52 --> Loader Class Initialized
INFO - 2021-09-11 16:41:52 --> Helper loaded: url_helper
INFO - 2021-09-11 16:41:52 --> Helper loaded: form_helper
INFO - 2021-09-11 16:41:52 --> Helper loaded: common_helper
INFO - 2021-09-11 16:41:52 --> Database Driver Class Initialized
DEBUG - 2021-09-11 16:41:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-11 16:41:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-11 16:41:52 --> Controller Class Initialized
INFO - 2021-09-11 16:41:52 --> Form Validation Class Initialized
DEBUG - 2021-09-11 16:41:52 --> Encrypt Class Initialized
DEBUG - 2021-09-11 16:41:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-09-11 16:41:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-09-11 16:41:52 --> Email Class Initialized
INFO - 2021-09-11 16:41:52 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-09-11 16:41:52 --> Calendar Class Initialized
INFO - 2021-09-11 16:41:52 --> Model "Login_model" initialized
INFO - 2021-09-11 16:41:52 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-09-11 16:41:52 --> Final output sent to browser
DEBUG - 2021-09-11 16:41:52 --> Total execution time: 0.0220
ERROR - 2021-09-11 16:41:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-11 16:41:52 --> Config Class Initialized
INFO - 2021-09-11 16:41:52 --> Hooks Class Initialized
DEBUG - 2021-09-11 16:41:52 --> UTF-8 Support Enabled
INFO - 2021-09-11 16:41:52 --> Utf8 Class Initialized
INFO - 2021-09-11 16:41:52 --> URI Class Initialized
INFO - 2021-09-11 16:41:52 --> Router Class Initialized
INFO - 2021-09-11 16:41:52 --> Output Class Initialized
INFO - 2021-09-11 16:41:52 --> Security Class Initialized
DEBUG - 2021-09-11 16:41:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-11 16:41:52 --> Input Class Initialized
INFO - 2021-09-11 16:41:52 --> Language Class Initialized
ERROR - 2021-09-11 16:41:52 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
ERROR - 2021-09-11 16:41:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-11 16:41:53 --> Config Class Initialized
INFO - 2021-09-11 16:41:53 --> Hooks Class Initialized
DEBUG - 2021-09-11 16:41:53 --> UTF-8 Support Enabled
INFO - 2021-09-11 16:41:53 --> Utf8 Class Initialized
INFO - 2021-09-11 16:41:53 --> URI Class Initialized
DEBUG - 2021-09-11 16:41:53 --> No URI present. Default controller set.
INFO - 2021-09-11 16:41:53 --> Router Class Initialized
INFO - 2021-09-11 16:41:53 --> Output Class Initialized
INFO - 2021-09-11 16:41:53 --> Security Class Initialized
DEBUG - 2021-09-11 16:41:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-11 16:41:53 --> Input Class Initialized
INFO - 2021-09-11 16:41:53 --> Language Class Initialized
INFO - 2021-09-11 16:41:53 --> Loader Class Initialized
INFO - 2021-09-11 16:41:53 --> Helper loaded: url_helper
INFO - 2021-09-11 16:41:53 --> Helper loaded: form_helper
INFO - 2021-09-11 16:41:53 --> Helper loaded: common_helper
INFO - 2021-09-11 16:41:53 --> Database Driver Class Initialized
DEBUG - 2021-09-11 16:41:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-11 16:41:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-11 16:41:53 --> Controller Class Initialized
INFO - 2021-09-11 16:41:53 --> Form Validation Class Initialized
DEBUG - 2021-09-11 16:41:53 --> Encrypt Class Initialized
DEBUG - 2021-09-11 16:41:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-09-11 16:41:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-09-11 16:41:53 --> Email Class Initialized
INFO - 2021-09-11 16:41:53 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-09-11 16:41:53 --> Calendar Class Initialized
INFO - 2021-09-11 16:41:53 --> Model "Login_model" initialized
INFO - 2021-09-11 16:41:53 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-09-11 16:41:53 --> Final output sent to browser
DEBUG - 2021-09-11 16:41:53 --> Total execution time: 0.0251
ERROR - 2021-09-11 16:41:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-11 16:41:53 --> Config Class Initialized
INFO - 2021-09-11 16:41:53 --> Hooks Class Initialized
DEBUG - 2021-09-11 16:41:53 --> UTF-8 Support Enabled
INFO - 2021-09-11 16:41:53 --> Utf8 Class Initialized
INFO - 2021-09-11 16:41:53 --> URI Class Initialized
INFO - 2021-09-11 16:41:53 --> Router Class Initialized
INFO - 2021-09-11 16:41:53 --> Output Class Initialized
INFO - 2021-09-11 16:41:53 --> Security Class Initialized
DEBUG - 2021-09-11 16:41:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-11 16:41:53 --> Input Class Initialized
INFO - 2021-09-11 16:41:53 --> Language Class Initialized
ERROR - 2021-09-11 16:41:53 --> 404 Page Not Found: Blog/wp-includes
ERROR - 2021-09-11 16:41:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-11 16:41:54 --> Config Class Initialized
INFO - 2021-09-11 16:41:54 --> Hooks Class Initialized
DEBUG - 2021-09-11 16:41:54 --> UTF-8 Support Enabled
INFO - 2021-09-11 16:41:54 --> Utf8 Class Initialized
INFO - 2021-09-11 16:41:54 --> URI Class Initialized
INFO - 2021-09-11 16:41:54 --> Router Class Initialized
INFO - 2021-09-11 16:41:54 --> Output Class Initialized
INFO - 2021-09-11 16:41:54 --> Security Class Initialized
DEBUG - 2021-09-11 16:41:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-11 16:41:54 --> Input Class Initialized
INFO - 2021-09-11 16:41:54 --> Language Class Initialized
ERROR - 2021-09-11 16:41:54 --> 404 Page Not Found: Web/wp-includes
ERROR - 2021-09-11 16:41:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-11 16:41:54 --> Config Class Initialized
INFO - 2021-09-11 16:41:54 --> Hooks Class Initialized
DEBUG - 2021-09-11 16:41:54 --> UTF-8 Support Enabled
INFO - 2021-09-11 16:41:54 --> Utf8 Class Initialized
INFO - 2021-09-11 16:41:54 --> URI Class Initialized
INFO - 2021-09-11 16:41:54 --> Router Class Initialized
INFO - 2021-09-11 16:41:54 --> Output Class Initialized
INFO - 2021-09-11 16:41:54 --> Security Class Initialized
DEBUG - 2021-09-11 16:41:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-11 16:41:54 --> Input Class Initialized
INFO - 2021-09-11 16:41:54 --> Language Class Initialized
ERROR - 2021-09-11 16:41:54 --> 404 Page Not Found: Wordpress/wp-includes
ERROR - 2021-09-11 16:41:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-11 16:41:55 --> Config Class Initialized
INFO - 2021-09-11 16:41:55 --> Hooks Class Initialized
DEBUG - 2021-09-11 16:41:55 --> UTF-8 Support Enabled
INFO - 2021-09-11 16:41:55 --> Utf8 Class Initialized
INFO - 2021-09-11 16:41:55 --> URI Class Initialized
INFO - 2021-09-11 16:41:55 --> Router Class Initialized
INFO - 2021-09-11 16:41:55 --> Output Class Initialized
INFO - 2021-09-11 16:41:55 --> Security Class Initialized
DEBUG - 2021-09-11 16:41:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-11 16:41:55 --> Input Class Initialized
INFO - 2021-09-11 16:41:55 --> Language Class Initialized
ERROR - 2021-09-11 16:41:55 --> 404 Page Not Found: Website/wp-includes
ERROR - 2021-09-11 16:41:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-11 16:41:55 --> Config Class Initialized
INFO - 2021-09-11 16:41:55 --> Hooks Class Initialized
DEBUG - 2021-09-11 16:41:55 --> UTF-8 Support Enabled
INFO - 2021-09-11 16:41:55 --> Utf8 Class Initialized
INFO - 2021-09-11 16:41:55 --> URI Class Initialized
INFO - 2021-09-11 16:41:55 --> Router Class Initialized
INFO - 2021-09-11 16:41:55 --> Output Class Initialized
INFO - 2021-09-11 16:41:55 --> Security Class Initialized
DEBUG - 2021-09-11 16:41:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-11 16:41:55 --> Input Class Initialized
INFO - 2021-09-11 16:41:55 --> Language Class Initialized
ERROR - 2021-09-11 16:41:55 --> 404 Page Not Found: Wp/wp-includes
ERROR - 2021-09-11 16:41:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-11 16:41:56 --> Config Class Initialized
INFO - 2021-09-11 16:41:56 --> Hooks Class Initialized
DEBUG - 2021-09-11 16:41:56 --> UTF-8 Support Enabled
INFO - 2021-09-11 16:41:56 --> Utf8 Class Initialized
INFO - 2021-09-11 16:41:56 --> URI Class Initialized
INFO - 2021-09-11 16:41:56 --> Router Class Initialized
INFO - 2021-09-11 16:41:56 --> Output Class Initialized
INFO - 2021-09-11 16:41:56 --> Security Class Initialized
DEBUG - 2021-09-11 16:41:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-11 16:41:56 --> Input Class Initialized
INFO - 2021-09-11 16:41:56 --> Language Class Initialized
ERROR - 2021-09-11 16:41:56 --> 404 Page Not Found: News/wp-includes
ERROR - 2021-09-11 16:41:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-11 16:41:56 --> Config Class Initialized
INFO - 2021-09-11 16:41:56 --> Hooks Class Initialized
DEBUG - 2021-09-11 16:41:56 --> UTF-8 Support Enabled
INFO - 2021-09-11 16:41:56 --> Utf8 Class Initialized
INFO - 2021-09-11 16:41:56 --> URI Class Initialized
INFO - 2021-09-11 16:41:56 --> Router Class Initialized
INFO - 2021-09-11 16:41:56 --> Output Class Initialized
INFO - 2021-09-11 16:41:56 --> Security Class Initialized
DEBUG - 2021-09-11 16:41:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-11 16:41:56 --> Input Class Initialized
INFO - 2021-09-11 16:41:56 --> Language Class Initialized
ERROR - 2021-09-11 16:41:56 --> 404 Page Not Found: 2018/wp-includes
ERROR - 2021-09-11 16:41:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-11 16:41:56 --> Config Class Initialized
INFO - 2021-09-11 16:41:56 --> Hooks Class Initialized
DEBUG - 2021-09-11 16:41:56 --> UTF-8 Support Enabled
INFO - 2021-09-11 16:41:56 --> Utf8 Class Initialized
INFO - 2021-09-11 16:41:56 --> URI Class Initialized
INFO - 2021-09-11 16:41:56 --> Router Class Initialized
INFO - 2021-09-11 16:41:56 --> Output Class Initialized
INFO - 2021-09-11 16:41:56 --> Security Class Initialized
DEBUG - 2021-09-11 16:41:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-11 16:41:56 --> Input Class Initialized
INFO - 2021-09-11 16:41:56 --> Language Class Initialized
ERROR - 2021-09-11 16:41:56 --> 404 Page Not Found: 2019/wp-includes
ERROR - 2021-09-11 16:41:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-11 16:41:57 --> Config Class Initialized
INFO - 2021-09-11 16:41:57 --> Hooks Class Initialized
DEBUG - 2021-09-11 16:41:57 --> UTF-8 Support Enabled
INFO - 2021-09-11 16:41:57 --> Utf8 Class Initialized
INFO - 2021-09-11 16:41:57 --> URI Class Initialized
INFO - 2021-09-11 16:41:57 --> Router Class Initialized
INFO - 2021-09-11 16:41:57 --> Output Class Initialized
INFO - 2021-09-11 16:41:57 --> Security Class Initialized
DEBUG - 2021-09-11 16:41:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-11 16:41:57 --> Input Class Initialized
INFO - 2021-09-11 16:41:57 --> Language Class Initialized
ERROR - 2021-09-11 16:41:57 --> 404 Page Not Found: Shop/wp-includes
ERROR - 2021-09-11 16:41:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-11 16:41:57 --> Config Class Initialized
INFO - 2021-09-11 16:41:57 --> Hooks Class Initialized
DEBUG - 2021-09-11 16:41:57 --> UTF-8 Support Enabled
INFO - 2021-09-11 16:41:57 --> Utf8 Class Initialized
INFO - 2021-09-11 16:41:57 --> URI Class Initialized
INFO - 2021-09-11 16:41:57 --> Router Class Initialized
INFO - 2021-09-11 16:41:57 --> Output Class Initialized
INFO - 2021-09-11 16:41:57 --> Security Class Initialized
DEBUG - 2021-09-11 16:41:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-11 16:41:57 --> Input Class Initialized
INFO - 2021-09-11 16:41:57 --> Language Class Initialized
ERROR - 2021-09-11 16:41:57 --> 404 Page Not Found: Wp1/wp-includes
ERROR - 2021-09-11 16:41:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-11 16:41:58 --> Config Class Initialized
INFO - 2021-09-11 16:41:58 --> Hooks Class Initialized
DEBUG - 2021-09-11 16:41:58 --> UTF-8 Support Enabled
INFO - 2021-09-11 16:41:58 --> Utf8 Class Initialized
INFO - 2021-09-11 16:41:58 --> URI Class Initialized
INFO - 2021-09-11 16:41:58 --> Router Class Initialized
INFO - 2021-09-11 16:41:58 --> Output Class Initialized
INFO - 2021-09-11 16:41:58 --> Security Class Initialized
DEBUG - 2021-09-11 16:41:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-11 16:41:58 --> Input Class Initialized
INFO - 2021-09-11 16:41:58 --> Language Class Initialized
ERROR - 2021-09-11 16:41:58 --> 404 Page Not Found: Test/wp-includes
ERROR - 2021-09-11 16:41:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-11 16:41:58 --> Config Class Initialized
INFO - 2021-09-11 16:41:58 --> Hooks Class Initialized
DEBUG - 2021-09-11 16:41:58 --> UTF-8 Support Enabled
INFO - 2021-09-11 16:41:58 --> Utf8 Class Initialized
INFO - 2021-09-11 16:41:58 --> URI Class Initialized
INFO - 2021-09-11 16:41:58 --> Router Class Initialized
INFO - 2021-09-11 16:41:58 --> Output Class Initialized
INFO - 2021-09-11 16:41:58 --> Security Class Initialized
DEBUG - 2021-09-11 16:41:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-11 16:41:58 --> Input Class Initialized
INFO - 2021-09-11 16:41:58 --> Language Class Initialized
ERROR - 2021-09-11 16:41:58 --> 404 Page Not Found: Media/wp-includes
ERROR - 2021-09-11 16:41:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-11 16:41:58 --> Config Class Initialized
INFO - 2021-09-11 16:41:58 --> Hooks Class Initialized
DEBUG - 2021-09-11 16:41:58 --> UTF-8 Support Enabled
INFO - 2021-09-11 16:41:58 --> Utf8 Class Initialized
INFO - 2021-09-11 16:41:58 --> URI Class Initialized
INFO - 2021-09-11 16:41:58 --> Router Class Initialized
INFO - 2021-09-11 16:41:58 --> Output Class Initialized
INFO - 2021-09-11 16:41:58 --> Security Class Initialized
DEBUG - 2021-09-11 16:41:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-11 16:41:58 --> Input Class Initialized
INFO - 2021-09-11 16:41:58 --> Language Class Initialized
ERROR - 2021-09-11 16:41:58 --> 404 Page Not Found: Wp2/wp-includes
ERROR - 2021-09-11 16:41:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-11 16:41:59 --> Config Class Initialized
INFO - 2021-09-11 16:41:59 --> Hooks Class Initialized
DEBUG - 2021-09-11 16:41:59 --> UTF-8 Support Enabled
INFO - 2021-09-11 16:41:59 --> Utf8 Class Initialized
INFO - 2021-09-11 16:41:59 --> URI Class Initialized
INFO - 2021-09-11 16:41:59 --> Router Class Initialized
INFO - 2021-09-11 16:41:59 --> Output Class Initialized
INFO - 2021-09-11 16:41:59 --> Security Class Initialized
DEBUG - 2021-09-11 16:41:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-11 16:41:59 --> Input Class Initialized
INFO - 2021-09-11 16:41:59 --> Language Class Initialized
ERROR - 2021-09-11 16:41:59 --> 404 Page Not Found: Site/wp-includes
ERROR - 2021-09-11 16:41:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-11 16:41:59 --> Config Class Initialized
INFO - 2021-09-11 16:41:59 --> Hooks Class Initialized
DEBUG - 2021-09-11 16:41:59 --> UTF-8 Support Enabled
INFO - 2021-09-11 16:41:59 --> Utf8 Class Initialized
INFO - 2021-09-11 16:41:59 --> URI Class Initialized
INFO - 2021-09-11 16:41:59 --> Router Class Initialized
INFO - 2021-09-11 16:41:59 --> Output Class Initialized
INFO - 2021-09-11 16:41:59 --> Security Class Initialized
DEBUG - 2021-09-11 16:41:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-11 16:41:59 --> Input Class Initialized
INFO - 2021-09-11 16:41:59 --> Language Class Initialized
ERROR - 2021-09-11 16:41:59 --> 404 Page Not Found: Cms/wp-includes
ERROR - 2021-09-11 16:42:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-11 16:42:00 --> Config Class Initialized
INFO - 2021-09-11 16:42:00 --> Hooks Class Initialized
DEBUG - 2021-09-11 16:42:00 --> UTF-8 Support Enabled
INFO - 2021-09-11 16:42:00 --> Utf8 Class Initialized
INFO - 2021-09-11 16:42:00 --> URI Class Initialized
INFO - 2021-09-11 16:42:00 --> Router Class Initialized
INFO - 2021-09-11 16:42:00 --> Output Class Initialized
INFO - 2021-09-11 16:42:00 --> Security Class Initialized
DEBUG - 2021-09-11 16:42:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-11 16:42:00 --> Input Class Initialized
INFO - 2021-09-11 16:42:00 --> Language Class Initialized
ERROR - 2021-09-11 16:42:00 --> 404 Page Not Found: Sito/wp-includes
