<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-11-26 00:55:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-26 00:55:20 --> Config Class Initialized
INFO - 2021-11-26 00:55:20 --> Hooks Class Initialized
DEBUG - 2021-11-26 00:55:20 --> UTF-8 Support Enabled
INFO - 2021-11-26 00:55:20 --> Utf8 Class Initialized
INFO - 2021-11-26 00:55:20 --> URI Class Initialized
DEBUG - 2021-11-26 00:55:20 --> No URI present. Default controller set.
INFO - 2021-11-26 00:55:20 --> Router Class Initialized
INFO - 2021-11-26 00:55:20 --> Output Class Initialized
INFO - 2021-11-26 00:55:20 --> Security Class Initialized
DEBUG - 2021-11-26 00:55:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-26 00:55:20 --> Input Class Initialized
INFO - 2021-11-26 00:55:20 --> Language Class Initialized
INFO - 2021-11-26 00:55:20 --> Loader Class Initialized
INFO - 2021-11-26 00:55:20 --> Helper loaded: url_helper
INFO - 2021-11-26 00:55:20 --> Helper loaded: form_helper
INFO - 2021-11-26 00:55:20 --> Helper loaded: common_helper
INFO - 2021-11-26 00:55:20 --> Database Driver Class Initialized
DEBUG - 2021-11-26 00:55:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-26 00:55:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-26 00:55:20 --> Controller Class Initialized
INFO - 2021-11-26 00:55:20 --> Form Validation Class Initialized
DEBUG - 2021-11-26 00:55:20 --> Encrypt Class Initialized
DEBUG - 2021-11-26 00:55:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-26 00:55:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-26 00:55:20 --> Email Class Initialized
INFO - 2021-11-26 00:55:20 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-26 00:55:20 --> Calendar Class Initialized
INFO - 2021-11-26 00:55:20 --> Model "Login_model" initialized
INFO - 2021-11-26 00:55:20 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-11-26 00:55:20 --> Final output sent to browser
DEBUG - 2021-11-26 00:55:20 --> Total execution time: 0.0237
ERROR - 2021-11-26 03:26:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-26 03:26:26 --> Config Class Initialized
INFO - 2021-11-26 03:26:26 --> Hooks Class Initialized
DEBUG - 2021-11-26 03:26:26 --> UTF-8 Support Enabled
INFO - 2021-11-26 03:26:26 --> Utf8 Class Initialized
INFO - 2021-11-26 03:26:26 --> URI Class Initialized
DEBUG - 2021-11-26 03:26:26 --> No URI present. Default controller set.
INFO - 2021-11-26 03:26:26 --> Router Class Initialized
INFO - 2021-11-26 03:26:26 --> Output Class Initialized
INFO - 2021-11-26 03:26:26 --> Security Class Initialized
DEBUG - 2021-11-26 03:26:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-26 03:26:26 --> Input Class Initialized
INFO - 2021-11-26 03:26:26 --> Language Class Initialized
INFO - 2021-11-26 03:26:26 --> Loader Class Initialized
INFO - 2021-11-26 03:26:26 --> Helper loaded: url_helper
INFO - 2021-11-26 03:26:26 --> Helper loaded: form_helper
INFO - 2021-11-26 03:26:26 --> Helper loaded: common_helper
INFO - 2021-11-26 03:26:26 --> Database Driver Class Initialized
DEBUG - 2021-11-26 03:26:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-26 03:26:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-26 03:26:26 --> Controller Class Initialized
INFO - 2021-11-26 03:26:26 --> Form Validation Class Initialized
DEBUG - 2021-11-26 03:26:26 --> Encrypt Class Initialized
DEBUG - 2021-11-26 03:26:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-26 03:26:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-26 03:26:26 --> Email Class Initialized
INFO - 2021-11-26 03:26:26 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-26 03:26:26 --> Calendar Class Initialized
INFO - 2021-11-26 03:26:26 --> Model "Login_model" initialized
INFO - 2021-11-26 03:26:26 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-11-26 03:26:26 --> Final output sent to browser
DEBUG - 2021-11-26 03:26:26 --> Total execution time: 0.0282
ERROR - 2021-11-26 03:30:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-26 03:30:14 --> Config Class Initialized
INFO - 2021-11-26 03:30:14 --> Hooks Class Initialized
DEBUG - 2021-11-26 03:30:14 --> UTF-8 Support Enabled
INFO - 2021-11-26 03:30:14 --> Utf8 Class Initialized
INFO - 2021-11-26 03:30:14 --> URI Class Initialized
DEBUG - 2021-11-26 03:30:14 --> No URI present. Default controller set.
INFO - 2021-11-26 03:30:14 --> Router Class Initialized
INFO - 2021-11-26 03:30:14 --> Output Class Initialized
INFO - 2021-11-26 03:30:14 --> Security Class Initialized
DEBUG - 2021-11-26 03:30:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-26 03:30:14 --> Input Class Initialized
INFO - 2021-11-26 03:30:14 --> Language Class Initialized
INFO - 2021-11-26 03:30:14 --> Loader Class Initialized
INFO - 2021-11-26 03:30:14 --> Helper loaded: url_helper
INFO - 2021-11-26 03:30:14 --> Helper loaded: form_helper
INFO - 2021-11-26 03:30:14 --> Helper loaded: common_helper
INFO - 2021-11-26 03:30:14 --> Database Driver Class Initialized
DEBUG - 2021-11-26 03:30:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-26 03:30:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-26 03:30:14 --> Controller Class Initialized
INFO - 2021-11-26 03:30:14 --> Form Validation Class Initialized
DEBUG - 2021-11-26 03:30:14 --> Encrypt Class Initialized
DEBUG - 2021-11-26 03:30:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-26 03:30:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-26 03:30:14 --> Email Class Initialized
INFO - 2021-11-26 03:30:14 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-26 03:30:14 --> Calendar Class Initialized
INFO - 2021-11-26 03:30:14 --> Model "Login_model" initialized
INFO - 2021-11-26 03:30:14 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-11-26 03:30:14 --> Final output sent to browser
DEBUG - 2021-11-26 03:30:14 --> Total execution time: 0.0299
ERROR - 2021-11-26 03:30:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-26 03:30:54 --> Config Class Initialized
INFO - 2021-11-26 03:30:54 --> Hooks Class Initialized
DEBUG - 2021-11-26 03:30:54 --> UTF-8 Support Enabled
INFO - 2021-11-26 03:30:54 --> Utf8 Class Initialized
INFO - 2021-11-26 03:30:54 --> URI Class Initialized
DEBUG - 2021-11-26 03:30:54 --> No URI present. Default controller set.
INFO - 2021-11-26 03:30:54 --> Router Class Initialized
INFO - 2021-11-26 03:30:54 --> Output Class Initialized
INFO - 2021-11-26 03:30:54 --> Security Class Initialized
DEBUG - 2021-11-26 03:30:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-26 03:30:54 --> Input Class Initialized
INFO - 2021-11-26 03:30:54 --> Language Class Initialized
INFO - 2021-11-26 03:30:54 --> Loader Class Initialized
INFO - 2021-11-26 03:30:54 --> Helper loaded: url_helper
INFO - 2021-11-26 03:30:54 --> Helper loaded: form_helper
INFO - 2021-11-26 03:30:54 --> Helper loaded: common_helper
INFO - 2021-11-26 03:30:54 --> Database Driver Class Initialized
DEBUG - 2021-11-26 03:30:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-26 03:30:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-26 03:30:54 --> Controller Class Initialized
INFO - 2021-11-26 03:30:54 --> Form Validation Class Initialized
DEBUG - 2021-11-26 03:30:54 --> Encrypt Class Initialized
DEBUG - 2021-11-26 03:30:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-26 03:30:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-26 03:30:54 --> Email Class Initialized
INFO - 2021-11-26 03:30:54 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-26 03:30:54 --> Calendar Class Initialized
INFO - 2021-11-26 03:30:54 --> Model "Login_model" initialized
INFO - 2021-11-26 03:30:54 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-11-26 03:30:54 --> Final output sent to browser
DEBUG - 2021-11-26 03:30:54 --> Total execution time: 0.0272
ERROR - 2021-11-26 03:31:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-26 03:31:17 --> Config Class Initialized
INFO - 2021-11-26 03:31:17 --> Hooks Class Initialized
DEBUG - 2021-11-26 03:31:17 --> UTF-8 Support Enabled
INFO - 2021-11-26 03:31:17 --> Utf8 Class Initialized
INFO - 2021-11-26 03:31:17 --> URI Class Initialized
DEBUG - 2021-11-26 03:31:17 --> No URI present. Default controller set.
INFO - 2021-11-26 03:31:17 --> Router Class Initialized
INFO - 2021-11-26 03:31:17 --> Output Class Initialized
INFO - 2021-11-26 03:31:17 --> Security Class Initialized
DEBUG - 2021-11-26 03:31:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-26 03:31:17 --> Input Class Initialized
INFO - 2021-11-26 03:31:17 --> Language Class Initialized
INFO - 2021-11-26 03:31:17 --> Loader Class Initialized
INFO - 2021-11-26 03:31:17 --> Helper loaded: url_helper
INFO - 2021-11-26 03:31:17 --> Helper loaded: form_helper
INFO - 2021-11-26 03:31:17 --> Helper loaded: common_helper
INFO - 2021-11-26 03:31:17 --> Database Driver Class Initialized
DEBUG - 2021-11-26 03:31:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-26 03:31:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-26 03:31:17 --> Controller Class Initialized
INFO - 2021-11-26 03:31:17 --> Form Validation Class Initialized
DEBUG - 2021-11-26 03:31:17 --> Encrypt Class Initialized
DEBUG - 2021-11-26 03:31:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-26 03:31:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-26 03:31:17 --> Email Class Initialized
INFO - 2021-11-26 03:31:17 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-26 03:31:17 --> Calendar Class Initialized
INFO - 2021-11-26 03:31:17 --> Model "Login_model" initialized
INFO - 2021-11-26 03:31:17 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-11-26 03:31:17 --> Final output sent to browser
DEBUG - 2021-11-26 03:31:17 --> Total execution time: 0.0226
ERROR - 2021-11-26 03:31:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-26 03:31:29 --> Config Class Initialized
INFO - 2021-11-26 03:31:29 --> Hooks Class Initialized
DEBUG - 2021-11-26 03:31:29 --> UTF-8 Support Enabled
INFO - 2021-11-26 03:31:29 --> Utf8 Class Initialized
INFO - 2021-11-26 03:31:29 --> URI Class Initialized
DEBUG - 2021-11-26 03:31:29 --> No URI present. Default controller set.
INFO - 2021-11-26 03:31:29 --> Router Class Initialized
INFO - 2021-11-26 03:31:29 --> Output Class Initialized
INFO - 2021-11-26 03:31:29 --> Security Class Initialized
DEBUG - 2021-11-26 03:31:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-26 03:31:29 --> Input Class Initialized
INFO - 2021-11-26 03:31:29 --> Language Class Initialized
INFO - 2021-11-26 03:31:29 --> Loader Class Initialized
INFO - 2021-11-26 03:31:29 --> Helper loaded: url_helper
INFO - 2021-11-26 03:31:29 --> Helper loaded: form_helper
INFO - 2021-11-26 03:31:29 --> Helper loaded: common_helper
INFO - 2021-11-26 03:31:29 --> Database Driver Class Initialized
DEBUG - 2021-11-26 03:31:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-26 03:31:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-26 03:31:29 --> Controller Class Initialized
INFO - 2021-11-26 03:31:29 --> Form Validation Class Initialized
DEBUG - 2021-11-26 03:31:29 --> Encrypt Class Initialized
DEBUG - 2021-11-26 03:31:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-26 03:31:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-26 03:31:29 --> Email Class Initialized
INFO - 2021-11-26 03:31:29 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-26 03:31:29 --> Calendar Class Initialized
INFO - 2021-11-26 03:31:29 --> Model "Login_model" initialized
INFO - 2021-11-26 03:31:29 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-11-26 03:31:29 --> Final output sent to browser
DEBUG - 2021-11-26 03:31:29 --> Total execution time: 0.0241
ERROR - 2021-11-26 03:31:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-26 03:31:36 --> Config Class Initialized
INFO - 2021-11-26 03:31:36 --> Hooks Class Initialized
DEBUG - 2021-11-26 03:31:36 --> UTF-8 Support Enabled
INFO - 2021-11-26 03:31:36 --> Utf8 Class Initialized
INFO - 2021-11-26 03:31:36 --> URI Class Initialized
DEBUG - 2021-11-26 03:31:36 --> No URI present. Default controller set.
INFO - 2021-11-26 03:31:36 --> Router Class Initialized
INFO - 2021-11-26 03:31:36 --> Output Class Initialized
INFO - 2021-11-26 03:31:36 --> Security Class Initialized
DEBUG - 2021-11-26 03:31:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-26 03:31:36 --> Input Class Initialized
INFO - 2021-11-26 03:31:36 --> Language Class Initialized
INFO - 2021-11-26 03:31:36 --> Loader Class Initialized
INFO - 2021-11-26 03:31:36 --> Helper loaded: url_helper
INFO - 2021-11-26 03:31:36 --> Helper loaded: form_helper
INFO - 2021-11-26 03:31:36 --> Helper loaded: common_helper
INFO - 2021-11-26 03:31:36 --> Database Driver Class Initialized
DEBUG - 2021-11-26 03:31:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-26 03:31:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-26 03:31:37 --> Controller Class Initialized
INFO - 2021-11-26 03:31:37 --> Form Validation Class Initialized
DEBUG - 2021-11-26 03:31:37 --> Encrypt Class Initialized
DEBUG - 2021-11-26 03:31:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-26 03:31:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-26 03:31:37 --> Email Class Initialized
INFO - 2021-11-26 03:31:37 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-26 03:31:37 --> Calendar Class Initialized
INFO - 2021-11-26 03:31:37 --> Model "Login_model" initialized
INFO - 2021-11-26 03:31:37 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-11-26 03:31:37 --> Final output sent to browser
DEBUG - 2021-11-26 03:31:37 --> Total execution time: 0.0263
ERROR - 2021-11-26 03:31:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-26 03:31:49 --> Config Class Initialized
INFO - 2021-11-26 03:31:49 --> Hooks Class Initialized
DEBUG - 2021-11-26 03:31:49 --> UTF-8 Support Enabled
INFO - 2021-11-26 03:31:49 --> Utf8 Class Initialized
INFO - 2021-11-26 03:31:49 --> URI Class Initialized
DEBUG - 2021-11-26 03:31:49 --> No URI present. Default controller set.
INFO - 2021-11-26 03:31:49 --> Router Class Initialized
INFO - 2021-11-26 03:31:49 --> Output Class Initialized
INFO - 2021-11-26 03:31:49 --> Security Class Initialized
DEBUG - 2021-11-26 03:31:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-26 03:31:49 --> Input Class Initialized
INFO - 2021-11-26 03:31:49 --> Language Class Initialized
INFO - 2021-11-26 03:31:49 --> Loader Class Initialized
INFO - 2021-11-26 03:31:49 --> Helper loaded: url_helper
INFO - 2021-11-26 03:31:49 --> Helper loaded: form_helper
INFO - 2021-11-26 03:31:49 --> Helper loaded: common_helper
INFO - 2021-11-26 03:31:49 --> Database Driver Class Initialized
DEBUG - 2021-11-26 03:31:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-26 03:31:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-26 03:31:49 --> Controller Class Initialized
INFO - 2021-11-26 03:31:49 --> Form Validation Class Initialized
DEBUG - 2021-11-26 03:31:49 --> Encrypt Class Initialized
DEBUG - 2021-11-26 03:31:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-26 03:31:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-26 03:31:49 --> Email Class Initialized
INFO - 2021-11-26 03:31:49 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-26 03:31:49 --> Calendar Class Initialized
INFO - 2021-11-26 03:31:49 --> Model "Login_model" initialized
INFO - 2021-11-26 03:31:49 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-11-26 03:31:49 --> Final output sent to browser
DEBUG - 2021-11-26 03:31:49 --> Total execution time: 0.0242
ERROR - 2021-11-26 05:42:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-26 05:42:19 --> Config Class Initialized
INFO - 2021-11-26 05:42:19 --> Hooks Class Initialized
DEBUG - 2021-11-26 05:42:19 --> UTF-8 Support Enabled
INFO - 2021-11-26 05:42:19 --> Utf8 Class Initialized
INFO - 2021-11-26 05:42:19 --> URI Class Initialized
DEBUG - 2021-11-26 05:42:19 --> No URI present. Default controller set.
INFO - 2021-11-26 05:42:19 --> Router Class Initialized
INFO - 2021-11-26 05:42:19 --> Output Class Initialized
INFO - 2021-11-26 05:42:19 --> Security Class Initialized
DEBUG - 2021-11-26 05:42:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-26 05:42:19 --> Input Class Initialized
INFO - 2021-11-26 05:42:19 --> Language Class Initialized
INFO - 2021-11-26 05:42:19 --> Loader Class Initialized
INFO - 2021-11-26 05:42:19 --> Helper loaded: url_helper
INFO - 2021-11-26 05:42:19 --> Helper loaded: form_helper
INFO - 2021-11-26 05:42:19 --> Helper loaded: common_helper
INFO - 2021-11-26 05:42:19 --> Database Driver Class Initialized
DEBUG - 2021-11-26 05:42:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-26 05:42:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-26 05:42:19 --> Controller Class Initialized
INFO - 2021-11-26 05:42:19 --> Form Validation Class Initialized
DEBUG - 2021-11-26 05:42:19 --> Encrypt Class Initialized
DEBUG - 2021-11-26 05:42:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-26 05:42:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-26 05:42:19 --> Email Class Initialized
INFO - 2021-11-26 05:42:19 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-26 05:42:19 --> Calendar Class Initialized
INFO - 2021-11-26 05:42:19 --> Model "Login_model" initialized
INFO - 2021-11-26 05:42:19 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-11-26 05:42:19 --> Final output sent to browser
DEBUG - 2021-11-26 05:42:19 --> Total execution time: 0.0366
ERROR - 2021-11-26 05:42:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-26 05:42:21 --> Config Class Initialized
INFO - 2021-11-26 05:42:21 --> Hooks Class Initialized
DEBUG - 2021-11-26 05:42:21 --> UTF-8 Support Enabled
INFO - 2021-11-26 05:42:21 --> Utf8 Class Initialized
INFO - 2021-11-26 05:42:21 --> URI Class Initialized
DEBUG - 2021-11-26 05:42:21 --> No URI present. Default controller set.
INFO - 2021-11-26 05:42:21 --> Router Class Initialized
INFO - 2021-11-26 05:42:21 --> Output Class Initialized
INFO - 2021-11-26 05:42:21 --> Security Class Initialized
DEBUG - 2021-11-26 05:42:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-26 05:42:21 --> Input Class Initialized
INFO - 2021-11-26 05:42:21 --> Language Class Initialized
INFO - 2021-11-26 05:42:21 --> Loader Class Initialized
INFO - 2021-11-26 05:42:21 --> Helper loaded: url_helper
INFO - 2021-11-26 05:42:21 --> Helper loaded: form_helper
INFO - 2021-11-26 05:42:21 --> Helper loaded: common_helper
INFO - 2021-11-26 05:42:21 --> Database Driver Class Initialized
DEBUG - 2021-11-26 05:42:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-26 05:42:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-26 05:42:21 --> Controller Class Initialized
INFO - 2021-11-26 05:42:21 --> Form Validation Class Initialized
DEBUG - 2021-11-26 05:42:21 --> Encrypt Class Initialized
DEBUG - 2021-11-26 05:42:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-26 05:42:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-26 05:42:21 --> Email Class Initialized
INFO - 2021-11-26 05:42:21 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-26 05:42:21 --> Calendar Class Initialized
INFO - 2021-11-26 05:42:21 --> Model "Login_model" initialized
INFO - 2021-11-26 05:42:21 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-11-26 05:42:21 --> Final output sent to browser
DEBUG - 2021-11-26 05:42:21 --> Total execution time: 0.0325
ERROR - 2021-11-26 07:12:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-26 07:12:15 --> Config Class Initialized
INFO - 2021-11-26 07:12:15 --> Hooks Class Initialized
DEBUG - 2021-11-26 07:12:15 --> UTF-8 Support Enabled
INFO - 2021-11-26 07:12:15 --> Utf8 Class Initialized
INFO - 2021-11-26 07:12:15 --> URI Class Initialized
DEBUG - 2021-11-26 07:12:15 --> No URI present. Default controller set.
INFO - 2021-11-26 07:12:15 --> Router Class Initialized
INFO - 2021-11-26 07:12:15 --> Output Class Initialized
INFO - 2021-11-26 07:12:15 --> Security Class Initialized
DEBUG - 2021-11-26 07:12:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-26 07:12:15 --> Input Class Initialized
INFO - 2021-11-26 07:12:15 --> Language Class Initialized
INFO - 2021-11-26 07:12:15 --> Loader Class Initialized
INFO - 2021-11-26 07:12:15 --> Helper loaded: url_helper
INFO - 2021-11-26 07:12:15 --> Helper loaded: form_helper
INFO - 2021-11-26 07:12:15 --> Helper loaded: common_helper
INFO - 2021-11-26 07:12:15 --> Database Driver Class Initialized
DEBUG - 2021-11-26 07:12:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-26 07:12:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-26 07:12:15 --> Controller Class Initialized
INFO - 2021-11-26 07:12:15 --> Form Validation Class Initialized
DEBUG - 2021-11-26 07:12:15 --> Encrypt Class Initialized
DEBUG - 2021-11-26 07:12:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-26 07:12:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-26 07:12:15 --> Email Class Initialized
INFO - 2021-11-26 07:12:15 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-26 07:12:15 --> Calendar Class Initialized
INFO - 2021-11-26 07:12:15 --> Model "Login_model" initialized
INFO - 2021-11-26 07:12:15 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-11-26 07:12:15 --> Final output sent to browser
DEBUG - 2021-11-26 07:12:15 --> Total execution time: 0.0378
ERROR - 2021-11-26 09:17:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-26 09:17:36 --> Config Class Initialized
INFO - 2021-11-26 09:17:36 --> Hooks Class Initialized
DEBUG - 2021-11-26 09:17:36 --> UTF-8 Support Enabled
INFO - 2021-11-26 09:17:36 --> Utf8 Class Initialized
INFO - 2021-11-26 09:17:36 --> URI Class Initialized
DEBUG - 2021-11-26 09:17:36 --> No URI present. Default controller set.
INFO - 2021-11-26 09:17:36 --> Router Class Initialized
INFO - 2021-11-26 09:17:36 --> Output Class Initialized
INFO - 2021-11-26 09:17:36 --> Security Class Initialized
DEBUG - 2021-11-26 09:17:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-26 09:17:36 --> Input Class Initialized
INFO - 2021-11-26 09:17:36 --> Language Class Initialized
INFO - 2021-11-26 09:17:36 --> Loader Class Initialized
INFO - 2021-11-26 09:17:36 --> Helper loaded: url_helper
INFO - 2021-11-26 09:17:36 --> Helper loaded: form_helper
INFO - 2021-11-26 09:17:36 --> Helper loaded: common_helper
INFO - 2021-11-26 09:17:36 --> Database Driver Class Initialized
DEBUG - 2021-11-26 09:17:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-26 09:17:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-26 09:17:36 --> Controller Class Initialized
INFO - 2021-11-26 09:17:36 --> Form Validation Class Initialized
DEBUG - 2021-11-26 09:17:36 --> Encrypt Class Initialized
DEBUG - 2021-11-26 09:17:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-26 09:17:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-26 09:17:36 --> Email Class Initialized
INFO - 2021-11-26 09:17:36 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-26 09:17:36 --> Calendar Class Initialized
INFO - 2021-11-26 09:17:36 --> Model "Login_model" initialized
INFO - 2021-11-26 09:17:36 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-11-26 09:17:36 --> Final output sent to browser
DEBUG - 2021-11-26 09:17:36 --> Total execution time: 0.0378
ERROR - 2021-11-26 10:22:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-26 10:22:48 --> Config Class Initialized
INFO - 2021-11-26 10:22:48 --> Hooks Class Initialized
DEBUG - 2021-11-26 10:22:48 --> UTF-8 Support Enabled
INFO - 2021-11-26 10:22:48 --> Utf8 Class Initialized
INFO - 2021-11-26 10:22:48 --> URI Class Initialized
DEBUG - 2021-11-26 10:22:48 --> No URI present. Default controller set.
INFO - 2021-11-26 10:22:48 --> Router Class Initialized
INFO - 2021-11-26 10:22:48 --> Output Class Initialized
INFO - 2021-11-26 10:22:48 --> Security Class Initialized
DEBUG - 2021-11-26 10:22:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-26 10:22:48 --> Input Class Initialized
INFO - 2021-11-26 10:22:48 --> Language Class Initialized
INFO - 2021-11-26 10:22:48 --> Loader Class Initialized
INFO - 2021-11-26 10:22:48 --> Helper loaded: url_helper
INFO - 2021-11-26 10:22:48 --> Helper loaded: form_helper
INFO - 2021-11-26 10:22:48 --> Helper loaded: common_helper
INFO - 2021-11-26 10:22:48 --> Database Driver Class Initialized
DEBUG - 2021-11-26 10:22:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-26 10:22:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-26 10:22:48 --> Controller Class Initialized
INFO - 2021-11-26 10:22:48 --> Form Validation Class Initialized
DEBUG - 2021-11-26 10:22:48 --> Encrypt Class Initialized
DEBUG - 2021-11-26 10:22:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-26 10:22:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-26 10:22:48 --> Email Class Initialized
INFO - 2021-11-26 10:22:48 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-26 10:22:48 --> Calendar Class Initialized
INFO - 2021-11-26 10:22:48 --> Model "Login_model" initialized
INFO - 2021-11-26 10:22:48 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-11-26 10:22:48 --> Final output sent to browser
DEBUG - 2021-11-26 10:22:48 --> Total execution time: 0.0472
ERROR - 2021-11-26 10:26:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-26 10:26:41 --> Config Class Initialized
INFO - 2021-11-26 10:26:41 --> Hooks Class Initialized
DEBUG - 2021-11-26 10:26:41 --> UTF-8 Support Enabled
INFO - 2021-11-26 10:26:41 --> Utf8 Class Initialized
INFO - 2021-11-26 10:26:41 --> URI Class Initialized
DEBUG - 2021-11-26 10:26:41 --> No URI present. Default controller set.
INFO - 2021-11-26 10:26:41 --> Router Class Initialized
INFO - 2021-11-26 10:26:41 --> Output Class Initialized
INFO - 2021-11-26 10:26:41 --> Security Class Initialized
DEBUG - 2021-11-26 10:26:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-26 10:26:41 --> Input Class Initialized
INFO - 2021-11-26 10:26:41 --> Language Class Initialized
INFO - 2021-11-26 10:26:41 --> Loader Class Initialized
INFO - 2021-11-26 10:26:41 --> Helper loaded: url_helper
INFO - 2021-11-26 10:26:41 --> Helper loaded: form_helper
INFO - 2021-11-26 10:26:41 --> Helper loaded: common_helper
INFO - 2021-11-26 10:26:41 --> Database Driver Class Initialized
DEBUG - 2021-11-26 10:26:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-26 10:26:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-26 10:26:41 --> Controller Class Initialized
INFO - 2021-11-26 10:26:41 --> Form Validation Class Initialized
DEBUG - 2021-11-26 10:26:41 --> Encrypt Class Initialized
DEBUG - 2021-11-26 10:26:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-26 10:26:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-26 10:26:41 --> Email Class Initialized
INFO - 2021-11-26 10:26:41 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-26 10:26:41 --> Calendar Class Initialized
INFO - 2021-11-26 10:26:41 --> Model "Login_model" initialized
INFO - 2021-11-26 10:26:41 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-11-26 10:26:41 --> Final output sent to browser
DEBUG - 2021-11-26 10:26:41 --> Total execution time: 0.0313
ERROR - 2021-11-26 10:27:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-26 10:27:24 --> Config Class Initialized
INFO - 2021-11-26 10:27:24 --> Hooks Class Initialized
DEBUG - 2021-11-26 10:27:24 --> UTF-8 Support Enabled
INFO - 2021-11-26 10:27:24 --> Utf8 Class Initialized
INFO - 2021-11-26 10:27:24 --> URI Class Initialized
DEBUG - 2021-11-26 10:27:24 --> No URI present. Default controller set.
INFO - 2021-11-26 10:27:24 --> Router Class Initialized
INFO - 2021-11-26 10:27:24 --> Output Class Initialized
INFO - 2021-11-26 10:27:24 --> Security Class Initialized
DEBUG - 2021-11-26 10:27:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-26 10:27:24 --> Input Class Initialized
INFO - 2021-11-26 10:27:24 --> Language Class Initialized
INFO - 2021-11-26 10:27:24 --> Loader Class Initialized
INFO - 2021-11-26 10:27:24 --> Helper loaded: url_helper
INFO - 2021-11-26 10:27:24 --> Helper loaded: form_helper
INFO - 2021-11-26 10:27:24 --> Helper loaded: common_helper
INFO - 2021-11-26 10:27:24 --> Database Driver Class Initialized
DEBUG - 2021-11-26 10:27:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-26 10:27:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-26 10:27:24 --> Controller Class Initialized
INFO - 2021-11-26 10:27:24 --> Form Validation Class Initialized
DEBUG - 2021-11-26 10:27:24 --> Encrypt Class Initialized
DEBUG - 2021-11-26 10:27:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-26 10:27:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-26 10:27:24 --> Email Class Initialized
INFO - 2021-11-26 10:27:24 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-26 10:27:24 --> Calendar Class Initialized
INFO - 2021-11-26 10:27:24 --> Model "Login_model" initialized
INFO - 2021-11-26 10:27:24 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-11-26 10:27:24 --> Final output sent to browser
DEBUG - 2021-11-26 10:27:24 --> Total execution time: 0.0327
ERROR - 2021-11-26 10:28:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-26 10:28:12 --> Config Class Initialized
INFO - 2021-11-26 10:28:12 --> Hooks Class Initialized
DEBUG - 2021-11-26 10:28:12 --> UTF-8 Support Enabled
INFO - 2021-11-26 10:28:12 --> Utf8 Class Initialized
INFO - 2021-11-26 10:28:12 --> URI Class Initialized
DEBUG - 2021-11-26 10:28:12 --> No URI present. Default controller set.
INFO - 2021-11-26 10:28:12 --> Router Class Initialized
INFO - 2021-11-26 10:28:12 --> Output Class Initialized
INFO - 2021-11-26 10:28:12 --> Security Class Initialized
DEBUG - 2021-11-26 10:28:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-26 10:28:12 --> Input Class Initialized
INFO - 2021-11-26 10:28:12 --> Language Class Initialized
INFO - 2021-11-26 10:28:12 --> Loader Class Initialized
INFO - 2021-11-26 10:28:12 --> Helper loaded: url_helper
INFO - 2021-11-26 10:28:12 --> Helper loaded: form_helper
INFO - 2021-11-26 10:28:12 --> Helper loaded: common_helper
INFO - 2021-11-26 10:28:12 --> Database Driver Class Initialized
DEBUG - 2021-11-26 10:28:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-26 10:28:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-26 10:28:12 --> Controller Class Initialized
INFO - 2021-11-26 10:28:12 --> Form Validation Class Initialized
DEBUG - 2021-11-26 10:28:12 --> Encrypt Class Initialized
DEBUG - 2021-11-26 10:28:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-26 10:28:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-26 10:28:12 --> Email Class Initialized
INFO - 2021-11-26 10:28:12 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-26 10:28:12 --> Calendar Class Initialized
INFO - 2021-11-26 10:28:12 --> Model "Login_model" initialized
INFO - 2021-11-26 10:28:12 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-11-26 10:28:12 --> Final output sent to browser
DEBUG - 2021-11-26 10:28:12 --> Total execution time: 0.0296
ERROR - 2021-11-26 11:09:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-26 11:09:31 --> Config Class Initialized
INFO - 2021-11-26 11:09:31 --> Hooks Class Initialized
DEBUG - 2021-11-26 11:09:31 --> UTF-8 Support Enabled
INFO - 2021-11-26 11:09:31 --> Utf8 Class Initialized
INFO - 2021-11-26 11:09:31 --> URI Class Initialized
DEBUG - 2021-11-26 11:09:31 --> No URI present. Default controller set.
INFO - 2021-11-26 11:09:31 --> Router Class Initialized
INFO - 2021-11-26 11:09:31 --> Output Class Initialized
INFO - 2021-11-26 11:09:31 --> Security Class Initialized
DEBUG - 2021-11-26 11:09:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-26 11:09:31 --> Input Class Initialized
INFO - 2021-11-26 11:09:31 --> Language Class Initialized
INFO - 2021-11-26 11:09:31 --> Loader Class Initialized
INFO - 2021-11-26 11:09:31 --> Helper loaded: url_helper
INFO - 2021-11-26 11:09:31 --> Helper loaded: form_helper
INFO - 2021-11-26 11:09:31 --> Helper loaded: common_helper
INFO - 2021-11-26 11:09:31 --> Database Driver Class Initialized
DEBUG - 2021-11-26 11:09:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-26 11:09:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-26 11:09:31 --> Controller Class Initialized
INFO - 2021-11-26 11:09:31 --> Form Validation Class Initialized
DEBUG - 2021-11-26 11:09:31 --> Encrypt Class Initialized
DEBUG - 2021-11-26 11:09:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-26 11:09:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-26 11:09:31 --> Email Class Initialized
INFO - 2021-11-26 11:09:31 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-26 11:09:31 --> Calendar Class Initialized
INFO - 2021-11-26 11:09:31 --> Model "Login_model" initialized
INFO - 2021-11-26 11:09:31 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-11-26 11:09:31 --> Final output sent to browser
DEBUG - 2021-11-26 11:09:31 --> Total execution time: 0.0291
ERROR - 2021-11-26 13:31:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-26 13:31:13 --> Config Class Initialized
INFO - 2021-11-26 13:31:13 --> Hooks Class Initialized
DEBUG - 2021-11-26 13:31:13 --> UTF-8 Support Enabled
INFO - 2021-11-26 13:31:13 --> Utf8 Class Initialized
INFO - 2021-11-26 13:31:13 --> URI Class Initialized
DEBUG - 2021-11-26 13:31:13 --> No URI present. Default controller set.
INFO - 2021-11-26 13:31:13 --> Router Class Initialized
INFO - 2021-11-26 13:31:13 --> Output Class Initialized
INFO - 2021-11-26 13:31:13 --> Security Class Initialized
DEBUG - 2021-11-26 13:31:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-26 13:31:13 --> Input Class Initialized
INFO - 2021-11-26 13:31:13 --> Language Class Initialized
INFO - 2021-11-26 13:31:13 --> Loader Class Initialized
INFO - 2021-11-26 13:31:13 --> Helper loaded: url_helper
INFO - 2021-11-26 13:31:13 --> Helper loaded: form_helper
INFO - 2021-11-26 13:31:13 --> Helper loaded: common_helper
INFO - 2021-11-26 13:31:13 --> Database Driver Class Initialized
DEBUG - 2021-11-26 13:31:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-26 13:31:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-26 13:31:13 --> Controller Class Initialized
INFO - 2021-11-26 13:31:13 --> Form Validation Class Initialized
DEBUG - 2021-11-26 13:31:13 --> Encrypt Class Initialized
DEBUG - 2021-11-26 13:31:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-26 13:31:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-26 13:31:13 --> Email Class Initialized
INFO - 2021-11-26 13:31:13 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-26 13:31:13 --> Calendar Class Initialized
INFO - 2021-11-26 13:31:13 --> Model "Login_model" initialized
INFO - 2021-11-26 13:31:13 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-11-26 13:31:13 --> Final output sent to browser
DEBUG - 2021-11-26 13:31:13 --> Total execution time: 0.0325
ERROR - 2021-11-26 14:23:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-26 14:23:36 --> Config Class Initialized
INFO - 2021-11-26 14:23:36 --> Hooks Class Initialized
DEBUG - 2021-11-26 14:23:36 --> UTF-8 Support Enabled
INFO - 2021-11-26 14:23:36 --> Utf8 Class Initialized
INFO - 2021-11-26 14:23:36 --> URI Class Initialized
DEBUG - 2021-11-26 14:23:36 --> No URI present. Default controller set.
INFO - 2021-11-26 14:23:36 --> Router Class Initialized
INFO - 2021-11-26 14:23:36 --> Output Class Initialized
INFO - 2021-11-26 14:23:36 --> Security Class Initialized
DEBUG - 2021-11-26 14:23:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-26 14:23:36 --> Input Class Initialized
INFO - 2021-11-26 14:23:36 --> Language Class Initialized
INFO - 2021-11-26 14:23:36 --> Loader Class Initialized
INFO - 2021-11-26 14:23:36 --> Helper loaded: url_helper
INFO - 2021-11-26 14:23:36 --> Helper loaded: form_helper
INFO - 2021-11-26 14:23:36 --> Helper loaded: common_helper
INFO - 2021-11-26 14:23:36 --> Database Driver Class Initialized
DEBUG - 2021-11-26 14:23:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-26 14:23:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-26 14:23:36 --> Controller Class Initialized
INFO - 2021-11-26 14:23:36 --> Form Validation Class Initialized
DEBUG - 2021-11-26 14:23:36 --> Encrypt Class Initialized
DEBUG - 2021-11-26 14:23:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-26 14:23:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-26 14:23:36 --> Email Class Initialized
INFO - 2021-11-26 14:23:36 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-26 14:23:36 --> Calendar Class Initialized
INFO - 2021-11-26 14:23:36 --> Model "Login_model" initialized
INFO - 2021-11-26 14:23:36 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-11-26 14:23:36 --> Final output sent to browser
DEBUG - 2021-11-26 14:23:36 --> Total execution time: 0.0329
ERROR - 2021-11-26 15:12:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-26 15:12:14 --> Config Class Initialized
INFO - 2021-11-26 15:12:14 --> Hooks Class Initialized
DEBUG - 2021-11-26 15:12:14 --> UTF-8 Support Enabled
INFO - 2021-11-26 15:12:14 --> Utf8 Class Initialized
INFO - 2021-11-26 15:12:14 --> URI Class Initialized
DEBUG - 2021-11-26 15:12:14 --> No URI present. Default controller set.
INFO - 2021-11-26 15:12:14 --> Router Class Initialized
INFO - 2021-11-26 15:12:14 --> Output Class Initialized
INFO - 2021-11-26 15:12:14 --> Security Class Initialized
DEBUG - 2021-11-26 15:12:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-26 15:12:14 --> Input Class Initialized
INFO - 2021-11-26 15:12:14 --> Language Class Initialized
INFO - 2021-11-26 15:12:14 --> Loader Class Initialized
INFO - 2021-11-26 15:12:14 --> Helper loaded: url_helper
INFO - 2021-11-26 15:12:14 --> Helper loaded: form_helper
INFO - 2021-11-26 15:12:14 --> Helper loaded: common_helper
INFO - 2021-11-26 15:12:14 --> Database Driver Class Initialized
DEBUG - 2021-11-26 15:12:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-26 15:12:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-26 15:12:14 --> Controller Class Initialized
INFO - 2021-11-26 15:12:14 --> Form Validation Class Initialized
DEBUG - 2021-11-26 15:12:14 --> Encrypt Class Initialized
DEBUG - 2021-11-26 15:12:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-26 15:12:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-26 15:12:14 --> Email Class Initialized
INFO - 2021-11-26 15:12:14 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-26 15:12:14 --> Calendar Class Initialized
INFO - 2021-11-26 15:12:14 --> Model "Login_model" initialized
INFO - 2021-11-26 15:12:14 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-11-26 15:12:14 --> Final output sent to browser
DEBUG - 2021-11-26 15:12:14 --> Total execution time: 0.0311
