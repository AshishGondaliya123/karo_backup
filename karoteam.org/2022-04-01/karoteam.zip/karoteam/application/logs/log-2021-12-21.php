<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-12-21 00:30:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-21 00:30:20 --> Config Class Initialized
INFO - 2021-12-21 00:30:20 --> Hooks Class Initialized
DEBUG - 2021-12-21 00:30:20 --> UTF-8 Support Enabled
INFO - 2021-12-21 00:30:20 --> Utf8 Class Initialized
INFO - 2021-12-21 00:30:20 --> URI Class Initialized
INFO - 2021-12-21 00:30:20 --> Router Class Initialized
INFO - 2021-12-21 00:30:20 --> Output Class Initialized
INFO - 2021-12-21 00:30:20 --> Security Class Initialized
DEBUG - 2021-12-21 00:30:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-21 00:30:20 --> Input Class Initialized
INFO - 2021-12-21 00:30:20 --> Language Class Initialized
INFO - 2021-12-21 00:30:20 --> Loader Class Initialized
INFO - 2021-12-21 00:30:20 --> Helper loaded: url_helper
INFO - 2021-12-21 00:30:20 --> Helper loaded: form_helper
INFO - 2021-12-21 00:30:20 --> Helper loaded: common_helper
INFO - 2021-12-21 00:30:20 --> Database Driver Class Initialized
DEBUG - 2021-12-21 00:30:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-21 00:30:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-21 00:30:20 --> Controller Class Initialized
INFO - 2021-12-21 00:30:20 --> Form Validation Class Initialized
DEBUG - 2021-12-21 00:30:20 --> Encrypt Class Initialized
INFO - 2021-12-21 00:30:20 --> Model "Patient_model" initialized
INFO - 2021-12-21 00:30:20 --> Model "Patientcase_model" initialized
INFO - 2021-12-21 00:30:20 --> Model "Referredby_model" initialized
INFO - 2021-12-21 00:30:20 --> Model "Prefix_master" initialized
INFO - 2021-12-21 00:30:20 --> Model "Hospital_model" initialized
INFO - 2021-12-21 00:30:20 --> File loaded: /home3/karoteam/public_html/application/views/header.php
ERROR - 2021-12-21 00:30:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-21 00:30:22 --> Config Class Initialized
INFO - 2021-12-21 00:30:22 --> Hooks Class Initialized
DEBUG - 2021-12-21 00:30:22 --> UTF-8 Support Enabled
INFO - 2021-12-21 00:30:22 --> Utf8 Class Initialized
INFO - 2021-12-21 00:30:22 --> URI Class Initialized
INFO - 2021-12-21 00:30:22 --> Router Class Initialized
INFO - 2021-12-21 00:30:22 --> Output Class Initialized
INFO - 2021-12-21 00:30:22 --> Security Class Initialized
DEBUG - 2021-12-21 00:30:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-21 00:30:22 --> Input Class Initialized
INFO - 2021-12-21 00:30:22 --> Language Class Initialized
INFO - 2021-12-21 00:30:22 --> Loader Class Initialized
INFO - 2021-12-21 00:30:22 --> Helper loaded: url_helper
INFO - 2021-12-21 00:30:22 --> Helper loaded: form_helper
INFO - 2021-12-21 00:30:22 --> Helper loaded: common_helper
INFO - 2021-12-21 00:30:22 --> Database Driver Class Initialized
DEBUG - 2021-12-21 00:30:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-21 00:30:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-21 00:30:22 --> Controller Class Initialized
INFO - 2021-12-21 00:30:22 --> Form Validation Class Initialized
DEBUG - 2021-12-21 00:30:22 --> Encrypt Class Initialized
INFO - 2021-12-21 00:30:22 --> Model "Patient_model" initialized
INFO - 2021-12-21 00:30:22 --> Model "Patientcase_model" initialized
INFO - 2021-12-21 00:30:22 --> Model "Referredby_model" initialized
INFO - 2021-12-21 00:30:22 --> Model "Prefix_master" initialized
INFO - 2021-12-21 00:30:22 --> Model "Hospital_model" initialized
INFO - 2021-12-21 00:30:22 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-21 00:30:25 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2021-12-21 00:30:25 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-21 00:30:27 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2021-12-21 00:30:28 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
ERROR - 2021-12-21 00:30:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-21 00:30:29 --> Config Class Initialized
INFO - 2021-12-21 00:30:29 --> Hooks Class Initialized
DEBUG - 2021-12-21 00:30:29 --> UTF-8 Support Enabled
INFO - 2021-12-21 00:30:29 --> Utf8 Class Initialized
INFO - 2021-12-21 00:30:29 --> URI Class Initialized
INFO - 2021-12-21 00:30:29 --> Router Class Initialized
INFO - 2021-12-21 00:30:29 --> Output Class Initialized
INFO - 2021-12-21 00:30:29 --> Security Class Initialized
DEBUG - 2021-12-21 00:30:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-21 00:30:29 --> Input Class Initialized
INFO - 2021-12-21 00:30:29 --> Language Class Initialized
ERROR - 2021-12-21 00:30:29 --> 404 Page Not Found: Karoclient/usersprofile
INFO - 2021-12-21 00:30:29 --> Final output sent to browser
DEBUG - 2021-12-21 00:30:29 --> Total execution time: 5.8849
ERROR - 2021-12-21 00:30:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-21 00:30:49 --> Config Class Initialized
INFO - 2021-12-21 00:30:49 --> Hooks Class Initialized
DEBUG - 2021-12-21 00:30:49 --> UTF-8 Support Enabled
INFO - 2021-12-21 00:30:49 --> Utf8 Class Initialized
INFO - 2021-12-21 00:30:49 --> URI Class Initialized
INFO - 2021-12-21 00:30:49 --> Router Class Initialized
INFO - 2021-12-21 00:30:49 --> Output Class Initialized
INFO - 2021-12-21 00:30:49 --> Security Class Initialized
DEBUG - 2021-12-21 00:30:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-21 00:30:49 --> Input Class Initialized
INFO - 2021-12-21 00:30:49 --> Language Class Initialized
INFO - 2021-12-21 00:30:49 --> Loader Class Initialized
INFO - 2021-12-21 00:30:49 --> Helper loaded: url_helper
INFO - 2021-12-21 00:30:49 --> Helper loaded: form_helper
INFO - 2021-12-21 00:30:49 --> Helper loaded: common_helper
INFO - 2021-12-21 00:30:49 --> Database Driver Class Initialized
DEBUG - 2021-12-21 00:30:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-21 00:30:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-21 00:30:49 --> Controller Class Initialized
INFO - 2021-12-21 00:30:49 --> Form Validation Class Initialized
DEBUG - 2021-12-21 00:30:49 --> Encrypt Class Initialized
INFO - 2021-12-21 00:30:49 --> Model "Patient_model" initialized
INFO - 2021-12-21 00:30:49 --> Model "Patientcase_model" initialized
INFO - 2021-12-21 00:30:49 --> Model "Prefix_master" initialized
INFO - 2021-12-21 00:30:49 --> Model "Users_model" initialized
INFO - 2021-12-21 00:30:49 --> Model "Hospital_model" initialized
INFO - 2021-12-21 00:30:49 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-21 00:30:49 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2021-12-21 00:30:49 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-21 00:30:49 --> Final output sent to browser
DEBUG - 2021-12-21 00:30:49 --> Total execution time: 0.2522
ERROR - 2021-12-21 00:30:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-21 00:30:50 --> Config Class Initialized
INFO - 2021-12-21 00:30:50 --> Hooks Class Initialized
DEBUG - 2021-12-21 00:30:50 --> UTF-8 Support Enabled
INFO - 2021-12-21 00:30:50 --> Utf8 Class Initialized
INFO - 2021-12-21 00:30:50 --> URI Class Initialized
INFO - 2021-12-21 00:30:50 --> Router Class Initialized
INFO - 2021-12-21 00:30:50 --> Output Class Initialized
INFO - 2021-12-21 00:30:50 --> Security Class Initialized
DEBUG - 2021-12-21 00:30:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-21 00:30:50 --> Input Class Initialized
INFO - 2021-12-21 00:30:50 --> Language Class Initialized
ERROR - 2021-12-21 00:30:50 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-12-21 00:32:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-21 00:32:20 --> Config Class Initialized
INFO - 2021-12-21 00:32:20 --> Hooks Class Initialized
DEBUG - 2021-12-21 00:32:20 --> UTF-8 Support Enabled
INFO - 2021-12-21 00:32:20 --> Utf8 Class Initialized
INFO - 2021-12-21 00:32:20 --> URI Class Initialized
INFO - 2021-12-21 00:32:20 --> Router Class Initialized
INFO - 2021-12-21 00:32:20 --> Output Class Initialized
INFO - 2021-12-21 00:32:20 --> Security Class Initialized
DEBUG - 2021-12-21 00:32:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-21 00:32:20 --> Input Class Initialized
INFO - 2021-12-21 00:32:20 --> Language Class Initialized
INFO - 2021-12-21 00:32:20 --> Loader Class Initialized
INFO - 2021-12-21 00:32:20 --> Helper loaded: url_helper
INFO - 2021-12-21 00:32:20 --> Helper loaded: form_helper
INFO - 2021-12-21 00:32:20 --> Helper loaded: common_helper
INFO - 2021-12-21 00:32:20 --> Database Driver Class Initialized
DEBUG - 2021-12-21 00:32:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-21 00:32:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-21 00:32:20 --> Controller Class Initialized
INFO - 2021-12-21 00:32:20 --> Form Validation Class Initialized
INFO - 2021-12-21 00:32:20 --> Model "Case_model" initialized
INFO - 2021-12-21 00:32:20 --> Model "Patientcase_model" initialized
INFO - 2021-12-21 00:32:20 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-21 00:32:20 --> File loaded: /home3/karoteam/public_html/application/views/cases/new_case.php
INFO - 2021-12-21 00:32:20 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-21 00:32:20 --> Final output sent to browser
DEBUG - 2021-12-21 00:32:20 --> Total execution time: 0.6912
ERROR - 2021-12-21 00:32:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-21 00:32:22 --> Config Class Initialized
INFO - 2021-12-21 00:32:22 --> Hooks Class Initialized
DEBUG - 2021-12-21 00:32:22 --> UTF-8 Support Enabled
INFO - 2021-12-21 00:32:22 --> Utf8 Class Initialized
INFO - 2021-12-21 00:32:22 --> URI Class Initialized
INFO - 2021-12-21 00:32:22 --> Router Class Initialized
INFO - 2021-12-21 00:32:22 --> Output Class Initialized
INFO - 2021-12-21 00:32:22 --> Security Class Initialized
DEBUG - 2021-12-21 00:32:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-21 00:32:22 --> Input Class Initialized
INFO - 2021-12-21 00:32:22 --> Language Class Initialized
ERROR - 2021-12-21 00:32:22 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-12-21 00:32:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-21 00:32:33 --> Config Class Initialized
INFO - 2021-12-21 00:32:33 --> Hooks Class Initialized
DEBUG - 2021-12-21 00:32:33 --> UTF-8 Support Enabled
INFO - 2021-12-21 00:32:33 --> Utf8 Class Initialized
INFO - 2021-12-21 00:32:33 --> URI Class Initialized
INFO - 2021-12-21 00:32:33 --> Router Class Initialized
INFO - 2021-12-21 00:32:33 --> Output Class Initialized
INFO - 2021-12-21 00:32:33 --> Security Class Initialized
DEBUG - 2021-12-21 00:32:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-21 00:32:33 --> Input Class Initialized
INFO - 2021-12-21 00:32:33 --> Language Class Initialized
INFO - 2021-12-21 00:32:33 --> Loader Class Initialized
INFO - 2021-12-21 00:32:33 --> Helper loaded: url_helper
INFO - 2021-12-21 00:32:33 --> Helper loaded: form_helper
INFO - 2021-12-21 00:32:33 --> Helper loaded: common_helper
INFO - 2021-12-21 00:32:33 --> Database Driver Class Initialized
DEBUG - 2021-12-21 00:32:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-21 00:32:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-21 00:32:33 --> Controller Class Initialized
INFO - 2021-12-21 00:32:33 --> Form Validation Class Initialized
DEBUG - 2021-12-21 00:32:33 --> Encrypt Class Initialized
INFO - 2021-12-21 00:32:33 --> Model "Patient_model" initialized
INFO - 2021-12-21 00:32:33 --> Model "Patientcase_model" initialized
INFO - 2021-12-21 00:32:33 --> Model "Prefix_master" initialized
INFO - 2021-12-21 00:32:33 --> Model "Users_model" initialized
INFO - 2021-12-21 00:32:33 --> Model "Hospital_model" initialized
INFO - 2021-12-21 00:32:33 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-21 00:32:33 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2021-12-21 00:32:33 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-21 00:32:33 --> Final output sent to browser
DEBUG - 2021-12-21 00:32:33 --> Total execution time: 0.0556
ERROR - 2021-12-21 00:32:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-21 00:32:33 --> Config Class Initialized
INFO - 2021-12-21 00:32:33 --> Hooks Class Initialized
DEBUG - 2021-12-21 00:32:33 --> UTF-8 Support Enabled
INFO - 2021-12-21 00:32:33 --> Utf8 Class Initialized
INFO - 2021-12-21 00:32:33 --> URI Class Initialized
INFO - 2021-12-21 00:32:33 --> Router Class Initialized
INFO - 2021-12-21 00:32:34 --> Output Class Initialized
INFO - 2021-12-21 00:32:34 --> Security Class Initialized
DEBUG - 2021-12-21 00:32:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-21 00:32:34 --> Input Class Initialized
INFO - 2021-12-21 00:32:34 --> Language Class Initialized
ERROR - 2021-12-21 00:32:34 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-12-21 00:34:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-21 00:34:11 --> Config Class Initialized
INFO - 2021-12-21 00:34:11 --> Hooks Class Initialized
DEBUG - 2021-12-21 00:34:11 --> UTF-8 Support Enabled
INFO - 2021-12-21 00:34:11 --> Utf8 Class Initialized
INFO - 2021-12-21 00:34:11 --> URI Class Initialized
INFO - 2021-12-21 00:34:11 --> Router Class Initialized
INFO - 2021-12-21 00:34:11 --> Output Class Initialized
INFO - 2021-12-21 00:34:11 --> Security Class Initialized
DEBUG - 2021-12-21 00:34:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-21 00:34:11 --> Input Class Initialized
INFO - 2021-12-21 00:34:11 --> Language Class Initialized
INFO - 2021-12-21 00:34:11 --> Loader Class Initialized
INFO - 2021-12-21 00:34:11 --> Helper loaded: url_helper
INFO - 2021-12-21 00:34:11 --> Helper loaded: form_helper
INFO - 2021-12-21 00:34:11 --> Helper loaded: common_helper
INFO - 2021-12-21 00:34:11 --> Database Driver Class Initialized
DEBUG - 2021-12-21 00:34:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-21 00:34:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-21 00:34:11 --> Controller Class Initialized
INFO - 2021-12-21 00:34:11 --> Form Validation Class Initialized
DEBUG - 2021-12-21 00:34:11 --> Encrypt Class Initialized
INFO - 2021-12-21 00:34:11 --> Model "Login_model" initialized
INFO - 2021-12-21 00:34:11 --> Model "Dashboard_model" initialized
INFO - 2021-12-21 00:34:11 --> Model "Case_model" initialized
INFO - 2021-12-21 00:34:21 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-21 00:34:31 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2021-12-21 00:34:31 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-21 00:34:31 --> Final output sent to browser
DEBUG - 2021-12-21 00:34:31 --> Total execution time: 19.8055
ERROR - 2021-12-21 00:34:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-21 00:34:32 --> Config Class Initialized
INFO - 2021-12-21 00:34:32 --> Hooks Class Initialized
DEBUG - 2021-12-21 00:34:32 --> UTF-8 Support Enabled
INFO - 2021-12-21 00:34:32 --> Utf8 Class Initialized
INFO - 2021-12-21 00:34:32 --> URI Class Initialized
INFO - 2021-12-21 00:34:32 --> Router Class Initialized
INFO - 2021-12-21 00:34:32 --> Output Class Initialized
INFO - 2021-12-21 00:34:32 --> Security Class Initialized
DEBUG - 2021-12-21 00:34:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-21 00:34:32 --> Input Class Initialized
INFO - 2021-12-21 00:34:32 --> Language Class Initialized
ERROR - 2021-12-21 00:34:32 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-12-21 00:35:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-21 00:35:34 --> Config Class Initialized
INFO - 2021-12-21 00:35:34 --> Hooks Class Initialized
DEBUG - 2021-12-21 00:35:34 --> UTF-8 Support Enabled
INFO - 2021-12-21 00:35:34 --> Utf8 Class Initialized
INFO - 2021-12-21 00:35:34 --> URI Class Initialized
INFO - 2021-12-21 00:35:34 --> Router Class Initialized
INFO - 2021-12-21 00:35:34 --> Output Class Initialized
INFO - 2021-12-21 00:35:34 --> Security Class Initialized
DEBUG - 2021-12-21 00:35:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-21 00:35:34 --> Input Class Initialized
INFO - 2021-12-21 00:35:34 --> Language Class Initialized
INFO - 2021-12-21 00:35:34 --> Loader Class Initialized
INFO - 2021-12-21 00:35:34 --> Helper loaded: url_helper
INFO - 2021-12-21 00:35:34 --> Helper loaded: form_helper
INFO - 2021-12-21 00:35:34 --> Helper loaded: common_helper
INFO - 2021-12-21 00:35:34 --> Database Driver Class Initialized
DEBUG - 2021-12-21 00:35:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-21 00:35:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-21 00:35:34 --> Controller Class Initialized
INFO - 2021-12-21 00:35:34 --> Form Validation Class Initialized
INFO - 2021-12-21 00:35:34 --> Model "Case_model" initialized
INFO - 2021-12-21 00:35:34 --> Model "Patientcase_model" initialized
INFO - 2021-12-21 00:35:35 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-21 00:35:35 --> File loaded: /home3/karoteam/public_html/application/views/cases/new_case.php
INFO - 2021-12-21 00:35:35 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-21 00:35:35 --> Final output sent to browser
DEBUG - 2021-12-21 00:35:35 --> Total execution time: 0.6466
ERROR - 2021-12-21 00:35:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-21 00:35:36 --> Config Class Initialized
INFO - 2021-12-21 00:35:36 --> Hooks Class Initialized
DEBUG - 2021-12-21 00:35:36 --> UTF-8 Support Enabled
INFO - 2021-12-21 00:35:36 --> Utf8 Class Initialized
INFO - 2021-12-21 00:35:36 --> URI Class Initialized
INFO - 2021-12-21 00:35:36 --> Router Class Initialized
INFO - 2021-12-21 00:35:36 --> Output Class Initialized
INFO - 2021-12-21 00:35:36 --> Security Class Initialized
DEBUG - 2021-12-21 00:35:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-21 00:35:36 --> Input Class Initialized
INFO - 2021-12-21 00:35:36 --> Language Class Initialized
ERROR - 2021-12-21 00:35:36 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-12-21 00:35:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-21 00:35:48 --> Config Class Initialized
INFO - 2021-12-21 00:35:48 --> Hooks Class Initialized
DEBUG - 2021-12-21 00:35:48 --> UTF-8 Support Enabled
INFO - 2021-12-21 00:35:48 --> Utf8 Class Initialized
INFO - 2021-12-21 00:35:48 --> URI Class Initialized
INFO - 2021-12-21 00:35:48 --> Router Class Initialized
INFO - 2021-12-21 00:35:48 --> Output Class Initialized
INFO - 2021-12-21 00:35:48 --> Security Class Initialized
DEBUG - 2021-12-21 00:35:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-21 00:35:48 --> Input Class Initialized
INFO - 2021-12-21 00:35:48 --> Language Class Initialized
INFO - 2021-12-21 00:35:48 --> Loader Class Initialized
INFO - 2021-12-21 00:35:48 --> Helper loaded: url_helper
INFO - 2021-12-21 00:35:48 --> Helper loaded: form_helper
INFO - 2021-12-21 00:35:48 --> Helper loaded: common_helper
INFO - 2021-12-21 00:35:48 --> Database Driver Class Initialized
DEBUG - 2021-12-21 00:35:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-21 00:35:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-21 00:35:48 --> Controller Class Initialized
INFO - 2021-12-21 00:35:48 --> Form Validation Class Initialized
DEBUG - 2021-12-21 00:35:48 --> Encrypt Class Initialized
INFO - 2021-12-21 00:35:48 --> Model "Patient_model" initialized
INFO - 2021-12-21 00:35:48 --> Model "Patientcase_model" initialized
INFO - 2021-12-21 00:35:48 --> Model "Prefix_master" initialized
INFO - 2021-12-21 00:35:48 --> Model "Users_model" initialized
INFO - 2021-12-21 00:35:48 --> Model "Hospital_model" initialized
INFO - 2021-12-21 00:35:48 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-21 00:35:48 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2021-12-21 00:35:48 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-21 00:35:48 --> Final output sent to browser
DEBUG - 2021-12-21 00:35:48 --> Total execution time: 0.0849
ERROR - 2021-12-21 00:35:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-21 00:35:49 --> Config Class Initialized
INFO - 2021-12-21 00:35:49 --> Hooks Class Initialized
DEBUG - 2021-12-21 00:35:49 --> UTF-8 Support Enabled
INFO - 2021-12-21 00:35:49 --> Utf8 Class Initialized
INFO - 2021-12-21 00:35:49 --> URI Class Initialized
INFO - 2021-12-21 00:35:49 --> Router Class Initialized
INFO - 2021-12-21 00:35:49 --> Output Class Initialized
INFO - 2021-12-21 00:35:49 --> Security Class Initialized
DEBUG - 2021-12-21 00:35:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-21 00:35:49 --> Input Class Initialized
INFO - 2021-12-21 00:35:49 --> Language Class Initialized
ERROR - 2021-12-21 00:35:49 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-12-21 00:36:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-21 00:36:09 --> Config Class Initialized
INFO - 2021-12-21 00:36:09 --> Hooks Class Initialized
DEBUG - 2021-12-21 00:36:09 --> UTF-8 Support Enabled
INFO - 2021-12-21 00:36:09 --> Utf8 Class Initialized
INFO - 2021-12-21 00:36:09 --> URI Class Initialized
INFO - 2021-12-21 00:36:09 --> Router Class Initialized
INFO - 2021-12-21 00:36:09 --> Output Class Initialized
INFO - 2021-12-21 00:36:09 --> Security Class Initialized
DEBUG - 2021-12-21 00:36:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-21 00:36:09 --> Input Class Initialized
INFO - 2021-12-21 00:36:09 --> Language Class Initialized
INFO - 2021-12-21 00:36:09 --> Loader Class Initialized
INFO - 2021-12-21 00:36:09 --> Helper loaded: url_helper
INFO - 2021-12-21 00:36:09 --> Helper loaded: form_helper
INFO - 2021-12-21 00:36:09 --> Helper loaded: common_helper
INFO - 2021-12-21 00:36:09 --> Database Driver Class Initialized
DEBUG - 2021-12-21 00:36:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-21 00:36:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-21 00:36:09 --> Controller Class Initialized
INFO - 2021-12-21 00:36:09 --> Form Validation Class Initialized
DEBUG - 2021-12-21 00:36:09 --> Encrypt Class Initialized
INFO - 2021-12-21 00:36:09 --> Model "Login_model" initialized
INFO - 2021-12-21 00:36:09 --> Model "Dashboard_model" initialized
INFO - 2021-12-21 00:36:09 --> Model "Case_model" initialized
INFO - 2021-12-21 00:36:17 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-21 00:36:27 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2021-12-21 00:36:27 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-21 00:36:27 --> Final output sent to browser
DEBUG - 2021-12-21 00:36:27 --> Total execution time: 17.4886
ERROR - 2021-12-21 00:36:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-21 00:36:28 --> Config Class Initialized
INFO - 2021-12-21 00:36:28 --> Hooks Class Initialized
DEBUG - 2021-12-21 00:36:28 --> UTF-8 Support Enabled
INFO - 2021-12-21 00:36:28 --> Utf8 Class Initialized
INFO - 2021-12-21 00:36:28 --> URI Class Initialized
INFO - 2021-12-21 00:36:28 --> Router Class Initialized
INFO - 2021-12-21 00:36:28 --> Output Class Initialized
INFO - 2021-12-21 00:36:28 --> Security Class Initialized
DEBUG - 2021-12-21 00:36:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-21 00:36:28 --> Input Class Initialized
INFO - 2021-12-21 00:36:28 --> Language Class Initialized
ERROR - 2021-12-21 00:36:28 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-12-21 00:37:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-21 00:37:09 --> Config Class Initialized
INFO - 2021-12-21 00:37:09 --> Hooks Class Initialized
DEBUG - 2021-12-21 00:37:09 --> UTF-8 Support Enabled
INFO - 2021-12-21 00:37:09 --> Utf8 Class Initialized
INFO - 2021-12-21 00:37:09 --> URI Class Initialized
INFO - 2021-12-21 00:37:09 --> Router Class Initialized
INFO - 2021-12-21 00:37:09 --> Output Class Initialized
INFO - 2021-12-21 00:37:09 --> Security Class Initialized
DEBUG - 2021-12-21 00:37:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-21 00:37:09 --> Input Class Initialized
INFO - 2021-12-21 00:37:09 --> Language Class Initialized
INFO - 2021-12-21 00:37:09 --> Loader Class Initialized
INFO - 2021-12-21 00:37:09 --> Helper loaded: url_helper
INFO - 2021-12-21 00:37:09 --> Helper loaded: form_helper
INFO - 2021-12-21 00:37:09 --> Helper loaded: common_helper
INFO - 2021-12-21 00:37:09 --> Database Driver Class Initialized
DEBUG - 2021-12-21 00:37:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-21 00:37:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-21 00:37:09 --> Controller Class Initialized
INFO - 2021-12-21 00:37:09 --> Form Validation Class Initialized
DEBUG - 2021-12-21 00:37:09 --> Encrypt Class Initialized
INFO - 2021-12-21 00:37:09 --> Model "Login_model" initialized
INFO - 2021-12-21 00:37:09 --> Model "Dashboard_model" initialized
INFO - 2021-12-21 00:37:09 --> Model "Case_model" initialized
INFO - 2021-12-21 00:37:09 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-21 00:37:09 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/birthday.php
INFO - 2021-12-21 00:37:09 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-21 00:37:09 --> Final output sent to browser
DEBUG - 2021-12-21 00:37:09 --> Total execution time: 0.0281
ERROR - 2021-12-21 00:37:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-21 00:37:09 --> Config Class Initialized
INFO - 2021-12-21 00:37:09 --> Hooks Class Initialized
DEBUG - 2021-12-21 00:37:09 --> UTF-8 Support Enabled
INFO - 2021-12-21 00:37:09 --> Utf8 Class Initialized
INFO - 2021-12-21 00:37:09 --> URI Class Initialized
INFO - 2021-12-21 00:37:09 --> Router Class Initialized
INFO - 2021-12-21 00:37:09 --> Output Class Initialized
INFO - 2021-12-21 00:37:09 --> Security Class Initialized
DEBUG - 2021-12-21 00:37:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-21 00:37:09 --> Input Class Initialized
INFO - 2021-12-21 00:37:09 --> Language Class Initialized
ERROR - 2021-12-21 00:37:09 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-12-21 00:38:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-21 00:38:09 --> Config Class Initialized
INFO - 2021-12-21 00:38:09 --> Hooks Class Initialized
DEBUG - 2021-12-21 00:38:09 --> UTF-8 Support Enabled
INFO - 2021-12-21 00:38:09 --> Utf8 Class Initialized
INFO - 2021-12-21 00:38:09 --> URI Class Initialized
INFO - 2021-12-21 00:38:09 --> Router Class Initialized
INFO - 2021-12-21 00:38:09 --> Output Class Initialized
INFO - 2021-12-21 00:38:09 --> Security Class Initialized
DEBUG - 2021-12-21 00:38:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-21 00:38:09 --> Input Class Initialized
INFO - 2021-12-21 00:38:09 --> Language Class Initialized
INFO - 2021-12-21 00:38:09 --> Loader Class Initialized
INFO - 2021-12-21 00:38:09 --> Helper loaded: url_helper
INFO - 2021-12-21 00:38:09 --> Helper loaded: form_helper
INFO - 2021-12-21 00:38:09 --> Helper loaded: common_helper
INFO - 2021-12-21 00:38:09 --> Database Driver Class Initialized
DEBUG - 2021-12-21 00:38:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-21 00:38:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-21 00:38:09 --> Controller Class Initialized
INFO - 2021-12-21 00:38:09 --> Form Validation Class Initialized
DEBUG - 2021-12-21 00:38:09 --> Encrypt Class Initialized
INFO - 2021-12-21 00:38:09 --> Model "Login_model" initialized
INFO - 2021-12-21 00:38:09 --> Model "Dashboard_model" initialized
INFO - 2021-12-21 00:38:09 --> Model "Case_model" initialized
INFO - 2021-12-21 00:38:16 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-21 00:38:25 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2021-12-21 00:38:25 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-21 00:38:25 --> Final output sent to browser
DEBUG - 2021-12-21 00:38:25 --> Total execution time: 15.9967
ERROR - 2021-12-21 00:39:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-21 00:39:11 --> Config Class Initialized
INFO - 2021-12-21 00:39:11 --> Hooks Class Initialized
DEBUG - 2021-12-21 00:39:11 --> UTF-8 Support Enabled
INFO - 2021-12-21 00:39:11 --> Utf8 Class Initialized
INFO - 2021-12-21 00:39:11 --> URI Class Initialized
INFO - 2021-12-21 00:39:11 --> Router Class Initialized
INFO - 2021-12-21 00:39:11 --> Output Class Initialized
INFO - 2021-12-21 00:39:11 --> Security Class Initialized
DEBUG - 2021-12-21 00:39:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-21 00:39:11 --> Input Class Initialized
INFO - 2021-12-21 00:39:11 --> Language Class Initialized
INFO - 2021-12-21 00:39:11 --> Loader Class Initialized
INFO - 2021-12-21 00:39:11 --> Helper loaded: url_helper
INFO - 2021-12-21 00:39:11 --> Helper loaded: form_helper
INFO - 2021-12-21 00:39:11 --> Helper loaded: common_helper
INFO - 2021-12-21 00:39:11 --> Database Driver Class Initialized
DEBUG - 2021-12-21 00:39:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-21 00:39:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-21 00:39:11 --> Controller Class Initialized
INFO - 2021-12-21 00:39:11 --> Form Validation Class Initialized
DEBUG - 2021-12-21 00:39:11 --> Encrypt Class Initialized
INFO - 2021-12-21 00:39:11 --> Model "Login_model" initialized
INFO - 2021-12-21 00:39:11 --> Model "Dashboard_model" initialized
INFO - 2021-12-21 00:39:11 --> Model "Case_model" initialized
INFO - 2021-12-21 00:39:19 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-21 00:39:28 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2021-12-21 00:39:28 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-21 00:39:28 --> Final output sent to browser
DEBUG - 2021-12-21 00:39:28 --> Total execution time: 16.3766
ERROR - 2021-12-21 00:39:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-21 00:39:28 --> Config Class Initialized
INFO - 2021-12-21 00:39:28 --> Hooks Class Initialized
DEBUG - 2021-12-21 00:39:28 --> UTF-8 Support Enabled
INFO - 2021-12-21 00:39:28 --> Utf8 Class Initialized
INFO - 2021-12-21 00:39:28 --> URI Class Initialized
INFO - 2021-12-21 00:39:28 --> Router Class Initialized
INFO - 2021-12-21 00:39:28 --> Output Class Initialized
INFO - 2021-12-21 00:39:28 --> Security Class Initialized
DEBUG - 2021-12-21 00:39:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-21 00:39:28 --> Input Class Initialized
INFO - 2021-12-21 00:39:28 --> Language Class Initialized
ERROR - 2021-12-21 00:39:28 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-12-21 00:44:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-21 00:44:00 --> Config Class Initialized
INFO - 2021-12-21 00:44:00 --> Hooks Class Initialized
DEBUG - 2021-12-21 00:44:00 --> UTF-8 Support Enabled
INFO - 2021-12-21 00:44:00 --> Utf8 Class Initialized
INFO - 2021-12-21 00:44:00 --> URI Class Initialized
INFO - 2021-12-21 00:44:00 --> Router Class Initialized
INFO - 2021-12-21 00:44:00 --> Output Class Initialized
INFO - 2021-12-21 00:44:00 --> Security Class Initialized
DEBUG - 2021-12-21 00:44:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-21 00:44:00 --> Input Class Initialized
INFO - 2021-12-21 00:44:00 --> Language Class Initialized
INFO - 2021-12-21 00:44:00 --> Loader Class Initialized
INFO - 2021-12-21 00:44:00 --> Helper loaded: url_helper
INFO - 2021-12-21 00:44:00 --> Helper loaded: form_helper
INFO - 2021-12-21 00:44:00 --> Helper loaded: common_helper
INFO - 2021-12-21 00:44:00 --> Database Driver Class Initialized
DEBUG - 2021-12-21 00:44:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-21 00:44:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-21 00:44:00 --> Controller Class Initialized
INFO - 2021-12-21 00:44:00 --> Form Validation Class Initialized
INFO - 2021-12-21 00:44:00 --> Model "Report_model" initialized
INFO - 2021-12-21 00:44:00 --> Model "Case_model" initialized
INFO - 2021-12-21 00:44:00 --> Model "Hospital_model" initialized
INFO - 2021-12-21 00:44:00 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-21 00:44:00 --> File loaded: /home3/karoteam/public_html/application/views/reports/donor_wise_patient_details.php
INFO - 2021-12-21 00:44:00 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-21 00:44:00 --> Final output sent to browser
DEBUG - 2021-12-21 00:44:00 --> Total execution time: 0.0288
ERROR - 2021-12-21 00:44:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-21 00:44:01 --> Config Class Initialized
INFO - 2021-12-21 00:44:01 --> Hooks Class Initialized
DEBUG - 2021-12-21 00:44:01 --> UTF-8 Support Enabled
INFO - 2021-12-21 00:44:01 --> Utf8 Class Initialized
INFO - 2021-12-21 00:44:01 --> URI Class Initialized
INFO - 2021-12-21 00:44:01 --> Router Class Initialized
INFO - 2021-12-21 00:44:01 --> Output Class Initialized
INFO - 2021-12-21 00:44:01 --> Security Class Initialized
DEBUG - 2021-12-21 00:44:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-21 00:44:01 --> Input Class Initialized
INFO - 2021-12-21 00:44:01 --> Language Class Initialized
ERROR - 2021-12-21 00:44:01 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-12-21 00:44:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-21 00:44:28 --> Config Class Initialized
INFO - 2021-12-21 00:44:28 --> Hooks Class Initialized
DEBUG - 2021-12-21 00:44:28 --> UTF-8 Support Enabled
INFO - 2021-12-21 00:44:28 --> Utf8 Class Initialized
INFO - 2021-12-21 00:44:28 --> URI Class Initialized
INFO - 2021-12-21 00:44:28 --> Router Class Initialized
INFO - 2021-12-21 00:44:28 --> Output Class Initialized
INFO - 2021-12-21 00:44:28 --> Security Class Initialized
DEBUG - 2021-12-21 00:44:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-21 00:44:28 --> Input Class Initialized
INFO - 2021-12-21 00:44:28 --> Language Class Initialized
INFO - 2021-12-21 00:44:28 --> Loader Class Initialized
INFO - 2021-12-21 00:44:28 --> Helper loaded: url_helper
INFO - 2021-12-21 00:44:28 --> Helper loaded: form_helper
INFO - 2021-12-21 00:44:28 --> Helper loaded: common_helper
INFO - 2021-12-21 00:44:28 --> Database Driver Class Initialized
DEBUG - 2021-12-21 00:44:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-21 00:44:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-21 00:44:28 --> Controller Class Initialized
INFO - 2021-12-21 00:44:28 --> Form Validation Class Initialized
INFO - 2021-12-21 00:44:28 --> Model "Case_model" initialized
INFO - 2021-12-21 00:44:28 --> Model "Patientcase_model" initialized
INFO - 2021-12-21 00:44:29 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-21 00:44:29 --> File loaded: /home3/karoteam/public_html/application/views/cases/new_case.php
INFO - 2021-12-21 00:44:29 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-21 00:44:29 --> Final output sent to browser
DEBUG - 2021-12-21 00:44:29 --> Total execution time: 0.5463
ERROR - 2021-12-21 00:44:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-21 00:44:30 --> Config Class Initialized
INFO - 2021-12-21 00:44:30 --> Hooks Class Initialized
DEBUG - 2021-12-21 00:44:30 --> UTF-8 Support Enabled
INFO - 2021-12-21 00:44:30 --> Utf8 Class Initialized
INFO - 2021-12-21 00:44:30 --> URI Class Initialized
INFO - 2021-12-21 00:44:30 --> Router Class Initialized
INFO - 2021-12-21 00:44:30 --> Output Class Initialized
INFO - 2021-12-21 00:44:30 --> Security Class Initialized
DEBUG - 2021-12-21 00:44:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-21 00:44:30 --> Input Class Initialized
INFO - 2021-12-21 00:44:30 --> Language Class Initialized
ERROR - 2021-12-21 00:44:30 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-12-21 00:46:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-21 00:46:41 --> Config Class Initialized
INFO - 2021-12-21 00:46:41 --> Hooks Class Initialized
DEBUG - 2021-12-21 00:46:41 --> UTF-8 Support Enabled
INFO - 2021-12-21 00:46:41 --> Utf8 Class Initialized
INFO - 2021-12-21 00:46:41 --> URI Class Initialized
INFO - 2021-12-21 00:46:41 --> Router Class Initialized
INFO - 2021-12-21 00:46:41 --> Output Class Initialized
INFO - 2021-12-21 00:46:41 --> Security Class Initialized
DEBUG - 2021-12-21 00:46:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-21 00:46:41 --> Input Class Initialized
INFO - 2021-12-21 00:46:41 --> Language Class Initialized
INFO - 2021-12-21 00:46:41 --> Loader Class Initialized
INFO - 2021-12-21 00:46:41 --> Helper loaded: url_helper
INFO - 2021-12-21 00:46:41 --> Helper loaded: form_helper
INFO - 2021-12-21 00:46:41 --> Helper loaded: common_helper
INFO - 2021-12-21 00:46:41 --> Database Driver Class Initialized
DEBUG - 2021-12-21 00:46:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-21 00:46:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-21 00:46:41 --> Controller Class Initialized
INFO - 2021-12-21 00:46:41 --> Form Validation Class Initialized
DEBUG - 2021-12-21 00:46:41 --> Encrypt Class Initialized
INFO - 2021-12-21 00:46:41 --> Model "Patient_model" initialized
INFO - 2021-12-21 00:46:41 --> Model "Patientcase_model" initialized
INFO - 2021-12-21 00:46:41 --> Model "Prefix_master" initialized
INFO - 2021-12-21 00:46:41 --> Model "Users_model" initialized
INFO - 2021-12-21 00:46:41 --> Model "Hospital_model" initialized
INFO - 2021-12-21 00:46:41 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-21 00:46:41 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2021-12-21 00:46:41 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-21 00:46:41 --> Final output sent to browser
DEBUG - 2021-12-21 00:46:41 --> Total execution time: 0.0823
ERROR - 2021-12-21 00:46:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-21 00:46:42 --> Config Class Initialized
INFO - 2021-12-21 00:46:42 --> Hooks Class Initialized
DEBUG - 2021-12-21 00:46:42 --> UTF-8 Support Enabled
INFO - 2021-12-21 00:46:42 --> Utf8 Class Initialized
INFO - 2021-12-21 00:46:42 --> URI Class Initialized
INFO - 2021-12-21 00:46:42 --> Router Class Initialized
INFO - 2021-12-21 00:46:42 --> Output Class Initialized
INFO - 2021-12-21 00:46:42 --> Security Class Initialized
DEBUG - 2021-12-21 00:46:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-21 00:46:42 --> Input Class Initialized
INFO - 2021-12-21 00:46:42 --> Language Class Initialized
ERROR - 2021-12-21 00:46:42 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-12-21 00:46:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-21 00:46:54 --> Config Class Initialized
INFO - 2021-12-21 00:46:54 --> Hooks Class Initialized
DEBUG - 2021-12-21 00:46:54 --> UTF-8 Support Enabled
INFO - 2021-12-21 00:46:54 --> Utf8 Class Initialized
INFO - 2021-12-21 00:46:54 --> URI Class Initialized
INFO - 2021-12-21 00:46:54 --> Router Class Initialized
INFO - 2021-12-21 00:46:54 --> Output Class Initialized
INFO - 2021-12-21 00:46:54 --> Security Class Initialized
DEBUG - 2021-12-21 00:46:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-21 00:46:54 --> Input Class Initialized
INFO - 2021-12-21 00:46:54 --> Language Class Initialized
INFO - 2021-12-21 00:46:54 --> Loader Class Initialized
INFO - 2021-12-21 00:46:54 --> Helper loaded: url_helper
INFO - 2021-12-21 00:46:54 --> Helper loaded: form_helper
INFO - 2021-12-21 00:46:54 --> Helper loaded: common_helper
INFO - 2021-12-21 00:46:54 --> Database Driver Class Initialized
DEBUG - 2021-12-21 00:46:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-21 00:46:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-21 00:46:54 --> Controller Class Initialized
INFO - 2021-12-21 00:46:54 --> Form Validation Class Initialized
DEBUG - 2021-12-21 00:46:54 --> Encrypt Class Initialized
INFO - 2021-12-21 00:46:54 --> Model "Patient_model" initialized
INFO - 2021-12-21 00:46:54 --> Model "Patientcase_model" initialized
INFO - 2021-12-21 00:46:54 --> Model "Referredby_model" initialized
INFO - 2021-12-21 00:46:54 --> Model "Prefix_master" initialized
INFO - 2021-12-21 00:46:54 --> Model "Hospital_model" initialized
ERROR - 2021-12-21 00:46:54 --> Severity: error --> Exception: Too few arguments to function Patient_model::getPatient(), 1 passed in /home3/karoteam/public_html/application/controllers/Patientmaster.php on line 25 and exactly 5 expected /home3/karoteam/public_html/application/models/Patient_model.php 6
ERROR - 2021-12-21 00:47:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-21 00:47:17 --> Config Class Initialized
INFO - 2021-12-21 00:47:17 --> Hooks Class Initialized
DEBUG - 2021-12-21 00:47:17 --> UTF-8 Support Enabled
INFO - 2021-12-21 00:47:17 --> Utf8 Class Initialized
INFO - 2021-12-21 00:47:17 --> URI Class Initialized
INFO - 2021-12-21 00:47:17 --> Router Class Initialized
INFO - 2021-12-21 00:47:17 --> Output Class Initialized
INFO - 2021-12-21 00:47:17 --> Security Class Initialized
DEBUG - 2021-12-21 00:47:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-21 00:47:17 --> Input Class Initialized
INFO - 2021-12-21 00:47:17 --> Language Class Initialized
INFO - 2021-12-21 00:47:17 --> Loader Class Initialized
INFO - 2021-12-21 00:47:17 --> Helper loaded: url_helper
INFO - 2021-12-21 00:47:17 --> Helper loaded: form_helper
INFO - 2021-12-21 00:47:17 --> Helper loaded: common_helper
INFO - 2021-12-21 00:47:17 --> Database Driver Class Initialized
DEBUG - 2021-12-21 00:47:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-21 00:47:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-21 00:47:17 --> Controller Class Initialized
INFO - 2021-12-21 00:47:17 --> Form Validation Class Initialized
INFO - 2021-12-21 00:47:17 --> Model "Case_model" initialized
INFO - 2021-12-21 00:47:17 --> Model "Patientcase_model" initialized
INFO - 2021-12-21 00:47:19 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-21 00:47:19 --> Model "Case_model" initialized
INFO - 2021-12-21 00:47:21 --> File loaded: /home3/karoteam/public_html/application/views/cases/open_case.php
INFO - 2021-12-21 00:47:21 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-21 00:47:22 --> Final output sent to browser
DEBUG - 2021-12-21 00:47:22 --> Total execution time: 4.4986
ERROR - 2021-12-21 00:47:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-21 00:47:22 --> Config Class Initialized
INFO - 2021-12-21 00:47:22 --> Hooks Class Initialized
DEBUG - 2021-12-21 00:47:22 --> UTF-8 Support Enabled
INFO - 2021-12-21 00:47:22 --> Utf8 Class Initialized
INFO - 2021-12-21 00:47:22 --> URI Class Initialized
INFO - 2021-12-21 00:47:22 --> Router Class Initialized
INFO - 2021-12-21 00:47:22 --> Output Class Initialized
INFO - 2021-12-21 00:47:22 --> Security Class Initialized
DEBUG - 2021-12-21 00:47:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-21 00:47:22 --> Input Class Initialized
INFO - 2021-12-21 00:47:22 --> Language Class Initialized
ERROR - 2021-12-21 00:47:22 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-12-21 00:47:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-21 00:47:29 --> Config Class Initialized
INFO - 2021-12-21 00:47:29 --> Hooks Class Initialized
DEBUG - 2021-12-21 00:47:29 --> UTF-8 Support Enabled
INFO - 2021-12-21 00:47:29 --> Utf8 Class Initialized
INFO - 2021-12-21 00:47:29 --> URI Class Initialized
INFO - 2021-12-21 00:47:29 --> Router Class Initialized
INFO - 2021-12-21 00:47:29 --> Output Class Initialized
INFO - 2021-12-21 00:47:29 --> Security Class Initialized
DEBUG - 2021-12-21 00:47:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-21 00:47:29 --> Input Class Initialized
INFO - 2021-12-21 00:47:29 --> Language Class Initialized
INFO - 2021-12-21 00:47:29 --> Loader Class Initialized
INFO - 2021-12-21 00:47:29 --> Helper loaded: url_helper
INFO - 2021-12-21 00:47:29 --> Helper loaded: form_helper
INFO - 2021-12-21 00:47:29 --> Helper loaded: common_helper
INFO - 2021-12-21 00:47:29 --> Database Driver Class Initialized
DEBUG - 2021-12-21 00:47:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-21 00:47:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-21 00:47:29 --> Controller Class Initialized
INFO - 2021-12-21 00:47:29 --> Form Validation Class Initialized
DEBUG - 2021-12-21 00:47:29 --> Encrypt Class Initialized
INFO - 2021-12-21 00:47:29 --> Model "Patient_model" initialized
INFO - 2021-12-21 00:47:29 --> Model "Patientcase_model" initialized
INFO - 2021-12-21 00:47:29 --> Model "Prefix_master" initialized
INFO - 2021-12-21 00:47:29 --> Model "Users_model" initialized
INFO - 2021-12-21 00:47:29 --> Model "Hospital_model" initialized
INFO - 2021-12-21 00:47:29 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-21 00:47:29 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2021-12-21 00:47:29 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-21 00:47:29 --> Final output sent to browser
DEBUG - 2021-12-21 00:47:29 --> Total execution time: 0.0853
ERROR - 2021-12-21 00:47:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-21 00:47:30 --> Config Class Initialized
INFO - 2021-12-21 00:47:30 --> Hooks Class Initialized
DEBUG - 2021-12-21 00:47:30 --> UTF-8 Support Enabled
INFO - 2021-12-21 00:47:30 --> Utf8 Class Initialized
INFO - 2021-12-21 00:47:30 --> URI Class Initialized
INFO - 2021-12-21 00:47:30 --> Router Class Initialized
INFO - 2021-12-21 00:47:30 --> Output Class Initialized
INFO - 2021-12-21 00:47:30 --> Security Class Initialized
DEBUG - 2021-12-21 00:47:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-21 00:47:30 --> Input Class Initialized
INFO - 2021-12-21 00:47:30 --> Language Class Initialized
ERROR - 2021-12-21 00:47:30 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-12-21 00:48:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-21 00:48:07 --> Config Class Initialized
INFO - 2021-12-21 00:48:07 --> Hooks Class Initialized
DEBUG - 2021-12-21 00:48:07 --> UTF-8 Support Enabled
INFO - 2021-12-21 00:48:07 --> Utf8 Class Initialized
INFO - 2021-12-21 00:48:07 --> URI Class Initialized
INFO - 2021-12-21 00:48:07 --> Router Class Initialized
INFO - 2021-12-21 00:48:07 --> Output Class Initialized
INFO - 2021-12-21 00:48:07 --> Security Class Initialized
DEBUG - 2021-12-21 00:48:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-21 00:48:07 --> Input Class Initialized
INFO - 2021-12-21 00:48:07 --> Language Class Initialized
INFO - 2021-12-21 00:48:07 --> Loader Class Initialized
INFO - 2021-12-21 00:48:07 --> Helper loaded: url_helper
INFO - 2021-12-21 00:48:07 --> Helper loaded: form_helper
INFO - 2021-12-21 00:48:07 --> Helper loaded: common_helper
INFO - 2021-12-21 00:48:07 --> Database Driver Class Initialized
DEBUG - 2021-12-21 00:48:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-21 00:48:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-21 00:48:07 --> Controller Class Initialized
INFO - 2021-12-21 00:48:07 --> Form Validation Class Initialized
DEBUG - 2021-12-21 00:48:07 --> Encrypt Class Initialized
INFO - 2021-12-21 00:48:07 --> Model "Patient_model" initialized
INFO - 2021-12-21 00:48:07 --> Model "Patientcase_model" initialized
INFO - 2021-12-21 00:48:07 --> Model "Referredby_model" initialized
INFO - 2021-12-21 00:48:07 --> Model "Prefix_master" initialized
INFO - 2021-12-21 00:48:07 --> Model "Hospital_model" initialized
ERROR - 2021-12-21 00:48:07 --> Severity: error --> Exception: Too few arguments to function Patient_model::getPatient(), 1 passed in /home3/karoteam/public_html/application/controllers/Patientmaster.php on line 25 and exactly 5 expected /home3/karoteam/public_html/application/models/Patient_model.php 6
ERROR - 2021-12-21 00:48:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-21 00:48:20 --> Config Class Initialized
INFO - 2021-12-21 00:48:20 --> Hooks Class Initialized
DEBUG - 2021-12-21 00:48:20 --> UTF-8 Support Enabled
INFO - 2021-12-21 00:48:20 --> Utf8 Class Initialized
INFO - 2021-12-21 00:48:20 --> URI Class Initialized
INFO - 2021-12-21 00:48:20 --> Router Class Initialized
INFO - 2021-12-21 00:48:20 --> Output Class Initialized
INFO - 2021-12-21 00:48:20 --> Security Class Initialized
DEBUG - 2021-12-21 00:48:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-21 00:48:20 --> Input Class Initialized
INFO - 2021-12-21 00:48:20 --> Language Class Initialized
INFO - 2021-12-21 00:48:20 --> Loader Class Initialized
INFO - 2021-12-21 00:48:20 --> Helper loaded: url_helper
INFO - 2021-12-21 00:48:20 --> Helper loaded: form_helper
INFO - 2021-12-21 00:48:20 --> Helper loaded: common_helper
INFO - 2021-12-21 00:48:20 --> Database Driver Class Initialized
DEBUG - 2021-12-21 00:48:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-21 00:48:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-21 00:48:20 --> Controller Class Initialized
INFO - 2021-12-21 00:48:20 --> Form Validation Class Initialized
DEBUG - 2021-12-21 00:48:20 --> Encrypt Class Initialized
INFO - 2021-12-21 00:48:20 --> Model "Patient_model" initialized
INFO - 2021-12-21 00:48:20 --> Model "Patientcase_model" initialized
INFO - 2021-12-21 00:48:20 --> Model "Referredby_model" initialized
INFO - 2021-12-21 00:48:20 --> Model "Prefix_master" initialized
INFO - 2021-12-21 00:48:20 --> Model "Hospital_model" initialized
INFO - 2021-12-21 00:48:20 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-21 00:48:26 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2021-12-21 00:48:26 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
ERROR - 2021-12-21 00:48:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-21 00:48:27 --> Config Class Initialized
INFO - 2021-12-21 00:48:27 --> Hooks Class Initialized
DEBUG - 2021-12-21 00:48:27 --> UTF-8 Support Enabled
INFO - 2021-12-21 00:48:27 --> Utf8 Class Initialized
INFO - 2021-12-21 00:48:27 --> URI Class Initialized
INFO - 2021-12-21 00:48:27 --> Router Class Initialized
INFO - 2021-12-21 00:48:27 --> Output Class Initialized
INFO - 2021-12-21 00:48:27 --> Security Class Initialized
DEBUG - 2021-12-21 00:48:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-21 00:48:27 --> Input Class Initialized
INFO - 2021-12-21 00:48:27 --> Language Class Initialized
ERROR - 2021-12-21 00:48:27 --> 404 Page Not Found: Karoclient/usersprofile
INFO - 2021-12-21 00:48:28 --> Final output sent to browser
DEBUG - 2021-12-21 00:48:28 --> Total execution time: 5.5910
ERROR - 2021-12-21 00:49:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-21 00:49:27 --> Config Class Initialized
INFO - 2021-12-21 00:49:27 --> Hooks Class Initialized
DEBUG - 2021-12-21 00:49:27 --> UTF-8 Support Enabled
INFO - 2021-12-21 00:49:27 --> Utf8 Class Initialized
INFO - 2021-12-21 00:49:27 --> URI Class Initialized
INFO - 2021-12-21 00:49:27 --> Router Class Initialized
INFO - 2021-12-21 00:49:27 --> Output Class Initialized
INFO - 2021-12-21 00:49:27 --> Security Class Initialized
DEBUG - 2021-12-21 00:49:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-21 00:49:27 --> Input Class Initialized
INFO - 2021-12-21 00:49:27 --> Language Class Initialized
INFO - 2021-12-21 00:49:27 --> Loader Class Initialized
INFO - 2021-12-21 00:49:27 --> Helper loaded: url_helper
INFO - 2021-12-21 00:49:27 --> Helper loaded: form_helper
INFO - 2021-12-21 00:49:27 --> Helper loaded: common_helper
INFO - 2021-12-21 00:49:27 --> Database Driver Class Initialized
DEBUG - 2021-12-21 00:49:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-21 00:49:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-21 00:49:27 --> Controller Class Initialized
INFO - 2021-12-21 00:49:27 --> Form Validation Class Initialized
DEBUG - 2021-12-21 00:49:27 --> Encrypt Class Initialized
INFO - 2021-12-21 00:49:27 --> Model "Patient_model" initialized
INFO - 2021-12-21 00:49:27 --> Model "Patientcase_model" initialized
INFO - 2021-12-21 00:49:27 --> Model "Referredby_model" initialized
INFO - 2021-12-21 00:49:27 --> Model "Prefix_master" initialized
INFO - 2021-12-21 00:49:27 --> Model "Hospital_model" initialized
ERROR - 2021-12-21 00:49:27 --> Severity: error --> Exception: Too few arguments to function Patient_model::getPatient(), 1 passed in /home3/karoteam/public_html/application/controllers/Patientmaster.php on line 25 and exactly 5 expected /home3/karoteam/public_html/application/models/Patient_model.php 6
ERROR - 2021-12-21 00:49:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-21 00:49:41 --> Config Class Initialized
INFO - 2021-12-21 00:49:41 --> Hooks Class Initialized
DEBUG - 2021-12-21 00:49:41 --> UTF-8 Support Enabled
INFO - 2021-12-21 00:49:41 --> Utf8 Class Initialized
INFO - 2021-12-21 00:49:41 --> URI Class Initialized
INFO - 2021-12-21 00:49:41 --> Router Class Initialized
INFO - 2021-12-21 00:49:41 --> Output Class Initialized
INFO - 2021-12-21 00:49:41 --> Security Class Initialized
DEBUG - 2021-12-21 00:49:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-21 00:49:41 --> Input Class Initialized
INFO - 2021-12-21 00:49:41 --> Language Class Initialized
INFO - 2021-12-21 00:49:41 --> Loader Class Initialized
INFO - 2021-12-21 00:49:41 --> Helper loaded: url_helper
INFO - 2021-12-21 00:49:41 --> Helper loaded: form_helper
INFO - 2021-12-21 00:49:41 --> Helper loaded: common_helper
INFO - 2021-12-21 00:49:41 --> Database Driver Class Initialized
DEBUG - 2021-12-21 00:49:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-21 00:49:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-21 00:49:41 --> Controller Class Initialized
INFO - 2021-12-21 00:49:41 --> Form Validation Class Initialized
DEBUG - 2021-12-21 00:49:41 --> Encrypt Class Initialized
INFO - 2021-12-21 00:49:41 --> Model "Patient_model" initialized
INFO - 2021-12-21 00:49:41 --> Model "Patientcase_model" initialized
INFO - 2021-12-21 00:49:41 --> Model "Referredby_model" initialized
INFO - 2021-12-21 00:49:41 --> Model "Prefix_master" initialized
INFO - 2021-12-21 00:49:41 --> Model "Hospital_model" initialized
INFO - 2021-12-21 00:49:41 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-21 00:49:46 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2021-12-21 00:49:46 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-21 00:49:48 --> Final output sent to browser
DEBUG - 2021-12-21 00:49:48 --> Total execution time: 5.5720
ERROR - 2021-12-21 00:50:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-21 00:50:28 --> Config Class Initialized
INFO - 2021-12-21 00:50:28 --> Hooks Class Initialized
DEBUG - 2021-12-21 00:50:28 --> UTF-8 Support Enabled
INFO - 2021-12-21 00:50:28 --> Utf8 Class Initialized
INFO - 2021-12-21 00:50:28 --> URI Class Initialized
INFO - 2021-12-21 00:50:28 --> Router Class Initialized
INFO - 2021-12-21 00:50:28 --> Output Class Initialized
INFO - 2021-12-21 00:50:28 --> Security Class Initialized
DEBUG - 2021-12-21 00:50:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-21 00:50:28 --> Input Class Initialized
INFO - 2021-12-21 00:50:28 --> Language Class Initialized
INFO - 2021-12-21 00:50:28 --> Loader Class Initialized
INFO - 2021-12-21 00:50:28 --> Helper loaded: url_helper
INFO - 2021-12-21 00:50:28 --> Helper loaded: form_helper
INFO - 2021-12-21 00:50:28 --> Helper loaded: common_helper
INFO - 2021-12-21 00:50:28 --> Database Driver Class Initialized
DEBUG - 2021-12-21 00:50:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-21 00:50:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-21 00:50:28 --> Controller Class Initialized
INFO - 2021-12-21 00:50:28 --> Form Validation Class Initialized
DEBUG - 2021-12-21 00:50:28 --> Encrypt Class Initialized
INFO - 2021-12-21 00:50:28 --> Model "Patient_model" initialized
INFO - 2021-12-21 00:50:28 --> Model "Patientcase_model" initialized
INFO - 2021-12-21 00:50:28 --> Model "Referredby_model" initialized
INFO - 2021-12-21 00:50:28 --> Model "Prefix_master" initialized
INFO - 2021-12-21 00:50:28 --> Model "Hospital_model" initialized
ERROR - 2021-12-21 00:50:28 --> Severity: error --> Exception: Too few arguments to function Patient_model::getPatient(), 1 passed in /home3/karoteam/public_html/application/controllers/Patientmaster.php on line 25 and exactly 5 expected /home3/karoteam/public_html/application/models/Patient_model.php 6
ERROR - 2021-12-21 00:50:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-21 00:50:31 --> Config Class Initialized
INFO - 2021-12-21 00:50:31 --> Hooks Class Initialized
DEBUG - 2021-12-21 00:50:31 --> UTF-8 Support Enabled
INFO - 2021-12-21 00:50:31 --> Utf8 Class Initialized
INFO - 2021-12-21 00:50:31 --> URI Class Initialized
INFO - 2021-12-21 00:50:31 --> Router Class Initialized
INFO - 2021-12-21 00:50:31 --> Output Class Initialized
INFO - 2021-12-21 00:50:31 --> Security Class Initialized
DEBUG - 2021-12-21 00:50:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-21 00:50:31 --> Input Class Initialized
INFO - 2021-12-21 00:50:31 --> Language Class Initialized
INFO - 2021-12-21 00:50:31 --> Loader Class Initialized
INFO - 2021-12-21 00:50:31 --> Helper loaded: url_helper
INFO - 2021-12-21 00:50:31 --> Helper loaded: form_helper
INFO - 2021-12-21 00:50:31 --> Helper loaded: common_helper
INFO - 2021-12-21 00:50:31 --> Database Driver Class Initialized
DEBUG - 2021-12-21 00:50:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-21 00:50:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-21 00:50:31 --> Controller Class Initialized
INFO - 2021-12-21 00:50:31 --> Form Validation Class Initialized
DEBUG - 2021-12-21 00:50:31 --> Encrypt Class Initialized
INFO - 2021-12-21 00:50:31 --> Model "Patient_model" initialized
INFO - 2021-12-21 00:50:31 --> Model "Patientcase_model" initialized
INFO - 2021-12-21 00:50:31 --> Model "Referredby_model" initialized
INFO - 2021-12-21 00:50:31 --> Model "Prefix_master" initialized
INFO - 2021-12-21 00:50:31 --> Model "Hospital_model" initialized
INFO - 2021-12-21 00:50:31 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-21 00:50:36 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2021-12-21 00:50:36 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-21 00:50:37 --> Final output sent to browser
DEBUG - 2021-12-21 00:50:37 --> Total execution time: 5.0526
ERROR - 2021-12-21 00:51:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-21 00:51:59 --> Config Class Initialized
INFO - 2021-12-21 00:51:59 --> Hooks Class Initialized
DEBUG - 2021-12-21 00:51:59 --> UTF-8 Support Enabled
INFO - 2021-12-21 00:51:59 --> Utf8 Class Initialized
INFO - 2021-12-21 00:51:59 --> URI Class Initialized
INFO - 2021-12-21 00:51:59 --> Router Class Initialized
INFO - 2021-12-21 00:51:59 --> Output Class Initialized
INFO - 2021-12-21 00:51:59 --> Security Class Initialized
DEBUG - 2021-12-21 00:51:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-21 00:51:59 --> Input Class Initialized
INFO - 2021-12-21 00:51:59 --> Language Class Initialized
INFO - 2021-12-21 00:51:59 --> Loader Class Initialized
INFO - 2021-12-21 00:51:59 --> Helper loaded: url_helper
INFO - 2021-12-21 00:51:59 --> Helper loaded: form_helper
INFO - 2021-12-21 00:51:59 --> Helper loaded: common_helper
INFO - 2021-12-21 00:51:59 --> Database Driver Class Initialized
DEBUG - 2021-12-21 00:51:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-21 00:51:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-21 00:51:59 --> Controller Class Initialized
INFO - 2021-12-21 00:51:59 --> Form Validation Class Initialized
DEBUG - 2021-12-21 00:51:59 --> Encrypt Class Initialized
INFO - 2021-12-21 00:51:59 --> Model "Patient_model" initialized
INFO - 2021-12-21 00:51:59 --> Model "Patientcase_model" initialized
INFO - 2021-12-21 00:51:59 --> Model "Referredby_model" initialized
INFO - 2021-12-21 00:51:59 --> Model "Prefix_master" initialized
INFO - 2021-12-21 00:51:59 --> Model "Hospital_model" initialized
INFO - 2021-12-21 00:51:59 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-21 00:51:59 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2021-12-21 00:51:59 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-21 00:51:59 --> Final output sent to browser
DEBUG - 2021-12-21 00:51:59 --> Total execution time: 0.0422
ERROR - 2021-12-21 00:51:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-21 00:51:59 --> Config Class Initialized
INFO - 2021-12-21 00:51:59 --> Hooks Class Initialized
DEBUG - 2021-12-21 00:51:59 --> UTF-8 Support Enabled
INFO - 2021-12-21 00:51:59 --> Utf8 Class Initialized
INFO - 2021-12-21 00:51:59 --> URI Class Initialized
INFO - 2021-12-21 00:51:59 --> Router Class Initialized
INFO - 2021-12-21 00:51:59 --> Output Class Initialized
INFO - 2021-12-21 00:51:59 --> Security Class Initialized
DEBUG - 2021-12-21 00:51:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-21 00:51:59 --> Input Class Initialized
INFO - 2021-12-21 00:51:59 --> Language Class Initialized
ERROR - 2021-12-21 00:51:59 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-12-21 00:52:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-21 00:52:27 --> Config Class Initialized
INFO - 2021-12-21 00:52:27 --> Hooks Class Initialized
DEBUG - 2021-12-21 00:52:27 --> UTF-8 Support Enabled
INFO - 2021-12-21 00:52:27 --> Utf8 Class Initialized
INFO - 2021-12-21 00:52:27 --> URI Class Initialized
INFO - 2021-12-21 00:52:27 --> Router Class Initialized
INFO - 2021-12-21 00:52:27 --> Output Class Initialized
INFO - 2021-12-21 00:52:27 --> Security Class Initialized
DEBUG - 2021-12-21 00:52:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-21 00:52:27 --> Input Class Initialized
INFO - 2021-12-21 00:52:27 --> Language Class Initialized
INFO - 2021-12-21 00:52:27 --> Loader Class Initialized
INFO - 2021-12-21 00:52:27 --> Helper loaded: url_helper
INFO - 2021-12-21 00:52:27 --> Helper loaded: form_helper
INFO - 2021-12-21 00:52:27 --> Helper loaded: common_helper
INFO - 2021-12-21 00:52:27 --> Database Driver Class Initialized
DEBUG - 2021-12-21 00:52:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-21 00:52:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-21 00:52:27 --> Controller Class Initialized
INFO - 2021-12-21 00:52:27 --> Form Validation Class Initialized
DEBUG - 2021-12-21 00:52:27 --> Encrypt Class Initialized
INFO - 2021-12-21 00:52:27 --> Model "Patient_model" initialized
INFO - 2021-12-21 00:52:27 --> Model "Patientcase_model" initialized
INFO - 2021-12-21 00:52:27 --> Model "Referredby_model" initialized
INFO - 2021-12-21 00:52:27 --> Model "Prefix_master" initialized
INFO - 2021-12-21 00:52:27 --> Model "Hospital_model" initialized
INFO - 2021-12-21 00:52:28 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-21 00:52:33 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2021-12-21 00:52:33 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
ERROR - 2021-12-21 00:52:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-21 00:52:34 --> Config Class Initialized
INFO - 2021-12-21 00:52:34 --> Hooks Class Initialized
DEBUG - 2021-12-21 00:52:34 --> UTF-8 Support Enabled
INFO - 2021-12-21 00:52:34 --> Utf8 Class Initialized
INFO - 2021-12-21 00:52:34 --> URI Class Initialized
INFO - 2021-12-21 00:52:34 --> Router Class Initialized
INFO - 2021-12-21 00:52:34 --> Output Class Initialized
INFO - 2021-12-21 00:52:34 --> Security Class Initialized
DEBUG - 2021-12-21 00:52:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-21 00:52:34 --> Input Class Initialized
INFO - 2021-12-21 00:52:34 --> Language Class Initialized
ERROR - 2021-12-21 00:52:34 --> 404 Page Not Found: Karoclient/usersprofile
INFO - 2021-12-21 00:52:35 --> Final output sent to browser
DEBUG - 2021-12-21 00:52:35 --> Total execution time: 5.4376
ERROR - 2021-12-21 00:53:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-21 00:53:30 --> Config Class Initialized
INFO - 2021-12-21 00:53:30 --> Hooks Class Initialized
DEBUG - 2021-12-21 00:53:30 --> UTF-8 Support Enabled
INFO - 2021-12-21 00:53:30 --> Utf8 Class Initialized
INFO - 2021-12-21 00:53:30 --> URI Class Initialized
INFO - 2021-12-21 00:53:30 --> Router Class Initialized
INFO - 2021-12-21 00:53:30 --> Output Class Initialized
INFO - 2021-12-21 00:53:30 --> Security Class Initialized
DEBUG - 2021-12-21 00:53:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-21 00:53:30 --> Input Class Initialized
INFO - 2021-12-21 00:53:30 --> Language Class Initialized
INFO - 2021-12-21 00:53:30 --> Loader Class Initialized
INFO - 2021-12-21 00:53:30 --> Helper loaded: url_helper
INFO - 2021-12-21 00:53:30 --> Helper loaded: form_helper
INFO - 2021-12-21 00:53:30 --> Helper loaded: common_helper
INFO - 2021-12-21 00:53:30 --> Database Driver Class Initialized
DEBUG - 2021-12-21 00:53:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-21 00:53:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-21 00:53:31 --> Controller Class Initialized
INFO - 2021-12-21 00:53:31 --> Form Validation Class Initialized
INFO - 2021-12-21 00:53:31 --> Model "Case_model" initialized
INFO - 2021-12-21 00:53:31 --> Model "Patientcase_model" initialized
INFO - 2021-12-21 00:53:31 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-21 00:53:31 --> File loaded: /home3/karoteam/public_html/application/views/cases/new_case.php
INFO - 2021-12-21 00:53:31 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-21 00:53:32 --> Final output sent to browser
DEBUG - 2021-12-21 00:53:32 --> Total execution time: 0.5468
ERROR - 2021-12-21 00:53:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-21 00:53:32 --> Config Class Initialized
INFO - 2021-12-21 00:53:32 --> Hooks Class Initialized
DEBUG - 2021-12-21 00:53:32 --> UTF-8 Support Enabled
INFO - 2021-12-21 00:53:32 --> Utf8 Class Initialized
INFO - 2021-12-21 00:53:32 --> URI Class Initialized
INFO - 2021-12-21 00:53:32 --> Router Class Initialized
INFO - 2021-12-21 00:53:32 --> Output Class Initialized
INFO - 2021-12-21 00:53:32 --> Security Class Initialized
DEBUG - 2021-12-21 00:53:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-21 00:53:32 --> Input Class Initialized
INFO - 2021-12-21 00:53:32 --> Language Class Initialized
ERROR - 2021-12-21 00:53:32 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-12-21 03:07:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-21 03:07:54 --> Config Class Initialized
INFO - 2021-12-21 03:07:54 --> Hooks Class Initialized
DEBUG - 2021-12-21 03:07:54 --> UTF-8 Support Enabled
INFO - 2021-12-21 03:07:54 --> Utf8 Class Initialized
INFO - 2021-12-21 03:07:54 --> URI Class Initialized
INFO - 2021-12-21 03:07:54 --> Router Class Initialized
INFO - 2021-12-21 03:07:54 --> Output Class Initialized
INFO - 2021-12-21 03:07:54 --> Security Class Initialized
DEBUG - 2021-12-21 03:07:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-21 03:07:54 --> Input Class Initialized
INFO - 2021-12-21 03:07:54 --> Language Class Initialized
INFO - 2021-12-21 03:07:54 --> Loader Class Initialized
INFO - 2021-12-21 03:07:54 --> Helper loaded: url_helper
INFO - 2021-12-21 03:07:54 --> Helper loaded: form_helper
INFO - 2021-12-21 03:07:54 --> Helper loaded: common_helper
INFO - 2021-12-21 03:07:54 --> Database Driver Class Initialized
DEBUG - 2021-12-21 03:07:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-21 03:07:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-21 03:07:54 --> Controller Class Initialized
ERROR - 2021-12-21 03:07:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-21 03:07:55 --> Config Class Initialized
INFO - 2021-12-21 03:07:55 --> Hooks Class Initialized
DEBUG - 2021-12-21 03:07:55 --> UTF-8 Support Enabled
INFO - 2021-12-21 03:07:55 --> Utf8 Class Initialized
INFO - 2021-12-21 03:07:55 --> URI Class Initialized
INFO - 2021-12-21 03:07:55 --> Router Class Initialized
INFO - 2021-12-21 03:07:55 --> Output Class Initialized
INFO - 2021-12-21 03:07:55 --> Security Class Initialized
DEBUG - 2021-12-21 03:07:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-21 03:07:55 --> Input Class Initialized
INFO - 2021-12-21 03:07:55 --> Language Class Initialized
INFO - 2021-12-21 03:07:55 --> Loader Class Initialized
INFO - 2021-12-21 03:07:55 --> Helper loaded: url_helper
INFO - 2021-12-21 03:07:55 --> Helper loaded: form_helper
INFO - 2021-12-21 03:07:55 --> Helper loaded: common_helper
INFO - 2021-12-21 03:07:55 --> Database Driver Class Initialized
DEBUG - 2021-12-21 03:07:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-21 03:07:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-21 03:07:55 --> Controller Class Initialized
INFO - 2021-12-21 03:07:55 --> Form Validation Class Initialized
DEBUG - 2021-12-21 03:07:55 --> Encrypt Class Initialized
DEBUG - 2021-12-21 03:07:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-21 03:07:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-21 03:07:55 --> Email Class Initialized
INFO - 2021-12-21 03:07:55 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-21 03:07:55 --> Calendar Class Initialized
INFO - 2021-12-21 03:07:55 --> Model "Login_model" initialized
INFO - 2021-12-21 03:07:55 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-21 03:07:55 --> Final output sent to browser
DEBUG - 2021-12-21 03:07:55 --> Total execution time: 0.0204
ERROR - 2021-12-21 03:17:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-21 03:17:15 --> Config Class Initialized
INFO - 2021-12-21 03:17:15 --> Hooks Class Initialized
DEBUG - 2021-12-21 03:17:15 --> UTF-8 Support Enabled
INFO - 2021-12-21 03:17:15 --> Utf8 Class Initialized
INFO - 2021-12-21 03:17:15 --> URI Class Initialized
INFO - 2021-12-21 03:17:15 --> Router Class Initialized
INFO - 2021-12-21 03:17:15 --> Output Class Initialized
INFO - 2021-12-21 03:17:15 --> Security Class Initialized
DEBUG - 2021-12-21 03:17:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-21 03:17:15 --> Input Class Initialized
INFO - 2021-12-21 03:17:15 --> Language Class Initialized
INFO - 2021-12-21 03:17:15 --> Loader Class Initialized
INFO - 2021-12-21 03:17:15 --> Helper loaded: url_helper
INFO - 2021-12-21 03:17:15 --> Helper loaded: form_helper
INFO - 2021-12-21 03:17:15 --> Helper loaded: common_helper
INFO - 2021-12-21 03:17:15 --> Database Driver Class Initialized
DEBUG - 2021-12-21 03:17:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-21 03:17:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-21 03:17:15 --> Controller Class Initialized
INFO - 2021-12-21 03:17:15 --> Form Validation Class Initialized
DEBUG - 2021-12-21 03:17:15 --> Encrypt Class Initialized
DEBUG - 2021-12-21 03:17:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-21 03:17:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-21 03:17:15 --> Email Class Initialized
INFO - 2021-12-21 03:17:15 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-21 03:17:15 --> Calendar Class Initialized
INFO - 2021-12-21 03:17:15 --> Model "Login_model" initialized
INFO - 2021-12-21 03:17:15 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2021-12-21 03:17:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-21 03:17:15 --> Config Class Initialized
INFO - 2021-12-21 03:17:15 --> Hooks Class Initialized
DEBUG - 2021-12-21 03:17:15 --> UTF-8 Support Enabled
INFO - 2021-12-21 03:17:15 --> Utf8 Class Initialized
INFO - 2021-12-21 03:17:15 --> URI Class Initialized
INFO - 2021-12-21 03:17:15 --> Router Class Initialized
INFO - 2021-12-21 03:17:15 --> Output Class Initialized
INFO - 2021-12-21 03:17:15 --> Security Class Initialized
DEBUG - 2021-12-21 03:17:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-21 03:17:15 --> Input Class Initialized
INFO - 2021-12-21 03:17:15 --> Language Class Initialized
INFO - 2021-12-21 03:17:15 --> Loader Class Initialized
INFO - 2021-12-21 03:17:15 --> Helper loaded: url_helper
INFO - 2021-12-21 03:17:15 --> Helper loaded: form_helper
INFO - 2021-12-21 03:17:15 --> Helper loaded: common_helper
INFO - 2021-12-21 03:17:15 --> Database Driver Class Initialized
DEBUG - 2021-12-21 03:17:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-21 03:17:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-21 03:17:15 --> Controller Class Initialized
INFO - 2021-12-21 03:17:15 --> Form Validation Class Initialized
DEBUG - 2021-12-21 03:17:15 --> Encrypt Class Initialized
INFO - 2021-12-21 03:17:15 --> Model "Login_model" initialized
INFO - 2021-12-21 03:17:15 --> Model "Dashboard_model" initialized
INFO - 2021-12-21 03:17:15 --> Model "Case_model" initialized
INFO - 2021-12-21 03:17:23 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-21 03:17:32 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2021-12-21 03:17:32 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-21 03:17:32 --> Final output sent to browser
DEBUG - 2021-12-21 03:17:32 --> Total execution time: 16.4732
ERROR - 2021-12-21 03:17:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-21 03:17:33 --> Config Class Initialized
INFO - 2021-12-21 03:17:33 --> Hooks Class Initialized
DEBUG - 2021-12-21 03:17:33 --> UTF-8 Support Enabled
INFO - 2021-12-21 03:17:33 --> Utf8 Class Initialized
INFO - 2021-12-21 03:17:33 --> URI Class Initialized
INFO - 2021-12-21 03:17:33 --> Router Class Initialized
INFO - 2021-12-21 03:17:33 --> Output Class Initialized
INFO - 2021-12-21 03:17:33 --> Security Class Initialized
DEBUG - 2021-12-21 03:17:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-21 03:17:33 --> Input Class Initialized
INFO - 2021-12-21 03:17:33 --> Language Class Initialized
ERROR - 2021-12-21 03:17:33 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-12-21 04:05:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-21 04:05:31 --> Config Class Initialized
INFO - 2021-12-21 04:05:31 --> Hooks Class Initialized
DEBUG - 2021-12-21 04:05:31 --> UTF-8 Support Enabled
INFO - 2021-12-21 04:05:31 --> Utf8 Class Initialized
INFO - 2021-12-21 04:05:31 --> URI Class Initialized
INFO - 2021-12-21 04:05:31 --> Router Class Initialized
INFO - 2021-12-21 04:05:31 --> Output Class Initialized
INFO - 2021-12-21 04:05:31 --> Security Class Initialized
DEBUG - 2021-12-21 04:05:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-21 04:05:31 --> Input Class Initialized
INFO - 2021-12-21 04:05:31 --> Language Class Initialized
INFO - 2021-12-21 04:05:31 --> Loader Class Initialized
INFO - 2021-12-21 04:05:31 --> Helper loaded: url_helper
INFO - 2021-12-21 04:05:31 --> Helper loaded: form_helper
INFO - 2021-12-21 04:05:31 --> Helper loaded: common_helper
INFO - 2021-12-21 04:05:31 --> Database Driver Class Initialized
DEBUG - 2021-12-21 04:05:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-21 04:05:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-21 04:05:31 --> Controller Class Initialized
INFO - 2021-12-21 04:05:31 --> Form Validation Class Initialized
DEBUG - 2021-12-21 04:05:31 --> Encrypt Class Initialized
INFO - 2021-12-21 04:05:31 --> Model "Login_model" initialized
INFO - 2021-12-21 04:05:31 --> Model "Dashboard_model" initialized
INFO - 2021-12-21 04:05:31 --> Model "Case_model" initialized
ERROR - 2021-12-21 04:05:31 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'GROUP BY  CALCULATEAGE(YEAR(patient_dob))
     
     UNION 
     
  SELECT calcu' at line 7 - Invalid query: SELECT SUM(TotalPatient) as TotalPatient ,AgeGroup
FROM
( 
SELECT CALCULATEAGE(YEAR(patient_dob)) AS AgeGroup, COUNT(CALCULATEAGE(YEAR(patient_dob)))  AS TotalPatient FROM patient_master
       
    WHERE  IFNULL(`status`,0)!= '1' AND patient_dob IS NOT NULL AND patient_dob != '0000-00-00'  AND patient_master.created_by = 
     GROUP BY  CALCULATEAGE(YEAR(patient_dob))
     
     UNION 
     
  SELECT calculateWithoutDOBAge(SUBSTRING(patient_age,1,2)) AS AgeGroup, COUNT(calculateWithoutDOBAge(SUBSTRING(patient_age,1,2))) AS 
  TotalPatient FROM patient_master WHERE IFNULL(`status`,0)!= '1' AND IFNULL(patient_dob,'')='0000-00-00'  AND IFNULL(patient_age,'')!=''  AND patient_master.created_by = 
        GROUP BY calculateWithoutDOBAge(SUBSTRING(patient_age,1,2))
        )B GROUP BY AgeGroup
INFO - 2021-12-21 04:05:31 --> Language file loaded: language/english/db_lang.php
ERROR - 2021-12-21 04:52:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-21 04:52:32 --> Config Class Initialized
INFO - 2021-12-21 04:52:32 --> Hooks Class Initialized
DEBUG - 2021-12-21 04:52:32 --> UTF-8 Support Enabled
INFO - 2021-12-21 04:52:32 --> Utf8 Class Initialized
INFO - 2021-12-21 04:52:32 --> URI Class Initialized
DEBUG - 2021-12-21 04:52:32 --> No URI present. Default controller set.
INFO - 2021-12-21 04:52:32 --> Router Class Initialized
INFO - 2021-12-21 04:52:32 --> Output Class Initialized
INFO - 2021-12-21 04:52:32 --> Security Class Initialized
DEBUG - 2021-12-21 04:52:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-21 04:52:32 --> Input Class Initialized
INFO - 2021-12-21 04:52:32 --> Language Class Initialized
INFO - 2021-12-21 04:52:32 --> Loader Class Initialized
INFO - 2021-12-21 04:52:32 --> Helper loaded: url_helper
INFO - 2021-12-21 04:52:32 --> Helper loaded: form_helper
INFO - 2021-12-21 04:52:32 --> Helper loaded: common_helper
INFO - 2021-12-21 04:52:32 --> Database Driver Class Initialized
DEBUG - 2021-12-21 04:52:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-21 04:52:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-21 04:52:32 --> Controller Class Initialized
INFO - 2021-12-21 04:52:32 --> Form Validation Class Initialized
DEBUG - 2021-12-21 04:52:32 --> Encrypt Class Initialized
DEBUG - 2021-12-21 04:52:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-21 04:52:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-21 04:52:32 --> Email Class Initialized
INFO - 2021-12-21 04:52:32 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-21 04:52:32 --> Calendar Class Initialized
INFO - 2021-12-21 04:52:32 --> Model "Login_model" initialized
INFO - 2021-12-21 04:52:32 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-21 04:52:32 --> Final output sent to browser
DEBUG - 2021-12-21 04:52:32 --> Total execution time: 0.0228
ERROR - 2021-12-21 04:57:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-21 04:57:33 --> Config Class Initialized
INFO - 2021-12-21 04:57:33 --> Hooks Class Initialized
DEBUG - 2021-12-21 04:57:33 --> UTF-8 Support Enabled
INFO - 2021-12-21 04:57:33 --> Utf8 Class Initialized
INFO - 2021-12-21 04:57:33 --> URI Class Initialized
DEBUG - 2021-12-21 04:57:33 --> No URI present. Default controller set.
INFO - 2021-12-21 04:57:33 --> Router Class Initialized
INFO - 2021-12-21 04:57:33 --> Output Class Initialized
INFO - 2021-12-21 04:57:33 --> Security Class Initialized
DEBUG - 2021-12-21 04:57:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-21 04:57:33 --> Input Class Initialized
INFO - 2021-12-21 04:57:33 --> Language Class Initialized
INFO - 2021-12-21 04:57:33 --> Loader Class Initialized
INFO - 2021-12-21 04:57:33 --> Helper loaded: url_helper
INFO - 2021-12-21 04:57:33 --> Helper loaded: form_helper
INFO - 2021-12-21 04:57:33 --> Helper loaded: common_helper
INFO - 2021-12-21 04:57:33 --> Database Driver Class Initialized
DEBUG - 2021-12-21 04:57:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-21 04:57:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-21 04:57:33 --> Controller Class Initialized
INFO - 2021-12-21 04:57:33 --> Form Validation Class Initialized
DEBUG - 2021-12-21 04:57:33 --> Encrypt Class Initialized
DEBUG - 2021-12-21 04:57:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-21 04:57:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-21 04:57:33 --> Email Class Initialized
INFO - 2021-12-21 04:57:33 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-21 04:57:33 --> Calendar Class Initialized
INFO - 2021-12-21 04:57:33 --> Model "Login_model" initialized
INFO - 2021-12-21 04:57:33 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-21 04:57:33 --> Final output sent to browser
DEBUG - 2021-12-21 04:57:33 --> Total execution time: 0.0228
ERROR - 2021-12-21 05:02:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-21 05:02:27 --> Config Class Initialized
INFO - 2021-12-21 05:02:27 --> Hooks Class Initialized
DEBUG - 2021-12-21 05:02:27 --> UTF-8 Support Enabled
INFO - 2021-12-21 05:02:27 --> Utf8 Class Initialized
INFO - 2021-12-21 05:02:27 --> URI Class Initialized
DEBUG - 2021-12-21 05:02:27 --> No URI present. Default controller set.
INFO - 2021-12-21 05:02:27 --> Router Class Initialized
INFO - 2021-12-21 05:02:27 --> Output Class Initialized
INFO - 2021-12-21 05:02:27 --> Security Class Initialized
DEBUG - 2021-12-21 05:02:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-21 05:02:27 --> Input Class Initialized
INFO - 2021-12-21 05:02:27 --> Language Class Initialized
INFO - 2021-12-21 05:02:27 --> Loader Class Initialized
INFO - 2021-12-21 05:02:27 --> Helper loaded: url_helper
INFO - 2021-12-21 05:02:27 --> Helper loaded: form_helper
INFO - 2021-12-21 05:02:27 --> Helper loaded: common_helper
INFO - 2021-12-21 05:02:27 --> Database Driver Class Initialized
DEBUG - 2021-12-21 05:02:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-21 05:02:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-21 05:02:27 --> Controller Class Initialized
INFO - 2021-12-21 05:02:27 --> Form Validation Class Initialized
DEBUG - 2021-12-21 05:02:27 --> Encrypt Class Initialized
DEBUG - 2021-12-21 05:02:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-21 05:02:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-21 05:02:27 --> Email Class Initialized
INFO - 2021-12-21 05:02:27 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-21 05:02:27 --> Calendar Class Initialized
INFO - 2021-12-21 05:02:27 --> Model "Login_model" initialized
INFO - 2021-12-21 05:02:27 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-21 05:02:27 --> Final output sent to browser
DEBUG - 2021-12-21 05:02:27 --> Total execution time: 0.0256
ERROR - 2021-12-21 11:51:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-21 11:51:06 --> Config Class Initialized
INFO - 2021-12-21 11:51:06 --> Hooks Class Initialized
DEBUG - 2021-12-21 11:51:06 --> UTF-8 Support Enabled
INFO - 2021-12-21 11:51:06 --> Utf8 Class Initialized
INFO - 2021-12-21 11:51:06 --> URI Class Initialized
DEBUG - 2021-12-21 11:51:06 --> No URI present. Default controller set.
INFO - 2021-12-21 11:51:06 --> Router Class Initialized
INFO - 2021-12-21 11:51:06 --> Output Class Initialized
INFO - 2021-12-21 11:51:06 --> Security Class Initialized
DEBUG - 2021-12-21 11:51:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-21 11:51:06 --> Input Class Initialized
INFO - 2021-12-21 11:51:06 --> Language Class Initialized
INFO - 2021-12-21 11:51:06 --> Loader Class Initialized
INFO - 2021-12-21 11:51:06 --> Helper loaded: url_helper
INFO - 2021-12-21 11:51:06 --> Helper loaded: form_helper
INFO - 2021-12-21 11:51:06 --> Helper loaded: common_helper
INFO - 2021-12-21 11:51:06 --> Database Driver Class Initialized
DEBUG - 2021-12-21 11:51:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-21 11:51:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-21 11:51:06 --> Controller Class Initialized
INFO - 2021-12-21 11:51:06 --> Form Validation Class Initialized
DEBUG - 2021-12-21 11:51:06 --> Encrypt Class Initialized
DEBUG - 2021-12-21 11:51:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-21 11:51:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-21 11:51:06 --> Email Class Initialized
INFO - 2021-12-21 11:51:06 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-21 11:51:06 --> Calendar Class Initialized
INFO - 2021-12-21 11:51:06 --> Model "Login_model" initialized
INFO - 2021-12-21 11:51:06 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-21 11:51:06 --> Final output sent to browser
DEBUG - 2021-12-21 11:51:06 --> Total execution time: 0.0281
ERROR - 2021-12-21 14:17:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-21 14:17:44 --> Config Class Initialized
INFO - 2021-12-21 14:17:44 --> Hooks Class Initialized
DEBUG - 2021-12-21 14:17:44 --> UTF-8 Support Enabled
INFO - 2021-12-21 14:17:44 --> Utf8 Class Initialized
INFO - 2021-12-21 14:17:44 --> URI Class Initialized
DEBUG - 2021-12-21 14:17:44 --> No URI present. Default controller set.
INFO - 2021-12-21 14:17:44 --> Router Class Initialized
INFO - 2021-12-21 14:17:44 --> Output Class Initialized
INFO - 2021-12-21 14:17:44 --> Security Class Initialized
DEBUG - 2021-12-21 14:17:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-21 14:17:44 --> Input Class Initialized
INFO - 2021-12-21 14:17:44 --> Language Class Initialized
INFO - 2021-12-21 14:17:44 --> Loader Class Initialized
INFO - 2021-12-21 14:17:44 --> Helper loaded: url_helper
INFO - 2021-12-21 14:17:44 --> Helper loaded: form_helper
INFO - 2021-12-21 14:17:44 --> Helper loaded: common_helper
INFO - 2021-12-21 14:17:44 --> Database Driver Class Initialized
DEBUG - 2021-12-21 14:17:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-21 14:17:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-21 14:17:44 --> Controller Class Initialized
INFO - 2021-12-21 14:17:44 --> Form Validation Class Initialized
DEBUG - 2021-12-21 14:17:44 --> Encrypt Class Initialized
DEBUG - 2021-12-21 14:17:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-21 14:17:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-21 14:17:44 --> Email Class Initialized
INFO - 2021-12-21 14:17:44 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-21 14:17:44 --> Calendar Class Initialized
INFO - 2021-12-21 14:17:44 --> Model "Login_model" initialized
INFO - 2021-12-21 14:17:44 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-21 14:17:44 --> Final output sent to browser
DEBUG - 2021-12-21 14:17:44 --> Total execution time: 0.0521
ERROR - 2021-12-21 14:17:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-21 14:17:46 --> Config Class Initialized
INFO - 2021-12-21 14:17:46 --> Hooks Class Initialized
DEBUG - 2021-12-21 14:17:46 --> UTF-8 Support Enabled
INFO - 2021-12-21 14:17:46 --> Utf8 Class Initialized
INFO - 2021-12-21 14:17:46 --> URI Class Initialized
INFO - 2021-12-21 14:17:46 --> Router Class Initialized
INFO - 2021-12-21 14:17:46 --> Output Class Initialized
INFO - 2021-12-21 14:17:46 --> Security Class Initialized
DEBUG - 2021-12-21 14:17:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-21 14:17:46 --> Input Class Initialized
INFO - 2021-12-21 14:17:46 --> Language Class Initialized
ERROR - 2021-12-21 14:17:46 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2021-12-21 14:19:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-21 14:19:12 --> Config Class Initialized
INFO - 2021-12-21 14:19:12 --> Hooks Class Initialized
DEBUG - 2021-12-21 14:19:12 --> UTF-8 Support Enabled
INFO - 2021-12-21 14:19:12 --> Utf8 Class Initialized
INFO - 2021-12-21 14:19:12 --> URI Class Initialized
INFO - 2021-12-21 14:19:12 --> Router Class Initialized
INFO - 2021-12-21 14:19:12 --> Output Class Initialized
INFO - 2021-12-21 14:19:12 --> Security Class Initialized
DEBUG - 2021-12-21 14:19:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-21 14:19:12 --> Input Class Initialized
INFO - 2021-12-21 14:19:12 --> Language Class Initialized
INFO - 2021-12-21 14:19:12 --> Loader Class Initialized
INFO - 2021-12-21 14:19:12 --> Helper loaded: url_helper
INFO - 2021-12-21 14:19:12 --> Helper loaded: form_helper
INFO - 2021-12-21 14:19:12 --> Helper loaded: common_helper
INFO - 2021-12-21 14:19:12 --> Database Driver Class Initialized
DEBUG - 2021-12-21 14:19:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-21 14:19:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-21 14:19:12 --> Controller Class Initialized
INFO - 2021-12-21 14:19:12 --> Form Validation Class Initialized
DEBUG - 2021-12-21 14:19:12 --> Encrypt Class Initialized
DEBUG - 2021-12-21 14:19:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-21 14:19:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-21 14:19:12 --> Email Class Initialized
INFO - 2021-12-21 14:19:12 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-21 14:19:12 --> Calendar Class Initialized
INFO - 2021-12-21 14:19:12 --> Model "Login_model" initialized
INFO - 2021-12-21 14:19:12 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-21 14:19:12 --> Final output sent to browser
DEBUG - 2021-12-21 14:19:12 --> Total execution time: 0.0231
ERROR - 2021-12-21 14:19:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-21 14:19:12 --> Config Class Initialized
INFO - 2021-12-21 14:19:12 --> Hooks Class Initialized
DEBUG - 2021-12-21 14:19:12 --> UTF-8 Support Enabled
INFO - 2021-12-21 14:19:12 --> Utf8 Class Initialized
INFO - 2021-12-21 14:19:12 --> URI Class Initialized
DEBUG - 2021-12-21 14:19:12 --> No URI present. Default controller set.
INFO - 2021-12-21 14:19:12 --> Router Class Initialized
INFO - 2021-12-21 14:19:12 --> Output Class Initialized
INFO - 2021-12-21 14:19:12 --> Security Class Initialized
DEBUG - 2021-12-21 14:19:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-21 14:19:12 --> Input Class Initialized
INFO - 2021-12-21 14:19:12 --> Language Class Initialized
INFO - 2021-12-21 14:19:12 --> Loader Class Initialized
INFO - 2021-12-21 14:19:12 --> Helper loaded: url_helper
INFO - 2021-12-21 14:19:12 --> Helper loaded: form_helper
INFO - 2021-12-21 14:19:12 --> Helper loaded: common_helper
INFO - 2021-12-21 14:19:12 --> Database Driver Class Initialized
DEBUG - 2021-12-21 14:19:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-21 14:19:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-21 14:19:12 --> Controller Class Initialized
INFO - 2021-12-21 14:19:12 --> Form Validation Class Initialized
DEBUG - 2021-12-21 14:19:12 --> Encrypt Class Initialized
DEBUG - 2021-12-21 14:19:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-21 14:19:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-21 14:19:12 --> Email Class Initialized
INFO - 2021-12-21 14:19:12 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-21 14:19:12 --> Calendar Class Initialized
INFO - 2021-12-21 14:19:12 --> Model "Login_model" initialized
INFO - 2021-12-21 14:19:12 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-21 14:19:12 --> Final output sent to browser
DEBUG - 2021-12-21 14:19:12 --> Total execution time: 0.0215
ERROR - 2021-12-21 14:19:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-21 14:19:13 --> Config Class Initialized
INFO - 2021-12-21 14:19:13 --> Hooks Class Initialized
DEBUG - 2021-12-21 14:19:13 --> UTF-8 Support Enabled
INFO - 2021-12-21 14:19:13 --> Utf8 Class Initialized
INFO - 2021-12-21 14:19:13 --> URI Class Initialized
INFO - 2021-12-21 14:19:13 --> Router Class Initialized
INFO - 2021-12-21 14:19:13 --> Output Class Initialized
INFO - 2021-12-21 14:19:13 --> Security Class Initialized
DEBUG - 2021-12-21 14:19:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-21 14:19:13 --> Input Class Initialized
INFO - 2021-12-21 14:19:13 --> Language Class Initialized
INFO - 2021-12-21 14:19:13 --> Loader Class Initialized
INFO - 2021-12-21 14:19:13 --> Helper loaded: url_helper
INFO - 2021-12-21 14:19:13 --> Helper loaded: form_helper
INFO - 2021-12-21 14:19:13 --> Helper loaded: common_helper
INFO - 2021-12-21 14:19:13 --> Database Driver Class Initialized
DEBUG - 2021-12-21 14:19:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-21 14:19:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-21 14:19:13 --> Controller Class Initialized
INFO - 2021-12-21 14:19:13 --> Form Validation Class Initialized
DEBUG - 2021-12-21 14:19:13 --> Encrypt Class Initialized
DEBUG - 2021-12-21 14:19:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-21 14:19:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-21 14:19:13 --> Email Class Initialized
INFO - 2021-12-21 14:19:13 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-21 14:19:13 --> Calendar Class Initialized
INFO - 2021-12-21 14:19:13 --> Model "Login_model" initialized
ERROR - 2021-12-21 14:19:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-21 14:19:14 --> Config Class Initialized
INFO - 2021-12-21 14:19:14 --> Hooks Class Initialized
DEBUG - 2021-12-21 14:19:14 --> UTF-8 Support Enabled
INFO - 2021-12-21 14:19:14 --> Utf8 Class Initialized
INFO - 2021-12-21 14:19:14 --> URI Class Initialized
INFO - 2021-12-21 14:19:14 --> Router Class Initialized
INFO - 2021-12-21 14:19:14 --> Output Class Initialized
INFO - 2021-12-21 14:19:14 --> Security Class Initialized
DEBUG - 2021-12-21 14:19:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-21 14:19:14 --> Input Class Initialized
INFO - 2021-12-21 14:19:14 --> Language Class Initialized
INFO - 2021-12-21 14:19:14 --> Loader Class Initialized
INFO - 2021-12-21 14:19:14 --> Helper loaded: url_helper
INFO - 2021-12-21 14:19:14 --> Helper loaded: form_helper
INFO - 2021-12-21 14:19:14 --> Helper loaded: common_helper
INFO - 2021-12-21 14:19:14 --> Database Driver Class Initialized
DEBUG - 2021-12-21 14:19:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-21 14:19:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-21 14:19:14 --> Controller Class Initialized
INFO - 2021-12-21 14:19:14 --> Form Validation Class Initialized
DEBUG - 2021-12-21 14:19:14 --> Encrypt Class Initialized
DEBUG - 2021-12-21 14:19:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-21 14:19:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-21 14:19:14 --> Email Class Initialized
INFO - 2021-12-21 14:19:14 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-21 14:19:14 --> Calendar Class Initialized
INFO - 2021-12-21 14:19:14 --> Model "Login_model" initialized
ERROR - 2021-12-21 15:19:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-21 15:19:05 --> Config Class Initialized
INFO - 2021-12-21 15:19:05 --> Hooks Class Initialized
DEBUG - 2021-12-21 15:19:05 --> UTF-8 Support Enabled
INFO - 2021-12-21 15:19:05 --> Utf8 Class Initialized
INFO - 2021-12-21 15:19:05 --> URI Class Initialized
DEBUG - 2021-12-21 15:19:05 --> No URI present. Default controller set.
INFO - 2021-12-21 15:19:05 --> Router Class Initialized
INFO - 2021-12-21 15:19:05 --> Output Class Initialized
INFO - 2021-12-21 15:19:05 --> Security Class Initialized
DEBUG - 2021-12-21 15:19:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-21 15:19:05 --> Input Class Initialized
INFO - 2021-12-21 15:19:05 --> Language Class Initialized
INFO - 2021-12-21 15:19:05 --> Loader Class Initialized
INFO - 2021-12-21 15:19:05 --> Helper loaded: url_helper
INFO - 2021-12-21 15:19:05 --> Helper loaded: form_helper
INFO - 2021-12-21 15:19:05 --> Helper loaded: common_helper
INFO - 2021-12-21 15:19:05 --> Database Driver Class Initialized
DEBUG - 2021-12-21 15:19:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-21 15:19:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-21 15:19:05 --> Controller Class Initialized
INFO - 2021-12-21 15:19:05 --> Form Validation Class Initialized
DEBUG - 2021-12-21 15:19:05 --> Encrypt Class Initialized
DEBUG - 2021-12-21 15:19:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-21 15:19:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-21 15:19:05 --> Email Class Initialized
INFO - 2021-12-21 15:19:05 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-21 15:19:05 --> Calendar Class Initialized
INFO - 2021-12-21 15:19:05 --> Model "Login_model" initialized
INFO - 2021-12-21 15:19:05 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-21 15:19:05 --> Final output sent to browser
DEBUG - 2021-12-21 15:19:05 --> Total execution time: 0.0242
ERROR - 2021-12-21 19:41:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-21 19:41:01 --> Config Class Initialized
INFO - 2021-12-21 19:41:01 --> Hooks Class Initialized
DEBUG - 2021-12-21 19:41:01 --> UTF-8 Support Enabled
INFO - 2021-12-21 19:41:01 --> Utf8 Class Initialized
INFO - 2021-12-21 19:41:01 --> URI Class Initialized
DEBUG - 2021-12-21 19:41:01 --> No URI present. Default controller set.
INFO - 2021-12-21 19:41:01 --> Router Class Initialized
INFO - 2021-12-21 19:41:01 --> Output Class Initialized
INFO - 2021-12-21 19:41:01 --> Security Class Initialized
DEBUG - 2021-12-21 19:41:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-21 19:41:01 --> Input Class Initialized
INFO - 2021-12-21 19:41:01 --> Language Class Initialized
INFO - 2021-12-21 19:41:01 --> Loader Class Initialized
INFO - 2021-12-21 19:41:01 --> Helper loaded: url_helper
INFO - 2021-12-21 19:41:01 --> Helper loaded: form_helper
INFO - 2021-12-21 19:41:01 --> Helper loaded: common_helper
INFO - 2021-12-21 19:41:01 --> Database Driver Class Initialized
DEBUG - 2021-12-21 19:41:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-21 19:41:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-21 19:41:01 --> Controller Class Initialized
INFO - 2021-12-21 19:41:01 --> Form Validation Class Initialized
DEBUG - 2021-12-21 19:41:01 --> Encrypt Class Initialized
DEBUG - 2021-12-21 19:41:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-21 19:41:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-21 19:41:01 --> Email Class Initialized
INFO - 2021-12-21 19:41:01 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-21 19:41:01 --> Calendar Class Initialized
INFO - 2021-12-21 19:41:01 --> Model "Login_model" initialized
INFO - 2021-12-21 19:41:01 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-21 19:41:01 --> Final output sent to browser
DEBUG - 2021-12-21 19:41:01 --> Total execution time: 0.0447
ERROR - 2021-12-21 21:35:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-21 21:35:48 --> Config Class Initialized
INFO - 2021-12-21 21:35:48 --> Hooks Class Initialized
DEBUG - 2021-12-21 21:35:48 --> UTF-8 Support Enabled
INFO - 2021-12-21 21:35:48 --> Utf8 Class Initialized
INFO - 2021-12-21 21:35:48 --> URI Class Initialized
INFO - 2021-12-21 21:35:48 --> Router Class Initialized
INFO - 2021-12-21 21:35:48 --> Output Class Initialized
INFO - 2021-12-21 21:35:48 --> Security Class Initialized
DEBUG - 2021-12-21 21:35:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-21 21:35:48 --> Input Class Initialized
INFO - 2021-12-21 21:35:48 --> Language Class Initialized
ERROR - 2021-12-21 21:35:48 --> 404 Page Not Found: Humanstxt/index
ERROR - 2021-12-21 21:35:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-21 21:35:49 --> Config Class Initialized
INFO - 2021-12-21 21:35:49 --> Hooks Class Initialized
DEBUG - 2021-12-21 21:35:49 --> UTF-8 Support Enabled
INFO - 2021-12-21 21:35:49 --> Utf8 Class Initialized
INFO - 2021-12-21 21:35:49 --> URI Class Initialized
INFO - 2021-12-21 21:35:49 --> Router Class Initialized
INFO - 2021-12-21 21:35:49 --> Output Class Initialized
INFO - 2021-12-21 21:35:49 --> Security Class Initialized
DEBUG - 2021-12-21 21:35:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-21 21:35:49 --> Input Class Initialized
INFO - 2021-12-21 21:35:49 --> Language Class Initialized
ERROR - 2021-12-21 21:35:49 --> 404 Page Not Found: Adstxt/index
ERROR - 2021-12-21 21:35:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-21 21:35:50 --> Config Class Initialized
INFO - 2021-12-21 21:35:50 --> Hooks Class Initialized
DEBUG - 2021-12-21 21:35:50 --> UTF-8 Support Enabled
INFO - 2021-12-21 21:35:50 --> Utf8 Class Initialized
INFO - 2021-12-21 21:35:50 --> URI Class Initialized
DEBUG - 2021-12-21 21:35:50 --> No URI present. Default controller set.
INFO - 2021-12-21 21:35:50 --> Router Class Initialized
INFO - 2021-12-21 21:35:50 --> Output Class Initialized
INFO - 2021-12-21 21:35:50 --> Security Class Initialized
DEBUG - 2021-12-21 21:35:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-21 21:35:50 --> Input Class Initialized
INFO - 2021-12-21 21:35:50 --> Language Class Initialized
INFO - 2021-12-21 21:35:50 --> Loader Class Initialized
INFO - 2021-12-21 21:35:50 --> Helper loaded: url_helper
INFO - 2021-12-21 21:35:50 --> Helper loaded: form_helper
INFO - 2021-12-21 21:35:50 --> Helper loaded: common_helper
INFO - 2021-12-21 21:35:50 --> Database Driver Class Initialized
DEBUG - 2021-12-21 21:35:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-21 21:35:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-21 21:35:50 --> Controller Class Initialized
INFO - 2021-12-21 21:35:50 --> Form Validation Class Initialized
DEBUG - 2021-12-21 21:35:50 --> Encrypt Class Initialized
DEBUG - 2021-12-21 21:35:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-21 21:35:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-21 21:35:50 --> Email Class Initialized
INFO - 2021-12-21 21:35:50 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-21 21:35:50 --> Calendar Class Initialized
INFO - 2021-12-21 21:35:50 --> Model "Login_model" initialized
INFO - 2021-12-21 21:35:50 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-21 21:35:50 --> Final output sent to browser
DEBUG - 2021-12-21 21:35:50 --> Total execution time: 0.0688
