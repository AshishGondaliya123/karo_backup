<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-05-26 10:03:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-26 10:03:36 --> Config Class Initialized
INFO - 2021-05-26 10:03:36 --> Hooks Class Initialized
DEBUG - 2021-05-26 10:03:36 --> UTF-8 Support Enabled
INFO - 2021-05-26 10:03:36 --> Utf8 Class Initialized
INFO - 2021-05-26 10:03:36 --> URI Class Initialized
DEBUG - 2021-05-26 10:03:36 --> No URI present. Default controller set.
INFO - 2021-05-26 10:03:36 --> Router Class Initialized
INFO - 2021-05-26 10:03:36 --> Output Class Initialized
INFO - 2021-05-26 10:03:36 --> Security Class Initialized
DEBUG - 2021-05-26 10:03:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-26 10:03:36 --> Input Class Initialized
INFO - 2021-05-26 10:03:36 --> Language Class Initialized
INFO - 2021-05-26 10:03:36 --> Loader Class Initialized
INFO - 2021-05-26 10:03:36 --> Helper loaded: url_helper
INFO - 2021-05-26 10:03:36 --> Helper loaded: form_helper
INFO - 2021-05-26 10:03:36 --> Helper loaded: common_helper
INFO - 2021-05-26 10:03:36 --> Database Driver Class Initialized
DEBUG - 2021-05-26 10:03:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-26 10:03:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-26 10:03:36 --> Controller Class Initialized
INFO - 2021-05-26 10:03:36 --> Form Validation Class Initialized
DEBUG - 2021-05-26 10:03:36 --> Encrypt Class Initialized
DEBUG - 2021-05-26 10:03:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-05-26 10:03:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-05-26 10:03:36 --> Email Class Initialized
INFO - 2021-05-26 10:03:36 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-05-26 10:03:36 --> Calendar Class Initialized
INFO - 2021-05-26 10:03:36 --> Model "Login_model" initialized
INFO - 2021-05-26 10:03:36 --> File loaded: /home/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-05-26 10:03:36 --> Final output sent to browser
DEBUG - 2021-05-26 10:03:36 --> Total execution time: 0.1543
ERROR - 2021-05-26 15:43:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-26 15:43:07 --> Config Class Initialized
INFO - 2021-05-26 15:43:07 --> Hooks Class Initialized
DEBUG - 2021-05-26 15:43:07 --> UTF-8 Support Enabled
INFO - 2021-05-26 15:43:07 --> Utf8 Class Initialized
INFO - 2021-05-26 15:43:07 --> URI Class Initialized
INFO - 2021-05-26 15:43:07 --> Router Class Initialized
INFO - 2021-05-26 15:43:07 --> Output Class Initialized
INFO - 2021-05-26 15:43:07 --> Security Class Initialized
DEBUG - 2021-05-26 15:43:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-26 15:43:07 --> Input Class Initialized
INFO - 2021-05-26 15:43:07 --> Language Class Initialized
ERROR - 2021-05-26 15:43:07 --> 404 Page Not Found: Git/HEAD
