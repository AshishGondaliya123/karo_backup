<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-09-12 08:53:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-12 08:53:18 --> Config Class Initialized
INFO - 2021-09-12 08:53:18 --> Hooks Class Initialized
DEBUG - 2021-09-12 08:53:18 --> UTF-8 Support Enabled
INFO - 2021-09-12 08:53:18 --> Utf8 Class Initialized
INFO - 2021-09-12 08:53:18 --> URI Class Initialized
DEBUG - 2021-09-12 08:53:18 --> No URI present. Default controller set.
INFO - 2021-09-12 08:53:18 --> Router Class Initialized
INFO - 2021-09-12 08:53:18 --> Output Class Initialized
INFO - 2021-09-12 08:53:18 --> Security Class Initialized
DEBUG - 2021-09-12 08:53:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-12 08:53:18 --> Input Class Initialized
INFO - 2021-09-12 08:53:18 --> Language Class Initialized
INFO - 2021-09-12 08:53:18 --> Loader Class Initialized
INFO - 2021-09-12 08:53:18 --> Helper loaded: url_helper
INFO - 2021-09-12 08:53:18 --> Helper loaded: form_helper
INFO - 2021-09-12 08:53:18 --> Helper loaded: common_helper
INFO - 2021-09-12 08:53:18 --> Database Driver Class Initialized
DEBUG - 2021-09-12 08:53:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-12 08:53:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-12 08:53:18 --> Controller Class Initialized
INFO - 2021-09-12 08:53:18 --> Form Validation Class Initialized
DEBUG - 2021-09-12 08:53:18 --> Encrypt Class Initialized
DEBUG - 2021-09-12 08:53:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-09-12 08:53:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-09-12 08:53:18 --> Email Class Initialized
INFO - 2021-09-12 08:53:18 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-09-12 08:53:18 --> Calendar Class Initialized
INFO - 2021-09-12 08:53:18 --> Model "Login_model" initialized
INFO - 2021-09-12 08:53:18 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-09-12 08:53:18 --> Final output sent to browser
DEBUG - 2021-09-12 08:53:18 --> Total execution time: 0.0482
ERROR - 2021-09-12 12:50:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-12 12:50:08 --> Config Class Initialized
INFO - 2021-09-12 12:50:08 --> Hooks Class Initialized
DEBUG - 2021-09-12 12:50:08 --> UTF-8 Support Enabled
INFO - 2021-09-12 12:50:08 --> Utf8 Class Initialized
INFO - 2021-09-12 12:50:08 --> URI Class Initialized
INFO - 2021-09-12 12:50:08 --> Router Class Initialized
INFO - 2021-09-12 12:50:09 --> Output Class Initialized
INFO - 2021-09-12 12:50:09 --> Security Class Initialized
DEBUG - 2021-09-12 12:50:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-12 12:50:09 --> Input Class Initialized
INFO - 2021-09-12 12:50:09 --> Language Class Initialized
ERROR - 2021-09-12 12:50:09 --> 404 Page Not Found: Wp-admin/css
ERROR - 2021-09-12 12:50:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-12 12:50:27 --> Config Class Initialized
INFO - 2021-09-12 12:50:27 --> Hooks Class Initialized
DEBUG - 2021-09-12 12:50:27 --> UTF-8 Support Enabled
INFO - 2021-09-12 12:50:27 --> Utf8 Class Initialized
INFO - 2021-09-12 12:50:27 --> URI Class Initialized
INFO - 2021-09-12 12:50:27 --> Router Class Initialized
INFO - 2021-09-12 12:50:27 --> Output Class Initialized
INFO - 2021-09-12 12:50:27 --> Security Class Initialized
DEBUG - 2021-09-12 12:50:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-12 12:50:27 --> Input Class Initialized
INFO - 2021-09-12 12:50:27 --> Language Class Initialized
ERROR - 2021-09-12 12:50:27 --> 404 Page Not Found: Sites/default
ERROR - 2021-09-12 12:50:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-12 12:50:36 --> Config Class Initialized
INFO - 2021-09-12 12:50:36 --> Hooks Class Initialized
DEBUG - 2021-09-12 12:50:36 --> UTF-8 Support Enabled
INFO - 2021-09-12 12:50:36 --> Utf8 Class Initialized
INFO - 2021-09-12 12:50:36 --> URI Class Initialized
INFO - 2021-09-12 12:50:36 --> Router Class Initialized
INFO - 2021-09-12 12:50:36 --> Output Class Initialized
INFO - 2021-09-12 12:50:36 --> Security Class Initialized
DEBUG - 2021-09-12 12:50:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-12 12:50:36 --> Input Class Initialized
INFO - 2021-09-12 12:50:36 --> Language Class Initialized
ERROR - 2021-09-12 12:50:36 --> 404 Page Not Found: Admin/controller
ERROR - 2021-09-12 12:50:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-12 12:50:44 --> Config Class Initialized
INFO - 2021-09-12 12:50:44 --> Hooks Class Initialized
DEBUG - 2021-09-12 12:50:44 --> UTF-8 Support Enabled
INFO - 2021-09-12 12:50:44 --> Utf8 Class Initialized
INFO - 2021-09-12 12:50:44 --> URI Class Initialized
INFO - 2021-09-12 12:50:44 --> Router Class Initialized
INFO - 2021-09-12 12:50:44 --> Output Class Initialized
INFO - 2021-09-12 12:50:44 --> Security Class Initialized
DEBUG - 2021-09-12 12:50:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-12 12:50:44 --> Input Class Initialized
INFO - 2021-09-12 12:50:44 --> Language Class Initialized
ERROR - 2021-09-12 12:50:44 --> 404 Page Not Found: Uploads/index
ERROR - 2021-09-12 12:50:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-12 12:50:53 --> Config Class Initialized
INFO - 2021-09-12 12:50:53 --> Hooks Class Initialized
DEBUG - 2021-09-12 12:50:53 --> UTF-8 Support Enabled
INFO - 2021-09-12 12:50:53 --> Utf8 Class Initialized
INFO - 2021-09-12 12:50:53 --> URI Class Initialized
INFO - 2021-09-12 12:50:53 --> Router Class Initialized
INFO - 2021-09-12 12:50:53 --> Output Class Initialized
INFO - 2021-09-12 12:50:53 --> Security Class Initialized
DEBUG - 2021-09-12 12:50:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-12 12:50:53 --> Input Class Initialized
INFO - 2021-09-12 12:50:53 --> Language Class Initialized
ERROR - 2021-09-12 12:50:53 --> 404 Page Not Found: Images/index
ERROR - 2021-09-12 12:51:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-12 12:51:02 --> Config Class Initialized
INFO - 2021-09-12 12:51:02 --> Hooks Class Initialized
DEBUG - 2021-09-12 12:51:02 --> UTF-8 Support Enabled
INFO - 2021-09-12 12:51:02 --> Utf8 Class Initialized
INFO - 2021-09-12 12:51:02 --> URI Class Initialized
INFO - 2021-09-12 12:51:02 --> Router Class Initialized
INFO - 2021-09-12 12:51:02 --> Output Class Initialized
INFO - 2021-09-12 12:51:02 --> Security Class Initialized
DEBUG - 2021-09-12 12:51:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-12 12:51:02 --> Input Class Initialized
INFO - 2021-09-12 12:51:02 --> Language Class Initialized
ERROR - 2021-09-12 12:51:02 --> 404 Page Not Found: Files/index
ERROR - 2021-09-12 15:25:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-12 15:25:59 --> Config Class Initialized
INFO - 2021-09-12 15:25:59 --> Hooks Class Initialized
DEBUG - 2021-09-12 15:25:59 --> UTF-8 Support Enabled
INFO - 2021-09-12 15:25:59 --> Utf8 Class Initialized
INFO - 2021-09-12 15:25:59 --> URI Class Initialized
DEBUG - 2021-09-12 15:25:59 --> No URI present. Default controller set.
INFO - 2021-09-12 15:25:59 --> Router Class Initialized
INFO - 2021-09-12 15:25:59 --> Output Class Initialized
INFO - 2021-09-12 15:25:59 --> Security Class Initialized
DEBUG - 2021-09-12 15:25:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-12 15:25:59 --> Input Class Initialized
INFO - 2021-09-12 15:25:59 --> Language Class Initialized
INFO - 2021-09-12 15:25:59 --> Loader Class Initialized
INFO - 2021-09-12 15:25:59 --> Helper loaded: url_helper
INFO - 2021-09-12 15:25:59 --> Helper loaded: form_helper
INFO - 2021-09-12 15:25:59 --> Helper loaded: common_helper
INFO - 2021-09-12 15:25:59 --> Database Driver Class Initialized
DEBUG - 2021-09-12 15:25:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-12 15:25:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-12 15:25:59 --> Controller Class Initialized
INFO - 2021-09-12 15:25:59 --> Form Validation Class Initialized
DEBUG - 2021-09-12 15:25:59 --> Encrypt Class Initialized
DEBUG - 2021-09-12 15:25:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-09-12 15:25:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-09-12 15:25:59 --> Email Class Initialized
INFO - 2021-09-12 15:25:59 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-09-12 15:25:59 --> Calendar Class Initialized
INFO - 2021-09-12 15:25:59 --> Model "Login_model" initialized
INFO - 2021-09-12 15:25:59 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-09-12 15:25:59 --> Final output sent to browser
DEBUG - 2021-09-12 15:25:59 --> Total execution time: 0.0487
ERROR - 2021-09-12 15:26:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-12 15:26:00 --> Config Class Initialized
INFO - 2021-09-12 15:26:00 --> Hooks Class Initialized
DEBUG - 2021-09-12 15:26:00 --> UTF-8 Support Enabled
INFO - 2021-09-12 15:26:00 --> Utf8 Class Initialized
INFO - 2021-09-12 15:26:00 --> URI Class Initialized
INFO - 2021-09-12 15:26:00 --> Router Class Initialized
INFO - 2021-09-12 15:26:00 --> Output Class Initialized
INFO - 2021-09-12 15:26:00 --> Security Class Initialized
DEBUG - 2021-09-12 15:26:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-12 15:26:00 --> Input Class Initialized
INFO - 2021-09-12 15:26:00 --> Language Class Initialized
ERROR - 2021-09-12 15:26:00 --> 404 Page Not Found: Blog/index
ERROR - 2021-09-12 15:26:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-12 15:26:00 --> Config Class Initialized
INFO - 2021-09-12 15:26:00 --> Hooks Class Initialized
DEBUG - 2021-09-12 15:26:00 --> UTF-8 Support Enabled
INFO - 2021-09-12 15:26:00 --> Utf8 Class Initialized
INFO - 2021-09-12 15:26:00 --> URI Class Initialized
INFO - 2021-09-12 15:26:00 --> Router Class Initialized
INFO - 2021-09-12 15:26:00 --> Output Class Initialized
INFO - 2021-09-12 15:26:00 --> Security Class Initialized
DEBUG - 2021-09-12 15:26:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-12 15:26:00 --> Input Class Initialized
INFO - 2021-09-12 15:26:00 --> Language Class Initialized
ERROR - 2021-09-12 15:26:00 --> 404 Page Not Found: Wp/index
ERROR - 2021-09-12 15:26:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-12 15:26:00 --> Config Class Initialized
INFO - 2021-09-12 15:26:00 --> Hooks Class Initialized
DEBUG - 2021-09-12 15:26:00 --> UTF-8 Support Enabled
INFO - 2021-09-12 15:26:00 --> Utf8 Class Initialized
INFO - 2021-09-12 15:26:00 --> URI Class Initialized
INFO - 2021-09-12 15:26:00 --> Router Class Initialized
INFO - 2021-09-12 15:26:00 --> Output Class Initialized
INFO - 2021-09-12 15:26:00 --> Security Class Initialized
DEBUG - 2021-09-12 15:26:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-12 15:26:00 --> Input Class Initialized
INFO - 2021-09-12 15:26:00 --> Language Class Initialized
ERROR - 2021-09-12 15:26:00 --> 404 Page Not Found: Wordpress/index
ERROR - 2021-09-12 15:26:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-12 15:26:01 --> Config Class Initialized
INFO - 2021-09-12 15:26:01 --> Hooks Class Initialized
DEBUG - 2021-09-12 15:26:01 --> UTF-8 Support Enabled
INFO - 2021-09-12 15:26:01 --> Utf8 Class Initialized
INFO - 2021-09-12 15:26:01 --> URI Class Initialized
INFO - 2021-09-12 15:26:01 --> Router Class Initialized
INFO - 2021-09-12 15:26:01 --> Output Class Initialized
INFO - 2021-09-12 15:26:01 --> Security Class Initialized
DEBUG - 2021-09-12 15:26:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-12 15:26:01 --> Input Class Initialized
INFO - 2021-09-12 15:26:01 --> Language Class Initialized
ERROR - 2021-09-12 15:26:01 --> 404 Page Not Found: New/index
ERROR - 2021-09-12 15:26:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-12 15:26:01 --> Config Class Initialized
INFO - 2021-09-12 15:26:01 --> Hooks Class Initialized
DEBUG - 2021-09-12 15:26:01 --> UTF-8 Support Enabled
INFO - 2021-09-12 15:26:01 --> Utf8 Class Initialized
INFO - 2021-09-12 15:26:01 --> URI Class Initialized
INFO - 2021-09-12 15:26:01 --> Router Class Initialized
INFO - 2021-09-12 15:26:01 --> Output Class Initialized
INFO - 2021-09-12 15:26:01 --> Security Class Initialized
DEBUG - 2021-09-12 15:26:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-12 15:26:01 --> Input Class Initialized
INFO - 2021-09-12 15:26:01 --> Language Class Initialized
ERROR - 2021-09-12 15:26:01 --> 404 Page Not Found: Old/index
ERROR - 2021-09-12 15:26:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-12 15:26:01 --> Config Class Initialized
INFO - 2021-09-12 15:26:01 --> Hooks Class Initialized
DEBUG - 2021-09-12 15:26:01 --> UTF-8 Support Enabled
INFO - 2021-09-12 15:26:01 --> Utf8 Class Initialized
INFO - 2021-09-12 15:26:01 --> URI Class Initialized
INFO - 2021-09-12 15:26:01 --> Router Class Initialized
INFO - 2021-09-12 15:26:01 --> Output Class Initialized
INFO - 2021-09-12 15:26:01 --> Security Class Initialized
DEBUG - 2021-09-12 15:26:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-12 15:26:01 --> Input Class Initialized
INFO - 2021-09-12 15:26:01 --> Language Class Initialized
ERROR - 2021-09-12 15:26:01 --> 404 Page Not Found: Test/index
ERROR - 2021-09-12 15:26:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-12 15:26:01 --> Config Class Initialized
INFO - 2021-09-12 15:26:01 --> Hooks Class Initialized
DEBUG - 2021-09-12 15:26:01 --> UTF-8 Support Enabled
INFO - 2021-09-12 15:26:01 --> Utf8 Class Initialized
INFO - 2021-09-12 15:26:01 --> URI Class Initialized
INFO - 2021-09-12 15:26:01 --> Router Class Initialized
INFO - 2021-09-12 15:26:01 --> Output Class Initialized
INFO - 2021-09-12 15:26:01 --> Security Class Initialized
DEBUG - 2021-09-12 15:26:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-12 15:26:01 --> Input Class Initialized
INFO - 2021-09-12 15:26:01 --> Language Class Initialized
ERROR - 2021-09-12 15:26:01 --> 404 Page Not Found: Main/index
ERROR - 2021-09-12 15:26:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-12 15:26:02 --> Config Class Initialized
INFO - 2021-09-12 15:26:02 --> Hooks Class Initialized
DEBUG - 2021-09-12 15:26:02 --> UTF-8 Support Enabled
INFO - 2021-09-12 15:26:02 --> Utf8 Class Initialized
INFO - 2021-09-12 15:26:02 --> URI Class Initialized
INFO - 2021-09-12 15:26:02 --> Router Class Initialized
INFO - 2021-09-12 15:26:02 --> Output Class Initialized
INFO - 2021-09-12 15:26:02 --> Security Class Initialized
DEBUG - 2021-09-12 15:26:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-12 15:26:02 --> Input Class Initialized
INFO - 2021-09-12 15:26:02 --> Language Class Initialized
ERROR - 2021-09-12 15:26:02 --> 404 Page Not Found: Site/index
ERROR - 2021-09-12 15:26:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-12 15:26:02 --> Config Class Initialized
INFO - 2021-09-12 15:26:02 --> Hooks Class Initialized
DEBUG - 2021-09-12 15:26:02 --> UTF-8 Support Enabled
INFO - 2021-09-12 15:26:02 --> Utf8 Class Initialized
INFO - 2021-09-12 15:26:02 --> URI Class Initialized
INFO - 2021-09-12 15:26:02 --> Router Class Initialized
INFO - 2021-09-12 15:26:02 --> Output Class Initialized
INFO - 2021-09-12 15:26:02 --> Security Class Initialized
DEBUG - 2021-09-12 15:26:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-12 15:26:02 --> Input Class Initialized
INFO - 2021-09-12 15:26:02 --> Language Class Initialized
ERROR - 2021-09-12 15:26:02 --> 404 Page Not Found: Backup/index
ERROR - 2021-09-12 15:26:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-12 15:26:02 --> Config Class Initialized
INFO - 2021-09-12 15:26:02 --> Hooks Class Initialized
DEBUG - 2021-09-12 15:26:02 --> UTF-8 Support Enabled
INFO - 2021-09-12 15:26:02 --> Utf8 Class Initialized
INFO - 2021-09-12 15:26:02 --> URI Class Initialized
INFO - 2021-09-12 15:26:02 --> Router Class Initialized
INFO - 2021-09-12 15:26:02 --> Output Class Initialized
INFO - 2021-09-12 15:26:02 --> Security Class Initialized
DEBUG - 2021-09-12 15:26:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-12 15:26:02 --> Input Class Initialized
INFO - 2021-09-12 15:26:02 --> Language Class Initialized
ERROR - 2021-09-12 15:26:02 --> 404 Page Not Found: Demo/index
ERROR - 2021-09-12 15:26:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-12 15:26:03 --> Config Class Initialized
INFO - 2021-09-12 15:26:03 --> Hooks Class Initialized
DEBUG - 2021-09-12 15:26:03 --> UTF-8 Support Enabled
INFO - 2021-09-12 15:26:03 --> Utf8 Class Initialized
INFO - 2021-09-12 15:26:03 --> URI Class Initialized
INFO - 2021-09-12 15:26:03 --> Router Class Initialized
INFO - 2021-09-12 15:26:03 --> Output Class Initialized
INFO - 2021-09-12 15:26:03 --> Security Class Initialized
DEBUG - 2021-09-12 15:26:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-12 15:26:03 --> Input Class Initialized
INFO - 2021-09-12 15:26:03 --> Language Class Initialized
ERROR - 2021-09-12 15:26:03 --> 404 Page Not Found: Home/index
ERROR - 2021-09-12 15:26:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-12 15:26:03 --> Config Class Initialized
INFO - 2021-09-12 15:26:03 --> Hooks Class Initialized
DEBUG - 2021-09-12 15:26:03 --> UTF-8 Support Enabled
INFO - 2021-09-12 15:26:03 --> Utf8 Class Initialized
INFO - 2021-09-12 15:26:03 --> URI Class Initialized
INFO - 2021-09-12 15:26:03 --> Router Class Initialized
INFO - 2021-09-12 15:26:03 --> Output Class Initialized
INFO - 2021-09-12 15:26:03 --> Security Class Initialized
DEBUG - 2021-09-12 15:26:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-12 15:26:03 --> Input Class Initialized
INFO - 2021-09-12 15:26:03 --> Language Class Initialized
ERROR - 2021-09-12 15:26:03 --> 404 Page Not Found: Tmp/index
ERROR - 2021-09-12 15:26:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-12 15:26:03 --> Config Class Initialized
INFO - 2021-09-12 15:26:03 --> Hooks Class Initialized
DEBUG - 2021-09-12 15:26:03 --> UTF-8 Support Enabled
INFO - 2021-09-12 15:26:03 --> Utf8 Class Initialized
INFO - 2021-09-12 15:26:03 --> URI Class Initialized
INFO - 2021-09-12 15:26:03 --> Router Class Initialized
INFO - 2021-09-12 15:26:03 --> Output Class Initialized
INFO - 2021-09-12 15:26:03 --> Security Class Initialized
DEBUG - 2021-09-12 15:26:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-12 15:26:03 --> Input Class Initialized
INFO - 2021-09-12 15:26:03 --> Language Class Initialized
ERROR - 2021-09-12 15:26:03 --> 404 Page Not Found: Cms/index
ERROR - 2021-09-12 15:26:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-12 15:26:03 --> Config Class Initialized
INFO - 2021-09-12 15:26:03 --> Hooks Class Initialized
DEBUG - 2021-09-12 15:26:03 --> UTF-8 Support Enabled
INFO - 2021-09-12 15:26:03 --> Utf8 Class Initialized
INFO - 2021-09-12 15:26:03 --> URI Class Initialized
INFO - 2021-09-12 15:26:03 --> Router Class Initialized
INFO - 2021-09-12 15:26:03 --> Output Class Initialized
INFO - 2021-09-12 15:26:03 --> Security Class Initialized
DEBUG - 2021-09-12 15:26:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-12 15:26:03 --> Input Class Initialized
INFO - 2021-09-12 15:26:03 --> Language Class Initialized
ERROR - 2021-09-12 15:26:03 --> 404 Page Not Found: Dev/index
ERROR - 2021-09-12 15:26:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-12 15:26:04 --> Config Class Initialized
INFO - 2021-09-12 15:26:04 --> Hooks Class Initialized
DEBUG - 2021-09-12 15:26:04 --> UTF-8 Support Enabled
INFO - 2021-09-12 15:26:04 --> Utf8 Class Initialized
INFO - 2021-09-12 15:26:04 --> URI Class Initialized
INFO - 2021-09-12 15:26:04 --> Router Class Initialized
INFO - 2021-09-12 15:26:04 --> Output Class Initialized
INFO - 2021-09-12 15:26:04 --> Security Class Initialized
DEBUG - 2021-09-12 15:26:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-12 15:26:04 --> Input Class Initialized
INFO - 2021-09-12 15:26:04 --> Language Class Initialized
ERROR - 2021-09-12 15:26:04 --> 404 Page Not Found: Old-wp/index
ERROR - 2021-09-12 15:26:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-12 15:26:04 --> Config Class Initialized
INFO - 2021-09-12 15:26:04 --> Hooks Class Initialized
DEBUG - 2021-09-12 15:26:04 --> UTF-8 Support Enabled
INFO - 2021-09-12 15:26:04 --> Utf8 Class Initialized
INFO - 2021-09-12 15:26:04 --> URI Class Initialized
INFO - 2021-09-12 15:26:04 --> Router Class Initialized
INFO - 2021-09-12 15:26:04 --> Output Class Initialized
INFO - 2021-09-12 15:26:04 --> Security Class Initialized
DEBUG - 2021-09-12 15:26:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-12 15:26:04 --> Input Class Initialized
INFO - 2021-09-12 15:26:04 --> Language Class Initialized
ERROR - 2021-09-12 15:26:04 --> 404 Page Not Found: Web/index
ERROR - 2021-09-12 15:26:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-12 15:26:04 --> Config Class Initialized
INFO - 2021-09-12 15:26:04 --> Hooks Class Initialized
DEBUG - 2021-09-12 15:26:04 --> UTF-8 Support Enabled
INFO - 2021-09-12 15:26:04 --> Utf8 Class Initialized
INFO - 2021-09-12 15:26:04 --> URI Class Initialized
INFO - 2021-09-12 15:26:04 --> Router Class Initialized
INFO - 2021-09-12 15:26:04 --> Output Class Initialized
INFO - 2021-09-12 15:26:04 --> Security Class Initialized
DEBUG - 2021-09-12 15:26:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-12 15:26:04 --> Input Class Initialized
INFO - 2021-09-12 15:26:04 --> Language Class Initialized
ERROR - 2021-09-12 15:26:04 --> 404 Page Not Found: Old-site/index
ERROR - 2021-09-12 15:26:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-12 15:26:05 --> Config Class Initialized
INFO - 2021-09-12 15:26:05 --> Hooks Class Initialized
DEBUG - 2021-09-12 15:26:05 --> UTF-8 Support Enabled
INFO - 2021-09-12 15:26:05 --> Utf8 Class Initialized
INFO - 2021-09-12 15:26:05 --> URI Class Initialized
INFO - 2021-09-12 15:26:05 --> Router Class Initialized
INFO - 2021-09-12 15:26:05 --> Output Class Initialized
INFO - 2021-09-12 15:26:05 --> Security Class Initialized
DEBUG - 2021-09-12 15:26:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-12 15:26:05 --> Input Class Initialized
INFO - 2021-09-12 15:26:05 --> Language Class Initialized
ERROR - 2021-09-12 15:26:05 --> 404 Page Not Found: Temp/index
ERROR - 2021-09-12 15:26:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-12 15:26:05 --> Config Class Initialized
INFO - 2021-09-12 15:26:05 --> Hooks Class Initialized
DEBUG - 2021-09-12 15:26:05 --> UTF-8 Support Enabled
INFO - 2021-09-12 15:26:05 --> Utf8 Class Initialized
INFO - 2021-09-12 15:26:05 --> URI Class Initialized
INFO - 2021-09-12 15:26:05 --> Router Class Initialized
INFO - 2021-09-12 15:26:05 --> Output Class Initialized
INFO - 2021-09-12 15:26:05 --> Security Class Initialized
DEBUG - 2021-09-12 15:26:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-12 15:26:05 --> Input Class Initialized
INFO - 2021-09-12 15:26:05 --> Language Class Initialized
ERROR - 2021-09-12 15:26:05 --> 404 Page Not Found: 2018/index
ERROR - 2021-09-12 15:26:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-12 15:26:06 --> Config Class Initialized
INFO - 2021-09-12 15:26:06 --> Hooks Class Initialized
DEBUG - 2021-09-12 15:26:06 --> UTF-8 Support Enabled
INFO - 2021-09-12 15:26:06 --> Utf8 Class Initialized
INFO - 2021-09-12 15:26:06 --> URI Class Initialized
INFO - 2021-09-12 15:26:06 --> Router Class Initialized
INFO - 2021-09-12 15:26:06 --> Output Class Initialized
INFO - 2021-09-12 15:26:06 --> Security Class Initialized
DEBUG - 2021-09-12 15:26:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-12 15:26:06 --> Input Class Initialized
INFO - 2021-09-12 15:26:06 --> Language Class Initialized
ERROR - 2021-09-12 15:26:06 --> 404 Page Not Found: 2019/index
ERROR - 2021-09-12 15:26:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-12 15:26:06 --> Config Class Initialized
INFO - 2021-09-12 15:26:06 --> Hooks Class Initialized
DEBUG - 2021-09-12 15:26:06 --> UTF-8 Support Enabled
INFO - 2021-09-12 15:26:06 --> Utf8 Class Initialized
INFO - 2021-09-12 15:26:06 --> URI Class Initialized
INFO - 2021-09-12 15:26:06 --> Router Class Initialized
INFO - 2021-09-12 15:26:06 --> Output Class Initialized
INFO - 2021-09-12 15:26:06 --> Security Class Initialized
DEBUG - 2021-09-12 15:26:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-12 15:26:06 --> Input Class Initialized
INFO - 2021-09-12 15:26:06 --> Language Class Initialized
ERROR - 2021-09-12 15:26:06 --> 404 Page Not Found: Bk/index
ERROR - 2021-09-12 15:26:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-12 15:26:06 --> Config Class Initialized
INFO - 2021-09-12 15:26:06 --> Hooks Class Initialized
DEBUG - 2021-09-12 15:26:06 --> UTF-8 Support Enabled
INFO - 2021-09-12 15:26:06 --> Utf8 Class Initialized
INFO - 2021-09-12 15:26:06 --> URI Class Initialized
INFO - 2021-09-12 15:26:06 --> Router Class Initialized
INFO - 2021-09-12 15:26:06 --> Output Class Initialized
INFO - 2021-09-12 15:26:06 --> Security Class Initialized
DEBUG - 2021-09-12 15:26:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-12 15:26:06 --> Input Class Initialized
INFO - 2021-09-12 15:26:06 --> Language Class Initialized
ERROR - 2021-09-12 15:26:06 --> 404 Page Not Found: Wp1/index
ERROR - 2021-09-12 15:26:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-12 15:26:07 --> Config Class Initialized
INFO - 2021-09-12 15:26:07 --> Hooks Class Initialized
DEBUG - 2021-09-12 15:26:07 --> UTF-8 Support Enabled
INFO - 2021-09-12 15:26:07 --> Utf8 Class Initialized
INFO - 2021-09-12 15:26:07 --> URI Class Initialized
INFO - 2021-09-12 15:26:07 --> Router Class Initialized
INFO - 2021-09-12 15:26:07 --> Output Class Initialized
INFO - 2021-09-12 15:26:07 --> Security Class Initialized
DEBUG - 2021-09-12 15:26:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-12 15:26:07 --> Input Class Initialized
INFO - 2021-09-12 15:26:07 --> Language Class Initialized
ERROR - 2021-09-12 15:26:07 --> 404 Page Not Found: Wp2/index
ERROR - 2021-09-12 15:26:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-12 15:26:07 --> Config Class Initialized
INFO - 2021-09-12 15:26:07 --> Hooks Class Initialized
DEBUG - 2021-09-12 15:26:07 --> UTF-8 Support Enabled
INFO - 2021-09-12 15:26:07 --> Utf8 Class Initialized
INFO - 2021-09-12 15:26:07 --> URI Class Initialized
INFO - 2021-09-12 15:26:07 --> Router Class Initialized
INFO - 2021-09-12 15:26:07 --> Output Class Initialized
INFO - 2021-09-12 15:26:07 --> Security Class Initialized
DEBUG - 2021-09-12 15:26:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-12 15:26:07 --> Input Class Initialized
INFO - 2021-09-12 15:26:07 --> Language Class Initialized
ERROR - 2021-09-12 15:26:07 --> 404 Page Not Found: V1/index
ERROR - 2021-09-12 15:26:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-12 15:26:07 --> Config Class Initialized
INFO - 2021-09-12 15:26:07 --> Hooks Class Initialized
DEBUG - 2021-09-12 15:26:07 --> UTF-8 Support Enabled
INFO - 2021-09-12 15:26:07 --> Utf8 Class Initialized
INFO - 2021-09-12 15:26:07 --> URI Class Initialized
INFO - 2021-09-12 15:26:07 --> Router Class Initialized
INFO - 2021-09-12 15:26:07 --> Output Class Initialized
INFO - 2021-09-12 15:26:07 --> Security Class Initialized
DEBUG - 2021-09-12 15:26:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-12 15:26:07 --> Input Class Initialized
INFO - 2021-09-12 15:26:07 --> Language Class Initialized
ERROR - 2021-09-12 15:26:07 --> 404 Page Not Found: V2/index
ERROR - 2021-09-12 15:26:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-12 15:26:07 --> Config Class Initialized
INFO - 2021-09-12 15:26:07 --> Hooks Class Initialized
DEBUG - 2021-09-12 15:26:07 --> UTF-8 Support Enabled
INFO - 2021-09-12 15:26:07 --> Utf8 Class Initialized
INFO - 2021-09-12 15:26:07 --> URI Class Initialized
INFO - 2021-09-12 15:26:07 --> Router Class Initialized
INFO - 2021-09-12 15:26:07 --> Output Class Initialized
INFO - 2021-09-12 15:26:07 --> Security Class Initialized
DEBUG - 2021-09-12 15:26:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-12 15:26:07 --> Input Class Initialized
INFO - 2021-09-12 15:26:07 --> Language Class Initialized
ERROR - 2021-09-12 15:26:07 --> 404 Page Not Found: Bak/index
ERROR - 2021-09-12 15:26:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-12 15:26:08 --> Config Class Initialized
INFO - 2021-09-12 15:26:08 --> Hooks Class Initialized
DEBUG - 2021-09-12 15:26:08 --> UTF-8 Support Enabled
INFO - 2021-09-12 15:26:08 --> Utf8 Class Initialized
INFO - 2021-09-12 15:26:08 --> URI Class Initialized
INFO - 2021-09-12 15:26:08 --> Router Class Initialized
INFO - 2021-09-12 15:26:08 --> Output Class Initialized
INFO - 2021-09-12 15:26:08 --> Security Class Initialized
DEBUG - 2021-09-12 15:26:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-12 15:26:08 --> Input Class Initialized
INFO - 2021-09-12 15:26:08 --> Language Class Initialized
ERROR - 2021-09-12 15:26:08 --> 404 Page Not Found: Install/index
ERROR - 2021-09-12 15:26:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-12 15:26:08 --> Config Class Initialized
INFO - 2021-09-12 15:26:08 --> Hooks Class Initialized
DEBUG - 2021-09-12 15:26:08 --> UTF-8 Support Enabled
INFO - 2021-09-12 15:26:08 --> Utf8 Class Initialized
INFO - 2021-09-12 15:26:08 --> URI Class Initialized
INFO - 2021-09-12 15:26:08 --> Router Class Initialized
INFO - 2021-09-12 15:26:08 --> Output Class Initialized
INFO - 2021-09-12 15:26:08 --> Security Class Initialized
DEBUG - 2021-09-12 15:26:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-12 15:26:08 --> Input Class Initialized
INFO - 2021-09-12 15:26:08 --> Language Class Initialized
ERROR - 2021-09-12 15:26:08 --> 404 Page Not Found: 2020/index
ERROR - 2021-09-12 15:26:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-12 15:26:09 --> Config Class Initialized
INFO - 2021-09-12 15:26:09 --> Hooks Class Initialized
DEBUG - 2021-09-12 15:26:09 --> UTF-8 Support Enabled
INFO - 2021-09-12 15:26:09 --> Utf8 Class Initialized
INFO - 2021-09-12 15:26:09 --> URI Class Initialized
INFO - 2021-09-12 15:26:09 --> Router Class Initialized
INFO - 2021-09-12 15:26:09 --> Output Class Initialized
INFO - 2021-09-12 15:26:09 --> Security Class Initialized
DEBUG - 2021-09-12 15:26:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-12 15:26:09 --> Input Class Initialized
INFO - 2021-09-12 15:26:09 --> Language Class Initialized
ERROR - 2021-09-12 15:26:09 --> 404 Page Not Found: New-site/index
ERROR - 2021-09-12 19:32:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-12 19:32:40 --> Config Class Initialized
INFO - 2021-09-12 19:32:40 --> Hooks Class Initialized
DEBUG - 2021-09-12 19:32:40 --> UTF-8 Support Enabled
INFO - 2021-09-12 19:32:40 --> Utf8 Class Initialized
INFO - 2021-09-12 19:32:40 --> URI Class Initialized
INFO - 2021-09-12 19:32:40 --> Router Class Initialized
INFO - 2021-09-12 19:32:40 --> Output Class Initialized
INFO - 2021-09-12 19:32:40 --> Security Class Initialized
DEBUG - 2021-09-12 19:32:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-12 19:32:40 --> Input Class Initialized
INFO - 2021-09-12 19:32:40 --> Language Class Initialized
ERROR - 2021-09-12 19:32:40 --> 404 Page Not Found: Wp-admin/setup-config.php
ERROR - 2021-09-12 20:15:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-12 20:15:30 --> Config Class Initialized
INFO - 2021-09-12 20:15:30 --> Hooks Class Initialized
DEBUG - 2021-09-12 20:15:30 --> UTF-8 Support Enabled
INFO - 2021-09-12 20:15:30 --> Utf8 Class Initialized
INFO - 2021-09-12 20:15:30 --> URI Class Initialized
DEBUG - 2021-09-12 20:15:30 --> No URI present. Default controller set.
INFO - 2021-09-12 20:15:30 --> Router Class Initialized
INFO - 2021-09-12 20:15:30 --> Output Class Initialized
INFO - 2021-09-12 20:15:30 --> Security Class Initialized
DEBUG - 2021-09-12 20:15:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-12 20:15:30 --> Input Class Initialized
INFO - 2021-09-12 20:15:30 --> Language Class Initialized
INFO - 2021-09-12 20:15:30 --> Loader Class Initialized
INFO - 2021-09-12 20:15:30 --> Helper loaded: url_helper
INFO - 2021-09-12 20:15:30 --> Helper loaded: form_helper
INFO - 2021-09-12 20:15:30 --> Helper loaded: common_helper
INFO - 2021-09-12 20:15:30 --> Database Driver Class Initialized
DEBUG - 2021-09-12 20:15:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-12 20:15:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-12 20:15:30 --> Controller Class Initialized
INFO - 2021-09-12 20:15:30 --> Form Validation Class Initialized
DEBUG - 2021-09-12 20:15:30 --> Encrypt Class Initialized
DEBUG - 2021-09-12 20:15:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-09-12 20:15:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-09-12 20:15:30 --> Email Class Initialized
INFO - 2021-09-12 20:15:30 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-09-12 20:15:30 --> Calendar Class Initialized
INFO - 2021-09-12 20:15:30 --> Model "Login_model" initialized
INFO - 2021-09-12 20:15:30 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-09-12 20:15:30 --> Final output sent to browser
DEBUG - 2021-09-12 20:15:30 --> Total execution time: 0.0744
ERROR - 2021-09-12 20:15:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-12 20:15:31 --> Config Class Initialized
INFO - 2021-09-12 20:15:31 --> Hooks Class Initialized
DEBUG - 2021-09-12 20:15:31 --> UTF-8 Support Enabled
INFO - 2021-09-12 20:15:31 --> Utf8 Class Initialized
INFO - 2021-09-12 20:15:31 --> URI Class Initialized
DEBUG - 2021-09-12 20:15:31 --> No URI present. Default controller set.
INFO - 2021-09-12 20:15:31 --> Router Class Initialized
INFO - 2021-09-12 20:15:31 --> Output Class Initialized
INFO - 2021-09-12 20:15:31 --> Security Class Initialized
DEBUG - 2021-09-12 20:15:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-12 20:15:31 --> Input Class Initialized
INFO - 2021-09-12 20:15:31 --> Language Class Initialized
INFO - 2021-09-12 20:15:31 --> Loader Class Initialized
INFO - 2021-09-12 20:15:31 --> Helper loaded: url_helper
INFO - 2021-09-12 20:15:31 --> Helper loaded: form_helper
INFO - 2021-09-12 20:15:31 --> Helper loaded: common_helper
INFO - 2021-09-12 20:15:31 --> Database Driver Class Initialized
DEBUG - 2021-09-12 20:15:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-12 20:15:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-12 20:15:31 --> Controller Class Initialized
INFO - 2021-09-12 20:15:31 --> Form Validation Class Initialized
DEBUG - 2021-09-12 20:15:31 --> Encrypt Class Initialized
DEBUG - 2021-09-12 20:15:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-09-12 20:15:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-09-12 20:15:31 --> Email Class Initialized
INFO - 2021-09-12 20:15:31 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-09-12 20:15:31 --> Calendar Class Initialized
INFO - 2021-09-12 20:15:31 --> Model "Login_model" initialized
INFO - 2021-09-12 20:15:31 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-09-12 20:15:31 --> Final output sent to browser
DEBUG - 2021-09-12 20:15:31 --> Total execution time: 0.0193
ERROR - 2021-09-12 20:15:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-12 20:15:31 --> Config Class Initialized
INFO - 2021-09-12 20:15:31 --> Hooks Class Initialized
DEBUG - 2021-09-12 20:15:31 --> UTF-8 Support Enabled
INFO - 2021-09-12 20:15:31 --> Utf8 Class Initialized
INFO - 2021-09-12 20:15:31 --> URI Class Initialized
INFO - 2021-09-12 20:15:31 --> Router Class Initialized
INFO - 2021-09-12 20:15:31 --> Output Class Initialized
INFO - 2021-09-12 20:15:31 --> Security Class Initialized
DEBUG - 2021-09-12 20:15:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-12 20:15:31 --> Input Class Initialized
INFO - 2021-09-12 20:15:31 --> Language Class Initialized
ERROR - 2021-09-12 20:15:31 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
ERROR - 2021-09-12 20:15:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-12 20:15:31 --> Config Class Initialized
INFO - 2021-09-12 20:15:31 --> Hooks Class Initialized
DEBUG - 2021-09-12 20:15:31 --> UTF-8 Support Enabled
INFO - 2021-09-12 20:15:31 --> Utf8 Class Initialized
INFO - 2021-09-12 20:15:31 --> URI Class Initialized
DEBUG - 2021-09-12 20:15:31 --> No URI present. Default controller set.
INFO - 2021-09-12 20:15:31 --> Router Class Initialized
INFO - 2021-09-12 20:15:31 --> Output Class Initialized
INFO - 2021-09-12 20:15:31 --> Security Class Initialized
DEBUG - 2021-09-12 20:15:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-12 20:15:31 --> Input Class Initialized
INFO - 2021-09-12 20:15:31 --> Language Class Initialized
INFO - 2021-09-12 20:15:31 --> Loader Class Initialized
INFO - 2021-09-12 20:15:31 --> Helper loaded: url_helper
INFO - 2021-09-12 20:15:31 --> Helper loaded: form_helper
INFO - 2021-09-12 20:15:31 --> Helper loaded: common_helper
INFO - 2021-09-12 20:15:31 --> Database Driver Class Initialized
DEBUG - 2021-09-12 20:15:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-12 20:15:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-12 20:15:31 --> Controller Class Initialized
INFO - 2021-09-12 20:15:31 --> Form Validation Class Initialized
DEBUG - 2021-09-12 20:15:31 --> Encrypt Class Initialized
DEBUG - 2021-09-12 20:15:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-09-12 20:15:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-09-12 20:15:31 --> Email Class Initialized
INFO - 2021-09-12 20:15:31 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-09-12 20:15:31 --> Calendar Class Initialized
INFO - 2021-09-12 20:15:31 --> Model "Login_model" initialized
INFO - 2021-09-12 20:15:31 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-09-12 20:15:31 --> Final output sent to browser
DEBUG - 2021-09-12 20:15:31 --> Total execution time: 0.0235
ERROR - 2021-09-12 20:15:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-12 20:15:32 --> Config Class Initialized
INFO - 2021-09-12 20:15:32 --> Hooks Class Initialized
DEBUG - 2021-09-12 20:15:32 --> UTF-8 Support Enabled
INFO - 2021-09-12 20:15:32 --> Utf8 Class Initialized
INFO - 2021-09-12 20:15:32 --> URI Class Initialized
INFO - 2021-09-12 20:15:32 --> Router Class Initialized
INFO - 2021-09-12 20:15:32 --> Output Class Initialized
INFO - 2021-09-12 20:15:32 --> Security Class Initialized
DEBUG - 2021-09-12 20:15:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-12 20:15:32 --> Input Class Initialized
INFO - 2021-09-12 20:15:32 --> Language Class Initialized
ERROR - 2021-09-12 20:15:32 --> 404 Page Not Found: Blog/wp-includes
ERROR - 2021-09-12 20:15:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-12 20:15:32 --> Config Class Initialized
INFO - 2021-09-12 20:15:32 --> Hooks Class Initialized
DEBUG - 2021-09-12 20:15:32 --> UTF-8 Support Enabled
INFO - 2021-09-12 20:15:32 --> Utf8 Class Initialized
INFO - 2021-09-12 20:15:32 --> URI Class Initialized
INFO - 2021-09-12 20:15:32 --> Router Class Initialized
INFO - 2021-09-12 20:15:32 --> Output Class Initialized
INFO - 2021-09-12 20:15:32 --> Security Class Initialized
DEBUG - 2021-09-12 20:15:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-12 20:15:32 --> Input Class Initialized
INFO - 2021-09-12 20:15:32 --> Language Class Initialized
ERROR - 2021-09-12 20:15:32 --> 404 Page Not Found: Web/wp-includes
ERROR - 2021-09-12 20:15:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-12 20:15:32 --> Config Class Initialized
INFO - 2021-09-12 20:15:32 --> Hooks Class Initialized
DEBUG - 2021-09-12 20:15:32 --> UTF-8 Support Enabled
INFO - 2021-09-12 20:15:32 --> Utf8 Class Initialized
INFO - 2021-09-12 20:15:32 --> URI Class Initialized
INFO - 2021-09-12 20:15:32 --> Router Class Initialized
INFO - 2021-09-12 20:15:32 --> Output Class Initialized
INFO - 2021-09-12 20:15:32 --> Security Class Initialized
DEBUG - 2021-09-12 20:15:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-12 20:15:32 --> Input Class Initialized
INFO - 2021-09-12 20:15:32 --> Language Class Initialized
ERROR - 2021-09-12 20:15:32 --> 404 Page Not Found: Wordpress/wp-includes
ERROR - 2021-09-12 20:15:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-12 20:15:33 --> Config Class Initialized
INFO - 2021-09-12 20:15:33 --> Hooks Class Initialized
DEBUG - 2021-09-12 20:15:33 --> UTF-8 Support Enabled
INFO - 2021-09-12 20:15:33 --> Utf8 Class Initialized
INFO - 2021-09-12 20:15:33 --> URI Class Initialized
INFO - 2021-09-12 20:15:33 --> Router Class Initialized
INFO - 2021-09-12 20:15:33 --> Output Class Initialized
INFO - 2021-09-12 20:15:33 --> Security Class Initialized
DEBUG - 2021-09-12 20:15:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-12 20:15:33 --> Input Class Initialized
INFO - 2021-09-12 20:15:33 --> Language Class Initialized
ERROR - 2021-09-12 20:15:33 --> 404 Page Not Found: Website/wp-includes
ERROR - 2021-09-12 20:15:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-12 20:15:33 --> Config Class Initialized
INFO - 2021-09-12 20:15:33 --> Hooks Class Initialized
DEBUG - 2021-09-12 20:15:33 --> UTF-8 Support Enabled
INFO - 2021-09-12 20:15:33 --> Utf8 Class Initialized
INFO - 2021-09-12 20:15:33 --> URI Class Initialized
INFO - 2021-09-12 20:15:33 --> Router Class Initialized
INFO - 2021-09-12 20:15:33 --> Output Class Initialized
INFO - 2021-09-12 20:15:33 --> Security Class Initialized
DEBUG - 2021-09-12 20:15:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-12 20:15:33 --> Input Class Initialized
INFO - 2021-09-12 20:15:33 --> Language Class Initialized
ERROR - 2021-09-12 20:15:33 --> 404 Page Not Found: Wp/wp-includes
ERROR - 2021-09-12 20:15:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-12 20:15:33 --> Config Class Initialized
INFO - 2021-09-12 20:15:33 --> Hooks Class Initialized
DEBUG - 2021-09-12 20:15:33 --> UTF-8 Support Enabled
INFO - 2021-09-12 20:15:33 --> Utf8 Class Initialized
INFO - 2021-09-12 20:15:33 --> URI Class Initialized
INFO - 2021-09-12 20:15:33 --> Router Class Initialized
INFO - 2021-09-12 20:15:33 --> Output Class Initialized
INFO - 2021-09-12 20:15:33 --> Security Class Initialized
DEBUG - 2021-09-12 20:15:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-12 20:15:33 --> Input Class Initialized
INFO - 2021-09-12 20:15:33 --> Language Class Initialized
ERROR - 2021-09-12 20:15:33 --> 404 Page Not Found: News/wp-includes
ERROR - 2021-09-12 20:15:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-12 20:15:34 --> Config Class Initialized
INFO - 2021-09-12 20:15:34 --> Hooks Class Initialized
DEBUG - 2021-09-12 20:15:34 --> UTF-8 Support Enabled
INFO - 2021-09-12 20:15:34 --> Utf8 Class Initialized
INFO - 2021-09-12 20:15:34 --> URI Class Initialized
INFO - 2021-09-12 20:15:34 --> Router Class Initialized
INFO - 2021-09-12 20:15:34 --> Output Class Initialized
INFO - 2021-09-12 20:15:34 --> Security Class Initialized
DEBUG - 2021-09-12 20:15:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-12 20:15:34 --> Input Class Initialized
INFO - 2021-09-12 20:15:34 --> Language Class Initialized
ERROR - 2021-09-12 20:15:34 --> 404 Page Not Found: 2018/wp-includes
ERROR - 2021-09-12 20:15:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-12 20:15:34 --> Config Class Initialized
INFO - 2021-09-12 20:15:34 --> Hooks Class Initialized
DEBUG - 2021-09-12 20:15:34 --> UTF-8 Support Enabled
INFO - 2021-09-12 20:15:34 --> Utf8 Class Initialized
INFO - 2021-09-12 20:15:34 --> URI Class Initialized
INFO - 2021-09-12 20:15:34 --> Router Class Initialized
INFO - 2021-09-12 20:15:34 --> Output Class Initialized
INFO - 2021-09-12 20:15:34 --> Security Class Initialized
DEBUG - 2021-09-12 20:15:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-12 20:15:34 --> Input Class Initialized
INFO - 2021-09-12 20:15:34 --> Language Class Initialized
ERROR - 2021-09-12 20:15:34 --> 404 Page Not Found: 2019/wp-includes
ERROR - 2021-09-12 20:15:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-12 20:15:34 --> Config Class Initialized
INFO - 2021-09-12 20:15:34 --> Hooks Class Initialized
DEBUG - 2021-09-12 20:15:34 --> UTF-8 Support Enabled
INFO - 2021-09-12 20:15:34 --> Utf8 Class Initialized
INFO - 2021-09-12 20:15:34 --> URI Class Initialized
INFO - 2021-09-12 20:15:34 --> Router Class Initialized
INFO - 2021-09-12 20:15:34 --> Output Class Initialized
INFO - 2021-09-12 20:15:34 --> Security Class Initialized
DEBUG - 2021-09-12 20:15:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-12 20:15:34 --> Input Class Initialized
INFO - 2021-09-12 20:15:34 --> Language Class Initialized
ERROR - 2021-09-12 20:15:34 --> 404 Page Not Found: Shop/wp-includes
ERROR - 2021-09-12 20:15:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-12 20:15:34 --> Config Class Initialized
INFO - 2021-09-12 20:15:34 --> Hooks Class Initialized
DEBUG - 2021-09-12 20:15:34 --> UTF-8 Support Enabled
INFO - 2021-09-12 20:15:34 --> Utf8 Class Initialized
INFO - 2021-09-12 20:15:34 --> URI Class Initialized
INFO - 2021-09-12 20:15:34 --> Router Class Initialized
INFO - 2021-09-12 20:15:34 --> Output Class Initialized
INFO - 2021-09-12 20:15:34 --> Security Class Initialized
DEBUG - 2021-09-12 20:15:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-12 20:15:34 --> Input Class Initialized
INFO - 2021-09-12 20:15:34 --> Language Class Initialized
ERROR - 2021-09-12 20:15:34 --> 404 Page Not Found: Wp1/wp-includes
ERROR - 2021-09-12 20:15:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-12 20:15:35 --> Config Class Initialized
INFO - 2021-09-12 20:15:35 --> Hooks Class Initialized
DEBUG - 2021-09-12 20:15:35 --> UTF-8 Support Enabled
INFO - 2021-09-12 20:15:35 --> Utf8 Class Initialized
INFO - 2021-09-12 20:15:35 --> URI Class Initialized
INFO - 2021-09-12 20:15:35 --> Router Class Initialized
INFO - 2021-09-12 20:15:35 --> Output Class Initialized
INFO - 2021-09-12 20:15:35 --> Security Class Initialized
DEBUG - 2021-09-12 20:15:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-12 20:15:35 --> Input Class Initialized
INFO - 2021-09-12 20:15:35 --> Language Class Initialized
ERROR - 2021-09-12 20:15:35 --> 404 Page Not Found: Test/wp-includes
ERROR - 2021-09-12 20:15:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-12 20:15:35 --> Config Class Initialized
INFO - 2021-09-12 20:15:35 --> Hooks Class Initialized
DEBUG - 2021-09-12 20:15:35 --> UTF-8 Support Enabled
INFO - 2021-09-12 20:15:35 --> Utf8 Class Initialized
INFO - 2021-09-12 20:15:35 --> URI Class Initialized
INFO - 2021-09-12 20:15:35 --> Router Class Initialized
INFO - 2021-09-12 20:15:35 --> Output Class Initialized
INFO - 2021-09-12 20:15:35 --> Security Class Initialized
DEBUG - 2021-09-12 20:15:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-12 20:15:35 --> Input Class Initialized
INFO - 2021-09-12 20:15:35 --> Language Class Initialized
ERROR - 2021-09-12 20:15:35 --> 404 Page Not Found: Media/wp-includes
ERROR - 2021-09-12 20:15:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-12 20:15:35 --> Config Class Initialized
INFO - 2021-09-12 20:15:35 --> Hooks Class Initialized
DEBUG - 2021-09-12 20:15:35 --> UTF-8 Support Enabled
INFO - 2021-09-12 20:15:35 --> Utf8 Class Initialized
INFO - 2021-09-12 20:15:35 --> URI Class Initialized
INFO - 2021-09-12 20:15:35 --> Router Class Initialized
INFO - 2021-09-12 20:15:35 --> Output Class Initialized
INFO - 2021-09-12 20:15:35 --> Security Class Initialized
DEBUG - 2021-09-12 20:15:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-12 20:15:35 --> Input Class Initialized
INFO - 2021-09-12 20:15:35 --> Language Class Initialized
ERROR - 2021-09-12 20:15:35 --> 404 Page Not Found: Wp2/wp-includes
ERROR - 2021-09-12 20:15:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-12 20:15:36 --> Config Class Initialized
INFO - 2021-09-12 20:15:36 --> Hooks Class Initialized
DEBUG - 2021-09-12 20:15:36 --> UTF-8 Support Enabled
INFO - 2021-09-12 20:15:36 --> Utf8 Class Initialized
INFO - 2021-09-12 20:15:36 --> URI Class Initialized
INFO - 2021-09-12 20:15:36 --> Router Class Initialized
INFO - 2021-09-12 20:15:36 --> Output Class Initialized
INFO - 2021-09-12 20:15:36 --> Security Class Initialized
DEBUG - 2021-09-12 20:15:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-12 20:15:36 --> Input Class Initialized
INFO - 2021-09-12 20:15:36 --> Language Class Initialized
ERROR - 2021-09-12 20:15:36 --> 404 Page Not Found: Site/wp-includes
ERROR - 2021-09-12 20:15:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-12 20:15:36 --> Config Class Initialized
INFO - 2021-09-12 20:15:36 --> Hooks Class Initialized
DEBUG - 2021-09-12 20:15:36 --> UTF-8 Support Enabled
INFO - 2021-09-12 20:15:36 --> Utf8 Class Initialized
INFO - 2021-09-12 20:15:36 --> URI Class Initialized
INFO - 2021-09-12 20:15:36 --> Router Class Initialized
INFO - 2021-09-12 20:15:36 --> Output Class Initialized
INFO - 2021-09-12 20:15:36 --> Security Class Initialized
DEBUG - 2021-09-12 20:15:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-12 20:15:36 --> Input Class Initialized
INFO - 2021-09-12 20:15:36 --> Language Class Initialized
ERROR - 2021-09-12 20:15:36 --> 404 Page Not Found: Cms/wp-includes
ERROR - 2021-09-12 20:15:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-12 20:15:36 --> Config Class Initialized
INFO - 2021-09-12 20:15:36 --> Hooks Class Initialized
DEBUG - 2021-09-12 20:15:36 --> UTF-8 Support Enabled
INFO - 2021-09-12 20:15:36 --> Utf8 Class Initialized
INFO - 2021-09-12 20:15:36 --> URI Class Initialized
INFO - 2021-09-12 20:15:36 --> Router Class Initialized
INFO - 2021-09-12 20:15:36 --> Output Class Initialized
INFO - 2021-09-12 20:15:36 --> Security Class Initialized
DEBUG - 2021-09-12 20:15:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-12 20:15:36 --> Input Class Initialized
INFO - 2021-09-12 20:15:36 --> Language Class Initialized
ERROR - 2021-09-12 20:15:36 --> 404 Page Not Found: Sito/wp-includes
