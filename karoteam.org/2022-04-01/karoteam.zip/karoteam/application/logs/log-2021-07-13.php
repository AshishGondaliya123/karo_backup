<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-07-13 14:57:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-13 14:57:08 --> Config Class Initialized
INFO - 2021-07-13 14:57:08 --> Hooks Class Initialized
DEBUG - 2021-07-13 14:57:08 --> UTF-8 Support Enabled
INFO - 2021-07-13 14:57:08 --> Utf8 Class Initialized
INFO - 2021-07-13 14:57:08 --> URI Class Initialized
DEBUG - 2021-07-13 14:57:08 --> No URI present. Default controller set.
INFO - 2021-07-13 14:57:08 --> Router Class Initialized
INFO - 2021-07-13 14:57:08 --> Output Class Initialized
INFO - 2021-07-13 14:57:08 --> Security Class Initialized
DEBUG - 2021-07-13 14:57:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-13 14:57:08 --> Input Class Initialized
INFO - 2021-07-13 14:57:08 --> Language Class Initialized
INFO - 2021-07-13 14:57:08 --> Loader Class Initialized
INFO - 2021-07-13 14:57:08 --> Helper loaded: url_helper
INFO - 2021-07-13 14:57:08 --> Helper loaded: form_helper
INFO - 2021-07-13 14:57:08 --> Helper loaded: common_helper
INFO - 2021-07-13 14:57:08 --> Database Driver Class Initialized
DEBUG - 2021-07-13 14:57:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-13 14:57:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-13 14:57:08 --> Controller Class Initialized
INFO - 2021-07-13 14:57:08 --> Form Validation Class Initialized
DEBUG - 2021-07-13 14:57:08 --> Encrypt Class Initialized
DEBUG - 2021-07-13 14:57:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-07-13 14:57:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-07-13 14:57:08 --> Email Class Initialized
INFO - 2021-07-13 14:57:08 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-07-13 14:57:08 --> Calendar Class Initialized
INFO - 2021-07-13 14:57:08 --> Model "Login_model" initialized
INFO - 2021-07-13 14:57:08 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-07-13 14:57:08 --> Final output sent to browser
DEBUG - 2021-07-13 14:57:08 --> Total execution time: 0.0420
ERROR - 2021-07-13 15:32:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-13 15:32:08 --> Config Class Initialized
INFO - 2021-07-13 15:32:08 --> Hooks Class Initialized
DEBUG - 2021-07-13 15:32:08 --> UTF-8 Support Enabled
INFO - 2021-07-13 15:32:08 --> Utf8 Class Initialized
INFO - 2021-07-13 15:32:08 --> URI Class Initialized
DEBUG - 2021-07-13 15:32:08 --> No URI present. Default controller set.
INFO - 2021-07-13 15:32:08 --> Router Class Initialized
INFO - 2021-07-13 15:32:08 --> Output Class Initialized
INFO - 2021-07-13 15:32:08 --> Security Class Initialized
DEBUG - 2021-07-13 15:32:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-13 15:32:08 --> Input Class Initialized
INFO - 2021-07-13 15:32:08 --> Language Class Initialized
INFO - 2021-07-13 15:32:08 --> Loader Class Initialized
INFO - 2021-07-13 15:32:08 --> Helper loaded: url_helper
INFO - 2021-07-13 15:32:08 --> Helper loaded: form_helper
INFO - 2021-07-13 15:32:08 --> Helper loaded: common_helper
INFO - 2021-07-13 15:32:08 --> Database Driver Class Initialized
DEBUG - 2021-07-13 15:32:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-13 15:32:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-13 15:32:08 --> Controller Class Initialized
INFO - 2021-07-13 15:32:08 --> Form Validation Class Initialized
DEBUG - 2021-07-13 15:32:08 --> Encrypt Class Initialized
DEBUG - 2021-07-13 15:32:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-07-13 15:32:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-07-13 15:32:08 --> Email Class Initialized
INFO - 2021-07-13 15:32:08 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-07-13 15:32:08 --> Calendar Class Initialized
INFO - 2021-07-13 15:32:08 --> Model "Login_model" initialized
INFO - 2021-07-13 15:32:08 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-07-13 15:32:08 --> Final output sent to browser
DEBUG - 2021-07-13 15:32:08 --> Total execution time: 0.0487
ERROR - 2021-07-13 15:38:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-13 15:38:06 --> Config Class Initialized
INFO - 2021-07-13 15:38:06 --> Hooks Class Initialized
DEBUG - 2021-07-13 15:38:06 --> UTF-8 Support Enabled
INFO - 2021-07-13 15:38:06 --> Utf8 Class Initialized
INFO - 2021-07-13 15:38:06 --> URI Class Initialized
DEBUG - 2021-07-13 15:38:06 --> No URI present. Default controller set.
INFO - 2021-07-13 15:38:06 --> Router Class Initialized
INFO - 2021-07-13 15:38:06 --> Output Class Initialized
INFO - 2021-07-13 15:38:06 --> Security Class Initialized
DEBUG - 2021-07-13 15:38:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-13 15:38:06 --> Input Class Initialized
INFO - 2021-07-13 15:38:06 --> Language Class Initialized
INFO - 2021-07-13 15:38:06 --> Loader Class Initialized
INFO - 2021-07-13 15:38:06 --> Helper loaded: url_helper
INFO - 2021-07-13 15:38:06 --> Helper loaded: form_helper
INFO - 2021-07-13 15:38:06 --> Helper loaded: common_helper
INFO - 2021-07-13 15:38:06 --> Database Driver Class Initialized
DEBUG - 2021-07-13 15:38:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-13 15:38:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-13 15:38:06 --> Controller Class Initialized
INFO - 2021-07-13 15:38:06 --> Form Validation Class Initialized
DEBUG - 2021-07-13 15:38:06 --> Encrypt Class Initialized
DEBUG - 2021-07-13 15:38:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-07-13 15:38:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-07-13 15:38:06 --> Email Class Initialized
INFO - 2021-07-13 15:38:06 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-07-13 15:38:06 --> Calendar Class Initialized
INFO - 2021-07-13 15:38:06 --> Model "Login_model" initialized
INFO - 2021-07-13 15:38:06 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-07-13 15:38:06 --> Final output sent to browser
DEBUG - 2021-07-13 15:38:06 --> Total execution time: 0.0180
ERROR - 2021-07-13 20:39:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-13 20:39:05 --> Config Class Initialized
INFO - 2021-07-13 20:39:05 --> Hooks Class Initialized
DEBUG - 2021-07-13 20:39:05 --> UTF-8 Support Enabled
INFO - 2021-07-13 20:39:05 --> Utf8 Class Initialized
INFO - 2021-07-13 20:39:05 --> URI Class Initialized
DEBUG - 2021-07-13 20:39:05 --> No URI present. Default controller set.
INFO - 2021-07-13 20:39:05 --> Router Class Initialized
INFO - 2021-07-13 20:39:05 --> Output Class Initialized
INFO - 2021-07-13 20:39:05 --> Security Class Initialized
DEBUG - 2021-07-13 20:39:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-13 20:39:05 --> Input Class Initialized
INFO - 2021-07-13 20:39:05 --> Language Class Initialized
INFO - 2021-07-13 20:39:05 --> Loader Class Initialized
INFO - 2021-07-13 20:39:05 --> Helper loaded: url_helper
INFO - 2021-07-13 20:39:05 --> Helper loaded: form_helper
INFO - 2021-07-13 20:39:05 --> Helper loaded: common_helper
INFO - 2021-07-13 20:39:05 --> Database Driver Class Initialized
DEBUG - 2021-07-13 20:39:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-13 20:39:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-13 20:39:05 --> Controller Class Initialized
INFO - 2021-07-13 20:39:05 --> Form Validation Class Initialized
DEBUG - 2021-07-13 20:39:05 --> Encrypt Class Initialized
DEBUG - 2021-07-13 20:39:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-07-13 20:39:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-07-13 20:39:05 --> Email Class Initialized
INFO - 2021-07-13 20:39:05 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-07-13 20:39:05 --> Calendar Class Initialized
INFO - 2021-07-13 20:39:05 --> Model "Login_model" initialized
INFO - 2021-07-13 20:39:05 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-07-13 20:39:05 --> Final output sent to browser
DEBUG - 2021-07-13 20:39:05 --> Total execution time: 0.0360
ERROR - 2021-07-13 20:39:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-13 20:39:05 --> Config Class Initialized
INFO - 2021-07-13 20:39:05 --> Hooks Class Initialized
DEBUG - 2021-07-13 20:39:05 --> UTF-8 Support Enabled
INFO - 2021-07-13 20:39:05 --> Utf8 Class Initialized
INFO - 2021-07-13 20:39:05 --> URI Class Initialized
INFO - 2021-07-13 20:39:05 --> Router Class Initialized
INFO - 2021-07-13 20:39:05 --> Output Class Initialized
INFO - 2021-07-13 20:39:05 --> Security Class Initialized
DEBUG - 2021-07-13 20:39:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-13 20:39:05 --> Input Class Initialized
INFO - 2021-07-13 20:39:05 --> Language Class Initialized
ERROR - 2021-07-13 20:39:05 --> 404 Page Not Found: Blog/index
ERROR - 2021-07-13 20:39:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-13 20:39:05 --> Config Class Initialized
INFO - 2021-07-13 20:39:05 --> Hooks Class Initialized
DEBUG - 2021-07-13 20:39:05 --> UTF-8 Support Enabled
INFO - 2021-07-13 20:39:05 --> Utf8 Class Initialized
INFO - 2021-07-13 20:39:05 --> URI Class Initialized
INFO - 2021-07-13 20:39:05 --> Router Class Initialized
INFO - 2021-07-13 20:39:05 --> Output Class Initialized
INFO - 2021-07-13 20:39:05 --> Security Class Initialized
DEBUG - 2021-07-13 20:39:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-13 20:39:05 --> Input Class Initialized
INFO - 2021-07-13 20:39:05 --> Language Class Initialized
ERROR - 2021-07-13 20:39:05 --> 404 Page Not Found: Wp/index
ERROR - 2021-07-13 20:39:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-13 20:39:06 --> Config Class Initialized
INFO - 2021-07-13 20:39:06 --> Hooks Class Initialized
DEBUG - 2021-07-13 20:39:06 --> UTF-8 Support Enabled
INFO - 2021-07-13 20:39:06 --> Utf8 Class Initialized
INFO - 2021-07-13 20:39:06 --> URI Class Initialized
INFO - 2021-07-13 20:39:06 --> Router Class Initialized
INFO - 2021-07-13 20:39:06 --> Output Class Initialized
INFO - 2021-07-13 20:39:06 --> Security Class Initialized
DEBUG - 2021-07-13 20:39:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-13 20:39:06 --> Input Class Initialized
INFO - 2021-07-13 20:39:06 --> Language Class Initialized
ERROR - 2021-07-13 20:39:06 --> 404 Page Not Found: Wordpress/index
ERROR - 2021-07-13 20:39:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-13 20:39:06 --> Config Class Initialized
INFO - 2021-07-13 20:39:06 --> Hooks Class Initialized
DEBUG - 2021-07-13 20:39:06 --> UTF-8 Support Enabled
INFO - 2021-07-13 20:39:06 --> Utf8 Class Initialized
INFO - 2021-07-13 20:39:06 --> URI Class Initialized
INFO - 2021-07-13 20:39:06 --> Router Class Initialized
INFO - 2021-07-13 20:39:06 --> Output Class Initialized
INFO - 2021-07-13 20:39:06 --> Security Class Initialized
DEBUG - 2021-07-13 20:39:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-13 20:39:06 --> Input Class Initialized
INFO - 2021-07-13 20:39:06 --> Language Class Initialized
ERROR - 2021-07-13 20:39:06 --> 404 Page Not Found: New/index
ERROR - 2021-07-13 20:39:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-13 20:39:06 --> Config Class Initialized
INFO - 2021-07-13 20:39:06 --> Hooks Class Initialized
DEBUG - 2021-07-13 20:39:06 --> UTF-8 Support Enabled
INFO - 2021-07-13 20:39:06 --> Utf8 Class Initialized
INFO - 2021-07-13 20:39:06 --> URI Class Initialized
INFO - 2021-07-13 20:39:06 --> Router Class Initialized
INFO - 2021-07-13 20:39:06 --> Output Class Initialized
INFO - 2021-07-13 20:39:06 --> Security Class Initialized
DEBUG - 2021-07-13 20:39:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-13 20:39:06 --> Input Class Initialized
INFO - 2021-07-13 20:39:06 --> Language Class Initialized
ERROR - 2021-07-13 20:39:06 --> 404 Page Not Found: Old/index
ERROR - 2021-07-13 20:39:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-13 20:39:06 --> Config Class Initialized
INFO - 2021-07-13 20:39:06 --> Hooks Class Initialized
DEBUG - 2021-07-13 20:39:06 --> UTF-8 Support Enabled
INFO - 2021-07-13 20:39:06 --> Utf8 Class Initialized
INFO - 2021-07-13 20:39:06 --> URI Class Initialized
INFO - 2021-07-13 20:39:06 --> Router Class Initialized
INFO - 2021-07-13 20:39:06 --> Output Class Initialized
INFO - 2021-07-13 20:39:06 --> Security Class Initialized
DEBUG - 2021-07-13 20:39:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-13 20:39:06 --> Input Class Initialized
INFO - 2021-07-13 20:39:06 --> Language Class Initialized
ERROR - 2021-07-13 20:39:06 --> 404 Page Not Found: Test/index
ERROR - 2021-07-13 20:39:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-13 20:39:07 --> Config Class Initialized
INFO - 2021-07-13 20:39:07 --> Hooks Class Initialized
DEBUG - 2021-07-13 20:39:07 --> UTF-8 Support Enabled
INFO - 2021-07-13 20:39:07 --> Utf8 Class Initialized
INFO - 2021-07-13 20:39:07 --> URI Class Initialized
INFO - 2021-07-13 20:39:07 --> Router Class Initialized
INFO - 2021-07-13 20:39:07 --> Output Class Initialized
INFO - 2021-07-13 20:39:07 --> Security Class Initialized
DEBUG - 2021-07-13 20:39:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-13 20:39:07 --> Input Class Initialized
INFO - 2021-07-13 20:39:07 --> Language Class Initialized
ERROR - 2021-07-13 20:39:07 --> 404 Page Not Found: Main/index
ERROR - 2021-07-13 20:39:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-13 20:39:07 --> Config Class Initialized
INFO - 2021-07-13 20:39:07 --> Hooks Class Initialized
DEBUG - 2021-07-13 20:39:07 --> UTF-8 Support Enabled
INFO - 2021-07-13 20:39:07 --> Utf8 Class Initialized
INFO - 2021-07-13 20:39:07 --> URI Class Initialized
INFO - 2021-07-13 20:39:07 --> Router Class Initialized
INFO - 2021-07-13 20:39:07 --> Output Class Initialized
INFO - 2021-07-13 20:39:07 --> Security Class Initialized
DEBUG - 2021-07-13 20:39:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-13 20:39:07 --> Input Class Initialized
INFO - 2021-07-13 20:39:07 --> Language Class Initialized
ERROR - 2021-07-13 20:39:07 --> 404 Page Not Found: Site/index
ERROR - 2021-07-13 20:39:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-13 20:39:07 --> Config Class Initialized
INFO - 2021-07-13 20:39:07 --> Hooks Class Initialized
DEBUG - 2021-07-13 20:39:07 --> UTF-8 Support Enabled
INFO - 2021-07-13 20:39:07 --> Utf8 Class Initialized
INFO - 2021-07-13 20:39:07 --> URI Class Initialized
INFO - 2021-07-13 20:39:07 --> Router Class Initialized
INFO - 2021-07-13 20:39:07 --> Output Class Initialized
INFO - 2021-07-13 20:39:07 --> Security Class Initialized
DEBUG - 2021-07-13 20:39:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-13 20:39:07 --> Input Class Initialized
INFO - 2021-07-13 20:39:07 --> Language Class Initialized
ERROR - 2021-07-13 20:39:07 --> 404 Page Not Found: Backup/index
ERROR - 2021-07-13 20:39:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-13 20:39:08 --> Config Class Initialized
INFO - 2021-07-13 20:39:08 --> Hooks Class Initialized
DEBUG - 2021-07-13 20:39:08 --> UTF-8 Support Enabled
INFO - 2021-07-13 20:39:08 --> Utf8 Class Initialized
INFO - 2021-07-13 20:39:08 --> URI Class Initialized
INFO - 2021-07-13 20:39:08 --> Router Class Initialized
INFO - 2021-07-13 20:39:08 --> Output Class Initialized
INFO - 2021-07-13 20:39:08 --> Security Class Initialized
DEBUG - 2021-07-13 20:39:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-13 20:39:08 --> Input Class Initialized
INFO - 2021-07-13 20:39:08 --> Language Class Initialized
ERROR - 2021-07-13 20:39:08 --> 404 Page Not Found: Demo/index
ERROR - 2021-07-13 20:39:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-13 20:39:08 --> Config Class Initialized
INFO - 2021-07-13 20:39:08 --> Hooks Class Initialized
DEBUG - 2021-07-13 20:39:08 --> UTF-8 Support Enabled
INFO - 2021-07-13 20:39:08 --> Utf8 Class Initialized
INFO - 2021-07-13 20:39:08 --> URI Class Initialized
INFO - 2021-07-13 20:39:08 --> Router Class Initialized
INFO - 2021-07-13 20:39:08 --> Output Class Initialized
INFO - 2021-07-13 20:39:08 --> Security Class Initialized
DEBUG - 2021-07-13 20:39:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-13 20:39:08 --> Input Class Initialized
INFO - 2021-07-13 20:39:08 --> Language Class Initialized
ERROR - 2021-07-13 20:39:08 --> 404 Page Not Found: Home/index
ERROR - 2021-07-13 20:39:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-13 20:39:08 --> Config Class Initialized
INFO - 2021-07-13 20:39:08 --> Hooks Class Initialized
DEBUG - 2021-07-13 20:39:08 --> UTF-8 Support Enabled
INFO - 2021-07-13 20:39:08 --> Utf8 Class Initialized
INFO - 2021-07-13 20:39:08 --> URI Class Initialized
INFO - 2021-07-13 20:39:08 --> Router Class Initialized
INFO - 2021-07-13 20:39:08 --> Output Class Initialized
INFO - 2021-07-13 20:39:08 --> Security Class Initialized
DEBUG - 2021-07-13 20:39:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-13 20:39:08 --> Input Class Initialized
INFO - 2021-07-13 20:39:08 --> Language Class Initialized
ERROR - 2021-07-13 20:39:08 --> 404 Page Not Found: Tmp/index
ERROR - 2021-07-13 20:39:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-13 20:39:08 --> Config Class Initialized
INFO - 2021-07-13 20:39:08 --> Hooks Class Initialized
DEBUG - 2021-07-13 20:39:08 --> UTF-8 Support Enabled
INFO - 2021-07-13 20:39:08 --> Utf8 Class Initialized
INFO - 2021-07-13 20:39:08 --> URI Class Initialized
INFO - 2021-07-13 20:39:08 --> Router Class Initialized
INFO - 2021-07-13 20:39:08 --> Output Class Initialized
INFO - 2021-07-13 20:39:08 --> Security Class Initialized
DEBUG - 2021-07-13 20:39:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-13 20:39:08 --> Input Class Initialized
INFO - 2021-07-13 20:39:08 --> Language Class Initialized
ERROR - 2021-07-13 20:39:08 --> 404 Page Not Found: Cms/index
ERROR - 2021-07-13 20:39:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-13 20:39:09 --> Config Class Initialized
INFO - 2021-07-13 20:39:09 --> Hooks Class Initialized
DEBUG - 2021-07-13 20:39:09 --> UTF-8 Support Enabled
INFO - 2021-07-13 20:39:09 --> Utf8 Class Initialized
INFO - 2021-07-13 20:39:09 --> URI Class Initialized
INFO - 2021-07-13 20:39:09 --> Router Class Initialized
INFO - 2021-07-13 20:39:09 --> Output Class Initialized
INFO - 2021-07-13 20:39:09 --> Security Class Initialized
DEBUG - 2021-07-13 20:39:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-13 20:39:09 --> Input Class Initialized
INFO - 2021-07-13 20:39:09 --> Language Class Initialized
ERROR - 2021-07-13 20:39:09 --> 404 Page Not Found: Dev/index
ERROR - 2021-07-13 20:39:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-13 20:39:09 --> Config Class Initialized
INFO - 2021-07-13 20:39:09 --> Hooks Class Initialized
DEBUG - 2021-07-13 20:39:09 --> UTF-8 Support Enabled
INFO - 2021-07-13 20:39:09 --> Utf8 Class Initialized
INFO - 2021-07-13 20:39:09 --> URI Class Initialized
INFO - 2021-07-13 20:39:09 --> Router Class Initialized
INFO - 2021-07-13 20:39:09 --> Output Class Initialized
INFO - 2021-07-13 20:39:09 --> Security Class Initialized
DEBUG - 2021-07-13 20:39:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-13 20:39:09 --> Input Class Initialized
INFO - 2021-07-13 20:39:09 --> Language Class Initialized
ERROR - 2021-07-13 20:39:09 --> 404 Page Not Found: Old-wp/index
ERROR - 2021-07-13 20:39:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-13 20:39:09 --> Config Class Initialized
INFO - 2021-07-13 20:39:09 --> Hooks Class Initialized
DEBUG - 2021-07-13 20:39:09 --> UTF-8 Support Enabled
INFO - 2021-07-13 20:39:09 --> Utf8 Class Initialized
INFO - 2021-07-13 20:39:09 --> URI Class Initialized
INFO - 2021-07-13 20:39:09 --> Router Class Initialized
INFO - 2021-07-13 20:39:09 --> Output Class Initialized
INFO - 2021-07-13 20:39:09 --> Security Class Initialized
DEBUG - 2021-07-13 20:39:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-13 20:39:09 --> Input Class Initialized
INFO - 2021-07-13 20:39:09 --> Language Class Initialized
ERROR - 2021-07-13 20:39:09 --> 404 Page Not Found: Web/index
ERROR - 2021-07-13 20:39:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-13 20:39:10 --> Config Class Initialized
INFO - 2021-07-13 20:39:10 --> Hooks Class Initialized
DEBUG - 2021-07-13 20:39:10 --> UTF-8 Support Enabled
INFO - 2021-07-13 20:39:10 --> Utf8 Class Initialized
INFO - 2021-07-13 20:39:10 --> URI Class Initialized
INFO - 2021-07-13 20:39:10 --> Router Class Initialized
INFO - 2021-07-13 20:39:10 --> Output Class Initialized
INFO - 2021-07-13 20:39:10 --> Security Class Initialized
DEBUG - 2021-07-13 20:39:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-13 20:39:10 --> Input Class Initialized
INFO - 2021-07-13 20:39:10 --> Language Class Initialized
ERROR - 2021-07-13 20:39:10 --> 404 Page Not Found: Old-site/index
ERROR - 2021-07-13 20:39:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-13 20:39:10 --> Config Class Initialized
INFO - 2021-07-13 20:39:10 --> Hooks Class Initialized
DEBUG - 2021-07-13 20:39:10 --> UTF-8 Support Enabled
INFO - 2021-07-13 20:39:10 --> Utf8 Class Initialized
INFO - 2021-07-13 20:39:10 --> URI Class Initialized
INFO - 2021-07-13 20:39:10 --> Router Class Initialized
INFO - 2021-07-13 20:39:10 --> Output Class Initialized
INFO - 2021-07-13 20:39:10 --> Security Class Initialized
DEBUG - 2021-07-13 20:39:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-13 20:39:10 --> Input Class Initialized
INFO - 2021-07-13 20:39:10 --> Language Class Initialized
ERROR - 2021-07-13 20:39:10 --> 404 Page Not Found: Temp/index
ERROR - 2021-07-13 20:39:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-13 20:39:10 --> Config Class Initialized
INFO - 2021-07-13 20:39:10 --> Hooks Class Initialized
DEBUG - 2021-07-13 20:39:10 --> UTF-8 Support Enabled
INFO - 2021-07-13 20:39:10 --> Utf8 Class Initialized
INFO - 2021-07-13 20:39:10 --> URI Class Initialized
INFO - 2021-07-13 20:39:10 --> Router Class Initialized
INFO - 2021-07-13 20:39:10 --> Output Class Initialized
INFO - 2021-07-13 20:39:10 --> Security Class Initialized
DEBUG - 2021-07-13 20:39:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-13 20:39:10 --> Input Class Initialized
INFO - 2021-07-13 20:39:10 --> Language Class Initialized
ERROR - 2021-07-13 20:39:10 --> 404 Page Not Found: 2018/index
ERROR - 2021-07-13 20:39:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-13 20:39:11 --> Config Class Initialized
INFO - 2021-07-13 20:39:11 --> Hooks Class Initialized
DEBUG - 2021-07-13 20:39:11 --> UTF-8 Support Enabled
INFO - 2021-07-13 20:39:11 --> Utf8 Class Initialized
INFO - 2021-07-13 20:39:11 --> URI Class Initialized
INFO - 2021-07-13 20:39:11 --> Router Class Initialized
INFO - 2021-07-13 20:39:11 --> Output Class Initialized
INFO - 2021-07-13 20:39:11 --> Security Class Initialized
DEBUG - 2021-07-13 20:39:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-13 20:39:11 --> Input Class Initialized
INFO - 2021-07-13 20:39:11 --> Language Class Initialized
ERROR - 2021-07-13 20:39:11 --> 404 Page Not Found: 2019/index
ERROR - 2021-07-13 20:39:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-13 20:39:11 --> Config Class Initialized
INFO - 2021-07-13 20:39:11 --> Hooks Class Initialized
DEBUG - 2021-07-13 20:39:11 --> UTF-8 Support Enabled
INFO - 2021-07-13 20:39:11 --> Utf8 Class Initialized
INFO - 2021-07-13 20:39:11 --> URI Class Initialized
INFO - 2021-07-13 20:39:11 --> Router Class Initialized
INFO - 2021-07-13 20:39:11 --> Output Class Initialized
INFO - 2021-07-13 20:39:11 --> Security Class Initialized
DEBUG - 2021-07-13 20:39:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-13 20:39:11 --> Input Class Initialized
INFO - 2021-07-13 20:39:11 --> Language Class Initialized
ERROR - 2021-07-13 20:39:11 --> 404 Page Not Found: Bk/index
ERROR - 2021-07-13 20:39:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-13 20:39:11 --> Config Class Initialized
INFO - 2021-07-13 20:39:11 --> Hooks Class Initialized
DEBUG - 2021-07-13 20:39:11 --> UTF-8 Support Enabled
INFO - 2021-07-13 20:39:11 --> Utf8 Class Initialized
INFO - 2021-07-13 20:39:11 --> URI Class Initialized
INFO - 2021-07-13 20:39:11 --> Router Class Initialized
INFO - 2021-07-13 20:39:11 --> Output Class Initialized
INFO - 2021-07-13 20:39:11 --> Security Class Initialized
DEBUG - 2021-07-13 20:39:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-13 20:39:11 --> Input Class Initialized
INFO - 2021-07-13 20:39:11 --> Language Class Initialized
ERROR - 2021-07-13 20:39:11 --> 404 Page Not Found: Wp1/index
ERROR - 2021-07-13 20:39:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-13 20:39:11 --> Config Class Initialized
INFO - 2021-07-13 20:39:11 --> Hooks Class Initialized
DEBUG - 2021-07-13 20:39:11 --> UTF-8 Support Enabled
INFO - 2021-07-13 20:39:11 --> Utf8 Class Initialized
INFO - 2021-07-13 20:39:11 --> URI Class Initialized
INFO - 2021-07-13 20:39:11 --> Router Class Initialized
INFO - 2021-07-13 20:39:11 --> Output Class Initialized
INFO - 2021-07-13 20:39:11 --> Security Class Initialized
DEBUG - 2021-07-13 20:39:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-13 20:39:11 --> Input Class Initialized
INFO - 2021-07-13 20:39:11 --> Language Class Initialized
ERROR - 2021-07-13 20:39:11 --> 404 Page Not Found: Wp2/index
ERROR - 2021-07-13 20:39:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-13 20:39:12 --> Config Class Initialized
INFO - 2021-07-13 20:39:12 --> Hooks Class Initialized
DEBUG - 2021-07-13 20:39:12 --> UTF-8 Support Enabled
INFO - 2021-07-13 20:39:12 --> Utf8 Class Initialized
INFO - 2021-07-13 20:39:12 --> URI Class Initialized
INFO - 2021-07-13 20:39:12 --> Router Class Initialized
INFO - 2021-07-13 20:39:12 --> Output Class Initialized
INFO - 2021-07-13 20:39:12 --> Security Class Initialized
DEBUG - 2021-07-13 20:39:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-13 20:39:12 --> Input Class Initialized
INFO - 2021-07-13 20:39:12 --> Language Class Initialized
ERROR - 2021-07-13 20:39:12 --> 404 Page Not Found: V1/index
ERROR - 2021-07-13 20:39:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-13 20:39:12 --> Config Class Initialized
INFO - 2021-07-13 20:39:12 --> Hooks Class Initialized
DEBUG - 2021-07-13 20:39:12 --> UTF-8 Support Enabled
INFO - 2021-07-13 20:39:12 --> Utf8 Class Initialized
INFO - 2021-07-13 20:39:12 --> URI Class Initialized
INFO - 2021-07-13 20:39:12 --> Router Class Initialized
INFO - 2021-07-13 20:39:12 --> Output Class Initialized
INFO - 2021-07-13 20:39:12 --> Security Class Initialized
DEBUG - 2021-07-13 20:39:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-13 20:39:12 --> Input Class Initialized
INFO - 2021-07-13 20:39:12 --> Language Class Initialized
ERROR - 2021-07-13 20:39:12 --> 404 Page Not Found: V2/index
ERROR - 2021-07-13 20:39:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-13 20:39:12 --> Config Class Initialized
INFO - 2021-07-13 20:39:12 --> Hooks Class Initialized
DEBUG - 2021-07-13 20:39:12 --> UTF-8 Support Enabled
INFO - 2021-07-13 20:39:12 --> Utf8 Class Initialized
INFO - 2021-07-13 20:39:12 --> URI Class Initialized
INFO - 2021-07-13 20:39:12 --> Router Class Initialized
INFO - 2021-07-13 20:39:12 --> Output Class Initialized
INFO - 2021-07-13 20:39:12 --> Security Class Initialized
DEBUG - 2021-07-13 20:39:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-13 20:39:12 --> Input Class Initialized
INFO - 2021-07-13 20:39:12 --> Language Class Initialized
ERROR - 2021-07-13 20:39:12 --> 404 Page Not Found: Bak/index
ERROR - 2021-07-13 20:39:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-13 20:39:12 --> Config Class Initialized
INFO - 2021-07-13 20:39:12 --> Hooks Class Initialized
DEBUG - 2021-07-13 20:39:12 --> UTF-8 Support Enabled
INFO - 2021-07-13 20:39:12 --> Utf8 Class Initialized
INFO - 2021-07-13 20:39:12 --> URI Class Initialized
INFO - 2021-07-13 20:39:12 --> Router Class Initialized
INFO - 2021-07-13 20:39:12 --> Output Class Initialized
INFO - 2021-07-13 20:39:12 --> Security Class Initialized
DEBUG - 2021-07-13 20:39:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-13 20:39:12 --> Input Class Initialized
INFO - 2021-07-13 20:39:12 --> Language Class Initialized
ERROR - 2021-07-13 20:39:12 --> 404 Page Not Found: Install/index
ERROR - 2021-07-13 20:39:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-13 20:39:13 --> Config Class Initialized
INFO - 2021-07-13 20:39:13 --> Hooks Class Initialized
DEBUG - 2021-07-13 20:39:13 --> UTF-8 Support Enabled
INFO - 2021-07-13 20:39:13 --> Utf8 Class Initialized
INFO - 2021-07-13 20:39:13 --> URI Class Initialized
INFO - 2021-07-13 20:39:13 --> Router Class Initialized
INFO - 2021-07-13 20:39:13 --> Output Class Initialized
INFO - 2021-07-13 20:39:13 --> Security Class Initialized
DEBUG - 2021-07-13 20:39:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-13 20:39:13 --> Input Class Initialized
INFO - 2021-07-13 20:39:13 --> Language Class Initialized
ERROR - 2021-07-13 20:39:13 --> 404 Page Not Found: 2020/index
ERROR - 2021-07-13 20:39:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-13 20:39:13 --> Config Class Initialized
INFO - 2021-07-13 20:39:13 --> Hooks Class Initialized
DEBUG - 2021-07-13 20:39:13 --> UTF-8 Support Enabled
INFO - 2021-07-13 20:39:13 --> Utf8 Class Initialized
INFO - 2021-07-13 20:39:13 --> URI Class Initialized
INFO - 2021-07-13 20:39:13 --> Router Class Initialized
INFO - 2021-07-13 20:39:13 --> Output Class Initialized
INFO - 2021-07-13 20:39:13 --> Security Class Initialized
DEBUG - 2021-07-13 20:39:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-13 20:39:13 --> Input Class Initialized
INFO - 2021-07-13 20:39:13 --> Language Class Initialized
ERROR - 2021-07-13 20:39:13 --> 404 Page Not Found: New-site/index
