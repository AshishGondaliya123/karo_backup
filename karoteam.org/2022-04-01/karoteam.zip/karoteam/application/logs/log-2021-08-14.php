<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-08-14 00:36:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-14 00:36:08 --> Config Class Initialized
INFO - 2021-08-14 00:36:08 --> Hooks Class Initialized
DEBUG - 2021-08-14 00:36:08 --> UTF-8 Support Enabled
INFO - 2021-08-14 00:36:08 --> Utf8 Class Initialized
INFO - 2021-08-14 00:36:08 --> URI Class Initialized
DEBUG - 2021-08-14 00:36:08 --> No URI present. Default controller set.
INFO - 2021-08-14 00:36:08 --> Router Class Initialized
INFO - 2021-08-14 00:36:08 --> Output Class Initialized
INFO - 2021-08-14 00:36:08 --> Security Class Initialized
DEBUG - 2021-08-14 00:36:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-14 00:36:08 --> Input Class Initialized
INFO - 2021-08-14 00:36:08 --> Language Class Initialized
INFO - 2021-08-14 00:36:08 --> Loader Class Initialized
INFO - 2021-08-14 00:36:08 --> Helper loaded: url_helper
INFO - 2021-08-14 00:36:08 --> Helper loaded: form_helper
INFO - 2021-08-14 00:36:08 --> Helper loaded: common_helper
INFO - 2021-08-14 00:36:08 --> Database Driver Class Initialized
DEBUG - 2021-08-14 00:36:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-14 00:36:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-14 00:36:08 --> Controller Class Initialized
INFO - 2021-08-14 00:36:08 --> Form Validation Class Initialized
DEBUG - 2021-08-14 00:36:08 --> Encrypt Class Initialized
DEBUG - 2021-08-14 00:36:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-08-14 00:36:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-08-14 00:36:08 --> Email Class Initialized
INFO - 2021-08-14 00:36:08 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-08-14 00:36:08 --> Calendar Class Initialized
INFO - 2021-08-14 00:36:08 --> Model "Login_model" initialized
INFO - 2021-08-14 00:36:08 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-08-14 00:36:08 --> Final output sent to browser
DEBUG - 2021-08-14 00:36:08 --> Total execution time: 0.0571
ERROR - 2021-08-14 05:47:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-14 05:47:42 --> Config Class Initialized
INFO - 2021-08-14 05:47:42 --> Hooks Class Initialized
DEBUG - 2021-08-14 05:47:42 --> UTF-8 Support Enabled
INFO - 2021-08-14 05:47:42 --> Utf8 Class Initialized
INFO - 2021-08-14 05:47:42 --> URI Class Initialized
DEBUG - 2021-08-14 05:47:42 --> No URI present. Default controller set.
INFO - 2021-08-14 05:47:42 --> Router Class Initialized
INFO - 2021-08-14 05:47:42 --> Output Class Initialized
INFO - 2021-08-14 05:47:42 --> Security Class Initialized
DEBUG - 2021-08-14 05:47:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-14 05:47:42 --> Input Class Initialized
INFO - 2021-08-14 05:47:42 --> Language Class Initialized
INFO - 2021-08-14 05:47:42 --> Loader Class Initialized
INFO - 2021-08-14 05:47:42 --> Helper loaded: url_helper
INFO - 2021-08-14 05:47:42 --> Helper loaded: form_helper
INFO - 2021-08-14 05:47:42 --> Helper loaded: common_helper
INFO - 2021-08-14 05:47:42 --> Database Driver Class Initialized
DEBUG - 2021-08-14 05:47:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-14 05:47:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-14 05:47:42 --> Controller Class Initialized
INFO - 2021-08-14 05:47:42 --> Form Validation Class Initialized
DEBUG - 2021-08-14 05:47:42 --> Encrypt Class Initialized
DEBUG - 2021-08-14 05:47:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-08-14 05:47:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-08-14 05:47:42 --> Email Class Initialized
INFO - 2021-08-14 05:47:42 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-08-14 05:47:42 --> Calendar Class Initialized
INFO - 2021-08-14 05:47:42 --> Model "Login_model" initialized
INFO - 2021-08-14 05:47:42 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-08-14 05:47:42 --> Final output sent to browser
DEBUG - 2021-08-14 05:47:42 --> Total execution time: 0.0484
