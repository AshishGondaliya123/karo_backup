<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-09-13 03:29:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-13 03:29:39 --> Config Class Initialized
INFO - 2021-09-13 03:29:39 --> Hooks Class Initialized
DEBUG - 2021-09-13 03:29:39 --> UTF-8 Support Enabled
INFO - 2021-09-13 03:29:39 --> Utf8 Class Initialized
INFO - 2021-09-13 03:29:39 --> URI Class Initialized
DEBUG - 2021-09-13 03:29:39 --> No URI present. Default controller set.
INFO - 2021-09-13 03:29:39 --> Router Class Initialized
INFO - 2021-09-13 03:29:39 --> Output Class Initialized
INFO - 2021-09-13 03:29:39 --> Security Class Initialized
DEBUG - 2021-09-13 03:29:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-13 03:29:39 --> Input Class Initialized
INFO - 2021-09-13 03:29:39 --> Language Class Initialized
INFO - 2021-09-13 03:29:39 --> Loader Class Initialized
INFO - 2021-09-13 03:29:39 --> Helper loaded: url_helper
INFO - 2021-09-13 03:29:39 --> Helper loaded: form_helper
INFO - 2021-09-13 03:29:39 --> Helper loaded: common_helper
INFO - 2021-09-13 03:29:39 --> Database Driver Class Initialized
DEBUG - 2021-09-13 03:29:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-13 03:29:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-13 03:29:39 --> Controller Class Initialized
INFO - 2021-09-13 03:29:39 --> Form Validation Class Initialized
DEBUG - 2021-09-13 03:29:39 --> Encrypt Class Initialized
DEBUG - 2021-09-13 03:29:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-09-13 03:29:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-09-13 03:29:39 --> Email Class Initialized
INFO - 2021-09-13 03:29:39 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-09-13 03:29:39 --> Calendar Class Initialized
INFO - 2021-09-13 03:29:39 --> Model "Login_model" initialized
INFO - 2021-09-13 03:29:39 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-09-13 03:29:39 --> Final output sent to browser
DEBUG - 2021-09-13 03:29:39 --> Total execution time: 0.0708
ERROR - 2021-09-13 03:29:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-13 03:29:39 --> Config Class Initialized
INFO - 2021-09-13 03:29:39 --> Hooks Class Initialized
DEBUG - 2021-09-13 03:29:39 --> UTF-8 Support Enabled
INFO - 2021-09-13 03:29:39 --> Utf8 Class Initialized
INFO - 2021-09-13 03:29:39 --> URI Class Initialized
INFO - 2021-09-13 03:29:39 --> Router Class Initialized
INFO - 2021-09-13 03:29:39 --> Output Class Initialized
INFO - 2021-09-13 03:29:39 --> Security Class Initialized
DEBUG - 2021-09-13 03:29:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-13 03:29:40 --> Input Class Initialized
INFO - 2021-09-13 03:29:40 --> Language Class Initialized
ERROR - 2021-09-13 03:29:40 --> 404 Page Not Found: Blog/index
ERROR - 2021-09-13 03:29:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-13 03:29:40 --> Config Class Initialized
INFO - 2021-09-13 03:29:40 --> Hooks Class Initialized
DEBUG - 2021-09-13 03:29:40 --> UTF-8 Support Enabled
INFO - 2021-09-13 03:29:40 --> Utf8 Class Initialized
INFO - 2021-09-13 03:29:40 --> URI Class Initialized
INFO - 2021-09-13 03:29:40 --> Router Class Initialized
INFO - 2021-09-13 03:29:40 --> Output Class Initialized
INFO - 2021-09-13 03:29:40 --> Security Class Initialized
DEBUG - 2021-09-13 03:29:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-13 03:29:40 --> Input Class Initialized
INFO - 2021-09-13 03:29:40 --> Language Class Initialized
ERROR - 2021-09-13 03:29:40 --> 404 Page Not Found: Wp/index
ERROR - 2021-09-13 03:29:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-13 03:29:40 --> Config Class Initialized
INFO - 2021-09-13 03:29:40 --> Hooks Class Initialized
DEBUG - 2021-09-13 03:29:40 --> UTF-8 Support Enabled
INFO - 2021-09-13 03:29:40 --> Utf8 Class Initialized
INFO - 2021-09-13 03:29:40 --> URI Class Initialized
INFO - 2021-09-13 03:29:40 --> Router Class Initialized
INFO - 2021-09-13 03:29:40 --> Output Class Initialized
INFO - 2021-09-13 03:29:40 --> Security Class Initialized
DEBUG - 2021-09-13 03:29:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-13 03:29:40 --> Input Class Initialized
INFO - 2021-09-13 03:29:40 --> Language Class Initialized
ERROR - 2021-09-13 03:29:40 --> 404 Page Not Found: Wordpress/index
ERROR - 2021-09-13 03:29:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-13 03:29:40 --> Config Class Initialized
INFO - 2021-09-13 03:29:40 --> Hooks Class Initialized
DEBUG - 2021-09-13 03:29:40 --> UTF-8 Support Enabled
INFO - 2021-09-13 03:29:40 --> Utf8 Class Initialized
INFO - 2021-09-13 03:29:40 --> URI Class Initialized
INFO - 2021-09-13 03:29:40 --> Router Class Initialized
INFO - 2021-09-13 03:29:40 --> Output Class Initialized
INFO - 2021-09-13 03:29:40 --> Security Class Initialized
DEBUG - 2021-09-13 03:29:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-13 03:29:40 --> Input Class Initialized
INFO - 2021-09-13 03:29:40 --> Language Class Initialized
ERROR - 2021-09-13 03:29:40 --> 404 Page Not Found: New/index
ERROR - 2021-09-13 03:29:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-13 03:29:41 --> Config Class Initialized
INFO - 2021-09-13 03:29:41 --> Hooks Class Initialized
DEBUG - 2021-09-13 03:29:41 --> UTF-8 Support Enabled
INFO - 2021-09-13 03:29:41 --> Utf8 Class Initialized
INFO - 2021-09-13 03:29:41 --> URI Class Initialized
INFO - 2021-09-13 03:29:41 --> Router Class Initialized
INFO - 2021-09-13 03:29:41 --> Output Class Initialized
INFO - 2021-09-13 03:29:41 --> Security Class Initialized
DEBUG - 2021-09-13 03:29:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-13 03:29:41 --> Input Class Initialized
INFO - 2021-09-13 03:29:41 --> Language Class Initialized
ERROR - 2021-09-13 03:29:41 --> 404 Page Not Found: Old/index
ERROR - 2021-09-13 03:29:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-13 03:29:41 --> Config Class Initialized
INFO - 2021-09-13 03:29:41 --> Hooks Class Initialized
DEBUG - 2021-09-13 03:29:41 --> UTF-8 Support Enabled
INFO - 2021-09-13 03:29:41 --> Utf8 Class Initialized
INFO - 2021-09-13 03:29:41 --> URI Class Initialized
INFO - 2021-09-13 03:29:41 --> Router Class Initialized
INFO - 2021-09-13 03:29:41 --> Output Class Initialized
INFO - 2021-09-13 03:29:41 --> Security Class Initialized
DEBUG - 2021-09-13 03:29:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-13 03:29:41 --> Input Class Initialized
INFO - 2021-09-13 03:29:41 --> Language Class Initialized
ERROR - 2021-09-13 03:29:41 --> 404 Page Not Found: Test/index
ERROR - 2021-09-13 03:29:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-13 03:29:41 --> Config Class Initialized
INFO - 2021-09-13 03:29:41 --> Hooks Class Initialized
DEBUG - 2021-09-13 03:29:41 --> UTF-8 Support Enabled
INFO - 2021-09-13 03:29:41 --> Utf8 Class Initialized
INFO - 2021-09-13 03:29:41 --> URI Class Initialized
INFO - 2021-09-13 03:29:41 --> Router Class Initialized
INFO - 2021-09-13 03:29:41 --> Output Class Initialized
INFO - 2021-09-13 03:29:41 --> Security Class Initialized
DEBUG - 2021-09-13 03:29:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-13 03:29:41 --> Input Class Initialized
INFO - 2021-09-13 03:29:41 --> Language Class Initialized
ERROR - 2021-09-13 03:29:41 --> 404 Page Not Found: Main/index
ERROR - 2021-09-13 03:29:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-13 03:29:42 --> Config Class Initialized
INFO - 2021-09-13 03:29:42 --> Hooks Class Initialized
DEBUG - 2021-09-13 03:29:42 --> UTF-8 Support Enabled
INFO - 2021-09-13 03:29:42 --> Utf8 Class Initialized
INFO - 2021-09-13 03:29:42 --> URI Class Initialized
INFO - 2021-09-13 03:29:42 --> Router Class Initialized
INFO - 2021-09-13 03:29:42 --> Output Class Initialized
INFO - 2021-09-13 03:29:42 --> Security Class Initialized
DEBUG - 2021-09-13 03:29:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-13 03:29:42 --> Input Class Initialized
INFO - 2021-09-13 03:29:42 --> Language Class Initialized
ERROR - 2021-09-13 03:29:42 --> 404 Page Not Found: Site/index
ERROR - 2021-09-13 03:29:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-13 03:29:43 --> Config Class Initialized
INFO - 2021-09-13 03:29:43 --> Hooks Class Initialized
DEBUG - 2021-09-13 03:29:43 --> UTF-8 Support Enabled
INFO - 2021-09-13 03:29:43 --> Utf8 Class Initialized
INFO - 2021-09-13 03:29:43 --> URI Class Initialized
INFO - 2021-09-13 03:29:43 --> Router Class Initialized
INFO - 2021-09-13 03:29:43 --> Output Class Initialized
INFO - 2021-09-13 03:29:43 --> Security Class Initialized
DEBUG - 2021-09-13 03:29:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-13 03:29:43 --> Input Class Initialized
INFO - 2021-09-13 03:29:43 --> Language Class Initialized
ERROR - 2021-09-13 03:29:43 --> 404 Page Not Found: Backup/index
ERROR - 2021-09-13 03:29:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-13 03:29:43 --> Config Class Initialized
INFO - 2021-09-13 03:29:43 --> Hooks Class Initialized
DEBUG - 2021-09-13 03:29:43 --> UTF-8 Support Enabled
INFO - 2021-09-13 03:29:43 --> Utf8 Class Initialized
INFO - 2021-09-13 03:29:43 --> URI Class Initialized
INFO - 2021-09-13 03:29:43 --> Router Class Initialized
INFO - 2021-09-13 03:29:43 --> Output Class Initialized
INFO - 2021-09-13 03:29:43 --> Security Class Initialized
DEBUG - 2021-09-13 03:29:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-13 03:29:43 --> Input Class Initialized
INFO - 2021-09-13 03:29:43 --> Language Class Initialized
ERROR - 2021-09-13 03:29:43 --> 404 Page Not Found: Demo/index
ERROR - 2021-09-13 15:56:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-13 15:56:59 --> Config Class Initialized
INFO - 2021-09-13 15:56:59 --> Hooks Class Initialized
DEBUG - 2021-09-13 15:56:59 --> UTF-8 Support Enabled
INFO - 2021-09-13 15:56:59 --> Utf8 Class Initialized
INFO - 2021-09-13 15:56:59 --> URI Class Initialized
DEBUG - 2021-09-13 15:56:59 --> No URI present. Default controller set.
INFO - 2021-09-13 15:56:59 --> Router Class Initialized
INFO - 2021-09-13 15:56:59 --> Output Class Initialized
INFO - 2021-09-13 15:56:59 --> Security Class Initialized
DEBUG - 2021-09-13 15:56:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-13 15:56:59 --> Input Class Initialized
INFO - 2021-09-13 15:56:59 --> Language Class Initialized
INFO - 2021-09-13 15:56:59 --> Loader Class Initialized
INFO - 2021-09-13 15:56:59 --> Helper loaded: url_helper
INFO - 2021-09-13 15:56:59 --> Helper loaded: form_helper
INFO - 2021-09-13 15:56:59 --> Helper loaded: common_helper
INFO - 2021-09-13 15:56:59 --> Database Driver Class Initialized
DEBUG - 2021-09-13 15:56:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-13 15:56:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-13 15:56:59 --> Controller Class Initialized
INFO - 2021-09-13 15:56:59 --> Form Validation Class Initialized
DEBUG - 2021-09-13 15:56:59 --> Encrypt Class Initialized
DEBUG - 2021-09-13 15:56:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-09-13 15:56:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-09-13 15:56:59 --> Email Class Initialized
INFO - 2021-09-13 15:56:59 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-09-13 15:56:59 --> Calendar Class Initialized
INFO - 2021-09-13 15:56:59 --> Model "Login_model" initialized
INFO - 2021-09-13 15:56:59 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-09-13 15:56:59 --> Final output sent to browser
DEBUG - 2021-09-13 15:56:59 --> Total execution time: 0.0427
ERROR - 2021-09-13 15:56:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-13 15:56:59 --> Config Class Initialized
INFO - 2021-09-13 15:56:59 --> Hooks Class Initialized
DEBUG - 2021-09-13 15:56:59 --> UTF-8 Support Enabled
INFO - 2021-09-13 15:56:59 --> Utf8 Class Initialized
INFO - 2021-09-13 15:56:59 --> URI Class Initialized
DEBUG - 2021-09-13 15:56:59 --> No URI present. Default controller set.
INFO - 2021-09-13 15:56:59 --> Router Class Initialized
INFO - 2021-09-13 15:56:59 --> Output Class Initialized
INFO - 2021-09-13 15:56:59 --> Security Class Initialized
DEBUG - 2021-09-13 15:56:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-13 15:56:59 --> Input Class Initialized
INFO - 2021-09-13 15:56:59 --> Language Class Initialized
INFO - 2021-09-13 15:56:59 --> Loader Class Initialized
INFO - 2021-09-13 15:56:59 --> Helper loaded: url_helper
INFO - 2021-09-13 15:56:59 --> Helper loaded: form_helper
INFO - 2021-09-13 15:56:59 --> Helper loaded: common_helper
INFO - 2021-09-13 15:56:59 --> Database Driver Class Initialized
DEBUG - 2021-09-13 15:56:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-13 15:56:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-13 15:56:59 --> Controller Class Initialized
INFO - 2021-09-13 15:56:59 --> Form Validation Class Initialized
DEBUG - 2021-09-13 15:56:59 --> Encrypt Class Initialized
DEBUG - 2021-09-13 15:56:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-09-13 15:56:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-09-13 15:56:59 --> Email Class Initialized
INFO - 2021-09-13 15:56:59 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-09-13 15:56:59 --> Calendar Class Initialized
INFO - 2021-09-13 15:56:59 --> Model "Login_model" initialized
INFO - 2021-09-13 15:56:59 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-09-13 15:56:59 --> Final output sent to browser
DEBUG - 2021-09-13 15:56:59 --> Total execution time: 0.0216
ERROR - 2021-09-13 15:57:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-13 15:57:00 --> Config Class Initialized
INFO - 2021-09-13 15:57:00 --> Hooks Class Initialized
DEBUG - 2021-09-13 15:57:00 --> UTF-8 Support Enabled
INFO - 2021-09-13 15:57:00 --> Utf8 Class Initialized
INFO - 2021-09-13 15:57:00 --> URI Class Initialized
INFO - 2021-09-13 15:57:00 --> Router Class Initialized
INFO - 2021-09-13 15:57:00 --> Output Class Initialized
INFO - 2021-09-13 15:57:00 --> Security Class Initialized
DEBUG - 2021-09-13 15:57:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-13 15:57:00 --> Input Class Initialized
INFO - 2021-09-13 15:57:00 --> Language Class Initialized
ERROR - 2021-09-13 15:57:00 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
ERROR - 2021-09-13 15:57:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-13 15:57:01 --> Config Class Initialized
INFO - 2021-09-13 15:57:01 --> Hooks Class Initialized
DEBUG - 2021-09-13 15:57:01 --> UTF-8 Support Enabled
INFO - 2021-09-13 15:57:01 --> Utf8 Class Initialized
INFO - 2021-09-13 15:57:01 --> URI Class Initialized
DEBUG - 2021-09-13 15:57:01 --> No URI present. Default controller set.
INFO - 2021-09-13 15:57:01 --> Router Class Initialized
INFO - 2021-09-13 15:57:01 --> Output Class Initialized
INFO - 2021-09-13 15:57:01 --> Security Class Initialized
DEBUG - 2021-09-13 15:57:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-13 15:57:01 --> Input Class Initialized
INFO - 2021-09-13 15:57:01 --> Language Class Initialized
INFO - 2021-09-13 15:57:01 --> Loader Class Initialized
INFO - 2021-09-13 15:57:01 --> Helper loaded: url_helper
INFO - 2021-09-13 15:57:01 --> Helper loaded: form_helper
INFO - 2021-09-13 15:57:01 --> Helper loaded: common_helper
INFO - 2021-09-13 15:57:01 --> Database Driver Class Initialized
DEBUG - 2021-09-13 15:57:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-13 15:57:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-13 15:57:01 --> Controller Class Initialized
INFO - 2021-09-13 15:57:01 --> Form Validation Class Initialized
DEBUG - 2021-09-13 15:57:01 --> Encrypt Class Initialized
DEBUG - 2021-09-13 15:57:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-09-13 15:57:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-09-13 15:57:01 --> Email Class Initialized
INFO - 2021-09-13 15:57:01 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-09-13 15:57:01 --> Calendar Class Initialized
INFO - 2021-09-13 15:57:01 --> Model "Login_model" initialized
INFO - 2021-09-13 15:57:01 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-09-13 15:57:01 --> Final output sent to browser
DEBUG - 2021-09-13 15:57:01 --> Total execution time: 0.0209
ERROR - 2021-09-13 15:57:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-13 15:57:01 --> Config Class Initialized
INFO - 2021-09-13 15:57:01 --> Hooks Class Initialized
DEBUG - 2021-09-13 15:57:01 --> UTF-8 Support Enabled
INFO - 2021-09-13 15:57:01 --> Utf8 Class Initialized
INFO - 2021-09-13 15:57:01 --> URI Class Initialized
INFO - 2021-09-13 15:57:01 --> Router Class Initialized
INFO - 2021-09-13 15:57:01 --> Output Class Initialized
INFO - 2021-09-13 15:57:01 --> Security Class Initialized
DEBUG - 2021-09-13 15:57:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-13 15:57:01 --> Input Class Initialized
INFO - 2021-09-13 15:57:01 --> Language Class Initialized
ERROR - 2021-09-13 15:57:01 --> 404 Page Not Found: Blog/wp-includes
ERROR - 2021-09-13 15:57:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-13 15:57:02 --> Config Class Initialized
INFO - 2021-09-13 15:57:02 --> Hooks Class Initialized
DEBUG - 2021-09-13 15:57:02 --> UTF-8 Support Enabled
INFO - 2021-09-13 15:57:02 --> Utf8 Class Initialized
INFO - 2021-09-13 15:57:02 --> URI Class Initialized
INFO - 2021-09-13 15:57:02 --> Router Class Initialized
INFO - 2021-09-13 15:57:02 --> Output Class Initialized
INFO - 2021-09-13 15:57:02 --> Security Class Initialized
DEBUG - 2021-09-13 15:57:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-13 15:57:02 --> Input Class Initialized
INFO - 2021-09-13 15:57:02 --> Language Class Initialized
ERROR - 2021-09-13 15:57:02 --> 404 Page Not Found: Web/wp-includes
ERROR - 2021-09-13 15:57:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-13 15:57:02 --> Config Class Initialized
INFO - 2021-09-13 15:57:02 --> Hooks Class Initialized
DEBUG - 2021-09-13 15:57:02 --> UTF-8 Support Enabled
INFO - 2021-09-13 15:57:02 --> Utf8 Class Initialized
INFO - 2021-09-13 15:57:02 --> URI Class Initialized
INFO - 2021-09-13 15:57:02 --> Router Class Initialized
INFO - 2021-09-13 15:57:02 --> Output Class Initialized
INFO - 2021-09-13 15:57:02 --> Security Class Initialized
DEBUG - 2021-09-13 15:57:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-13 15:57:02 --> Input Class Initialized
INFO - 2021-09-13 15:57:02 --> Language Class Initialized
ERROR - 2021-09-13 15:57:02 --> 404 Page Not Found: Wordpress/wp-includes
ERROR - 2021-09-13 15:57:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-13 15:57:03 --> Config Class Initialized
INFO - 2021-09-13 15:57:03 --> Hooks Class Initialized
DEBUG - 2021-09-13 15:57:03 --> UTF-8 Support Enabled
INFO - 2021-09-13 15:57:03 --> Utf8 Class Initialized
INFO - 2021-09-13 15:57:03 --> URI Class Initialized
INFO - 2021-09-13 15:57:03 --> Router Class Initialized
INFO - 2021-09-13 15:57:03 --> Output Class Initialized
INFO - 2021-09-13 15:57:03 --> Security Class Initialized
DEBUG - 2021-09-13 15:57:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-13 15:57:03 --> Input Class Initialized
INFO - 2021-09-13 15:57:03 --> Language Class Initialized
ERROR - 2021-09-13 15:57:03 --> 404 Page Not Found: Website/wp-includes
ERROR - 2021-09-13 15:57:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-13 15:57:03 --> Config Class Initialized
INFO - 2021-09-13 15:57:03 --> Hooks Class Initialized
DEBUG - 2021-09-13 15:57:03 --> UTF-8 Support Enabled
INFO - 2021-09-13 15:57:03 --> Utf8 Class Initialized
INFO - 2021-09-13 15:57:03 --> URI Class Initialized
INFO - 2021-09-13 15:57:03 --> Router Class Initialized
INFO - 2021-09-13 15:57:03 --> Output Class Initialized
INFO - 2021-09-13 15:57:03 --> Security Class Initialized
DEBUG - 2021-09-13 15:57:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-13 15:57:03 --> Input Class Initialized
INFO - 2021-09-13 15:57:03 --> Language Class Initialized
ERROR - 2021-09-13 15:57:03 --> 404 Page Not Found: Wp/wp-includes
ERROR - 2021-09-13 15:57:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-13 15:57:04 --> Config Class Initialized
INFO - 2021-09-13 15:57:04 --> Hooks Class Initialized
DEBUG - 2021-09-13 15:57:04 --> UTF-8 Support Enabled
INFO - 2021-09-13 15:57:04 --> Utf8 Class Initialized
INFO - 2021-09-13 15:57:04 --> URI Class Initialized
INFO - 2021-09-13 15:57:04 --> Router Class Initialized
INFO - 2021-09-13 15:57:04 --> Output Class Initialized
INFO - 2021-09-13 15:57:04 --> Security Class Initialized
DEBUG - 2021-09-13 15:57:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-13 15:57:04 --> Input Class Initialized
INFO - 2021-09-13 15:57:04 --> Language Class Initialized
ERROR - 2021-09-13 15:57:04 --> 404 Page Not Found: News/wp-includes
ERROR - 2021-09-13 15:57:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-13 15:57:04 --> Config Class Initialized
INFO - 2021-09-13 15:57:04 --> Hooks Class Initialized
DEBUG - 2021-09-13 15:57:04 --> UTF-8 Support Enabled
INFO - 2021-09-13 15:57:04 --> Utf8 Class Initialized
INFO - 2021-09-13 15:57:04 --> URI Class Initialized
INFO - 2021-09-13 15:57:04 --> Router Class Initialized
INFO - 2021-09-13 15:57:04 --> Output Class Initialized
INFO - 2021-09-13 15:57:04 --> Security Class Initialized
DEBUG - 2021-09-13 15:57:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-13 15:57:04 --> Input Class Initialized
INFO - 2021-09-13 15:57:04 --> Language Class Initialized
ERROR - 2021-09-13 15:57:04 --> 404 Page Not Found: 2020/wp-includes
ERROR - 2021-09-13 15:57:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-13 15:57:05 --> Config Class Initialized
INFO - 2021-09-13 15:57:05 --> Hooks Class Initialized
DEBUG - 2021-09-13 15:57:05 --> UTF-8 Support Enabled
INFO - 2021-09-13 15:57:05 --> Utf8 Class Initialized
INFO - 2021-09-13 15:57:05 --> URI Class Initialized
INFO - 2021-09-13 15:57:05 --> Router Class Initialized
INFO - 2021-09-13 15:57:05 --> Output Class Initialized
INFO - 2021-09-13 15:57:05 --> Security Class Initialized
DEBUG - 2021-09-13 15:57:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-13 15:57:05 --> Input Class Initialized
INFO - 2021-09-13 15:57:05 --> Language Class Initialized
ERROR - 2021-09-13 15:57:05 --> 404 Page Not Found: 2019/wp-includes
ERROR - 2021-09-13 15:57:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-13 15:57:05 --> Config Class Initialized
INFO - 2021-09-13 15:57:05 --> Hooks Class Initialized
DEBUG - 2021-09-13 15:57:05 --> UTF-8 Support Enabled
INFO - 2021-09-13 15:57:05 --> Utf8 Class Initialized
INFO - 2021-09-13 15:57:05 --> URI Class Initialized
INFO - 2021-09-13 15:57:05 --> Router Class Initialized
INFO - 2021-09-13 15:57:05 --> Output Class Initialized
INFO - 2021-09-13 15:57:05 --> Security Class Initialized
DEBUG - 2021-09-13 15:57:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-13 15:57:05 --> Input Class Initialized
INFO - 2021-09-13 15:57:05 --> Language Class Initialized
ERROR - 2021-09-13 15:57:05 --> 404 Page Not Found: Shop/wp-includes
ERROR - 2021-09-13 15:57:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-13 15:57:06 --> Config Class Initialized
INFO - 2021-09-13 15:57:06 --> Hooks Class Initialized
DEBUG - 2021-09-13 15:57:06 --> UTF-8 Support Enabled
INFO - 2021-09-13 15:57:06 --> Utf8 Class Initialized
INFO - 2021-09-13 15:57:06 --> URI Class Initialized
INFO - 2021-09-13 15:57:06 --> Router Class Initialized
INFO - 2021-09-13 15:57:06 --> Output Class Initialized
INFO - 2021-09-13 15:57:06 --> Security Class Initialized
DEBUG - 2021-09-13 15:57:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-13 15:57:06 --> Input Class Initialized
INFO - 2021-09-13 15:57:06 --> Language Class Initialized
ERROR - 2021-09-13 15:57:06 --> 404 Page Not Found: Wp1/wp-includes
ERROR - 2021-09-13 15:57:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-13 15:57:06 --> Config Class Initialized
INFO - 2021-09-13 15:57:06 --> Hooks Class Initialized
DEBUG - 2021-09-13 15:57:06 --> UTF-8 Support Enabled
INFO - 2021-09-13 15:57:06 --> Utf8 Class Initialized
INFO - 2021-09-13 15:57:06 --> URI Class Initialized
INFO - 2021-09-13 15:57:06 --> Router Class Initialized
INFO - 2021-09-13 15:57:06 --> Output Class Initialized
INFO - 2021-09-13 15:57:06 --> Security Class Initialized
DEBUG - 2021-09-13 15:57:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-13 15:57:06 --> Input Class Initialized
INFO - 2021-09-13 15:57:06 --> Language Class Initialized
ERROR - 2021-09-13 15:57:06 --> 404 Page Not Found: Test/wp-includes
ERROR - 2021-09-13 15:57:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-13 15:57:07 --> Config Class Initialized
INFO - 2021-09-13 15:57:07 --> Hooks Class Initialized
DEBUG - 2021-09-13 15:57:07 --> UTF-8 Support Enabled
INFO - 2021-09-13 15:57:07 --> Utf8 Class Initialized
INFO - 2021-09-13 15:57:07 --> URI Class Initialized
INFO - 2021-09-13 15:57:07 --> Router Class Initialized
INFO - 2021-09-13 15:57:07 --> Output Class Initialized
INFO - 2021-09-13 15:57:07 --> Security Class Initialized
DEBUG - 2021-09-13 15:57:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-13 15:57:07 --> Input Class Initialized
INFO - 2021-09-13 15:57:07 --> Language Class Initialized
ERROR - 2021-09-13 15:57:07 --> 404 Page Not Found: Wp2/wp-includes
ERROR - 2021-09-13 15:57:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-13 15:57:07 --> Config Class Initialized
INFO - 2021-09-13 15:57:07 --> Hooks Class Initialized
DEBUG - 2021-09-13 15:57:07 --> UTF-8 Support Enabled
INFO - 2021-09-13 15:57:07 --> Utf8 Class Initialized
INFO - 2021-09-13 15:57:07 --> URI Class Initialized
INFO - 2021-09-13 15:57:07 --> Router Class Initialized
INFO - 2021-09-13 15:57:07 --> Output Class Initialized
INFO - 2021-09-13 15:57:07 --> Security Class Initialized
DEBUG - 2021-09-13 15:57:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-13 15:57:07 --> Input Class Initialized
INFO - 2021-09-13 15:57:07 --> Language Class Initialized
ERROR - 2021-09-13 15:57:07 --> 404 Page Not Found: Site/wp-includes
ERROR - 2021-09-13 15:57:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-13 15:57:08 --> Config Class Initialized
INFO - 2021-09-13 15:57:08 --> Hooks Class Initialized
DEBUG - 2021-09-13 15:57:08 --> UTF-8 Support Enabled
INFO - 2021-09-13 15:57:08 --> Utf8 Class Initialized
INFO - 2021-09-13 15:57:08 --> URI Class Initialized
INFO - 2021-09-13 15:57:08 --> Router Class Initialized
INFO - 2021-09-13 15:57:08 --> Output Class Initialized
INFO - 2021-09-13 15:57:08 --> Security Class Initialized
DEBUG - 2021-09-13 15:57:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-13 15:57:08 --> Input Class Initialized
INFO - 2021-09-13 15:57:08 --> Language Class Initialized
ERROR - 2021-09-13 15:57:08 --> 404 Page Not Found: Cms/wp-includes
ERROR - 2021-09-13 15:57:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-13 15:57:08 --> Config Class Initialized
INFO - 2021-09-13 15:57:08 --> Hooks Class Initialized
DEBUG - 2021-09-13 15:57:08 --> UTF-8 Support Enabled
INFO - 2021-09-13 15:57:08 --> Utf8 Class Initialized
INFO - 2021-09-13 15:57:08 --> URI Class Initialized
INFO - 2021-09-13 15:57:08 --> Router Class Initialized
INFO - 2021-09-13 15:57:08 --> Output Class Initialized
INFO - 2021-09-13 15:57:08 --> Security Class Initialized
DEBUG - 2021-09-13 15:57:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-13 15:57:08 --> Input Class Initialized
INFO - 2021-09-13 15:57:08 --> Language Class Initialized
ERROR - 2021-09-13 15:57:08 --> 404 Page Not Found: Sito/wp-includes
