<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-10-18 03:52:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-18 03:52:50 --> Config Class Initialized
INFO - 2021-10-18 03:52:50 --> Hooks Class Initialized
DEBUG - 2021-10-18 03:52:50 --> UTF-8 Support Enabled
INFO - 2021-10-18 03:52:50 --> Utf8 Class Initialized
INFO - 2021-10-18 03:52:50 --> URI Class Initialized
INFO - 2021-10-18 03:52:50 --> Router Class Initialized
INFO - 2021-10-18 03:52:50 --> Output Class Initialized
INFO - 2021-10-18 03:52:50 --> Security Class Initialized
DEBUG - 2021-10-18 03:52:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-18 03:52:50 --> Input Class Initialized
INFO - 2021-10-18 03:52:50 --> Language Class Initialized
ERROR - 2021-10-18 03:52:50 --> 404 Page Not Found: Wp-admin/install.php
ERROR - 2021-10-18 12:25:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-18 12:25:31 --> Config Class Initialized
INFO - 2021-10-18 12:25:31 --> Hooks Class Initialized
DEBUG - 2021-10-18 12:25:31 --> UTF-8 Support Enabled
INFO - 2021-10-18 12:25:31 --> Utf8 Class Initialized
INFO - 2021-10-18 12:25:31 --> URI Class Initialized
INFO - 2021-10-18 12:25:31 --> Router Class Initialized
INFO - 2021-10-18 12:25:31 --> Output Class Initialized
INFO - 2021-10-18 12:25:31 --> Security Class Initialized
DEBUG - 2021-10-18 12:25:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-18 12:25:31 --> Input Class Initialized
INFO - 2021-10-18 12:25:31 --> Language Class Initialized
ERROR - 2021-10-18 12:25:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-18 12:25:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-18 12:25:32 --> Config Class Initialized
INFO - 2021-10-18 12:25:32 --> Hooks Class Initialized
DEBUG - 2021-10-18 12:25:32 --> UTF-8 Support Enabled
INFO - 2021-10-18 12:25:32 --> Utf8 Class Initialized
INFO - 2021-10-18 12:25:32 --> URI Class Initialized
INFO - 2021-10-18 12:25:32 --> Router Class Initialized
INFO - 2021-10-18 12:25:32 --> Output Class Initialized
INFO - 2021-10-18 12:25:32 --> Security Class Initialized
DEBUG - 2021-10-18 12:25:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-18 12:25:32 --> Input Class Initialized
INFO - 2021-10-18 12:25:32 --> Language Class Initialized
ERROR - 2021-10-18 12:25:32 --> 404 Page Not Found: Blog/robots.txt
ERROR - 2021-10-18 12:25:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-18 12:25:32 --> Config Class Initialized
INFO - 2021-10-18 12:25:32 --> Hooks Class Initialized
DEBUG - 2021-10-18 12:25:32 --> UTF-8 Support Enabled
INFO - 2021-10-18 12:25:32 --> Utf8 Class Initialized
INFO - 2021-10-18 12:25:32 --> URI Class Initialized
INFO - 2021-10-18 12:25:32 --> Router Class Initialized
INFO - 2021-10-18 12:25:32 --> Output Class Initialized
INFO - 2021-10-18 12:25:32 --> Security Class Initialized
DEBUG - 2021-10-18 12:25:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-18 12:25:32 --> Input Class Initialized
INFO - 2021-10-18 12:25:32 --> Language Class Initialized
ERROR - 2021-10-18 12:25:32 --> 404 Page Not Found: Blog/index
ERROR - 2021-10-18 12:25:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-18 12:25:32 --> Config Class Initialized
INFO - 2021-10-18 12:25:32 --> Hooks Class Initialized
DEBUG - 2021-10-18 12:25:32 --> UTF-8 Support Enabled
INFO - 2021-10-18 12:25:32 --> Utf8 Class Initialized
INFO - 2021-10-18 12:25:32 --> URI Class Initialized
INFO - 2021-10-18 12:25:32 --> Router Class Initialized
INFO - 2021-10-18 12:25:32 --> Output Class Initialized
INFO - 2021-10-18 12:25:32 --> Security Class Initialized
DEBUG - 2021-10-18 12:25:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-18 12:25:32 --> Input Class Initialized
INFO - 2021-10-18 12:25:32 --> Language Class Initialized
ERROR - 2021-10-18 12:25:32 --> 404 Page Not Found: Wordpress/index
ERROR - 2021-10-18 12:25:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-18 12:25:33 --> Config Class Initialized
INFO - 2021-10-18 12:25:33 --> Hooks Class Initialized
DEBUG - 2021-10-18 12:25:33 --> UTF-8 Support Enabled
INFO - 2021-10-18 12:25:33 --> Utf8 Class Initialized
INFO - 2021-10-18 12:25:33 --> URI Class Initialized
INFO - 2021-10-18 12:25:33 --> Router Class Initialized
INFO - 2021-10-18 12:25:33 --> Output Class Initialized
INFO - 2021-10-18 12:25:33 --> Security Class Initialized
DEBUG - 2021-10-18 12:25:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-18 12:25:33 --> Input Class Initialized
INFO - 2021-10-18 12:25:33 --> Language Class Initialized
ERROR - 2021-10-18 12:25:33 --> 404 Page Not Found: Wp/index
ERROR - 2021-10-18 16:58:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-18 16:58:09 --> Config Class Initialized
INFO - 2021-10-18 16:58:09 --> Hooks Class Initialized
DEBUG - 2021-10-18 16:58:09 --> UTF-8 Support Enabled
INFO - 2021-10-18 16:58:09 --> Utf8 Class Initialized
INFO - 2021-10-18 16:58:09 --> URI Class Initialized
DEBUG - 2021-10-18 16:58:09 --> No URI present. Default controller set.
INFO - 2021-10-18 16:58:09 --> Router Class Initialized
INFO - 2021-10-18 16:58:09 --> Output Class Initialized
INFO - 2021-10-18 16:58:09 --> Security Class Initialized
DEBUG - 2021-10-18 16:58:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-18 16:58:09 --> Input Class Initialized
INFO - 2021-10-18 16:58:09 --> Language Class Initialized
INFO - 2021-10-18 16:58:09 --> Loader Class Initialized
INFO - 2021-10-18 16:58:09 --> Helper loaded: url_helper
INFO - 2021-10-18 16:58:09 --> Helper loaded: form_helper
INFO - 2021-10-18 16:58:09 --> Helper loaded: common_helper
INFO - 2021-10-18 16:58:09 --> Database Driver Class Initialized
DEBUG - 2021-10-18 16:58:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-18 16:58:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-18 16:58:09 --> Controller Class Initialized
INFO - 2021-10-18 16:58:09 --> Form Validation Class Initialized
DEBUG - 2021-10-18 16:58:09 --> Encrypt Class Initialized
DEBUG - 2021-10-18 16:58:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-10-18 16:58:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-10-18 16:58:09 --> Email Class Initialized
INFO - 2021-10-18 16:58:09 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-10-18 16:58:09 --> Calendar Class Initialized
INFO - 2021-10-18 16:58:09 --> Model "Login_model" initialized
INFO - 2021-10-18 16:58:09 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-10-18 16:58:09 --> Final output sent to browser
DEBUG - 2021-10-18 16:58:09 --> Total execution time: 0.0569
ERROR - 2021-10-18 16:58:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-18 16:58:14 --> Config Class Initialized
INFO - 2021-10-18 16:58:14 --> Hooks Class Initialized
DEBUG - 2021-10-18 16:58:14 --> UTF-8 Support Enabled
INFO - 2021-10-18 16:58:14 --> Utf8 Class Initialized
INFO - 2021-10-18 16:58:14 --> URI Class Initialized
INFO - 2021-10-18 16:58:14 --> Router Class Initialized
INFO - 2021-10-18 16:58:14 --> Output Class Initialized
INFO - 2021-10-18 16:58:14 --> Security Class Initialized
DEBUG - 2021-10-18 16:58:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-18 16:58:14 --> Input Class Initialized
INFO - 2021-10-18 16:58:14 --> Language Class Initialized
ERROR - 2021-10-18 16:58:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-18 17:31:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-18 17:31:38 --> Config Class Initialized
INFO - 2021-10-18 17:31:38 --> Hooks Class Initialized
DEBUG - 2021-10-18 17:31:38 --> UTF-8 Support Enabled
INFO - 2021-10-18 17:31:38 --> Utf8 Class Initialized
INFO - 2021-10-18 17:31:38 --> URI Class Initialized
INFO - 2021-10-18 17:31:38 --> Router Class Initialized
INFO - 2021-10-18 17:31:38 --> Output Class Initialized
INFO - 2021-10-18 17:31:38 --> Security Class Initialized
DEBUG - 2021-10-18 17:31:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-18 17:31:38 --> Input Class Initialized
INFO - 2021-10-18 17:31:38 --> Language Class Initialized
ERROR - 2021-10-18 17:31:38 --> 404 Page Not Found: Wp-admin/setup-config.php
ERROR - 2021-10-18 18:01:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-18 18:01:09 --> Config Class Initialized
INFO - 2021-10-18 18:01:09 --> Hooks Class Initialized
DEBUG - 2021-10-18 18:01:09 --> UTF-8 Support Enabled
INFO - 2021-10-18 18:01:09 --> Utf8 Class Initialized
INFO - 2021-10-18 18:01:09 --> URI Class Initialized
DEBUG - 2021-10-18 18:01:09 --> No URI present. Default controller set.
INFO - 2021-10-18 18:01:09 --> Router Class Initialized
INFO - 2021-10-18 18:01:09 --> Output Class Initialized
INFO - 2021-10-18 18:01:09 --> Security Class Initialized
DEBUG - 2021-10-18 18:01:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-18 18:01:09 --> Input Class Initialized
INFO - 2021-10-18 18:01:09 --> Language Class Initialized
INFO - 2021-10-18 18:01:09 --> Loader Class Initialized
INFO - 2021-10-18 18:01:09 --> Helper loaded: url_helper
INFO - 2021-10-18 18:01:09 --> Helper loaded: form_helper
INFO - 2021-10-18 18:01:09 --> Helper loaded: common_helper
INFO - 2021-10-18 18:01:09 --> Database Driver Class Initialized
DEBUG - 2021-10-18 18:01:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-18 18:01:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-18 18:01:09 --> Controller Class Initialized
INFO - 2021-10-18 18:01:09 --> Form Validation Class Initialized
DEBUG - 2021-10-18 18:01:09 --> Encrypt Class Initialized
DEBUG - 2021-10-18 18:01:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-10-18 18:01:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-10-18 18:01:09 --> Email Class Initialized
INFO - 2021-10-18 18:01:09 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-10-18 18:01:09 --> Calendar Class Initialized
INFO - 2021-10-18 18:01:09 --> Model "Login_model" initialized
INFO - 2021-10-18 18:01:09 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-10-18 18:01:09 --> Final output sent to browser
DEBUG - 2021-10-18 18:01:09 --> Total execution time: 0.0423
ERROR - 2021-10-18 18:01:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-18 18:01:09 --> Config Class Initialized
INFO - 2021-10-18 18:01:09 --> Hooks Class Initialized
DEBUG - 2021-10-18 18:01:09 --> UTF-8 Support Enabled
INFO - 2021-10-18 18:01:09 --> Utf8 Class Initialized
INFO - 2021-10-18 18:01:09 --> URI Class Initialized
DEBUG - 2021-10-18 18:01:09 --> No URI present. Default controller set.
INFO - 2021-10-18 18:01:09 --> Router Class Initialized
INFO - 2021-10-18 18:01:09 --> Output Class Initialized
INFO - 2021-10-18 18:01:09 --> Security Class Initialized
DEBUG - 2021-10-18 18:01:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-18 18:01:09 --> Input Class Initialized
INFO - 2021-10-18 18:01:09 --> Language Class Initialized
INFO - 2021-10-18 18:01:09 --> Loader Class Initialized
INFO - 2021-10-18 18:01:09 --> Helper loaded: url_helper
INFO - 2021-10-18 18:01:09 --> Helper loaded: form_helper
INFO - 2021-10-18 18:01:09 --> Helper loaded: common_helper
INFO - 2021-10-18 18:01:09 --> Database Driver Class Initialized
DEBUG - 2021-10-18 18:01:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-18 18:01:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-18 18:01:09 --> Controller Class Initialized
INFO - 2021-10-18 18:01:09 --> Form Validation Class Initialized
DEBUG - 2021-10-18 18:01:09 --> Encrypt Class Initialized
DEBUG - 2021-10-18 18:01:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-10-18 18:01:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-10-18 18:01:09 --> Email Class Initialized
INFO - 2021-10-18 18:01:09 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-10-18 18:01:09 --> Calendar Class Initialized
INFO - 2021-10-18 18:01:09 --> Model "Login_model" initialized
INFO - 2021-10-18 18:01:09 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-10-18 18:01:09 --> Final output sent to browser
DEBUG - 2021-10-18 18:01:09 --> Total execution time: 0.0253
