<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-03-15 00:30:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 00:30:48 --> Config Class Initialized
INFO - 2022-03-15 00:30:48 --> Hooks Class Initialized
DEBUG - 2022-03-15 00:30:48 --> UTF-8 Support Enabled
INFO - 2022-03-15 00:30:48 --> Utf8 Class Initialized
INFO - 2022-03-15 00:30:48 --> URI Class Initialized
DEBUG - 2022-03-15 00:30:48 --> No URI present. Default controller set.
INFO - 2022-03-15 00:30:48 --> Router Class Initialized
INFO - 2022-03-15 00:30:48 --> Output Class Initialized
INFO - 2022-03-15 00:30:48 --> Security Class Initialized
DEBUG - 2022-03-15 00:30:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 00:30:48 --> Input Class Initialized
INFO - 2022-03-15 00:30:48 --> Language Class Initialized
INFO - 2022-03-15 00:30:48 --> Loader Class Initialized
INFO - 2022-03-15 00:30:48 --> Helper loaded: url_helper
INFO - 2022-03-15 00:30:48 --> Helper loaded: form_helper
INFO - 2022-03-15 00:30:48 --> Helper loaded: common_helper
INFO - 2022-03-15 00:30:48 --> Database Driver Class Initialized
DEBUG - 2022-03-15 00:30:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 00:30:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 00:30:48 --> Controller Class Initialized
INFO - 2022-03-15 00:30:48 --> Form Validation Class Initialized
DEBUG - 2022-03-15 00:30:48 --> Encrypt Class Initialized
DEBUG - 2022-03-15 00:30:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-15 00:30:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-15 00:30:48 --> Email Class Initialized
INFO - 2022-03-15 00:30:48 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-15 00:30:48 --> Calendar Class Initialized
INFO - 2022-03-15 00:30:48 --> Model "Login_model" initialized
INFO - 2022-03-15 00:30:48 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-15 00:30:48 --> Final output sent to browser
DEBUG - 2022-03-15 00:30:48 --> Total execution time: 0.0222
ERROR - 2022-03-15 00:35:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 00:35:34 --> Config Class Initialized
INFO - 2022-03-15 00:35:34 --> Hooks Class Initialized
DEBUG - 2022-03-15 00:35:34 --> UTF-8 Support Enabled
INFO - 2022-03-15 00:35:34 --> Utf8 Class Initialized
INFO - 2022-03-15 00:35:34 --> URI Class Initialized
DEBUG - 2022-03-15 00:35:34 --> No URI present. Default controller set.
INFO - 2022-03-15 00:35:34 --> Router Class Initialized
INFO - 2022-03-15 00:35:34 --> Output Class Initialized
INFO - 2022-03-15 00:35:34 --> Security Class Initialized
DEBUG - 2022-03-15 00:35:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 00:35:34 --> Input Class Initialized
INFO - 2022-03-15 00:35:34 --> Language Class Initialized
INFO - 2022-03-15 00:35:34 --> Loader Class Initialized
INFO - 2022-03-15 00:35:34 --> Helper loaded: url_helper
INFO - 2022-03-15 00:35:34 --> Helper loaded: form_helper
INFO - 2022-03-15 00:35:34 --> Helper loaded: common_helper
INFO - 2022-03-15 00:35:34 --> Database Driver Class Initialized
DEBUG - 2022-03-15 00:35:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 00:35:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 00:35:34 --> Controller Class Initialized
INFO - 2022-03-15 00:35:34 --> Form Validation Class Initialized
DEBUG - 2022-03-15 00:35:34 --> Encrypt Class Initialized
DEBUG - 2022-03-15 00:35:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-15 00:35:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-15 00:35:34 --> Email Class Initialized
INFO - 2022-03-15 00:35:34 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-15 00:35:34 --> Calendar Class Initialized
INFO - 2022-03-15 00:35:34 --> Model "Login_model" initialized
INFO - 2022-03-15 00:35:34 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-15 00:35:34 --> Final output sent to browser
DEBUG - 2022-03-15 00:35:34 --> Total execution time: 0.0335
ERROR - 2022-03-15 03:10:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 03:10:44 --> Config Class Initialized
INFO - 2022-03-15 03:10:44 --> Hooks Class Initialized
DEBUG - 2022-03-15 03:10:44 --> UTF-8 Support Enabled
INFO - 2022-03-15 03:10:44 --> Utf8 Class Initialized
INFO - 2022-03-15 03:10:44 --> URI Class Initialized
INFO - 2022-03-15 03:10:44 --> Router Class Initialized
INFO - 2022-03-15 03:10:44 --> Output Class Initialized
INFO - 2022-03-15 03:10:44 --> Security Class Initialized
DEBUG - 2022-03-15 03:10:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 03:10:44 --> Input Class Initialized
INFO - 2022-03-15 03:10:44 --> Language Class Initialized
INFO - 2022-03-15 03:10:44 --> Loader Class Initialized
INFO - 2022-03-15 03:10:44 --> Helper loaded: url_helper
INFO - 2022-03-15 03:10:44 --> Helper loaded: form_helper
INFO - 2022-03-15 03:10:44 --> Helper loaded: common_helper
INFO - 2022-03-15 03:10:44 --> Database Driver Class Initialized
DEBUG - 2022-03-15 03:10:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 03:10:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 03:10:44 --> Controller Class Initialized
INFO - 2022-03-15 03:10:44 --> Form Validation Class Initialized
DEBUG - 2022-03-15 03:10:44 --> Encrypt Class Initialized
DEBUG - 2022-03-15 03:10:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-15 03:10:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-15 03:10:44 --> Email Class Initialized
INFO - 2022-03-15 03:10:44 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-15 03:10:44 --> Calendar Class Initialized
INFO - 2022-03-15 03:10:44 --> Model "Login_model" initialized
INFO - 2022-03-15 03:10:44 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-15 03:10:44 --> Final output sent to browser
DEBUG - 2022-03-15 03:10:44 --> Total execution time: 0.0268
ERROR - 2022-03-15 03:13:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 03:13:54 --> Config Class Initialized
INFO - 2022-03-15 03:13:54 --> Hooks Class Initialized
DEBUG - 2022-03-15 03:13:54 --> UTF-8 Support Enabled
INFO - 2022-03-15 03:13:54 --> Utf8 Class Initialized
INFO - 2022-03-15 03:13:54 --> URI Class Initialized
INFO - 2022-03-15 03:13:54 --> Router Class Initialized
INFO - 2022-03-15 03:13:54 --> Output Class Initialized
INFO - 2022-03-15 03:13:54 --> Security Class Initialized
DEBUG - 2022-03-15 03:13:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 03:13:54 --> Input Class Initialized
INFO - 2022-03-15 03:13:54 --> Language Class Initialized
INFO - 2022-03-15 03:13:54 --> Loader Class Initialized
INFO - 2022-03-15 03:13:54 --> Helper loaded: url_helper
INFO - 2022-03-15 03:13:54 --> Helper loaded: form_helper
INFO - 2022-03-15 03:13:54 --> Helper loaded: common_helper
INFO - 2022-03-15 03:13:54 --> Database Driver Class Initialized
DEBUG - 2022-03-15 03:13:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 03:13:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 03:13:54 --> Controller Class Initialized
INFO - 2022-03-15 03:13:54 --> Form Validation Class Initialized
DEBUG - 2022-03-15 03:13:54 --> Encrypt Class Initialized
DEBUG - 2022-03-15 03:13:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-15 03:13:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-15 03:13:54 --> Email Class Initialized
INFO - 2022-03-15 03:13:54 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-15 03:13:54 --> Calendar Class Initialized
INFO - 2022-03-15 03:13:54 --> Model "Login_model" initialized
INFO - 2022-03-15 03:13:54 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-03-15 03:13:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 03:13:55 --> Config Class Initialized
INFO - 2022-03-15 03:13:55 --> Hooks Class Initialized
DEBUG - 2022-03-15 03:13:55 --> UTF-8 Support Enabled
INFO - 2022-03-15 03:13:55 --> Utf8 Class Initialized
INFO - 2022-03-15 03:13:55 --> URI Class Initialized
INFO - 2022-03-15 03:13:55 --> Router Class Initialized
INFO - 2022-03-15 03:13:55 --> Output Class Initialized
INFO - 2022-03-15 03:13:55 --> Security Class Initialized
DEBUG - 2022-03-15 03:13:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 03:13:55 --> Input Class Initialized
INFO - 2022-03-15 03:13:55 --> Language Class Initialized
INFO - 2022-03-15 03:13:55 --> Loader Class Initialized
INFO - 2022-03-15 03:13:55 --> Helper loaded: url_helper
INFO - 2022-03-15 03:13:55 --> Helper loaded: form_helper
INFO - 2022-03-15 03:13:55 --> Helper loaded: common_helper
INFO - 2022-03-15 03:13:55 --> Database Driver Class Initialized
DEBUG - 2022-03-15 03:13:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 03:13:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 03:13:55 --> Controller Class Initialized
INFO - 2022-03-15 03:13:55 --> Form Validation Class Initialized
DEBUG - 2022-03-15 03:13:55 --> Encrypt Class Initialized
INFO - 2022-03-15 03:13:55 --> Model "Login_model" initialized
INFO - 2022-03-15 03:13:55 --> Model "Dashboard_model" initialized
INFO - 2022-03-15 03:13:55 --> Model "Case_model" initialized
INFO - 2022-03-15 03:13:56 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 03:13:56 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2022-03-15 03:13:56 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 03:13:56 --> Final output sent to browser
DEBUG - 2022-03-15 03:13:56 --> Total execution time: 1.1551
ERROR - 2022-03-15 03:14:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 03:14:23 --> Config Class Initialized
INFO - 2022-03-15 03:14:23 --> Hooks Class Initialized
DEBUG - 2022-03-15 03:14:23 --> UTF-8 Support Enabled
INFO - 2022-03-15 03:14:23 --> Utf8 Class Initialized
INFO - 2022-03-15 03:14:23 --> URI Class Initialized
INFO - 2022-03-15 03:14:23 --> Router Class Initialized
INFO - 2022-03-15 03:14:23 --> Output Class Initialized
INFO - 2022-03-15 03:14:23 --> Security Class Initialized
DEBUG - 2022-03-15 03:14:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 03:14:23 --> Input Class Initialized
INFO - 2022-03-15 03:14:23 --> Language Class Initialized
INFO - 2022-03-15 03:14:23 --> Loader Class Initialized
INFO - 2022-03-15 03:14:23 --> Helper loaded: url_helper
INFO - 2022-03-15 03:14:23 --> Helper loaded: form_helper
INFO - 2022-03-15 03:14:23 --> Helper loaded: common_helper
INFO - 2022-03-15 03:14:23 --> Database Driver Class Initialized
DEBUG - 2022-03-15 03:14:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 03:14:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 03:14:23 --> Controller Class Initialized
INFO - 2022-03-15 03:14:23 --> Form Validation Class Initialized
DEBUG - 2022-03-15 03:14:23 --> Encrypt Class Initialized
INFO - 2022-03-15 03:14:23 --> Model "Patient_model" initialized
INFO - 2022-03-15 03:14:23 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 03:14:23 --> Model "Referredby_model" initialized
INFO - 2022-03-15 03:14:23 --> Model "Prefix_master" initialized
INFO - 2022-03-15 03:14:23 --> Model "Hospital_model" initialized
INFO - 2022-03-15 03:14:23 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 03:14:23 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-15 03:14:23 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 03:14:23 --> Final output sent to browser
DEBUG - 2022-03-15 03:14:23 --> Total execution time: 0.2492
ERROR - 2022-03-15 03:14:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 03:14:47 --> Config Class Initialized
INFO - 2022-03-15 03:14:47 --> Hooks Class Initialized
DEBUG - 2022-03-15 03:14:47 --> UTF-8 Support Enabled
INFO - 2022-03-15 03:14:47 --> Utf8 Class Initialized
INFO - 2022-03-15 03:14:47 --> URI Class Initialized
INFO - 2022-03-15 03:14:47 --> Router Class Initialized
INFO - 2022-03-15 03:14:47 --> Output Class Initialized
INFO - 2022-03-15 03:14:47 --> Security Class Initialized
DEBUG - 2022-03-15 03:14:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 03:14:47 --> Input Class Initialized
INFO - 2022-03-15 03:14:47 --> Language Class Initialized
INFO - 2022-03-15 03:14:47 --> Loader Class Initialized
INFO - 2022-03-15 03:14:47 --> Helper loaded: url_helper
INFO - 2022-03-15 03:14:47 --> Helper loaded: form_helper
INFO - 2022-03-15 03:14:47 --> Helper loaded: common_helper
INFO - 2022-03-15 03:14:47 --> Database Driver Class Initialized
DEBUG - 2022-03-15 03:14:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 03:14:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 03:14:47 --> Controller Class Initialized
INFO - 2022-03-15 03:14:47 --> Form Validation Class Initialized
DEBUG - 2022-03-15 03:14:47 --> Encrypt Class Initialized
INFO - 2022-03-15 03:14:47 --> Model "Patient_model" initialized
INFO - 2022-03-15 03:14:47 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 03:14:47 --> Model "Referredby_model" initialized
INFO - 2022-03-15 03:14:47 --> Model "Prefix_master" initialized
INFO - 2022-03-15 03:14:47 --> Model "Hospital_model" initialized
INFO - 2022-03-15 03:14:47 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 03:14:47 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-15 03:14:47 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 03:14:47 --> Final output sent to browser
DEBUG - 2022-03-15 03:14:47 --> Total execution time: 0.0572
ERROR - 2022-03-15 03:34:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 03:34:07 --> Config Class Initialized
INFO - 2022-03-15 03:34:07 --> Hooks Class Initialized
DEBUG - 2022-03-15 03:34:07 --> UTF-8 Support Enabled
INFO - 2022-03-15 03:34:07 --> Utf8 Class Initialized
INFO - 2022-03-15 03:34:07 --> URI Class Initialized
INFO - 2022-03-15 03:34:07 --> Router Class Initialized
INFO - 2022-03-15 03:34:07 --> Output Class Initialized
INFO - 2022-03-15 03:34:07 --> Security Class Initialized
DEBUG - 2022-03-15 03:34:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 03:34:07 --> Input Class Initialized
INFO - 2022-03-15 03:34:07 --> Language Class Initialized
INFO - 2022-03-15 03:34:07 --> Loader Class Initialized
INFO - 2022-03-15 03:34:07 --> Helper loaded: url_helper
INFO - 2022-03-15 03:34:07 --> Helper loaded: form_helper
INFO - 2022-03-15 03:34:07 --> Helper loaded: common_helper
INFO - 2022-03-15 03:34:07 --> Database Driver Class Initialized
DEBUG - 2022-03-15 03:34:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 03:34:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 03:34:08 --> Controller Class Initialized
INFO - 2022-03-15 03:34:08 --> Model "Referredby_model" initialized
INFO - 2022-03-15 03:34:08 --> Final output sent to browser
DEBUG - 2022-03-15 03:34:08 --> Total execution time: 0.5726
ERROR - 2022-03-15 03:34:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 03:34:22 --> Config Class Initialized
INFO - 2022-03-15 03:34:22 --> Hooks Class Initialized
DEBUG - 2022-03-15 03:34:22 --> UTF-8 Support Enabled
INFO - 2022-03-15 03:34:22 --> Utf8 Class Initialized
INFO - 2022-03-15 03:34:22 --> URI Class Initialized
INFO - 2022-03-15 03:34:22 --> Router Class Initialized
INFO - 2022-03-15 03:34:22 --> Output Class Initialized
INFO - 2022-03-15 03:34:22 --> Security Class Initialized
DEBUG - 2022-03-15 03:34:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 03:34:22 --> Input Class Initialized
INFO - 2022-03-15 03:34:22 --> Language Class Initialized
INFO - 2022-03-15 03:34:22 --> Loader Class Initialized
INFO - 2022-03-15 03:34:22 --> Helper loaded: url_helper
INFO - 2022-03-15 03:34:22 --> Helper loaded: form_helper
INFO - 2022-03-15 03:34:22 --> Helper loaded: common_helper
INFO - 2022-03-15 03:34:22 --> Database Driver Class Initialized
DEBUG - 2022-03-15 03:34:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 03:34:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 03:34:22 --> Controller Class Initialized
INFO - 2022-03-15 03:34:22 --> Model "Referredby_model" initialized
INFO - 2022-03-15 03:34:22 --> Final output sent to browser
DEBUG - 2022-03-15 03:34:22 --> Total execution time: 0.0975
ERROR - 2022-03-15 03:34:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 03:34:56 --> Config Class Initialized
INFO - 2022-03-15 03:34:56 --> Hooks Class Initialized
DEBUG - 2022-03-15 03:34:56 --> UTF-8 Support Enabled
INFO - 2022-03-15 03:34:56 --> Utf8 Class Initialized
INFO - 2022-03-15 03:34:56 --> URI Class Initialized
INFO - 2022-03-15 03:34:56 --> Router Class Initialized
INFO - 2022-03-15 03:34:56 --> Output Class Initialized
INFO - 2022-03-15 03:34:56 --> Security Class Initialized
DEBUG - 2022-03-15 03:34:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 03:34:56 --> Input Class Initialized
INFO - 2022-03-15 03:34:56 --> Language Class Initialized
INFO - 2022-03-15 03:34:56 --> Loader Class Initialized
INFO - 2022-03-15 03:34:56 --> Helper loaded: url_helper
INFO - 2022-03-15 03:34:56 --> Helper loaded: form_helper
INFO - 2022-03-15 03:34:56 --> Helper loaded: common_helper
INFO - 2022-03-15 03:34:56 --> Database Driver Class Initialized
DEBUG - 2022-03-15 03:34:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 03:34:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 03:34:56 --> Controller Class Initialized
INFO - 2022-03-15 03:34:56 --> Form Validation Class Initialized
DEBUG - 2022-03-15 03:34:56 --> Encrypt Class Initialized
INFO - 2022-03-15 03:34:56 --> Model "Patient_model" initialized
INFO - 2022-03-15 03:34:56 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 03:34:56 --> Model "Referredby_model" initialized
INFO - 2022-03-15 03:34:56 --> Model "Prefix_master" initialized
INFO - 2022-03-15 03:34:56 --> Model "Hospital_model" initialized
INFO - 2022-03-15 03:34:56 --> Final output sent to browser
DEBUG - 2022-03-15 03:34:56 --> Total execution time: 0.0408
ERROR - 2022-03-15 03:53:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 03:53:43 --> Config Class Initialized
INFO - 2022-03-15 03:53:43 --> Hooks Class Initialized
DEBUG - 2022-03-15 03:53:43 --> UTF-8 Support Enabled
INFO - 2022-03-15 03:53:43 --> Utf8 Class Initialized
INFO - 2022-03-15 03:53:43 --> URI Class Initialized
INFO - 2022-03-15 03:53:43 --> Router Class Initialized
INFO - 2022-03-15 03:53:43 --> Output Class Initialized
INFO - 2022-03-15 03:53:43 --> Security Class Initialized
DEBUG - 2022-03-15 03:53:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 03:53:43 --> Input Class Initialized
INFO - 2022-03-15 03:53:43 --> Language Class Initialized
INFO - 2022-03-15 03:53:43 --> Loader Class Initialized
INFO - 2022-03-15 03:53:43 --> Helper loaded: url_helper
INFO - 2022-03-15 03:53:43 --> Helper loaded: form_helper
INFO - 2022-03-15 03:53:43 --> Helper loaded: common_helper
INFO - 2022-03-15 03:53:43 --> Database Driver Class Initialized
DEBUG - 2022-03-15 03:53:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 03:53:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 03:53:43 --> Controller Class Initialized
INFO - 2022-03-15 03:53:43 --> Form Validation Class Initialized
DEBUG - 2022-03-15 03:53:43 --> Encrypt Class Initialized
INFO - 2022-03-15 03:53:43 --> Model "Patient_model" initialized
INFO - 2022-03-15 03:53:43 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 03:53:43 --> Model "Referredby_model" initialized
INFO - 2022-03-15 03:53:43 --> Model "Prefix_master" initialized
INFO - 2022-03-15 03:53:43 --> Model "Hospital_model" initialized
ERROR - 2022-03-15 03:53:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 03:53:44 --> Config Class Initialized
INFO - 2022-03-15 03:53:44 --> Hooks Class Initialized
DEBUG - 2022-03-15 03:53:44 --> UTF-8 Support Enabled
INFO - 2022-03-15 03:53:44 --> Utf8 Class Initialized
INFO - 2022-03-15 03:53:44 --> URI Class Initialized
INFO - 2022-03-15 03:53:44 --> Router Class Initialized
INFO - 2022-03-15 03:53:44 --> Output Class Initialized
INFO - 2022-03-15 03:53:44 --> Security Class Initialized
DEBUG - 2022-03-15 03:53:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 03:53:44 --> Input Class Initialized
INFO - 2022-03-15 03:53:44 --> Language Class Initialized
INFO - 2022-03-15 03:53:44 --> Loader Class Initialized
INFO - 2022-03-15 03:53:44 --> Helper loaded: url_helper
INFO - 2022-03-15 03:53:44 --> Helper loaded: form_helper
INFO - 2022-03-15 03:53:44 --> Helper loaded: common_helper
INFO - 2022-03-15 03:53:44 --> Database Driver Class Initialized
DEBUG - 2022-03-15 03:53:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 03:53:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 03:53:44 --> Controller Class Initialized
INFO - 2022-03-15 03:53:44 --> Form Validation Class Initialized
DEBUG - 2022-03-15 03:53:44 --> Encrypt Class Initialized
INFO - 2022-03-15 03:53:44 --> Model "Patient_model" initialized
INFO - 2022-03-15 03:53:44 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 03:53:44 --> Model "Referredby_model" initialized
INFO - 2022-03-15 03:53:44 --> Model "Prefix_master" initialized
INFO - 2022-03-15 03:53:44 --> Model "Hospital_model" initialized
INFO - 2022-03-15 03:53:44 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 03:53:44 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-15 03:53:44 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 03:53:44 --> Final output sent to browser
DEBUG - 2022-03-15 03:53:44 --> Total execution time: 0.2219
ERROR - 2022-03-15 03:53:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 03:53:45 --> Config Class Initialized
INFO - 2022-03-15 03:53:45 --> Hooks Class Initialized
DEBUG - 2022-03-15 03:53:45 --> UTF-8 Support Enabled
INFO - 2022-03-15 03:53:45 --> Utf8 Class Initialized
INFO - 2022-03-15 03:53:45 --> URI Class Initialized
INFO - 2022-03-15 03:53:45 --> Router Class Initialized
INFO - 2022-03-15 03:53:45 --> Output Class Initialized
INFO - 2022-03-15 03:53:45 --> Security Class Initialized
DEBUG - 2022-03-15 03:53:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 03:53:45 --> Input Class Initialized
INFO - 2022-03-15 03:53:45 --> Language Class Initialized
INFO - 2022-03-15 03:53:45 --> Loader Class Initialized
INFO - 2022-03-15 03:53:45 --> Helper loaded: url_helper
INFO - 2022-03-15 03:53:45 --> Helper loaded: form_helper
INFO - 2022-03-15 03:53:45 --> Helper loaded: common_helper
INFO - 2022-03-15 03:53:45 --> Database Driver Class Initialized
DEBUG - 2022-03-15 03:53:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 03:53:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 03:53:45 --> Controller Class Initialized
INFO - 2022-03-15 03:53:45 --> Form Validation Class Initialized
DEBUG - 2022-03-15 03:53:45 --> Encrypt Class Initialized
INFO - 2022-03-15 03:53:45 --> Model "Patient_model" initialized
INFO - 2022-03-15 03:53:45 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 03:53:45 --> Model "Prefix_master" initialized
INFO - 2022-03-15 03:53:45 --> Model "Users_model" initialized
INFO - 2022-03-15 03:53:45 --> Model "Hospital_model" initialized
INFO - 2022-03-15 03:53:45 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 03:53:45 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-15 03:53:45 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 03:53:45 --> Final output sent to browser
DEBUG - 2022-03-15 03:53:45 --> Total execution time: 0.4405
ERROR - 2022-03-15 03:57:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 03:57:47 --> Config Class Initialized
INFO - 2022-03-15 03:57:47 --> Hooks Class Initialized
DEBUG - 2022-03-15 03:57:47 --> UTF-8 Support Enabled
INFO - 2022-03-15 03:57:47 --> Utf8 Class Initialized
INFO - 2022-03-15 03:57:47 --> URI Class Initialized
INFO - 2022-03-15 03:57:47 --> Router Class Initialized
INFO - 2022-03-15 03:57:47 --> Output Class Initialized
INFO - 2022-03-15 03:57:47 --> Security Class Initialized
DEBUG - 2022-03-15 03:57:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 03:57:47 --> Input Class Initialized
INFO - 2022-03-15 03:57:47 --> Language Class Initialized
INFO - 2022-03-15 03:57:47 --> Loader Class Initialized
INFO - 2022-03-15 03:57:47 --> Helper loaded: url_helper
INFO - 2022-03-15 03:57:47 --> Helper loaded: form_helper
INFO - 2022-03-15 03:57:47 --> Helper loaded: common_helper
INFO - 2022-03-15 03:57:47 --> Database Driver Class Initialized
DEBUG - 2022-03-15 03:57:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 03:57:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 03:57:47 --> Controller Class Initialized
INFO - 2022-03-15 03:57:47 --> Form Validation Class Initialized
DEBUG - 2022-03-15 03:57:47 --> Encrypt Class Initialized
INFO - 2022-03-15 03:57:47 --> Model "Patient_model" initialized
INFO - 2022-03-15 03:57:47 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 03:57:47 --> Model "Prefix_master" initialized
INFO - 2022-03-15 03:57:47 --> Model "Users_model" initialized
INFO - 2022-03-15 03:57:47 --> Model "Hospital_model" initialized
ERROR - 2022-03-15 03:57:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 03:57:48 --> Config Class Initialized
INFO - 2022-03-15 03:57:48 --> Hooks Class Initialized
DEBUG - 2022-03-15 03:57:48 --> UTF-8 Support Enabled
INFO - 2022-03-15 03:57:48 --> Utf8 Class Initialized
INFO - 2022-03-15 03:57:48 --> URI Class Initialized
INFO - 2022-03-15 03:57:48 --> Router Class Initialized
INFO - 2022-03-15 03:57:48 --> Output Class Initialized
INFO - 2022-03-15 03:57:48 --> Security Class Initialized
DEBUG - 2022-03-15 03:57:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 03:57:48 --> Input Class Initialized
INFO - 2022-03-15 03:57:48 --> Language Class Initialized
INFO - 2022-03-15 03:57:48 --> Loader Class Initialized
INFO - 2022-03-15 03:57:48 --> Helper loaded: url_helper
INFO - 2022-03-15 03:57:48 --> Helper loaded: form_helper
INFO - 2022-03-15 03:57:48 --> Helper loaded: common_helper
INFO - 2022-03-15 03:57:48 --> Database Driver Class Initialized
DEBUG - 2022-03-15 03:57:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 03:57:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 03:57:48 --> Controller Class Initialized
INFO - 2022-03-15 03:57:48 --> Form Validation Class Initialized
DEBUG - 2022-03-15 03:57:48 --> Encrypt Class Initialized
INFO - 2022-03-15 03:57:48 --> Model "Patient_model" initialized
INFO - 2022-03-15 03:57:48 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 03:57:48 --> Model "Prefix_master" initialized
INFO - 2022-03-15 03:57:48 --> Model "Users_model" initialized
INFO - 2022-03-15 03:57:48 --> Model "Hospital_model" initialized
INFO - 2022-03-15 03:57:49 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 03:57:49 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-15 03:57:49 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 03:57:49 --> Final output sent to browser
DEBUG - 2022-03-15 03:57:49 --> Total execution time: 1.6880
ERROR - 2022-03-15 04:03:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 04:03:46 --> Config Class Initialized
INFO - 2022-03-15 04:03:46 --> Hooks Class Initialized
DEBUG - 2022-03-15 04:03:46 --> UTF-8 Support Enabled
INFO - 2022-03-15 04:03:46 --> Utf8 Class Initialized
INFO - 2022-03-15 04:03:46 --> URI Class Initialized
INFO - 2022-03-15 04:03:46 --> Router Class Initialized
INFO - 2022-03-15 04:03:46 --> Output Class Initialized
INFO - 2022-03-15 04:03:46 --> Security Class Initialized
DEBUG - 2022-03-15 04:03:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 04:03:46 --> Input Class Initialized
INFO - 2022-03-15 04:03:46 --> Language Class Initialized
INFO - 2022-03-15 04:03:46 --> Loader Class Initialized
INFO - 2022-03-15 04:03:46 --> Helper loaded: url_helper
INFO - 2022-03-15 04:03:46 --> Helper loaded: form_helper
INFO - 2022-03-15 04:03:46 --> Helper loaded: common_helper
INFO - 2022-03-15 04:03:46 --> Database Driver Class Initialized
DEBUG - 2022-03-15 04:03:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 04:03:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 04:03:46 --> Controller Class Initialized
INFO - 2022-03-15 04:03:46 --> Form Validation Class Initialized
DEBUG - 2022-03-15 04:03:46 --> Encrypt Class Initialized
INFO - 2022-03-15 04:03:46 --> Model "Patient_model" initialized
INFO - 2022-03-15 04:03:46 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 04:03:46 --> Model "Prefix_master" initialized
INFO - 2022-03-15 04:03:46 --> Model "Users_model" initialized
INFO - 2022-03-15 04:03:46 --> Model "Hospital_model" initialized
ERROR - 2022-03-15 04:03:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 04:03:47 --> Config Class Initialized
INFO - 2022-03-15 04:03:47 --> Hooks Class Initialized
DEBUG - 2022-03-15 04:03:47 --> UTF-8 Support Enabled
INFO - 2022-03-15 04:03:47 --> Utf8 Class Initialized
INFO - 2022-03-15 04:03:47 --> URI Class Initialized
INFO - 2022-03-15 04:03:47 --> Router Class Initialized
INFO - 2022-03-15 04:03:47 --> Output Class Initialized
INFO - 2022-03-15 04:03:47 --> Security Class Initialized
DEBUG - 2022-03-15 04:03:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 04:03:47 --> Input Class Initialized
INFO - 2022-03-15 04:03:47 --> Language Class Initialized
INFO - 2022-03-15 04:03:47 --> Loader Class Initialized
INFO - 2022-03-15 04:03:47 --> Helper loaded: url_helper
INFO - 2022-03-15 04:03:47 --> Helper loaded: form_helper
INFO - 2022-03-15 04:03:47 --> Helper loaded: common_helper
INFO - 2022-03-15 04:03:47 --> Database Driver Class Initialized
DEBUG - 2022-03-15 04:03:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 04:03:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 04:03:47 --> Controller Class Initialized
INFO - 2022-03-15 04:03:47 --> Form Validation Class Initialized
DEBUG - 2022-03-15 04:03:47 --> Encrypt Class Initialized
INFO - 2022-03-15 04:03:47 --> Model "Patient_model" initialized
INFO - 2022-03-15 04:03:47 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 04:03:47 --> Model "Prefix_master" initialized
INFO - 2022-03-15 04:03:47 --> Model "Users_model" initialized
INFO - 2022-03-15 04:03:47 --> Model "Hospital_model" initialized
INFO - 2022-03-15 04:03:47 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 04:03:47 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-15 04:03:47 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 04:03:47 --> Final output sent to browser
DEBUG - 2022-03-15 04:03:47 --> Total execution time: 0.0824
ERROR - 2022-03-15 04:05:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 04:05:01 --> Config Class Initialized
INFO - 2022-03-15 04:05:01 --> Hooks Class Initialized
DEBUG - 2022-03-15 04:05:01 --> UTF-8 Support Enabled
INFO - 2022-03-15 04:05:01 --> Utf8 Class Initialized
INFO - 2022-03-15 04:05:01 --> URI Class Initialized
INFO - 2022-03-15 04:05:01 --> Router Class Initialized
INFO - 2022-03-15 04:05:01 --> Output Class Initialized
INFO - 2022-03-15 04:05:01 --> Security Class Initialized
DEBUG - 2022-03-15 04:05:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 04:05:01 --> Input Class Initialized
INFO - 2022-03-15 04:05:01 --> Language Class Initialized
INFO - 2022-03-15 04:05:01 --> Loader Class Initialized
INFO - 2022-03-15 04:05:01 --> Helper loaded: url_helper
INFO - 2022-03-15 04:05:01 --> Helper loaded: form_helper
INFO - 2022-03-15 04:05:01 --> Helper loaded: common_helper
INFO - 2022-03-15 04:05:01 --> Database Driver Class Initialized
DEBUG - 2022-03-15 04:05:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 04:05:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 04:05:01 --> Controller Class Initialized
INFO - 2022-03-15 04:05:01 --> Form Validation Class Initialized
DEBUG - 2022-03-15 04:05:01 --> Encrypt Class Initialized
INFO - 2022-03-15 04:05:01 --> Model "Patient_model" initialized
INFO - 2022-03-15 04:05:01 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 04:05:01 --> Model "Prefix_master" initialized
INFO - 2022-03-15 04:05:01 --> Model "Users_model" initialized
INFO - 2022-03-15 04:05:01 --> Model "Hospital_model" initialized
INFO - 2022-03-15 04:05:01 --> Upload Class Initialized
INFO - 2022-03-15 04:05:01 --> Final output sent to browser
DEBUG - 2022-03-15 04:05:01 --> Total execution time: 0.0674
ERROR - 2022-03-15 04:05:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 04:05:13 --> Config Class Initialized
INFO - 2022-03-15 04:05:13 --> Hooks Class Initialized
DEBUG - 2022-03-15 04:05:13 --> UTF-8 Support Enabled
INFO - 2022-03-15 04:05:13 --> Utf8 Class Initialized
INFO - 2022-03-15 04:05:13 --> URI Class Initialized
INFO - 2022-03-15 04:05:13 --> Router Class Initialized
INFO - 2022-03-15 04:05:13 --> Output Class Initialized
INFO - 2022-03-15 04:05:13 --> Security Class Initialized
DEBUG - 2022-03-15 04:05:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 04:05:13 --> Input Class Initialized
INFO - 2022-03-15 04:05:13 --> Language Class Initialized
INFO - 2022-03-15 04:05:13 --> Loader Class Initialized
INFO - 2022-03-15 04:05:13 --> Helper loaded: url_helper
INFO - 2022-03-15 04:05:13 --> Helper loaded: form_helper
INFO - 2022-03-15 04:05:13 --> Helper loaded: common_helper
INFO - 2022-03-15 04:05:13 --> Database Driver Class Initialized
DEBUG - 2022-03-15 04:05:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 04:05:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 04:05:13 --> Controller Class Initialized
INFO - 2022-03-15 04:05:13 --> Form Validation Class Initialized
DEBUG - 2022-03-15 04:05:13 --> Encrypt Class Initialized
INFO - 2022-03-15 04:05:13 --> Model "Patient_model" initialized
INFO - 2022-03-15 04:05:13 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 04:05:13 --> Model "Prefix_master" initialized
INFO - 2022-03-15 04:05:13 --> Model "Users_model" initialized
INFO - 2022-03-15 04:05:13 --> Model "Hospital_model" initialized
INFO - 2022-03-15 04:05:13 --> Final output sent to browser
DEBUG - 2022-03-15 04:05:13 --> Total execution time: 0.0222
ERROR - 2022-03-15 04:05:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 04:05:38 --> Config Class Initialized
INFO - 2022-03-15 04:05:38 --> Hooks Class Initialized
DEBUG - 2022-03-15 04:05:38 --> UTF-8 Support Enabled
INFO - 2022-03-15 04:05:38 --> Utf8 Class Initialized
INFO - 2022-03-15 04:05:38 --> URI Class Initialized
INFO - 2022-03-15 04:05:38 --> Router Class Initialized
INFO - 2022-03-15 04:05:38 --> Output Class Initialized
INFO - 2022-03-15 04:05:38 --> Security Class Initialized
DEBUG - 2022-03-15 04:05:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 04:05:38 --> Input Class Initialized
INFO - 2022-03-15 04:05:38 --> Language Class Initialized
INFO - 2022-03-15 04:05:38 --> Loader Class Initialized
INFO - 2022-03-15 04:05:38 --> Helper loaded: url_helper
INFO - 2022-03-15 04:05:38 --> Helper loaded: form_helper
INFO - 2022-03-15 04:05:38 --> Helper loaded: common_helper
INFO - 2022-03-15 04:05:38 --> Database Driver Class Initialized
DEBUG - 2022-03-15 04:05:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 04:05:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 04:05:38 --> Controller Class Initialized
INFO - 2022-03-15 04:05:38 --> Form Validation Class Initialized
DEBUG - 2022-03-15 04:05:38 --> Encrypt Class Initialized
INFO - 2022-03-15 04:05:38 --> Model "Patient_model" initialized
INFO - 2022-03-15 04:05:38 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 04:05:38 --> Model "Prefix_master" initialized
INFO - 2022-03-15 04:05:38 --> Model "Users_model" initialized
INFO - 2022-03-15 04:05:38 --> Model "Hospital_model" initialized
INFO - 2022-03-15 04:05:38 --> Upload Class Initialized
INFO - 2022-03-15 04:05:38 --> Final output sent to browser
DEBUG - 2022-03-15 04:05:38 --> Total execution time: 0.0544
ERROR - 2022-03-15 04:05:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 04:05:55 --> Config Class Initialized
INFO - 2022-03-15 04:05:55 --> Hooks Class Initialized
DEBUG - 2022-03-15 04:05:55 --> UTF-8 Support Enabled
INFO - 2022-03-15 04:05:55 --> Utf8 Class Initialized
INFO - 2022-03-15 04:05:55 --> URI Class Initialized
INFO - 2022-03-15 04:05:55 --> Router Class Initialized
INFO - 2022-03-15 04:05:55 --> Output Class Initialized
INFO - 2022-03-15 04:05:55 --> Security Class Initialized
DEBUG - 2022-03-15 04:05:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 04:05:55 --> Input Class Initialized
INFO - 2022-03-15 04:05:55 --> Language Class Initialized
INFO - 2022-03-15 04:05:55 --> Loader Class Initialized
INFO - 2022-03-15 04:05:55 --> Helper loaded: url_helper
INFO - 2022-03-15 04:05:55 --> Helper loaded: form_helper
INFO - 2022-03-15 04:05:55 --> Helper loaded: common_helper
INFO - 2022-03-15 04:05:55 --> Database Driver Class Initialized
DEBUG - 2022-03-15 04:05:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 04:05:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 04:05:55 --> Controller Class Initialized
INFO - 2022-03-15 04:05:55 --> Form Validation Class Initialized
DEBUG - 2022-03-15 04:05:55 --> Encrypt Class Initialized
INFO - 2022-03-15 04:05:55 --> Model "Patient_model" initialized
INFO - 2022-03-15 04:05:55 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 04:05:55 --> Model "Prefix_master" initialized
INFO - 2022-03-15 04:05:55 --> Model "Users_model" initialized
INFO - 2022-03-15 04:05:55 --> Model "Hospital_model" initialized
INFO - 2022-03-15 04:05:55 --> Upload Class Initialized
INFO - 2022-03-15 04:05:55 --> Final output sent to browser
DEBUG - 2022-03-15 04:05:55 --> Total execution time: 0.0755
ERROR - 2022-03-15 04:06:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 04:06:11 --> Config Class Initialized
INFO - 2022-03-15 04:06:11 --> Hooks Class Initialized
DEBUG - 2022-03-15 04:06:11 --> UTF-8 Support Enabled
INFO - 2022-03-15 04:06:11 --> Utf8 Class Initialized
INFO - 2022-03-15 04:06:11 --> URI Class Initialized
INFO - 2022-03-15 04:06:11 --> Router Class Initialized
INFO - 2022-03-15 04:06:11 --> Output Class Initialized
INFO - 2022-03-15 04:06:11 --> Security Class Initialized
DEBUG - 2022-03-15 04:06:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 04:06:11 --> Input Class Initialized
INFO - 2022-03-15 04:06:11 --> Language Class Initialized
INFO - 2022-03-15 04:06:11 --> Loader Class Initialized
INFO - 2022-03-15 04:06:11 --> Helper loaded: url_helper
INFO - 2022-03-15 04:06:11 --> Helper loaded: form_helper
INFO - 2022-03-15 04:06:11 --> Helper loaded: common_helper
INFO - 2022-03-15 04:06:11 --> Database Driver Class Initialized
DEBUG - 2022-03-15 04:06:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 04:06:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 04:06:11 --> Controller Class Initialized
INFO - 2022-03-15 04:06:11 --> Form Validation Class Initialized
DEBUG - 2022-03-15 04:06:11 --> Encrypt Class Initialized
INFO - 2022-03-15 04:06:11 --> Model "Patient_model" initialized
INFO - 2022-03-15 04:06:11 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 04:06:11 --> Model "Prefix_master" initialized
INFO - 2022-03-15 04:06:11 --> Model "Users_model" initialized
INFO - 2022-03-15 04:06:11 --> Model "Hospital_model" initialized
ERROR - 2022-03-15 04:06:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 04:06:11 --> Config Class Initialized
INFO - 2022-03-15 04:06:11 --> Hooks Class Initialized
DEBUG - 2022-03-15 04:06:11 --> UTF-8 Support Enabled
INFO - 2022-03-15 04:06:11 --> Utf8 Class Initialized
INFO - 2022-03-15 04:06:11 --> URI Class Initialized
INFO - 2022-03-15 04:06:11 --> Router Class Initialized
INFO - 2022-03-15 04:06:11 --> Output Class Initialized
INFO - 2022-03-15 04:06:11 --> Security Class Initialized
DEBUG - 2022-03-15 04:06:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 04:06:11 --> Input Class Initialized
INFO - 2022-03-15 04:06:11 --> Language Class Initialized
INFO - 2022-03-15 04:06:11 --> Loader Class Initialized
INFO - 2022-03-15 04:06:11 --> Helper loaded: url_helper
INFO - 2022-03-15 04:06:11 --> Helper loaded: form_helper
INFO - 2022-03-15 04:06:11 --> Helper loaded: common_helper
INFO - 2022-03-15 04:06:11 --> Database Driver Class Initialized
DEBUG - 2022-03-15 04:06:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 04:06:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 04:06:11 --> Controller Class Initialized
INFO - 2022-03-15 04:06:11 --> Form Validation Class Initialized
DEBUG - 2022-03-15 04:06:11 --> Encrypt Class Initialized
INFO - 2022-03-15 04:06:11 --> Model "Patient_model" initialized
INFO - 2022-03-15 04:06:11 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 04:06:11 --> Model "Prefix_master" initialized
INFO - 2022-03-15 04:06:11 --> Model "Users_model" initialized
INFO - 2022-03-15 04:06:11 --> Model "Hospital_model" initialized
INFO - 2022-03-15 04:06:11 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 04:06:11 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-15 04:06:11 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 04:06:11 --> Final output sent to browser
DEBUG - 2022-03-15 04:06:11 --> Total execution time: 0.0736
ERROR - 2022-03-15 04:36:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 04:36:31 --> Config Class Initialized
INFO - 2022-03-15 04:36:31 --> Hooks Class Initialized
DEBUG - 2022-03-15 04:36:31 --> UTF-8 Support Enabled
INFO - 2022-03-15 04:36:31 --> Utf8 Class Initialized
INFO - 2022-03-15 04:36:31 --> URI Class Initialized
INFO - 2022-03-15 04:36:31 --> Router Class Initialized
INFO - 2022-03-15 04:36:31 --> Output Class Initialized
INFO - 2022-03-15 04:36:31 --> Security Class Initialized
DEBUG - 2022-03-15 04:36:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 04:36:31 --> Input Class Initialized
INFO - 2022-03-15 04:36:31 --> Language Class Initialized
INFO - 2022-03-15 04:36:31 --> Loader Class Initialized
INFO - 2022-03-15 04:36:31 --> Helper loaded: url_helper
INFO - 2022-03-15 04:36:31 --> Helper loaded: form_helper
INFO - 2022-03-15 04:36:31 --> Helper loaded: common_helper
INFO - 2022-03-15 04:36:31 --> Database Driver Class Initialized
DEBUG - 2022-03-15 04:36:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 04:36:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 04:36:31 --> Controller Class Initialized
INFO - 2022-03-15 04:36:31 --> Form Validation Class Initialized
DEBUG - 2022-03-15 04:36:31 --> Encrypt Class Initialized
INFO - 2022-03-15 04:36:31 --> Model "Patient_model" initialized
INFO - 2022-03-15 04:36:31 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 04:36:31 --> Model "Prefix_master" initialized
INFO - 2022-03-15 04:36:31 --> Model "Users_model" initialized
INFO - 2022-03-15 04:36:31 --> Model "Hospital_model" initialized
ERROR - 2022-03-15 04:36:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 04:36:32 --> Config Class Initialized
INFO - 2022-03-15 04:36:32 --> Hooks Class Initialized
DEBUG - 2022-03-15 04:36:32 --> UTF-8 Support Enabled
INFO - 2022-03-15 04:36:32 --> Utf8 Class Initialized
INFO - 2022-03-15 04:36:32 --> URI Class Initialized
INFO - 2022-03-15 04:36:32 --> Router Class Initialized
INFO - 2022-03-15 04:36:32 --> Output Class Initialized
INFO - 2022-03-15 04:36:32 --> Security Class Initialized
DEBUG - 2022-03-15 04:36:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 04:36:32 --> Input Class Initialized
INFO - 2022-03-15 04:36:32 --> Language Class Initialized
INFO - 2022-03-15 04:36:32 --> Loader Class Initialized
INFO - 2022-03-15 04:36:32 --> Helper loaded: url_helper
INFO - 2022-03-15 04:36:32 --> Helper loaded: form_helper
INFO - 2022-03-15 04:36:32 --> Helper loaded: common_helper
INFO - 2022-03-15 04:36:32 --> Database Driver Class Initialized
DEBUG - 2022-03-15 04:36:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 04:36:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 04:36:32 --> Controller Class Initialized
INFO - 2022-03-15 04:36:32 --> Form Validation Class Initialized
DEBUG - 2022-03-15 04:36:32 --> Encrypt Class Initialized
INFO - 2022-03-15 04:36:32 --> Model "Patient_model" initialized
INFO - 2022-03-15 04:36:32 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 04:36:32 --> Model "Prefix_master" initialized
INFO - 2022-03-15 04:36:32 --> Model "Users_model" initialized
INFO - 2022-03-15 04:36:32 --> Model "Hospital_model" initialized
INFO - 2022-03-15 04:36:32 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 04:36:32 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-15 04:36:32 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 04:36:32 --> Final output sent to browser
DEBUG - 2022-03-15 04:36:32 --> Total execution time: 0.0626
ERROR - 2022-03-15 04:36:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 04:36:44 --> Config Class Initialized
INFO - 2022-03-15 04:36:44 --> Hooks Class Initialized
DEBUG - 2022-03-15 04:36:44 --> UTF-8 Support Enabled
INFO - 2022-03-15 04:36:44 --> Utf8 Class Initialized
INFO - 2022-03-15 04:36:44 --> URI Class Initialized
INFO - 2022-03-15 04:36:44 --> Router Class Initialized
INFO - 2022-03-15 04:36:44 --> Output Class Initialized
INFO - 2022-03-15 04:36:44 --> Security Class Initialized
DEBUG - 2022-03-15 04:36:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 04:36:44 --> Input Class Initialized
INFO - 2022-03-15 04:36:44 --> Language Class Initialized
INFO - 2022-03-15 04:36:44 --> Loader Class Initialized
INFO - 2022-03-15 04:36:44 --> Helper loaded: url_helper
INFO - 2022-03-15 04:36:44 --> Helper loaded: form_helper
INFO - 2022-03-15 04:36:44 --> Helper loaded: common_helper
INFO - 2022-03-15 04:36:44 --> Database Driver Class Initialized
DEBUG - 2022-03-15 04:36:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 04:36:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 04:36:44 --> Controller Class Initialized
INFO - 2022-03-15 04:36:44 --> Form Validation Class Initialized
DEBUG - 2022-03-15 04:36:44 --> Encrypt Class Initialized
INFO - 2022-03-15 04:36:44 --> Model "Patient_model" initialized
INFO - 2022-03-15 04:36:44 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 04:36:44 --> Model "Referredby_model" initialized
INFO - 2022-03-15 04:36:44 --> Model "Prefix_master" initialized
INFO - 2022-03-15 04:36:44 --> Model "Hospital_model" initialized
INFO - 2022-03-15 04:36:44 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 04:36:44 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-15 04:36:44 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 04:36:44 --> Final output sent to browser
DEBUG - 2022-03-15 04:36:44 --> Total execution time: 0.1872
ERROR - 2022-03-15 04:36:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 04:36:54 --> Config Class Initialized
INFO - 2022-03-15 04:36:54 --> Hooks Class Initialized
DEBUG - 2022-03-15 04:36:54 --> UTF-8 Support Enabled
INFO - 2022-03-15 04:36:54 --> Utf8 Class Initialized
INFO - 2022-03-15 04:36:54 --> URI Class Initialized
INFO - 2022-03-15 04:36:54 --> Router Class Initialized
INFO - 2022-03-15 04:36:54 --> Output Class Initialized
INFO - 2022-03-15 04:36:54 --> Security Class Initialized
DEBUG - 2022-03-15 04:36:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 04:36:54 --> Input Class Initialized
INFO - 2022-03-15 04:36:54 --> Language Class Initialized
INFO - 2022-03-15 04:36:54 --> Loader Class Initialized
INFO - 2022-03-15 04:36:54 --> Helper loaded: url_helper
INFO - 2022-03-15 04:36:54 --> Helper loaded: form_helper
INFO - 2022-03-15 04:36:54 --> Helper loaded: common_helper
INFO - 2022-03-15 04:36:54 --> Database Driver Class Initialized
DEBUG - 2022-03-15 04:36:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 04:36:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 04:36:54 --> Controller Class Initialized
INFO - 2022-03-15 04:36:54 --> Form Validation Class Initialized
DEBUG - 2022-03-15 04:36:54 --> Encrypt Class Initialized
INFO - 2022-03-15 04:36:54 --> Model "Patient_model" initialized
INFO - 2022-03-15 04:36:54 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 04:36:54 --> Model "Referredby_model" initialized
INFO - 2022-03-15 04:36:54 --> Model "Prefix_master" initialized
INFO - 2022-03-15 04:36:54 --> Model "Hospital_model" initialized
INFO - 2022-03-15 04:36:54 --> Upload Class Initialized
INFO - 2022-03-15 04:36:54 --> Final output sent to browser
DEBUG - 2022-03-15 04:36:54 --> Total execution time: 0.0461
ERROR - 2022-03-15 04:37:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 04:37:23 --> Config Class Initialized
INFO - 2022-03-15 04:37:23 --> Hooks Class Initialized
DEBUG - 2022-03-15 04:37:23 --> UTF-8 Support Enabled
INFO - 2022-03-15 04:37:23 --> Utf8 Class Initialized
INFO - 2022-03-15 04:37:23 --> URI Class Initialized
INFO - 2022-03-15 04:37:23 --> Router Class Initialized
INFO - 2022-03-15 04:37:23 --> Output Class Initialized
INFO - 2022-03-15 04:37:23 --> Security Class Initialized
DEBUG - 2022-03-15 04:37:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 04:37:23 --> Input Class Initialized
INFO - 2022-03-15 04:37:23 --> Language Class Initialized
INFO - 2022-03-15 04:37:23 --> Loader Class Initialized
INFO - 2022-03-15 04:37:23 --> Helper loaded: url_helper
INFO - 2022-03-15 04:37:23 --> Helper loaded: form_helper
INFO - 2022-03-15 04:37:23 --> Helper loaded: common_helper
INFO - 2022-03-15 04:37:23 --> Database Driver Class Initialized
DEBUG - 2022-03-15 04:37:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 04:37:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 04:37:23 --> Controller Class Initialized
INFO - 2022-03-15 04:37:23 --> Form Validation Class Initialized
DEBUG - 2022-03-15 04:37:23 --> Encrypt Class Initialized
INFO - 2022-03-15 04:37:23 --> Model "Patient_model" initialized
INFO - 2022-03-15 04:37:23 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 04:37:23 --> Model "Referredby_model" initialized
INFO - 2022-03-15 04:37:23 --> Model "Prefix_master" initialized
INFO - 2022-03-15 04:37:23 --> Model "Hospital_model" initialized
INFO - 2022-03-15 04:37:23 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 04:37:23 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-15 04:37:23 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 04:37:23 --> Final output sent to browser
DEBUG - 2022-03-15 04:37:23 --> Total execution time: 0.3027
ERROR - 2022-03-15 04:37:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 04:37:40 --> Config Class Initialized
INFO - 2022-03-15 04:37:40 --> Hooks Class Initialized
DEBUG - 2022-03-15 04:37:40 --> UTF-8 Support Enabled
INFO - 2022-03-15 04:37:40 --> Utf8 Class Initialized
INFO - 2022-03-15 04:37:40 --> URI Class Initialized
INFO - 2022-03-15 04:37:40 --> Router Class Initialized
INFO - 2022-03-15 04:37:40 --> Output Class Initialized
INFO - 2022-03-15 04:37:40 --> Security Class Initialized
DEBUG - 2022-03-15 04:37:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 04:37:40 --> Input Class Initialized
INFO - 2022-03-15 04:37:40 --> Language Class Initialized
INFO - 2022-03-15 04:37:40 --> Loader Class Initialized
INFO - 2022-03-15 04:37:40 --> Helper loaded: url_helper
INFO - 2022-03-15 04:37:40 --> Helper loaded: form_helper
INFO - 2022-03-15 04:37:40 --> Helper loaded: common_helper
INFO - 2022-03-15 04:37:40 --> Database Driver Class Initialized
DEBUG - 2022-03-15 04:37:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 04:37:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 04:37:40 --> Controller Class Initialized
INFO - 2022-03-15 04:37:40 --> Form Validation Class Initialized
DEBUG - 2022-03-15 04:37:40 --> Encrypt Class Initialized
INFO - 2022-03-15 04:37:40 --> Model "Patient_model" initialized
INFO - 2022-03-15 04:37:40 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 04:37:40 --> Model "Prefix_master" initialized
INFO - 2022-03-15 04:37:40 --> Model "Users_model" initialized
INFO - 2022-03-15 04:37:40 --> Model "Hospital_model" initialized
INFO - 2022-03-15 04:37:41 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-15 04:37:43 --> Final output sent to browser
DEBUG - 2022-03-15 04:37:43 --> Total execution time: 2.8435
ERROR - 2022-03-15 04:44:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 04:44:58 --> Config Class Initialized
INFO - 2022-03-15 04:44:58 --> Hooks Class Initialized
DEBUG - 2022-03-15 04:44:58 --> UTF-8 Support Enabled
INFO - 2022-03-15 04:44:58 --> Utf8 Class Initialized
INFO - 2022-03-15 04:44:58 --> URI Class Initialized
INFO - 2022-03-15 04:44:58 --> Router Class Initialized
INFO - 2022-03-15 04:44:58 --> Output Class Initialized
INFO - 2022-03-15 04:44:58 --> Security Class Initialized
DEBUG - 2022-03-15 04:44:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 04:44:58 --> Input Class Initialized
INFO - 2022-03-15 04:44:58 --> Language Class Initialized
INFO - 2022-03-15 04:44:58 --> Loader Class Initialized
INFO - 2022-03-15 04:44:58 --> Helper loaded: url_helper
INFO - 2022-03-15 04:44:58 --> Helper loaded: form_helper
INFO - 2022-03-15 04:44:58 --> Helper loaded: common_helper
INFO - 2022-03-15 04:44:58 --> Database Driver Class Initialized
DEBUG - 2022-03-15 04:44:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 04:44:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 04:44:58 --> Controller Class Initialized
INFO - 2022-03-15 04:44:58 --> Form Validation Class Initialized
DEBUG - 2022-03-15 04:44:58 --> Encrypt Class Initialized
INFO - 2022-03-15 04:44:58 --> Model "Patient_model" initialized
INFO - 2022-03-15 04:44:58 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 04:44:58 --> Model "Referredby_model" initialized
INFO - 2022-03-15 04:44:58 --> Model "Prefix_master" initialized
INFO - 2022-03-15 04:44:58 --> Model "Hospital_model" initialized
INFO - 2022-03-15 04:44:58 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 04:44:58 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-15 04:44:58 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 04:44:58 --> Final output sent to browser
DEBUG - 2022-03-15 04:44:58 --> Total execution time: 0.0737
ERROR - 2022-03-15 04:45:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 04:45:11 --> Config Class Initialized
INFO - 2022-03-15 04:45:11 --> Hooks Class Initialized
DEBUG - 2022-03-15 04:45:11 --> UTF-8 Support Enabled
INFO - 2022-03-15 04:45:11 --> Utf8 Class Initialized
INFO - 2022-03-15 04:45:11 --> URI Class Initialized
INFO - 2022-03-15 04:45:11 --> Router Class Initialized
INFO - 2022-03-15 04:45:11 --> Output Class Initialized
INFO - 2022-03-15 04:45:11 --> Security Class Initialized
DEBUG - 2022-03-15 04:45:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 04:45:11 --> Input Class Initialized
INFO - 2022-03-15 04:45:11 --> Language Class Initialized
INFO - 2022-03-15 04:45:11 --> Loader Class Initialized
INFO - 2022-03-15 04:45:11 --> Helper loaded: url_helper
INFO - 2022-03-15 04:45:11 --> Helper loaded: form_helper
INFO - 2022-03-15 04:45:11 --> Helper loaded: common_helper
INFO - 2022-03-15 04:45:11 --> Database Driver Class Initialized
DEBUG - 2022-03-15 04:45:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 04:45:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 04:45:11 --> Controller Class Initialized
INFO - 2022-03-15 04:45:11 --> Form Validation Class Initialized
DEBUG - 2022-03-15 04:45:11 --> Encrypt Class Initialized
INFO - 2022-03-15 04:45:11 --> Model "Patient_model" initialized
INFO - 2022-03-15 04:45:11 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 04:45:11 --> Model "Referredby_model" initialized
INFO - 2022-03-15 04:45:11 --> Model "Prefix_master" initialized
INFO - 2022-03-15 04:45:11 --> Model "Hospital_model" initialized
INFO - 2022-03-15 04:45:11 --> Upload Class Initialized
INFO - 2022-03-15 04:45:11 --> Final output sent to browser
DEBUG - 2022-03-15 04:45:11 --> Total execution time: 0.0373
ERROR - 2022-03-15 04:45:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 04:45:16 --> Config Class Initialized
INFO - 2022-03-15 04:45:16 --> Hooks Class Initialized
DEBUG - 2022-03-15 04:45:16 --> UTF-8 Support Enabled
INFO - 2022-03-15 04:45:16 --> Utf8 Class Initialized
INFO - 2022-03-15 04:45:16 --> URI Class Initialized
INFO - 2022-03-15 04:45:16 --> Router Class Initialized
INFO - 2022-03-15 04:45:16 --> Output Class Initialized
INFO - 2022-03-15 04:45:16 --> Security Class Initialized
DEBUG - 2022-03-15 04:45:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 04:45:16 --> Input Class Initialized
INFO - 2022-03-15 04:45:16 --> Language Class Initialized
INFO - 2022-03-15 04:45:16 --> Loader Class Initialized
INFO - 2022-03-15 04:45:16 --> Helper loaded: url_helper
INFO - 2022-03-15 04:45:16 --> Helper loaded: form_helper
INFO - 2022-03-15 04:45:16 --> Helper loaded: common_helper
INFO - 2022-03-15 04:45:16 --> Database Driver Class Initialized
DEBUG - 2022-03-15 04:45:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 04:45:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 04:45:16 --> Controller Class Initialized
INFO - 2022-03-15 04:45:16 --> Form Validation Class Initialized
DEBUG - 2022-03-15 04:45:16 --> Encrypt Class Initialized
INFO - 2022-03-15 04:45:16 --> Model "Patient_model" initialized
INFO - 2022-03-15 04:45:16 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 04:45:16 --> Model "Referredby_model" initialized
INFO - 2022-03-15 04:45:16 --> Model "Prefix_master" initialized
INFO - 2022-03-15 04:45:16 --> Model "Hospital_model" initialized
ERROR - 2022-03-15 04:45:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 04:45:16 --> Config Class Initialized
INFO - 2022-03-15 04:45:16 --> Hooks Class Initialized
DEBUG - 2022-03-15 04:45:16 --> UTF-8 Support Enabled
INFO - 2022-03-15 04:45:16 --> Utf8 Class Initialized
INFO - 2022-03-15 04:45:16 --> URI Class Initialized
INFO - 2022-03-15 04:45:16 --> Router Class Initialized
INFO - 2022-03-15 04:45:16 --> Output Class Initialized
INFO - 2022-03-15 04:45:16 --> Security Class Initialized
DEBUG - 2022-03-15 04:45:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 04:45:16 --> Input Class Initialized
INFO - 2022-03-15 04:45:16 --> Language Class Initialized
INFO - 2022-03-15 04:45:16 --> Loader Class Initialized
INFO - 2022-03-15 04:45:16 --> Helper loaded: url_helper
INFO - 2022-03-15 04:45:16 --> Helper loaded: form_helper
INFO - 2022-03-15 04:45:16 --> Helper loaded: common_helper
INFO - 2022-03-15 04:45:16 --> Database Driver Class Initialized
DEBUG - 2022-03-15 04:45:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 04:45:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 04:45:16 --> Controller Class Initialized
INFO - 2022-03-15 04:45:16 --> Form Validation Class Initialized
DEBUG - 2022-03-15 04:45:16 --> Encrypt Class Initialized
INFO - 2022-03-15 04:45:16 --> Model "Patient_model" initialized
INFO - 2022-03-15 04:45:16 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 04:45:16 --> Model "Referredby_model" initialized
INFO - 2022-03-15 04:45:16 --> Model "Prefix_master" initialized
INFO - 2022-03-15 04:45:16 --> Model "Hospital_model" initialized
INFO - 2022-03-15 04:45:16 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 04:45:16 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-15 04:45:16 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 04:45:16 --> Final output sent to browser
DEBUG - 2022-03-15 04:45:16 --> Total execution time: 0.0454
ERROR - 2022-03-15 04:45:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 04:45:17 --> Config Class Initialized
INFO - 2022-03-15 04:45:17 --> Hooks Class Initialized
DEBUG - 2022-03-15 04:45:17 --> UTF-8 Support Enabled
INFO - 2022-03-15 04:45:17 --> Utf8 Class Initialized
INFO - 2022-03-15 04:45:17 --> URI Class Initialized
INFO - 2022-03-15 04:45:17 --> Router Class Initialized
INFO - 2022-03-15 04:45:17 --> Output Class Initialized
INFO - 2022-03-15 04:45:17 --> Security Class Initialized
DEBUG - 2022-03-15 04:45:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 04:45:17 --> Input Class Initialized
INFO - 2022-03-15 04:45:17 --> Language Class Initialized
INFO - 2022-03-15 04:45:17 --> Loader Class Initialized
INFO - 2022-03-15 04:45:17 --> Helper loaded: url_helper
INFO - 2022-03-15 04:45:17 --> Helper loaded: form_helper
INFO - 2022-03-15 04:45:17 --> Helper loaded: common_helper
INFO - 2022-03-15 04:45:17 --> Database Driver Class Initialized
DEBUG - 2022-03-15 04:45:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 04:45:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 04:45:17 --> Controller Class Initialized
INFO - 2022-03-15 04:45:17 --> Form Validation Class Initialized
DEBUG - 2022-03-15 04:45:17 --> Encrypt Class Initialized
INFO - 2022-03-15 04:45:17 --> Model "Patient_model" initialized
INFO - 2022-03-15 04:45:17 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 04:45:17 --> Model "Prefix_master" initialized
INFO - 2022-03-15 04:45:17 --> Model "Users_model" initialized
INFO - 2022-03-15 04:45:17 --> Model "Hospital_model" initialized
INFO - 2022-03-15 04:45:17 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 04:45:17 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-15 04:45:17 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 04:45:17 --> Final output sent to browser
DEBUG - 2022-03-15 04:45:17 --> Total execution time: 0.0805
ERROR - 2022-03-15 04:46:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 04:46:17 --> Config Class Initialized
INFO - 2022-03-15 04:46:17 --> Hooks Class Initialized
DEBUG - 2022-03-15 04:46:17 --> UTF-8 Support Enabled
INFO - 2022-03-15 04:46:17 --> Utf8 Class Initialized
INFO - 2022-03-15 04:46:17 --> URI Class Initialized
INFO - 2022-03-15 04:46:17 --> Router Class Initialized
INFO - 2022-03-15 04:46:17 --> Output Class Initialized
INFO - 2022-03-15 04:46:17 --> Security Class Initialized
DEBUG - 2022-03-15 04:46:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 04:46:17 --> Input Class Initialized
INFO - 2022-03-15 04:46:17 --> Language Class Initialized
INFO - 2022-03-15 04:46:17 --> Loader Class Initialized
INFO - 2022-03-15 04:46:17 --> Helper loaded: url_helper
INFO - 2022-03-15 04:46:17 --> Helper loaded: form_helper
INFO - 2022-03-15 04:46:17 --> Helper loaded: common_helper
INFO - 2022-03-15 04:46:17 --> Database Driver Class Initialized
DEBUG - 2022-03-15 04:46:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 04:46:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 04:46:17 --> Controller Class Initialized
INFO - 2022-03-15 04:46:17 --> Form Validation Class Initialized
DEBUG - 2022-03-15 04:46:17 --> Encrypt Class Initialized
INFO - 2022-03-15 04:46:17 --> Model "Patient_model" initialized
INFO - 2022-03-15 04:46:17 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 04:46:17 --> Model "Referredby_model" initialized
INFO - 2022-03-15 04:46:17 --> Model "Prefix_master" initialized
INFO - 2022-03-15 04:46:17 --> Model "Hospital_model" initialized
INFO - 2022-03-15 04:46:17 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 04:46:17 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-15 04:46:17 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 04:46:17 --> Final output sent to browser
DEBUG - 2022-03-15 04:46:17 --> Total execution time: 0.0495
ERROR - 2022-03-15 04:46:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 04:46:26 --> Config Class Initialized
INFO - 2022-03-15 04:46:26 --> Hooks Class Initialized
DEBUG - 2022-03-15 04:46:26 --> UTF-8 Support Enabled
INFO - 2022-03-15 04:46:26 --> Utf8 Class Initialized
INFO - 2022-03-15 04:46:26 --> URI Class Initialized
INFO - 2022-03-15 04:46:26 --> Router Class Initialized
INFO - 2022-03-15 04:46:26 --> Output Class Initialized
INFO - 2022-03-15 04:46:26 --> Security Class Initialized
DEBUG - 2022-03-15 04:46:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 04:46:26 --> Input Class Initialized
INFO - 2022-03-15 04:46:26 --> Language Class Initialized
INFO - 2022-03-15 04:46:26 --> Loader Class Initialized
INFO - 2022-03-15 04:46:26 --> Helper loaded: url_helper
INFO - 2022-03-15 04:46:26 --> Helper loaded: form_helper
INFO - 2022-03-15 04:46:26 --> Helper loaded: common_helper
INFO - 2022-03-15 04:46:26 --> Database Driver Class Initialized
DEBUG - 2022-03-15 04:46:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 04:46:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 04:46:26 --> Controller Class Initialized
INFO - 2022-03-15 04:46:26 --> Form Validation Class Initialized
DEBUG - 2022-03-15 04:46:26 --> Encrypt Class Initialized
INFO - 2022-03-15 04:46:26 --> Model "Patient_model" initialized
INFO - 2022-03-15 04:46:26 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 04:46:26 --> Model "Prefix_master" initialized
INFO - 2022-03-15 04:46:26 --> Model "Users_model" initialized
INFO - 2022-03-15 04:46:26 --> Model "Hospital_model" initialized
INFO - 2022-03-15 04:46:26 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-15 04:46:27 --> Final output sent to browser
DEBUG - 2022-03-15 04:46:27 --> Total execution time: 1.1156
ERROR - 2022-03-15 04:54:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 04:54:57 --> Config Class Initialized
INFO - 2022-03-15 04:54:57 --> Hooks Class Initialized
DEBUG - 2022-03-15 04:54:57 --> UTF-8 Support Enabled
INFO - 2022-03-15 04:54:57 --> Utf8 Class Initialized
INFO - 2022-03-15 04:54:57 --> URI Class Initialized
INFO - 2022-03-15 04:54:57 --> Router Class Initialized
INFO - 2022-03-15 04:54:57 --> Output Class Initialized
INFO - 2022-03-15 04:54:57 --> Security Class Initialized
DEBUG - 2022-03-15 04:54:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 04:54:57 --> Input Class Initialized
INFO - 2022-03-15 04:54:57 --> Language Class Initialized
INFO - 2022-03-15 04:54:57 --> Loader Class Initialized
INFO - 2022-03-15 04:54:57 --> Helper loaded: url_helper
INFO - 2022-03-15 04:54:57 --> Helper loaded: form_helper
INFO - 2022-03-15 04:54:57 --> Helper loaded: common_helper
INFO - 2022-03-15 04:54:57 --> Database Driver Class Initialized
DEBUG - 2022-03-15 04:54:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 04:54:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 04:54:57 --> Controller Class Initialized
INFO - 2022-03-15 04:54:57 --> Form Validation Class Initialized
DEBUG - 2022-03-15 04:54:57 --> Encrypt Class Initialized
INFO - 2022-03-15 04:54:57 --> Model "Patient_model" initialized
INFO - 2022-03-15 04:54:57 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 04:54:57 --> Model "Referredby_model" initialized
INFO - 2022-03-15 04:54:57 --> Model "Prefix_master" initialized
INFO - 2022-03-15 04:54:57 --> Model "Hospital_model" initialized
INFO - 2022-03-15 04:54:57 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 04:54:57 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-15 04:54:57 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 04:54:57 --> Final output sent to browser
DEBUG - 2022-03-15 04:54:57 --> Total execution time: 0.0798
ERROR - 2022-03-15 04:55:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 04:55:03 --> Config Class Initialized
INFO - 2022-03-15 04:55:03 --> Hooks Class Initialized
DEBUG - 2022-03-15 04:55:03 --> UTF-8 Support Enabled
INFO - 2022-03-15 04:55:03 --> Utf8 Class Initialized
INFO - 2022-03-15 04:55:03 --> URI Class Initialized
INFO - 2022-03-15 04:55:03 --> Router Class Initialized
INFO - 2022-03-15 04:55:03 --> Output Class Initialized
INFO - 2022-03-15 04:55:03 --> Security Class Initialized
DEBUG - 2022-03-15 04:55:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 04:55:03 --> Input Class Initialized
INFO - 2022-03-15 04:55:03 --> Language Class Initialized
INFO - 2022-03-15 04:55:03 --> Loader Class Initialized
INFO - 2022-03-15 04:55:03 --> Helper loaded: url_helper
INFO - 2022-03-15 04:55:03 --> Helper loaded: form_helper
INFO - 2022-03-15 04:55:03 --> Helper loaded: common_helper
INFO - 2022-03-15 04:55:03 --> Database Driver Class Initialized
DEBUG - 2022-03-15 04:55:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 04:55:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 04:55:03 --> Controller Class Initialized
INFO - 2022-03-15 04:55:03 --> Form Validation Class Initialized
DEBUG - 2022-03-15 04:55:03 --> Encrypt Class Initialized
INFO - 2022-03-15 04:55:03 --> Model "Patient_model" initialized
INFO - 2022-03-15 04:55:03 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 04:55:03 --> Model "Referredby_model" initialized
INFO - 2022-03-15 04:55:03 --> Model "Prefix_master" initialized
INFO - 2022-03-15 04:55:03 --> Model "Hospital_model" initialized
ERROR - 2022-03-15 04:55:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 04:55:04 --> Config Class Initialized
INFO - 2022-03-15 04:55:04 --> Hooks Class Initialized
DEBUG - 2022-03-15 04:55:04 --> UTF-8 Support Enabled
INFO - 2022-03-15 04:55:04 --> Utf8 Class Initialized
INFO - 2022-03-15 04:55:04 --> URI Class Initialized
INFO - 2022-03-15 04:55:04 --> Router Class Initialized
INFO - 2022-03-15 04:55:04 --> Output Class Initialized
INFO - 2022-03-15 04:55:04 --> Security Class Initialized
DEBUG - 2022-03-15 04:55:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 04:55:04 --> Input Class Initialized
INFO - 2022-03-15 04:55:04 --> Language Class Initialized
INFO - 2022-03-15 04:55:04 --> Loader Class Initialized
INFO - 2022-03-15 04:55:04 --> Helper loaded: url_helper
INFO - 2022-03-15 04:55:04 --> Helper loaded: form_helper
INFO - 2022-03-15 04:55:04 --> Helper loaded: common_helper
INFO - 2022-03-15 04:55:04 --> Database Driver Class Initialized
DEBUG - 2022-03-15 04:55:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 04:55:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 04:55:04 --> Controller Class Initialized
INFO - 2022-03-15 04:55:04 --> Form Validation Class Initialized
DEBUG - 2022-03-15 04:55:04 --> Encrypt Class Initialized
INFO - 2022-03-15 04:55:04 --> Model "Patient_model" initialized
INFO - 2022-03-15 04:55:04 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 04:55:04 --> Model "Referredby_model" initialized
INFO - 2022-03-15 04:55:04 --> Model "Prefix_master" initialized
INFO - 2022-03-15 04:55:04 --> Model "Hospital_model" initialized
INFO - 2022-03-15 04:55:04 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 04:55:04 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-15 04:55:04 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 04:55:04 --> Final output sent to browser
DEBUG - 2022-03-15 04:55:04 --> Total execution time: 0.0524
ERROR - 2022-03-15 04:55:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 04:55:05 --> Config Class Initialized
INFO - 2022-03-15 04:55:05 --> Hooks Class Initialized
DEBUG - 2022-03-15 04:55:05 --> UTF-8 Support Enabled
INFO - 2022-03-15 04:55:05 --> Utf8 Class Initialized
INFO - 2022-03-15 04:55:05 --> URI Class Initialized
INFO - 2022-03-15 04:55:05 --> Router Class Initialized
INFO - 2022-03-15 04:55:05 --> Output Class Initialized
INFO - 2022-03-15 04:55:05 --> Security Class Initialized
DEBUG - 2022-03-15 04:55:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 04:55:05 --> Input Class Initialized
INFO - 2022-03-15 04:55:05 --> Language Class Initialized
INFO - 2022-03-15 04:55:05 --> Loader Class Initialized
INFO - 2022-03-15 04:55:05 --> Helper loaded: url_helper
INFO - 2022-03-15 04:55:05 --> Helper loaded: form_helper
INFO - 2022-03-15 04:55:05 --> Helper loaded: common_helper
INFO - 2022-03-15 04:55:05 --> Database Driver Class Initialized
DEBUG - 2022-03-15 04:55:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 04:55:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 04:55:05 --> Controller Class Initialized
INFO - 2022-03-15 04:55:05 --> Form Validation Class Initialized
DEBUG - 2022-03-15 04:55:05 --> Encrypt Class Initialized
INFO - 2022-03-15 04:55:05 --> Model "Patient_model" initialized
INFO - 2022-03-15 04:55:05 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 04:55:05 --> Model "Prefix_master" initialized
INFO - 2022-03-15 04:55:05 --> Model "Users_model" initialized
INFO - 2022-03-15 04:55:05 --> Model "Hospital_model" initialized
INFO - 2022-03-15 04:55:05 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 04:55:05 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-15 04:55:05 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 04:55:05 --> Final output sent to browser
DEBUG - 2022-03-15 04:55:05 --> Total execution time: 0.0583
ERROR - 2022-03-15 05:03:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 05:03:38 --> Config Class Initialized
INFO - 2022-03-15 05:03:38 --> Hooks Class Initialized
DEBUG - 2022-03-15 05:03:38 --> UTF-8 Support Enabled
INFO - 2022-03-15 05:03:38 --> Utf8 Class Initialized
INFO - 2022-03-15 05:03:38 --> URI Class Initialized
INFO - 2022-03-15 05:03:38 --> Router Class Initialized
INFO - 2022-03-15 05:03:38 --> Output Class Initialized
INFO - 2022-03-15 05:03:38 --> Security Class Initialized
DEBUG - 2022-03-15 05:03:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 05:03:38 --> Input Class Initialized
INFO - 2022-03-15 05:03:38 --> Language Class Initialized
INFO - 2022-03-15 05:03:38 --> Loader Class Initialized
INFO - 2022-03-15 05:03:38 --> Helper loaded: url_helper
INFO - 2022-03-15 05:03:38 --> Helper loaded: form_helper
INFO - 2022-03-15 05:03:38 --> Helper loaded: common_helper
INFO - 2022-03-15 05:03:38 --> Database Driver Class Initialized
DEBUG - 2022-03-15 05:03:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 05:03:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 05:03:38 --> Controller Class Initialized
INFO - 2022-03-15 05:03:38 --> Form Validation Class Initialized
DEBUG - 2022-03-15 05:03:38 --> Encrypt Class Initialized
INFO - 2022-03-15 05:03:38 --> Model "Patient_model" initialized
INFO - 2022-03-15 05:03:38 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 05:03:38 --> Model "Prefix_master" initialized
INFO - 2022-03-15 05:03:38 --> Model "Users_model" initialized
INFO - 2022-03-15 05:03:38 --> Model "Hospital_model" initialized
ERROR - 2022-03-15 05:03:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 05:03:39 --> Config Class Initialized
INFO - 2022-03-15 05:03:39 --> Hooks Class Initialized
DEBUG - 2022-03-15 05:03:39 --> UTF-8 Support Enabled
INFO - 2022-03-15 05:03:39 --> Utf8 Class Initialized
INFO - 2022-03-15 05:03:39 --> URI Class Initialized
INFO - 2022-03-15 05:03:39 --> Router Class Initialized
INFO - 2022-03-15 05:03:39 --> Output Class Initialized
INFO - 2022-03-15 05:03:39 --> Security Class Initialized
DEBUG - 2022-03-15 05:03:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 05:03:39 --> Input Class Initialized
INFO - 2022-03-15 05:03:39 --> Language Class Initialized
INFO - 2022-03-15 05:03:39 --> Loader Class Initialized
INFO - 2022-03-15 05:03:39 --> Helper loaded: url_helper
INFO - 2022-03-15 05:03:39 --> Helper loaded: form_helper
INFO - 2022-03-15 05:03:39 --> Helper loaded: common_helper
INFO - 2022-03-15 05:03:39 --> Database Driver Class Initialized
DEBUG - 2022-03-15 05:03:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 05:03:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 05:03:39 --> Controller Class Initialized
INFO - 2022-03-15 05:03:39 --> Form Validation Class Initialized
DEBUG - 2022-03-15 05:03:39 --> Encrypt Class Initialized
INFO - 2022-03-15 05:03:39 --> Model "Patient_model" initialized
INFO - 2022-03-15 05:03:39 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 05:03:39 --> Model "Prefix_master" initialized
INFO - 2022-03-15 05:03:39 --> Model "Users_model" initialized
INFO - 2022-03-15 05:03:39 --> Model "Hospital_model" initialized
INFO - 2022-03-15 05:03:39 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 05:03:39 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-15 05:03:39 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 05:03:39 --> Final output sent to browser
DEBUG - 2022-03-15 05:03:39 --> Total execution time: 0.0576
ERROR - 2022-03-15 05:03:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 05:03:40 --> Config Class Initialized
INFO - 2022-03-15 05:03:40 --> Hooks Class Initialized
DEBUG - 2022-03-15 05:03:40 --> UTF-8 Support Enabled
INFO - 2022-03-15 05:03:40 --> Utf8 Class Initialized
INFO - 2022-03-15 05:03:40 --> URI Class Initialized
INFO - 2022-03-15 05:03:40 --> Router Class Initialized
INFO - 2022-03-15 05:03:40 --> Output Class Initialized
INFO - 2022-03-15 05:03:40 --> Security Class Initialized
DEBUG - 2022-03-15 05:03:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 05:03:40 --> Input Class Initialized
INFO - 2022-03-15 05:03:40 --> Language Class Initialized
INFO - 2022-03-15 05:03:40 --> Loader Class Initialized
INFO - 2022-03-15 05:03:40 --> Helper loaded: url_helper
INFO - 2022-03-15 05:03:40 --> Helper loaded: form_helper
INFO - 2022-03-15 05:03:40 --> Helper loaded: common_helper
INFO - 2022-03-15 05:03:40 --> Database Driver Class Initialized
DEBUG - 2022-03-15 05:03:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 05:03:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 05:03:40 --> Controller Class Initialized
INFO - 2022-03-15 05:03:40 --> Form Validation Class Initialized
DEBUG - 2022-03-15 05:03:40 --> Encrypt Class Initialized
INFO - 2022-03-15 05:03:40 --> Model "Patient_model" initialized
INFO - 2022-03-15 05:03:40 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 05:03:40 --> Model "Prefix_master" initialized
INFO - 2022-03-15 05:03:40 --> Model "Users_model" initialized
INFO - 2022-03-15 05:03:40 --> Model "Hospital_model" initialized
ERROR - 2022-03-15 05:03:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 05:03:41 --> Config Class Initialized
INFO - 2022-03-15 05:03:41 --> Hooks Class Initialized
DEBUG - 2022-03-15 05:03:41 --> UTF-8 Support Enabled
INFO - 2022-03-15 05:03:41 --> Utf8 Class Initialized
INFO - 2022-03-15 05:03:41 --> URI Class Initialized
INFO - 2022-03-15 05:03:41 --> Router Class Initialized
INFO - 2022-03-15 05:03:41 --> Output Class Initialized
INFO - 2022-03-15 05:03:41 --> Security Class Initialized
DEBUG - 2022-03-15 05:03:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 05:03:41 --> Input Class Initialized
INFO - 2022-03-15 05:03:41 --> Language Class Initialized
INFO - 2022-03-15 05:03:41 --> Loader Class Initialized
INFO - 2022-03-15 05:03:41 --> Helper loaded: url_helper
INFO - 2022-03-15 05:03:41 --> Helper loaded: form_helper
INFO - 2022-03-15 05:03:41 --> Helper loaded: common_helper
INFO - 2022-03-15 05:03:41 --> Database Driver Class Initialized
DEBUG - 2022-03-15 05:03:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 05:03:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 05:03:41 --> Controller Class Initialized
INFO - 2022-03-15 05:03:41 --> Form Validation Class Initialized
DEBUG - 2022-03-15 05:03:41 --> Encrypt Class Initialized
INFO - 2022-03-15 05:03:41 --> Model "Patient_model" initialized
INFO - 2022-03-15 05:03:41 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 05:03:41 --> Model "Prefix_master" initialized
INFO - 2022-03-15 05:03:41 --> Model "Users_model" initialized
INFO - 2022-03-15 05:03:41 --> Model "Hospital_model" initialized
INFO - 2022-03-15 05:03:41 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 05:03:41 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-15 05:03:41 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 05:03:41 --> Final output sent to browser
DEBUG - 2022-03-15 05:03:41 --> Total execution time: 0.0743
ERROR - 2022-03-15 05:03:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 05:03:50 --> Config Class Initialized
INFO - 2022-03-15 05:03:50 --> Hooks Class Initialized
DEBUG - 2022-03-15 05:03:50 --> UTF-8 Support Enabled
INFO - 2022-03-15 05:03:50 --> Utf8 Class Initialized
INFO - 2022-03-15 05:03:50 --> URI Class Initialized
INFO - 2022-03-15 05:03:50 --> Router Class Initialized
INFO - 2022-03-15 05:03:50 --> Output Class Initialized
INFO - 2022-03-15 05:03:50 --> Security Class Initialized
DEBUG - 2022-03-15 05:03:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 05:03:50 --> Input Class Initialized
INFO - 2022-03-15 05:03:50 --> Language Class Initialized
INFO - 2022-03-15 05:03:50 --> Loader Class Initialized
INFO - 2022-03-15 05:03:50 --> Helper loaded: url_helper
INFO - 2022-03-15 05:03:50 --> Helper loaded: form_helper
INFO - 2022-03-15 05:03:50 --> Helper loaded: common_helper
INFO - 2022-03-15 05:03:50 --> Database Driver Class Initialized
DEBUG - 2022-03-15 05:03:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 05:03:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 05:03:50 --> Controller Class Initialized
INFO - 2022-03-15 05:03:50 --> Form Validation Class Initialized
DEBUG - 2022-03-15 05:03:50 --> Encrypt Class Initialized
INFO - 2022-03-15 05:03:50 --> Model "Patient_model" initialized
INFO - 2022-03-15 05:03:50 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 05:03:50 --> Model "Referredby_model" initialized
INFO - 2022-03-15 05:03:50 --> Model "Prefix_master" initialized
INFO - 2022-03-15 05:03:50 --> Model "Hospital_model" initialized
INFO - 2022-03-15 05:03:50 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 05:03:50 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-15 05:03:50 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 05:03:50 --> Final output sent to browser
DEBUG - 2022-03-15 05:03:50 --> Total execution time: 0.0831
ERROR - 2022-03-15 05:03:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 05:03:58 --> Config Class Initialized
INFO - 2022-03-15 05:03:58 --> Hooks Class Initialized
DEBUG - 2022-03-15 05:03:58 --> UTF-8 Support Enabled
INFO - 2022-03-15 05:03:58 --> Utf8 Class Initialized
INFO - 2022-03-15 05:03:58 --> URI Class Initialized
INFO - 2022-03-15 05:03:58 --> Router Class Initialized
INFO - 2022-03-15 05:03:58 --> Output Class Initialized
INFO - 2022-03-15 05:03:58 --> Security Class Initialized
DEBUG - 2022-03-15 05:03:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 05:03:58 --> Input Class Initialized
INFO - 2022-03-15 05:03:58 --> Language Class Initialized
INFO - 2022-03-15 05:03:58 --> Loader Class Initialized
INFO - 2022-03-15 05:03:58 --> Helper loaded: url_helper
INFO - 2022-03-15 05:03:59 --> Helper loaded: form_helper
INFO - 2022-03-15 05:03:59 --> Helper loaded: common_helper
INFO - 2022-03-15 05:03:59 --> Database Driver Class Initialized
DEBUG - 2022-03-15 05:03:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 05:03:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 05:03:59 --> Controller Class Initialized
INFO - 2022-03-15 05:03:59 --> Form Validation Class Initialized
DEBUG - 2022-03-15 05:03:59 --> Encrypt Class Initialized
INFO - 2022-03-15 05:03:59 --> Model "Patient_model" initialized
INFO - 2022-03-15 05:03:59 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 05:03:59 --> Model "Referredby_model" initialized
INFO - 2022-03-15 05:03:59 --> Model "Prefix_master" initialized
INFO - 2022-03-15 05:03:59 --> Model "Hospital_model" initialized
INFO - 2022-03-15 05:03:59 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 05:03:59 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-15 05:03:59 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 05:03:59 --> Final output sent to browser
DEBUG - 2022-03-15 05:03:59 --> Total execution time: 0.0609
ERROR - 2022-03-15 05:04:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 05:04:51 --> Config Class Initialized
INFO - 2022-03-15 05:04:51 --> Hooks Class Initialized
DEBUG - 2022-03-15 05:04:51 --> UTF-8 Support Enabled
INFO - 2022-03-15 05:04:51 --> Utf8 Class Initialized
INFO - 2022-03-15 05:04:51 --> URI Class Initialized
INFO - 2022-03-15 05:04:51 --> Router Class Initialized
INFO - 2022-03-15 05:04:51 --> Output Class Initialized
INFO - 2022-03-15 05:04:51 --> Security Class Initialized
DEBUG - 2022-03-15 05:04:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 05:04:51 --> Input Class Initialized
INFO - 2022-03-15 05:04:51 --> Language Class Initialized
INFO - 2022-03-15 05:04:51 --> Loader Class Initialized
INFO - 2022-03-15 05:04:51 --> Helper loaded: url_helper
INFO - 2022-03-15 05:04:51 --> Helper loaded: form_helper
INFO - 2022-03-15 05:04:51 --> Helper loaded: common_helper
INFO - 2022-03-15 05:04:51 --> Database Driver Class Initialized
DEBUG - 2022-03-15 05:04:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 05:04:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 05:04:51 --> Controller Class Initialized
INFO - 2022-03-15 05:04:51 --> Form Validation Class Initialized
DEBUG - 2022-03-15 05:04:51 --> Encrypt Class Initialized
INFO - 2022-03-15 05:04:51 --> Model "Patient_model" initialized
INFO - 2022-03-15 05:04:51 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 05:04:51 --> Model "Referredby_model" initialized
INFO - 2022-03-15 05:04:51 --> Model "Prefix_master" initialized
INFO - 2022-03-15 05:04:51 --> Model "Hospital_model" initialized
INFO - 2022-03-15 05:04:51 --> Upload Class Initialized
INFO - 2022-03-15 05:04:51 --> Final output sent to browser
DEBUG - 2022-03-15 05:04:51 --> Total execution time: 0.0350
ERROR - 2022-03-15 05:12:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 05:12:08 --> Config Class Initialized
INFO - 2022-03-15 05:12:08 --> Hooks Class Initialized
DEBUG - 2022-03-15 05:12:08 --> UTF-8 Support Enabled
INFO - 2022-03-15 05:12:08 --> Utf8 Class Initialized
INFO - 2022-03-15 05:12:08 --> URI Class Initialized
INFO - 2022-03-15 05:12:08 --> Router Class Initialized
INFO - 2022-03-15 05:12:08 --> Output Class Initialized
INFO - 2022-03-15 05:12:08 --> Security Class Initialized
DEBUG - 2022-03-15 05:12:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 05:12:08 --> Input Class Initialized
INFO - 2022-03-15 05:12:08 --> Language Class Initialized
INFO - 2022-03-15 05:12:08 --> Loader Class Initialized
INFO - 2022-03-15 05:12:08 --> Helper loaded: url_helper
INFO - 2022-03-15 05:12:08 --> Helper loaded: form_helper
INFO - 2022-03-15 05:12:08 --> Helper loaded: common_helper
INFO - 2022-03-15 05:12:08 --> Database Driver Class Initialized
DEBUG - 2022-03-15 05:12:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 05:12:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 05:12:08 --> Controller Class Initialized
INFO - 2022-03-15 05:12:08 --> Model "Referredby_model" initialized
INFO - 2022-03-15 05:12:08 --> Final output sent to browser
DEBUG - 2022-03-15 05:12:08 --> Total execution time: 0.0211
ERROR - 2022-03-15 05:12:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 05:12:28 --> Config Class Initialized
INFO - 2022-03-15 05:12:28 --> Hooks Class Initialized
DEBUG - 2022-03-15 05:12:28 --> UTF-8 Support Enabled
INFO - 2022-03-15 05:12:28 --> Utf8 Class Initialized
INFO - 2022-03-15 05:12:28 --> URI Class Initialized
INFO - 2022-03-15 05:12:28 --> Router Class Initialized
INFO - 2022-03-15 05:12:28 --> Output Class Initialized
INFO - 2022-03-15 05:12:28 --> Security Class Initialized
DEBUG - 2022-03-15 05:12:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 05:12:28 --> Input Class Initialized
INFO - 2022-03-15 05:12:28 --> Language Class Initialized
INFO - 2022-03-15 05:12:28 --> Loader Class Initialized
INFO - 2022-03-15 05:12:28 --> Helper loaded: url_helper
INFO - 2022-03-15 05:12:28 --> Helper loaded: form_helper
INFO - 2022-03-15 05:12:28 --> Helper loaded: common_helper
INFO - 2022-03-15 05:12:28 --> Database Driver Class Initialized
DEBUG - 2022-03-15 05:12:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 05:12:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 05:12:28 --> Controller Class Initialized
INFO - 2022-03-15 05:12:28 --> Model "Referredby_model" initialized
INFO - 2022-03-15 05:12:28 --> Final output sent to browser
DEBUG - 2022-03-15 05:12:28 --> Total execution time: 0.0179
ERROR - 2022-03-15 05:13:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 05:13:02 --> Config Class Initialized
INFO - 2022-03-15 05:13:02 --> Hooks Class Initialized
DEBUG - 2022-03-15 05:13:02 --> UTF-8 Support Enabled
INFO - 2022-03-15 05:13:02 --> Utf8 Class Initialized
INFO - 2022-03-15 05:13:02 --> URI Class Initialized
INFO - 2022-03-15 05:13:02 --> Router Class Initialized
INFO - 2022-03-15 05:13:02 --> Output Class Initialized
INFO - 2022-03-15 05:13:02 --> Security Class Initialized
DEBUG - 2022-03-15 05:13:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 05:13:02 --> Input Class Initialized
INFO - 2022-03-15 05:13:02 --> Language Class Initialized
INFO - 2022-03-15 05:13:02 --> Loader Class Initialized
INFO - 2022-03-15 05:13:02 --> Helper loaded: url_helper
INFO - 2022-03-15 05:13:02 --> Helper loaded: form_helper
INFO - 2022-03-15 05:13:02 --> Helper loaded: common_helper
INFO - 2022-03-15 05:13:02 --> Database Driver Class Initialized
DEBUG - 2022-03-15 05:13:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 05:13:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 05:13:02 --> Controller Class Initialized
INFO - 2022-03-15 05:13:02 --> Form Validation Class Initialized
DEBUG - 2022-03-15 05:13:02 --> Encrypt Class Initialized
INFO - 2022-03-15 05:13:02 --> Model "Patient_model" initialized
INFO - 2022-03-15 05:13:02 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 05:13:02 --> Model "Referredby_model" initialized
INFO - 2022-03-15 05:13:02 --> Model "Prefix_master" initialized
INFO - 2022-03-15 05:13:02 --> Model "Hospital_model" initialized
INFO - 2022-03-15 05:13:02 --> Final output sent to browser
DEBUG - 2022-03-15 05:13:02 --> Total execution time: 0.0328
ERROR - 2022-03-15 05:13:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 05:13:35 --> Config Class Initialized
INFO - 2022-03-15 05:13:35 --> Hooks Class Initialized
DEBUG - 2022-03-15 05:13:35 --> UTF-8 Support Enabled
INFO - 2022-03-15 05:13:35 --> Utf8 Class Initialized
INFO - 2022-03-15 05:13:35 --> URI Class Initialized
DEBUG - 2022-03-15 05:13:35 --> No URI present. Default controller set.
INFO - 2022-03-15 05:13:35 --> Router Class Initialized
INFO - 2022-03-15 05:13:35 --> Output Class Initialized
INFO - 2022-03-15 05:13:35 --> Security Class Initialized
DEBUG - 2022-03-15 05:13:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 05:13:35 --> Input Class Initialized
INFO - 2022-03-15 05:13:35 --> Language Class Initialized
INFO - 2022-03-15 05:13:35 --> Loader Class Initialized
INFO - 2022-03-15 05:13:35 --> Helper loaded: url_helper
INFO - 2022-03-15 05:13:35 --> Helper loaded: form_helper
INFO - 2022-03-15 05:13:35 --> Helper loaded: common_helper
INFO - 2022-03-15 05:13:35 --> Database Driver Class Initialized
DEBUG - 2022-03-15 05:13:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 05:13:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 05:13:35 --> Controller Class Initialized
INFO - 2022-03-15 05:13:35 --> Form Validation Class Initialized
DEBUG - 2022-03-15 05:13:35 --> Encrypt Class Initialized
DEBUG - 2022-03-15 05:13:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-15 05:13:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-15 05:13:35 --> Email Class Initialized
INFO - 2022-03-15 05:13:35 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-15 05:13:35 --> Calendar Class Initialized
INFO - 2022-03-15 05:13:35 --> Model "Login_model" initialized
INFO - 2022-03-15 05:13:35 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-15 05:13:35 --> Final output sent to browser
DEBUG - 2022-03-15 05:13:35 --> Total execution time: 0.0907
ERROR - 2022-03-15 05:14:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 05:14:33 --> Config Class Initialized
INFO - 2022-03-15 05:14:33 --> Hooks Class Initialized
DEBUG - 2022-03-15 05:14:33 --> UTF-8 Support Enabled
INFO - 2022-03-15 05:14:33 --> Utf8 Class Initialized
INFO - 2022-03-15 05:14:33 --> URI Class Initialized
INFO - 2022-03-15 05:14:33 --> Router Class Initialized
INFO - 2022-03-15 05:14:33 --> Output Class Initialized
INFO - 2022-03-15 05:14:33 --> Security Class Initialized
DEBUG - 2022-03-15 05:14:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 05:14:33 --> Input Class Initialized
INFO - 2022-03-15 05:14:33 --> Language Class Initialized
INFO - 2022-03-15 05:14:33 --> Loader Class Initialized
INFO - 2022-03-15 05:14:33 --> Helper loaded: url_helper
INFO - 2022-03-15 05:14:33 --> Helper loaded: form_helper
INFO - 2022-03-15 05:14:33 --> Helper loaded: common_helper
INFO - 2022-03-15 05:14:33 --> Database Driver Class Initialized
DEBUG - 2022-03-15 05:14:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 05:14:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 05:14:33 --> Controller Class Initialized
INFO - 2022-03-15 05:14:33 --> Form Validation Class Initialized
DEBUG - 2022-03-15 05:14:33 --> Encrypt Class Initialized
DEBUG - 2022-03-15 05:14:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-15 05:14:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-15 05:14:33 --> Email Class Initialized
INFO - 2022-03-15 05:14:33 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-15 05:14:33 --> Calendar Class Initialized
INFO - 2022-03-15 05:14:33 --> Model "Login_model" initialized
INFO - 2022-03-15 05:14:33 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-03-15 05:14:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 05:14:33 --> Config Class Initialized
INFO - 2022-03-15 05:14:33 --> Hooks Class Initialized
DEBUG - 2022-03-15 05:14:33 --> UTF-8 Support Enabled
INFO - 2022-03-15 05:14:33 --> Utf8 Class Initialized
INFO - 2022-03-15 05:14:33 --> URI Class Initialized
INFO - 2022-03-15 05:14:33 --> Router Class Initialized
INFO - 2022-03-15 05:14:33 --> Output Class Initialized
INFO - 2022-03-15 05:14:33 --> Security Class Initialized
DEBUG - 2022-03-15 05:14:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 05:14:33 --> Input Class Initialized
INFO - 2022-03-15 05:14:33 --> Language Class Initialized
INFO - 2022-03-15 05:14:33 --> Loader Class Initialized
INFO - 2022-03-15 05:14:33 --> Helper loaded: url_helper
INFO - 2022-03-15 05:14:33 --> Helper loaded: form_helper
INFO - 2022-03-15 05:14:33 --> Helper loaded: common_helper
INFO - 2022-03-15 05:14:33 --> Database Driver Class Initialized
DEBUG - 2022-03-15 05:14:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 05:14:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 05:14:33 --> Controller Class Initialized
INFO - 2022-03-15 05:14:33 --> Form Validation Class Initialized
DEBUG - 2022-03-15 05:14:33 --> Encrypt Class Initialized
DEBUG - 2022-03-15 05:14:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-15 05:14:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-15 05:14:33 --> Email Class Initialized
INFO - 2022-03-15 05:14:33 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-15 05:14:33 --> Calendar Class Initialized
INFO - 2022-03-15 05:14:33 --> Model "Login_model" initialized
INFO - 2022-03-15 05:14:33 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-15 05:14:33 --> Final output sent to browser
DEBUG - 2022-03-15 05:14:33 --> Total execution time: 0.0259
ERROR - 2022-03-15 05:15:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 05:15:24 --> Config Class Initialized
INFO - 2022-03-15 05:15:24 --> Hooks Class Initialized
DEBUG - 2022-03-15 05:15:24 --> UTF-8 Support Enabled
INFO - 2022-03-15 05:15:24 --> Utf8 Class Initialized
INFO - 2022-03-15 05:15:24 --> URI Class Initialized
INFO - 2022-03-15 05:15:24 --> Router Class Initialized
INFO - 2022-03-15 05:15:24 --> Output Class Initialized
INFO - 2022-03-15 05:15:24 --> Security Class Initialized
DEBUG - 2022-03-15 05:15:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 05:15:24 --> Input Class Initialized
INFO - 2022-03-15 05:15:24 --> Language Class Initialized
INFO - 2022-03-15 05:15:24 --> Loader Class Initialized
INFO - 2022-03-15 05:15:24 --> Helper loaded: url_helper
INFO - 2022-03-15 05:15:24 --> Helper loaded: form_helper
INFO - 2022-03-15 05:15:24 --> Helper loaded: common_helper
INFO - 2022-03-15 05:15:24 --> Database Driver Class Initialized
DEBUG - 2022-03-15 05:15:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 05:15:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 05:15:24 --> Controller Class Initialized
INFO - 2022-03-15 05:15:24 --> Form Validation Class Initialized
DEBUG - 2022-03-15 05:15:24 --> Encrypt Class Initialized
DEBUG - 2022-03-15 05:15:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-15 05:15:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-15 05:15:24 --> Email Class Initialized
INFO - 2022-03-15 05:15:24 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-15 05:15:24 --> Calendar Class Initialized
INFO - 2022-03-15 05:15:24 --> Model "Login_model" initialized
INFO - 2022-03-15 05:15:24 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-03-15 05:15:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 05:15:25 --> Config Class Initialized
INFO - 2022-03-15 05:15:25 --> Hooks Class Initialized
DEBUG - 2022-03-15 05:15:25 --> UTF-8 Support Enabled
INFO - 2022-03-15 05:15:25 --> Utf8 Class Initialized
INFO - 2022-03-15 05:15:25 --> URI Class Initialized
INFO - 2022-03-15 05:15:25 --> Router Class Initialized
INFO - 2022-03-15 05:15:25 --> Output Class Initialized
INFO - 2022-03-15 05:15:25 --> Security Class Initialized
DEBUG - 2022-03-15 05:15:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 05:15:25 --> Input Class Initialized
INFO - 2022-03-15 05:15:25 --> Language Class Initialized
INFO - 2022-03-15 05:15:25 --> Loader Class Initialized
INFO - 2022-03-15 05:15:25 --> Helper loaded: url_helper
INFO - 2022-03-15 05:15:25 --> Helper loaded: form_helper
INFO - 2022-03-15 05:15:25 --> Helper loaded: common_helper
INFO - 2022-03-15 05:15:25 --> Database Driver Class Initialized
DEBUG - 2022-03-15 05:15:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 05:15:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 05:15:25 --> Controller Class Initialized
INFO - 2022-03-15 05:15:25 --> Form Validation Class Initialized
DEBUG - 2022-03-15 05:15:25 --> Encrypt Class Initialized
INFO - 2022-03-15 05:15:25 --> Model "Login_model" initialized
INFO - 2022-03-15 05:15:25 --> Model "Dashboard_model" initialized
INFO - 2022-03-15 05:15:25 --> Model "Case_model" initialized
INFO - 2022-03-15 05:15:25 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 05:15:25 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2022-03-15 05:15:25 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 05:15:25 --> Final output sent to browser
DEBUG - 2022-03-15 05:15:25 --> Total execution time: 0.1817
ERROR - 2022-03-15 05:15:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 05:15:40 --> Config Class Initialized
INFO - 2022-03-15 05:15:40 --> Hooks Class Initialized
DEBUG - 2022-03-15 05:15:40 --> UTF-8 Support Enabled
INFO - 2022-03-15 05:15:40 --> Utf8 Class Initialized
INFO - 2022-03-15 05:15:40 --> URI Class Initialized
INFO - 2022-03-15 05:15:40 --> Router Class Initialized
INFO - 2022-03-15 05:15:40 --> Output Class Initialized
INFO - 2022-03-15 05:15:40 --> Security Class Initialized
DEBUG - 2022-03-15 05:15:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 05:15:40 --> Input Class Initialized
INFO - 2022-03-15 05:15:40 --> Language Class Initialized
INFO - 2022-03-15 05:15:40 --> Loader Class Initialized
INFO - 2022-03-15 05:15:40 --> Helper loaded: url_helper
INFO - 2022-03-15 05:15:40 --> Helper loaded: form_helper
INFO - 2022-03-15 05:15:40 --> Helper loaded: common_helper
INFO - 2022-03-15 05:15:40 --> Database Driver Class Initialized
DEBUG - 2022-03-15 05:15:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 05:15:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 05:15:40 --> Controller Class Initialized
INFO - 2022-03-15 05:15:40 --> Form Validation Class Initialized
DEBUG - 2022-03-15 05:15:40 --> Encrypt Class Initialized
INFO - 2022-03-15 05:15:40 --> Model "Patient_model" initialized
INFO - 2022-03-15 05:15:40 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 05:15:40 --> Model "Referredby_model" initialized
INFO - 2022-03-15 05:15:40 --> Model "Prefix_master" initialized
INFO - 2022-03-15 05:15:40 --> Model "Hospital_model" initialized
INFO - 2022-03-15 05:15:40 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 05:15:40 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-15 05:15:40 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 05:15:40 --> Final output sent to browser
DEBUG - 2022-03-15 05:15:40 --> Total execution time: 0.0289
ERROR - 2022-03-15 05:16:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 05:16:43 --> Config Class Initialized
INFO - 2022-03-15 05:16:43 --> Hooks Class Initialized
DEBUG - 2022-03-15 05:16:43 --> UTF-8 Support Enabled
INFO - 2022-03-15 05:16:43 --> Utf8 Class Initialized
INFO - 2022-03-15 05:16:43 --> URI Class Initialized
INFO - 2022-03-15 05:16:43 --> Router Class Initialized
INFO - 2022-03-15 05:16:43 --> Output Class Initialized
INFO - 2022-03-15 05:16:43 --> Security Class Initialized
DEBUG - 2022-03-15 05:16:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 05:16:43 --> Input Class Initialized
INFO - 2022-03-15 05:16:43 --> Language Class Initialized
INFO - 2022-03-15 05:16:43 --> Loader Class Initialized
INFO - 2022-03-15 05:16:43 --> Helper loaded: url_helper
INFO - 2022-03-15 05:16:43 --> Helper loaded: form_helper
INFO - 2022-03-15 05:16:43 --> Helper loaded: common_helper
INFO - 2022-03-15 05:16:43 --> Database Driver Class Initialized
DEBUG - 2022-03-15 05:16:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 05:16:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 05:16:43 --> Controller Class Initialized
INFO - 2022-03-15 05:16:43 --> Form Validation Class Initialized
DEBUG - 2022-03-15 05:16:43 --> Encrypt Class Initialized
INFO - 2022-03-15 05:16:43 --> Model "Patient_model" initialized
INFO - 2022-03-15 05:16:43 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 05:16:43 --> Model "Referredby_model" initialized
INFO - 2022-03-15 05:16:43 --> Model "Prefix_master" initialized
INFO - 2022-03-15 05:16:43 --> Model "Hospital_model" initialized
INFO - 2022-03-15 05:16:43 --> Final output sent to browser
DEBUG - 2022-03-15 05:16:43 --> Total execution time: 0.0360
ERROR - 2022-03-15 05:18:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 05:18:30 --> Config Class Initialized
INFO - 2022-03-15 05:18:30 --> Hooks Class Initialized
DEBUG - 2022-03-15 05:18:30 --> UTF-8 Support Enabled
INFO - 2022-03-15 05:18:30 --> Utf8 Class Initialized
INFO - 2022-03-15 05:18:30 --> URI Class Initialized
DEBUG - 2022-03-15 05:18:30 --> No URI present. Default controller set.
INFO - 2022-03-15 05:18:30 --> Router Class Initialized
INFO - 2022-03-15 05:18:30 --> Output Class Initialized
INFO - 2022-03-15 05:18:30 --> Security Class Initialized
DEBUG - 2022-03-15 05:18:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 05:18:30 --> Input Class Initialized
INFO - 2022-03-15 05:18:30 --> Language Class Initialized
INFO - 2022-03-15 05:18:30 --> Loader Class Initialized
INFO - 2022-03-15 05:18:30 --> Helper loaded: url_helper
INFO - 2022-03-15 05:18:30 --> Helper loaded: form_helper
INFO - 2022-03-15 05:18:30 --> Helper loaded: common_helper
INFO - 2022-03-15 05:18:30 --> Database Driver Class Initialized
DEBUG - 2022-03-15 05:18:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 05:18:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 05:18:30 --> Controller Class Initialized
INFO - 2022-03-15 05:18:30 --> Form Validation Class Initialized
DEBUG - 2022-03-15 05:18:30 --> Encrypt Class Initialized
DEBUG - 2022-03-15 05:18:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-15 05:18:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-15 05:18:30 --> Email Class Initialized
INFO - 2022-03-15 05:18:30 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-15 05:18:30 --> Calendar Class Initialized
INFO - 2022-03-15 05:18:30 --> Model "Login_model" initialized
INFO - 2022-03-15 05:18:30 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-15 05:18:30 --> Final output sent to browser
DEBUG - 2022-03-15 05:18:30 --> Total execution time: 0.0231
ERROR - 2022-03-15 05:21:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 05:21:58 --> Config Class Initialized
INFO - 2022-03-15 05:21:58 --> Hooks Class Initialized
DEBUG - 2022-03-15 05:21:58 --> UTF-8 Support Enabled
INFO - 2022-03-15 05:21:58 --> Utf8 Class Initialized
INFO - 2022-03-15 05:21:58 --> URI Class Initialized
INFO - 2022-03-15 05:21:58 --> Router Class Initialized
INFO - 2022-03-15 05:21:58 --> Output Class Initialized
INFO - 2022-03-15 05:21:58 --> Security Class Initialized
DEBUG - 2022-03-15 05:21:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 05:21:58 --> Input Class Initialized
INFO - 2022-03-15 05:21:58 --> Language Class Initialized
INFO - 2022-03-15 05:21:58 --> Loader Class Initialized
INFO - 2022-03-15 05:21:58 --> Helper loaded: url_helper
INFO - 2022-03-15 05:21:58 --> Helper loaded: form_helper
INFO - 2022-03-15 05:21:58 --> Helper loaded: common_helper
INFO - 2022-03-15 05:21:58 --> Database Driver Class Initialized
DEBUG - 2022-03-15 05:21:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 05:21:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 05:21:58 --> Controller Class Initialized
INFO - 2022-03-15 05:21:58 --> Form Validation Class Initialized
DEBUG - 2022-03-15 05:21:58 --> Encrypt Class Initialized
INFO - 2022-03-15 05:21:58 --> Model "Patient_model" initialized
INFO - 2022-03-15 05:21:58 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 05:21:58 --> Model "Referredby_model" initialized
INFO - 2022-03-15 05:21:58 --> Model "Prefix_master" initialized
INFO - 2022-03-15 05:21:58 --> Model "Hospital_model" initialized
ERROR - 2022-03-15 05:21:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 05:21:58 --> Config Class Initialized
INFO - 2022-03-15 05:21:58 --> Hooks Class Initialized
DEBUG - 2022-03-15 05:21:58 --> UTF-8 Support Enabled
INFO - 2022-03-15 05:21:58 --> Utf8 Class Initialized
INFO - 2022-03-15 05:21:58 --> URI Class Initialized
INFO - 2022-03-15 05:21:58 --> Router Class Initialized
INFO - 2022-03-15 05:21:58 --> Output Class Initialized
INFO - 2022-03-15 05:21:58 --> Security Class Initialized
DEBUG - 2022-03-15 05:21:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 05:21:58 --> Input Class Initialized
INFO - 2022-03-15 05:21:58 --> Language Class Initialized
INFO - 2022-03-15 05:21:58 --> Loader Class Initialized
INFO - 2022-03-15 05:21:58 --> Helper loaded: url_helper
INFO - 2022-03-15 05:21:58 --> Helper loaded: form_helper
INFO - 2022-03-15 05:21:58 --> Helper loaded: common_helper
INFO - 2022-03-15 05:21:58 --> Database Driver Class Initialized
DEBUG - 2022-03-15 05:21:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 05:21:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 05:21:58 --> Controller Class Initialized
INFO - 2022-03-15 05:21:58 --> Form Validation Class Initialized
DEBUG - 2022-03-15 05:21:58 --> Encrypt Class Initialized
INFO - 2022-03-15 05:21:58 --> Model "Patient_model" initialized
INFO - 2022-03-15 05:21:58 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 05:21:58 --> Model "Referredby_model" initialized
INFO - 2022-03-15 05:21:58 --> Model "Prefix_master" initialized
INFO - 2022-03-15 05:21:58 --> Model "Hospital_model" initialized
INFO - 2022-03-15 05:21:58 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 05:21:58 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-15 05:21:58 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 05:21:58 --> Final output sent to browser
DEBUG - 2022-03-15 05:21:58 --> Total execution time: 0.0515
ERROR - 2022-03-15 05:22:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 05:22:00 --> Config Class Initialized
INFO - 2022-03-15 05:22:00 --> Hooks Class Initialized
DEBUG - 2022-03-15 05:22:00 --> UTF-8 Support Enabled
INFO - 2022-03-15 05:22:00 --> Utf8 Class Initialized
INFO - 2022-03-15 05:22:00 --> URI Class Initialized
INFO - 2022-03-15 05:22:00 --> Router Class Initialized
INFO - 2022-03-15 05:22:00 --> Output Class Initialized
INFO - 2022-03-15 05:22:00 --> Security Class Initialized
DEBUG - 2022-03-15 05:22:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 05:22:00 --> Input Class Initialized
INFO - 2022-03-15 05:22:00 --> Language Class Initialized
INFO - 2022-03-15 05:22:00 --> Loader Class Initialized
INFO - 2022-03-15 05:22:00 --> Helper loaded: url_helper
INFO - 2022-03-15 05:22:00 --> Helper loaded: form_helper
INFO - 2022-03-15 05:22:00 --> Helper loaded: common_helper
INFO - 2022-03-15 05:22:00 --> Database Driver Class Initialized
DEBUG - 2022-03-15 05:22:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 05:22:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 05:22:00 --> Controller Class Initialized
INFO - 2022-03-15 05:22:00 --> Form Validation Class Initialized
DEBUG - 2022-03-15 05:22:00 --> Encrypt Class Initialized
INFO - 2022-03-15 05:22:00 --> Model "Patient_model" initialized
INFO - 2022-03-15 05:22:00 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 05:22:00 --> Model "Referredby_model" initialized
INFO - 2022-03-15 05:22:00 --> Model "Prefix_master" initialized
INFO - 2022-03-15 05:22:00 --> Model "Hospital_model" initialized
ERROR - 2022-03-15 05:22:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 05:22:00 --> Config Class Initialized
INFO - 2022-03-15 05:22:00 --> Hooks Class Initialized
DEBUG - 2022-03-15 05:22:00 --> UTF-8 Support Enabled
INFO - 2022-03-15 05:22:00 --> Utf8 Class Initialized
INFO - 2022-03-15 05:22:00 --> URI Class Initialized
INFO - 2022-03-15 05:22:00 --> Router Class Initialized
INFO - 2022-03-15 05:22:00 --> Output Class Initialized
INFO - 2022-03-15 05:22:00 --> Security Class Initialized
DEBUG - 2022-03-15 05:22:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 05:22:00 --> Input Class Initialized
INFO - 2022-03-15 05:22:00 --> Language Class Initialized
INFO - 2022-03-15 05:22:00 --> Loader Class Initialized
INFO - 2022-03-15 05:22:00 --> Helper loaded: url_helper
INFO - 2022-03-15 05:22:00 --> Helper loaded: form_helper
INFO - 2022-03-15 05:22:00 --> Helper loaded: common_helper
INFO - 2022-03-15 05:22:00 --> Database Driver Class Initialized
DEBUG - 2022-03-15 05:22:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 05:22:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 05:22:00 --> Controller Class Initialized
INFO - 2022-03-15 05:22:00 --> Form Validation Class Initialized
DEBUG - 2022-03-15 05:22:00 --> Encrypt Class Initialized
INFO - 2022-03-15 05:22:00 --> Model "Patient_model" initialized
INFO - 2022-03-15 05:22:00 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 05:22:00 --> Model "Referredby_model" initialized
INFO - 2022-03-15 05:22:00 --> Model "Prefix_master" initialized
INFO - 2022-03-15 05:22:00 --> Model "Hospital_model" initialized
INFO - 2022-03-15 05:22:00 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 05:22:00 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-15 05:22:00 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 05:22:00 --> Final output sent to browser
DEBUG - 2022-03-15 05:22:00 --> Total execution time: 0.0547
ERROR - 2022-03-15 05:22:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 05:22:01 --> Config Class Initialized
INFO - 2022-03-15 05:22:01 --> Hooks Class Initialized
DEBUG - 2022-03-15 05:22:01 --> UTF-8 Support Enabled
INFO - 2022-03-15 05:22:01 --> Utf8 Class Initialized
INFO - 2022-03-15 05:22:01 --> URI Class Initialized
INFO - 2022-03-15 05:22:01 --> Router Class Initialized
INFO - 2022-03-15 05:22:01 --> Output Class Initialized
INFO - 2022-03-15 05:22:01 --> Security Class Initialized
DEBUG - 2022-03-15 05:22:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 05:22:01 --> Input Class Initialized
INFO - 2022-03-15 05:22:01 --> Language Class Initialized
INFO - 2022-03-15 05:22:01 --> Loader Class Initialized
INFO - 2022-03-15 05:22:01 --> Helper loaded: url_helper
INFO - 2022-03-15 05:22:01 --> Helper loaded: form_helper
INFO - 2022-03-15 05:22:01 --> Helper loaded: common_helper
INFO - 2022-03-15 05:22:01 --> Database Driver Class Initialized
DEBUG - 2022-03-15 05:22:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 05:22:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 05:22:01 --> Controller Class Initialized
INFO - 2022-03-15 05:22:01 --> Form Validation Class Initialized
DEBUG - 2022-03-15 05:22:01 --> Encrypt Class Initialized
INFO - 2022-03-15 05:22:01 --> Model "Patient_model" initialized
INFO - 2022-03-15 05:22:01 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 05:22:01 --> Model "Prefix_master" initialized
INFO - 2022-03-15 05:22:01 --> Model "Users_model" initialized
INFO - 2022-03-15 05:22:01 --> Model "Hospital_model" initialized
INFO - 2022-03-15 05:22:01 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 05:22:01 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-15 05:22:01 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 05:22:01 --> Final output sent to browser
DEBUG - 2022-03-15 05:22:01 --> Total execution time: 0.0633
ERROR - 2022-03-15 05:23:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 05:23:32 --> Config Class Initialized
INFO - 2022-03-15 05:23:32 --> Hooks Class Initialized
DEBUG - 2022-03-15 05:23:32 --> UTF-8 Support Enabled
INFO - 2022-03-15 05:23:32 --> Utf8 Class Initialized
INFO - 2022-03-15 05:23:32 --> URI Class Initialized
INFO - 2022-03-15 05:23:32 --> Router Class Initialized
INFO - 2022-03-15 05:23:32 --> Output Class Initialized
INFO - 2022-03-15 05:23:32 --> Security Class Initialized
DEBUG - 2022-03-15 05:23:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 05:23:32 --> Input Class Initialized
INFO - 2022-03-15 05:23:32 --> Language Class Initialized
INFO - 2022-03-15 05:23:32 --> Loader Class Initialized
INFO - 2022-03-15 05:23:32 --> Helper loaded: url_helper
INFO - 2022-03-15 05:23:32 --> Helper loaded: form_helper
INFO - 2022-03-15 05:23:32 --> Helper loaded: common_helper
INFO - 2022-03-15 05:23:32 --> Database Driver Class Initialized
DEBUG - 2022-03-15 05:23:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 05:23:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 05:23:32 --> Controller Class Initialized
INFO - 2022-03-15 05:23:32 --> Model "Referredby_model" initialized
INFO - 2022-03-15 05:23:32 --> Final output sent to browser
DEBUG - 2022-03-15 05:23:32 --> Total execution time: 0.0176
ERROR - 2022-03-15 05:23:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 05:23:36 --> Config Class Initialized
INFO - 2022-03-15 05:23:36 --> Hooks Class Initialized
DEBUG - 2022-03-15 05:23:36 --> UTF-8 Support Enabled
INFO - 2022-03-15 05:23:36 --> Utf8 Class Initialized
INFO - 2022-03-15 05:23:36 --> URI Class Initialized
INFO - 2022-03-15 05:23:36 --> Router Class Initialized
INFO - 2022-03-15 05:23:36 --> Output Class Initialized
INFO - 2022-03-15 05:23:36 --> Security Class Initialized
DEBUG - 2022-03-15 05:23:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 05:23:36 --> Input Class Initialized
INFO - 2022-03-15 05:23:36 --> Language Class Initialized
INFO - 2022-03-15 05:23:36 --> Loader Class Initialized
INFO - 2022-03-15 05:23:36 --> Helper loaded: url_helper
INFO - 2022-03-15 05:23:36 --> Helper loaded: form_helper
INFO - 2022-03-15 05:23:36 --> Helper loaded: common_helper
INFO - 2022-03-15 05:23:36 --> Database Driver Class Initialized
DEBUG - 2022-03-15 05:23:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 05:23:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 05:23:36 --> Controller Class Initialized
INFO - 2022-03-15 05:23:36 --> Model "Referredby_model" initialized
INFO - 2022-03-15 05:23:36 --> Final output sent to browser
DEBUG - 2022-03-15 05:23:36 --> Total execution time: 0.0174
ERROR - 2022-03-15 05:24:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 05:24:00 --> Config Class Initialized
INFO - 2022-03-15 05:24:00 --> Hooks Class Initialized
DEBUG - 2022-03-15 05:24:00 --> UTF-8 Support Enabled
INFO - 2022-03-15 05:24:00 --> Utf8 Class Initialized
INFO - 2022-03-15 05:24:00 --> URI Class Initialized
INFO - 2022-03-15 05:24:00 --> Router Class Initialized
INFO - 2022-03-15 05:24:00 --> Output Class Initialized
INFO - 2022-03-15 05:24:00 --> Security Class Initialized
DEBUG - 2022-03-15 05:24:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 05:24:00 --> Input Class Initialized
INFO - 2022-03-15 05:24:00 --> Language Class Initialized
INFO - 2022-03-15 05:24:00 --> Loader Class Initialized
INFO - 2022-03-15 05:24:00 --> Helper loaded: url_helper
INFO - 2022-03-15 05:24:00 --> Helper loaded: form_helper
INFO - 2022-03-15 05:24:00 --> Helper loaded: common_helper
INFO - 2022-03-15 05:24:00 --> Database Driver Class Initialized
DEBUG - 2022-03-15 05:24:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 05:24:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 05:24:00 --> Controller Class Initialized
INFO - 2022-03-15 05:24:00 --> Model "Referredby_model" initialized
INFO - 2022-03-15 05:24:00 --> Final output sent to browser
DEBUG - 2022-03-15 05:24:00 --> Total execution time: 0.0569
ERROR - 2022-03-15 05:27:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 05:27:10 --> Config Class Initialized
INFO - 2022-03-15 05:27:10 --> Hooks Class Initialized
DEBUG - 2022-03-15 05:27:10 --> UTF-8 Support Enabled
INFO - 2022-03-15 05:27:10 --> Utf8 Class Initialized
INFO - 2022-03-15 05:27:10 --> URI Class Initialized
INFO - 2022-03-15 05:27:10 --> Router Class Initialized
INFO - 2022-03-15 05:27:10 --> Output Class Initialized
INFO - 2022-03-15 05:27:10 --> Security Class Initialized
DEBUG - 2022-03-15 05:27:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 05:27:10 --> Input Class Initialized
INFO - 2022-03-15 05:27:10 --> Language Class Initialized
INFO - 2022-03-15 05:27:10 --> Loader Class Initialized
INFO - 2022-03-15 05:27:10 --> Helper loaded: url_helper
INFO - 2022-03-15 05:27:10 --> Helper loaded: form_helper
INFO - 2022-03-15 05:27:10 --> Helper loaded: common_helper
INFO - 2022-03-15 05:27:10 --> Database Driver Class Initialized
DEBUG - 2022-03-15 05:27:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 05:27:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 05:27:10 --> Controller Class Initialized
INFO - 2022-03-15 05:27:10 --> Form Validation Class Initialized
DEBUG - 2022-03-15 05:27:10 --> Encrypt Class Initialized
INFO - 2022-03-15 05:27:10 --> Model "Patient_model" initialized
INFO - 2022-03-15 05:27:10 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 05:27:10 --> Model "Prefix_master" initialized
INFO - 2022-03-15 05:27:10 --> Model "Users_model" initialized
INFO - 2022-03-15 05:27:10 --> Model "Hospital_model" initialized
ERROR - 2022-03-15 05:27:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 05:27:11 --> Config Class Initialized
INFO - 2022-03-15 05:27:11 --> Hooks Class Initialized
DEBUG - 2022-03-15 05:27:11 --> UTF-8 Support Enabled
INFO - 2022-03-15 05:27:11 --> Utf8 Class Initialized
INFO - 2022-03-15 05:27:11 --> URI Class Initialized
INFO - 2022-03-15 05:27:11 --> Router Class Initialized
INFO - 2022-03-15 05:27:11 --> Output Class Initialized
INFO - 2022-03-15 05:27:11 --> Security Class Initialized
DEBUG - 2022-03-15 05:27:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 05:27:11 --> Input Class Initialized
INFO - 2022-03-15 05:27:11 --> Language Class Initialized
INFO - 2022-03-15 05:27:11 --> Loader Class Initialized
INFO - 2022-03-15 05:27:11 --> Helper loaded: url_helper
INFO - 2022-03-15 05:27:11 --> Helper loaded: form_helper
INFO - 2022-03-15 05:27:11 --> Helper loaded: common_helper
INFO - 2022-03-15 05:27:11 --> Database Driver Class Initialized
DEBUG - 2022-03-15 05:27:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 05:27:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 05:27:11 --> Controller Class Initialized
INFO - 2022-03-15 05:27:11 --> Form Validation Class Initialized
DEBUG - 2022-03-15 05:27:11 --> Encrypt Class Initialized
INFO - 2022-03-15 05:27:11 --> Model "Patient_model" initialized
INFO - 2022-03-15 05:27:11 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 05:27:11 --> Model "Prefix_master" initialized
INFO - 2022-03-15 05:27:11 --> Model "Users_model" initialized
INFO - 2022-03-15 05:27:11 --> Model "Hospital_model" initialized
INFO - 2022-03-15 05:27:11 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 05:27:11 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-15 05:27:11 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 05:27:11 --> Final output sent to browser
DEBUG - 2022-03-15 05:27:11 --> Total execution time: 0.0642
ERROR - 2022-03-15 05:30:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 05:30:22 --> Config Class Initialized
INFO - 2022-03-15 05:30:22 --> Hooks Class Initialized
DEBUG - 2022-03-15 05:30:22 --> UTF-8 Support Enabled
INFO - 2022-03-15 05:30:22 --> Utf8 Class Initialized
INFO - 2022-03-15 05:30:22 --> URI Class Initialized
INFO - 2022-03-15 05:30:22 --> Router Class Initialized
INFO - 2022-03-15 05:30:22 --> Output Class Initialized
INFO - 2022-03-15 05:30:22 --> Security Class Initialized
DEBUG - 2022-03-15 05:30:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 05:30:22 --> Input Class Initialized
INFO - 2022-03-15 05:30:22 --> Language Class Initialized
INFO - 2022-03-15 05:30:22 --> Loader Class Initialized
INFO - 2022-03-15 05:30:22 --> Helper loaded: url_helper
INFO - 2022-03-15 05:30:22 --> Helper loaded: form_helper
INFO - 2022-03-15 05:30:22 --> Helper loaded: common_helper
INFO - 2022-03-15 05:30:22 --> Database Driver Class Initialized
DEBUG - 2022-03-15 05:30:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 05:30:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 05:30:22 --> Controller Class Initialized
INFO - 2022-03-15 05:30:22 --> Form Validation Class Initialized
DEBUG - 2022-03-15 05:30:22 --> Encrypt Class Initialized
INFO - 2022-03-15 05:30:22 --> Model "Patient_model" initialized
INFO - 2022-03-15 05:30:22 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 05:30:22 --> Model "Prefix_master" initialized
INFO - 2022-03-15 05:30:22 --> Model "Users_model" initialized
INFO - 2022-03-15 05:30:22 --> Model "Hospital_model" initialized
ERROR - 2022-03-15 05:30:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 05:30:23 --> Config Class Initialized
INFO - 2022-03-15 05:30:23 --> Hooks Class Initialized
DEBUG - 2022-03-15 05:30:23 --> UTF-8 Support Enabled
INFO - 2022-03-15 05:30:23 --> Utf8 Class Initialized
INFO - 2022-03-15 05:30:23 --> URI Class Initialized
INFO - 2022-03-15 05:30:23 --> Router Class Initialized
INFO - 2022-03-15 05:30:23 --> Output Class Initialized
INFO - 2022-03-15 05:30:23 --> Security Class Initialized
DEBUG - 2022-03-15 05:30:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 05:30:23 --> Input Class Initialized
INFO - 2022-03-15 05:30:23 --> Language Class Initialized
INFO - 2022-03-15 05:30:23 --> Loader Class Initialized
INFO - 2022-03-15 05:30:23 --> Helper loaded: url_helper
INFO - 2022-03-15 05:30:23 --> Helper loaded: form_helper
INFO - 2022-03-15 05:30:23 --> Helper loaded: common_helper
INFO - 2022-03-15 05:30:23 --> Database Driver Class Initialized
DEBUG - 2022-03-15 05:30:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 05:30:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 05:30:23 --> Controller Class Initialized
INFO - 2022-03-15 05:30:23 --> Form Validation Class Initialized
DEBUG - 2022-03-15 05:30:23 --> Encrypt Class Initialized
INFO - 2022-03-15 05:30:23 --> Model "Patient_model" initialized
INFO - 2022-03-15 05:30:23 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 05:30:23 --> Model "Prefix_master" initialized
INFO - 2022-03-15 05:30:23 --> Model "Users_model" initialized
INFO - 2022-03-15 05:30:23 --> Model "Hospital_model" initialized
INFO - 2022-03-15 05:30:23 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 05:30:23 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-15 05:30:23 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 05:30:23 --> Final output sent to browser
DEBUG - 2022-03-15 05:30:23 --> Total execution time: 0.0989
ERROR - 2022-03-15 05:31:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 05:31:00 --> Config Class Initialized
INFO - 2022-03-15 05:31:00 --> Hooks Class Initialized
DEBUG - 2022-03-15 05:31:00 --> UTF-8 Support Enabled
INFO - 2022-03-15 05:31:00 --> Utf8 Class Initialized
INFO - 2022-03-15 05:31:00 --> URI Class Initialized
INFO - 2022-03-15 05:31:00 --> Router Class Initialized
INFO - 2022-03-15 05:31:00 --> Output Class Initialized
INFO - 2022-03-15 05:31:00 --> Security Class Initialized
DEBUG - 2022-03-15 05:31:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 05:31:00 --> Input Class Initialized
INFO - 2022-03-15 05:31:00 --> Language Class Initialized
INFO - 2022-03-15 05:31:00 --> Loader Class Initialized
INFO - 2022-03-15 05:31:00 --> Helper loaded: url_helper
INFO - 2022-03-15 05:31:00 --> Helper loaded: form_helper
INFO - 2022-03-15 05:31:00 --> Helper loaded: common_helper
INFO - 2022-03-15 05:31:00 --> Database Driver Class Initialized
DEBUG - 2022-03-15 05:31:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 05:31:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 05:31:00 --> Controller Class Initialized
INFO - 2022-03-15 05:31:00 --> Form Validation Class Initialized
DEBUG - 2022-03-15 05:31:00 --> Encrypt Class Initialized
INFO - 2022-03-15 05:31:00 --> Model "Patient_model" initialized
INFO - 2022-03-15 05:31:00 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 05:31:00 --> Model "Prefix_master" initialized
INFO - 2022-03-15 05:31:00 --> Model "Users_model" initialized
INFO - 2022-03-15 05:31:00 --> Model "Hospital_model" initialized
INFO - 2022-03-15 05:31:00 --> Upload Class Initialized
INFO - 2022-03-15 05:31:00 --> Final output sent to browser
DEBUG - 2022-03-15 05:31:00 --> Total execution time: 0.1636
ERROR - 2022-03-15 05:31:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 05:31:24 --> Config Class Initialized
INFO - 2022-03-15 05:31:24 --> Hooks Class Initialized
DEBUG - 2022-03-15 05:31:24 --> UTF-8 Support Enabled
INFO - 2022-03-15 05:31:24 --> Utf8 Class Initialized
INFO - 2022-03-15 05:31:24 --> URI Class Initialized
INFO - 2022-03-15 05:31:24 --> Router Class Initialized
INFO - 2022-03-15 05:31:24 --> Output Class Initialized
INFO - 2022-03-15 05:31:24 --> Security Class Initialized
DEBUG - 2022-03-15 05:31:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 05:31:24 --> Input Class Initialized
INFO - 2022-03-15 05:31:24 --> Language Class Initialized
INFO - 2022-03-15 05:31:24 --> Loader Class Initialized
INFO - 2022-03-15 05:31:24 --> Helper loaded: url_helper
INFO - 2022-03-15 05:31:24 --> Helper loaded: form_helper
INFO - 2022-03-15 05:31:24 --> Helper loaded: common_helper
INFO - 2022-03-15 05:31:24 --> Database Driver Class Initialized
DEBUG - 2022-03-15 05:31:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 05:31:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 05:31:24 --> Controller Class Initialized
INFO - 2022-03-15 05:31:24 --> Form Validation Class Initialized
DEBUG - 2022-03-15 05:31:24 --> Encrypt Class Initialized
INFO - 2022-03-15 05:31:24 --> Model "Patient_model" initialized
INFO - 2022-03-15 05:31:24 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 05:31:24 --> Model "Prefix_master" initialized
INFO - 2022-03-15 05:31:24 --> Model "Users_model" initialized
INFO - 2022-03-15 05:31:24 --> Model "Hospital_model" initialized
INFO - 2022-03-15 05:31:24 --> Upload Class Initialized
INFO - 2022-03-15 05:31:24 --> Final output sent to browser
DEBUG - 2022-03-15 05:31:24 --> Total execution time: 0.0943
ERROR - 2022-03-15 05:31:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 05:31:31 --> Config Class Initialized
INFO - 2022-03-15 05:31:31 --> Hooks Class Initialized
DEBUG - 2022-03-15 05:31:31 --> UTF-8 Support Enabled
INFO - 2022-03-15 05:31:31 --> Utf8 Class Initialized
INFO - 2022-03-15 05:31:31 --> URI Class Initialized
INFO - 2022-03-15 05:31:31 --> Router Class Initialized
INFO - 2022-03-15 05:31:31 --> Output Class Initialized
INFO - 2022-03-15 05:31:31 --> Security Class Initialized
DEBUG - 2022-03-15 05:31:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 05:31:31 --> Input Class Initialized
INFO - 2022-03-15 05:31:31 --> Language Class Initialized
INFO - 2022-03-15 05:31:31 --> Loader Class Initialized
INFO - 2022-03-15 05:31:31 --> Helper loaded: url_helper
INFO - 2022-03-15 05:31:31 --> Helper loaded: form_helper
INFO - 2022-03-15 05:31:31 --> Helper loaded: common_helper
INFO - 2022-03-15 05:31:31 --> Database Driver Class Initialized
DEBUG - 2022-03-15 05:31:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 05:31:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 05:31:31 --> Controller Class Initialized
INFO - 2022-03-15 05:31:31 --> Form Validation Class Initialized
DEBUG - 2022-03-15 05:31:31 --> Encrypt Class Initialized
INFO - 2022-03-15 05:31:31 --> Model "Patient_model" initialized
INFO - 2022-03-15 05:31:31 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 05:31:31 --> Model "Prefix_master" initialized
INFO - 2022-03-15 05:31:31 --> Model "Users_model" initialized
INFO - 2022-03-15 05:31:31 --> Model "Hospital_model" initialized
ERROR - 2022-03-15 05:31:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 05:31:32 --> Config Class Initialized
INFO - 2022-03-15 05:31:32 --> Hooks Class Initialized
DEBUG - 2022-03-15 05:31:32 --> UTF-8 Support Enabled
INFO - 2022-03-15 05:31:32 --> Utf8 Class Initialized
INFO - 2022-03-15 05:31:32 --> URI Class Initialized
INFO - 2022-03-15 05:31:32 --> Router Class Initialized
INFO - 2022-03-15 05:31:32 --> Output Class Initialized
INFO - 2022-03-15 05:31:32 --> Security Class Initialized
DEBUG - 2022-03-15 05:31:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 05:31:32 --> Input Class Initialized
INFO - 2022-03-15 05:31:32 --> Language Class Initialized
INFO - 2022-03-15 05:31:32 --> Loader Class Initialized
INFO - 2022-03-15 05:31:32 --> Helper loaded: url_helper
INFO - 2022-03-15 05:31:32 --> Helper loaded: form_helper
INFO - 2022-03-15 05:31:32 --> Helper loaded: common_helper
INFO - 2022-03-15 05:31:32 --> Database Driver Class Initialized
DEBUG - 2022-03-15 05:31:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 05:31:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 05:31:32 --> Controller Class Initialized
INFO - 2022-03-15 05:31:32 --> Form Validation Class Initialized
DEBUG - 2022-03-15 05:31:32 --> Encrypt Class Initialized
INFO - 2022-03-15 05:31:32 --> Model "Patient_model" initialized
INFO - 2022-03-15 05:31:32 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 05:31:32 --> Model "Prefix_master" initialized
INFO - 2022-03-15 05:31:32 --> Model "Users_model" initialized
INFO - 2022-03-15 05:31:32 --> Model "Hospital_model" initialized
INFO - 2022-03-15 05:31:32 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 05:31:32 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-15 05:31:32 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 05:31:32 --> Final output sent to browser
DEBUG - 2022-03-15 05:31:32 --> Total execution time: 0.0977
ERROR - 2022-03-15 05:35:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 05:35:47 --> Config Class Initialized
INFO - 2022-03-15 05:35:47 --> Hooks Class Initialized
DEBUG - 2022-03-15 05:35:47 --> UTF-8 Support Enabled
INFO - 2022-03-15 05:35:47 --> Utf8 Class Initialized
INFO - 2022-03-15 05:35:47 --> URI Class Initialized
DEBUG - 2022-03-15 05:35:47 --> No URI present. Default controller set.
INFO - 2022-03-15 05:35:47 --> Router Class Initialized
INFO - 2022-03-15 05:35:47 --> Output Class Initialized
INFO - 2022-03-15 05:35:47 --> Security Class Initialized
DEBUG - 2022-03-15 05:35:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 05:35:47 --> Input Class Initialized
INFO - 2022-03-15 05:35:47 --> Language Class Initialized
INFO - 2022-03-15 05:35:47 --> Loader Class Initialized
INFO - 2022-03-15 05:35:47 --> Helper loaded: url_helper
INFO - 2022-03-15 05:35:47 --> Helper loaded: form_helper
INFO - 2022-03-15 05:35:47 --> Helper loaded: common_helper
INFO - 2022-03-15 05:35:47 --> Database Driver Class Initialized
DEBUG - 2022-03-15 05:35:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 05:35:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 05:35:47 --> Controller Class Initialized
INFO - 2022-03-15 05:35:47 --> Form Validation Class Initialized
DEBUG - 2022-03-15 05:35:47 --> Encrypt Class Initialized
DEBUG - 2022-03-15 05:35:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-15 05:35:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-15 05:35:47 --> Email Class Initialized
INFO - 2022-03-15 05:35:47 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-15 05:35:47 --> Calendar Class Initialized
INFO - 2022-03-15 05:35:47 --> Model "Login_model" initialized
INFO - 2022-03-15 05:35:47 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-15 05:35:47 --> Final output sent to browser
DEBUG - 2022-03-15 05:35:47 --> Total execution time: 0.0256
ERROR - 2022-03-15 05:36:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 05:36:25 --> Config Class Initialized
INFO - 2022-03-15 05:36:25 --> Hooks Class Initialized
DEBUG - 2022-03-15 05:36:25 --> UTF-8 Support Enabled
INFO - 2022-03-15 05:36:25 --> Utf8 Class Initialized
INFO - 2022-03-15 05:36:25 --> URI Class Initialized
INFO - 2022-03-15 05:36:25 --> Router Class Initialized
INFO - 2022-03-15 05:36:25 --> Output Class Initialized
INFO - 2022-03-15 05:36:25 --> Security Class Initialized
DEBUG - 2022-03-15 05:36:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 05:36:25 --> Input Class Initialized
INFO - 2022-03-15 05:36:25 --> Language Class Initialized
INFO - 2022-03-15 05:36:25 --> Loader Class Initialized
INFO - 2022-03-15 05:36:25 --> Helper loaded: url_helper
INFO - 2022-03-15 05:36:25 --> Helper loaded: form_helper
INFO - 2022-03-15 05:36:25 --> Helper loaded: common_helper
INFO - 2022-03-15 05:36:25 --> Database Driver Class Initialized
DEBUG - 2022-03-15 05:36:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 05:36:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 05:36:25 --> Controller Class Initialized
INFO - 2022-03-15 05:36:25 --> Form Validation Class Initialized
DEBUG - 2022-03-15 05:36:25 --> Encrypt Class Initialized
DEBUG - 2022-03-15 05:36:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-15 05:36:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-15 05:36:25 --> Email Class Initialized
INFO - 2022-03-15 05:36:25 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-15 05:36:25 --> Calendar Class Initialized
INFO - 2022-03-15 05:36:25 --> Model "Login_model" initialized
INFO - 2022-03-15 05:36:25 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-03-15 05:36:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 05:36:26 --> Config Class Initialized
INFO - 2022-03-15 05:36:26 --> Hooks Class Initialized
DEBUG - 2022-03-15 05:36:26 --> UTF-8 Support Enabled
INFO - 2022-03-15 05:36:26 --> Utf8 Class Initialized
INFO - 2022-03-15 05:36:26 --> URI Class Initialized
INFO - 2022-03-15 05:36:26 --> Router Class Initialized
INFO - 2022-03-15 05:36:26 --> Output Class Initialized
INFO - 2022-03-15 05:36:26 --> Security Class Initialized
DEBUG - 2022-03-15 05:36:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 05:36:26 --> Input Class Initialized
INFO - 2022-03-15 05:36:26 --> Language Class Initialized
INFO - 2022-03-15 05:36:26 --> Loader Class Initialized
INFO - 2022-03-15 05:36:26 --> Helper loaded: url_helper
INFO - 2022-03-15 05:36:26 --> Helper loaded: form_helper
INFO - 2022-03-15 05:36:26 --> Helper loaded: common_helper
INFO - 2022-03-15 05:36:26 --> Database Driver Class Initialized
DEBUG - 2022-03-15 05:36:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 05:36:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 05:36:26 --> Controller Class Initialized
INFO - 2022-03-15 05:36:26 --> Form Validation Class Initialized
DEBUG - 2022-03-15 05:36:26 --> Encrypt Class Initialized
INFO - 2022-03-15 05:36:26 --> Model "Login_model" initialized
INFO - 2022-03-15 05:36:26 --> Model "Dashboard_model" initialized
INFO - 2022-03-15 05:36:26 --> Model "Case_model" initialized
INFO - 2022-03-15 05:36:36 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 05:36:49 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2022-03-15 05:36:49 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 05:36:49 --> Final output sent to browser
DEBUG - 2022-03-15 05:36:49 --> Total execution time: 23.4887
ERROR - 2022-03-15 05:36:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 05:36:50 --> Config Class Initialized
INFO - 2022-03-15 05:36:50 --> Hooks Class Initialized
DEBUG - 2022-03-15 05:36:50 --> UTF-8 Support Enabled
INFO - 2022-03-15 05:36:50 --> Utf8 Class Initialized
INFO - 2022-03-15 05:36:50 --> URI Class Initialized
INFO - 2022-03-15 05:36:50 --> Router Class Initialized
INFO - 2022-03-15 05:36:50 --> Output Class Initialized
INFO - 2022-03-15 05:36:50 --> Security Class Initialized
DEBUG - 2022-03-15 05:36:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 05:36:50 --> Input Class Initialized
INFO - 2022-03-15 05:36:50 --> Language Class Initialized
ERROR - 2022-03-15 05:36:50 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-15 05:37:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 05:37:00 --> Config Class Initialized
INFO - 2022-03-15 05:37:00 --> Hooks Class Initialized
DEBUG - 2022-03-15 05:37:00 --> UTF-8 Support Enabled
INFO - 2022-03-15 05:37:00 --> Utf8 Class Initialized
INFO - 2022-03-15 05:37:00 --> URI Class Initialized
INFO - 2022-03-15 05:37:00 --> Router Class Initialized
INFO - 2022-03-15 05:37:00 --> Output Class Initialized
INFO - 2022-03-15 05:37:00 --> Security Class Initialized
DEBUG - 2022-03-15 05:37:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 05:37:00 --> Input Class Initialized
INFO - 2022-03-15 05:37:00 --> Language Class Initialized
INFO - 2022-03-15 05:37:00 --> Loader Class Initialized
INFO - 2022-03-15 05:37:00 --> Helper loaded: url_helper
INFO - 2022-03-15 05:37:00 --> Helper loaded: form_helper
INFO - 2022-03-15 05:37:00 --> Helper loaded: common_helper
INFO - 2022-03-15 05:37:00 --> Database Driver Class Initialized
DEBUG - 2022-03-15 05:37:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 05:37:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 05:37:00 --> Controller Class Initialized
INFO - 2022-03-15 05:37:00 --> Form Validation Class Initialized
DEBUG - 2022-03-15 05:37:00 --> Encrypt Class Initialized
INFO - 2022-03-15 05:37:00 --> Model "Patient_model" initialized
INFO - 2022-03-15 05:37:00 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 05:37:00 --> Model "Referredby_model" initialized
INFO - 2022-03-15 05:37:00 --> Model "Prefix_master" initialized
INFO - 2022-03-15 05:37:00 --> Model "Hospital_model" initialized
INFO - 2022-03-15 05:37:01 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 05:37:10 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-15 05:37:10 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
ERROR - 2022-03-15 05:37:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 05:37:11 --> Config Class Initialized
INFO - 2022-03-15 05:37:11 --> Hooks Class Initialized
DEBUG - 2022-03-15 05:37:11 --> UTF-8 Support Enabled
INFO - 2022-03-15 05:37:11 --> Utf8 Class Initialized
INFO - 2022-03-15 05:37:11 --> URI Class Initialized
INFO - 2022-03-15 05:37:11 --> Router Class Initialized
INFO - 2022-03-15 05:37:11 --> Output Class Initialized
INFO - 2022-03-15 05:37:11 --> Security Class Initialized
DEBUG - 2022-03-15 05:37:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 05:37:11 --> Input Class Initialized
INFO - 2022-03-15 05:37:11 --> Language Class Initialized
ERROR - 2022-03-15 05:37:11 --> 404 Page Not Found: Karoclient/usersprofile
INFO - 2022-03-15 05:37:12 --> Final output sent to browser
DEBUG - 2022-03-15 05:37:12 --> Total execution time: 9.4046
ERROR - 2022-03-15 05:37:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 05:37:58 --> Config Class Initialized
INFO - 2022-03-15 05:37:58 --> Hooks Class Initialized
DEBUG - 2022-03-15 05:37:58 --> UTF-8 Support Enabled
INFO - 2022-03-15 05:37:58 --> Utf8 Class Initialized
INFO - 2022-03-15 05:37:58 --> URI Class Initialized
INFO - 2022-03-15 05:37:58 --> Router Class Initialized
INFO - 2022-03-15 05:37:58 --> Output Class Initialized
INFO - 2022-03-15 05:37:58 --> Security Class Initialized
DEBUG - 2022-03-15 05:37:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 05:37:58 --> Input Class Initialized
INFO - 2022-03-15 05:37:58 --> Language Class Initialized
INFO - 2022-03-15 05:37:58 --> Loader Class Initialized
INFO - 2022-03-15 05:37:58 --> Helper loaded: url_helper
INFO - 2022-03-15 05:37:58 --> Helper loaded: form_helper
INFO - 2022-03-15 05:37:58 --> Helper loaded: common_helper
INFO - 2022-03-15 05:37:58 --> Database Driver Class Initialized
DEBUG - 2022-03-15 05:37:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 05:37:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 05:37:58 --> Controller Class Initialized
INFO - 2022-03-15 05:37:58 --> Form Validation Class Initialized
DEBUG - 2022-03-15 05:37:58 --> Encrypt Class Initialized
INFO - 2022-03-15 05:37:58 --> Model "Patient_model" initialized
INFO - 2022-03-15 05:37:58 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 05:37:58 --> Model "Referredby_model" initialized
INFO - 2022-03-15 05:37:58 --> Model "Prefix_master" initialized
INFO - 2022-03-15 05:37:58 --> Model "Hospital_model" initialized
INFO - 2022-03-15 05:37:58 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 05:37:58 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-15 05:37:58 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 05:37:58 --> Final output sent to browser
DEBUG - 2022-03-15 05:37:58 --> Total execution time: 0.0831
ERROR - 2022-03-15 05:37:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 05:37:58 --> Config Class Initialized
INFO - 2022-03-15 05:37:58 --> Hooks Class Initialized
DEBUG - 2022-03-15 05:37:58 --> UTF-8 Support Enabled
INFO - 2022-03-15 05:37:58 --> Utf8 Class Initialized
INFO - 2022-03-15 05:37:58 --> URI Class Initialized
INFO - 2022-03-15 05:37:58 --> Router Class Initialized
INFO - 2022-03-15 05:37:58 --> Output Class Initialized
INFO - 2022-03-15 05:37:58 --> Security Class Initialized
DEBUG - 2022-03-15 05:37:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 05:37:58 --> Input Class Initialized
INFO - 2022-03-15 05:37:58 --> Language Class Initialized
ERROR - 2022-03-15 05:37:58 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-15 05:37:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 05:37:58 --> Config Class Initialized
INFO - 2022-03-15 05:37:58 --> Hooks Class Initialized
DEBUG - 2022-03-15 05:37:58 --> UTF-8 Support Enabled
INFO - 2022-03-15 05:37:58 --> Utf8 Class Initialized
INFO - 2022-03-15 05:37:58 --> URI Class Initialized
INFO - 2022-03-15 05:37:58 --> Router Class Initialized
INFO - 2022-03-15 05:37:58 --> Output Class Initialized
INFO - 2022-03-15 05:37:58 --> Security Class Initialized
DEBUG - 2022-03-15 05:37:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 05:37:58 --> Input Class Initialized
INFO - 2022-03-15 05:37:58 --> Language Class Initialized
ERROR - 2022-03-15 05:37:58 --> 404 Page Not Found: Karoclient/images
ERROR - 2022-03-15 05:38:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 05:38:24 --> Config Class Initialized
INFO - 2022-03-15 05:38:24 --> Hooks Class Initialized
DEBUG - 2022-03-15 05:38:24 --> UTF-8 Support Enabled
INFO - 2022-03-15 05:38:24 --> Utf8 Class Initialized
INFO - 2022-03-15 05:38:24 --> URI Class Initialized
INFO - 2022-03-15 05:38:24 --> Router Class Initialized
INFO - 2022-03-15 05:38:24 --> Output Class Initialized
INFO - 2022-03-15 05:38:24 --> Security Class Initialized
DEBUG - 2022-03-15 05:38:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 05:38:24 --> Input Class Initialized
INFO - 2022-03-15 05:38:24 --> Language Class Initialized
INFO - 2022-03-15 05:38:24 --> Loader Class Initialized
INFO - 2022-03-15 05:38:24 --> Helper loaded: url_helper
INFO - 2022-03-15 05:38:24 --> Helper loaded: form_helper
INFO - 2022-03-15 05:38:24 --> Helper loaded: common_helper
INFO - 2022-03-15 05:38:24 --> Database Driver Class Initialized
DEBUG - 2022-03-15 05:38:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 05:38:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 05:38:24 --> Controller Class Initialized
INFO - 2022-03-15 05:38:24 --> Form Validation Class Initialized
DEBUG - 2022-03-15 05:38:24 --> Encrypt Class Initialized
INFO - 2022-03-15 05:38:24 --> Model "Patient_model" initialized
INFO - 2022-03-15 05:38:24 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 05:38:24 --> Model "Referredby_model" initialized
INFO - 2022-03-15 05:38:24 --> Model "Prefix_master" initialized
INFO - 2022-03-15 05:38:24 --> Model "Hospital_model" initialized
ERROR - 2022-03-15 05:38:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 05:38:25 --> Config Class Initialized
INFO - 2022-03-15 05:38:25 --> Hooks Class Initialized
DEBUG - 2022-03-15 05:38:25 --> UTF-8 Support Enabled
INFO - 2022-03-15 05:38:25 --> Utf8 Class Initialized
INFO - 2022-03-15 05:38:25 --> URI Class Initialized
INFO - 2022-03-15 05:38:25 --> Router Class Initialized
INFO - 2022-03-15 05:38:25 --> Output Class Initialized
INFO - 2022-03-15 05:38:25 --> Security Class Initialized
DEBUG - 2022-03-15 05:38:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 05:38:25 --> Input Class Initialized
INFO - 2022-03-15 05:38:25 --> Language Class Initialized
INFO - 2022-03-15 05:38:25 --> Loader Class Initialized
INFO - 2022-03-15 05:38:25 --> Helper loaded: url_helper
INFO - 2022-03-15 05:38:25 --> Helper loaded: form_helper
INFO - 2022-03-15 05:38:25 --> Helper loaded: common_helper
INFO - 2022-03-15 05:38:25 --> Database Driver Class Initialized
DEBUG - 2022-03-15 05:38:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 05:38:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 05:38:25 --> Controller Class Initialized
INFO - 2022-03-15 05:38:25 --> Form Validation Class Initialized
DEBUG - 2022-03-15 05:38:25 --> Encrypt Class Initialized
INFO - 2022-03-15 05:38:25 --> Model "Patient_model" initialized
INFO - 2022-03-15 05:38:25 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 05:38:25 --> Model "Referredby_model" initialized
INFO - 2022-03-15 05:38:25 --> Model "Prefix_master" initialized
INFO - 2022-03-15 05:38:25 --> Model "Hospital_model" initialized
INFO - 2022-03-15 05:38:25 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 05:38:25 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-15 05:38:25 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 05:38:25 --> Final output sent to browser
DEBUG - 2022-03-15 05:38:25 --> Total execution time: 0.0405
ERROR - 2022-03-15 05:38:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 05:38:26 --> Config Class Initialized
INFO - 2022-03-15 05:38:26 --> Hooks Class Initialized
DEBUG - 2022-03-15 05:38:26 --> UTF-8 Support Enabled
INFO - 2022-03-15 05:38:26 --> Utf8 Class Initialized
INFO - 2022-03-15 05:38:26 --> URI Class Initialized
INFO - 2022-03-15 05:38:26 --> Router Class Initialized
INFO - 2022-03-15 05:38:26 --> Output Class Initialized
INFO - 2022-03-15 05:38:26 --> Security Class Initialized
DEBUG - 2022-03-15 05:38:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 05:38:26 --> Input Class Initialized
INFO - 2022-03-15 05:38:26 --> Language Class Initialized
ERROR - 2022-03-15 05:38:26 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-15 05:38:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 05:38:26 --> Config Class Initialized
INFO - 2022-03-15 05:38:26 --> Hooks Class Initialized
DEBUG - 2022-03-15 05:38:26 --> UTF-8 Support Enabled
INFO - 2022-03-15 05:38:26 --> Utf8 Class Initialized
INFO - 2022-03-15 05:38:26 --> URI Class Initialized
INFO - 2022-03-15 05:38:26 --> Router Class Initialized
INFO - 2022-03-15 05:38:26 --> Output Class Initialized
INFO - 2022-03-15 05:38:26 --> Security Class Initialized
DEBUG - 2022-03-15 05:38:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 05:38:26 --> Input Class Initialized
INFO - 2022-03-15 05:38:26 --> Language Class Initialized
ERROR - 2022-03-15 05:38:26 --> 404 Page Not Found: Karoclient/images
ERROR - 2022-03-15 05:38:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 05:38:26 --> Config Class Initialized
INFO - 2022-03-15 05:38:26 --> Hooks Class Initialized
DEBUG - 2022-03-15 05:38:26 --> UTF-8 Support Enabled
INFO - 2022-03-15 05:38:26 --> Utf8 Class Initialized
INFO - 2022-03-15 05:38:26 --> URI Class Initialized
INFO - 2022-03-15 05:38:26 --> Router Class Initialized
INFO - 2022-03-15 05:38:26 --> Output Class Initialized
INFO - 2022-03-15 05:38:26 --> Security Class Initialized
DEBUG - 2022-03-15 05:38:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 05:38:26 --> Input Class Initialized
INFO - 2022-03-15 05:38:26 --> Language Class Initialized
INFO - 2022-03-15 05:38:26 --> Loader Class Initialized
INFO - 2022-03-15 05:38:26 --> Helper loaded: url_helper
INFO - 2022-03-15 05:38:26 --> Helper loaded: form_helper
INFO - 2022-03-15 05:38:26 --> Helper loaded: common_helper
INFO - 2022-03-15 05:38:26 --> Database Driver Class Initialized
DEBUG - 2022-03-15 05:38:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 05:38:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 05:38:26 --> Controller Class Initialized
INFO - 2022-03-15 05:38:26 --> Form Validation Class Initialized
DEBUG - 2022-03-15 05:38:26 --> Encrypt Class Initialized
INFO - 2022-03-15 05:38:26 --> Model "Patient_model" initialized
INFO - 2022-03-15 05:38:26 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 05:38:26 --> Model "Prefix_master" initialized
INFO - 2022-03-15 05:38:26 --> Model "Users_model" initialized
INFO - 2022-03-15 05:38:26 --> Model "Hospital_model" initialized
INFO - 2022-03-15 05:38:26 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 05:38:26 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-15 05:38:26 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 05:38:26 --> Final output sent to browser
DEBUG - 2022-03-15 05:38:26 --> Total execution time: 0.0532
ERROR - 2022-03-15 05:38:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 05:38:27 --> Config Class Initialized
INFO - 2022-03-15 05:38:27 --> Hooks Class Initialized
DEBUG - 2022-03-15 05:38:27 --> UTF-8 Support Enabled
INFO - 2022-03-15 05:38:27 --> Utf8 Class Initialized
INFO - 2022-03-15 05:38:27 --> URI Class Initialized
INFO - 2022-03-15 05:38:27 --> Router Class Initialized
INFO - 2022-03-15 05:38:27 --> Output Class Initialized
INFO - 2022-03-15 05:38:27 --> Security Class Initialized
DEBUG - 2022-03-15 05:38:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 05:38:27 --> Input Class Initialized
INFO - 2022-03-15 05:38:27 --> Language Class Initialized
ERROR - 2022-03-15 05:38:27 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-15 05:47:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 05:47:51 --> Config Class Initialized
INFO - 2022-03-15 05:47:51 --> Hooks Class Initialized
DEBUG - 2022-03-15 05:47:51 --> UTF-8 Support Enabled
INFO - 2022-03-15 05:47:51 --> Utf8 Class Initialized
INFO - 2022-03-15 05:47:51 --> URI Class Initialized
INFO - 2022-03-15 05:47:51 --> Router Class Initialized
INFO - 2022-03-15 05:47:51 --> Output Class Initialized
INFO - 2022-03-15 05:47:51 --> Security Class Initialized
DEBUG - 2022-03-15 05:47:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 05:47:51 --> Input Class Initialized
INFO - 2022-03-15 05:47:51 --> Language Class Initialized
INFO - 2022-03-15 05:47:51 --> Loader Class Initialized
INFO - 2022-03-15 05:47:51 --> Helper loaded: url_helper
INFO - 2022-03-15 05:47:51 --> Helper loaded: form_helper
INFO - 2022-03-15 05:47:51 --> Helper loaded: common_helper
INFO - 2022-03-15 05:47:51 --> Database Driver Class Initialized
DEBUG - 2022-03-15 05:47:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 05:47:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 05:47:51 --> Controller Class Initialized
INFO - 2022-03-15 05:47:51 --> Form Validation Class Initialized
INFO - 2022-03-15 05:47:51 --> Model "Case_model" initialized
INFO - 2022-03-15 05:47:51 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 05:47:51 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 05:47:51 --> File loaded: /home3/karoteam/public_html/application/views/cases/rehelp.php
INFO - 2022-03-15 05:47:51 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 05:47:51 --> Final output sent to browser
DEBUG - 2022-03-15 05:47:51 --> Total execution time: 0.2124
ERROR - 2022-03-15 05:47:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 05:47:52 --> Config Class Initialized
INFO - 2022-03-15 05:47:52 --> Hooks Class Initialized
DEBUG - 2022-03-15 05:47:52 --> UTF-8 Support Enabled
INFO - 2022-03-15 05:47:52 --> Utf8 Class Initialized
INFO - 2022-03-15 05:47:52 --> URI Class Initialized
INFO - 2022-03-15 05:47:52 --> Router Class Initialized
INFO - 2022-03-15 05:47:52 --> Output Class Initialized
INFO - 2022-03-15 05:47:52 --> Security Class Initialized
DEBUG - 2022-03-15 05:47:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 05:47:52 --> Input Class Initialized
INFO - 2022-03-15 05:47:52 --> Language Class Initialized
ERROR - 2022-03-15 05:47:52 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-15 05:49:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 05:49:28 --> Config Class Initialized
INFO - 2022-03-15 05:49:28 --> Hooks Class Initialized
DEBUG - 2022-03-15 05:49:28 --> UTF-8 Support Enabled
INFO - 2022-03-15 05:49:28 --> Utf8 Class Initialized
INFO - 2022-03-15 05:49:28 --> URI Class Initialized
INFO - 2022-03-15 05:49:28 --> Router Class Initialized
INFO - 2022-03-15 05:49:28 --> Output Class Initialized
INFO - 2022-03-15 05:49:28 --> Security Class Initialized
DEBUG - 2022-03-15 05:49:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 05:49:28 --> Input Class Initialized
INFO - 2022-03-15 05:49:28 --> Language Class Initialized
INFO - 2022-03-15 05:49:28 --> Loader Class Initialized
INFO - 2022-03-15 05:49:28 --> Helper loaded: url_helper
INFO - 2022-03-15 05:49:28 --> Helper loaded: form_helper
INFO - 2022-03-15 05:49:28 --> Helper loaded: common_helper
INFO - 2022-03-15 05:49:28 --> Database Driver Class Initialized
DEBUG - 2022-03-15 05:49:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 05:49:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 05:49:28 --> Controller Class Initialized
INFO - 2022-03-15 05:49:28 --> Form Validation Class Initialized
DEBUG - 2022-03-15 05:49:28 --> Encrypt Class Initialized
INFO - 2022-03-15 05:49:28 --> Model "Patient_model" initialized
INFO - 2022-03-15 05:49:28 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 05:49:28 --> Model "Prefix_master" initialized
INFO - 2022-03-15 05:49:28 --> Model "Users_model" initialized
INFO - 2022-03-15 05:49:28 --> Model "Hospital_model" initialized
INFO - 2022-03-15 05:49:28 --> Upload Class Initialized
INFO - 2022-03-15 05:49:28 --> Final output sent to browser
DEBUG - 2022-03-15 05:49:28 --> Total execution time: 0.0709
ERROR - 2022-03-15 05:57:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 05:57:49 --> Config Class Initialized
INFO - 2022-03-15 05:57:49 --> Hooks Class Initialized
DEBUG - 2022-03-15 05:57:49 --> UTF-8 Support Enabled
INFO - 2022-03-15 05:57:49 --> Utf8 Class Initialized
INFO - 2022-03-15 05:57:49 --> URI Class Initialized
INFO - 2022-03-15 05:57:49 --> Router Class Initialized
INFO - 2022-03-15 05:57:49 --> Output Class Initialized
INFO - 2022-03-15 05:57:49 --> Security Class Initialized
DEBUG - 2022-03-15 05:57:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 05:57:49 --> Input Class Initialized
INFO - 2022-03-15 05:57:49 --> Language Class Initialized
INFO - 2022-03-15 05:57:49 --> Loader Class Initialized
INFO - 2022-03-15 05:57:49 --> Helper loaded: url_helper
INFO - 2022-03-15 05:57:49 --> Helper loaded: form_helper
INFO - 2022-03-15 05:57:49 --> Helper loaded: common_helper
INFO - 2022-03-15 05:57:49 --> Database Driver Class Initialized
DEBUG - 2022-03-15 05:57:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 05:57:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 05:57:49 --> Controller Class Initialized
INFO - 2022-03-15 05:57:49 --> Form Validation Class Initialized
DEBUG - 2022-03-15 05:57:49 --> Encrypt Class Initialized
INFO - 2022-03-15 05:57:49 --> Model "Patient_model" initialized
INFO - 2022-03-15 05:57:49 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 05:57:49 --> Model "Referredby_model" initialized
INFO - 2022-03-15 05:57:49 --> Model "Prefix_master" initialized
INFO - 2022-03-15 05:57:49 --> Model "Hospital_model" initialized
INFO - 2022-03-15 05:57:49 --> Final output sent to browser
DEBUG - 2022-03-15 05:57:49 --> Total execution time: 0.0416
ERROR - 2022-03-15 05:58:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 05:58:12 --> Config Class Initialized
INFO - 2022-03-15 05:58:12 --> Hooks Class Initialized
DEBUG - 2022-03-15 05:58:12 --> UTF-8 Support Enabled
INFO - 2022-03-15 05:58:12 --> Utf8 Class Initialized
INFO - 2022-03-15 05:58:12 --> URI Class Initialized
INFO - 2022-03-15 05:58:12 --> Router Class Initialized
INFO - 2022-03-15 05:58:12 --> Output Class Initialized
INFO - 2022-03-15 05:58:12 --> Security Class Initialized
DEBUG - 2022-03-15 05:58:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 05:58:12 --> Input Class Initialized
INFO - 2022-03-15 05:58:12 --> Language Class Initialized
INFO - 2022-03-15 05:58:12 --> Loader Class Initialized
INFO - 2022-03-15 05:58:12 --> Helper loaded: url_helper
INFO - 2022-03-15 05:58:12 --> Helper loaded: form_helper
INFO - 2022-03-15 05:58:12 --> Helper loaded: common_helper
INFO - 2022-03-15 05:58:12 --> Database Driver Class Initialized
DEBUG - 2022-03-15 05:58:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 05:58:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 05:58:12 --> Controller Class Initialized
INFO - 2022-03-15 05:58:12 --> Form Validation Class Initialized
DEBUG - 2022-03-15 05:58:12 --> Encrypt Class Initialized
INFO - 2022-03-15 05:58:12 --> Model "Patient_model" initialized
INFO - 2022-03-15 05:58:12 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 05:58:12 --> Model "Prefix_master" initialized
INFO - 2022-03-15 05:58:12 --> Model "Users_model" initialized
INFO - 2022-03-15 05:58:12 --> Model "Hospital_model" initialized
ERROR - 2022-03-15 05:58:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 05:58:13 --> Config Class Initialized
INFO - 2022-03-15 05:58:13 --> Hooks Class Initialized
DEBUG - 2022-03-15 05:58:13 --> UTF-8 Support Enabled
INFO - 2022-03-15 05:58:13 --> Utf8 Class Initialized
INFO - 2022-03-15 05:58:13 --> URI Class Initialized
INFO - 2022-03-15 05:58:13 --> Router Class Initialized
INFO - 2022-03-15 05:58:13 --> Output Class Initialized
INFO - 2022-03-15 05:58:13 --> Security Class Initialized
DEBUG - 2022-03-15 05:58:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 05:58:13 --> Input Class Initialized
INFO - 2022-03-15 05:58:13 --> Language Class Initialized
INFO - 2022-03-15 05:58:13 --> Loader Class Initialized
INFO - 2022-03-15 05:58:13 --> Helper loaded: url_helper
INFO - 2022-03-15 05:58:13 --> Helper loaded: form_helper
INFO - 2022-03-15 05:58:13 --> Helper loaded: common_helper
INFO - 2022-03-15 05:58:13 --> Database Driver Class Initialized
DEBUG - 2022-03-15 05:58:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 05:58:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 05:58:13 --> Controller Class Initialized
INFO - 2022-03-15 05:58:13 --> Form Validation Class Initialized
DEBUG - 2022-03-15 05:58:13 --> Encrypt Class Initialized
INFO - 2022-03-15 05:58:13 --> Model "Patient_model" initialized
INFO - 2022-03-15 05:58:13 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 05:58:13 --> Model "Prefix_master" initialized
INFO - 2022-03-15 05:58:13 --> Model "Users_model" initialized
INFO - 2022-03-15 05:58:13 --> Model "Hospital_model" initialized
INFO - 2022-03-15 05:58:13 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 05:58:13 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-15 05:58:13 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 05:58:13 --> Final output sent to browser
DEBUG - 2022-03-15 05:58:13 --> Total execution time: 0.0876
ERROR - 2022-03-15 06:03:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:03:11 --> Config Class Initialized
INFO - 2022-03-15 06:03:11 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:03:11 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:03:11 --> Utf8 Class Initialized
INFO - 2022-03-15 06:03:11 --> URI Class Initialized
INFO - 2022-03-15 06:03:11 --> Router Class Initialized
INFO - 2022-03-15 06:03:11 --> Output Class Initialized
INFO - 2022-03-15 06:03:11 --> Security Class Initialized
DEBUG - 2022-03-15 06:03:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:03:11 --> Input Class Initialized
INFO - 2022-03-15 06:03:11 --> Language Class Initialized
INFO - 2022-03-15 06:03:11 --> Loader Class Initialized
INFO - 2022-03-15 06:03:11 --> Helper loaded: url_helper
INFO - 2022-03-15 06:03:11 --> Helper loaded: form_helper
INFO - 2022-03-15 06:03:11 --> Helper loaded: common_helper
INFO - 2022-03-15 06:03:11 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:03:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:03:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:03:11 --> Controller Class Initialized
INFO - 2022-03-15 06:03:11 --> Form Validation Class Initialized
DEBUG - 2022-03-15 06:03:11 --> Encrypt Class Initialized
INFO - 2022-03-15 06:03:11 --> Model "Patient_model" initialized
INFO - 2022-03-15 06:03:11 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 06:03:11 --> Model "Referredby_model" initialized
INFO - 2022-03-15 06:03:11 --> Model "Prefix_master" initialized
INFO - 2022-03-15 06:03:11 --> Model "Hospital_model" initialized
INFO - 2022-03-15 06:03:11 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 06:03:11 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-15 06:03:11 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 06:03:11 --> Final output sent to browser
DEBUG - 2022-03-15 06:03:11 --> Total execution time: 0.0735
ERROR - 2022-03-15 06:05:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:05:45 --> Config Class Initialized
INFO - 2022-03-15 06:05:45 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:05:45 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:05:45 --> Utf8 Class Initialized
INFO - 2022-03-15 06:05:45 --> URI Class Initialized
INFO - 2022-03-15 06:05:45 --> Router Class Initialized
INFO - 2022-03-15 06:05:45 --> Output Class Initialized
INFO - 2022-03-15 06:05:45 --> Security Class Initialized
DEBUG - 2022-03-15 06:05:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:05:45 --> Input Class Initialized
INFO - 2022-03-15 06:05:45 --> Language Class Initialized
INFO - 2022-03-15 06:05:45 --> Loader Class Initialized
INFO - 2022-03-15 06:05:45 --> Helper loaded: url_helper
INFO - 2022-03-15 06:05:45 --> Helper loaded: form_helper
INFO - 2022-03-15 06:05:45 --> Helper loaded: common_helper
INFO - 2022-03-15 06:05:45 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:05:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:05:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:05:45 --> Controller Class Initialized
INFO - 2022-03-15 06:05:45 --> Form Validation Class Initialized
INFO - 2022-03-15 06:05:45 --> Model "Case_model" initialized
INFO - 2022-03-15 06:05:45 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 06:05:48 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 06:05:48 --> Model "Case_model" initialized
INFO - 2022-03-15 06:05:52 --> File loaded: /home3/karoteam/public_html/application/views/cases/closed_case.php
INFO - 2022-03-15 06:05:52 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 06:05:52 --> Final output sent to browser
DEBUG - 2022-03-15 06:05:52 --> Total execution time: 6.4033
ERROR - 2022-03-15 06:05:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:05:53 --> Config Class Initialized
INFO - 2022-03-15 06:05:53 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:05:53 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:05:53 --> Utf8 Class Initialized
INFO - 2022-03-15 06:05:53 --> URI Class Initialized
INFO - 2022-03-15 06:05:53 --> Router Class Initialized
INFO - 2022-03-15 06:05:53 --> Output Class Initialized
INFO - 2022-03-15 06:05:53 --> Security Class Initialized
DEBUG - 2022-03-15 06:05:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:05:53 --> Input Class Initialized
INFO - 2022-03-15 06:05:53 --> Language Class Initialized
ERROR - 2022-03-15 06:05:53 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-15 06:07:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:07:00 --> Config Class Initialized
INFO - 2022-03-15 06:07:00 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:07:00 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:07:00 --> Utf8 Class Initialized
INFO - 2022-03-15 06:07:00 --> URI Class Initialized
INFO - 2022-03-15 06:07:00 --> Router Class Initialized
INFO - 2022-03-15 06:07:00 --> Output Class Initialized
INFO - 2022-03-15 06:07:00 --> Security Class Initialized
DEBUG - 2022-03-15 06:07:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:07:00 --> Input Class Initialized
INFO - 2022-03-15 06:07:00 --> Language Class Initialized
INFO - 2022-03-15 06:07:00 --> Loader Class Initialized
INFO - 2022-03-15 06:07:00 --> Helper loaded: url_helper
INFO - 2022-03-15 06:07:00 --> Helper loaded: form_helper
INFO - 2022-03-15 06:07:00 --> Helper loaded: common_helper
INFO - 2022-03-15 06:07:00 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:07:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:07:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:07:00 --> Controller Class Initialized
INFO - 2022-03-15 06:07:00 --> Form Validation Class Initialized
DEBUG - 2022-03-15 06:07:00 --> Encrypt Class Initialized
INFO - 2022-03-15 06:07:00 --> Model "Patient_model" initialized
INFO - 2022-03-15 06:07:00 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 06:07:00 --> Model "Referredby_model" initialized
INFO - 2022-03-15 06:07:00 --> Model "Prefix_master" initialized
INFO - 2022-03-15 06:07:00 --> Model "Hospital_model" initialized
ERROR - 2022-03-15 06:07:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:07:00 --> Config Class Initialized
INFO - 2022-03-15 06:07:00 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:07:00 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:07:00 --> Utf8 Class Initialized
INFO - 2022-03-15 06:07:00 --> URI Class Initialized
INFO - 2022-03-15 06:07:00 --> Router Class Initialized
INFO - 2022-03-15 06:07:00 --> Output Class Initialized
INFO - 2022-03-15 06:07:00 --> Security Class Initialized
DEBUG - 2022-03-15 06:07:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:07:00 --> Input Class Initialized
INFO - 2022-03-15 06:07:00 --> Language Class Initialized
INFO - 2022-03-15 06:07:00 --> Loader Class Initialized
INFO - 2022-03-15 06:07:00 --> Helper loaded: url_helper
INFO - 2022-03-15 06:07:00 --> Helper loaded: form_helper
INFO - 2022-03-15 06:07:00 --> Helper loaded: common_helper
INFO - 2022-03-15 06:07:00 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:07:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:07:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:07:00 --> Controller Class Initialized
INFO - 2022-03-15 06:07:00 --> Form Validation Class Initialized
DEBUG - 2022-03-15 06:07:00 --> Encrypt Class Initialized
INFO - 2022-03-15 06:07:00 --> Model "Patient_model" initialized
INFO - 2022-03-15 06:07:00 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 06:07:00 --> Model "Referredby_model" initialized
INFO - 2022-03-15 06:07:00 --> Model "Prefix_master" initialized
INFO - 2022-03-15 06:07:00 --> Model "Hospital_model" initialized
INFO - 2022-03-15 06:07:00 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 06:07:00 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-15 06:07:00 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 06:07:00 --> Final output sent to browser
DEBUG - 2022-03-15 06:07:00 --> Total execution time: 0.0633
ERROR - 2022-03-15 06:07:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:07:01 --> Config Class Initialized
INFO - 2022-03-15 06:07:01 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:07:01 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:07:01 --> Utf8 Class Initialized
INFO - 2022-03-15 06:07:01 --> URI Class Initialized
INFO - 2022-03-15 06:07:01 --> Router Class Initialized
INFO - 2022-03-15 06:07:01 --> Output Class Initialized
INFO - 2022-03-15 06:07:01 --> Security Class Initialized
DEBUG - 2022-03-15 06:07:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:07:01 --> Input Class Initialized
INFO - 2022-03-15 06:07:01 --> Language Class Initialized
INFO - 2022-03-15 06:07:01 --> Loader Class Initialized
INFO - 2022-03-15 06:07:01 --> Helper loaded: url_helper
INFO - 2022-03-15 06:07:01 --> Helper loaded: form_helper
INFO - 2022-03-15 06:07:01 --> Helper loaded: common_helper
INFO - 2022-03-15 06:07:01 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:07:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:07:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:07:01 --> Controller Class Initialized
INFO - 2022-03-15 06:07:01 --> Form Validation Class Initialized
DEBUG - 2022-03-15 06:07:01 --> Encrypt Class Initialized
INFO - 2022-03-15 06:07:01 --> Model "Patient_model" initialized
INFO - 2022-03-15 06:07:01 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 06:07:01 --> Model "Prefix_master" initialized
INFO - 2022-03-15 06:07:01 --> Model "Users_model" initialized
INFO - 2022-03-15 06:07:01 --> Model "Hospital_model" initialized
INFO - 2022-03-15 06:07:02 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 06:07:02 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-15 06:07:02 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 06:07:02 --> Final output sent to browser
DEBUG - 2022-03-15 06:07:02 --> Total execution time: 0.0806
ERROR - 2022-03-15 06:07:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:07:06 --> Config Class Initialized
INFO - 2022-03-15 06:07:06 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:07:06 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:07:06 --> Utf8 Class Initialized
INFO - 2022-03-15 06:07:06 --> URI Class Initialized
INFO - 2022-03-15 06:07:06 --> Router Class Initialized
INFO - 2022-03-15 06:07:06 --> Output Class Initialized
INFO - 2022-03-15 06:07:06 --> Security Class Initialized
DEBUG - 2022-03-15 06:07:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:07:06 --> Input Class Initialized
INFO - 2022-03-15 06:07:06 --> Language Class Initialized
INFO - 2022-03-15 06:07:06 --> Loader Class Initialized
INFO - 2022-03-15 06:07:06 --> Helper loaded: url_helper
INFO - 2022-03-15 06:07:06 --> Helper loaded: form_helper
INFO - 2022-03-15 06:07:06 --> Helper loaded: common_helper
INFO - 2022-03-15 06:07:06 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:07:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:07:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:07:06 --> Controller Class Initialized
INFO - 2022-03-15 06:07:06 --> Form Validation Class Initialized
DEBUG - 2022-03-15 06:07:06 --> Encrypt Class Initialized
INFO - 2022-03-15 06:07:06 --> Model "Patient_model" initialized
INFO - 2022-03-15 06:07:06 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 06:07:06 --> Model "Referredby_model" initialized
INFO - 2022-03-15 06:07:06 --> Model "Prefix_master" initialized
INFO - 2022-03-15 06:07:06 --> Model "Hospital_model" initialized
INFO - 2022-03-15 06:07:06 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 06:07:06 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-15 06:07:06 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 06:07:06 --> Final output sent to browser
DEBUG - 2022-03-15 06:07:06 --> Total execution time: 0.1990
ERROR - 2022-03-15 06:07:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:07:25 --> Config Class Initialized
INFO - 2022-03-15 06:07:25 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:07:25 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:07:25 --> Utf8 Class Initialized
INFO - 2022-03-15 06:07:25 --> URI Class Initialized
INFO - 2022-03-15 06:07:25 --> Router Class Initialized
INFO - 2022-03-15 06:07:25 --> Output Class Initialized
INFO - 2022-03-15 06:07:25 --> Security Class Initialized
DEBUG - 2022-03-15 06:07:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:07:25 --> Input Class Initialized
INFO - 2022-03-15 06:07:25 --> Language Class Initialized
INFO - 2022-03-15 06:07:25 --> Loader Class Initialized
INFO - 2022-03-15 06:07:25 --> Helper loaded: url_helper
INFO - 2022-03-15 06:07:25 --> Helper loaded: form_helper
INFO - 2022-03-15 06:07:25 --> Helper loaded: common_helper
INFO - 2022-03-15 06:07:25 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:07:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:07:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:07:25 --> Controller Class Initialized
INFO - 2022-03-15 06:07:25 --> Form Validation Class Initialized
DEBUG - 2022-03-15 06:07:25 --> Encrypt Class Initialized
INFO - 2022-03-15 06:07:25 --> Model "Patient_model" initialized
INFO - 2022-03-15 06:07:25 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 06:07:25 --> Model "Referredby_model" initialized
INFO - 2022-03-15 06:07:25 --> Model "Prefix_master" initialized
INFO - 2022-03-15 06:07:25 --> Model "Hospital_model" initialized
INFO - 2022-03-15 06:07:25 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 06:07:25 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-15 06:07:25 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 06:07:25 --> Final output sent to browser
DEBUG - 2022-03-15 06:07:25 --> Total execution time: 0.0704
ERROR - 2022-03-15 06:07:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:07:25 --> Config Class Initialized
INFO - 2022-03-15 06:07:25 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:07:25 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:07:25 --> Utf8 Class Initialized
INFO - 2022-03-15 06:07:25 --> URI Class Initialized
INFO - 2022-03-15 06:07:25 --> Router Class Initialized
INFO - 2022-03-15 06:07:25 --> Output Class Initialized
INFO - 2022-03-15 06:07:25 --> Security Class Initialized
DEBUG - 2022-03-15 06:07:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:07:25 --> Input Class Initialized
INFO - 2022-03-15 06:07:25 --> Language Class Initialized
INFO - 2022-03-15 06:07:25 --> Loader Class Initialized
INFO - 2022-03-15 06:07:25 --> Helper loaded: url_helper
INFO - 2022-03-15 06:07:25 --> Helper loaded: form_helper
INFO - 2022-03-15 06:07:25 --> Helper loaded: common_helper
INFO - 2022-03-15 06:07:25 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:07:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:07:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:07:25 --> Controller Class Initialized
INFO - 2022-03-15 06:07:25 --> Form Validation Class Initialized
DEBUG - 2022-03-15 06:07:25 --> Encrypt Class Initialized
INFO - 2022-03-15 06:07:25 --> Model "Patient_model" initialized
INFO - 2022-03-15 06:07:25 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 06:07:25 --> Model "Referredby_model" initialized
INFO - 2022-03-15 06:07:25 --> Model "Prefix_master" initialized
INFO - 2022-03-15 06:07:25 --> Model "Hospital_model" initialized
INFO - 2022-03-15 06:07:25 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 06:07:25 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-15 06:07:25 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 06:07:25 --> Final output sent to browser
DEBUG - 2022-03-15 06:07:25 --> Total execution time: 0.0929
ERROR - 2022-03-15 06:07:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:07:26 --> Config Class Initialized
INFO - 2022-03-15 06:07:26 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:07:26 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:07:26 --> Utf8 Class Initialized
INFO - 2022-03-15 06:07:26 --> URI Class Initialized
INFO - 2022-03-15 06:07:26 --> Router Class Initialized
INFO - 2022-03-15 06:07:26 --> Output Class Initialized
INFO - 2022-03-15 06:07:26 --> Security Class Initialized
DEBUG - 2022-03-15 06:07:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:07:26 --> Input Class Initialized
INFO - 2022-03-15 06:07:26 --> Language Class Initialized
INFO - 2022-03-15 06:07:26 --> Loader Class Initialized
INFO - 2022-03-15 06:07:26 --> Helper loaded: url_helper
INFO - 2022-03-15 06:07:26 --> Helper loaded: form_helper
INFO - 2022-03-15 06:07:26 --> Helper loaded: common_helper
INFO - 2022-03-15 06:07:26 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:07:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:07:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:07:26 --> Controller Class Initialized
INFO - 2022-03-15 06:07:26 --> Form Validation Class Initialized
INFO - 2022-03-15 06:07:26 --> Model "Case_model" initialized
INFO - 2022-03-15 06:07:26 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 06:07:26 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 06:07:26 --> File loaded: /home3/karoteam/public_html/application/views/cases/patient_amount_disbursed.php
INFO - 2022-03-15 06:07:26 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 06:07:26 --> Final output sent to browser
DEBUG - 2022-03-15 06:07:26 --> Total execution time: 0.1524
ERROR - 2022-03-15 06:07:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:07:28 --> Config Class Initialized
INFO - 2022-03-15 06:07:28 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:07:28 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:07:28 --> Utf8 Class Initialized
INFO - 2022-03-15 06:07:28 --> URI Class Initialized
INFO - 2022-03-15 06:07:28 --> Router Class Initialized
INFO - 2022-03-15 06:07:28 --> Output Class Initialized
INFO - 2022-03-15 06:07:28 --> Security Class Initialized
DEBUG - 2022-03-15 06:07:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:07:28 --> Input Class Initialized
INFO - 2022-03-15 06:07:28 --> Language Class Initialized
ERROR - 2022-03-15 06:07:28 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-15 06:07:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:07:36 --> Config Class Initialized
INFO - 2022-03-15 06:07:36 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:07:36 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:07:36 --> Utf8 Class Initialized
INFO - 2022-03-15 06:07:36 --> URI Class Initialized
INFO - 2022-03-15 06:07:36 --> Router Class Initialized
INFO - 2022-03-15 06:07:36 --> Output Class Initialized
INFO - 2022-03-15 06:07:36 --> Security Class Initialized
DEBUG - 2022-03-15 06:07:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:07:36 --> Input Class Initialized
INFO - 2022-03-15 06:07:36 --> Language Class Initialized
INFO - 2022-03-15 06:07:36 --> Loader Class Initialized
INFO - 2022-03-15 06:07:36 --> Helper loaded: url_helper
INFO - 2022-03-15 06:07:36 --> Helper loaded: form_helper
INFO - 2022-03-15 06:07:36 --> Helper loaded: common_helper
INFO - 2022-03-15 06:07:36 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:07:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:07:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:07:36 --> Controller Class Initialized
INFO - 2022-03-15 06:07:36 --> Form Validation Class Initialized
DEBUG - 2022-03-15 06:07:36 --> Encrypt Class Initialized
INFO - 2022-03-15 06:07:36 --> Model "Patient_model" initialized
INFO - 2022-03-15 06:07:36 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 06:07:36 --> Model "Referredby_model" initialized
INFO - 2022-03-15 06:07:36 --> Model "Prefix_master" initialized
INFO - 2022-03-15 06:07:36 --> Model "Hospital_model" initialized
ERROR - 2022-03-15 06:07:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:07:37 --> Config Class Initialized
INFO - 2022-03-15 06:07:37 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:07:37 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:07:37 --> Utf8 Class Initialized
INFO - 2022-03-15 06:07:37 --> URI Class Initialized
INFO - 2022-03-15 06:07:37 --> Router Class Initialized
INFO - 2022-03-15 06:07:37 --> Output Class Initialized
INFO - 2022-03-15 06:07:37 --> Security Class Initialized
DEBUG - 2022-03-15 06:07:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:07:37 --> Input Class Initialized
INFO - 2022-03-15 06:07:37 --> Language Class Initialized
INFO - 2022-03-15 06:07:37 --> Loader Class Initialized
INFO - 2022-03-15 06:07:37 --> Helper loaded: url_helper
INFO - 2022-03-15 06:07:37 --> Helper loaded: form_helper
INFO - 2022-03-15 06:07:37 --> Helper loaded: common_helper
INFO - 2022-03-15 06:07:37 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:07:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:07:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:07:37 --> Controller Class Initialized
INFO - 2022-03-15 06:07:37 --> Form Validation Class Initialized
DEBUG - 2022-03-15 06:07:37 --> Encrypt Class Initialized
INFO - 2022-03-15 06:07:37 --> Model "Patient_model" initialized
INFO - 2022-03-15 06:07:37 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 06:07:37 --> Model "Referredby_model" initialized
INFO - 2022-03-15 06:07:37 --> Model "Prefix_master" initialized
INFO - 2022-03-15 06:07:37 --> Model "Hospital_model" initialized
INFO - 2022-03-15 06:07:37 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 06:07:37 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-15 06:07:37 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 06:07:37 --> Final output sent to browser
DEBUG - 2022-03-15 06:07:37 --> Total execution time: 0.0828
ERROR - 2022-03-15 06:07:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:07:38 --> Config Class Initialized
INFO - 2022-03-15 06:07:38 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:07:38 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:07:38 --> Utf8 Class Initialized
INFO - 2022-03-15 06:07:38 --> URI Class Initialized
INFO - 2022-03-15 06:07:38 --> Router Class Initialized
INFO - 2022-03-15 06:07:38 --> Output Class Initialized
INFO - 2022-03-15 06:07:38 --> Security Class Initialized
DEBUG - 2022-03-15 06:07:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:07:38 --> Input Class Initialized
INFO - 2022-03-15 06:07:38 --> Language Class Initialized
INFO - 2022-03-15 06:07:38 --> Loader Class Initialized
INFO - 2022-03-15 06:07:38 --> Helper loaded: url_helper
INFO - 2022-03-15 06:07:38 --> Helper loaded: form_helper
INFO - 2022-03-15 06:07:38 --> Helper loaded: common_helper
INFO - 2022-03-15 06:07:38 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:07:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:07:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:07:38 --> Controller Class Initialized
INFO - 2022-03-15 06:07:38 --> Form Validation Class Initialized
DEBUG - 2022-03-15 06:07:38 --> Encrypt Class Initialized
INFO - 2022-03-15 06:07:38 --> Model "Patient_model" initialized
INFO - 2022-03-15 06:07:38 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 06:07:38 --> Model "Prefix_master" initialized
INFO - 2022-03-15 06:07:38 --> Model "Users_model" initialized
INFO - 2022-03-15 06:07:38 --> Model "Hospital_model" initialized
INFO - 2022-03-15 06:07:38 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 06:07:38 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-15 06:07:38 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 06:07:38 --> Final output sent to browser
DEBUG - 2022-03-15 06:07:38 --> Total execution time: 0.1007
ERROR - 2022-03-15 06:07:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:07:46 --> Config Class Initialized
INFO - 2022-03-15 06:07:46 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:07:46 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:07:46 --> Utf8 Class Initialized
INFO - 2022-03-15 06:07:46 --> URI Class Initialized
INFO - 2022-03-15 06:07:46 --> Router Class Initialized
INFO - 2022-03-15 06:07:46 --> Output Class Initialized
INFO - 2022-03-15 06:07:46 --> Security Class Initialized
DEBUG - 2022-03-15 06:07:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:07:46 --> Input Class Initialized
INFO - 2022-03-15 06:07:46 --> Language Class Initialized
INFO - 2022-03-15 06:07:46 --> Loader Class Initialized
INFO - 2022-03-15 06:07:46 --> Helper loaded: url_helper
INFO - 2022-03-15 06:07:46 --> Helper loaded: form_helper
INFO - 2022-03-15 06:07:46 --> Helper loaded: common_helper
INFO - 2022-03-15 06:07:46 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:07:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:07:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:07:46 --> Controller Class Initialized
INFO - 2022-03-15 06:07:46 --> Form Validation Class Initialized
INFO - 2022-03-15 06:07:46 --> Model "Case_model" initialized
INFO - 2022-03-15 06:07:46 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 06:07:47 --> Final output sent to browser
DEBUG - 2022-03-15 06:07:47 --> Total execution time: 0.0366
ERROR - 2022-03-15 06:07:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:07:53 --> Config Class Initialized
INFO - 2022-03-15 06:07:53 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:07:53 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:07:53 --> Utf8 Class Initialized
INFO - 2022-03-15 06:07:53 --> URI Class Initialized
INFO - 2022-03-15 06:07:53 --> Router Class Initialized
INFO - 2022-03-15 06:07:53 --> Output Class Initialized
INFO - 2022-03-15 06:07:53 --> Security Class Initialized
DEBUG - 2022-03-15 06:07:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:07:53 --> Input Class Initialized
INFO - 2022-03-15 06:07:53 --> Language Class Initialized
INFO - 2022-03-15 06:07:53 --> Loader Class Initialized
INFO - 2022-03-15 06:07:53 --> Helper loaded: url_helper
INFO - 2022-03-15 06:07:53 --> Helper loaded: form_helper
INFO - 2022-03-15 06:07:53 --> Helper loaded: common_helper
INFO - 2022-03-15 06:07:53 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:07:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:07:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:07:53 --> Controller Class Initialized
INFO - 2022-03-15 06:07:53 --> Form Validation Class Initialized
DEBUG - 2022-03-15 06:07:53 --> Encrypt Class Initialized
INFO - 2022-03-15 06:07:53 --> Model "Patient_model" initialized
INFO - 2022-03-15 06:07:53 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 06:07:53 --> Model "Referredby_model" initialized
INFO - 2022-03-15 06:07:53 --> Model "Prefix_master" initialized
INFO - 2022-03-15 06:07:53 --> Model "Hospital_model" initialized
INFO - 2022-03-15 06:07:53 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 06:07:53 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-15 06:07:53 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 06:07:53 --> Final output sent to browser
DEBUG - 2022-03-15 06:07:53 --> Total execution time: 0.0889
ERROR - 2022-03-15 06:08:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:08:00 --> Config Class Initialized
INFO - 2022-03-15 06:08:00 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:08:00 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:08:00 --> Utf8 Class Initialized
INFO - 2022-03-15 06:08:00 --> URI Class Initialized
INFO - 2022-03-15 06:08:00 --> Router Class Initialized
INFO - 2022-03-15 06:08:00 --> Output Class Initialized
INFO - 2022-03-15 06:08:00 --> Security Class Initialized
DEBUG - 2022-03-15 06:08:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:08:00 --> Input Class Initialized
INFO - 2022-03-15 06:08:00 --> Language Class Initialized
INFO - 2022-03-15 06:08:00 --> Loader Class Initialized
INFO - 2022-03-15 06:08:00 --> Helper loaded: url_helper
INFO - 2022-03-15 06:08:00 --> Helper loaded: form_helper
INFO - 2022-03-15 06:08:00 --> Helper loaded: common_helper
INFO - 2022-03-15 06:08:00 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:08:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:08:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:08:00 --> Controller Class Initialized
INFO - 2022-03-15 06:08:00 --> Form Validation Class Initialized
DEBUG - 2022-03-15 06:08:00 --> Encrypt Class Initialized
INFO - 2022-03-15 06:08:00 --> Model "Patient_model" initialized
INFO - 2022-03-15 06:08:00 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 06:08:00 --> Model "Referredby_model" initialized
INFO - 2022-03-15 06:08:00 --> Model "Prefix_master" initialized
INFO - 2022-03-15 06:08:00 --> Model "Hospital_model" initialized
INFO - 2022-03-15 06:08:00 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 06:08:00 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-15 06:08:00 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 06:08:00 --> Final output sent to browser
DEBUG - 2022-03-15 06:08:00 --> Total execution time: 0.0615
ERROR - 2022-03-15 06:08:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:08:01 --> Config Class Initialized
INFO - 2022-03-15 06:08:01 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:08:01 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:08:01 --> Utf8 Class Initialized
INFO - 2022-03-15 06:08:01 --> URI Class Initialized
INFO - 2022-03-15 06:08:01 --> Router Class Initialized
INFO - 2022-03-15 06:08:01 --> Output Class Initialized
INFO - 2022-03-15 06:08:01 --> Security Class Initialized
DEBUG - 2022-03-15 06:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:08:01 --> Input Class Initialized
INFO - 2022-03-15 06:08:01 --> Language Class Initialized
INFO - 2022-03-15 06:08:01 --> Loader Class Initialized
INFO - 2022-03-15 06:08:01 --> Helper loaded: url_helper
INFO - 2022-03-15 06:08:01 --> Helper loaded: form_helper
INFO - 2022-03-15 06:08:01 --> Helper loaded: common_helper
INFO - 2022-03-15 06:08:01 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:08:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:08:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:08:01 --> Controller Class Initialized
INFO - 2022-03-15 06:08:01 --> Form Validation Class Initialized
INFO - 2022-03-15 06:08:01 --> Model "Case_model" initialized
INFO - 2022-03-15 06:08:01 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 06:08:01 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 06:08:01 --> File loaded: /home3/karoteam/public_html/application/views/cases/edit_sanction_details.php
INFO - 2022-03-15 06:08:01 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 06:08:01 --> Final output sent to browser
DEBUG - 2022-03-15 06:08:01 --> Total execution time: 0.0571
ERROR - 2022-03-15 06:08:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:08:02 --> Config Class Initialized
INFO - 2022-03-15 06:08:02 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:08:02 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:08:02 --> Utf8 Class Initialized
INFO - 2022-03-15 06:08:02 --> URI Class Initialized
INFO - 2022-03-15 06:08:02 --> Router Class Initialized
INFO - 2022-03-15 06:08:02 --> Output Class Initialized
INFO - 2022-03-15 06:08:02 --> Security Class Initialized
DEBUG - 2022-03-15 06:08:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:08:02 --> Input Class Initialized
INFO - 2022-03-15 06:08:02 --> Language Class Initialized
ERROR - 2022-03-15 06:08:02 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-15 06:08:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:08:12 --> Config Class Initialized
INFO - 2022-03-15 06:08:12 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:08:12 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:08:12 --> Utf8 Class Initialized
INFO - 2022-03-15 06:08:12 --> URI Class Initialized
INFO - 2022-03-15 06:08:12 --> Router Class Initialized
INFO - 2022-03-15 06:08:12 --> Output Class Initialized
INFO - 2022-03-15 06:08:12 --> Security Class Initialized
DEBUG - 2022-03-15 06:08:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:08:12 --> Input Class Initialized
INFO - 2022-03-15 06:08:12 --> Language Class Initialized
INFO - 2022-03-15 06:08:12 --> Loader Class Initialized
INFO - 2022-03-15 06:08:12 --> Helper loaded: url_helper
INFO - 2022-03-15 06:08:12 --> Helper loaded: form_helper
INFO - 2022-03-15 06:08:12 --> Helper loaded: common_helper
INFO - 2022-03-15 06:08:12 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:08:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:08:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:08:12 --> Controller Class Initialized
INFO - 2022-03-15 06:08:12 --> Form Validation Class Initialized
DEBUG - 2022-03-15 06:08:12 --> Encrypt Class Initialized
INFO - 2022-03-15 06:08:12 --> Model "Patient_model" initialized
INFO - 2022-03-15 06:08:12 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 06:08:12 --> Model "Referredby_model" initialized
INFO - 2022-03-15 06:08:12 --> Model "Prefix_master" initialized
INFO - 2022-03-15 06:08:12 --> Model "Hospital_model" initialized
ERROR - 2022-03-15 06:08:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:08:13 --> Config Class Initialized
INFO - 2022-03-15 06:08:13 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:08:13 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:08:13 --> Utf8 Class Initialized
INFO - 2022-03-15 06:08:13 --> URI Class Initialized
INFO - 2022-03-15 06:08:13 --> Router Class Initialized
INFO - 2022-03-15 06:08:13 --> Output Class Initialized
INFO - 2022-03-15 06:08:13 --> Security Class Initialized
DEBUG - 2022-03-15 06:08:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:08:13 --> Input Class Initialized
INFO - 2022-03-15 06:08:13 --> Language Class Initialized
INFO - 2022-03-15 06:08:13 --> Loader Class Initialized
INFO - 2022-03-15 06:08:13 --> Helper loaded: url_helper
INFO - 2022-03-15 06:08:13 --> Helper loaded: form_helper
INFO - 2022-03-15 06:08:13 --> Helper loaded: common_helper
INFO - 2022-03-15 06:08:13 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:08:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:08:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:08:13 --> Controller Class Initialized
INFO - 2022-03-15 06:08:13 --> Form Validation Class Initialized
DEBUG - 2022-03-15 06:08:13 --> Encrypt Class Initialized
INFO - 2022-03-15 06:08:13 --> Model "Patient_model" initialized
INFO - 2022-03-15 06:08:13 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 06:08:13 --> Model "Referredby_model" initialized
INFO - 2022-03-15 06:08:13 --> Model "Prefix_master" initialized
INFO - 2022-03-15 06:08:13 --> Model "Hospital_model" initialized
INFO - 2022-03-15 06:08:13 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 06:08:13 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-15 06:08:13 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 06:08:13 --> Final output sent to browser
DEBUG - 2022-03-15 06:08:13 --> Total execution time: 0.0730
ERROR - 2022-03-15 06:08:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:08:14 --> Config Class Initialized
INFO - 2022-03-15 06:08:14 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:08:14 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:08:14 --> Utf8 Class Initialized
INFO - 2022-03-15 06:08:14 --> URI Class Initialized
INFO - 2022-03-15 06:08:14 --> Router Class Initialized
INFO - 2022-03-15 06:08:14 --> Output Class Initialized
INFO - 2022-03-15 06:08:14 --> Security Class Initialized
DEBUG - 2022-03-15 06:08:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:08:14 --> Input Class Initialized
INFO - 2022-03-15 06:08:14 --> Language Class Initialized
INFO - 2022-03-15 06:08:14 --> Loader Class Initialized
INFO - 2022-03-15 06:08:14 --> Helper loaded: url_helper
INFO - 2022-03-15 06:08:14 --> Helper loaded: form_helper
INFO - 2022-03-15 06:08:14 --> Helper loaded: common_helper
INFO - 2022-03-15 06:08:14 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:08:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:08:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:08:14 --> Controller Class Initialized
INFO - 2022-03-15 06:08:14 --> Form Validation Class Initialized
DEBUG - 2022-03-15 06:08:14 --> Encrypt Class Initialized
INFO - 2022-03-15 06:08:14 --> Model "Patient_model" initialized
INFO - 2022-03-15 06:08:14 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 06:08:14 --> Model "Prefix_master" initialized
INFO - 2022-03-15 06:08:14 --> Model "Users_model" initialized
INFO - 2022-03-15 06:08:14 --> Model "Hospital_model" initialized
INFO - 2022-03-15 06:08:14 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 06:08:14 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-15 06:08:14 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 06:08:14 --> Final output sent to browser
DEBUG - 2022-03-15 06:08:14 --> Total execution time: 0.0710
ERROR - 2022-03-15 06:08:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:08:18 --> Config Class Initialized
INFO - 2022-03-15 06:08:18 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:08:18 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:08:18 --> Utf8 Class Initialized
INFO - 2022-03-15 06:08:18 --> URI Class Initialized
INFO - 2022-03-15 06:08:18 --> Router Class Initialized
INFO - 2022-03-15 06:08:18 --> Output Class Initialized
INFO - 2022-03-15 06:08:18 --> Security Class Initialized
DEBUG - 2022-03-15 06:08:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:08:18 --> Input Class Initialized
INFO - 2022-03-15 06:08:18 --> Language Class Initialized
INFO - 2022-03-15 06:08:18 --> Loader Class Initialized
INFO - 2022-03-15 06:08:18 --> Helper loaded: url_helper
INFO - 2022-03-15 06:08:18 --> Helper loaded: form_helper
INFO - 2022-03-15 06:08:18 --> Helper loaded: common_helper
INFO - 2022-03-15 06:08:18 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:08:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:08:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:08:18 --> Controller Class Initialized
INFO - 2022-03-15 06:08:18 --> Form Validation Class Initialized
INFO - 2022-03-15 06:08:18 --> Model "Case_model" initialized
INFO - 2022-03-15 06:08:18 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 06:08:18 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 06:08:18 --> File loaded: /home3/karoteam/public_html/application/views/cases/patient_amount_disbursed.php
INFO - 2022-03-15 06:08:18 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 06:08:18 --> Final output sent to browser
DEBUG - 2022-03-15 06:08:18 --> Total execution time: 0.0678
ERROR - 2022-03-15 06:08:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:08:19 --> Config Class Initialized
INFO - 2022-03-15 06:08:19 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:08:19 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:08:19 --> Utf8 Class Initialized
INFO - 2022-03-15 06:08:19 --> URI Class Initialized
INFO - 2022-03-15 06:08:19 --> Router Class Initialized
INFO - 2022-03-15 06:08:19 --> Output Class Initialized
INFO - 2022-03-15 06:08:19 --> Security Class Initialized
DEBUG - 2022-03-15 06:08:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:08:19 --> Input Class Initialized
INFO - 2022-03-15 06:08:19 --> Language Class Initialized
ERROR - 2022-03-15 06:08:19 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-15 06:08:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:08:29 --> Config Class Initialized
INFO - 2022-03-15 06:08:29 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:08:29 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:08:29 --> Utf8 Class Initialized
INFO - 2022-03-15 06:08:29 --> URI Class Initialized
INFO - 2022-03-15 06:08:29 --> Router Class Initialized
INFO - 2022-03-15 06:08:29 --> Output Class Initialized
INFO - 2022-03-15 06:08:29 --> Security Class Initialized
DEBUG - 2022-03-15 06:08:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:08:29 --> Input Class Initialized
INFO - 2022-03-15 06:08:29 --> Language Class Initialized
INFO - 2022-03-15 06:08:29 --> Loader Class Initialized
INFO - 2022-03-15 06:08:29 --> Helper loaded: url_helper
INFO - 2022-03-15 06:08:29 --> Helper loaded: form_helper
INFO - 2022-03-15 06:08:29 --> Helper loaded: common_helper
INFO - 2022-03-15 06:08:29 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:08:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:08:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:08:29 --> Controller Class Initialized
INFO - 2022-03-15 06:08:29 --> Form Validation Class Initialized
INFO - 2022-03-15 06:08:29 --> Model "Case_model" initialized
INFO - 2022-03-15 06:08:29 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 06:08:29 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 06:08:29 --> File loaded: /home3/karoteam/public_html/application/views/cases/edit_sanction_details.php
INFO - 2022-03-15 06:08:29 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 06:08:29 --> Final output sent to browser
DEBUG - 2022-03-15 06:08:29 --> Total execution time: 0.0549
ERROR - 2022-03-15 06:08:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:08:30 --> Config Class Initialized
INFO - 2022-03-15 06:08:30 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:08:30 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:08:30 --> Utf8 Class Initialized
INFO - 2022-03-15 06:08:30 --> URI Class Initialized
INFO - 2022-03-15 06:08:30 --> Router Class Initialized
INFO - 2022-03-15 06:08:30 --> Output Class Initialized
INFO - 2022-03-15 06:08:30 --> Security Class Initialized
DEBUG - 2022-03-15 06:08:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:08:30 --> Input Class Initialized
INFO - 2022-03-15 06:08:30 --> Language Class Initialized
ERROR - 2022-03-15 06:08:30 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-15 06:08:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:08:35 --> Config Class Initialized
INFO - 2022-03-15 06:08:35 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:08:35 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:08:35 --> Utf8 Class Initialized
INFO - 2022-03-15 06:08:35 --> URI Class Initialized
INFO - 2022-03-15 06:08:35 --> Router Class Initialized
INFO - 2022-03-15 06:08:35 --> Output Class Initialized
INFO - 2022-03-15 06:08:35 --> Security Class Initialized
DEBUG - 2022-03-15 06:08:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:08:35 --> Input Class Initialized
INFO - 2022-03-15 06:08:35 --> Language Class Initialized
INFO - 2022-03-15 06:08:35 --> Loader Class Initialized
INFO - 2022-03-15 06:08:35 --> Helper loaded: url_helper
INFO - 2022-03-15 06:08:35 --> Helper loaded: form_helper
INFO - 2022-03-15 06:08:35 --> Helper loaded: common_helper
INFO - 2022-03-15 06:08:35 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:08:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:08:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:08:35 --> Controller Class Initialized
INFO - 2022-03-15 06:08:35 --> Form Validation Class Initialized
DEBUG - 2022-03-15 06:08:35 --> Encrypt Class Initialized
INFO - 2022-03-15 06:08:35 --> Model "Patient_model" initialized
INFO - 2022-03-15 06:08:35 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 06:08:35 --> Model "Referredby_model" initialized
INFO - 2022-03-15 06:08:35 --> Model "Prefix_master" initialized
INFO - 2022-03-15 06:08:35 --> Model "Hospital_model" initialized
INFO - 2022-03-15 06:08:35 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 06:08:35 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-15 06:08:35 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 06:08:35 --> Final output sent to browser
DEBUG - 2022-03-15 06:08:35 --> Total execution time: 0.0631
ERROR - 2022-03-15 06:08:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:08:36 --> Config Class Initialized
INFO - 2022-03-15 06:08:36 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:08:36 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:08:36 --> Utf8 Class Initialized
INFO - 2022-03-15 06:08:36 --> URI Class Initialized
INFO - 2022-03-15 06:08:36 --> Router Class Initialized
INFO - 2022-03-15 06:08:36 --> Output Class Initialized
INFO - 2022-03-15 06:08:36 --> Security Class Initialized
DEBUG - 2022-03-15 06:08:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:08:36 --> Input Class Initialized
INFO - 2022-03-15 06:08:36 --> Language Class Initialized
INFO - 2022-03-15 06:08:36 --> Loader Class Initialized
INFO - 2022-03-15 06:08:36 --> Helper loaded: url_helper
INFO - 2022-03-15 06:08:36 --> Helper loaded: form_helper
INFO - 2022-03-15 06:08:36 --> Helper loaded: common_helper
INFO - 2022-03-15 06:08:36 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:08:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:08:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:08:36 --> Controller Class Initialized
INFO - 2022-03-15 06:08:36 --> Form Validation Class Initialized
INFO - 2022-03-15 06:08:36 --> Model "Case_model" initialized
INFO - 2022-03-15 06:08:36 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 06:08:36 --> Final output sent to browser
DEBUG - 2022-03-15 06:08:36 --> Total execution time: 0.0337
ERROR - 2022-03-15 06:08:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:08:42 --> Config Class Initialized
INFO - 2022-03-15 06:08:42 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:08:42 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:08:42 --> Utf8 Class Initialized
INFO - 2022-03-15 06:08:42 --> URI Class Initialized
INFO - 2022-03-15 06:08:42 --> Router Class Initialized
INFO - 2022-03-15 06:08:42 --> Output Class Initialized
INFO - 2022-03-15 06:08:42 --> Security Class Initialized
DEBUG - 2022-03-15 06:08:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:08:42 --> Input Class Initialized
INFO - 2022-03-15 06:08:42 --> Language Class Initialized
ERROR - 2022-03-15 06:08:42 --> 404 Page Not Found: Karoclient/css
ERROR - 2022-03-15 06:08:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:08:58 --> Config Class Initialized
INFO - 2022-03-15 06:08:58 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:08:58 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:08:58 --> Utf8 Class Initialized
INFO - 2022-03-15 06:08:58 --> URI Class Initialized
INFO - 2022-03-15 06:08:58 --> Router Class Initialized
INFO - 2022-03-15 06:08:58 --> Output Class Initialized
INFO - 2022-03-15 06:08:58 --> Security Class Initialized
DEBUG - 2022-03-15 06:08:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:08:58 --> Input Class Initialized
INFO - 2022-03-15 06:08:58 --> Language Class Initialized
INFO - 2022-03-15 06:08:58 --> Loader Class Initialized
INFO - 2022-03-15 06:08:58 --> Helper loaded: url_helper
INFO - 2022-03-15 06:08:58 --> Helper loaded: form_helper
INFO - 2022-03-15 06:08:58 --> Helper loaded: common_helper
INFO - 2022-03-15 06:08:58 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:08:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:08:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:08:58 --> Controller Class Initialized
INFO - 2022-03-15 06:08:58 --> Form Validation Class Initialized
DEBUG - 2022-03-15 06:08:58 --> Encrypt Class Initialized
INFO - 2022-03-15 06:08:58 --> Model "Patient_model" initialized
INFO - 2022-03-15 06:08:58 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 06:08:58 --> Model "Prefix_master" initialized
INFO - 2022-03-15 06:08:58 --> Model "Users_model" initialized
INFO - 2022-03-15 06:08:58 --> Model "Hospital_model" initialized
INFO - 2022-03-15 06:08:58 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 06:08:58 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-15 06:08:58 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 06:08:58 --> Final output sent to browser
DEBUG - 2022-03-15 06:08:58 --> Total execution time: 0.0941
ERROR - 2022-03-15 06:09:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:09:16 --> Config Class Initialized
INFO - 2022-03-15 06:09:16 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:09:16 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:09:16 --> Utf8 Class Initialized
INFO - 2022-03-15 06:09:16 --> URI Class Initialized
INFO - 2022-03-15 06:09:16 --> Router Class Initialized
INFO - 2022-03-15 06:09:16 --> Output Class Initialized
INFO - 2022-03-15 06:09:16 --> Security Class Initialized
DEBUG - 2022-03-15 06:09:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:09:16 --> Input Class Initialized
INFO - 2022-03-15 06:09:16 --> Language Class Initialized
INFO - 2022-03-15 06:09:16 --> Loader Class Initialized
INFO - 2022-03-15 06:09:16 --> Helper loaded: url_helper
INFO - 2022-03-15 06:09:16 --> Helper loaded: form_helper
INFO - 2022-03-15 06:09:16 --> Helper loaded: common_helper
INFO - 2022-03-15 06:09:16 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:09:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:09:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:09:16 --> Controller Class Initialized
INFO - 2022-03-15 06:09:16 --> Form Validation Class Initialized
INFO - 2022-03-15 06:09:16 --> Model "Case_model" initialized
INFO - 2022-03-15 06:09:16 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 06:09:18 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 06:09:18 --> Model "Case_model" initialized
ERROR - 2022-03-15 06:09:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:09:19 --> Config Class Initialized
INFO - 2022-03-15 06:09:19 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:09:19 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:09:19 --> Utf8 Class Initialized
INFO - 2022-03-15 06:09:19 --> URI Class Initialized
INFO - 2022-03-15 06:09:19 --> Router Class Initialized
INFO - 2022-03-15 06:09:19 --> Output Class Initialized
INFO - 2022-03-15 06:09:19 --> Security Class Initialized
DEBUG - 2022-03-15 06:09:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:09:19 --> Input Class Initialized
INFO - 2022-03-15 06:09:19 --> Language Class Initialized
INFO - 2022-03-15 06:09:19 --> Loader Class Initialized
INFO - 2022-03-15 06:09:19 --> Helper loaded: url_helper
INFO - 2022-03-15 06:09:19 --> Helper loaded: form_helper
INFO - 2022-03-15 06:09:19 --> Helper loaded: common_helper
INFO - 2022-03-15 06:09:19 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:09:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:09:21 --> File loaded: /home3/karoteam/public_html/application/views/cases/closed_case.php
INFO - 2022-03-15 06:09:21 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 06:09:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:09:21 --> Controller Class Initialized
INFO - 2022-03-15 06:09:21 --> Form Validation Class Initialized
INFO - 2022-03-15 06:09:21 --> Model "Case_model" initialized
INFO - 2022-03-15 06:09:21 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 06:09:23 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 06:09:23 --> Model "Case_model" initialized
INFO - 2022-03-15 06:09:25 --> File loaded: /home3/karoteam/public_html/application/views/cases/closed_case.php
INFO - 2022-03-15 06:09:25 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 06:09:26 --> Final output sent to browser
DEBUG - 2022-03-15 06:09:26 --> Total execution time: 5.4755
ERROR - 2022-03-15 06:09:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:09:26 --> Config Class Initialized
INFO - 2022-03-15 06:09:26 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:09:26 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:09:26 --> Utf8 Class Initialized
INFO - 2022-03-15 06:09:26 --> URI Class Initialized
INFO - 2022-03-15 06:09:26 --> Router Class Initialized
INFO - 2022-03-15 06:09:26 --> Output Class Initialized
INFO - 2022-03-15 06:09:26 --> Security Class Initialized
DEBUG - 2022-03-15 06:09:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:09:26 --> Input Class Initialized
INFO - 2022-03-15 06:09:26 --> Language Class Initialized
ERROR - 2022-03-15 06:09:26 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-15 06:09:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:09:28 --> Config Class Initialized
INFO - 2022-03-15 06:09:28 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:09:28 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:09:28 --> Utf8 Class Initialized
INFO - 2022-03-15 06:09:28 --> URI Class Initialized
INFO - 2022-03-15 06:09:28 --> Router Class Initialized
INFO - 2022-03-15 06:09:28 --> Output Class Initialized
INFO - 2022-03-15 06:09:28 --> Security Class Initialized
DEBUG - 2022-03-15 06:09:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:09:28 --> Input Class Initialized
INFO - 2022-03-15 06:09:28 --> Language Class Initialized
INFO - 2022-03-15 06:09:28 --> Loader Class Initialized
INFO - 2022-03-15 06:09:28 --> Helper loaded: url_helper
INFO - 2022-03-15 06:09:28 --> Helper loaded: form_helper
INFO - 2022-03-15 06:09:28 --> Helper loaded: common_helper
INFO - 2022-03-15 06:09:28 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:09:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:09:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:09:28 --> Controller Class Initialized
INFO - 2022-03-15 06:09:28 --> Form Validation Class Initialized
INFO - 2022-03-15 06:09:28 --> Model "Case_model" initialized
INFO - 2022-03-15 06:09:28 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 06:09:28 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 06:09:28 --> File loaded: /home3/karoteam/public_html/application/views/cases/new_case.php
INFO - 2022-03-15 06:09:28 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 06:09:28 --> Final output sent to browser
DEBUG - 2022-03-15 06:09:28 --> Total execution time: 0.0745
ERROR - 2022-03-15 06:09:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:09:48 --> Config Class Initialized
INFO - 2022-03-15 06:09:48 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:09:48 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:09:48 --> Utf8 Class Initialized
INFO - 2022-03-15 06:09:48 --> URI Class Initialized
INFO - 2022-03-15 06:09:48 --> Router Class Initialized
INFO - 2022-03-15 06:09:48 --> Output Class Initialized
INFO - 2022-03-15 06:09:48 --> Security Class Initialized
DEBUG - 2022-03-15 06:09:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:09:48 --> Input Class Initialized
INFO - 2022-03-15 06:09:48 --> Language Class Initialized
INFO - 2022-03-15 06:09:48 --> Loader Class Initialized
INFO - 2022-03-15 06:09:48 --> Helper loaded: url_helper
INFO - 2022-03-15 06:09:48 --> Helper loaded: form_helper
INFO - 2022-03-15 06:09:48 --> Helper loaded: common_helper
INFO - 2022-03-15 06:09:48 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:09:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:09:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:09:48 --> Controller Class Initialized
INFO - 2022-03-15 06:09:48 --> Form Validation Class Initialized
DEBUG - 2022-03-15 06:09:48 --> Encrypt Class Initialized
INFO - 2022-03-15 06:09:48 --> Model "Patient_model" initialized
INFO - 2022-03-15 06:09:48 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 06:09:48 --> Model "Prefix_master" initialized
INFO - 2022-03-15 06:09:48 --> Model "Users_model" initialized
INFO - 2022-03-15 06:09:48 --> Model "Hospital_model" initialized
INFO - 2022-03-15 06:09:48 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 06:09:48 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-15 06:09:48 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 06:09:48 --> Final output sent to browser
DEBUG - 2022-03-15 06:09:48 --> Total execution time: 0.0761
ERROR - 2022-03-15 06:09:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:09:49 --> Config Class Initialized
INFO - 2022-03-15 06:09:49 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:09:49 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:09:49 --> Utf8 Class Initialized
INFO - 2022-03-15 06:09:49 --> URI Class Initialized
INFO - 2022-03-15 06:09:49 --> Router Class Initialized
INFO - 2022-03-15 06:09:49 --> Output Class Initialized
INFO - 2022-03-15 06:09:49 --> Security Class Initialized
DEBUG - 2022-03-15 06:09:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:09:49 --> Input Class Initialized
INFO - 2022-03-15 06:09:49 --> Language Class Initialized
INFO - 2022-03-15 06:09:49 --> Loader Class Initialized
INFO - 2022-03-15 06:09:49 --> Helper loaded: url_helper
INFO - 2022-03-15 06:09:49 --> Helper loaded: form_helper
INFO - 2022-03-15 06:09:49 --> Helper loaded: common_helper
INFO - 2022-03-15 06:09:49 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:09:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:09:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:09:49 --> Controller Class Initialized
INFO - 2022-03-15 06:09:49 --> Form Validation Class Initialized
DEBUG - 2022-03-15 06:09:49 --> Encrypt Class Initialized
INFO - 2022-03-15 06:09:49 --> Model "Patient_model" initialized
INFO - 2022-03-15 06:09:49 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 06:09:49 --> Model "Prefix_master" initialized
INFO - 2022-03-15 06:09:49 --> Model "Users_model" initialized
INFO - 2022-03-15 06:09:49 --> Model "Hospital_model" initialized
INFO - 2022-03-15 06:09:49 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 06:09:49 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-15 06:09:49 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 06:09:49 --> Final output sent to browser
DEBUG - 2022-03-15 06:09:49 --> Total execution time: 0.0726
ERROR - 2022-03-15 06:09:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:09:49 --> Config Class Initialized
INFO - 2022-03-15 06:09:49 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:09:49 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:09:49 --> Utf8 Class Initialized
INFO - 2022-03-15 06:09:49 --> URI Class Initialized
INFO - 2022-03-15 06:09:49 --> Router Class Initialized
INFO - 2022-03-15 06:09:49 --> Output Class Initialized
INFO - 2022-03-15 06:09:49 --> Security Class Initialized
DEBUG - 2022-03-15 06:09:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:09:49 --> Input Class Initialized
INFO - 2022-03-15 06:09:49 --> Language Class Initialized
ERROR - 2022-03-15 06:09:49 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-15 06:10:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:10:00 --> Config Class Initialized
INFO - 2022-03-15 06:10:00 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:10:00 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:10:00 --> Utf8 Class Initialized
INFO - 2022-03-15 06:10:00 --> URI Class Initialized
INFO - 2022-03-15 06:10:00 --> Router Class Initialized
INFO - 2022-03-15 06:10:00 --> Output Class Initialized
INFO - 2022-03-15 06:10:00 --> Security Class Initialized
DEBUG - 2022-03-15 06:10:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:10:00 --> Input Class Initialized
INFO - 2022-03-15 06:10:00 --> Language Class Initialized
INFO - 2022-03-15 06:10:00 --> Loader Class Initialized
INFO - 2022-03-15 06:10:00 --> Helper loaded: url_helper
INFO - 2022-03-15 06:10:00 --> Helper loaded: form_helper
INFO - 2022-03-15 06:10:00 --> Helper loaded: common_helper
INFO - 2022-03-15 06:10:00 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:10:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:10:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:10:00 --> Controller Class Initialized
INFO - 2022-03-15 06:10:00 --> Form Validation Class Initialized
DEBUG - 2022-03-15 06:10:00 --> Encrypt Class Initialized
INFO - 2022-03-15 06:10:00 --> Model "Patient_model" initialized
INFO - 2022-03-15 06:10:00 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 06:10:00 --> Model "Referredby_model" initialized
INFO - 2022-03-15 06:10:00 --> Model "Prefix_master" initialized
INFO - 2022-03-15 06:10:00 --> Model "Hospital_model" initialized
INFO - 2022-03-15 06:10:00 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 06:10:00 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-15 06:10:00 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 06:10:00 --> Final output sent to browser
DEBUG - 2022-03-15 06:10:00 --> Total execution time: 0.1059
ERROR - 2022-03-15 06:10:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:10:09 --> Config Class Initialized
INFO - 2022-03-15 06:10:09 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:10:09 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:10:09 --> Utf8 Class Initialized
INFO - 2022-03-15 06:10:09 --> URI Class Initialized
INFO - 2022-03-15 06:10:09 --> Router Class Initialized
INFO - 2022-03-15 06:10:09 --> Output Class Initialized
INFO - 2022-03-15 06:10:09 --> Security Class Initialized
DEBUG - 2022-03-15 06:10:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:10:09 --> Input Class Initialized
INFO - 2022-03-15 06:10:09 --> Language Class Initialized
INFO - 2022-03-15 06:10:09 --> Loader Class Initialized
INFO - 2022-03-15 06:10:09 --> Helper loaded: url_helper
INFO - 2022-03-15 06:10:09 --> Helper loaded: form_helper
INFO - 2022-03-15 06:10:09 --> Helper loaded: common_helper
INFO - 2022-03-15 06:10:09 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:10:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:10:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:10:09 --> Controller Class Initialized
INFO - 2022-03-15 06:10:09 --> Form Validation Class Initialized
INFO - 2022-03-15 06:10:09 --> Model "Case_model" initialized
INFO - 2022-03-15 06:10:09 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 06:10:09 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 06:10:09 --> File loaded: /home3/karoteam/public_html/application/views/cases/new_case.php
INFO - 2022-03-15 06:10:09 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 06:10:09 --> Final output sent to browser
DEBUG - 2022-03-15 06:10:09 --> Total execution time: 0.0676
ERROR - 2022-03-15 06:10:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:10:15 --> Config Class Initialized
INFO - 2022-03-15 06:10:15 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:10:15 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:10:15 --> Utf8 Class Initialized
INFO - 2022-03-15 06:10:15 --> URI Class Initialized
INFO - 2022-03-15 06:10:15 --> Router Class Initialized
INFO - 2022-03-15 06:10:15 --> Output Class Initialized
INFO - 2022-03-15 06:10:15 --> Security Class Initialized
DEBUG - 2022-03-15 06:10:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:10:15 --> Input Class Initialized
INFO - 2022-03-15 06:10:15 --> Language Class Initialized
INFO - 2022-03-15 06:10:15 --> Loader Class Initialized
INFO - 2022-03-15 06:10:15 --> Helper loaded: url_helper
INFO - 2022-03-15 06:10:15 --> Helper loaded: form_helper
INFO - 2022-03-15 06:10:15 --> Helper loaded: common_helper
INFO - 2022-03-15 06:10:15 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:10:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:10:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:10:15 --> Controller Class Initialized
INFO - 2022-03-15 06:10:15 --> Form Validation Class Initialized
INFO - 2022-03-15 06:10:15 --> Model "Case_model" initialized
INFO - 2022-03-15 06:10:15 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 06:10:15 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 06:10:15 --> File loaded: /home3/karoteam/public_html/application/views/cases/rehelp.php
INFO - 2022-03-15 06:10:15 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 06:10:15 --> Final output sent to browser
DEBUG - 2022-03-15 06:10:15 --> Total execution time: 0.0689
ERROR - 2022-03-15 06:10:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:10:16 --> Config Class Initialized
INFO - 2022-03-15 06:10:16 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:10:16 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:10:16 --> Utf8 Class Initialized
INFO - 2022-03-15 06:10:16 --> URI Class Initialized
INFO - 2022-03-15 06:10:16 --> Router Class Initialized
INFO - 2022-03-15 06:10:16 --> Output Class Initialized
INFO - 2022-03-15 06:10:16 --> Security Class Initialized
DEBUG - 2022-03-15 06:10:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:10:16 --> Input Class Initialized
INFO - 2022-03-15 06:10:16 --> Language Class Initialized
ERROR - 2022-03-15 06:10:16 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-15 06:12:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:12:29 --> Config Class Initialized
INFO - 2022-03-15 06:12:29 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:12:29 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:12:29 --> Utf8 Class Initialized
INFO - 2022-03-15 06:12:29 --> URI Class Initialized
DEBUG - 2022-03-15 06:12:29 --> No URI present. Default controller set.
INFO - 2022-03-15 06:12:29 --> Router Class Initialized
INFO - 2022-03-15 06:12:29 --> Output Class Initialized
INFO - 2022-03-15 06:12:29 --> Security Class Initialized
DEBUG - 2022-03-15 06:12:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:12:29 --> Input Class Initialized
INFO - 2022-03-15 06:12:29 --> Language Class Initialized
INFO - 2022-03-15 06:12:29 --> Loader Class Initialized
INFO - 2022-03-15 06:12:29 --> Helper loaded: url_helper
INFO - 2022-03-15 06:12:29 --> Helper loaded: form_helper
INFO - 2022-03-15 06:12:29 --> Helper loaded: common_helper
INFO - 2022-03-15 06:12:29 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:12:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:12:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:12:29 --> Controller Class Initialized
INFO - 2022-03-15 06:12:29 --> Form Validation Class Initialized
DEBUG - 2022-03-15 06:12:29 --> Encrypt Class Initialized
DEBUG - 2022-03-15 06:12:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-15 06:12:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-15 06:12:29 --> Email Class Initialized
INFO - 2022-03-15 06:12:29 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-15 06:12:29 --> Calendar Class Initialized
INFO - 2022-03-15 06:12:29 --> Model "Login_model" initialized
INFO - 2022-03-15 06:12:29 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-15 06:12:29 --> Final output sent to browser
DEBUG - 2022-03-15 06:12:29 --> Total execution time: 0.0368
ERROR - 2022-03-15 06:12:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:12:30 --> Config Class Initialized
INFO - 2022-03-15 06:12:30 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:12:30 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:12:30 --> Utf8 Class Initialized
INFO - 2022-03-15 06:12:30 --> URI Class Initialized
DEBUG - 2022-03-15 06:12:30 --> No URI present. Default controller set.
INFO - 2022-03-15 06:12:30 --> Router Class Initialized
INFO - 2022-03-15 06:12:30 --> Output Class Initialized
INFO - 2022-03-15 06:12:30 --> Security Class Initialized
DEBUG - 2022-03-15 06:12:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:12:30 --> Input Class Initialized
INFO - 2022-03-15 06:12:30 --> Language Class Initialized
INFO - 2022-03-15 06:12:30 --> Loader Class Initialized
INFO - 2022-03-15 06:12:30 --> Helper loaded: url_helper
INFO - 2022-03-15 06:12:30 --> Helper loaded: form_helper
INFO - 2022-03-15 06:12:30 --> Helper loaded: common_helper
INFO - 2022-03-15 06:12:30 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:12:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:12:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:12:30 --> Controller Class Initialized
INFO - 2022-03-15 06:12:30 --> Form Validation Class Initialized
DEBUG - 2022-03-15 06:12:30 --> Encrypt Class Initialized
DEBUG - 2022-03-15 06:12:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-15 06:12:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-15 06:12:30 --> Email Class Initialized
INFO - 2022-03-15 06:12:30 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-15 06:12:30 --> Calendar Class Initialized
INFO - 2022-03-15 06:12:30 --> Model "Login_model" initialized
INFO - 2022-03-15 06:12:30 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-15 06:12:30 --> Final output sent to browser
DEBUG - 2022-03-15 06:12:30 --> Total execution time: 0.0326
ERROR - 2022-03-15 06:12:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:12:37 --> Config Class Initialized
INFO - 2022-03-15 06:12:37 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:12:37 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:12:37 --> Utf8 Class Initialized
INFO - 2022-03-15 06:12:37 --> URI Class Initialized
INFO - 2022-03-15 06:12:37 --> Router Class Initialized
INFO - 2022-03-15 06:12:37 --> Output Class Initialized
INFO - 2022-03-15 06:12:37 --> Security Class Initialized
DEBUG - 2022-03-15 06:12:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:12:37 --> Input Class Initialized
INFO - 2022-03-15 06:12:37 --> Language Class Initialized
INFO - 2022-03-15 06:12:37 --> Loader Class Initialized
INFO - 2022-03-15 06:12:37 --> Helper loaded: url_helper
INFO - 2022-03-15 06:12:37 --> Helper loaded: form_helper
INFO - 2022-03-15 06:12:37 --> Helper loaded: common_helper
INFO - 2022-03-15 06:12:37 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:12:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:12:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:12:37 --> Controller Class Initialized
INFO - 2022-03-15 06:12:37 --> Form Validation Class Initialized
DEBUG - 2022-03-15 06:12:37 --> Encrypt Class Initialized
DEBUG - 2022-03-15 06:12:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-15 06:12:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-15 06:12:37 --> Email Class Initialized
INFO - 2022-03-15 06:12:37 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-15 06:12:37 --> Calendar Class Initialized
INFO - 2022-03-15 06:12:37 --> Model "Login_model" initialized
INFO - 2022-03-15 06:12:37 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-03-15 06:12:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:12:38 --> Config Class Initialized
INFO - 2022-03-15 06:12:38 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:12:38 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:12:38 --> Utf8 Class Initialized
INFO - 2022-03-15 06:12:38 --> URI Class Initialized
INFO - 2022-03-15 06:12:38 --> Router Class Initialized
INFO - 2022-03-15 06:12:38 --> Output Class Initialized
INFO - 2022-03-15 06:12:38 --> Security Class Initialized
DEBUG - 2022-03-15 06:12:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:12:38 --> Input Class Initialized
INFO - 2022-03-15 06:12:38 --> Language Class Initialized
INFO - 2022-03-15 06:12:38 --> Loader Class Initialized
INFO - 2022-03-15 06:12:38 --> Helper loaded: url_helper
INFO - 2022-03-15 06:12:38 --> Helper loaded: form_helper
INFO - 2022-03-15 06:12:38 --> Helper loaded: common_helper
INFO - 2022-03-15 06:12:38 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:12:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:12:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:12:38 --> Controller Class Initialized
INFO - 2022-03-15 06:12:38 --> Form Validation Class Initialized
DEBUG - 2022-03-15 06:12:38 --> Encrypt Class Initialized
INFO - 2022-03-15 06:12:38 --> Model "Login_model" initialized
INFO - 2022-03-15 06:12:38 --> Model "Dashboard_model" initialized
INFO - 2022-03-15 06:12:38 --> Model "Case_model" initialized
INFO - 2022-03-15 06:12:50 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 06:13:06 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2022-03-15 06:13:06 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 06:13:06 --> Final output sent to browser
DEBUG - 2022-03-15 06:13:06 --> Total execution time: 28.4381
ERROR - 2022-03-15 06:13:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:13:15 --> Config Class Initialized
INFO - 2022-03-15 06:13:15 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:13:15 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:13:15 --> Utf8 Class Initialized
INFO - 2022-03-15 06:13:15 --> URI Class Initialized
INFO - 2022-03-15 06:13:15 --> Router Class Initialized
INFO - 2022-03-15 06:13:15 --> Output Class Initialized
INFO - 2022-03-15 06:13:15 --> Security Class Initialized
DEBUG - 2022-03-15 06:13:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:13:15 --> Input Class Initialized
INFO - 2022-03-15 06:13:15 --> Language Class Initialized
INFO - 2022-03-15 06:13:15 --> Loader Class Initialized
INFO - 2022-03-15 06:13:15 --> Helper loaded: url_helper
INFO - 2022-03-15 06:13:15 --> Helper loaded: form_helper
INFO - 2022-03-15 06:13:15 --> Helper loaded: common_helper
INFO - 2022-03-15 06:13:15 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:13:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:13:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:13:15 --> Controller Class Initialized
INFO - 2022-03-15 06:13:15 --> Form Validation Class Initialized
INFO - 2022-03-15 06:13:15 --> Model "Case_model" initialized
INFO - 2022-03-15 06:13:15 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 06:13:18 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 06:13:18 --> Model "Case_model" initialized
INFO - 2022-03-15 06:13:21 --> File loaded: /home3/karoteam/public_html/application/views/cases/closed_case.php
INFO - 2022-03-15 06:13:21 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 06:13:22 --> Final output sent to browser
DEBUG - 2022-03-15 06:13:22 --> Total execution time: 5.8189
ERROR - 2022-03-15 06:13:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:13:38 --> Config Class Initialized
INFO - 2022-03-15 06:13:38 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:13:38 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:13:38 --> Utf8 Class Initialized
INFO - 2022-03-15 06:13:38 --> URI Class Initialized
INFO - 2022-03-15 06:13:38 --> Router Class Initialized
INFO - 2022-03-15 06:13:38 --> Output Class Initialized
INFO - 2022-03-15 06:13:38 --> Security Class Initialized
DEBUG - 2022-03-15 06:13:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:13:38 --> Input Class Initialized
INFO - 2022-03-15 06:13:38 --> Language Class Initialized
INFO - 2022-03-15 06:13:38 --> Loader Class Initialized
INFO - 2022-03-15 06:13:38 --> Helper loaded: url_helper
INFO - 2022-03-15 06:13:38 --> Helper loaded: form_helper
INFO - 2022-03-15 06:13:38 --> Helper loaded: common_helper
INFO - 2022-03-15 06:13:38 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:13:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:13:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:13:38 --> Controller Class Initialized
INFO - 2022-03-15 06:13:38 --> Form Validation Class Initialized
DEBUG - 2022-03-15 06:13:38 --> Encrypt Class Initialized
INFO - 2022-03-15 06:13:38 --> Model "Patient_model" initialized
INFO - 2022-03-15 06:13:38 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 06:13:38 --> Model "Prefix_master" initialized
INFO - 2022-03-15 06:13:38 --> Model "Users_model" initialized
INFO - 2022-03-15 06:13:38 --> Model "Hospital_model" initialized
INFO - 2022-03-15 06:13:38 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 06:13:38 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-15 06:13:38 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 06:13:38 --> Final output sent to browser
DEBUG - 2022-03-15 06:13:38 --> Total execution time: 0.1670
ERROR - 2022-03-15 06:13:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:13:46 --> Config Class Initialized
INFO - 2022-03-15 06:13:46 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:13:46 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:13:46 --> Utf8 Class Initialized
INFO - 2022-03-15 06:13:46 --> URI Class Initialized
INFO - 2022-03-15 06:13:46 --> Router Class Initialized
INFO - 2022-03-15 06:13:46 --> Output Class Initialized
INFO - 2022-03-15 06:13:46 --> Security Class Initialized
DEBUG - 2022-03-15 06:13:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:13:46 --> Input Class Initialized
INFO - 2022-03-15 06:13:46 --> Language Class Initialized
INFO - 2022-03-15 06:13:46 --> Loader Class Initialized
INFO - 2022-03-15 06:13:46 --> Helper loaded: url_helper
INFO - 2022-03-15 06:13:46 --> Helper loaded: form_helper
INFO - 2022-03-15 06:13:46 --> Helper loaded: common_helper
INFO - 2022-03-15 06:13:46 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:13:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:13:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:13:46 --> Controller Class Initialized
INFO - 2022-03-15 06:13:46 --> Form Validation Class Initialized
INFO - 2022-03-15 06:13:46 --> Model "Case_model" initialized
INFO - 2022-03-15 06:13:46 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 06:13:46 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 06:13:46 --> File loaded: /home3/karoteam/public_html/application/views/cases/rehelp.php
INFO - 2022-03-15 06:13:46 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 06:13:46 --> Final output sent to browser
DEBUG - 2022-03-15 06:13:46 --> Total execution time: 0.0518
ERROR - 2022-03-15 06:15:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:15:40 --> Config Class Initialized
INFO - 2022-03-15 06:15:40 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:15:40 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:15:40 --> Utf8 Class Initialized
INFO - 2022-03-15 06:15:40 --> URI Class Initialized
INFO - 2022-03-15 06:15:40 --> Router Class Initialized
INFO - 2022-03-15 06:15:40 --> Output Class Initialized
INFO - 2022-03-15 06:15:40 --> Security Class Initialized
DEBUG - 2022-03-15 06:15:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:15:40 --> Input Class Initialized
INFO - 2022-03-15 06:15:40 --> Language Class Initialized
INFO - 2022-03-15 06:15:40 --> Loader Class Initialized
INFO - 2022-03-15 06:15:40 --> Helper loaded: url_helper
INFO - 2022-03-15 06:15:40 --> Helper loaded: form_helper
INFO - 2022-03-15 06:15:40 --> Helper loaded: common_helper
INFO - 2022-03-15 06:15:40 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:15:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:15:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:15:40 --> Controller Class Initialized
INFO - 2022-03-15 06:15:40 --> Form Validation Class Initialized
INFO - 2022-03-15 06:15:40 --> Model "Case_model" initialized
INFO - 2022-03-15 06:15:40 --> Model "Patientcase_model" initialized
ERROR - 2022-03-15 06:15:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:15:44 --> Config Class Initialized
INFO - 2022-03-15 06:15:44 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:15:44 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:15:44 --> Utf8 Class Initialized
INFO - 2022-03-15 06:15:44 --> URI Class Initialized
INFO - 2022-03-15 06:15:44 --> Router Class Initialized
INFO - 2022-03-15 06:15:44 --> Output Class Initialized
INFO - 2022-03-15 06:15:44 --> Security Class Initialized
DEBUG - 2022-03-15 06:15:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:15:44 --> Input Class Initialized
INFO - 2022-03-15 06:15:44 --> Language Class Initialized
INFO - 2022-03-15 06:15:44 --> Loader Class Initialized
INFO - 2022-03-15 06:15:44 --> Helper loaded: url_helper
INFO - 2022-03-15 06:15:44 --> Helper loaded: form_helper
INFO - 2022-03-15 06:15:44 --> Helper loaded: common_helper
INFO - 2022-03-15 06:15:44 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:15:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:15:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:15:45 --> Controller Class Initialized
INFO - 2022-03-15 06:15:45 --> Form Validation Class Initialized
INFO - 2022-03-15 06:15:45 --> Model "Case_model" initialized
INFO - 2022-03-15 06:15:45 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 06:15:49 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 06:15:49 --> Model "Case_model" initialized
INFO - 2022-03-15 06:15:54 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 06:15:54 --> Model "Case_model" initialized
INFO - 2022-03-15 06:16:03 --> File loaded: /home3/karoteam/public_html/application/views/cases/all_case.php
INFO - 2022-03-15 06:16:03 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
ERROR - 2022-03-15 06:16:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:16:04 --> Config Class Initialized
INFO - 2022-03-15 06:16:04 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:16:04 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:16:04 --> Utf8 Class Initialized
INFO - 2022-03-15 06:16:04 --> URI Class Initialized
INFO - 2022-03-15 06:16:04 --> Router Class Initialized
INFO - 2022-03-15 06:16:04 --> Output Class Initialized
INFO - 2022-03-15 06:16:04 --> Security Class Initialized
DEBUG - 2022-03-15 06:16:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:16:04 --> Input Class Initialized
INFO - 2022-03-15 06:16:04 --> Language Class Initialized
INFO - 2022-03-15 06:16:04 --> Loader Class Initialized
INFO - 2022-03-15 06:16:04 --> Helper loaded: url_helper
INFO - 2022-03-15 06:16:04 --> Helper loaded: form_helper
INFO - 2022-03-15 06:16:04 --> Helper loaded: common_helper
INFO - 2022-03-15 06:16:04 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:16:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:16:07 --> File loaded: /home3/karoteam/public_html/application/views/cases/all_case.php
INFO - 2022-03-15 06:16:07 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 06:16:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:16:07 --> Controller Class Initialized
INFO - 2022-03-15 06:16:07 --> Form Validation Class Initialized
INFO - 2022-03-15 06:16:07 --> Model "Case_model" initialized
INFO - 2022-03-15 06:16:07 --> Model "Patientcase_model" initialized
ERROR - 2022-03-15 06:16:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:16:07 --> Config Class Initialized
INFO - 2022-03-15 06:16:07 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:16:07 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:16:07 --> Utf8 Class Initialized
INFO - 2022-03-15 06:16:07 --> URI Class Initialized
INFO - 2022-03-15 06:16:07 --> Router Class Initialized
INFO - 2022-03-15 06:16:07 --> Output Class Initialized
INFO - 2022-03-15 06:16:07 --> Security Class Initialized
DEBUG - 2022-03-15 06:16:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:16:07 --> Input Class Initialized
INFO - 2022-03-15 06:16:07 --> Language Class Initialized
INFO - 2022-03-15 06:16:07 --> Loader Class Initialized
INFO - 2022-03-15 06:16:07 --> Helper loaded: url_helper
INFO - 2022-03-15 06:16:07 --> Helper loaded: form_helper
INFO - 2022-03-15 06:16:07 --> Helper loaded: common_helper
INFO - 2022-03-15 06:16:07 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:16:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:16:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:16:07 --> Controller Class Initialized
INFO - 2022-03-15 06:16:07 --> Form Validation Class Initialized
DEBUG - 2022-03-15 06:16:07 --> Encrypt Class Initialized
INFO - 2022-03-15 06:16:07 --> Model "Patient_model" initialized
INFO - 2022-03-15 06:16:07 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 06:16:07 --> Model "Referredby_model" initialized
INFO - 2022-03-15 06:16:07 --> Model "Prefix_master" initialized
INFO - 2022-03-15 06:16:07 --> Model "Hospital_model" initialized
INFO - 2022-03-15 06:16:07 --> Final output sent to browser
DEBUG - 2022-03-15 06:16:07 --> Total execution time: 0.0637
ERROR - 2022-03-15 06:16:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:16:08 --> Config Class Initialized
INFO - 2022-03-15 06:16:08 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:16:08 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:16:08 --> Utf8 Class Initialized
INFO - 2022-03-15 06:16:08 --> URI Class Initialized
INFO - 2022-03-15 06:16:08 --> Router Class Initialized
INFO - 2022-03-15 06:16:08 --> Output Class Initialized
INFO - 2022-03-15 06:16:08 --> Security Class Initialized
DEBUG - 2022-03-15 06:16:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:16:08 --> Input Class Initialized
INFO - 2022-03-15 06:16:08 --> Language Class Initialized
INFO - 2022-03-15 06:16:08 --> Loader Class Initialized
INFO - 2022-03-15 06:16:08 --> Helper loaded: url_helper
INFO - 2022-03-15 06:16:08 --> Helper loaded: form_helper
INFO - 2022-03-15 06:16:08 --> Helper loaded: common_helper
INFO - 2022-03-15 06:16:08 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:16:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-03-15 06:16:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:16:10 --> Config Class Initialized
INFO - 2022-03-15 06:16:10 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:16:10 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:16:10 --> Utf8 Class Initialized
INFO - 2022-03-15 06:16:10 --> URI Class Initialized
INFO - 2022-03-15 06:16:10 --> Router Class Initialized
INFO - 2022-03-15 06:16:10 --> Output Class Initialized
INFO - 2022-03-15 06:16:10 --> Security Class Initialized
DEBUG - 2022-03-15 06:16:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:16:10 --> Input Class Initialized
INFO - 2022-03-15 06:16:10 --> Language Class Initialized
INFO - 2022-03-15 06:16:10 --> Loader Class Initialized
INFO - 2022-03-15 06:16:10 --> Helper loaded: url_helper
INFO - 2022-03-15 06:16:10 --> Helper loaded: form_helper
INFO - 2022-03-15 06:16:10 --> Helper loaded: common_helper
INFO - 2022-03-15 06:16:10 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:16:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:16:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:16:10 --> Controller Class Initialized
INFO - 2022-03-15 06:16:10 --> Form Validation Class Initialized
DEBUG - 2022-03-15 06:16:10 --> Encrypt Class Initialized
INFO - 2022-03-15 06:16:10 --> Model "Patient_model" initialized
INFO - 2022-03-15 06:16:10 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 06:16:10 --> Model "Referredby_model" initialized
INFO - 2022-03-15 06:16:10 --> Model "Prefix_master" initialized
INFO - 2022-03-15 06:16:10 --> Model "Hospital_model" initialized
INFO - 2022-03-15 06:16:10 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 06:16:10 --> Model "Case_model" initialized
ERROR - 2022-03-15 06:16:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:16:11 --> Config Class Initialized
INFO - 2022-03-15 06:16:11 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:16:11 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:16:11 --> Utf8 Class Initialized
INFO - 2022-03-15 06:16:11 --> URI Class Initialized
INFO - 2022-03-15 06:16:11 --> Router Class Initialized
INFO - 2022-03-15 06:16:11 --> Output Class Initialized
INFO - 2022-03-15 06:16:11 --> Security Class Initialized
DEBUG - 2022-03-15 06:16:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:16:11 --> Input Class Initialized
INFO - 2022-03-15 06:16:11 --> Language Class Initialized
INFO - 2022-03-15 06:16:11 --> Loader Class Initialized
INFO - 2022-03-15 06:16:11 --> Helper loaded: url_helper
INFO - 2022-03-15 06:16:11 --> Helper loaded: form_helper
INFO - 2022-03-15 06:16:11 --> Helper loaded: common_helper
INFO - 2022-03-15 06:16:11 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:16:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:16:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:16:11 --> Controller Class Initialized
INFO - 2022-03-15 06:16:11 --> Form Validation Class Initialized
DEBUG - 2022-03-15 06:16:11 --> Encrypt Class Initialized
INFO - 2022-03-15 06:16:11 --> Model "Patient_model" initialized
INFO - 2022-03-15 06:16:11 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 06:16:11 --> Model "Referredby_model" initialized
INFO - 2022-03-15 06:16:11 --> Model "Prefix_master" initialized
INFO - 2022-03-15 06:16:11 --> Model "Hospital_model" initialized
INFO - 2022-03-15 06:16:11 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 06:16:11 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-15 06:16:11 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 06:16:11 --> Final output sent to browser
DEBUG - 2022-03-15 06:16:11 --> Total execution time: 0.1797
ERROR - 2022-03-15 06:16:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:16:14 --> Config Class Initialized
INFO - 2022-03-15 06:16:14 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:16:14 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:16:14 --> Utf8 Class Initialized
INFO - 2022-03-15 06:16:14 --> URI Class Initialized
INFO - 2022-03-15 06:16:14 --> Router Class Initialized
INFO - 2022-03-15 06:16:14 --> Output Class Initialized
INFO - 2022-03-15 06:16:14 --> Security Class Initialized
DEBUG - 2022-03-15 06:16:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:16:14 --> Input Class Initialized
INFO - 2022-03-15 06:16:14 --> Language Class Initialized
INFO - 2022-03-15 06:16:14 --> Loader Class Initialized
INFO - 2022-03-15 06:16:14 --> Helper loaded: url_helper
INFO - 2022-03-15 06:16:14 --> Helper loaded: form_helper
INFO - 2022-03-15 06:16:14 --> Helper loaded: common_helper
INFO - 2022-03-15 06:16:14 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:16:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:16:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:16:14 --> Controller Class Initialized
INFO - 2022-03-15 06:16:14 --> Form Validation Class Initialized
DEBUG - 2022-03-15 06:16:14 --> Encrypt Class Initialized
INFO - 2022-03-15 06:16:14 --> Model "Patient_model" initialized
INFO - 2022-03-15 06:16:14 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 06:16:14 --> Model "Prefix_master" initialized
INFO - 2022-03-15 06:16:14 --> Model "Users_model" initialized
INFO - 2022-03-15 06:16:14 --> Model "Hospital_model" initialized
INFO - 2022-03-15 06:16:14 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 06:16:14 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-15 06:16:14 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 06:16:14 --> Final output sent to browser
DEBUG - 2022-03-15 06:16:14 --> Total execution time: 0.1845
INFO - 2022-03-15 06:16:14 --> File loaded: /home3/karoteam/public_html/application/views/cases/closed_case.php
INFO - 2022-03-15 06:16:14 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 06:16:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:16:14 --> Controller Class Initialized
INFO - 2022-03-15 06:16:14 --> Form Validation Class Initialized
INFO - 2022-03-15 06:16:14 --> Model "Case_model" initialized
INFO - 2022-03-15 06:16:14 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 06:16:17 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 06:16:17 --> Model "Case_model" initialized
INFO - 2022-03-15 06:16:20 --> File loaded: /home3/karoteam/public_html/application/views/cases/closed_case.php
INFO - 2022-03-15 06:16:20 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 06:16:22 --> Final output sent to browser
DEBUG - 2022-03-15 06:16:22 --> Total execution time: 12.1465
ERROR - 2022-03-15 06:16:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:16:22 --> Config Class Initialized
INFO - 2022-03-15 06:16:22 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:16:22 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:16:22 --> Utf8 Class Initialized
INFO - 2022-03-15 06:16:22 --> URI Class Initialized
INFO - 2022-03-15 06:16:22 --> Router Class Initialized
INFO - 2022-03-15 06:16:22 --> Output Class Initialized
INFO - 2022-03-15 06:16:22 --> Security Class Initialized
DEBUG - 2022-03-15 06:16:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:16:22 --> Input Class Initialized
INFO - 2022-03-15 06:16:22 --> Language Class Initialized
ERROR - 2022-03-15 06:16:22 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-15 06:17:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:17:28 --> Config Class Initialized
INFO - 2022-03-15 06:17:28 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:17:28 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:17:28 --> Utf8 Class Initialized
INFO - 2022-03-15 06:17:28 --> URI Class Initialized
INFO - 2022-03-15 06:17:28 --> Router Class Initialized
INFO - 2022-03-15 06:17:28 --> Output Class Initialized
INFO - 2022-03-15 06:17:28 --> Security Class Initialized
DEBUG - 2022-03-15 06:17:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:17:28 --> Input Class Initialized
INFO - 2022-03-15 06:17:28 --> Language Class Initialized
INFO - 2022-03-15 06:17:28 --> Loader Class Initialized
INFO - 2022-03-15 06:17:28 --> Helper loaded: url_helper
INFO - 2022-03-15 06:17:28 --> Helper loaded: form_helper
INFO - 2022-03-15 06:17:28 --> Helper loaded: common_helper
INFO - 2022-03-15 06:17:28 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:17:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:17:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:17:28 --> Controller Class Initialized
INFO - 2022-03-15 06:17:28 --> Form Validation Class Initialized
DEBUG - 2022-03-15 06:17:28 --> Encrypt Class Initialized
INFO - 2022-03-15 06:17:28 --> Model "Patient_model" initialized
INFO - 2022-03-15 06:17:28 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 06:17:28 --> Model "Prefix_master" initialized
INFO - 2022-03-15 06:17:28 --> Model "Users_model" initialized
INFO - 2022-03-15 06:17:28 --> Model "Hospital_model" initialized
INFO - 2022-03-15 06:17:28 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 06:17:28 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-15 06:17:28 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 06:17:28 --> Final output sent to browser
DEBUG - 2022-03-15 06:17:28 --> Total execution time: 0.1684
ERROR - 2022-03-15 06:17:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:17:29 --> Config Class Initialized
INFO - 2022-03-15 06:17:29 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:17:29 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:17:29 --> Utf8 Class Initialized
INFO - 2022-03-15 06:17:29 --> URI Class Initialized
INFO - 2022-03-15 06:17:29 --> Router Class Initialized
INFO - 2022-03-15 06:17:29 --> Output Class Initialized
INFO - 2022-03-15 06:17:29 --> Security Class Initialized
DEBUG - 2022-03-15 06:17:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:17:29 --> Input Class Initialized
INFO - 2022-03-15 06:17:29 --> Language Class Initialized
ERROR - 2022-03-15 06:17:29 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-15 06:18:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:18:11 --> Config Class Initialized
INFO - 2022-03-15 06:18:11 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:18:11 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:18:11 --> Utf8 Class Initialized
INFO - 2022-03-15 06:18:11 --> URI Class Initialized
INFO - 2022-03-15 06:18:11 --> Router Class Initialized
INFO - 2022-03-15 06:18:11 --> Output Class Initialized
INFO - 2022-03-15 06:18:11 --> Security Class Initialized
DEBUG - 2022-03-15 06:18:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:18:11 --> Input Class Initialized
INFO - 2022-03-15 06:18:11 --> Language Class Initialized
INFO - 2022-03-15 06:18:11 --> Loader Class Initialized
INFO - 2022-03-15 06:18:11 --> Helper loaded: url_helper
INFO - 2022-03-15 06:18:11 --> Helper loaded: form_helper
INFO - 2022-03-15 06:18:11 --> Helper loaded: common_helper
INFO - 2022-03-15 06:18:11 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:18:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:18:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:18:11 --> Controller Class Initialized
INFO - 2022-03-15 06:18:11 --> Form Validation Class Initialized
DEBUG - 2022-03-15 06:18:11 --> Encrypt Class Initialized
INFO - 2022-03-15 06:18:11 --> Model "Patient_model" initialized
INFO - 2022-03-15 06:18:11 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 06:18:11 --> Model "Prefix_master" initialized
INFO - 2022-03-15 06:18:11 --> Model "Users_model" initialized
INFO - 2022-03-15 06:18:11 --> Model "Hospital_model" initialized
INFO - 2022-03-15 06:18:11 --> Upload Class Initialized
INFO - 2022-03-15 06:18:11 --> Final output sent to browser
DEBUG - 2022-03-15 06:18:11 --> Total execution time: 0.1335
ERROR - 2022-03-15 06:18:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:18:34 --> Config Class Initialized
INFO - 2022-03-15 06:18:34 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:18:34 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:18:34 --> Utf8 Class Initialized
INFO - 2022-03-15 06:18:34 --> URI Class Initialized
INFO - 2022-03-15 06:18:34 --> Router Class Initialized
INFO - 2022-03-15 06:18:34 --> Output Class Initialized
INFO - 2022-03-15 06:18:34 --> Security Class Initialized
DEBUG - 2022-03-15 06:18:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:18:34 --> Input Class Initialized
INFO - 2022-03-15 06:18:34 --> Language Class Initialized
INFO - 2022-03-15 06:18:34 --> Loader Class Initialized
INFO - 2022-03-15 06:18:34 --> Helper loaded: url_helper
INFO - 2022-03-15 06:18:34 --> Helper loaded: form_helper
INFO - 2022-03-15 06:18:34 --> Helper loaded: common_helper
INFO - 2022-03-15 06:18:34 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:18:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:18:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:18:34 --> Controller Class Initialized
INFO - 2022-03-15 06:18:34 --> Form Validation Class Initialized
INFO - 2022-03-15 06:18:34 --> Model "Case_model" initialized
INFO - 2022-03-15 06:18:34 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 06:18:34 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 06:18:34 --> Model "Case_model" initialized
INFO - 2022-03-15 06:18:34 --> File loaded: /home3/karoteam/public_html/application/views/cases/all_case.php
INFO - 2022-03-15 06:18:34 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 06:18:34 --> Final output sent to browser
DEBUG - 2022-03-15 06:18:34 --> Total execution time: 0.0759
ERROR - 2022-03-15 06:18:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:18:45 --> Config Class Initialized
INFO - 2022-03-15 06:18:45 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:18:45 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:18:45 --> Utf8 Class Initialized
INFO - 2022-03-15 06:18:45 --> URI Class Initialized
INFO - 2022-03-15 06:18:45 --> Router Class Initialized
INFO - 2022-03-15 06:18:45 --> Output Class Initialized
INFO - 2022-03-15 06:18:45 --> Security Class Initialized
DEBUG - 2022-03-15 06:18:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:18:45 --> Input Class Initialized
INFO - 2022-03-15 06:18:45 --> Language Class Initialized
INFO - 2022-03-15 06:18:45 --> Loader Class Initialized
INFO - 2022-03-15 06:18:45 --> Helper loaded: url_helper
INFO - 2022-03-15 06:18:45 --> Helper loaded: form_helper
INFO - 2022-03-15 06:18:45 --> Helper loaded: common_helper
INFO - 2022-03-15 06:18:45 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:18:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:18:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:18:45 --> Controller Class Initialized
INFO - 2022-03-15 06:18:45 --> Form Validation Class Initialized
DEBUG - 2022-03-15 06:18:45 --> Encrypt Class Initialized
INFO - 2022-03-15 06:18:45 --> Model "Patient_model" initialized
INFO - 2022-03-15 06:18:45 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 06:18:45 --> Model "Prefix_master" initialized
INFO - 2022-03-15 06:18:45 --> Model "Users_model" initialized
INFO - 2022-03-15 06:18:45 --> Model "Hospital_model" initialized
ERROR - 2022-03-15 06:18:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:18:46 --> Config Class Initialized
INFO - 2022-03-15 06:18:46 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:18:46 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:18:46 --> Utf8 Class Initialized
INFO - 2022-03-15 06:18:46 --> URI Class Initialized
INFO - 2022-03-15 06:18:46 --> Router Class Initialized
INFO - 2022-03-15 06:18:46 --> Output Class Initialized
INFO - 2022-03-15 06:18:46 --> Security Class Initialized
DEBUG - 2022-03-15 06:18:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:18:46 --> Input Class Initialized
INFO - 2022-03-15 06:18:46 --> Language Class Initialized
INFO - 2022-03-15 06:18:46 --> Loader Class Initialized
INFO - 2022-03-15 06:18:46 --> Helper loaded: url_helper
INFO - 2022-03-15 06:18:46 --> Helper loaded: form_helper
INFO - 2022-03-15 06:18:46 --> Helper loaded: common_helper
INFO - 2022-03-15 06:18:46 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:18:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:18:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:18:46 --> Controller Class Initialized
INFO - 2022-03-15 06:18:46 --> Form Validation Class Initialized
DEBUG - 2022-03-15 06:18:46 --> Encrypt Class Initialized
INFO - 2022-03-15 06:18:46 --> Model "Patient_model" initialized
INFO - 2022-03-15 06:18:46 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 06:18:46 --> Model "Prefix_master" initialized
INFO - 2022-03-15 06:18:46 --> Model "Users_model" initialized
INFO - 2022-03-15 06:18:46 --> Model "Hospital_model" initialized
INFO - 2022-03-15 06:18:46 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 06:18:46 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-15 06:18:46 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 06:18:46 --> Final output sent to browser
DEBUG - 2022-03-15 06:18:46 --> Total execution time: 0.0581
ERROR - 2022-03-15 06:18:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:18:46 --> Config Class Initialized
INFO - 2022-03-15 06:18:46 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:18:46 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:18:46 --> Utf8 Class Initialized
INFO - 2022-03-15 06:18:46 --> URI Class Initialized
INFO - 2022-03-15 06:18:46 --> Router Class Initialized
INFO - 2022-03-15 06:18:46 --> Output Class Initialized
INFO - 2022-03-15 06:18:46 --> Security Class Initialized
DEBUG - 2022-03-15 06:18:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:18:46 --> Input Class Initialized
INFO - 2022-03-15 06:18:46 --> Language Class Initialized
ERROR - 2022-03-15 06:18:46 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-15 06:18:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:18:48 --> Config Class Initialized
INFO - 2022-03-15 06:18:48 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:18:48 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:18:48 --> Utf8 Class Initialized
INFO - 2022-03-15 06:18:48 --> URI Class Initialized
INFO - 2022-03-15 06:18:48 --> Router Class Initialized
INFO - 2022-03-15 06:18:48 --> Output Class Initialized
INFO - 2022-03-15 06:18:48 --> Security Class Initialized
DEBUG - 2022-03-15 06:18:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:18:48 --> Input Class Initialized
INFO - 2022-03-15 06:18:48 --> Language Class Initialized
INFO - 2022-03-15 06:18:48 --> Loader Class Initialized
INFO - 2022-03-15 06:18:48 --> Helper loaded: url_helper
INFO - 2022-03-15 06:18:48 --> Helper loaded: form_helper
INFO - 2022-03-15 06:18:48 --> Helper loaded: common_helper
INFO - 2022-03-15 06:18:48 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:18:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:18:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:18:48 --> Controller Class Initialized
INFO - 2022-03-15 06:18:48 --> Form Validation Class Initialized
DEBUG - 2022-03-15 06:18:48 --> Encrypt Class Initialized
INFO - 2022-03-15 06:18:48 --> Model "Patient_model" initialized
INFO - 2022-03-15 06:18:48 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 06:18:48 --> Model "Referredby_model" initialized
INFO - 2022-03-15 06:18:48 --> Model "Prefix_master" initialized
INFO - 2022-03-15 06:18:48 --> Model "Hospital_model" initialized
INFO - 2022-03-15 06:18:48 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 06:18:48 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-15 06:18:48 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 06:18:48 --> Final output sent to browser
DEBUG - 2022-03-15 06:18:48 --> Total execution time: 0.0518
ERROR - 2022-03-15 06:18:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:18:49 --> Config Class Initialized
INFO - 2022-03-15 06:18:49 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:18:49 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:18:49 --> Utf8 Class Initialized
INFO - 2022-03-15 06:18:49 --> URI Class Initialized
INFO - 2022-03-15 06:18:49 --> Router Class Initialized
INFO - 2022-03-15 06:18:49 --> Output Class Initialized
INFO - 2022-03-15 06:18:49 --> Security Class Initialized
DEBUG - 2022-03-15 06:18:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:18:49 --> Input Class Initialized
INFO - 2022-03-15 06:18:49 --> Language Class Initialized
ERROR - 2022-03-15 06:18:49 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-15 06:18:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:18:49 --> Config Class Initialized
INFO - 2022-03-15 06:18:49 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:18:49 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:18:49 --> Utf8 Class Initialized
INFO - 2022-03-15 06:18:49 --> URI Class Initialized
INFO - 2022-03-15 06:18:49 --> Router Class Initialized
INFO - 2022-03-15 06:18:49 --> Output Class Initialized
INFO - 2022-03-15 06:18:49 --> Security Class Initialized
DEBUG - 2022-03-15 06:18:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:18:49 --> Input Class Initialized
INFO - 2022-03-15 06:18:49 --> Language Class Initialized
ERROR - 2022-03-15 06:18:49 --> 404 Page Not Found: Karoclient/images
ERROR - 2022-03-15 06:19:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:19:02 --> Config Class Initialized
INFO - 2022-03-15 06:19:02 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:19:02 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:19:02 --> Utf8 Class Initialized
INFO - 2022-03-15 06:19:02 --> URI Class Initialized
INFO - 2022-03-15 06:19:02 --> Router Class Initialized
INFO - 2022-03-15 06:19:02 --> Output Class Initialized
INFO - 2022-03-15 06:19:02 --> Security Class Initialized
DEBUG - 2022-03-15 06:19:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:19:02 --> Input Class Initialized
INFO - 2022-03-15 06:19:02 --> Language Class Initialized
ERROR - 2022-03-15 06:19:02 --> 404 Page Not Found: Karoclient/css
ERROR - 2022-03-15 06:19:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:19:04 --> Config Class Initialized
INFO - 2022-03-15 06:19:04 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:19:04 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:19:04 --> Utf8 Class Initialized
INFO - 2022-03-15 06:19:04 --> URI Class Initialized
INFO - 2022-03-15 06:19:04 --> Router Class Initialized
INFO - 2022-03-15 06:19:04 --> Output Class Initialized
INFO - 2022-03-15 06:19:04 --> Security Class Initialized
DEBUG - 2022-03-15 06:19:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:19:04 --> Input Class Initialized
INFO - 2022-03-15 06:19:04 --> Language Class Initialized
INFO - 2022-03-15 06:19:04 --> Loader Class Initialized
INFO - 2022-03-15 06:19:04 --> Helper loaded: url_helper
INFO - 2022-03-15 06:19:04 --> Helper loaded: form_helper
INFO - 2022-03-15 06:19:04 --> Helper loaded: common_helper
INFO - 2022-03-15 06:19:04 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:19:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:19:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:19:04 --> Controller Class Initialized
INFO - 2022-03-15 06:19:04 --> Form Validation Class Initialized
DEBUG - 2022-03-15 06:19:04 --> Encrypt Class Initialized
INFO - 2022-03-15 06:19:04 --> Model "Patient_model" initialized
INFO - 2022-03-15 06:19:04 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 06:19:04 --> Model "Referredby_model" initialized
INFO - 2022-03-15 06:19:04 --> Model "Prefix_master" initialized
INFO - 2022-03-15 06:19:04 --> Model "Hospital_model" initialized
INFO - 2022-03-15 06:19:04 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 06:19:04 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-15 06:19:04 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 06:19:04 --> Final output sent to browser
DEBUG - 2022-03-15 06:19:04 --> Total execution time: 0.0928
ERROR - 2022-03-15 06:19:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:19:13 --> Config Class Initialized
INFO - 2022-03-15 06:19:13 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:19:13 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:19:13 --> Utf8 Class Initialized
INFO - 2022-03-15 06:19:13 --> URI Class Initialized
INFO - 2022-03-15 06:19:13 --> Router Class Initialized
INFO - 2022-03-15 06:19:13 --> Output Class Initialized
INFO - 2022-03-15 06:19:13 --> Security Class Initialized
DEBUG - 2022-03-15 06:19:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:19:13 --> Input Class Initialized
INFO - 2022-03-15 06:19:13 --> Language Class Initialized
INFO - 2022-03-15 06:19:13 --> Loader Class Initialized
INFO - 2022-03-15 06:19:13 --> Helper loaded: url_helper
INFO - 2022-03-15 06:19:13 --> Helper loaded: form_helper
INFO - 2022-03-15 06:19:13 --> Helper loaded: common_helper
INFO - 2022-03-15 06:19:13 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:19:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:19:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:19:13 --> Controller Class Initialized
INFO - 2022-03-15 06:19:13 --> Form Validation Class Initialized
DEBUG - 2022-03-15 06:19:13 --> Encrypt Class Initialized
INFO - 2022-03-15 06:19:13 --> Model "Patient_model" initialized
INFO - 2022-03-15 06:19:13 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 06:19:13 --> Model "Referredby_model" initialized
INFO - 2022-03-15 06:19:13 --> Model "Prefix_master" initialized
INFO - 2022-03-15 06:19:13 --> Model "Hospital_model" initialized
INFO - 2022-03-15 06:19:13 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 06:19:13 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-15 06:19:13 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 06:19:13 --> Final output sent to browser
DEBUG - 2022-03-15 06:19:13 --> Total execution time: 0.1435
ERROR - 2022-03-15 06:19:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:19:51 --> Config Class Initialized
INFO - 2022-03-15 06:19:51 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:19:51 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:19:51 --> Utf8 Class Initialized
INFO - 2022-03-15 06:19:51 --> URI Class Initialized
INFO - 2022-03-15 06:19:51 --> Router Class Initialized
INFO - 2022-03-15 06:19:51 --> Output Class Initialized
INFO - 2022-03-15 06:19:51 --> Security Class Initialized
DEBUG - 2022-03-15 06:19:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:19:51 --> Input Class Initialized
INFO - 2022-03-15 06:19:51 --> Language Class Initialized
INFO - 2022-03-15 06:19:52 --> Loader Class Initialized
INFO - 2022-03-15 06:19:52 --> Helper loaded: url_helper
INFO - 2022-03-15 06:19:52 --> Helper loaded: form_helper
INFO - 2022-03-15 06:19:52 --> Helper loaded: common_helper
INFO - 2022-03-15 06:19:52 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:19:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:19:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:19:52 --> Controller Class Initialized
INFO - 2022-03-15 06:19:52 --> Form Validation Class Initialized
DEBUG - 2022-03-15 06:19:52 --> Encrypt Class Initialized
INFO - 2022-03-15 06:19:52 --> Model "Patient_model" initialized
INFO - 2022-03-15 06:19:52 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 06:19:52 --> Model "Referredby_model" initialized
INFO - 2022-03-15 06:19:52 --> Model "Prefix_master" initialized
INFO - 2022-03-15 06:19:52 --> Model "Hospital_model" initialized
ERROR - 2022-03-15 06:19:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:19:52 --> Config Class Initialized
INFO - 2022-03-15 06:19:52 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:19:52 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:19:52 --> Utf8 Class Initialized
INFO - 2022-03-15 06:19:52 --> URI Class Initialized
INFO - 2022-03-15 06:19:52 --> Router Class Initialized
INFO - 2022-03-15 06:19:52 --> Output Class Initialized
INFO - 2022-03-15 06:19:52 --> Security Class Initialized
DEBUG - 2022-03-15 06:19:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:19:52 --> Input Class Initialized
INFO - 2022-03-15 06:19:52 --> Language Class Initialized
INFO - 2022-03-15 06:19:52 --> Loader Class Initialized
INFO - 2022-03-15 06:19:52 --> Helper loaded: url_helper
INFO - 2022-03-15 06:19:52 --> Helper loaded: form_helper
INFO - 2022-03-15 06:19:52 --> Helper loaded: common_helper
INFO - 2022-03-15 06:19:52 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:19:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:19:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:19:52 --> Controller Class Initialized
INFO - 2022-03-15 06:19:52 --> Form Validation Class Initialized
DEBUG - 2022-03-15 06:19:52 --> Encrypt Class Initialized
INFO - 2022-03-15 06:19:52 --> Model "Patient_model" initialized
INFO - 2022-03-15 06:19:52 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 06:19:52 --> Model "Referredby_model" initialized
INFO - 2022-03-15 06:19:52 --> Model "Prefix_master" initialized
INFO - 2022-03-15 06:19:52 --> Model "Hospital_model" initialized
INFO - 2022-03-15 06:19:53 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 06:19:53 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-15 06:19:53 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 06:19:53 --> Final output sent to browser
DEBUG - 2022-03-15 06:19:53 --> Total execution time: 0.1198
ERROR - 2022-03-15 06:19:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:19:54 --> Config Class Initialized
INFO - 2022-03-15 06:19:54 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:19:54 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:19:54 --> Utf8 Class Initialized
INFO - 2022-03-15 06:19:54 --> URI Class Initialized
INFO - 2022-03-15 06:19:54 --> Router Class Initialized
INFO - 2022-03-15 06:19:54 --> Output Class Initialized
INFO - 2022-03-15 06:19:54 --> Security Class Initialized
DEBUG - 2022-03-15 06:19:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:19:54 --> Input Class Initialized
INFO - 2022-03-15 06:19:54 --> Language Class Initialized
INFO - 2022-03-15 06:19:54 --> Loader Class Initialized
INFO - 2022-03-15 06:19:54 --> Helper loaded: url_helper
INFO - 2022-03-15 06:19:54 --> Helper loaded: form_helper
INFO - 2022-03-15 06:19:54 --> Helper loaded: common_helper
INFO - 2022-03-15 06:19:54 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:19:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:19:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:19:54 --> Controller Class Initialized
INFO - 2022-03-15 06:19:54 --> Form Validation Class Initialized
DEBUG - 2022-03-15 06:19:54 --> Encrypt Class Initialized
INFO - 2022-03-15 06:19:54 --> Model "Patient_model" initialized
INFO - 2022-03-15 06:19:54 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 06:19:54 --> Model "Prefix_master" initialized
INFO - 2022-03-15 06:19:54 --> Model "Users_model" initialized
INFO - 2022-03-15 06:19:54 --> Model "Hospital_model" initialized
INFO - 2022-03-15 06:19:54 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 06:19:54 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-15 06:19:54 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 06:19:54 --> Final output sent to browser
DEBUG - 2022-03-15 06:19:54 --> Total execution time: 0.1914
ERROR - 2022-03-15 06:20:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:20:36 --> Config Class Initialized
INFO - 2022-03-15 06:20:36 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:20:36 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:20:36 --> Utf8 Class Initialized
INFO - 2022-03-15 06:20:36 --> URI Class Initialized
INFO - 2022-03-15 06:20:36 --> Router Class Initialized
INFO - 2022-03-15 06:20:36 --> Output Class Initialized
INFO - 2022-03-15 06:20:36 --> Security Class Initialized
DEBUG - 2022-03-15 06:20:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:20:36 --> Input Class Initialized
INFO - 2022-03-15 06:20:36 --> Language Class Initialized
INFO - 2022-03-15 06:20:36 --> Loader Class Initialized
INFO - 2022-03-15 06:20:36 --> Helper loaded: url_helper
INFO - 2022-03-15 06:20:36 --> Helper loaded: form_helper
INFO - 2022-03-15 06:20:36 --> Helper loaded: common_helper
INFO - 2022-03-15 06:20:36 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:20:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:20:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:20:36 --> Controller Class Initialized
INFO - 2022-03-15 06:20:36 --> Form Validation Class Initialized
DEBUG - 2022-03-15 06:20:36 --> Encrypt Class Initialized
INFO - 2022-03-15 06:20:36 --> Model "Patient_model" initialized
INFO - 2022-03-15 06:20:36 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 06:20:36 --> Model "Referredby_model" initialized
INFO - 2022-03-15 06:20:36 --> Model "Prefix_master" initialized
INFO - 2022-03-15 06:20:36 --> Model "Hospital_model" initialized
ERROR - 2022-03-15 06:20:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:20:36 --> Config Class Initialized
INFO - 2022-03-15 06:20:36 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:20:36 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:20:36 --> Utf8 Class Initialized
INFO - 2022-03-15 06:20:36 --> URI Class Initialized
INFO - 2022-03-15 06:20:36 --> Router Class Initialized
INFO - 2022-03-15 06:20:36 --> Output Class Initialized
INFO - 2022-03-15 06:20:36 --> Security Class Initialized
DEBUG - 2022-03-15 06:20:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:20:36 --> Input Class Initialized
INFO - 2022-03-15 06:20:36 --> Language Class Initialized
INFO - 2022-03-15 06:20:36 --> Loader Class Initialized
INFO - 2022-03-15 06:20:36 --> Helper loaded: url_helper
INFO - 2022-03-15 06:20:36 --> Helper loaded: form_helper
INFO - 2022-03-15 06:20:36 --> Helper loaded: common_helper
INFO - 2022-03-15 06:20:36 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:20:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:20:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:20:36 --> Controller Class Initialized
INFO - 2022-03-15 06:20:36 --> Form Validation Class Initialized
DEBUG - 2022-03-15 06:20:36 --> Encrypt Class Initialized
INFO - 2022-03-15 06:20:36 --> Model "Patient_model" initialized
INFO - 2022-03-15 06:20:36 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 06:20:36 --> Model "Referredby_model" initialized
INFO - 2022-03-15 06:20:36 --> Model "Prefix_master" initialized
INFO - 2022-03-15 06:20:36 --> Model "Hospital_model" initialized
INFO - 2022-03-15 06:20:36 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 06:20:36 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-15 06:20:36 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 06:20:36 --> Final output sent to browser
DEBUG - 2022-03-15 06:20:36 --> Total execution time: 0.0469
ERROR - 2022-03-15 06:20:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:20:37 --> Config Class Initialized
INFO - 2022-03-15 06:20:37 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:20:37 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:20:37 --> Utf8 Class Initialized
INFO - 2022-03-15 06:20:37 --> URI Class Initialized
INFO - 2022-03-15 06:20:37 --> Router Class Initialized
INFO - 2022-03-15 06:20:37 --> Output Class Initialized
INFO - 2022-03-15 06:20:37 --> Security Class Initialized
DEBUG - 2022-03-15 06:20:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:20:37 --> Input Class Initialized
INFO - 2022-03-15 06:20:37 --> Language Class Initialized
INFO - 2022-03-15 06:20:37 --> Loader Class Initialized
INFO - 2022-03-15 06:20:37 --> Helper loaded: url_helper
INFO - 2022-03-15 06:20:37 --> Helper loaded: form_helper
INFO - 2022-03-15 06:20:37 --> Helper loaded: common_helper
INFO - 2022-03-15 06:20:37 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:20:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:20:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:20:37 --> Controller Class Initialized
INFO - 2022-03-15 06:20:37 --> Form Validation Class Initialized
DEBUG - 2022-03-15 06:20:37 --> Encrypt Class Initialized
INFO - 2022-03-15 06:20:37 --> Model "Patient_model" initialized
INFO - 2022-03-15 06:20:37 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 06:20:37 --> Model "Referredby_model" initialized
INFO - 2022-03-15 06:20:37 --> Model "Prefix_master" initialized
INFO - 2022-03-15 06:20:37 --> Model "Hospital_model" initialized
INFO - 2022-03-15 06:20:37 --> File loaded: /home3/karoteam/public_html/application/views/header.php
ERROR - 2022-03-15 06:20:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:20:41 --> Config Class Initialized
INFO - 2022-03-15 06:20:41 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:20:41 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:20:41 --> Utf8 Class Initialized
INFO - 2022-03-15 06:20:41 --> URI Class Initialized
INFO - 2022-03-15 06:20:41 --> Router Class Initialized
INFO - 2022-03-15 06:20:41 --> Output Class Initialized
INFO - 2022-03-15 06:20:41 --> Security Class Initialized
DEBUG - 2022-03-15 06:20:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:20:41 --> Input Class Initialized
INFO - 2022-03-15 06:20:41 --> Language Class Initialized
INFO - 2022-03-15 06:20:41 --> Loader Class Initialized
INFO - 2022-03-15 06:20:41 --> Helper loaded: url_helper
INFO - 2022-03-15 06:20:41 --> Helper loaded: form_helper
INFO - 2022-03-15 06:20:41 --> Helper loaded: common_helper
INFO - 2022-03-15 06:20:41 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:20:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:20:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:20:41 --> Controller Class Initialized
INFO - 2022-03-15 06:20:41 --> Form Validation Class Initialized
DEBUG - 2022-03-15 06:20:41 --> Encrypt Class Initialized
INFO - 2022-03-15 06:20:41 --> Model "Patient_model" initialized
INFO - 2022-03-15 06:20:41 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 06:20:41 --> Model "Prefix_master" initialized
INFO - 2022-03-15 06:20:41 --> Model "Users_model" initialized
INFO - 2022-03-15 06:20:41 --> Model "Hospital_model" initialized
ERROR - 2022-03-15 06:20:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:20:42 --> Config Class Initialized
INFO - 2022-03-15 06:20:42 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:20:42 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:20:42 --> Utf8 Class Initialized
INFO - 2022-03-15 06:20:42 --> URI Class Initialized
INFO - 2022-03-15 06:20:42 --> Router Class Initialized
INFO - 2022-03-15 06:20:42 --> Output Class Initialized
INFO - 2022-03-15 06:20:42 --> Security Class Initialized
DEBUG - 2022-03-15 06:20:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:20:42 --> Input Class Initialized
INFO - 2022-03-15 06:20:42 --> Language Class Initialized
INFO - 2022-03-15 06:20:42 --> Loader Class Initialized
INFO - 2022-03-15 06:20:42 --> Helper loaded: url_helper
INFO - 2022-03-15 06:20:42 --> Helper loaded: form_helper
INFO - 2022-03-15 06:20:42 --> Helper loaded: common_helper
INFO - 2022-03-15 06:20:42 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:20:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-03-15 06:20:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:20:42 --> Config Class Initialized
INFO - 2022-03-15 06:20:42 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:20:42 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:20:42 --> Utf8 Class Initialized
INFO - 2022-03-15 06:20:42 --> URI Class Initialized
INFO - 2022-03-15 06:20:42 --> Router Class Initialized
INFO - 2022-03-15 06:20:42 --> Output Class Initialized
INFO - 2022-03-15 06:20:42 --> Security Class Initialized
DEBUG - 2022-03-15 06:20:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:20:42 --> Input Class Initialized
INFO - 2022-03-15 06:20:42 --> Language Class Initialized
INFO - 2022-03-15 06:20:42 --> Loader Class Initialized
INFO - 2022-03-15 06:20:42 --> Helper loaded: url_helper
INFO - 2022-03-15 06:20:42 --> Helper loaded: form_helper
INFO - 2022-03-15 06:20:42 --> Helper loaded: common_helper
INFO - 2022-03-15 06:20:42 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:20:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:20:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:20:42 --> Controller Class Initialized
INFO - 2022-03-15 06:20:42 --> Form Validation Class Initialized
DEBUG - 2022-03-15 06:20:42 --> Encrypt Class Initialized
INFO - 2022-03-15 06:20:42 --> Model "Patient_model" initialized
INFO - 2022-03-15 06:20:42 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 06:20:42 --> Model "Prefix_master" initialized
INFO - 2022-03-15 06:20:42 --> Model "Users_model" initialized
INFO - 2022-03-15 06:20:42 --> Model "Hospital_model" initialized
INFO - 2022-03-15 06:20:42 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 06:20:42 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-15 06:20:42 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 06:20:42 --> Final output sent to browser
DEBUG - 2022-03-15 06:20:42 --> Total execution time: 0.1877
INFO - 2022-03-15 06:20:48 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-15 06:20:48 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 06:20:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:20:48 --> Controller Class Initialized
INFO - 2022-03-15 06:20:48 --> Form Validation Class Initialized
DEBUG - 2022-03-15 06:20:48 --> Encrypt Class Initialized
INFO - 2022-03-15 06:20:48 --> Model "Patient_model" initialized
INFO - 2022-03-15 06:20:48 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 06:20:48 --> Model "Referredby_model" initialized
INFO - 2022-03-15 06:20:48 --> Model "Prefix_master" initialized
INFO - 2022-03-15 06:20:48 --> Model "Hospital_model" initialized
INFO - 2022-03-15 06:20:48 --> File loaded: /home3/karoteam/public_html/application/views/header.php
ERROR - 2022-03-15 06:20:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:20:49 --> Config Class Initialized
INFO - 2022-03-15 06:20:49 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:20:49 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:20:49 --> Utf8 Class Initialized
INFO - 2022-03-15 06:20:49 --> URI Class Initialized
INFO - 2022-03-15 06:20:49 --> Router Class Initialized
INFO - 2022-03-15 06:20:49 --> Output Class Initialized
INFO - 2022-03-15 06:20:49 --> Security Class Initialized
DEBUG - 2022-03-15 06:20:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:20:49 --> Input Class Initialized
INFO - 2022-03-15 06:20:49 --> Language Class Initialized
INFO - 2022-03-15 06:20:49 --> Loader Class Initialized
INFO - 2022-03-15 06:20:49 --> Helper loaded: url_helper
INFO - 2022-03-15 06:20:49 --> Helper loaded: form_helper
INFO - 2022-03-15 06:20:49 --> Helper loaded: common_helper
INFO - 2022-03-15 06:20:49 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:20:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:20:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:20:49 --> Controller Class Initialized
INFO - 2022-03-15 06:20:49 --> Form Validation Class Initialized
DEBUG - 2022-03-15 06:20:49 --> Encrypt Class Initialized
INFO - 2022-03-15 06:20:49 --> Model "Patient_model" initialized
INFO - 2022-03-15 06:20:49 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 06:20:49 --> Model "Referredby_model" initialized
INFO - 2022-03-15 06:20:49 --> Model "Prefix_master" initialized
INFO - 2022-03-15 06:20:49 --> Model "Hospital_model" initialized
INFO - 2022-03-15 06:20:49 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 06:20:49 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-15 06:20:49 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 06:20:49 --> Final output sent to browser
DEBUG - 2022-03-15 06:20:49 --> Total execution time: 0.1273
ERROR - 2022-03-15 06:20:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:20:51 --> Config Class Initialized
INFO - 2022-03-15 06:20:51 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:20:51 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:20:51 --> Utf8 Class Initialized
INFO - 2022-03-15 06:20:51 --> URI Class Initialized
INFO - 2022-03-15 06:20:51 --> Router Class Initialized
INFO - 2022-03-15 06:20:51 --> Output Class Initialized
INFO - 2022-03-15 06:20:51 --> Security Class Initialized
DEBUG - 2022-03-15 06:20:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:20:51 --> Input Class Initialized
INFO - 2022-03-15 06:20:51 --> Language Class Initialized
INFO - 2022-03-15 06:20:51 --> Loader Class Initialized
INFO - 2022-03-15 06:20:51 --> Helper loaded: url_helper
INFO - 2022-03-15 06:20:51 --> Helper loaded: form_helper
INFO - 2022-03-15 06:20:51 --> Helper loaded: common_helper
INFO - 2022-03-15 06:20:51 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:20:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:20:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:20:51 --> Controller Class Initialized
INFO - 2022-03-15 06:20:51 --> Form Validation Class Initialized
DEBUG - 2022-03-15 06:20:51 --> Encrypt Class Initialized
INFO - 2022-03-15 06:20:51 --> Model "Patient_model" initialized
INFO - 2022-03-15 06:20:51 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 06:20:51 --> Model "Referredby_model" initialized
INFO - 2022-03-15 06:20:51 --> Model "Prefix_master" initialized
INFO - 2022-03-15 06:20:51 --> Model "Hospital_model" initialized
INFO - 2022-03-15 06:20:51 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 06:20:51 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-15 06:20:51 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 06:20:51 --> Final output sent to browser
DEBUG - 2022-03-15 06:20:51 --> Total execution time: 0.0981
ERROR - 2022-03-15 06:20:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:20:51 --> Config Class Initialized
INFO - 2022-03-15 06:20:51 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:20:51 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:20:51 --> Utf8 Class Initialized
INFO - 2022-03-15 06:20:51 --> URI Class Initialized
INFO - 2022-03-15 06:20:51 --> Router Class Initialized
INFO - 2022-03-15 06:20:51 --> Output Class Initialized
INFO - 2022-03-15 06:20:51 --> Security Class Initialized
DEBUG - 2022-03-15 06:20:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:20:51 --> Input Class Initialized
INFO - 2022-03-15 06:20:51 --> Language Class Initialized
INFO - 2022-03-15 06:20:51 --> Loader Class Initialized
INFO - 2022-03-15 06:20:51 --> Helper loaded: url_helper
INFO - 2022-03-15 06:20:51 --> Helper loaded: form_helper
INFO - 2022-03-15 06:20:51 --> Helper loaded: common_helper
INFO - 2022-03-15 06:20:51 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:20:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:20:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:20:51 --> Controller Class Initialized
INFO - 2022-03-15 06:20:51 --> Form Validation Class Initialized
DEBUG - 2022-03-15 06:20:51 --> Encrypt Class Initialized
INFO - 2022-03-15 06:20:51 --> Model "Patient_model" initialized
INFO - 2022-03-15 06:20:51 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 06:20:51 --> Model "Referredby_model" initialized
INFO - 2022-03-15 06:20:51 --> Model "Prefix_master" initialized
INFO - 2022-03-15 06:20:51 --> Model "Hospital_model" initialized
INFO - 2022-03-15 06:20:51 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 06:20:59 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-15 06:20:59 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
ERROR - 2022-03-15 06:21:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:21:00 --> Config Class Initialized
INFO - 2022-03-15 06:21:00 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:21:00 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:21:00 --> Utf8 Class Initialized
INFO - 2022-03-15 06:21:00 --> URI Class Initialized
INFO - 2022-03-15 06:21:00 --> Router Class Initialized
INFO - 2022-03-15 06:21:00 --> Output Class Initialized
INFO - 2022-03-15 06:21:00 --> Security Class Initialized
DEBUG - 2022-03-15 06:21:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:21:00 --> Input Class Initialized
INFO - 2022-03-15 06:21:00 --> Language Class Initialized
INFO - 2022-03-15 06:21:00 --> Loader Class Initialized
INFO - 2022-03-15 06:21:00 --> Helper loaded: url_helper
INFO - 2022-03-15 06:21:00 --> Helper loaded: form_helper
INFO - 2022-03-15 06:21:00 --> Helper loaded: common_helper
INFO - 2022-03-15 06:21:00 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:21:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:21:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:21:00 --> Controller Class Initialized
INFO - 2022-03-15 06:21:00 --> Form Validation Class Initialized
DEBUG - 2022-03-15 06:21:00 --> Encrypt Class Initialized
INFO - 2022-03-15 06:21:00 --> Model "Patient_model" initialized
INFO - 2022-03-15 06:21:00 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 06:21:00 --> Model "Referredby_model" initialized
INFO - 2022-03-15 06:21:00 --> Model "Prefix_master" initialized
INFO - 2022-03-15 06:21:00 --> Model "Hospital_model" initialized
INFO - 2022-03-15 06:21:00 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 06:21:00 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-15 06:21:00 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 06:21:00 --> Final output sent to browser
DEBUG - 2022-03-15 06:21:00 --> Total execution time: 0.1207
INFO - 2022-03-15 06:21:03 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-15 06:21:03 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
ERROR - 2022-03-15 06:21:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:21:04 --> Config Class Initialized
INFO - 2022-03-15 06:21:04 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:21:04 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:21:04 --> Utf8 Class Initialized
INFO - 2022-03-15 06:21:04 --> URI Class Initialized
INFO - 2022-03-15 06:21:04 --> Router Class Initialized
INFO - 2022-03-15 06:21:04 --> Output Class Initialized
INFO - 2022-03-15 06:21:04 --> Security Class Initialized
DEBUG - 2022-03-15 06:21:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:21:04 --> Input Class Initialized
INFO - 2022-03-15 06:21:04 --> Language Class Initialized
ERROR - 2022-03-15 06:21:04 --> 404 Page Not Found: Karoclient/usersprofile
INFO - 2022-03-15 06:21:05 --> Final output sent to browser
DEBUG - 2022-03-15 06:21:05 --> Total execution time: 11.7757
ERROR - 2022-03-15 06:21:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:21:09 --> Config Class Initialized
INFO - 2022-03-15 06:21:09 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:21:09 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:21:09 --> Utf8 Class Initialized
INFO - 2022-03-15 06:21:09 --> URI Class Initialized
INFO - 2022-03-15 06:21:09 --> Router Class Initialized
INFO - 2022-03-15 06:21:09 --> Output Class Initialized
INFO - 2022-03-15 06:21:09 --> Security Class Initialized
DEBUG - 2022-03-15 06:21:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:21:09 --> Input Class Initialized
INFO - 2022-03-15 06:21:09 --> Language Class Initialized
INFO - 2022-03-15 06:21:09 --> Loader Class Initialized
INFO - 2022-03-15 06:21:09 --> Helper loaded: url_helper
INFO - 2022-03-15 06:21:09 --> Helper loaded: form_helper
INFO - 2022-03-15 06:21:09 --> Helper loaded: common_helper
INFO - 2022-03-15 06:21:09 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:21:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:21:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:21:09 --> Controller Class Initialized
INFO - 2022-03-15 06:21:09 --> Form Validation Class Initialized
DEBUG - 2022-03-15 06:21:09 --> Encrypt Class Initialized
INFO - 2022-03-15 06:21:09 --> Model "Patient_model" initialized
INFO - 2022-03-15 06:21:09 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 06:21:09 --> Model "Referredby_model" initialized
INFO - 2022-03-15 06:21:09 --> Model "Prefix_master" initialized
INFO - 2022-03-15 06:21:09 --> Model "Hospital_model" initialized
ERROR - 2022-03-15 06:21:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:21:10 --> Config Class Initialized
INFO - 2022-03-15 06:21:10 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:21:10 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:21:10 --> Utf8 Class Initialized
INFO - 2022-03-15 06:21:10 --> URI Class Initialized
INFO - 2022-03-15 06:21:10 --> Router Class Initialized
INFO - 2022-03-15 06:21:10 --> Output Class Initialized
INFO - 2022-03-15 06:21:10 --> Security Class Initialized
DEBUG - 2022-03-15 06:21:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:21:10 --> Input Class Initialized
INFO - 2022-03-15 06:21:10 --> Language Class Initialized
INFO - 2022-03-15 06:21:10 --> Loader Class Initialized
INFO - 2022-03-15 06:21:10 --> Helper loaded: url_helper
INFO - 2022-03-15 06:21:10 --> Helper loaded: form_helper
INFO - 2022-03-15 06:21:10 --> Helper loaded: common_helper
INFO - 2022-03-15 06:21:10 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:21:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:21:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:21:10 --> Controller Class Initialized
INFO - 2022-03-15 06:21:10 --> Form Validation Class Initialized
DEBUG - 2022-03-15 06:21:10 --> Encrypt Class Initialized
INFO - 2022-03-15 06:21:10 --> Model "Patient_model" initialized
INFO - 2022-03-15 06:21:10 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 06:21:10 --> Model "Referredby_model" initialized
INFO - 2022-03-15 06:21:10 --> Model "Prefix_master" initialized
INFO - 2022-03-15 06:21:10 --> Model "Hospital_model" initialized
INFO - 2022-03-15 06:21:10 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 06:21:10 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-15 06:21:10 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 06:21:10 --> Final output sent to browser
DEBUG - 2022-03-15 06:21:10 --> Total execution time: 0.0892
ERROR - 2022-03-15 06:21:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:21:11 --> Config Class Initialized
INFO - 2022-03-15 06:21:11 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:21:11 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:21:11 --> Utf8 Class Initialized
INFO - 2022-03-15 06:21:11 --> URI Class Initialized
INFO - 2022-03-15 06:21:11 --> Router Class Initialized
INFO - 2022-03-15 06:21:11 --> Output Class Initialized
INFO - 2022-03-15 06:21:11 --> Security Class Initialized
DEBUG - 2022-03-15 06:21:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:21:11 --> Input Class Initialized
INFO - 2022-03-15 06:21:11 --> Language Class Initialized
INFO - 2022-03-15 06:21:11 --> Loader Class Initialized
INFO - 2022-03-15 06:21:11 --> Helper loaded: url_helper
INFO - 2022-03-15 06:21:11 --> Helper loaded: form_helper
INFO - 2022-03-15 06:21:11 --> Helper loaded: common_helper
INFO - 2022-03-15 06:21:11 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:21:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:21:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:21:11 --> Controller Class Initialized
INFO - 2022-03-15 06:21:11 --> Form Validation Class Initialized
DEBUG - 2022-03-15 06:21:11 --> Encrypt Class Initialized
INFO - 2022-03-15 06:21:11 --> Model "Patient_model" initialized
INFO - 2022-03-15 06:21:11 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 06:21:11 --> Model "Prefix_master" initialized
INFO - 2022-03-15 06:21:11 --> Model "Users_model" initialized
INFO - 2022-03-15 06:21:11 --> Model "Hospital_model" initialized
INFO - 2022-03-15 06:21:11 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 06:21:11 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-15 06:21:11 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 06:21:11 --> Final output sent to browser
DEBUG - 2022-03-15 06:21:11 --> Total execution time: 0.1079
ERROR - 2022-03-15 06:22:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:22:19 --> Config Class Initialized
INFO - 2022-03-15 06:22:19 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:22:19 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:22:19 --> Utf8 Class Initialized
INFO - 2022-03-15 06:22:19 --> URI Class Initialized
INFO - 2022-03-15 06:22:19 --> Router Class Initialized
INFO - 2022-03-15 06:22:19 --> Output Class Initialized
INFO - 2022-03-15 06:22:19 --> Security Class Initialized
DEBUG - 2022-03-15 06:22:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:22:19 --> Input Class Initialized
INFO - 2022-03-15 06:22:19 --> Language Class Initialized
INFO - 2022-03-15 06:22:19 --> Loader Class Initialized
INFO - 2022-03-15 06:22:19 --> Helper loaded: url_helper
INFO - 2022-03-15 06:22:19 --> Helper loaded: form_helper
INFO - 2022-03-15 06:22:19 --> Helper loaded: common_helper
INFO - 2022-03-15 06:22:19 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:22:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:22:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:22:19 --> Controller Class Initialized
INFO - 2022-03-15 06:22:19 --> Form Validation Class Initialized
DEBUG - 2022-03-15 06:22:19 --> Encrypt Class Initialized
INFO - 2022-03-15 06:22:19 --> Model "Patient_model" initialized
INFO - 2022-03-15 06:22:19 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 06:22:19 --> Model "Prefix_master" initialized
INFO - 2022-03-15 06:22:19 --> Model "Users_model" initialized
INFO - 2022-03-15 06:22:19 --> Model "Hospital_model" initialized
INFO - 2022-03-15 06:22:19 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 06:22:19 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-15 06:22:19 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 06:22:19 --> Final output sent to browser
DEBUG - 2022-03-15 06:22:19 --> Total execution time: 0.0879
ERROR - 2022-03-15 06:22:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:22:20 --> Config Class Initialized
INFO - 2022-03-15 06:22:20 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:22:20 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:22:20 --> Utf8 Class Initialized
INFO - 2022-03-15 06:22:20 --> URI Class Initialized
INFO - 2022-03-15 06:22:20 --> Router Class Initialized
INFO - 2022-03-15 06:22:20 --> Output Class Initialized
INFO - 2022-03-15 06:22:20 --> Security Class Initialized
DEBUG - 2022-03-15 06:22:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:22:20 --> Input Class Initialized
INFO - 2022-03-15 06:22:20 --> Language Class Initialized
ERROR - 2022-03-15 06:22:20 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-15 06:22:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:22:28 --> Config Class Initialized
INFO - 2022-03-15 06:22:28 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:22:28 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:22:28 --> Utf8 Class Initialized
INFO - 2022-03-15 06:22:28 --> URI Class Initialized
INFO - 2022-03-15 06:22:28 --> Router Class Initialized
INFO - 2022-03-15 06:22:28 --> Output Class Initialized
INFO - 2022-03-15 06:22:28 --> Security Class Initialized
DEBUG - 2022-03-15 06:22:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:22:28 --> Input Class Initialized
INFO - 2022-03-15 06:22:28 --> Language Class Initialized
INFO - 2022-03-15 06:22:28 --> Loader Class Initialized
INFO - 2022-03-15 06:22:28 --> Helper loaded: url_helper
INFO - 2022-03-15 06:22:28 --> Helper loaded: form_helper
INFO - 2022-03-15 06:22:28 --> Helper loaded: common_helper
INFO - 2022-03-15 06:22:28 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:22:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:22:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:22:28 --> Controller Class Initialized
INFO - 2022-03-15 06:22:28 --> Form Validation Class Initialized
DEBUG - 2022-03-15 06:22:28 --> Encrypt Class Initialized
INFO - 2022-03-15 06:22:28 --> Model "Patient_model" initialized
INFO - 2022-03-15 06:22:28 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 06:22:28 --> Model "Prefix_master" initialized
INFO - 2022-03-15 06:22:28 --> Model "Users_model" initialized
INFO - 2022-03-15 06:22:28 --> Model "Hospital_model" initialized
ERROR - 2022-03-15 06:22:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:22:29 --> Config Class Initialized
INFO - 2022-03-15 06:22:29 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:22:29 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:22:29 --> Utf8 Class Initialized
INFO - 2022-03-15 06:22:29 --> URI Class Initialized
INFO - 2022-03-15 06:22:29 --> Router Class Initialized
INFO - 2022-03-15 06:22:29 --> Output Class Initialized
INFO - 2022-03-15 06:22:29 --> Security Class Initialized
DEBUG - 2022-03-15 06:22:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:22:29 --> Input Class Initialized
INFO - 2022-03-15 06:22:29 --> Language Class Initialized
INFO - 2022-03-15 06:22:29 --> Loader Class Initialized
INFO - 2022-03-15 06:22:29 --> Helper loaded: url_helper
INFO - 2022-03-15 06:22:29 --> Helper loaded: form_helper
INFO - 2022-03-15 06:22:29 --> Helper loaded: common_helper
INFO - 2022-03-15 06:22:29 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:22:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:22:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:22:29 --> Controller Class Initialized
INFO - 2022-03-15 06:22:29 --> Form Validation Class Initialized
DEBUG - 2022-03-15 06:22:29 --> Encrypt Class Initialized
INFO - 2022-03-15 06:22:29 --> Model "Patient_model" initialized
INFO - 2022-03-15 06:22:29 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 06:22:29 --> Model "Prefix_master" initialized
INFO - 2022-03-15 06:22:29 --> Model "Users_model" initialized
INFO - 2022-03-15 06:22:29 --> Model "Hospital_model" initialized
INFO - 2022-03-15 06:22:29 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 06:22:29 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-15 06:22:29 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 06:22:29 --> Final output sent to browser
DEBUG - 2022-03-15 06:22:29 --> Total execution time: 0.0852
ERROR - 2022-03-15 06:22:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:22:29 --> Config Class Initialized
INFO - 2022-03-15 06:22:29 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:22:29 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:22:29 --> Utf8 Class Initialized
INFO - 2022-03-15 06:22:29 --> URI Class Initialized
INFO - 2022-03-15 06:22:29 --> Router Class Initialized
INFO - 2022-03-15 06:22:29 --> Output Class Initialized
INFO - 2022-03-15 06:22:29 --> Security Class Initialized
DEBUG - 2022-03-15 06:22:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:22:29 --> Input Class Initialized
INFO - 2022-03-15 06:22:29 --> Language Class Initialized
ERROR - 2022-03-15 06:22:29 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-15 06:22:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:22:30 --> Config Class Initialized
INFO - 2022-03-15 06:22:30 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:22:30 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:22:30 --> Utf8 Class Initialized
INFO - 2022-03-15 06:22:30 --> URI Class Initialized
INFO - 2022-03-15 06:22:30 --> Router Class Initialized
INFO - 2022-03-15 06:22:30 --> Output Class Initialized
INFO - 2022-03-15 06:22:30 --> Security Class Initialized
DEBUG - 2022-03-15 06:22:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:22:30 --> Input Class Initialized
INFO - 2022-03-15 06:22:30 --> Language Class Initialized
INFO - 2022-03-15 06:22:30 --> Loader Class Initialized
INFO - 2022-03-15 06:22:30 --> Helper loaded: url_helper
INFO - 2022-03-15 06:22:30 --> Helper loaded: form_helper
INFO - 2022-03-15 06:22:30 --> Helper loaded: common_helper
INFO - 2022-03-15 06:22:30 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:22:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:22:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:22:30 --> Controller Class Initialized
INFO - 2022-03-15 06:22:30 --> Form Validation Class Initialized
DEBUG - 2022-03-15 06:22:30 --> Encrypt Class Initialized
INFO - 2022-03-15 06:22:30 --> Model "Patient_model" initialized
INFO - 2022-03-15 06:22:30 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 06:22:30 --> Model "Prefix_master" initialized
INFO - 2022-03-15 06:22:30 --> Model "Users_model" initialized
INFO - 2022-03-15 06:22:30 --> Model "Hospital_model" initialized
ERROR - 2022-03-15 06:22:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:22:31 --> Config Class Initialized
INFO - 2022-03-15 06:22:31 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:22:31 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:22:31 --> Utf8 Class Initialized
INFO - 2022-03-15 06:22:31 --> URI Class Initialized
INFO - 2022-03-15 06:22:31 --> Router Class Initialized
INFO - 2022-03-15 06:22:31 --> Output Class Initialized
INFO - 2022-03-15 06:22:31 --> Security Class Initialized
DEBUG - 2022-03-15 06:22:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:22:31 --> Input Class Initialized
INFO - 2022-03-15 06:22:31 --> Language Class Initialized
INFO - 2022-03-15 06:22:31 --> Loader Class Initialized
INFO - 2022-03-15 06:22:31 --> Helper loaded: url_helper
INFO - 2022-03-15 06:22:31 --> Helper loaded: form_helper
INFO - 2022-03-15 06:22:31 --> Helper loaded: common_helper
INFO - 2022-03-15 06:22:31 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:22:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:22:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:22:31 --> Controller Class Initialized
INFO - 2022-03-15 06:22:31 --> Form Validation Class Initialized
DEBUG - 2022-03-15 06:22:31 --> Encrypt Class Initialized
INFO - 2022-03-15 06:22:31 --> Model "Patient_model" initialized
INFO - 2022-03-15 06:22:31 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 06:22:31 --> Model "Prefix_master" initialized
INFO - 2022-03-15 06:22:31 --> Model "Users_model" initialized
INFO - 2022-03-15 06:22:31 --> Model "Hospital_model" initialized
INFO - 2022-03-15 06:22:31 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 06:22:31 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-15 06:22:31 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 06:22:31 --> Final output sent to browser
DEBUG - 2022-03-15 06:22:31 --> Total execution time: 0.0580
ERROR - 2022-03-15 06:22:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:22:53 --> Config Class Initialized
INFO - 2022-03-15 06:22:53 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:22:53 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:22:53 --> Utf8 Class Initialized
INFO - 2022-03-15 06:22:53 --> URI Class Initialized
INFO - 2022-03-15 06:22:53 --> Router Class Initialized
INFO - 2022-03-15 06:22:53 --> Output Class Initialized
INFO - 2022-03-15 06:22:53 --> Security Class Initialized
DEBUG - 2022-03-15 06:22:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:22:53 --> Input Class Initialized
INFO - 2022-03-15 06:22:53 --> Language Class Initialized
INFO - 2022-03-15 06:22:53 --> Loader Class Initialized
INFO - 2022-03-15 06:22:53 --> Helper loaded: url_helper
INFO - 2022-03-15 06:22:53 --> Helper loaded: form_helper
INFO - 2022-03-15 06:22:53 --> Helper loaded: common_helper
INFO - 2022-03-15 06:22:53 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:22:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:22:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:22:53 --> Controller Class Initialized
INFO - 2022-03-15 06:22:53 --> Form Validation Class Initialized
DEBUG - 2022-03-15 06:22:53 --> Encrypt Class Initialized
INFO - 2022-03-15 06:22:53 --> Model "Patient_model" initialized
INFO - 2022-03-15 06:22:53 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 06:22:53 --> Model "Referredby_model" initialized
INFO - 2022-03-15 06:22:53 --> Model "Prefix_master" initialized
INFO - 2022-03-15 06:22:53 --> Model "Hospital_model" initialized
INFO - 2022-03-15 06:22:53 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 06:23:10 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-15 06:23:10 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
ERROR - 2022-03-15 06:23:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:23:11 --> Config Class Initialized
INFO - 2022-03-15 06:23:11 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:23:11 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:23:11 --> Utf8 Class Initialized
INFO - 2022-03-15 06:23:11 --> URI Class Initialized
INFO - 2022-03-15 06:23:11 --> Router Class Initialized
INFO - 2022-03-15 06:23:11 --> Output Class Initialized
INFO - 2022-03-15 06:23:11 --> Security Class Initialized
DEBUG - 2022-03-15 06:23:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:23:11 --> Input Class Initialized
INFO - 2022-03-15 06:23:11 --> Language Class Initialized
ERROR - 2022-03-15 06:23:11 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-15 06:23:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:23:11 --> Config Class Initialized
INFO - 2022-03-15 06:23:11 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:23:11 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:23:11 --> Utf8 Class Initialized
INFO - 2022-03-15 06:23:11 --> URI Class Initialized
INFO - 2022-03-15 06:23:11 --> Router Class Initialized
INFO - 2022-03-15 06:23:11 --> Output Class Initialized
INFO - 2022-03-15 06:23:11 --> Security Class Initialized
DEBUG - 2022-03-15 06:23:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:23:11 --> Input Class Initialized
INFO - 2022-03-15 06:23:11 --> Language Class Initialized
INFO - 2022-03-15 06:23:11 --> Loader Class Initialized
INFO - 2022-03-15 06:23:11 --> Helper loaded: url_helper
INFO - 2022-03-15 06:23:11 --> Helper loaded: form_helper
INFO - 2022-03-15 06:23:11 --> Helper loaded: common_helper
INFO - 2022-03-15 06:23:11 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:23:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:23:12 --> Final output sent to browser
DEBUG - 2022-03-15 06:23:12 --> Total execution time: 16.5692
INFO - 2022-03-15 06:23:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:23:12 --> Controller Class Initialized
INFO - 2022-03-15 06:23:12 --> Form Validation Class Initialized
DEBUG - 2022-03-15 06:23:12 --> Encrypt Class Initialized
INFO - 2022-03-15 06:23:12 --> Model "Patient_model" initialized
INFO - 2022-03-15 06:23:12 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 06:23:12 --> Model "Referredby_model" initialized
INFO - 2022-03-15 06:23:12 --> Model "Prefix_master" initialized
INFO - 2022-03-15 06:23:12 --> Model "Hospital_model" initialized
INFO - 2022-03-15 06:23:12 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 06:23:24 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-15 06:23:24 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
ERROR - 2022-03-15 06:23:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:23:25 --> Config Class Initialized
INFO - 2022-03-15 06:23:25 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:23:25 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:23:25 --> Utf8 Class Initialized
INFO - 2022-03-15 06:23:25 --> URI Class Initialized
INFO - 2022-03-15 06:23:25 --> Router Class Initialized
INFO - 2022-03-15 06:23:25 --> Output Class Initialized
INFO - 2022-03-15 06:23:25 --> Security Class Initialized
DEBUG - 2022-03-15 06:23:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:23:25 --> Input Class Initialized
INFO - 2022-03-15 06:23:25 --> Language Class Initialized
ERROR - 2022-03-15 06:23:25 --> 404 Page Not Found: Karoclient/usersprofile
INFO - 2022-03-15 06:23:25 --> Final output sent to browser
DEBUG - 2022-03-15 06:23:25 --> Total execution time: 12.8692
ERROR - 2022-03-15 06:24:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:24:12 --> Config Class Initialized
INFO - 2022-03-15 06:24:12 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:24:12 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:24:12 --> Utf8 Class Initialized
INFO - 2022-03-15 06:24:12 --> URI Class Initialized
INFO - 2022-03-15 06:24:12 --> Router Class Initialized
INFO - 2022-03-15 06:24:12 --> Output Class Initialized
INFO - 2022-03-15 06:24:12 --> Security Class Initialized
DEBUG - 2022-03-15 06:24:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:24:12 --> Input Class Initialized
INFO - 2022-03-15 06:24:12 --> Language Class Initialized
INFO - 2022-03-15 06:24:12 --> Loader Class Initialized
INFO - 2022-03-15 06:24:12 --> Helper loaded: url_helper
INFO - 2022-03-15 06:24:12 --> Helper loaded: form_helper
INFO - 2022-03-15 06:24:12 --> Helper loaded: common_helper
INFO - 2022-03-15 06:24:12 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:24:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:24:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:24:12 --> Controller Class Initialized
INFO - 2022-03-15 06:24:12 --> Form Validation Class Initialized
DEBUG - 2022-03-15 06:24:12 --> Encrypt Class Initialized
INFO - 2022-03-15 06:24:12 --> Model "Patient_model" initialized
INFO - 2022-03-15 06:24:12 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 06:24:12 --> Model "Referredby_model" initialized
INFO - 2022-03-15 06:24:12 --> Model "Prefix_master" initialized
INFO - 2022-03-15 06:24:12 --> Model "Hospital_model" initialized
INFO - 2022-03-15 06:24:12 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 06:24:12 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-15 06:24:12 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 06:24:12 --> Final output sent to browser
DEBUG - 2022-03-15 06:24:12 --> Total execution time: 0.1307
ERROR - 2022-03-15 06:24:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:24:13 --> Config Class Initialized
INFO - 2022-03-15 06:24:13 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:24:13 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:24:13 --> Utf8 Class Initialized
INFO - 2022-03-15 06:24:13 --> URI Class Initialized
INFO - 2022-03-15 06:24:13 --> Router Class Initialized
INFO - 2022-03-15 06:24:13 --> Output Class Initialized
INFO - 2022-03-15 06:24:13 --> Security Class Initialized
DEBUG - 2022-03-15 06:24:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:24:13 --> Input Class Initialized
INFO - 2022-03-15 06:24:13 --> Language Class Initialized
INFO - 2022-03-15 06:24:13 --> Loader Class Initialized
INFO - 2022-03-15 06:24:13 --> Helper loaded: url_helper
INFO - 2022-03-15 06:24:13 --> Helper loaded: form_helper
INFO - 2022-03-15 06:24:13 --> Helper loaded: common_helper
INFO - 2022-03-15 06:24:13 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:24:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:24:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:24:13 --> Controller Class Initialized
INFO - 2022-03-15 06:24:13 --> Form Validation Class Initialized
DEBUG - 2022-03-15 06:24:13 --> Encrypt Class Initialized
INFO - 2022-03-15 06:24:13 --> Model "Patient_model" initialized
INFO - 2022-03-15 06:24:13 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 06:24:13 --> Model "Referredby_model" initialized
INFO - 2022-03-15 06:24:13 --> Model "Prefix_master" initialized
INFO - 2022-03-15 06:24:13 --> Model "Hospital_model" initialized
INFO - 2022-03-15 06:24:13 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 06:24:13 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-15 06:24:13 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 06:24:13 --> Final output sent to browser
DEBUG - 2022-03-15 06:24:13 --> Total execution time: 0.1120
ERROR - 2022-03-15 06:24:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:24:23 --> Config Class Initialized
INFO - 2022-03-15 06:24:23 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:24:23 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:24:23 --> Utf8 Class Initialized
INFO - 2022-03-15 06:24:23 --> URI Class Initialized
INFO - 2022-03-15 06:24:23 --> Router Class Initialized
INFO - 2022-03-15 06:24:23 --> Output Class Initialized
INFO - 2022-03-15 06:24:23 --> Security Class Initialized
DEBUG - 2022-03-15 06:24:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:24:23 --> Input Class Initialized
INFO - 2022-03-15 06:24:23 --> Language Class Initialized
INFO - 2022-03-15 06:24:23 --> Loader Class Initialized
INFO - 2022-03-15 06:24:23 --> Helper loaded: url_helper
INFO - 2022-03-15 06:24:23 --> Helper loaded: form_helper
INFO - 2022-03-15 06:24:23 --> Helper loaded: common_helper
INFO - 2022-03-15 06:24:23 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:24:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:24:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:24:23 --> Controller Class Initialized
INFO - 2022-03-15 06:24:23 --> Form Validation Class Initialized
DEBUG - 2022-03-15 06:24:23 --> Encrypt Class Initialized
INFO - 2022-03-15 06:24:23 --> Model "Patient_model" initialized
INFO - 2022-03-15 06:24:23 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 06:24:23 --> Model "Prefix_master" initialized
INFO - 2022-03-15 06:24:23 --> Model "Users_model" initialized
INFO - 2022-03-15 06:24:23 --> Model "Hospital_model" initialized
ERROR - 2022-03-15 06:24:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:24:23 --> Config Class Initialized
INFO - 2022-03-15 06:24:23 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:24:23 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:24:23 --> Utf8 Class Initialized
INFO - 2022-03-15 06:24:23 --> URI Class Initialized
INFO - 2022-03-15 06:24:23 --> Router Class Initialized
INFO - 2022-03-15 06:24:23 --> Output Class Initialized
INFO - 2022-03-15 06:24:23 --> Security Class Initialized
DEBUG - 2022-03-15 06:24:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:24:23 --> Input Class Initialized
INFO - 2022-03-15 06:24:23 --> Language Class Initialized
INFO - 2022-03-15 06:24:23 --> Loader Class Initialized
INFO - 2022-03-15 06:24:23 --> Helper loaded: url_helper
INFO - 2022-03-15 06:24:23 --> Helper loaded: form_helper
INFO - 2022-03-15 06:24:23 --> Helper loaded: common_helper
INFO - 2022-03-15 06:24:23 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:24:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:24:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:24:23 --> Controller Class Initialized
INFO - 2022-03-15 06:24:23 --> Form Validation Class Initialized
DEBUG - 2022-03-15 06:24:23 --> Encrypt Class Initialized
INFO - 2022-03-15 06:24:23 --> Model "Patient_model" initialized
INFO - 2022-03-15 06:24:23 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 06:24:23 --> Model "Prefix_master" initialized
INFO - 2022-03-15 06:24:23 --> Model "Users_model" initialized
INFO - 2022-03-15 06:24:23 --> Model "Hospital_model" initialized
INFO - 2022-03-15 06:24:23 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 06:24:23 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-15 06:24:23 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 06:24:23 --> Final output sent to browser
DEBUG - 2022-03-15 06:24:23 --> Total execution time: 0.0827
ERROR - 2022-03-15 06:24:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:24:46 --> Config Class Initialized
INFO - 2022-03-15 06:24:46 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:24:46 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:24:46 --> Utf8 Class Initialized
INFO - 2022-03-15 06:24:46 --> URI Class Initialized
INFO - 2022-03-15 06:24:46 --> Router Class Initialized
INFO - 2022-03-15 06:24:46 --> Output Class Initialized
INFO - 2022-03-15 06:24:46 --> Security Class Initialized
DEBUG - 2022-03-15 06:24:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:24:46 --> Input Class Initialized
INFO - 2022-03-15 06:24:46 --> Language Class Initialized
INFO - 2022-03-15 06:24:46 --> Loader Class Initialized
INFO - 2022-03-15 06:24:46 --> Helper loaded: url_helper
INFO - 2022-03-15 06:24:46 --> Helper loaded: form_helper
INFO - 2022-03-15 06:24:46 --> Helper loaded: common_helper
INFO - 2022-03-15 06:24:46 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:24:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:24:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:24:46 --> Controller Class Initialized
INFO - 2022-03-15 06:24:46 --> Form Validation Class Initialized
DEBUG - 2022-03-15 06:24:46 --> Encrypt Class Initialized
INFO - 2022-03-15 06:24:46 --> Model "Patient_model" initialized
INFO - 2022-03-15 06:24:46 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 06:24:46 --> Model "Referredby_model" initialized
INFO - 2022-03-15 06:24:46 --> Model "Prefix_master" initialized
INFO - 2022-03-15 06:24:46 --> Model "Hospital_model" initialized
INFO - 2022-03-15 06:24:46 --> Final output sent to browser
DEBUG - 2022-03-15 06:24:46 --> Total execution time: 0.0498
ERROR - 2022-03-15 06:24:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:24:56 --> Config Class Initialized
INFO - 2022-03-15 06:24:56 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:24:56 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:24:56 --> Utf8 Class Initialized
INFO - 2022-03-15 06:24:56 --> URI Class Initialized
INFO - 2022-03-15 06:24:56 --> Router Class Initialized
INFO - 2022-03-15 06:24:56 --> Output Class Initialized
INFO - 2022-03-15 06:24:56 --> Security Class Initialized
DEBUG - 2022-03-15 06:24:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:24:56 --> Input Class Initialized
INFO - 2022-03-15 06:24:56 --> Language Class Initialized
INFO - 2022-03-15 06:24:56 --> Loader Class Initialized
INFO - 2022-03-15 06:24:56 --> Helper loaded: url_helper
INFO - 2022-03-15 06:24:56 --> Helper loaded: form_helper
INFO - 2022-03-15 06:24:56 --> Helper loaded: common_helper
INFO - 2022-03-15 06:24:56 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:24:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:24:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:24:56 --> Controller Class Initialized
INFO - 2022-03-15 06:24:56 --> Form Validation Class Initialized
DEBUG - 2022-03-15 06:24:56 --> Encrypt Class Initialized
INFO - 2022-03-15 06:24:56 --> Model "Patient_model" initialized
INFO - 2022-03-15 06:24:56 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 06:24:56 --> Model "Referredby_model" initialized
INFO - 2022-03-15 06:24:56 --> Model "Prefix_master" initialized
INFO - 2022-03-15 06:24:56 --> Model "Hospital_model" initialized
INFO - 2022-03-15 06:24:56 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 06:24:56 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-15 06:24:56 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 06:24:56 --> Final output sent to browser
DEBUG - 2022-03-15 06:24:56 --> Total execution time: 0.0618
ERROR - 2022-03-15 06:24:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:24:57 --> Config Class Initialized
INFO - 2022-03-15 06:24:57 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:24:57 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:24:57 --> Utf8 Class Initialized
INFO - 2022-03-15 06:24:57 --> URI Class Initialized
INFO - 2022-03-15 06:24:57 --> Router Class Initialized
INFO - 2022-03-15 06:24:57 --> Output Class Initialized
INFO - 2022-03-15 06:24:57 --> Security Class Initialized
DEBUG - 2022-03-15 06:24:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:24:57 --> Input Class Initialized
INFO - 2022-03-15 06:24:57 --> Language Class Initialized
ERROR - 2022-03-15 06:24:57 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-15 06:25:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:25:15 --> Config Class Initialized
INFO - 2022-03-15 06:25:15 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:25:15 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:25:15 --> Utf8 Class Initialized
INFO - 2022-03-15 06:25:15 --> URI Class Initialized
INFO - 2022-03-15 06:25:15 --> Router Class Initialized
INFO - 2022-03-15 06:25:15 --> Output Class Initialized
INFO - 2022-03-15 06:25:15 --> Security Class Initialized
DEBUG - 2022-03-15 06:25:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:25:15 --> Input Class Initialized
INFO - 2022-03-15 06:25:15 --> Language Class Initialized
INFO - 2022-03-15 06:25:15 --> Loader Class Initialized
INFO - 2022-03-15 06:25:15 --> Helper loaded: url_helper
INFO - 2022-03-15 06:25:15 --> Helper loaded: form_helper
INFO - 2022-03-15 06:25:15 --> Helper loaded: common_helper
INFO - 2022-03-15 06:25:15 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:25:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:25:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:25:15 --> Controller Class Initialized
INFO - 2022-03-15 06:25:15 --> Form Validation Class Initialized
DEBUG - 2022-03-15 06:25:15 --> Encrypt Class Initialized
INFO - 2022-03-15 06:25:15 --> Model "Patient_model" initialized
INFO - 2022-03-15 06:25:15 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 06:25:15 --> Model "Referredby_model" initialized
INFO - 2022-03-15 06:25:15 --> Model "Prefix_master" initialized
INFO - 2022-03-15 06:25:15 --> Model "Hospital_model" initialized
ERROR - 2022-03-15 06:25:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:25:16 --> Config Class Initialized
INFO - 2022-03-15 06:25:16 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:25:16 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:25:16 --> Utf8 Class Initialized
INFO - 2022-03-15 06:25:16 --> URI Class Initialized
INFO - 2022-03-15 06:25:16 --> Router Class Initialized
INFO - 2022-03-15 06:25:16 --> Output Class Initialized
INFO - 2022-03-15 06:25:16 --> Security Class Initialized
DEBUG - 2022-03-15 06:25:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:25:16 --> Input Class Initialized
INFO - 2022-03-15 06:25:16 --> Language Class Initialized
INFO - 2022-03-15 06:25:16 --> Loader Class Initialized
INFO - 2022-03-15 06:25:16 --> Helper loaded: url_helper
INFO - 2022-03-15 06:25:16 --> Helper loaded: form_helper
INFO - 2022-03-15 06:25:16 --> Helper loaded: common_helper
INFO - 2022-03-15 06:25:16 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:25:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:25:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:25:16 --> Controller Class Initialized
INFO - 2022-03-15 06:25:16 --> Form Validation Class Initialized
DEBUG - 2022-03-15 06:25:16 --> Encrypt Class Initialized
INFO - 2022-03-15 06:25:16 --> Model "Patient_model" initialized
INFO - 2022-03-15 06:25:16 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 06:25:16 --> Model "Referredby_model" initialized
INFO - 2022-03-15 06:25:16 --> Model "Prefix_master" initialized
INFO - 2022-03-15 06:25:16 --> Model "Hospital_model" initialized
INFO - 2022-03-15 06:25:16 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 06:25:16 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-15 06:25:16 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 06:25:16 --> Final output sent to browser
DEBUG - 2022-03-15 06:25:16 --> Total execution time: 0.0982
ERROR - 2022-03-15 06:25:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:25:17 --> Config Class Initialized
INFO - 2022-03-15 06:25:17 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:25:17 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:25:17 --> Utf8 Class Initialized
INFO - 2022-03-15 06:25:17 --> URI Class Initialized
INFO - 2022-03-15 06:25:17 --> Router Class Initialized
INFO - 2022-03-15 06:25:17 --> Output Class Initialized
INFO - 2022-03-15 06:25:17 --> Security Class Initialized
DEBUG - 2022-03-15 06:25:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:25:17 --> Input Class Initialized
INFO - 2022-03-15 06:25:17 --> Language Class Initialized
ERROR - 2022-03-15 06:25:17 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-15 06:25:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:25:17 --> Config Class Initialized
INFO - 2022-03-15 06:25:17 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:25:17 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:25:17 --> Utf8 Class Initialized
INFO - 2022-03-15 06:25:17 --> URI Class Initialized
INFO - 2022-03-15 06:25:17 --> Router Class Initialized
INFO - 2022-03-15 06:25:17 --> Output Class Initialized
INFO - 2022-03-15 06:25:17 --> Security Class Initialized
DEBUG - 2022-03-15 06:25:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:25:17 --> Input Class Initialized
INFO - 2022-03-15 06:25:17 --> Language Class Initialized
INFO - 2022-03-15 06:25:17 --> Loader Class Initialized
INFO - 2022-03-15 06:25:17 --> Helper loaded: url_helper
INFO - 2022-03-15 06:25:17 --> Helper loaded: form_helper
INFO - 2022-03-15 06:25:17 --> Helper loaded: common_helper
INFO - 2022-03-15 06:25:17 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:25:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:25:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:25:17 --> Controller Class Initialized
INFO - 2022-03-15 06:25:17 --> Form Validation Class Initialized
DEBUG - 2022-03-15 06:25:17 --> Encrypt Class Initialized
INFO - 2022-03-15 06:25:17 --> Model "Patient_model" initialized
INFO - 2022-03-15 06:25:17 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 06:25:17 --> Model "Prefix_master" initialized
INFO - 2022-03-15 06:25:17 --> Model "Users_model" initialized
INFO - 2022-03-15 06:25:17 --> Model "Hospital_model" initialized
ERROR - 2022-03-15 06:25:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:25:17 --> Config Class Initialized
INFO - 2022-03-15 06:25:17 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:25:17 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:25:17 --> Utf8 Class Initialized
INFO - 2022-03-15 06:25:17 --> URI Class Initialized
INFO - 2022-03-15 06:25:17 --> Router Class Initialized
INFO - 2022-03-15 06:25:17 --> Output Class Initialized
INFO - 2022-03-15 06:25:17 --> Security Class Initialized
DEBUG - 2022-03-15 06:25:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:25:17 --> Input Class Initialized
INFO - 2022-03-15 06:25:17 --> Language Class Initialized
INFO - 2022-03-15 06:25:17 --> Loader Class Initialized
INFO - 2022-03-15 06:25:17 --> Helper loaded: url_helper
INFO - 2022-03-15 06:25:17 --> Helper loaded: form_helper
INFO - 2022-03-15 06:25:17 --> Helper loaded: common_helper
INFO - 2022-03-15 06:25:17 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:25:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:25:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:25:17 --> Controller Class Initialized
INFO - 2022-03-15 06:25:17 --> Form Validation Class Initialized
DEBUG - 2022-03-15 06:25:17 --> Encrypt Class Initialized
INFO - 2022-03-15 06:25:17 --> Model "Patient_model" initialized
INFO - 2022-03-15 06:25:17 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 06:25:17 --> Model "Referredby_model" initialized
INFO - 2022-03-15 06:25:17 --> Model "Prefix_master" initialized
INFO - 2022-03-15 06:25:17 --> Model "Hospital_model" initialized
INFO - 2022-03-15 06:25:17 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 06:25:17 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-15 06:25:17 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 06:25:18 --> Final output sent to browser
DEBUG - 2022-03-15 06:25:18 --> Total execution time: 0.1938
INFO - 2022-03-15 06:25:18 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 06:25:18 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-15 06:25:18 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 06:25:18 --> Final output sent to browser
DEBUG - 2022-03-15 06:25:18 --> Total execution time: 0.1424
ERROR - 2022-03-15 06:25:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:25:18 --> Config Class Initialized
INFO - 2022-03-15 06:25:18 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:25:18 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:25:18 --> Utf8 Class Initialized
INFO - 2022-03-15 06:25:18 --> URI Class Initialized
INFO - 2022-03-15 06:25:18 --> Router Class Initialized
INFO - 2022-03-15 06:25:18 --> Output Class Initialized
INFO - 2022-03-15 06:25:18 --> Security Class Initialized
DEBUG - 2022-03-15 06:25:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:25:18 --> Input Class Initialized
INFO - 2022-03-15 06:25:18 --> Language Class Initialized
ERROR - 2022-03-15 06:25:18 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-15 06:25:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:25:21 --> Config Class Initialized
INFO - 2022-03-15 06:25:21 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:25:21 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:25:21 --> Utf8 Class Initialized
INFO - 2022-03-15 06:25:21 --> URI Class Initialized
INFO - 2022-03-15 06:25:21 --> Router Class Initialized
INFO - 2022-03-15 06:25:21 --> Output Class Initialized
INFO - 2022-03-15 06:25:21 --> Security Class Initialized
DEBUG - 2022-03-15 06:25:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:25:21 --> Input Class Initialized
INFO - 2022-03-15 06:25:21 --> Language Class Initialized
INFO - 2022-03-15 06:25:21 --> Loader Class Initialized
INFO - 2022-03-15 06:25:21 --> Helper loaded: url_helper
INFO - 2022-03-15 06:25:21 --> Helper loaded: form_helper
INFO - 2022-03-15 06:25:21 --> Helper loaded: common_helper
INFO - 2022-03-15 06:25:21 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:25:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:25:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:25:21 --> Controller Class Initialized
INFO - 2022-03-15 06:25:21 --> Form Validation Class Initialized
DEBUG - 2022-03-15 06:25:21 --> Encrypt Class Initialized
INFO - 2022-03-15 06:25:21 --> Model "Patient_model" initialized
INFO - 2022-03-15 06:25:21 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 06:25:21 --> Model "Referredby_model" initialized
INFO - 2022-03-15 06:25:21 --> Model "Prefix_master" initialized
INFO - 2022-03-15 06:25:21 --> Model "Hospital_model" initialized
INFO - 2022-03-15 06:25:22 --> File loaded: /home3/karoteam/public_html/application/views/header.php
ERROR - 2022-03-15 06:25:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:25:25 --> Config Class Initialized
INFO - 2022-03-15 06:25:25 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:25:25 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:25:25 --> Utf8 Class Initialized
INFO - 2022-03-15 06:25:25 --> URI Class Initialized
INFO - 2022-03-15 06:25:25 --> Router Class Initialized
INFO - 2022-03-15 06:25:26 --> Output Class Initialized
INFO - 2022-03-15 06:25:26 --> Security Class Initialized
DEBUG - 2022-03-15 06:25:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:25:26 --> Input Class Initialized
INFO - 2022-03-15 06:25:26 --> Language Class Initialized
INFO - 2022-03-15 06:25:26 --> Loader Class Initialized
INFO - 2022-03-15 06:25:26 --> Helper loaded: url_helper
INFO - 2022-03-15 06:25:26 --> Helper loaded: form_helper
INFO - 2022-03-15 06:25:26 --> Helper loaded: common_helper
INFO - 2022-03-15 06:25:26 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:25:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:25:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:25:26 --> Controller Class Initialized
INFO - 2022-03-15 06:25:26 --> Form Validation Class Initialized
DEBUG - 2022-03-15 06:25:26 --> Encrypt Class Initialized
INFO - 2022-03-15 06:25:26 --> Model "Patient_model" initialized
INFO - 2022-03-15 06:25:26 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 06:25:26 --> Model "Referredby_model" initialized
INFO - 2022-03-15 06:25:26 --> Model "Prefix_master" initialized
INFO - 2022-03-15 06:25:26 --> Model "Hospital_model" initialized
INFO - 2022-03-15 06:25:26 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 06:25:26 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-15 06:25:26 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 06:25:26 --> Final output sent to browser
DEBUG - 2022-03-15 06:25:26 --> Total execution time: 0.0965
INFO - 2022-03-15 06:25:33 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-15 06:25:33 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 06:25:34 --> Final output sent to browser
DEBUG - 2022-03-15 06:25:34 --> Total execution time: 11.2080
ERROR - 2022-03-15 06:25:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:25:34 --> Config Class Initialized
INFO - 2022-03-15 06:25:34 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:25:34 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:25:34 --> Utf8 Class Initialized
INFO - 2022-03-15 06:25:34 --> URI Class Initialized
INFO - 2022-03-15 06:25:34 --> Router Class Initialized
INFO - 2022-03-15 06:25:34 --> Output Class Initialized
INFO - 2022-03-15 06:25:34 --> Security Class Initialized
DEBUG - 2022-03-15 06:25:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:25:34 --> Input Class Initialized
INFO - 2022-03-15 06:25:34 --> Language Class Initialized
ERROR - 2022-03-15 06:25:34 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-15 06:25:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:25:48 --> Config Class Initialized
INFO - 2022-03-15 06:25:48 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:25:48 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:25:48 --> Utf8 Class Initialized
INFO - 2022-03-15 06:25:48 --> URI Class Initialized
INFO - 2022-03-15 06:25:48 --> Router Class Initialized
INFO - 2022-03-15 06:25:48 --> Output Class Initialized
INFO - 2022-03-15 06:25:48 --> Security Class Initialized
DEBUG - 2022-03-15 06:25:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:25:48 --> Input Class Initialized
INFO - 2022-03-15 06:25:48 --> Language Class Initialized
INFO - 2022-03-15 06:25:48 --> Loader Class Initialized
INFO - 2022-03-15 06:25:48 --> Helper loaded: url_helper
INFO - 2022-03-15 06:25:48 --> Helper loaded: form_helper
INFO - 2022-03-15 06:25:48 --> Helper loaded: common_helper
INFO - 2022-03-15 06:25:48 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:25:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:25:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:25:48 --> Controller Class Initialized
INFO - 2022-03-15 06:25:48 --> Form Validation Class Initialized
DEBUG - 2022-03-15 06:25:48 --> Encrypt Class Initialized
INFO - 2022-03-15 06:25:48 --> Model "Patient_model" initialized
INFO - 2022-03-15 06:25:48 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 06:25:48 --> Model "Referredby_model" initialized
INFO - 2022-03-15 06:25:48 --> Model "Prefix_master" initialized
INFO - 2022-03-15 06:25:48 --> Model "Hospital_model" initialized
ERROR - 2022-03-15 06:25:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:25:48 --> Config Class Initialized
INFO - 2022-03-15 06:25:48 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:25:48 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:25:48 --> Utf8 Class Initialized
INFO - 2022-03-15 06:25:48 --> URI Class Initialized
INFO - 2022-03-15 06:25:48 --> Router Class Initialized
INFO - 2022-03-15 06:25:48 --> Output Class Initialized
INFO - 2022-03-15 06:25:48 --> Security Class Initialized
DEBUG - 2022-03-15 06:25:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:25:48 --> Input Class Initialized
INFO - 2022-03-15 06:25:48 --> Language Class Initialized
INFO - 2022-03-15 06:25:48 --> Loader Class Initialized
INFO - 2022-03-15 06:25:48 --> Helper loaded: url_helper
INFO - 2022-03-15 06:25:48 --> Helper loaded: form_helper
INFO - 2022-03-15 06:25:48 --> Helper loaded: common_helper
INFO - 2022-03-15 06:25:48 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:25:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:25:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:25:48 --> Controller Class Initialized
INFO - 2022-03-15 06:25:48 --> Form Validation Class Initialized
DEBUG - 2022-03-15 06:25:48 --> Encrypt Class Initialized
INFO - 2022-03-15 06:25:48 --> Model "Patient_model" initialized
INFO - 2022-03-15 06:25:48 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 06:25:48 --> Model "Referredby_model" initialized
INFO - 2022-03-15 06:25:48 --> Model "Prefix_master" initialized
INFO - 2022-03-15 06:25:48 --> Model "Hospital_model" initialized
INFO - 2022-03-15 06:25:49 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 06:25:49 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-15 06:25:49 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 06:25:49 --> Final output sent to browser
DEBUG - 2022-03-15 06:25:49 --> Total execution time: 0.0724
ERROR - 2022-03-15 06:25:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:25:50 --> Config Class Initialized
INFO - 2022-03-15 06:25:50 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:25:50 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:25:50 --> Utf8 Class Initialized
INFO - 2022-03-15 06:25:50 --> URI Class Initialized
INFO - 2022-03-15 06:25:50 --> Router Class Initialized
INFO - 2022-03-15 06:25:50 --> Output Class Initialized
INFO - 2022-03-15 06:25:50 --> Security Class Initialized
DEBUG - 2022-03-15 06:25:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:25:50 --> Input Class Initialized
INFO - 2022-03-15 06:25:50 --> Language Class Initialized
INFO - 2022-03-15 06:25:50 --> Loader Class Initialized
INFO - 2022-03-15 06:25:50 --> Helper loaded: url_helper
INFO - 2022-03-15 06:25:50 --> Helper loaded: form_helper
INFO - 2022-03-15 06:25:50 --> Helper loaded: common_helper
INFO - 2022-03-15 06:25:50 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:25:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:25:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:25:50 --> Controller Class Initialized
INFO - 2022-03-15 06:25:50 --> Form Validation Class Initialized
DEBUG - 2022-03-15 06:25:50 --> Encrypt Class Initialized
INFO - 2022-03-15 06:25:50 --> Model "Patient_model" initialized
INFO - 2022-03-15 06:25:50 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 06:25:50 --> Model "Prefix_master" initialized
INFO - 2022-03-15 06:25:50 --> Model "Users_model" initialized
INFO - 2022-03-15 06:25:50 --> Model "Hospital_model" initialized
INFO - 2022-03-15 06:25:50 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 06:25:50 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-15 06:25:50 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 06:25:50 --> Final output sent to browser
DEBUG - 2022-03-15 06:25:50 --> Total execution time: 0.1208
ERROR - 2022-03-15 06:26:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:26:11 --> Config Class Initialized
INFO - 2022-03-15 06:26:11 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:26:11 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:26:11 --> Utf8 Class Initialized
INFO - 2022-03-15 06:26:11 --> URI Class Initialized
INFO - 2022-03-15 06:26:11 --> Router Class Initialized
INFO - 2022-03-15 06:26:11 --> Output Class Initialized
INFO - 2022-03-15 06:26:11 --> Security Class Initialized
DEBUG - 2022-03-15 06:26:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:26:11 --> Input Class Initialized
INFO - 2022-03-15 06:26:11 --> Language Class Initialized
INFO - 2022-03-15 06:26:11 --> Loader Class Initialized
INFO - 2022-03-15 06:26:11 --> Helper loaded: url_helper
INFO - 2022-03-15 06:26:11 --> Helper loaded: form_helper
INFO - 2022-03-15 06:26:11 --> Helper loaded: common_helper
INFO - 2022-03-15 06:26:11 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:26:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:26:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:26:11 --> Controller Class Initialized
INFO - 2022-03-15 06:26:11 --> Form Validation Class Initialized
DEBUG - 2022-03-15 06:26:11 --> Encrypt Class Initialized
INFO - 2022-03-15 06:26:11 --> Model "Patient_model" initialized
INFO - 2022-03-15 06:26:11 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 06:26:11 --> Model "Prefix_master" initialized
INFO - 2022-03-15 06:26:11 --> Model "Users_model" initialized
INFO - 2022-03-15 06:26:11 --> Model "Hospital_model" initialized
INFO - 2022-03-15 06:26:11 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 06:26:11 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-15 06:26:11 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 06:26:11 --> Final output sent to browser
DEBUG - 2022-03-15 06:26:11 --> Total execution time: 0.3990
ERROR - 2022-03-15 06:26:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:26:12 --> Config Class Initialized
INFO - 2022-03-15 06:26:12 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:26:12 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:26:12 --> Utf8 Class Initialized
INFO - 2022-03-15 06:26:12 --> URI Class Initialized
INFO - 2022-03-15 06:26:12 --> Router Class Initialized
INFO - 2022-03-15 06:26:12 --> Output Class Initialized
INFO - 2022-03-15 06:26:12 --> Security Class Initialized
DEBUG - 2022-03-15 06:26:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:26:12 --> Input Class Initialized
INFO - 2022-03-15 06:26:12 --> Language Class Initialized
ERROR - 2022-03-15 06:26:12 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-15 06:26:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:26:32 --> Config Class Initialized
INFO - 2022-03-15 06:26:32 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:26:32 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:26:32 --> Utf8 Class Initialized
INFO - 2022-03-15 06:26:32 --> URI Class Initialized
INFO - 2022-03-15 06:26:32 --> Router Class Initialized
INFO - 2022-03-15 06:26:32 --> Output Class Initialized
INFO - 2022-03-15 06:26:32 --> Security Class Initialized
DEBUG - 2022-03-15 06:26:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:26:32 --> Input Class Initialized
INFO - 2022-03-15 06:26:32 --> Language Class Initialized
INFO - 2022-03-15 06:26:32 --> Loader Class Initialized
INFO - 2022-03-15 06:26:32 --> Helper loaded: url_helper
INFO - 2022-03-15 06:26:32 --> Helper loaded: form_helper
INFO - 2022-03-15 06:26:32 --> Helper loaded: common_helper
INFO - 2022-03-15 06:26:32 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:26:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:26:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:26:32 --> Controller Class Initialized
INFO - 2022-03-15 06:26:32 --> Form Validation Class Initialized
INFO - 2022-03-15 06:26:32 --> Model "Case_model" initialized
INFO - 2022-03-15 06:26:32 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 06:26:33 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 06:26:33 --> File loaded: /home3/karoteam/public_html/application/views/cases/new_case.php
INFO - 2022-03-15 06:26:33 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 06:26:33 --> Final output sent to browser
DEBUG - 2022-03-15 06:26:33 --> Total execution time: 1.0407
ERROR - 2022-03-15 06:26:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:26:34 --> Config Class Initialized
INFO - 2022-03-15 06:26:34 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:26:34 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:26:34 --> Utf8 Class Initialized
INFO - 2022-03-15 06:26:34 --> URI Class Initialized
INFO - 2022-03-15 06:26:34 --> Router Class Initialized
INFO - 2022-03-15 06:26:34 --> Output Class Initialized
INFO - 2022-03-15 06:26:34 --> Security Class Initialized
DEBUG - 2022-03-15 06:26:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:26:34 --> Input Class Initialized
INFO - 2022-03-15 06:26:34 --> Language Class Initialized
ERROR - 2022-03-15 06:26:34 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-15 06:27:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:27:00 --> Config Class Initialized
INFO - 2022-03-15 06:27:00 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:27:00 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:27:00 --> Utf8 Class Initialized
INFO - 2022-03-15 06:27:00 --> URI Class Initialized
INFO - 2022-03-15 06:27:00 --> Router Class Initialized
INFO - 2022-03-15 06:27:00 --> Output Class Initialized
INFO - 2022-03-15 06:27:00 --> Security Class Initialized
DEBUG - 2022-03-15 06:27:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:27:00 --> Input Class Initialized
INFO - 2022-03-15 06:27:00 --> Language Class Initialized
INFO - 2022-03-15 06:27:00 --> Loader Class Initialized
INFO - 2022-03-15 06:27:00 --> Helper loaded: url_helper
INFO - 2022-03-15 06:27:00 --> Helper loaded: form_helper
INFO - 2022-03-15 06:27:00 --> Helper loaded: common_helper
INFO - 2022-03-15 06:27:00 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:27:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:27:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:27:00 --> Controller Class Initialized
INFO - 2022-03-15 06:27:00 --> Form Validation Class Initialized
DEBUG - 2022-03-15 06:27:00 --> Encrypt Class Initialized
INFO - 2022-03-15 06:27:00 --> Model "Patient_model" initialized
INFO - 2022-03-15 06:27:00 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 06:27:00 --> Model "Prefix_master" initialized
INFO - 2022-03-15 06:27:00 --> Model "Users_model" initialized
INFO - 2022-03-15 06:27:00 --> Model "Hospital_model" initialized
ERROR - 2022-03-15 06:27:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:27:01 --> Config Class Initialized
INFO - 2022-03-15 06:27:01 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:27:01 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:27:01 --> Utf8 Class Initialized
INFO - 2022-03-15 06:27:01 --> URI Class Initialized
INFO - 2022-03-15 06:27:01 --> Router Class Initialized
INFO - 2022-03-15 06:27:01 --> Output Class Initialized
INFO - 2022-03-15 06:27:01 --> Security Class Initialized
DEBUG - 2022-03-15 06:27:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:27:01 --> Input Class Initialized
INFO - 2022-03-15 06:27:01 --> Language Class Initialized
INFO - 2022-03-15 06:27:01 --> Loader Class Initialized
INFO - 2022-03-15 06:27:01 --> Helper loaded: url_helper
INFO - 2022-03-15 06:27:01 --> Helper loaded: form_helper
INFO - 2022-03-15 06:27:01 --> Helper loaded: common_helper
INFO - 2022-03-15 06:27:01 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:27:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:27:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:27:01 --> Controller Class Initialized
INFO - 2022-03-15 06:27:01 --> Form Validation Class Initialized
DEBUG - 2022-03-15 06:27:01 --> Encrypt Class Initialized
INFO - 2022-03-15 06:27:01 --> Model "Patient_model" initialized
INFO - 2022-03-15 06:27:01 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 06:27:01 --> Model "Prefix_master" initialized
INFO - 2022-03-15 06:27:01 --> Model "Users_model" initialized
INFO - 2022-03-15 06:27:01 --> Model "Hospital_model" initialized
INFO - 2022-03-15 06:27:01 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 06:27:01 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-15 06:27:01 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 06:27:01 --> Final output sent to browser
DEBUG - 2022-03-15 06:27:01 --> Total execution time: 0.0858
ERROR - 2022-03-15 06:27:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:27:17 --> Config Class Initialized
INFO - 2022-03-15 06:27:17 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:27:17 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:27:17 --> Utf8 Class Initialized
INFO - 2022-03-15 06:27:17 --> URI Class Initialized
INFO - 2022-03-15 06:27:17 --> Router Class Initialized
INFO - 2022-03-15 06:27:17 --> Output Class Initialized
INFO - 2022-03-15 06:27:17 --> Security Class Initialized
DEBUG - 2022-03-15 06:27:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:27:17 --> Input Class Initialized
INFO - 2022-03-15 06:27:17 --> Language Class Initialized
INFO - 2022-03-15 06:27:17 --> Loader Class Initialized
INFO - 2022-03-15 06:27:17 --> Helper loaded: url_helper
INFO - 2022-03-15 06:27:17 --> Helper loaded: form_helper
INFO - 2022-03-15 06:27:17 --> Helper loaded: common_helper
INFO - 2022-03-15 06:27:17 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:27:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:27:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:27:17 --> Controller Class Initialized
INFO - 2022-03-15 06:27:17 --> Form Validation Class Initialized
DEBUG - 2022-03-15 06:27:17 --> Encrypt Class Initialized
INFO - 2022-03-15 06:27:17 --> Model "Patient_model" initialized
INFO - 2022-03-15 06:27:17 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 06:27:17 --> Model "Prefix_master" initialized
INFO - 2022-03-15 06:27:17 --> Model "Users_model" initialized
INFO - 2022-03-15 06:27:17 --> Model "Hospital_model" initialized
ERROR - 2022-03-15 06:27:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:27:18 --> Config Class Initialized
INFO - 2022-03-15 06:27:18 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:27:18 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:27:18 --> Utf8 Class Initialized
INFO - 2022-03-15 06:27:18 --> URI Class Initialized
INFO - 2022-03-15 06:27:18 --> Router Class Initialized
INFO - 2022-03-15 06:27:18 --> Output Class Initialized
INFO - 2022-03-15 06:27:18 --> Security Class Initialized
DEBUG - 2022-03-15 06:27:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:27:18 --> Input Class Initialized
INFO - 2022-03-15 06:27:18 --> Language Class Initialized
INFO - 2022-03-15 06:27:18 --> Loader Class Initialized
INFO - 2022-03-15 06:27:18 --> Helper loaded: url_helper
INFO - 2022-03-15 06:27:18 --> Helper loaded: form_helper
INFO - 2022-03-15 06:27:18 --> Helper loaded: common_helper
INFO - 2022-03-15 06:27:18 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:27:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:27:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:27:18 --> Controller Class Initialized
INFO - 2022-03-15 06:27:18 --> Form Validation Class Initialized
DEBUG - 2022-03-15 06:27:18 --> Encrypt Class Initialized
INFO - 2022-03-15 06:27:18 --> Model "Patient_model" initialized
INFO - 2022-03-15 06:27:18 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 06:27:18 --> Model "Prefix_master" initialized
INFO - 2022-03-15 06:27:18 --> Model "Users_model" initialized
INFO - 2022-03-15 06:27:18 --> Model "Hospital_model" initialized
INFO - 2022-03-15 06:27:18 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 06:27:18 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-15 06:27:18 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 06:27:18 --> Final output sent to browser
DEBUG - 2022-03-15 06:27:18 --> Total execution time: 0.1027
ERROR - 2022-03-15 06:27:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:27:19 --> Config Class Initialized
INFO - 2022-03-15 06:27:19 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:27:19 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:27:19 --> Utf8 Class Initialized
INFO - 2022-03-15 06:27:19 --> URI Class Initialized
INFO - 2022-03-15 06:27:19 --> Router Class Initialized
INFO - 2022-03-15 06:27:19 --> Output Class Initialized
INFO - 2022-03-15 06:27:19 --> Security Class Initialized
DEBUG - 2022-03-15 06:27:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:27:19 --> Input Class Initialized
INFO - 2022-03-15 06:27:19 --> Language Class Initialized
INFO - 2022-03-15 06:27:19 --> Loader Class Initialized
INFO - 2022-03-15 06:27:19 --> Helper loaded: url_helper
INFO - 2022-03-15 06:27:19 --> Helper loaded: form_helper
INFO - 2022-03-15 06:27:19 --> Helper loaded: common_helper
INFO - 2022-03-15 06:27:19 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:27:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:27:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:27:19 --> Controller Class Initialized
INFO - 2022-03-15 06:27:19 --> Form Validation Class Initialized
DEBUG - 2022-03-15 06:27:19 --> Encrypt Class Initialized
INFO - 2022-03-15 06:27:19 --> Model "Patient_model" initialized
INFO - 2022-03-15 06:27:19 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 06:27:19 --> Model "Prefix_master" initialized
INFO - 2022-03-15 06:27:19 --> Model "Users_model" initialized
INFO - 2022-03-15 06:27:19 --> Model "Hospital_model" initialized
ERROR - 2022-03-15 06:27:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:27:20 --> Config Class Initialized
INFO - 2022-03-15 06:27:20 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:27:20 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:27:20 --> Utf8 Class Initialized
INFO - 2022-03-15 06:27:20 --> URI Class Initialized
INFO - 2022-03-15 06:27:20 --> Router Class Initialized
INFO - 2022-03-15 06:27:20 --> Output Class Initialized
INFO - 2022-03-15 06:27:20 --> Security Class Initialized
DEBUG - 2022-03-15 06:27:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:27:20 --> Input Class Initialized
INFO - 2022-03-15 06:27:20 --> Language Class Initialized
INFO - 2022-03-15 06:27:20 --> Loader Class Initialized
INFO - 2022-03-15 06:27:20 --> Helper loaded: url_helper
INFO - 2022-03-15 06:27:20 --> Helper loaded: form_helper
INFO - 2022-03-15 06:27:20 --> Helper loaded: common_helper
INFO - 2022-03-15 06:27:20 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:27:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:27:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:27:20 --> Controller Class Initialized
INFO - 2022-03-15 06:27:20 --> Form Validation Class Initialized
DEBUG - 2022-03-15 06:27:20 --> Encrypt Class Initialized
INFO - 2022-03-15 06:27:20 --> Model "Patient_model" initialized
INFO - 2022-03-15 06:27:20 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 06:27:20 --> Model "Prefix_master" initialized
INFO - 2022-03-15 06:27:20 --> Model "Users_model" initialized
INFO - 2022-03-15 06:27:20 --> Model "Hospital_model" initialized
INFO - 2022-03-15 06:27:20 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 06:27:20 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-15 06:27:20 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 06:27:20 --> Final output sent to browser
DEBUG - 2022-03-15 06:27:20 --> Total execution time: 0.1350
ERROR - 2022-03-15 06:28:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:28:35 --> Config Class Initialized
INFO - 2022-03-15 06:28:35 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:28:35 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:28:35 --> Utf8 Class Initialized
INFO - 2022-03-15 06:28:35 --> URI Class Initialized
INFO - 2022-03-15 06:28:35 --> Router Class Initialized
INFO - 2022-03-15 06:28:35 --> Output Class Initialized
INFO - 2022-03-15 06:28:35 --> Security Class Initialized
DEBUG - 2022-03-15 06:28:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:28:35 --> Input Class Initialized
INFO - 2022-03-15 06:28:35 --> Language Class Initialized
ERROR - 2022-03-15 06:28:35 --> 404 Page Not Found: Karoclient/css
ERROR - 2022-03-15 06:28:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:28:54 --> Config Class Initialized
INFO - 2022-03-15 06:28:54 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:28:54 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:28:54 --> Utf8 Class Initialized
INFO - 2022-03-15 06:28:54 --> URI Class Initialized
INFO - 2022-03-15 06:28:54 --> Router Class Initialized
INFO - 2022-03-15 06:28:54 --> Output Class Initialized
INFO - 2022-03-15 06:28:54 --> Security Class Initialized
DEBUG - 2022-03-15 06:28:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:28:54 --> Input Class Initialized
INFO - 2022-03-15 06:28:54 --> Language Class Initialized
INFO - 2022-03-15 06:28:54 --> Loader Class Initialized
INFO - 2022-03-15 06:28:54 --> Helper loaded: url_helper
INFO - 2022-03-15 06:28:54 --> Helper loaded: form_helper
INFO - 2022-03-15 06:28:54 --> Helper loaded: common_helper
INFO - 2022-03-15 06:28:54 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:28:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:28:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:28:54 --> Controller Class Initialized
INFO - 2022-03-15 06:28:54 --> Form Validation Class Initialized
DEBUG - 2022-03-15 06:28:54 --> Encrypt Class Initialized
INFO - 2022-03-15 06:28:54 --> Model "Patient_model" initialized
INFO - 2022-03-15 06:28:54 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 06:28:54 --> Model "Prefix_master" initialized
INFO - 2022-03-15 06:28:54 --> Model "Users_model" initialized
INFO - 2022-03-15 06:28:54 --> Model "Hospital_model" initialized
ERROR - 2022-03-15 06:28:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:28:55 --> Config Class Initialized
INFO - 2022-03-15 06:28:55 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:28:55 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:28:55 --> Utf8 Class Initialized
INFO - 2022-03-15 06:28:55 --> URI Class Initialized
INFO - 2022-03-15 06:28:55 --> Router Class Initialized
INFO - 2022-03-15 06:28:55 --> Output Class Initialized
INFO - 2022-03-15 06:28:55 --> Security Class Initialized
DEBUG - 2022-03-15 06:28:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:28:55 --> Input Class Initialized
INFO - 2022-03-15 06:28:55 --> Language Class Initialized
INFO - 2022-03-15 06:28:55 --> Loader Class Initialized
INFO - 2022-03-15 06:28:55 --> Helper loaded: url_helper
INFO - 2022-03-15 06:28:55 --> Helper loaded: form_helper
INFO - 2022-03-15 06:28:55 --> Helper loaded: common_helper
INFO - 2022-03-15 06:28:55 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:28:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:28:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:28:55 --> Controller Class Initialized
INFO - 2022-03-15 06:28:55 --> Form Validation Class Initialized
DEBUG - 2022-03-15 06:28:55 --> Encrypt Class Initialized
INFO - 2022-03-15 06:28:55 --> Model "Patient_model" initialized
INFO - 2022-03-15 06:28:55 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 06:28:55 --> Model "Prefix_master" initialized
INFO - 2022-03-15 06:28:55 --> Model "Users_model" initialized
INFO - 2022-03-15 06:28:55 --> Model "Hospital_model" initialized
INFO - 2022-03-15 06:28:55 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 06:28:55 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-15 06:28:55 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 06:28:55 --> Final output sent to browser
DEBUG - 2022-03-15 06:28:55 --> Total execution time: 0.0580
ERROR - 2022-03-15 06:29:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:29:08 --> Config Class Initialized
INFO - 2022-03-15 06:29:08 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:29:08 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:29:08 --> Utf8 Class Initialized
INFO - 2022-03-15 06:29:08 --> URI Class Initialized
INFO - 2022-03-15 06:29:08 --> Router Class Initialized
INFO - 2022-03-15 06:29:08 --> Output Class Initialized
INFO - 2022-03-15 06:29:08 --> Security Class Initialized
DEBUG - 2022-03-15 06:29:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:29:08 --> Input Class Initialized
INFO - 2022-03-15 06:29:08 --> Language Class Initialized
INFO - 2022-03-15 06:29:08 --> Loader Class Initialized
INFO - 2022-03-15 06:29:08 --> Helper loaded: url_helper
INFO - 2022-03-15 06:29:08 --> Helper loaded: form_helper
INFO - 2022-03-15 06:29:08 --> Helper loaded: common_helper
INFO - 2022-03-15 06:29:08 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:29:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:29:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:29:08 --> Controller Class Initialized
INFO - 2022-03-15 06:29:08 --> Form Validation Class Initialized
DEBUG - 2022-03-15 06:29:08 --> Encrypt Class Initialized
INFO - 2022-03-15 06:29:08 --> Model "Patient_model" initialized
INFO - 2022-03-15 06:29:08 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 06:29:08 --> Model "Prefix_master" initialized
INFO - 2022-03-15 06:29:08 --> Model "Users_model" initialized
INFO - 2022-03-15 06:29:08 --> Model "Hospital_model" initialized
ERROR - 2022-03-15 06:29:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:29:08 --> Config Class Initialized
INFO - 2022-03-15 06:29:08 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:29:08 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:29:08 --> Utf8 Class Initialized
INFO - 2022-03-15 06:29:08 --> URI Class Initialized
INFO - 2022-03-15 06:29:08 --> Router Class Initialized
INFO - 2022-03-15 06:29:08 --> Output Class Initialized
INFO - 2022-03-15 06:29:08 --> Security Class Initialized
DEBUG - 2022-03-15 06:29:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:29:08 --> Input Class Initialized
INFO - 2022-03-15 06:29:08 --> Language Class Initialized
INFO - 2022-03-15 06:29:08 --> Loader Class Initialized
INFO - 2022-03-15 06:29:08 --> Helper loaded: url_helper
INFO - 2022-03-15 06:29:08 --> Helper loaded: form_helper
INFO - 2022-03-15 06:29:08 --> Helper loaded: common_helper
INFO - 2022-03-15 06:29:08 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:29:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:29:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:29:08 --> Controller Class Initialized
INFO - 2022-03-15 06:29:08 --> Form Validation Class Initialized
DEBUG - 2022-03-15 06:29:08 --> Encrypt Class Initialized
INFO - 2022-03-15 06:29:08 --> Model "Patient_model" initialized
INFO - 2022-03-15 06:29:08 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 06:29:08 --> Model "Prefix_master" initialized
INFO - 2022-03-15 06:29:08 --> Model "Users_model" initialized
INFO - 2022-03-15 06:29:08 --> Model "Hospital_model" initialized
INFO - 2022-03-15 06:29:08 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 06:29:08 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-15 06:29:08 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 06:29:08 --> Final output sent to browser
DEBUG - 2022-03-15 06:29:08 --> Total execution time: 0.0710
ERROR - 2022-03-15 06:29:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:29:12 --> Config Class Initialized
INFO - 2022-03-15 06:29:12 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:29:12 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:29:12 --> Utf8 Class Initialized
INFO - 2022-03-15 06:29:12 --> URI Class Initialized
INFO - 2022-03-15 06:29:12 --> Router Class Initialized
INFO - 2022-03-15 06:29:12 --> Output Class Initialized
INFO - 2022-03-15 06:29:12 --> Security Class Initialized
DEBUG - 2022-03-15 06:29:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:29:12 --> Input Class Initialized
INFO - 2022-03-15 06:29:12 --> Language Class Initialized
INFO - 2022-03-15 06:29:12 --> Loader Class Initialized
INFO - 2022-03-15 06:29:12 --> Helper loaded: url_helper
INFO - 2022-03-15 06:29:12 --> Helper loaded: form_helper
INFO - 2022-03-15 06:29:12 --> Helper loaded: common_helper
INFO - 2022-03-15 06:29:12 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:29:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:29:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:29:12 --> Controller Class Initialized
INFO - 2022-03-15 06:29:12 --> Form Validation Class Initialized
DEBUG - 2022-03-15 06:29:12 --> Encrypt Class Initialized
INFO - 2022-03-15 06:29:12 --> Model "Patient_model" initialized
INFO - 2022-03-15 06:29:12 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 06:29:12 --> Model "Prefix_master" initialized
INFO - 2022-03-15 06:29:12 --> Model "Users_model" initialized
INFO - 2022-03-15 06:29:12 --> Model "Hospital_model" initialized
ERROR - 2022-03-15 06:29:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:29:12 --> Config Class Initialized
INFO - 2022-03-15 06:29:12 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:29:12 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:29:12 --> Utf8 Class Initialized
INFO - 2022-03-15 06:29:12 --> URI Class Initialized
INFO - 2022-03-15 06:29:12 --> Router Class Initialized
INFO - 2022-03-15 06:29:12 --> Output Class Initialized
INFO - 2022-03-15 06:29:12 --> Security Class Initialized
DEBUG - 2022-03-15 06:29:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:29:12 --> Input Class Initialized
INFO - 2022-03-15 06:29:12 --> Language Class Initialized
INFO - 2022-03-15 06:29:12 --> Loader Class Initialized
INFO - 2022-03-15 06:29:12 --> Helper loaded: url_helper
INFO - 2022-03-15 06:29:12 --> Helper loaded: form_helper
INFO - 2022-03-15 06:29:12 --> Helper loaded: common_helper
INFO - 2022-03-15 06:29:12 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:29:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:29:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:29:12 --> Controller Class Initialized
INFO - 2022-03-15 06:29:12 --> Form Validation Class Initialized
DEBUG - 2022-03-15 06:29:12 --> Encrypt Class Initialized
INFO - 2022-03-15 06:29:12 --> Model "Patient_model" initialized
INFO - 2022-03-15 06:29:12 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 06:29:12 --> Model "Prefix_master" initialized
INFO - 2022-03-15 06:29:12 --> Model "Users_model" initialized
INFO - 2022-03-15 06:29:12 --> Model "Hospital_model" initialized
INFO - 2022-03-15 06:29:12 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 06:29:12 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-15 06:29:12 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 06:29:12 --> Final output sent to browser
DEBUG - 2022-03-15 06:29:12 --> Total execution time: 0.0922
ERROR - 2022-03-15 06:29:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:29:18 --> Config Class Initialized
INFO - 2022-03-15 06:29:18 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:29:18 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:29:18 --> Utf8 Class Initialized
INFO - 2022-03-15 06:29:18 --> URI Class Initialized
INFO - 2022-03-15 06:29:18 --> Router Class Initialized
INFO - 2022-03-15 06:29:18 --> Output Class Initialized
INFO - 2022-03-15 06:29:18 --> Security Class Initialized
DEBUG - 2022-03-15 06:29:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:29:18 --> Input Class Initialized
INFO - 2022-03-15 06:29:18 --> Language Class Initialized
INFO - 2022-03-15 06:29:18 --> Loader Class Initialized
INFO - 2022-03-15 06:29:18 --> Helper loaded: url_helper
INFO - 2022-03-15 06:29:18 --> Helper loaded: form_helper
INFO - 2022-03-15 06:29:18 --> Helper loaded: common_helper
INFO - 2022-03-15 06:29:18 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:29:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:29:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:29:18 --> Controller Class Initialized
INFO - 2022-03-15 06:29:18 --> Form Validation Class Initialized
DEBUG - 2022-03-15 06:29:18 --> Encrypt Class Initialized
INFO - 2022-03-15 06:29:18 --> Model "Patient_model" initialized
INFO - 2022-03-15 06:29:18 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 06:29:18 --> Model "Prefix_master" initialized
INFO - 2022-03-15 06:29:18 --> Model "Users_model" initialized
INFO - 2022-03-15 06:29:18 --> Model "Hospital_model" initialized
INFO - 2022-03-15 06:29:18 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 06:29:18 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-15 06:29:18 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 06:29:18 --> Final output sent to browser
DEBUG - 2022-03-15 06:29:18 --> Total execution time: 0.0528
ERROR - 2022-03-15 06:29:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:29:19 --> Config Class Initialized
INFO - 2022-03-15 06:29:19 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:29:19 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:29:19 --> Utf8 Class Initialized
INFO - 2022-03-15 06:29:19 --> URI Class Initialized
INFO - 2022-03-15 06:29:19 --> Router Class Initialized
INFO - 2022-03-15 06:29:19 --> Output Class Initialized
INFO - 2022-03-15 06:29:19 --> Security Class Initialized
DEBUG - 2022-03-15 06:29:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:29:19 --> Input Class Initialized
INFO - 2022-03-15 06:29:19 --> Language Class Initialized
INFO - 2022-03-15 06:29:19 --> Loader Class Initialized
INFO - 2022-03-15 06:29:19 --> Helper loaded: url_helper
INFO - 2022-03-15 06:29:19 --> Helper loaded: form_helper
INFO - 2022-03-15 06:29:19 --> Helper loaded: common_helper
INFO - 2022-03-15 06:29:19 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:29:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:29:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:29:19 --> Controller Class Initialized
INFO - 2022-03-15 06:29:19 --> Form Validation Class Initialized
DEBUG - 2022-03-15 06:29:19 --> Encrypt Class Initialized
INFO - 2022-03-15 06:29:19 --> Model "Patient_model" initialized
INFO - 2022-03-15 06:29:19 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 06:29:19 --> Model "Referredby_model" initialized
INFO - 2022-03-15 06:29:19 --> Model "Prefix_master" initialized
INFO - 2022-03-15 06:29:19 --> Model "Hospital_model" initialized
INFO - 2022-03-15 06:29:19 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 06:29:19 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-15 06:29:19 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 06:29:19 --> Final output sent to browser
DEBUG - 2022-03-15 06:29:19 --> Total execution time: 0.0800
ERROR - 2022-03-15 06:29:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:29:19 --> Config Class Initialized
INFO - 2022-03-15 06:29:19 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:29:19 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:29:19 --> Utf8 Class Initialized
INFO - 2022-03-15 06:29:19 --> URI Class Initialized
INFO - 2022-03-15 06:29:19 --> Router Class Initialized
INFO - 2022-03-15 06:29:19 --> Output Class Initialized
INFO - 2022-03-15 06:29:19 --> Security Class Initialized
DEBUG - 2022-03-15 06:29:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:29:19 --> Input Class Initialized
INFO - 2022-03-15 06:29:19 --> Language Class Initialized
ERROR - 2022-03-15 06:29:19 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-15 06:29:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:29:20 --> Config Class Initialized
INFO - 2022-03-15 06:29:20 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:29:20 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:29:20 --> Utf8 Class Initialized
INFO - 2022-03-15 06:29:20 --> URI Class Initialized
INFO - 2022-03-15 06:29:20 --> Router Class Initialized
INFO - 2022-03-15 06:29:20 --> Output Class Initialized
INFO - 2022-03-15 06:29:20 --> Security Class Initialized
DEBUG - 2022-03-15 06:29:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:29:20 --> Input Class Initialized
INFO - 2022-03-15 06:29:20 --> Language Class Initialized
INFO - 2022-03-15 06:29:20 --> Loader Class Initialized
INFO - 2022-03-15 06:29:20 --> Helper loaded: url_helper
INFO - 2022-03-15 06:29:20 --> Helper loaded: form_helper
INFO - 2022-03-15 06:29:20 --> Helper loaded: common_helper
INFO - 2022-03-15 06:29:20 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:29:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:29:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:29:20 --> Controller Class Initialized
INFO - 2022-03-15 06:29:20 --> Form Validation Class Initialized
DEBUG - 2022-03-15 06:29:20 --> Encrypt Class Initialized
INFO - 2022-03-15 06:29:20 --> Model "Patient_model" initialized
INFO - 2022-03-15 06:29:20 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 06:29:20 --> Model "Referredby_model" initialized
INFO - 2022-03-15 06:29:20 --> Model "Prefix_master" initialized
INFO - 2022-03-15 06:29:20 --> Model "Hospital_model" initialized
INFO - 2022-03-15 06:29:20 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 06:29:20 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-15 06:29:20 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 06:29:20 --> Final output sent to browser
DEBUG - 2022-03-15 06:29:20 --> Total execution time: 0.0532
ERROR - 2022-03-15 06:29:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:29:28 --> Config Class Initialized
INFO - 2022-03-15 06:29:28 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:29:28 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:29:28 --> Utf8 Class Initialized
INFO - 2022-03-15 06:29:28 --> URI Class Initialized
INFO - 2022-03-15 06:29:28 --> Router Class Initialized
INFO - 2022-03-15 06:29:28 --> Output Class Initialized
INFO - 2022-03-15 06:29:28 --> Security Class Initialized
DEBUG - 2022-03-15 06:29:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:29:28 --> Input Class Initialized
INFO - 2022-03-15 06:29:28 --> Language Class Initialized
INFO - 2022-03-15 06:29:28 --> Loader Class Initialized
INFO - 2022-03-15 06:29:28 --> Helper loaded: url_helper
INFO - 2022-03-15 06:29:28 --> Helper loaded: form_helper
INFO - 2022-03-15 06:29:28 --> Helper loaded: common_helper
INFO - 2022-03-15 06:29:28 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:29:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:29:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:29:28 --> Controller Class Initialized
INFO - 2022-03-15 06:29:28 --> Form Validation Class Initialized
DEBUG - 2022-03-15 06:29:28 --> Encrypt Class Initialized
INFO - 2022-03-15 06:29:28 --> Model "Patient_model" initialized
INFO - 2022-03-15 06:29:28 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 06:29:28 --> Model "Prefix_master" initialized
INFO - 2022-03-15 06:29:28 --> Model "Users_model" initialized
INFO - 2022-03-15 06:29:28 --> Model "Hospital_model" initialized
ERROR - 2022-03-15 06:29:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:29:29 --> Config Class Initialized
INFO - 2022-03-15 06:29:29 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:29:29 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:29:29 --> Utf8 Class Initialized
INFO - 2022-03-15 06:29:29 --> URI Class Initialized
INFO - 2022-03-15 06:29:29 --> Router Class Initialized
INFO - 2022-03-15 06:29:29 --> Output Class Initialized
INFO - 2022-03-15 06:29:29 --> Security Class Initialized
DEBUG - 2022-03-15 06:29:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:29:29 --> Input Class Initialized
INFO - 2022-03-15 06:29:29 --> Language Class Initialized
INFO - 2022-03-15 06:29:29 --> Loader Class Initialized
INFO - 2022-03-15 06:29:29 --> Helper loaded: url_helper
INFO - 2022-03-15 06:29:29 --> Helper loaded: form_helper
INFO - 2022-03-15 06:29:29 --> Helper loaded: common_helper
INFO - 2022-03-15 06:29:29 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:29:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:29:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:29:29 --> Controller Class Initialized
INFO - 2022-03-15 06:29:29 --> Form Validation Class Initialized
DEBUG - 2022-03-15 06:29:29 --> Encrypt Class Initialized
INFO - 2022-03-15 06:29:29 --> Model "Patient_model" initialized
INFO - 2022-03-15 06:29:29 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 06:29:29 --> Model "Prefix_master" initialized
INFO - 2022-03-15 06:29:29 --> Model "Users_model" initialized
INFO - 2022-03-15 06:29:29 --> Model "Hospital_model" initialized
INFO - 2022-03-15 06:29:29 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 06:29:29 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-15 06:29:29 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 06:29:29 --> Final output sent to browser
DEBUG - 2022-03-15 06:29:29 --> Total execution time: 0.0797
ERROR - 2022-03-15 06:29:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:29:30 --> Config Class Initialized
INFO - 2022-03-15 06:29:30 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:29:30 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:29:30 --> Utf8 Class Initialized
INFO - 2022-03-15 06:29:30 --> URI Class Initialized
INFO - 2022-03-15 06:29:30 --> Router Class Initialized
INFO - 2022-03-15 06:29:30 --> Output Class Initialized
INFO - 2022-03-15 06:29:30 --> Security Class Initialized
DEBUG - 2022-03-15 06:29:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:29:30 --> Input Class Initialized
INFO - 2022-03-15 06:29:30 --> Language Class Initialized
ERROR - 2022-03-15 06:29:30 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-15 06:29:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:29:40 --> Config Class Initialized
INFO - 2022-03-15 06:29:40 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:29:40 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:29:40 --> Utf8 Class Initialized
INFO - 2022-03-15 06:29:40 --> URI Class Initialized
INFO - 2022-03-15 06:29:40 --> Router Class Initialized
INFO - 2022-03-15 06:29:40 --> Output Class Initialized
INFO - 2022-03-15 06:29:40 --> Security Class Initialized
DEBUG - 2022-03-15 06:29:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:29:40 --> Input Class Initialized
INFO - 2022-03-15 06:29:40 --> Language Class Initialized
INFO - 2022-03-15 06:29:40 --> Loader Class Initialized
INFO - 2022-03-15 06:29:40 --> Helper loaded: url_helper
INFO - 2022-03-15 06:29:40 --> Helper loaded: form_helper
INFO - 2022-03-15 06:29:40 --> Helper loaded: common_helper
INFO - 2022-03-15 06:29:40 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:29:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:29:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:29:40 --> Controller Class Initialized
INFO - 2022-03-15 06:29:40 --> Form Validation Class Initialized
DEBUG - 2022-03-15 06:29:40 --> Encrypt Class Initialized
INFO - 2022-03-15 06:29:40 --> Model "Patient_model" initialized
INFO - 2022-03-15 06:29:40 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 06:29:40 --> Model "Prefix_master" initialized
INFO - 2022-03-15 06:29:40 --> Model "Users_model" initialized
INFO - 2022-03-15 06:29:40 --> Model "Hospital_model" initialized
ERROR - 2022-03-15 06:29:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:29:41 --> Config Class Initialized
INFO - 2022-03-15 06:29:41 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:29:41 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:29:41 --> Utf8 Class Initialized
INFO - 2022-03-15 06:29:41 --> URI Class Initialized
INFO - 2022-03-15 06:29:41 --> Router Class Initialized
INFO - 2022-03-15 06:29:41 --> Output Class Initialized
INFO - 2022-03-15 06:29:41 --> Security Class Initialized
DEBUG - 2022-03-15 06:29:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:29:41 --> Input Class Initialized
INFO - 2022-03-15 06:29:41 --> Language Class Initialized
INFO - 2022-03-15 06:29:41 --> Loader Class Initialized
INFO - 2022-03-15 06:29:41 --> Helper loaded: url_helper
INFO - 2022-03-15 06:29:41 --> Helper loaded: form_helper
INFO - 2022-03-15 06:29:41 --> Helper loaded: common_helper
INFO - 2022-03-15 06:29:41 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:29:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:29:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:29:41 --> Controller Class Initialized
INFO - 2022-03-15 06:29:41 --> Form Validation Class Initialized
DEBUG - 2022-03-15 06:29:41 --> Encrypt Class Initialized
INFO - 2022-03-15 06:29:41 --> Model "Patient_model" initialized
INFO - 2022-03-15 06:29:41 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 06:29:41 --> Model "Prefix_master" initialized
INFO - 2022-03-15 06:29:41 --> Model "Users_model" initialized
INFO - 2022-03-15 06:29:41 --> Model "Hospital_model" initialized
INFO - 2022-03-15 06:29:41 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 06:29:41 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-15 06:29:41 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 06:29:41 --> Final output sent to browser
DEBUG - 2022-03-15 06:29:41 --> Total execution time: 0.0779
ERROR - 2022-03-15 06:29:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:29:42 --> Config Class Initialized
INFO - 2022-03-15 06:29:42 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:29:42 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:29:42 --> Utf8 Class Initialized
INFO - 2022-03-15 06:29:42 --> URI Class Initialized
INFO - 2022-03-15 06:29:42 --> Router Class Initialized
INFO - 2022-03-15 06:29:42 --> Output Class Initialized
INFO - 2022-03-15 06:29:42 --> Security Class Initialized
DEBUG - 2022-03-15 06:29:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:29:42 --> Input Class Initialized
INFO - 2022-03-15 06:29:42 --> Language Class Initialized
ERROR - 2022-03-15 06:29:42 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-15 06:33:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:33:14 --> Config Class Initialized
INFO - 2022-03-15 06:33:14 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:33:14 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:33:14 --> Utf8 Class Initialized
INFO - 2022-03-15 06:33:14 --> URI Class Initialized
INFO - 2022-03-15 06:33:14 --> Router Class Initialized
INFO - 2022-03-15 06:33:14 --> Output Class Initialized
INFO - 2022-03-15 06:33:14 --> Security Class Initialized
DEBUG - 2022-03-15 06:33:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:33:14 --> Input Class Initialized
INFO - 2022-03-15 06:33:14 --> Language Class Initialized
INFO - 2022-03-15 06:33:14 --> Loader Class Initialized
INFO - 2022-03-15 06:33:14 --> Helper loaded: url_helper
INFO - 2022-03-15 06:33:14 --> Helper loaded: form_helper
INFO - 2022-03-15 06:33:14 --> Helper loaded: common_helper
INFO - 2022-03-15 06:33:14 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:33:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:33:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:33:14 --> Controller Class Initialized
INFO - 2022-03-15 06:33:14 --> Form Validation Class Initialized
DEBUG - 2022-03-15 06:33:14 --> Encrypt Class Initialized
INFO - 2022-03-15 06:33:14 --> Model "Patient_model" initialized
INFO - 2022-03-15 06:33:14 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 06:33:14 --> Model "Prefix_master" initialized
INFO - 2022-03-15 06:33:14 --> Model "Users_model" initialized
INFO - 2022-03-15 06:33:14 --> Model "Hospital_model" initialized
INFO - 2022-03-15 06:33:14 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-15 06:33:15 --> Final output sent to browser
DEBUG - 2022-03-15 06:33:15 --> Total execution time: 1.0685
ERROR - 2022-03-15 06:33:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:33:44 --> Config Class Initialized
INFO - 2022-03-15 06:33:44 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:33:44 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:33:44 --> Utf8 Class Initialized
INFO - 2022-03-15 06:33:44 --> URI Class Initialized
INFO - 2022-03-15 06:33:44 --> Router Class Initialized
INFO - 2022-03-15 06:33:44 --> Output Class Initialized
INFO - 2022-03-15 06:33:44 --> Security Class Initialized
DEBUG - 2022-03-15 06:33:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:33:44 --> Input Class Initialized
INFO - 2022-03-15 06:33:44 --> Language Class Initialized
INFO - 2022-03-15 06:33:44 --> Loader Class Initialized
INFO - 2022-03-15 06:33:44 --> Helper loaded: url_helper
INFO - 2022-03-15 06:33:44 --> Helper loaded: form_helper
INFO - 2022-03-15 06:33:44 --> Helper loaded: common_helper
INFO - 2022-03-15 06:33:44 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:33:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:33:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:33:44 --> Controller Class Initialized
INFO - 2022-03-15 06:33:44 --> Form Validation Class Initialized
DEBUG - 2022-03-15 06:33:44 --> Encrypt Class Initialized
INFO - 2022-03-15 06:33:44 --> Model "Referredby_model" initialized
INFO - 2022-03-15 06:33:44 --> Model "Donner_model" initialized
INFO - 2022-03-15 06:33:44 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 06:33:44 --> File loaded: /home3/karoteam/public_html/application/views/donner/index.php
INFO - 2022-03-15 06:33:44 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 06:33:44 --> Final output sent to browser
DEBUG - 2022-03-15 06:33:44 --> Total execution time: 0.1802
ERROR - 2022-03-15 06:33:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:33:45 --> Config Class Initialized
INFO - 2022-03-15 06:33:45 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:33:45 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:33:45 --> Utf8 Class Initialized
INFO - 2022-03-15 06:33:45 --> URI Class Initialized
INFO - 2022-03-15 06:33:45 --> Router Class Initialized
INFO - 2022-03-15 06:33:45 --> Output Class Initialized
INFO - 2022-03-15 06:33:45 --> Security Class Initialized
DEBUG - 2022-03-15 06:33:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:33:45 --> Input Class Initialized
INFO - 2022-03-15 06:33:45 --> Language Class Initialized
ERROR - 2022-03-15 06:33:45 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-15 06:34:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:34:09 --> Config Class Initialized
INFO - 2022-03-15 06:34:09 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:34:09 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:34:09 --> Utf8 Class Initialized
INFO - 2022-03-15 06:34:09 --> URI Class Initialized
INFO - 2022-03-15 06:34:09 --> Router Class Initialized
INFO - 2022-03-15 06:34:09 --> Output Class Initialized
INFO - 2022-03-15 06:34:09 --> Security Class Initialized
DEBUG - 2022-03-15 06:34:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:34:09 --> Input Class Initialized
INFO - 2022-03-15 06:34:09 --> Language Class Initialized
INFO - 2022-03-15 06:34:09 --> Loader Class Initialized
INFO - 2022-03-15 06:34:09 --> Helper loaded: url_helper
INFO - 2022-03-15 06:34:09 --> Helper loaded: form_helper
INFO - 2022-03-15 06:34:09 --> Helper loaded: common_helper
INFO - 2022-03-15 06:34:09 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:34:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:34:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:34:09 --> Controller Class Initialized
INFO - 2022-03-15 06:34:09 --> Form Validation Class Initialized
DEBUG - 2022-03-15 06:34:09 --> Encrypt Class Initialized
INFO - 2022-03-15 06:34:09 --> Model "Referredby_model" initialized
INFO - 2022-03-15 06:34:09 --> Model "Donner_model" initialized
INFO - 2022-03-15 06:34:09 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 06:34:09 --> File loaded: /home3/karoteam/public_html/application/views/donner/index.php
INFO - 2022-03-15 06:34:09 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 06:34:09 --> Final output sent to browser
DEBUG - 2022-03-15 06:34:09 --> Total execution time: 0.0307
ERROR - 2022-03-15 06:34:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:34:10 --> Config Class Initialized
INFO - 2022-03-15 06:34:10 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:34:10 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:34:10 --> Utf8 Class Initialized
INFO - 2022-03-15 06:34:10 --> URI Class Initialized
INFO - 2022-03-15 06:34:10 --> Router Class Initialized
INFO - 2022-03-15 06:34:10 --> Output Class Initialized
INFO - 2022-03-15 06:34:10 --> Security Class Initialized
DEBUG - 2022-03-15 06:34:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:34:10 --> Input Class Initialized
INFO - 2022-03-15 06:34:10 --> Language Class Initialized
ERROR - 2022-03-15 06:34:10 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-15 06:34:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:34:32 --> Config Class Initialized
INFO - 2022-03-15 06:34:32 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:34:32 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:34:32 --> Utf8 Class Initialized
INFO - 2022-03-15 06:34:32 --> URI Class Initialized
INFO - 2022-03-15 06:34:32 --> Router Class Initialized
INFO - 2022-03-15 06:34:32 --> Output Class Initialized
INFO - 2022-03-15 06:34:32 --> Security Class Initialized
DEBUG - 2022-03-15 06:34:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:34:32 --> Input Class Initialized
INFO - 2022-03-15 06:34:32 --> Language Class Initialized
INFO - 2022-03-15 06:34:32 --> Loader Class Initialized
INFO - 2022-03-15 06:34:32 --> Helper loaded: url_helper
INFO - 2022-03-15 06:34:32 --> Helper loaded: form_helper
INFO - 2022-03-15 06:34:32 --> Helper loaded: common_helper
INFO - 2022-03-15 06:34:32 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:34:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:34:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:34:32 --> Controller Class Initialized
INFO - 2022-03-15 06:34:32 --> Form Validation Class Initialized
DEBUG - 2022-03-15 06:34:32 --> Encrypt Class Initialized
INFO - 2022-03-15 06:34:32 --> Model "Login_model" initialized
INFO - 2022-03-15 06:34:32 --> Model "Dashboard_model" initialized
INFO - 2022-03-15 06:34:32 --> Model "Case_model" initialized
ERROR - 2022-03-15 06:34:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:34:39 --> Config Class Initialized
INFO - 2022-03-15 06:34:39 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:34:39 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:34:39 --> Utf8 Class Initialized
INFO - 2022-03-15 06:34:39 --> URI Class Initialized
INFO - 2022-03-15 06:34:39 --> Router Class Initialized
INFO - 2022-03-15 06:34:39 --> Output Class Initialized
INFO - 2022-03-15 06:34:39 --> Security Class Initialized
DEBUG - 2022-03-15 06:34:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:34:39 --> Input Class Initialized
INFO - 2022-03-15 06:34:39 --> Language Class Initialized
INFO - 2022-03-15 06:34:39 --> Loader Class Initialized
INFO - 2022-03-15 06:34:39 --> Helper loaded: url_helper
INFO - 2022-03-15 06:34:39 --> Helper loaded: form_helper
INFO - 2022-03-15 06:34:39 --> Helper loaded: common_helper
INFO - 2022-03-15 06:34:39 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:34:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:34:42 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 06:34:54 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2022-03-15 06:34:54 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 06:34:54 --> Final output sent to browser
DEBUG - 2022-03-15 06:34:54 --> Total execution time: 21.2134
INFO - 2022-03-15 06:34:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:34:54 --> Controller Class Initialized
INFO - 2022-03-15 06:34:54 --> Form Validation Class Initialized
DEBUG - 2022-03-15 06:34:54 --> Encrypt Class Initialized
INFO - 2022-03-15 06:34:54 --> Model "Login_model" initialized
INFO - 2022-03-15 06:34:54 --> Model "Dashboard_model" initialized
INFO - 2022-03-15 06:34:54 --> Model "Case_model" initialized
ERROR - 2022-03-15 06:35:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:35:03 --> Config Class Initialized
INFO - 2022-03-15 06:35:03 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:35:03 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:35:03 --> Utf8 Class Initialized
INFO - 2022-03-15 06:35:03 --> URI Class Initialized
INFO - 2022-03-15 06:35:03 --> Router Class Initialized
INFO - 2022-03-15 06:35:03 --> Output Class Initialized
INFO - 2022-03-15 06:35:03 --> Security Class Initialized
DEBUG - 2022-03-15 06:35:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:35:03 --> Input Class Initialized
INFO - 2022-03-15 06:35:03 --> Language Class Initialized
INFO - 2022-03-15 06:35:03 --> Loader Class Initialized
INFO - 2022-03-15 06:35:03 --> Helper loaded: url_helper
INFO - 2022-03-15 06:35:03 --> Helper loaded: form_helper
INFO - 2022-03-15 06:35:03 --> Helper loaded: common_helper
INFO - 2022-03-15 06:35:03 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:35:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:35:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:35:03 --> Controller Class Initialized
INFO - 2022-03-15 06:35:03 --> Form Validation Class Initialized
INFO - 2022-03-15 06:35:03 --> Model "Case_model" initialized
INFO - 2022-03-15 06:35:03 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 06:35:03 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 06:35:06 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 06:35:06 --> Model "Case_model" initialized
INFO - 2022-03-15 06:35:12 --> File loaded: /home3/karoteam/public_html/application/views/cases/open_case.php
INFO - 2022-03-15 06:35:12 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 06:35:13 --> Final output sent to browser
DEBUG - 2022-03-15 06:35:13 --> Total execution time: 8.9515
INFO - 2022-03-15 06:35:17 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2022-03-15 06:35:17 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 06:35:17 --> Final output sent to browser
DEBUG - 2022-03-15 06:35:17 --> Total execution time: 37.9237
ERROR - 2022-03-15 06:35:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:35:18 --> Config Class Initialized
INFO - 2022-03-15 06:35:18 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:35:18 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:35:18 --> Utf8 Class Initialized
INFO - 2022-03-15 06:35:18 --> URI Class Initialized
INFO - 2022-03-15 06:35:18 --> Router Class Initialized
INFO - 2022-03-15 06:35:18 --> Output Class Initialized
INFO - 2022-03-15 06:35:18 --> Security Class Initialized
DEBUG - 2022-03-15 06:35:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:35:18 --> Input Class Initialized
INFO - 2022-03-15 06:35:18 --> Language Class Initialized
ERROR - 2022-03-15 06:35:18 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-15 06:36:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:36:03 --> Config Class Initialized
INFO - 2022-03-15 06:36:03 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:36:03 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:36:03 --> Utf8 Class Initialized
INFO - 2022-03-15 06:36:03 --> URI Class Initialized
INFO - 2022-03-15 06:36:03 --> Router Class Initialized
INFO - 2022-03-15 06:36:03 --> Output Class Initialized
INFO - 2022-03-15 06:36:03 --> Security Class Initialized
DEBUG - 2022-03-15 06:36:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:36:03 --> Input Class Initialized
INFO - 2022-03-15 06:36:03 --> Language Class Initialized
INFO - 2022-03-15 06:36:03 --> Loader Class Initialized
INFO - 2022-03-15 06:36:03 --> Helper loaded: url_helper
INFO - 2022-03-15 06:36:03 --> Helper loaded: form_helper
INFO - 2022-03-15 06:36:03 --> Helper loaded: common_helper
INFO - 2022-03-15 06:36:03 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:36:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:36:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:36:03 --> Controller Class Initialized
INFO - 2022-03-15 06:36:03 --> Form Validation Class Initialized
INFO - 2022-03-15 06:36:03 --> Model "Case_model" initialized
INFO - 2022-03-15 06:36:03 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 06:36:04 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 06:36:04 --> File loaded: /home3/karoteam/public_html/application/views/cases/new_case.php
INFO - 2022-03-15 06:36:04 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 06:36:05 --> Final output sent to browser
DEBUG - 2022-03-15 06:36:05 --> Total execution time: 1.0143
ERROR - 2022-03-15 06:36:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:36:47 --> Config Class Initialized
INFO - 2022-03-15 06:36:47 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:36:47 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:36:47 --> Utf8 Class Initialized
INFO - 2022-03-15 06:36:47 --> URI Class Initialized
INFO - 2022-03-15 06:36:47 --> Router Class Initialized
INFO - 2022-03-15 06:36:47 --> Output Class Initialized
INFO - 2022-03-15 06:36:47 --> Security Class Initialized
DEBUG - 2022-03-15 06:36:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:36:47 --> Input Class Initialized
INFO - 2022-03-15 06:36:47 --> Language Class Initialized
INFO - 2022-03-15 06:36:47 --> Loader Class Initialized
INFO - 2022-03-15 06:36:47 --> Helper loaded: url_helper
INFO - 2022-03-15 06:36:47 --> Helper loaded: form_helper
INFO - 2022-03-15 06:36:47 --> Helper loaded: common_helper
INFO - 2022-03-15 06:36:47 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:36:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:36:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:36:47 --> Controller Class Initialized
INFO - 2022-03-15 06:36:47 --> Form Validation Class Initialized
DEBUG - 2022-03-15 06:36:47 --> Encrypt Class Initialized
INFO - 2022-03-15 06:36:47 --> Model "Patient_model" initialized
INFO - 2022-03-15 06:36:47 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 06:36:47 --> Model "Referredby_model" initialized
INFO - 2022-03-15 06:36:47 --> Model "Prefix_master" initialized
INFO - 2022-03-15 06:36:47 --> Model "Hospital_model" initialized
INFO - 2022-03-15 06:36:47 --> File loaded: /home3/karoteam/public_html/application/views/header.php
ERROR - 2022-03-15 06:36:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:36:51 --> Config Class Initialized
INFO - 2022-03-15 06:36:51 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:36:51 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:36:51 --> Utf8 Class Initialized
INFO - 2022-03-15 06:36:51 --> URI Class Initialized
INFO - 2022-03-15 06:36:51 --> Router Class Initialized
INFO - 2022-03-15 06:36:51 --> Output Class Initialized
INFO - 2022-03-15 06:36:51 --> Security Class Initialized
DEBUG - 2022-03-15 06:36:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:36:51 --> Input Class Initialized
INFO - 2022-03-15 06:36:51 --> Language Class Initialized
INFO - 2022-03-15 06:36:51 --> Loader Class Initialized
INFO - 2022-03-15 06:36:51 --> Helper loaded: url_helper
INFO - 2022-03-15 06:36:51 --> Helper loaded: form_helper
INFO - 2022-03-15 06:36:51 --> Helper loaded: common_helper
INFO - 2022-03-15 06:36:51 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:36:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:36:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:36:51 --> Controller Class Initialized
INFO - 2022-03-15 06:36:51 --> Form Validation Class Initialized
DEBUG - 2022-03-15 06:36:51 --> Encrypt Class Initialized
INFO - 2022-03-15 06:36:51 --> Model "Patient_model" initialized
INFO - 2022-03-15 06:36:51 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 06:36:51 --> Model "Prefix_master" initialized
INFO - 2022-03-15 06:36:51 --> Model "Users_model" initialized
INFO - 2022-03-15 06:36:51 --> Model "Hospital_model" initialized
INFO - 2022-03-15 06:36:52 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-15 06:36:52 --> Final output sent to browser
DEBUG - 2022-03-15 06:36:52 --> Total execution time: 0.9770
INFO - 2022-03-15 06:36:55 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-15 06:36:55 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
ERROR - 2022-03-15 06:36:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:36:56 --> Config Class Initialized
INFO - 2022-03-15 06:36:56 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:36:56 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:36:56 --> Utf8 Class Initialized
INFO - 2022-03-15 06:36:56 --> URI Class Initialized
INFO - 2022-03-15 06:36:56 --> Router Class Initialized
INFO - 2022-03-15 06:36:56 --> Output Class Initialized
INFO - 2022-03-15 06:36:56 --> Security Class Initialized
DEBUG - 2022-03-15 06:36:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:36:56 --> Input Class Initialized
INFO - 2022-03-15 06:36:56 --> Language Class Initialized
ERROR - 2022-03-15 06:36:56 --> 404 Page Not Found: Karoclient/usersprofile
INFO - 2022-03-15 06:36:57 --> Final output sent to browser
DEBUG - 2022-03-15 06:36:57 --> Total execution time: 8.1166
ERROR - 2022-03-15 06:37:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:37:08 --> Config Class Initialized
INFO - 2022-03-15 06:37:08 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:37:08 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:37:08 --> Utf8 Class Initialized
INFO - 2022-03-15 06:37:08 --> URI Class Initialized
INFO - 2022-03-15 06:37:08 --> Router Class Initialized
INFO - 2022-03-15 06:37:08 --> Output Class Initialized
INFO - 2022-03-15 06:37:08 --> Security Class Initialized
DEBUG - 2022-03-15 06:37:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:37:08 --> Input Class Initialized
INFO - 2022-03-15 06:37:08 --> Language Class Initialized
INFO - 2022-03-15 06:37:08 --> Loader Class Initialized
INFO - 2022-03-15 06:37:08 --> Helper loaded: url_helper
INFO - 2022-03-15 06:37:08 --> Helper loaded: form_helper
INFO - 2022-03-15 06:37:08 --> Helper loaded: common_helper
INFO - 2022-03-15 06:37:08 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:37:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:37:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:37:08 --> Controller Class Initialized
INFO - 2022-03-15 06:37:08 --> Form Validation Class Initialized
DEBUG - 2022-03-15 06:37:08 --> Encrypt Class Initialized
INFO - 2022-03-15 06:37:08 --> Model "Login_model" initialized
INFO - 2022-03-15 06:37:08 --> Model "Dashboard_model" initialized
INFO - 2022-03-15 06:37:08 --> Model "Case_model" initialized
INFO - 2022-03-15 06:37:18 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 06:37:30 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2022-03-15 06:37:30 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 06:37:30 --> Final output sent to browser
DEBUG - 2022-03-15 06:37:30 --> Total execution time: 22.2809
ERROR - 2022-03-15 06:37:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:37:31 --> Config Class Initialized
INFO - 2022-03-15 06:37:31 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:37:31 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:37:31 --> Utf8 Class Initialized
INFO - 2022-03-15 06:37:31 --> URI Class Initialized
INFO - 2022-03-15 06:37:31 --> Router Class Initialized
INFO - 2022-03-15 06:37:31 --> Output Class Initialized
INFO - 2022-03-15 06:37:31 --> Security Class Initialized
DEBUG - 2022-03-15 06:37:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:37:31 --> Input Class Initialized
INFO - 2022-03-15 06:37:31 --> Language Class Initialized
ERROR - 2022-03-15 06:37:31 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-15 06:37:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:37:43 --> Config Class Initialized
INFO - 2022-03-15 06:37:43 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:37:43 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:37:43 --> Utf8 Class Initialized
INFO - 2022-03-15 06:37:43 --> URI Class Initialized
INFO - 2022-03-15 06:37:43 --> Router Class Initialized
INFO - 2022-03-15 06:37:43 --> Output Class Initialized
INFO - 2022-03-15 06:37:43 --> Security Class Initialized
DEBUG - 2022-03-15 06:37:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:37:43 --> Input Class Initialized
INFO - 2022-03-15 06:37:43 --> Language Class Initialized
INFO - 2022-03-15 06:37:43 --> Loader Class Initialized
INFO - 2022-03-15 06:37:43 --> Helper loaded: url_helper
INFO - 2022-03-15 06:37:43 --> Helper loaded: form_helper
INFO - 2022-03-15 06:37:43 --> Helper loaded: common_helper
INFO - 2022-03-15 06:37:43 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:37:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:37:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:37:43 --> Controller Class Initialized
INFO - 2022-03-15 06:37:43 --> Form Validation Class Initialized
DEBUG - 2022-03-15 06:37:43 --> Encrypt Class Initialized
INFO - 2022-03-15 06:37:43 --> Model "Patient_model" initialized
INFO - 2022-03-15 06:37:43 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 06:37:43 --> Model "Prefix_master" initialized
INFO - 2022-03-15 06:37:43 --> Model "Users_model" initialized
INFO - 2022-03-15 06:37:43 --> Model "Hospital_model" initialized
INFO - 2022-03-15 06:37:43 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 06:37:43 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-15 06:37:43 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 06:37:43 --> Final output sent to browser
DEBUG - 2022-03-15 06:37:43 --> Total execution time: 0.0585
ERROR - 2022-03-15 06:37:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:37:44 --> Config Class Initialized
INFO - 2022-03-15 06:37:44 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:37:44 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:37:44 --> Utf8 Class Initialized
INFO - 2022-03-15 06:37:44 --> URI Class Initialized
INFO - 2022-03-15 06:37:44 --> Router Class Initialized
INFO - 2022-03-15 06:37:44 --> Output Class Initialized
INFO - 2022-03-15 06:37:44 --> Security Class Initialized
DEBUG - 2022-03-15 06:37:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:37:44 --> Input Class Initialized
INFO - 2022-03-15 06:37:44 --> Language Class Initialized
ERROR - 2022-03-15 06:37:44 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-15 06:37:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:37:48 --> Config Class Initialized
INFO - 2022-03-15 06:37:48 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:37:48 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:37:48 --> Utf8 Class Initialized
INFO - 2022-03-15 06:37:48 --> URI Class Initialized
INFO - 2022-03-15 06:37:48 --> Router Class Initialized
INFO - 2022-03-15 06:37:48 --> Output Class Initialized
INFO - 2022-03-15 06:37:48 --> Security Class Initialized
DEBUG - 2022-03-15 06:37:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:37:48 --> Input Class Initialized
INFO - 2022-03-15 06:37:48 --> Language Class Initialized
INFO - 2022-03-15 06:37:48 --> Loader Class Initialized
INFO - 2022-03-15 06:37:48 --> Helper loaded: url_helper
INFO - 2022-03-15 06:37:48 --> Helper loaded: form_helper
INFO - 2022-03-15 06:37:48 --> Helper loaded: common_helper
INFO - 2022-03-15 06:37:48 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:37:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:37:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:37:48 --> Controller Class Initialized
INFO - 2022-03-15 06:37:48 --> Form Validation Class Initialized
DEBUG - 2022-03-15 06:37:48 --> Encrypt Class Initialized
INFO - 2022-03-15 06:37:48 --> Model "Login_model" initialized
INFO - 2022-03-15 06:37:48 --> Model "Dashboard_model" initialized
INFO - 2022-03-15 06:37:48 --> Model "Case_model" initialized
INFO - 2022-03-15 06:37:56 --> File loaded: /home3/karoteam/public_html/application/views/header.php
ERROR - 2022-03-15 06:38:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:38:02 --> Config Class Initialized
INFO - 2022-03-15 06:38:02 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:38:02 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:38:02 --> Utf8 Class Initialized
INFO - 2022-03-15 06:38:02 --> URI Class Initialized
INFO - 2022-03-15 06:38:02 --> Router Class Initialized
INFO - 2022-03-15 06:38:02 --> Output Class Initialized
INFO - 2022-03-15 06:38:02 --> Security Class Initialized
DEBUG - 2022-03-15 06:38:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:38:02 --> Input Class Initialized
INFO - 2022-03-15 06:38:02 --> Language Class Initialized
INFO - 2022-03-15 06:38:02 --> Loader Class Initialized
INFO - 2022-03-15 06:38:02 --> Helper loaded: url_helper
INFO - 2022-03-15 06:38:02 --> Helper loaded: form_helper
INFO - 2022-03-15 06:38:02 --> Helper loaded: common_helper
INFO - 2022-03-15 06:38:02 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:38:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:38:07 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2022-03-15 06:38:07 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 06:38:07 --> Final output sent to browser
DEBUG - 2022-03-15 06:38:07 --> Total execution time: 19.4380
INFO - 2022-03-15 06:38:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:38:07 --> Controller Class Initialized
INFO - 2022-03-15 06:38:07 --> Form Validation Class Initialized
INFO - 2022-03-15 06:38:07 --> Model "Case_model" initialized
INFO - 2022-03-15 06:38:07 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 06:38:07 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 06:38:07 --> File loaded: /home3/karoteam/public_html/application/views/cases/rehelp.php
INFO - 2022-03-15 06:38:07 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 06:38:07 --> Final output sent to browser
DEBUG - 2022-03-15 06:38:07 --> Total execution time: 4.7757
ERROR - 2022-03-15 06:38:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:38:08 --> Config Class Initialized
INFO - 2022-03-15 06:38:08 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:38:08 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:38:08 --> Utf8 Class Initialized
INFO - 2022-03-15 06:38:08 --> URI Class Initialized
INFO - 2022-03-15 06:38:08 --> Router Class Initialized
INFO - 2022-03-15 06:38:08 --> Output Class Initialized
INFO - 2022-03-15 06:38:08 --> Security Class Initialized
DEBUG - 2022-03-15 06:38:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:38:08 --> Input Class Initialized
INFO - 2022-03-15 06:38:08 --> Language Class Initialized
ERROR - 2022-03-15 06:38:08 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-15 06:39:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:39:26 --> Config Class Initialized
INFO - 2022-03-15 06:39:26 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:39:26 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:39:26 --> Utf8 Class Initialized
INFO - 2022-03-15 06:39:26 --> URI Class Initialized
INFO - 2022-03-15 06:39:26 --> Router Class Initialized
INFO - 2022-03-15 06:39:26 --> Output Class Initialized
INFO - 2022-03-15 06:39:26 --> Security Class Initialized
DEBUG - 2022-03-15 06:39:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:39:26 --> Input Class Initialized
INFO - 2022-03-15 06:39:26 --> Language Class Initialized
INFO - 2022-03-15 06:39:26 --> Loader Class Initialized
INFO - 2022-03-15 06:39:26 --> Helper loaded: url_helper
INFO - 2022-03-15 06:39:26 --> Helper loaded: form_helper
INFO - 2022-03-15 06:39:26 --> Helper loaded: common_helper
INFO - 2022-03-15 06:39:26 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:39:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:39:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:39:26 --> Controller Class Initialized
INFO - 2022-03-15 06:39:26 --> Form Validation Class Initialized
DEBUG - 2022-03-15 06:39:26 --> Encrypt Class Initialized
INFO - 2022-03-15 06:39:26 --> Model "Login_model" initialized
INFO - 2022-03-15 06:39:26 --> Model "Dashboard_model" initialized
INFO - 2022-03-15 06:39:26 --> Model "Case_model" initialized
INFO - 2022-03-15 06:39:34 --> File loaded: /home3/karoteam/public_html/application/views/header.php
ERROR - 2022-03-15 06:39:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:39:42 --> Config Class Initialized
INFO - 2022-03-15 06:39:42 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:39:42 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:39:42 --> Utf8 Class Initialized
INFO - 2022-03-15 06:39:42 --> URI Class Initialized
INFO - 2022-03-15 06:39:42 --> Router Class Initialized
INFO - 2022-03-15 06:39:42 --> Output Class Initialized
INFO - 2022-03-15 06:39:42 --> Security Class Initialized
DEBUG - 2022-03-15 06:39:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:39:42 --> Input Class Initialized
INFO - 2022-03-15 06:39:42 --> Language Class Initialized
INFO - 2022-03-15 06:39:42 --> Loader Class Initialized
INFO - 2022-03-15 06:39:42 --> Helper loaded: url_helper
INFO - 2022-03-15 06:39:42 --> Helper loaded: form_helper
INFO - 2022-03-15 06:39:42 --> Helper loaded: common_helper
INFO - 2022-03-15 06:39:42 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:39:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:39:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:39:42 --> Controller Class Initialized
INFO - 2022-03-15 06:39:42 --> Form Validation Class Initialized
DEBUG - 2022-03-15 06:39:42 --> Encrypt Class Initialized
INFO - 2022-03-15 06:39:42 --> Model "Login_model" initialized
INFO - 2022-03-15 06:39:42 --> Model "Dashboard_model" initialized
INFO - 2022-03-15 06:39:42 --> Model "Case_model" initialized
INFO - 2022-03-15 06:39:46 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2022-03-15 06:39:46 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 06:39:46 --> Final output sent to browser
DEBUG - 2022-03-15 06:39:46 --> Total execution time: 19.8367
INFO - 2022-03-15 06:39:51 --> File loaded: /home3/karoteam/public_html/application/views/header.php
ERROR - 2022-03-15 06:39:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:39:51 --> Config Class Initialized
INFO - 2022-03-15 06:39:51 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:39:51 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:39:51 --> Utf8 Class Initialized
INFO - 2022-03-15 06:39:51 --> URI Class Initialized
INFO - 2022-03-15 06:39:51 --> Router Class Initialized
INFO - 2022-03-15 06:39:51 --> Output Class Initialized
INFO - 2022-03-15 06:39:51 --> Security Class Initialized
DEBUG - 2022-03-15 06:39:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:39:51 --> Input Class Initialized
INFO - 2022-03-15 06:39:51 --> Language Class Initialized
INFO - 2022-03-15 06:39:51 --> Loader Class Initialized
INFO - 2022-03-15 06:39:51 --> Helper loaded: url_helper
INFO - 2022-03-15 06:39:51 --> Helper loaded: form_helper
INFO - 2022-03-15 06:39:51 --> Helper loaded: common_helper
INFO - 2022-03-15 06:39:51 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:39:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:40:01 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2022-03-15 06:40:01 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 06:40:01 --> Final output sent to browser
DEBUG - 2022-03-15 06:40:01 --> Total execution time: 19.3935
INFO - 2022-03-15 06:40:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:40:01 --> Controller Class Initialized
INFO - 2022-03-15 06:40:01 --> Form Validation Class Initialized
DEBUG - 2022-03-15 06:40:01 --> Encrypt Class Initialized
INFO - 2022-03-15 06:40:01 --> Model "Login_model" initialized
INFO - 2022-03-15 06:40:01 --> Model "Dashboard_model" initialized
INFO - 2022-03-15 06:40:01 --> Model "Case_model" initialized
INFO - 2022-03-15 06:40:10 --> File loaded: /home3/karoteam/public_html/application/views/header.php
ERROR - 2022-03-15 06:40:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:40:14 --> Config Class Initialized
INFO - 2022-03-15 06:40:14 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:40:14 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:40:14 --> Utf8 Class Initialized
INFO - 2022-03-15 06:40:14 --> URI Class Initialized
INFO - 2022-03-15 06:40:14 --> Router Class Initialized
INFO - 2022-03-15 06:40:14 --> Output Class Initialized
INFO - 2022-03-15 06:40:14 --> Security Class Initialized
DEBUG - 2022-03-15 06:40:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:40:14 --> Input Class Initialized
INFO - 2022-03-15 06:40:14 --> Language Class Initialized
INFO - 2022-03-15 06:40:14 --> Loader Class Initialized
INFO - 2022-03-15 06:40:14 --> Helper loaded: url_helper
INFO - 2022-03-15 06:40:14 --> Helper loaded: form_helper
INFO - 2022-03-15 06:40:14 --> Helper loaded: common_helper
INFO - 2022-03-15 06:40:14 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:40:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:40:20 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2022-03-15 06:40:20 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 06:40:20 --> Final output sent to browser
DEBUG - 2022-03-15 06:40:20 --> Total execution time: 29.2363
INFO - 2022-03-15 06:40:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:40:20 --> Controller Class Initialized
INFO - 2022-03-15 06:40:20 --> Form Validation Class Initialized
DEBUG - 2022-03-15 06:40:20 --> Encrypt Class Initialized
INFO - 2022-03-15 06:40:20 --> Model "Login_model" initialized
INFO - 2022-03-15 06:40:20 --> Model "Dashboard_model" initialized
INFO - 2022-03-15 06:40:20 --> Model "Case_model" initialized
ERROR - 2022-03-15 06:40:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:40:21 --> Config Class Initialized
INFO - 2022-03-15 06:40:21 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:40:21 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:40:21 --> Utf8 Class Initialized
INFO - 2022-03-15 06:40:21 --> URI Class Initialized
INFO - 2022-03-15 06:40:21 --> Router Class Initialized
INFO - 2022-03-15 06:40:21 --> Output Class Initialized
INFO - 2022-03-15 06:40:21 --> Security Class Initialized
DEBUG - 2022-03-15 06:40:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:40:21 --> Input Class Initialized
INFO - 2022-03-15 06:40:21 --> Language Class Initialized
ERROR - 2022-03-15 06:40:21 --> 404 Page Not Found: Karoclient/usersprofile
INFO - 2022-03-15 06:40:29 --> File loaded: /home3/karoteam/public_html/application/views/header.php
ERROR - 2022-03-15 06:40:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:40:29 --> Config Class Initialized
INFO - 2022-03-15 06:40:29 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:40:29 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:40:29 --> Utf8 Class Initialized
INFO - 2022-03-15 06:40:29 --> URI Class Initialized
INFO - 2022-03-15 06:40:29 --> Router Class Initialized
INFO - 2022-03-15 06:40:29 --> Output Class Initialized
INFO - 2022-03-15 06:40:29 --> Security Class Initialized
DEBUG - 2022-03-15 06:40:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:40:29 --> Input Class Initialized
INFO - 2022-03-15 06:40:29 --> Language Class Initialized
INFO - 2022-03-15 06:40:29 --> Loader Class Initialized
INFO - 2022-03-15 06:40:29 --> Helper loaded: url_helper
INFO - 2022-03-15 06:40:29 --> Helper loaded: form_helper
INFO - 2022-03-15 06:40:29 --> Helper loaded: common_helper
INFO - 2022-03-15 06:40:29 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:40:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:40:39 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2022-03-15 06:40:39 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 06:40:39 --> Final output sent to browser
DEBUG - 2022-03-15 06:40:39 --> Total execution time: 25.2045
INFO - 2022-03-15 06:40:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:40:39 --> Controller Class Initialized
INFO - 2022-03-15 06:40:39 --> Form Validation Class Initialized
DEBUG - 2022-03-15 06:40:39 --> Encrypt Class Initialized
INFO - 2022-03-15 06:40:39 --> Model "Login_model" initialized
INFO - 2022-03-15 06:40:39 --> Model "Dashboard_model" initialized
INFO - 2022-03-15 06:40:39 --> Model "Case_model" initialized
ERROR - 2022-03-15 06:40:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:40:40 --> Config Class Initialized
INFO - 2022-03-15 06:40:40 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:40:40 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:40:40 --> Utf8 Class Initialized
INFO - 2022-03-15 06:40:40 --> URI Class Initialized
INFO - 2022-03-15 06:40:40 --> Router Class Initialized
INFO - 2022-03-15 06:40:40 --> Output Class Initialized
INFO - 2022-03-15 06:40:40 --> Security Class Initialized
DEBUG - 2022-03-15 06:40:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:40:40 --> Input Class Initialized
INFO - 2022-03-15 06:40:40 --> Language Class Initialized
ERROR - 2022-03-15 06:40:40 --> 404 Page Not Found: Karoclient/usersprofile
INFO - 2022-03-15 06:40:48 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 06:40:59 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2022-03-15 06:40:59 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 06:40:59 --> Final output sent to browser
DEBUG - 2022-03-15 06:40:59 --> Total execution time: 29.7819
ERROR - 2022-03-15 06:40:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:40:59 --> Config Class Initialized
INFO - 2022-03-15 06:40:59 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:40:59 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:40:59 --> Utf8 Class Initialized
INFO - 2022-03-15 06:40:59 --> URI Class Initialized
INFO - 2022-03-15 06:40:59 --> Router Class Initialized
INFO - 2022-03-15 06:40:59 --> Output Class Initialized
INFO - 2022-03-15 06:40:59 --> Security Class Initialized
DEBUG - 2022-03-15 06:40:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:40:59 --> Input Class Initialized
INFO - 2022-03-15 06:40:59 --> Language Class Initialized
ERROR - 2022-03-15 06:40:59 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-15 06:41:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:41:18 --> Config Class Initialized
INFO - 2022-03-15 06:41:18 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:41:18 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:41:18 --> Utf8 Class Initialized
INFO - 2022-03-15 06:41:18 --> URI Class Initialized
INFO - 2022-03-15 06:41:18 --> Router Class Initialized
INFO - 2022-03-15 06:41:18 --> Output Class Initialized
INFO - 2022-03-15 06:41:18 --> Security Class Initialized
DEBUG - 2022-03-15 06:41:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:41:18 --> Input Class Initialized
INFO - 2022-03-15 06:41:18 --> Language Class Initialized
INFO - 2022-03-15 06:41:18 --> Loader Class Initialized
INFO - 2022-03-15 06:41:18 --> Helper loaded: url_helper
INFO - 2022-03-15 06:41:18 --> Helper loaded: form_helper
INFO - 2022-03-15 06:41:18 --> Helper loaded: common_helper
INFO - 2022-03-15 06:41:18 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:41:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:41:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:41:18 --> Controller Class Initialized
INFO - 2022-03-15 06:41:18 --> Form Validation Class Initialized
INFO - 2022-03-15 06:41:18 --> Model "Case_model" initialized
INFO - 2022-03-15 06:41:18 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 06:41:20 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 06:41:20 --> Model "Case_model" initialized
INFO - 2022-03-15 06:41:21 --> File loaded: /home3/karoteam/public_html/application/views/cases/closed_case.php
INFO - 2022-03-15 06:41:21 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 06:41:22 --> Final output sent to browser
DEBUG - 2022-03-15 06:41:22 --> Total execution time: 2.9914
ERROR - 2022-03-15 06:41:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:41:22 --> Config Class Initialized
INFO - 2022-03-15 06:41:22 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:41:22 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:41:22 --> Utf8 Class Initialized
INFO - 2022-03-15 06:41:22 --> URI Class Initialized
INFO - 2022-03-15 06:41:22 --> Router Class Initialized
INFO - 2022-03-15 06:41:22 --> Output Class Initialized
INFO - 2022-03-15 06:41:22 --> Security Class Initialized
DEBUG - 2022-03-15 06:41:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:41:22 --> Input Class Initialized
INFO - 2022-03-15 06:41:22 --> Language Class Initialized
ERROR - 2022-03-15 06:41:22 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-15 06:41:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:41:30 --> Config Class Initialized
INFO - 2022-03-15 06:41:30 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:41:30 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:41:30 --> Utf8 Class Initialized
INFO - 2022-03-15 06:41:30 --> URI Class Initialized
INFO - 2022-03-15 06:41:30 --> Router Class Initialized
INFO - 2022-03-15 06:41:30 --> Output Class Initialized
INFO - 2022-03-15 06:41:30 --> Security Class Initialized
DEBUG - 2022-03-15 06:41:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:41:30 --> Input Class Initialized
INFO - 2022-03-15 06:41:30 --> Language Class Initialized
INFO - 2022-03-15 06:41:30 --> Loader Class Initialized
INFO - 2022-03-15 06:41:30 --> Helper loaded: url_helper
INFO - 2022-03-15 06:41:30 --> Helper loaded: form_helper
INFO - 2022-03-15 06:41:30 --> Helper loaded: common_helper
INFO - 2022-03-15 06:41:30 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:41:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:41:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:41:30 --> Controller Class Initialized
INFO - 2022-03-15 06:41:30 --> Form Validation Class Initialized
DEBUG - 2022-03-15 06:41:30 --> Encrypt Class Initialized
DEBUG - 2022-03-15 06:41:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-15 06:41:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-15 06:41:30 --> Email Class Initialized
INFO - 2022-03-15 06:41:30 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-15 06:41:30 --> Calendar Class Initialized
INFO - 2022-03-15 06:41:30 --> Model "Login_model" initialized
ERROR - 2022-03-15 06:41:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:41:30 --> Config Class Initialized
INFO - 2022-03-15 06:41:30 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:41:30 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:41:30 --> Utf8 Class Initialized
INFO - 2022-03-15 06:41:30 --> URI Class Initialized
INFO - 2022-03-15 06:41:30 --> Router Class Initialized
INFO - 2022-03-15 06:41:30 --> Output Class Initialized
INFO - 2022-03-15 06:41:30 --> Security Class Initialized
DEBUG - 2022-03-15 06:41:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:41:30 --> Input Class Initialized
INFO - 2022-03-15 06:41:30 --> Language Class Initialized
INFO - 2022-03-15 06:41:30 --> Loader Class Initialized
INFO - 2022-03-15 06:41:30 --> Helper loaded: url_helper
INFO - 2022-03-15 06:41:30 --> Helper loaded: form_helper
INFO - 2022-03-15 06:41:30 --> Helper loaded: common_helper
INFO - 2022-03-15 06:41:30 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:41:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:41:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:41:30 --> Controller Class Initialized
INFO - 2022-03-15 06:41:30 --> Form Validation Class Initialized
DEBUG - 2022-03-15 06:41:30 --> Encrypt Class Initialized
INFO - 2022-03-15 06:41:30 --> Model "Diseases_model" initialized
INFO - 2022-03-15 06:41:30 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 06:41:30 --> File loaded: /home3/karoteam/public_html/application/views/diseases/index.php
INFO - 2022-03-15 06:41:30 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 06:41:30 --> Final output sent to browser
DEBUG - 2022-03-15 06:41:30 --> Total execution time: 0.0216
ERROR - 2022-03-15 06:41:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:41:30 --> Config Class Initialized
INFO - 2022-03-15 06:41:30 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:41:30 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:41:30 --> Utf8 Class Initialized
INFO - 2022-03-15 06:41:30 --> URI Class Initialized
INFO - 2022-03-15 06:41:30 --> Router Class Initialized
INFO - 2022-03-15 06:41:30 --> Output Class Initialized
INFO - 2022-03-15 06:41:30 --> Security Class Initialized
DEBUG - 2022-03-15 06:41:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:41:30 --> Input Class Initialized
INFO - 2022-03-15 06:41:30 --> Language Class Initialized
INFO - 2022-03-15 06:41:30 --> Loader Class Initialized
INFO - 2022-03-15 06:41:30 --> Helper loaded: url_helper
INFO - 2022-03-15 06:41:30 --> Helper loaded: form_helper
INFO - 2022-03-15 06:41:30 --> Helper loaded: common_helper
INFO - 2022-03-15 06:41:30 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:41:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:41:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:41:30 --> Controller Class Initialized
INFO - 2022-03-15 06:41:30 --> Form Validation Class Initialized
DEBUG - 2022-03-15 06:41:30 --> Encrypt Class Initialized
DEBUG - 2022-03-15 06:41:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-15 06:41:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-15 06:41:30 --> Email Class Initialized
INFO - 2022-03-15 06:41:30 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-15 06:41:30 --> Calendar Class Initialized
INFO - 2022-03-15 06:41:30 --> Model "Login_model" initialized
ERROR - 2022-03-15 06:41:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:41:31 --> Config Class Initialized
INFO - 2022-03-15 06:41:31 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:41:31 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:41:31 --> Utf8 Class Initialized
INFO - 2022-03-15 06:41:31 --> URI Class Initialized
INFO - 2022-03-15 06:41:31 --> Router Class Initialized
INFO - 2022-03-15 06:41:31 --> Output Class Initialized
INFO - 2022-03-15 06:41:31 --> Security Class Initialized
DEBUG - 2022-03-15 06:41:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:41:31 --> Input Class Initialized
INFO - 2022-03-15 06:41:31 --> Language Class Initialized
INFO - 2022-03-15 06:41:31 --> Loader Class Initialized
INFO - 2022-03-15 06:41:31 --> Helper loaded: url_helper
INFO - 2022-03-15 06:41:31 --> Helper loaded: form_helper
INFO - 2022-03-15 06:41:31 --> Helper loaded: common_helper
INFO - 2022-03-15 06:41:31 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:41:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:41:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:41:31 --> Controller Class Initialized
INFO - 2022-03-15 06:41:31 --> Form Validation Class Initialized
DEBUG - 2022-03-15 06:41:31 --> Encrypt Class Initialized
INFO - 2022-03-15 06:41:31 --> Model "Diseases_model" initialized
INFO - 2022-03-15 06:41:31 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 06:41:31 --> File loaded: /home3/karoteam/public_html/application/views/diseases/index.php
INFO - 2022-03-15 06:41:31 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 06:41:31 --> Final output sent to browser
DEBUG - 2022-03-15 06:41:31 --> Total execution time: 0.0201
ERROR - 2022-03-15 06:41:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:41:36 --> Config Class Initialized
INFO - 2022-03-15 06:41:36 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:41:36 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:41:36 --> Utf8 Class Initialized
INFO - 2022-03-15 06:41:36 --> URI Class Initialized
INFO - 2022-03-15 06:41:36 --> Router Class Initialized
INFO - 2022-03-15 06:41:36 --> Output Class Initialized
INFO - 2022-03-15 06:41:36 --> Security Class Initialized
DEBUG - 2022-03-15 06:41:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:41:36 --> Input Class Initialized
INFO - 2022-03-15 06:41:36 --> Language Class Initialized
INFO - 2022-03-15 06:41:36 --> Loader Class Initialized
INFO - 2022-03-15 06:41:36 --> Helper loaded: url_helper
INFO - 2022-03-15 06:41:36 --> Helper loaded: form_helper
INFO - 2022-03-15 06:41:36 --> Helper loaded: common_helper
INFO - 2022-03-15 06:41:36 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:41:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:41:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:41:36 --> Controller Class Initialized
INFO - 2022-03-15 06:41:36 --> Form Validation Class Initialized
DEBUG - 2022-03-15 06:41:36 --> Encrypt Class Initialized
INFO - 2022-03-15 06:41:36 --> Model "Patient_model" initialized
INFO - 2022-03-15 06:41:36 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 06:41:36 --> Model "Referredby_model" initialized
INFO - 2022-03-15 06:41:36 --> Model "Prefix_master" initialized
INFO - 2022-03-15 06:41:36 --> Model "Hospital_model" initialized
INFO - 2022-03-15 06:41:36 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 06:41:36 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-15 06:41:36 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 06:41:36 --> Final output sent to browser
DEBUG - 2022-03-15 06:41:36 --> Total execution time: 0.0714
ERROR - 2022-03-15 06:41:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:41:37 --> Config Class Initialized
INFO - 2022-03-15 06:41:37 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:41:37 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:41:37 --> Utf8 Class Initialized
INFO - 2022-03-15 06:41:37 --> URI Class Initialized
INFO - 2022-03-15 06:41:37 --> Router Class Initialized
INFO - 2022-03-15 06:41:37 --> Output Class Initialized
INFO - 2022-03-15 06:41:37 --> Security Class Initialized
DEBUG - 2022-03-15 06:41:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:41:37 --> Input Class Initialized
INFO - 2022-03-15 06:41:37 --> Language Class Initialized
INFO - 2022-03-15 06:41:37 --> Loader Class Initialized
INFO - 2022-03-15 06:41:37 --> Helper loaded: url_helper
INFO - 2022-03-15 06:41:37 --> Helper loaded: form_helper
INFO - 2022-03-15 06:41:37 --> Helper loaded: common_helper
INFO - 2022-03-15 06:41:37 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:41:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:41:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:41:37 --> Controller Class Initialized
INFO - 2022-03-15 06:41:37 --> Form Validation Class Initialized
DEBUG - 2022-03-15 06:41:37 --> Encrypt Class Initialized
INFO - 2022-03-15 06:41:37 --> Model "Patient_model" initialized
INFO - 2022-03-15 06:41:37 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 06:41:37 --> Model "Prefix_master" initialized
INFO - 2022-03-15 06:41:37 --> Model "Users_model" initialized
INFO - 2022-03-15 06:41:37 --> Model "Hospital_model" initialized
INFO - 2022-03-15 06:41:37 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 06:41:37 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-15 06:41:37 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 06:41:37 --> Final output sent to browser
DEBUG - 2022-03-15 06:41:37 --> Total execution time: 0.0781
ERROR - 2022-03-15 06:41:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:41:38 --> Config Class Initialized
INFO - 2022-03-15 06:41:38 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:41:38 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:41:38 --> Utf8 Class Initialized
INFO - 2022-03-15 06:41:38 --> URI Class Initialized
INFO - 2022-03-15 06:41:38 --> Router Class Initialized
INFO - 2022-03-15 06:41:38 --> Output Class Initialized
INFO - 2022-03-15 06:41:38 --> Security Class Initialized
DEBUG - 2022-03-15 06:41:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:41:38 --> Input Class Initialized
INFO - 2022-03-15 06:41:38 --> Language Class Initialized
ERROR - 2022-03-15 06:41:38 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-15 06:41:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:41:56 --> Config Class Initialized
INFO - 2022-03-15 06:41:56 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:41:56 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:41:56 --> Utf8 Class Initialized
INFO - 2022-03-15 06:41:56 --> URI Class Initialized
INFO - 2022-03-15 06:41:56 --> Router Class Initialized
INFO - 2022-03-15 06:41:56 --> Output Class Initialized
INFO - 2022-03-15 06:41:56 --> Security Class Initialized
DEBUG - 2022-03-15 06:41:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:41:56 --> Input Class Initialized
INFO - 2022-03-15 06:41:56 --> Language Class Initialized
INFO - 2022-03-15 06:41:56 --> Loader Class Initialized
INFO - 2022-03-15 06:41:56 --> Helper loaded: url_helper
INFO - 2022-03-15 06:41:56 --> Helper loaded: form_helper
INFO - 2022-03-15 06:41:56 --> Helper loaded: common_helper
INFO - 2022-03-15 06:41:56 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:41:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:41:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:41:56 --> Controller Class Initialized
INFO - 2022-03-15 06:41:56 --> Form Validation Class Initialized
DEBUG - 2022-03-15 06:41:56 --> Encrypt Class Initialized
INFO - 2022-03-15 06:41:57 --> Model "Patient_model" initialized
INFO - 2022-03-15 06:41:57 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 06:41:57 --> Model "Referredby_model" initialized
INFO - 2022-03-15 06:41:57 --> Model "Prefix_master" initialized
INFO - 2022-03-15 06:41:57 --> Model "Hospital_model" initialized
INFO - 2022-03-15 06:41:57 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 06:41:57 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-15 06:41:57 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 06:41:57 --> Final output sent to browser
DEBUG - 2022-03-15 06:41:57 --> Total execution time: 0.0595
ERROR - 2022-03-15 06:41:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:41:57 --> Config Class Initialized
INFO - 2022-03-15 06:41:57 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:41:57 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:41:57 --> Utf8 Class Initialized
INFO - 2022-03-15 06:41:57 --> URI Class Initialized
INFO - 2022-03-15 06:41:57 --> Router Class Initialized
INFO - 2022-03-15 06:41:57 --> Output Class Initialized
INFO - 2022-03-15 06:41:57 --> Security Class Initialized
DEBUG - 2022-03-15 06:41:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:41:57 --> Input Class Initialized
INFO - 2022-03-15 06:41:57 --> Language Class Initialized
ERROR - 2022-03-15 06:41:57 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-15 06:41:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:41:57 --> Config Class Initialized
INFO - 2022-03-15 06:41:57 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:41:57 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:41:57 --> Utf8 Class Initialized
INFO - 2022-03-15 06:41:57 --> URI Class Initialized
INFO - 2022-03-15 06:41:57 --> Router Class Initialized
INFO - 2022-03-15 06:41:57 --> Output Class Initialized
INFO - 2022-03-15 06:41:57 --> Security Class Initialized
DEBUG - 2022-03-15 06:41:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:41:57 --> Input Class Initialized
INFO - 2022-03-15 06:41:57 --> Language Class Initialized
ERROR - 2022-03-15 06:41:57 --> 404 Page Not Found: Karoclient/images
ERROR - 2022-03-15 06:42:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:42:39 --> Config Class Initialized
INFO - 2022-03-15 06:42:39 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:42:39 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:42:39 --> Utf8 Class Initialized
INFO - 2022-03-15 06:42:39 --> URI Class Initialized
INFO - 2022-03-15 06:42:39 --> Router Class Initialized
INFO - 2022-03-15 06:42:39 --> Output Class Initialized
INFO - 2022-03-15 06:42:39 --> Security Class Initialized
DEBUG - 2022-03-15 06:42:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:42:39 --> Input Class Initialized
INFO - 2022-03-15 06:42:39 --> Language Class Initialized
INFO - 2022-03-15 06:42:39 --> Loader Class Initialized
INFO - 2022-03-15 06:42:39 --> Helper loaded: url_helper
INFO - 2022-03-15 06:42:39 --> Helper loaded: form_helper
INFO - 2022-03-15 06:42:39 --> Helper loaded: common_helper
INFO - 2022-03-15 06:42:39 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:42:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:42:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:42:39 --> Controller Class Initialized
INFO - 2022-03-15 06:42:39 --> Form Validation Class Initialized
INFO - 2022-03-15 06:42:39 --> Model "Case_model" initialized
INFO - 2022-03-15 06:42:39 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 06:42:41 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 06:42:41 --> Model "Case_model" initialized
INFO - 2022-03-15 06:42:43 --> File loaded: /home3/karoteam/public_html/application/views/cases/closed_case.php
INFO - 2022-03-15 06:42:43 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 06:42:44 --> Final output sent to browser
DEBUG - 2022-03-15 06:42:44 --> Total execution time: 3.1978
ERROR - 2022-03-15 06:42:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:42:44 --> Config Class Initialized
INFO - 2022-03-15 06:42:44 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:42:44 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:42:44 --> Utf8 Class Initialized
INFO - 2022-03-15 06:42:44 --> URI Class Initialized
INFO - 2022-03-15 06:42:44 --> Router Class Initialized
INFO - 2022-03-15 06:42:44 --> Output Class Initialized
INFO - 2022-03-15 06:42:44 --> Security Class Initialized
DEBUG - 2022-03-15 06:42:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:42:44 --> Input Class Initialized
INFO - 2022-03-15 06:42:44 --> Language Class Initialized
ERROR - 2022-03-15 06:42:44 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-15 06:42:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:42:52 --> Config Class Initialized
INFO - 2022-03-15 06:42:52 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:42:52 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:42:52 --> Utf8 Class Initialized
INFO - 2022-03-15 06:42:52 --> URI Class Initialized
INFO - 2022-03-15 06:42:52 --> Router Class Initialized
INFO - 2022-03-15 06:42:52 --> Output Class Initialized
INFO - 2022-03-15 06:42:52 --> Security Class Initialized
DEBUG - 2022-03-15 06:42:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:42:52 --> Input Class Initialized
INFO - 2022-03-15 06:42:52 --> Language Class Initialized
INFO - 2022-03-15 06:42:52 --> Loader Class Initialized
INFO - 2022-03-15 06:42:52 --> Helper loaded: url_helper
INFO - 2022-03-15 06:42:52 --> Helper loaded: form_helper
INFO - 2022-03-15 06:42:52 --> Helper loaded: common_helper
INFO - 2022-03-15 06:42:52 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:42:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:42:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:42:52 --> Controller Class Initialized
INFO - 2022-03-15 06:42:52 --> Form Validation Class Initialized
INFO - 2022-03-15 06:42:52 --> Model "Case_model" initialized
INFO - 2022-03-15 06:42:52 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 06:42:52 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 06:42:52 --> File loaded: /home3/karoteam/public_html/application/views/cases/patient_amount_disbursed.php
INFO - 2022-03-15 06:42:52 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 06:42:52 --> Final output sent to browser
DEBUG - 2022-03-15 06:42:52 --> Total execution time: 0.0368
ERROR - 2022-03-15 06:42:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:42:53 --> Config Class Initialized
INFO - 2022-03-15 06:42:53 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:42:53 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:42:53 --> Utf8 Class Initialized
INFO - 2022-03-15 06:42:53 --> URI Class Initialized
INFO - 2022-03-15 06:42:53 --> Router Class Initialized
INFO - 2022-03-15 06:42:53 --> Output Class Initialized
INFO - 2022-03-15 06:42:53 --> Security Class Initialized
DEBUG - 2022-03-15 06:42:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:42:53 --> Input Class Initialized
INFO - 2022-03-15 06:42:53 --> Language Class Initialized
ERROR - 2022-03-15 06:42:53 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-15 06:43:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:43:10 --> Config Class Initialized
INFO - 2022-03-15 06:43:10 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:43:10 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:43:10 --> Utf8 Class Initialized
INFO - 2022-03-15 06:43:10 --> URI Class Initialized
INFO - 2022-03-15 06:43:10 --> Router Class Initialized
INFO - 2022-03-15 06:43:10 --> Output Class Initialized
INFO - 2022-03-15 06:43:10 --> Security Class Initialized
DEBUG - 2022-03-15 06:43:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:43:10 --> Input Class Initialized
INFO - 2022-03-15 06:43:10 --> Language Class Initialized
INFO - 2022-03-15 06:43:10 --> Loader Class Initialized
INFO - 2022-03-15 06:43:10 --> Helper loaded: url_helper
INFO - 2022-03-15 06:43:10 --> Helper loaded: form_helper
INFO - 2022-03-15 06:43:10 --> Helper loaded: common_helper
INFO - 2022-03-15 06:43:10 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:43:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:43:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:43:10 --> Controller Class Initialized
INFO - 2022-03-15 06:43:10 --> Form Validation Class Initialized
INFO - 2022-03-15 06:43:10 --> Model "Case_model" initialized
INFO - 2022-03-15 06:43:10 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 06:43:10 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 06:43:10 --> File loaded: /home3/karoteam/public_html/application/views/cases/edit_sanction_details.php
INFO - 2022-03-15 06:43:10 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 06:43:10 --> Final output sent to browser
DEBUG - 2022-03-15 06:43:10 --> Total execution time: 0.0345
ERROR - 2022-03-15 06:43:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:43:11 --> Config Class Initialized
INFO - 2022-03-15 06:43:11 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:43:11 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:43:11 --> Utf8 Class Initialized
INFO - 2022-03-15 06:43:11 --> URI Class Initialized
INFO - 2022-03-15 06:43:11 --> Router Class Initialized
INFO - 2022-03-15 06:43:11 --> Output Class Initialized
INFO - 2022-03-15 06:43:11 --> Security Class Initialized
DEBUG - 2022-03-15 06:43:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:43:11 --> Input Class Initialized
INFO - 2022-03-15 06:43:11 --> Language Class Initialized
ERROR - 2022-03-15 06:43:11 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-15 06:43:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:43:14 --> Config Class Initialized
INFO - 2022-03-15 06:43:14 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:43:14 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:43:14 --> Utf8 Class Initialized
INFO - 2022-03-15 06:43:14 --> URI Class Initialized
INFO - 2022-03-15 06:43:14 --> Router Class Initialized
INFO - 2022-03-15 06:43:14 --> Output Class Initialized
INFO - 2022-03-15 06:43:14 --> Security Class Initialized
DEBUG - 2022-03-15 06:43:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:43:14 --> Input Class Initialized
INFO - 2022-03-15 06:43:14 --> Language Class Initialized
INFO - 2022-03-15 06:43:14 --> Loader Class Initialized
INFO - 2022-03-15 06:43:14 --> Helper loaded: url_helper
INFO - 2022-03-15 06:43:14 --> Helper loaded: form_helper
INFO - 2022-03-15 06:43:14 --> Helper loaded: common_helper
INFO - 2022-03-15 06:43:14 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:43:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:43:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:43:14 --> Controller Class Initialized
INFO - 2022-03-15 06:43:14 --> Form Validation Class Initialized
INFO - 2022-03-15 06:43:14 --> Model "Case_model" initialized
INFO - 2022-03-15 06:43:14 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 06:43:14 --> Final output sent to browser
DEBUG - 2022-03-15 06:43:14 --> Total execution time: 0.0329
ERROR - 2022-03-15 06:43:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:43:24 --> Config Class Initialized
INFO - 2022-03-15 06:43:24 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:43:24 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:43:24 --> Utf8 Class Initialized
INFO - 2022-03-15 06:43:24 --> URI Class Initialized
INFO - 2022-03-15 06:43:24 --> Router Class Initialized
INFO - 2022-03-15 06:43:24 --> Output Class Initialized
INFO - 2022-03-15 06:43:24 --> Security Class Initialized
DEBUG - 2022-03-15 06:43:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:43:24 --> Input Class Initialized
INFO - 2022-03-15 06:43:24 --> Language Class Initialized
INFO - 2022-03-15 06:43:24 --> Loader Class Initialized
INFO - 2022-03-15 06:43:24 --> Helper loaded: url_helper
INFO - 2022-03-15 06:43:24 --> Helper loaded: form_helper
INFO - 2022-03-15 06:43:24 --> Helper loaded: common_helper
INFO - 2022-03-15 06:43:24 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:43:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:43:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:43:24 --> Controller Class Initialized
INFO - 2022-03-15 06:43:24 --> Form Validation Class Initialized
INFO - 2022-03-15 06:43:24 --> Model "Case_model" initialized
INFO - 2022-03-15 06:43:24 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 06:43:24 --> Final output sent to browser
DEBUG - 2022-03-15 06:43:24 --> Total execution time: 0.0744
ERROR - 2022-03-15 06:43:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:43:26 --> Config Class Initialized
INFO - 2022-03-15 06:43:26 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:43:26 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:43:26 --> Utf8 Class Initialized
INFO - 2022-03-15 06:43:26 --> URI Class Initialized
INFO - 2022-03-15 06:43:26 --> Router Class Initialized
INFO - 2022-03-15 06:43:26 --> Output Class Initialized
INFO - 2022-03-15 06:43:26 --> Security Class Initialized
DEBUG - 2022-03-15 06:43:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:43:26 --> Input Class Initialized
INFO - 2022-03-15 06:43:26 --> Language Class Initialized
INFO - 2022-03-15 06:43:26 --> Loader Class Initialized
INFO - 2022-03-15 06:43:26 --> Helper loaded: url_helper
INFO - 2022-03-15 06:43:26 --> Helper loaded: form_helper
INFO - 2022-03-15 06:43:26 --> Helper loaded: common_helper
INFO - 2022-03-15 06:43:26 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:43:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:43:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:43:26 --> Controller Class Initialized
INFO - 2022-03-15 06:43:26 --> Form Validation Class Initialized
INFO - 2022-03-15 06:43:26 --> Model "Case_model" initialized
INFO - 2022-03-15 06:43:26 --> Model "Patientcase_model" initialized
ERROR - 2022-03-15 06:43:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:43:26 --> Config Class Initialized
INFO - 2022-03-15 06:43:26 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:43:26 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:43:26 --> Utf8 Class Initialized
INFO - 2022-03-15 06:43:26 --> URI Class Initialized
INFO - 2022-03-15 06:43:26 --> Router Class Initialized
INFO - 2022-03-15 06:43:26 --> Output Class Initialized
INFO - 2022-03-15 06:43:26 --> Security Class Initialized
DEBUG - 2022-03-15 06:43:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:43:26 --> Input Class Initialized
INFO - 2022-03-15 06:43:26 --> Language Class Initialized
INFO - 2022-03-15 06:43:26 --> Loader Class Initialized
INFO - 2022-03-15 06:43:26 --> Helper loaded: url_helper
INFO - 2022-03-15 06:43:26 --> Helper loaded: form_helper
INFO - 2022-03-15 06:43:26 --> Helper loaded: common_helper
INFO - 2022-03-15 06:43:26 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:43:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:43:26 --> Final output sent to browser
DEBUG - 2022-03-15 06:43:26 --> Total execution time: 0.0758
INFO - 2022-03-15 06:43:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:43:26 --> Controller Class Initialized
INFO - 2022-03-15 06:43:26 --> Form Validation Class Initialized
INFO - 2022-03-15 06:43:26 --> Model "Case_model" initialized
INFO - 2022-03-15 06:43:26 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 06:43:26 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 06:43:26 --> File loaded: /home3/karoteam/public_html/application/views/cases/edit_sanction_details.php
INFO - 2022-03-15 06:43:26 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 06:43:26 --> Final output sent to browser
DEBUG - 2022-03-15 06:43:26 --> Total execution time: 0.0774
ERROR - 2022-03-15 06:43:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:43:27 --> Config Class Initialized
INFO - 2022-03-15 06:43:27 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:43:27 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:43:27 --> Utf8 Class Initialized
INFO - 2022-03-15 06:43:27 --> URI Class Initialized
INFO - 2022-03-15 06:43:27 --> Router Class Initialized
INFO - 2022-03-15 06:43:27 --> Output Class Initialized
INFO - 2022-03-15 06:43:27 --> Security Class Initialized
DEBUG - 2022-03-15 06:43:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:43:27 --> Input Class Initialized
INFO - 2022-03-15 06:43:27 --> Language Class Initialized
ERROR - 2022-03-15 06:43:27 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-15 06:43:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:43:33 --> Config Class Initialized
INFO - 2022-03-15 06:43:33 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:43:33 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:43:33 --> Utf8 Class Initialized
INFO - 2022-03-15 06:43:33 --> URI Class Initialized
INFO - 2022-03-15 06:43:33 --> Router Class Initialized
INFO - 2022-03-15 06:43:33 --> Output Class Initialized
INFO - 2022-03-15 06:43:33 --> Security Class Initialized
DEBUG - 2022-03-15 06:43:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:43:33 --> Input Class Initialized
INFO - 2022-03-15 06:43:33 --> Language Class Initialized
INFO - 2022-03-15 06:43:33 --> Loader Class Initialized
INFO - 2022-03-15 06:43:33 --> Helper loaded: url_helper
INFO - 2022-03-15 06:43:33 --> Helper loaded: form_helper
INFO - 2022-03-15 06:43:33 --> Helper loaded: common_helper
INFO - 2022-03-15 06:43:33 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:43:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:43:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:43:33 --> Controller Class Initialized
INFO - 2022-03-15 06:43:33 --> Form Validation Class Initialized
INFO - 2022-03-15 06:43:33 --> Model "Case_model" initialized
INFO - 2022-03-15 06:43:33 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 06:43:33 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 06:43:33 --> File loaded: /home3/karoteam/public_html/application/views/cases/patient_amount_disbursed.php
INFO - 2022-03-15 06:43:33 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 06:43:33 --> Final output sent to browser
DEBUG - 2022-03-15 06:43:33 --> Total execution time: 0.0372
ERROR - 2022-03-15 06:43:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:43:33 --> Config Class Initialized
INFO - 2022-03-15 06:43:33 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:43:33 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:43:33 --> Utf8 Class Initialized
INFO - 2022-03-15 06:43:33 --> URI Class Initialized
INFO - 2022-03-15 06:43:33 --> Router Class Initialized
INFO - 2022-03-15 06:43:33 --> Output Class Initialized
INFO - 2022-03-15 06:43:33 --> Security Class Initialized
DEBUG - 2022-03-15 06:43:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:43:33 --> Input Class Initialized
INFO - 2022-03-15 06:43:33 --> Language Class Initialized
ERROR - 2022-03-15 06:43:33 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-15 06:43:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:43:40 --> Config Class Initialized
INFO - 2022-03-15 06:43:40 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:43:40 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:43:40 --> Utf8 Class Initialized
INFO - 2022-03-15 06:43:40 --> URI Class Initialized
INFO - 2022-03-15 06:43:40 --> Router Class Initialized
INFO - 2022-03-15 06:43:40 --> Output Class Initialized
INFO - 2022-03-15 06:43:40 --> Security Class Initialized
DEBUG - 2022-03-15 06:43:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:43:40 --> Input Class Initialized
INFO - 2022-03-15 06:43:40 --> Language Class Initialized
INFO - 2022-03-15 06:43:40 --> Loader Class Initialized
INFO - 2022-03-15 06:43:40 --> Helper loaded: url_helper
INFO - 2022-03-15 06:43:40 --> Helper loaded: form_helper
INFO - 2022-03-15 06:43:40 --> Helper loaded: common_helper
INFO - 2022-03-15 06:43:40 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:43:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:43:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:43:40 --> Controller Class Initialized
INFO - 2022-03-15 06:43:40 --> Form Validation Class Initialized
INFO - 2022-03-15 06:43:40 --> Model "Case_model" initialized
INFO - 2022-03-15 06:43:40 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 06:43:42 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 06:43:42 --> Model "Case_model" initialized
INFO - 2022-03-15 06:43:44 --> File loaded: /home3/karoteam/public_html/application/views/cases/closed_case.php
INFO - 2022-03-15 06:43:44 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 06:43:45 --> Final output sent to browser
DEBUG - 2022-03-15 06:43:45 --> Total execution time: 3.2299
ERROR - 2022-03-15 06:43:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:43:45 --> Config Class Initialized
INFO - 2022-03-15 06:43:45 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:43:45 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:43:45 --> Utf8 Class Initialized
INFO - 2022-03-15 06:43:45 --> URI Class Initialized
INFO - 2022-03-15 06:43:45 --> Router Class Initialized
INFO - 2022-03-15 06:43:45 --> Output Class Initialized
INFO - 2022-03-15 06:43:45 --> Security Class Initialized
DEBUG - 2022-03-15 06:43:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:43:45 --> Input Class Initialized
INFO - 2022-03-15 06:43:45 --> Language Class Initialized
ERROR - 2022-03-15 06:43:45 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-15 06:43:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:43:54 --> Config Class Initialized
INFO - 2022-03-15 06:43:54 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:43:54 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:43:54 --> Utf8 Class Initialized
INFO - 2022-03-15 06:43:54 --> URI Class Initialized
INFO - 2022-03-15 06:43:54 --> Router Class Initialized
INFO - 2022-03-15 06:43:54 --> Output Class Initialized
INFO - 2022-03-15 06:43:54 --> Security Class Initialized
DEBUG - 2022-03-15 06:43:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:43:54 --> Input Class Initialized
INFO - 2022-03-15 06:43:54 --> Language Class Initialized
INFO - 2022-03-15 06:43:54 --> Loader Class Initialized
INFO - 2022-03-15 06:43:54 --> Helper loaded: url_helper
INFO - 2022-03-15 06:43:54 --> Helper loaded: form_helper
INFO - 2022-03-15 06:43:54 --> Helper loaded: common_helper
INFO - 2022-03-15 06:43:54 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:43:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:43:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:43:54 --> Controller Class Initialized
INFO - 2022-03-15 06:43:54 --> Form Validation Class Initialized
DEBUG - 2022-03-15 06:43:54 --> Encrypt Class Initialized
INFO - 2022-03-15 06:43:54 --> Model "Patient_model" initialized
INFO - 2022-03-15 06:43:54 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 06:43:54 --> Model "Prefix_master" initialized
INFO - 2022-03-15 06:43:54 --> Model "Users_model" initialized
INFO - 2022-03-15 06:43:54 --> Model "Hospital_model" initialized
INFO - 2022-03-15 06:43:54 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 06:43:54 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-15 06:43:54 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 06:43:54 --> Final output sent to browser
DEBUG - 2022-03-15 06:43:54 --> Total execution time: 0.0575
ERROR - 2022-03-15 06:43:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:43:54 --> Config Class Initialized
INFO - 2022-03-15 06:43:54 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:43:54 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:43:54 --> Utf8 Class Initialized
INFO - 2022-03-15 06:43:54 --> URI Class Initialized
INFO - 2022-03-15 06:43:54 --> Router Class Initialized
INFO - 2022-03-15 06:43:54 --> Output Class Initialized
INFO - 2022-03-15 06:43:54 --> Security Class Initialized
DEBUG - 2022-03-15 06:43:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:43:54 --> Input Class Initialized
INFO - 2022-03-15 06:43:54 --> Language Class Initialized
ERROR - 2022-03-15 06:43:54 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-15 06:44:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:44:01 --> Config Class Initialized
INFO - 2022-03-15 06:44:01 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:44:01 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:44:01 --> Utf8 Class Initialized
INFO - 2022-03-15 06:44:01 --> URI Class Initialized
INFO - 2022-03-15 06:44:01 --> Router Class Initialized
INFO - 2022-03-15 06:44:01 --> Output Class Initialized
INFO - 2022-03-15 06:44:01 --> Security Class Initialized
DEBUG - 2022-03-15 06:44:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:44:01 --> Input Class Initialized
INFO - 2022-03-15 06:44:01 --> Language Class Initialized
INFO - 2022-03-15 06:44:01 --> Loader Class Initialized
INFO - 2022-03-15 06:44:01 --> Helper loaded: url_helper
INFO - 2022-03-15 06:44:01 --> Helper loaded: form_helper
INFO - 2022-03-15 06:44:01 --> Helper loaded: common_helper
INFO - 2022-03-15 06:44:01 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:44:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:44:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:44:01 --> Controller Class Initialized
INFO - 2022-03-15 06:44:01 --> Form Validation Class Initialized
INFO - 2022-03-15 06:44:01 --> Model "Case_model" initialized
INFO - 2022-03-15 06:44:01 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 06:44:01 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 06:44:01 --> File loaded: /home3/karoteam/public_html/application/views/cases/rehelp.php
INFO - 2022-03-15 06:44:01 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 06:44:01 --> Final output sent to browser
DEBUG - 2022-03-15 06:44:01 --> Total execution time: 0.0537
ERROR - 2022-03-15 06:44:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:44:02 --> Config Class Initialized
INFO - 2022-03-15 06:44:02 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:44:02 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:44:02 --> Utf8 Class Initialized
INFO - 2022-03-15 06:44:02 --> URI Class Initialized
INFO - 2022-03-15 06:44:02 --> Router Class Initialized
INFO - 2022-03-15 06:44:02 --> Output Class Initialized
INFO - 2022-03-15 06:44:02 --> Security Class Initialized
DEBUG - 2022-03-15 06:44:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:44:02 --> Input Class Initialized
INFO - 2022-03-15 06:44:02 --> Language Class Initialized
ERROR - 2022-03-15 06:44:02 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-15 06:44:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:44:23 --> Config Class Initialized
INFO - 2022-03-15 06:44:23 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:44:23 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:44:23 --> Utf8 Class Initialized
INFO - 2022-03-15 06:44:23 --> URI Class Initialized
INFO - 2022-03-15 06:44:23 --> Router Class Initialized
INFO - 2022-03-15 06:44:23 --> Output Class Initialized
INFO - 2022-03-15 06:44:23 --> Security Class Initialized
DEBUG - 2022-03-15 06:44:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:44:23 --> Input Class Initialized
INFO - 2022-03-15 06:44:23 --> Language Class Initialized
INFO - 2022-03-15 06:44:23 --> Loader Class Initialized
INFO - 2022-03-15 06:44:23 --> Helper loaded: url_helper
INFO - 2022-03-15 06:44:23 --> Helper loaded: form_helper
INFO - 2022-03-15 06:44:23 --> Helper loaded: common_helper
INFO - 2022-03-15 06:44:23 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:44:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:44:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:44:23 --> Controller Class Initialized
INFO - 2022-03-15 06:44:23 --> Form Validation Class Initialized
DEBUG - 2022-03-15 06:44:23 --> Encrypt Class Initialized
INFO - 2022-03-15 06:44:23 --> Model "Patient_model" initialized
INFO - 2022-03-15 06:44:23 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 06:44:23 --> Model "Prefix_master" initialized
INFO - 2022-03-15 06:44:23 --> Model "Users_model" initialized
INFO - 2022-03-15 06:44:23 --> Model "Hospital_model" initialized
ERROR - 2022-03-15 06:44:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:44:23 --> Config Class Initialized
INFO - 2022-03-15 06:44:23 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:44:23 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:44:23 --> Utf8 Class Initialized
INFO - 2022-03-15 06:44:23 --> URI Class Initialized
INFO - 2022-03-15 06:44:23 --> Router Class Initialized
INFO - 2022-03-15 06:44:23 --> Output Class Initialized
INFO - 2022-03-15 06:44:23 --> Security Class Initialized
DEBUG - 2022-03-15 06:44:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:44:23 --> Input Class Initialized
INFO - 2022-03-15 06:44:23 --> Language Class Initialized
INFO - 2022-03-15 06:44:23 --> Loader Class Initialized
INFO - 2022-03-15 06:44:23 --> Helper loaded: url_helper
INFO - 2022-03-15 06:44:23 --> Helper loaded: form_helper
INFO - 2022-03-15 06:44:23 --> Helper loaded: common_helper
INFO - 2022-03-15 06:44:23 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:44:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:44:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:44:23 --> Controller Class Initialized
INFO - 2022-03-15 06:44:23 --> Form Validation Class Initialized
DEBUG - 2022-03-15 06:44:23 --> Encrypt Class Initialized
INFO - 2022-03-15 06:44:23 --> Model "Patient_model" initialized
INFO - 2022-03-15 06:44:23 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 06:44:23 --> Model "Prefix_master" initialized
INFO - 2022-03-15 06:44:23 --> Model "Users_model" initialized
INFO - 2022-03-15 06:44:23 --> Model "Hospital_model" initialized
INFO - 2022-03-15 06:44:23 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 06:44:23 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-15 06:44:23 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 06:44:23 --> Final output sent to browser
DEBUG - 2022-03-15 06:44:23 --> Total execution time: 0.0635
ERROR - 2022-03-15 06:45:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:45:08 --> Config Class Initialized
INFO - 2022-03-15 06:45:08 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:45:08 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:45:08 --> Utf8 Class Initialized
INFO - 2022-03-15 06:45:08 --> URI Class Initialized
INFO - 2022-03-15 06:45:08 --> Router Class Initialized
INFO - 2022-03-15 06:45:08 --> Output Class Initialized
INFO - 2022-03-15 06:45:08 --> Security Class Initialized
DEBUG - 2022-03-15 06:45:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:45:08 --> Input Class Initialized
INFO - 2022-03-15 06:45:08 --> Language Class Initialized
INFO - 2022-03-15 06:45:08 --> Loader Class Initialized
INFO - 2022-03-15 06:45:08 --> Helper loaded: url_helper
INFO - 2022-03-15 06:45:08 --> Helper loaded: form_helper
INFO - 2022-03-15 06:45:08 --> Helper loaded: common_helper
INFO - 2022-03-15 06:45:08 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:45:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:45:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:45:08 --> Controller Class Initialized
INFO - 2022-03-15 06:45:08 --> Form Validation Class Initialized
INFO - 2022-03-15 06:45:08 --> Model "Case_model" initialized
INFO - 2022-03-15 06:45:08 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 06:45:08 --> File loaded: /home3/karoteam/public_html/application/views/transaction/donner_donation.php
INFO - 2022-03-15 06:45:08 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 06:45:08 --> Final output sent to browser
DEBUG - 2022-03-15 06:45:08 --> Total execution time: 0.0402
ERROR - 2022-03-15 06:45:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:45:09 --> Config Class Initialized
INFO - 2022-03-15 06:45:09 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:45:09 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:45:09 --> Utf8 Class Initialized
INFO - 2022-03-15 06:45:09 --> URI Class Initialized
INFO - 2022-03-15 06:45:09 --> Router Class Initialized
INFO - 2022-03-15 06:45:09 --> Output Class Initialized
INFO - 2022-03-15 06:45:09 --> Security Class Initialized
DEBUG - 2022-03-15 06:45:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:45:09 --> Input Class Initialized
INFO - 2022-03-15 06:45:09 --> Language Class Initialized
ERROR - 2022-03-15 06:45:09 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-15 06:50:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:50:48 --> Config Class Initialized
INFO - 2022-03-15 06:50:48 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:50:48 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:50:48 --> Utf8 Class Initialized
INFO - 2022-03-15 06:50:48 --> URI Class Initialized
INFO - 2022-03-15 06:50:48 --> Router Class Initialized
INFO - 2022-03-15 06:50:48 --> Output Class Initialized
INFO - 2022-03-15 06:50:48 --> Security Class Initialized
DEBUG - 2022-03-15 06:50:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:50:48 --> Input Class Initialized
INFO - 2022-03-15 06:50:48 --> Language Class Initialized
INFO - 2022-03-15 06:50:48 --> Loader Class Initialized
INFO - 2022-03-15 06:50:48 --> Helper loaded: url_helper
INFO - 2022-03-15 06:50:48 --> Helper loaded: form_helper
INFO - 2022-03-15 06:50:48 --> Helper loaded: common_helper
INFO - 2022-03-15 06:50:48 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:50:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:50:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:50:48 --> Controller Class Initialized
INFO - 2022-03-15 06:50:48 --> Form Validation Class Initialized
DEBUG - 2022-03-15 06:50:48 --> Encrypt Class Initialized
INFO - 2022-03-15 06:50:48 --> Model "Patient_model" initialized
INFO - 2022-03-15 06:50:48 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 06:50:48 --> Model "Referredby_model" initialized
INFO - 2022-03-15 06:50:48 --> Model "Prefix_master" initialized
INFO - 2022-03-15 06:50:48 --> Model "Hospital_model" initialized
INFO - 2022-03-15 06:50:48 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 06:50:54 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-15 06:50:54 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
ERROR - 2022-03-15 06:50:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:50:55 --> Config Class Initialized
INFO - 2022-03-15 06:50:55 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:50:55 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:50:55 --> Utf8 Class Initialized
INFO - 2022-03-15 06:50:55 --> URI Class Initialized
INFO - 2022-03-15 06:50:55 --> Router Class Initialized
INFO - 2022-03-15 06:50:55 --> Output Class Initialized
INFO - 2022-03-15 06:50:55 --> Security Class Initialized
DEBUG - 2022-03-15 06:50:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:50:55 --> Input Class Initialized
INFO - 2022-03-15 06:50:55 --> Language Class Initialized
ERROR - 2022-03-15 06:50:55 --> 404 Page Not Found: Karoclient/usersprofile
INFO - 2022-03-15 06:50:55 --> Final output sent to browser
DEBUG - 2022-03-15 06:50:55 --> Total execution time: 6.3898
ERROR - 2022-03-15 06:51:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:51:20 --> Config Class Initialized
INFO - 2022-03-15 06:51:20 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:51:20 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:51:20 --> Utf8 Class Initialized
INFO - 2022-03-15 06:51:20 --> URI Class Initialized
INFO - 2022-03-15 06:51:20 --> Router Class Initialized
INFO - 2022-03-15 06:51:20 --> Output Class Initialized
INFO - 2022-03-15 06:51:20 --> Security Class Initialized
DEBUG - 2022-03-15 06:51:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:51:20 --> Input Class Initialized
INFO - 2022-03-15 06:51:20 --> Language Class Initialized
INFO - 2022-03-15 06:51:20 --> Loader Class Initialized
INFO - 2022-03-15 06:51:20 --> Helper loaded: url_helper
INFO - 2022-03-15 06:51:20 --> Helper loaded: form_helper
INFO - 2022-03-15 06:51:20 --> Helper loaded: common_helper
INFO - 2022-03-15 06:51:20 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:51:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:51:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:51:20 --> Controller Class Initialized
INFO - 2022-03-15 06:51:20 --> Form Validation Class Initialized
DEBUG - 2022-03-15 06:51:20 --> Encrypt Class Initialized
INFO - 2022-03-15 06:51:20 --> Model "Patient_model" initialized
INFO - 2022-03-15 06:51:20 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 06:51:20 --> Model "Referredby_model" initialized
INFO - 2022-03-15 06:51:20 --> Model "Prefix_master" initialized
INFO - 2022-03-15 06:51:20 --> Model "Hospital_model" initialized
INFO - 2022-03-15 06:51:20 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 06:51:20 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-15 06:51:20 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 06:51:20 --> Final output sent to browser
DEBUG - 2022-03-15 06:51:20 --> Total execution time: 0.0604
ERROR - 2022-03-15 06:51:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:51:21 --> Config Class Initialized
INFO - 2022-03-15 06:51:21 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:51:21 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:51:21 --> Utf8 Class Initialized
INFO - 2022-03-15 06:51:21 --> URI Class Initialized
INFO - 2022-03-15 06:51:21 --> Router Class Initialized
INFO - 2022-03-15 06:51:21 --> Output Class Initialized
INFO - 2022-03-15 06:51:21 --> Security Class Initialized
DEBUG - 2022-03-15 06:51:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:51:21 --> Input Class Initialized
INFO - 2022-03-15 06:51:21 --> Language Class Initialized
ERROR - 2022-03-15 06:51:21 --> 404 Page Not Found: Karoclient/images
ERROR - 2022-03-15 06:51:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:51:21 --> Config Class Initialized
INFO - 2022-03-15 06:51:21 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:51:21 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:51:21 --> Utf8 Class Initialized
INFO - 2022-03-15 06:51:21 --> URI Class Initialized
INFO - 2022-03-15 06:51:21 --> Router Class Initialized
INFO - 2022-03-15 06:51:21 --> Output Class Initialized
INFO - 2022-03-15 06:51:21 --> Security Class Initialized
DEBUG - 2022-03-15 06:51:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:51:21 --> Input Class Initialized
INFO - 2022-03-15 06:51:21 --> Language Class Initialized
ERROR - 2022-03-15 06:51:21 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-15 06:51:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:51:46 --> Config Class Initialized
INFO - 2022-03-15 06:51:46 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:51:46 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:51:46 --> Utf8 Class Initialized
INFO - 2022-03-15 06:51:46 --> URI Class Initialized
INFO - 2022-03-15 06:51:46 --> Router Class Initialized
INFO - 2022-03-15 06:51:46 --> Output Class Initialized
INFO - 2022-03-15 06:51:46 --> Security Class Initialized
DEBUG - 2022-03-15 06:51:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:51:46 --> Input Class Initialized
INFO - 2022-03-15 06:51:46 --> Language Class Initialized
INFO - 2022-03-15 06:51:46 --> Loader Class Initialized
INFO - 2022-03-15 06:51:46 --> Helper loaded: url_helper
INFO - 2022-03-15 06:51:46 --> Helper loaded: form_helper
INFO - 2022-03-15 06:51:46 --> Helper loaded: common_helper
INFO - 2022-03-15 06:51:46 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:51:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:51:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:51:46 --> Controller Class Initialized
INFO - 2022-03-15 06:51:46 --> Form Validation Class Initialized
DEBUG - 2022-03-15 06:51:46 --> Encrypt Class Initialized
INFO - 2022-03-15 06:51:46 --> Model "Patient_model" initialized
INFO - 2022-03-15 06:51:46 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 06:51:46 --> Model "Referredby_model" initialized
INFO - 2022-03-15 06:51:46 --> Model "Prefix_master" initialized
INFO - 2022-03-15 06:51:46 --> Model "Hospital_model" initialized
INFO - 2022-03-15 06:51:46 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 06:51:52 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-15 06:51:52 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
ERROR - 2022-03-15 06:51:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:51:53 --> Config Class Initialized
INFO - 2022-03-15 06:51:53 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:51:53 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:51:53 --> Utf8 Class Initialized
INFO - 2022-03-15 06:51:53 --> URI Class Initialized
INFO - 2022-03-15 06:51:53 --> Router Class Initialized
INFO - 2022-03-15 06:51:53 --> Output Class Initialized
INFO - 2022-03-15 06:51:53 --> Security Class Initialized
DEBUG - 2022-03-15 06:51:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:51:53 --> Input Class Initialized
INFO - 2022-03-15 06:51:53 --> Language Class Initialized
ERROR - 2022-03-15 06:51:53 --> 404 Page Not Found: Karoclient/usersprofile
INFO - 2022-03-15 06:51:54 --> Final output sent to browser
DEBUG - 2022-03-15 06:51:54 --> Total execution time: 6.7022
ERROR - 2022-03-15 06:52:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:52:21 --> Config Class Initialized
INFO - 2022-03-15 06:52:21 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:52:21 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:52:21 --> Utf8 Class Initialized
INFO - 2022-03-15 06:52:21 --> URI Class Initialized
INFO - 2022-03-15 06:52:21 --> Router Class Initialized
INFO - 2022-03-15 06:52:21 --> Output Class Initialized
INFO - 2022-03-15 06:52:21 --> Security Class Initialized
DEBUG - 2022-03-15 06:52:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:52:21 --> Input Class Initialized
INFO - 2022-03-15 06:52:21 --> Language Class Initialized
INFO - 2022-03-15 06:52:21 --> Loader Class Initialized
INFO - 2022-03-15 06:52:21 --> Helper loaded: url_helper
INFO - 2022-03-15 06:52:21 --> Helper loaded: form_helper
INFO - 2022-03-15 06:52:21 --> Helper loaded: common_helper
INFO - 2022-03-15 06:52:21 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:52:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:52:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:52:21 --> Controller Class Initialized
INFO - 2022-03-15 06:52:21 --> Form Validation Class Initialized
DEBUG - 2022-03-15 06:52:21 --> Encrypt Class Initialized
INFO - 2022-03-15 06:52:21 --> Model "Patient_model" initialized
INFO - 2022-03-15 06:52:21 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 06:52:21 --> Model "Prefix_master" initialized
INFO - 2022-03-15 06:52:21 --> Model "Users_model" initialized
INFO - 2022-03-15 06:52:21 --> Model "Hospital_model" initialized
INFO - 2022-03-15 06:52:21 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
ERROR - 2022-03-15 06:52:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:52:22 --> Config Class Initialized
INFO - 2022-03-15 06:52:22 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:52:22 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:52:22 --> Utf8 Class Initialized
INFO - 2022-03-15 06:52:22 --> URI Class Initialized
INFO - 2022-03-15 06:52:22 --> Router Class Initialized
INFO - 2022-03-15 06:52:22 --> Output Class Initialized
INFO - 2022-03-15 06:52:22 --> Security Class Initialized
DEBUG - 2022-03-15 06:52:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:52:22 --> Input Class Initialized
INFO - 2022-03-15 06:52:22 --> Language Class Initialized
ERROR - 2022-03-15 06:52:22 --> 404 Page Not Found: Karoclient/images
ERROR - 2022-03-15 06:52:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:52:22 --> Config Class Initialized
INFO - 2022-03-15 06:52:22 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:52:22 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:52:22 --> Utf8 Class Initialized
INFO - 2022-03-15 06:52:22 --> URI Class Initialized
INFO - 2022-03-15 06:52:22 --> Router Class Initialized
INFO - 2022-03-15 06:52:22 --> Output Class Initialized
INFO - 2022-03-15 06:52:22 --> Security Class Initialized
DEBUG - 2022-03-15 06:52:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:52:22 --> Input Class Initialized
INFO - 2022-03-15 06:52:22 --> Language Class Initialized
ERROR - 2022-03-15 06:52:22 --> 404 Page Not Found: Karoclient/images
ERROR - 2022-03-15 06:52:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:52:22 --> Config Class Initialized
INFO - 2022-03-15 06:52:22 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:52:22 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:52:22 --> Utf8 Class Initialized
INFO - 2022-03-15 06:52:22 --> URI Class Initialized
INFO - 2022-03-15 06:52:22 --> Router Class Initialized
INFO - 2022-03-15 06:52:22 --> Output Class Initialized
INFO - 2022-03-15 06:52:22 --> Security Class Initialized
DEBUG - 2022-03-15 06:52:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:52:22 --> Input Class Initialized
INFO - 2022-03-15 06:52:22 --> Language Class Initialized
ERROR - 2022-03-15 06:52:22 --> 404 Page Not Found: Karoclient/images
INFO - 2022-03-15 06:52:23 --> Final output sent to browser
DEBUG - 2022-03-15 06:52:23 --> Total execution time: 1.6735
ERROR - 2022-03-15 06:55:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:55:26 --> Config Class Initialized
INFO - 2022-03-15 06:55:26 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:55:26 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:55:26 --> Utf8 Class Initialized
INFO - 2022-03-15 06:55:26 --> URI Class Initialized
INFO - 2022-03-15 06:55:26 --> Router Class Initialized
INFO - 2022-03-15 06:55:26 --> Output Class Initialized
INFO - 2022-03-15 06:55:26 --> Security Class Initialized
DEBUG - 2022-03-15 06:55:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:55:26 --> Input Class Initialized
INFO - 2022-03-15 06:55:26 --> Language Class Initialized
INFO - 2022-03-15 06:55:26 --> Loader Class Initialized
INFO - 2022-03-15 06:55:26 --> Helper loaded: url_helper
INFO - 2022-03-15 06:55:26 --> Helper loaded: form_helper
INFO - 2022-03-15 06:55:26 --> Helper loaded: common_helper
INFO - 2022-03-15 06:55:26 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:55:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:55:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:55:26 --> Controller Class Initialized
INFO - 2022-03-15 06:55:26 --> Form Validation Class Initialized
DEBUG - 2022-03-15 06:55:26 --> Encrypt Class Initialized
INFO - 2022-03-15 06:55:26 --> Model "Patient_model" initialized
INFO - 2022-03-15 06:55:26 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 06:55:26 --> Model "Referredby_model" initialized
INFO - 2022-03-15 06:55:26 --> Model "Prefix_master" initialized
INFO - 2022-03-15 06:55:26 --> Model "Hospital_model" initialized
INFO - 2022-03-15 06:55:26 --> Final output sent to browser
DEBUG - 2022-03-15 06:55:26 --> Total execution time: 0.0369
ERROR - 2022-03-15 06:55:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:55:28 --> Config Class Initialized
INFO - 2022-03-15 06:55:28 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:55:28 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:55:28 --> Utf8 Class Initialized
INFO - 2022-03-15 06:55:28 --> URI Class Initialized
INFO - 2022-03-15 06:55:28 --> Router Class Initialized
INFO - 2022-03-15 06:55:28 --> Output Class Initialized
INFO - 2022-03-15 06:55:28 --> Security Class Initialized
DEBUG - 2022-03-15 06:55:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:55:28 --> Input Class Initialized
INFO - 2022-03-15 06:55:28 --> Language Class Initialized
INFO - 2022-03-15 06:55:28 --> Loader Class Initialized
INFO - 2022-03-15 06:55:28 --> Helper loaded: url_helper
INFO - 2022-03-15 06:55:28 --> Helper loaded: form_helper
INFO - 2022-03-15 06:55:28 --> Helper loaded: common_helper
INFO - 2022-03-15 06:55:28 --> Database Driver Class Initialized
DEBUG - 2022-03-15 06:55:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 06:55:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 06:55:28 --> Controller Class Initialized
INFO - 2022-03-15 06:55:28 --> Form Validation Class Initialized
DEBUG - 2022-03-15 06:55:28 --> Encrypt Class Initialized
INFO - 2022-03-15 06:55:28 --> Model "Patient_model" initialized
INFO - 2022-03-15 06:55:28 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 06:55:28 --> Model "Referredby_model" initialized
INFO - 2022-03-15 06:55:28 --> Model "Prefix_master" initialized
INFO - 2022-03-15 06:55:28 --> Model "Hospital_model" initialized
INFO - 2022-03-15 06:55:28 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 06:55:28 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-15 06:55:28 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 06:55:28 --> Final output sent to browser
DEBUG - 2022-03-15 06:55:28 --> Total execution time: 0.0287
ERROR - 2022-03-15 06:55:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 06:55:29 --> Config Class Initialized
INFO - 2022-03-15 06:55:29 --> Hooks Class Initialized
DEBUG - 2022-03-15 06:55:29 --> UTF-8 Support Enabled
INFO - 2022-03-15 06:55:29 --> Utf8 Class Initialized
INFO - 2022-03-15 06:55:29 --> URI Class Initialized
INFO - 2022-03-15 06:55:29 --> Router Class Initialized
INFO - 2022-03-15 06:55:29 --> Output Class Initialized
INFO - 2022-03-15 06:55:29 --> Security Class Initialized
DEBUG - 2022-03-15 06:55:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 06:55:29 --> Input Class Initialized
INFO - 2022-03-15 06:55:29 --> Language Class Initialized
ERROR - 2022-03-15 06:55:29 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-15 07:11:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 07:11:26 --> Config Class Initialized
INFO - 2022-03-15 07:11:26 --> Hooks Class Initialized
DEBUG - 2022-03-15 07:11:26 --> UTF-8 Support Enabled
INFO - 2022-03-15 07:11:26 --> Utf8 Class Initialized
INFO - 2022-03-15 07:11:26 --> URI Class Initialized
INFO - 2022-03-15 07:11:26 --> Router Class Initialized
INFO - 2022-03-15 07:11:26 --> Output Class Initialized
INFO - 2022-03-15 07:11:26 --> Security Class Initialized
DEBUG - 2022-03-15 07:11:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 07:11:26 --> Input Class Initialized
INFO - 2022-03-15 07:11:26 --> Language Class Initialized
INFO - 2022-03-15 07:11:26 --> Loader Class Initialized
INFO - 2022-03-15 07:11:26 --> Helper loaded: url_helper
INFO - 2022-03-15 07:11:26 --> Helper loaded: form_helper
INFO - 2022-03-15 07:11:26 --> Helper loaded: common_helper
INFO - 2022-03-15 07:11:26 --> Database Driver Class Initialized
DEBUG - 2022-03-15 07:11:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 07:11:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 07:11:26 --> Controller Class Initialized
INFO - 2022-03-15 07:11:26 --> Form Validation Class Initialized
DEBUG - 2022-03-15 07:11:26 --> Encrypt Class Initialized
INFO - 2022-03-15 07:11:26 --> Model "Login_model" initialized
INFO - 2022-03-15 07:11:26 --> Model "Dashboard_model" initialized
INFO - 2022-03-15 07:11:26 --> Model "Case_model" initialized
INFO - 2022-03-15 07:11:35 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 07:11:47 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2022-03-15 07:11:47 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 07:11:47 --> Final output sent to browser
DEBUG - 2022-03-15 07:11:47 --> Total execution time: 21.0546
ERROR - 2022-03-15 07:11:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 07:11:49 --> Config Class Initialized
INFO - 2022-03-15 07:11:49 --> Hooks Class Initialized
DEBUG - 2022-03-15 07:11:49 --> UTF-8 Support Enabled
INFO - 2022-03-15 07:11:49 --> Utf8 Class Initialized
INFO - 2022-03-15 07:11:49 --> URI Class Initialized
INFO - 2022-03-15 07:11:49 --> Router Class Initialized
INFO - 2022-03-15 07:11:49 --> Output Class Initialized
INFO - 2022-03-15 07:11:49 --> Security Class Initialized
DEBUG - 2022-03-15 07:11:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 07:11:49 --> Input Class Initialized
INFO - 2022-03-15 07:11:49 --> Language Class Initialized
ERROR - 2022-03-15 07:11:49 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-15 07:13:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 07:13:42 --> Config Class Initialized
INFO - 2022-03-15 07:13:42 --> Hooks Class Initialized
DEBUG - 2022-03-15 07:13:42 --> UTF-8 Support Enabled
INFO - 2022-03-15 07:13:42 --> Utf8 Class Initialized
INFO - 2022-03-15 07:13:42 --> URI Class Initialized
INFO - 2022-03-15 07:13:42 --> Router Class Initialized
INFO - 2022-03-15 07:13:42 --> Output Class Initialized
INFO - 2022-03-15 07:13:42 --> Security Class Initialized
DEBUG - 2022-03-15 07:13:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 07:13:42 --> Input Class Initialized
INFO - 2022-03-15 07:13:42 --> Language Class Initialized
INFO - 2022-03-15 07:13:42 --> Loader Class Initialized
INFO - 2022-03-15 07:13:42 --> Helper loaded: url_helper
INFO - 2022-03-15 07:13:42 --> Helper loaded: form_helper
INFO - 2022-03-15 07:13:42 --> Helper loaded: common_helper
INFO - 2022-03-15 07:13:42 --> Database Driver Class Initialized
DEBUG - 2022-03-15 07:13:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 07:13:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 07:13:42 --> Controller Class Initialized
INFO - 2022-03-15 07:13:42 --> Model "Referredby_model" initialized
INFO - 2022-03-15 07:13:42 --> Final output sent to browser
DEBUG - 2022-03-15 07:13:42 --> Total execution time: 0.0308
ERROR - 2022-03-15 07:14:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 07:14:40 --> Config Class Initialized
INFO - 2022-03-15 07:14:40 --> Hooks Class Initialized
DEBUG - 2022-03-15 07:14:40 --> UTF-8 Support Enabled
INFO - 2022-03-15 07:14:40 --> Utf8 Class Initialized
INFO - 2022-03-15 07:14:40 --> URI Class Initialized
INFO - 2022-03-15 07:14:40 --> Router Class Initialized
INFO - 2022-03-15 07:14:40 --> Output Class Initialized
INFO - 2022-03-15 07:14:40 --> Security Class Initialized
DEBUG - 2022-03-15 07:14:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 07:14:40 --> Input Class Initialized
INFO - 2022-03-15 07:14:40 --> Language Class Initialized
INFO - 2022-03-15 07:14:40 --> Loader Class Initialized
INFO - 2022-03-15 07:14:40 --> Helper loaded: url_helper
INFO - 2022-03-15 07:14:40 --> Helper loaded: form_helper
INFO - 2022-03-15 07:14:40 --> Helper loaded: common_helper
INFO - 2022-03-15 07:14:40 --> Database Driver Class Initialized
DEBUG - 2022-03-15 07:14:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 07:14:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 07:14:40 --> Controller Class Initialized
INFO - 2022-03-15 07:14:40 --> Model "Referredby_model" initialized
INFO - 2022-03-15 07:14:40 --> Final output sent to browser
DEBUG - 2022-03-15 07:14:40 --> Total execution time: 0.0253
ERROR - 2022-03-15 07:14:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 07:14:57 --> Config Class Initialized
INFO - 2022-03-15 07:14:57 --> Hooks Class Initialized
DEBUG - 2022-03-15 07:14:57 --> UTF-8 Support Enabled
INFO - 2022-03-15 07:14:57 --> Utf8 Class Initialized
INFO - 2022-03-15 07:14:57 --> URI Class Initialized
INFO - 2022-03-15 07:14:57 --> Router Class Initialized
INFO - 2022-03-15 07:14:57 --> Output Class Initialized
INFO - 2022-03-15 07:14:57 --> Security Class Initialized
DEBUG - 2022-03-15 07:14:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 07:14:57 --> Input Class Initialized
INFO - 2022-03-15 07:14:57 --> Language Class Initialized
INFO - 2022-03-15 07:14:57 --> Loader Class Initialized
INFO - 2022-03-15 07:14:57 --> Helper loaded: url_helper
INFO - 2022-03-15 07:14:57 --> Helper loaded: form_helper
INFO - 2022-03-15 07:14:57 --> Helper loaded: common_helper
INFO - 2022-03-15 07:14:57 --> Database Driver Class Initialized
DEBUG - 2022-03-15 07:14:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 07:14:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 07:14:57 --> Controller Class Initialized
INFO - 2022-03-15 07:14:57 --> Form Validation Class Initialized
DEBUG - 2022-03-15 07:14:57 --> Encrypt Class Initialized
INFO - 2022-03-15 07:14:57 --> Model "Patient_model" initialized
INFO - 2022-03-15 07:14:57 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 07:14:57 --> Model "Referredby_model" initialized
INFO - 2022-03-15 07:14:57 --> Model "Prefix_master" initialized
INFO - 2022-03-15 07:14:57 --> Model "Hospital_model" initialized
INFO - 2022-03-15 07:14:57 --> Final output sent to browser
DEBUG - 2022-03-15 07:14:57 --> Total execution time: 0.0277
ERROR - 2022-03-15 07:15:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 07:15:20 --> Config Class Initialized
INFO - 2022-03-15 07:15:20 --> Hooks Class Initialized
DEBUG - 2022-03-15 07:15:20 --> UTF-8 Support Enabled
INFO - 2022-03-15 07:15:20 --> Utf8 Class Initialized
INFO - 2022-03-15 07:15:20 --> URI Class Initialized
INFO - 2022-03-15 07:15:20 --> Router Class Initialized
INFO - 2022-03-15 07:15:20 --> Output Class Initialized
INFO - 2022-03-15 07:15:20 --> Security Class Initialized
DEBUG - 2022-03-15 07:15:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 07:15:20 --> Input Class Initialized
INFO - 2022-03-15 07:15:20 --> Language Class Initialized
INFO - 2022-03-15 07:15:20 --> Loader Class Initialized
INFO - 2022-03-15 07:15:20 --> Helper loaded: url_helper
INFO - 2022-03-15 07:15:20 --> Helper loaded: form_helper
INFO - 2022-03-15 07:15:20 --> Helper loaded: common_helper
INFO - 2022-03-15 07:15:20 --> Database Driver Class Initialized
DEBUG - 2022-03-15 07:15:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 07:15:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 07:15:20 --> Controller Class Initialized
INFO - 2022-03-15 07:15:20 --> Form Validation Class Initialized
DEBUG - 2022-03-15 07:15:20 --> Encrypt Class Initialized
INFO - 2022-03-15 07:15:20 --> Model "Patient_model" initialized
INFO - 2022-03-15 07:15:20 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 07:15:20 --> Model "Referredby_model" initialized
INFO - 2022-03-15 07:15:20 --> Model "Prefix_master" initialized
INFO - 2022-03-15 07:15:20 --> Model "Hospital_model" initialized
INFO - 2022-03-15 07:15:20 --> Final output sent to browser
DEBUG - 2022-03-15 07:15:20 --> Total execution time: 0.0260
ERROR - 2022-03-15 07:15:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 07:15:20 --> Config Class Initialized
INFO - 2022-03-15 07:15:20 --> Hooks Class Initialized
DEBUG - 2022-03-15 07:15:20 --> UTF-8 Support Enabled
INFO - 2022-03-15 07:15:20 --> Utf8 Class Initialized
INFO - 2022-03-15 07:15:20 --> URI Class Initialized
INFO - 2022-03-15 07:15:20 --> Router Class Initialized
INFO - 2022-03-15 07:15:20 --> Output Class Initialized
INFO - 2022-03-15 07:15:20 --> Security Class Initialized
DEBUG - 2022-03-15 07:15:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 07:15:20 --> Input Class Initialized
INFO - 2022-03-15 07:15:20 --> Language Class Initialized
INFO - 2022-03-15 07:15:20 --> Loader Class Initialized
INFO - 2022-03-15 07:15:20 --> Helper loaded: url_helper
INFO - 2022-03-15 07:15:20 --> Helper loaded: form_helper
INFO - 2022-03-15 07:15:20 --> Helper loaded: common_helper
INFO - 2022-03-15 07:15:20 --> Database Driver Class Initialized
DEBUG - 2022-03-15 07:15:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 07:15:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 07:15:20 --> Controller Class Initialized
INFO - 2022-03-15 07:15:20 --> Form Validation Class Initialized
DEBUG - 2022-03-15 07:15:20 --> Encrypt Class Initialized
INFO - 2022-03-15 07:15:20 --> Model "Patient_model" initialized
INFO - 2022-03-15 07:15:20 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 07:15:20 --> Model "Referredby_model" initialized
INFO - 2022-03-15 07:15:20 --> Model "Prefix_master" initialized
INFO - 2022-03-15 07:15:20 --> Model "Hospital_model" initialized
INFO - 2022-03-15 07:15:20 --> Final output sent to browser
DEBUG - 2022-03-15 07:15:20 --> Total execution time: 0.0367
ERROR - 2022-03-15 07:18:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 07:18:29 --> Config Class Initialized
INFO - 2022-03-15 07:18:29 --> Hooks Class Initialized
DEBUG - 2022-03-15 07:18:29 --> UTF-8 Support Enabled
INFO - 2022-03-15 07:18:29 --> Utf8 Class Initialized
INFO - 2022-03-15 07:18:29 --> URI Class Initialized
INFO - 2022-03-15 07:18:29 --> Router Class Initialized
INFO - 2022-03-15 07:18:29 --> Output Class Initialized
INFO - 2022-03-15 07:18:29 --> Security Class Initialized
DEBUG - 2022-03-15 07:18:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 07:18:29 --> Input Class Initialized
INFO - 2022-03-15 07:18:29 --> Language Class Initialized
INFO - 2022-03-15 07:18:29 --> Loader Class Initialized
INFO - 2022-03-15 07:18:29 --> Helper loaded: url_helper
INFO - 2022-03-15 07:18:29 --> Helper loaded: form_helper
INFO - 2022-03-15 07:18:29 --> Helper loaded: common_helper
INFO - 2022-03-15 07:18:29 --> Database Driver Class Initialized
DEBUG - 2022-03-15 07:18:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 07:18:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 07:18:29 --> Controller Class Initialized
INFO - 2022-03-15 07:18:29 --> Form Validation Class Initialized
DEBUG - 2022-03-15 07:18:29 --> Encrypt Class Initialized
INFO - 2022-03-15 07:18:29 --> Model "Patient_model" initialized
INFO - 2022-03-15 07:18:29 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 07:18:29 --> Model "Referredby_model" initialized
INFO - 2022-03-15 07:18:29 --> Model "Prefix_master" initialized
INFO - 2022-03-15 07:18:29 --> Model "Hospital_model" initialized
ERROR - 2022-03-15 07:18:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 07:18:30 --> Config Class Initialized
INFO - 2022-03-15 07:18:30 --> Hooks Class Initialized
DEBUG - 2022-03-15 07:18:30 --> UTF-8 Support Enabled
INFO - 2022-03-15 07:18:30 --> Utf8 Class Initialized
INFO - 2022-03-15 07:18:30 --> URI Class Initialized
INFO - 2022-03-15 07:18:30 --> Router Class Initialized
INFO - 2022-03-15 07:18:30 --> Output Class Initialized
INFO - 2022-03-15 07:18:30 --> Security Class Initialized
DEBUG - 2022-03-15 07:18:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 07:18:30 --> Input Class Initialized
INFO - 2022-03-15 07:18:30 --> Language Class Initialized
INFO - 2022-03-15 07:18:30 --> Loader Class Initialized
INFO - 2022-03-15 07:18:30 --> Helper loaded: url_helper
INFO - 2022-03-15 07:18:30 --> Helper loaded: form_helper
INFO - 2022-03-15 07:18:30 --> Helper loaded: common_helper
INFO - 2022-03-15 07:18:30 --> Database Driver Class Initialized
DEBUG - 2022-03-15 07:18:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 07:18:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 07:18:30 --> Controller Class Initialized
INFO - 2022-03-15 07:18:30 --> Form Validation Class Initialized
DEBUG - 2022-03-15 07:18:30 --> Encrypt Class Initialized
INFO - 2022-03-15 07:18:30 --> Model "Patient_model" initialized
INFO - 2022-03-15 07:18:30 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 07:18:30 --> Model "Referredby_model" initialized
INFO - 2022-03-15 07:18:30 --> Model "Prefix_master" initialized
INFO - 2022-03-15 07:18:30 --> Model "Hospital_model" initialized
INFO - 2022-03-15 07:18:30 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 07:18:30 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-15 07:18:30 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 07:18:30 --> Final output sent to browser
DEBUG - 2022-03-15 07:18:30 --> Total execution time: 0.0622
ERROR - 2022-03-15 07:18:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 07:18:31 --> Config Class Initialized
INFO - 2022-03-15 07:18:31 --> Hooks Class Initialized
DEBUG - 2022-03-15 07:18:31 --> UTF-8 Support Enabled
INFO - 2022-03-15 07:18:31 --> Utf8 Class Initialized
INFO - 2022-03-15 07:18:31 --> URI Class Initialized
INFO - 2022-03-15 07:18:31 --> Router Class Initialized
INFO - 2022-03-15 07:18:31 --> Output Class Initialized
INFO - 2022-03-15 07:18:31 --> Security Class Initialized
DEBUG - 2022-03-15 07:18:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 07:18:31 --> Input Class Initialized
INFO - 2022-03-15 07:18:31 --> Language Class Initialized
ERROR - 2022-03-15 07:18:31 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-15 07:18:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 07:18:31 --> Config Class Initialized
INFO - 2022-03-15 07:18:31 --> Hooks Class Initialized
DEBUG - 2022-03-15 07:18:31 --> UTF-8 Support Enabled
INFO - 2022-03-15 07:18:31 --> Utf8 Class Initialized
INFO - 2022-03-15 07:18:31 --> URI Class Initialized
INFO - 2022-03-15 07:18:31 --> Router Class Initialized
INFO - 2022-03-15 07:18:31 --> Output Class Initialized
INFO - 2022-03-15 07:18:31 --> Security Class Initialized
DEBUG - 2022-03-15 07:18:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 07:18:31 --> Input Class Initialized
INFO - 2022-03-15 07:18:31 --> Language Class Initialized
INFO - 2022-03-15 07:18:31 --> Loader Class Initialized
INFO - 2022-03-15 07:18:31 --> Helper loaded: url_helper
INFO - 2022-03-15 07:18:31 --> Helper loaded: form_helper
INFO - 2022-03-15 07:18:31 --> Helper loaded: common_helper
INFO - 2022-03-15 07:18:31 --> Database Driver Class Initialized
DEBUG - 2022-03-15 07:18:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 07:18:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 07:18:31 --> Controller Class Initialized
INFO - 2022-03-15 07:18:31 --> Form Validation Class Initialized
DEBUG - 2022-03-15 07:18:31 --> Encrypt Class Initialized
INFO - 2022-03-15 07:18:31 --> Model "Patient_model" initialized
INFO - 2022-03-15 07:18:31 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 07:18:31 --> Model "Prefix_master" initialized
INFO - 2022-03-15 07:18:31 --> Model "Users_model" initialized
INFO - 2022-03-15 07:18:31 --> Model "Hospital_model" initialized
INFO - 2022-03-15 07:18:31 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 07:18:31 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-15 07:18:31 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 07:18:31 --> Final output sent to browser
DEBUG - 2022-03-15 07:18:31 --> Total execution time: 0.0700
ERROR - 2022-03-15 07:18:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 07:18:32 --> Config Class Initialized
INFO - 2022-03-15 07:18:32 --> Hooks Class Initialized
DEBUG - 2022-03-15 07:18:32 --> UTF-8 Support Enabled
INFO - 2022-03-15 07:18:32 --> Utf8 Class Initialized
INFO - 2022-03-15 07:18:32 --> URI Class Initialized
INFO - 2022-03-15 07:18:32 --> Router Class Initialized
INFO - 2022-03-15 07:18:32 --> Output Class Initialized
INFO - 2022-03-15 07:18:32 --> Security Class Initialized
DEBUG - 2022-03-15 07:18:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 07:18:32 --> Input Class Initialized
INFO - 2022-03-15 07:18:32 --> Language Class Initialized
ERROR - 2022-03-15 07:18:32 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-15 07:21:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 07:21:14 --> Config Class Initialized
INFO - 2022-03-15 07:21:14 --> Hooks Class Initialized
DEBUG - 2022-03-15 07:21:14 --> UTF-8 Support Enabled
INFO - 2022-03-15 07:21:14 --> Utf8 Class Initialized
INFO - 2022-03-15 07:21:14 --> URI Class Initialized
INFO - 2022-03-15 07:21:14 --> Router Class Initialized
INFO - 2022-03-15 07:21:14 --> Output Class Initialized
INFO - 2022-03-15 07:21:14 --> Security Class Initialized
DEBUG - 2022-03-15 07:21:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 07:21:14 --> Input Class Initialized
INFO - 2022-03-15 07:21:14 --> Language Class Initialized
INFO - 2022-03-15 07:21:14 --> Loader Class Initialized
INFO - 2022-03-15 07:21:14 --> Helper loaded: url_helper
INFO - 2022-03-15 07:21:14 --> Helper loaded: form_helper
INFO - 2022-03-15 07:21:14 --> Helper loaded: common_helper
INFO - 2022-03-15 07:21:14 --> Database Driver Class Initialized
DEBUG - 2022-03-15 07:21:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 07:21:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 07:21:14 --> Controller Class Initialized
INFO - 2022-03-15 07:21:14 --> Form Validation Class Initialized
DEBUG - 2022-03-15 07:21:14 --> Encrypt Class Initialized
INFO - 2022-03-15 07:21:14 --> Model "Patient_model" initialized
INFO - 2022-03-15 07:21:14 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 07:21:14 --> Model "Prefix_master" initialized
INFO - 2022-03-15 07:21:14 --> Model "Users_model" initialized
INFO - 2022-03-15 07:21:14 --> Model "Hospital_model" initialized
ERROR - 2022-03-15 07:21:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 07:21:14 --> Config Class Initialized
INFO - 2022-03-15 07:21:14 --> Hooks Class Initialized
DEBUG - 2022-03-15 07:21:14 --> UTF-8 Support Enabled
INFO - 2022-03-15 07:21:14 --> Utf8 Class Initialized
INFO - 2022-03-15 07:21:14 --> URI Class Initialized
INFO - 2022-03-15 07:21:14 --> Router Class Initialized
INFO - 2022-03-15 07:21:14 --> Output Class Initialized
INFO - 2022-03-15 07:21:14 --> Security Class Initialized
DEBUG - 2022-03-15 07:21:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 07:21:14 --> Input Class Initialized
INFO - 2022-03-15 07:21:14 --> Language Class Initialized
INFO - 2022-03-15 07:21:14 --> Loader Class Initialized
INFO - 2022-03-15 07:21:14 --> Helper loaded: url_helper
INFO - 2022-03-15 07:21:14 --> Helper loaded: form_helper
INFO - 2022-03-15 07:21:14 --> Helper loaded: common_helper
INFO - 2022-03-15 07:21:14 --> Database Driver Class Initialized
DEBUG - 2022-03-15 07:21:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 07:21:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 07:21:14 --> Controller Class Initialized
INFO - 2022-03-15 07:21:14 --> Form Validation Class Initialized
DEBUG - 2022-03-15 07:21:14 --> Encrypt Class Initialized
INFO - 2022-03-15 07:21:14 --> Model "Patient_model" initialized
INFO - 2022-03-15 07:21:14 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 07:21:14 --> Model "Prefix_master" initialized
INFO - 2022-03-15 07:21:14 --> Model "Users_model" initialized
INFO - 2022-03-15 07:21:14 --> Model "Hospital_model" initialized
INFO - 2022-03-15 07:21:14 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 07:21:14 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-15 07:21:14 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 07:21:14 --> Final output sent to browser
DEBUG - 2022-03-15 07:21:14 --> Total execution time: 0.0708
ERROR - 2022-03-15 07:21:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 07:21:15 --> Config Class Initialized
INFO - 2022-03-15 07:21:15 --> Hooks Class Initialized
DEBUG - 2022-03-15 07:21:15 --> UTF-8 Support Enabled
INFO - 2022-03-15 07:21:15 --> Utf8 Class Initialized
INFO - 2022-03-15 07:21:15 --> URI Class Initialized
INFO - 2022-03-15 07:21:15 --> Router Class Initialized
INFO - 2022-03-15 07:21:15 --> Output Class Initialized
INFO - 2022-03-15 07:21:15 --> Security Class Initialized
DEBUG - 2022-03-15 07:21:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 07:21:15 --> Input Class Initialized
INFO - 2022-03-15 07:21:15 --> Language Class Initialized
ERROR - 2022-03-15 07:21:15 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-15 07:23:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 07:23:35 --> Config Class Initialized
INFO - 2022-03-15 07:23:35 --> Hooks Class Initialized
DEBUG - 2022-03-15 07:23:35 --> UTF-8 Support Enabled
INFO - 2022-03-15 07:23:35 --> Utf8 Class Initialized
INFO - 2022-03-15 07:23:35 --> URI Class Initialized
INFO - 2022-03-15 07:23:35 --> Router Class Initialized
INFO - 2022-03-15 07:23:35 --> Output Class Initialized
INFO - 2022-03-15 07:23:35 --> Security Class Initialized
DEBUG - 2022-03-15 07:23:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 07:23:35 --> Input Class Initialized
INFO - 2022-03-15 07:23:35 --> Language Class Initialized
INFO - 2022-03-15 07:23:35 --> Loader Class Initialized
INFO - 2022-03-15 07:23:35 --> Helper loaded: url_helper
INFO - 2022-03-15 07:23:35 --> Helper loaded: form_helper
INFO - 2022-03-15 07:23:35 --> Helper loaded: common_helper
INFO - 2022-03-15 07:23:35 --> Database Driver Class Initialized
DEBUG - 2022-03-15 07:23:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 07:23:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 07:23:35 --> Controller Class Initialized
INFO - 2022-03-15 07:23:35 --> Form Validation Class Initialized
DEBUG - 2022-03-15 07:23:35 --> Encrypt Class Initialized
INFO - 2022-03-15 07:23:35 --> Model "Patient_model" initialized
INFO - 2022-03-15 07:23:35 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 07:23:35 --> Model "Prefix_master" initialized
INFO - 2022-03-15 07:23:35 --> Model "Users_model" initialized
INFO - 2022-03-15 07:23:35 --> Model "Hospital_model" initialized
ERROR - 2022-03-15 07:23:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 07:23:35 --> Config Class Initialized
INFO - 2022-03-15 07:23:35 --> Hooks Class Initialized
DEBUG - 2022-03-15 07:23:35 --> UTF-8 Support Enabled
INFO - 2022-03-15 07:23:35 --> Utf8 Class Initialized
INFO - 2022-03-15 07:23:35 --> URI Class Initialized
INFO - 2022-03-15 07:23:35 --> Router Class Initialized
INFO - 2022-03-15 07:23:35 --> Output Class Initialized
INFO - 2022-03-15 07:23:35 --> Security Class Initialized
DEBUG - 2022-03-15 07:23:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 07:23:35 --> Input Class Initialized
INFO - 2022-03-15 07:23:35 --> Language Class Initialized
INFO - 2022-03-15 07:23:35 --> Loader Class Initialized
INFO - 2022-03-15 07:23:35 --> Helper loaded: url_helper
INFO - 2022-03-15 07:23:35 --> Helper loaded: form_helper
INFO - 2022-03-15 07:23:35 --> Helper loaded: common_helper
INFO - 2022-03-15 07:23:35 --> Database Driver Class Initialized
DEBUG - 2022-03-15 07:23:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 07:23:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 07:23:35 --> Controller Class Initialized
INFO - 2022-03-15 07:23:35 --> Form Validation Class Initialized
DEBUG - 2022-03-15 07:23:35 --> Encrypt Class Initialized
INFO - 2022-03-15 07:23:35 --> Model "Patient_model" initialized
INFO - 2022-03-15 07:23:35 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 07:23:35 --> Model "Prefix_master" initialized
INFO - 2022-03-15 07:23:35 --> Model "Users_model" initialized
INFO - 2022-03-15 07:23:35 --> Model "Hospital_model" initialized
INFO - 2022-03-15 07:23:35 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 07:23:35 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-15 07:23:35 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 07:23:35 --> Final output sent to browser
DEBUG - 2022-03-15 07:23:35 --> Total execution time: 0.0607
ERROR - 2022-03-15 07:23:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 07:23:36 --> Config Class Initialized
INFO - 2022-03-15 07:23:36 --> Hooks Class Initialized
DEBUG - 2022-03-15 07:23:36 --> UTF-8 Support Enabled
INFO - 2022-03-15 07:23:36 --> Utf8 Class Initialized
INFO - 2022-03-15 07:23:36 --> URI Class Initialized
INFO - 2022-03-15 07:23:36 --> Router Class Initialized
INFO - 2022-03-15 07:23:36 --> Output Class Initialized
INFO - 2022-03-15 07:23:36 --> Security Class Initialized
DEBUG - 2022-03-15 07:23:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 07:23:36 --> Input Class Initialized
INFO - 2022-03-15 07:23:36 --> Language Class Initialized
ERROR - 2022-03-15 07:23:36 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-15 07:24:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 07:24:21 --> Config Class Initialized
INFO - 2022-03-15 07:24:21 --> Hooks Class Initialized
DEBUG - 2022-03-15 07:24:21 --> UTF-8 Support Enabled
INFO - 2022-03-15 07:24:21 --> Utf8 Class Initialized
INFO - 2022-03-15 07:24:21 --> URI Class Initialized
INFO - 2022-03-15 07:24:21 --> Router Class Initialized
INFO - 2022-03-15 07:24:21 --> Output Class Initialized
INFO - 2022-03-15 07:24:21 --> Security Class Initialized
DEBUG - 2022-03-15 07:24:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 07:24:21 --> Input Class Initialized
INFO - 2022-03-15 07:24:21 --> Language Class Initialized
INFO - 2022-03-15 07:24:21 --> Loader Class Initialized
INFO - 2022-03-15 07:24:21 --> Helper loaded: url_helper
INFO - 2022-03-15 07:24:21 --> Helper loaded: form_helper
INFO - 2022-03-15 07:24:21 --> Helper loaded: common_helper
INFO - 2022-03-15 07:24:21 --> Database Driver Class Initialized
DEBUG - 2022-03-15 07:24:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 07:24:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 07:24:21 --> Controller Class Initialized
INFO - 2022-03-15 07:24:21 --> Form Validation Class Initialized
DEBUG - 2022-03-15 07:24:21 --> Encrypt Class Initialized
INFO - 2022-03-15 07:24:21 --> Model "Patient_model" initialized
INFO - 2022-03-15 07:24:21 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 07:24:21 --> Model "Prefix_master" initialized
INFO - 2022-03-15 07:24:21 --> Model "Users_model" initialized
INFO - 2022-03-15 07:24:21 --> Model "Hospital_model" initialized
INFO - 2022-03-15 07:24:21 --> Upload Class Initialized
INFO - 2022-03-15 07:24:21 --> Final output sent to browser
DEBUG - 2022-03-15 07:24:21 --> Total execution time: 0.0732
ERROR - 2022-03-15 07:24:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 07:24:33 --> Config Class Initialized
INFO - 2022-03-15 07:24:33 --> Hooks Class Initialized
DEBUG - 2022-03-15 07:24:33 --> UTF-8 Support Enabled
INFO - 2022-03-15 07:24:33 --> Utf8 Class Initialized
INFO - 2022-03-15 07:24:33 --> URI Class Initialized
INFO - 2022-03-15 07:24:33 --> Router Class Initialized
INFO - 2022-03-15 07:24:33 --> Output Class Initialized
INFO - 2022-03-15 07:24:33 --> Security Class Initialized
DEBUG - 2022-03-15 07:24:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 07:24:33 --> Input Class Initialized
INFO - 2022-03-15 07:24:33 --> Language Class Initialized
INFO - 2022-03-15 07:24:33 --> Loader Class Initialized
INFO - 2022-03-15 07:24:33 --> Helper loaded: url_helper
INFO - 2022-03-15 07:24:33 --> Helper loaded: form_helper
INFO - 2022-03-15 07:24:33 --> Helper loaded: common_helper
INFO - 2022-03-15 07:24:33 --> Database Driver Class Initialized
DEBUG - 2022-03-15 07:24:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 07:24:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 07:24:33 --> Controller Class Initialized
INFO - 2022-03-15 07:24:33 --> Form Validation Class Initialized
DEBUG - 2022-03-15 07:24:33 --> Encrypt Class Initialized
INFO - 2022-03-15 07:24:33 --> Model "Patient_model" initialized
INFO - 2022-03-15 07:24:33 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 07:24:33 --> Model "Prefix_master" initialized
INFO - 2022-03-15 07:24:33 --> Model "Users_model" initialized
INFO - 2022-03-15 07:24:33 --> Model "Hospital_model" initialized
ERROR - 2022-03-15 07:24:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 07:24:34 --> Config Class Initialized
INFO - 2022-03-15 07:24:34 --> Hooks Class Initialized
DEBUG - 2022-03-15 07:24:34 --> UTF-8 Support Enabled
INFO - 2022-03-15 07:24:34 --> Utf8 Class Initialized
INFO - 2022-03-15 07:24:34 --> URI Class Initialized
INFO - 2022-03-15 07:24:34 --> Router Class Initialized
INFO - 2022-03-15 07:24:34 --> Output Class Initialized
INFO - 2022-03-15 07:24:34 --> Security Class Initialized
DEBUG - 2022-03-15 07:24:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 07:24:34 --> Input Class Initialized
INFO - 2022-03-15 07:24:34 --> Language Class Initialized
INFO - 2022-03-15 07:24:34 --> Loader Class Initialized
INFO - 2022-03-15 07:24:34 --> Helper loaded: url_helper
INFO - 2022-03-15 07:24:34 --> Helper loaded: form_helper
INFO - 2022-03-15 07:24:34 --> Helper loaded: common_helper
INFO - 2022-03-15 07:24:34 --> Database Driver Class Initialized
DEBUG - 2022-03-15 07:24:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 07:24:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 07:24:34 --> Controller Class Initialized
INFO - 2022-03-15 07:24:34 --> Form Validation Class Initialized
DEBUG - 2022-03-15 07:24:34 --> Encrypt Class Initialized
INFO - 2022-03-15 07:24:34 --> Model "Patient_model" initialized
INFO - 2022-03-15 07:24:34 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 07:24:34 --> Model "Prefix_master" initialized
INFO - 2022-03-15 07:24:34 --> Model "Users_model" initialized
INFO - 2022-03-15 07:24:34 --> Model "Hospital_model" initialized
INFO - 2022-03-15 07:24:34 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 07:24:34 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-15 07:24:34 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 07:24:34 --> Final output sent to browser
DEBUG - 2022-03-15 07:24:34 --> Total execution time: 0.0822
ERROR - 2022-03-15 07:24:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 07:24:34 --> Config Class Initialized
INFO - 2022-03-15 07:24:34 --> Hooks Class Initialized
DEBUG - 2022-03-15 07:24:34 --> UTF-8 Support Enabled
INFO - 2022-03-15 07:24:34 --> Utf8 Class Initialized
INFO - 2022-03-15 07:24:34 --> URI Class Initialized
INFO - 2022-03-15 07:24:34 --> Router Class Initialized
INFO - 2022-03-15 07:24:34 --> Output Class Initialized
INFO - 2022-03-15 07:24:34 --> Security Class Initialized
DEBUG - 2022-03-15 07:24:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 07:24:34 --> Input Class Initialized
INFO - 2022-03-15 07:24:34 --> Language Class Initialized
ERROR - 2022-03-15 07:24:34 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-15 07:29:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 07:29:11 --> Config Class Initialized
INFO - 2022-03-15 07:29:11 --> Hooks Class Initialized
DEBUG - 2022-03-15 07:29:11 --> UTF-8 Support Enabled
INFO - 2022-03-15 07:29:11 --> Utf8 Class Initialized
INFO - 2022-03-15 07:29:11 --> URI Class Initialized
INFO - 2022-03-15 07:29:11 --> Router Class Initialized
INFO - 2022-03-15 07:29:11 --> Output Class Initialized
INFO - 2022-03-15 07:29:11 --> Security Class Initialized
DEBUG - 2022-03-15 07:29:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 07:29:11 --> Input Class Initialized
INFO - 2022-03-15 07:29:11 --> Language Class Initialized
INFO - 2022-03-15 07:29:11 --> Loader Class Initialized
INFO - 2022-03-15 07:29:11 --> Helper loaded: url_helper
INFO - 2022-03-15 07:29:11 --> Helper loaded: form_helper
INFO - 2022-03-15 07:29:11 --> Helper loaded: common_helper
INFO - 2022-03-15 07:29:11 --> Database Driver Class Initialized
DEBUG - 2022-03-15 07:29:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 07:29:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 07:29:11 --> Controller Class Initialized
INFO - 2022-03-15 07:29:11 --> Form Validation Class Initialized
DEBUG - 2022-03-15 07:29:11 --> Encrypt Class Initialized
INFO - 2022-03-15 07:29:11 --> Model "Patient_model" initialized
INFO - 2022-03-15 07:29:11 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 07:29:11 --> Model "Prefix_master" initialized
INFO - 2022-03-15 07:29:11 --> Model "Users_model" initialized
INFO - 2022-03-15 07:29:11 --> Model "Hospital_model" initialized
ERROR - 2022-03-15 07:29:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 07:29:12 --> Config Class Initialized
INFO - 2022-03-15 07:29:12 --> Hooks Class Initialized
DEBUG - 2022-03-15 07:29:12 --> UTF-8 Support Enabled
INFO - 2022-03-15 07:29:12 --> Utf8 Class Initialized
INFO - 2022-03-15 07:29:12 --> URI Class Initialized
INFO - 2022-03-15 07:29:12 --> Router Class Initialized
INFO - 2022-03-15 07:29:12 --> Output Class Initialized
INFO - 2022-03-15 07:29:12 --> Security Class Initialized
DEBUG - 2022-03-15 07:29:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 07:29:12 --> Input Class Initialized
INFO - 2022-03-15 07:29:12 --> Language Class Initialized
INFO - 2022-03-15 07:29:12 --> Loader Class Initialized
INFO - 2022-03-15 07:29:12 --> Helper loaded: url_helper
INFO - 2022-03-15 07:29:12 --> Helper loaded: form_helper
INFO - 2022-03-15 07:29:12 --> Helper loaded: common_helper
INFO - 2022-03-15 07:29:12 --> Database Driver Class Initialized
DEBUG - 2022-03-15 07:29:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 07:29:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 07:29:12 --> Controller Class Initialized
INFO - 2022-03-15 07:29:12 --> Form Validation Class Initialized
DEBUG - 2022-03-15 07:29:12 --> Encrypt Class Initialized
INFO - 2022-03-15 07:29:12 --> Model "Patient_model" initialized
INFO - 2022-03-15 07:29:12 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 07:29:12 --> Model "Prefix_master" initialized
INFO - 2022-03-15 07:29:12 --> Model "Users_model" initialized
INFO - 2022-03-15 07:29:12 --> Model "Hospital_model" initialized
INFO - 2022-03-15 07:29:12 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 07:29:12 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-15 07:29:12 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 07:29:12 --> Final output sent to browser
DEBUG - 2022-03-15 07:29:12 --> Total execution time: 0.0893
ERROR - 2022-03-15 07:29:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 07:29:13 --> Config Class Initialized
INFO - 2022-03-15 07:29:13 --> Hooks Class Initialized
DEBUG - 2022-03-15 07:29:13 --> UTF-8 Support Enabled
INFO - 2022-03-15 07:29:13 --> Utf8 Class Initialized
INFO - 2022-03-15 07:29:13 --> URI Class Initialized
INFO - 2022-03-15 07:29:13 --> Router Class Initialized
INFO - 2022-03-15 07:29:13 --> Output Class Initialized
INFO - 2022-03-15 07:29:13 --> Security Class Initialized
DEBUG - 2022-03-15 07:29:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 07:29:13 --> Input Class Initialized
INFO - 2022-03-15 07:29:13 --> Language Class Initialized
ERROR - 2022-03-15 07:29:13 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-15 07:31:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 07:31:26 --> Config Class Initialized
INFO - 2022-03-15 07:31:26 --> Hooks Class Initialized
DEBUG - 2022-03-15 07:31:26 --> UTF-8 Support Enabled
INFO - 2022-03-15 07:31:26 --> Utf8 Class Initialized
INFO - 2022-03-15 07:31:26 --> URI Class Initialized
INFO - 2022-03-15 07:31:26 --> Router Class Initialized
INFO - 2022-03-15 07:31:26 --> Output Class Initialized
INFO - 2022-03-15 07:31:26 --> Security Class Initialized
DEBUG - 2022-03-15 07:31:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 07:31:26 --> Input Class Initialized
INFO - 2022-03-15 07:31:26 --> Language Class Initialized
INFO - 2022-03-15 07:31:26 --> Loader Class Initialized
INFO - 2022-03-15 07:31:26 --> Helper loaded: url_helper
INFO - 2022-03-15 07:31:26 --> Helper loaded: form_helper
INFO - 2022-03-15 07:31:26 --> Helper loaded: common_helper
INFO - 2022-03-15 07:31:26 --> Database Driver Class Initialized
DEBUG - 2022-03-15 07:31:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 07:31:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 07:31:26 --> Controller Class Initialized
INFO - 2022-03-15 07:31:26 --> Form Validation Class Initialized
DEBUG - 2022-03-15 07:31:26 --> Encrypt Class Initialized
INFO - 2022-03-15 07:31:26 --> Model "Login_model" initialized
INFO - 2022-03-15 07:31:26 --> Model "Dashboard_model" initialized
INFO - 2022-03-15 07:31:26 --> Model "Case_model" initialized
INFO - 2022-03-15 07:31:36 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 07:31:47 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2022-03-15 07:31:47 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 07:31:47 --> Final output sent to browser
DEBUG - 2022-03-15 07:31:47 --> Total execution time: 21.1739
ERROR - 2022-03-15 07:31:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 07:31:48 --> Config Class Initialized
INFO - 2022-03-15 07:31:48 --> Hooks Class Initialized
DEBUG - 2022-03-15 07:31:48 --> UTF-8 Support Enabled
INFO - 2022-03-15 07:31:48 --> Utf8 Class Initialized
INFO - 2022-03-15 07:31:48 --> URI Class Initialized
INFO - 2022-03-15 07:31:48 --> Router Class Initialized
INFO - 2022-03-15 07:31:48 --> Output Class Initialized
INFO - 2022-03-15 07:31:48 --> Security Class Initialized
DEBUG - 2022-03-15 07:31:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 07:31:48 --> Input Class Initialized
INFO - 2022-03-15 07:31:48 --> Language Class Initialized
ERROR - 2022-03-15 07:31:48 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-15 07:32:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 07:32:55 --> Config Class Initialized
INFO - 2022-03-15 07:32:55 --> Hooks Class Initialized
DEBUG - 2022-03-15 07:32:55 --> UTF-8 Support Enabled
INFO - 2022-03-15 07:32:55 --> Utf8 Class Initialized
INFO - 2022-03-15 07:32:55 --> URI Class Initialized
INFO - 2022-03-15 07:32:55 --> Router Class Initialized
INFO - 2022-03-15 07:32:55 --> Output Class Initialized
INFO - 2022-03-15 07:32:55 --> Security Class Initialized
DEBUG - 2022-03-15 07:32:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 07:32:55 --> Input Class Initialized
INFO - 2022-03-15 07:32:55 --> Language Class Initialized
INFO - 2022-03-15 07:32:55 --> Loader Class Initialized
INFO - 2022-03-15 07:32:55 --> Helper loaded: url_helper
INFO - 2022-03-15 07:32:55 --> Helper loaded: form_helper
INFO - 2022-03-15 07:32:55 --> Helper loaded: common_helper
INFO - 2022-03-15 07:32:55 --> Database Driver Class Initialized
DEBUG - 2022-03-15 07:32:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 07:32:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 07:32:55 --> Controller Class Initialized
INFO - 2022-03-15 07:32:55 --> Form Validation Class Initialized
DEBUG - 2022-03-15 07:32:55 --> Encrypt Class Initialized
INFO - 2022-03-15 07:32:55 --> Model "Patient_model" initialized
INFO - 2022-03-15 07:32:55 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 07:32:55 --> Model "Referredby_model" initialized
INFO - 2022-03-15 07:32:55 --> Model "Prefix_master" initialized
INFO - 2022-03-15 07:32:55 --> Model "Hospital_model" initialized
INFO - 2022-03-15 07:32:55 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 07:32:55 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-15 07:32:55 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 07:32:55 --> Final output sent to browser
DEBUG - 2022-03-15 07:32:55 --> Total execution time: 0.0419
ERROR - 2022-03-15 07:32:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 07:32:56 --> Config Class Initialized
INFO - 2022-03-15 07:32:56 --> Hooks Class Initialized
DEBUG - 2022-03-15 07:32:56 --> UTF-8 Support Enabled
INFO - 2022-03-15 07:32:56 --> Utf8 Class Initialized
INFO - 2022-03-15 07:32:56 --> URI Class Initialized
INFO - 2022-03-15 07:32:56 --> Router Class Initialized
INFO - 2022-03-15 07:32:56 --> Output Class Initialized
INFO - 2022-03-15 07:32:56 --> Security Class Initialized
DEBUG - 2022-03-15 07:32:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 07:32:56 --> Input Class Initialized
INFO - 2022-03-15 07:32:56 --> Language Class Initialized
ERROR - 2022-03-15 07:32:56 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-15 07:33:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 07:33:02 --> Config Class Initialized
INFO - 2022-03-15 07:33:02 --> Hooks Class Initialized
DEBUG - 2022-03-15 07:33:02 --> UTF-8 Support Enabled
INFO - 2022-03-15 07:33:02 --> Utf8 Class Initialized
INFO - 2022-03-15 07:33:02 --> URI Class Initialized
INFO - 2022-03-15 07:33:02 --> Router Class Initialized
INFO - 2022-03-15 07:33:02 --> Output Class Initialized
INFO - 2022-03-15 07:33:02 --> Security Class Initialized
DEBUG - 2022-03-15 07:33:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 07:33:02 --> Input Class Initialized
INFO - 2022-03-15 07:33:02 --> Language Class Initialized
INFO - 2022-03-15 07:33:02 --> Loader Class Initialized
INFO - 2022-03-15 07:33:02 --> Helper loaded: url_helper
INFO - 2022-03-15 07:33:02 --> Helper loaded: form_helper
INFO - 2022-03-15 07:33:02 --> Helper loaded: common_helper
INFO - 2022-03-15 07:33:02 --> Database Driver Class Initialized
DEBUG - 2022-03-15 07:33:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 07:33:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 07:33:02 --> Controller Class Initialized
INFO - 2022-03-15 07:33:02 --> Form Validation Class Initialized
DEBUG - 2022-03-15 07:33:02 --> Encrypt Class Initialized
INFO - 2022-03-15 07:33:02 --> Model "Patient_model" initialized
INFO - 2022-03-15 07:33:02 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 07:33:02 --> Model "Referredby_model" initialized
INFO - 2022-03-15 07:33:02 --> Model "Prefix_master" initialized
INFO - 2022-03-15 07:33:02 --> Model "Hospital_model" initialized
INFO - 2022-03-15 07:33:02 --> Upload Class Initialized
INFO - 2022-03-15 07:33:02 --> Final output sent to browser
DEBUG - 2022-03-15 07:33:02 --> Total execution time: 0.0314
ERROR - 2022-03-15 07:34:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 07:34:13 --> Config Class Initialized
INFO - 2022-03-15 07:34:13 --> Hooks Class Initialized
DEBUG - 2022-03-15 07:34:13 --> UTF-8 Support Enabled
INFO - 2022-03-15 07:34:13 --> Utf8 Class Initialized
INFO - 2022-03-15 07:34:13 --> URI Class Initialized
INFO - 2022-03-15 07:34:13 --> Router Class Initialized
INFO - 2022-03-15 07:34:13 --> Output Class Initialized
INFO - 2022-03-15 07:34:13 --> Security Class Initialized
DEBUG - 2022-03-15 07:34:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 07:34:13 --> Input Class Initialized
INFO - 2022-03-15 07:34:13 --> Language Class Initialized
INFO - 2022-03-15 07:34:13 --> Loader Class Initialized
INFO - 2022-03-15 07:34:13 --> Helper loaded: url_helper
INFO - 2022-03-15 07:34:13 --> Helper loaded: form_helper
INFO - 2022-03-15 07:34:13 --> Helper loaded: common_helper
INFO - 2022-03-15 07:34:13 --> Database Driver Class Initialized
DEBUG - 2022-03-15 07:34:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 07:34:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 07:34:13 --> Controller Class Initialized
INFO - 2022-03-15 07:34:13 --> Form Validation Class Initialized
DEBUG - 2022-03-15 07:34:13 --> Encrypt Class Initialized
INFO - 2022-03-15 07:34:13 --> Model "Patient_model" initialized
INFO - 2022-03-15 07:34:13 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 07:34:13 --> Model "Referredby_model" initialized
INFO - 2022-03-15 07:34:13 --> Model "Prefix_master" initialized
INFO - 2022-03-15 07:34:13 --> Model "Hospital_model" initialized
INFO - 2022-03-15 07:34:13 --> Final output sent to browser
DEBUG - 2022-03-15 07:34:13 --> Total execution time: 0.0513
ERROR - 2022-03-15 07:35:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 07:35:36 --> Config Class Initialized
INFO - 2022-03-15 07:35:36 --> Hooks Class Initialized
DEBUG - 2022-03-15 07:35:36 --> UTF-8 Support Enabled
INFO - 2022-03-15 07:35:36 --> Utf8 Class Initialized
INFO - 2022-03-15 07:35:36 --> URI Class Initialized
INFO - 2022-03-15 07:35:36 --> Router Class Initialized
INFO - 2022-03-15 07:35:36 --> Output Class Initialized
INFO - 2022-03-15 07:35:36 --> Security Class Initialized
DEBUG - 2022-03-15 07:35:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 07:35:36 --> Input Class Initialized
INFO - 2022-03-15 07:35:36 --> Language Class Initialized
INFO - 2022-03-15 07:35:36 --> Loader Class Initialized
INFO - 2022-03-15 07:35:36 --> Helper loaded: url_helper
INFO - 2022-03-15 07:35:36 --> Helper loaded: form_helper
INFO - 2022-03-15 07:35:36 --> Helper loaded: common_helper
INFO - 2022-03-15 07:35:36 --> Database Driver Class Initialized
DEBUG - 2022-03-15 07:35:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 07:35:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 07:35:36 --> Controller Class Initialized
INFO - 2022-03-15 07:35:36 --> Form Validation Class Initialized
DEBUG - 2022-03-15 07:35:36 --> Encrypt Class Initialized
INFO - 2022-03-15 07:35:36 --> Model "Patient_model" initialized
INFO - 2022-03-15 07:35:36 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 07:35:36 --> Model "Referredby_model" initialized
INFO - 2022-03-15 07:35:36 --> Model "Prefix_master" initialized
INFO - 2022-03-15 07:35:36 --> Model "Hospital_model" initialized
INFO - 2022-03-15 07:35:36 --> Final output sent to browser
DEBUG - 2022-03-15 07:35:36 --> Total execution time: 0.0269
ERROR - 2022-03-15 07:37:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 07:37:31 --> Config Class Initialized
INFO - 2022-03-15 07:37:31 --> Hooks Class Initialized
DEBUG - 2022-03-15 07:37:31 --> UTF-8 Support Enabled
INFO - 2022-03-15 07:37:31 --> Utf8 Class Initialized
INFO - 2022-03-15 07:37:31 --> URI Class Initialized
INFO - 2022-03-15 07:37:31 --> Router Class Initialized
INFO - 2022-03-15 07:37:31 --> Output Class Initialized
INFO - 2022-03-15 07:37:31 --> Security Class Initialized
DEBUG - 2022-03-15 07:37:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 07:37:31 --> Input Class Initialized
INFO - 2022-03-15 07:37:31 --> Language Class Initialized
INFO - 2022-03-15 07:37:31 --> Loader Class Initialized
INFO - 2022-03-15 07:37:31 --> Helper loaded: url_helper
INFO - 2022-03-15 07:37:31 --> Helper loaded: form_helper
INFO - 2022-03-15 07:37:31 --> Helper loaded: common_helper
INFO - 2022-03-15 07:37:31 --> Database Driver Class Initialized
DEBUG - 2022-03-15 07:37:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 07:37:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 07:37:31 --> Controller Class Initialized
INFO - 2022-03-15 07:37:31 --> Form Validation Class Initialized
DEBUG - 2022-03-15 07:37:31 --> Encrypt Class Initialized
DEBUG - 2022-03-15 07:37:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-15 07:37:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-15 07:37:31 --> Email Class Initialized
INFO - 2022-03-15 07:37:31 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-15 07:37:31 --> Calendar Class Initialized
INFO - 2022-03-15 07:37:31 --> Model "Login_model" initialized
ERROR - 2022-03-15 07:37:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 07:37:31 --> Config Class Initialized
INFO - 2022-03-15 07:37:31 --> Hooks Class Initialized
DEBUG - 2022-03-15 07:37:31 --> UTF-8 Support Enabled
INFO - 2022-03-15 07:37:31 --> Utf8 Class Initialized
INFO - 2022-03-15 07:37:31 --> URI Class Initialized
INFO - 2022-03-15 07:37:31 --> Router Class Initialized
INFO - 2022-03-15 07:37:31 --> Output Class Initialized
INFO - 2022-03-15 07:37:31 --> Security Class Initialized
DEBUG - 2022-03-15 07:37:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 07:37:31 --> Input Class Initialized
INFO - 2022-03-15 07:37:31 --> Language Class Initialized
INFO - 2022-03-15 07:37:31 --> Loader Class Initialized
INFO - 2022-03-15 07:37:31 --> Helper loaded: url_helper
INFO - 2022-03-15 07:37:31 --> Helper loaded: form_helper
INFO - 2022-03-15 07:37:31 --> Helper loaded: common_helper
INFO - 2022-03-15 07:37:31 --> Database Driver Class Initialized
DEBUG - 2022-03-15 07:37:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 07:37:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 07:37:31 --> Controller Class Initialized
INFO - 2022-03-15 07:37:31 --> Form Validation Class Initialized
DEBUG - 2022-03-15 07:37:31 --> Encrypt Class Initialized
DEBUG - 2022-03-15 07:37:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-15 07:37:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-15 07:37:31 --> Email Class Initialized
INFO - 2022-03-15 07:37:31 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-15 07:37:31 --> Calendar Class Initialized
INFO - 2022-03-15 07:37:31 --> Model "Login_model" initialized
INFO - 2022-03-15 07:37:31 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-15 07:37:31 --> Final output sent to browser
DEBUG - 2022-03-15 07:37:31 --> Total execution time: 0.0224
ERROR - 2022-03-15 07:38:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 07:38:53 --> Config Class Initialized
INFO - 2022-03-15 07:38:53 --> Hooks Class Initialized
DEBUG - 2022-03-15 07:38:53 --> UTF-8 Support Enabled
INFO - 2022-03-15 07:38:53 --> Utf8 Class Initialized
INFO - 2022-03-15 07:38:53 --> URI Class Initialized
INFO - 2022-03-15 07:38:53 --> Router Class Initialized
INFO - 2022-03-15 07:38:53 --> Output Class Initialized
INFO - 2022-03-15 07:38:53 --> Security Class Initialized
DEBUG - 2022-03-15 07:38:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 07:38:53 --> Input Class Initialized
INFO - 2022-03-15 07:38:53 --> Language Class Initialized
INFO - 2022-03-15 07:38:53 --> Loader Class Initialized
INFO - 2022-03-15 07:38:53 --> Helper loaded: url_helper
INFO - 2022-03-15 07:38:53 --> Helper loaded: form_helper
INFO - 2022-03-15 07:38:53 --> Helper loaded: common_helper
INFO - 2022-03-15 07:38:53 --> Database Driver Class Initialized
DEBUG - 2022-03-15 07:38:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 07:38:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 07:38:53 --> Controller Class Initialized
ERROR - 2022-03-15 07:38:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 07:38:53 --> Config Class Initialized
INFO - 2022-03-15 07:38:53 --> Hooks Class Initialized
INFO - 2022-03-15 07:38:53 --> Form Validation Class Initialized
DEBUG - 2022-03-15 07:38:53 --> Encrypt Class Initialized
DEBUG - 2022-03-15 07:38:53 --> UTF-8 Support Enabled
INFO - 2022-03-15 07:38:53 --> Utf8 Class Initialized
INFO - 2022-03-15 07:38:53 --> Model "Patient_model" initialized
INFO - 2022-03-15 07:38:53 --> URI Class Initialized
INFO - 2022-03-15 07:38:53 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 07:38:53 --> Model "Referredby_model" initialized
INFO - 2022-03-15 07:38:53 --> Model "Prefix_master" initialized
INFO - 2022-03-15 07:38:53 --> Router Class Initialized
INFO - 2022-03-15 07:38:53 --> Model "Hospital_model" initialized
INFO - 2022-03-15 07:38:53 --> Output Class Initialized
INFO - 2022-03-15 07:38:53 --> Security Class Initialized
DEBUG - 2022-03-15 07:38:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 07:38:53 --> Input Class Initialized
INFO - 2022-03-15 07:38:53 --> Language Class Initialized
INFO - 2022-03-15 07:38:53 --> Loader Class Initialized
INFO - 2022-03-15 07:38:53 --> Helper loaded: url_helper
INFO - 2022-03-15 07:38:53 --> Helper loaded: form_helper
INFO - 2022-03-15 07:38:53 --> Helper loaded: common_helper
INFO - 2022-03-15 07:38:53 --> Database Driver Class Initialized
DEBUG - 2022-03-15 07:38:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 07:38:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 07:38:53 --> Controller Class Initialized
INFO - 2022-03-15 07:38:53 --> Form Validation Class Initialized
DEBUG - 2022-03-15 07:38:53 --> Encrypt Class Initialized
INFO - 2022-03-15 07:38:53 --> Model "Patient_model" initialized
INFO - 2022-03-15 07:38:53 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 07:38:53 --> Model "Referredby_model" initialized
INFO - 2022-03-15 07:38:53 --> Model "Prefix_master" initialized
INFO - 2022-03-15 07:38:53 --> Model "Hospital_model" initialized
INFO - 2022-03-15 07:38:53 --> Final output sent to browser
DEBUG - 2022-03-15 07:38:53 --> Total execution time: 0.0364
ERROR - 2022-03-15 07:38:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 07:38:53 --> Config Class Initialized
INFO - 2022-03-15 07:38:53 --> Hooks Class Initialized
DEBUG - 2022-03-15 07:38:53 --> UTF-8 Support Enabled
INFO - 2022-03-15 07:38:53 --> Utf8 Class Initialized
INFO - 2022-03-15 07:38:53 --> URI Class Initialized
INFO - 2022-03-15 07:38:53 --> Router Class Initialized
INFO - 2022-03-15 07:38:53 --> Output Class Initialized
INFO - 2022-03-15 07:38:53 --> Security Class Initialized
DEBUG - 2022-03-15 07:38:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 07:38:53 --> Input Class Initialized
INFO - 2022-03-15 07:38:53 --> Language Class Initialized
INFO - 2022-03-15 07:38:53 --> Loader Class Initialized
INFO - 2022-03-15 07:38:53 --> Helper loaded: url_helper
INFO - 2022-03-15 07:38:53 --> Helper loaded: form_helper
INFO - 2022-03-15 07:38:53 --> Helper loaded: common_helper
INFO - 2022-03-15 07:38:53 --> Database Driver Class Initialized
DEBUG - 2022-03-15 07:38:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 07:38:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 07:38:53 --> Controller Class Initialized
INFO - 2022-03-15 07:38:53 --> Form Validation Class Initialized
DEBUG - 2022-03-15 07:38:53 --> Encrypt Class Initialized
INFO - 2022-03-15 07:38:53 --> Model "Patient_model" initialized
INFO - 2022-03-15 07:38:53 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 07:38:53 --> Model "Referredby_model" initialized
INFO - 2022-03-15 07:38:53 --> Model "Prefix_master" initialized
INFO - 2022-03-15 07:38:53 --> Model "Hospital_model" initialized
INFO - 2022-03-15 07:38:53 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 07:38:53 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-15 07:38:53 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 07:38:53 --> Final output sent to browser
DEBUG - 2022-03-15 07:38:53 --> Total execution time: 0.0602
ERROR - 2022-03-15 07:38:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 07:38:54 --> Config Class Initialized
INFO - 2022-03-15 07:38:54 --> Hooks Class Initialized
DEBUG - 2022-03-15 07:38:54 --> UTF-8 Support Enabled
INFO - 2022-03-15 07:38:54 --> Utf8 Class Initialized
INFO - 2022-03-15 07:38:54 --> URI Class Initialized
INFO - 2022-03-15 07:38:54 --> Router Class Initialized
INFO - 2022-03-15 07:38:54 --> Output Class Initialized
INFO - 2022-03-15 07:38:54 --> Security Class Initialized
DEBUG - 2022-03-15 07:38:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 07:38:54 --> Input Class Initialized
INFO - 2022-03-15 07:38:54 --> Language Class Initialized
ERROR - 2022-03-15 07:38:54 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-15 07:38:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 07:38:54 --> Config Class Initialized
INFO - 2022-03-15 07:38:54 --> Hooks Class Initialized
DEBUG - 2022-03-15 07:38:54 --> UTF-8 Support Enabled
INFO - 2022-03-15 07:38:54 --> Utf8 Class Initialized
INFO - 2022-03-15 07:38:54 --> URI Class Initialized
INFO - 2022-03-15 07:38:54 --> Router Class Initialized
INFO - 2022-03-15 07:38:54 --> Output Class Initialized
INFO - 2022-03-15 07:38:54 --> Security Class Initialized
DEBUG - 2022-03-15 07:38:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 07:38:54 --> Input Class Initialized
INFO - 2022-03-15 07:38:54 --> Language Class Initialized
INFO - 2022-03-15 07:38:54 --> Loader Class Initialized
INFO - 2022-03-15 07:38:54 --> Helper loaded: url_helper
INFO - 2022-03-15 07:38:54 --> Helper loaded: form_helper
INFO - 2022-03-15 07:38:54 --> Helper loaded: common_helper
INFO - 2022-03-15 07:38:54 --> Database Driver Class Initialized
DEBUG - 2022-03-15 07:38:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 07:38:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 07:38:54 --> Controller Class Initialized
INFO - 2022-03-15 07:38:54 --> Form Validation Class Initialized
DEBUG - 2022-03-15 07:38:54 --> Encrypt Class Initialized
INFO - 2022-03-15 07:38:54 --> Model "Patient_model" initialized
INFO - 2022-03-15 07:38:54 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 07:38:54 --> Model "Prefix_master" initialized
INFO - 2022-03-15 07:38:54 --> Model "Users_model" initialized
INFO - 2022-03-15 07:38:54 --> Model "Hospital_model" initialized
INFO - 2022-03-15 07:38:55 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 07:38:55 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-15 07:38:55 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 07:38:55 --> Final output sent to browser
DEBUG - 2022-03-15 07:38:55 --> Total execution time: 0.0944
ERROR - 2022-03-15 07:38:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 07:38:55 --> Config Class Initialized
INFO - 2022-03-15 07:38:55 --> Hooks Class Initialized
DEBUG - 2022-03-15 07:38:55 --> UTF-8 Support Enabled
INFO - 2022-03-15 07:38:55 --> Utf8 Class Initialized
INFO - 2022-03-15 07:38:55 --> URI Class Initialized
INFO - 2022-03-15 07:38:55 --> Router Class Initialized
INFO - 2022-03-15 07:38:55 --> Output Class Initialized
INFO - 2022-03-15 07:38:55 --> Security Class Initialized
DEBUG - 2022-03-15 07:38:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 07:38:55 --> Input Class Initialized
INFO - 2022-03-15 07:38:55 --> Language Class Initialized
ERROR - 2022-03-15 07:38:55 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-15 07:38:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 07:38:59 --> Config Class Initialized
INFO - 2022-03-15 07:38:59 --> Hooks Class Initialized
DEBUG - 2022-03-15 07:38:59 --> UTF-8 Support Enabled
INFO - 2022-03-15 07:38:59 --> Utf8 Class Initialized
INFO - 2022-03-15 07:38:59 --> URI Class Initialized
INFO - 2022-03-15 07:38:59 --> Router Class Initialized
INFO - 2022-03-15 07:38:59 --> Output Class Initialized
INFO - 2022-03-15 07:38:59 --> Security Class Initialized
DEBUG - 2022-03-15 07:38:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 07:38:59 --> Input Class Initialized
INFO - 2022-03-15 07:38:59 --> Language Class Initialized
INFO - 2022-03-15 07:38:59 --> Loader Class Initialized
INFO - 2022-03-15 07:38:59 --> Helper loaded: url_helper
INFO - 2022-03-15 07:38:59 --> Helper loaded: form_helper
INFO - 2022-03-15 07:38:59 --> Helper loaded: common_helper
INFO - 2022-03-15 07:38:59 --> Database Driver Class Initialized
DEBUG - 2022-03-15 07:38:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 07:38:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 07:38:59 --> Controller Class Initialized
INFO - 2022-03-15 07:38:59 --> Form Validation Class Initialized
DEBUG - 2022-03-15 07:38:59 --> Encrypt Class Initialized
INFO - 2022-03-15 07:38:59 --> Model "Patient_model" initialized
INFO - 2022-03-15 07:38:59 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 07:38:59 --> Model "Referredby_model" initialized
INFO - 2022-03-15 07:38:59 --> Model "Prefix_master" initialized
INFO - 2022-03-15 07:38:59 --> Model "Hospital_model" initialized
INFO - 2022-03-15 07:39:00 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 07:39:00 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-15 07:39:00 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-15 07:39:00 --> Final output sent to browser
DEBUG - 2022-03-15 07:39:00 --> Total execution time: 0.0562
ERROR - 2022-03-15 07:39:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 07:39:00 --> Config Class Initialized
INFO - 2022-03-15 07:39:00 --> Hooks Class Initialized
DEBUG - 2022-03-15 07:39:00 --> UTF-8 Support Enabled
INFO - 2022-03-15 07:39:00 --> Utf8 Class Initialized
INFO - 2022-03-15 07:39:00 --> URI Class Initialized
INFO - 2022-03-15 07:39:00 --> Router Class Initialized
INFO - 2022-03-15 07:39:00 --> Output Class Initialized
INFO - 2022-03-15 07:39:00 --> Security Class Initialized
DEBUG - 2022-03-15 07:39:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 07:39:00 --> Input Class Initialized
INFO - 2022-03-15 07:39:00 --> Language Class Initialized
ERROR - 2022-03-15 07:39:00 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-15 07:40:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 07:40:11 --> Config Class Initialized
INFO - 2022-03-15 07:40:11 --> Hooks Class Initialized
DEBUG - 2022-03-15 07:40:11 --> UTF-8 Support Enabled
INFO - 2022-03-15 07:40:11 --> Utf8 Class Initialized
INFO - 2022-03-15 07:40:11 --> URI Class Initialized
INFO - 2022-03-15 07:40:11 --> Router Class Initialized
INFO - 2022-03-15 07:40:11 --> Output Class Initialized
INFO - 2022-03-15 07:40:11 --> Security Class Initialized
DEBUG - 2022-03-15 07:40:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 07:40:11 --> Input Class Initialized
INFO - 2022-03-15 07:40:11 --> Language Class Initialized
INFO - 2022-03-15 07:40:11 --> Loader Class Initialized
INFO - 2022-03-15 07:40:11 --> Helper loaded: url_helper
INFO - 2022-03-15 07:40:11 --> Helper loaded: form_helper
INFO - 2022-03-15 07:40:11 --> Helper loaded: common_helper
INFO - 2022-03-15 07:40:11 --> Database Driver Class Initialized
DEBUG - 2022-03-15 07:40:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 07:40:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 07:40:11 --> Controller Class Initialized
INFO - 2022-03-15 07:40:11 --> Form Validation Class Initialized
DEBUG - 2022-03-15 07:40:11 --> Encrypt Class Initialized
INFO - 2022-03-15 07:40:11 --> Model "Patient_model" initialized
INFO - 2022-03-15 07:40:11 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 07:40:11 --> Model "Referredby_model" initialized
INFO - 2022-03-15 07:40:11 --> Model "Prefix_master" initialized
INFO - 2022-03-15 07:40:11 --> Model "Hospital_model" initialized
INFO - 2022-03-15 07:40:11 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-15 07:40:17 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-15 07:40:17 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
ERROR - 2022-03-15 07:40:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 07:40:18 --> Config Class Initialized
INFO - 2022-03-15 07:40:18 --> Hooks Class Initialized
DEBUG - 2022-03-15 07:40:18 --> UTF-8 Support Enabled
INFO - 2022-03-15 07:40:18 --> Utf8 Class Initialized
INFO - 2022-03-15 07:40:18 --> URI Class Initialized
INFO - 2022-03-15 07:40:18 --> Router Class Initialized
INFO - 2022-03-15 07:40:18 --> Output Class Initialized
INFO - 2022-03-15 07:40:18 --> Security Class Initialized
DEBUG - 2022-03-15 07:40:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 07:40:18 --> Input Class Initialized
INFO - 2022-03-15 07:40:18 --> Language Class Initialized
ERROR - 2022-03-15 07:40:18 --> 404 Page Not Found: Karoclient/usersprofile
INFO - 2022-03-15 07:40:19 --> Final output sent to browser
DEBUG - 2022-03-15 07:40:19 --> Total execution time: 6.0397
ERROR - 2022-03-15 07:41:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 07:41:56 --> Config Class Initialized
INFO - 2022-03-15 07:41:56 --> Hooks Class Initialized
DEBUG - 2022-03-15 07:41:56 --> UTF-8 Support Enabled
INFO - 2022-03-15 07:41:56 --> Utf8 Class Initialized
INFO - 2022-03-15 07:41:56 --> URI Class Initialized
INFO - 2022-03-15 07:41:56 --> Router Class Initialized
INFO - 2022-03-15 07:41:56 --> Output Class Initialized
INFO - 2022-03-15 07:41:56 --> Security Class Initialized
DEBUG - 2022-03-15 07:41:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 07:41:56 --> Input Class Initialized
INFO - 2022-03-15 07:41:56 --> Language Class Initialized
INFO - 2022-03-15 07:41:56 --> Loader Class Initialized
INFO - 2022-03-15 07:41:56 --> Helper loaded: url_helper
INFO - 2022-03-15 07:41:56 --> Helper loaded: form_helper
INFO - 2022-03-15 07:41:56 --> Helper loaded: common_helper
INFO - 2022-03-15 07:41:56 --> Database Driver Class Initialized
DEBUG - 2022-03-15 07:41:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 07:41:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 07:41:56 --> Controller Class Initialized
INFO - 2022-03-15 07:41:56 --> Form Validation Class Initialized
DEBUG - 2022-03-15 07:41:56 --> Encrypt Class Initialized
INFO - 2022-03-15 07:41:56 --> Model "Patient_model" initialized
INFO - 2022-03-15 07:41:56 --> Model "Patientcase_model" initialized
INFO - 2022-03-15 07:41:56 --> Model "Prefix_master" initialized
INFO - 2022-03-15 07:41:56 --> Model "Users_model" initialized
INFO - 2022-03-15 07:41:56 --> Model "Hospital_model" initialized
INFO - 2022-03-15 07:41:57 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-15 07:41:58 --> Final output sent to browser
DEBUG - 2022-03-15 07:41:58 --> Total execution time: 1.3475
ERROR - 2022-03-15 07:44:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 07:44:40 --> Config Class Initialized
INFO - 2022-03-15 07:44:40 --> Hooks Class Initialized
DEBUG - 2022-03-15 07:44:41 --> UTF-8 Support Enabled
INFO - 2022-03-15 07:44:41 --> Utf8 Class Initialized
INFO - 2022-03-15 07:44:41 --> URI Class Initialized
INFO - 2022-03-15 07:44:41 --> Router Class Initialized
INFO - 2022-03-15 07:44:41 --> Output Class Initialized
INFO - 2022-03-15 07:44:41 --> Security Class Initialized
DEBUG - 2022-03-15 07:44:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 07:44:41 --> Input Class Initialized
INFO - 2022-03-15 07:44:41 --> Language Class Initialized
INFO - 2022-03-15 07:44:41 --> Loader Class Initialized
INFO - 2022-03-15 07:44:41 --> Helper loaded: url_helper
INFO - 2022-03-15 07:44:41 --> Helper loaded: form_helper
INFO - 2022-03-15 07:44:41 --> Helper loaded: common_helper
INFO - 2022-03-15 07:44:41 --> Database Driver Class Initialized
DEBUG - 2022-03-15 07:44:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 07:44:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 07:44:41 --> Controller Class Initialized
INFO - 2022-03-15 07:44:41 --> Form Validation Class Initialized
DEBUG - 2022-03-15 07:44:41 --> Encrypt Class Initialized
DEBUG - 2022-03-15 07:44:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-15 07:44:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-15 07:44:41 --> Email Class Initialized
INFO - 2022-03-15 07:44:41 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-15 07:44:41 --> Calendar Class Initialized
INFO - 2022-03-15 07:44:41 --> Model "Login_model" initialized
ERROR - 2022-03-15 07:44:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 07:44:41 --> Config Class Initialized
INFO - 2022-03-15 07:44:41 --> Hooks Class Initialized
DEBUG - 2022-03-15 07:44:41 --> UTF-8 Support Enabled
INFO - 2022-03-15 07:44:41 --> Utf8 Class Initialized
INFO - 2022-03-15 07:44:41 --> URI Class Initialized
INFO - 2022-03-15 07:44:41 --> Router Class Initialized
INFO - 2022-03-15 07:44:41 --> Output Class Initialized
INFO - 2022-03-15 07:44:41 --> Security Class Initialized
DEBUG - 2022-03-15 07:44:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 07:44:41 --> Input Class Initialized
INFO - 2022-03-15 07:44:41 --> Language Class Initialized
INFO - 2022-03-15 07:44:41 --> Loader Class Initialized
INFO - 2022-03-15 07:44:41 --> Helper loaded: url_helper
INFO - 2022-03-15 07:44:41 --> Helper loaded: form_helper
INFO - 2022-03-15 07:44:41 --> Helper loaded: common_helper
INFO - 2022-03-15 07:44:41 --> Database Driver Class Initialized
DEBUG - 2022-03-15 07:44:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 07:44:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 07:44:41 --> Controller Class Initialized
INFO - 2022-03-15 07:44:41 --> Form Validation Class Initialized
DEBUG - 2022-03-15 07:44:41 --> Encrypt Class Initialized
DEBUG - 2022-03-15 07:44:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-15 07:44:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-15 07:44:41 --> Email Class Initialized
INFO - 2022-03-15 07:44:41 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-15 07:44:41 --> Calendar Class Initialized
INFO - 2022-03-15 07:44:41 --> Model "Login_model" initialized
INFO - 2022-03-15 07:44:41 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-15 07:44:41 --> Final output sent to browser
DEBUG - 2022-03-15 07:44:41 --> Total execution time: 0.0240
ERROR - 2022-03-15 09:29:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 09:29:07 --> Config Class Initialized
INFO - 2022-03-15 09:29:07 --> Hooks Class Initialized
DEBUG - 2022-03-15 09:29:07 --> UTF-8 Support Enabled
INFO - 2022-03-15 09:29:07 --> Utf8 Class Initialized
INFO - 2022-03-15 09:29:07 --> URI Class Initialized
DEBUG - 2022-03-15 09:29:07 --> No URI present. Default controller set.
INFO - 2022-03-15 09:29:07 --> Router Class Initialized
INFO - 2022-03-15 09:29:07 --> Output Class Initialized
INFO - 2022-03-15 09:29:07 --> Security Class Initialized
DEBUG - 2022-03-15 09:29:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 09:29:07 --> Input Class Initialized
INFO - 2022-03-15 09:29:07 --> Language Class Initialized
INFO - 2022-03-15 09:29:07 --> Loader Class Initialized
INFO - 2022-03-15 09:29:07 --> Helper loaded: url_helper
INFO - 2022-03-15 09:29:07 --> Helper loaded: form_helper
INFO - 2022-03-15 09:29:07 --> Helper loaded: common_helper
INFO - 2022-03-15 09:29:07 --> Database Driver Class Initialized
DEBUG - 2022-03-15 09:29:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 09:29:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 09:29:07 --> Controller Class Initialized
INFO - 2022-03-15 09:29:07 --> Form Validation Class Initialized
DEBUG - 2022-03-15 09:29:07 --> Encrypt Class Initialized
DEBUG - 2022-03-15 09:29:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-15 09:29:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-15 09:29:07 --> Email Class Initialized
INFO - 2022-03-15 09:29:07 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-15 09:29:07 --> Calendar Class Initialized
INFO - 2022-03-15 09:29:07 --> Model "Login_model" initialized
INFO - 2022-03-15 09:29:07 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-15 09:29:07 --> Final output sent to browser
DEBUG - 2022-03-15 09:29:07 --> Total execution time: 0.0342
ERROR - 2022-03-15 11:20:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 11:20:30 --> Config Class Initialized
INFO - 2022-03-15 11:20:30 --> Hooks Class Initialized
DEBUG - 2022-03-15 11:20:30 --> UTF-8 Support Enabled
INFO - 2022-03-15 11:20:30 --> Utf8 Class Initialized
INFO - 2022-03-15 11:20:30 --> URI Class Initialized
DEBUG - 2022-03-15 11:20:30 --> No URI present. Default controller set.
INFO - 2022-03-15 11:20:30 --> Router Class Initialized
INFO - 2022-03-15 11:20:30 --> Output Class Initialized
INFO - 2022-03-15 11:20:30 --> Security Class Initialized
DEBUG - 2022-03-15 11:20:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 11:20:30 --> Input Class Initialized
INFO - 2022-03-15 11:20:30 --> Language Class Initialized
INFO - 2022-03-15 11:20:30 --> Loader Class Initialized
INFO - 2022-03-15 11:20:30 --> Helper loaded: url_helper
INFO - 2022-03-15 11:20:30 --> Helper loaded: form_helper
INFO - 2022-03-15 11:20:30 --> Helper loaded: common_helper
INFO - 2022-03-15 11:20:30 --> Database Driver Class Initialized
DEBUG - 2022-03-15 11:20:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 11:20:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 11:20:30 --> Controller Class Initialized
INFO - 2022-03-15 11:20:30 --> Form Validation Class Initialized
DEBUG - 2022-03-15 11:20:30 --> Encrypt Class Initialized
DEBUG - 2022-03-15 11:20:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-15 11:20:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-15 11:20:30 --> Email Class Initialized
INFO - 2022-03-15 11:20:30 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-15 11:20:30 --> Calendar Class Initialized
INFO - 2022-03-15 11:20:30 --> Model "Login_model" initialized
INFO - 2022-03-15 11:20:30 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-15 11:20:30 --> Final output sent to browser
DEBUG - 2022-03-15 11:20:30 --> Total execution time: 0.0418
ERROR - 2022-03-15 11:20:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 11:20:38 --> Config Class Initialized
INFO - 2022-03-15 11:20:38 --> Hooks Class Initialized
DEBUG - 2022-03-15 11:20:38 --> UTF-8 Support Enabled
INFO - 2022-03-15 11:20:38 --> Utf8 Class Initialized
INFO - 2022-03-15 11:20:38 --> URI Class Initialized
DEBUG - 2022-03-15 11:20:38 --> No URI present. Default controller set.
INFO - 2022-03-15 11:20:38 --> Router Class Initialized
INFO - 2022-03-15 11:20:38 --> Output Class Initialized
INFO - 2022-03-15 11:20:38 --> Security Class Initialized
DEBUG - 2022-03-15 11:20:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 11:20:38 --> Input Class Initialized
INFO - 2022-03-15 11:20:38 --> Language Class Initialized
INFO - 2022-03-15 11:20:38 --> Loader Class Initialized
INFO - 2022-03-15 11:20:38 --> Helper loaded: url_helper
INFO - 2022-03-15 11:20:38 --> Helper loaded: form_helper
INFO - 2022-03-15 11:20:38 --> Helper loaded: common_helper
INFO - 2022-03-15 11:20:38 --> Database Driver Class Initialized
DEBUG - 2022-03-15 11:20:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 11:20:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 11:20:38 --> Controller Class Initialized
INFO - 2022-03-15 11:20:38 --> Form Validation Class Initialized
DEBUG - 2022-03-15 11:20:38 --> Encrypt Class Initialized
DEBUG - 2022-03-15 11:20:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-15 11:20:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-15 11:20:38 --> Email Class Initialized
INFO - 2022-03-15 11:20:38 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-15 11:20:38 --> Calendar Class Initialized
INFO - 2022-03-15 11:20:38 --> Model "Login_model" initialized
INFO - 2022-03-15 11:20:38 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-15 11:20:38 --> Final output sent to browser
DEBUG - 2022-03-15 11:20:38 --> Total execution time: 0.0369
ERROR - 2022-03-15 11:43:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 11:43:37 --> Config Class Initialized
INFO - 2022-03-15 11:43:37 --> Hooks Class Initialized
DEBUG - 2022-03-15 11:43:37 --> UTF-8 Support Enabled
INFO - 2022-03-15 11:43:37 --> Utf8 Class Initialized
INFO - 2022-03-15 11:43:37 --> URI Class Initialized
DEBUG - 2022-03-15 11:43:37 --> No URI present. Default controller set.
INFO - 2022-03-15 11:43:37 --> Router Class Initialized
INFO - 2022-03-15 11:43:37 --> Output Class Initialized
INFO - 2022-03-15 11:43:37 --> Security Class Initialized
DEBUG - 2022-03-15 11:43:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 11:43:37 --> Input Class Initialized
INFO - 2022-03-15 11:43:37 --> Language Class Initialized
INFO - 2022-03-15 11:43:37 --> Loader Class Initialized
INFO - 2022-03-15 11:43:37 --> Helper loaded: url_helper
INFO - 2022-03-15 11:43:37 --> Helper loaded: form_helper
INFO - 2022-03-15 11:43:37 --> Helper loaded: common_helper
INFO - 2022-03-15 11:43:37 --> Database Driver Class Initialized
DEBUG - 2022-03-15 11:43:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 11:43:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 11:43:37 --> Controller Class Initialized
INFO - 2022-03-15 11:43:37 --> Form Validation Class Initialized
DEBUG - 2022-03-15 11:43:37 --> Encrypt Class Initialized
DEBUG - 2022-03-15 11:43:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-15 11:43:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-15 11:43:37 --> Email Class Initialized
INFO - 2022-03-15 11:43:37 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-15 11:43:37 --> Calendar Class Initialized
INFO - 2022-03-15 11:43:37 --> Model "Login_model" initialized
INFO - 2022-03-15 11:43:37 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-15 11:43:37 --> Final output sent to browser
DEBUG - 2022-03-15 11:43:37 --> Total execution time: 0.0330
ERROR - 2022-03-15 14:24:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 14:24:08 --> Config Class Initialized
INFO - 2022-03-15 14:24:08 --> Hooks Class Initialized
DEBUG - 2022-03-15 14:24:08 --> UTF-8 Support Enabled
INFO - 2022-03-15 14:24:08 --> Utf8 Class Initialized
INFO - 2022-03-15 14:24:08 --> URI Class Initialized
DEBUG - 2022-03-15 14:24:08 --> No URI present. Default controller set.
INFO - 2022-03-15 14:24:08 --> Router Class Initialized
INFO - 2022-03-15 14:24:08 --> Output Class Initialized
INFO - 2022-03-15 14:24:08 --> Security Class Initialized
DEBUG - 2022-03-15 14:24:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 14:24:08 --> Input Class Initialized
INFO - 2022-03-15 14:24:08 --> Language Class Initialized
INFO - 2022-03-15 14:24:08 --> Loader Class Initialized
INFO - 2022-03-15 14:24:08 --> Helper loaded: url_helper
INFO - 2022-03-15 14:24:08 --> Helper loaded: form_helper
INFO - 2022-03-15 14:24:08 --> Helper loaded: common_helper
INFO - 2022-03-15 14:24:08 --> Database Driver Class Initialized
DEBUG - 2022-03-15 14:24:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 14:24:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 14:24:08 --> Controller Class Initialized
INFO - 2022-03-15 14:24:08 --> Form Validation Class Initialized
DEBUG - 2022-03-15 14:24:08 --> Encrypt Class Initialized
DEBUG - 2022-03-15 14:24:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-15 14:24:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-15 14:24:08 --> Email Class Initialized
INFO - 2022-03-15 14:24:08 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-15 14:24:08 --> Calendar Class Initialized
INFO - 2022-03-15 14:24:08 --> Model "Login_model" initialized
INFO - 2022-03-15 14:24:08 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-15 14:24:08 --> Final output sent to browser
DEBUG - 2022-03-15 14:24:08 --> Total execution time: 0.0284
ERROR - 2022-03-15 14:24:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 14:24:09 --> Config Class Initialized
INFO - 2022-03-15 14:24:09 --> Hooks Class Initialized
DEBUG - 2022-03-15 14:24:09 --> UTF-8 Support Enabled
INFO - 2022-03-15 14:24:09 --> Utf8 Class Initialized
INFO - 2022-03-15 14:24:09 --> URI Class Initialized
INFO - 2022-03-15 14:24:09 --> Router Class Initialized
INFO - 2022-03-15 14:24:09 --> Output Class Initialized
INFO - 2022-03-15 14:24:09 --> Security Class Initialized
DEBUG - 2022-03-15 14:24:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 14:24:09 --> Input Class Initialized
INFO - 2022-03-15 14:24:09 --> Language Class Initialized
ERROR - 2022-03-15 14:24:09 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2022-03-15 14:24:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 14:24:17 --> Config Class Initialized
INFO - 2022-03-15 14:24:17 --> Hooks Class Initialized
DEBUG - 2022-03-15 14:24:17 --> UTF-8 Support Enabled
INFO - 2022-03-15 14:24:17 --> Utf8 Class Initialized
INFO - 2022-03-15 14:24:17 --> URI Class Initialized
INFO - 2022-03-15 14:24:17 --> Router Class Initialized
INFO - 2022-03-15 14:24:17 --> Output Class Initialized
INFO - 2022-03-15 14:24:17 --> Security Class Initialized
DEBUG - 2022-03-15 14:24:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 14:24:17 --> Input Class Initialized
INFO - 2022-03-15 14:24:17 --> Language Class Initialized
INFO - 2022-03-15 14:24:17 --> Loader Class Initialized
INFO - 2022-03-15 14:24:17 --> Helper loaded: url_helper
INFO - 2022-03-15 14:24:17 --> Helper loaded: form_helper
INFO - 2022-03-15 14:24:17 --> Helper loaded: common_helper
INFO - 2022-03-15 14:24:17 --> Database Driver Class Initialized
DEBUG - 2022-03-15 14:24:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 14:24:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 14:24:17 --> Controller Class Initialized
INFO - 2022-03-15 14:24:17 --> Form Validation Class Initialized
DEBUG - 2022-03-15 14:24:17 --> Encrypt Class Initialized
DEBUG - 2022-03-15 14:24:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-15 14:24:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-15 14:24:17 --> Email Class Initialized
INFO - 2022-03-15 14:24:17 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-15 14:24:17 --> Calendar Class Initialized
INFO - 2022-03-15 14:24:17 --> Model "Login_model" initialized
INFO - 2022-03-15 14:24:17 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-15 14:24:17 --> Final output sent to browser
DEBUG - 2022-03-15 14:24:17 --> Total execution time: 0.0227
ERROR - 2022-03-15 14:24:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 14:24:17 --> Config Class Initialized
INFO - 2022-03-15 14:24:17 --> Hooks Class Initialized
DEBUG - 2022-03-15 14:24:17 --> UTF-8 Support Enabled
INFO - 2022-03-15 14:24:17 --> Utf8 Class Initialized
INFO - 2022-03-15 14:24:17 --> URI Class Initialized
INFO - 2022-03-15 14:24:17 --> Router Class Initialized
INFO - 2022-03-15 14:24:17 --> Output Class Initialized
INFO - 2022-03-15 14:24:17 --> Security Class Initialized
DEBUG - 2022-03-15 14:24:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 14:24:17 --> Input Class Initialized
INFO - 2022-03-15 14:24:17 --> Language Class Initialized
INFO - 2022-03-15 14:24:17 --> Loader Class Initialized
INFO - 2022-03-15 14:24:17 --> Helper loaded: url_helper
INFO - 2022-03-15 14:24:17 --> Helper loaded: form_helper
INFO - 2022-03-15 14:24:17 --> Helper loaded: common_helper
INFO - 2022-03-15 14:24:17 --> Database Driver Class Initialized
DEBUG - 2022-03-15 14:24:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 14:24:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 14:24:17 --> Controller Class Initialized
INFO - 2022-03-15 14:24:17 --> Form Validation Class Initialized
DEBUG - 2022-03-15 14:24:17 --> Encrypt Class Initialized
DEBUG - 2022-03-15 14:24:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-15 14:24:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-15 14:24:17 --> Email Class Initialized
INFO - 2022-03-15 14:24:17 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-15 14:24:17 --> Calendar Class Initialized
INFO - 2022-03-15 14:24:17 --> Model "Login_model" initialized
ERROR - 2022-03-15 14:24:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 14:24:18 --> Config Class Initialized
INFO - 2022-03-15 14:24:18 --> Hooks Class Initialized
DEBUG - 2022-03-15 14:24:18 --> UTF-8 Support Enabled
INFO - 2022-03-15 14:24:18 --> Utf8 Class Initialized
INFO - 2022-03-15 14:24:18 --> URI Class Initialized
INFO - 2022-03-15 14:24:18 --> Router Class Initialized
INFO - 2022-03-15 14:24:18 --> Output Class Initialized
INFO - 2022-03-15 14:24:18 --> Security Class Initialized
DEBUG - 2022-03-15 14:24:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 14:24:18 --> Input Class Initialized
INFO - 2022-03-15 14:24:18 --> Language Class Initialized
INFO - 2022-03-15 14:24:18 --> Loader Class Initialized
INFO - 2022-03-15 14:24:18 --> Helper loaded: url_helper
INFO - 2022-03-15 14:24:18 --> Helper loaded: form_helper
INFO - 2022-03-15 14:24:18 --> Helper loaded: common_helper
INFO - 2022-03-15 14:24:18 --> Database Driver Class Initialized
DEBUG - 2022-03-15 14:24:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 14:24:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 14:24:18 --> Controller Class Initialized
INFO - 2022-03-15 14:24:18 --> Form Validation Class Initialized
DEBUG - 2022-03-15 14:24:18 --> Encrypt Class Initialized
DEBUG - 2022-03-15 14:24:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-15 14:24:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-15 14:24:18 --> Email Class Initialized
INFO - 2022-03-15 14:24:18 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-15 14:24:18 --> Calendar Class Initialized
INFO - 2022-03-15 14:24:18 --> Model "Login_model" initialized
ERROR - 2022-03-15 14:24:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 14:24:19 --> Config Class Initialized
INFO - 2022-03-15 14:24:19 --> Hooks Class Initialized
DEBUG - 2022-03-15 14:24:19 --> UTF-8 Support Enabled
INFO - 2022-03-15 14:24:19 --> Utf8 Class Initialized
INFO - 2022-03-15 14:24:19 --> URI Class Initialized
DEBUG - 2022-03-15 14:24:19 --> No URI present. Default controller set.
INFO - 2022-03-15 14:24:19 --> Router Class Initialized
INFO - 2022-03-15 14:24:19 --> Output Class Initialized
INFO - 2022-03-15 14:24:19 --> Security Class Initialized
DEBUG - 2022-03-15 14:24:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 14:24:19 --> Input Class Initialized
INFO - 2022-03-15 14:24:19 --> Language Class Initialized
INFO - 2022-03-15 14:24:19 --> Loader Class Initialized
INFO - 2022-03-15 14:24:19 --> Helper loaded: url_helper
INFO - 2022-03-15 14:24:19 --> Helper loaded: form_helper
INFO - 2022-03-15 14:24:19 --> Helper loaded: common_helper
INFO - 2022-03-15 14:24:19 --> Database Driver Class Initialized
DEBUG - 2022-03-15 14:24:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 14:24:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 14:24:19 --> Controller Class Initialized
INFO - 2022-03-15 14:24:19 --> Form Validation Class Initialized
DEBUG - 2022-03-15 14:24:19 --> Encrypt Class Initialized
DEBUG - 2022-03-15 14:24:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-15 14:24:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-15 14:24:19 --> Email Class Initialized
INFO - 2022-03-15 14:24:19 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-15 14:24:19 --> Calendar Class Initialized
INFO - 2022-03-15 14:24:19 --> Model "Login_model" initialized
INFO - 2022-03-15 14:24:19 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-15 14:24:19 --> Final output sent to browser
DEBUG - 2022-03-15 14:24:19 --> Total execution time: 0.0253
ERROR - 2022-03-15 17:19:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 17:19:58 --> Config Class Initialized
INFO - 2022-03-15 17:19:58 --> Hooks Class Initialized
DEBUG - 2022-03-15 17:19:58 --> UTF-8 Support Enabled
INFO - 2022-03-15 17:19:58 --> Utf8 Class Initialized
INFO - 2022-03-15 17:19:58 --> URI Class Initialized
DEBUG - 2022-03-15 17:19:58 --> No URI present. Default controller set.
INFO - 2022-03-15 17:19:58 --> Router Class Initialized
INFO - 2022-03-15 17:19:58 --> Output Class Initialized
INFO - 2022-03-15 17:19:58 --> Security Class Initialized
DEBUG - 2022-03-15 17:19:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 17:19:58 --> Input Class Initialized
INFO - 2022-03-15 17:19:58 --> Language Class Initialized
INFO - 2022-03-15 17:19:58 --> Loader Class Initialized
INFO - 2022-03-15 17:19:58 --> Helper loaded: url_helper
INFO - 2022-03-15 17:19:58 --> Helper loaded: form_helper
INFO - 2022-03-15 17:19:58 --> Helper loaded: common_helper
INFO - 2022-03-15 17:19:58 --> Database Driver Class Initialized
DEBUG - 2022-03-15 17:19:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 17:19:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 17:19:58 --> Controller Class Initialized
INFO - 2022-03-15 17:19:58 --> Form Validation Class Initialized
DEBUG - 2022-03-15 17:19:58 --> Encrypt Class Initialized
DEBUG - 2022-03-15 17:19:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-15 17:19:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-15 17:19:58 --> Email Class Initialized
INFO - 2022-03-15 17:19:58 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-15 17:19:58 --> Calendar Class Initialized
INFO - 2022-03-15 17:19:58 --> Model "Login_model" initialized
INFO - 2022-03-15 17:19:58 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-15 17:19:58 --> Final output sent to browser
DEBUG - 2022-03-15 17:19:58 --> Total execution time: 0.0374
ERROR - 2022-03-15 17:38:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-15 17:38:41 --> Config Class Initialized
INFO - 2022-03-15 17:38:41 --> Hooks Class Initialized
DEBUG - 2022-03-15 17:38:41 --> UTF-8 Support Enabled
INFO - 2022-03-15 17:38:41 --> Utf8 Class Initialized
INFO - 2022-03-15 17:38:41 --> URI Class Initialized
DEBUG - 2022-03-15 17:38:41 --> No URI present. Default controller set.
INFO - 2022-03-15 17:38:41 --> Router Class Initialized
INFO - 2022-03-15 17:38:41 --> Output Class Initialized
INFO - 2022-03-15 17:38:41 --> Security Class Initialized
DEBUG - 2022-03-15 17:38:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-15 17:38:41 --> Input Class Initialized
INFO - 2022-03-15 17:38:41 --> Language Class Initialized
INFO - 2022-03-15 17:38:41 --> Loader Class Initialized
INFO - 2022-03-15 17:38:41 --> Helper loaded: url_helper
INFO - 2022-03-15 17:38:41 --> Helper loaded: form_helper
INFO - 2022-03-15 17:38:41 --> Helper loaded: common_helper
INFO - 2022-03-15 17:38:41 --> Database Driver Class Initialized
DEBUG - 2022-03-15 17:38:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-15 17:38:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-15 17:38:41 --> Controller Class Initialized
INFO - 2022-03-15 17:38:41 --> Form Validation Class Initialized
DEBUG - 2022-03-15 17:38:41 --> Encrypt Class Initialized
DEBUG - 2022-03-15 17:38:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-15 17:38:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-15 17:38:41 --> Email Class Initialized
INFO - 2022-03-15 17:38:41 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-15 17:38:41 --> Calendar Class Initialized
INFO - 2022-03-15 17:38:41 --> Model "Login_model" initialized
INFO - 2022-03-15 17:38:41 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-15 17:38:41 --> Final output sent to browser
DEBUG - 2022-03-15 17:38:41 --> Total execution time: 0.0243
