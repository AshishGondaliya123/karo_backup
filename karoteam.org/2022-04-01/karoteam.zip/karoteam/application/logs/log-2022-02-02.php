<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-02-02 09:09:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-02 09:09:25 --> Config Class Initialized
INFO - 2022-02-02 09:09:25 --> Hooks Class Initialized
DEBUG - 2022-02-02 09:09:25 --> UTF-8 Support Enabled
INFO - 2022-02-02 09:09:25 --> Utf8 Class Initialized
INFO - 2022-02-02 09:09:25 --> URI Class Initialized
DEBUG - 2022-02-02 09:09:25 --> No URI present. Default controller set.
INFO - 2022-02-02 09:09:25 --> Router Class Initialized
INFO - 2022-02-02 09:09:25 --> Output Class Initialized
INFO - 2022-02-02 09:09:25 --> Security Class Initialized
DEBUG - 2022-02-02 09:09:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-02 09:09:25 --> Input Class Initialized
INFO - 2022-02-02 09:09:25 --> Language Class Initialized
INFO - 2022-02-02 09:09:25 --> Loader Class Initialized
INFO - 2022-02-02 09:09:25 --> Helper loaded: url_helper
INFO - 2022-02-02 09:09:25 --> Helper loaded: form_helper
INFO - 2022-02-02 09:09:25 --> Helper loaded: common_helper
INFO - 2022-02-02 09:09:25 --> Database Driver Class Initialized
DEBUG - 2022-02-02 09:09:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-02 09:09:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-02 09:09:25 --> Controller Class Initialized
INFO - 2022-02-02 09:09:25 --> Form Validation Class Initialized
DEBUG - 2022-02-02 09:09:25 --> Encrypt Class Initialized
DEBUG - 2022-02-02 09:09:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-02 09:09:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-02 09:09:25 --> Email Class Initialized
INFO - 2022-02-02 09:09:25 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-02 09:09:25 --> Calendar Class Initialized
INFO - 2022-02-02 09:09:25 --> Model "Login_model" initialized
INFO - 2022-02-02 09:09:25 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-02 09:09:25 --> Final output sent to browser
DEBUG - 2022-02-02 09:09:25 --> Total execution time: 0.0309
ERROR - 2022-02-02 09:58:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-02 09:58:00 --> Config Class Initialized
INFO - 2022-02-02 09:58:00 --> Hooks Class Initialized
DEBUG - 2022-02-02 09:58:00 --> UTF-8 Support Enabled
INFO - 2022-02-02 09:58:00 --> Utf8 Class Initialized
INFO - 2022-02-02 09:58:00 --> URI Class Initialized
DEBUG - 2022-02-02 09:58:00 --> No URI present. Default controller set.
INFO - 2022-02-02 09:58:00 --> Router Class Initialized
INFO - 2022-02-02 09:58:00 --> Output Class Initialized
INFO - 2022-02-02 09:58:00 --> Security Class Initialized
DEBUG - 2022-02-02 09:58:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-02 09:58:00 --> Input Class Initialized
INFO - 2022-02-02 09:58:00 --> Language Class Initialized
INFO - 2022-02-02 09:58:00 --> Loader Class Initialized
INFO - 2022-02-02 09:58:00 --> Helper loaded: url_helper
INFO - 2022-02-02 09:58:00 --> Helper loaded: form_helper
INFO - 2022-02-02 09:58:00 --> Helper loaded: common_helper
INFO - 2022-02-02 09:58:00 --> Database Driver Class Initialized
DEBUG - 2022-02-02 09:58:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-02 09:58:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-02 09:58:00 --> Controller Class Initialized
INFO - 2022-02-02 09:58:00 --> Form Validation Class Initialized
DEBUG - 2022-02-02 09:58:00 --> Encrypt Class Initialized
DEBUG - 2022-02-02 09:58:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-02 09:58:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-02 09:58:00 --> Email Class Initialized
INFO - 2022-02-02 09:58:00 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-02 09:58:00 --> Calendar Class Initialized
INFO - 2022-02-02 09:58:00 --> Model "Login_model" initialized
INFO - 2022-02-02 09:58:00 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-02 09:58:00 --> Final output sent to browser
DEBUG - 2022-02-02 09:58:00 --> Total execution time: 0.0376
ERROR - 2022-02-02 10:16:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-02 10:16:35 --> Config Class Initialized
INFO - 2022-02-02 10:16:35 --> Hooks Class Initialized
DEBUG - 2022-02-02 10:16:35 --> UTF-8 Support Enabled
INFO - 2022-02-02 10:16:35 --> Utf8 Class Initialized
INFO - 2022-02-02 10:16:35 --> URI Class Initialized
DEBUG - 2022-02-02 10:16:35 --> No URI present. Default controller set.
INFO - 2022-02-02 10:16:35 --> Router Class Initialized
INFO - 2022-02-02 10:16:35 --> Output Class Initialized
INFO - 2022-02-02 10:16:35 --> Security Class Initialized
DEBUG - 2022-02-02 10:16:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-02 10:16:35 --> Input Class Initialized
INFO - 2022-02-02 10:16:35 --> Language Class Initialized
INFO - 2022-02-02 10:16:35 --> Loader Class Initialized
INFO - 2022-02-02 10:16:35 --> Helper loaded: url_helper
INFO - 2022-02-02 10:16:35 --> Helper loaded: form_helper
INFO - 2022-02-02 10:16:35 --> Helper loaded: common_helper
INFO - 2022-02-02 10:16:35 --> Database Driver Class Initialized
DEBUG - 2022-02-02 10:16:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-02 10:16:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-02 10:16:35 --> Controller Class Initialized
INFO - 2022-02-02 10:16:35 --> Form Validation Class Initialized
DEBUG - 2022-02-02 10:16:35 --> Encrypt Class Initialized
DEBUG - 2022-02-02 10:16:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-02 10:16:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-02 10:16:35 --> Email Class Initialized
INFO - 2022-02-02 10:16:35 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-02 10:16:35 --> Calendar Class Initialized
INFO - 2022-02-02 10:16:35 --> Model "Login_model" initialized
INFO - 2022-02-02 10:16:35 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-02 10:16:35 --> Final output sent to browser
DEBUG - 2022-02-02 10:16:35 --> Total execution time: 0.0238
ERROR - 2022-02-02 10:17:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-02 10:17:30 --> Config Class Initialized
INFO - 2022-02-02 10:17:30 --> Hooks Class Initialized
DEBUG - 2022-02-02 10:17:30 --> UTF-8 Support Enabled
INFO - 2022-02-02 10:17:30 --> Utf8 Class Initialized
INFO - 2022-02-02 10:17:30 --> URI Class Initialized
DEBUG - 2022-02-02 10:17:30 --> No URI present. Default controller set.
INFO - 2022-02-02 10:17:30 --> Router Class Initialized
INFO - 2022-02-02 10:17:30 --> Output Class Initialized
INFO - 2022-02-02 10:17:30 --> Security Class Initialized
DEBUG - 2022-02-02 10:17:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-02 10:17:30 --> Input Class Initialized
INFO - 2022-02-02 10:17:30 --> Language Class Initialized
INFO - 2022-02-02 10:17:30 --> Loader Class Initialized
INFO - 2022-02-02 10:17:30 --> Helper loaded: url_helper
INFO - 2022-02-02 10:17:30 --> Helper loaded: form_helper
INFO - 2022-02-02 10:17:30 --> Helper loaded: common_helper
INFO - 2022-02-02 10:17:30 --> Database Driver Class Initialized
DEBUG - 2022-02-02 10:17:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-02 10:17:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-02 10:17:30 --> Controller Class Initialized
INFO - 2022-02-02 10:17:30 --> Form Validation Class Initialized
DEBUG - 2022-02-02 10:17:30 --> Encrypt Class Initialized
DEBUG - 2022-02-02 10:17:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-02 10:17:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-02 10:17:30 --> Email Class Initialized
INFO - 2022-02-02 10:17:30 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-02 10:17:30 --> Calendar Class Initialized
INFO - 2022-02-02 10:17:30 --> Model "Login_model" initialized
INFO - 2022-02-02 10:17:30 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-02 10:17:30 --> Final output sent to browser
DEBUG - 2022-02-02 10:17:30 --> Total execution time: 0.0269
ERROR - 2022-02-02 12:24:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-02 12:24:19 --> Config Class Initialized
INFO - 2022-02-02 12:24:19 --> Hooks Class Initialized
DEBUG - 2022-02-02 12:24:19 --> UTF-8 Support Enabled
INFO - 2022-02-02 12:24:19 --> Utf8 Class Initialized
INFO - 2022-02-02 12:24:19 --> URI Class Initialized
DEBUG - 2022-02-02 12:24:19 --> No URI present. Default controller set.
INFO - 2022-02-02 12:24:19 --> Router Class Initialized
INFO - 2022-02-02 12:24:19 --> Output Class Initialized
INFO - 2022-02-02 12:24:19 --> Security Class Initialized
DEBUG - 2022-02-02 12:24:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-02 12:24:19 --> Input Class Initialized
INFO - 2022-02-02 12:24:19 --> Language Class Initialized
INFO - 2022-02-02 12:24:19 --> Loader Class Initialized
INFO - 2022-02-02 12:24:19 --> Helper loaded: url_helper
INFO - 2022-02-02 12:24:19 --> Helper loaded: form_helper
INFO - 2022-02-02 12:24:19 --> Helper loaded: common_helper
INFO - 2022-02-02 12:24:19 --> Database Driver Class Initialized
DEBUG - 2022-02-02 12:24:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-02 12:24:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-02 12:24:19 --> Controller Class Initialized
INFO - 2022-02-02 12:24:19 --> Form Validation Class Initialized
DEBUG - 2022-02-02 12:24:19 --> Encrypt Class Initialized
DEBUG - 2022-02-02 12:24:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-02 12:24:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-02 12:24:19 --> Email Class Initialized
INFO - 2022-02-02 12:24:19 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-02 12:24:19 --> Calendar Class Initialized
INFO - 2022-02-02 12:24:19 --> Model "Login_model" initialized
INFO - 2022-02-02 12:24:19 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-02 12:24:19 --> Final output sent to browser
DEBUG - 2022-02-02 12:24:19 --> Total execution time: 0.0259
ERROR - 2022-02-02 12:24:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-02 12:24:20 --> Config Class Initialized
INFO - 2022-02-02 12:24:20 --> Hooks Class Initialized
DEBUG - 2022-02-02 12:24:20 --> UTF-8 Support Enabled
INFO - 2022-02-02 12:24:20 --> Utf8 Class Initialized
INFO - 2022-02-02 12:24:20 --> URI Class Initialized
DEBUG - 2022-02-02 12:24:20 --> No URI present. Default controller set.
INFO - 2022-02-02 12:24:20 --> Router Class Initialized
INFO - 2022-02-02 12:24:20 --> Output Class Initialized
INFO - 2022-02-02 12:24:20 --> Security Class Initialized
DEBUG - 2022-02-02 12:24:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-02 12:24:20 --> Input Class Initialized
INFO - 2022-02-02 12:24:20 --> Language Class Initialized
INFO - 2022-02-02 12:24:20 --> Loader Class Initialized
INFO - 2022-02-02 12:24:20 --> Helper loaded: url_helper
INFO - 2022-02-02 12:24:20 --> Helper loaded: form_helper
INFO - 2022-02-02 12:24:20 --> Helper loaded: common_helper
INFO - 2022-02-02 12:24:20 --> Database Driver Class Initialized
DEBUG - 2022-02-02 12:24:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-02 12:24:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-02 12:24:20 --> Controller Class Initialized
INFO - 2022-02-02 12:24:20 --> Form Validation Class Initialized
DEBUG - 2022-02-02 12:24:20 --> Encrypt Class Initialized
DEBUG - 2022-02-02 12:24:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-02 12:24:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-02 12:24:20 --> Email Class Initialized
INFO - 2022-02-02 12:24:20 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-02 12:24:20 --> Calendar Class Initialized
INFO - 2022-02-02 12:24:20 --> Model "Login_model" initialized
INFO - 2022-02-02 12:24:20 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-02 12:24:20 --> Final output sent to browser
DEBUG - 2022-02-02 12:24:20 --> Total execution time: 0.0225
ERROR - 2022-02-02 12:24:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-02 12:24:21 --> Config Class Initialized
INFO - 2022-02-02 12:24:21 --> Hooks Class Initialized
DEBUG - 2022-02-02 12:24:21 --> UTF-8 Support Enabled
INFO - 2022-02-02 12:24:21 --> Utf8 Class Initialized
INFO - 2022-02-02 12:24:21 --> URI Class Initialized
INFO - 2022-02-02 12:24:21 --> Router Class Initialized
INFO - 2022-02-02 12:24:21 --> Output Class Initialized
INFO - 2022-02-02 12:24:21 --> Security Class Initialized
DEBUG - 2022-02-02 12:24:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-02 12:24:21 --> Input Class Initialized
INFO - 2022-02-02 12:24:21 --> Language Class Initialized
ERROR - 2022-02-02 12:24:21 --> 404 Page Not Found: Blog/wp-includes
ERROR - 2022-02-02 12:24:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-02 12:24:22 --> Config Class Initialized
INFO - 2022-02-02 12:24:22 --> Hooks Class Initialized
DEBUG - 2022-02-02 12:24:22 --> UTF-8 Support Enabled
INFO - 2022-02-02 12:24:22 --> Utf8 Class Initialized
INFO - 2022-02-02 12:24:22 --> URI Class Initialized
INFO - 2022-02-02 12:24:22 --> Router Class Initialized
INFO - 2022-02-02 12:24:22 --> Output Class Initialized
INFO - 2022-02-02 12:24:22 --> Security Class Initialized
DEBUG - 2022-02-02 12:24:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-02 12:24:22 --> Input Class Initialized
INFO - 2022-02-02 12:24:22 --> Language Class Initialized
ERROR - 2022-02-02 12:24:22 --> 404 Page Not Found: Web/wp-includes
ERROR - 2022-02-02 12:24:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-02 12:24:22 --> Config Class Initialized
INFO - 2022-02-02 12:24:22 --> Hooks Class Initialized
DEBUG - 2022-02-02 12:24:22 --> UTF-8 Support Enabled
INFO - 2022-02-02 12:24:22 --> Utf8 Class Initialized
INFO - 2022-02-02 12:24:22 --> URI Class Initialized
INFO - 2022-02-02 12:24:22 --> Router Class Initialized
INFO - 2022-02-02 12:24:22 --> Output Class Initialized
INFO - 2022-02-02 12:24:22 --> Security Class Initialized
DEBUG - 2022-02-02 12:24:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-02 12:24:22 --> Input Class Initialized
INFO - 2022-02-02 12:24:22 --> Language Class Initialized
ERROR - 2022-02-02 12:24:22 --> 404 Page Not Found: Wordpress/wp-includes
ERROR - 2022-02-02 12:24:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-02 12:24:23 --> Config Class Initialized
INFO - 2022-02-02 12:24:23 --> Hooks Class Initialized
DEBUG - 2022-02-02 12:24:23 --> UTF-8 Support Enabled
INFO - 2022-02-02 12:24:23 --> Utf8 Class Initialized
INFO - 2022-02-02 12:24:23 --> URI Class Initialized
INFO - 2022-02-02 12:24:23 --> Router Class Initialized
INFO - 2022-02-02 12:24:23 --> Output Class Initialized
INFO - 2022-02-02 12:24:23 --> Security Class Initialized
DEBUG - 2022-02-02 12:24:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-02 12:24:23 --> Input Class Initialized
INFO - 2022-02-02 12:24:23 --> Language Class Initialized
ERROR - 2022-02-02 12:24:23 --> 404 Page Not Found: Website/wp-includes
ERROR - 2022-02-02 12:24:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-02 12:24:23 --> Config Class Initialized
INFO - 2022-02-02 12:24:23 --> Hooks Class Initialized
DEBUG - 2022-02-02 12:24:23 --> UTF-8 Support Enabled
INFO - 2022-02-02 12:24:23 --> Utf8 Class Initialized
INFO - 2022-02-02 12:24:23 --> URI Class Initialized
INFO - 2022-02-02 12:24:23 --> Router Class Initialized
INFO - 2022-02-02 12:24:23 --> Output Class Initialized
INFO - 2022-02-02 12:24:23 --> Security Class Initialized
DEBUG - 2022-02-02 12:24:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-02 12:24:23 --> Input Class Initialized
INFO - 2022-02-02 12:24:23 --> Language Class Initialized
ERROR - 2022-02-02 12:24:23 --> 404 Page Not Found: Wp/wp-includes
ERROR - 2022-02-02 12:24:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-02 12:24:24 --> Config Class Initialized
INFO - 2022-02-02 12:24:24 --> Hooks Class Initialized
DEBUG - 2022-02-02 12:24:24 --> UTF-8 Support Enabled
INFO - 2022-02-02 12:24:24 --> Utf8 Class Initialized
INFO - 2022-02-02 12:24:24 --> URI Class Initialized
INFO - 2022-02-02 12:24:24 --> Router Class Initialized
INFO - 2022-02-02 12:24:24 --> Output Class Initialized
INFO - 2022-02-02 12:24:24 --> Security Class Initialized
DEBUG - 2022-02-02 12:24:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-02 12:24:24 --> Input Class Initialized
INFO - 2022-02-02 12:24:24 --> Language Class Initialized
ERROR - 2022-02-02 12:24:24 --> 404 Page Not Found: News/wp-includes
ERROR - 2022-02-02 12:24:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-02 12:24:24 --> Config Class Initialized
INFO - 2022-02-02 12:24:24 --> Hooks Class Initialized
DEBUG - 2022-02-02 12:24:24 --> UTF-8 Support Enabled
INFO - 2022-02-02 12:24:24 --> Utf8 Class Initialized
INFO - 2022-02-02 12:24:24 --> URI Class Initialized
INFO - 2022-02-02 12:24:24 --> Router Class Initialized
INFO - 2022-02-02 12:24:24 --> Output Class Initialized
INFO - 2022-02-02 12:24:24 --> Security Class Initialized
DEBUG - 2022-02-02 12:24:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-02 12:24:24 --> Input Class Initialized
INFO - 2022-02-02 12:24:24 --> Language Class Initialized
ERROR - 2022-02-02 12:24:24 --> 404 Page Not Found: 2018/wp-includes
ERROR - 2022-02-02 12:24:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-02 12:24:25 --> Config Class Initialized
INFO - 2022-02-02 12:24:25 --> Hooks Class Initialized
DEBUG - 2022-02-02 12:24:25 --> UTF-8 Support Enabled
INFO - 2022-02-02 12:24:25 --> Utf8 Class Initialized
INFO - 2022-02-02 12:24:25 --> URI Class Initialized
INFO - 2022-02-02 12:24:25 --> Router Class Initialized
INFO - 2022-02-02 12:24:25 --> Output Class Initialized
INFO - 2022-02-02 12:24:25 --> Security Class Initialized
DEBUG - 2022-02-02 12:24:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-02 12:24:25 --> Input Class Initialized
INFO - 2022-02-02 12:24:25 --> Language Class Initialized
ERROR - 2022-02-02 12:24:25 --> 404 Page Not Found: 2019/wp-includes
ERROR - 2022-02-02 12:24:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-02 12:24:25 --> Config Class Initialized
INFO - 2022-02-02 12:24:25 --> Hooks Class Initialized
DEBUG - 2022-02-02 12:24:25 --> UTF-8 Support Enabled
INFO - 2022-02-02 12:24:25 --> Utf8 Class Initialized
INFO - 2022-02-02 12:24:25 --> URI Class Initialized
INFO - 2022-02-02 12:24:25 --> Router Class Initialized
INFO - 2022-02-02 12:24:25 --> Output Class Initialized
INFO - 2022-02-02 12:24:25 --> Security Class Initialized
DEBUG - 2022-02-02 12:24:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-02 12:24:25 --> Input Class Initialized
INFO - 2022-02-02 12:24:25 --> Language Class Initialized
ERROR - 2022-02-02 12:24:25 --> 404 Page Not Found: Shop/wp-includes
ERROR - 2022-02-02 12:24:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-02 12:24:26 --> Config Class Initialized
INFO - 2022-02-02 12:24:26 --> Hooks Class Initialized
DEBUG - 2022-02-02 12:24:26 --> UTF-8 Support Enabled
INFO - 2022-02-02 12:24:26 --> Utf8 Class Initialized
INFO - 2022-02-02 12:24:26 --> URI Class Initialized
INFO - 2022-02-02 12:24:26 --> Router Class Initialized
INFO - 2022-02-02 12:24:26 --> Output Class Initialized
INFO - 2022-02-02 12:24:26 --> Security Class Initialized
DEBUG - 2022-02-02 12:24:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-02 12:24:26 --> Input Class Initialized
INFO - 2022-02-02 12:24:26 --> Language Class Initialized
ERROR - 2022-02-02 12:24:26 --> 404 Page Not Found: Wp1/wp-includes
ERROR - 2022-02-02 12:24:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-02 12:24:26 --> Config Class Initialized
INFO - 2022-02-02 12:24:26 --> Hooks Class Initialized
DEBUG - 2022-02-02 12:24:26 --> UTF-8 Support Enabled
INFO - 2022-02-02 12:24:26 --> Utf8 Class Initialized
INFO - 2022-02-02 12:24:26 --> URI Class Initialized
INFO - 2022-02-02 12:24:26 --> Router Class Initialized
INFO - 2022-02-02 12:24:26 --> Output Class Initialized
INFO - 2022-02-02 12:24:26 --> Security Class Initialized
DEBUG - 2022-02-02 12:24:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-02 12:24:26 --> Input Class Initialized
INFO - 2022-02-02 12:24:26 --> Language Class Initialized
ERROR - 2022-02-02 12:24:26 --> 404 Page Not Found: Test/wp-includes
ERROR - 2022-02-02 12:24:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-02 12:24:27 --> Config Class Initialized
INFO - 2022-02-02 12:24:27 --> Hooks Class Initialized
DEBUG - 2022-02-02 12:24:27 --> UTF-8 Support Enabled
INFO - 2022-02-02 12:24:27 --> Utf8 Class Initialized
INFO - 2022-02-02 12:24:27 --> URI Class Initialized
INFO - 2022-02-02 12:24:27 --> Router Class Initialized
INFO - 2022-02-02 12:24:27 --> Output Class Initialized
INFO - 2022-02-02 12:24:27 --> Security Class Initialized
DEBUG - 2022-02-02 12:24:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-02 12:24:27 --> Input Class Initialized
INFO - 2022-02-02 12:24:27 --> Language Class Initialized
ERROR - 2022-02-02 12:24:27 --> 404 Page Not Found: Media/wp-includes
ERROR - 2022-02-02 12:24:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-02 12:24:27 --> Config Class Initialized
INFO - 2022-02-02 12:24:27 --> Hooks Class Initialized
DEBUG - 2022-02-02 12:24:27 --> UTF-8 Support Enabled
INFO - 2022-02-02 12:24:27 --> Utf8 Class Initialized
INFO - 2022-02-02 12:24:27 --> URI Class Initialized
INFO - 2022-02-02 12:24:27 --> Router Class Initialized
INFO - 2022-02-02 12:24:27 --> Output Class Initialized
INFO - 2022-02-02 12:24:27 --> Security Class Initialized
DEBUG - 2022-02-02 12:24:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-02 12:24:27 --> Input Class Initialized
INFO - 2022-02-02 12:24:27 --> Language Class Initialized
ERROR - 2022-02-02 12:24:27 --> 404 Page Not Found: Wp2/wp-includes
ERROR - 2022-02-02 12:24:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-02 12:24:28 --> Config Class Initialized
INFO - 2022-02-02 12:24:28 --> Hooks Class Initialized
DEBUG - 2022-02-02 12:24:28 --> UTF-8 Support Enabled
INFO - 2022-02-02 12:24:28 --> Utf8 Class Initialized
INFO - 2022-02-02 12:24:28 --> URI Class Initialized
INFO - 2022-02-02 12:24:28 --> Router Class Initialized
INFO - 2022-02-02 12:24:28 --> Output Class Initialized
INFO - 2022-02-02 12:24:28 --> Security Class Initialized
DEBUG - 2022-02-02 12:24:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-02 12:24:28 --> Input Class Initialized
INFO - 2022-02-02 12:24:28 --> Language Class Initialized
ERROR - 2022-02-02 12:24:28 --> 404 Page Not Found: Site/wp-includes
ERROR - 2022-02-02 12:24:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-02 12:24:29 --> Config Class Initialized
INFO - 2022-02-02 12:24:29 --> Hooks Class Initialized
DEBUG - 2022-02-02 12:24:29 --> UTF-8 Support Enabled
INFO - 2022-02-02 12:24:29 --> Utf8 Class Initialized
INFO - 2022-02-02 12:24:29 --> URI Class Initialized
INFO - 2022-02-02 12:24:29 --> Router Class Initialized
INFO - 2022-02-02 12:24:29 --> Output Class Initialized
INFO - 2022-02-02 12:24:29 --> Security Class Initialized
DEBUG - 2022-02-02 12:24:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-02 12:24:29 --> Input Class Initialized
INFO - 2022-02-02 12:24:29 --> Language Class Initialized
ERROR - 2022-02-02 12:24:29 --> 404 Page Not Found: Cms/wp-includes
ERROR - 2022-02-02 12:24:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-02 12:24:29 --> Config Class Initialized
INFO - 2022-02-02 12:24:29 --> Hooks Class Initialized
DEBUG - 2022-02-02 12:24:29 --> UTF-8 Support Enabled
INFO - 2022-02-02 12:24:29 --> Utf8 Class Initialized
INFO - 2022-02-02 12:24:29 --> URI Class Initialized
INFO - 2022-02-02 12:24:29 --> Router Class Initialized
INFO - 2022-02-02 12:24:29 --> Output Class Initialized
INFO - 2022-02-02 12:24:29 --> Security Class Initialized
DEBUG - 2022-02-02 12:24:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-02 12:24:29 --> Input Class Initialized
INFO - 2022-02-02 12:24:29 --> Language Class Initialized
ERROR - 2022-02-02 12:24:29 --> 404 Page Not Found: Sito/wp-includes
ERROR - 2022-02-02 14:21:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-02 14:21:43 --> Config Class Initialized
INFO - 2022-02-02 14:21:43 --> Hooks Class Initialized
DEBUG - 2022-02-02 14:21:43 --> UTF-8 Support Enabled
INFO - 2022-02-02 14:21:43 --> Utf8 Class Initialized
INFO - 2022-02-02 14:21:43 --> URI Class Initialized
DEBUG - 2022-02-02 14:21:43 --> No URI present. Default controller set.
INFO - 2022-02-02 14:21:43 --> Router Class Initialized
INFO - 2022-02-02 14:21:43 --> Output Class Initialized
INFO - 2022-02-02 14:21:43 --> Security Class Initialized
DEBUG - 2022-02-02 14:21:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-02 14:21:43 --> Input Class Initialized
INFO - 2022-02-02 14:21:43 --> Language Class Initialized
INFO - 2022-02-02 14:21:43 --> Loader Class Initialized
INFO - 2022-02-02 14:21:43 --> Helper loaded: url_helper
INFO - 2022-02-02 14:21:43 --> Helper loaded: form_helper
INFO - 2022-02-02 14:21:43 --> Helper loaded: common_helper
INFO - 2022-02-02 14:21:43 --> Database Driver Class Initialized
DEBUG - 2022-02-02 14:21:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-02 14:21:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-02 14:21:43 --> Controller Class Initialized
INFO - 2022-02-02 14:21:43 --> Form Validation Class Initialized
DEBUG - 2022-02-02 14:21:43 --> Encrypt Class Initialized
DEBUG - 2022-02-02 14:21:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-02 14:21:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-02 14:21:43 --> Email Class Initialized
INFO - 2022-02-02 14:21:43 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-02 14:21:43 --> Calendar Class Initialized
INFO - 2022-02-02 14:21:43 --> Model "Login_model" initialized
INFO - 2022-02-02 14:21:43 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-02 14:21:43 --> Final output sent to browser
DEBUG - 2022-02-02 14:21:43 --> Total execution time: 0.0249
ERROR - 2022-02-02 14:21:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-02 14:21:44 --> Config Class Initialized
INFO - 2022-02-02 14:21:44 --> Hooks Class Initialized
DEBUG - 2022-02-02 14:21:44 --> UTF-8 Support Enabled
INFO - 2022-02-02 14:21:44 --> Utf8 Class Initialized
INFO - 2022-02-02 14:21:44 --> URI Class Initialized
INFO - 2022-02-02 14:21:44 --> Router Class Initialized
INFO - 2022-02-02 14:21:44 --> Output Class Initialized
INFO - 2022-02-02 14:21:44 --> Security Class Initialized
DEBUG - 2022-02-02 14:21:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-02 14:21:44 --> Input Class Initialized
INFO - 2022-02-02 14:21:44 --> Language Class Initialized
ERROR - 2022-02-02 14:21:44 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2022-02-02 14:21:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-02 14:21:53 --> Config Class Initialized
INFO - 2022-02-02 14:21:53 --> Hooks Class Initialized
DEBUG - 2022-02-02 14:21:53 --> UTF-8 Support Enabled
INFO - 2022-02-02 14:21:53 --> Utf8 Class Initialized
INFO - 2022-02-02 14:21:53 --> URI Class Initialized
INFO - 2022-02-02 14:21:53 --> Router Class Initialized
INFO - 2022-02-02 14:21:53 --> Output Class Initialized
INFO - 2022-02-02 14:21:53 --> Security Class Initialized
DEBUG - 2022-02-02 14:21:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-02 14:21:53 --> Input Class Initialized
INFO - 2022-02-02 14:21:53 --> Language Class Initialized
INFO - 2022-02-02 14:21:53 --> Loader Class Initialized
INFO - 2022-02-02 14:21:53 --> Helper loaded: url_helper
INFO - 2022-02-02 14:21:53 --> Helper loaded: form_helper
INFO - 2022-02-02 14:21:53 --> Helper loaded: common_helper
INFO - 2022-02-02 14:21:53 --> Database Driver Class Initialized
DEBUG - 2022-02-02 14:21:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-02 14:21:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-02 14:21:53 --> Controller Class Initialized
INFO - 2022-02-02 14:21:53 --> Form Validation Class Initialized
DEBUG - 2022-02-02 14:21:53 --> Encrypt Class Initialized
DEBUG - 2022-02-02 14:21:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-02 14:21:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-02 14:21:53 --> Email Class Initialized
INFO - 2022-02-02 14:21:53 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-02 14:21:53 --> Calendar Class Initialized
INFO - 2022-02-02 14:21:53 --> Model "Login_model" initialized
INFO - 2022-02-02 14:21:53 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-02 14:21:53 --> Final output sent to browser
DEBUG - 2022-02-02 14:21:53 --> Total execution time: 0.0231
ERROR - 2022-02-02 14:21:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-02 14:21:54 --> Config Class Initialized
INFO - 2022-02-02 14:21:54 --> Hooks Class Initialized
DEBUG - 2022-02-02 14:21:54 --> UTF-8 Support Enabled
INFO - 2022-02-02 14:21:54 --> Utf8 Class Initialized
INFO - 2022-02-02 14:21:54 --> URI Class Initialized
INFO - 2022-02-02 14:21:54 --> Router Class Initialized
INFO - 2022-02-02 14:21:54 --> Output Class Initialized
INFO - 2022-02-02 14:21:54 --> Security Class Initialized
DEBUG - 2022-02-02 14:21:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-02 14:21:54 --> Input Class Initialized
INFO - 2022-02-02 14:21:54 --> Language Class Initialized
INFO - 2022-02-02 14:21:54 --> Loader Class Initialized
INFO - 2022-02-02 14:21:54 --> Helper loaded: url_helper
INFO - 2022-02-02 14:21:54 --> Helper loaded: form_helper
INFO - 2022-02-02 14:21:54 --> Helper loaded: common_helper
INFO - 2022-02-02 14:21:54 --> Database Driver Class Initialized
DEBUG - 2022-02-02 14:21:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-02 14:21:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-02 14:21:54 --> Controller Class Initialized
INFO - 2022-02-02 14:21:54 --> Form Validation Class Initialized
DEBUG - 2022-02-02 14:21:54 --> Encrypt Class Initialized
DEBUG - 2022-02-02 14:21:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-02 14:21:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-02 14:21:54 --> Email Class Initialized
INFO - 2022-02-02 14:21:54 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-02 14:21:54 --> Calendar Class Initialized
INFO - 2022-02-02 14:21:54 --> Model "Login_model" initialized
ERROR - 2022-02-02 14:21:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-02 14:21:54 --> Config Class Initialized
INFO - 2022-02-02 14:21:54 --> Hooks Class Initialized
DEBUG - 2022-02-02 14:21:54 --> UTF-8 Support Enabled
INFO - 2022-02-02 14:21:54 --> Utf8 Class Initialized
INFO - 2022-02-02 14:21:54 --> URI Class Initialized
INFO - 2022-02-02 14:21:54 --> Router Class Initialized
INFO - 2022-02-02 14:21:54 --> Output Class Initialized
INFO - 2022-02-02 14:21:54 --> Security Class Initialized
DEBUG - 2022-02-02 14:21:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-02 14:21:54 --> Input Class Initialized
INFO - 2022-02-02 14:21:54 --> Language Class Initialized
INFO - 2022-02-02 14:21:54 --> Loader Class Initialized
INFO - 2022-02-02 14:21:54 --> Helper loaded: url_helper
INFO - 2022-02-02 14:21:54 --> Helper loaded: form_helper
INFO - 2022-02-02 14:21:54 --> Helper loaded: common_helper
INFO - 2022-02-02 14:21:54 --> Database Driver Class Initialized
DEBUG - 2022-02-02 14:21:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-02 14:21:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-02 14:21:54 --> Controller Class Initialized
INFO - 2022-02-02 14:21:54 --> Form Validation Class Initialized
DEBUG - 2022-02-02 14:21:54 --> Encrypt Class Initialized
DEBUG - 2022-02-02 14:21:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-02 14:21:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-02 14:21:54 --> Email Class Initialized
INFO - 2022-02-02 14:21:54 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-02 14:21:54 --> Calendar Class Initialized
INFO - 2022-02-02 14:21:54 --> Model "Login_model" initialized
ERROR - 2022-02-02 14:21:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-02 14:21:55 --> Config Class Initialized
INFO - 2022-02-02 14:21:55 --> Hooks Class Initialized
DEBUG - 2022-02-02 14:21:55 --> UTF-8 Support Enabled
INFO - 2022-02-02 14:21:55 --> Utf8 Class Initialized
INFO - 2022-02-02 14:21:55 --> URI Class Initialized
DEBUG - 2022-02-02 14:21:55 --> No URI present. Default controller set.
INFO - 2022-02-02 14:21:55 --> Router Class Initialized
INFO - 2022-02-02 14:21:55 --> Output Class Initialized
INFO - 2022-02-02 14:21:55 --> Security Class Initialized
DEBUG - 2022-02-02 14:21:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-02 14:21:55 --> Input Class Initialized
INFO - 2022-02-02 14:21:55 --> Language Class Initialized
INFO - 2022-02-02 14:21:55 --> Loader Class Initialized
INFO - 2022-02-02 14:21:55 --> Helper loaded: url_helper
INFO - 2022-02-02 14:21:55 --> Helper loaded: form_helper
INFO - 2022-02-02 14:21:55 --> Helper loaded: common_helper
INFO - 2022-02-02 14:21:55 --> Database Driver Class Initialized
DEBUG - 2022-02-02 14:21:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-02 14:21:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-02 14:21:55 --> Controller Class Initialized
INFO - 2022-02-02 14:21:55 --> Form Validation Class Initialized
DEBUG - 2022-02-02 14:21:55 --> Encrypt Class Initialized
DEBUG - 2022-02-02 14:21:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-02 14:21:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-02 14:21:55 --> Email Class Initialized
INFO - 2022-02-02 14:21:55 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-02 14:21:55 --> Calendar Class Initialized
INFO - 2022-02-02 14:21:55 --> Model "Login_model" initialized
INFO - 2022-02-02 14:21:55 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-02 14:21:55 --> Final output sent to browser
DEBUG - 2022-02-02 14:21:55 --> Total execution time: 0.0264
ERROR - 2022-02-02 14:37:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-02 14:37:03 --> Config Class Initialized
INFO - 2022-02-02 14:37:03 --> Hooks Class Initialized
DEBUG - 2022-02-02 14:37:03 --> UTF-8 Support Enabled
INFO - 2022-02-02 14:37:03 --> Utf8 Class Initialized
INFO - 2022-02-02 14:37:03 --> URI Class Initialized
DEBUG - 2022-02-02 14:37:03 --> No URI present. Default controller set.
INFO - 2022-02-02 14:37:03 --> Router Class Initialized
INFO - 2022-02-02 14:37:03 --> Output Class Initialized
INFO - 2022-02-02 14:37:03 --> Security Class Initialized
DEBUG - 2022-02-02 14:37:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-02 14:37:03 --> Input Class Initialized
INFO - 2022-02-02 14:37:03 --> Language Class Initialized
INFO - 2022-02-02 14:37:03 --> Loader Class Initialized
INFO - 2022-02-02 14:37:03 --> Helper loaded: url_helper
INFO - 2022-02-02 14:37:03 --> Helper loaded: form_helper
INFO - 2022-02-02 14:37:03 --> Helper loaded: common_helper
INFO - 2022-02-02 14:37:03 --> Database Driver Class Initialized
DEBUG - 2022-02-02 14:37:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-02 14:37:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-02 14:37:03 --> Controller Class Initialized
INFO - 2022-02-02 14:37:03 --> Form Validation Class Initialized
DEBUG - 2022-02-02 14:37:03 --> Encrypt Class Initialized
DEBUG - 2022-02-02 14:37:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-02 14:37:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-02 14:37:03 --> Email Class Initialized
INFO - 2022-02-02 14:37:03 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-02 14:37:03 --> Calendar Class Initialized
INFO - 2022-02-02 14:37:03 --> Model "Login_model" initialized
INFO - 2022-02-02 14:37:03 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-02 14:37:03 --> Final output sent to browser
DEBUG - 2022-02-02 14:37:03 --> Total execution time: 0.0285
ERROR - 2022-02-02 15:08:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-02 15:08:01 --> Config Class Initialized
INFO - 2022-02-02 15:08:01 --> Hooks Class Initialized
DEBUG - 2022-02-02 15:08:01 --> UTF-8 Support Enabled
INFO - 2022-02-02 15:08:01 --> Utf8 Class Initialized
INFO - 2022-02-02 15:08:01 --> URI Class Initialized
DEBUG - 2022-02-02 15:08:01 --> No URI present. Default controller set.
INFO - 2022-02-02 15:08:01 --> Router Class Initialized
INFO - 2022-02-02 15:08:01 --> Output Class Initialized
INFO - 2022-02-02 15:08:01 --> Security Class Initialized
DEBUG - 2022-02-02 15:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-02 15:08:01 --> Input Class Initialized
INFO - 2022-02-02 15:08:01 --> Language Class Initialized
INFO - 2022-02-02 15:08:01 --> Loader Class Initialized
INFO - 2022-02-02 15:08:01 --> Helper loaded: url_helper
INFO - 2022-02-02 15:08:01 --> Helper loaded: form_helper
INFO - 2022-02-02 15:08:01 --> Helper loaded: common_helper
INFO - 2022-02-02 15:08:01 --> Database Driver Class Initialized
DEBUG - 2022-02-02 15:08:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-02 15:08:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-02 15:08:01 --> Controller Class Initialized
INFO - 2022-02-02 15:08:01 --> Form Validation Class Initialized
DEBUG - 2022-02-02 15:08:01 --> Encrypt Class Initialized
DEBUG - 2022-02-02 15:08:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-02 15:08:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-02 15:08:01 --> Email Class Initialized
INFO - 2022-02-02 15:08:01 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-02 15:08:01 --> Calendar Class Initialized
INFO - 2022-02-02 15:08:01 --> Model "Login_model" initialized
INFO - 2022-02-02 15:08:01 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-02 15:08:01 --> Final output sent to browser
DEBUG - 2022-02-02 15:08:01 --> Total execution time: 0.0220
ERROR - 2022-02-02 16:43:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-02 16:43:30 --> Config Class Initialized
INFO - 2022-02-02 16:43:30 --> Hooks Class Initialized
DEBUG - 2022-02-02 16:43:30 --> UTF-8 Support Enabled
INFO - 2022-02-02 16:43:30 --> Utf8 Class Initialized
INFO - 2022-02-02 16:43:30 --> URI Class Initialized
DEBUG - 2022-02-02 16:43:30 --> No URI present. Default controller set.
INFO - 2022-02-02 16:43:30 --> Router Class Initialized
INFO - 2022-02-02 16:43:30 --> Output Class Initialized
INFO - 2022-02-02 16:43:30 --> Security Class Initialized
DEBUG - 2022-02-02 16:43:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-02 16:43:30 --> Input Class Initialized
INFO - 2022-02-02 16:43:30 --> Language Class Initialized
INFO - 2022-02-02 16:43:30 --> Loader Class Initialized
INFO - 2022-02-02 16:43:30 --> Helper loaded: url_helper
INFO - 2022-02-02 16:43:30 --> Helper loaded: form_helper
INFO - 2022-02-02 16:43:30 --> Helper loaded: common_helper
INFO - 2022-02-02 16:43:30 --> Database Driver Class Initialized
DEBUG - 2022-02-02 16:43:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-02 16:43:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-02 16:43:31 --> Controller Class Initialized
INFO - 2022-02-02 16:43:31 --> Form Validation Class Initialized
DEBUG - 2022-02-02 16:43:31 --> Encrypt Class Initialized
DEBUG - 2022-02-02 16:43:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-02 16:43:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-02 16:43:31 --> Email Class Initialized
INFO - 2022-02-02 16:43:31 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-02 16:43:31 --> Calendar Class Initialized
INFO - 2022-02-02 16:43:31 --> Model "Login_model" initialized
INFO - 2022-02-02 16:43:31 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-02 16:43:31 --> Final output sent to browser
DEBUG - 2022-02-02 16:43:31 --> Total execution time: 0.0267
