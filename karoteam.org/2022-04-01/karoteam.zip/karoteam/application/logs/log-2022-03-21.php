<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-03-21 00:41:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 00:41:34 --> Config Class Initialized
INFO - 2022-03-21 00:41:34 --> Hooks Class Initialized
DEBUG - 2022-03-21 00:41:34 --> UTF-8 Support Enabled
INFO - 2022-03-21 00:41:34 --> Utf8 Class Initialized
INFO - 2022-03-21 00:41:34 --> URI Class Initialized
DEBUG - 2022-03-21 00:41:34 --> No URI present. Default controller set.
INFO - 2022-03-21 00:41:34 --> Router Class Initialized
INFO - 2022-03-21 00:41:34 --> Output Class Initialized
INFO - 2022-03-21 00:41:34 --> Security Class Initialized
DEBUG - 2022-03-21 00:41:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 00:41:34 --> Input Class Initialized
INFO - 2022-03-21 00:41:34 --> Language Class Initialized
INFO - 2022-03-21 00:41:34 --> Loader Class Initialized
INFO - 2022-03-21 00:41:34 --> Helper loaded: url_helper
INFO - 2022-03-21 00:41:34 --> Helper loaded: form_helper
INFO - 2022-03-21 00:41:34 --> Helper loaded: common_helper
INFO - 2022-03-21 00:41:34 --> Database Driver Class Initialized
DEBUG - 2022-03-21 00:41:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 00:41:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 00:41:34 --> Controller Class Initialized
INFO - 2022-03-21 00:41:34 --> Form Validation Class Initialized
DEBUG - 2022-03-21 00:41:34 --> Encrypt Class Initialized
DEBUG - 2022-03-21 00:41:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 00:41:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-21 00:41:34 --> Email Class Initialized
INFO - 2022-03-21 00:41:34 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-21 00:41:34 --> Calendar Class Initialized
INFO - 2022-03-21 00:41:34 --> Model "Login_model" initialized
INFO - 2022-03-21 00:41:34 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-21 00:41:34 --> Final output sent to browser
DEBUG - 2022-03-21 00:41:34 --> Total execution time: 0.0384
ERROR - 2022-03-21 00:41:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 00:41:38 --> Config Class Initialized
INFO - 2022-03-21 00:41:38 --> Hooks Class Initialized
DEBUG - 2022-03-21 00:41:38 --> UTF-8 Support Enabled
INFO - 2022-03-21 00:41:38 --> Utf8 Class Initialized
INFO - 2022-03-21 00:41:38 --> URI Class Initialized
INFO - 2022-03-21 00:41:38 --> Router Class Initialized
INFO - 2022-03-21 00:41:38 --> Output Class Initialized
INFO - 2022-03-21 00:41:38 --> Security Class Initialized
DEBUG - 2022-03-21 00:41:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 00:41:38 --> Input Class Initialized
INFO - 2022-03-21 00:41:38 --> Language Class Initialized
INFO - 2022-03-21 00:41:38 --> Loader Class Initialized
INFO - 2022-03-21 00:41:38 --> Helper loaded: url_helper
INFO - 2022-03-21 00:41:38 --> Helper loaded: form_helper
INFO - 2022-03-21 00:41:38 --> Helper loaded: common_helper
INFO - 2022-03-21 00:41:38 --> Database Driver Class Initialized
DEBUG - 2022-03-21 00:41:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 00:41:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 00:41:38 --> Controller Class Initialized
INFO - 2022-03-21 00:41:38 --> Form Validation Class Initialized
DEBUG - 2022-03-21 00:41:38 --> Encrypt Class Initialized
DEBUG - 2022-03-21 00:41:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 00:41:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-21 00:41:38 --> Email Class Initialized
INFO - 2022-03-21 00:41:38 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-21 00:41:38 --> Calendar Class Initialized
INFO - 2022-03-21 00:41:38 --> Model "Login_model" initialized
INFO - 2022-03-21 00:41:38 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-03-21 00:41:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 00:41:39 --> Config Class Initialized
INFO - 2022-03-21 00:41:39 --> Hooks Class Initialized
DEBUG - 2022-03-21 00:41:39 --> UTF-8 Support Enabled
INFO - 2022-03-21 00:41:39 --> Utf8 Class Initialized
INFO - 2022-03-21 00:41:39 --> URI Class Initialized
INFO - 2022-03-21 00:41:39 --> Router Class Initialized
INFO - 2022-03-21 00:41:39 --> Output Class Initialized
INFO - 2022-03-21 00:41:39 --> Security Class Initialized
DEBUG - 2022-03-21 00:41:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 00:41:39 --> Input Class Initialized
INFO - 2022-03-21 00:41:39 --> Language Class Initialized
INFO - 2022-03-21 00:41:39 --> Loader Class Initialized
INFO - 2022-03-21 00:41:39 --> Helper loaded: url_helper
INFO - 2022-03-21 00:41:39 --> Helper loaded: form_helper
INFO - 2022-03-21 00:41:39 --> Helper loaded: common_helper
INFO - 2022-03-21 00:41:39 --> Database Driver Class Initialized
DEBUG - 2022-03-21 00:41:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 00:41:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 00:41:39 --> Controller Class Initialized
INFO - 2022-03-21 00:41:39 --> Form Validation Class Initialized
DEBUG - 2022-03-21 00:41:39 --> Encrypt Class Initialized
INFO - 2022-03-21 00:41:39 --> Model "Login_model" initialized
INFO - 2022-03-21 00:41:39 --> Model "Dashboard_model" initialized
INFO - 2022-03-21 00:41:39 --> Model "Case_model" initialized
INFO - 2022-03-21 00:41:49 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-21 00:42:02 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2022-03-21 00:42:02 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-21 00:42:02 --> Final output sent to browser
DEBUG - 2022-03-21 00:42:02 --> Total execution time: 23.4688
ERROR - 2022-03-21 00:42:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 00:42:12 --> Config Class Initialized
INFO - 2022-03-21 00:42:12 --> Hooks Class Initialized
DEBUG - 2022-03-21 00:42:12 --> UTF-8 Support Enabled
INFO - 2022-03-21 00:42:12 --> Utf8 Class Initialized
INFO - 2022-03-21 00:42:12 --> URI Class Initialized
INFO - 2022-03-21 00:42:12 --> Router Class Initialized
INFO - 2022-03-21 00:42:12 --> Output Class Initialized
INFO - 2022-03-21 00:42:12 --> Security Class Initialized
DEBUG - 2022-03-21 00:42:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 00:42:12 --> Input Class Initialized
INFO - 2022-03-21 00:42:12 --> Language Class Initialized
INFO - 2022-03-21 00:42:12 --> Loader Class Initialized
INFO - 2022-03-21 00:42:12 --> Helper loaded: url_helper
INFO - 2022-03-21 00:42:12 --> Helper loaded: form_helper
INFO - 2022-03-21 00:42:12 --> Helper loaded: common_helper
INFO - 2022-03-21 00:42:12 --> Database Driver Class Initialized
DEBUG - 2022-03-21 00:42:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 00:42:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 00:42:12 --> Controller Class Initialized
INFO - 2022-03-21 00:42:12 --> Form Validation Class Initialized
DEBUG - 2022-03-21 00:42:12 --> Encrypt Class Initialized
INFO - 2022-03-21 00:42:12 --> Model "Patient_model" initialized
INFO - 2022-03-21 00:42:12 --> Model "Patientcase_model" initialized
INFO - 2022-03-21 00:42:12 --> Model "Referredby_model" initialized
INFO - 2022-03-21 00:42:12 --> Model "Prefix_master" initialized
INFO - 2022-03-21 00:42:12 --> Model "Hospital_model" initialized
INFO - 2022-03-21 00:42:12 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-21 00:42:21 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-21 00:42:21 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-21 00:42:22 --> Final output sent to browser
DEBUG - 2022-03-21 00:42:22 --> Total execution time: 8.9313
ERROR - 2022-03-21 00:59:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 00:59:59 --> Config Class Initialized
INFO - 2022-03-21 00:59:59 --> Hooks Class Initialized
DEBUG - 2022-03-21 00:59:59 --> UTF-8 Support Enabled
INFO - 2022-03-21 00:59:59 --> Utf8 Class Initialized
INFO - 2022-03-21 00:59:59 --> URI Class Initialized
DEBUG - 2022-03-21 00:59:59 --> No URI present. Default controller set.
INFO - 2022-03-21 00:59:59 --> Router Class Initialized
INFO - 2022-03-21 00:59:59 --> Output Class Initialized
INFO - 2022-03-21 00:59:59 --> Security Class Initialized
DEBUG - 2022-03-21 00:59:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 00:59:59 --> Input Class Initialized
INFO - 2022-03-21 00:59:59 --> Language Class Initialized
INFO - 2022-03-21 00:59:59 --> Loader Class Initialized
INFO - 2022-03-21 00:59:59 --> Helper loaded: url_helper
INFO - 2022-03-21 00:59:59 --> Helper loaded: form_helper
INFO - 2022-03-21 00:59:59 --> Helper loaded: common_helper
INFO - 2022-03-21 00:59:59 --> Database Driver Class Initialized
DEBUG - 2022-03-21 00:59:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 00:59:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 00:59:59 --> Controller Class Initialized
INFO - 2022-03-21 00:59:59 --> Form Validation Class Initialized
DEBUG - 2022-03-21 00:59:59 --> Encrypt Class Initialized
DEBUG - 2022-03-21 00:59:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 00:59:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-21 00:59:59 --> Email Class Initialized
INFO - 2022-03-21 00:59:59 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-21 00:59:59 --> Calendar Class Initialized
INFO - 2022-03-21 00:59:59 --> Model "Login_model" initialized
INFO - 2022-03-21 00:59:59 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-21 00:59:59 --> Final output sent to browser
DEBUG - 2022-03-21 00:59:59 --> Total execution time: 0.0377
ERROR - 2022-03-21 01:31:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 01:31:44 --> Config Class Initialized
INFO - 2022-03-21 01:31:44 --> Hooks Class Initialized
DEBUG - 2022-03-21 01:31:44 --> UTF-8 Support Enabled
INFO - 2022-03-21 01:31:44 --> Utf8 Class Initialized
INFO - 2022-03-21 01:31:44 --> URI Class Initialized
DEBUG - 2022-03-21 01:31:44 --> No URI present. Default controller set.
INFO - 2022-03-21 01:31:44 --> Router Class Initialized
INFO - 2022-03-21 01:31:44 --> Output Class Initialized
INFO - 2022-03-21 01:31:44 --> Security Class Initialized
DEBUG - 2022-03-21 01:31:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 01:31:44 --> Input Class Initialized
INFO - 2022-03-21 01:31:44 --> Language Class Initialized
INFO - 2022-03-21 01:31:44 --> Loader Class Initialized
INFO - 2022-03-21 01:31:44 --> Helper loaded: url_helper
INFO - 2022-03-21 01:31:44 --> Helper loaded: form_helper
INFO - 2022-03-21 01:31:44 --> Helper loaded: common_helper
INFO - 2022-03-21 01:31:44 --> Database Driver Class Initialized
DEBUG - 2022-03-21 01:31:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 01:31:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 01:31:44 --> Controller Class Initialized
INFO - 2022-03-21 01:31:44 --> Form Validation Class Initialized
DEBUG - 2022-03-21 01:31:44 --> Encrypt Class Initialized
DEBUG - 2022-03-21 01:31:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 01:31:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-21 01:31:44 --> Email Class Initialized
INFO - 2022-03-21 01:31:44 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-21 01:31:44 --> Calendar Class Initialized
INFO - 2022-03-21 01:31:44 --> Model "Login_model" initialized
INFO - 2022-03-21 01:31:44 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-21 01:31:44 --> Final output sent to browser
DEBUG - 2022-03-21 01:31:44 --> Total execution time: 0.0388
ERROR - 2022-03-21 03:38:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 03:38:59 --> Config Class Initialized
INFO - 2022-03-21 03:38:59 --> Hooks Class Initialized
DEBUG - 2022-03-21 03:38:59 --> UTF-8 Support Enabled
INFO - 2022-03-21 03:38:59 --> Utf8 Class Initialized
INFO - 2022-03-21 03:38:59 --> URI Class Initialized
INFO - 2022-03-21 03:38:59 --> Router Class Initialized
INFO - 2022-03-21 03:38:59 --> Output Class Initialized
INFO - 2022-03-21 03:38:59 --> Security Class Initialized
DEBUG - 2022-03-21 03:38:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 03:38:59 --> Input Class Initialized
INFO - 2022-03-21 03:38:59 --> Language Class Initialized
INFO - 2022-03-21 03:38:59 --> Loader Class Initialized
INFO - 2022-03-21 03:38:59 --> Helper loaded: url_helper
INFO - 2022-03-21 03:38:59 --> Helper loaded: form_helper
INFO - 2022-03-21 03:38:59 --> Helper loaded: common_helper
INFO - 2022-03-21 03:38:59 --> Database Driver Class Initialized
DEBUG - 2022-03-21 03:38:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 03:38:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 03:38:59 --> Controller Class Initialized
ERROR - 2022-03-21 03:39:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 03:39:00 --> Config Class Initialized
INFO - 2022-03-21 03:39:00 --> Hooks Class Initialized
DEBUG - 2022-03-21 03:39:00 --> UTF-8 Support Enabled
INFO - 2022-03-21 03:39:00 --> Utf8 Class Initialized
INFO - 2022-03-21 03:39:00 --> URI Class Initialized
INFO - 2022-03-21 03:39:00 --> Router Class Initialized
INFO - 2022-03-21 03:39:00 --> Output Class Initialized
INFO - 2022-03-21 03:39:00 --> Security Class Initialized
DEBUG - 2022-03-21 03:39:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 03:39:00 --> Input Class Initialized
INFO - 2022-03-21 03:39:00 --> Language Class Initialized
INFO - 2022-03-21 03:39:00 --> Loader Class Initialized
INFO - 2022-03-21 03:39:00 --> Helper loaded: url_helper
INFO - 2022-03-21 03:39:00 --> Helper loaded: form_helper
INFO - 2022-03-21 03:39:00 --> Helper loaded: common_helper
INFO - 2022-03-21 03:39:00 --> Database Driver Class Initialized
DEBUG - 2022-03-21 03:39:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 03:39:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 03:39:00 --> Controller Class Initialized
INFO - 2022-03-21 03:39:00 --> Form Validation Class Initialized
DEBUG - 2022-03-21 03:39:00 --> Encrypt Class Initialized
DEBUG - 2022-03-21 03:39:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 03:39:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-21 03:39:00 --> Email Class Initialized
INFO - 2022-03-21 03:39:00 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-21 03:39:00 --> Calendar Class Initialized
INFO - 2022-03-21 03:39:00 --> Model "Login_model" initialized
INFO - 2022-03-21 03:39:00 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-21 03:39:00 --> Final output sent to browser
DEBUG - 2022-03-21 03:39:00 --> Total execution time: 0.0268
ERROR - 2022-03-21 03:40:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 03:40:09 --> Config Class Initialized
INFO - 2022-03-21 03:40:09 --> Hooks Class Initialized
DEBUG - 2022-03-21 03:40:09 --> UTF-8 Support Enabled
INFO - 2022-03-21 03:40:09 --> Utf8 Class Initialized
INFO - 2022-03-21 03:40:09 --> URI Class Initialized
INFO - 2022-03-21 03:40:09 --> Router Class Initialized
INFO - 2022-03-21 03:40:09 --> Output Class Initialized
INFO - 2022-03-21 03:40:09 --> Security Class Initialized
DEBUG - 2022-03-21 03:40:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 03:40:09 --> Input Class Initialized
INFO - 2022-03-21 03:40:09 --> Language Class Initialized
INFO - 2022-03-21 03:40:09 --> Loader Class Initialized
INFO - 2022-03-21 03:40:09 --> Helper loaded: url_helper
INFO - 2022-03-21 03:40:09 --> Helper loaded: form_helper
INFO - 2022-03-21 03:40:09 --> Helper loaded: common_helper
INFO - 2022-03-21 03:40:09 --> Database Driver Class Initialized
DEBUG - 2022-03-21 03:40:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 03:40:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 03:40:09 --> Controller Class Initialized
INFO - 2022-03-21 03:40:09 --> Form Validation Class Initialized
DEBUG - 2022-03-21 03:40:09 --> Encrypt Class Initialized
DEBUG - 2022-03-21 03:40:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 03:40:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-21 03:40:09 --> Email Class Initialized
INFO - 2022-03-21 03:40:09 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-21 03:40:09 --> Calendar Class Initialized
INFO - 2022-03-21 03:40:09 --> Model "Login_model" initialized
INFO - 2022-03-21 03:40:09 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-03-21 03:40:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 03:40:10 --> Config Class Initialized
INFO - 2022-03-21 03:40:10 --> Hooks Class Initialized
DEBUG - 2022-03-21 03:40:10 --> UTF-8 Support Enabled
INFO - 2022-03-21 03:40:10 --> Utf8 Class Initialized
INFO - 2022-03-21 03:40:10 --> URI Class Initialized
INFO - 2022-03-21 03:40:10 --> Router Class Initialized
INFO - 2022-03-21 03:40:10 --> Output Class Initialized
INFO - 2022-03-21 03:40:10 --> Security Class Initialized
DEBUG - 2022-03-21 03:40:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 03:40:10 --> Input Class Initialized
INFO - 2022-03-21 03:40:10 --> Language Class Initialized
INFO - 2022-03-21 03:40:10 --> Loader Class Initialized
INFO - 2022-03-21 03:40:10 --> Helper loaded: url_helper
INFO - 2022-03-21 03:40:10 --> Helper loaded: form_helper
INFO - 2022-03-21 03:40:10 --> Helper loaded: common_helper
INFO - 2022-03-21 03:40:10 --> Database Driver Class Initialized
DEBUG - 2022-03-21 03:40:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 03:40:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 03:40:10 --> Controller Class Initialized
INFO - 2022-03-21 03:40:10 --> Form Validation Class Initialized
DEBUG - 2022-03-21 03:40:10 --> Encrypt Class Initialized
INFO - 2022-03-21 03:40:10 --> Model "Login_model" initialized
INFO - 2022-03-21 03:40:10 --> Model "Dashboard_model" initialized
INFO - 2022-03-21 03:40:10 --> Model "Case_model" initialized
INFO - 2022-03-21 03:40:13 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-21 03:40:13 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2022-03-21 03:40:13 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-21 03:40:13 --> Final output sent to browser
DEBUG - 2022-03-21 03:40:13 --> Total execution time: 2.8877
ERROR - 2022-03-21 03:40:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 03:40:27 --> Config Class Initialized
INFO - 2022-03-21 03:40:27 --> Hooks Class Initialized
DEBUG - 2022-03-21 03:40:27 --> UTF-8 Support Enabled
INFO - 2022-03-21 03:40:27 --> Utf8 Class Initialized
INFO - 2022-03-21 03:40:27 --> URI Class Initialized
INFO - 2022-03-21 03:40:27 --> Router Class Initialized
INFO - 2022-03-21 03:40:27 --> Output Class Initialized
INFO - 2022-03-21 03:40:27 --> Security Class Initialized
DEBUG - 2022-03-21 03:40:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 03:40:27 --> Input Class Initialized
INFO - 2022-03-21 03:40:27 --> Language Class Initialized
INFO - 2022-03-21 03:40:27 --> Loader Class Initialized
INFO - 2022-03-21 03:40:27 --> Helper loaded: url_helper
INFO - 2022-03-21 03:40:27 --> Helper loaded: form_helper
INFO - 2022-03-21 03:40:27 --> Helper loaded: common_helper
INFO - 2022-03-21 03:40:27 --> Database Driver Class Initialized
DEBUG - 2022-03-21 03:40:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 03:40:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 03:40:27 --> Controller Class Initialized
INFO - 2022-03-21 03:40:27 --> Form Validation Class Initialized
DEBUG - 2022-03-21 03:40:27 --> Encrypt Class Initialized
INFO - 2022-03-21 03:40:27 --> Model "Patient_model" initialized
INFO - 2022-03-21 03:40:27 --> Model "Patientcase_model" initialized
INFO - 2022-03-21 03:40:27 --> Model "Referredby_model" initialized
INFO - 2022-03-21 03:40:27 --> Model "Prefix_master" initialized
INFO - 2022-03-21 03:40:27 --> Model "Hospital_model" initialized
INFO - 2022-03-21 03:40:27 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-21 03:40:27 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-21 03:40:27 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-21 03:40:27 --> Final output sent to browser
DEBUG - 2022-03-21 03:40:27 --> Total execution time: 0.1068
ERROR - 2022-03-21 03:40:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 03:40:52 --> Config Class Initialized
INFO - 2022-03-21 03:40:52 --> Hooks Class Initialized
DEBUG - 2022-03-21 03:40:52 --> UTF-8 Support Enabled
INFO - 2022-03-21 03:40:52 --> Utf8 Class Initialized
INFO - 2022-03-21 03:40:52 --> URI Class Initialized
INFO - 2022-03-21 03:40:52 --> Router Class Initialized
INFO - 2022-03-21 03:40:52 --> Output Class Initialized
INFO - 2022-03-21 03:40:52 --> Security Class Initialized
DEBUG - 2022-03-21 03:40:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 03:40:52 --> Input Class Initialized
INFO - 2022-03-21 03:40:52 --> Language Class Initialized
INFO - 2022-03-21 03:40:52 --> Loader Class Initialized
INFO - 2022-03-21 03:40:52 --> Helper loaded: url_helper
INFO - 2022-03-21 03:40:52 --> Helper loaded: form_helper
INFO - 2022-03-21 03:40:52 --> Helper loaded: common_helper
INFO - 2022-03-21 03:40:52 --> Database Driver Class Initialized
DEBUG - 2022-03-21 03:40:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 03:40:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 03:40:52 --> Controller Class Initialized
INFO - 2022-03-21 03:40:52 --> Form Validation Class Initialized
DEBUG - 2022-03-21 03:40:52 --> Encrypt Class Initialized
INFO - 2022-03-21 03:40:52 --> Model "Patient_model" initialized
INFO - 2022-03-21 03:40:52 --> Model "Patientcase_model" initialized
INFO - 2022-03-21 03:40:52 --> Model "Prefix_master" initialized
INFO - 2022-03-21 03:40:52 --> Model "Users_model" initialized
INFO - 2022-03-21 03:40:52 --> Model "Hospital_model" initialized
INFO - 2022-03-21 03:40:53 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-21 03:40:54 --> Final output sent to browser
DEBUG - 2022-03-21 03:40:54 --> Total execution time: 1.9618
ERROR - 2022-03-21 03:46:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 03:46:43 --> Config Class Initialized
INFO - 2022-03-21 03:46:43 --> Hooks Class Initialized
DEBUG - 2022-03-21 03:46:43 --> UTF-8 Support Enabled
INFO - 2022-03-21 03:46:43 --> Utf8 Class Initialized
INFO - 2022-03-21 03:46:43 --> URI Class Initialized
INFO - 2022-03-21 03:46:43 --> Router Class Initialized
INFO - 2022-03-21 03:46:43 --> Output Class Initialized
INFO - 2022-03-21 03:46:43 --> Security Class Initialized
DEBUG - 2022-03-21 03:46:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 03:46:43 --> Input Class Initialized
INFO - 2022-03-21 03:46:43 --> Language Class Initialized
INFO - 2022-03-21 03:46:43 --> Loader Class Initialized
INFO - 2022-03-21 03:46:43 --> Helper loaded: url_helper
INFO - 2022-03-21 03:46:43 --> Helper loaded: form_helper
INFO - 2022-03-21 03:46:43 --> Helper loaded: common_helper
INFO - 2022-03-21 03:46:43 --> Database Driver Class Initialized
DEBUG - 2022-03-21 03:46:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 03:46:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 03:46:43 --> Controller Class Initialized
INFO - 2022-03-21 03:46:43 --> Form Validation Class Initialized
DEBUG - 2022-03-21 03:46:43 --> Encrypt Class Initialized
INFO - 2022-03-21 03:46:43 --> Model "Patient_model" initialized
INFO - 2022-03-21 03:46:43 --> Model "Patientcase_model" initialized
INFO - 2022-03-21 03:46:43 --> Model "Prefix_master" initialized
INFO - 2022-03-21 03:46:43 --> Model "Users_model" initialized
INFO - 2022-03-21 03:46:43 --> Model "Hospital_model" initialized
INFO - 2022-03-21 03:46:45 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-21 03:46:46 --> Final output sent to browser
DEBUG - 2022-03-21 03:46:46 --> Total execution time: 3.4575
ERROR - 2022-03-21 03:49:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 03:49:36 --> Config Class Initialized
INFO - 2022-03-21 03:49:36 --> Hooks Class Initialized
DEBUG - 2022-03-21 03:49:36 --> UTF-8 Support Enabled
INFO - 2022-03-21 03:49:36 --> Utf8 Class Initialized
INFO - 2022-03-21 03:49:36 --> URI Class Initialized
INFO - 2022-03-21 03:49:36 --> Router Class Initialized
INFO - 2022-03-21 03:49:36 --> Output Class Initialized
INFO - 2022-03-21 03:49:36 --> Security Class Initialized
DEBUG - 2022-03-21 03:49:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 03:49:36 --> Input Class Initialized
INFO - 2022-03-21 03:49:36 --> Language Class Initialized
INFO - 2022-03-21 03:49:36 --> Loader Class Initialized
INFO - 2022-03-21 03:49:36 --> Helper loaded: url_helper
INFO - 2022-03-21 03:49:36 --> Helper loaded: form_helper
INFO - 2022-03-21 03:49:36 --> Helper loaded: common_helper
INFO - 2022-03-21 03:49:36 --> Database Driver Class Initialized
DEBUG - 2022-03-21 03:49:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 03:49:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 03:49:36 --> Controller Class Initialized
INFO - 2022-03-21 03:49:36 --> Form Validation Class Initialized
DEBUG - 2022-03-21 03:49:36 --> Encrypt Class Initialized
INFO - 2022-03-21 03:49:36 --> Model "Patient_model" initialized
INFO - 2022-03-21 03:49:36 --> Model "Patientcase_model" initialized
INFO - 2022-03-21 03:49:36 --> Model "Prefix_master" initialized
INFO - 2022-03-21 03:49:36 --> Model "Users_model" initialized
INFO - 2022-03-21 03:49:36 --> Model "Hospital_model" initialized
INFO - 2022-03-21 03:49:38 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-21 03:49:39 --> Final output sent to browser
DEBUG - 2022-03-21 03:49:39 --> Total execution time: 2.9640
ERROR - 2022-03-21 03:51:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 03:51:52 --> Config Class Initialized
INFO - 2022-03-21 03:51:52 --> Hooks Class Initialized
DEBUG - 2022-03-21 03:51:52 --> UTF-8 Support Enabled
INFO - 2022-03-21 03:51:52 --> Utf8 Class Initialized
INFO - 2022-03-21 03:51:52 --> URI Class Initialized
INFO - 2022-03-21 03:51:52 --> Router Class Initialized
INFO - 2022-03-21 03:51:52 --> Output Class Initialized
INFO - 2022-03-21 03:51:52 --> Security Class Initialized
DEBUG - 2022-03-21 03:51:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 03:51:52 --> Input Class Initialized
INFO - 2022-03-21 03:51:52 --> Language Class Initialized
INFO - 2022-03-21 03:51:52 --> Loader Class Initialized
INFO - 2022-03-21 03:51:52 --> Helper loaded: url_helper
INFO - 2022-03-21 03:51:52 --> Helper loaded: form_helper
INFO - 2022-03-21 03:51:52 --> Helper loaded: common_helper
INFO - 2022-03-21 03:51:52 --> Database Driver Class Initialized
DEBUG - 2022-03-21 03:51:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 03:51:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 03:51:52 --> Controller Class Initialized
INFO - 2022-03-21 03:51:52 --> Form Validation Class Initialized
DEBUG - 2022-03-21 03:51:52 --> Encrypt Class Initialized
INFO - 2022-03-21 03:51:52 --> Model "Patient_model" initialized
INFO - 2022-03-21 03:51:52 --> Model "Patientcase_model" initialized
INFO - 2022-03-21 03:51:52 --> Model "Prefix_master" initialized
INFO - 2022-03-21 03:51:52 --> Model "Users_model" initialized
INFO - 2022-03-21 03:51:52 --> Model "Hospital_model" initialized
INFO - 2022-03-21 03:51:56 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-21 03:51:56 --> Final output sent to browser
DEBUG - 2022-03-21 03:51:56 --> Total execution time: 3.9278
ERROR - 2022-03-21 03:53:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 03:53:39 --> Config Class Initialized
INFO - 2022-03-21 03:53:39 --> Hooks Class Initialized
DEBUG - 2022-03-21 03:53:39 --> UTF-8 Support Enabled
INFO - 2022-03-21 03:53:39 --> Utf8 Class Initialized
INFO - 2022-03-21 03:53:39 --> URI Class Initialized
INFO - 2022-03-21 03:53:39 --> Router Class Initialized
INFO - 2022-03-21 03:53:39 --> Output Class Initialized
INFO - 2022-03-21 03:53:39 --> Security Class Initialized
DEBUG - 2022-03-21 03:53:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 03:53:39 --> Input Class Initialized
INFO - 2022-03-21 03:53:39 --> Language Class Initialized
INFO - 2022-03-21 03:53:39 --> Loader Class Initialized
INFO - 2022-03-21 03:53:39 --> Helper loaded: url_helper
INFO - 2022-03-21 03:53:39 --> Helper loaded: form_helper
INFO - 2022-03-21 03:53:39 --> Helper loaded: common_helper
INFO - 2022-03-21 03:53:39 --> Database Driver Class Initialized
DEBUG - 2022-03-21 03:53:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 03:53:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 03:53:39 --> Controller Class Initialized
INFO - 2022-03-21 03:53:39 --> Form Validation Class Initialized
DEBUG - 2022-03-21 03:53:39 --> Encrypt Class Initialized
INFO - 2022-03-21 03:53:39 --> Model "Patient_model" initialized
INFO - 2022-03-21 03:53:39 --> Model "Patientcase_model" initialized
INFO - 2022-03-21 03:53:39 --> Model "Prefix_master" initialized
INFO - 2022-03-21 03:53:39 --> Model "Users_model" initialized
INFO - 2022-03-21 03:53:39 --> Model "Hospital_model" initialized
INFO - 2022-03-21 03:53:39 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-21 03:53:40 --> Final output sent to browser
DEBUG - 2022-03-21 03:53:40 --> Total execution time: 1.0298
ERROR - 2022-03-21 03:53:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 03:53:53 --> Config Class Initialized
INFO - 2022-03-21 03:53:53 --> Hooks Class Initialized
DEBUG - 2022-03-21 03:53:53 --> UTF-8 Support Enabled
INFO - 2022-03-21 03:53:53 --> Utf8 Class Initialized
INFO - 2022-03-21 03:53:53 --> URI Class Initialized
INFO - 2022-03-21 03:53:53 --> Router Class Initialized
INFO - 2022-03-21 03:53:53 --> Output Class Initialized
INFO - 2022-03-21 03:53:53 --> Security Class Initialized
DEBUG - 2022-03-21 03:53:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 03:53:53 --> Input Class Initialized
INFO - 2022-03-21 03:53:53 --> Language Class Initialized
INFO - 2022-03-21 03:53:53 --> Loader Class Initialized
INFO - 2022-03-21 03:53:53 --> Helper loaded: url_helper
INFO - 2022-03-21 03:53:53 --> Helper loaded: form_helper
INFO - 2022-03-21 03:53:53 --> Helper loaded: common_helper
INFO - 2022-03-21 03:53:53 --> Database Driver Class Initialized
DEBUG - 2022-03-21 03:53:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 03:53:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 03:53:53 --> Controller Class Initialized
INFO - 2022-03-21 03:53:53 --> Form Validation Class Initialized
DEBUG - 2022-03-21 03:53:53 --> Encrypt Class Initialized
INFO - 2022-03-21 03:53:53 --> Model "Patient_model" initialized
INFO - 2022-03-21 03:53:53 --> Model "Patientcase_model" initialized
INFO - 2022-03-21 03:53:53 --> Model "Prefix_master" initialized
INFO - 2022-03-21 03:53:53 --> Model "Users_model" initialized
INFO - 2022-03-21 03:53:53 --> Model "Hospital_model" initialized
INFO - 2022-03-21 03:53:53 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-21 03:53:54 --> Final output sent to browser
DEBUG - 2022-03-21 03:53:54 --> Total execution time: 1.1024
ERROR - 2022-03-21 03:55:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 03:55:56 --> Config Class Initialized
INFO - 2022-03-21 03:55:56 --> Hooks Class Initialized
DEBUG - 2022-03-21 03:55:56 --> UTF-8 Support Enabled
INFO - 2022-03-21 03:55:56 --> Utf8 Class Initialized
INFO - 2022-03-21 03:55:56 --> URI Class Initialized
INFO - 2022-03-21 03:55:56 --> Router Class Initialized
INFO - 2022-03-21 03:55:56 --> Output Class Initialized
INFO - 2022-03-21 03:55:56 --> Security Class Initialized
DEBUG - 2022-03-21 03:55:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 03:55:56 --> Input Class Initialized
INFO - 2022-03-21 03:55:56 --> Language Class Initialized
INFO - 2022-03-21 03:55:56 --> Loader Class Initialized
INFO - 2022-03-21 03:55:56 --> Helper loaded: url_helper
INFO - 2022-03-21 03:55:56 --> Helper loaded: form_helper
INFO - 2022-03-21 03:55:56 --> Helper loaded: common_helper
INFO - 2022-03-21 03:55:56 --> Database Driver Class Initialized
DEBUG - 2022-03-21 03:55:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 03:55:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 03:55:56 --> Controller Class Initialized
INFO - 2022-03-21 03:55:56 --> Form Validation Class Initialized
DEBUG - 2022-03-21 03:55:56 --> Encrypt Class Initialized
INFO - 2022-03-21 03:55:56 --> Model "Patient_model" initialized
INFO - 2022-03-21 03:55:56 --> Model "Patientcase_model" initialized
INFO - 2022-03-21 03:55:56 --> Model "Prefix_master" initialized
INFO - 2022-03-21 03:55:56 --> Model "Users_model" initialized
INFO - 2022-03-21 03:55:56 --> Model "Hospital_model" initialized
INFO - 2022-03-21 03:55:57 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-21 03:55:57 --> Final output sent to browser
DEBUG - 2022-03-21 03:55:57 --> Total execution time: 0.8527
ERROR - 2022-03-21 04:00:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 04:00:34 --> Config Class Initialized
INFO - 2022-03-21 04:00:34 --> Hooks Class Initialized
DEBUG - 2022-03-21 04:00:34 --> UTF-8 Support Enabled
INFO - 2022-03-21 04:00:34 --> Utf8 Class Initialized
INFO - 2022-03-21 04:00:34 --> URI Class Initialized
INFO - 2022-03-21 04:00:34 --> Router Class Initialized
INFO - 2022-03-21 04:00:34 --> Output Class Initialized
INFO - 2022-03-21 04:00:34 --> Security Class Initialized
DEBUG - 2022-03-21 04:00:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 04:00:34 --> Input Class Initialized
INFO - 2022-03-21 04:00:34 --> Language Class Initialized
INFO - 2022-03-21 04:00:34 --> Loader Class Initialized
INFO - 2022-03-21 04:00:34 --> Helper loaded: url_helper
INFO - 2022-03-21 04:00:34 --> Helper loaded: form_helper
INFO - 2022-03-21 04:00:34 --> Helper loaded: common_helper
INFO - 2022-03-21 04:00:34 --> Database Driver Class Initialized
DEBUG - 2022-03-21 04:00:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 04:00:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 04:00:34 --> Controller Class Initialized
INFO - 2022-03-21 04:00:34 --> Form Validation Class Initialized
DEBUG - 2022-03-21 04:00:34 --> Encrypt Class Initialized
INFO - 2022-03-21 04:00:34 --> Model "Patient_model" initialized
INFO - 2022-03-21 04:00:34 --> Model "Patientcase_model" initialized
INFO - 2022-03-21 04:00:34 --> Model "Prefix_master" initialized
INFO - 2022-03-21 04:00:34 --> Model "Users_model" initialized
INFO - 2022-03-21 04:00:34 --> Model "Hospital_model" initialized
INFO - 2022-03-21 04:00:34 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-21 04:00:35 --> Final output sent to browser
DEBUG - 2022-03-21 04:00:35 --> Total execution time: 1.2185
ERROR - 2022-03-21 04:00:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 04:00:40 --> Config Class Initialized
INFO - 2022-03-21 04:00:40 --> Hooks Class Initialized
DEBUG - 2022-03-21 04:00:40 --> UTF-8 Support Enabled
INFO - 2022-03-21 04:00:40 --> Utf8 Class Initialized
INFO - 2022-03-21 04:00:40 --> URI Class Initialized
INFO - 2022-03-21 04:00:40 --> Router Class Initialized
INFO - 2022-03-21 04:00:40 --> Output Class Initialized
INFO - 2022-03-21 04:00:40 --> Security Class Initialized
DEBUG - 2022-03-21 04:00:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 04:00:40 --> Input Class Initialized
INFO - 2022-03-21 04:00:40 --> Language Class Initialized
INFO - 2022-03-21 04:00:40 --> Loader Class Initialized
INFO - 2022-03-21 04:00:40 --> Helper loaded: url_helper
INFO - 2022-03-21 04:00:40 --> Helper loaded: form_helper
INFO - 2022-03-21 04:00:40 --> Helper loaded: common_helper
INFO - 2022-03-21 04:00:40 --> Database Driver Class Initialized
DEBUG - 2022-03-21 04:00:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 04:00:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 04:00:40 --> Controller Class Initialized
INFO - 2022-03-21 04:00:40 --> Form Validation Class Initialized
DEBUG - 2022-03-21 04:00:40 --> Encrypt Class Initialized
INFO - 2022-03-21 04:00:40 --> Model "Patient_model" initialized
INFO - 2022-03-21 04:00:40 --> Model "Patientcase_model" initialized
INFO - 2022-03-21 04:00:40 --> Model "Prefix_master" initialized
INFO - 2022-03-21 04:00:40 --> Model "Users_model" initialized
INFO - 2022-03-21 04:00:40 --> Model "Hospital_model" initialized
INFO - 2022-03-21 04:00:40 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-21 04:00:41 --> Final output sent to browser
DEBUG - 2022-03-21 04:00:41 --> Total execution time: 0.9369
ERROR - 2022-03-21 04:00:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 04:00:49 --> Config Class Initialized
INFO - 2022-03-21 04:00:49 --> Hooks Class Initialized
DEBUG - 2022-03-21 04:00:49 --> UTF-8 Support Enabled
INFO - 2022-03-21 04:00:49 --> Utf8 Class Initialized
INFO - 2022-03-21 04:00:49 --> URI Class Initialized
INFO - 2022-03-21 04:00:49 --> Router Class Initialized
INFO - 2022-03-21 04:00:49 --> Output Class Initialized
INFO - 2022-03-21 04:00:49 --> Security Class Initialized
DEBUG - 2022-03-21 04:00:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 04:00:49 --> Input Class Initialized
INFO - 2022-03-21 04:00:49 --> Language Class Initialized
INFO - 2022-03-21 04:00:49 --> Loader Class Initialized
INFO - 2022-03-21 04:00:49 --> Helper loaded: url_helper
INFO - 2022-03-21 04:00:49 --> Helper loaded: form_helper
INFO - 2022-03-21 04:00:49 --> Helper loaded: common_helper
INFO - 2022-03-21 04:00:49 --> Database Driver Class Initialized
DEBUG - 2022-03-21 04:00:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 04:00:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 04:00:49 --> Controller Class Initialized
INFO - 2022-03-21 04:00:49 --> Form Validation Class Initialized
DEBUG - 2022-03-21 04:00:49 --> Encrypt Class Initialized
INFO - 2022-03-21 04:00:49 --> Model "Patient_model" initialized
INFO - 2022-03-21 04:00:49 --> Model "Patientcase_model" initialized
INFO - 2022-03-21 04:00:49 --> Model "Prefix_master" initialized
INFO - 2022-03-21 04:00:49 --> Model "Users_model" initialized
INFO - 2022-03-21 04:00:49 --> Model "Hospital_model" initialized
INFO - 2022-03-21 04:00:49 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-21 04:00:50 --> Final output sent to browser
DEBUG - 2022-03-21 04:00:50 --> Total execution time: 1.1247
ERROR - 2022-03-21 04:00:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 04:00:57 --> Config Class Initialized
INFO - 2022-03-21 04:00:57 --> Hooks Class Initialized
DEBUG - 2022-03-21 04:00:57 --> UTF-8 Support Enabled
INFO - 2022-03-21 04:00:57 --> Utf8 Class Initialized
INFO - 2022-03-21 04:00:57 --> URI Class Initialized
INFO - 2022-03-21 04:00:57 --> Router Class Initialized
INFO - 2022-03-21 04:00:57 --> Output Class Initialized
INFO - 2022-03-21 04:00:57 --> Security Class Initialized
DEBUG - 2022-03-21 04:00:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 04:00:57 --> Input Class Initialized
INFO - 2022-03-21 04:00:57 --> Language Class Initialized
INFO - 2022-03-21 04:00:57 --> Loader Class Initialized
INFO - 2022-03-21 04:00:57 --> Helper loaded: url_helper
INFO - 2022-03-21 04:00:57 --> Helper loaded: form_helper
INFO - 2022-03-21 04:00:57 --> Helper loaded: common_helper
INFO - 2022-03-21 04:00:57 --> Database Driver Class Initialized
DEBUG - 2022-03-21 04:00:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 04:00:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 04:00:57 --> Controller Class Initialized
INFO - 2022-03-21 04:00:57 --> Form Validation Class Initialized
DEBUG - 2022-03-21 04:00:57 --> Encrypt Class Initialized
INFO - 2022-03-21 04:00:57 --> Model "Patient_model" initialized
INFO - 2022-03-21 04:00:57 --> Model "Patientcase_model" initialized
INFO - 2022-03-21 04:00:57 --> Model "Prefix_master" initialized
INFO - 2022-03-21 04:00:57 --> Model "Users_model" initialized
INFO - 2022-03-21 04:00:57 --> Model "Hospital_model" initialized
INFO - 2022-03-21 04:00:57 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-21 04:00:58 --> Final output sent to browser
DEBUG - 2022-03-21 04:00:58 --> Total execution time: 1.1381
ERROR - 2022-03-21 04:01:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 04:01:09 --> Config Class Initialized
INFO - 2022-03-21 04:01:09 --> Hooks Class Initialized
DEBUG - 2022-03-21 04:01:09 --> UTF-8 Support Enabled
INFO - 2022-03-21 04:01:09 --> Utf8 Class Initialized
INFO - 2022-03-21 04:01:09 --> URI Class Initialized
INFO - 2022-03-21 04:01:09 --> Router Class Initialized
INFO - 2022-03-21 04:01:09 --> Output Class Initialized
INFO - 2022-03-21 04:01:09 --> Security Class Initialized
DEBUG - 2022-03-21 04:01:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 04:01:09 --> Input Class Initialized
INFO - 2022-03-21 04:01:09 --> Language Class Initialized
INFO - 2022-03-21 04:01:09 --> Loader Class Initialized
INFO - 2022-03-21 04:01:09 --> Helper loaded: url_helper
INFO - 2022-03-21 04:01:09 --> Helper loaded: form_helper
INFO - 2022-03-21 04:01:09 --> Helper loaded: common_helper
INFO - 2022-03-21 04:01:09 --> Database Driver Class Initialized
DEBUG - 2022-03-21 04:01:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 04:01:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 04:01:09 --> Controller Class Initialized
INFO - 2022-03-21 04:01:09 --> Form Validation Class Initialized
DEBUG - 2022-03-21 04:01:09 --> Encrypt Class Initialized
INFO - 2022-03-21 04:01:09 --> Model "Patient_model" initialized
INFO - 2022-03-21 04:01:09 --> Model "Patientcase_model" initialized
INFO - 2022-03-21 04:01:09 --> Model "Prefix_master" initialized
INFO - 2022-03-21 04:01:09 --> Model "Users_model" initialized
INFO - 2022-03-21 04:01:09 --> Model "Hospital_model" initialized
INFO - 2022-03-21 04:01:09 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-21 04:01:11 --> Final output sent to browser
DEBUG - 2022-03-21 04:01:11 --> Total execution time: 2.4776
ERROR - 2022-03-21 04:01:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 04:01:30 --> Config Class Initialized
INFO - 2022-03-21 04:01:30 --> Hooks Class Initialized
DEBUG - 2022-03-21 04:01:30 --> UTF-8 Support Enabled
INFO - 2022-03-21 04:01:30 --> Utf8 Class Initialized
INFO - 2022-03-21 04:01:30 --> URI Class Initialized
INFO - 2022-03-21 04:01:30 --> Router Class Initialized
INFO - 2022-03-21 04:01:30 --> Output Class Initialized
INFO - 2022-03-21 04:01:30 --> Security Class Initialized
DEBUG - 2022-03-21 04:01:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 04:01:30 --> Input Class Initialized
INFO - 2022-03-21 04:01:30 --> Language Class Initialized
INFO - 2022-03-21 04:01:30 --> Loader Class Initialized
INFO - 2022-03-21 04:01:30 --> Helper loaded: url_helper
INFO - 2022-03-21 04:01:30 --> Helper loaded: form_helper
INFO - 2022-03-21 04:01:30 --> Helper loaded: common_helper
INFO - 2022-03-21 04:01:30 --> Database Driver Class Initialized
DEBUG - 2022-03-21 04:01:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 04:01:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 04:01:30 --> Controller Class Initialized
INFO - 2022-03-21 04:01:30 --> Form Validation Class Initialized
DEBUG - 2022-03-21 04:01:30 --> Encrypt Class Initialized
INFO - 2022-03-21 04:01:30 --> Model "Patient_model" initialized
INFO - 2022-03-21 04:01:30 --> Model "Patientcase_model" initialized
INFO - 2022-03-21 04:01:30 --> Model "Prefix_master" initialized
INFO - 2022-03-21 04:01:30 --> Model "Users_model" initialized
INFO - 2022-03-21 04:01:30 --> Model "Hospital_model" initialized
INFO - 2022-03-21 04:01:30 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-21 04:01:31 --> Final output sent to browser
DEBUG - 2022-03-21 04:01:31 --> Total execution time: 1.5314
ERROR - 2022-03-21 04:01:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 04:01:37 --> Config Class Initialized
INFO - 2022-03-21 04:01:37 --> Hooks Class Initialized
DEBUG - 2022-03-21 04:01:37 --> UTF-8 Support Enabled
INFO - 2022-03-21 04:01:37 --> Utf8 Class Initialized
INFO - 2022-03-21 04:01:37 --> URI Class Initialized
INFO - 2022-03-21 04:01:37 --> Router Class Initialized
INFO - 2022-03-21 04:01:37 --> Output Class Initialized
INFO - 2022-03-21 04:01:37 --> Security Class Initialized
DEBUG - 2022-03-21 04:01:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 04:01:37 --> Input Class Initialized
INFO - 2022-03-21 04:01:37 --> Language Class Initialized
INFO - 2022-03-21 04:01:37 --> Loader Class Initialized
INFO - 2022-03-21 04:01:37 --> Helper loaded: url_helper
INFO - 2022-03-21 04:01:37 --> Helper loaded: form_helper
INFO - 2022-03-21 04:01:37 --> Helper loaded: common_helper
INFO - 2022-03-21 04:01:37 --> Database Driver Class Initialized
DEBUG - 2022-03-21 04:01:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 04:01:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 04:01:37 --> Controller Class Initialized
INFO - 2022-03-21 04:01:37 --> Form Validation Class Initialized
DEBUG - 2022-03-21 04:01:37 --> Encrypt Class Initialized
INFO - 2022-03-21 04:01:37 --> Model "Patient_model" initialized
INFO - 2022-03-21 04:01:37 --> Model "Patientcase_model" initialized
INFO - 2022-03-21 04:01:37 --> Model "Prefix_master" initialized
INFO - 2022-03-21 04:01:37 --> Model "Users_model" initialized
INFO - 2022-03-21 04:01:37 --> Model "Hospital_model" initialized
INFO - 2022-03-21 04:01:37 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-21 04:01:38 --> Final output sent to browser
DEBUG - 2022-03-21 04:01:38 --> Total execution time: 1.2149
ERROR - 2022-03-21 04:01:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 04:01:45 --> Config Class Initialized
INFO - 2022-03-21 04:01:45 --> Hooks Class Initialized
DEBUG - 2022-03-21 04:01:45 --> UTF-8 Support Enabled
INFO - 2022-03-21 04:01:45 --> Utf8 Class Initialized
INFO - 2022-03-21 04:01:45 --> URI Class Initialized
INFO - 2022-03-21 04:01:45 --> Router Class Initialized
INFO - 2022-03-21 04:01:45 --> Output Class Initialized
INFO - 2022-03-21 04:01:45 --> Security Class Initialized
DEBUG - 2022-03-21 04:01:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 04:01:45 --> Input Class Initialized
INFO - 2022-03-21 04:01:45 --> Language Class Initialized
INFO - 2022-03-21 04:01:45 --> Loader Class Initialized
INFO - 2022-03-21 04:01:45 --> Helper loaded: url_helper
INFO - 2022-03-21 04:01:45 --> Helper loaded: form_helper
INFO - 2022-03-21 04:01:45 --> Helper loaded: common_helper
INFO - 2022-03-21 04:01:45 --> Database Driver Class Initialized
DEBUG - 2022-03-21 04:01:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 04:01:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 04:01:45 --> Controller Class Initialized
INFO - 2022-03-21 04:01:45 --> Form Validation Class Initialized
DEBUG - 2022-03-21 04:01:45 --> Encrypt Class Initialized
INFO - 2022-03-21 04:01:45 --> Model "Patient_model" initialized
INFO - 2022-03-21 04:01:45 --> Model "Patientcase_model" initialized
INFO - 2022-03-21 04:01:45 --> Model "Prefix_master" initialized
INFO - 2022-03-21 04:01:45 --> Model "Users_model" initialized
INFO - 2022-03-21 04:01:45 --> Model "Hospital_model" initialized
INFO - 2022-03-21 04:01:46 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-21 04:01:47 --> Final output sent to browser
DEBUG - 2022-03-21 04:01:47 --> Total execution time: 1.3109
ERROR - 2022-03-21 04:01:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 04:01:54 --> Config Class Initialized
INFO - 2022-03-21 04:01:54 --> Hooks Class Initialized
DEBUG - 2022-03-21 04:01:54 --> UTF-8 Support Enabled
INFO - 2022-03-21 04:01:54 --> Utf8 Class Initialized
INFO - 2022-03-21 04:01:54 --> URI Class Initialized
INFO - 2022-03-21 04:01:54 --> Router Class Initialized
INFO - 2022-03-21 04:01:54 --> Output Class Initialized
INFO - 2022-03-21 04:01:54 --> Security Class Initialized
DEBUG - 2022-03-21 04:01:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 04:01:54 --> Input Class Initialized
INFO - 2022-03-21 04:01:54 --> Language Class Initialized
INFO - 2022-03-21 04:01:54 --> Loader Class Initialized
INFO - 2022-03-21 04:01:54 --> Helper loaded: url_helper
INFO - 2022-03-21 04:01:54 --> Helper loaded: form_helper
INFO - 2022-03-21 04:01:54 --> Helper loaded: common_helper
INFO - 2022-03-21 04:01:54 --> Database Driver Class Initialized
DEBUG - 2022-03-21 04:01:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 04:01:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 04:01:54 --> Controller Class Initialized
INFO - 2022-03-21 04:01:54 --> Form Validation Class Initialized
DEBUG - 2022-03-21 04:01:54 --> Encrypt Class Initialized
INFO - 2022-03-21 04:01:54 --> Model "Patient_model" initialized
INFO - 2022-03-21 04:01:54 --> Model "Patientcase_model" initialized
INFO - 2022-03-21 04:01:54 --> Model "Prefix_master" initialized
INFO - 2022-03-21 04:01:54 --> Model "Users_model" initialized
INFO - 2022-03-21 04:01:54 --> Model "Hospital_model" initialized
INFO - 2022-03-21 04:01:54 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
ERROR - 2022-03-21 04:01:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 04:01:56 --> Config Class Initialized
INFO - 2022-03-21 04:01:56 --> Hooks Class Initialized
DEBUG - 2022-03-21 04:01:56 --> UTF-8 Support Enabled
INFO - 2022-03-21 04:01:56 --> Utf8 Class Initialized
INFO - 2022-03-21 04:01:56 --> URI Class Initialized
INFO - 2022-03-21 04:01:56 --> Router Class Initialized
INFO - 2022-03-21 04:01:56 --> Output Class Initialized
INFO - 2022-03-21 04:01:56 --> Security Class Initialized
DEBUG - 2022-03-21 04:01:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 04:01:56 --> Input Class Initialized
INFO - 2022-03-21 04:01:56 --> Language Class Initialized
ERROR - 2022-03-21 04:01:56 --> 404 Page Not Found: Karoclient/images
ERROR - 2022-03-21 04:01:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 04:01:56 --> Config Class Initialized
INFO - 2022-03-21 04:01:56 --> Hooks Class Initialized
DEBUG - 2022-03-21 04:01:56 --> UTF-8 Support Enabled
INFO - 2022-03-21 04:01:56 --> Utf8 Class Initialized
INFO - 2022-03-21 04:01:56 --> URI Class Initialized
INFO - 2022-03-21 04:01:56 --> Router Class Initialized
INFO - 2022-03-21 04:01:56 --> Output Class Initialized
INFO - 2022-03-21 04:01:56 --> Security Class Initialized
DEBUG - 2022-03-21 04:01:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 04:01:56 --> Input Class Initialized
INFO - 2022-03-21 04:01:56 --> Language Class Initialized
ERROR - 2022-03-21 04:01:56 --> 404 Page Not Found: Karoclient/images
ERROR - 2022-03-21 04:01:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 04:01:57 --> Config Class Initialized
INFO - 2022-03-21 04:01:57 --> Hooks Class Initialized
DEBUG - 2022-03-21 04:01:57 --> UTF-8 Support Enabled
INFO - 2022-03-21 04:01:57 --> Utf8 Class Initialized
INFO - 2022-03-21 04:01:57 --> URI Class Initialized
INFO - 2022-03-21 04:01:57 --> Router Class Initialized
INFO - 2022-03-21 04:01:57 --> Output Class Initialized
INFO - 2022-03-21 04:01:57 --> Security Class Initialized
DEBUG - 2022-03-21 04:01:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 04:01:57 --> Input Class Initialized
INFO - 2022-03-21 04:01:57 --> Language Class Initialized
ERROR - 2022-03-21 04:01:57 --> 404 Page Not Found: Karoclient/images
INFO - 2022-03-21 04:01:58 --> Final output sent to browser
DEBUG - 2022-03-21 04:01:58 --> Total execution time: 3.4426
ERROR - 2022-03-21 04:02:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 04:02:15 --> Config Class Initialized
INFO - 2022-03-21 04:02:15 --> Hooks Class Initialized
DEBUG - 2022-03-21 04:02:15 --> UTF-8 Support Enabled
INFO - 2022-03-21 04:02:15 --> Utf8 Class Initialized
INFO - 2022-03-21 04:02:15 --> URI Class Initialized
INFO - 2022-03-21 04:02:15 --> Router Class Initialized
INFO - 2022-03-21 04:02:15 --> Output Class Initialized
INFO - 2022-03-21 04:02:15 --> Security Class Initialized
DEBUG - 2022-03-21 04:02:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 04:02:15 --> Input Class Initialized
INFO - 2022-03-21 04:02:15 --> Language Class Initialized
INFO - 2022-03-21 04:02:15 --> Loader Class Initialized
INFO - 2022-03-21 04:02:15 --> Helper loaded: url_helper
INFO - 2022-03-21 04:02:15 --> Helper loaded: form_helper
INFO - 2022-03-21 04:02:15 --> Helper loaded: common_helper
INFO - 2022-03-21 04:02:15 --> Database Driver Class Initialized
DEBUG - 2022-03-21 04:02:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 04:02:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 04:02:15 --> Controller Class Initialized
INFO - 2022-03-21 04:02:15 --> Form Validation Class Initialized
DEBUG - 2022-03-21 04:02:15 --> Encrypt Class Initialized
INFO - 2022-03-21 04:02:15 --> Model "Patient_model" initialized
INFO - 2022-03-21 04:02:15 --> Model "Patientcase_model" initialized
INFO - 2022-03-21 04:02:15 --> Model "Prefix_master" initialized
INFO - 2022-03-21 04:02:15 --> Model "Users_model" initialized
INFO - 2022-03-21 04:02:15 --> Model "Hospital_model" initialized
INFO - 2022-03-21 04:02:15 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-21 04:02:16 --> Final output sent to browser
DEBUG - 2022-03-21 04:02:16 --> Total execution time: 1.1540
ERROR - 2022-03-21 04:02:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 04:02:30 --> Config Class Initialized
INFO - 2022-03-21 04:02:30 --> Hooks Class Initialized
DEBUG - 2022-03-21 04:02:30 --> UTF-8 Support Enabled
INFO - 2022-03-21 04:02:30 --> Utf8 Class Initialized
INFO - 2022-03-21 04:02:30 --> URI Class Initialized
INFO - 2022-03-21 04:02:30 --> Router Class Initialized
INFO - 2022-03-21 04:02:30 --> Output Class Initialized
INFO - 2022-03-21 04:02:30 --> Security Class Initialized
DEBUG - 2022-03-21 04:02:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 04:02:30 --> Input Class Initialized
INFO - 2022-03-21 04:02:30 --> Language Class Initialized
INFO - 2022-03-21 04:02:30 --> Loader Class Initialized
INFO - 2022-03-21 04:02:30 --> Helper loaded: url_helper
INFO - 2022-03-21 04:02:30 --> Helper loaded: form_helper
INFO - 2022-03-21 04:02:30 --> Helper loaded: common_helper
INFO - 2022-03-21 04:02:30 --> Database Driver Class Initialized
DEBUG - 2022-03-21 04:02:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 04:02:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 04:02:30 --> Controller Class Initialized
INFO - 2022-03-21 04:02:30 --> Form Validation Class Initialized
DEBUG - 2022-03-21 04:02:30 --> Encrypt Class Initialized
INFO - 2022-03-21 04:02:30 --> Model "Patient_model" initialized
INFO - 2022-03-21 04:02:30 --> Model "Patientcase_model" initialized
INFO - 2022-03-21 04:02:30 --> Model "Referredby_model" initialized
INFO - 2022-03-21 04:02:30 --> Model "Prefix_master" initialized
INFO - 2022-03-21 04:02:30 --> Model "Hospital_model" initialized
INFO - 2022-03-21 04:02:30 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-21 04:02:30 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-21 04:02:30 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-21 04:02:30 --> Final output sent to browser
DEBUG - 2022-03-21 04:02:30 --> Total execution time: 0.0606
ERROR - 2022-03-21 04:03:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 04:03:45 --> Config Class Initialized
INFO - 2022-03-21 04:03:45 --> Hooks Class Initialized
DEBUG - 2022-03-21 04:03:45 --> UTF-8 Support Enabled
INFO - 2022-03-21 04:03:45 --> Utf8 Class Initialized
INFO - 2022-03-21 04:03:45 --> URI Class Initialized
INFO - 2022-03-21 04:03:45 --> Router Class Initialized
INFO - 2022-03-21 04:03:45 --> Output Class Initialized
INFO - 2022-03-21 04:03:45 --> Security Class Initialized
DEBUG - 2022-03-21 04:03:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 04:03:45 --> Input Class Initialized
INFO - 2022-03-21 04:03:45 --> Language Class Initialized
INFO - 2022-03-21 04:03:45 --> Loader Class Initialized
INFO - 2022-03-21 04:03:45 --> Helper loaded: url_helper
INFO - 2022-03-21 04:03:45 --> Helper loaded: form_helper
INFO - 2022-03-21 04:03:45 --> Helper loaded: common_helper
INFO - 2022-03-21 04:03:45 --> Database Driver Class Initialized
DEBUG - 2022-03-21 04:03:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 04:03:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 04:03:45 --> Controller Class Initialized
INFO - 2022-03-21 04:03:45 --> Form Validation Class Initialized
DEBUG - 2022-03-21 04:03:45 --> Encrypt Class Initialized
INFO - 2022-03-21 04:03:45 --> Model "Patient_model" initialized
INFO - 2022-03-21 04:03:45 --> Model "Patientcase_model" initialized
INFO - 2022-03-21 04:03:45 --> Model "Referredby_model" initialized
INFO - 2022-03-21 04:03:45 --> Model "Prefix_master" initialized
INFO - 2022-03-21 04:03:45 --> Model "Hospital_model" initialized
INFO - 2022-03-21 04:03:45 --> Upload Class Initialized
INFO - 2022-03-21 04:03:45 --> Final output sent to browser
DEBUG - 2022-03-21 04:03:45 --> Total execution time: 0.1061
ERROR - 2022-03-21 04:05:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 04:05:58 --> Config Class Initialized
INFO - 2022-03-21 04:05:58 --> Hooks Class Initialized
DEBUG - 2022-03-21 04:05:58 --> UTF-8 Support Enabled
INFO - 2022-03-21 04:05:58 --> Utf8 Class Initialized
INFO - 2022-03-21 04:05:58 --> URI Class Initialized
INFO - 2022-03-21 04:05:58 --> Router Class Initialized
INFO - 2022-03-21 04:05:58 --> Output Class Initialized
INFO - 2022-03-21 04:05:58 --> Security Class Initialized
DEBUG - 2022-03-21 04:05:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 04:05:58 --> Input Class Initialized
INFO - 2022-03-21 04:05:58 --> Language Class Initialized
ERROR - 2022-03-21 04:05:58 --> 404 Page Not Found: Karoclient/css
ERROR - 2022-03-21 04:06:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 04:06:38 --> Config Class Initialized
INFO - 2022-03-21 04:06:38 --> Hooks Class Initialized
DEBUG - 2022-03-21 04:06:38 --> UTF-8 Support Enabled
INFO - 2022-03-21 04:06:38 --> Utf8 Class Initialized
INFO - 2022-03-21 04:06:38 --> URI Class Initialized
INFO - 2022-03-21 04:06:38 --> Router Class Initialized
INFO - 2022-03-21 04:06:38 --> Output Class Initialized
INFO - 2022-03-21 04:06:38 --> Security Class Initialized
DEBUG - 2022-03-21 04:06:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 04:06:38 --> Input Class Initialized
INFO - 2022-03-21 04:06:38 --> Language Class Initialized
INFO - 2022-03-21 04:06:38 --> Loader Class Initialized
INFO - 2022-03-21 04:06:38 --> Helper loaded: url_helper
INFO - 2022-03-21 04:06:38 --> Helper loaded: form_helper
INFO - 2022-03-21 04:06:38 --> Helper loaded: common_helper
INFO - 2022-03-21 04:06:38 --> Database Driver Class Initialized
DEBUG - 2022-03-21 04:06:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 04:06:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 04:06:38 --> Controller Class Initialized
INFO - 2022-03-21 04:06:38 --> Model "Referredby_model" initialized
INFO - 2022-03-21 04:06:38 --> Final output sent to browser
DEBUG - 2022-03-21 04:06:38 --> Total execution time: 0.0412
ERROR - 2022-03-21 04:07:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 04:07:38 --> Config Class Initialized
INFO - 2022-03-21 04:07:38 --> Hooks Class Initialized
DEBUG - 2022-03-21 04:07:38 --> UTF-8 Support Enabled
INFO - 2022-03-21 04:07:38 --> Utf8 Class Initialized
INFO - 2022-03-21 04:07:38 --> URI Class Initialized
INFO - 2022-03-21 04:07:38 --> Router Class Initialized
INFO - 2022-03-21 04:07:38 --> Output Class Initialized
INFO - 2022-03-21 04:07:38 --> Security Class Initialized
DEBUG - 2022-03-21 04:07:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 04:07:38 --> Input Class Initialized
INFO - 2022-03-21 04:07:38 --> Language Class Initialized
INFO - 2022-03-21 04:07:38 --> Loader Class Initialized
INFO - 2022-03-21 04:07:38 --> Helper loaded: url_helper
INFO - 2022-03-21 04:07:38 --> Helper loaded: form_helper
INFO - 2022-03-21 04:07:38 --> Helper loaded: common_helper
INFO - 2022-03-21 04:07:38 --> Database Driver Class Initialized
DEBUG - 2022-03-21 04:07:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 04:07:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 04:07:38 --> Controller Class Initialized
INFO - 2022-03-21 04:07:38 --> Model "Referredby_model" initialized
INFO - 2022-03-21 04:07:38 --> Final output sent to browser
DEBUG - 2022-03-21 04:07:38 --> Total execution time: 0.0318
ERROR - 2022-03-21 04:07:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 04:07:54 --> Config Class Initialized
INFO - 2022-03-21 04:07:54 --> Hooks Class Initialized
DEBUG - 2022-03-21 04:07:54 --> UTF-8 Support Enabled
INFO - 2022-03-21 04:07:54 --> Utf8 Class Initialized
INFO - 2022-03-21 04:07:54 --> URI Class Initialized
INFO - 2022-03-21 04:07:54 --> Router Class Initialized
INFO - 2022-03-21 04:07:54 --> Output Class Initialized
INFO - 2022-03-21 04:07:54 --> Security Class Initialized
DEBUG - 2022-03-21 04:07:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 04:07:54 --> Input Class Initialized
INFO - 2022-03-21 04:07:54 --> Language Class Initialized
INFO - 2022-03-21 04:07:54 --> Loader Class Initialized
INFO - 2022-03-21 04:07:54 --> Helper loaded: url_helper
INFO - 2022-03-21 04:07:54 --> Helper loaded: form_helper
INFO - 2022-03-21 04:07:54 --> Helper loaded: common_helper
INFO - 2022-03-21 04:07:54 --> Database Driver Class Initialized
DEBUG - 2022-03-21 04:07:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 04:07:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 04:07:54 --> Controller Class Initialized
INFO - 2022-03-21 04:07:54 --> Model "Referredby_model" initialized
INFO - 2022-03-21 04:07:54 --> Final output sent to browser
DEBUG - 2022-03-21 04:07:54 --> Total execution time: 0.0332
ERROR - 2022-03-21 04:08:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 04:08:12 --> Config Class Initialized
INFO - 2022-03-21 04:08:12 --> Hooks Class Initialized
DEBUG - 2022-03-21 04:08:12 --> UTF-8 Support Enabled
INFO - 2022-03-21 04:08:12 --> Utf8 Class Initialized
INFO - 2022-03-21 04:08:12 --> URI Class Initialized
INFO - 2022-03-21 04:08:12 --> Router Class Initialized
INFO - 2022-03-21 04:08:12 --> Output Class Initialized
INFO - 2022-03-21 04:08:12 --> Security Class Initialized
DEBUG - 2022-03-21 04:08:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 04:08:12 --> Input Class Initialized
INFO - 2022-03-21 04:08:12 --> Language Class Initialized
INFO - 2022-03-21 04:08:12 --> Loader Class Initialized
INFO - 2022-03-21 04:08:12 --> Helper loaded: url_helper
INFO - 2022-03-21 04:08:12 --> Helper loaded: form_helper
INFO - 2022-03-21 04:08:12 --> Helper loaded: common_helper
INFO - 2022-03-21 04:08:12 --> Database Driver Class Initialized
DEBUG - 2022-03-21 04:08:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 04:08:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 04:08:12 --> Controller Class Initialized
INFO - 2022-03-21 04:08:12 --> Model "Referredby_model" initialized
INFO - 2022-03-21 04:08:12 --> Final output sent to browser
DEBUG - 2022-03-21 04:08:12 --> Total execution time: 0.0462
ERROR - 2022-03-21 04:09:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 04:09:58 --> Config Class Initialized
INFO - 2022-03-21 04:09:58 --> Hooks Class Initialized
DEBUG - 2022-03-21 04:09:58 --> UTF-8 Support Enabled
INFO - 2022-03-21 04:09:58 --> Utf8 Class Initialized
INFO - 2022-03-21 04:09:58 --> URI Class Initialized
INFO - 2022-03-21 04:09:58 --> Router Class Initialized
INFO - 2022-03-21 04:09:58 --> Output Class Initialized
INFO - 2022-03-21 04:09:58 --> Security Class Initialized
DEBUG - 2022-03-21 04:09:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 04:09:58 --> Input Class Initialized
INFO - 2022-03-21 04:09:58 --> Language Class Initialized
INFO - 2022-03-21 04:09:58 --> Loader Class Initialized
INFO - 2022-03-21 04:09:58 --> Helper loaded: url_helper
INFO - 2022-03-21 04:09:58 --> Helper loaded: form_helper
INFO - 2022-03-21 04:09:58 --> Helper loaded: common_helper
INFO - 2022-03-21 04:09:58 --> Database Driver Class Initialized
DEBUG - 2022-03-21 04:09:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 04:09:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 04:09:58 --> Controller Class Initialized
INFO - 2022-03-21 04:09:58 --> Model "Referredby_model" initialized
INFO - 2022-03-21 04:09:58 --> Final output sent to browser
DEBUG - 2022-03-21 04:09:58 --> Total execution time: 0.0248
ERROR - 2022-03-21 04:10:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 04:10:51 --> Config Class Initialized
INFO - 2022-03-21 04:10:51 --> Hooks Class Initialized
DEBUG - 2022-03-21 04:10:51 --> UTF-8 Support Enabled
INFO - 2022-03-21 04:10:51 --> Utf8 Class Initialized
INFO - 2022-03-21 04:10:51 --> URI Class Initialized
INFO - 2022-03-21 04:10:51 --> Router Class Initialized
INFO - 2022-03-21 04:10:51 --> Output Class Initialized
INFO - 2022-03-21 04:10:51 --> Security Class Initialized
DEBUG - 2022-03-21 04:10:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 04:10:51 --> Input Class Initialized
INFO - 2022-03-21 04:10:51 --> Language Class Initialized
INFO - 2022-03-21 04:10:51 --> Loader Class Initialized
INFO - 2022-03-21 04:10:51 --> Helper loaded: url_helper
INFO - 2022-03-21 04:10:51 --> Helper loaded: form_helper
INFO - 2022-03-21 04:10:51 --> Helper loaded: common_helper
INFO - 2022-03-21 04:10:51 --> Database Driver Class Initialized
DEBUG - 2022-03-21 04:10:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 04:10:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 04:10:51 --> Controller Class Initialized
INFO - 2022-03-21 04:10:51 --> Form Validation Class Initialized
DEBUG - 2022-03-21 04:10:51 --> Encrypt Class Initialized
INFO - 2022-03-21 04:10:51 --> Model "Patient_model" initialized
INFO - 2022-03-21 04:10:51 --> Model "Patientcase_model" initialized
INFO - 2022-03-21 04:10:51 --> Model "Referredby_model" initialized
INFO - 2022-03-21 04:10:51 --> Model "Prefix_master" initialized
INFO - 2022-03-21 04:10:51 --> Model "Hospital_model" initialized
INFO - 2022-03-21 04:10:51 --> Final output sent to browser
DEBUG - 2022-03-21 04:10:51 --> Total execution time: 0.0292
ERROR - 2022-03-21 04:16:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 04:16:28 --> Config Class Initialized
INFO - 2022-03-21 04:16:28 --> Hooks Class Initialized
DEBUG - 2022-03-21 04:16:28 --> UTF-8 Support Enabled
INFO - 2022-03-21 04:16:28 --> Utf8 Class Initialized
INFO - 2022-03-21 04:16:28 --> URI Class Initialized
INFO - 2022-03-21 04:16:28 --> Router Class Initialized
INFO - 2022-03-21 04:16:28 --> Output Class Initialized
INFO - 2022-03-21 04:16:28 --> Security Class Initialized
DEBUG - 2022-03-21 04:16:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 04:16:28 --> Input Class Initialized
INFO - 2022-03-21 04:16:28 --> Language Class Initialized
INFO - 2022-03-21 04:16:28 --> Loader Class Initialized
INFO - 2022-03-21 04:16:28 --> Helper loaded: url_helper
INFO - 2022-03-21 04:16:28 --> Helper loaded: form_helper
INFO - 2022-03-21 04:16:28 --> Helper loaded: common_helper
INFO - 2022-03-21 04:16:28 --> Database Driver Class Initialized
DEBUG - 2022-03-21 04:16:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 04:16:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 04:16:28 --> Controller Class Initialized
INFO - 2022-03-21 04:16:28 --> Form Validation Class Initialized
DEBUG - 2022-03-21 04:16:28 --> Encrypt Class Initialized
INFO - 2022-03-21 04:16:28 --> Model "Patient_model" initialized
INFO - 2022-03-21 04:16:28 --> Model "Patientcase_model" initialized
INFO - 2022-03-21 04:16:28 --> Model "Referredby_model" initialized
INFO - 2022-03-21 04:16:28 --> Model "Prefix_master" initialized
INFO - 2022-03-21 04:16:28 --> Model "Hospital_model" initialized
ERROR - 2022-03-21 04:16:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 04:16:28 --> Config Class Initialized
INFO - 2022-03-21 04:16:28 --> Hooks Class Initialized
DEBUG - 2022-03-21 04:16:28 --> UTF-8 Support Enabled
INFO - 2022-03-21 04:16:28 --> Utf8 Class Initialized
INFO - 2022-03-21 04:16:28 --> URI Class Initialized
INFO - 2022-03-21 04:16:28 --> Router Class Initialized
INFO - 2022-03-21 04:16:28 --> Output Class Initialized
INFO - 2022-03-21 04:16:28 --> Security Class Initialized
DEBUG - 2022-03-21 04:16:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 04:16:28 --> Input Class Initialized
INFO - 2022-03-21 04:16:28 --> Language Class Initialized
INFO - 2022-03-21 04:16:28 --> Loader Class Initialized
INFO - 2022-03-21 04:16:28 --> Helper loaded: url_helper
INFO - 2022-03-21 04:16:28 --> Helper loaded: form_helper
INFO - 2022-03-21 04:16:28 --> Helper loaded: common_helper
INFO - 2022-03-21 04:16:28 --> Database Driver Class Initialized
DEBUG - 2022-03-21 04:16:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 04:16:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 04:16:28 --> Controller Class Initialized
INFO - 2022-03-21 04:16:28 --> Form Validation Class Initialized
DEBUG - 2022-03-21 04:16:28 --> Encrypt Class Initialized
INFO - 2022-03-21 04:16:28 --> Model "Patient_model" initialized
INFO - 2022-03-21 04:16:28 --> Model "Patientcase_model" initialized
INFO - 2022-03-21 04:16:28 --> Model "Referredby_model" initialized
INFO - 2022-03-21 04:16:29 --> Model "Prefix_master" initialized
INFO - 2022-03-21 04:16:29 --> Model "Hospital_model" initialized
INFO - 2022-03-21 04:16:29 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-21 04:16:29 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-21 04:16:29 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-21 04:16:29 --> Final output sent to browser
DEBUG - 2022-03-21 04:16:29 --> Total execution time: 0.0728
ERROR - 2022-03-21 04:16:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 04:16:30 --> Config Class Initialized
INFO - 2022-03-21 04:16:30 --> Hooks Class Initialized
DEBUG - 2022-03-21 04:16:30 --> UTF-8 Support Enabled
INFO - 2022-03-21 04:16:30 --> Utf8 Class Initialized
INFO - 2022-03-21 04:16:30 --> URI Class Initialized
INFO - 2022-03-21 04:16:30 --> Router Class Initialized
INFO - 2022-03-21 04:16:30 --> Output Class Initialized
INFO - 2022-03-21 04:16:30 --> Security Class Initialized
DEBUG - 2022-03-21 04:16:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 04:16:30 --> Input Class Initialized
INFO - 2022-03-21 04:16:30 --> Language Class Initialized
INFO - 2022-03-21 04:16:30 --> Loader Class Initialized
INFO - 2022-03-21 04:16:30 --> Helper loaded: url_helper
INFO - 2022-03-21 04:16:30 --> Helper loaded: form_helper
INFO - 2022-03-21 04:16:30 --> Helper loaded: common_helper
INFO - 2022-03-21 04:16:30 --> Database Driver Class Initialized
DEBUG - 2022-03-21 04:16:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 04:16:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 04:16:30 --> Controller Class Initialized
INFO - 2022-03-21 04:16:30 --> Form Validation Class Initialized
DEBUG - 2022-03-21 04:16:30 --> Encrypt Class Initialized
INFO - 2022-03-21 04:16:30 --> Model "Patient_model" initialized
INFO - 2022-03-21 04:16:30 --> Model "Patientcase_model" initialized
INFO - 2022-03-21 04:16:30 --> Model "Prefix_master" initialized
INFO - 2022-03-21 04:16:30 --> Model "Users_model" initialized
INFO - 2022-03-21 04:16:30 --> Model "Hospital_model" initialized
INFO - 2022-03-21 04:16:30 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-21 04:16:30 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-21 04:16:30 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-21 04:16:30 --> Final output sent to browser
DEBUG - 2022-03-21 04:16:30 --> Total execution time: 0.4720
ERROR - 2022-03-21 04:17:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 04:17:02 --> Config Class Initialized
INFO - 2022-03-21 04:17:02 --> Hooks Class Initialized
DEBUG - 2022-03-21 04:17:02 --> UTF-8 Support Enabled
INFO - 2022-03-21 04:17:02 --> Utf8 Class Initialized
INFO - 2022-03-21 04:17:02 --> URI Class Initialized
INFO - 2022-03-21 04:17:02 --> Router Class Initialized
INFO - 2022-03-21 04:17:02 --> Output Class Initialized
INFO - 2022-03-21 04:17:02 --> Security Class Initialized
DEBUG - 2022-03-21 04:17:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 04:17:02 --> Input Class Initialized
INFO - 2022-03-21 04:17:02 --> Language Class Initialized
INFO - 2022-03-21 04:17:02 --> Loader Class Initialized
INFO - 2022-03-21 04:17:02 --> Helper loaded: url_helper
INFO - 2022-03-21 04:17:02 --> Helper loaded: form_helper
INFO - 2022-03-21 04:17:02 --> Helper loaded: common_helper
INFO - 2022-03-21 04:17:02 --> Database Driver Class Initialized
DEBUG - 2022-03-21 04:17:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 04:17:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 04:17:02 --> Controller Class Initialized
INFO - 2022-03-21 04:17:02 --> Form Validation Class Initialized
DEBUG - 2022-03-21 04:17:02 --> Encrypt Class Initialized
INFO - 2022-03-21 04:17:02 --> Model "Patient_model" initialized
INFO - 2022-03-21 04:17:02 --> Model "Patientcase_model" initialized
INFO - 2022-03-21 04:17:02 --> Model "Referredby_model" initialized
INFO - 2022-03-21 04:17:02 --> Model "Prefix_master" initialized
INFO - 2022-03-21 04:17:02 --> Model "Hospital_model" initialized
INFO - 2022-03-21 04:17:02 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-21 04:17:02 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-21 04:17:02 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-21 04:17:02 --> Final output sent to browser
DEBUG - 2022-03-21 04:17:02 --> Total execution time: 0.1136
ERROR - 2022-03-21 04:19:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 04:19:00 --> Config Class Initialized
INFO - 2022-03-21 04:19:00 --> Hooks Class Initialized
DEBUG - 2022-03-21 04:19:00 --> UTF-8 Support Enabled
INFO - 2022-03-21 04:19:00 --> Utf8 Class Initialized
INFO - 2022-03-21 04:19:00 --> URI Class Initialized
INFO - 2022-03-21 04:19:00 --> Router Class Initialized
INFO - 2022-03-21 04:19:00 --> Output Class Initialized
INFO - 2022-03-21 04:19:00 --> Security Class Initialized
DEBUG - 2022-03-21 04:19:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 04:19:00 --> Input Class Initialized
INFO - 2022-03-21 04:19:00 --> Language Class Initialized
INFO - 2022-03-21 04:19:00 --> Loader Class Initialized
INFO - 2022-03-21 04:19:00 --> Helper loaded: url_helper
INFO - 2022-03-21 04:19:00 --> Helper loaded: form_helper
INFO - 2022-03-21 04:19:00 --> Helper loaded: common_helper
INFO - 2022-03-21 04:19:00 --> Database Driver Class Initialized
DEBUG - 2022-03-21 04:19:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 04:19:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 04:19:00 --> Controller Class Initialized
INFO - 2022-03-21 04:19:00 --> Form Validation Class Initialized
DEBUG - 2022-03-21 04:19:00 --> Encrypt Class Initialized
INFO - 2022-03-21 04:19:00 --> Model "Patient_model" initialized
INFO - 2022-03-21 04:19:00 --> Model "Patientcase_model" initialized
INFO - 2022-03-21 04:19:00 --> Model "Referredby_model" initialized
INFO - 2022-03-21 04:19:00 --> Model "Prefix_master" initialized
INFO - 2022-03-21 04:19:00 --> Model "Hospital_model" initialized
ERROR - 2022-03-21 04:19:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 04:19:01 --> Config Class Initialized
INFO - 2022-03-21 04:19:01 --> Hooks Class Initialized
DEBUG - 2022-03-21 04:19:01 --> UTF-8 Support Enabled
INFO - 2022-03-21 04:19:01 --> Utf8 Class Initialized
INFO - 2022-03-21 04:19:01 --> URI Class Initialized
INFO - 2022-03-21 04:19:01 --> Router Class Initialized
INFO - 2022-03-21 04:19:01 --> Output Class Initialized
INFO - 2022-03-21 04:19:01 --> Security Class Initialized
DEBUG - 2022-03-21 04:19:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 04:19:01 --> Input Class Initialized
INFO - 2022-03-21 04:19:01 --> Language Class Initialized
INFO - 2022-03-21 04:19:01 --> Loader Class Initialized
INFO - 2022-03-21 04:19:01 --> Helper loaded: url_helper
INFO - 2022-03-21 04:19:01 --> Helper loaded: form_helper
INFO - 2022-03-21 04:19:01 --> Helper loaded: common_helper
INFO - 2022-03-21 04:19:01 --> Database Driver Class Initialized
DEBUG - 2022-03-21 04:19:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 04:19:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 04:19:01 --> Controller Class Initialized
INFO - 2022-03-21 04:19:01 --> Form Validation Class Initialized
DEBUG - 2022-03-21 04:19:01 --> Encrypt Class Initialized
INFO - 2022-03-21 04:19:01 --> Model "Patient_model" initialized
INFO - 2022-03-21 04:19:01 --> Model "Patientcase_model" initialized
INFO - 2022-03-21 04:19:01 --> Model "Referredby_model" initialized
INFO - 2022-03-21 04:19:01 --> Model "Prefix_master" initialized
INFO - 2022-03-21 04:19:01 --> Model "Hospital_model" initialized
INFO - 2022-03-21 04:19:01 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-21 04:19:01 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-21 04:19:01 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-21 04:19:01 --> Final output sent to browser
DEBUG - 2022-03-21 04:19:01 --> Total execution time: 0.0597
ERROR - 2022-03-21 04:19:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 04:19:02 --> Config Class Initialized
INFO - 2022-03-21 04:19:02 --> Hooks Class Initialized
DEBUG - 2022-03-21 04:19:02 --> UTF-8 Support Enabled
INFO - 2022-03-21 04:19:02 --> Utf8 Class Initialized
INFO - 2022-03-21 04:19:02 --> URI Class Initialized
INFO - 2022-03-21 04:19:02 --> Router Class Initialized
INFO - 2022-03-21 04:19:02 --> Output Class Initialized
INFO - 2022-03-21 04:19:02 --> Security Class Initialized
DEBUG - 2022-03-21 04:19:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 04:19:02 --> Input Class Initialized
INFO - 2022-03-21 04:19:02 --> Language Class Initialized
INFO - 2022-03-21 04:19:02 --> Loader Class Initialized
INFO - 2022-03-21 04:19:02 --> Helper loaded: url_helper
INFO - 2022-03-21 04:19:02 --> Helper loaded: form_helper
INFO - 2022-03-21 04:19:02 --> Helper loaded: common_helper
INFO - 2022-03-21 04:19:02 --> Database Driver Class Initialized
DEBUG - 2022-03-21 04:19:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 04:19:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 04:19:02 --> Controller Class Initialized
INFO - 2022-03-21 04:19:02 --> Form Validation Class Initialized
DEBUG - 2022-03-21 04:19:02 --> Encrypt Class Initialized
INFO - 2022-03-21 04:19:02 --> Model "Patient_model" initialized
INFO - 2022-03-21 04:19:02 --> Model "Patientcase_model" initialized
INFO - 2022-03-21 04:19:02 --> Model "Prefix_master" initialized
INFO - 2022-03-21 04:19:02 --> Model "Users_model" initialized
INFO - 2022-03-21 04:19:02 --> Model "Hospital_model" initialized
INFO - 2022-03-21 04:19:02 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-21 04:19:02 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-21 04:19:02 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-21 04:19:02 --> Final output sent to browser
DEBUG - 2022-03-21 04:19:02 --> Total execution time: 0.0956
ERROR - 2022-03-21 04:24:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 04:24:47 --> Config Class Initialized
INFO - 2022-03-21 04:24:47 --> Hooks Class Initialized
DEBUG - 2022-03-21 04:24:47 --> UTF-8 Support Enabled
INFO - 2022-03-21 04:24:47 --> Utf8 Class Initialized
INFO - 2022-03-21 04:24:47 --> URI Class Initialized
INFO - 2022-03-21 04:24:47 --> Router Class Initialized
INFO - 2022-03-21 04:24:47 --> Output Class Initialized
INFO - 2022-03-21 04:24:47 --> Security Class Initialized
DEBUG - 2022-03-21 04:24:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 04:24:47 --> Input Class Initialized
INFO - 2022-03-21 04:24:47 --> Language Class Initialized
INFO - 2022-03-21 04:24:47 --> Loader Class Initialized
INFO - 2022-03-21 04:24:47 --> Helper loaded: url_helper
INFO - 2022-03-21 04:24:47 --> Helper loaded: form_helper
INFO - 2022-03-21 04:24:47 --> Helper loaded: common_helper
INFO - 2022-03-21 04:24:47 --> Database Driver Class Initialized
DEBUG - 2022-03-21 04:24:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 04:24:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 04:24:47 --> Controller Class Initialized
INFO - 2022-03-21 04:24:47 --> Form Validation Class Initialized
DEBUG - 2022-03-21 04:24:47 --> Encrypt Class Initialized
INFO - 2022-03-21 04:24:47 --> Model "Patient_model" initialized
INFO - 2022-03-21 04:24:47 --> Model "Patientcase_model" initialized
INFO - 2022-03-21 04:24:47 --> Model "Prefix_master" initialized
INFO - 2022-03-21 04:24:47 --> Model "Users_model" initialized
INFO - 2022-03-21 04:24:47 --> Model "Hospital_model" initialized
ERROR - 2022-03-21 04:24:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 04:24:48 --> Config Class Initialized
INFO - 2022-03-21 04:24:48 --> Hooks Class Initialized
DEBUG - 2022-03-21 04:24:48 --> UTF-8 Support Enabled
INFO - 2022-03-21 04:24:48 --> Utf8 Class Initialized
INFO - 2022-03-21 04:24:48 --> URI Class Initialized
INFO - 2022-03-21 04:24:48 --> Router Class Initialized
INFO - 2022-03-21 04:24:48 --> Output Class Initialized
INFO - 2022-03-21 04:24:48 --> Security Class Initialized
DEBUG - 2022-03-21 04:24:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 04:24:48 --> Input Class Initialized
INFO - 2022-03-21 04:24:48 --> Language Class Initialized
INFO - 2022-03-21 04:24:48 --> Loader Class Initialized
INFO - 2022-03-21 04:24:48 --> Helper loaded: url_helper
INFO - 2022-03-21 04:24:48 --> Helper loaded: form_helper
INFO - 2022-03-21 04:24:48 --> Helper loaded: common_helper
INFO - 2022-03-21 04:24:48 --> Database Driver Class Initialized
DEBUG - 2022-03-21 04:24:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 04:24:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 04:24:48 --> Controller Class Initialized
INFO - 2022-03-21 04:24:48 --> Form Validation Class Initialized
DEBUG - 2022-03-21 04:24:48 --> Encrypt Class Initialized
INFO - 2022-03-21 04:24:48 --> Model "Patient_model" initialized
INFO - 2022-03-21 04:24:48 --> Model "Patientcase_model" initialized
INFO - 2022-03-21 04:24:48 --> Model "Prefix_master" initialized
INFO - 2022-03-21 04:24:48 --> Model "Users_model" initialized
INFO - 2022-03-21 04:24:48 --> Model "Hospital_model" initialized
INFO - 2022-03-21 04:24:48 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-21 04:24:48 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-21 04:24:48 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-21 04:24:48 --> Final output sent to browser
DEBUG - 2022-03-21 04:24:48 --> Total execution time: 0.1035
ERROR - 2022-03-21 04:28:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 04:28:34 --> Config Class Initialized
INFO - 2022-03-21 04:28:34 --> Hooks Class Initialized
DEBUG - 2022-03-21 04:28:34 --> UTF-8 Support Enabled
INFO - 2022-03-21 04:28:34 --> Utf8 Class Initialized
INFO - 2022-03-21 04:28:34 --> URI Class Initialized
INFO - 2022-03-21 04:28:34 --> Router Class Initialized
INFO - 2022-03-21 04:28:34 --> Output Class Initialized
INFO - 2022-03-21 04:28:34 --> Security Class Initialized
DEBUG - 2022-03-21 04:28:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 04:28:34 --> Input Class Initialized
INFO - 2022-03-21 04:28:34 --> Language Class Initialized
INFO - 2022-03-21 04:28:34 --> Loader Class Initialized
INFO - 2022-03-21 04:28:34 --> Helper loaded: url_helper
INFO - 2022-03-21 04:28:34 --> Helper loaded: form_helper
INFO - 2022-03-21 04:28:34 --> Helper loaded: common_helper
INFO - 2022-03-21 04:28:34 --> Database Driver Class Initialized
DEBUG - 2022-03-21 04:28:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 04:28:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 04:28:34 --> Controller Class Initialized
INFO - 2022-03-21 04:28:34 --> Form Validation Class Initialized
DEBUG - 2022-03-21 04:28:34 --> Encrypt Class Initialized
INFO - 2022-03-21 04:28:34 --> Model "Patient_model" initialized
INFO - 2022-03-21 04:28:34 --> Model "Patientcase_model" initialized
INFO - 2022-03-21 04:28:34 --> Model "Prefix_master" initialized
INFO - 2022-03-21 04:28:34 --> Model "Users_model" initialized
INFO - 2022-03-21 04:28:34 --> Model "Hospital_model" initialized
ERROR - 2022-03-21 04:28:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 04:28:35 --> Config Class Initialized
INFO - 2022-03-21 04:28:35 --> Hooks Class Initialized
DEBUG - 2022-03-21 04:28:35 --> UTF-8 Support Enabled
INFO - 2022-03-21 04:28:35 --> Utf8 Class Initialized
INFO - 2022-03-21 04:28:35 --> URI Class Initialized
INFO - 2022-03-21 04:28:35 --> Router Class Initialized
INFO - 2022-03-21 04:28:35 --> Output Class Initialized
INFO - 2022-03-21 04:28:35 --> Security Class Initialized
DEBUG - 2022-03-21 04:28:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 04:28:35 --> Input Class Initialized
INFO - 2022-03-21 04:28:35 --> Language Class Initialized
INFO - 2022-03-21 04:28:35 --> Loader Class Initialized
INFO - 2022-03-21 04:28:35 --> Helper loaded: url_helper
INFO - 2022-03-21 04:28:35 --> Helper loaded: form_helper
INFO - 2022-03-21 04:28:35 --> Helper loaded: common_helper
INFO - 2022-03-21 04:28:35 --> Database Driver Class Initialized
DEBUG - 2022-03-21 04:28:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 04:28:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 04:28:35 --> Controller Class Initialized
INFO - 2022-03-21 04:28:35 --> Form Validation Class Initialized
DEBUG - 2022-03-21 04:28:35 --> Encrypt Class Initialized
INFO - 2022-03-21 04:28:35 --> Model "Patient_model" initialized
INFO - 2022-03-21 04:28:35 --> Model "Patientcase_model" initialized
INFO - 2022-03-21 04:28:35 --> Model "Prefix_master" initialized
INFO - 2022-03-21 04:28:35 --> Model "Users_model" initialized
INFO - 2022-03-21 04:28:35 --> Model "Hospital_model" initialized
INFO - 2022-03-21 04:28:35 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-21 04:28:35 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-21 04:28:35 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-21 04:28:35 --> Final output sent to browser
DEBUG - 2022-03-21 04:28:35 --> Total execution time: 0.1030
ERROR - 2022-03-21 04:29:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 04:29:22 --> Config Class Initialized
INFO - 2022-03-21 04:29:22 --> Hooks Class Initialized
DEBUG - 2022-03-21 04:29:22 --> UTF-8 Support Enabled
INFO - 2022-03-21 04:29:22 --> Utf8 Class Initialized
INFO - 2022-03-21 04:29:22 --> URI Class Initialized
INFO - 2022-03-21 04:29:22 --> Router Class Initialized
INFO - 2022-03-21 04:29:22 --> Output Class Initialized
INFO - 2022-03-21 04:29:22 --> Security Class Initialized
DEBUG - 2022-03-21 04:29:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 04:29:22 --> Input Class Initialized
INFO - 2022-03-21 04:29:22 --> Language Class Initialized
INFO - 2022-03-21 04:29:22 --> Loader Class Initialized
INFO - 2022-03-21 04:29:22 --> Helper loaded: url_helper
INFO - 2022-03-21 04:29:22 --> Helper loaded: form_helper
INFO - 2022-03-21 04:29:22 --> Helper loaded: common_helper
INFO - 2022-03-21 04:29:22 --> Database Driver Class Initialized
DEBUG - 2022-03-21 04:29:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 04:29:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 04:29:22 --> Controller Class Initialized
INFO - 2022-03-21 04:29:22 --> Form Validation Class Initialized
DEBUG - 2022-03-21 04:29:22 --> Encrypt Class Initialized
INFO - 2022-03-21 04:29:22 --> Model "Patient_model" initialized
INFO - 2022-03-21 04:29:22 --> Model "Patientcase_model" initialized
INFO - 2022-03-21 04:29:22 --> Model "Prefix_master" initialized
INFO - 2022-03-21 04:29:22 --> Model "Users_model" initialized
INFO - 2022-03-21 04:29:22 --> Model "Hospital_model" initialized
INFO - 2022-03-21 04:29:22 --> Upload Class Initialized
INFO - 2022-03-21 04:29:22 --> Final output sent to browser
DEBUG - 2022-03-21 04:29:22 --> Total execution time: 0.2246
ERROR - 2022-03-21 04:29:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 04:29:36 --> Config Class Initialized
INFO - 2022-03-21 04:29:36 --> Hooks Class Initialized
DEBUG - 2022-03-21 04:29:36 --> UTF-8 Support Enabled
INFO - 2022-03-21 04:29:36 --> Utf8 Class Initialized
INFO - 2022-03-21 04:29:36 --> URI Class Initialized
INFO - 2022-03-21 04:29:36 --> Router Class Initialized
INFO - 2022-03-21 04:29:36 --> Output Class Initialized
INFO - 2022-03-21 04:29:36 --> Security Class Initialized
DEBUG - 2022-03-21 04:29:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 04:29:36 --> Input Class Initialized
INFO - 2022-03-21 04:29:36 --> Language Class Initialized
INFO - 2022-03-21 04:29:36 --> Loader Class Initialized
INFO - 2022-03-21 04:29:36 --> Helper loaded: url_helper
INFO - 2022-03-21 04:29:36 --> Helper loaded: form_helper
INFO - 2022-03-21 04:29:36 --> Helper loaded: common_helper
INFO - 2022-03-21 04:29:36 --> Database Driver Class Initialized
DEBUG - 2022-03-21 04:29:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 04:29:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 04:29:36 --> Controller Class Initialized
INFO - 2022-03-21 04:29:36 --> Form Validation Class Initialized
DEBUG - 2022-03-21 04:29:36 --> Encrypt Class Initialized
INFO - 2022-03-21 04:29:36 --> Model "Patient_model" initialized
INFO - 2022-03-21 04:29:36 --> Model "Patientcase_model" initialized
INFO - 2022-03-21 04:29:36 --> Model "Prefix_master" initialized
INFO - 2022-03-21 04:29:36 --> Model "Users_model" initialized
INFO - 2022-03-21 04:29:36 --> Model "Hospital_model" initialized
ERROR - 2022-03-21 04:29:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 04:29:56 --> Config Class Initialized
INFO - 2022-03-21 04:29:56 --> Hooks Class Initialized
DEBUG - 2022-03-21 04:29:56 --> UTF-8 Support Enabled
INFO - 2022-03-21 04:29:56 --> Utf8 Class Initialized
INFO - 2022-03-21 04:29:56 --> URI Class Initialized
INFO - 2022-03-21 04:29:56 --> Router Class Initialized
INFO - 2022-03-21 04:29:56 --> Output Class Initialized
INFO - 2022-03-21 04:29:56 --> Security Class Initialized
DEBUG - 2022-03-21 04:29:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 04:29:56 --> Input Class Initialized
INFO - 2022-03-21 04:29:56 --> Language Class Initialized
INFO - 2022-03-21 04:29:56 --> Loader Class Initialized
INFO - 2022-03-21 04:29:56 --> Helper loaded: url_helper
INFO - 2022-03-21 04:29:56 --> Helper loaded: form_helper
INFO - 2022-03-21 04:29:56 --> Helper loaded: common_helper
INFO - 2022-03-21 04:29:56 --> Database Driver Class Initialized
DEBUG - 2022-03-21 04:29:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 04:29:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 04:29:56 --> Controller Class Initialized
INFO - 2022-03-21 04:29:56 --> Form Validation Class Initialized
DEBUG - 2022-03-21 04:29:56 --> Encrypt Class Initialized
INFO - 2022-03-21 04:29:56 --> Model "Patient_model" initialized
INFO - 2022-03-21 04:29:56 --> Model "Patientcase_model" initialized
INFO - 2022-03-21 04:29:56 --> Model "Prefix_master" initialized
INFO - 2022-03-21 04:29:56 --> Model "Users_model" initialized
INFO - 2022-03-21 04:29:56 --> Model "Hospital_model" initialized
INFO - 2022-03-21 04:29:56 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-21 04:29:56 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-21 04:29:56 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-21 04:29:56 --> Final output sent to browser
DEBUG - 2022-03-21 04:29:56 --> Total execution time: 0.0903
ERROR - 2022-03-21 04:56:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 04:56:28 --> Config Class Initialized
INFO - 2022-03-21 04:56:28 --> Hooks Class Initialized
DEBUG - 2022-03-21 04:56:28 --> UTF-8 Support Enabled
INFO - 2022-03-21 04:56:28 --> Utf8 Class Initialized
INFO - 2022-03-21 04:56:28 --> URI Class Initialized
INFO - 2022-03-21 04:56:28 --> Router Class Initialized
INFO - 2022-03-21 04:56:28 --> Output Class Initialized
INFO - 2022-03-21 04:56:28 --> Security Class Initialized
DEBUG - 2022-03-21 04:56:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 04:56:28 --> Input Class Initialized
INFO - 2022-03-21 04:56:28 --> Language Class Initialized
INFO - 2022-03-21 04:56:28 --> Loader Class Initialized
INFO - 2022-03-21 04:56:28 --> Helper loaded: url_helper
INFO - 2022-03-21 04:56:28 --> Helper loaded: form_helper
INFO - 2022-03-21 04:56:28 --> Helper loaded: common_helper
INFO - 2022-03-21 04:56:28 --> Database Driver Class Initialized
DEBUG - 2022-03-21 04:56:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 04:56:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 04:56:28 --> Controller Class Initialized
INFO - 2022-03-21 04:56:28 --> Form Validation Class Initialized
DEBUG - 2022-03-21 04:56:28 --> Encrypt Class Initialized
INFO - 2022-03-21 04:56:28 --> Model "Patient_model" initialized
INFO - 2022-03-21 04:56:28 --> Model "Patientcase_model" initialized
INFO - 2022-03-21 04:56:28 --> Model "Prefix_master" initialized
INFO - 2022-03-21 04:56:28 --> Model "Users_model" initialized
INFO - 2022-03-21 04:56:28 --> Model "Hospital_model" initialized
ERROR - 2022-03-21 04:56:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 04:56:29 --> Config Class Initialized
INFO - 2022-03-21 04:56:29 --> Hooks Class Initialized
DEBUG - 2022-03-21 04:56:29 --> UTF-8 Support Enabled
INFO - 2022-03-21 04:56:29 --> Utf8 Class Initialized
INFO - 2022-03-21 04:56:29 --> URI Class Initialized
INFO - 2022-03-21 04:56:29 --> Router Class Initialized
INFO - 2022-03-21 04:56:29 --> Output Class Initialized
INFO - 2022-03-21 04:56:29 --> Security Class Initialized
DEBUG - 2022-03-21 04:56:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 04:56:29 --> Input Class Initialized
INFO - 2022-03-21 04:56:29 --> Language Class Initialized
INFO - 2022-03-21 04:56:29 --> Loader Class Initialized
INFO - 2022-03-21 04:56:29 --> Helper loaded: url_helper
INFO - 2022-03-21 04:56:29 --> Helper loaded: form_helper
INFO - 2022-03-21 04:56:29 --> Helper loaded: common_helper
INFO - 2022-03-21 04:56:29 --> Database Driver Class Initialized
DEBUG - 2022-03-21 04:56:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 04:56:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 04:56:29 --> Controller Class Initialized
INFO - 2022-03-21 04:56:29 --> Form Validation Class Initialized
DEBUG - 2022-03-21 04:56:29 --> Encrypt Class Initialized
INFO - 2022-03-21 04:56:29 --> Model "Patient_model" initialized
INFO - 2022-03-21 04:56:29 --> Model "Patientcase_model" initialized
INFO - 2022-03-21 04:56:29 --> Model "Prefix_master" initialized
INFO - 2022-03-21 04:56:29 --> Model "Users_model" initialized
INFO - 2022-03-21 04:56:29 --> Model "Hospital_model" initialized
ERROR - 2022-03-21 04:56:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 04:56:30 --> Config Class Initialized
INFO - 2022-03-21 04:56:30 --> Hooks Class Initialized
DEBUG - 2022-03-21 04:56:30 --> UTF-8 Support Enabled
INFO - 2022-03-21 04:56:30 --> Utf8 Class Initialized
INFO - 2022-03-21 04:56:30 --> URI Class Initialized
INFO - 2022-03-21 04:56:30 --> Router Class Initialized
INFO - 2022-03-21 04:56:30 --> Output Class Initialized
INFO - 2022-03-21 04:56:30 --> Security Class Initialized
DEBUG - 2022-03-21 04:56:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 04:56:30 --> Input Class Initialized
INFO - 2022-03-21 04:56:30 --> Language Class Initialized
INFO - 2022-03-21 04:56:30 --> Loader Class Initialized
INFO - 2022-03-21 04:56:30 --> Helper loaded: url_helper
INFO - 2022-03-21 04:56:30 --> Helper loaded: form_helper
INFO - 2022-03-21 04:56:30 --> Helper loaded: common_helper
INFO - 2022-03-21 04:56:30 --> Database Driver Class Initialized
DEBUG - 2022-03-21 04:56:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 04:56:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 04:56:30 --> Controller Class Initialized
INFO - 2022-03-21 04:56:30 --> Form Validation Class Initialized
DEBUG - 2022-03-21 04:56:30 --> Encrypt Class Initialized
INFO - 2022-03-21 04:56:30 --> Model "Patient_model" initialized
INFO - 2022-03-21 04:56:30 --> Model "Patientcase_model" initialized
INFO - 2022-03-21 04:56:30 --> Model "Prefix_master" initialized
INFO - 2022-03-21 04:56:30 --> Model "Users_model" initialized
INFO - 2022-03-21 04:56:30 --> Model "Hospital_model" initialized
INFO - 2022-03-21 04:56:30 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-21 04:56:30 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-21 04:56:30 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-21 04:56:30 --> Final output sent to browser
DEBUG - 2022-03-21 04:56:30 --> Total execution time: 0.0895
ERROR - 2022-03-21 04:57:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 04:57:16 --> Config Class Initialized
INFO - 2022-03-21 04:57:16 --> Hooks Class Initialized
DEBUG - 2022-03-21 04:57:16 --> UTF-8 Support Enabled
INFO - 2022-03-21 04:57:16 --> Utf8 Class Initialized
INFO - 2022-03-21 04:57:16 --> URI Class Initialized
INFO - 2022-03-21 04:57:16 --> Router Class Initialized
INFO - 2022-03-21 04:57:16 --> Output Class Initialized
INFO - 2022-03-21 04:57:16 --> Security Class Initialized
DEBUG - 2022-03-21 04:57:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 04:57:16 --> Input Class Initialized
INFO - 2022-03-21 04:57:16 --> Language Class Initialized
INFO - 2022-03-21 04:57:16 --> Loader Class Initialized
INFO - 2022-03-21 04:57:16 --> Helper loaded: url_helper
INFO - 2022-03-21 04:57:16 --> Helper loaded: form_helper
INFO - 2022-03-21 04:57:16 --> Helper loaded: common_helper
INFO - 2022-03-21 04:57:16 --> Database Driver Class Initialized
DEBUG - 2022-03-21 04:57:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 04:57:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 04:57:16 --> Controller Class Initialized
INFO - 2022-03-21 04:57:16 --> Form Validation Class Initialized
DEBUG - 2022-03-21 04:57:16 --> Encrypt Class Initialized
INFO - 2022-03-21 04:57:16 --> Model "Patient_model" initialized
INFO - 2022-03-21 04:57:16 --> Model "Patientcase_model" initialized
INFO - 2022-03-21 04:57:16 --> Model "Prefix_master" initialized
INFO - 2022-03-21 04:57:16 --> Model "Users_model" initialized
INFO - 2022-03-21 04:57:16 --> Model "Hospital_model" initialized
ERROR - 2022-03-21 04:57:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 04:57:16 --> Config Class Initialized
INFO - 2022-03-21 04:57:16 --> Hooks Class Initialized
DEBUG - 2022-03-21 04:57:16 --> UTF-8 Support Enabled
INFO - 2022-03-21 04:57:16 --> Utf8 Class Initialized
INFO - 2022-03-21 04:57:16 --> URI Class Initialized
INFO - 2022-03-21 04:57:16 --> Router Class Initialized
INFO - 2022-03-21 04:57:16 --> Output Class Initialized
INFO - 2022-03-21 04:57:16 --> Security Class Initialized
DEBUG - 2022-03-21 04:57:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 04:57:16 --> Input Class Initialized
INFO - 2022-03-21 04:57:16 --> Language Class Initialized
INFO - 2022-03-21 04:57:16 --> Loader Class Initialized
INFO - 2022-03-21 04:57:16 --> Helper loaded: url_helper
INFO - 2022-03-21 04:57:16 --> Helper loaded: form_helper
INFO - 2022-03-21 04:57:16 --> Helper loaded: common_helper
INFO - 2022-03-21 04:57:16 --> Database Driver Class Initialized
DEBUG - 2022-03-21 04:57:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 04:57:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 04:57:16 --> Controller Class Initialized
INFO - 2022-03-21 04:57:16 --> Form Validation Class Initialized
DEBUG - 2022-03-21 04:57:16 --> Encrypt Class Initialized
INFO - 2022-03-21 04:57:16 --> Model "Patient_model" initialized
INFO - 2022-03-21 04:57:16 --> Model "Patientcase_model" initialized
INFO - 2022-03-21 04:57:16 --> Model "Prefix_master" initialized
INFO - 2022-03-21 04:57:16 --> Model "Users_model" initialized
INFO - 2022-03-21 04:57:16 --> Model "Hospital_model" initialized
INFO - 2022-03-21 04:57:17 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-21 04:57:17 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-21 04:57:17 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-21 04:57:17 --> Final output sent to browser
DEBUG - 2022-03-21 04:57:17 --> Total execution time: 0.0745
ERROR - 2022-03-21 04:57:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 04:57:21 --> Config Class Initialized
INFO - 2022-03-21 04:57:21 --> Hooks Class Initialized
DEBUG - 2022-03-21 04:57:21 --> UTF-8 Support Enabled
INFO - 2022-03-21 04:57:21 --> Utf8 Class Initialized
INFO - 2022-03-21 04:57:21 --> URI Class Initialized
INFO - 2022-03-21 04:57:21 --> Router Class Initialized
INFO - 2022-03-21 04:57:21 --> Output Class Initialized
INFO - 2022-03-21 04:57:21 --> Security Class Initialized
DEBUG - 2022-03-21 04:57:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 04:57:21 --> Input Class Initialized
INFO - 2022-03-21 04:57:21 --> Language Class Initialized
INFO - 2022-03-21 04:57:21 --> Loader Class Initialized
INFO - 2022-03-21 04:57:21 --> Helper loaded: url_helper
INFO - 2022-03-21 04:57:21 --> Helper loaded: form_helper
INFO - 2022-03-21 04:57:21 --> Helper loaded: common_helper
INFO - 2022-03-21 04:57:21 --> Database Driver Class Initialized
DEBUG - 2022-03-21 04:57:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 04:57:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 04:57:21 --> Controller Class Initialized
INFO - 2022-03-21 04:57:21 --> Form Validation Class Initialized
DEBUG - 2022-03-21 04:57:21 --> Encrypt Class Initialized
INFO - 2022-03-21 04:57:21 --> Model "Patient_model" initialized
INFO - 2022-03-21 04:57:21 --> Model "Patientcase_model" initialized
INFO - 2022-03-21 04:57:21 --> Model "Referredby_model" initialized
INFO - 2022-03-21 04:57:21 --> Model "Prefix_master" initialized
INFO - 2022-03-21 04:57:21 --> Model "Hospital_model" initialized
INFO - 2022-03-21 04:57:21 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-21 04:57:21 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-21 04:57:21 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-21 04:57:21 --> Final output sent to browser
DEBUG - 2022-03-21 04:57:21 --> Total execution time: 0.1045
ERROR - 2022-03-21 04:57:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 04:57:54 --> Config Class Initialized
INFO - 2022-03-21 04:57:54 --> Hooks Class Initialized
DEBUG - 2022-03-21 04:57:54 --> UTF-8 Support Enabled
INFO - 2022-03-21 04:57:54 --> Utf8 Class Initialized
INFO - 2022-03-21 04:57:54 --> URI Class Initialized
INFO - 2022-03-21 04:57:54 --> Router Class Initialized
INFO - 2022-03-21 04:57:54 --> Output Class Initialized
INFO - 2022-03-21 04:57:54 --> Security Class Initialized
DEBUG - 2022-03-21 04:57:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 04:57:54 --> Input Class Initialized
INFO - 2022-03-21 04:57:54 --> Language Class Initialized
INFO - 2022-03-21 04:57:54 --> Loader Class Initialized
INFO - 2022-03-21 04:57:54 --> Helper loaded: url_helper
INFO - 2022-03-21 04:57:54 --> Helper loaded: form_helper
INFO - 2022-03-21 04:57:54 --> Helper loaded: common_helper
INFO - 2022-03-21 04:57:54 --> Database Driver Class Initialized
DEBUG - 2022-03-21 04:57:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 04:57:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 04:57:54 --> Controller Class Initialized
INFO - 2022-03-21 04:57:54 --> Form Validation Class Initialized
DEBUG - 2022-03-21 04:57:54 --> Encrypt Class Initialized
INFO - 2022-03-21 04:57:54 --> Model "Patient_model" initialized
INFO - 2022-03-21 04:57:54 --> Model "Patientcase_model" initialized
INFO - 2022-03-21 04:57:54 --> Model "Prefix_master" initialized
INFO - 2022-03-21 04:57:54 --> Model "Users_model" initialized
INFO - 2022-03-21 04:57:54 --> Model "Hospital_model" initialized
INFO - 2022-03-21 04:57:55 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-21 04:57:56 --> Final output sent to browser
DEBUG - 2022-03-21 04:57:56 --> Total execution time: 2.1585
ERROR - 2022-03-21 04:59:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 04:59:03 --> Config Class Initialized
INFO - 2022-03-21 04:59:03 --> Hooks Class Initialized
DEBUG - 2022-03-21 04:59:03 --> UTF-8 Support Enabled
INFO - 2022-03-21 04:59:03 --> Utf8 Class Initialized
INFO - 2022-03-21 04:59:03 --> URI Class Initialized
INFO - 2022-03-21 04:59:03 --> Router Class Initialized
INFO - 2022-03-21 04:59:03 --> Output Class Initialized
INFO - 2022-03-21 04:59:03 --> Security Class Initialized
DEBUG - 2022-03-21 04:59:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 04:59:03 --> Input Class Initialized
INFO - 2022-03-21 04:59:03 --> Language Class Initialized
INFO - 2022-03-21 04:59:03 --> Loader Class Initialized
INFO - 2022-03-21 04:59:03 --> Helper loaded: url_helper
INFO - 2022-03-21 04:59:03 --> Helper loaded: form_helper
INFO - 2022-03-21 04:59:03 --> Helper loaded: common_helper
INFO - 2022-03-21 04:59:03 --> Database Driver Class Initialized
DEBUG - 2022-03-21 04:59:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 04:59:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 04:59:03 --> Controller Class Initialized
INFO - 2022-03-21 04:59:03 --> Form Validation Class Initialized
DEBUG - 2022-03-21 04:59:03 --> Encrypt Class Initialized
INFO - 2022-03-21 04:59:03 --> Model "Patient_model" initialized
INFO - 2022-03-21 04:59:03 --> Model "Patientcase_model" initialized
INFO - 2022-03-21 04:59:03 --> Model "Referredby_model" initialized
INFO - 2022-03-21 04:59:03 --> Model "Prefix_master" initialized
INFO - 2022-03-21 04:59:03 --> Model "Hospital_model" initialized
INFO - 2022-03-21 04:59:03 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-21 04:59:03 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-21 04:59:03 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-21 04:59:03 --> Final output sent to browser
DEBUG - 2022-03-21 04:59:03 --> Total execution time: 0.0492
ERROR - 2022-03-21 04:59:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 04:59:48 --> Config Class Initialized
INFO - 2022-03-21 04:59:48 --> Hooks Class Initialized
DEBUG - 2022-03-21 04:59:48 --> UTF-8 Support Enabled
INFO - 2022-03-21 04:59:48 --> Utf8 Class Initialized
INFO - 2022-03-21 04:59:48 --> URI Class Initialized
INFO - 2022-03-21 04:59:48 --> Router Class Initialized
INFO - 2022-03-21 04:59:48 --> Output Class Initialized
INFO - 2022-03-21 04:59:48 --> Security Class Initialized
DEBUG - 2022-03-21 04:59:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 04:59:48 --> Input Class Initialized
INFO - 2022-03-21 04:59:48 --> Language Class Initialized
INFO - 2022-03-21 04:59:48 --> Loader Class Initialized
INFO - 2022-03-21 04:59:48 --> Helper loaded: url_helper
INFO - 2022-03-21 04:59:48 --> Helper loaded: form_helper
INFO - 2022-03-21 04:59:48 --> Helper loaded: common_helper
INFO - 2022-03-21 04:59:48 --> Database Driver Class Initialized
DEBUG - 2022-03-21 04:59:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 04:59:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 04:59:48 --> Controller Class Initialized
INFO - 2022-03-21 04:59:48 --> Form Validation Class Initialized
DEBUG - 2022-03-21 04:59:48 --> Encrypt Class Initialized
INFO - 2022-03-21 04:59:48 --> Model "Patient_model" initialized
INFO - 2022-03-21 04:59:48 --> Model "Patientcase_model" initialized
INFO - 2022-03-21 04:59:48 --> Model "Referredby_model" initialized
INFO - 2022-03-21 04:59:48 --> Model "Prefix_master" initialized
INFO - 2022-03-21 04:59:48 --> Model "Hospital_model" initialized
ERROR - 2022-03-21 04:59:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 04:59:49 --> Config Class Initialized
INFO - 2022-03-21 04:59:49 --> Hooks Class Initialized
DEBUG - 2022-03-21 04:59:49 --> UTF-8 Support Enabled
INFO - 2022-03-21 04:59:49 --> Utf8 Class Initialized
INFO - 2022-03-21 04:59:49 --> URI Class Initialized
INFO - 2022-03-21 04:59:49 --> Router Class Initialized
INFO - 2022-03-21 04:59:49 --> Output Class Initialized
INFO - 2022-03-21 04:59:49 --> Security Class Initialized
DEBUG - 2022-03-21 04:59:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 04:59:49 --> Input Class Initialized
INFO - 2022-03-21 04:59:49 --> Language Class Initialized
INFO - 2022-03-21 04:59:49 --> Loader Class Initialized
INFO - 2022-03-21 04:59:49 --> Helper loaded: url_helper
INFO - 2022-03-21 04:59:49 --> Helper loaded: form_helper
INFO - 2022-03-21 04:59:49 --> Helper loaded: common_helper
INFO - 2022-03-21 04:59:49 --> Database Driver Class Initialized
DEBUG - 2022-03-21 04:59:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 04:59:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 04:59:49 --> Controller Class Initialized
INFO - 2022-03-21 04:59:49 --> Form Validation Class Initialized
DEBUG - 2022-03-21 04:59:49 --> Encrypt Class Initialized
INFO - 2022-03-21 04:59:49 --> Model "Patient_model" initialized
INFO - 2022-03-21 04:59:49 --> Model "Patientcase_model" initialized
INFO - 2022-03-21 04:59:49 --> Model "Referredby_model" initialized
INFO - 2022-03-21 04:59:49 --> Model "Prefix_master" initialized
INFO - 2022-03-21 04:59:49 --> Model "Hospital_model" initialized
INFO - 2022-03-21 04:59:49 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-21 04:59:49 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-21 04:59:49 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-21 04:59:49 --> Final output sent to browser
DEBUG - 2022-03-21 04:59:49 --> Total execution time: 0.0613
ERROR - 2022-03-21 04:59:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 04:59:50 --> Config Class Initialized
INFO - 2022-03-21 04:59:50 --> Hooks Class Initialized
DEBUG - 2022-03-21 04:59:50 --> UTF-8 Support Enabled
INFO - 2022-03-21 04:59:50 --> Utf8 Class Initialized
INFO - 2022-03-21 04:59:50 --> URI Class Initialized
INFO - 2022-03-21 04:59:50 --> Router Class Initialized
INFO - 2022-03-21 04:59:50 --> Output Class Initialized
INFO - 2022-03-21 04:59:50 --> Security Class Initialized
DEBUG - 2022-03-21 04:59:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 04:59:50 --> Input Class Initialized
INFO - 2022-03-21 04:59:50 --> Language Class Initialized
INFO - 2022-03-21 04:59:50 --> Loader Class Initialized
INFO - 2022-03-21 04:59:50 --> Helper loaded: url_helper
INFO - 2022-03-21 04:59:50 --> Helper loaded: form_helper
INFO - 2022-03-21 04:59:50 --> Helper loaded: common_helper
INFO - 2022-03-21 04:59:50 --> Database Driver Class Initialized
DEBUG - 2022-03-21 04:59:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 04:59:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 04:59:50 --> Controller Class Initialized
INFO - 2022-03-21 04:59:50 --> Form Validation Class Initialized
DEBUG - 2022-03-21 04:59:50 --> Encrypt Class Initialized
INFO - 2022-03-21 04:59:50 --> Model "Patient_model" initialized
INFO - 2022-03-21 04:59:50 --> Model "Patientcase_model" initialized
INFO - 2022-03-21 04:59:50 --> Model "Prefix_master" initialized
INFO - 2022-03-21 04:59:50 --> Model "Users_model" initialized
INFO - 2022-03-21 04:59:50 --> Model "Hospital_model" initialized
INFO - 2022-03-21 04:59:50 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-21 04:59:50 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-21 04:59:50 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-21 04:59:50 --> Final output sent to browser
DEBUG - 2022-03-21 04:59:50 --> Total execution time: 0.0670
ERROR - 2022-03-21 05:01:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 05:01:35 --> Config Class Initialized
INFO - 2022-03-21 05:01:35 --> Hooks Class Initialized
DEBUG - 2022-03-21 05:01:35 --> UTF-8 Support Enabled
INFO - 2022-03-21 05:01:35 --> Utf8 Class Initialized
INFO - 2022-03-21 05:01:35 --> URI Class Initialized
INFO - 2022-03-21 05:01:35 --> Router Class Initialized
INFO - 2022-03-21 05:01:35 --> Output Class Initialized
INFO - 2022-03-21 05:01:35 --> Security Class Initialized
DEBUG - 2022-03-21 05:01:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 05:01:35 --> Input Class Initialized
INFO - 2022-03-21 05:01:35 --> Language Class Initialized
INFO - 2022-03-21 05:01:35 --> Loader Class Initialized
INFO - 2022-03-21 05:01:35 --> Helper loaded: url_helper
INFO - 2022-03-21 05:01:35 --> Helper loaded: form_helper
INFO - 2022-03-21 05:01:35 --> Helper loaded: common_helper
INFO - 2022-03-21 05:01:35 --> Database Driver Class Initialized
DEBUG - 2022-03-21 05:01:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 05:01:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 05:01:35 --> Controller Class Initialized
INFO - 2022-03-21 05:01:35 --> Form Validation Class Initialized
DEBUG - 2022-03-21 05:01:35 --> Encrypt Class Initialized
INFO - 2022-03-21 05:01:35 --> Model "Patient_model" initialized
INFO - 2022-03-21 05:01:35 --> Model "Patientcase_model" initialized
INFO - 2022-03-21 05:01:35 --> Model "Referredby_model" initialized
INFO - 2022-03-21 05:01:35 --> Model "Prefix_master" initialized
INFO - 2022-03-21 05:01:35 --> Model "Hospital_model" initialized
INFO - 2022-03-21 05:01:35 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-21 05:01:35 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-21 05:01:35 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-21 05:01:35 --> Final output sent to browser
DEBUG - 2022-03-21 05:01:35 --> Total execution time: 0.0670
ERROR - 2022-03-21 05:01:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 05:01:49 --> Config Class Initialized
INFO - 2022-03-21 05:01:49 --> Hooks Class Initialized
DEBUG - 2022-03-21 05:01:49 --> UTF-8 Support Enabled
INFO - 2022-03-21 05:01:49 --> Utf8 Class Initialized
INFO - 2022-03-21 05:01:49 --> URI Class Initialized
INFO - 2022-03-21 05:01:49 --> Router Class Initialized
INFO - 2022-03-21 05:01:49 --> Output Class Initialized
INFO - 2022-03-21 05:01:49 --> Security Class Initialized
DEBUG - 2022-03-21 05:01:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 05:01:49 --> Input Class Initialized
INFO - 2022-03-21 05:01:49 --> Language Class Initialized
INFO - 2022-03-21 05:01:49 --> Loader Class Initialized
INFO - 2022-03-21 05:01:49 --> Helper loaded: url_helper
INFO - 2022-03-21 05:01:49 --> Helper loaded: form_helper
INFO - 2022-03-21 05:01:49 --> Helper loaded: common_helper
INFO - 2022-03-21 05:01:49 --> Database Driver Class Initialized
DEBUG - 2022-03-21 05:01:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 05:01:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 05:01:49 --> Controller Class Initialized
INFO - 2022-03-21 05:01:49 --> Form Validation Class Initialized
DEBUG - 2022-03-21 05:01:49 --> Encrypt Class Initialized
INFO - 2022-03-21 05:01:49 --> Model "Patient_model" initialized
INFO - 2022-03-21 05:01:49 --> Model "Patientcase_model" initialized
INFO - 2022-03-21 05:01:49 --> Model "Referredby_model" initialized
INFO - 2022-03-21 05:01:49 --> Model "Prefix_master" initialized
INFO - 2022-03-21 05:01:49 --> Model "Hospital_model" initialized
INFO - 2022-03-21 05:01:49 --> Upload Class Initialized
INFO - 2022-03-21 05:01:49 --> Final output sent to browser
DEBUG - 2022-03-21 05:01:49 --> Total execution time: 0.0602
ERROR - 2022-03-21 05:01:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 05:01:53 --> Config Class Initialized
INFO - 2022-03-21 05:01:53 --> Hooks Class Initialized
DEBUG - 2022-03-21 05:01:53 --> UTF-8 Support Enabled
INFO - 2022-03-21 05:01:53 --> Utf8 Class Initialized
INFO - 2022-03-21 05:01:53 --> URI Class Initialized
INFO - 2022-03-21 05:01:53 --> Router Class Initialized
INFO - 2022-03-21 05:01:53 --> Output Class Initialized
INFO - 2022-03-21 05:01:53 --> Security Class Initialized
DEBUG - 2022-03-21 05:01:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 05:01:53 --> Input Class Initialized
INFO - 2022-03-21 05:01:53 --> Language Class Initialized
INFO - 2022-03-21 05:01:53 --> Loader Class Initialized
INFO - 2022-03-21 05:01:53 --> Helper loaded: url_helper
INFO - 2022-03-21 05:01:53 --> Helper loaded: form_helper
INFO - 2022-03-21 05:01:53 --> Helper loaded: common_helper
INFO - 2022-03-21 05:01:53 --> Database Driver Class Initialized
DEBUG - 2022-03-21 05:01:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 05:01:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 05:01:53 --> Controller Class Initialized
INFO - 2022-03-21 05:01:53 --> Form Validation Class Initialized
DEBUG - 2022-03-21 05:01:53 --> Encrypt Class Initialized
INFO - 2022-03-21 05:01:53 --> Model "Patient_model" initialized
INFO - 2022-03-21 05:01:53 --> Model "Patientcase_model" initialized
INFO - 2022-03-21 05:01:53 --> Model "Referredby_model" initialized
INFO - 2022-03-21 05:01:53 --> Model "Prefix_master" initialized
INFO - 2022-03-21 05:01:53 --> Model "Hospital_model" initialized
INFO - 2022-03-21 05:01:53 --> Upload Class Initialized
INFO - 2022-03-21 05:01:53 --> Final output sent to browser
DEBUG - 2022-03-21 05:01:53 --> Total execution time: 0.0335
ERROR - 2022-03-21 05:01:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 05:01:57 --> Config Class Initialized
INFO - 2022-03-21 05:01:57 --> Hooks Class Initialized
DEBUG - 2022-03-21 05:01:57 --> UTF-8 Support Enabled
INFO - 2022-03-21 05:01:57 --> Utf8 Class Initialized
INFO - 2022-03-21 05:01:57 --> URI Class Initialized
INFO - 2022-03-21 05:01:57 --> Router Class Initialized
INFO - 2022-03-21 05:01:57 --> Output Class Initialized
INFO - 2022-03-21 05:01:57 --> Security Class Initialized
DEBUG - 2022-03-21 05:01:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 05:01:57 --> Input Class Initialized
INFO - 2022-03-21 05:01:57 --> Language Class Initialized
INFO - 2022-03-21 05:01:57 --> Loader Class Initialized
INFO - 2022-03-21 05:01:57 --> Helper loaded: url_helper
INFO - 2022-03-21 05:01:57 --> Helper loaded: form_helper
INFO - 2022-03-21 05:01:57 --> Helper loaded: common_helper
INFO - 2022-03-21 05:01:57 --> Database Driver Class Initialized
DEBUG - 2022-03-21 05:01:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 05:01:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 05:01:57 --> Controller Class Initialized
INFO - 2022-03-21 05:01:57 --> Form Validation Class Initialized
DEBUG - 2022-03-21 05:01:57 --> Encrypt Class Initialized
INFO - 2022-03-21 05:01:57 --> Model "Patient_model" initialized
INFO - 2022-03-21 05:01:57 --> Model "Patientcase_model" initialized
INFO - 2022-03-21 05:01:57 --> Model "Referredby_model" initialized
INFO - 2022-03-21 05:01:57 --> Model "Prefix_master" initialized
INFO - 2022-03-21 05:01:57 --> Model "Hospital_model" initialized
ERROR - 2022-03-21 05:01:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 05:01:57 --> Config Class Initialized
INFO - 2022-03-21 05:01:57 --> Hooks Class Initialized
DEBUG - 2022-03-21 05:01:57 --> UTF-8 Support Enabled
INFO - 2022-03-21 05:01:57 --> Utf8 Class Initialized
INFO - 2022-03-21 05:01:57 --> URI Class Initialized
INFO - 2022-03-21 05:01:57 --> Router Class Initialized
INFO - 2022-03-21 05:01:57 --> Output Class Initialized
INFO - 2022-03-21 05:01:57 --> Security Class Initialized
DEBUG - 2022-03-21 05:01:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 05:01:57 --> Input Class Initialized
INFO - 2022-03-21 05:01:57 --> Language Class Initialized
INFO - 2022-03-21 05:01:57 --> Loader Class Initialized
INFO - 2022-03-21 05:01:58 --> Helper loaded: url_helper
INFO - 2022-03-21 05:01:58 --> Helper loaded: form_helper
INFO - 2022-03-21 05:01:58 --> Helper loaded: common_helper
INFO - 2022-03-21 05:01:58 --> Database Driver Class Initialized
DEBUG - 2022-03-21 05:01:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 05:01:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 05:01:58 --> Controller Class Initialized
INFO - 2022-03-21 05:01:58 --> Form Validation Class Initialized
DEBUG - 2022-03-21 05:01:58 --> Encrypt Class Initialized
INFO - 2022-03-21 05:01:58 --> Model "Patient_model" initialized
INFO - 2022-03-21 05:01:58 --> Model "Patientcase_model" initialized
INFO - 2022-03-21 05:01:58 --> Model "Referredby_model" initialized
INFO - 2022-03-21 05:01:58 --> Model "Prefix_master" initialized
INFO - 2022-03-21 05:01:58 --> Model "Hospital_model" initialized
INFO - 2022-03-21 05:01:58 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-21 05:01:58 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-21 05:01:58 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-21 05:01:58 --> Final output sent to browser
DEBUG - 2022-03-21 05:01:58 --> Total execution time: 0.0519
ERROR - 2022-03-21 05:01:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 05:01:58 --> Config Class Initialized
INFO - 2022-03-21 05:01:58 --> Hooks Class Initialized
DEBUG - 2022-03-21 05:01:58 --> UTF-8 Support Enabled
INFO - 2022-03-21 05:01:58 --> Utf8 Class Initialized
INFO - 2022-03-21 05:01:58 --> URI Class Initialized
INFO - 2022-03-21 05:01:58 --> Router Class Initialized
INFO - 2022-03-21 05:01:58 --> Output Class Initialized
INFO - 2022-03-21 05:01:58 --> Security Class Initialized
DEBUG - 2022-03-21 05:01:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 05:01:58 --> Input Class Initialized
INFO - 2022-03-21 05:01:58 --> Language Class Initialized
INFO - 2022-03-21 05:01:58 --> Loader Class Initialized
INFO - 2022-03-21 05:01:58 --> Helper loaded: url_helper
INFO - 2022-03-21 05:01:58 --> Helper loaded: form_helper
INFO - 2022-03-21 05:01:58 --> Helper loaded: common_helper
INFO - 2022-03-21 05:01:58 --> Database Driver Class Initialized
DEBUG - 2022-03-21 05:01:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 05:01:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 05:01:58 --> Controller Class Initialized
INFO - 2022-03-21 05:01:58 --> Form Validation Class Initialized
DEBUG - 2022-03-21 05:01:58 --> Encrypt Class Initialized
INFO - 2022-03-21 05:01:58 --> Model "Patient_model" initialized
INFO - 2022-03-21 05:01:58 --> Model "Patientcase_model" initialized
INFO - 2022-03-21 05:01:58 --> Model "Prefix_master" initialized
INFO - 2022-03-21 05:01:58 --> Model "Users_model" initialized
INFO - 2022-03-21 05:01:58 --> Model "Hospital_model" initialized
INFO - 2022-03-21 05:01:58 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-21 05:01:58 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-21 05:01:58 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-21 05:01:58 --> Final output sent to browser
DEBUG - 2022-03-21 05:01:58 --> Total execution time: 0.0772
ERROR - 2022-03-21 05:02:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 05:02:03 --> Config Class Initialized
INFO - 2022-03-21 05:02:03 --> Hooks Class Initialized
DEBUG - 2022-03-21 05:02:03 --> UTF-8 Support Enabled
INFO - 2022-03-21 05:02:03 --> Utf8 Class Initialized
INFO - 2022-03-21 05:02:03 --> URI Class Initialized
INFO - 2022-03-21 05:02:03 --> Router Class Initialized
INFO - 2022-03-21 05:02:03 --> Output Class Initialized
INFO - 2022-03-21 05:02:03 --> Security Class Initialized
DEBUG - 2022-03-21 05:02:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 05:02:03 --> Input Class Initialized
INFO - 2022-03-21 05:02:03 --> Language Class Initialized
INFO - 2022-03-21 05:02:03 --> Loader Class Initialized
INFO - 2022-03-21 05:02:03 --> Helper loaded: url_helper
INFO - 2022-03-21 05:02:03 --> Helper loaded: form_helper
INFO - 2022-03-21 05:02:03 --> Helper loaded: common_helper
INFO - 2022-03-21 05:02:03 --> Database Driver Class Initialized
DEBUG - 2022-03-21 05:02:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 05:02:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 05:02:03 --> Controller Class Initialized
INFO - 2022-03-21 05:02:03 --> Form Validation Class Initialized
DEBUG - 2022-03-21 05:02:03 --> Encrypt Class Initialized
INFO - 2022-03-21 05:02:03 --> Model "Patient_model" initialized
INFO - 2022-03-21 05:02:03 --> Model "Patientcase_model" initialized
INFO - 2022-03-21 05:02:03 --> Model "Referredby_model" initialized
INFO - 2022-03-21 05:02:03 --> Model "Prefix_master" initialized
INFO - 2022-03-21 05:02:03 --> Model "Hospital_model" initialized
INFO - 2022-03-21 05:02:03 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-21 05:02:03 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-21 05:02:03 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-21 05:02:03 --> Final output sent to browser
DEBUG - 2022-03-21 05:02:03 --> Total execution time: 0.1460
ERROR - 2022-03-21 05:02:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 05:02:29 --> Config Class Initialized
INFO - 2022-03-21 05:02:29 --> Hooks Class Initialized
DEBUG - 2022-03-21 05:02:29 --> UTF-8 Support Enabled
INFO - 2022-03-21 05:02:29 --> Utf8 Class Initialized
INFO - 2022-03-21 05:02:29 --> URI Class Initialized
INFO - 2022-03-21 05:02:29 --> Router Class Initialized
INFO - 2022-03-21 05:02:29 --> Output Class Initialized
INFO - 2022-03-21 05:02:29 --> Security Class Initialized
DEBUG - 2022-03-21 05:02:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 05:02:29 --> Input Class Initialized
INFO - 2022-03-21 05:02:29 --> Language Class Initialized
INFO - 2022-03-21 05:02:29 --> Loader Class Initialized
INFO - 2022-03-21 05:02:29 --> Helper loaded: url_helper
INFO - 2022-03-21 05:02:29 --> Helper loaded: form_helper
INFO - 2022-03-21 05:02:29 --> Helper loaded: common_helper
INFO - 2022-03-21 05:02:29 --> Database Driver Class Initialized
DEBUG - 2022-03-21 05:02:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 05:02:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 05:02:29 --> Controller Class Initialized
INFO - 2022-03-21 05:02:29 --> Form Validation Class Initialized
DEBUG - 2022-03-21 05:02:29 --> Encrypt Class Initialized
INFO - 2022-03-21 05:02:29 --> Model "Patient_model" initialized
INFO - 2022-03-21 05:02:29 --> Model "Patientcase_model" initialized
INFO - 2022-03-21 05:02:29 --> Model "Prefix_master" initialized
INFO - 2022-03-21 05:02:29 --> Model "Users_model" initialized
INFO - 2022-03-21 05:02:29 --> Model "Hospital_model" initialized
INFO - 2022-03-21 05:02:29 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-21 05:02:31 --> Final output sent to browser
DEBUG - 2022-03-21 05:02:31 --> Total execution time: 1.8937
ERROR - 2022-03-21 05:06:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 05:06:18 --> Config Class Initialized
INFO - 2022-03-21 05:06:18 --> Hooks Class Initialized
DEBUG - 2022-03-21 05:06:18 --> UTF-8 Support Enabled
INFO - 2022-03-21 05:06:18 --> Utf8 Class Initialized
INFO - 2022-03-21 05:06:18 --> URI Class Initialized
DEBUG - 2022-03-21 05:06:18 --> No URI present. Default controller set.
INFO - 2022-03-21 05:06:18 --> Router Class Initialized
INFO - 2022-03-21 05:06:18 --> Output Class Initialized
INFO - 2022-03-21 05:06:18 --> Security Class Initialized
DEBUG - 2022-03-21 05:06:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 05:06:18 --> Input Class Initialized
INFO - 2022-03-21 05:06:18 --> Language Class Initialized
INFO - 2022-03-21 05:06:18 --> Loader Class Initialized
INFO - 2022-03-21 05:06:18 --> Helper loaded: url_helper
INFO - 2022-03-21 05:06:18 --> Helper loaded: form_helper
INFO - 2022-03-21 05:06:18 --> Helper loaded: common_helper
INFO - 2022-03-21 05:06:18 --> Database Driver Class Initialized
DEBUG - 2022-03-21 05:06:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 05:06:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 05:06:18 --> Controller Class Initialized
INFO - 2022-03-21 05:06:18 --> Form Validation Class Initialized
DEBUG - 2022-03-21 05:06:18 --> Encrypt Class Initialized
DEBUG - 2022-03-21 05:06:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 05:06:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-21 05:06:18 --> Email Class Initialized
INFO - 2022-03-21 05:06:18 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-21 05:06:18 --> Calendar Class Initialized
INFO - 2022-03-21 05:06:18 --> Model "Login_model" initialized
INFO - 2022-03-21 05:06:18 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-21 05:06:18 --> Final output sent to browser
DEBUG - 2022-03-21 05:06:18 --> Total execution time: 0.1300
ERROR - 2022-03-21 05:06:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 05:06:19 --> Config Class Initialized
INFO - 2022-03-21 05:06:19 --> Hooks Class Initialized
DEBUG - 2022-03-21 05:06:19 --> UTF-8 Support Enabled
INFO - 2022-03-21 05:06:19 --> Utf8 Class Initialized
INFO - 2022-03-21 05:06:19 --> URI Class Initialized
DEBUG - 2022-03-21 05:06:19 --> No URI present. Default controller set.
INFO - 2022-03-21 05:06:19 --> Router Class Initialized
INFO - 2022-03-21 05:06:19 --> Output Class Initialized
INFO - 2022-03-21 05:06:19 --> Security Class Initialized
DEBUG - 2022-03-21 05:06:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 05:06:19 --> Input Class Initialized
INFO - 2022-03-21 05:06:19 --> Language Class Initialized
INFO - 2022-03-21 05:06:19 --> Loader Class Initialized
INFO - 2022-03-21 05:06:19 --> Helper loaded: url_helper
INFO - 2022-03-21 05:06:19 --> Helper loaded: form_helper
INFO - 2022-03-21 05:06:19 --> Helper loaded: common_helper
INFO - 2022-03-21 05:06:19 --> Database Driver Class Initialized
DEBUG - 2022-03-21 05:06:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 05:06:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 05:06:19 --> Controller Class Initialized
INFO - 2022-03-21 05:06:19 --> Form Validation Class Initialized
DEBUG - 2022-03-21 05:06:19 --> Encrypt Class Initialized
DEBUG - 2022-03-21 05:06:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 05:06:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-21 05:06:19 --> Email Class Initialized
INFO - 2022-03-21 05:06:19 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-21 05:06:19 --> Calendar Class Initialized
INFO - 2022-03-21 05:06:19 --> Model "Login_model" initialized
INFO - 2022-03-21 05:06:19 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-21 05:06:19 --> Final output sent to browser
DEBUG - 2022-03-21 05:06:19 --> Total execution time: 0.0252
ERROR - 2022-03-21 05:06:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 05:06:35 --> Config Class Initialized
INFO - 2022-03-21 05:06:35 --> Hooks Class Initialized
DEBUG - 2022-03-21 05:06:35 --> UTF-8 Support Enabled
INFO - 2022-03-21 05:06:35 --> Utf8 Class Initialized
INFO - 2022-03-21 05:06:35 --> URI Class Initialized
INFO - 2022-03-21 05:06:35 --> Router Class Initialized
INFO - 2022-03-21 05:06:35 --> Output Class Initialized
INFO - 2022-03-21 05:06:35 --> Security Class Initialized
DEBUG - 2022-03-21 05:06:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 05:06:35 --> Input Class Initialized
INFO - 2022-03-21 05:06:35 --> Language Class Initialized
INFO - 2022-03-21 05:06:35 --> Loader Class Initialized
INFO - 2022-03-21 05:06:35 --> Helper loaded: url_helper
INFO - 2022-03-21 05:06:35 --> Helper loaded: form_helper
INFO - 2022-03-21 05:06:35 --> Helper loaded: common_helper
INFO - 2022-03-21 05:06:35 --> Database Driver Class Initialized
DEBUG - 2022-03-21 05:06:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 05:06:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 05:06:35 --> Controller Class Initialized
INFO - 2022-03-21 05:06:35 --> Form Validation Class Initialized
DEBUG - 2022-03-21 05:06:35 --> Encrypt Class Initialized
DEBUG - 2022-03-21 05:06:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 05:06:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-21 05:06:35 --> Email Class Initialized
INFO - 2022-03-21 05:06:35 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-21 05:06:35 --> Calendar Class Initialized
INFO - 2022-03-21 05:06:35 --> Model "Login_model" initialized
INFO - 2022-03-21 05:06:35 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-03-21 05:06:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 05:06:36 --> Config Class Initialized
INFO - 2022-03-21 05:06:36 --> Hooks Class Initialized
DEBUG - 2022-03-21 05:06:36 --> UTF-8 Support Enabled
INFO - 2022-03-21 05:06:36 --> Utf8 Class Initialized
INFO - 2022-03-21 05:06:36 --> URI Class Initialized
INFO - 2022-03-21 05:06:36 --> Router Class Initialized
INFO - 2022-03-21 05:06:36 --> Output Class Initialized
INFO - 2022-03-21 05:06:36 --> Security Class Initialized
DEBUG - 2022-03-21 05:06:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 05:06:36 --> Input Class Initialized
INFO - 2022-03-21 05:06:36 --> Language Class Initialized
INFO - 2022-03-21 05:06:36 --> Loader Class Initialized
INFO - 2022-03-21 05:06:36 --> Helper loaded: url_helper
INFO - 2022-03-21 05:06:36 --> Helper loaded: form_helper
INFO - 2022-03-21 05:06:36 --> Helper loaded: common_helper
INFO - 2022-03-21 05:06:36 --> Database Driver Class Initialized
DEBUG - 2022-03-21 05:06:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 05:06:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 05:06:36 --> Controller Class Initialized
INFO - 2022-03-21 05:06:36 --> Form Validation Class Initialized
DEBUG - 2022-03-21 05:06:36 --> Encrypt Class Initialized
INFO - 2022-03-21 05:06:36 --> Model "Login_model" initialized
INFO - 2022-03-21 05:06:36 --> Model "Dashboard_model" initialized
INFO - 2022-03-21 05:06:36 --> Model "Case_model" initialized
INFO - 2022-03-21 05:06:36 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-21 05:06:36 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2022-03-21 05:06:36 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-21 05:06:36 --> Final output sent to browser
DEBUG - 2022-03-21 05:06:36 --> Total execution time: 0.2626
ERROR - 2022-03-21 05:07:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 05:07:31 --> Config Class Initialized
INFO - 2022-03-21 05:07:31 --> Hooks Class Initialized
DEBUG - 2022-03-21 05:07:31 --> UTF-8 Support Enabled
INFO - 2022-03-21 05:07:31 --> Utf8 Class Initialized
INFO - 2022-03-21 05:07:31 --> URI Class Initialized
INFO - 2022-03-21 05:07:31 --> Router Class Initialized
INFO - 2022-03-21 05:07:31 --> Output Class Initialized
INFO - 2022-03-21 05:07:31 --> Security Class Initialized
DEBUG - 2022-03-21 05:07:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 05:07:31 --> Input Class Initialized
INFO - 2022-03-21 05:07:31 --> Language Class Initialized
INFO - 2022-03-21 05:07:31 --> Loader Class Initialized
INFO - 2022-03-21 05:07:31 --> Helper loaded: url_helper
INFO - 2022-03-21 05:07:31 --> Helper loaded: form_helper
INFO - 2022-03-21 05:07:31 --> Helper loaded: common_helper
INFO - 2022-03-21 05:07:31 --> Database Driver Class Initialized
DEBUG - 2022-03-21 05:07:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 05:07:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 05:07:31 --> Controller Class Initialized
INFO - 2022-03-21 05:07:31 --> Form Validation Class Initialized
DEBUG - 2022-03-21 05:07:31 --> Encrypt Class Initialized
INFO - 2022-03-21 05:07:31 --> Model "Patient_model" initialized
INFO - 2022-03-21 05:07:31 --> Model "Patientcase_model" initialized
INFO - 2022-03-21 05:07:31 --> Model "Referredby_model" initialized
INFO - 2022-03-21 05:07:31 --> Model "Prefix_master" initialized
INFO - 2022-03-21 05:07:31 --> Model "Hospital_model" initialized
INFO - 2022-03-21 05:07:31 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-21 05:07:31 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-21 05:07:31 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-21 05:07:31 --> Final output sent to browser
DEBUG - 2022-03-21 05:07:31 --> Total execution time: 0.0927
ERROR - 2022-03-21 05:07:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 05:07:55 --> Config Class Initialized
INFO - 2022-03-21 05:07:55 --> Hooks Class Initialized
DEBUG - 2022-03-21 05:07:55 --> UTF-8 Support Enabled
INFO - 2022-03-21 05:07:55 --> Utf8 Class Initialized
INFO - 2022-03-21 05:07:55 --> URI Class Initialized
INFO - 2022-03-21 05:07:55 --> Router Class Initialized
INFO - 2022-03-21 05:07:55 --> Output Class Initialized
INFO - 2022-03-21 05:07:55 --> Security Class Initialized
DEBUG - 2022-03-21 05:07:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 05:07:55 --> Input Class Initialized
INFO - 2022-03-21 05:07:55 --> Language Class Initialized
INFO - 2022-03-21 05:07:55 --> Loader Class Initialized
INFO - 2022-03-21 05:07:55 --> Helper loaded: url_helper
INFO - 2022-03-21 05:07:55 --> Helper loaded: form_helper
INFO - 2022-03-21 05:07:55 --> Helper loaded: common_helper
INFO - 2022-03-21 05:07:55 --> Database Driver Class Initialized
DEBUG - 2022-03-21 05:07:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 05:07:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 05:07:55 --> Controller Class Initialized
INFO - 2022-03-21 05:07:55 --> Form Validation Class Initialized
DEBUG - 2022-03-21 05:07:55 --> Encrypt Class Initialized
INFO - 2022-03-21 05:07:55 --> Model "Patient_model" initialized
INFO - 2022-03-21 05:07:55 --> Model "Patientcase_model" initialized
INFO - 2022-03-21 05:07:55 --> Model "Prefix_master" initialized
INFO - 2022-03-21 05:07:55 --> Model "Users_model" initialized
INFO - 2022-03-21 05:07:55 --> Model "Hospital_model" initialized
INFO - 2022-03-21 05:07:55 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-21 05:07:55 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-21 05:07:55 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-21 05:07:55 --> Final output sent to browser
DEBUG - 2022-03-21 05:07:55 --> Total execution time: 0.1127
ERROR - 2022-03-21 05:08:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 05:08:05 --> Config Class Initialized
INFO - 2022-03-21 05:08:05 --> Hooks Class Initialized
DEBUG - 2022-03-21 05:08:05 --> UTF-8 Support Enabled
INFO - 2022-03-21 05:08:05 --> Utf8 Class Initialized
INFO - 2022-03-21 05:08:05 --> URI Class Initialized
INFO - 2022-03-21 05:08:05 --> Router Class Initialized
INFO - 2022-03-21 05:08:05 --> Output Class Initialized
INFO - 2022-03-21 05:08:05 --> Security Class Initialized
DEBUG - 2022-03-21 05:08:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 05:08:05 --> Input Class Initialized
INFO - 2022-03-21 05:08:05 --> Language Class Initialized
INFO - 2022-03-21 05:08:05 --> Loader Class Initialized
INFO - 2022-03-21 05:08:05 --> Helper loaded: url_helper
INFO - 2022-03-21 05:08:05 --> Helper loaded: form_helper
INFO - 2022-03-21 05:08:05 --> Helper loaded: common_helper
INFO - 2022-03-21 05:08:05 --> Database Driver Class Initialized
DEBUG - 2022-03-21 05:08:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 05:08:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 05:08:05 --> Controller Class Initialized
INFO - 2022-03-21 05:08:05 --> Form Validation Class Initialized
DEBUG - 2022-03-21 05:08:05 --> Encrypt Class Initialized
INFO - 2022-03-21 05:08:05 --> Model "Patient_model" initialized
INFO - 2022-03-21 05:08:05 --> Model "Patientcase_model" initialized
INFO - 2022-03-21 05:08:05 --> Model "Referredby_model" initialized
INFO - 2022-03-21 05:08:05 --> Model "Prefix_master" initialized
INFO - 2022-03-21 05:08:05 --> Model "Hospital_model" initialized
INFO - 2022-03-21 05:08:05 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-21 05:08:05 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-21 05:08:05 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-21 05:08:05 --> Final output sent to browser
DEBUG - 2022-03-21 05:08:05 --> Total execution time: 0.0804
ERROR - 2022-03-21 05:09:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 05:09:37 --> Config Class Initialized
INFO - 2022-03-21 05:09:37 --> Hooks Class Initialized
DEBUG - 2022-03-21 05:09:37 --> UTF-8 Support Enabled
INFO - 2022-03-21 05:09:37 --> Utf8 Class Initialized
INFO - 2022-03-21 05:09:37 --> URI Class Initialized
INFO - 2022-03-21 05:09:37 --> Router Class Initialized
INFO - 2022-03-21 05:09:37 --> Output Class Initialized
INFO - 2022-03-21 05:09:37 --> Security Class Initialized
DEBUG - 2022-03-21 05:09:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 05:09:37 --> Input Class Initialized
INFO - 2022-03-21 05:09:37 --> Language Class Initialized
INFO - 2022-03-21 05:09:37 --> Loader Class Initialized
INFO - 2022-03-21 05:09:37 --> Helper loaded: url_helper
INFO - 2022-03-21 05:09:37 --> Helper loaded: form_helper
INFO - 2022-03-21 05:09:37 --> Helper loaded: common_helper
INFO - 2022-03-21 05:09:37 --> Database Driver Class Initialized
DEBUG - 2022-03-21 05:09:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 05:09:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 05:09:37 --> Controller Class Initialized
INFO - 2022-03-21 05:09:37 --> Form Validation Class Initialized
DEBUG - 2022-03-21 05:09:37 --> Encrypt Class Initialized
INFO - 2022-03-21 05:09:37 --> Model "Patient_model" initialized
INFO - 2022-03-21 05:09:37 --> Model "Patientcase_model" initialized
INFO - 2022-03-21 05:09:37 --> Model "Referredby_model" initialized
INFO - 2022-03-21 05:09:37 --> Model "Prefix_master" initialized
INFO - 2022-03-21 05:09:37 --> Model "Hospital_model" initialized
ERROR - 2022-03-21 05:09:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 05:09:38 --> Config Class Initialized
INFO - 2022-03-21 05:09:38 --> Hooks Class Initialized
DEBUG - 2022-03-21 05:09:38 --> UTF-8 Support Enabled
INFO - 2022-03-21 05:09:38 --> Utf8 Class Initialized
INFO - 2022-03-21 05:09:38 --> URI Class Initialized
INFO - 2022-03-21 05:09:38 --> Router Class Initialized
INFO - 2022-03-21 05:09:38 --> Output Class Initialized
INFO - 2022-03-21 05:09:38 --> Security Class Initialized
DEBUG - 2022-03-21 05:09:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 05:09:38 --> Input Class Initialized
INFO - 2022-03-21 05:09:38 --> Language Class Initialized
INFO - 2022-03-21 05:09:38 --> Loader Class Initialized
INFO - 2022-03-21 05:09:38 --> Helper loaded: url_helper
INFO - 2022-03-21 05:09:38 --> Helper loaded: form_helper
INFO - 2022-03-21 05:09:38 --> Helper loaded: common_helper
INFO - 2022-03-21 05:09:38 --> Database Driver Class Initialized
DEBUG - 2022-03-21 05:09:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 05:09:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 05:09:38 --> Controller Class Initialized
INFO - 2022-03-21 05:09:38 --> Form Validation Class Initialized
DEBUG - 2022-03-21 05:09:38 --> Encrypt Class Initialized
INFO - 2022-03-21 05:09:38 --> Model "Patient_model" initialized
INFO - 2022-03-21 05:09:38 --> Model "Patientcase_model" initialized
INFO - 2022-03-21 05:09:38 --> Model "Referredby_model" initialized
INFO - 2022-03-21 05:09:38 --> Model "Prefix_master" initialized
INFO - 2022-03-21 05:09:38 --> Model "Hospital_model" initialized
INFO - 2022-03-21 05:09:38 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-21 05:09:38 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-21 05:09:38 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-21 05:09:38 --> Final output sent to browser
DEBUG - 2022-03-21 05:09:38 --> Total execution time: 0.1090
ERROR - 2022-03-21 05:09:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 05:09:40 --> Config Class Initialized
INFO - 2022-03-21 05:09:40 --> Hooks Class Initialized
DEBUG - 2022-03-21 05:09:40 --> UTF-8 Support Enabled
INFO - 2022-03-21 05:09:40 --> Utf8 Class Initialized
INFO - 2022-03-21 05:09:40 --> URI Class Initialized
INFO - 2022-03-21 05:09:40 --> Router Class Initialized
INFO - 2022-03-21 05:09:40 --> Output Class Initialized
INFO - 2022-03-21 05:09:40 --> Security Class Initialized
DEBUG - 2022-03-21 05:09:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 05:09:40 --> Input Class Initialized
INFO - 2022-03-21 05:09:40 --> Language Class Initialized
INFO - 2022-03-21 05:09:40 --> Loader Class Initialized
INFO - 2022-03-21 05:09:40 --> Helper loaded: url_helper
INFO - 2022-03-21 05:09:40 --> Helper loaded: form_helper
INFO - 2022-03-21 05:09:40 --> Helper loaded: common_helper
INFO - 2022-03-21 05:09:40 --> Database Driver Class Initialized
DEBUG - 2022-03-21 05:09:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 05:09:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 05:09:40 --> Controller Class Initialized
INFO - 2022-03-21 05:09:40 --> Form Validation Class Initialized
DEBUG - 2022-03-21 05:09:40 --> Encrypt Class Initialized
INFO - 2022-03-21 05:09:40 --> Model "Patient_model" initialized
INFO - 2022-03-21 05:09:40 --> Model "Patientcase_model" initialized
INFO - 2022-03-21 05:09:40 --> Model "Prefix_master" initialized
INFO - 2022-03-21 05:09:40 --> Model "Users_model" initialized
INFO - 2022-03-21 05:09:40 --> Model "Hospital_model" initialized
INFO - 2022-03-21 05:09:40 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-21 05:09:40 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-21 05:09:40 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-21 05:09:40 --> Final output sent to browser
DEBUG - 2022-03-21 05:09:40 --> Total execution time: 0.1457
ERROR - 2022-03-21 05:10:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 05:10:03 --> Config Class Initialized
INFO - 2022-03-21 05:10:03 --> Hooks Class Initialized
DEBUG - 2022-03-21 05:10:03 --> UTF-8 Support Enabled
INFO - 2022-03-21 05:10:03 --> Utf8 Class Initialized
INFO - 2022-03-21 05:10:03 --> URI Class Initialized
INFO - 2022-03-21 05:10:03 --> Router Class Initialized
INFO - 2022-03-21 05:10:03 --> Output Class Initialized
INFO - 2022-03-21 05:10:03 --> Security Class Initialized
DEBUG - 2022-03-21 05:10:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 05:10:03 --> Input Class Initialized
INFO - 2022-03-21 05:10:03 --> Language Class Initialized
INFO - 2022-03-21 05:10:03 --> Loader Class Initialized
INFO - 2022-03-21 05:10:03 --> Helper loaded: url_helper
INFO - 2022-03-21 05:10:03 --> Helper loaded: form_helper
INFO - 2022-03-21 05:10:03 --> Helper loaded: common_helper
INFO - 2022-03-21 05:10:03 --> Database Driver Class Initialized
DEBUG - 2022-03-21 05:10:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 05:10:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 05:10:03 --> Controller Class Initialized
INFO - 2022-03-21 05:10:03 --> Form Validation Class Initialized
DEBUG - 2022-03-21 05:10:03 --> Encrypt Class Initialized
INFO - 2022-03-21 05:10:03 --> Model "Patient_model" initialized
INFO - 2022-03-21 05:10:03 --> Model "Patientcase_model" initialized
INFO - 2022-03-21 05:10:03 --> Model "Prefix_master" initialized
INFO - 2022-03-21 05:10:03 --> Model "Users_model" initialized
INFO - 2022-03-21 05:10:03 --> Model "Hospital_model" initialized
ERROR - 2022-03-21 05:10:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 05:10:04 --> Config Class Initialized
INFO - 2022-03-21 05:10:04 --> Hooks Class Initialized
DEBUG - 2022-03-21 05:10:04 --> UTF-8 Support Enabled
INFO - 2022-03-21 05:10:04 --> Utf8 Class Initialized
INFO - 2022-03-21 05:10:04 --> URI Class Initialized
INFO - 2022-03-21 05:10:04 --> Router Class Initialized
INFO - 2022-03-21 05:10:04 --> Output Class Initialized
INFO - 2022-03-21 05:10:04 --> Security Class Initialized
DEBUG - 2022-03-21 05:10:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 05:10:04 --> Input Class Initialized
INFO - 2022-03-21 05:10:04 --> Language Class Initialized
INFO - 2022-03-21 05:10:04 --> Loader Class Initialized
INFO - 2022-03-21 05:10:04 --> Helper loaded: url_helper
INFO - 2022-03-21 05:10:04 --> Helper loaded: form_helper
INFO - 2022-03-21 05:10:04 --> Helper loaded: common_helper
INFO - 2022-03-21 05:10:04 --> Database Driver Class Initialized
DEBUG - 2022-03-21 05:10:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 05:10:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 05:10:04 --> Controller Class Initialized
INFO - 2022-03-21 05:10:04 --> Form Validation Class Initialized
DEBUG - 2022-03-21 05:10:04 --> Encrypt Class Initialized
INFO - 2022-03-21 05:10:04 --> Model "Patient_model" initialized
INFO - 2022-03-21 05:10:04 --> Model "Patientcase_model" initialized
INFO - 2022-03-21 05:10:04 --> Model "Prefix_master" initialized
INFO - 2022-03-21 05:10:04 --> Model "Users_model" initialized
INFO - 2022-03-21 05:10:04 --> Model "Hospital_model" initialized
INFO - 2022-03-21 05:10:04 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-21 05:10:04 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-21 05:10:04 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-21 05:10:04 --> Final output sent to browser
DEBUG - 2022-03-21 05:10:04 --> Total execution time: 0.0857
ERROR - 2022-03-21 05:10:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 05:10:16 --> Config Class Initialized
INFO - 2022-03-21 05:10:16 --> Hooks Class Initialized
DEBUG - 2022-03-21 05:10:16 --> UTF-8 Support Enabled
INFO - 2022-03-21 05:10:16 --> Utf8 Class Initialized
INFO - 2022-03-21 05:10:16 --> URI Class Initialized
INFO - 2022-03-21 05:10:16 --> Router Class Initialized
INFO - 2022-03-21 05:10:16 --> Output Class Initialized
INFO - 2022-03-21 05:10:16 --> Security Class Initialized
DEBUG - 2022-03-21 05:10:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 05:10:16 --> Input Class Initialized
INFO - 2022-03-21 05:10:16 --> Language Class Initialized
INFO - 2022-03-21 05:10:16 --> Loader Class Initialized
INFO - 2022-03-21 05:10:16 --> Helper loaded: url_helper
INFO - 2022-03-21 05:10:16 --> Helper loaded: form_helper
INFO - 2022-03-21 05:10:16 --> Helper loaded: common_helper
INFO - 2022-03-21 05:10:16 --> Database Driver Class Initialized
DEBUG - 2022-03-21 05:10:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 05:10:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 05:10:16 --> Controller Class Initialized
INFO - 2022-03-21 05:10:16 --> Form Validation Class Initialized
DEBUG - 2022-03-21 05:10:16 --> Encrypt Class Initialized
INFO - 2022-03-21 05:10:16 --> Model "Patient_model" initialized
INFO - 2022-03-21 05:10:16 --> Model "Patientcase_model" initialized
INFO - 2022-03-21 05:10:16 --> Model "Prefix_master" initialized
INFO - 2022-03-21 05:10:16 --> Model "Users_model" initialized
INFO - 2022-03-21 05:10:16 --> Model "Hospital_model" initialized
ERROR - 2022-03-21 05:10:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 05:10:16 --> Config Class Initialized
INFO - 2022-03-21 05:10:16 --> Hooks Class Initialized
DEBUG - 2022-03-21 05:10:16 --> UTF-8 Support Enabled
INFO - 2022-03-21 05:10:16 --> Utf8 Class Initialized
INFO - 2022-03-21 05:10:16 --> URI Class Initialized
INFO - 2022-03-21 05:10:16 --> Router Class Initialized
INFO - 2022-03-21 05:10:16 --> Output Class Initialized
INFO - 2022-03-21 05:10:16 --> Security Class Initialized
DEBUG - 2022-03-21 05:10:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 05:10:16 --> Input Class Initialized
INFO - 2022-03-21 05:10:16 --> Language Class Initialized
INFO - 2022-03-21 05:10:16 --> Loader Class Initialized
INFO - 2022-03-21 05:10:16 --> Helper loaded: url_helper
INFO - 2022-03-21 05:10:16 --> Helper loaded: form_helper
INFO - 2022-03-21 05:10:16 --> Helper loaded: common_helper
INFO - 2022-03-21 05:10:16 --> Database Driver Class Initialized
DEBUG - 2022-03-21 05:10:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 05:10:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 05:10:16 --> Controller Class Initialized
INFO - 2022-03-21 05:10:16 --> Form Validation Class Initialized
DEBUG - 2022-03-21 05:10:16 --> Encrypt Class Initialized
INFO - 2022-03-21 05:10:16 --> Model "Patient_model" initialized
INFO - 2022-03-21 05:10:16 --> Model "Patientcase_model" initialized
INFO - 2022-03-21 05:10:16 --> Model "Prefix_master" initialized
INFO - 2022-03-21 05:10:16 --> Model "Users_model" initialized
INFO - 2022-03-21 05:10:16 --> Model "Hospital_model" initialized
INFO - 2022-03-21 05:10:17 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-21 05:10:17 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-21 05:10:17 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-21 05:10:17 --> Final output sent to browser
DEBUG - 2022-03-21 05:10:17 --> Total execution time: 0.0742
ERROR - 2022-03-21 05:48:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 05:48:29 --> Config Class Initialized
INFO - 2022-03-21 05:48:29 --> Hooks Class Initialized
DEBUG - 2022-03-21 05:48:29 --> UTF-8 Support Enabled
INFO - 2022-03-21 05:48:29 --> Utf8 Class Initialized
INFO - 2022-03-21 05:48:29 --> URI Class Initialized
DEBUG - 2022-03-21 05:48:29 --> No URI present. Default controller set.
INFO - 2022-03-21 05:48:29 --> Router Class Initialized
INFO - 2022-03-21 05:48:29 --> Output Class Initialized
INFO - 2022-03-21 05:48:29 --> Security Class Initialized
DEBUG - 2022-03-21 05:48:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 05:48:29 --> Input Class Initialized
INFO - 2022-03-21 05:48:29 --> Language Class Initialized
INFO - 2022-03-21 05:48:29 --> Loader Class Initialized
INFO - 2022-03-21 05:48:29 --> Helper loaded: url_helper
INFO - 2022-03-21 05:48:29 --> Helper loaded: form_helper
INFO - 2022-03-21 05:48:29 --> Helper loaded: common_helper
INFO - 2022-03-21 05:48:29 --> Database Driver Class Initialized
DEBUG - 2022-03-21 05:48:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 05:48:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 05:48:29 --> Controller Class Initialized
INFO - 2022-03-21 05:48:29 --> Form Validation Class Initialized
DEBUG - 2022-03-21 05:48:29 --> Encrypt Class Initialized
DEBUG - 2022-03-21 05:48:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 05:48:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-21 05:48:29 --> Email Class Initialized
INFO - 2022-03-21 05:48:29 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-21 05:48:29 --> Calendar Class Initialized
INFO - 2022-03-21 05:48:29 --> Model "Login_model" initialized
INFO - 2022-03-21 05:48:29 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-21 05:48:29 --> Final output sent to browser
DEBUG - 2022-03-21 05:48:29 --> Total execution time: 0.0380
ERROR - 2022-03-21 06:11:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 06:11:20 --> Config Class Initialized
INFO - 2022-03-21 06:11:20 --> Hooks Class Initialized
DEBUG - 2022-03-21 06:11:20 --> UTF-8 Support Enabled
INFO - 2022-03-21 06:11:20 --> Utf8 Class Initialized
INFO - 2022-03-21 06:11:20 --> URI Class Initialized
DEBUG - 2022-03-21 06:11:20 --> No URI present. Default controller set.
INFO - 2022-03-21 06:11:20 --> Router Class Initialized
INFO - 2022-03-21 06:11:20 --> Output Class Initialized
INFO - 2022-03-21 06:11:20 --> Security Class Initialized
DEBUG - 2022-03-21 06:11:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 06:11:20 --> Input Class Initialized
INFO - 2022-03-21 06:11:20 --> Language Class Initialized
INFO - 2022-03-21 06:11:20 --> Loader Class Initialized
INFO - 2022-03-21 06:11:20 --> Helper loaded: url_helper
INFO - 2022-03-21 06:11:20 --> Helper loaded: form_helper
INFO - 2022-03-21 06:11:21 --> Helper loaded: common_helper
INFO - 2022-03-21 06:11:21 --> Database Driver Class Initialized
DEBUG - 2022-03-21 06:11:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 06:11:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 06:11:21 --> Controller Class Initialized
INFO - 2022-03-21 06:11:21 --> Form Validation Class Initialized
DEBUG - 2022-03-21 06:11:21 --> Encrypt Class Initialized
DEBUG - 2022-03-21 06:11:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 06:11:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-21 06:11:21 --> Email Class Initialized
INFO - 2022-03-21 06:11:21 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-21 06:11:21 --> Calendar Class Initialized
INFO - 2022-03-21 06:11:21 --> Model "Login_model" initialized
INFO - 2022-03-21 06:11:21 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-21 06:11:21 --> Final output sent to browser
DEBUG - 2022-03-21 06:11:21 --> Total execution time: 0.0679
ERROR - 2022-03-21 06:11:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 06:11:39 --> Config Class Initialized
INFO - 2022-03-21 06:11:39 --> Hooks Class Initialized
DEBUG - 2022-03-21 06:11:39 --> UTF-8 Support Enabled
INFO - 2022-03-21 06:11:39 --> Utf8 Class Initialized
INFO - 2022-03-21 06:11:39 --> URI Class Initialized
INFO - 2022-03-21 06:11:39 --> Router Class Initialized
INFO - 2022-03-21 06:11:39 --> Output Class Initialized
INFO - 2022-03-21 06:11:39 --> Security Class Initialized
DEBUG - 2022-03-21 06:11:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 06:11:39 --> Input Class Initialized
INFO - 2022-03-21 06:11:39 --> Language Class Initialized
INFO - 2022-03-21 06:11:39 --> Loader Class Initialized
INFO - 2022-03-21 06:11:39 --> Helper loaded: url_helper
INFO - 2022-03-21 06:11:39 --> Helper loaded: form_helper
INFO - 2022-03-21 06:11:39 --> Helper loaded: common_helper
INFO - 2022-03-21 06:11:39 --> Database Driver Class Initialized
DEBUG - 2022-03-21 06:11:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 06:11:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 06:11:39 --> Controller Class Initialized
INFO - 2022-03-21 06:11:39 --> Form Validation Class Initialized
DEBUG - 2022-03-21 06:11:39 --> Encrypt Class Initialized
DEBUG - 2022-03-21 06:11:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 06:11:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-21 06:11:39 --> Email Class Initialized
INFO - 2022-03-21 06:11:39 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-21 06:11:39 --> Calendar Class Initialized
INFO - 2022-03-21 06:11:39 --> Model "Login_model" initialized
INFO - 2022-03-21 06:11:39 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-03-21 06:11:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 06:11:40 --> Config Class Initialized
INFO - 2022-03-21 06:11:40 --> Hooks Class Initialized
DEBUG - 2022-03-21 06:11:40 --> UTF-8 Support Enabled
INFO - 2022-03-21 06:11:40 --> Utf8 Class Initialized
INFO - 2022-03-21 06:11:40 --> URI Class Initialized
INFO - 2022-03-21 06:11:40 --> Router Class Initialized
INFO - 2022-03-21 06:11:40 --> Output Class Initialized
INFO - 2022-03-21 06:11:40 --> Security Class Initialized
DEBUG - 2022-03-21 06:11:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 06:11:40 --> Input Class Initialized
INFO - 2022-03-21 06:11:40 --> Language Class Initialized
INFO - 2022-03-21 06:11:40 --> Loader Class Initialized
INFO - 2022-03-21 06:11:40 --> Helper loaded: url_helper
INFO - 2022-03-21 06:11:40 --> Helper loaded: form_helper
INFO - 2022-03-21 06:11:40 --> Helper loaded: common_helper
INFO - 2022-03-21 06:11:40 --> Database Driver Class Initialized
DEBUG - 2022-03-21 06:11:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 06:11:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 06:11:40 --> Controller Class Initialized
INFO - 2022-03-21 06:11:40 --> Form Validation Class Initialized
DEBUG - 2022-03-21 06:11:40 --> Encrypt Class Initialized
INFO - 2022-03-21 06:11:40 --> Model "Login_model" initialized
INFO - 2022-03-21 06:11:40 --> Model "Dashboard_model" initialized
INFO - 2022-03-21 06:11:40 --> Model "Case_model" initialized
ERROR - 2022-03-21 06:11:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 06:11:41 --> Config Class Initialized
INFO - 2022-03-21 06:11:41 --> Hooks Class Initialized
DEBUG - 2022-03-21 06:11:41 --> UTF-8 Support Enabled
INFO - 2022-03-21 06:11:41 --> Utf8 Class Initialized
INFO - 2022-03-21 06:11:41 --> URI Class Initialized
INFO - 2022-03-21 06:11:41 --> Router Class Initialized
INFO - 2022-03-21 06:11:41 --> Output Class Initialized
INFO - 2022-03-21 06:11:41 --> Security Class Initialized
DEBUG - 2022-03-21 06:11:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 06:11:41 --> Input Class Initialized
INFO - 2022-03-21 06:11:41 --> Language Class Initialized
INFO - 2022-03-21 06:11:41 --> Loader Class Initialized
INFO - 2022-03-21 06:11:41 --> Helper loaded: url_helper
INFO - 2022-03-21 06:11:41 --> Helper loaded: form_helper
INFO - 2022-03-21 06:11:41 --> Helper loaded: common_helper
INFO - 2022-03-21 06:11:41 --> Database Driver Class Initialized
DEBUG - 2022-03-21 06:11:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 06:11:58 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-21 06:12:15 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2022-03-21 06:12:15 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-21 06:12:15 --> Final output sent to browser
DEBUG - 2022-03-21 06:12:15 --> Total execution time: 34.4314
INFO - 2022-03-21 06:12:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 06:12:15 --> Controller Class Initialized
INFO - 2022-03-21 06:12:15 --> Form Validation Class Initialized
DEBUG - 2022-03-21 06:12:15 --> Encrypt Class Initialized
DEBUG - 2022-03-21 06:12:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 06:12:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-21 06:12:15 --> Email Class Initialized
INFO - 2022-03-21 06:12:15 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-21 06:12:15 --> Calendar Class Initialized
INFO - 2022-03-21 06:12:15 --> Model "Login_model" initialized
INFO - 2022-03-21 06:12:15 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-03-21 06:12:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 06:12:16 --> Config Class Initialized
INFO - 2022-03-21 06:12:16 --> Hooks Class Initialized
DEBUG - 2022-03-21 06:12:16 --> UTF-8 Support Enabled
INFO - 2022-03-21 06:12:16 --> Utf8 Class Initialized
INFO - 2022-03-21 06:12:16 --> URI Class Initialized
INFO - 2022-03-21 06:12:16 --> Router Class Initialized
INFO - 2022-03-21 06:12:16 --> Output Class Initialized
INFO - 2022-03-21 06:12:16 --> Security Class Initialized
DEBUG - 2022-03-21 06:12:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 06:12:16 --> Input Class Initialized
INFO - 2022-03-21 06:12:16 --> Language Class Initialized
INFO - 2022-03-21 06:12:16 --> Loader Class Initialized
INFO - 2022-03-21 06:12:16 --> Helper loaded: url_helper
INFO - 2022-03-21 06:12:16 --> Helper loaded: form_helper
INFO - 2022-03-21 06:12:16 --> Helper loaded: common_helper
INFO - 2022-03-21 06:12:16 --> Database Driver Class Initialized
DEBUG - 2022-03-21 06:12:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 06:12:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 06:12:16 --> Controller Class Initialized
INFO - 2022-03-21 06:12:16 --> Form Validation Class Initialized
DEBUG - 2022-03-21 06:12:16 --> Encrypt Class Initialized
INFO - 2022-03-21 06:12:16 --> Model "Login_model" initialized
INFO - 2022-03-21 06:12:16 --> Model "Dashboard_model" initialized
INFO - 2022-03-21 06:12:16 --> Model "Case_model" initialized
INFO - 2022-03-21 06:12:36 --> File loaded: /home3/karoteam/public_html/application/views/header.php
ERROR - 2022-03-21 06:12:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 06:12:47 --> Config Class Initialized
INFO - 2022-03-21 06:12:47 --> Hooks Class Initialized
DEBUG - 2022-03-21 06:12:47 --> UTF-8 Support Enabled
INFO - 2022-03-21 06:12:47 --> Utf8 Class Initialized
INFO - 2022-03-21 06:12:47 --> URI Class Initialized
INFO - 2022-03-21 06:12:47 --> Router Class Initialized
INFO - 2022-03-21 06:12:47 --> Output Class Initialized
INFO - 2022-03-21 06:12:47 --> Security Class Initialized
DEBUG - 2022-03-21 06:12:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 06:12:47 --> Input Class Initialized
INFO - 2022-03-21 06:12:47 --> Language Class Initialized
INFO - 2022-03-21 06:12:47 --> Loader Class Initialized
INFO - 2022-03-21 06:12:47 --> Helper loaded: url_helper
INFO - 2022-03-21 06:12:47 --> Helper loaded: form_helper
INFO - 2022-03-21 06:12:47 --> Helper loaded: common_helper
INFO - 2022-03-21 06:12:47 --> Database Driver Class Initialized
DEBUG - 2022-03-21 06:12:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 06:12:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 06:12:47 --> Controller Class Initialized
ERROR - 2022-03-21 06:12:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 06:12:49 --> Config Class Initialized
INFO - 2022-03-21 06:12:49 --> Hooks Class Initialized
DEBUG - 2022-03-21 06:12:49 --> UTF-8 Support Enabled
INFO - 2022-03-21 06:12:49 --> Utf8 Class Initialized
INFO - 2022-03-21 06:12:49 --> URI Class Initialized
INFO - 2022-03-21 06:12:49 --> Router Class Initialized
INFO - 2022-03-21 06:12:49 --> Output Class Initialized
INFO - 2022-03-21 06:12:49 --> Security Class Initialized
DEBUG - 2022-03-21 06:12:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 06:12:49 --> Input Class Initialized
INFO - 2022-03-21 06:12:49 --> Language Class Initialized
INFO - 2022-03-21 06:12:49 --> Loader Class Initialized
INFO - 2022-03-21 06:12:49 --> Helper loaded: url_helper
INFO - 2022-03-21 06:12:49 --> Helper loaded: form_helper
INFO - 2022-03-21 06:12:49 --> Helper loaded: common_helper
INFO - 2022-03-21 06:12:49 --> Database Driver Class Initialized
DEBUG - 2022-03-21 06:12:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 06:12:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 06:12:49 --> Controller Class Initialized
INFO - 2022-03-21 06:12:49 --> Form Validation Class Initialized
DEBUG - 2022-03-21 06:12:49 --> Encrypt Class Initialized
DEBUG - 2022-03-21 06:12:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 06:12:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-21 06:12:49 --> Email Class Initialized
INFO - 2022-03-21 06:12:49 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-21 06:12:49 --> Calendar Class Initialized
INFO - 2022-03-21 06:12:49 --> Model "Login_model" initialized
INFO - 2022-03-21 06:12:49 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-21 06:12:49 --> Final output sent to browser
DEBUG - 2022-03-21 06:12:49 --> Total execution time: 0.1100
ERROR - 2022-03-21 06:12:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 06:12:54 --> Config Class Initialized
INFO - 2022-03-21 06:12:54 --> Hooks Class Initialized
DEBUG - 2022-03-21 06:12:54 --> UTF-8 Support Enabled
INFO - 2022-03-21 06:12:54 --> Utf8 Class Initialized
INFO - 2022-03-21 06:12:54 --> URI Class Initialized
INFO - 2022-03-21 06:12:54 --> Router Class Initialized
INFO - 2022-03-21 06:12:54 --> Output Class Initialized
INFO - 2022-03-21 06:12:54 --> Security Class Initialized
DEBUG - 2022-03-21 06:12:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 06:12:54 --> Input Class Initialized
INFO - 2022-03-21 06:12:54 --> Language Class Initialized
INFO - 2022-03-21 06:12:54 --> Loader Class Initialized
INFO - 2022-03-21 06:12:54 --> Helper loaded: url_helper
INFO - 2022-03-21 06:12:54 --> Helper loaded: form_helper
INFO - 2022-03-21 06:12:54 --> Helper loaded: common_helper
INFO - 2022-03-21 06:12:54 --> Database Driver Class Initialized
DEBUG - 2022-03-21 06:12:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 06:12:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 06:12:54 --> Controller Class Initialized
INFO - 2022-03-21 06:12:54 --> Form Validation Class Initialized
DEBUG - 2022-03-21 06:12:54 --> Encrypt Class Initialized
DEBUG - 2022-03-21 06:12:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 06:12:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-21 06:12:54 --> Email Class Initialized
INFO - 2022-03-21 06:12:54 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-21 06:12:54 --> Calendar Class Initialized
INFO - 2022-03-21 06:12:54 --> Model "Login_model" initialized
INFO - 2022-03-21 06:12:54 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-03-21 06:12:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 06:12:56 --> Config Class Initialized
INFO - 2022-03-21 06:12:56 --> Hooks Class Initialized
DEBUG - 2022-03-21 06:12:56 --> UTF-8 Support Enabled
INFO - 2022-03-21 06:12:56 --> Utf8 Class Initialized
INFO - 2022-03-21 06:12:56 --> URI Class Initialized
INFO - 2022-03-21 06:12:56 --> Router Class Initialized
INFO - 2022-03-21 06:12:56 --> Output Class Initialized
INFO - 2022-03-21 06:12:56 --> Security Class Initialized
DEBUG - 2022-03-21 06:12:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 06:12:56 --> Input Class Initialized
INFO - 2022-03-21 06:12:56 --> Language Class Initialized
INFO - 2022-03-21 06:12:56 --> Loader Class Initialized
INFO - 2022-03-21 06:12:56 --> Helper loaded: url_helper
INFO - 2022-03-21 06:12:56 --> Helper loaded: form_helper
INFO - 2022-03-21 06:12:56 --> Helper loaded: common_helper
INFO - 2022-03-21 06:12:56 --> Database Driver Class Initialized
DEBUG - 2022-03-21 06:12:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 06:12:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 06:12:56 --> Controller Class Initialized
INFO - 2022-03-21 06:12:56 --> Form Validation Class Initialized
DEBUG - 2022-03-21 06:12:56 --> Encrypt Class Initialized
INFO - 2022-03-21 06:12:56 --> Model "Login_model" initialized
INFO - 2022-03-21 06:12:56 --> Model "Dashboard_model" initialized
INFO - 2022-03-21 06:12:56 --> Model "Case_model" initialized
INFO - 2022-03-21 06:12:56 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2022-03-21 06:12:56 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-21 06:12:56 --> Final output sent to browser
DEBUG - 2022-03-21 06:12:56 --> Total execution time: 40.5439
ERROR - 2022-03-21 06:12:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 06:12:58 --> Config Class Initialized
INFO - 2022-03-21 06:12:58 --> Hooks Class Initialized
DEBUG - 2022-03-21 06:12:58 --> UTF-8 Support Enabled
INFO - 2022-03-21 06:12:58 --> Utf8 Class Initialized
INFO - 2022-03-21 06:12:58 --> URI Class Initialized
INFO - 2022-03-21 06:12:58 --> Router Class Initialized
INFO - 2022-03-21 06:12:58 --> Output Class Initialized
INFO - 2022-03-21 06:12:58 --> Security Class Initialized
DEBUG - 2022-03-21 06:12:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 06:12:58 --> Input Class Initialized
INFO - 2022-03-21 06:12:58 --> Language Class Initialized
ERROR - 2022-03-21 06:12:58 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-21 06:13:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 06:13:05 --> Config Class Initialized
INFO - 2022-03-21 06:13:05 --> Hooks Class Initialized
DEBUG - 2022-03-21 06:13:05 --> UTF-8 Support Enabled
INFO - 2022-03-21 06:13:05 --> Utf8 Class Initialized
INFO - 2022-03-21 06:13:05 --> URI Class Initialized
INFO - 2022-03-21 06:13:05 --> Router Class Initialized
INFO - 2022-03-21 06:13:05 --> Output Class Initialized
INFO - 2022-03-21 06:13:05 --> Security Class Initialized
DEBUG - 2022-03-21 06:13:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 06:13:05 --> Input Class Initialized
INFO - 2022-03-21 06:13:05 --> Language Class Initialized
INFO - 2022-03-21 06:13:05 --> Loader Class Initialized
INFO - 2022-03-21 06:13:05 --> Helper loaded: url_helper
INFO - 2022-03-21 06:13:05 --> Helper loaded: form_helper
INFO - 2022-03-21 06:13:05 --> Helper loaded: common_helper
INFO - 2022-03-21 06:13:05 --> Database Driver Class Initialized
DEBUG - 2022-03-21 06:13:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 06:13:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 06:13:05 --> Controller Class Initialized
INFO - 2022-03-21 06:13:05 --> Form Validation Class Initialized
DEBUG - 2022-03-21 06:13:05 --> Encrypt Class Initialized
INFO - 2022-03-21 06:13:05 --> Model "Patient_model" initialized
INFO - 2022-03-21 06:13:05 --> Model "Patientcase_model" initialized
INFO - 2022-03-21 06:13:05 --> Model "Referredby_model" initialized
INFO - 2022-03-21 06:13:05 --> Model "Prefix_master" initialized
INFO - 2022-03-21 06:13:05 --> Model "Hospital_model" initialized
INFO - 2022-03-21 06:13:05 --> File loaded: /home3/karoteam/public_html/application/views/header.php
ERROR - 2022-03-21 06:13:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 06:13:10 --> Config Class Initialized
INFO - 2022-03-21 06:13:10 --> Hooks Class Initialized
DEBUG - 2022-03-21 06:13:10 --> UTF-8 Support Enabled
INFO - 2022-03-21 06:13:10 --> Utf8 Class Initialized
INFO - 2022-03-21 06:13:10 --> URI Class Initialized
INFO - 2022-03-21 06:13:10 --> Router Class Initialized
INFO - 2022-03-21 06:13:10 --> Output Class Initialized
INFO - 2022-03-21 06:13:10 --> Security Class Initialized
DEBUG - 2022-03-21 06:13:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 06:13:10 --> Input Class Initialized
INFO - 2022-03-21 06:13:10 --> Language Class Initialized
INFO - 2022-03-21 06:13:10 --> Loader Class Initialized
INFO - 2022-03-21 06:13:10 --> Helper loaded: url_helper
INFO - 2022-03-21 06:13:10 --> Helper loaded: form_helper
INFO - 2022-03-21 06:13:10 --> Helper loaded: common_helper
INFO - 2022-03-21 06:13:10 --> Database Driver Class Initialized
DEBUG - 2022-03-21 06:13:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-03-21 06:13:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 06:13:15 --> Config Class Initialized
INFO - 2022-03-21 06:13:15 --> Hooks Class Initialized
DEBUG - 2022-03-21 06:13:15 --> UTF-8 Support Enabled
INFO - 2022-03-21 06:13:15 --> Utf8 Class Initialized
INFO - 2022-03-21 06:13:15 --> URI Class Initialized
INFO - 2022-03-21 06:13:15 --> Router Class Initialized
INFO - 2022-03-21 06:13:15 --> Output Class Initialized
INFO - 2022-03-21 06:13:15 --> Security Class Initialized
DEBUG - 2022-03-21 06:13:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 06:13:15 --> Input Class Initialized
INFO - 2022-03-21 06:13:15 --> Language Class Initialized
INFO - 2022-03-21 06:13:15 --> Loader Class Initialized
INFO - 2022-03-21 06:13:15 --> Helper loaded: url_helper
INFO - 2022-03-21 06:13:15 --> Helper loaded: form_helper
INFO - 2022-03-21 06:13:15 --> Helper loaded: common_helper
INFO - 2022-03-21 06:13:15 --> Database Driver Class Initialized
DEBUG - 2022-03-21 06:13:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 06:13:17 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-21 06:13:19 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-21 06:13:19 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-21 06:13:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 06:13:19 --> Controller Class Initialized
INFO - 2022-03-21 06:13:19 --> Form Validation Class Initialized
DEBUG - 2022-03-21 06:13:19 --> Encrypt Class Initialized
INFO - 2022-03-21 06:13:19 --> Model "Patient_model" initialized
INFO - 2022-03-21 06:13:19 --> Model "Patientcase_model" initialized
INFO - 2022-03-21 06:13:19 --> Model "Referredby_model" initialized
INFO - 2022-03-21 06:13:19 --> Model "Prefix_master" initialized
INFO - 2022-03-21 06:13:19 --> Model "Hospital_model" initialized
INFO - 2022-03-21 06:13:19 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-21 06:13:31 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-21 06:13:31 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
ERROR - 2022-03-21 06:13:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 06:13:32 --> Config Class Initialized
INFO - 2022-03-21 06:13:32 --> Hooks Class Initialized
DEBUG - 2022-03-21 06:13:32 --> UTF-8 Support Enabled
INFO - 2022-03-21 06:13:32 --> Utf8 Class Initialized
INFO - 2022-03-21 06:13:32 --> URI Class Initialized
INFO - 2022-03-21 06:13:32 --> Router Class Initialized
INFO - 2022-03-21 06:13:32 --> Output Class Initialized
INFO - 2022-03-21 06:13:32 --> Security Class Initialized
DEBUG - 2022-03-21 06:13:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 06:13:32 --> Input Class Initialized
INFO - 2022-03-21 06:13:32 --> Language Class Initialized
ERROR - 2022-03-21 06:13:32 --> 404 Page Not Found: Karoclient/usersprofile
INFO - 2022-03-21 06:13:33 --> Final output sent to browser
DEBUG - 2022-03-21 06:13:33 --> Total execution time: 20.6074
INFO - 2022-03-21 06:13:35 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2022-03-21 06:13:35 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-21 06:13:35 --> Final output sent to browser
DEBUG - 2022-03-21 06:13:35 --> Total execution time: 39.1586
INFO - 2022-03-21 06:13:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 06:13:35 --> Controller Class Initialized
INFO - 2022-03-21 06:13:35 --> Form Validation Class Initialized
DEBUG - 2022-03-21 06:13:35 --> Encrypt Class Initialized
DEBUG - 2022-03-21 06:13:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 06:13:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-21 06:13:35 --> Email Class Initialized
INFO - 2022-03-21 06:13:35 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-21 06:13:35 --> Calendar Class Initialized
INFO - 2022-03-21 06:13:35 --> Model "Login_model" initialized
INFO - 2022-03-21 06:13:35 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-03-21 06:13:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 06:13:36 --> Config Class Initialized
INFO - 2022-03-21 06:13:36 --> Hooks Class Initialized
DEBUG - 2022-03-21 06:13:36 --> UTF-8 Support Enabled
INFO - 2022-03-21 06:13:36 --> Utf8 Class Initialized
INFO - 2022-03-21 06:13:36 --> URI Class Initialized
INFO - 2022-03-21 06:13:36 --> Router Class Initialized
INFO - 2022-03-21 06:13:36 --> Output Class Initialized
INFO - 2022-03-21 06:13:36 --> Security Class Initialized
DEBUG - 2022-03-21 06:13:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 06:13:36 --> Input Class Initialized
INFO - 2022-03-21 06:13:36 --> Language Class Initialized
INFO - 2022-03-21 06:13:36 --> Loader Class Initialized
INFO - 2022-03-21 06:13:36 --> Helper loaded: url_helper
INFO - 2022-03-21 06:13:36 --> Helper loaded: form_helper
INFO - 2022-03-21 06:13:36 --> Helper loaded: common_helper
INFO - 2022-03-21 06:13:36 --> Database Driver Class Initialized
DEBUG - 2022-03-21 06:13:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 06:13:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 06:13:36 --> Controller Class Initialized
INFO - 2022-03-21 06:13:36 --> Form Validation Class Initialized
DEBUG - 2022-03-21 06:13:36 --> Encrypt Class Initialized
INFO - 2022-03-21 06:13:36 --> Model "Login_model" initialized
INFO - 2022-03-21 06:13:36 --> Model "Dashboard_model" initialized
INFO - 2022-03-21 06:13:36 --> Model "Case_model" initialized
ERROR - 2022-03-21 06:13:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 06:13:53 --> Config Class Initialized
INFO - 2022-03-21 06:13:53 --> Hooks Class Initialized
DEBUG - 2022-03-21 06:13:53 --> UTF-8 Support Enabled
INFO - 2022-03-21 06:13:53 --> Utf8 Class Initialized
INFO - 2022-03-21 06:13:53 --> URI Class Initialized
INFO - 2022-03-21 06:13:53 --> Router Class Initialized
INFO - 2022-03-21 06:13:53 --> Output Class Initialized
INFO - 2022-03-21 06:13:53 --> Security Class Initialized
DEBUG - 2022-03-21 06:13:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 06:13:53 --> Input Class Initialized
INFO - 2022-03-21 06:13:53 --> Language Class Initialized
INFO - 2022-03-21 06:13:53 --> Loader Class Initialized
INFO - 2022-03-21 06:13:53 --> Helper loaded: url_helper
INFO - 2022-03-21 06:13:53 --> Helper loaded: form_helper
INFO - 2022-03-21 06:13:53 --> Helper loaded: common_helper
INFO - 2022-03-21 06:13:53 --> Database Driver Class Initialized
DEBUG - 2022-03-21 06:13:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 06:13:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 06:13:53 --> Controller Class Initialized
INFO - 2022-03-21 06:13:53 --> Form Validation Class Initialized
DEBUG - 2022-03-21 06:13:53 --> Encrypt Class Initialized
INFO - 2022-03-21 06:13:53 --> Model "Patient_model" initialized
INFO - 2022-03-21 06:13:53 --> Model "Patientcase_model" initialized
INFO - 2022-03-21 06:13:53 --> Model "Prefix_master" initialized
INFO - 2022-03-21 06:13:53 --> Model "Users_model" initialized
INFO - 2022-03-21 06:13:53 --> Model "Hospital_model" initialized
INFO - 2022-03-21 06:13:53 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-21 06:13:53 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-21 06:13:53 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-21 06:13:53 --> Final output sent to browser
DEBUG - 2022-03-21 06:13:53 --> Total execution time: 0.1042
ERROR - 2022-03-21 06:13:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 06:13:54 --> Config Class Initialized
INFO - 2022-03-21 06:13:54 --> Hooks Class Initialized
DEBUG - 2022-03-21 06:13:54 --> UTF-8 Support Enabled
INFO - 2022-03-21 06:13:54 --> Utf8 Class Initialized
INFO - 2022-03-21 06:13:54 --> URI Class Initialized
INFO - 2022-03-21 06:13:54 --> Router Class Initialized
INFO - 2022-03-21 06:13:54 --> Output Class Initialized
INFO - 2022-03-21 06:13:54 --> Security Class Initialized
DEBUG - 2022-03-21 06:13:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 06:13:54 --> Input Class Initialized
INFO - 2022-03-21 06:13:54 --> Language Class Initialized
ERROR - 2022-03-21 06:13:54 --> 404 Page Not Found: Karoclient/usersprofile
INFO - 2022-03-21 06:13:55 --> File loaded: /home3/karoteam/public_html/application/views/header.php
ERROR - 2022-03-21 06:14:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 06:14:07 --> Config Class Initialized
INFO - 2022-03-21 06:14:07 --> Hooks Class Initialized
DEBUG - 2022-03-21 06:14:07 --> UTF-8 Support Enabled
INFO - 2022-03-21 06:14:07 --> Utf8 Class Initialized
INFO - 2022-03-21 06:14:07 --> URI Class Initialized
INFO - 2022-03-21 06:14:07 --> Router Class Initialized
INFO - 2022-03-21 06:14:07 --> Output Class Initialized
INFO - 2022-03-21 06:14:07 --> Security Class Initialized
DEBUG - 2022-03-21 06:14:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 06:14:07 --> Input Class Initialized
INFO - 2022-03-21 06:14:07 --> Language Class Initialized
INFO - 2022-03-21 06:14:07 --> Loader Class Initialized
INFO - 2022-03-21 06:14:07 --> Helper loaded: url_helper
INFO - 2022-03-21 06:14:07 --> Helper loaded: form_helper
INFO - 2022-03-21 06:14:07 --> Helper loaded: common_helper
INFO - 2022-03-21 06:14:07 --> Database Driver Class Initialized
DEBUG - 2022-03-21 06:14:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 06:14:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 06:14:07 --> Controller Class Initialized
INFO - 2022-03-21 06:14:07 --> Form Validation Class Initialized
DEBUG - 2022-03-21 06:14:07 --> Encrypt Class Initialized
INFO - 2022-03-21 06:14:07 --> Model "Patient_model" initialized
INFO - 2022-03-21 06:14:07 --> Model "Patientcase_model" initialized
INFO - 2022-03-21 06:14:07 --> Model "Referredby_model" initialized
INFO - 2022-03-21 06:14:07 --> Model "Prefix_master" initialized
INFO - 2022-03-21 06:14:07 --> Model "Hospital_model" initialized
INFO - 2022-03-21 06:14:07 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-21 06:14:07 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-21 06:14:07 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-21 06:14:07 --> Final output sent to browser
DEBUG - 2022-03-21 06:14:07 --> Total execution time: 0.1298
ERROR - 2022-03-21 06:14:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 06:14:09 --> Config Class Initialized
INFO - 2022-03-21 06:14:09 --> Hooks Class Initialized
DEBUG - 2022-03-21 06:14:09 --> UTF-8 Support Enabled
INFO - 2022-03-21 06:14:09 --> Utf8 Class Initialized
INFO - 2022-03-21 06:14:09 --> URI Class Initialized
INFO - 2022-03-21 06:14:09 --> Router Class Initialized
INFO - 2022-03-21 06:14:09 --> Output Class Initialized
INFO - 2022-03-21 06:14:09 --> Security Class Initialized
DEBUG - 2022-03-21 06:14:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 06:14:09 --> Input Class Initialized
INFO - 2022-03-21 06:14:09 --> Language Class Initialized
ERROR - 2022-03-21 06:14:09 --> 404 Page Not Found: Karoclient/images
ERROR - 2022-03-21 06:14:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 06:14:09 --> Config Class Initialized
INFO - 2022-03-21 06:14:09 --> Hooks Class Initialized
DEBUG - 2022-03-21 06:14:09 --> UTF-8 Support Enabled
INFO - 2022-03-21 06:14:09 --> Utf8 Class Initialized
INFO - 2022-03-21 06:14:09 --> URI Class Initialized
INFO - 2022-03-21 06:14:09 --> Router Class Initialized
INFO - 2022-03-21 06:14:09 --> Output Class Initialized
INFO - 2022-03-21 06:14:09 --> Security Class Initialized
DEBUG - 2022-03-21 06:14:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 06:14:09 --> Input Class Initialized
INFO - 2022-03-21 06:14:09 --> Language Class Initialized
ERROR - 2022-03-21 06:14:09 --> 404 Page Not Found: Karoclient/usersprofile
INFO - 2022-03-21 06:14:13 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2022-03-21 06:14:13 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-21 06:14:13 --> Final output sent to browser
DEBUG - 2022-03-21 06:14:13 --> Total execution time: 36.9073
ERROR - 2022-03-21 06:14:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 06:14:55 --> Config Class Initialized
INFO - 2022-03-21 06:14:55 --> Hooks Class Initialized
DEBUG - 2022-03-21 06:14:55 --> UTF-8 Support Enabled
INFO - 2022-03-21 06:14:55 --> Utf8 Class Initialized
INFO - 2022-03-21 06:14:55 --> URI Class Initialized
DEBUG - 2022-03-21 06:14:55 --> No URI present. Default controller set.
INFO - 2022-03-21 06:14:55 --> Router Class Initialized
INFO - 2022-03-21 06:14:55 --> Output Class Initialized
INFO - 2022-03-21 06:14:55 --> Security Class Initialized
DEBUG - 2022-03-21 06:14:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 06:14:55 --> Input Class Initialized
INFO - 2022-03-21 06:14:55 --> Language Class Initialized
INFO - 2022-03-21 06:14:55 --> Loader Class Initialized
INFO - 2022-03-21 06:14:55 --> Helper loaded: url_helper
INFO - 2022-03-21 06:14:55 --> Helper loaded: form_helper
INFO - 2022-03-21 06:14:55 --> Helper loaded: common_helper
INFO - 2022-03-21 06:14:55 --> Database Driver Class Initialized
DEBUG - 2022-03-21 06:14:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 06:14:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 06:14:55 --> Controller Class Initialized
INFO - 2022-03-21 06:14:55 --> Form Validation Class Initialized
DEBUG - 2022-03-21 06:14:55 --> Encrypt Class Initialized
DEBUG - 2022-03-21 06:14:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 06:14:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-21 06:14:55 --> Email Class Initialized
INFO - 2022-03-21 06:14:55 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-21 06:14:55 --> Calendar Class Initialized
INFO - 2022-03-21 06:14:55 --> Model "Login_model" initialized
ERROR - 2022-03-21 06:14:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 06:14:56 --> Config Class Initialized
INFO - 2022-03-21 06:14:56 --> Hooks Class Initialized
DEBUG - 2022-03-21 06:14:56 --> UTF-8 Support Enabled
INFO - 2022-03-21 06:14:56 --> Utf8 Class Initialized
INFO - 2022-03-21 06:14:56 --> URI Class Initialized
INFO - 2022-03-21 06:14:56 --> Router Class Initialized
INFO - 2022-03-21 06:14:56 --> Output Class Initialized
INFO - 2022-03-21 06:14:56 --> Security Class Initialized
DEBUG - 2022-03-21 06:14:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 06:14:56 --> Input Class Initialized
INFO - 2022-03-21 06:14:56 --> Language Class Initialized
INFO - 2022-03-21 06:14:56 --> Loader Class Initialized
INFO - 2022-03-21 06:14:56 --> Helper loaded: url_helper
INFO - 2022-03-21 06:14:56 --> Helper loaded: form_helper
INFO - 2022-03-21 06:14:56 --> Helper loaded: common_helper
INFO - 2022-03-21 06:14:56 --> Database Driver Class Initialized
DEBUG - 2022-03-21 06:14:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 06:14:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 06:14:56 --> Controller Class Initialized
INFO - 2022-03-21 06:14:56 --> Form Validation Class Initialized
DEBUG - 2022-03-21 06:14:56 --> Encrypt Class Initialized
INFO - 2022-03-21 06:14:56 --> Model "Diseases_model" initialized
INFO - 2022-03-21 06:14:56 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-21 06:14:56 --> File loaded: /home3/karoteam/public_html/application/views/diseases/index.php
INFO - 2022-03-21 06:14:56 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-21 06:14:56 --> Final output sent to browser
DEBUG - 2022-03-21 06:14:56 --> Total execution time: 0.0853
ERROR - 2022-03-21 06:15:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 06:15:07 --> Config Class Initialized
INFO - 2022-03-21 06:15:07 --> Hooks Class Initialized
DEBUG - 2022-03-21 06:15:07 --> UTF-8 Support Enabled
INFO - 2022-03-21 06:15:07 --> Utf8 Class Initialized
INFO - 2022-03-21 06:15:07 --> URI Class Initialized
INFO - 2022-03-21 06:15:07 --> Router Class Initialized
INFO - 2022-03-21 06:15:07 --> Output Class Initialized
INFO - 2022-03-21 06:15:07 --> Security Class Initialized
DEBUG - 2022-03-21 06:15:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 06:15:07 --> Input Class Initialized
INFO - 2022-03-21 06:15:07 --> Language Class Initialized
INFO - 2022-03-21 06:15:07 --> Loader Class Initialized
INFO - 2022-03-21 06:15:07 --> Helper loaded: url_helper
INFO - 2022-03-21 06:15:07 --> Helper loaded: form_helper
INFO - 2022-03-21 06:15:07 --> Helper loaded: common_helper
INFO - 2022-03-21 06:15:07 --> Database Driver Class Initialized
DEBUG - 2022-03-21 06:15:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 06:15:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 06:15:07 --> Controller Class Initialized
INFO - 2022-03-21 06:15:07 --> Form Validation Class Initialized
DEBUG - 2022-03-21 06:15:07 --> Encrypt Class Initialized
INFO - 2022-03-21 06:15:07 --> Model "Patient_model" initialized
INFO - 2022-03-21 06:15:07 --> Model "Patientcase_model" initialized
INFO - 2022-03-21 06:15:07 --> Model "Referredby_model" initialized
INFO - 2022-03-21 06:15:07 --> Model "Prefix_master" initialized
INFO - 2022-03-21 06:15:07 --> Model "Hospital_model" initialized
INFO - 2022-03-21 06:15:07 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-21 06:15:07 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-21 06:15:07 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-21 06:15:07 --> Final output sent to browser
DEBUG - 2022-03-21 06:15:07 --> Total execution time: 0.2345
ERROR - 2022-03-21 06:19:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 06:19:06 --> Config Class Initialized
INFO - 2022-03-21 06:19:06 --> Hooks Class Initialized
DEBUG - 2022-03-21 06:19:06 --> UTF-8 Support Enabled
INFO - 2022-03-21 06:19:06 --> Utf8 Class Initialized
INFO - 2022-03-21 06:19:06 --> URI Class Initialized
INFO - 2022-03-21 06:19:06 --> Router Class Initialized
INFO - 2022-03-21 06:19:06 --> Output Class Initialized
INFO - 2022-03-21 06:19:06 --> Security Class Initialized
DEBUG - 2022-03-21 06:19:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 06:19:06 --> Input Class Initialized
INFO - 2022-03-21 06:19:06 --> Language Class Initialized
INFO - 2022-03-21 06:19:06 --> Loader Class Initialized
INFO - 2022-03-21 06:19:06 --> Helper loaded: url_helper
INFO - 2022-03-21 06:19:06 --> Helper loaded: form_helper
INFO - 2022-03-21 06:19:06 --> Helper loaded: common_helper
INFO - 2022-03-21 06:19:06 --> Database Driver Class Initialized
DEBUG - 2022-03-21 06:19:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 06:19:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 06:19:06 --> Controller Class Initialized
INFO - 2022-03-21 06:19:06 --> Model "Referredby_model" initialized
INFO - 2022-03-21 06:19:06 --> Final output sent to browser
DEBUG - 2022-03-21 06:19:06 --> Total execution time: 0.0312
ERROR - 2022-03-21 06:20:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 06:20:06 --> Config Class Initialized
INFO - 2022-03-21 06:20:06 --> Hooks Class Initialized
DEBUG - 2022-03-21 06:20:06 --> UTF-8 Support Enabled
INFO - 2022-03-21 06:20:06 --> Utf8 Class Initialized
INFO - 2022-03-21 06:20:06 --> URI Class Initialized
INFO - 2022-03-21 06:20:06 --> Router Class Initialized
INFO - 2022-03-21 06:20:06 --> Output Class Initialized
INFO - 2022-03-21 06:20:06 --> Security Class Initialized
DEBUG - 2022-03-21 06:20:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 06:20:06 --> Input Class Initialized
INFO - 2022-03-21 06:20:06 --> Language Class Initialized
INFO - 2022-03-21 06:20:06 --> Loader Class Initialized
INFO - 2022-03-21 06:20:06 --> Helper loaded: url_helper
INFO - 2022-03-21 06:20:06 --> Helper loaded: form_helper
INFO - 2022-03-21 06:20:06 --> Helper loaded: common_helper
INFO - 2022-03-21 06:20:06 --> Database Driver Class Initialized
DEBUG - 2022-03-21 06:20:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 06:20:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 06:20:06 --> Controller Class Initialized
INFO - 2022-03-21 06:20:06 --> Model "Referredby_model" initialized
INFO - 2022-03-21 06:20:06 --> Final output sent to browser
DEBUG - 2022-03-21 06:20:06 --> Total execution time: 0.0266
ERROR - 2022-03-21 06:20:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 06:20:21 --> Config Class Initialized
INFO - 2022-03-21 06:20:21 --> Hooks Class Initialized
DEBUG - 2022-03-21 06:20:21 --> UTF-8 Support Enabled
INFO - 2022-03-21 06:20:21 --> Utf8 Class Initialized
INFO - 2022-03-21 06:20:21 --> URI Class Initialized
INFO - 2022-03-21 06:20:21 --> Router Class Initialized
INFO - 2022-03-21 06:20:21 --> Output Class Initialized
INFO - 2022-03-21 06:20:21 --> Security Class Initialized
DEBUG - 2022-03-21 06:20:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 06:20:21 --> Input Class Initialized
INFO - 2022-03-21 06:20:21 --> Language Class Initialized
INFO - 2022-03-21 06:20:21 --> Loader Class Initialized
INFO - 2022-03-21 06:20:21 --> Helper loaded: url_helper
INFO - 2022-03-21 06:20:21 --> Helper loaded: form_helper
INFO - 2022-03-21 06:20:21 --> Helper loaded: common_helper
INFO - 2022-03-21 06:20:21 --> Database Driver Class Initialized
DEBUG - 2022-03-21 06:20:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 06:20:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 06:20:21 --> Controller Class Initialized
INFO - 2022-03-21 06:20:21 --> Form Validation Class Initialized
DEBUG - 2022-03-21 06:20:21 --> Encrypt Class Initialized
INFO - 2022-03-21 06:20:21 --> Model "Patient_model" initialized
INFO - 2022-03-21 06:20:21 --> Model "Patientcase_model" initialized
INFO - 2022-03-21 06:20:21 --> Model "Referredby_model" initialized
INFO - 2022-03-21 06:20:21 --> Model "Prefix_master" initialized
INFO - 2022-03-21 06:20:21 --> Model "Hospital_model" initialized
INFO - 2022-03-21 06:20:21 --> Final output sent to browser
DEBUG - 2022-03-21 06:20:21 --> Total execution time: 0.0469
ERROR - 2022-03-21 06:20:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 06:20:30 --> Config Class Initialized
INFO - 2022-03-21 06:20:30 --> Hooks Class Initialized
DEBUG - 2022-03-21 06:20:30 --> UTF-8 Support Enabled
INFO - 2022-03-21 06:20:30 --> Utf8 Class Initialized
INFO - 2022-03-21 06:20:30 --> URI Class Initialized
INFO - 2022-03-21 06:20:30 --> Router Class Initialized
INFO - 2022-03-21 06:20:30 --> Output Class Initialized
INFO - 2022-03-21 06:20:30 --> Security Class Initialized
DEBUG - 2022-03-21 06:20:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 06:20:30 --> Input Class Initialized
INFO - 2022-03-21 06:20:30 --> Language Class Initialized
INFO - 2022-03-21 06:20:30 --> Loader Class Initialized
INFO - 2022-03-21 06:20:30 --> Helper loaded: url_helper
INFO - 2022-03-21 06:20:30 --> Helper loaded: form_helper
INFO - 2022-03-21 06:20:30 --> Helper loaded: common_helper
INFO - 2022-03-21 06:20:30 --> Database Driver Class Initialized
DEBUG - 2022-03-21 06:20:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 06:20:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 06:20:30 --> Controller Class Initialized
INFO - 2022-03-21 06:20:30 --> Form Validation Class Initialized
DEBUG - 2022-03-21 06:20:30 --> Encrypt Class Initialized
INFO - 2022-03-21 06:20:30 --> Model "Patient_model" initialized
INFO - 2022-03-21 06:20:30 --> Model "Patientcase_model" initialized
INFO - 2022-03-21 06:20:30 --> Model "Referredby_model" initialized
INFO - 2022-03-21 06:20:30 --> Model "Prefix_master" initialized
INFO - 2022-03-21 06:20:30 --> Model "Hospital_model" initialized
INFO - 2022-03-21 06:20:30 --> Final output sent to browser
DEBUG - 2022-03-21 06:20:30 --> Total execution time: 0.0434
ERROR - 2022-03-21 06:23:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 06:23:27 --> Config Class Initialized
INFO - 2022-03-21 06:23:27 --> Hooks Class Initialized
DEBUG - 2022-03-21 06:23:27 --> UTF-8 Support Enabled
INFO - 2022-03-21 06:23:27 --> Utf8 Class Initialized
INFO - 2022-03-21 06:23:27 --> URI Class Initialized
INFO - 2022-03-21 06:23:27 --> Router Class Initialized
INFO - 2022-03-21 06:23:27 --> Output Class Initialized
INFO - 2022-03-21 06:23:27 --> Security Class Initialized
DEBUG - 2022-03-21 06:23:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 06:23:27 --> Input Class Initialized
INFO - 2022-03-21 06:23:27 --> Language Class Initialized
INFO - 2022-03-21 06:23:27 --> Loader Class Initialized
INFO - 2022-03-21 06:23:27 --> Helper loaded: url_helper
INFO - 2022-03-21 06:23:27 --> Helper loaded: form_helper
INFO - 2022-03-21 06:23:27 --> Helper loaded: common_helper
INFO - 2022-03-21 06:23:27 --> Database Driver Class Initialized
DEBUG - 2022-03-21 06:23:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 06:23:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 06:23:27 --> Controller Class Initialized
INFO - 2022-03-21 06:23:27 --> Form Validation Class Initialized
DEBUG - 2022-03-21 06:23:27 --> Encrypt Class Initialized
INFO - 2022-03-21 06:23:27 --> Model "Patient_model" initialized
INFO - 2022-03-21 06:23:27 --> Model "Patientcase_model" initialized
INFO - 2022-03-21 06:23:27 --> Model "Referredby_model" initialized
INFO - 2022-03-21 06:23:27 --> Model "Prefix_master" initialized
INFO - 2022-03-21 06:23:27 --> Model "Hospital_model" initialized
INFO - 2022-03-21 06:23:27 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-21 06:23:27 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-21 06:23:27 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-21 06:23:27 --> Final output sent to browser
DEBUG - 2022-03-21 06:23:27 --> Total execution time: 0.0732
ERROR - 2022-03-21 06:25:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 06:25:25 --> Config Class Initialized
INFO - 2022-03-21 06:25:25 --> Hooks Class Initialized
DEBUG - 2022-03-21 06:25:25 --> UTF-8 Support Enabled
INFO - 2022-03-21 06:25:25 --> Utf8 Class Initialized
INFO - 2022-03-21 06:25:25 --> URI Class Initialized
INFO - 2022-03-21 06:25:25 --> Router Class Initialized
INFO - 2022-03-21 06:25:25 --> Output Class Initialized
INFO - 2022-03-21 06:25:25 --> Security Class Initialized
DEBUG - 2022-03-21 06:25:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 06:25:25 --> Input Class Initialized
INFO - 2022-03-21 06:25:25 --> Language Class Initialized
INFO - 2022-03-21 06:25:25 --> Loader Class Initialized
INFO - 2022-03-21 06:25:25 --> Helper loaded: url_helper
INFO - 2022-03-21 06:25:25 --> Helper loaded: form_helper
INFO - 2022-03-21 06:25:25 --> Helper loaded: common_helper
INFO - 2022-03-21 06:25:25 --> Database Driver Class Initialized
DEBUG - 2022-03-21 06:25:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 06:25:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 06:25:25 --> Controller Class Initialized
INFO - 2022-03-21 06:25:25 --> Form Validation Class Initialized
DEBUG - 2022-03-21 06:25:25 --> Encrypt Class Initialized
INFO - 2022-03-21 06:25:25 --> Model "Patient_model" initialized
INFO - 2022-03-21 06:25:25 --> Model "Patientcase_model" initialized
INFO - 2022-03-21 06:25:25 --> Model "Referredby_model" initialized
INFO - 2022-03-21 06:25:25 --> Model "Prefix_master" initialized
INFO - 2022-03-21 06:25:25 --> Model "Hospital_model" initialized
ERROR - 2022-03-21 06:25:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 06:25:26 --> Config Class Initialized
INFO - 2022-03-21 06:25:26 --> Hooks Class Initialized
DEBUG - 2022-03-21 06:25:26 --> UTF-8 Support Enabled
INFO - 2022-03-21 06:25:26 --> Utf8 Class Initialized
INFO - 2022-03-21 06:25:26 --> URI Class Initialized
INFO - 2022-03-21 06:25:26 --> Router Class Initialized
INFO - 2022-03-21 06:25:26 --> Output Class Initialized
INFO - 2022-03-21 06:25:26 --> Security Class Initialized
DEBUG - 2022-03-21 06:25:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 06:25:26 --> Input Class Initialized
INFO - 2022-03-21 06:25:26 --> Language Class Initialized
INFO - 2022-03-21 06:25:26 --> Loader Class Initialized
INFO - 2022-03-21 06:25:26 --> Helper loaded: url_helper
INFO - 2022-03-21 06:25:26 --> Helper loaded: form_helper
INFO - 2022-03-21 06:25:26 --> Helper loaded: common_helper
INFO - 2022-03-21 06:25:26 --> Database Driver Class Initialized
DEBUG - 2022-03-21 06:25:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 06:25:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 06:25:26 --> Controller Class Initialized
INFO - 2022-03-21 06:25:26 --> Form Validation Class Initialized
DEBUG - 2022-03-21 06:25:26 --> Encrypt Class Initialized
INFO - 2022-03-21 06:25:26 --> Model "Patient_model" initialized
INFO - 2022-03-21 06:25:26 --> Model "Patientcase_model" initialized
INFO - 2022-03-21 06:25:26 --> Model "Referredby_model" initialized
INFO - 2022-03-21 06:25:26 --> Model "Prefix_master" initialized
INFO - 2022-03-21 06:25:26 --> Model "Hospital_model" initialized
INFO - 2022-03-21 06:25:26 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-21 06:25:26 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-21 06:25:26 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-21 06:25:26 --> Final output sent to browser
DEBUG - 2022-03-21 06:25:26 --> Total execution time: 0.0752
ERROR - 2022-03-21 06:25:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 06:25:27 --> Config Class Initialized
INFO - 2022-03-21 06:25:27 --> Hooks Class Initialized
DEBUG - 2022-03-21 06:25:27 --> UTF-8 Support Enabled
INFO - 2022-03-21 06:25:27 --> Utf8 Class Initialized
INFO - 2022-03-21 06:25:27 --> URI Class Initialized
INFO - 2022-03-21 06:25:27 --> Router Class Initialized
INFO - 2022-03-21 06:25:27 --> Output Class Initialized
INFO - 2022-03-21 06:25:27 --> Security Class Initialized
DEBUG - 2022-03-21 06:25:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 06:25:27 --> Input Class Initialized
INFO - 2022-03-21 06:25:27 --> Language Class Initialized
INFO - 2022-03-21 06:25:27 --> Loader Class Initialized
INFO - 2022-03-21 06:25:27 --> Helper loaded: url_helper
INFO - 2022-03-21 06:25:27 --> Helper loaded: form_helper
INFO - 2022-03-21 06:25:27 --> Helper loaded: common_helper
INFO - 2022-03-21 06:25:27 --> Database Driver Class Initialized
DEBUG - 2022-03-21 06:25:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 06:25:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 06:25:27 --> Controller Class Initialized
INFO - 2022-03-21 06:25:27 --> Form Validation Class Initialized
DEBUG - 2022-03-21 06:25:27 --> Encrypt Class Initialized
INFO - 2022-03-21 06:25:27 --> Model "Patient_model" initialized
INFO - 2022-03-21 06:25:27 --> Model "Patientcase_model" initialized
INFO - 2022-03-21 06:25:27 --> Model "Prefix_master" initialized
INFO - 2022-03-21 06:25:27 --> Model "Users_model" initialized
INFO - 2022-03-21 06:25:27 --> Model "Hospital_model" initialized
INFO - 2022-03-21 06:25:27 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-21 06:25:27 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-21 06:25:27 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-21 06:25:27 --> Final output sent to browser
DEBUG - 2022-03-21 06:25:27 --> Total execution time: 0.0786
ERROR - 2022-03-21 06:28:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 06:28:39 --> Config Class Initialized
INFO - 2022-03-21 06:28:39 --> Hooks Class Initialized
DEBUG - 2022-03-21 06:28:39 --> UTF-8 Support Enabled
INFO - 2022-03-21 06:28:39 --> Utf8 Class Initialized
INFO - 2022-03-21 06:28:39 --> URI Class Initialized
INFO - 2022-03-21 06:28:39 --> Router Class Initialized
INFO - 2022-03-21 06:28:39 --> Output Class Initialized
INFO - 2022-03-21 06:28:39 --> Security Class Initialized
DEBUG - 2022-03-21 06:28:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 06:28:39 --> Input Class Initialized
INFO - 2022-03-21 06:28:39 --> Language Class Initialized
INFO - 2022-03-21 06:28:39 --> Loader Class Initialized
INFO - 2022-03-21 06:28:39 --> Helper loaded: url_helper
INFO - 2022-03-21 06:28:39 --> Helper loaded: form_helper
INFO - 2022-03-21 06:28:39 --> Helper loaded: common_helper
INFO - 2022-03-21 06:28:39 --> Database Driver Class Initialized
DEBUG - 2022-03-21 06:28:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 06:28:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 06:28:39 --> Controller Class Initialized
INFO - 2022-03-21 06:28:39 --> Model "Referredby_model" initialized
INFO - 2022-03-21 06:28:39 --> Final output sent to browser
DEBUG - 2022-03-21 06:28:39 --> Total execution time: 0.0305
ERROR - 2022-03-21 06:30:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 06:30:14 --> Config Class Initialized
INFO - 2022-03-21 06:30:14 --> Hooks Class Initialized
DEBUG - 2022-03-21 06:30:14 --> UTF-8 Support Enabled
INFO - 2022-03-21 06:30:14 --> Utf8 Class Initialized
INFO - 2022-03-21 06:30:14 --> URI Class Initialized
INFO - 2022-03-21 06:30:14 --> Router Class Initialized
INFO - 2022-03-21 06:30:14 --> Output Class Initialized
INFO - 2022-03-21 06:30:14 --> Security Class Initialized
DEBUG - 2022-03-21 06:30:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 06:30:14 --> Input Class Initialized
INFO - 2022-03-21 06:30:14 --> Language Class Initialized
INFO - 2022-03-21 06:30:14 --> Loader Class Initialized
INFO - 2022-03-21 06:30:14 --> Helper loaded: url_helper
INFO - 2022-03-21 06:30:14 --> Helper loaded: form_helper
INFO - 2022-03-21 06:30:14 --> Helper loaded: common_helper
INFO - 2022-03-21 06:30:14 --> Database Driver Class Initialized
DEBUG - 2022-03-21 06:30:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 06:30:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 06:30:14 --> Controller Class Initialized
INFO - 2022-03-21 06:30:14 --> Form Validation Class Initialized
DEBUG - 2022-03-21 06:30:14 --> Encrypt Class Initialized
INFO - 2022-03-21 06:30:14 --> Model "Patient_model" initialized
INFO - 2022-03-21 06:30:14 --> Model "Patientcase_model" initialized
INFO - 2022-03-21 06:30:14 --> Model "Prefix_master" initialized
INFO - 2022-03-21 06:30:14 --> Model "Users_model" initialized
INFO - 2022-03-21 06:30:14 --> Model "Hospital_model" initialized
ERROR - 2022-03-21 06:30:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 06:30:15 --> Config Class Initialized
INFO - 2022-03-21 06:30:15 --> Hooks Class Initialized
DEBUG - 2022-03-21 06:30:15 --> UTF-8 Support Enabled
INFO - 2022-03-21 06:30:15 --> Utf8 Class Initialized
INFO - 2022-03-21 06:30:15 --> URI Class Initialized
INFO - 2022-03-21 06:30:15 --> Router Class Initialized
INFO - 2022-03-21 06:30:15 --> Output Class Initialized
INFO - 2022-03-21 06:30:15 --> Security Class Initialized
DEBUG - 2022-03-21 06:30:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 06:30:15 --> Input Class Initialized
INFO - 2022-03-21 06:30:15 --> Language Class Initialized
INFO - 2022-03-21 06:30:15 --> Loader Class Initialized
INFO - 2022-03-21 06:30:15 --> Helper loaded: url_helper
INFO - 2022-03-21 06:30:15 --> Helper loaded: form_helper
INFO - 2022-03-21 06:30:15 --> Helper loaded: common_helper
INFO - 2022-03-21 06:30:15 --> Database Driver Class Initialized
DEBUG - 2022-03-21 06:30:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 06:30:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 06:30:15 --> Controller Class Initialized
INFO - 2022-03-21 06:30:15 --> Form Validation Class Initialized
DEBUG - 2022-03-21 06:30:15 --> Encrypt Class Initialized
INFO - 2022-03-21 06:30:15 --> Model "Patient_model" initialized
INFO - 2022-03-21 06:30:15 --> Model "Patientcase_model" initialized
INFO - 2022-03-21 06:30:15 --> Model "Prefix_master" initialized
INFO - 2022-03-21 06:30:15 --> Model "Users_model" initialized
INFO - 2022-03-21 06:30:15 --> Model "Hospital_model" initialized
INFO - 2022-03-21 06:30:15 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-21 06:30:15 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-21 06:30:15 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-21 06:30:15 --> Final output sent to browser
DEBUG - 2022-03-21 06:30:15 --> Total execution time: 0.0628
ERROR - 2022-03-21 06:30:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 06:30:20 --> Config Class Initialized
INFO - 2022-03-21 06:30:20 --> Hooks Class Initialized
DEBUG - 2022-03-21 06:30:20 --> UTF-8 Support Enabled
INFO - 2022-03-21 06:30:20 --> Utf8 Class Initialized
INFO - 2022-03-21 06:30:20 --> URI Class Initialized
INFO - 2022-03-21 06:30:20 --> Router Class Initialized
INFO - 2022-03-21 06:30:20 --> Output Class Initialized
INFO - 2022-03-21 06:30:20 --> Security Class Initialized
DEBUG - 2022-03-21 06:30:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 06:30:20 --> Input Class Initialized
INFO - 2022-03-21 06:30:20 --> Language Class Initialized
INFO - 2022-03-21 06:30:20 --> Loader Class Initialized
INFO - 2022-03-21 06:30:20 --> Helper loaded: url_helper
INFO - 2022-03-21 06:30:20 --> Helper loaded: form_helper
INFO - 2022-03-21 06:30:20 --> Helper loaded: common_helper
INFO - 2022-03-21 06:30:20 --> Database Driver Class Initialized
DEBUG - 2022-03-21 06:30:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 06:30:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 06:30:20 --> Controller Class Initialized
INFO - 2022-03-21 06:30:20 --> Form Validation Class Initialized
DEBUG - 2022-03-21 06:30:20 --> Encrypt Class Initialized
INFO - 2022-03-21 06:30:20 --> Model "Patient_model" initialized
INFO - 2022-03-21 06:30:20 --> Model "Patientcase_model" initialized
INFO - 2022-03-21 06:30:20 --> Model "Referredby_model" initialized
INFO - 2022-03-21 06:30:20 --> Model "Prefix_master" initialized
INFO - 2022-03-21 06:30:20 --> Model "Hospital_model" initialized
INFO - 2022-03-21 06:30:20 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-21 06:30:20 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-21 06:30:20 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-21 06:30:20 --> Final output sent to browser
DEBUG - 2022-03-21 06:30:20 --> Total execution time: 0.0826
ERROR - 2022-03-21 06:32:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 06:32:52 --> Config Class Initialized
INFO - 2022-03-21 06:32:52 --> Hooks Class Initialized
DEBUG - 2022-03-21 06:32:52 --> UTF-8 Support Enabled
INFO - 2022-03-21 06:32:52 --> Utf8 Class Initialized
INFO - 2022-03-21 06:32:52 --> URI Class Initialized
INFO - 2022-03-21 06:32:52 --> Router Class Initialized
INFO - 2022-03-21 06:32:52 --> Output Class Initialized
INFO - 2022-03-21 06:32:52 --> Security Class Initialized
DEBUG - 2022-03-21 06:32:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 06:32:52 --> Input Class Initialized
INFO - 2022-03-21 06:32:52 --> Language Class Initialized
INFO - 2022-03-21 06:32:52 --> Loader Class Initialized
INFO - 2022-03-21 06:32:52 --> Helper loaded: url_helper
INFO - 2022-03-21 06:32:52 --> Helper loaded: form_helper
INFO - 2022-03-21 06:32:52 --> Helper loaded: common_helper
INFO - 2022-03-21 06:32:52 --> Database Driver Class Initialized
DEBUG - 2022-03-21 06:32:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 06:32:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 06:32:52 --> Controller Class Initialized
INFO - 2022-03-21 06:32:52 --> Model "Referredby_model" initialized
INFO - 2022-03-21 06:32:52 --> Final output sent to browser
DEBUG - 2022-03-21 06:32:52 --> Total execution time: 0.0311
ERROR - 2022-03-21 06:32:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 06:32:56 --> Config Class Initialized
INFO - 2022-03-21 06:32:56 --> Hooks Class Initialized
DEBUG - 2022-03-21 06:32:56 --> UTF-8 Support Enabled
INFO - 2022-03-21 06:32:56 --> Utf8 Class Initialized
INFO - 2022-03-21 06:32:56 --> URI Class Initialized
INFO - 2022-03-21 06:32:56 --> Router Class Initialized
INFO - 2022-03-21 06:32:56 --> Output Class Initialized
INFO - 2022-03-21 06:32:56 --> Security Class Initialized
DEBUG - 2022-03-21 06:32:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 06:32:56 --> Input Class Initialized
INFO - 2022-03-21 06:32:56 --> Language Class Initialized
INFO - 2022-03-21 06:32:56 --> Loader Class Initialized
INFO - 2022-03-21 06:32:56 --> Helper loaded: url_helper
INFO - 2022-03-21 06:32:56 --> Helper loaded: form_helper
INFO - 2022-03-21 06:32:56 --> Helper loaded: common_helper
INFO - 2022-03-21 06:32:56 --> Database Driver Class Initialized
DEBUG - 2022-03-21 06:32:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 06:32:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 06:32:56 --> Controller Class Initialized
INFO - 2022-03-21 06:32:56 --> Form Validation Class Initialized
DEBUG - 2022-03-21 06:32:56 --> Encrypt Class Initialized
INFO - 2022-03-21 06:32:56 --> Model "Patient_model" initialized
INFO - 2022-03-21 06:32:56 --> Model "Patientcase_model" initialized
INFO - 2022-03-21 06:32:56 --> Model "Referredby_model" initialized
INFO - 2022-03-21 06:32:56 --> Model "Prefix_master" initialized
INFO - 2022-03-21 06:32:56 --> Model "Hospital_model" initialized
ERROR - 2022-03-21 06:32:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 06:32:56 --> Config Class Initialized
INFO - 2022-03-21 06:32:56 --> Hooks Class Initialized
DEBUG - 2022-03-21 06:32:56 --> UTF-8 Support Enabled
INFO - 2022-03-21 06:32:56 --> Utf8 Class Initialized
INFO - 2022-03-21 06:32:56 --> URI Class Initialized
INFO - 2022-03-21 06:32:56 --> Router Class Initialized
INFO - 2022-03-21 06:32:56 --> Output Class Initialized
INFO - 2022-03-21 06:32:56 --> Security Class Initialized
DEBUG - 2022-03-21 06:32:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 06:32:56 --> Input Class Initialized
INFO - 2022-03-21 06:32:56 --> Language Class Initialized
INFO - 2022-03-21 06:32:56 --> Loader Class Initialized
INFO - 2022-03-21 06:32:56 --> Helper loaded: url_helper
INFO - 2022-03-21 06:32:56 --> Helper loaded: form_helper
INFO - 2022-03-21 06:32:56 --> Helper loaded: common_helper
INFO - 2022-03-21 06:32:56 --> Database Driver Class Initialized
DEBUG - 2022-03-21 06:32:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 06:32:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 06:32:56 --> Controller Class Initialized
INFO - 2022-03-21 06:32:56 --> Form Validation Class Initialized
DEBUG - 2022-03-21 06:32:56 --> Encrypt Class Initialized
INFO - 2022-03-21 06:32:56 --> Model "Patient_model" initialized
INFO - 2022-03-21 06:32:56 --> Model "Patientcase_model" initialized
INFO - 2022-03-21 06:32:56 --> Model "Referredby_model" initialized
INFO - 2022-03-21 06:32:56 --> Model "Prefix_master" initialized
INFO - 2022-03-21 06:32:56 --> Model "Hospital_model" initialized
INFO - 2022-03-21 06:32:56 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-21 06:32:56 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-21 06:32:56 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-21 06:32:56 --> Final output sent to browser
DEBUG - 2022-03-21 06:32:56 --> Total execution time: 0.0746
ERROR - 2022-03-21 06:32:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 06:32:57 --> Config Class Initialized
INFO - 2022-03-21 06:32:57 --> Hooks Class Initialized
DEBUG - 2022-03-21 06:32:57 --> UTF-8 Support Enabled
INFO - 2022-03-21 06:32:57 --> Utf8 Class Initialized
INFO - 2022-03-21 06:32:57 --> URI Class Initialized
INFO - 2022-03-21 06:32:57 --> Router Class Initialized
INFO - 2022-03-21 06:32:57 --> Output Class Initialized
INFO - 2022-03-21 06:32:57 --> Security Class Initialized
DEBUG - 2022-03-21 06:32:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 06:32:57 --> Input Class Initialized
INFO - 2022-03-21 06:32:57 --> Language Class Initialized
INFO - 2022-03-21 06:32:57 --> Loader Class Initialized
INFO - 2022-03-21 06:32:57 --> Helper loaded: url_helper
INFO - 2022-03-21 06:32:57 --> Helper loaded: form_helper
INFO - 2022-03-21 06:32:57 --> Helper loaded: common_helper
INFO - 2022-03-21 06:32:57 --> Database Driver Class Initialized
DEBUG - 2022-03-21 06:32:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 06:32:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 06:32:57 --> Controller Class Initialized
INFO - 2022-03-21 06:32:57 --> Form Validation Class Initialized
DEBUG - 2022-03-21 06:32:57 --> Encrypt Class Initialized
INFO - 2022-03-21 06:32:57 --> Model "Patient_model" initialized
INFO - 2022-03-21 06:32:57 --> Model "Patientcase_model" initialized
INFO - 2022-03-21 06:32:57 --> Model "Prefix_master" initialized
INFO - 2022-03-21 06:32:57 --> Model "Users_model" initialized
INFO - 2022-03-21 06:32:57 --> Model "Hospital_model" initialized
INFO - 2022-03-21 06:32:58 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-21 06:32:58 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-21 06:32:58 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-21 06:32:58 --> Final output sent to browser
DEBUG - 2022-03-21 06:32:58 --> Total execution time: 0.1202
ERROR - 2022-03-21 06:35:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 06:35:21 --> Config Class Initialized
INFO - 2022-03-21 06:35:21 --> Hooks Class Initialized
DEBUG - 2022-03-21 06:35:21 --> UTF-8 Support Enabled
INFO - 2022-03-21 06:35:21 --> Utf8 Class Initialized
INFO - 2022-03-21 06:35:21 --> URI Class Initialized
INFO - 2022-03-21 06:35:21 --> Router Class Initialized
INFO - 2022-03-21 06:35:21 --> Output Class Initialized
INFO - 2022-03-21 06:35:21 --> Security Class Initialized
DEBUG - 2022-03-21 06:35:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 06:35:21 --> Input Class Initialized
INFO - 2022-03-21 06:35:21 --> Language Class Initialized
INFO - 2022-03-21 06:35:21 --> Loader Class Initialized
INFO - 2022-03-21 06:35:21 --> Helper loaded: url_helper
INFO - 2022-03-21 06:35:21 --> Helper loaded: form_helper
INFO - 2022-03-21 06:35:21 --> Helper loaded: common_helper
INFO - 2022-03-21 06:35:21 --> Database Driver Class Initialized
DEBUG - 2022-03-21 06:35:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 06:35:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 06:35:21 --> Controller Class Initialized
INFO - 2022-03-21 06:35:21 --> Form Validation Class Initialized
DEBUG - 2022-03-21 06:35:21 --> Encrypt Class Initialized
INFO - 2022-03-21 06:35:21 --> Model "Patient_model" initialized
INFO - 2022-03-21 06:35:21 --> Model "Patientcase_model" initialized
INFO - 2022-03-21 06:35:21 --> Model "Prefix_master" initialized
INFO - 2022-03-21 06:35:21 --> Model "Users_model" initialized
INFO - 2022-03-21 06:35:21 --> Model "Hospital_model" initialized
ERROR - 2022-03-21 06:35:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 06:35:22 --> Config Class Initialized
INFO - 2022-03-21 06:35:22 --> Hooks Class Initialized
DEBUG - 2022-03-21 06:35:22 --> UTF-8 Support Enabled
INFO - 2022-03-21 06:35:22 --> Utf8 Class Initialized
INFO - 2022-03-21 06:35:22 --> URI Class Initialized
INFO - 2022-03-21 06:35:22 --> Router Class Initialized
INFO - 2022-03-21 06:35:22 --> Output Class Initialized
INFO - 2022-03-21 06:35:22 --> Security Class Initialized
DEBUG - 2022-03-21 06:35:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 06:35:22 --> Input Class Initialized
INFO - 2022-03-21 06:35:22 --> Language Class Initialized
INFO - 2022-03-21 06:35:22 --> Loader Class Initialized
INFO - 2022-03-21 06:35:22 --> Helper loaded: url_helper
INFO - 2022-03-21 06:35:22 --> Helper loaded: form_helper
INFO - 2022-03-21 06:35:22 --> Helper loaded: common_helper
INFO - 2022-03-21 06:35:22 --> Database Driver Class Initialized
DEBUG - 2022-03-21 06:35:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 06:35:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 06:35:22 --> Controller Class Initialized
INFO - 2022-03-21 06:35:22 --> Form Validation Class Initialized
DEBUG - 2022-03-21 06:35:22 --> Encrypt Class Initialized
INFO - 2022-03-21 06:35:22 --> Model "Patient_model" initialized
INFO - 2022-03-21 06:35:22 --> Model "Patientcase_model" initialized
INFO - 2022-03-21 06:35:22 --> Model "Prefix_master" initialized
INFO - 2022-03-21 06:35:22 --> Model "Users_model" initialized
INFO - 2022-03-21 06:35:22 --> Model "Hospital_model" initialized
INFO - 2022-03-21 06:35:22 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-21 06:35:22 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-21 06:35:22 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-21 06:35:22 --> Final output sent to browser
DEBUG - 2022-03-21 06:35:22 --> Total execution time: 0.0636
ERROR - 2022-03-21 06:35:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 06:35:49 --> Config Class Initialized
INFO - 2022-03-21 06:35:49 --> Hooks Class Initialized
DEBUG - 2022-03-21 06:35:49 --> UTF-8 Support Enabled
INFO - 2022-03-21 06:35:49 --> Utf8 Class Initialized
INFO - 2022-03-21 06:35:49 --> URI Class Initialized
INFO - 2022-03-21 06:35:49 --> Router Class Initialized
INFO - 2022-03-21 06:35:49 --> Output Class Initialized
INFO - 2022-03-21 06:35:49 --> Security Class Initialized
DEBUG - 2022-03-21 06:35:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 06:35:49 --> Input Class Initialized
INFO - 2022-03-21 06:35:49 --> Language Class Initialized
INFO - 2022-03-21 06:35:49 --> Loader Class Initialized
INFO - 2022-03-21 06:35:49 --> Helper loaded: url_helper
INFO - 2022-03-21 06:35:49 --> Helper loaded: form_helper
INFO - 2022-03-21 06:35:49 --> Helper loaded: common_helper
INFO - 2022-03-21 06:35:49 --> Database Driver Class Initialized
DEBUG - 2022-03-21 06:35:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 06:35:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 06:35:49 --> Controller Class Initialized
INFO - 2022-03-21 06:35:49 --> Form Validation Class Initialized
DEBUG - 2022-03-21 06:35:49 --> Encrypt Class Initialized
INFO - 2022-03-21 06:35:49 --> Model "Patient_model" initialized
INFO - 2022-03-21 06:35:49 --> Model "Patientcase_model" initialized
INFO - 2022-03-21 06:35:49 --> Model "Prefix_master" initialized
INFO - 2022-03-21 06:35:49 --> Model "Users_model" initialized
INFO - 2022-03-21 06:35:49 --> Model "Hospital_model" initialized
ERROR - 2022-03-21 06:35:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 06:35:50 --> Config Class Initialized
INFO - 2022-03-21 06:35:50 --> Hooks Class Initialized
DEBUG - 2022-03-21 06:35:50 --> UTF-8 Support Enabled
INFO - 2022-03-21 06:35:50 --> Utf8 Class Initialized
INFO - 2022-03-21 06:35:50 --> URI Class Initialized
INFO - 2022-03-21 06:35:50 --> Router Class Initialized
INFO - 2022-03-21 06:35:50 --> Output Class Initialized
INFO - 2022-03-21 06:35:50 --> Security Class Initialized
DEBUG - 2022-03-21 06:35:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 06:35:50 --> Input Class Initialized
INFO - 2022-03-21 06:35:50 --> Language Class Initialized
INFO - 2022-03-21 06:35:50 --> Loader Class Initialized
INFO - 2022-03-21 06:35:50 --> Helper loaded: url_helper
INFO - 2022-03-21 06:35:50 --> Helper loaded: form_helper
INFO - 2022-03-21 06:35:50 --> Helper loaded: common_helper
INFO - 2022-03-21 06:35:50 --> Database Driver Class Initialized
DEBUG - 2022-03-21 06:35:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 06:35:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 06:35:50 --> Controller Class Initialized
INFO - 2022-03-21 06:35:50 --> Form Validation Class Initialized
DEBUG - 2022-03-21 06:35:50 --> Encrypt Class Initialized
INFO - 2022-03-21 06:35:50 --> Model "Patient_model" initialized
INFO - 2022-03-21 06:35:50 --> Model "Patientcase_model" initialized
INFO - 2022-03-21 06:35:50 --> Model "Prefix_master" initialized
INFO - 2022-03-21 06:35:50 --> Model "Users_model" initialized
INFO - 2022-03-21 06:35:50 --> Model "Hospital_model" initialized
INFO - 2022-03-21 06:35:50 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-21 06:35:50 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-21 06:35:50 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-21 06:35:50 --> Final output sent to browser
DEBUG - 2022-03-21 06:35:50 --> Total execution time: 0.0807
ERROR - 2022-03-21 06:36:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 06:36:08 --> Config Class Initialized
INFO - 2022-03-21 06:36:08 --> Hooks Class Initialized
DEBUG - 2022-03-21 06:36:08 --> UTF-8 Support Enabled
INFO - 2022-03-21 06:36:08 --> Utf8 Class Initialized
INFO - 2022-03-21 06:36:08 --> URI Class Initialized
INFO - 2022-03-21 06:36:08 --> Router Class Initialized
INFO - 2022-03-21 06:36:08 --> Output Class Initialized
INFO - 2022-03-21 06:36:08 --> Security Class Initialized
DEBUG - 2022-03-21 06:36:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 06:36:08 --> Input Class Initialized
INFO - 2022-03-21 06:36:08 --> Language Class Initialized
INFO - 2022-03-21 06:36:08 --> Loader Class Initialized
INFO - 2022-03-21 06:36:08 --> Helper loaded: url_helper
INFO - 2022-03-21 06:36:08 --> Helper loaded: form_helper
INFO - 2022-03-21 06:36:08 --> Helper loaded: common_helper
INFO - 2022-03-21 06:36:08 --> Database Driver Class Initialized
DEBUG - 2022-03-21 06:36:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 06:36:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 06:36:08 --> Controller Class Initialized
INFO - 2022-03-21 06:36:08 --> Form Validation Class Initialized
DEBUG - 2022-03-21 06:36:08 --> Encrypt Class Initialized
INFO - 2022-03-21 06:36:08 --> Model "Patient_model" initialized
INFO - 2022-03-21 06:36:08 --> Model "Patientcase_model" initialized
INFO - 2022-03-21 06:36:08 --> Model "Prefix_master" initialized
INFO - 2022-03-21 06:36:08 --> Model "Users_model" initialized
INFO - 2022-03-21 06:36:08 --> Model "Hospital_model" initialized
ERROR - 2022-03-21 06:36:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 06:36:09 --> Config Class Initialized
INFO - 2022-03-21 06:36:09 --> Hooks Class Initialized
DEBUG - 2022-03-21 06:36:09 --> UTF-8 Support Enabled
INFO - 2022-03-21 06:36:09 --> Utf8 Class Initialized
INFO - 2022-03-21 06:36:09 --> URI Class Initialized
INFO - 2022-03-21 06:36:09 --> Router Class Initialized
INFO - 2022-03-21 06:36:09 --> Output Class Initialized
INFO - 2022-03-21 06:36:09 --> Security Class Initialized
DEBUG - 2022-03-21 06:36:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 06:36:09 --> Input Class Initialized
INFO - 2022-03-21 06:36:09 --> Language Class Initialized
INFO - 2022-03-21 06:36:09 --> Loader Class Initialized
INFO - 2022-03-21 06:36:09 --> Helper loaded: url_helper
INFO - 2022-03-21 06:36:09 --> Helper loaded: form_helper
INFO - 2022-03-21 06:36:09 --> Helper loaded: common_helper
INFO - 2022-03-21 06:36:09 --> Database Driver Class Initialized
DEBUG - 2022-03-21 06:36:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 06:36:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 06:36:09 --> Controller Class Initialized
INFO - 2022-03-21 06:36:09 --> Form Validation Class Initialized
DEBUG - 2022-03-21 06:36:09 --> Encrypt Class Initialized
INFO - 2022-03-21 06:36:09 --> Model "Patient_model" initialized
INFO - 2022-03-21 06:36:09 --> Model "Patientcase_model" initialized
INFO - 2022-03-21 06:36:09 --> Model "Prefix_master" initialized
INFO - 2022-03-21 06:36:09 --> Model "Users_model" initialized
INFO - 2022-03-21 06:36:09 --> Model "Hospital_model" initialized
INFO - 2022-03-21 06:36:09 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-21 06:36:09 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-21 06:36:09 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-21 06:36:09 --> Final output sent to browser
DEBUG - 2022-03-21 06:36:09 --> Total execution time: 0.0778
ERROR - 2022-03-21 06:36:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 06:36:12 --> Config Class Initialized
INFO - 2022-03-21 06:36:12 --> Hooks Class Initialized
DEBUG - 2022-03-21 06:36:12 --> UTF-8 Support Enabled
INFO - 2022-03-21 06:36:12 --> Utf8 Class Initialized
INFO - 2022-03-21 06:36:12 --> URI Class Initialized
INFO - 2022-03-21 06:36:12 --> Router Class Initialized
INFO - 2022-03-21 06:36:12 --> Output Class Initialized
INFO - 2022-03-21 06:36:12 --> Security Class Initialized
DEBUG - 2022-03-21 06:36:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 06:36:12 --> Input Class Initialized
INFO - 2022-03-21 06:36:12 --> Language Class Initialized
INFO - 2022-03-21 06:36:12 --> Loader Class Initialized
INFO - 2022-03-21 06:36:12 --> Helper loaded: url_helper
INFO - 2022-03-21 06:36:12 --> Helper loaded: form_helper
INFO - 2022-03-21 06:36:12 --> Helper loaded: common_helper
INFO - 2022-03-21 06:36:12 --> Database Driver Class Initialized
DEBUG - 2022-03-21 06:36:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 06:36:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 06:36:12 --> Controller Class Initialized
INFO - 2022-03-21 06:36:12 --> Form Validation Class Initialized
DEBUG - 2022-03-21 06:36:12 --> Encrypt Class Initialized
INFO - 2022-03-21 06:36:12 --> Model "Patient_model" initialized
INFO - 2022-03-21 06:36:12 --> Model "Patientcase_model" initialized
INFO - 2022-03-21 06:36:12 --> Model "Referredby_model" initialized
INFO - 2022-03-21 06:36:12 --> Model "Prefix_master" initialized
INFO - 2022-03-21 06:36:12 --> Model "Hospital_model" initialized
INFO - 2022-03-21 06:36:12 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-21 06:36:12 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-21 06:36:12 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-21 06:36:12 --> Final output sent to browser
DEBUG - 2022-03-21 06:36:12 --> Total execution time: 0.0471
ERROR - 2022-03-21 06:36:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 06:36:37 --> Config Class Initialized
INFO - 2022-03-21 06:36:37 --> Hooks Class Initialized
DEBUG - 2022-03-21 06:36:37 --> UTF-8 Support Enabled
INFO - 2022-03-21 06:36:37 --> Utf8 Class Initialized
INFO - 2022-03-21 06:36:37 --> URI Class Initialized
INFO - 2022-03-21 06:36:37 --> Router Class Initialized
INFO - 2022-03-21 06:36:37 --> Output Class Initialized
INFO - 2022-03-21 06:36:37 --> Security Class Initialized
DEBUG - 2022-03-21 06:36:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 06:36:37 --> Input Class Initialized
INFO - 2022-03-21 06:36:37 --> Language Class Initialized
INFO - 2022-03-21 06:36:37 --> Loader Class Initialized
INFO - 2022-03-21 06:36:37 --> Helper loaded: url_helper
INFO - 2022-03-21 06:36:37 --> Helper loaded: form_helper
INFO - 2022-03-21 06:36:37 --> Helper loaded: common_helper
INFO - 2022-03-21 06:36:37 --> Database Driver Class Initialized
DEBUG - 2022-03-21 06:36:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 06:36:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 06:36:37 --> Controller Class Initialized
INFO - 2022-03-21 06:36:37 --> Form Validation Class Initialized
DEBUG - 2022-03-21 06:36:37 --> Encrypt Class Initialized
INFO - 2022-03-21 06:36:37 --> Model "Patient_model" initialized
INFO - 2022-03-21 06:36:37 --> Model "Patientcase_model" initialized
INFO - 2022-03-21 06:36:37 --> Model "Referredby_model" initialized
INFO - 2022-03-21 06:36:37 --> Model "Prefix_master" initialized
INFO - 2022-03-21 06:36:37 --> Model "Hospital_model" initialized
INFO - 2022-03-21 06:36:37 --> Upload Class Initialized
INFO - 2022-03-21 06:36:37 --> Final output sent to browser
DEBUG - 2022-03-21 06:36:37 --> Total execution time: 0.0710
ERROR - 2022-03-21 06:36:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 06:36:47 --> Config Class Initialized
INFO - 2022-03-21 06:36:47 --> Hooks Class Initialized
DEBUG - 2022-03-21 06:36:47 --> UTF-8 Support Enabled
INFO - 2022-03-21 06:36:47 --> Utf8 Class Initialized
INFO - 2022-03-21 06:36:47 --> URI Class Initialized
INFO - 2022-03-21 06:36:47 --> Router Class Initialized
INFO - 2022-03-21 06:36:47 --> Output Class Initialized
INFO - 2022-03-21 06:36:47 --> Security Class Initialized
DEBUG - 2022-03-21 06:36:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 06:36:47 --> Input Class Initialized
INFO - 2022-03-21 06:36:47 --> Language Class Initialized
INFO - 2022-03-21 06:36:47 --> Loader Class Initialized
INFO - 2022-03-21 06:36:47 --> Helper loaded: url_helper
INFO - 2022-03-21 06:36:47 --> Helper loaded: form_helper
INFO - 2022-03-21 06:36:47 --> Helper loaded: common_helper
INFO - 2022-03-21 06:36:47 --> Database Driver Class Initialized
DEBUG - 2022-03-21 06:36:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 06:36:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 06:36:47 --> Controller Class Initialized
INFO - 2022-03-21 06:36:47 --> Form Validation Class Initialized
DEBUG - 2022-03-21 06:36:47 --> Encrypt Class Initialized
INFO - 2022-03-21 06:36:47 --> Model "Patient_model" initialized
INFO - 2022-03-21 06:36:47 --> Model "Patientcase_model" initialized
INFO - 2022-03-21 06:36:47 --> Model "Referredby_model" initialized
INFO - 2022-03-21 06:36:47 --> Model "Prefix_master" initialized
INFO - 2022-03-21 06:36:47 --> Model "Hospital_model" initialized
ERROR - 2022-03-21 06:36:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 06:36:48 --> Config Class Initialized
INFO - 2022-03-21 06:36:48 --> Hooks Class Initialized
DEBUG - 2022-03-21 06:36:48 --> UTF-8 Support Enabled
INFO - 2022-03-21 06:36:48 --> Utf8 Class Initialized
INFO - 2022-03-21 06:36:48 --> URI Class Initialized
INFO - 2022-03-21 06:36:48 --> Router Class Initialized
INFO - 2022-03-21 06:36:48 --> Output Class Initialized
INFO - 2022-03-21 06:36:48 --> Security Class Initialized
DEBUG - 2022-03-21 06:36:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 06:36:48 --> Input Class Initialized
INFO - 2022-03-21 06:36:48 --> Language Class Initialized
INFO - 2022-03-21 06:36:48 --> Loader Class Initialized
INFO - 2022-03-21 06:36:48 --> Helper loaded: url_helper
INFO - 2022-03-21 06:36:48 --> Helper loaded: form_helper
INFO - 2022-03-21 06:36:48 --> Helper loaded: common_helper
INFO - 2022-03-21 06:36:48 --> Database Driver Class Initialized
DEBUG - 2022-03-21 06:36:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 06:36:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 06:36:48 --> Controller Class Initialized
INFO - 2022-03-21 06:36:48 --> Form Validation Class Initialized
DEBUG - 2022-03-21 06:36:48 --> Encrypt Class Initialized
INFO - 2022-03-21 06:36:48 --> Model "Patient_model" initialized
INFO - 2022-03-21 06:36:48 --> Model "Patientcase_model" initialized
INFO - 2022-03-21 06:36:48 --> Model "Referredby_model" initialized
INFO - 2022-03-21 06:36:48 --> Model "Prefix_master" initialized
INFO - 2022-03-21 06:36:48 --> Model "Hospital_model" initialized
INFO - 2022-03-21 06:36:48 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-21 06:36:48 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-21 06:36:48 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-21 06:36:48 --> Final output sent to browser
DEBUG - 2022-03-21 06:36:48 --> Total execution time: 0.0552
ERROR - 2022-03-21 06:36:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 06:36:49 --> Config Class Initialized
INFO - 2022-03-21 06:36:49 --> Hooks Class Initialized
DEBUG - 2022-03-21 06:36:49 --> UTF-8 Support Enabled
INFO - 2022-03-21 06:36:49 --> Utf8 Class Initialized
INFO - 2022-03-21 06:36:49 --> URI Class Initialized
INFO - 2022-03-21 06:36:49 --> Router Class Initialized
INFO - 2022-03-21 06:36:49 --> Output Class Initialized
INFO - 2022-03-21 06:36:49 --> Security Class Initialized
DEBUG - 2022-03-21 06:36:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 06:36:49 --> Input Class Initialized
INFO - 2022-03-21 06:36:49 --> Language Class Initialized
INFO - 2022-03-21 06:36:49 --> Loader Class Initialized
INFO - 2022-03-21 06:36:49 --> Helper loaded: url_helper
INFO - 2022-03-21 06:36:49 --> Helper loaded: form_helper
INFO - 2022-03-21 06:36:49 --> Helper loaded: common_helper
INFO - 2022-03-21 06:36:49 --> Database Driver Class Initialized
DEBUG - 2022-03-21 06:36:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 06:36:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 06:36:49 --> Controller Class Initialized
INFO - 2022-03-21 06:36:49 --> Form Validation Class Initialized
DEBUG - 2022-03-21 06:36:49 --> Encrypt Class Initialized
INFO - 2022-03-21 06:36:49 --> Model "Patient_model" initialized
INFO - 2022-03-21 06:36:49 --> Model "Patientcase_model" initialized
INFO - 2022-03-21 06:36:49 --> Model "Prefix_master" initialized
INFO - 2022-03-21 06:36:49 --> Model "Users_model" initialized
INFO - 2022-03-21 06:36:49 --> Model "Hospital_model" initialized
INFO - 2022-03-21 06:36:49 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-21 06:36:49 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-21 06:36:49 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-21 06:36:49 --> Final output sent to browser
DEBUG - 2022-03-21 06:36:49 --> Total execution time: 0.1045
ERROR - 2022-03-21 06:36:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 06:36:58 --> Config Class Initialized
INFO - 2022-03-21 06:36:58 --> Hooks Class Initialized
DEBUG - 2022-03-21 06:36:58 --> UTF-8 Support Enabled
INFO - 2022-03-21 06:36:58 --> Utf8 Class Initialized
INFO - 2022-03-21 06:36:58 --> URI Class Initialized
INFO - 2022-03-21 06:36:58 --> Router Class Initialized
INFO - 2022-03-21 06:36:58 --> Output Class Initialized
INFO - 2022-03-21 06:36:58 --> Security Class Initialized
DEBUG - 2022-03-21 06:36:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 06:36:58 --> Input Class Initialized
INFO - 2022-03-21 06:36:58 --> Language Class Initialized
INFO - 2022-03-21 06:36:58 --> Loader Class Initialized
INFO - 2022-03-21 06:36:58 --> Helper loaded: url_helper
INFO - 2022-03-21 06:36:58 --> Helper loaded: form_helper
INFO - 2022-03-21 06:36:58 --> Helper loaded: common_helper
INFO - 2022-03-21 06:36:58 --> Database Driver Class Initialized
DEBUG - 2022-03-21 06:36:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 06:36:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 06:36:58 --> Controller Class Initialized
INFO - 2022-03-21 06:36:58 --> Form Validation Class Initialized
DEBUG - 2022-03-21 06:36:58 --> Encrypt Class Initialized
INFO - 2022-03-21 06:36:58 --> Model "Patient_model" initialized
INFO - 2022-03-21 06:36:58 --> Model "Patientcase_model" initialized
INFO - 2022-03-21 06:36:58 --> Model "Referredby_model" initialized
INFO - 2022-03-21 06:36:58 --> Model "Prefix_master" initialized
INFO - 2022-03-21 06:36:58 --> Model "Hospital_model" initialized
INFO - 2022-03-21 06:36:58 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-21 06:36:58 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-21 06:36:58 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-21 06:36:58 --> Final output sent to browser
DEBUG - 2022-03-21 06:36:58 --> Total execution time: 0.0531
ERROR - 2022-03-21 06:37:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 06:37:12 --> Config Class Initialized
INFO - 2022-03-21 06:37:12 --> Hooks Class Initialized
DEBUG - 2022-03-21 06:37:12 --> UTF-8 Support Enabled
INFO - 2022-03-21 06:37:12 --> Utf8 Class Initialized
INFO - 2022-03-21 06:37:12 --> URI Class Initialized
INFO - 2022-03-21 06:37:12 --> Router Class Initialized
INFO - 2022-03-21 06:37:12 --> Output Class Initialized
INFO - 2022-03-21 06:37:12 --> Security Class Initialized
DEBUG - 2022-03-21 06:37:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 06:37:12 --> Input Class Initialized
INFO - 2022-03-21 06:37:12 --> Language Class Initialized
INFO - 2022-03-21 06:37:12 --> Loader Class Initialized
INFO - 2022-03-21 06:37:12 --> Helper loaded: url_helper
INFO - 2022-03-21 06:37:12 --> Helper loaded: form_helper
INFO - 2022-03-21 06:37:12 --> Helper loaded: common_helper
INFO - 2022-03-21 06:37:12 --> Database Driver Class Initialized
DEBUG - 2022-03-21 06:37:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 06:37:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 06:37:12 --> Controller Class Initialized
INFO - 2022-03-21 06:37:12 --> Form Validation Class Initialized
DEBUG - 2022-03-21 06:37:12 --> Encrypt Class Initialized
INFO - 2022-03-21 06:37:12 --> Model "Patient_model" initialized
INFO - 2022-03-21 06:37:12 --> Model "Patientcase_model" initialized
INFO - 2022-03-21 06:37:12 --> Model "Referredby_model" initialized
INFO - 2022-03-21 06:37:12 --> Model "Prefix_master" initialized
INFO - 2022-03-21 06:37:12 --> Model "Hospital_model" initialized
INFO - 2022-03-21 06:37:12 --> Final output sent to browser
DEBUG - 2022-03-21 06:37:12 --> Total execution time: 0.0344
ERROR - 2022-03-21 06:37:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 06:37:23 --> Config Class Initialized
INFO - 2022-03-21 06:37:23 --> Hooks Class Initialized
DEBUG - 2022-03-21 06:37:23 --> UTF-8 Support Enabled
INFO - 2022-03-21 06:37:23 --> Utf8 Class Initialized
INFO - 2022-03-21 06:37:23 --> URI Class Initialized
INFO - 2022-03-21 06:37:23 --> Router Class Initialized
INFO - 2022-03-21 06:37:23 --> Output Class Initialized
INFO - 2022-03-21 06:37:23 --> Security Class Initialized
DEBUG - 2022-03-21 06:37:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 06:37:23 --> Input Class Initialized
INFO - 2022-03-21 06:37:23 --> Language Class Initialized
INFO - 2022-03-21 06:37:23 --> Loader Class Initialized
INFO - 2022-03-21 06:37:23 --> Helper loaded: url_helper
INFO - 2022-03-21 06:37:23 --> Helper loaded: form_helper
INFO - 2022-03-21 06:37:23 --> Helper loaded: common_helper
INFO - 2022-03-21 06:37:23 --> Database Driver Class Initialized
DEBUG - 2022-03-21 06:37:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 06:37:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 06:37:23 --> Controller Class Initialized
INFO - 2022-03-21 06:37:23 --> Model "Referredby_model" initialized
INFO - 2022-03-21 06:37:23 --> Final output sent to browser
DEBUG - 2022-03-21 06:37:23 --> Total execution time: 0.0283
ERROR - 2022-03-21 06:37:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 06:37:51 --> Config Class Initialized
INFO - 2022-03-21 06:37:51 --> Hooks Class Initialized
DEBUG - 2022-03-21 06:37:51 --> UTF-8 Support Enabled
INFO - 2022-03-21 06:37:51 --> Utf8 Class Initialized
INFO - 2022-03-21 06:37:51 --> URI Class Initialized
INFO - 2022-03-21 06:37:51 --> Router Class Initialized
INFO - 2022-03-21 06:37:51 --> Output Class Initialized
INFO - 2022-03-21 06:37:51 --> Security Class Initialized
DEBUG - 2022-03-21 06:37:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 06:37:51 --> Input Class Initialized
INFO - 2022-03-21 06:37:51 --> Language Class Initialized
INFO - 2022-03-21 06:37:51 --> Loader Class Initialized
INFO - 2022-03-21 06:37:51 --> Helper loaded: url_helper
INFO - 2022-03-21 06:37:51 --> Helper loaded: form_helper
INFO - 2022-03-21 06:37:51 --> Helper loaded: common_helper
INFO - 2022-03-21 06:37:51 --> Database Driver Class Initialized
DEBUG - 2022-03-21 06:37:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 06:37:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 06:37:51 --> Controller Class Initialized
INFO - 2022-03-21 06:37:51 --> Form Validation Class Initialized
DEBUG - 2022-03-21 06:37:51 --> Encrypt Class Initialized
INFO - 2022-03-21 06:37:51 --> Model "Patient_model" initialized
INFO - 2022-03-21 06:37:51 --> Model "Patientcase_model" initialized
INFO - 2022-03-21 06:37:51 --> Model "Referredby_model" initialized
INFO - 2022-03-21 06:37:51 --> Model "Prefix_master" initialized
INFO - 2022-03-21 06:37:51 --> Model "Hospital_model" initialized
ERROR - 2022-03-21 06:37:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 06:37:52 --> Config Class Initialized
INFO - 2022-03-21 06:37:52 --> Hooks Class Initialized
DEBUG - 2022-03-21 06:37:52 --> UTF-8 Support Enabled
INFO - 2022-03-21 06:37:52 --> Utf8 Class Initialized
INFO - 2022-03-21 06:37:52 --> URI Class Initialized
INFO - 2022-03-21 06:37:52 --> Router Class Initialized
INFO - 2022-03-21 06:37:52 --> Output Class Initialized
INFO - 2022-03-21 06:37:52 --> Security Class Initialized
DEBUG - 2022-03-21 06:37:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 06:37:52 --> Input Class Initialized
INFO - 2022-03-21 06:37:52 --> Language Class Initialized
INFO - 2022-03-21 06:37:52 --> Loader Class Initialized
INFO - 2022-03-21 06:37:52 --> Helper loaded: url_helper
INFO - 2022-03-21 06:37:52 --> Helper loaded: form_helper
INFO - 2022-03-21 06:37:52 --> Helper loaded: common_helper
INFO - 2022-03-21 06:37:52 --> Database Driver Class Initialized
DEBUG - 2022-03-21 06:37:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 06:37:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 06:37:52 --> Controller Class Initialized
INFO - 2022-03-21 06:37:52 --> Form Validation Class Initialized
DEBUG - 2022-03-21 06:37:52 --> Encrypt Class Initialized
INFO - 2022-03-21 06:37:52 --> Model "Patient_model" initialized
INFO - 2022-03-21 06:37:52 --> Model "Patientcase_model" initialized
INFO - 2022-03-21 06:37:52 --> Model "Referredby_model" initialized
INFO - 2022-03-21 06:37:52 --> Model "Prefix_master" initialized
INFO - 2022-03-21 06:37:52 --> Model "Hospital_model" initialized
INFO - 2022-03-21 06:37:52 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-21 06:37:52 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-21 06:37:52 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-21 06:37:52 --> Final output sent to browser
DEBUG - 2022-03-21 06:37:52 --> Total execution time: 0.0866
ERROR - 2022-03-21 06:37:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 06:37:54 --> Config Class Initialized
INFO - 2022-03-21 06:37:54 --> Hooks Class Initialized
DEBUG - 2022-03-21 06:37:54 --> UTF-8 Support Enabled
INFO - 2022-03-21 06:37:54 --> Utf8 Class Initialized
INFO - 2022-03-21 06:37:54 --> URI Class Initialized
INFO - 2022-03-21 06:37:54 --> Router Class Initialized
INFO - 2022-03-21 06:37:54 --> Output Class Initialized
INFO - 2022-03-21 06:37:54 --> Security Class Initialized
DEBUG - 2022-03-21 06:37:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 06:37:54 --> Input Class Initialized
INFO - 2022-03-21 06:37:54 --> Language Class Initialized
INFO - 2022-03-21 06:37:54 --> Loader Class Initialized
INFO - 2022-03-21 06:37:54 --> Helper loaded: url_helper
INFO - 2022-03-21 06:37:54 --> Helper loaded: form_helper
INFO - 2022-03-21 06:37:54 --> Helper loaded: common_helper
INFO - 2022-03-21 06:37:54 --> Database Driver Class Initialized
DEBUG - 2022-03-21 06:37:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 06:37:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 06:37:54 --> Controller Class Initialized
INFO - 2022-03-21 06:37:54 --> Form Validation Class Initialized
DEBUG - 2022-03-21 06:37:54 --> Encrypt Class Initialized
INFO - 2022-03-21 06:37:54 --> Model "Patient_model" initialized
INFO - 2022-03-21 06:37:54 --> Model "Patientcase_model" initialized
INFO - 2022-03-21 06:37:54 --> Model "Prefix_master" initialized
INFO - 2022-03-21 06:37:54 --> Model "Users_model" initialized
INFO - 2022-03-21 06:37:54 --> Model "Hospital_model" initialized
INFO - 2022-03-21 06:37:54 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-21 06:37:54 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-21 06:37:54 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-21 06:37:54 --> Final output sent to browser
DEBUG - 2022-03-21 06:37:54 --> Total execution time: 0.1175
ERROR - 2022-03-21 06:45:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 06:45:45 --> Config Class Initialized
INFO - 2022-03-21 06:45:45 --> Hooks Class Initialized
DEBUG - 2022-03-21 06:45:45 --> UTF-8 Support Enabled
INFO - 2022-03-21 06:45:45 --> Utf8 Class Initialized
INFO - 2022-03-21 06:45:45 --> URI Class Initialized
INFO - 2022-03-21 06:45:45 --> Router Class Initialized
INFO - 2022-03-21 06:45:45 --> Output Class Initialized
INFO - 2022-03-21 06:45:45 --> Security Class Initialized
DEBUG - 2022-03-21 06:45:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 06:45:45 --> Input Class Initialized
INFO - 2022-03-21 06:45:45 --> Language Class Initialized
INFO - 2022-03-21 06:45:45 --> Loader Class Initialized
INFO - 2022-03-21 06:45:45 --> Helper loaded: url_helper
INFO - 2022-03-21 06:45:45 --> Helper loaded: form_helper
INFO - 2022-03-21 06:45:45 --> Helper loaded: common_helper
INFO - 2022-03-21 06:45:45 --> Database Driver Class Initialized
DEBUG - 2022-03-21 06:45:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 06:45:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 06:45:45 --> Controller Class Initialized
INFO - 2022-03-21 06:45:45 --> Form Validation Class Initialized
DEBUG - 2022-03-21 06:45:45 --> Encrypt Class Initialized
INFO - 2022-03-21 06:45:45 --> Model "Patient_model" initialized
INFO - 2022-03-21 06:45:45 --> Model "Patientcase_model" initialized
INFO - 2022-03-21 06:45:45 --> Model "Referredby_model" initialized
INFO - 2022-03-21 06:45:45 --> Model "Prefix_master" initialized
INFO - 2022-03-21 06:45:45 --> Model "Hospital_model" initialized
ERROR - 2022-03-21 06:45:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 06:45:46 --> Config Class Initialized
INFO - 2022-03-21 06:45:46 --> Hooks Class Initialized
DEBUG - 2022-03-21 06:45:46 --> UTF-8 Support Enabled
INFO - 2022-03-21 06:45:46 --> Utf8 Class Initialized
INFO - 2022-03-21 06:45:46 --> URI Class Initialized
INFO - 2022-03-21 06:45:46 --> Router Class Initialized
INFO - 2022-03-21 06:45:46 --> Output Class Initialized
INFO - 2022-03-21 06:45:46 --> Security Class Initialized
DEBUG - 2022-03-21 06:45:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 06:45:46 --> Input Class Initialized
INFO - 2022-03-21 06:45:46 --> Language Class Initialized
INFO - 2022-03-21 06:45:46 --> Loader Class Initialized
INFO - 2022-03-21 06:45:46 --> Helper loaded: url_helper
INFO - 2022-03-21 06:45:46 --> Helper loaded: form_helper
INFO - 2022-03-21 06:45:46 --> Helper loaded: common_helper
INFO - 2022-03-21 06:45:46 --> Database Driver Class Initialized
DEBUG - 2022-03-21 06:45:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 06:45:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 06:45:46 --> Controller Class Initialized
INFO - 2022-03-21 06:45:46 --> Form Validation Class Initialized
DEBUG - 2022-03-21 06:45:46 --> Encrypt Class Initialized
INFO - 2022-03-21 06:45:46 --> Model "Patient_model" initialized
INFO - 2022-03-21 06:45:46 --> Model "Patientcase_model" initialized
INFO - 2022-03-21 06:45:46 --> Model "Referredby_model" initialized
INFO - 2022-03-21 06:45:46 --> Model "Prefix_master" initialized
INFO - 2022-03-21 06:45:46 --> Model "Hospital_model" initialized
INFO - 2022-03-21 06:45:46 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-21 06:45:46 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-21 06:45:46 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-21 06:45:46 --> Final output sent to browser
DEBUG - 2022-03-21 06:45:46 --> Total execution time: 0.0507
ERROR - 2022-03-21 06:45:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 06:45:47 --> Config Class Initialized
INFO - 2022-03-21 06:45:47 --> Hooks Class Initialized
DEBUG - 2022-03-21 06:45:47 --> UTF-8 Support Enabled
INFO - 2022-03-21 06:45:47 --> Utf8 Class Initialized
INFO - 2022-03-21 06:45:47 --> URI Class Initialized
INFO - 2022-03-21 06:45:47 --> Router Class Initialized
INFO - 2022-03-21 06:45:47 --> Output Class Initialized
INFO - 2022-03-21 06:45:47 --> Security Class Initialized
DEBUG - 2022-03-21 06:45:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 06:45:47 --> Input Class Initialized
INFO - 2022-03-21 06:45:47 --> Language Class Initialized
INFO - 2022-03-21 06:45:47 --> Loader Class Initialized
INFO - 2022-03-21 06:45:47 --> Helper loaded: url_helper
INFO - 2022-03-21 06:45:47 --> Helper loaded: form_helper
INFO - 2022-03-21 06:45:47 --> Helper loaded: common_helper
INFO - 2022-03-21 06:45:47 --> Database Driver Class Initialized
DEBUG - 2022-03-21 06:45:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 06:45:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 06:45:47 --> Controller Class Initialized
INFO - 2022-03-21 06:45:47 --> Form Validation Class Initialized
DEBUG - 2022-03-21 06:45:47 --> Encrypt Class Initialized
INFO - 2022-03-21 06:45:47 --> Model "Patient_model" initialized
INFO - 2022-03-21 06:45:47 --> Model "Patientcase_model" initialized
INFO - 2022-03-21 06:45:47 --> Model "Prefix_master" initialized
INFO - 2022-03-21 06:45:47 --> Model "Users_model" initialized
INFO - 2022-03-21 06:45:47 --> Model "Hospital_model" initialized
INFO - 2022-03-21 06:45:47 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-21 06:45:47 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-21 06:45:47 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-21 06:45:47 --> Final output sent to browser
DEBUG - 2022-03-21 06:45:47 --> Total execution time: 0.0789
ERROR - 2022-03-21 06:54:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 06:54:12 --> Config Class Initialized
INFO - 2022-03-21 06:54:12 --> Hooks Class Initialized
DEBUG - 2022-03-21 06:54:12 --> UTF-8 Support Enabled
INFO - 2022-03-21 06:54:12 --> Utf8 Class Initialized
INFO - 2022-03-21 06:54:12 --> URI Class Initialized
INFO - 2022-03-21 06:54:12 --> Router Class Initialized
INFO - 2022-03-21 06:54:12 --> Output Class Initialized
INFO - 2022-03-21 06:54:12 --> Security Class Initialized
DEBUG - 2022-03-21 06:54:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 06:54:12 --> Input Class Initialized
INFO - 2022-03-21 06:54:12 --> Language Class Initialized
INFO - 2022-03-21 06:54:12 --> Loader Class Initialized
INFO - 2022-03-21 06:54:12 --> Helper loaded: url_helper
INFO - 2022-03-21 06:54:12 --> Helper loaded: form_helper
INFO - 2022-03-21 06:54:12 --> Helper loaded: common_helper
INFO - 2022-03-21 06:54:12 --> Database Driver Class Initialized
DEBUG - 2022-03-21 06:54:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 06:54:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 06:54:12 --> Controller Class Initialized
INFO - 2022-03-21 06:54:12 --> Form Validation Class Initialized
DEBUG - 2022-03-21 06:54:12 --> Encrypt Class Initialized
INFO - 2022-03-21 06:54:12 --> Model "Patient_model" initialized
INFO - 2022-03-21 06:54:12 --> Model "Patientcase_model" initialized
INFO - 2022-03-21 06:54:12 --> Model "Prefix_master" initialized
INFO - 2022-03-21 06:54:12 --> Model "Users_model" initialized
INFO - 2022-03-21 06:54:12 --> Model "Hospital_model" initialized
ERROR - 2022-03-21 06:54:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 06:54:13 --> Config Class Initialized
INFO - 2022-03-21 06:54:13 --> Hooks Class Initialized
DEBUG - 2022-03-21 06:54:13 --> UTF-8 Support Enabled
INFO - 2022-03-21 06:54:13 --> Utf8 Class Initialized
INFO - 2022-03-21 06:54:13 --> URI Class Initialized
INFO - 2022-03-21 06:54:13 --> Router Class Initialized
INFO - 2022-03-21 06:54:13 --> Output Class Initialized
INFO - 2022-03-21 06:54:13 --> Security Class Initialized
DEBUG - 2022-03-21 06:54:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 06:54:13 --> Input Class Initialized
INFO - 2022-03-21 06:54:13 --> Language Class Initialized
INFO - 2022-03-21 06:54:13 --> Loader Class Initialized
INFO - 2022-03-21 06:54:13 --> Helper loaded: url_helper
INFO - 2022-03-21 06:54:13 --> Helper loaded: form_helper
INFO - 2022-03-21 06:54:13 --> Helper loaded: common_helper
INFO - 2022-03-21 06:54:13 --> Database Driver Class Initialized
DEBUG - 2022-03-21 06:54:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 06:54:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 06:54:13 --> Controller Class Initialized
INFO - 2022-03-21 06:54:13 --> Form Validation Class Initialized
DEBUG - 2022-03-21 06:54:13 --> Encrypt Class Initialized
INFO - 2022-03-21 06:54:13 --> Model "Patient_model" initialized
INFO - 2022-03-21 06:54:13 --> Model "Patientcase_model" initialized
INFO - 2022-03-21 06:54:13 --> Model "Prefix_master" initialized
INFO - 2022-03-21 06:54:13 --> Model "Users_model" initialized
INFO - 2022-03-21 06:54:13 --> Model "Hospital_model" initialized
INFO - 2022-03-21 06:54:13 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-21 06:54:13 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-21 06:54:13 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-21 06:54:13 --> Final output sent to browser
DEBUG - 2022-03-21 06:54:13 --> Total execution time: 0.1058
ERROR - 2022-03-21 06:54:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 06:54:16 --> Config Class Initialized
INFO - 2022-03-21 06:54:16 --> Hooks Class Initialized
DEBUG - 2022-03-21 06:54:16 --> UTF-8 Support Enabled
INFO - 2022-03-21 06:54:16 --> Utf8 Class Initialized
INFO - 2022-03-21 06:54:16 --> URI Class Initialized
INFO - 2022-03-21 06:54:16 --> Router Class Initialized
INFO - 2022-03-21 06:54:16 --> Output Class Initialized
INFO - 2022-03-21 06:54:16 --> Security Class Initialized
DEBUG - 2022-03-21 06:54:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 06:54:16 --> Input Class Initialized
INFO - 2022-03-21 06:54:16 --> Language Class Initialized
INFO - 2022-03-21 06:54:16 --> Loader Class Initialized
INFO - 2022-03-21 06:54:16 --> Helper loaded: url_helper
INFO - 2022-03-21 06:54:16 --> Helper loaded: form_helper
INFO - 2022-03-21 06:54:16 --> Helper loaded: common_helper
INFO - 2022-03-21 06:54:16 --> Database Driver Class Initialized
DEBUG - 2022-03-21 06:54:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 06:54:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 06:54:16 --> Controller Class Initialized
INFO - 2022-03-21 06:54:16 --> Form Validation Class Initialized
DEBUG - 2022-03-21 06:54:16 --> Encrypt Class Initialized
INFO - 2022-03-21 06:54:16 --> Model "Patient_model" initialized
INFO - 2022-03-21 06:54:16 --> Model "Patientcase_model" initialized
INFO - 2022-03-21 06:54:16 --> Model "Referredby_model" initialized
INFO - 2022-03-21 06:54:16 --> Model "Prefix_master" initialized
INFO - 2022-03-21 06:54:16 --> Model "Hospital_model" initialized
ERROR - 2022-03-21 06:54:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 06:54:17 --> Config Class Initialized
INFO - 2022-03-21 06:54:17 --> Hooks Class Initialized
DEBUG - 2022-03-21 06:54:17 --> UTF-8 Support Enabled
INFO - 2022-03-21 06:54:17 --> Utf8 Class Initialized
INFO - 2022-03-21 06:54:17 --> URI Class Initialized
INFO - 2022-03-21 06:54:17 --> Router Class Initialized
INFO - 2022-03-21 06:54:17 --> Output Class Initialized
INFO - 2022-03-21 06:54:17 --> Security Class Initialized
DEBUG - 2022-03-21 06:54:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 06:54:17 --> Input Class Initialized
INFO - 2022-03-21 06:54:17 --> Language Class Initialized
INFO - 2022-03-21 06:54:17 --> Loader Class Initialized
INFO - 2022-03-21 06:54:17 --> Helper loaded: url_helper
INFO - 2022-03-21 06:54:17 --> Helper loaded: form_helper
INFO - 2022-03-21 06:54:17 --> Helper loaded: common_helper
INFO - 2022-03-21 06:54:17 --> Database Driver Class Initialized
DEBUG - 2022-03-21 06:54:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 06:54:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 06:54:17 --> Controller Class Initialized
INFO - 2022-03-21 06:54:17 --> Form Validation Class Initialized
DEBUG - 2022-03-21 06:54:17 --> Encrypt Class Initialized
INFO - 2022-03-21 06:54:17 --> Model "Patient_model" initialized
INFO - 2022-03-21 06:54:17 --> Model "Patientcase_model" initialized
INFO - 2022-03-21 06:54:17 --> Model "Referredby_model" initialized
INFO - 2022-03-21 06:54:17 --> Model "Prefix_master" initialized
INFO - 2022-03-21 06:54:17 --> Model "Hospital_model" initialized
INFO - 2022-03-21 06:54:17 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-21 06:54:17 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-21 06:54:17 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-21 06:54:17 --> Final output sent to browser
DEBUG - 2022-03-21 06:54:17 --> Total execution time: 0.0731
ERROR - 2022-03-21 06:54:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 06:54:19 --> Config Class Initialized
INFO - 2022-03-21 06:54:19 --> Hooks Class Initialized
DEBUG - 2022-03-21 06:54:19 --> UTF-8 Support Enabled
INFO - 2022-03-21 06:54:19 --> Utf8 Class Initialized
INFO - 2022-03-21 06:54:19 --> URI Class Initialized
INFO - 2022-03-21 06:54:19 --> Router Class Initialized
INFO - 2022-03-21 06:54:19 --> Output Class Initialized
INFO - 2022-03-21 06:54:19 --> Security Class Initialized
DEBUG - 2022-03-21 06:54:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 06:54:19 --> Input Class Initialized
INFO - 2022-03-21 06:54:19 --> Language Class Initialized
ERROR - 2022-03-21 06:54:19 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-21 06:54:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 06:54:19 --> Config Class Initialized
INFO - 2022-03-21 06:54:19 --> Hooks Class Initialized
DEBUG - 2022-03-21 06:54:19 --> UTF-8 Support Enabled
INFO - 2022-03-21 06:54:19 --> Utf8 Class Initialized
INFO - 2022-03-21 06:54:19 --> URI Class Initialized
INFO - 2022-03-21 06:54:19 --> Router Class Initialized
INFO - 2022-03-21 06:54:19 --> Output Class Initialized
INFO - 2022-03-21 06:54:19 --> Security Class Initialized
DEBUG - 2022-03-21 06:54:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 06:54:19 --> Input Class Initialized
INFO - 2022-03-21 06:54:19 --> Language Class Initialized
INFO - 2022-03-21 06:54:19 --> Loader Class Initialized
INFO - 2022-03-21 06:54:19 --> Helper loaded: url_helper
INFO - 2022-03-21 06:54:19 --> Helper loaded: form_helper
INFO - 2022-03-21 06:54:19 --> Helper loaded: common_helper
INFO - 2022-03-21 06:54:19 --> Database Driver Class Initialized
DEBUG - 2022-03-21 06:54:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 06:54:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 06:54:19 --> Controller Class Initialized
INFO - 2022-03-21 06:54:19 --> Form Validation Class Initialized
DEBUG - 2022-03-21 06:54:19 --> Encrypt Class Initialized
INFO - 2022-03-21 06:54:19 --> Model "Patient_model" initialized
INFO - 2022-03-21 06:54:19 --> Model "Patientcase_model" initialized
INFO - 2022-03-21 06:54:19 --> Model "Prefix_master" initialized
INFO - 2022-03-21 06:54:19 --> Model "Users_model" initialized
INFO - 2022-03-21 06:54:19 --> Model "Hospital_model" initialized
ERROR - 2022-03-21 06:54:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 06:54:19 --> Config Class Initialized
INFO - 2022-03-21 06:54:19 --> Hooks Class Initialized
DEBUG - 2022-03-21 06:54:19 --> UTF-8 Support Enabled
INFO - 2022-03-21 06:54:19 --> Utf8 Class Initialized
INFO - 2022-03-21 06:54:19 --> URI Class Initialized
INFO - 2022-03-21 06:54:19 --> Router Class Initialized
INFO - 2022-03-21 06:54:19 --> Output Class Initialized
INFO - 2022-03-21 06:54:19 --> Security Class Initialized
DEBUG - 2022-03-21 06:54:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 06:54:19 --> Input Class Initialized
INFO - 2022-03-21 06:54:19 --> Language Class Initialized
ERROR - 2022-03-21 06:54:19 --> 404 Page Not Found: Karoclient/images
INFO - 2022-03-21 06:54:19 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-21 06:54:19 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-21 06:54:19 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-21 06:54:19 --> Final output sent to browser
DEBUG - 2022-03-21 06:54:19 --> Total execution time: 0.1218
ERROR - 2022-03-21 06:54:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 06:54:20 --> Config Class Initialized
INFO - 2022-03-21 06:54:20 --> Hooks Class Initialized
DEBUG - 2022-03-21 06:54:20 --> UTF-8 Support Enabled
INFO - 2022-03-21 06:54:20 --> Utf8 Class Initialized
INFO - 2022-03-21 06:54:20 --> URI Class Initialized
INFO - 2022-03-21 06:54:20 --> Router Class Initialized
INFO - 2022-03-21 06:54:20 --> Output Class Initialized
INFO - 2022-03-21 06:54:20 --> Security Class Initialized
DEBUG - 2022-03-21 06:54:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 06:54:20 --> Input Class Initialized
INFO - 2022-03-21 06:54:20 --> Language Class Initialized
ERROR - 2022-03-21 06:54:20 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-21 06:55:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 06:55:34 --> Config Class Initialized
INFO - 2022-03-21 06:55:34 --> Hooks Class Initialized
DEBUG - 2022-03-21 06:55:34 --> UTF-8 Support Enabled
INFO - 2022-03-21 06:55:34 --> Utf8 Class Initialized
INFO - 2022-03-21 06:55:34 --> URI Class Initialized
INFO - 2022-03-21 06:55:34 --> Router Class Initialized
INFO - 2022-03-21 06:55:34 --> Output Class Initialized
INFO - 2022-03-21 06:55:34 --> Security Class Initialized
DEBUG - 2022-03-21 06:55:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 06:55:34 --> Input Class Initialized
INFO - 2022-03-21 06:55:34 --> Language Class Initialized
INFO - 2022-03-21 06:55:34 --> Loader Class Initialized
INFO - 2022-03-21 06:55:34 --> Helper loaded: url_helper
INFO - 2022-03-21 06:55:34 --> Helper loaded: form_helper
INFO - 2022-03-21 06:55:34 --> Helper loaded: common_helper
INFO - 2022-03-21 06:55:34 --> Database Driver Class Initialized
DEBUG - 2022-03-21 06:55:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 06:55:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 06:55:34 --> Controller Class Initialized
INFO - 2022-03-21 06:55:34 --> Form Validation Class Initialized
DEBUG - 2022-03-21 06:55:34 --> Encrypt Class Initialized
INFO - 2022-03-21 06:55:34 --> Model "Patient_model" initialized
INFO - 2022-03-21 06:55:34 --> Model "Patientcase_model" initialized
INFO - 2022-03-21 06:55:34 --> Model "Prefix_master" initialized
INFO - 2022-03-21 06:55:34 --> Model "Users_model" initialized
INFO - 2022-03-21 06:55:34 --> Model "Hospital_model" initialized
INFO - 2022-03-21 06:55:34 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-21 06:55:34 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-21 06:55:34 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-21 06:55:34 --> Final output sent to browser
DEBUG - 2022-03-21 06:55:34 --> Total execution time: 0.0883
ERROR - 2022-03-21 06:55:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 06:55:36 --> Config Class Initialized
INFO - 2022-03-21 06:55:36 --> Hooks Class Initialized
DEBUG - 2022-03-21 06:55:36 --> UTF-8 Support Enabled
INFO - 2022-03-21 06:55:36 --> Utf8 Class Initialized
INFO - 2022-03-21 06:55:36 --> URI Class Initialized
INFO - 2022-03-21 06:55:36 --> Router Class Initialized
INFO - 2022-03-21 06:55:36 --> Output Class Initialized
INFO - 2022-03-21 06:55:36 --> Security Class Initialized
DEBUG - 2022-03-21 06:55:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 06:55:36 --> Input Class Initialized
INFO - 2022-03-21 06:55:36 --> Language Class Initialized
ERROR - 2022-03-21 06:55:36 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-21 07:03:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 07:03:30 --> Config Class Initialized
INFO - 2022-03-21 07:03:30 --> Hooks Class Initialized
DEBUG - 2022-03-21 07:03:30 --> UTF-8 Support Enabled
INFO - 2022-03-21 07:03:30 --> Utf8 Class Initialized
INFO - 2022-03-21 07:03:30 --> URI Class Initialized
INFO - 2022-03-21 07:03:30 --> Router Class Initialized
INFO - 2022-03-21 07:03:30 --> Output Class Initialized
INFO - 2022-03-21 07:03:30 --> Security Class Initialized
DEBUG - 2022-03-21 07:03:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 07:03:30 --> Input Class Initialized
INFO - 2022-03-21 07:03:30 --> Language Class Initialized
INFO - 2022-03-21 07:03:30 --> Loader Class Initialized
INFO - 2022-03-21 07:03:30 --> Helper loaded: url_helper
INFO - 2022-03-21 07:03:30 --> Helper loaded: form_helper
INFO - 2022-03-21 07:03:30 --> Helper loaded: common_helper
INFO - 2022-03-21 07:03:30 --> Database Driver Class Initialized
DEBUG - 2022-03-21 07:03:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 07:03:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 07:03:30 --> Controller Class Initialized
INFO - 2022-03-21 07:03:30 --> Form Validation Class Initialized
DEBUG - 2022-03-21 07:03:30 --> Encrypt Class Initialized
INFO - 2022-03-21 07:03:30 --> Model "Patient_model" initialized
INFO - 2022-03-21 07:03:30 --> Model "Patientcase_model" initialized
INFO - 2022-03-21 07:03:30 --> Model "Prefix_master" initialized
INFO - 2022-03-21 07:03:30 --> Model "Users_model" initialized
INFO - 2022-03-21 07:03:30 --> Model "Hospital_model" initialized
ERROR - 2022-03-21 07:03:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 07:03:36 --> Config Class Initialized
INFO - 2022-03-21 07:03:36 --> Hooks Class Initialized
DEBUG - 2022-03-21 07:03:36 --> UTF-8 Support Enabled
INFO - 2022-03-21 07:03:36 --> Utf8 Class Initialized
INFO - 2022-03-21 07:03:36 --> URI Class Initialized
INFO - 2022-03-21 07:03:36 --> Router Class Initialized
INFO - 2022-03-21 07:03:36 --> Output Class Initialized
INFO - 2022-03-21 07:03:36 --> Security Class Initialized
DEBUG - 2022-03-21 07:03:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 07:03:36 --> Input Class Initialized
INFO - 2022-03-21 07:03:36 --> Language Class Initialized
INFO - 2022-03-21 07:03:36 --> Loader Class Initialized
INFO - 2022-03-21 07:03:36 --> Helper loaded: url_helper
INFO - 2022-03-21 07:03:36 --> Helper loaded: form_helper
INFO - 2022-03-21 07:03:36 --> Helper loaded: common_helper
INFO - 2022-03-21 07:03:36 --> Database Driver Class Initialized
DEBUG - 2022-03-21 07:03:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 07:03:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 07:03:36 --> Controller Class Initialized
INFO - 2022-03-21 07:03:36 --> Form Validation Class Initialized
DEBUG - 2022-03-21 07:03:36 --> Encrypt Class Initialized
INFO - 2022-03-21 07:03:36 --> Model "Patient_model" initialized
INFO - 2022-03-21 07:03:36 --> Model "Patientcase_model" initialized
INFO - 2022-03-21 07:03:36 --> Model "Prefix_master" initialized
INFO - 2022-03-21 07:03:36 --> Model "Users_model" initialized
INFO - 2022-03-21 07:03:36 --> Model "Hospital_model" initialized
INFO - 2022-03-21 07:03:37 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-21 07:03:37 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-21 07:03:37 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-21 07:03:37 --> Final output sent to browser
DEBUG - 2022-03-21 07:03:37 --> Total execution time: 0.1652
ERROR - 2022-03-21 07:03:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 07:03:59 --> Config Class Initialized
INFO - 2022-03-21 07:03:59 --> Hooks Class Initialized
DEBUG - 2022-03-21 07:03:59 --> UTF-8 Support Enabled
INFO - 2022-03-21 07:03:59 --> Utf8 Class Initialized
INFO - 2022-03-21 07:03:59 --> URI Class Initialized
INFO - 2022-03-21 07:03:59 --> Router Class Initialized
INFO - 2022-03-21 07:03:59 --> Output Class Initialized
INFO - 2022-03-21 07:03:59 --> Security Class Initialized
DEBUG - 2022-03-21 07:03:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 07:03:59 --> Input Class Initialized
INFO - 2022-03-21 07:03:59 --> Language Class Initialized
INFO - 2022-03-21 07:03:59 --> Loader Class Initialized
INFO - 2022-03-21 07:03:59 --> Helper loaded: url_helper
INFO - 2022-03-21 07:03:59 --> Helper loaded: form_helper
INFO - 2022-03-21 07:03:59 --> Helper loaded: common_helper
INFO - 2022-03-21 07:03:59 --> Database Driver Class Initialized
DEBUG - 2022-03-21 07:03:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 07:03:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 07:03:59 --> Controller Class Initialized
INFO - 2022-03-21 07:03:59 --> Form Validation Class Initialized
DEBUG - 2022-03-21 07:03:59 --> Encrypt Class Initialized
INFO - 2022-03-21 07:03:59 --> Model "Patient_model" initialized
INFO - 2022-03-21 07:03:59 --> Model "Patientcase_model" initialized
INFO - 2022-03-21 07:03:59 --> Model "Prefix_master" initialized
INFO - 2022-03-21 07:03:59 --> Model "Users_model" initialized
INFO - 2022-03-21 07:03:59 --> Model "Hospital_model" initialized
ERROR - 2022-03-21 07:03:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 07:03:59 --> Config Class Initialized
INFO - 2022-03-21 07:03:59 --> Hooks Class Initialized
DEBUG - 2022-03-21 07:03:59 --> UTF-8 Support Enabled
INFO - 2022-03-21 07:03:59 --> Utf8 Class Initialized
INFO - 2022-03-21 07:03:59 --> URI Class Initialized
INFO - 2022-03-21 07:03:59 --> Router Class Initialized
INFO - 2022-03-21 07:03:59 --> Output Class Initialized
INFO - 2022-03-21 07:03:59 --> Security Class Initialized
DEBUG - 2022-03-21 07:03:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 07:03:59 --> Input Class Initialized
INFO - 2022-03-21 07:03:59 --> Language Class Initialized
INFO - 2022-03-21 07:03:59 --> Loader Class Initialized
INFO - 2022-03-21 07:03:59 --> Helper loaded: url_helper
INFO - 2022-03-21 07:03:59 --> Helper loaded: form_helper
INFO - 2022-03-21 07:03:59 --> Helper loaded: common_helper
INFO - 2022-03-21 07:03:59 --> Database Driver Class Initialized
DEBUG - 2022-03-21 07:03:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 07:03:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 07:03:59 --> Controller Class Initialized
INFO - 2022-03-21 07:03:59 --> Form Validation Class Initialized
DEBUG - 2022-03-21 07:03:59 --> Encrypt Class Initialized
INFO - 2022-03-21 07:03:59 --> Model "Patient_model" initialized
INFO - 2022-03-21 07:03:59 --> Model "Patientcase_model" initialized
INFO - 2022-03-21 07:03:59 --> Model "Prefix_master" initialized
INFO - 2022-03-21 07:03:59 --> Model "Users_model" initialized
INFO - 2022-03-21 07:03:59 --> Model "Hospital_model" initialized
INFO - 2022-03-21 07:04:00 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-21 07:04:00 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-21 07:04:00 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-21 07:04:00 --> Final output sent to browser
DEBUG - 2022-03-21 07:04:00 --> Total execution time: 0.0799
ERROR - 2022-03-21 07:04:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 07:04:33 --> Config Class Initialized
INFO - 2022-03-21 07:04:33 --> Hooks Class Initialized
DEBUG - 2022-03-21 07:04:33 --> UTF-8 Support Enabled
INFO - 2022-03-21 07:04:33 --> Utf8 Class Initialized
INFO - 2022-03-21 07:04:33 --> URI Class Initialized
INFO - 2022-03-21 07:04:33 --> Router Class Initialized
INFO - 2022-03-21 07:04:33 --> Output Class Initialized
INFO - 2022-03-21 07:04:33 --> Security Class Initialized
DEBUG - 2022-03-21 07:04:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 07:04:33 --> Input Class Initialized
INFO - 2022-03-21 07:04:33 --> Language Class Initialized
INFO - 2022-03-21 07:04:33 --> Loader Class Initialized
INFO - 2022-03-21 07:04:33 --> Helper loaded: url_helper
INFO - 2022-03-21 07:04:33 --> Helper loaded: form_helper
INFO - 2022-03-21 07:04:33 --> Helper loaded: common_helper
INFO - 2022-03-21 07:04:33 --> Database Driver Class Initialized
DEBUG - 2022-03-21 07:04:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 07:04:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 07:04:33 --> Controller Class Initialized
INFO - 2022-03-21 07:04:33 --> Form Validation Class Initialized
DEBUG - 2022-03-21 07:04:33 --> Encrypt Class Initialized
INFO - 2022-03-21 07:04:33 --> Model "Patient_model" initialized
INFO - 2022-03-21 07:04:33 --> Model "Patientcase_model" initialized
INFO - 2022-03-21 07:04:33 --> Model "Prefix_master" initialized
INFO - 2022-03-21 07:04:33 --> Model "Users_model" initialized
INFO - 2022-03-21 07:04:33 --> Model "Hospital_model" initialized
ERROR - 2022-03-21 07:04:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 07:04:34 --> Config Class Initialized
INFO - 2022-03-21 07:04:34 --> Hooks Class Initialized
DEBUG - 2022-03-21 07:04:34 --> UTF-8 Support Enabled
INFO - 2022-03-21 07:04:34 --> Utf8 Class Initialized
INFO - 2022-03-21 07:04:34 --> URI Class Initialized
INFO - 2022-03-21 07:04:34 --> Router Class Initialized
INFO - 2022-03-21 07:04:34 --> Output Class Initialized
INFO - 2022-03-21 07:04:34 --> Security Class Initialized
DEBUG - 2022-03-21 07:04:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 07:04:34 --> Input Class Initialized
INFO - 2022-03-21 07:04:34 --> Language Class Initialized
INFO - 2022-03-21 07:04:34 --> Loader Class Initialized
INFO - 2022-03-21 07:04:34 --> Helper loaded: url_helper
INFO - 2022-03-21 07:04:34 --> Helper loaded: form_helper
INFO - 2022-03-21 07:04:34 --> Helper loaded: common_helper
INFO - 2022-03-21 07:04:34 --> Database Driver Class Initialized
DEBUG - 2022-03-21 07:04:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 07:04:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 07:04:34 --> Controller Class Initialized
INFO - 2022-03-21 07:04:34 --> Form Validation Class Initialized
DEBUG - 2022-03-21 07:04:34 --> Encrypt Class Initialized
INFO - 2022-03-21 07:04:34 --> Model "Patient_model" initialized
INFO - 2022-03-21 07:04:34 --> Model "Patientcase_model" initialized
INFO - 2022-03-21 07:04:34 --> Model "Prefix_master" initialized
INFO - 2022-03-21 07:04:34 --> Model "Users_model" initialized
INFO - 2022-03-21 07:04:34 --> Model "Hospital_model" initialized
INFO - 2022-03-21 07:04:34 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-21 07:04:34 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-21 07:04:34 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-21 07:04:34 --> Final output sent to browser
DEBUG - 2022-03-21 07:04:34 --> Total execution time: 0.0972
ERROR - 2022-03-21 07:27:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 07:27:30 --> Config Class Initialized
INFO - 2022-03-21 07:27:30 --> Hooks Class Initialized
DEBUG - 2022-03-21 07:27:30 --> UTF-8 Support Enabled
INFO - 2022-03-21 07:27:30 --> Utf8 Class Initialized
INFO - 2022-03-21 07:27:30 --> URI Class Initialized
INFO - 2022-03-21 07:27:30 --> Router Class Initialized
INFO - 2022-03-21 07:27:30 --> Output Class Initialized
INFO - 2022-03-21 07:27:30 --> Security Class Initialized
DEBUG - 2022-03-21 07:27:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 07:27:30 --> Input Class Initialized
INFO - 2022-03-21 07:27:30 --> Language Class Initialized
INFO - 2022-03-21 07:27:30 --> Loader Class Initialized
INFO - 2022-03-21 07:27:30 --> Helper loaded: url_helper
INFO - 2022-03-21 07:27:30 --> Helper loaded: form_helper
INFO - 2022-03-21 07:27:30 --> Helper loaded: common_helper
INFO - 2022-03-21 07:27:30 --> Database Driver Class Initialized
DEBUG - 2022-03-21 07:27:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 07:27:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 07:27:30 --> Controller Class Initialized
INFO - 2022-03-21 07:27:30 --> Form Validation Class Initialized
DEBUG - 2022-03-21 07:27:30 --> Encrypt Class Initialized
INFO - 2022-03-21 07:27:30 --> Model "Patient_model" initialized
INFO - 2022-03-21 07:27:30 --> Model "Patientcase_model" initialized
INFO - 2022-03-21 07:27:30 --> Model "Prefix_master" initialized
INFO - 2022-03-21 07:27:30 --> Model "Users_model" initialized
INFO - 2022-03-21 07:27:30 --> Model "Hospital_model" initialized
ERROR - 2022-03-21 07:27:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 07:27:31 --> Config Class Initialized
INFO - 2022-03-21 07:27:31 --> Hooks Class Initialized
DEBUG - 2022-03-21 07:27:31 --> UTF-8 Support Enabled
INFO - 2022-03-21 07:27:31 --> Utf8 Class Initialized
INFO - 2022-03-21 07:27:31 --> URI Class Initialized
INFO - 2022-03-21 07:27:31 --> Router Class Initialized
INFO - 2022-03-21 07:27:31 --> Output Class Initialized
INFO - 2022-03-21 07:27:31 --> Security Class Initialized
DEBUG - 2022-03-21 07:27:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 07:27:31 --> Input Class Initialized
INFO - 2022-03-21 07:27:31 --> Language Class Initialized
INFO - 2022-03-21 07:27:31 --> Loader Class Initialized
INFO - 2022-03-21 07:27:31 --> Helper loaded: url_helper
INFO - 2022-03-21 07:27:31 --> Helper loaded: form_helper
INFO - 2022-03-21 07:27:31 --> Helper loaded: common_helper
INFO - 2022-03-21 07:27:31 --> Database Driver Class Initialized
DEBUG - 2022-03-21 07:27:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 07:27:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 07:27:31 --> Controller Class Initialized
INFO - 2022-03-21 07:27:31 --> Form Validation Class Initialized
DEBUG - 2022-03-21 07:27:31 --> Encrypt Class Initialized
INFO - 2022-03-21 07:27:31 --> Model "Patient_model" initialized
INFO - 2022-03-21 07:27:31 --> Model "Patientcase_model" initialized
INFO - 2022-03-21 07:27:31 --> Model "Prefix_master" initialized
INFO - 2022-03-21 07:27:31 --> Model "Users_model" initialized
INFO - 2022-03-21 07:27:31 --> Model "Hospital_model" initialized
INFO - 2022-03-21 07:27:31 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-21 07:27:31 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-21 07:27:31 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-21 07:27:31 --> Final output sent to browser
DEBUG - 2022-03-21 07:27:31 --> Total execution time: 0.0924
ERROR - 2022-03-21 07:27:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 07:27:41 --> Config Class Initialized
INFO - 2022-03-21 07:27:41 --> Hooks Class Initialized
DEBUG - 2022-03-21 07:27:41 --> UTF-8 Support Enabled
INFO - 2022-03-21 07:27:41 --> Utf8 Class Initialized
INFO - 2022-03-21 07:27:41 --> URI Class Initialized
INFO - 2022-03-21 07:27:41 --> Router Class Initialized
INFO - 2022-03-21 07:27:41 --> Output Class Initialized
INFO - 2022-03-21 07:27:41 --> Security Class Initialized
DEBUG - 2022-03-21 07:27:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 07:27:41 --> Input Class Initialized
INFO - 2022-03-21 07:27:41 --> Language Class Initialized
INFO - 2022-03-21 07:27:41 --> Loader Class Initialized
INFO - 2022-03-21 07:27:41 --> Helper loaded: url_helper
INFO - 2022-03-21 07:27:41 --> Helper loaded: form_helper
INFO - 2022-03-21 07:27:41 --> Helper loaded: common_helper
INFO - 2022-03-21 07:27:41 --> Database Driver Class Initialized
DEBUG - 2022-03-21 07:27:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 07:27:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 07:27:41 --> Controller Class Initialized
INFO - 2022-03-21 07:27:41 --> Form Validation Class Initialized
DEBUG - 2022-03-21 07:27:41 --> Encrypt Class Initialized
DEBUG - 2022-03-21 07:27:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 07:27:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-21 07:27:41 --> Email Class Initialized
INFO - 2022-03-21 07:27:41 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-21 07:27:41 --> Calendar Class Initialized
INFO - 2022-03-21 07:27:41 --> Model "Login_model" initialized
ERROR - 2022-03-21 07:27:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 07:27:41 --> Config Class Initialized
INFO - 2022-03-21 07:27:41 --> Hooks Class Initialized
DEBUG - 2022-03-21 07:27:41 --> UTF-8 Support Enabled
INFO - 2022-03-21 07:27:41 --> Utf8 Class Initialized
INFO - 2022-03-21 07:27:41 --> URI Class Initialized
INFO - 2022-03-21 07:27:41 --> Router Class Initialized
INFO - 2022-03-21 07:27:41 --> Output Class Initialized
INFO - 2022-03-21 07:27:41 --> Security Class Initialized
DEBUG - 2022-03-21 07:27:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 07:27:41 --> Input Class Initialized
INFO - 2022-03-21 07:27:41 --> Language Class Initialized
INFO - 2022-03-21 07:27:41 --> Loader Class Initialized
INFO - 2022-03-21 07:27:41 --> Helper loaded: url_helper
INFO - 2022-03-21 07:27:41 --> Helper loaded: form_helper
INFO - 2022-03-21 07:27:41 --> Helper loaded: common_helper
INFO - 2022-03-21 07:27:41 --> Database Driver Class Initialized
DEBUG - 2022-03-21 07:27:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 07:27:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 07:27:41 --> Controller Class Initialized
INFO - 2022-03-21 07:27:41 --> Form Validation Class Initialized
DEBUG - 2022-03-21 07:27:41 --> Encrypt Class Initialized
DEBUG - 2022-03-21 07:27:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 07:27:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-21 07:27:41 --> Email Class Initialized
INFO - 2022-03-21 07:27:41 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-21 07:27:41 --> Calendar Class Initialized
INFO - 2022-03-21 07:27:41 --> Model "Login_model" initialized
INFO - 2022-03-21 07:27:41 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-21 07:27:41 --> Final output sent to browser
DEBUG - 2022-03-21 07:27:41 --> Total execution time: 0.0362
ERROR - 2022-03-21 07:43:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 07:43:03 --> Config Class Initialized
INFO - 2022-03-21 07:43:03 --> Hooks Class Initialized
DEBUG - 2022-03-21 07:43:03 --> UTF-8 Support Enabled
INFO - 2022-03-21 07:43:03 --> Utf8 Class Initialized
INFO - 2022-03-21 07:43:03 --> URI Class Initialized
INFO - 2022-03-21 07:43:03 --> Router Class Initialized
INFO - 2022-03-21 07:43:03 --> Output Class Initialized
INFO - 2022-03-21 07:43:03 --> Security Class Initialized
DEBUG - 2022-03-21 07:43:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 07:43:03 --> Input Class Initialized
INFO - 2022-03-21 07:43:03 --> Language Class Initialized
INFO - 2022-03-21 07:43:03 --> Loader Class Initialized
INFO - 2022-03-21 07:43:03 --> Helper loaded: url_helper
INFO - 2022-03-21 07:43:03 --> Helper loaded: form_helper
INFO - 2022-03-21 07:43:03 --> Helper loaded: common_helper
INFO - 2022-03-21 07:43:03 --> Database Driver Class Initialized
DEBUG - 2022-03-21 07:43:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 07:43:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 07:43:03 --> Controller Class Initialized
INFO - 2022-03-21 07:43:03 --> Form Validation Class Initialized
DEBUG - 2022-03-21 07:43:03 --> Encrypt Class Initialized
INFO - 2022-03-21 07:43:03 --> Model "Patient_model" initialized
INFO - 2022-03-21 07:43:03 --> Model "Patientcase_model" initialized
INFO - 2022-03-21 07:43:03 --> Model "Prefix_master" initialized
INFO - 2022-03-21 07:43:03 --> Model "Users_model" initialized
INFO - 2022-03-21 07:43:03 --> Model "Hospital_model" initialized
INFO - 2022-03-21 07:43:03 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-21 07:43:03 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-21 07:43:03 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-21 07:43:03 --> Final output sent to browser
DEBUG - 2022-03-21 07:43:03 --> Total execution time: 0.1164
ERROR - 2022-03-21 07:43:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 07:43:05 --> Config Class Initialized
INFO - 2022-03-21 07:43:05 --> Hooks Class Initialized
DEBUG - 2022-03-21 07:43:05 --> UTF-8 Support Enabled
INFO - 2022-03-21 07:43:05 --> Utf8 Class Initialized
INFO - 2022-03-21 07:43:05 --> URI Class Initialized
INFO - 2022-03-21 07:43:05 --> Router Class Initialized
INFO - 2022-03-21 07:43:05 --> Output Class Initialized
INFO - 2022-03-21 07:43:05 --> Security Class Initialized
DEBUG - 2022-03-21 07:43:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 07:43:05 --> Input Class Initialized
INFO - 2022-03-21 07:43:05 --> Language Class Initialized
ERROR - 2022-03-21 07:43:05 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-21 07:46:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 07:46:17 --> Config Class Initialized
INFO - 2022-03-21 07:46:17 --> Hooks Class Initialized
DEBUG - 2022-03-21 07:46:17 --> UTF-8 Support Enabled
INFO - 2022-03-21 07:46:17 --> Utf8 Class Initialized
INFO - 2022-03-21 07:46:17 --> URI Class Initialized
INFO - 2022-03-21 07:46:17 --> Router Class Initialized
INFO - 2022-03-21 07:46:17 --> Output Class Initialized
INFO - 2022-03-21 07:46:17 --> Security Class Initialized
DEBUG - 2022-03-21 07:46:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 07:46:17 --> Input Class Initialized
INFO - 2022-03-21 07:46:17 --> Language Class Initialized
INFO - 2022-03-21 07:46:17 --> Loader Class Initialized
INFO - 2022-03-21 07:46:17 --> Helper loaded: url_helper
INFO - 2022-03-21 07:46:17 --> Helper loaded: form_helper
INFO - 2022-03-21 07:46:17 --> Helper loaded: common_helper
INFO - 2022-03-21 07:46:17 --> Database Driver Class Initialized
DEBUG - 2022-03-21 07:46:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 07:46:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 07:46:17 --> Controller Class Initialized
INFO - 2022-03-21 07:46:17 --> Form Validation Class Initialized
DEBUG - 2022-03-21 07:46:17 --> Encrypt Class Initialized
INFO - 2022-03-21 07:46:17 --> Model "Patient_model" initialized
INFO - 2022-03-21 07:46:17 --> Model "Patientcase_model" initialized
INFO - 2022-03-21 07:46:17 --> Model "Prefix_master" initialized
INFO - 2022-03-21 07:46:17 --> Model "Users_model" initialized
INFO - 2022-03-21 07:46:17 --> Model "Hospital_model" initialized
INFO - 2022-03-21 07:46:17 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-21 07:46:17 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-21 07:46:17 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-21 07:46:17 --> Final output sent to browser
DEBUG - 2022-03-21 07:46:17 --> Total execution time: 0.1069
ERROR - 2022-03-21 07:46:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 07:46:18 --> Config Class Initialized
INFO - 2022-03-21 07:46:18 --> Hooks Class Initialized
DEBUG - 2022-03-21 07:46:18 --> UTF-8 Support Enabled
INFO - 2022-03-21 07:46:18 --> Utf8 Class Initialized
INFO - 2022-03-21 07:46:18 --> URI Class Initialized
INFO - 2022-03-21 07:46:18 --> Router Class Initialized
INFO - 2022-03-21 07:46:18 --> Output Class Initialized
INFO - 2022-03-21 07:46:18 --> Security Class Initialized
DEBUG - 2022-03-21 07:46:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 07:46:18 --> Input Class Initialized
INFO - 2022-03-21 07:46:18 --> Language Class Initialized
ERROR - 2022-03-21 07:46:18 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-21 11:23:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 11:23:25 --> Config Class Initialized
INFO - 2022-03-21 11:23:25 --> Hooks Class Initialized
DEBUG - 2022-03-21 11:23:25 --> UTF-8 Support Enabled
INFO - 2022-03-21 11:23:25 --> Utf8 Class Initialized
INFO - 2022-03-21 11:23:25 --> URI Class Initialized
DEBUG - 2022-03-21 11:23:25 --> No URI present. Default controller set.
INFO - 2022-03-21 11:23:25 --> Router Class Initialized
INFO - 2022-03-21 11:23:25 --> Output Class Initialized
INFO - 2022-03-21 11:23:25 --> Security Class Initialized
DEBUG - 2022-03-21 11:23:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 11:23:25 --> Input Class Initialized
INFO - 2022-03-21 11:23:25 --> Language Class Initialized
INFO - 2022-03-21 11:23:25 --> Loader Class Initialized
INFO - 2022-03-21 11:23:25 --> Helper loaded: url_helper
INFO - 2022-03-21 11:23:25 --> Helper loaded: form_helper
INFO - 2022-03-21 11:23:25 --> Helper loaded: common_helper
INFO - 2022-03-21 11:23:25 --> Database Driver Class Initialized
DEBUG - 2022-03-21 11:23:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 11:23:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 11:23:25 --> Controller Class Initialized
INFO - 2022-03-21 11:23:25 --> Form Validation Class Initialized
DEBUG - 2022-03-21 11:23:25 --> Encrypt Class Initialized
DEBUG - 2022-03-21 11:23:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 11:23:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-21 11:23:25 --> Email Class Initialized
INFO - 2022-03-21 11:23:25 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-21 11:23:25 --> Calendar Class Initialized
INFO - 2022-03-21 11:23:25 --> Model "Login_model" initialized
INFO - 2022-03-21 11:23:25 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-21 11:23:25 --> Final output sent to browser
DEBUG - 2022-03-21 11:23:25 --> Total execution time: 0.0407
ERROR - 2022-03-21 11:31:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 11:31:54 --> Config Class Initialized
INFO - 2022-03-21 11:31:54 --> Hooks Class Initialized
DEBUG - 2022-03-21 11:31:54 --> UTF-8 Support Enabled
INFO - 2022-03-21 11:31:54 --> Utf8 Class Initialized
INFO - 2022-03-21 11:31:54 --> URI Class Initialized
DEBUG - 2022-03-21 11:31:54 --> No URI present. Default controller set.
INFO - 2022-03-21 11:31:54 --> Router Class Initialized
INFO - 2022-03-21 11:31:54 --> Output Class Initialized
INFO - 2022-03-21 11:31:54 --> Security Class Initialized
DEBUG - 2022-03-21 11:31:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 11:31:54 --> Input Class Initialized
INFO - 2022-03-21 11:31:54 --> Language Class Initialized
INFO - 2022-03-21 11:31:54 --> Loader Class Initialized
INFO - 2022-03-21 11:31:54 --> Helper loaded: url_helper
INFO - 2022-03-21 11:31:54 --> Helper loaded: form_helper
INFO - 2022-03-21 11:31:54 --> Helper loaded: common_helper
INFO - 2022-03-21 11:31:54 --> Database Driver Class Initialized
DEBUG - 2022-03-21 11:31:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 11:31:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 11:31:54 --> Controller Class Initialized
INFO - 2022-03-21 11:31:54 --> Form Validation Class Initialized
DEBUG - 2022-03-21 11:31:54 --> Encrypt Class Initialized
DEBUG - 2022-03-21 11:31:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 11:31:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-21 11:31:54 --> Email Class Initialized
INFO - 2022-03-21 11:31:54 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-21 11:31:54 --> Calendar Class Initialized
INFO - 2022-03-21 11:31:54 --> Model "Login_model" initialized
INFO - 2022-03-21 11:31:54 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-21 11:31:54 --> Final output sent to browser
DEBUG - 2022-03-21 11:31:54 --> Total execution time: 0.0370
ERROR - 2022-03-21 11:31:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 11:31:57 --> Config Class Initialized
INFO - 2022-03-21 11:31:57 --> Hooks Class Initialized
DEBUG - 2022-03-21 11:31:57 --> UTF-8 Support Enabled
INFO - 2022-03-21 11:31:57 --> Utf8 Class Initialized
INFO - 2022-03-21 11:31:57 --> URI Class Initialized
DEBUG - 2022-03-21 11:31:57 --> No URI present. Default controller set.
INFO - 2022-03-21 11:31:57 --> Router Class Initialized
INFO - 2022-03-21 11:31:57 --> Output Class Initialized
INFO - 2022-03-21 11:31:57 --> Security Class Initialized
DEBUG - 2022-03-21 11:31:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 11:31:57 --> Input Class Initialized
INFO - 2022-03-21 11:31:57 --> Language Class Initialized
INFO - 2022-03-21 11:31:57 --> Loader Class Initialized
INFO - 2022-03-21 11:31:57 --> Helper loaded: url_helper
INFO - 2022-03-21 11:31:57 --> Helper loaded: form_helper
INFO - 2022-03-21 11:31:57 --> Helper loaded: common_helper
INFO - 2022-03-21 11:31:57 --> Database Driver Class Initialized
DEBUG - 2022-03-21 11:31:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 11:31:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 11:31:57 --> Controller Class Initialized
INFO - 2022-03-21 11:31:57 --> Form Validation Class Initialized
DEBUG - 2022-03-21 11:31:57 --> Encrypt Class Initialized
DEBUG - 2022-03-21 11:31:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 11:31:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-21 11:31:57 --> Email Class Initialized
INFO - 2022-03-21 11:31:57 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-21 11:31:57 --> Calendar Class Initialized
INFO - 2022-03-21 11:31:57 --> Model "Login_model" initialized
INFO - 2022-03-21 11:31:57 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-21 11:31:57 --> Final output sent to browser
DEBUG - 2022-03-21 11:31:57 --> Total execution time: 0.0502
ERROR - 2022-03-21 12:23:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 12:23:31 --> Config Class Initialized
INFO - 2022-03-21 12:23:31 --> Hooks Class Initialized
DEBUG - 2022-03-21 12:23:31 --> UTF-8 Support Enabled
INFO - 2022-03-21 12:23:31 --> Utf8 Class Initialized
INFO - 2022-03-21 12:23:31 --> URI Class Initialized
DEBUG - 2022-03-21 12:23:31 --> No URI present. Default controller set.
INFO - 2022-03-21 12:23:31 --> Router Class Initialized
INFO - 2022-03-21 12:23:31 --> Output Class Initialized
INFO - 2022-03-21 12:23:31 --> Security Class Initialized
DEBUG - 2022-03-21 12:23:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 12:23:31 --> Input Class Initialized
INFO - 2022-03-21 12:23:31 --> Language Class Initialized
INFO - 2022-03-21 12:23:31 --> Loader Class Initialized
INFO - 2022-03-21 12:23:31 --> Helper loaded: url_helper
INFO - 2022-03-21 12:23:31 --> Helper loaded: form_helper
INFO - 2022-03-21 12:23:31 --> Helper loaded: common_helper
INFO - 2022-03-21 12:23:31 --> Database Driver Class Initialized
DEBUG - 2022-03-21 12:23:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 12:23:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 12:23:31 --> Controller Class Initialized
INFO - 2022-03-21 12:23:31 --> Form Validation Class Initialized
DEBUG - 2022-03-21 12:23:31 --> Encrypt Class Initialized
DEBUG - 2022-03-21 12:23:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 12:23:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-21 12:23:31 --> Email Class Initialized
INFO - 2022-03-21 12:23:31 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-21 12:23:31 --> Calendar Class Initialized
INFO - 2022-03-21 12:23:31 --> Model "Login_model" initialized
INFO - 2022-03-21 12:23:31 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-21 12:23:31 --> Final output sent to browser
DEBUG - 2022-03-21 12:23:31 --> Total execution time: 0.0333
ERROR - 2022-03-21 12:23:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 12:23:32 --> Config Class Initialized
INFO - 2022-03-21 12:23:32 --> Hooks Class Initialized
DEBUG - 2022-03-21 12:23:32 --> UTF-8 Support Enabled
INFO - 2022-03-21 12:23:32 --> Utf8 Class Initialized
INFO - 2022-03-21 12:23:32 --> URI Class Initialized
DEBUG - 2022-03-21 12:23:32 --> No URI present. Default controller set.
INFO - 2022-03-21 12:23:32 --> Router Class Initialized
INFO - 2022-03-21 12:23:32 --> Output Class Initialized
INFO - 2022-03-21 12:23:32 --> Security Class Initialized
DEBUG - 2022-03-21 12:23:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 12:23:32 --> Input Class Initialized
INFO - 2022-03-21 12:23:32 --> Language Class Initialized
INFO - 2022-03-21 12:23:32 --> Loader Class Initialized
INFO - 2022-03-21 12:23:32 --> Helper loaded: url_helper
INFO - 2022-03-21 12:23:32 --> Helper loaded: form_helper
INFO - 2022-03-21 12:23:32 --> Helper loaded: common_helper
INFO - 2022-03-21 12:23:32 --> Database Driver Class Initialized
DEBUG - 2022-03-21 12:23:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 12:23:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 12:23:32 --> Controller Class Initialized
INFO - 2022-03-21 12:23:32 --> Form Validation Class Initialized
DEBUG - 2022-03-21 12:23:32 --> Encrypt Class Initialized
DEBUG - 2022-03-21 12:23:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 12:23:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-21 12:23:32 --> Email Class Initialized
INFO - 2022-03-21 12:23:32 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-21 12:23:32 --> Calendar Class Initialized
INFO - 2022-03-21 12:23:32 --> Model "Login_model" initialized
INFO - 2022-03-21 12:23:32 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-21 12:23:32 --> Final output sent to browser
DEBUG - 2022-03-21 12:23:32 --> Total execution time: 0.0320
ERROR - 2022-03-21 12:23:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 12:23:33 --> Config Class Initialized
INFO - 2022-03-21 12:23:33 --> Hooks Class Initialized
DEBUG - 2022-03-21 12:23:33 --> UTF-8 Support Enabled
INFO - 2022-03-21 12:23:33 --> Utf8 Class Initialized
INFO - 2022-03-21 12:23:33 --> URI Class Initialized
INFO - 2022-03-21 12:23:33 --> Router Class Initialized
INFO - 2022-03-21 12:23:33 --> Output Class Initialized
INFO - 2022-03-21 12:23:33 --> Security Class Initialized
DEBUG - 2022-03-21 12:23:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 12:23:33 --> Input Class Initialized
INFO - 2022-03-21 12:23:33 --> Language Class Initialized
ERROR - 2022-03-21 12:23:33 --> 404 Page Not Found: Blog/wp-includes
ERROR - 2022-03-21 12:23:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 12:23:33 --> Config Class Initialized
INFO - 2022-03-21 12:23:33 --> Hooks Class Initialized
DEBUG - 2022-03-21 12:23:33 --> UTF-8 Support Enabled
INFO - 2022-03-21 12:23:33 --> Utf8 Class Initialized
INFO - 2022-03-21 12:23:33 --> URI Class Initialized
INFO - 2022-03-21 12:23:33 --> Router Class Initialized
INFO - 2022-03-21 12:23:33 --> Output Class Initialized
INFO - 2022-03-21 12:23:33 --> Security Class Initialized
DEBUG - 2022-03-21 12:23:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 12:23:33 --> Input Class Initialized
INFO - 2022-03-21 12:23:33 --> Language Class Initialized
ERROR - 2022-03-21 12:23:33 --> 404 Page Not Found: Web/wp-includes
ERROR - 2022-03-21 12:23:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 12:23:34 --> Config Class Initialized
INFO - 2022-03-21 12:23:34 --> Hooks Class Initialized
DEBUG - 2022-03-21 12:23:34 --> UTF-8 Support Enabled
INFO - 2022-03-21 12:23:34 --> Utf8 Class Initialized
INFO - 2022-03-21 12:23:34 --> URI Class Initialized
INFO - 2022-03-21 12:23:34 --> Router Class Initialized
INFO - 2022-03-21 12:23:34 --> Output Class Initialized
INFO - 2022-03-21 12:23:34 --> Security Class Initialized
DEBUG - 2022-03-21 12:23:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 12:23:34 --> Input Class Initialized
INFO - 2022-03-21 12:23:34 --> Language Class Initialized
ERROR - 2022-03-21 12:23:34 --> 404 Page Not Found: Wordpress/wp-includes
ERROR - 2022-03-21 12:23:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 12:23:34 --> Config Class Initialized
INFO - 2022-03-21 12:23:34 --> Hooks Class Initialized
DEBUG - 2022-03-21 12:23:34 --> UTF-8 Support Enabled
INFO - 2022-03-21 12:23:34 --> Utf8 Class Initialized
INFO - 2022-03-21 12:23:34 --> URI Class Initialized
INFO - 2022-03-21 12:23:34 --> Router Class Initialized
INFO - 2022-03-21 12:23:34 --> Output Class Initialized
INFO - 2022-03-21 12:23:34 --> Security Class Initialized
DEBUG - 2022-03-21 12:23:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 12:23:34 --> Input Class Initialized
INFO - 2022-03-21 12:23:34 --> Language Class Initialized
ERROR - 2022-03-21 12:23:34 --> 404 Page Not Found: Website/wp-includes
ERROR - 2022-03-21 12:23:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 12:23:34 --> Config Class Initialized
INFO - 2022-03-21 12:23:34 --> Hooks Class Initialized
DEBUG - 2022-03-21 12:23:34 --> UTF-8 Support Enabled
INFO - 2022-03-21 12:23:34 --> Utf8 Class Initialized
INFO - 2022-03-21 12:23:34 --> URI Class Initialized
INFO - 2022-03-21 12:23:34 --> Router Class Initialized
INFO - 2022-03-21 12:23:34 --> Output Class Initialized
INFO - 2022-03-21 12:23:34 --> Security Class Initialized
DEBUG - 2022-03-21 12:23:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 12:23:34 --> Input Class Initialized
INFO - 2022-03-21 12:23:34 --> Language Class Initialized
ERROR - 2022-03-21 12:23:34 --> 404 Page Not Found: Wp/wp-includes
ERROR - 2022-03-21 12:23:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 12:23:35 --> Config Class Initialized
INFO - 2022-03-21 12:23:35 --> Hooks Class Initialized
DEBUG - 2022-03-21 12:23:35 --> UTF-8 Support Enabled
INFO - 2022-03-21 12:23:35 --> Utf8 Class Initialized
INFO - 2022-03-21 12:23:35 --> URI Class Initialized
INFO - 2022-03-21 12:23:35 --> Router Class Initialized
INFO - 2022-03-21 12:23:35 --> Output Class Initialized
INFO - 2022-03-21 12:23:35 --> Security Class Initialized
DEBUG - 2022-03-21 12:23:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 12:23:35 --> Input Class Initialized
INFO - 2022-03-21 12:23:35 --> Language Class Initialized
ERROR - 2022-03-21 12:23:35 --> 404 Page Not Found: News/wp-includes
ERROR - 2022-03-21 12:23:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 12:23:35 --> Config Class Initialized
INFO - 2022-03-21 12:23:35 --> Hooks Class Initialized
DEBUG - 2022-03-21 12:23:35 --> UTF-8 Support Enabled
INFO - 2022-03-21 12:23:35 --> Utf8 Class Initialized
INFO - 2022-03-21 12:23:35 --> URI Class Initialized
INFO - 2022-03-21 12:23:35 --> Router Class Initialized
INFO - 2022-03-21 12:23:35 --> Output Class Initialized
INFO - 2022-03-21 12:23:35 --> Security Class Initialized
DEBUG - 2022-03-21 12:23:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 12:23:35 --> Input Class Initialized
INFO - 2022-03-21 12:23:35 --> Language Class Initialized
ERROR - 2022-03-21 12:23:35 --> 404 Page Not Found: 2020/wp-includes
ERROR - 2022-03-21 12:23:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 12:23:36 --> Config Class Initialized
INFO - 2022-03-21 12:23:36 --> Hooks Class Initialized
DEBUG - 2022-03-21 12:23:36 --> UTF-8 Support Enabled
INFO - 2022-03-21 12:23:36 --> Utf8 Class Initialized
INFO - 2022-03-21 12:23:36 --> URI Class Initialized
INFO - 2022-03-21 12:23:36 --> Router Class Initialized
INFO - 2022-03-21 12:23:36 --> Output Class Initialized
INFO - 2022-03-21 12:23:36 --> Security Class Initialized
DEBUG - 2022-03-21 12:23:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 12:23:36 --> Input Class Initialized
INFO - 2022-03-21 12:23:36 --> Language Class Initialized
ERROR - 2022-03-21 12:23:36 --> 404 Page Not Found: 2019/wp-includes
ERROR - 2022-03-21 12:23:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 12:23:36 --> Config Class Initialized
INFO - 2022-03-21 12:23:36 --> Hooks Class Initialized
DEBUG - 2022-03-21 12:23:36 --> UTF-8 Support Enabled
INFO - 2022-03-21 12:23:36 --> Utf8 Class Initialized
INFO - 2022-03-21 12:23:36 --> URI Class Initialized
INFO - 2022-03-21 12:23:36 --> Router Class Initialized
INFO - 2022-03-21 12:23:36 --> Output Class Initialized
INFO - 2022-03-21 12:23:36 --> Security Class Initialized
DEBUG - 2022-03-21 12:23:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 12:23:36 --> Input Class Initialized
INFO - 2022-03-21 12:23:36 --> Language Class Initialized
ERROR - 2022-03-21 12:23:36 --> 404 Page Not Found: Shop/wp-includes
ERROR - 2022-03-21 12:23:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 12:23:37 --> Config Class Initialized
INFO - 2022-03-21 12:23:37 --> Hooks Class Initialized
DEBUG - 2022-03-21 12:23:37 --> UTF-8 Support Enabled
INFO - 2022-03-21 12:23:37 --> Utf8 Class Initialized
INFO - 2022-03-21 12:23:37 --> URI Class Initialized
INFO - 2022-03-21 12:23:37 --> Router Class Initialized
INFO - 2022-03-21 12:23:37 --> Output Class Initialized
INFO - 2022-03-21 12:23:37 --> Security Class Initialized
DEBUG - 2022-03-21 12:23:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 12:23:37 --> Input Class Initialized
INFO - 2022-03-21 12:23:37 --> Language Class Initialized
ERROR - 2022-03-21 12:23:37 --> 404 Page Not Found: Wp1/wp-includes
ERROR - 2022-03-21 12:23:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 12:23:38 --> Config Class Initialized
INFO - 2022-03-21 12:23:38 --> Hooks Class Initialized
DEBUG - 2022-03-21 12:23:38 --> UTF-8 Support Enabled
INFO - 2022-03-21 12:23:38 --> Utf8 Class Initialized
INFO - 2022-03-21 12:23:38 --> URI Class Initialized
INFO - 2022-03-21 12:23:38 --> Router Class Initialized
INFO - 2022-03-21 12:23:38 --> Output Class Initialized
INFO - 2022-03-21 12:23:38 --> Security Class Initialized
DEBUG - 2022-03-21 12:23:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 12:23:38 --> Input Class Initialized
INFO - 2022-03-21 12:23:38 --> Language Class Initialized
ERROR - 2022-03-21 12:23:38 --> 404 Page Not Found: Test/wp-includes
ERROR - 2022-03-21 12:23:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 12:23:38 --> Config Class Initialized
INFO - 2022-03-21 12:23:38 --> Hooks Class Initialized
DEBUG - 2022-03-21 12:23:38 --> UTF-8 Support Enabled
INFO - 2022-03-21 12:23:38 --> Utf8 Class Initialized
INFO - 2022-03-21 12:23:38 --> URI Class Initialized
INFO - 2022-03-21 12:23:38 --> Router Class Initialized
INFO - 2022-03-21 12:23:38 --> Output Class Initialized
INFO - 2022-03-21 12:23:38 --> Security Class Initialized
DEBUG - 2022-03-21 12:23:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 12:23:38 --> Input Class Initialized
INFO - 2022-03-21 12:23:38 --> Language Class Initialized
ERROR - 2022-03-21 12:23:38 --> 404 Page Not Found: Wp2/wp-includes
ERROR - 2022-03-21 12:23:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 12:23:39 --> Config Class Initialized
INFO - 2022-03-21 12:23:39 --> Hooks Class Initialized
DEBUG - 2022-03-21 12:23:39 --> UTF-8 Support Enabled
INFO - 2022-03-21 12:23:39 --> Utf8 Class Initialized
INFO - 2022-03-21 12:23:39 --> URI Class Initialized
INFO - 2022-03-21 12:23:39 --> Router Class Initialized
INFO - 2022-03-21 12:23:39 --> Output Class Initialized
INFO - 2022-03-21 12:23:39 --> Security Class Initialized
DEBUG - 2022-03-21 12:23:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 12:23:39 --> Input Class Initialized
INFO - 2022-03-21 12:23:39 --> Language Class Initialized
ERROR - 2022-03-21 12:23:39 --> 404 Page Not Found: Site/wp-includes
ERROR - 2022-03-21 12:23:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 12:23:39 --> Config Class Initialized
INFO - 2022-03-21 12:23:39 --> Hooks Class Initialized
DEBUG - 2022-03-21 12:23:39 --> UTF-8 Support Enabled
INFO - 2022-03-21 12:23:39 --> Utf8 Class Initialized
INFO - 2022-03-21 12:23:39 --> URI Class Initialized
INFO - 2022-03-21 12:23:39 --> Router Class Initialized
INFO - 2022-03-21 12:23:39 --> Output Class Initialized
INFO - 2022-03-21 12:23:39 --> Security Class Initialized
DEBUG - 2022-03-21 12:23:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 12:23:39 --> Input Class Initialized
INFO - 2022-03-21 12:23:39 --> Language Class Initialized
ERROR - 2022-03-21 12:23:39 --> 404 Page Not Found: Cms/wp-includes
ERROR - 2022-03-21 12:23:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 12:23:40 --> Config Class Initialized
INFO - 2022-03-21 12:23:40 --> Hooks Class Initialized
DEBUG - 2022-03-21 12:23:40 --> UTF-8 Support Enabled
INFO - 2022-03-21 12:23:40 --> Utf8 Class Initialized
INFO - 2022-03-21 12:23:40 --> URI Class Initialized
INFO - 2022-03-21 12:23:40 --> Router Class Initialized
INFO - 2022-03-21 12:23:40 --> Output Class Initialized
INFO - 2022-03-21 12:23:40 --> Security Class Initialized
DEBUG - 2022-03-21 12:23:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 12:23:40 --> Input Class Initialized
INFO - 2022-03-21 12:23:40 --> Language Class Initialized
ERROR - 2022-03-21 12:23:40 --> 404 Page Not Found: Sito/wp-includes
ERROR - 2022-03-21 14:21:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 14:21:57 --> Config Class Initialized
INFO - 2022-03-21 14:21:57 --> Hooks Class Initialized
DEBUG - 2022-03-21 14:21:57 --> UTF-8 Support Enabled
INFO - 2022-03-21 14:21:57 --> Utf8 Class Initialized
INFO - 2022-03-21 14:21:57 --> URI Class Initialized
DEBUG - 2022-03-21 14:21:57 --> No URI present. Default controller set.
INFO - 2022-03-21 14:21:57 --> Router Class Initialized
INFO - 2022-03-21 14:21:57 --> Output Class Initialized
INFO - 2022-03-21 14:21:57 --> Security Class Initialized
DEBUG - 2022-03-21 14:21:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 14:21:57 --> Input Class Initialized
INFO - 2022-03-21 14:21:57 --> Language Class Initialized
INFO - 2022-03-21 14:21:57 --> Loader Class Initialized
INFO - 2022-03-21 14:21:57 --> Helper loaded: url_helper
INFO - 2022-03-21 14:21:57 --> Helper loaded: form_helper
INFO - 2022-03-21 14:21:57 --> Helper loaded: common_helper
INFO - 2022-03-21 14:21:57 --> Database Driver Class Initialized
DEBUG - 2022-03-21 14:21:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 14:21:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 14:21:57 --> Controller Class Initialized
INFO - 2022-03-21 14:21:57 --> Form Validation Class Initialized
DEBUG - 2022-03-21 14:21:57 --> Encrypt Class Initialized
DEBUG - 2022-03-21 14:21:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 14:21:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-21 14:21:57 --> Email Class Initialized
INFO - 2022-03-21 14:21:57 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-21 14:21:57 --> Calendar Class Initialized
INFO - 2022-03-21 14:21:57 --> Model "Login_model" initialized
INFO - 2022-03-21 14:21:57 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-21 14:21:57 --> Final output sent to browser
DEBUG - 2022-03-21 14:21:57 --> Total execution time: 0.0559
ERROR - 2022-03-21 14:21:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 14:21:58 --> Config Class Initialized
INFO - 2022-03-21 14:21:58 --> Hooks Class Initialized
DEBUG - 2022-03-21 14:21:58 --> UTF-8 Support Enabled
INFO - 2022-03-21 14:21:58 --> Utf8 Class Initialized
INFO - 2022-03-21 14:21:58 --> URI Class Initialized
INFO - 2022-03-21 14:21:58 --> Router Class Initialized
INFO - 2022-03-21 14:21:58 --> Output Class Initialized
INFO - 2022-03-21 14:21:58 --> Security Class Initialized
DEBUG - 2022-03-21 14:21:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 14:21:58 --> Input Class Initialized
INFO - 2022-03-21 14:21:58 --> Language Class Initialized
ERROR - 2022-03-21 14:21:58 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2022-03-21 14:22:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 14:22:14 --> Config Class Initialized
INFO - 2022-03-21 14:22:14 --> Hooks Class Initialized
DEBUG - 2022-03-21 14:22:14 --> UTF-8 Support Enabled
INFO - 2022-03-21 14:22:14 --> Utf8 Class Initialized
INFO - 2022-03-21 14:22:14 --> URI Class Initialized
DEBUG - 2022-03-21 14:22:14 --> No URI present. Default controller set.
INFO - 2022-03-21 14:22:14 --> Router Class Initialized
INFO - 2022-03-21 14:22:14 --> Output Class Initialized
INFO - 2022-03-21 14:22:14 --> Security Class Initialized
DEBUG - 2022-03-21 14:22:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 14:22:14 --> Input Class Initialized
INFO - 2022-03-21 14:22:14 --> Language Class Initialized
INFO - 2022-03-21 14:22:14 --> Loader Class Initialized
INFO - 2022-03-21 14:22:14 --> Helper loaded: url_helper
INFO - 2022-03-21 14:22:14 --> Helper loaded: form_helper
INFO - 2022-03-21 14:22:14 --> Helper loaded: common_helper
INFO - 2022-03-21 14:22:14 --> Database Driver Class Initialized
DEBUG - 2022-03-21 14:22:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 14:22:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 14:22:14 --> Controller Class Initialized
INFO - 2022-03-21 14:22:14 --> Form Validation Class Initialized
DEBUG - 2022-03-21 14:22:14 --> Encrypt Class Initialized
DEBUG - 2022-03-21 14:22:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 14:22:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-21 14:22:14 --> Email Class Initialized
INFO - 2022-03-21 14:22:14 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-21 14:22:14 --> Calendar Class Initialized
INFO - 2022-03-21 14:22:14 --> Model "Login_model" initialized
INFO - 2022-03-21 14:22:14 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-21 14:22:14 --> Final output sent to browser
DEBUG - 2022-03-21 14:22:14 --> Total execution time: 0.0405
ERROR - 2022-03-21 14:22:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 14:22:15 --> Config Class Initialized
INFO - 2022-03-21 14:22:15 --> Hooks Class Initialized
DEBUG - 2022-03-21 14:22:15 --> UTF-8 Support Enabled
INFO - 2022-03-21 14:22:15 --> Utf8 Class Initialized
INFO - 2022-03-21 14:22:15 --> URI Class Initialized
INFO - 2022-03-21 14:22:15 --> Router Class Initialized
INFO - 2022-03-21 14:22:15 --> Output Class Initialized
INFO - 2022-03-21 14:22:15 --> Security Class Initialized
DEBUG - 2022-03-21 14:22:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 14:22:15 --> Input Class Initialized
INFO - 2022-03-21 14:22:15 --> Language Class Initialized
INFO - 2022-03-21 14:22:15 --> Loader Class Initialized
INFO - 2022-03-21 14:22:15 --> Helper loaded: url_helper
INFO - 2022-03-21 14:22:15 --> Helper loaded: form_helper
INFO - 2022-03-21 14:22:15 --> Helper loaded: common_helper
INFO - 2022-03-21 14:22:15 --> Database Driver Class Initialized
DEBUG - 2022-03-21 14:22:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 14:22:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 14:22:15 --> Controller Class Initialized
INFO - 2022-03-21 14:22:15 --> Form Validation Class Initialized
DEBUG - 2022-03-21 14:22:15 --> Encrypt Class Initialized
DEBUG - 2022-03-21 14:22:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 14:22:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-21 14:22:15 --> Email Class Initialized
INFO - 2022-03-21 14:22:15 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-21 14:22:15 --> Calendar Class Initialized
INFO - 2022-03-21 14:22:15 --> Model "Login_model" initialized
INFO - 2022-03-21 14:22:15 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-21 14:22:15 --> Final output sent to browser
DEBUG - 2022-03-21 14:22:15 --> Total execution time: 0.0246
ERROR - 2022-03-21 14:22:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 14:22:16 --> Config Class Initialized
INFO - 2022-03-21 14:22:16 --> Hooks Class Initialized
DEBUG - 2022-03-21 14:22:16 --> UTF-8 Support Enabled
INFO - 2022-03-21 14:22:16 --> Utf8 Class Initialized
INFO - 2022-03-21 14:22:16 --> URI Class Initialized
INFO - 2022-03-21 14:22:16 --> Router Class Initialized
INFO - 2022-03-21 14:22:16 --> Output Class Initialized
INFO - 2022-03-21 14:22:16 --> Security Class Initialized
DEBUG - 2022-03-21 14:22:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 14:22:16 --> Input Class Initialized
INFO - 2022-03-21 14:22:16 --> Language Class Initialized
INFO - 2022-03-21 14:22:16 --> Loader Class Initialized
INFO - 2022-03-21 14:22:16 --> Helper loaded: url_helper
INFO - 2022-03-21 14:22:16 --> Helper loaded: form_helper
INFO - 2022-03-21 14:22:16 --> Helper loaded: common_helper
INFO - 2022-03-21 14:22:16 --> Database Driver Class Initialized
DEBUG - 2022-03-21 14:22:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 14:22:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 14:22:16 --> Controller Class Initialized
INFO - 2022-03-21 14:22:16 --> Form Validation Class Initialized
DEBUG - 2022-03-21 14:22:16 --> Encrypt Class Initialized
DEBUG - 2022-03-21 14:22:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 14:22:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-21 14:22:16 --> Email Class Initialized
INFO - 2022-03-21 14:22:16 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-21 14:22:16 --> Calendar Class Initialized
INFO - 2022-03-21 14:22:16 --> Model "Login_model" initialized
ERROR - 2022-03-21 14:22:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 14:22:16 --> Config Class Initialized
INFO - 2022-03-21 14:22:16 --> Hooks Class Initialized
DEBUG - 2022-03-21 14:22:16 --> UTF-8 Support Enabled
INFO - 2022-03-21 14:22:16 --> Utf8 Class Initialized
INFO - 2022-03-21 14:22:16 --> URI Class Initialized
INFO - 2022-03-21 14:22:16 --> Router Class Initialized
INFO - 2022-03-21 14:22:16 --> Output Class Initialized
INFO - 2022-03-21 14:22:16 --> Security Class Initialized
DEBUG - 2022-03-21 14:22:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 14:22:16 --> Input Class Initialized
INFO - 2022-03-21 14:22:16 --> Language Class Initialized
INFO - 2022-03-21 14:22:16 --> Loader Class Initialized
INFO - 2022-03-21 14:22:16 --> Helper loaded: url_helper
INFO - 2022-03-21 14:22:16 --> Helper loaded: form_helper
INFO - 2022-03-21 14:22:16 --> Helper loaded: common_helper
INFO - 2022-03-21 14:22:16 --> Database Driver Class Initialized
DEBUG - 2022-03-21 14:22:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 14:22:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 14:22:16 --> Controller Class Initialized
INFO - 2022-03-21 14:22:16 --> Form Validation Class Initialized
DEBUG - 2022-03-21 14:22:16 --> Encrypt Class Initialized
DEBUG - 2022-03-21 14:22:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 14:22:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-21 14:22:16 --> Email Class Initialized
INFO - 2022-03-21 14:22:16 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-21 14:22:16 --> Calendar Class Initialized
INFO - 2022-03-21 14:22:16 --> Model "Login_model" initialized
ERROR - 2022-03-21 14:47:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 14:47:25 --> Config Class Initialized
INFO - 2022-03-21 14:47:25 --> Hooks Class Initialized
DEBUG - 2022-03-21 14:47:25 --> UTF-8 Support Enabled
INFO - 2022-03-21 14:47:25 --> Utf8 Class Initialized
INFO - 2022-03-21 14:47:25 --> URI Class Initialized
DEBUG - 2022-03-21 14:47:25 --> No URI present. Default controller set.
INFO - 2022-03-21 14:47:25 --> Router Class Initialized
INFO - 2022-03-21 14:47:25 --> Output Class Initialized
INFO - 2022-03-21 14:47:25 --> Security Class Initialized
DEBUG - 2022-03-21 14:47:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 14:47:25 --> Input Class Initialized
INFO - 2022-03-21 14:47:25 --> Language Class Initialized
INFO - 2022-03-21 14:47:25 --> Loader Class Initialized
INFO - 2022-03-21 14:47:25 --> Helper loaded: url_helper
INFO - 2022-03-21 14:47:25 --> Helper loaded: form_helper
INFO - 2022-03-21 14:47:25 --> Helper loaded: common_helper
INFO - 2022-03-21 14:47:25 --> Database Driver Class Initialized
DEBUG - 2022-03-21 14:47:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 14:47:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 14:47:25 --> Controller Class Initialized
INFO - 2022-03-21 14:47:25 --> Form Validation Class Initialized
DEBUG - 2022-03-21 14:47:25 --> Encrypt Class Initialized
DEBUG - 2022-03-21 14:47:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 14:47:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-21 14:47:25 --> Email Class Initialized
INFO - 2022-03-21 14:47:25 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-21 14:47:25 --> Calendar Class Initialized
INFO - 2022-03-21 14:47:25 --> Model "Login_model" initialized
INFO - 2022-03-21 14:47:25 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-21 14:47:25 --> Final output sent to browser
DEBUG - 2022-03-21 14:47:25 --> Total execution time: 0.0557
ERROR - 2022-03-21 17:29:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 17:29:47 --> Config Class Initialized
INFO - 2022-03-21 17:29:47 --> Hooks Class Initialized
DEBUG - 2022-03-21 17:29:47 --> UTF-8 Support Enabled
INFO - 2022-03-21 17:29:47 --> Utf8 Class Initialized
INFO - 2022-03-21 17:29:47 --> URI Class Initialized
DEBUG - 2022-03-21 17:29:47 --> No URI present. Default controller set.
INFO - 2022-03-21 17:29:47 --> Router Class Initialized
INFO - 2022-03-21 17:29:47 --> Output Class Initialized
INFO - 2022-03-21 17:29:47 --> Security Class Initialized
DEBUG - 2022-03-21 17:29:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 17:29:47 --> Input Class Initialized
INFO - 2022-03-21 17:29:47 --> Language Class Initialized
INFO - 2022-03-21 17:29:47 --> Loader Class Initialized
INFO - 2022-03-21 17:29:47 --> Helper loaded: url_helper
INFO - 2022-03-21 17:29:47 --> Helper loaded: form_helper
INFO - 2022-03-21 17:29:47 --> Helper loaded: common_helper
INFO - 2022-03-21 17:29:47 --> Database Driver Class Initialized
DEBUG - 2022-03-21 17:29:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 17:29:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 17:29:47 --> Controller Class Initialized
INFO - 2022-03-21 17:29:47 --> Form Validation Class Initialized
DEBUG - 2022-03-21 17:29:47 --> Encrypt Class Initialized
DEBUG - 2022-03-21 17:29:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 17:29:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-21 17:29:47 --> Email Class Initialized
INFO - 2022-03-21 17:29:47 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-21 17:29:47 --> Calendar Class Initialized
INFO - 2022-03-21 17:29:47 --> Model "Login_model" initialized
INFO - 2022-03-21 17:29:47 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-21 17:29:47 --> Final output sent to browser
DEBUG - 2022-03-21 17:29:47 --> Total execution time: 0.0364
ERROR - 2022-03-21 17:33:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 17:33:35 --> Config Class Initialized
INFO - 2022-03-21 17:33:35 --> Hooks Class Initialized
DEBUG - 2022-03-21 17:33:35 --> UTF-8 Support Enabled
INFO - 2022-03-21 17:33:35 --> Utf8 Class Initialized
INFO - 2022-03-21 17:33:35 --> URI Class Initialized
DEBUG - 2022-03-21 17:33:35 --> No URI present. Default controller set.
INFO - 2022-03-21 17:33:35 --> Router Class Initialized
INFO - 2022-03-21 17:33:35 --> Output Class Initialized
INFO - 2022-03-21 17:33:35 --> Security Class Initialized
DEBUG - 2022-03-21 17:33:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 17:33:35 --> Input Class Initialized
INFO - 2022-03-21 17:33:35 --> Language Class Initialized
INFO - 2022-03-21 17:33:35 --> Loader Class Initialized
INFO - 2022-03-21 17:33:35 --> Helper loaded: url_helper
INFO - 2022-03-21 17:33:35 --> Helper loaded: form_helper
INFO - 2022-03-21 17:33:35 --> Helper loaded: common_helper
INFO - 2022-03-21 17:33:35 --> Database Driver Class Initialized
DEBUG - 2022-03-21 17:33:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 17:33:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 17:33:35 --> Controller Class Initialized
INFO - 2022-03-21 17:33:35 --> Form Validation Class Initialized
DEBUG - 2022-03-21 17:33:35 --> Encrypt Class Initialized
DEBUG - 2022-03-21 17:33:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 17:33:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-21 17:33:35 --> Email Class Initialized
INFO - 2022-03-21 17:33:35 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-21 17:33:35 --> Calendar Class Initialized
INFO - 2022-03-21 17:33:35 --> Model "Login_model" initialized
INFO - 2022-03-21 17:33:35 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-21 17:33:35 --> Final output sent to browser
DEBUG - 2022-03-21 17:33:35 --> Total execution time: 0.0411
ERROR - 2022-03-21 18:45:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-21 18:45:29 --> Config Class Initialized
INFO - 2022-03-21 18:45:29 --> Hooks Class Initialized
DEBUG - 2022-03-21 18:45:29 --> UTF-8 Support Enabled
INFO - 2022-03-21 18:45:29 --> Utf8 Class Initialized
INFO - 2022-03-21 18:45:29 --> URI Class Initialized
DEBUG - 2022-03-21 18:45:29 --> No URI present. Default controller set.
INFO - 2022-03-21 18:45:29 --> Router Class Initialized
INFO - 2022-03-21 18:45:29 --> Output Class Initialized
INFO - 2022-03-21 18:45:29 --> Security Class Initialized
DEBUG - 2022-03-21 18:45:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 18:45:29 --> Input Class Initialized
INFO - 2022-03-21 18:45:29 --> Language Class Initialized
INFO - 2022-03-21 18:45:29 --> Loader Class Initialized
INFO - 2022-03-21 18:45:29 --> Helper loaded: url_helper
INFO - 2022-03-21 18:45:29 --> Helper loaded: form_helper
INFO - 2022-03-21 18:45:29 --> Helper loaded: common_helper
INFO - 2022-03-21 18:45:29 --> Database Driver Class Initialized
DEBUG - 2022-03-21 18:45:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 18:45:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 18:45:29 --> Controller Class Initialized
INFO - 2022-03-21 18:45:29 --> Form Validation Class Initialized
DEBUG - 2022-03-21 18:45:29 --> Encrypt Class Initialized
DEBUG - 2022-03-21 18:45:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 18:45:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-21 18:45:29 --> Email Class Initialized
INFO - 2022-03-21 18:45:29 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-21 18:45:29 --> Calendar Class Initialized
INFO - 2022-03-21 18:45:29 --> Model "Login_model" initialized
INFO - 2022-03-21 18:45:29 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-21 18:45:29 --> Final output sent to browser
DEBUG - 2022-03-21 18:45:29 --> Total execution time: 0.0505
