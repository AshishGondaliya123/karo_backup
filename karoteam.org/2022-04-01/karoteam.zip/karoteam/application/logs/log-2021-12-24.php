<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-12-24 01:19:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-24 01:19:11 --> Config Class Initialized
INFO - 2021-12-24 01:19:11 --> Hooks Class Initialized
DEBUG - 2021-12-24 01:19:11 --> UTF-8 Support Enabled
INFO - 2021-12-24 01:19:11 --> Utf8 Class Initialized
INFO - 2021-12-24 01:19:11 --> URI Class Initialized
DEBUG - 2021-12-24 01:19:11 --> No URI present. Default controller set.
INFO - 2021-12-24 01:19:11 --> Router Class Initialized
INFO - 2021-12-24 01:19:11 --> Output Class Initialized
INFO - 2021-12-24 01:19:11 --> Security Class Initialized
DEBUG - 2021-12-24 01:19:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-24 01:19:11 --> Input Class Initialized
INFO - 2021-12-24 01:19:11 --> Language Class Initialized
INFO - 2021-12-24 01:19:11 --> Loader Class Initialized
INFO - 2021-12-24 01:19:11 --> Helper loaded: url_helper
INFO - 2021-12-24 01:19:11 --> Helper loaded: form_helper
INFO - 2021-12-24 01:19:11 --> Helper loaded: common_helper
INFO - 2021-12-24 01:19:11 --> Database Driver Class Initialized
DEBUG - 2021-12-24 01:19:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-24 01:19:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-24 01:19:11 --> Controller Class Initialized
INFO - 2021-12-24 01:19:11 --> Form Validation Class Initialized
DEBUG - 2021-12-24 01:19:11 --> Encrypt Class Initialized
DEBUG - 2021-12-24 01:19:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 01:19:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-24 01:19:11 --> Email Class Initialized
INFO - 2021-12-24 01:19:11 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-24 01:19:11 --> Calendar Class Initialized
INFO - 2021-12-24 01:19:11 --> Model "Login_model" initialized
INFO - 2021-12-24 01:19:11 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-24 01:19:11 --> Final output sent to browser
DEBUG - 2021-12-24 01:19:11 --> Total execution time: 0.0252
ERROR - 2021-12-24 01:19:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-24 01:19:23 --> Config Class Initialized
INFO - 2021-12-24 01:19:23 --> Hooks Class Initialized
DEBUG - 2021-12-24 01:19:23 --> UTF-8 Support Enabled
INFO - 2021-12-24 01:19:23 --> Utf8 Class Initialized
INFO - 2021-12-24 01:19:23 --> URI Class Initialized
DEBUG - 2021-12-24 01:19:23 --> No URI present. Default controller set.
INFO - 2021-12-24 01:19:23 --> Router Class Initialized
INFO - 2021-12-24 01:19:23 --> Output Class Initialized
INFO - 2021-12-24 01:19:23 --> Security Class Initialized
DEBUG - 2021-12-24 01:19:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-24 01:19:23 --> Input Class Initialized
INFO - 2021-12-24 01:19:23 --> Language Class Initialized
INFO - 2021-12-24 01:19:23 --> Loader Class Initialized
INFO - 2021-12-24 01:19:23 --> Helper loaded: url_helper
INFO - 2021-12-24 01:19:23 --> Helper loaded: form_helper
INFO - 2021-12-24 01:19:23 --> Helper loaded: common_helper
INFO - 2021-12-24 01:19:23 --> Database Driver Class Initialized
DEBUG - 2021-12-24 01:19:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-24 01:19:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-24 01:19:23 --> Controller Class Initialized
INFO - 2021-12-24 01:19:23 --> Form Validation Class Initialized
DEBUG - 2021-12-24 01:19:23 --> Encrypt Class Initialized
DEBUG - 2021-12-24 01:19:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 01:19:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-24 01:19:23 --> Email Class Initialized
INFO - 2021-12-24 01:19:23 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-24 01:19:23 --> Calendar Class Initialized
INFO - 2021-12-24 01:19:23 --> Model "Login_model" initialized
INFO - 2021-12-24 01:19:23 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-24 01:19:23 --> Final output sent to browser
DEBUG - 2021-12-24 01:19:23 --> Total execution time: 0.0219
ERROR - 2021-12-24 05:43:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-24 05:43:57 --> Config Class Initialized
INFO - 2021-12-24 05:43:57 --> Hooks Class Initialized
DEBUG - 2021-12-24 05:43:57 --> UTF-8 Support Enabled
INFO - 2021-12-24 05:43:57 --> Utf8 Class Initialized
INFO - 2021-12-24 05:43:57 --> URI Class Initialized
DEBUG - 2021-12-24 05:43:57 --> No URI present. Default controller set.
INFO - 2021-12-24 05:43:57 --> Router Class Initialized
INFO - 2021-12-24 05:43:57 --> Output Class Initialized
INFO - 2021-12-24 05:43:57 --> Security Class Initialized
DEBUG - 2021-12-24 05:43:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-24 05:43:57 --> Input Class Initialized
INFO - 2021-12-24 05:43:57 --> Language Class Initialized
INFO - 2021-12-24 05:43:57 --> Loader Class Initialized
INFO - 2021-12-24 05:43:57 --> Helper loaded: url_helper
INFO - 2021-12-24 05:43:57 --> Helper loaded: form_helper
INFO - 2021-12-24 05:43:57 --> Helper loaded: common_helper
INFO - 2021-12-24 05:43:57 --> Database Driver Class Initialized
DEBUG - 2021-12-24 05:43:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-24 05:43:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-24 05:43:57 --> Controller Class Initialized
INFO - 2021-12-24 05:43:57 --> Form Validation Class Initialized
DEBUG - 2021-12-24 05:43:57 --> Encrypt Class Initialized
DEBUG - 2021-12-24 05:43:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 05:43:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-24 05:43:57 --> Email Class Initialized
INFO - 2021-12-24 05:43:57 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-24 05:43:57 --> Calendar Class Initialized
INFO - 2021-12-24 05:43:57 --> Model "Login_model" initialized
INFO - 2021-12-24 05:43:57 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-24 05:43:57 --> Final output sent to browser
DEBUG - 2021-12-24 05:43:57 --> Total execution time: 0.0243
ERROR - 2021-12-24 06:15:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-24 06:15:48 --> Config Class Initialized
INFO - 2021-12-24 06:15:48 --> Hooks Class Initialized
DEBUG - 2021-12-24 06:15:48 --> UTF-8 Support Enabled
INFO - 2021-12-24 06:15:48 --> Utf8 Class Initialized
INFO - 2021-12-24 06:15:48 --> URI Class Initialized
DEBUG - 2021-12-24 06:15:48 --> No URI present. Default controller set.
INFO - 2021-12-24 06:15:48 --> Router Class Initialized
INFO - 2021-12-24 06:15:48 --> Output Class Initialized
INFO - 2021-12-24 06:15:48 --> Security Class Initialized
DEBUG - 2021-12-24 06:15:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-24 06:15:48 --> Input Class Initialized
INFO - 2021-12-24 06:15:48 --> Language Class Initialized
INFO - 2021-12-24 06:15:48 --> Loader Class Initialized
INFO - 2021-12-24 06:15:48 --> Helper loaded: url_helper
INFO - 2021-12-24 06:15:48 --> Helper loaded: form_helper
INFO - 2021-12-24 06:15:48 --> Helper loaded: common_helper
INFO - 2021-12-24 06:15:48 --> Database Driver Class Initialized
DEBUG - 2021-12-24 06:15:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-24 06:15:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-24 06:15:48 --> Controller Class Initialized
INFO - 2021-12-24 06:15:48 --> Form Validation Class Initialized
DEBUG - 2021-12-24 06:15:48 --> Encrypt Class Initialized
DEBUG - 2021-12-24 06:15:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 06:15:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-24 06:15:48 --> Email Class Initialized
INFO - 2021-12-24 06:15:48 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-24 06:15:48 --> Calendar Class Initialized
INFO - 2021-12-24 06:15:48 --> Model "Login_model" initialized
INFO - 2021-12-24 06:15:48 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-24 06:15:48 --> Final output sent to browser
DEBUG - 2021-12-24 06:15:48 --> Total execution time: 0.0315
ERROR - 2021-12-24 07:52:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-24 07:52:42 --> Config Class Initialized
INFO - 2021-12-24 07:52:42 --> Hooks Class Initialized
DEBUG - 2021-12-24 07:52:42 --> UTF-8 Support Enabled
INFO - 2021-12-24 07:52:42 --> Utf8 Class Initialized
INFO - 2021-12-24 07:52:42 --> URI Class Initialized
DEBUG - 2021-12-24 07:52:42 --> No URI present. Default controller set.
INFO - 2021-12-24 07:52:42 --> Router Class Initialized
INFO - 2021-12-24 07:52:42 --> Output Class Initialized
INFO - 2021-12-24 07:52:42 --> Security Class Initialized
DEBUG - 2021-12-24 07:52:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-24 07:52:42 --> Input Class Initialized
INFO - 2021-12-24 07:52:42 --> Language Class Initialized
INFO - 2021-12-24 07:52:42 --> Loader Class Initialized
INFO - 2021-12-24 07:52:42 --> Helper loaded: url_helper
INFO - 2021-12-24 07:52:42 --> Helper loaded: form_helper
INFO - 2021-12-24 07:52:42 --> Helper loaded: common_helper
INFO - 2021-12-24 07:52:42 --> Database Driver Class Initialized
DEBUG - 2021-12-24 07:52:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-24 07:52:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-24 07:52:42 --> Controller Class Initialized
INFO - 2021-12-24 07:52:42 --> Form Validation Class Initialized
DEBUG - 2021-12-24 07:52:42 --> Encrypt Class Initialized
DEBUG - 2021-12-24 07:52:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 07:52:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-24 07:52:42 --> Email Class Initialized
INFO - 2021-12-24 07:52:42 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-24 07:52:42 --> Calendar Class Initialized
INFO - 2021-12-24 07:52:42 --> Model "Login_model" initialized
INFO - 2021-12-24 07:52:42 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-24 07:52:42 --> Final output sent to browser
DEBUG - 2021-12-24 07:52:42 --> Total execution time: 0.0233
ERROR - 2021-12-24 10:08:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-24 10:08:29 --> Config Class Initialized
INFO - 2021-12-24 10:08:29 --> Hooks Class Initialized
DEBUG - 2021-12-24 10:08:29 --> UTF-8 Support Enabled
INFO - 2021-12-24 10:08:29 --> Utf8 Class Initialized
INFO - 2021-12-24 10:08:29 --> URI Class Initialized
DEBUG - 2021-12-24 10:08:29 --> No URI present. Default controller set.
INFO - 2021-12-24 10:08:29 --> Router Class Initialized
INFO - 2021-12-24 10:08:29 --> Output Class Initialized
INFO - 2021-12-24 10:08:29 --> Security Class Initialized
DEBUG - 2021-12-24 10:08:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-24 10:08:29 --> Input Class Initialized
INFO - 2021-12-24 10:08:29 --> Language Class Initialized
INFO - 2021-12-24 10:08:29 --> Loader Class Initialized
INFO - 2021-12-24 10:08:29 --> Helper loaded: url_helper
INFO - 2021-12-24 10:08:29 --> Helper loaded: form_helper
INFO - 2021-12-24 10:08:29 --> Helper loaded: common_helper
INFO - 2021-12-24 10:08:29 --> Database Driver Class Initialized
DEBUG - 2021-12-24 10:08:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-24 10:08:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-24 10:08:29 --> Controller Class Initialized
INFO - 2021-12-24 10:08:29 --> Form Validation Class Initialized
DEBUG - 2021-12-24 10:08:29 --> Encrypt Class Initialized
DEBUG - 2021-12-24 10:08:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 10:08:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-24 10:08:29 --> Email Class Initialized
INFO - 2021-12-24 10:08:29 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-24 10:08:29 --> Calendar Class Initialized
INFO - 2021-12-24 10:08:29 --> Model "Login_model" initialized
INFO - 2021-12-24 10:08:29 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-24 10:08:29 --> Final output sent to browser
DEBUG - 2021-12-24 10:08:29 --> Total execution time: 0.0220
ERROR - 2021-12-24 14:21:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-24 14:21:49 --> Config Class Initialized
INFO - 2021-12-24 14:21:49 --> Hooks Class Initialized
DEBUG - 2021-12-24 14:21:49 --> UTF-8 Support Enabled
INFO - 2021-12-24 14:21:49 --> Utf8 Class Initialized
INFO - 2021-12-24 14:21:49 --> URI Class Initialized
DEBUG - 2021-12-24 14:21:49 --> No URI present. Default controller set.
INFO - 2021-12-24 14:21:49 --> Router Class Initialized
INFO - 2021-12-24 14:21:49 --> Output Class Initialized
INFO - 2021-12-24 14:21:49 --> Security Class Initialized
DEBUG - 2021-12-24 14:21:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-24 14:21:49 --> Input Class Initialized
INFO - 2021-12-24 14:21:49 --> Language Class Initialized
INFO - 2021-12-24 14:21:49 --> Loader Class Initialized
INFO - 2021-12-24 14:21:49 --> Helper loaded: url_helper
INFO - 2021-12-24 14:21:49 --> Helper loaded: form_helper
INFO - 2021-12-24 14:21:49 --> Helper loaded: common_helper
INFO - 2021-12-24 14:21:49 --> Database Driver Class Initialized
DEBUG - 2021-12-24 14:21:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-24 14:21:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-24 14:21:49 --> Controller Class Initialized
INFO - 2021-12-24 14:21:49 --> Form Validation Class Initialized
DEBUG - 2021-12-24 14:21:49 --> Encrypt Class Initialized
DEBUG - 2021-12-24 14:21:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 14:21:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-24 14:21:49 --> Email Class Initialized
INFO - 2021-12-24 14:21:49 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-24 14:21:49 --> Calendar Class Initialized
INFO - 2021-12-24 14:21:49 --> Model "Login_model" initialized
INFO - 2021-12-24 14:21:49 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-24 14:21:49 --> Final output sent to browser
DEBUG - 2021-12-24 14:21:49 --> Total execution time: 0.0292
ERROR - 2021-12-24 14:21:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-24 14:21:50 --> Config Class Initialized
INFO - 2021-12-24 14:21:50 --> Hooks Class Initialized
DEBUG - 2021-12-24 14:21:50 --> UTF-8 Support Enabled
INFO - 2021-12-24 14:21:50 --> Utf8 Class Initialized
INFO - 2021-12-24 14:21:50 --> URI Class Initialized
INFO - 2021-12-24 14:21:50 --> Router Class Initialized
INFO - 2021-12-24 14:21:50 --> Output Class Initialized
INFO - 2021-12-24 14:21:50 --> Security Class Initialized
DEBUG - 2021-12-24 14:21:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-24 14:21:50 --> Input Class Initialized
INFO - 2021-12-24 14:21:50 --> Language Class Initialized
ERROR - 2021-12-24 14:21:50 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2021-12-24 14:22:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-24 14:22:10 --> Config Class Initialized
INFO - 2021-12-24 14:22:10 --> Hooks Class Initialized
DEBUG - 2021-12-24 14:22:10 --> UTF-8 Support Enabled
INFO - 2021-12-24 14:22:10 --> Utf8 Class Initialized
INFO - 2021-12-24 14:22:10 --> URI Class Initialized
DEBUG - 2021-12-24 14:22:10 --> No URI present. Default controller set.
INFO - 2021-12-24 14:22:10 --> Router Class Initialized
INFO - 2021-12-24 14:22:10 --> Output Class Initialized
INFO - 2021-12-24 14:22:10 --> Security Class Initialized
DEBUG - 2021-12-24 14:22:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-24 14:22:10 --> Input Class Initialized
INFO - 2021-12-24 14:22:10 --> Language Class Initialized
INFO - 2021-12-24 14:22:10 --> Loader Class Initialized
INFO - 2021-12-24 14:22:10 --> Helper loaded: url_helper
INFO - 2021-12-24 14:22:10 --> Helper loaded: form_helper
INFO - 2021-12-24 14:22:10 --> Helper loaded: common_helper
INFO - 2021-12-24 14:22:10 --> Database Driver Class Initialized
DEBUG - 2021-12-24 14:22:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-24 14:22:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-24 14:22:10 --> Controller Class Initialized
INFO - 2021-12-24 14:22:10 --> Form Validation Class Initialized
DEBUG - 2021-12-24 14:22:10 --> Encrypt Class Initialized
DEBUG - 2021-12-24 14:22:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 14:22:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-24 14:22:10 --> Email Class Initialized
INFO - 2021-12-24 14:22:10 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-24 14:22:10 --> Calendar Class Initialized
INFO - 2021-12-24 14:22:10 --> Model "Login_model" initialized
INFO - 2021-12-24 14:22:10 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-24 14:22:10 --> Final output sent to browser
DEBUG - 2021-12-24 14:22:10 --> Total execution time: 0.0280
ERROR - 2021-12-24 14:22:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-24 14:22:11 --> Config Class Initialized
INFO - 2021-12-24 14:22:11 --> Hooks Class Initialized
DEBUG - 2021-12-24 14:22:11 --> UTF-8 Support Enabled
INFO - 2021-12-24 14:22:11 --> Utf8 Class Initialized
INFO - 2021-12-24 14:22:11 --> URI Class Initialized
INFO - 2021-12-24 14:22:11 --> Router Class Initialized
INFO - 2021-12-24 14:22:11 --> Output Class Initialized
INFO - 2021-12-24 14:22:11 --> Security Class Initialized
DEBUG - 2021-12-24 14:22:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-24 14:22:11 --> Input Class Initialized
INFO - 2021-12-24 14:22:11 --> Language Class Initialized
INFO - 2021-12-24 14:22:11 --> Loader Class Initialized
INFO - 2021-12-24 14:22:11 --> Helper loaded: url_helper
INFO - 2021-12-24 14:22:11 --> Helper loaded: form_helper
INFO - 2021-12-24 14:22:11 --> Helper loaded: common_helper
INFO - 2021-12-24 14:22:11 --> Database Driver Class Initialized
DEBUG - 2021-12-24 14:22:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-24 14:22:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-24 14:22:11 --> Controller Class Initialized
INFO - 2021-12-24 14:22:11 --> Form Validation Class Initialized
DEBUG - 2021-12-24 14:22:11 --> Encrypt Class Initialized
DEBUG - 2021-12-24 14:22:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 14:22:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-24 14:22:11 --> Email Class Initialized
INFO - 2021-12-24 14:22:11 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-24 14:22:11 --> Calendar Class Initialized
INFO - 2021-12-24 14:22:11 --> Model "Login_model" initialized
INFO - 2021-12-24 14:22:11 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-24 14:22:11 --> Final output sent to browser
DEBUG - 2021-12-24 14:22:11 --> Total execution time: 0.0281
ERROR - 2021-12-24 14:22:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-24 14:22:11 --> Config Class Initialized
INFO - 2021-12-24 14:22:11 --> Hooks Class Initialized
DEBUG - 2021-12-24 14:22:11 --> UTF-8 Support Enabled
INFO - 2021-12-24 14:22:11 --> Utf8 Class Initialized
INFO - 2021-12-24 14:22:11 --> URI Class Initialized
INFO - 2021-12-24 14:22:11 --> Router Class Initialized
INFO - 2021-12-24 14:22:11 --> Output Class Initialized
INFO - 2021-12-24 14:22:11 --> Security Class Initialized
DEBUG - 2021-12-24 14:22:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-24 14:22:11 --> Input Class Initialized
INFO - 2021-12-24 14:22:11 --> Language Class Initialized
INFO - 2021-12-24 14:22:11 --> Loader Class Initialized
INFO - 2021-12-24 14:22:11 --> Helper loaded: url_helper
INFO - 2021-12-24 14:22:11 --> Helper loaded: form_helper
INFO - 2021-12-24 14:22:11 --> Helper loaded: common_helper
INFO - 2021-12-24 14:22:11 --> Database Driver Class Initialized
DEBUG - 2021-12-24 14:22:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-24 14:22:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-24 14:22:11 --> Controller Class Initialized
INFO - 2021-12-24 14:22:11 --> Form Validation Class Initialized
DEBUG - 2021-12-24 14:22:11 --> Encrypt Class Initialized
DEBUG - 2021-12-24 14:22:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 14:22:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-24 14:22:11 --> Email Class Initialized
INFO - 2021-12-24 14:22:11 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-24 14:22:11 --> Calendar Class Initialized
INFO - 2021-12-24 14:22:11 --> Model "Login_model" initialized
ERROR - 2021-12-24 14:22:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-24 14:22:12 --> Config Class Initialized
INFO - 2021-12-24 14:22:12 --> Hooks Class Initialized
DEBUG - 2021-12-24 14:22:12 --> UTF-8 Support Enabled
INFO - 2021-12-24 14:22:12 --> Utf8 Class Initialized
INFO - 2021-12-24 14:22:12 --> URI Class Initialized
INFO - 2021-12-24 14:22:12 --> Router Class Initialized
INFO - 2021-12-24 14:22:12 --> Output Class Initialized
INFO - 2021-12-24 14:22:12 --> Security Class Initialized
DEBUG - 2021-12-24 14:22:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-24 14:22:12 --> Input Class Initialized
INFO - 2021-12-24 14:22:12 --> Language Class Initialized
INFO - 2021-12-24 14:22:12 --> Loader Class Initialized
INFO - 2021-12-24 14:22:12 --> Helper loaded: url_helper
INFO - 2021-12-24 14:22:12 --> Helper loaded: form_helper
INFO - 2021-12-24 14:22:12 --> Helper loaded: common_helper
INFO - 2021-12-24 14:22:12 --> Database Driver Class Initialized
DEBUG - 2021-12-24 14:22:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-24 14:22:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-24 14:22:12 --> Controller Class Initialized
INFO - 2021-12-24 14:22:12 --> Form Validation Class Initialized
DEBUG - 2021-12-24 14:22:12 --> Encrypt Class Initialized
DEBUG - 2021-12-24 14:22:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 14:22:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-24 14:22:12 --> Email Class Initialized
INFO - 2021-12-24 14:22:12 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-24 14:22:12 --> Calendar Class Initialized
INFO - 2021-12-24 14:22:12 --> Model "Login_model" initialized
ERROR - 2021-12-24 20:00:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-24 20:00:16 --> Config Class Initialized
INFO - 2021-12-24 20:00:16 --> Hooks Class Initialized
DEBUG - 2021-12-24 20:00:16 --> UTF-8 Support Enabled
INFO - 2021-12-24 20:00:16 --> Utf8 Class Initialized
INFO - 2021-12-24 20:00:16 --> URI Class Initialized
DEBUG - 2021-12-24 20:00:16 --> No URI present. Default controller set.
INFO - 2021-12-24 20:00:16 --> Router Class Initialized
INFO - 2021-12-24 20:00:16 --> Output Class Initialized
INFO - 2021-12-24 20:00:16 --> Security Class Initialized
DEBUG - 2021-12-24 20:00:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-24 20:00:16 --> Input Class Initialized
INFO - 2021-12-24 20:00:16 --> Language Class Initialized
INFO - 2021-12-24 20:00:16 --> Loader Class Initialized
INFO - 2021-12-24 20:00:16 --> Helper loaded: url_helper
INFO - 2021-12-24 20:00:16 --> Helper loaded: form_helper
INFO - 2021-12-24 20:00:16 --> Helper loaded: common_helper
INFO - 2021-12-24 20:00:16 --> Database Driver Class Initialized
DEBUG - 2021-12-24 20:00:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-24 20:00:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-24 20:00:16 --> Controller Class Initialized
INFO - 2021-12-24 20:00:16 --> Form Validation Class Initialized
DEBUG - 2021-12-24 20:00:16 --> Encrypt Class Initialized
DEBUG - 2021-12-24 20:00:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 20:00:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-24 20:00:16 --> Email Class Initialized
INFO - 2021-12-24 20:00:16 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-24 20:00:16 --> Calendar Class Initialized
INFO - 2021-12-24 20:00:16 --> Model "Login_model" initialized
INFO - 2021-12-24 20:00:16 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-24 20:00:16 --> Final output sent to browser
DEBUG - 2021-12-24 20:00:16 --> Total execution time: 0.0299
