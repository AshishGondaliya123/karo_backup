<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-01-03 14:18:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-03 14:18:36 --> Config Class Initialized
INFO - 2022-01-03 14:18:36 --> Hooks Class Initialized
DEBUG - 2022-01-03 14:18:36 --> UTF-8 Support Enabled
INFO - 2022-01-03 14:18:36 --> Utf8 Class Initialized
INFO - 2022-01-03 14:18:36 --> URI Class Initialized
DEBUG - 2022-01-03 14:18:36 --> No URI present. Default controller set.
INFO - 2022-01-03 14:18:36 --> Router Class Initialized
INFO - 2022-01-03 14:18:36 --> Output Class Initialized
INFO - 2022-01-03 14:18:36 --> Security Class Initialized
DEBUG - 2022-01-03 14:18:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 14:18:36 --> Input Class Initialized
INFO - 2022-01-03 14:18:36 --> Language Class Initialized
INFO - 2022-01-03 14:18:36 --> Loader Class Initialized
INFO - 2022-01-03 14:18:36 --> Helper loaded: url_helper
INFO - 2022-01-03 14:18:36 --> Helper loaded: form_helper
INFO - 2022-01-03 14:18:36 --> Helper loaded: common_helper
INFO - 2022-01-03 14:18:36 --> Database Driver Class Initialized
DEBUG - 2022-01-03 14:18:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 14:18:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 14:18:36 --> Controller Class Initialized
INFO - 2022-01-03 14:18:36 --> Form Validation Class Initialized
DEBUG - 2022-01-03 14:18:36 --> Encrypt Class Initialized
DEBUG - 2022-01-03 14:18:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-03 14:18:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-03 14:18:36 --> Email Class Initialized
INFO - 2022-01-03 14:18:36 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-03 14:18:36 --> Calendar Class Initialized
INFO - 2022-01-03 14:18:36 --> Model "Login_model" initialized
INFO - 2022-01-03 14:18:36 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-03 14:18:36 --> Final output sent to browser
DEBUG - 2022-01-03 14:18:36 --> Total execution time: 0.0320
ERROR - 2022-01-03 14:18:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-03 14:18:38 --> Config Class Initialized
INFO - 2022-01-03 14:18:38 --> Hooks Class Initialized
DEBUG - 2022-01-03 14:18:38 --> UTF-8 Support Enabled
INFO - 2022-01-03 14:18:38 --> Utf8 Class Initialized
INFO - 2022-01-03 14:18:38 --> URI Class Initialized
INFO - 2022-01-03 14:18:38 --> Router Class Initialized
INFO - 2022-01-03 14:18:38 --> Output Class Initialized
INFO - 2022-01-03 14:18:38 --> Security Class Initialized
DEBUG - 2022-01-03 14:18:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 14:18:38 --> Input Class Initialized
INFO - 2022-01-03 14:18:38 --> Language Class Initialized
ERROR - 2022-01-03 14:18:38 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2022-01-03 14:19:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-03 14:19:01 --> Config Class Initialized
INFO - 2022-01-03 14:19:01 --> Hooks Class Initialized
DEBUG - 2022-01-03 14:19:01 --> UTF-8 Support Enabled
INFO - 2022-01-03 14:19:01 --> Utf8 Class Initialized
INFO - 2022-01-03 14:19:01 --> URI Class Initialized
INFO - 2022-01-03 14:19:01 --> Router Class Initialized
INFO - 2022-01-03 14:19:01 --> Output Class Initialized
INFO - 2022-01-03 14:19:01 --> Security Class Initialized
DEBUG - 2022-01-03 14:19:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 14:19:01 --> Input Class Initialized
INFO - 2022-01-03 14:19:01 --> Language Class Initialized
INFO - 2022-01-03 14:19:01 --> Loader Class Initialized
INFO - 2022-01-03 14:19:01 --> Helper loaded: url_helper
INFO - 2022-01-03 14:19:01 --> Helper loaded: form_helper
INFO - 2022-01-03 14:19:01 --> Helper loaded: common_helper
INFO - 2022-01-03 14:19:01 --> Database Driver Class Initialized
DEBUG - 2022-01-03 14:19:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 14:19:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 14:19:01 --> Controller Class Initialized
INFO - 2022-01-03 14:19:01 --> Form Validation Class Initialized
DEBUG - 2022-01-03 14:19:01 --> Encrypt Class Initialized
DEBUG - 2022-01-03 14:19:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-03 14:19:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-03 14:19:01 --> Email Class Initialized
INFO - 2022-01-03 14:19:01 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-03 14:19:01 --> Calendar Class Initialized
INFO - 2022-01-03 14:19:01 --> Model "Login_model" initialized
INFO - 2022-01-03 14:19:01 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-03 14:19:01 --> Final output sent to browser
DEBUG - 2022-01-03 14:19:01 --> Total execution time: 0.0466
ERROR - 2022-01-03 14:19:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-03 14:19:02 --> Config Class Initialized
INFO - 2022-01-03 14:19:02 --> Hooks Class Initialized
DEBUG - 2022-01-03 14:19:02 --> UTF-8 Support Enabled
INFO - 2022-01-03 14:19:02 --> Utf8 Class Initialized
INFO - 2022-01-03 14:19:02 --> URI Class Initialized
INFO - 2022-01-03 14:19:02 --> Router Class Initialized
INFO - 2022-01-03 14:19:02 --> Output Class Initialized
INFO - 2022-01-03 14:19:02 --> Security Class Initialized
DEBUG - 2022-01-03 14:19:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 14:19:02 --> Input Class Initialized
INFO - 2022-01-03 14:19:02 --> Language Class Initialized
INFO - 2022-01-03 14:19:02 --> Loader Class Initialized
INFO - 2022-01-03 14:19:02 --> Helper loaded: url_helper
INFO - 2022-01-03 14:19:02 --> Helper loaded: form_helper
INFO - 2022-01-03 14:19:02 --> Helper loaded: common_helper
INFO - 2022-01-03 14:19:02 --> Database Driver Class Initialized
DEBUG - 2022-01-03 14:19:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 14:19:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 14:19:02 --> Controller Class Initialized
INFO - 2022-01-03 14:19:02 --> Form Validation Class Initialized
DEBUG - 2022-01-03 14:19:02 --> Encrypt Class Initialized
DEBUG - 2022-01-03 14:19:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-03 14:19:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-03 14:19:02 --> Email Class Initialized
INFO - 2022-01-03 14:19:02 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-03 14:19:02 --> Calendar Class Initialized
INFO - 2022-01-03 14:19:02 --> Model "Login_model" initialized
ERROR - 2022-01-03 14:19:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-03 14:19:03 --> Config Class Initialized
INFO - 2022-01-03 14:19:03 --> Hooks Class Initialized
DEBUG - 2022-01-03 14:19:03 --> UTF-8 Support Enabled
INFO - 2022-01-03 14:19:03 --> Utf8 Class Initialized
INFO - 2022-01-03 14:19:03 --> URI Class Initialized
INFO - 2022-01-03 14:19:03 --> Router Class Initialized
INFO - 2022-01-03 14:19:03 --> Output Class Initialized
INFO - 2022-01-03 14:19:03 --> Security Class Initialized
DEBUG - 2022-01-03 14:19:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 14:19:03 --> Input Class Initialized
INFO - 2022-01-03 14:19:03 --> Language Class Initialized
INFO - 2022-01-03 14:19:03 --> Loader Class Initialized
INFO - 2022-01-03 14:19:03 --> Helper loaded: url_helper
INFO - 2022-01-03 14:19:03 --> Helper loaded: form_helper
INFO - 2022-01-03 14:19:03 --> Helper loaded: common_helper
INFO - 2022-01-03 14:19:03 --> Database Driver Class Initialized
DEBUG - 2022-01-03 14:19:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 14:19:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 14:19:03 --> Controller Class Initialized
INFO - 2022-01-03 14:19:03 --> Form Validation Class Initialized
DEBUG - 2022-01-03 14:19:03 --> Encrypt Class Initialized
DEBUG - 2022-01-03 14:19:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-03 14:19:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-03 14:19:03 --> Email Class Initialized
INFO - 2022-01-03 14:19:03 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-03 14:19:03 --> Calendar Class Initialized
INFO - 2022-01-03 14:19:03 --> Model "Login_model" initialized
ERROR - 2022-01-03 14:19:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-03 14:19:03 --> Config Class Initialized
INFO - 2022-01-03 14:19:03 --> Hooks Class Initialized
DEBUG - 2022-01-03 14:19:03 --> UTF-8 Support Enabled
INFO - 2022-01-03 14:19:03 --> Utf8 Class Initialized
INFO - 2022-01-03 14:19:03 --> URI Class Initialized
DEBUG - 2022-01-03 14:19:03 --> No URI present. Default controller set.
INFO - 2022-01-03 14:19:03 --> Router Class Initialized
INFO - 2022-01-03 14:19:03 --> Output Class Initialized
INFO - 2022-01-03 14:19:03 --> Security Class Initialized
DEBUG - 2022-01-03 14:19:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 14:19:03 --> Input Class Initialized
INFO - 2022-01-03 14:19:03 --> Language Class Initialized
INFO - 2022-01-03 14:19:03 --> Loader Class Initialized
INFO - 2022-01-03 14:19:03 --> Helper loaded: url_helper
INFO - 2022-01-03 14:19:03 --> Helper loaded: form_helper
INFO - 2022-01-03 14:19:03 --> Helper loaded: common_helper
INFO - 2022-01-03 14:19:03 --> Database Driver Class Initialized
DEBUG - 2022-01-03 14:19:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 14:19:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 14:19:03 --> Controller Class Initialized
INFO - 2022-01-03 14:19:03 --> Form Validation Class Initialized
DEBUG - 2022-01-03 14:19:03 --> Encrypt Class Initialized
DEBUG - 2022-01-03 14:19:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-03 14:19:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-03 14:19:03 --> Email Class Initialized
INFO - 2022-01-03 14:19:03 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-03 14:19:03 --> Calendar Class Initialized
INFO - 2022-01-03 14:19:03 --> Model "Login_model" initialized
INFO - 2022-01-03 14:19:03 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-03 14:19:03 --> Final output sent to browser
DEBUG - 2022-01-03 14:19:03 --> Total execution time: 0.0292
ERROR - 2022-01-03 15:48:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-03 15:48:49 --> Config Class Initialized
INFO - 2022-01-03 15:48:49 --> Hooks Class Initialized
DEBUG - 2022-01-03 15:48:49 --> UTF-8 Support Enabled
INFO - 2022-01-03 15:48:49 --> Utf8 Class Initialized
INFO - 2022-01-03 15:48:49 --> URI Class Initialized
DEBUG - 2022-01-03 15:48:49 --> No URI present. Default controller set.
INFO - 2022-01-03 15:48:49 --> Router Class Initialized
INFO - 2022-01-03 15:48:49 --> Output Class Initialized
INFO - 2022-01-03 15:48:49 --> Security Class Initialized
DEBUG - 2022-01-03 15:48:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 15:48:49 --> Input Class Initialized
INFO - 2022-01-03 15:48:49 --> Language Class Initialized
INFO - 2022-01-03 15:48:49 --> Loader Class Initialized
INFO - 2022-01-03 15:48:49 --> Helper loaded: url_helper
INFO - 2022-01-03 15:48:49 --> Helper loaded: form_helper
INFO - 2022-01-03 15:48:49 --> Helper loaded: common_helper
INFO - 2022-01-03 15:48:49 --> Database Driver Class Initialized
DEBUG - 2022-01-03 15:48:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 15:48:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 15:48:49 --> Controller Class Initialized
INFO - 2022-01-03 15:48:49 --> Form Validation Class Initialized
DEBUG - 2022-01-03 15:48:49 --> Encrypt Class Initialized
DEBUG - 2022-01-03 15:48:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-03 15:48:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-03 15:48:49 --> Email Class Initialized
INFO - 2022-01-03 15:48:49 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-03 15:48:49 --> Calendar Class Initialized
INFO - 2022-01-03 15:48:49 --> Model "Login_model" initialized
INFO - 2022-01-03 15:48:49 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-03 15:48:49 --> Final output sent to browser
DEBUG - 2022-01-03 15:48:49 --> Total execution time: 0.0233
ERROR - 2022-01-03 16:06:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-03 16:06:40 --> Config Class Initialized
INFO - 2022-01-03 16:06:40 --> Hooks Class Initialized
DEBUG - 2022-01-03 16:06:40 --> UTF-8 Support Enabled
INFO - 2022-01-03 16:06:40 --> Utf8 Class Initialized
INFO - 2022-01-03 16:06:40 --> URI Class Initialized
DEBUG - 2022-01-03 16:06:40 --> No URI present. Default controller set.
INFO - 2022-01-03 16:06:40 --> Router Class Initialized
INFO - 2022-01-03 16:06:40 --> Output Class Initialized
INFO - 2022-01-03 16:06:40 --> Security Class Initialized
DEBUG - 2022-01-03 16:06:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 16:06:40 --> Input Class Initialized
INFO - 2022-01-03 16:06:40 --> Language Class Initialized
INFO - 2022-01-03 16:06:40 --> Loader Class Initialized
INFO - 2022-01-03 16:06:40 --> Helper loaded: url_helper
INFO - 2022-01-03 16:06:40 --> Helper loaded: form_helper
INFO - 2022-01-03 16:06:40 --> Helper loaded: common_helper
INFO - 2022-01-03 16:06:40 --> Database Driver Class Initialized
DEBUG - 2022-01-03 16:06:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 16:06:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 16:06:40 --> Controller Class Initialized
INFO - 2022-01-03 16:06:40 --> Form Validation Class Initialized
DEBUG - 2022-01-03 16:06:40 --> Encrypt Class Initialized
DEBUG - 2022-01-03 16:06:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-03 16:06:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-03 16:06:40 --> Email Class Initialized
INFO - 2022-01-03 16:06:40 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-03 16:06:40 --> Calendar Class Initialized
INFO - 2022-01-03 16:06:40 --> Model "Login_model" initialized
INFO - 2022-01-03 16:06:40 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-03 16:06:40 --> Final output sent to browser
DEBUG - 2022-01-03 16:06:40 --> Total execution time: 0.0284
ERROR - 2022-01-03 16:10:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-03 16:10:03 --> Config Class Initialized
INFO - 2022-01-03 16:10:03 --> Hooks Class Initialized
DEBUG - 2022-01-03 16:10:03 --> UTF-8 Support Enabled
INFO - 2022-01-03 16:10:03 --> Utf8 Class Initialized
INFO - 2022-01-03 16:10:03 --> URI Class Initialized
DEBUG - 2022-01-03 16:10:03 --> No URI present. Default controller set.
INFO - 2022-01-03 16:10:03 --> Router Class Initialized
INFO - 2022-01-03 16:10:03 --> Output Class Initialized
INFO - 2022-01-03 16:10:03 --> Security Class Initialized
DEBUG - 2022-01-03 16:10:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 16:10:03 --> Input Class Initialized
INFO - 2022-01-03 16:10:03 --> Language Class Initialized
INFO - 2022-01-03 16:10:03 --> Loader Class Initialized
INFO - 2022-01-03 16:10:03 --> Helper loaded: url_helper
INFO - 2022-01-03 16:10:03 --> Helper loaded: form_helper
INFO - 2022-01-03 16:10:03 --> Helper loaded: common_helper
INFO - 2022-01-03 16:10:03 --> Database Driver Class Initialized
DEBUG - 2022-01-03 16:10:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 16:10:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 16:10:03 --> Controller Class Initialized
INFO - 2022-01-03 16:10:03 --> Form Validation Class Initialized
DEBUG - 2022-01-03 16:10:03 --> Encrypt Class Initialized
DEBUG - 2022-01-03 16:10:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-03 16:10:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-03 16:10:03 --> Email Class Initialized
INFO - 2022-01-03 16:10:03 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-03 16:10:03 --> Calendar Class Initialized
INFO - 2022-01-03 16:10:03 --> Model "Login_model" initialized
INFO - 2022-01-03 16:10:03 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-03 16:10:03 --> Final output sent to browser
DEBUG - 2022-01-03 16:10:03 --> Total execution time: 0.0280
ERROR - 2022-01-03 23:08:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-03 23:08:37 --> Config Class Initialized
INFO - 2022-01-03 23:08:37 --> Hooks Class Initialized
DEBUG - 2022-01-03 23:08:37 --> UTF-8 Support Enabled
INFO - 2022-01-03 23:08:37 --> Utf8 Class Initialized
INFO - 2022-01-03 23:08:37 --> URI Class Initialized
INFO - 2022-01-03 23:08:37 --> Router Class Initialized
INFO - 2022-01-03 23:08:37 --> Output Class Initialized
INFO - 2022-01-03 23:08:37 --> Security Class Initialized
DEBUG - 2022-01-03 23:08:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 23:08:37 --> Input Class Initialized
INFO - 2022-01-03 23:08:37 --> Language Class Initialized
ERROR - 2022-01-03 23:08:37 --> 404 Page Not Found: Scripts/app.js
ERROR - 2022-01-03 23:08:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-03 23:08:37 --> Config Class Initialized
INFO - 2022-01-03 23:08:37 --> Hooks Class Initialized
DEBUG - 2022-01-03 23:08:37 --> UTF-8 Support Enabled
INFO - 2022-01-03 23:08:37 --> Utf8 Class Initialized
INFO - 2022-01-03 23:08:37 --> URI Class Initialized
INFO - 2022-01-03 23:08:37 --> Router Class Initialized
INFO - 2022-01-03 23:08:37 --> Output Class Initialized
INFO - 2022-01-03 23:08:37 --> Security Class Initialized
DEBUG - 2022-01-03 23:08:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 23:08:37 --> Input Class Initialized
INFO - 2022-01-03 23:08:37 --> Language Class Initialized
ERROR - 2022-01-03 23:08:37 --> 404 Page Not Found: Scripts/app.js
ERROR - 2022-01-03 23:48:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-03 23:48:59 --> Config Class Initialized
INFO - 2022-01-03 23:48:59 --> Hooks Class Initialized
DEBUG - 2022-01-03 23:48:59 --> UTF-8 Support Enabled
INFO - 2022-01-03 23:48:59 --> Utf8 Class Initialized
INFO - 2022-01-03 23:48:59 --> URI Class Initialized
DEBUG - 2022-01-03 23:48:59 --> No URI present. Default controller set.
INFO - 2022-01-03 23:48:59 --> Router Class Initialized
INFO - 2022-01-03 23:48:59 --> Output Class Initialized
INFO - 2022-01-03 23:48:59 --> Security Class Initialized
DEBUG - 2022-01-03 23:48:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 23:48:59 --> Input Class Initialized
INFO - 2022-01-03 23:48:59 --> Language Class Initialized
INFO - 2022-01-03 23:48:59 --> Loader Class Initialized
INFO - 2022-01-03 23:48:59 --> Helper loaded: url_helper
INFO - 2022-01-03 23:48:59 --> Helper loaded: form_helper
INFO - 2022-01-03 23:48:59 --> Helper loaded: common_helper
INFO - 2022-01-03 23:48:59 --> Database Driver Class Initialized
DEBUG - 2022-01-03 23:48:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 23:48:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 23:48:59 --> Controller Class Initialized
INFO - 2022-01-03 23:48:59 --> Form Validation Class Initialized
DEBUG - 2022-01-03 23:48:59 --> Encrypt Class Initialized
DEBUG - 2022-01-03 23:48:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-03 23:48:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-03 23:48:59 --> Email Class Initialized
INFO - 2022-01-03 23:48:59 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-03 23:48:59 --> Calendar Class Initialized
INFO - 2022-01-03 23:48:59 --> Model "Login_model" initialized
INFO - 2022-01-03 23:48:59 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-03 23:48:59 --> Final output sent to browser
DEBUG - 2022-01-03 23:48:59 --> Total execution time: 0.0224
