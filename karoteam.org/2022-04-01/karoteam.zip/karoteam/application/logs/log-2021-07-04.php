<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-07-04 10:41:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-04 10:41:43 --> Config Class Initialized
INFO - 2021-07-04 10:41:43 --> Hooks Class Initialized
DEBUG - 2021-07-04 10:41:43 --> UTF-8 Support Enabled
INFO - 2021-07-04 10:41:43 --> Utf8 Class Initialized
INFO - 2021-07-04 10:41:43 --> URI Class Initialized
INFO - 2021-07-04 10:41:43 --> Router Class Initialized
INFO - 2021-07-04 10:41:43 --> Output Class Initialized
INFO - 2021-07-04 10:41:43 --> Security Class Initialized
DEBUG - 2021-07-04 10:41:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-04 10:41:43 --> Input Class Initialized
INFO - 2021-07-04 10:41:43 --> Language Class Initialized
ERROR - 2021-07-04 10:41:43 --> 404 Page Not Found: Git/config
ERROR - 2021-07-04 10:41:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-04 10:41:45 --> Config Class Initialized
INFO - 2021-07-04 10:41:45 --> Hooks Class Initialized
DEBUG - 2021-07-04 10:41:45 --> UTF-8 Support Enabled
INFO - 2021-07-04 10:41:45 --> Utf8 Class Initialized
INFO - 2021-07-04 10:41:45 --> URI Class Initialized
INFO - 2021-07-04 10:41:45 --> Router Class Initialized
INFO - 2021-07-04 10:41:45 --> Output Class Initialized
INFO - 2021-07-04 10:41:45 --> Security Class Initialized
DEBUG - 2021-07-04 10:41:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-04 10:41:45 --> Input Class Initialized
INFO - 2021-07-04 10:41:45 --> Language Class Initialized
ERROR - 2021-07-04 10:41:45 --> 404 Page Not Found: Git/config
ERROR - 2021-07-04 10:41:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-04 10:41:45 --> Config Class Initialized
INFO - 2021-07-04 10:41:45 --> Hooks Class Initialized
DEBUG - 2021-07-04 10:41:45 --> UTF-8 Support Enabled
INFO - 2021-07-04 10:41:45 --> Utf8 Class Initialized
INFO - 2021-07-04 10:41:45 --> URI Class Initialized
INFO - 2021-07-04 10:41:45 --> Router Class Initialized
INFO - 2021-07-04 10:41:45 --> Output Class Initialized
INFO - 2021-07-04 10:41:45 --> Security Class Initialized
DEBUG - 2021-07-04 10:41:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-04 10:41:45 --> Input Class Initialized
INFO - 2021-07-04 10:41:45 --> Language Class Initialized
ERROR - 2021-07-04 10:41:45 --> 404 Page Not Found: Git/config
ERROR - 2021-07-04 10:41:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-04 10:41:47 --> Config Class Initialized
INFO - 2021-07-04 10:41:47 --> Hooks Class Initialized
DEBUG - 2021-07-04 10:41:47 --> UTF-8 Support Enabled
INFO - 2021-07-04 10:41:47 --> Utf8 Class Initialized
INFO - 2021-07-04 10:41:47 --> URI Class Initialized
INFO - 2021-07-04 10:41:47 --> Router Class Initialized
INFO - 2021-07-04 10:41:47 --> Output Class Initialized
INFO - 2021-07-04 10:41:47 --> Security Class Initialized
DEBUG - 2021-07-04 10:41:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-04 10:41:47 --> Input Class Initialized
INFO - 2021-07-04 10:41:47 --> Language Class Initialized
ERROR - 2021-07-04 10:41:47 --> 404 Page Not Found: Git/config
