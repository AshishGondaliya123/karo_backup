<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-12-15 00:00:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 00:00:20 --> Config Class Initialized
INFO - 2021-12-15 00:00:20 --> Hooks Class Initialized
DEBUG - 2021-12-15 00:00:20 --> UTF-8 Support Enabled
INFO - 2021-12-15 00:00:20 --> Utf8 Class Initialized
INFO - 2021-12-15 00:00:20 --> URI Class Initialized
INFO - 2021-12-15 00:00:20 --> Router Class Initialized
INFO - 2021-12-15 00:00:20 --> Output Class Initialized
INFO - 2021-12-15 00:00:20 --> Security Class Initialized
DEBUG - 2021-12-15 00:00:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 00:00:20 --> Input Class Initialized
INFO - 2021-12-15 00:00:20 --> Language Class Initialized
INFO - 2021-12-15 00:00:20 --> Loader Class Initialized
INFO - 2021-12-15 00:00:20 --> Helper loaded: url_helper
INFO - 2021-12-15 00:00:20 --> Helper loaded: form_helper
INFO - 2021-12-15 00:00:20 --> Helper loaded: common_helper
INFO - 2021-12-15 00:00:20 --> Database Driver Class Initialized
DEBUG - 2021-12-15 00:00:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 00:00:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 00:00:20 --> Controller Class Initialized
INFO - 2021-12-15 00:00:20 --> Form Validation Class Initialized
DEBUG - 2021-12-15 00:00:20 --> Encrypt Class Initialized
INFO - 2021-12-15 00:00:20 --> Model "Login_model" initialized
INFO - 2021-12-15 00:00:20 --> Model "Dashboard_model" initialized
INFO - 2021-12-15 00:00:20 --> Model "Case_model" initialized
INFO - 2021-12-15 00:00:31 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-15 00:00:42 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2021-12-15 00:00:42 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-15 00:00:42 --> Final output sent to browser
DEBUG - 2021-12-15 00:00:42 --> Total execution time: 22.5301
ERROR - 2021-12-15 00:00:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 00:00:43 --> Config Class Initialized
INFO - 2021-12-15 00:00:43 --> Hooks Class Initialized
DEBUG - 2021-12-15 00:00:43 --> UTF-8 Support Enabled
INFO - 2021-12-15 00:00:43 --> Utf8 Class Initialized
INFO - 2021-12-15 00:00:43 --> URI Class Initialized
INFO - 2021-12-15 00:00:43 --> Router Class Initialized
INFO - 2021-12-15 00:00:43 --> Output Class Initialized
INFO - 2021-12-15 00:00:43 --> Security Class Initialized
DEBUG - 2021-12-15 00:00:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 00:00:43 --> Input Class Initialized
INFO - 2021-12-15 00:00:43 --> Language Class Initialized
ERROR - 2021-12-15 00:00:43 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-12-15 00:01:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 00:01:04 --> Config Class Initialized
INFO - 2021-12-15 00:01:04 --> Hooks Class Initialized
DEBUG - 2021-12-15 00:01:04 --> UTF-8 Support Enabled
INFO - 2021-12-15 00:01:04 --> Utf8 Class Initialized
INFO - 2021-12-15 00:01:04 --> URI Class Initialized
INFO - 2021-12-15 00:01:04 --> Router Class Initialized
INFO - 2021-12-15 00:01:04 --> Output Class Initialized
INFO - 2021-12-15 00:01:04 --> Security Class Initialized
DEBUG - 2021-12-15 00:01:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 00:01:04 --> Input Class Initialized
INFO - 2021-12-15 00:01:04 --> Language Class Initialized
INFO - 2021-12-15 00:01:04 --> Loader Class Initialized
INFO - 2021-12-15 00:01:04 --> Helper loaded: url_helper
INFO - 2021-12-15 00:01:04 --> Helper loaded: form_helper
INFO - 2021-12-15 00:01:04 --> Helper loaded: common_helper
INFO - 2021-12-15 00:01:04 --> Database Driver Class Initialized
DEBUG - 2021-12-15 00:01:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 00:01:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 00:01:04 --> Controller Class Initialized
INFO - 2021-12-15 00:01:04 --> Form Validation Class Initialized
DEBUG - 2021-12-15 00:01:04 --> Encrypt Class Initialized
INFO - 2021-12-15 00:01:04 --> Model "Patient_model" initialized
INFO - 2021-12-15 00:01:04 --> Model "Patientcase_model" initialized
INFO - 2021-12-15 00:01:04 --> Model "Referredby_model" initialized
INFO - 2021-12-15 00:01:04 --> Model "Prefix_master" initialized
INFO - 2021-12-15 00:01:04 --> Model "Hospital_model" initialized
INFO - 2021-12-15 00:01:04 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-15 00:01:04 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2021-12-15 00:01:04 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-15 00:01:04 --> Final output sent to browser
DEBUG - 2021-12-15 00:01:04 --> Total execution time: 0.0837
ERROR - 2021-12-15 00:01:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 00:01:05 --> Config Class Initialized
INFO - 2021-12-15 00:01:05 --> Hooks Class Initialized
DEBUG - 2021-12-15 00:01:05 --> UTF-8 Support Enabled
INFO - 2021-12-15 00:01:05 --> Utf8 Class Initialized
INFO - 2021-12-15 00:01:05 --> URI Class Initialized
INFO - 2021-12-15 00:01:05 --> Router Class Initialized
INFO - 2021-12-15 00:01:05 --> Output Class Initialized
INFO - 2021-12-15 00:01:05 --> Security Class Initialized
DEBUG - 2021-12-15 00:01:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 00:01:05 --> Input Class Initialized
INFO - 2021-12-15 00:01:05 --> Language Class Initialized
ERROR - 2021-12-15 00:01:05 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-12-15 00:05:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 00:05:55 --> Config Class Initialized
INFO - 2021-12-15 00:05:55 --> Hooks Class Initialized
DEBUG - 2021-12-15 00:05:55 --> UTF-8 Support Enabled
INFO - 2021-12-15 00:05:55 --> Utf8 Class Initialized
INFO - 2021-12-15 00:05:55 --> URI Class Initialized
INFO - 2021-12-15 00:05:55 --> Router Class Initialized
INFO - 2021-12-15 00:05:55 --> Output Class Initialized
INFO - 2021-12-15 00:05:55 --> Security Class Initialized
DEBUG - 2021-12-15 00:05:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 00:05:55 --> Input Class Initialized
INFO - 2021-12-15 00:05:55 --> Language Class Initialized
INFO - 2021-12-15 00:05:55 --> Loader Class Initialized
INFO - 2021-12-15 00:05:55 --> Helper loaded: url_helper
INFO - 2021-12-15 00:05:55 --> Helper loaded: form_helper
INFO - 2021-12-15 00:05:55 --> Helper loaded: common_helper
INFO - 2021-12-15 00:05:55 --> Database Driver Class Initialized
DEBUG - 2021-12-15 00:05:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 00:05:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 00:05:55 --> Controller Class Initialized
INFO - 2021-12-15 00:05:55 --> Form Validation Class Initialized
DEBUG - 2021-12-15 00:05:55 --> Encrypt Class Initialized
INFO - 2021-12-15 00:05:55 --> Model "Patient_model" initialized
INFO - 2021-12-15 00:05:55 --> Model "Patientcase_model" initialized
INFO - 2021-12-15 00:05:55 --> Model "Referredby_model" initialized
INFO - 2021-12-15 00:05:55 --> Model "Prefix_master" initialized
INFO - 2021-12-15 00:05:55 --> Model "Hospital_model" initialized
INFO - 2021-12-15 00:05:55 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-15 00:06:02 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2021-12-15 00:06:02 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
ERROR - 2021-12-15 00:06:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 00:06:04 --> Config Class Initialized
INFO - 2021-12-15 00:06:04 --> Hooks Class Initialized
DEBUG - 2021-12-15 00:06:04 --> UTF-8 Support Enabled
INFO - 2021-12-15 00:06:04 --> Utf8 Class Initialized
INFO - 2021-12-15 00:06:04 --> URI Class Initialized
INFO - 2021-12-15 00:06:04 --> Router Class Initialized
INFO - 2021-12-15 00:06:04 --> Output Class Initialized
INFO - 2021-12-15 00:06:04 --> Security Class Initialized
DEBUG - 2021-12-15 00:06:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 00:06:04 --> Input Class Initialized
INFO - 2021-12-15 00:06:04 --> Language Class Initialized
ERROR - 2021-12-15 00:06:04 --> 404 Page Not Found: Karoclient/usersprofile
INFO - 2021-12-15 00:06:04 --> Final output sent to browser
DEBUG - 2021-12-15 00:06:04 --> Total execution time: 7.7366
ERROR - 2021-12-15 00:07:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 00:07:19 --> Config Class Initialized
INFO - 2021-12-15 00:07:19 --> Hooks Class Initialized
DEBUG - 2021-12-15 00:07:19 --> UTF-8 Support Enabled
INFO - 2021-12-15 00:07:19 --> Utf8 Class Initialized
INFO - 2021-12-15 00:07:19 --> URI Class Initialized
INFO - 2021-12-15 00:07:19 --> Router Class Initialized
INFO - 2021-12-15 00:07:19 --> Output Class Initialized
INFO - 2021-12-15 00:07:19 --> Security Class Initialized
DEBUG - 2021-12-15 00:07:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 00:07:19 --> Input Class Initialized
INFO - 2021-12-15 00:07:19 --> Language Class Initialized
INFO - 2021-12-15 00:07:19 --> Loader Class Initialized
INFO - 2021-12-15 00:07:19 --> Helper loaded: url_helper
INFO - 2021-12-15 00:07:19 --> Helper loaded: form_helper
INFO - 2021-12-15 00:07:19 --> Helper loaded: common_helper
INFO - 2021-12-15 00:07:19 --> Database Driver Class Initialized
DEBUG - 2021-12-15 00:07:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 00:07:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 00:07:19 --> Controller Class Initialized
INFO - 2021-12-15 00:07:19 --> Form Validation Class Initialized
DEBUG - 2021-12-15 00:07:19 --> Encrypt Class Initialized
INFO - 2021-12-15 00:07:19 --> Model "Patient_model" initialized
INFO - 2021-12-15 00:07:19 --> Model "Patientcase_model" initialized
INFO - 2021-12-15 00:07:19 --> Model "Prefix_master" initialized
INFO - 2021-12-15 00:07:19 --> Model "Users_model" initialized
INFO - 2021-12-15 00:07:19 --> Model "Hospital_model" initialized
INFO - 2021-12-15 00:07:19 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-15 00:07:19 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2021-12-15 00:07:19 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-15 00:07:19 --> Final output sent to browser
DEBUG - 2021-12-15 00:07:19 --> Total execution time: 0.1116
ERROR - 2021-12-15 00:07:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 00:07:19 --> Config Class Initialized
INFO - 2021-12-15 00:07:19 --> Hooks Class Initialized
DEBUG - 2021-12-15 00:07:19 --> UTF-8 Support Enabled
INFO - 2021-12-15 00:07:19 --> Utf8 Class Initialized
INFO - 2021-12-15 00:07:19 --> URI Class Initialized
INFO - 2021-12-15 00:07:19 --> Router Class Initialized
INFO - 2021-12-15 00:07:19 --> Output Class Initialized
INFO - 2021-12-15 00:07:19 --> Security Class Initialized
DEBUG - 2021-12-15 00:07:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 00:07:19 --> Input Class Initialized
INFO - 2021-12-15 00:07:19 --> Language Class Initialized
ERROR - 2021-12-15 00:07:19 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-12-15 00:07:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 00:07:43 --> Config Class Initialized
INFO - 2021-12-15 00:07:43 --> Hooks Class Initialized
DEBUG - 2021-12-15 00:07:43 --> UTF-8 Support Enabled
INFO - 2021-12-15 00:07:43 --> Utf8 Class Initialized
INFO - 2021-12-15 00:07:43 --> URI Class Initialized
INFO - 2021-12-15 00:07:43 --> Router Class Initialized
INFO - 2021-12-15 00:07:43 --> Output Class Initialized
INFO - 2021-12-15 00:07:43 --> Security Class Initialized
DEBUG - 2021-12-15 00:07:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 00:07:43 --> Input Class Initialized
INFO - 2021-12-15 00:07:43 --> Language Class Initialized
INFO - 2021-12-15 00:07:43 --> Loader Class Initialized
INFO - 2021-12-15 00:07:43 --> Helper loaded: url_helper
INFO - 2021-12-15 00:07:43 --> Helper loaded: form_helper
INFO - 2021-12-15 00:07:43 --> Helper loaded: common_helper
INFO - 2021-12-15 00:07:43 --> Database Driver Class Initialized
DEBUG - 2021-12-15 00:07:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 00:07:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 00:07:43 --> Controller Class Initialized
INFO - 2021-12-15 00:07:43 --> Form Validation Class Initialized
DEBUG - 2021-12-15 00:07:43 --> Encrypt Class Initialized
INFO - 2021-12-15 00:07:43 --> Model "Patient_model" initialized
INFO - 2021-12-15 00:07:43 --> Model "Patientcase_model" initialized
INFO - 2021-12-15 00:07:43 --> Model "Referredby_model" initialized
INFO - 2021-12-15 00:07:43 --> Model "Prefix_master" initialized
INFO - 2021-12-15 00:07:43 --> Model "Hospital_model" initialized
INFO - 2021-12-15 00:07:43 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-15 00:07:49 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2021-12-15 00:07:49 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-15 00:07:51 --> Final output sent to browser
DEBUG - 2021-12-15 00:07:51 --> Total execution time: 6.0166
ERROR - 2021-12-15 00:08:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 00:08:23 --> Config Class Initialized
INFO - 2021-12-15 00:08:23 --> Hooks Class Initialized
DEBUG - 2021-12-15 00:08:23 --> UTF-8 Support Enabled
INFO - 2021-12-15 00:08:23 --> Utf8 Class Initialized
INFO - 2021-12-15 00:08:23 --> URI Class Initialized
INFO - 2021-12-15 00:08:23 --> Router Class Initialized
INFO - 2021-12-15 00:08:23 --> Output Class Initialized
INFO - 2021-12-15 00:08:23 --> Security Class Initialized
DEBUG - 2021-12-15 00:08:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 00:08:23 --> Input Class Initialized
INFO - 2021-12-15 00:08:23 --> Language Class Initialized
INFO - 2021-12-15 00:08:23 --> Loader Class Initialized
INFO - 2021-12-15 00:08:23 --> Helper loaded: url_helper
INFO - 2021-12-15 00:08:23 --> Helper loaded: form_helper
INFO - 2021-12-15 00:08:23 --> Helper loaded: common_helper
INFO - 2021-12-15 00:08:23 --> Database Driver Class Initialized
DEBUG - 2021-12-15 00:08:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 00:08:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 00:08:23 --> Controller Class Initialized
INFO - 2021-12-15 00:08:23 --> Form Validation Class Initialized
DEBUG - 2021-12-15 00:08:23 --> Encrypt Class Initialized
INFO - 2021-12-15 00:08:23 --> Model "Patient_model" initialized
INFO - 2021-12-15 00:08:23 --> Model "Patientcase_model" initialized
INFO - 2021-12-15 00:08:23 --> Model "Referredby_model" initialized
INFO - 2021-12-15 00:08:23 --> Model "Prefix_master" initialized
INFO - 2021-12-15 00:08:23 --> Model "Hospital_model" initialized
INFO - 2021-12-15 00:08:23 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-15 00:08:23 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2021-12-15 00:08:23 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-15 00:08:23 --> Final output sent to browser
DEBUG - 2021-12-15 00:08:23 --> Total execution time: 0.0868
ERROR - 2021-12-15 00:08:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 00:08:23 --> Config Class Initialized
INFO - 2021-12-15 00:08:23 --> Hooks Class Initialized
DEBUG - 2021-12-15 00:08:23 --> UTF-8 Support Enabled
INFO - 2021-12-15 00:08:23 --> Utf8 Class Initialized
INFO - 2021-12-15 00:08:23 --> URI Class Initialized
INFO - 2021-12-15 00:08:23 --> Router Class Initialized
INFO - 2021-12-15 00:08:23 --> Output Class Initialized
INFO - 2021-12-15 00:08:23 --> Security Class Initialized
DEBUG - 2021-12-15 00:08:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 00:08:23 --> Input Class Initialized
INFO - 2021-12-15 00:08:23 --> Language Class Initialized
ERROR - 2021-12-15 00:08:23 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-12-15 00:08:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 00:08:32 --> Config Class Initialized
INFO - 2021-12-15 00:08:32 --> Hooks Class Initialized
DEBUG - 2021-12-15 00:08:32 --> UTF-8 Support Enabled
INFO - 2021-12-15 00:08:32 --> Utf8 Class Initialized
INFO - 2021-12-15 00:08:32 --> URI Class Initialized
INFO - 2021-12-15 00:08:32 --> Router Class Initialized
INFO - 2021-12-15 00:08:32 --> Output Class Initialized
INFO - 2021-12-15 00:08:32 --> Security Class Initialized
DEBUG - 2021-12-15 00:08:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 00:08:32 --> Input Class Initialized
INFO - 2021-12-15 00:08:32 --> Language Class Initialized
INFO - 2021-12-15 00:08:32 --> Loader Class Initialized
INFO - 2021-12-15 00:08:32 --> Helper loaded: url_helper
INFO - 2021-12-15 00:08:32 --> Helper loaded: form_helper
INFO - 2021-12-15 00:08:32 --> Helper loaded: common_helper
INFO - 2021-12-15 00:08:32 --> Database Driver Class Initialized
DEBUG - 2021-12-15 00:08:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 00:08:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 00:08:32 --> Controller Class Initialized
INFO - 2021-12-15 00:08:32 --> Form Validation Class Initialized
DEBUG - 2021-12-15 00:08:32 --> Encrypt Class Initialized
INFO - 2021-12-15 00:08:32 --> Model "Patient_model" initialized
INFO - 2021-12-15 00:08:32 --> Model "Patientcase_model" initialized
INFO - 2021-12-15 00:08:32 --> Model "Referredby_model" initialized
INFO - 2021-12-15 00:08:32 --> Model "Prefix_master" initialized
INFO - 2021-12-15 00:08:32 --> Model "Hospital_model" initialized
INFO - 2021-12-15 00:08:32 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-15 00:08:33 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2021-12-15 00:08:33 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-15 00:08:34 --> Final output sent to browser
DEBUG - 2021-12-15 00:08:34 --> Total execution time: 1.6178
ERROR - 2021-12-15 00:08:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 00:08:34 --> Config Class Initialized
INFO - 2021-12-15 00:08:34 --> Hooks Class Initialized
DEBUG - 2021-12-15 00:08:34 --> UTF-8 Support Enabled
INFO - 2021-12-15 00:08:34 --> Utf8 Class Initialized
INFO - 2021-12-15 00:08:34 --> URI Class Initialized
INFO - 2021-12-15 00:08:34 --> Router Class Initialized
INFO - 2021-12-15 00:08:34 --> Output Class Initialized
INFO - 2021-12-15 00:08:34 --> Security Class Initialized
DEBUG - 2021-12-15 00:08:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 00:08:34 --> Input Class Initialized
INFO - 2021-12-15 00:08:34 --> Language Class Initialized
ERROR - 2021-12-15 00:08:34 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-12-15 00:09:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 00:09:45 --> Config Class Initialized
INFO - 2021-12-15 00:09:45 --> Hooks Class Initialized
DEBUG - 2021-12-15 00:09:45 --> UTF-8 Support Enabled
INFO - 2021-12-15 00:09:45 --> Utf8 Class Initialized
INFO - 2021-12-15 00:09:45 --> URI Class Initialized
INFO - 2021-12-15 00:09:45 --> Router Class Initialized
INFO - 2021-12-15 00:09:45 --> Output Class Initialized
INFO - 2021-12-15 00:09:45 --> Security Class Initialized
DEBUG - 2021-12-15 00:09:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 00:09:45 --> Input Class Initialized
INFO - 2021-12-15 00:09:45 --> Language Class Initialized
INFO - 2021-12-15 00:09:45 --> Loader Class Initialized
INFO - 2021-12-15 00:09:45 --> Helper loaded: url_helper
INFO - 2021-12-15 00:09:45 --> Helper loaded: form_helper
INFO - 2021-12-15 00:09:45 --> Helper loaded: common_helper
INFO - 2021-12-15 00:09:45 --> Database Driver Class Initialized
DEBUG - 2021-12-15 00:09:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 00:09:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 00:09:45 --> Controller Class Initialized
INFO - 2021-12-15 00:09:45 --> Form Validation Class Initialized
INFO - 2021-12-15 00:09:45 --> Model "Case_model" initialized
INFO - 2021-12-15 00:09:45 --> Model "Patientcase_model" initialized
INFO - 2021-12-15 00:09:46 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-15 00:09:46 --> File loaded: /home3/karoteam/public_html/application/views/cases/new_case.php
INFO - 2021-12-15 00:09:46 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-15 00:09:47 --> Final output sent to browser
DEBUG - 2021-12-15 00:09:47 --> Total execution time: 0.5652
ERROR - 2021-12-15 00:09:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 00:09:47 --> Config Class Initialized
INFO - 2021-12-15 00:09:47 --> Hooks Class Initialized
DEBUG - 2021-12-15 00:09:47 --> UTF-8 Support Enabled
INFO - 2021-12-15 00:09:47 --> Utf8 Class Initialized
INFO - 2021-12-15 00:09:47 --> URI Class Initialized
INFO - 2021-12-15 00:09:47 --> Router Class Initialized
INFO - 2021-12-15 00:09:47 --> Output Class Initialized
INFO - 2021-12-15 00:09:47 --> Security Class Initialized
DEBUG - 2021-12-15 00:09:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 00:09:47 --> Input Class Initialized
INFO - 2021-12-15 00:09:47 --> Language Class Initialized
ERROR - 2021-12-15 00:09:47 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-12-15 00:10:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 00:10:45 --> Config Class Initialized
INFO - 2021-12-15 00:10:45 --> Hooks Class Initialized
DEBUG - 2021-12-15 00:10:45 --> UTF-8 Support Enabled
INFO - 2021-12-15 00:10:45 --> Utf8 Class Initialized
INFO - 2021-12-15 00:10:45 --> URI Class Initialized
INFO - 2021-12-15 00:10:45 --> Router Class Initialized
INFO - 2021-12-15 00:10:45 --> Output Class Initialized
INFO - 2021-12-15 00:10:45 --> Security Class Initialized
DEBUG - 2021-12-15 00:10:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 00:10:45 --> Input Class Initialized
INFO - 2021-12-15 00:10:45 --> Language Class Initialized
INFO - 2021-12-15 00:10:45 --> Loader Class Initialized
INFO - 2021-12-15 00:10:45 --> Helper loaded: url_helper
INFO - 2021-12-15 00:10:45 --> Helper loaded: form_helper
INFO - 2021-12-15 00:10:45 --> Helper loaded: common_helper
INFO - 2021-12-15 00:10:45 --> Database Driver Class Initialized
DEBUG - 2021-12-15 00:10:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 00:10:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 00:10:45 --> Controller Class Initialized
INFO - 2021-12-15 00:10:45 --> Form Validation Class Initialized
DEBUG - 2021-12-15 00:10:45 --> Encrypt Class Initialized
INFO - 2021-12-15 00:10:45 --> Model "Patient_model" initialized
INFO - 2021-12-15 00:10:45 --> Model "Patientcase_model" initialized
INFO - 2021-12-15 00:10:45 --> Model "Referredby_model" initialized
INFO - 2021-12-15 00:10:45 --> Model "Prefix_master" initialized
INFO - 2021-12-15 00:10:45 --> Model "Hospital_model" initialized
INFO - 2021-12-15 00:10:45 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-15 00:10:53 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2021-12-15 00:10:53 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
ERROR - 2021-12-15 00:10:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 00:10:54 --> Config Class Initialized
INFO - 2021-12-15 00:10:54 --> Hooks Class Initialized
DEBUG - 2021-12-15 00:10:54 --> UTF-8 Support Enabled
INFO - 2021-12-15 00:10:54 --> Utf8 Class Initialized
INFO - 2021-12-15 00:10:54 --> URI Class Initialized
INFO - 2021-12-15 00:10:54 --> Router Class Initialized
INFO - 2021-12-15 00:10:54 --> Output Class Initialized
INFO - 2021-12-15 00:10:54 --> Security Class Initialized
DEBUG - 2021-12-15 00:10:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 00:10:54 --> Input Class Initialized
INFO - 2021-12-15 00:10:54 --> Language Class Initialized
ERROR - 2021-12-15 00:10:54 --> 404 Page Not Found: Karoclient/usersprofile
INFO - 2021-12-15 00:10:55 --> Final output sent to browser
DEBUG - 2021-12-15 00:10:55 --> Total execution time: 7.9521
ERROR - 2021-12-15 00:15:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 00:15:29 --> Config Class Initialized
INFO - 2021-12-15 00:15:29 --> Hooks Class Initialized
DEBUG - 2021-12-15 00:15:29 --> UTF-8 Support Enabled
INFO - 2021-12-15 00:15:29 --> Utf8 Class Initialized
INFO - 2021-12-15 00:15:29 --> URI Class Initialized
INFO - 2021-12-15 00:15:29 --> Router Class Initialized
INFO - 2021-12-15 00:15:29 --> Output Class Initialized
INFO - 2021-12-15 00:15:29 --> Security Class Initialized
DEBUG - 2021-12-15 00:15:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 00:15:29 --> Input Class Initialized
INFO - 2021-12-15 00:15:29 --> Language Class Initialized
INFO - 2021-12-15 00:15:29 --> Loader Class Initialized
INFO - 2021-12-15 00:15:29 --> Helper loaded: url_helper
INFO - 2021-12-15 00:15:29 --> Helper loaded: form_helper
INFO - 2021-12-15 00:15:29 --> Helper loaded: common_helper
INFO - 2021-12-15 00:15:29 --> Database Driver Class Initialized
DEBUG - 2021-12-15 00:15:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 00:15:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 00:15:29 --> Controller Class Initialized
INFO - 2021-12-15 00:15:29 --> Form Validation Class Initialized
DEBUG - 2021-12-15 00:15:29 --> Encrypt Class Initialized
INFO - 2021-12-15 00:15:29 --> Model "Login_model" initialized
INFO - 2021-12-15 00:15:29 --> Model "Dashboard_model" initialized
INFO - 2021-12-15 00:15:29 --> Model "Case_model" initialized
INFO - 2021-12-15 00:15:38 --> File loaded: /home3/karoteam/public_html/application/views/header.php
ERROR - 2021-12-15 00:15:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 00:15:40 --> Config Class Initialized
INFO - 2021-12-15 00:15:40 --> Hooks Class Initialized
DEBUG - 2021-12-15 00:15:40 --> UTF-8 Support Enabled
INFO - 2021-12-15 00:15:40 --> Utf8 Class Initialized
INFO - 2021-12-15 00:15:40 --> URI Class Initialized
INFO - 2021-12-15 00:15:40 --> Router Class Initialized
INFO - 2021-12-15 00:15:40 --> Output Class Initialized
INFO - 2021-12-15 00:15:40 --> Security Class Initialized
DEBUG - 2021-12-15 00:15:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 00:15:40 --> Input Class Initialized
INFO - 2021-12-15 00:15:40 --> Language Class Initialized
INFO - 2021-12-15 00:15:40 --> Loader Class Initialized
INFO - 2021-12-15 00:15:40 --> Helper loaded: url_helper
INFO - 2021-12-15 00:15:40 --> Helper loaded: form_helper
INFO - 2021-12-15 00:15:40 --> Helper loaded: common_helper
INFO - 2021-12-15 00:15:40 --> Database Driver Class Initialized
DEBUG - 2021-12-15 00:15:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 00:15:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 00:15:40 --> Controller Class Initialized
INFO - 2021-12-15 00:15:40 --> Form Validation Class Initialized
DEBUG - 2021-12-15 00:15:40 --> Encrypt Class Initialized
INFO - 2021-12-15 00:15:40 --> Model "Payment_model" initialized
INFO - 2021-12-15 00:15:40 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-15 00:15:40 --> File loaded: /home3/karoteam/public_html/application/views/payment/index.php
INFO - 2021-12-15 00:15:40 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-15 00:15:40 --> Final output sent to browser
DEBUG - 2021-12-15 00:15:40 --> Total execution time: 0.0259
ERROR - 2021-12-15 00:15:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 00:15:41 --> Config Class Initialized
INFO - 2021-12-15 00:15:41 --> Hooks Class Initialized
DEBUG - 2021-12-15 00:15:41 --> UTF-8 Support Enabled
INFO - 2021-12-15 00:15:41 --> Utf8 Class Initialized
INFO - 2021-12-15 00:15:41 --> URI Class Initialized
INFO - 2021-12-15 00:15:41 --> Router Class Initialized
INFO - 2021-12-15 00:15:41 --> Output Class Initialized
INFO - 2021-12-15 00:15:41 --> Security Class Initialized
DEBUG - 2021-12-15 00:15:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 00:15:41 --> Input Class Initialized
INFO - 2021-12-15 00:15:41 --> Language Class Initialized
ERROR - 2021-12-15 00:15:41 --> 404 Page Not Found: Karoclient/usersprofile
INFO - 2021-12-15 00:15:48 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2021-12-15 00:15:48 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-15 00:15:48 --> Final output sent to browser
DEBUG - 2021-12-15 00:15:48 --> Total execution time: 19.1702
ERROR - 2021-12-15 00:16:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 00:16:44 --> Config Class Initialized
INFO - 2021-12-15 00:16:44 --> Hooks Class Initialized
DEBUG - 2021-12-15 00:16:44 --> UTF-8 Support Enabled
INFO - 2021-12-15 00:16:44 --> Utf8 Class Initialized
INFO - 2021-12-15 00:16:44 --> URI Class Initialized
INFO - 2021-12-15 00:16:44 --> Router Class Initialized
INFO - 2021-12-15 00:16:44 --> Output Class Initialized
INFO - 2021-12-15 00:16:44 --> Security Class Initialized
DEBUG - 2021-12-15 00:16:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 00:16:44 --> Input Class Initialized
INFO - 2021-12-15 00:16:44 --> Language Class Initialized
INFO - 2021-12-15 00:16:44 --> Loader Class Initialized
INFO - 2021-12-15 00:16:44 --> Helper loaded: url_helper
INFO - 2021-12-15 00:16:44 --> Helper loaded: form_helper
INFO - 2021-12-15 00:16:44 --> Helper loaded: common_helper
INFO - 2021-12-15 00:16:44 --> Database Driver Class Initialized
DEBUG - 2021-12-15 00:16:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 00:16:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 00:16:44 --> Controller Class Initialized
INFO - 2021-12-15 00:16:44 --> Form Validation Class Initialized
DEBUG - 2021-12-15 00:16:44 --> Encrypt Class Initialized
INFO - 2021-12-15 00:16:44 --> Model "Referredby_model" initialized
INFO - 2021-12-15 00:16:44 --> Model "Users_model" initialized
INFO - 2021-12-15 00:16:44 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-15 00:16:44 --> File loaded: /home3/karoteam/public_html/application/views/users/index.php
INFO - 2021-12-15 00:16:44 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-15 00:16:44 --> Final output sent to browser
DEBUG - 2021-12-15 00:16:44 --> Total execution time: 0.0399
ERROR - 2021-12-15 00:16:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 00:16:45 --> Config Class Initialized
INFO - 2021-12-15 00:16:45 --> Hooks Class Initialized
DEBUG - 2021-12-15 00:16:45 --> UTF-8 Support Enabled
INFO - 2021-12-15 00:16:45 --> Utf8 Class Initialized
INFO - 2021-12-15 00:16:45 --> URI Class Initialized
INFO - 2021-12-15 00:16:45 --> Router Class Initialized
INFO - 2021-12-15 00:16:45 --> Output Class Initialized
INFO - 2021-12-15 00:16:45 --> Security Class Initialized
DEBUG - 2021-12-15 00:16:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 00:16:45 --> Input Class Initialized
INFO - 2021-12-15 00:16:45 --> Language Class Initialized
ERROR - 2021-12-15 00:16:45 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-12-15 00:16:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 00:16:48 --> Config Class Initialized
INFO - 2021-12-15 00:16:48 --> Hooks Class Initialized
DEBUG - 2021-12-15 00:16:48 --> UTF-8 Support Enabled
INFO - 2021-12-15 00:16:48 --> Utf8 Class Initialized
INFO - 2021-12-15 00:16:48 --> URI Class Initialized
INFO - 2021-12-15 00:16:48 --> Router Class Initialized
INFO - 2021-12-15 00:16:48 --> Output Class Initialized
INFO - 2021-12-15 00:16:48 --> Security Class Initialized
DEBUG - 2021-12-15 00:16:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 00:16:48 --> Input Class Initialized
INFO - 2021-12-15 00:16:48 --> Language Class Initialized
INFO - 2021-12-15 00:16:48 --> Loader Class Initialized
INFO - 2021-12-15 00:16:48 --> Helper loaded: url_helper
INFO - 2021-12-15 00:16:48 --> Helper loaded: form_helper
INFO - 2021-12-15 00:16:48 --> Helper loaded: common_helper
INFO - 2021-12-15 00:16:48 --> Database Driver Class Initialized
DEBUG - 2021-12-15 00:16:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 00:16:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 00:16:48 --> Controller Class Initialized
INFO - 2021-12-15 00:16:48 --> Form Validation Class Initialized
DEBUG - 2021-12-15 00:16:48 --> Encrypt Class Initialized
INFO - 2021-12-15 00:16:48 --> Model "Referredby_model" initialized
INFO - 2021-12-15 00:16:48 --> Model "Users_model" initialized
INFO - 2021-12-15 00:16:48 --> Final output sent to browser
DEBUG - 2021-12-15 00:16:48 --> Total execution time: 0.0261
ERROR - 2021-12-15 00:17:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 00:17:31 --> Config Class Initialized
INFO - 2021-12-15 00:17:31 --> Hooks Class Initialized
DEBUG - 2021-12-15 00:17:31 --> UTF-8 Support Enabled
INFO - 2021-12-15 00:17:31 --> Utf8 Class Initialized
INFO - 2021-12-15 00:17:31 --> URI Class Initialized
INFO - 2021-12-15 00:17:31 --> Router Class Initialized
INFO - 2021-12-15 00:17:31 --> Output Class Initialized
INFO - 2021-12-15 00:17:31 --> Security Class Initialized
DEBUG - 2021-12-15 00:17:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 00:17:31 --> Input Class Initialized
INFO - 2021-12-15 00:17:31 --> Language Class Initialized
INFO - 2021-12-15 00:17:31 --> Loader Class Initialized
INFO - 2021-12-15 00:17:31 --> Helper loaded: url_helper
INFO - 2021-12-15 00:17:31 --> Helper loaded: form_helper
INFO - 2021-12-15 00:17:31 --> Helper loaded: common_helper
INFO - 2021-12-15 00:17:31 --> Database Driver Class Initialized
DEBUG - 2021-12-15 00:17:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 00:17:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 00:17:31 --> Controller Class Initialized
INFO - 2021-12-15 00:17:31 --> Form Validation Class Initialized
DEBUG - 2021-12-15 00:17:31 --> Encrypt Class Initialized
INFO - 2021-12-15 00:17:31 --> Model "Referredby_model" initialized
INFO - 2021-12-15 00:17:31 --> Model "Users_model" initialized
ERROR - 2021-12-15 00:17:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 00:17:32 --> Config Class Initialized
INFO - 2021-12-15 00:17:32 --> Hooks Class Initialized
DEBUG - 2021-12-15 00:17:32 --> UTF-8 Support Enabled
INFO - 2021-12-15 00:17:32 --> Utf8 Class Initialized
INFO - 2021-12-15 00:17:32 --> URI Class Initialized
INFO - 2021-12-15 00:17:32 --> Router Class Initialized
INFO - 2021-12-15 00:17:32 --> Output Class Initialized
INFO - 2021-12-15 00:17:32 --> Security Class Initialized
DEBUG - 2021-12-15 00:17:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 00:17:32 --> Input Class Initialized
INFO - 2021-12-15 00:17:32 --> Language Class Initialized
INFO - 2021-12-15 00:17:32 --> Loader Class Initialized
INFO - 2021-12-15 00:17:32 --> Helper loaded: url_helper
INFO - 2021-12-15 00:17:32 --> Helper loaded: form_helper
INFO - 2021-12-15 00:17:32 --> Helper loaded: common_helper
INFO - 2021-12-15 00:17:32 --> Database Driver Class Initialized
DEBUG - 2021-12-15 00:17:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 00:17:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 00:17:32 --> Controller Class Initialized
INFO - 2021-12-15 00:17:32 --> Form Validation Class Initialized
DEBUG - 2021-12-15 00:17:32 --> Encrypt Class Initialized
INFO - 2021-12-15 00:17:32 --> Model "Referredby_model" initialized
INFO - 2021-12-15 00:17:32 --> Model "Users_model" initialized
INFO - 2021-12-15 00:17:32 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-15 00:17:32 --> File loaded: /home3/karoteam/public_html/application/views/users/index.php
INFO - 2021-12-15 00:17:32 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-15 00:17:32 --> Final output sent to browser
DEBUG - 2021-12-15 00:17:32 --> Total execution time: 0.0418
ERROR - 2021-12-15 00:17:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 00:17:33 --> Config Class Initialized
INFO - 2021-12-15 00:17:33 --> Hooks Class Initialized
DEBUG - 2021-12-15 00:17:33 --> UTF-8 Support Enabled
INFO - 2021-12-15 00:17:33 --> Utf8 Class Initialized
INFO - 2021-12-15 00:17:33 --> URI Class Initialized
INFO - 2021-12-15 00:17:33 --> Router Class Initialized
INFO - 2021-12-15 00:17:33 --> Output Class Initialized
INFO - 2021-12-15 00:17:33 --> Security Class Initialized
DEBUG - 2021-12-15 00:17:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 00:17:33 --> Input Class Initialized
INFO - 2021-12-15 00:17:33 --> Language Class Initialized
ERROR - 2021-12-15 00:17:33 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-12-15 00:17:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 00:17:37 --> Config Class Initialized
INFO - 2021-12-15 00:17:37 --> Hooks Class Initialized
DEBUG - 2021-12-15 00:17:37 --> UTF-8 Support Enabled
INFO - 2021-12-15 00:17:37 --> Utf8 Class Initialized
INFO - 2021-12-15 00:17:37 --> URI Class Initialized
INFO - 2021-12-15 00:17:37 --> Router Class Initialized
INFO - 2021-12-15 00:17:37 --> Output Class Initialized
INFO - 2021-12-15 00:17:37 --> Security Class Initialized
DEBUG - 2021-12-15 00:17:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 00:17:37 --> Input Class Initialized
INFO - 2021-12-15 00:17:37 --> Language Class Initialized
INFO - 2021-12-15 00:17:37 --> Loader Class Initialized
INFO - 2021-12-15 00:17:37 --> Helper loaded: url_helper
INFO - 2021-12-15 00:17:37 --> Helper loaded: form_helper
INFO - 2021-12-15 00:17:37 --> Helper loaded: common_helper
INFO - 2021-12-15 00:17:37 --> Database Driver Class Initialized
DEBUG - 2021-12-15 00:17:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 00:17:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 00:17:37 --> Controller Class Initialized
INFO - 2021-12-15 00:17:37 --> Form Validation Class Initialized
DEBUG - 2021-12-15 00:17:37 --> Encrypt Class Initialized
INFO - 2021-12-15 00:17:37 --> Model "Referredby_model" initialized
INFO - 2021-12-15 00:17:37 --> Model "Users_model" initialized
INFO - 2021-12-15 00:17:37 --> Final output sent to browser
DEBUG - 2021-12-15 00:17:37 --> Total execution time: 0.0236
ERROR - 2021-12-15 00:17:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 00:17:44 --> Config Class Initialized
INFO - 2021-12-15 00:17:44 --> Hooks Class Initialized
DEBUG - 2021-12-15 00:17:44 --> UTF-8 Support Enabled
INFO - 2021-12-15 00:17:44 --> Utf8 Class Initialized
INFO - 2021-12-15 00:17:44 --> URI Class Initialized
INFO - 2021-12-15 00:17:44 --> Router Class Initialized
INFO - 2021-12-15 00:17:44 --> Output Class Initialized
INFO - 2021-12-15 00:17:44 --> Security Class Initialized
DEBUG - 2021-12-15 00:17:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 00:17:44 --> Input Class Initialized
INFO - 2021-12-15 00:17:44 --> Language Class Initialized
INFO - 2021-12-15 00:17:44 --> Loader Class Initialized
INFO - 2021-12-15 00:17:44 --> Helper loaded: url_helper
INFO - 2021-12-15 00:17:44 --> Helper loaded: form_helper
INFO - 2021-12-15 00:17:44 --> Helper loaded: common_helper
INFO - 2021-12-15 00:17:44 --> Database Driver Class Initialized
DEBUG - 2021-12-15 00:17:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 00:17:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 00:17:44 --> Controller Class Initialized
INFO - 2021-12-15 00:17:44 --> Form Validation Class Initialized
DEBUG - 2021-12-15 00:17:44 --> Encrypt Class Initialized
INFO - 2021-12-15 00:17:44 --> Model "Referredby_model" initialized
INFO - 2021-12-15 00:17:44 --> Model "Users_model" initialized
ERROR - 2021-12-15 00:17:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 00:17:45 --> Config Class Initialized
INFO - 2021-12-15 00:17:45 --> Hooks Class Initialized
DEBUG - 2021-12-15 00:17:45 --> UTF-8 Support Enabled
INFO - 2021-12-15 00:17:45 --> Utf8 Class Initialized
INFO - 2021-12-15 00:17:45 --> URI Class Initialized
INFO - 2021-12-15 00:17:45 --> Router Class Initialized
INFO - 2021-12-15 00:17:45 --> Output Class Initialized
INFO - 2021-12-15 00:17:45 --> Security Class Initialized
DEBUG - 2021-12-15 00:17:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 00:17:45 --> Input Class Initialized
INFO - 2021-12-15 00:17:45 --> Language Class Initialized
INFO - 2021-12-15 00:17:45 --> Loader Class Initialized
INFO - 2021-12-15 00:17:45 --> Helper loaded: url_helper
INFO - 2021-12-15 00:17:45 --> Helper loaded: form_helper
INFO - 2021-12-15 00:17:45 --> Helper loaded: common_helper
INFO - 2021-12-15 00:17:45 --> Database Driver Class Initialized
DEBUG - 2021-12-15 00:17:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 00:17:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 00:17:45 --> Controller Class Initialized
INFO - 2021-12-15 00:17:45 --> Form Validation Class Initialized
DEBUG - 2021-12-15 00:17:45 --> Encrypt Class Initialized
INFO - 2021-12-15 00:17:45 --> Model "Referredby_model" initialized
INFO - 2021-12-15 00:17:45 --> Model "Users_model" initialized
INFO - 2021-12-15 00:17:45 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-15 00:17:45 --> File loaded: /home3/karoteam/public_html/application/views/users/index.php
INFO - 2021-12-15 00:17:45 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-15 00:17:45 --> Final output sent to browser
DEBUG - 2021-12-15 00:17:45 --> Total execution time: 0.0302
ERROR - 2021-12-15 00:17:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 00:17:46 --> Config Class Initialized
INFO - 2021-12-15 00:17:46 --> Hooks Class Initialized
DEBUG - 2021-12-15 00:17:46 --> UTF-8 Support Enabled
INFO - 2021-12-15 00:17:46 --> Utf8 Class Initialized
INFO - 2021-12-15 00:17:46 --> URI Class Initialized
INFO - 2021-12-15 00:17:46 --> Router Class Initialized
INFO - 2021-12-15 00:17:46 --> Output Class Initialized
INFO - 2021-12-15 00:17:46 --> Security Class Initialized
DEBUG - 2021-12-15 00:17:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 00:17:46 --> Input Class Initialized
INFO - 2021-12-15 00:17:46 --> Language Class Initialized
ERROR - 2021-12-15 00:17:46 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-12-15 00:17:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 00:17:52 --> Config Class Initialized
INFO - 2021-12-15 00:17:52 --> Hooks Class Initialized
DEBUG - 2021-12-15 00:17:52 --> UTF-8 Support Enabled
INFO - 2021-12-15 00:17:52 --> Utf8 Class Initialized
INFO - 2021-12-15 00:17:52 --> URI Class Initialized
INFO - 2021-12-15 00:17:52 --> Router Class Initialized
INFO - 2021-12-15 00:17:52 --> Output Class Initialized
INFO - 2021-12-15 00:17:52 --> Security Class Initialized
DEBUG - 2021-12-15 00:17:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 00:17:52 --> Input Class Initialized
INFO - 2021-12-15 00:17:52 --> Language Class Initialized
INFO - 2021-12-15 00:17:52 --> Loader Class Initialized
INFO - 2021-12-15 00:17:52 --> Helper loaded: url_helper
INFO - 2021-12-15 00:17:52 --> Helper loaded: form_helper
INFO - 2021-12-15 00:17:52 --> Helper loaded: common_helper
INFO - 2021-12-15 00:17:52 --> Database Driver Class Initialized
DEBUG - 2021-12-15 00:17:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 00:17:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 00:17:52 --> Controller Class Initialized
INFO - 2021-12-15 00:17:52 --> Form Validation Class Initialized
DEBUG - 2021-12-15 00:17:52 --> Encrypt Class Initialized
INFO - 2021-12-15 00:17:52 --> Model "Referredby_model" initialized
INFO - 2021-12-15 00:17:52 --> Model "Users_model" initialized
INFO - 2021-12-15 00:17:52 --> Final output sent to browser
DEBUG - 2021-12-15 00:17:52 --> Total execution time: 0.0206
ERROR - 2021-12-15 00:17:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 00:17:57 --> Config Class Initialized
INFO - 2021-12-15 00:17:57 --> Hooks Class Initialized
DEBUG - 2021-12-15 00:17:57 --> UTF-8 Support Enabled
INFO - 2021-12-15 00:17:57 --> Utf8 Class Initialized
INFO - 2021-12-15 00:17:57 --> URI Class Initialized
INFO - 2021-12-15 00:17:57 --> Router Class Initialized
INFO - 2021-12-15 00:17:57 --> Output Class Initialized
INFO - 2021-12-15 00:17:57 --> Security Class Initialized
DEBUG - 2021-12-15 00:17:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 00:17:57 --> Input Class Initialized
INFO - 2021-12-15 00:17:57 --> Language Class Initialized
INFO - 2021-12-15 00:17:57 --> Loader Class Initialized
INFO - 2021-12-15 00:17:57 --> Helper loaded: url_helper
INFO - 2021-12-15 00:17:57 --> Helper loaded: form_helper
INFO - 2021-12-15 00:17:57 --> Helper loaded: common_helper
INFO - 2021-12-15 00:17:57 --> Database Driver Class Initialized
DEBUG - 2021-12-15 00:17:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 00:17:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 00:17:57 --> Controller Class Initialized
INFO - 2021-12-15 00:17:57 --> Form Validation Class Initialized
DEBUG - 2021-12-15 00:17:57 --> Encrypt Class Initialized
INFO - 2021-12-15 00:17:57 --> Model "Referredby_model" initialized
INFO - 2021-12-15 00:17:57 --> Model "Users_model" initialized
ERROR - 2021-12-15 00:17:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 00:17:58 --> Config Class Initialized
INFO - 2021-12-15 00:17:58 --> Hooks Class Initialized
DEBUG - 2021-12-15 00:17:58 --> UTF-8 Support Enabled
INFO - 2021-12-15 00:17:58 --> Utf8 Class Initialized
INFO - 2021-12-15 00:17:58 --> URI Class Initialized
INFO - 2021-12-15 00:17:58 --> Router Class Initialized
INFO - 2021-12-15 00:17:58 --> Output Class Initialized
INFO - 2021-12-15 00:17:58 --> Security Class Initialized
DEBUG - 2021-12-15 00:17:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 00:17:58 --> Input Class Initialized
INFO - 2021-12-15 00:17:58 --> Language Class Initialized
INFO - 2021-12-15 00:17:58 --> Loader Class Initialized
INFO - 2021-12-15 00:17:58 --> Helper loaded: url_helper
INFO - 2021-12-15 00:17:58 --> Helper loaded: form_helper
INFO - 2021-12-15 00:17:58 --> Helper loaded: common_helper
INFO - 2021-12-15 00:17:58 --> Database Driver Class Initialized
DEBUG - 2021-12-15 00:17:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 00:17:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 00:17:58 --> Controller Class Initialized
INFO - 2021-12-15 00:17:58 --> Form Validation Class Initialized
DEBUG - 2021-12-15 00:17:58 --> Encrypt Class Initialized
INFO - 2021-12-15 00:17:58 --> Model "Referredby_model" initialized
INFO - 2021-12-15 00:17:58 --> Model "Users_model" initialized
INFO - 2021-12-15 00:17:58 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-15 00:17:58 --> File loaded: /home3/karoteam/public_html/application/views/users/index.php
INFO - 2021-12-15 00:17:58 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-15 00:17:58 --> Final output sent to browser
DEBUG - 2021-12-15 00:17:58 --> Total execution time: 0.0338
ERROR - 2021-12-15 00:17:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 00:17:58 --> Config Class Initialized
INFO - 2021-12-15 00:17:58 --> Hooks Class Initialized
DEBUG - 2021-12-15 00:17:58 --> UTF-8 Support Enabled
INFO - 2021-12-15 00:17:58 --> Utf8 Class Initialized
INFO - 2021-12-15 00:17:58 --> URI Class Initialized
INFO - 2021-12-15 00:17:58 --> Router Class Initialized
INFO - 2021-12-15 00:17:58 --> Output Class Initialized
INFO - 2021-12-15 00:17:58 --> Security Class Initialized
DEBUG - 2021-12-15 00:17:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 00:17:58 --> Input Class Initialized
INFO - 2021-12-15 00:17:58 --> Language Class Initialized
ERROR - 2021-12-15 00:17:58 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-12-15 00:18:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 00:18:06 --> Config Class Initialized
INFO - 2021-12-15 00:18:06 --> Hooks Class Initialized
DEBUG - 2021-12-15 00:18:06 --> UTF-8 Support Enabled
INFO - 2021-12-15 00:18:06 --> Utf8 Class Initialized
INFO - 2021-12-15 00:18:06 --> URI Class Initialized
INFO - 2021-12-15 00:18:06 --> Router Class Initialized
INFO - 2021-12-15 00:18:06 --> Output Class Initialized
INFO - 2021-12-15 00:18:06 --> Security Class Initialized
DEBUG - 2021-12-15 00:18:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 00:18:06 --> Input Class Initialized
INFO - 2021-12-15 00:18:06 --> Language Class Initialized
INFO - 2021-12-15 00:18:06 --> Loader Class Initialized
INFO - 2021-12-15 00:18:06 --> Helper loaded: url_helper
INFO - 2021-12-15 00:18:06 --> Helper loaded: form_helper
INFO - 2021-12-15 00:18:06 --> Helper loaded: common_helper
INFO - 2021-12-15 00:18:06 --> Database Driver Class Initialized
DEBUG - 2021-12-15 00:18:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 00:18:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 00:18:06 --> Controller Class Initialized
INFO - 2021-12-15 00:18:06 --> Form Validation Class Initialized
DEBUG - 2021-12-15 00:18:06 --> Encrypt Class Initialized
INFO - 2021-12-15 00:18:06 --> Model "Referredby_model" initialized
INFO - 2021-12-15 00:18:06 --> Model "Users_model" initialized
INFO - 2021-12-15 00:18:06 --> Final output sent to browser
DEBUG - 2021-12-15 00:18:06 --> Total execution time: 0.0205
ERROR - 2021-12-15 00:18:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 00:18:15 --> Config Class Initialized
INFO - 2021-12-15 00:18:15 --> Hooks Class Initialized
DEBUG - 2021-12-15 00:18:15 --> UTF-8 Support Enabled
INFO - 2021-12-15 00:18:15 --> Utf8 Class Initialized
INFO - 2021-12-15 00:18:15 --> URI Class Initialized
INFO - 2021-12-15 00:18:15 --> Router Class Initialized
INFO - 2021-12-15 00:18:15 --> Output Class Initialized
INFO - 2021-12-15 00:18:15 --> Security Class Initialized
DEBUG - 2021-12-15 00:18:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 00:18:15 --> Input Class Initialized
INFO - 2021-12-15 00:18:15 --> Language Class Initialized
INFO - 2021-12-15 00:18:15 --> Loader Class Initialized
INFO - 2021-12-15 00:18:15 --> Helper loaded: url_helper
INFO - 2021-12-15 00:18:15 --> Helper loaded: form_helper
INFO - 2021-12-15 00:18:15 --> Helper loaded: common_helper
INFO - 2021-12-15 00:18:15 --> Database Driver Class Initialized
DEBUG - 2021-12-15 00:18:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 00:18:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 00:18:15 --> Controller Class Initialized
INFO - 2021-12-15 00:18:15 --> Form Validation Class Initialized
DEBUG - 2021-12-15 00:18:15 --> Encrypt Class Initialized
INFO - 2021-12-15 00:18:15 --> Model "Referredby_model" initialized
INFO - 2021-12-15 00:18:15 --> Model "Users_model" initialized
ERROR - 2021-12-15 00:18:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 00:18:15 --> Config Class Initialized
INFO - 2021-12-15 00:18:15 --> Hooks Class Initialized
DEBUG - 2021-12-15 00:18:15 --> UTF-8 Support Enabled
INFO - 2021-12-15 00:18:15 --> Utf8 Class Initialized
INFO - 2021-12-15 00:18:15 --> URI Class Initialized
INFO - 2021-12-15 00:18:15 --> Router Class Initialized
INFO - 2021-12-15 00:18:15 --> Output Class Initialized
INFO - 2021-12-15 00:18:15 --> Security Class Initialized
DEBUG - 2021-12-15 00:18:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 00:18:15 --> Input Class Initialized
INFO - 2021-12-15 00:18:15 --> Language Class Initialized
INFO - 2021-12-15 00:18:15 --> Loader Class Initialized
INFO - 2021-12-15 00:18:15 --> Helper loaded: url_helper
INFO - 2021-12-15 00:18:15 --> Helper loaded: form_helper
INFO - 2021-12-15 00:18:15 --> Helper loaded: common_helper
INFO - 2021-12-15 00:18:15 --> Database Driver Class Initialized
DEBUG - 2021-12-15 00:18:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 00:18:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 00:18:15 --> Controller Class Initialized
INFO - 2021-12-15 00:18:15 --> Form Validation Class Initialized
DEBUG - 2021-12-15 00:18:15 --> Encrypt Class Initialized
INFO - 2021-12-15 00:18:15 --> Model "Referredby_model" initialized
INFO - 2021-12-15 00:18:15 --> Model "Users_model" initialized
INFO - 2021-12-15 00:18:15 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-15 00:18:15 --> File loaded: /home3/karoteam/public_html/application/views/users/index.php
INFO - 2021-12-15 00:18:15 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-15 00:18:15 --> Final output sent to browser
DEBUG - 2021-12-15 00:18:15 --> Total execution time: 0.0243
ERROR - 2021-12-15 00:18:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 00:18:16 --> Config Class Initialized
INFO - 2021-12-15 00:18:16 --> Hooks Class Initialized
DEBUG - 2021-12-15 00:18:16 --> UTF-8 Support Enabled
INFO - 2021-12-15 00:18:16 --> Utf8 Class Initialized
INFO - 2021-12-15 00:18:16 --> URI Class Initialized
INFO - 2021-12-15 00:18:16 --> Router Class Initialized
INFO - 2021-12-15 00:18:16 --> Output Class Initialized
INFO - 2021-12-15 00:18:16 --> Security Class Initialized
DEBUG - 2021-12-15 00:18:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 00:18:16 --> Input Class Initialized
INFO - 2021-12-15 00:18:16 --> Language Class Initialized
ERROR - 2021-12-15 00:18:16 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-12-15 00:18:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 00:18:19 --> Config Class Initialized
INFO - 2021-12-15 00:18:19 --> Hooks Class Initialized
DEBUG - 2021-12-15 00:18:19 --> UTF-8 Support Enabled
INFO - 2021-12-15 00:18:19 --> Utf8 Class Initialized
INFO - 2021-12-15 00:18:19 --> URI Class Initialized
INFO - 2021-12-15 00:18:19 --> Router Class Initialized
INFO - 2021-12-15 00:18:19 --> Output Class Initialized
INFO - 2021-12-15 00:18:19 --> Security Class Initialized
DEBUG - 2021-12-15 00:18:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 00:18:19 --> Input Class Initialized
INFO - 2021-12-15 00:18:19 --> Language Class Initialized
INFO - 2021-12-15 00:18:19 --> Loader Class Initialized
INFO - 2021-12-15 00:18:19 --> Helper loaded: url_helper
INFO - 2021-12-15 00:18:19 --> Helper loaded: form_helper
INFO - 2021-12-15 00:18:19 --> Helper loaded: common_helper
INFO - 2021-12-15 00:18:19 --> Database Driver Class Initialized
DEBUG - 2021-12-15 00:18:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 00:18:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 00:18:19 --> Controller Class Initialized
INFO - 2021-12-15 00:18:19 --> Form Validation Class Initialized
DEBUG - 2021-12-15 00:18:19 --> Encrypt Class Initialized
INFO - 2021-12-15 00:18:19 --> Model "Referredby_model" initialized
INFO - 2021-12-15 00:18:19 --> Model "Users_model" initialized
INFO - 2021-12-15 00:18:19 --> Final output sent to browser
DEBUG - 2021-12-15 00:18:19 --> Total execution time: 0.0234
ERROR - 2021-12-15 00:20:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 00:20:03 --> Config Class Initialized
INFO - 2021-12-15 00:20:03 --> Hooks Class Initialized
DEBUG - 2021-12-15 00:20:03 --> UTF-8 Support Enabled
INFO - 2021-12-15 00:20:03 --> Utf8 Class Initialized
INFO - 2021-12-15 00:20:03 --> URI Class Initialized
INFO - 2021-12-15 00:20:03 --> Router Class Initialized
INFO - 2021-12-15 00:20:03 --> Output Class Initialized
INFO - 2021-12-15 00:20:03 --> Security Class Initialized
DEBUG - 2021-12-15 00:20:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 00:20:03 --> Input Class Initialized
INFO - 2021-12-15 00:20:03 --> Language Class Initialized
INFO - 2021-12-15 00:20:03 --> Loader Class Initialized
INFO - 2021-12-15 00:20:03 --> Helper loaded: url_helper
INFO - 2021-12-15 00:20:03 --> Helper loaded: form_helper
INFO - 2021-12-15 00:20:03 --> Helper loaded: common_helper
INFO - 2021-12-15 00:20:03 --> Database Driver Class Initialized
DEBUG - 2021-12-15 00:20:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 00:20:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 00:20:03 --> Controller Class Initialized
INFO - 2021-12-15 00:20:03 --> Form Validation Class Initialized
DEBUG - 2021-12-15 00:20:03 --> Encrypt Class Initialized
INFO - 2021-12-15 00:20:03 --> Model "Hospital_model" initialized
INFO - 2021-12-15 00:20:03 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-15 00:20:03 --> File loaded: /home3/karoteam/public_html/application/views/hospital/index.php
INFO - 2021-12-15 00:20:03 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-15 00:20:03 --> Final output sent to browser
DEBUG - 2021-12-15 00:20:03 --> Total execution time: 0.0407
ERROR - 2021-12-15 00:20:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 00:20:03 --> Config Class Initialized
INFO - 2021-12-15 00:20:03 --> Hooks Class Initialized
DEBUG - 2021-12-15 00:20:03 --> UTF-8 Support Enabled
INFO - 2021-12-15 00:20:03 --> Utf8 Class Initialized
INFO - 2021-12-15 00:20:03 --> URI Class Initialized
INFO - 2021-12-15 00:20:03 --> Router Class Initialized
INFO - 2021-12-15 00:20:03 --> Output Class Initialized
INFO - 2021-12-15 00:20:03 --> Security Class Initialized
DEBUG - 2021-12-15 00:20:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 00:20:03 --> Input Class Initialized
INFO - 2021-12-15 00:20:03 --> Language Class Initialized
ERROR - 2021-12-15 00:20:03 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-12-15 00:20:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 00:20:17 --> Config Class Initialized
INFO - 2021-12-15 00:20:17 --> Hooks Class Initialized
DEBUG - 2021-12-15 00:20:17 --> UTF-8 Support Enabled
INFO - 2021-12-15 00:20:17 --> Utf8 Class Initialized
INFO - 2021-12-15 00:20:17 --> URI Class Initialized
INFO - 2021-12-15 00:20:17 --> Router Class Initialized
INFO - 2021-12-15 00:20:17 --> Output Class Initialized
INFO - 2021-12-15 00:20:17 --> Security Class Initialized
DEBUG - 2021-12-15 00:20:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 00:20:17 --> Input Class Initialized
INFO - 2021-12-15 00:20:17 --> Language Class Initialized
INFO - 2021-12-15 00:20:17 --> Loader Class Initialized
INFO - 2021-12-15 00:20:17 --> Helper loaded: url_helper
INFO - 2021-12-15 00:20:17 --> Helper loaded: form_helper
INFO - 2021-12-15 00:20:17 --> Helper loaded: common_helper
INFO - 2021-12-15 00:20:17 --> Database Driver Class Initialized
DEBUG - 2021-12-15 00:20:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 00:20:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 00:20:17 --> Controller Class Initialized
INFO - 2021-12-15 00:20:17 --> Form Validation Class Initialized
DEBUG - 2021-12-15 00:20:17 --> Encrypt Class Initialized
INFO - 2021-12-15 00:20:17 --> Model "Referredby_model" initialized
INFO - 2021-12-15 00:20:17 --> Model "Donner_model" initialized
INFO - 2021-12-15 00:20:17 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-15 00:20:17 --> File loaded: /home3/karoteam/public_html/application/views/donner/index.php
INFO - 2021-12-15 00:20:17 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-15 00:20:17 --> Final output sent to browser
DEBUG - 2021-12-15 00:20:17 --> Total execution time: 0.0588
ERROR - 2021-12-15 00:20:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 00:20:18 --> Config Class Initialized
INFO - 2021-12-15 00:20:18 --> Hooks Class Initialized
DEBUG - 2021-12-15 00:20:18 --> UTF-8 Support Enabled
INFO - 2021-12-15 00:20:18 --> Utf8 Class Initialized
INFO - 2021-12-15 00:20:18 --> URI Class Initialized
INFO - 2021-12-15 00:20:18 --> Router Class Initialized
INFO - 2021-12-15 00:20:18 --> Output Class Initialized
INFO - 2021-12-15 00:20:18 --> Security Class Initialized
DEBUG - 2021-12-15 00:20:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 00:20:18 --> Input Class Initialized
INFO - 2021-12-15 00:20:18 --> Language Class Initialized
ERROR - 2021-12-15 00:20:18 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-12-15 00:23:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 00:23:00 --> Config Class Initialized
INFO - 2021-12-15 00:23:00 --> Hooks Class Initialized
DEBUG - 2021-12-15 00:23:00 --> UTF-8 Support Enabled
INFO - 2021-12-15 00:23:00 --> Utf8 Class Initialized
INFO - 2021-12-15 00:23:00 --> URI Class Initialized
INFO - 2021-12-15 00:23:00 --> Router Class Initialized
INFO - 2021-12-15 00:23:00 --> Output Class Initialized
INFO - 2021-12-15 00:23:00 --> Security Class Initialized
DEBUG - 2021-12-15 00:23:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 00:23:00 --> Input Class Initialized
INFO - 2021-12-15 00:23:00 --> Language Class Initialized
INFO - 2021-12-15 00:23:00 --> Loader Class Initialized
INFO - 2021-12-15 00:23:00 --> Helper loaded: url_helper
INFO - 2021-12-15 00:23:00 --> Helper loaded: form_helper
INFO - 2021-12-15 00:23:00 --> Helper loaded: common_helper
INFO - 2021-12-15 00:23:00 --> Database Driver Class Initialized
DEBUG - 2021-12-15 00:23:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 00:23:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 00:23:00 --> Controller Class Initialized
INFO - 2021-12-15 00:23:00 --> Form Validation Class Initialized
DEBUG - 2021-12-15 00:23:00 --> Encrypt Class Initialized
INFO - 2021-12-15 00:23:00 --> Model "Hospital_model" initialized
INFO - 2021-12-15 00:23:00 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-15 00:23:00 --> File loaded: /home3/karoteam/public_html/application/views/hospital/depart.php
INFO - 2021-12-15 00:23:00 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-15 00:23:00 --> Final output sent to browser
DEBUG - 2021-12-15 00:23:00 --> Total execution time: 0.0284
ERROR - 2021-12-15 00:23:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 00:23:00 --> Config Class Initialized
INFO - 2021-12-15 00:23:00 --> Hooks Class Initialized
DEBUG - 2021-12-15 00:23:00 --> UTF-8 Support Enabled
INFO - 2021-12-15 00:23:00 --> Utf8 Class Initialized
INFO - 2021-12-15 00:23:00 --> URI Class Initialized
INFO - 2021-12-15 00:23:00 --> Router Class Initialized
INFO - 2021-12-15 00:23:00 --> Output Class Initialized
INFO - 2021-12-15 00:23:00 --> Security Class Initialized
DEBUG - 2021-12-15 00:23:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 00:23:00 --> Input Class Initialized
INFO - 2021-12-15 00:23:00 --> Language Class Initialized
ERROR - 2021-12-15 00:23:00 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-12-15 00:23:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 00:23:18 --> Config Class Initialized
INFO - 2021-12-15 00:23:18 --> Hooks Class Initialized
DEBUG - 2021-12-15 00:23:18 --> UTF-8 Support Enabled
INFO - 2021-12-15 00:23:18 --> Utf8 Class Initialized
INFO - 2021-12-15 00:23:18 --> URI Class Initialized
INFO - 2021-12-15 00:23:18 --> Router Class Initialized
INFO - 2021-12-15 00:23:18 --> Output Class Initialized
INFO - 2021-12-15 00:23:18 --> Security Class Initialized
DEBUG - 2021-12-15 00:23:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 00:23:18 --> Input Class Initialized
INFO - 2021-12-15 00:23:18 --> Language Class Initialized
INFO - 2021-12-15 00:23:18 --> Loader Class Initialized
INFO - 2021-12-15 00:23:18 --> Helper loaded: url_helper
INFO - 2021-12-15 00:23:18 --> Helper loaded: form_helper
INFO - 2021-12-15 00:23:18 --> Helper loaded: common_helper
INFO - 2021-12-15 00:23:18 --> Database Driver Class Initialized
DEBUG - 2021-12-15 00:23:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 00:23:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 00:23:18 --> Controller Class Initialized
INFO - 2021-12-15 00:23:18 --> Form Validation Class Initialized
INFO - 2021-12-15 00:23:18 --> Model "Case_model" initialized
INFO - 2021-12-15 00:23:18 --> Model "Hospital_model" initialized
INFO - 2021-12-15 00:23:18 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-15 00:23:18 --> File loaded: /home3/karoteam/public_html/application/views/transaction/upcomingFollowup.php
INFO - 2021-12-15 00:23:18 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-15 00:23:18 --> Final output sent to browser
DEBUG - 2021-12-15 00:23:18 --> Total execution time: 0.0420
ERROR - 2021-12-15 00:23:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 00:23:19 --> Config Class Initialized
INFO - 2021-12-15 00:23:19 --> Hooks Class Initialized
DEBUG - 2021-12-15 00:23:19 --> UTF-8 Support Enabled
INFO - 2021-12-15 00:23:19 --> Utf8 Class Initialized
INFO - 2021-12-15 00:23:19 --> URI Class Initialized
INFO - 2021-12-15 00:23:19 --> Router Class Initialized
INFO - 2021-12-15 00:23:19 --> Output Class Initialized
INFO - 2021-12-15 00:23:19 --> Security Class Initialized
DEBUG - 2021-12-15 00:23:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 00:23:19 --> Input Class Initialized
INFO - 2021-12-15 00:23:19 --> Language Class Initialized
ERROR - 2021-12-15 00:23:19 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-12-15 00:24:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 00:24:29 --> Config Class Initialized
INFO - 2021-12-15 00:24:29 --> Hooks Class Initialized
DEBUG - 2021-12-15 00:24:29 --> UTF-8 Support Enabled
INFO - 2021-12-15 00:24:29 --> Utf8 Class Initialized
INFO - 2021-12-15 00:24:29 --> URI Class Initialized
INFO - 2021-12-15 00:24:29 --> Router Class Initialized
INFO - 2021-12-15 00:24:29 --> Output Class Initialized
INFO - 2021-12-15 00:24:29 --> Security Class Initialized
DEBUG - 2021-12-15 00:24:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 00:24:29 --> Input Class Initialized
INFO - 2021-12-15 00:24:29 --> Language Class Initialized
INFO - 2021-12-15 00:24:29 --> Loader Class Initialized
INFO - 2021-12-15 00:24:29 --> Helper loaded: url_helper
INFO - 2021-12-15 00:24:29 --> Helper loaded: form_helper
INFO - 2021-12-15 00:24:29 --> Helper loaded: common_helper
INFO - 2021-12-15 00:24:29 --> Database Driver Class Initialized
DEBUG - 2021-12-15 00:24:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 00:24:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 00:24:29 --> Controller Class Initialized
INFO - 2021-12-15 00:24:29 --> Form Validation Class Initialized
INFO - 2021-12-15 00:24:29 --> Model "Case_model" initialized
INFO - 2021-12-15 00:24:30 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-15 00:24:30 --> File loaded: /home3/karoteam/public_html/application/views/transaction/donner_donation.php
INFO - 2021-12-15 00:24:30 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-15 00:24:30 --> Final output sent to browser
DEBUG - 2021-12-15 00:24:30 --> Total execution time: 0.0361
ERROR - 2021-12-15 00:24:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 00:24:30 --> Config Class Initialized
INFO - 2021-12-15 00:24:30 --> Hooks Class Initialized
DEBUG - 2021-12-15 00:24:30 --> UTF-8 Support Enabled
INFO - 2021-12-15 00:24:30 --> Utf8 Class Initialized
INFO - 2021-12-15 00:24:30 --> URI Class Initialized
INFO - 2021-12-15 00:24:30 --> Router Class Initialized
INFO - 2021-12-15 00:24:30 --> Output Class Initialized
INFO - 2021-12-15 00:24:30 --> Security Class Initialized
DEBUG - 2021-12-15 00:24:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 00:24:30 --> Input Class Initialized
INFO - 2021-12-15 00:24:30 --> Language Class Initialized
ERROR - 2021-12-15 00:24:30 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-12-15 00:31:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 00:31:12 --> Config Class Initialized
INFO - 2021-12-15 00:31:12 --> Hooks Class Initialized
DEBUG - 2021-12-15 00:31:12 --> UTF-8 Support Enabled
INFO - 2021-12-15 00:31:12 --> Utf8 Class Initialized
INFO - 2021-12-15 00:31:12 --> URI Class Initialized
INFO - 2021-12-15 00:31:12 --> Router Class Initialized
INFO - 2021-12-15 00:31:12 --> Output Class Initialized
INFO - 2021-12-15 00:31:12 --> Security Class Initialized
DEBUG - 2021-12-15 00:31:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 00:31:12 --> Input Class Initialized
INFO - 2021-12-15 00:31:12 --> Language Class Initialized
INFO - 2021-12-15 00:31:12 --> Loader Class Initialized
INFO - 2021-12-15 00:31:12 --> Helper loaded: url_helper
INFO - 2021-12-15 00:31:12 --> Helper loaded: form_helper
INFO - 2021-12-15 00:31:12 --> Helper loaded: common_helper
INFO - 2021-12-15 00:31:12 --> Database Driver Class Initialized
DEBUG - 2021-12-15 00:31:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 00:31:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 00:31:12 --> Controller Class Initialized
INFO - 2021-12-15 00:31:12 --> Form Validation Class Initialized
INFO - 2021-12-15 00:31:12 --> Model "Case_model" initialized
INFO - 2021-12-15 00:31:12 --> Model "Hospital_model" initialized
INFO - 2021-12-15 00:31:12 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-15 00:31:12 --> File loaded: /home3/karoteam/public_html/application/views/transaction/refund_amount.php
INFO - 2021-12-15 00:31:12 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-15 00:31:12 --> Final output sent to browser
DEBUG - 2021-12-15 00:31:12 --> Total execution time: 0.0275
ERROR - 2021-12-15 00:31:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 00:31:13 --> Config Class Initialized
INFO - 2021-12-15 00:31:13 --> Hooks Class Initialized
DEBUG - 2021-12-15 00:31:13 --> UTF-8 Support Enabled
INFO - 2021-12-15 00:31:13 --> Utf8 Class Initialized
INFO - 2021-12-15 00:31:13 --> URI Class Initialized
INFO - 2021-12-15 00:31:13 --> Router Class Initialized
INFO - 2021-12-15 00:31:13 --> Output Class Initialized
INFO - 2021-12-15 00:31:13 --> Security Class Initialized
DEBUG - 2021-12-15 00:31:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 00:31:13 --> Input Class Initialized
INFO - 2021-12-15 00:31:13 --> Language Class Initialized
ERROR - 2021-12-15 00:31:13 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-12-15 00:31:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 00:31:52 --> Config Class Initialized
INFO - 2021-12-15 00:31:52 --> Hooks Class Initialized
DEBUG - 2021-12-15 00:31:52 --> UTF-8 Support Enabled
INFO - 2021-12-15 00:31:52 --> Utf8 Class Initialized
INFO - 2021-12-15 00:31:52 --> URI Class Initialized
INFO - 2021-12-15 00:31:52 --> Router Class Initialized
INFO - 2021-12-15 00:31:52 --> Output Class Initialized
INFO - 2021-12-15 00:31:52 --> Security Class Initialized
DEBUG - 2021-12-15 00:31:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 00:31:52 --> Input Class Initialized
INFO - 2021-12-15 00:31:52 --> Language Class Initialized
INFO - 2021-12-15 00:31:52 --> Loader Class Initialized
INFO - 2021-12-15 00:31:52 --> Helper loaded: url_helper
INFO - 2021-12-15 00:31:52 --> Helper loaded: form_helper
INFO - 2021-12-15 00:31:52 --> Helper loaded: common_helper
INFO - 2021-12-15 00:31:52 --> Database Driver Class Initialized
DEBUG - 2021-12-15 00:31:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 00:31:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 00:31:52 --> Controller Class Initialized
INFO - 2021-12-15 00:31:52 --> Form Validation Class Initialized
INFO - 2021-12-15 00:31:52 --> Model "Report_model" initialized
INFO - 2021-12-15 00:31:52 --> Model "Case_model" initialized
INFO - 2021-12-15 00:31:52 --> Model "Hospital_model" initialized
INFO - 2021-12-15 00:31:52 --> Model "Donner_model" initialized
INFO - 2021-12-15 00:31:52 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-15 00:31:52 --> File loaded: /home3/karoteam/public_html/application/views/reports/patient_details.php
INFO - 2021-12-15 00:31:52 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-15 00:31:52 --> Final output sent to browser
DEBUG - 2021-12-15 00:31:52 --> Total execution time: 0.0301
ERROR - 2021-12-15 00:31:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 00:31:53 --> Config Class Initialized
INFO - 2021-12-15 00:31:53 --> Hooks Class Initialized
DEBUG - 2021-12-15 00:31:53 --> UTF-8 Support Enabled
INFO - 2021-12-15 00:31:53 --> Utf8 Class Initialized
INFO - 2021-12-15 00:31:53 --> URI Class Initialized
INFO - 2021-12-15 00:31:53 --> Router Class Initialized
INFO - 2021-12-15 00:31:53 --> Output Class Initialized
INFO - 2021-12-15 00:31:53 --> Security Class Initialized
DEBUG - 2021-12-15 00:31:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 00:31:53 --> Input Class Initialized
INFO - 2021-12-15 00:31:53 --> Language Class Initialized
ERROR - 2021-12-15 00:31:53 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-12-15 00:36:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 00:36:29 --> Config Class Initialized
INFO - 2021-12-15 00:36:29 --> Hooks Class Initialized
DEBUG - 2021-12-15 00:36:29 --> UTF-8 Support Enabled
INFO - 2021-12-15 00:36:29 --> Utf8 Class Initialized
INFO - 2021-12-15 00:36:29 --> URI Class Initialized
INFO - 2021-12-15 00:36:29 --> Router Class Initialized
INFO - 2021-12-15 00:36:29 --> Output Class Initialized
INFO - 2021-12-15 00:36:29 --> Security Class Initialized
DEBUG - 2021-12-15 00:36:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 00:36:29 --> Input Class Initialized
INFO - 2021-12-15 00:36:29 --> Language Class Initialized
ERROR - 2021-12-15 00:36:29 --> 404 Page Not Found: Karoclient/css
ERROR - 2021-12-15 00:59:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 00:59:33 --> Config Class Initialized
INFO - 2021-12-15 00:59:33 --> Hooks Class Initialized
DEBUG - 2021-12-15 00:59:33 --> UTF-8 Support Enabled
INFO - 2021-12-15 00:59:33 --> Utf8 Class Initialized
INFO - 2021-12-15 00:59:33 --> URI Class Initialized
INFO - 2021-12-15 00:59:33 --> Router Class Initialized
INFO - 2021-12-15 00:59:33 --> Output Class Initialized
INFO - 2021-12-15 00:59:33 --> Security Class Initialized
DEBUG - 2021-12-15 00:59:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 00:59:33 --> Input Class Initialized
INFO - 2021-12-15 00:59:33 --> Language Class Initialized
INFO - 2021-12-15 00:59:33 --> Loader Class Initialized
INFO - 2021-12-15 00:59:33 --> Helper loaded: url_helper
INFO - 2021-12-15 00:59:33 --> Helper loaded: form_helper
INFO - 2021-12-15 00:59:33 --> Helper loaded: common_helper
INFO - 2021-12-15 00:59:33 --> Database Driver Class Initialized
DEBUG - 2021-12-15 00:59:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 00:59:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 00:59:33 --> Controller Class Initialized
INFO - 2021-12-15 00:59:33 --> Form Validation Class Initialized
INFO - 2021-12-15 00:59:33 --> Model "Report_model" initialized
INFO - 2021-12-15 00:59:33 --> Model "Case_model" initialized
INFO - 2021-12-15 00:59:33 --> Model "Hospital_model" initialized
INFO - 2021-12-15 00:59:33 --> Model "Donner_model" initialized
INFO - 2021-12-15 00:59:33 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-15 00:59:33 --> File loaded: /home3/karoteam/public_html/application/views/reports/patient_details.php
INFO - 2021-12-15 00:59:33 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-15 00:59:33 --> Final output sent to browser
DEBUG - 2021-12-15 00:59:33 --> Total execution time: 0.0275
ERROR - 2021-12-15 00:59:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 00:59:35 --> Config Class Initialized
INFO - 2021-12-15 00:59:35 --> Hooks Class Initialized
DEBUG - 2021-12-15 00:59:35 --> UTF-8 Support Enabled
INFO - 2021-12-15 00:59:35 --> Utf8 Class Initialized
INFO - 2021-12-15 00:59:35 --> URI Class Initialized
INFO - 2021-12-15 00:59:35 --> Router Class Initialized
INFO - 2021-12-15 00:59:35 --> Output Class Initialized
INFO - 2021-12-15 00:59:35 --> Security Class Initialized
DEBUG - 2021-12-15 00:59:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 00:59:35 --> Input Class Initialized
INFO - 2021-12-15 00:59:35 --> Language Class Initialized
ERROR - 2021-12-15 00:59:35 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-12-15 01:00:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 01:00:10 --> Config Class Initialized
INFO - 2021-12-15 01:00:10 --> Hooks Class Initialized
DEBUG - 2021-12-15 01:00:10 --> UTF-8 Support Enabled
INFO - 2021-12-15 01:00:10 --> Utf8 Class Initialized
INFO - 2021-12-15 01:00:10 --> URI Class Initialized
INFO - 2021-12-15 01:00:10 --> Router Class Initialized
INFO - 2021-12-15 01:00:10 --> Output Class Initialized
INFO - 2021-12-15 01:00:10 --> Security Class Initialized
DEBUG - 2021-12-15 01:00:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 01:00:10 --> Input Class Initialized
INFO - 2021-12-15 01:00:10 --> Language Class Initialized
ERROR - 2021-12-15 01:00:10 --> 404 Page Not Found: Karoclient/css
ERROR - 2021-12-15 01:00:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 01:00:35 --> Config Class Initialized
INFO - 2021-12-15 01:00:35 --> Hooks Class Initialized
DEBUG - 2021-12-15 01:00:35 --> UTF-8 Support Enabled
INFO - 2021-12-15 01:00:35 --> Utf8 Class Initialized
INFO - 2021-12-15 01:00:35 --> URI Class Initialized
INFO - 2021-12-15 01:00:35 --> Router Class Initialized
INFO - 2021-12-15 01:00:35 --> Output Class Initialized
INFO - 2021-12-15 01:00:35 --> Security Class Initialized
DEBUG - 2021-12-15 01:00:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 01:00:35 --> Input Class Initialized
INFO - 2021-12-15 01:00:35 --> Language Class Initialized
INFO - 2021-12-15 01:00:35 --> Loader Class Initialized
INFO - 2021-12-15 01:00:35 --> Helper loaded: url_helper
INFO - 2021-12-15 01:00:35 --> Helper loaded: form_helper
INFO - 2021-12-15 01:00:35 --> Helper loaded: common_helper
INFO - 2021-12-15 01:00:35 --> Database Driver Class Initialized
DEBUG - 2021-12-15 01:00:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 01:00:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 01:00:35 --> Controller Class Initialized
INFO - 2021-12-15 01:00:35 --> Form Validation Class Initialized
INFO - 2021-12-15 01:00:35 --> Model "Report_model" initialized
INFO - 2021-12-15 01:00:35 --> Model "Case_model" initialized
INFO - 2021-12-15 01:00:43 --> Final output sent to browser
DEBUG - 2021-12-15 01:00:43 --> Total execution time: 7.8476
ERROR - 2021-12-15 01:01:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 01:01:24 --> Config Class Initialized
INFO - 2021-12-15 01:01:24 --> Hooks Class Initialized
DEBUG - 2021-12-15 01:01:24 --> UTF-8 Support Enabled
INFO - 2021-12-15 01:01:24 --> Utf8 Class Initialized
INFO - 2021-12-15 01:01:24 --> URI Class Initialized
INFO - 2021-12-15 01:01:24 --> Router Class Initialized
INFO - 2021-12-15 01:01:24 --> Output Class Initialized
INFO - 2021-12-15 01:01:24 --> Security Class Initialized
DEBUG - 2021-12-15 01:01:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 01:01:24 --> Input Class Initialized
INFO - 2021-12-15 01:01:24 --> Language Class Initialized
INFO - 2021-12-15 01:01:24 --> Loader Class Initialized
INFO - 2021-12-15 01:01:24 --> Helper loaded: url_helper
INFO - 2021-12-15 01:01:24 --> Helper loaded: form_helper
INFO - 2021-12-15 01:01:24 --> Helper loaded: common_helper
INFO - 2021-12-15 01:01:24 --> Database Driver Class Initialized
DEBUG - 2021-12-15 01:01:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 01:01:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 01:01:24 --> Controller Class Initialized
INFO - 2021-12-15 01:01:24 --> Form Validation Class Initialized
INFO - 2021-12-15 01:01:24 --> Model "Report_model" initialized
INFO - 2021-12-15 01:01:24 --> Model "Case_model" initialized
INFO - 2021-12-15 01:01:31 --> Final output sent to browser
DEBUG - 2021-12-15 01:01:31 --> Total execution time: 7.2792
ERROR - 2021-12-15 01:02:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 01:02:03 --> Config Class Initialized
INFO - 2021-12-15 01:02:03 --> Hooks Class Initialized
DEBUG - 2021-12-15 01:02:03 --> UTF-8 Support Enabled
INFO - 2021-12-15 01:02:03 --> Utf8 Class Initialized
INFO - 2021-12-15 01:02:03 --> URI Class Initialized
INFO - 2021-12-15 01:02:03 --> Router Class Initialized
INFO - 2021-12-15 01:02:03 --> Output Class Initialized
INFO - 2021-12-15 01:02:03 --> Security Class Initialized
DEBUG - 2021-12-15 01:02:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 01:02:03 --> Input Class Initialized
INFO - 2021-12-15 01:02:03 --> Language Class Initialized
INFO - 2021-12-15 01:02:03 --> Loader Class Initialized
INFO - 2021-12-15 01:02:03 --> Helper loaded: url_helper
INFO - 2021-12-15 01:02:03 --> Helper loaded: form_helper
INFO - 2021-12-15 01:02:03 --> Helper loaded: common_helper
INFO - 2021-12-15 01:02:03 --> Database Driver Class Initialized
DEBUG - 2021-12-15 01:02:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 01:02:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 01:02:03 --> Controller Class Initialized
INFO - 2021-12-15 01:02:03 --> Form Validation Class Initialized
INFO - 2021-12-15 01:02:03 --> Model "Report_model" initialized
INFO - 2021-12-15 01:02:03 --> Model "Case_model" initialized
INFO - 2021-12-15 01:02:03 --> Model "Hospital_model" initialized
INFO - 2021-12-15 01:02:03 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-15 01:02:03 --> File loaded: /home3/karoteam/public_html/application/views/reports/donor_wise_patient_details.php
INFO - 2021-12-15 01:02:03 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-15 01:02:03 --> Final output sent to browser
DEBUG - 2021-12-15 01:02:03 --> Total execution time: 0.0263
ERROR - 2021-12-15 01:02:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 01:02:04 --> Config Class Initialized
INFO - 2021-12-15 01:02:04 --> Hooks Class Initialized
DEBUG - 2021-12-15 01:02:04 --> UTF-8 Support Enabled
INFO - 2021-12-15 01:02:04 --> Utf8 Class Initialized
INFO - 2021-12-15 01:02:04 --> URI Class Initialized
INFO - 2021-12-15 01:02:04 --> Router Class Initialized
INFO - 2021-12-15 01:02:04 --> Output Class Initialized
INFO - 2021-12-15 01:02:04 --> Security Class Initialized
DEBUG - 2021-12-15 01:02:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 01:02:04 --> Input Class Initialized
INFO - 2021-12-15 01:02:04 --> Language Class Initialized
ERROR - 2021-12-15 01:02:04 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-12-15 01:02:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 01:02:37 --> Config Class Initialized
INFO - 2021-12-15 01:02:37 --> Hooks Class Initialized
DEBUG - 2021-12-15 01:02:37 --> UTF-8 Support Enabled
INFO - 2021-12-15 01:02:37 --> Utf8 Class Initialized
INFO - 2021-12-15 01:02:37 --> URI Class Initialized
INFO - 2021-12-15 01:02:37 --> Router Class Initialized
INFO - 2021-12-15 01:02:37 --> Output Class Initialized
INFO - 2021-12-15 01:02:37 --> Security Class Initialized
DEBUG - 2021-12-15 01:02:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 01:02:37 --> Input Class Initialized
INFO - 2021-12-15 01:02:37 --> Language Class Initialized
INFO - 2021-12-15 01:02:37 --> Loader Class Initialized
INFO - 2021-12-15 01:02:37 --> Helper loaded: url_helper
INFO - 2021-12-15 01:02:37 --> Helper loaded: form_helper
INFO - 2021-12-15 01:02:37 --> Helper loaded: common_helper
INFO - 2021-12-15 01:02:37 --> Database Driver Class Initialized
DEBUG - 2021-12-15 01:02:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 01:02:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 01:02:37 --> Controller Class Initialized
INFO - 2021-12-15 01:02:37 --> Form Validation Class Initialized
INFO - 2021-12-15 01:02:37 --> Model "Report_model" initialized
INFO - 2021-12-15 01:02:37 --> Model "Case_model" initialized
INFO - 2021-12-15 01:02:41 --> Final output sent to browser
DEBUG - 2021-12-15 01:02:41 --> Total execution time: 4.6471
ERROR - 2021-12-15 01:03:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 01:03:26 --> Config Class Initialized
INFO - 2021-12-15 01:03:26 --> Hooks Class Initialized
DEBUG - 2021-12-15 01:03:26 --> UTF-8 Support Enabled
INFO - 2021-12-15 01:03:26 --> Utf8 Class Initialized
INFO - 2021-12-15 01:03:26 --> URI Class Initialized
INFO - 2021-12-15 01:03:26 --> Router Class Initialized
INFO - 2021-12-15 01:03:26 --> Output Class Initialized
INFO - 2021-12-15 01:03:26 --> Security Class Initialized
DEBUG - 2021-12-15 01:03:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 01:03:26 --> Input Class Initialized
INFO - 2021-12-15 01:03:26 --> Language Class Initialized
INFO - 2021-12-15 01:03:26 --> Loader Class Initialized
INFO - 2021-12-15 01:03:26 --> Helper loaded: url_helper
INFO - 2021-12-15 01:03:26 --> Helper loaded: form_helper
INFO - 2021-12-15 01:03:26 --> Helper loaded: common_helper
INFO - 2021-12-15 01:03:26 --> Database Driver Class Initialized
DEBUG - 2021-12-15 01:03:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 01:03:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 01:03:26 --> Controller Class Initialized
INFO - 2021-12-15 01:03:26 --> Form Validation Class Initialized
INFO - 2021-12-15 01:03:26 --> Model "Report_model" initialized
INFO - 2021-12-15 01:03:26 --> Model "Case_model" initialized
INFO - 2021-12-15 01:03:26 --> Final output sent to browser
DEBUG - 2021-12-15 01:03:26 --> Total execution time: 0.0916
ERROR - 2021-12-15 01:05:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 01:05:09 --> Config Class Initialized
INFO - 2021-12-15 01:05:09 --> Hooks Class Initialized
DEBUG - 2021-12-15 01:05:09 --> UTF-8 Support Enabled
INFO - 2021-12-15 01:05:09 --> Utf8 Class Initialized
INFO - 2021-12-15 01:05:09 --> URI Class Initialized
INFO - 2021-12-15 01:05:09 --> Router Class Initialized
INFO - 2021-12-15 01:05:09 --> Output Class Initialized
INFO - 2021-12-15 01:05:09 --> Security Class Initialized
DEBUG - 2021-12-15 01:05:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 01:05:09 --> Input Class Initialized
INFO - 2021-12-15 01:05:09 --> Language Class Initialized
INFO - 2021-12-15 01:05:09 --> Loader Class Initialized
INFO - 2021-12-15 01:05:09 --> Helper loaded: url_helper
INFO - 2021-12-15 01:05:09 --> Helper loaded: form_helper
INFO - 2021-12-15 01:05:09 --> Helper loaded: common_helper
INFO - 2021-12-15 01:05:10 --> Database Driver Class Initialized
DEBUG - 2021-12-15 01:05:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 01:05:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 01:05:10 --> Controller Class Initialized
INFO - 2021-12-15 01:05:10 --> Form Validation Class Initialized
INFO - 2021-12-15 01:05:10 --> Model "Report_model" initialized
INFO - 2021-12-15 01:05:10 --> Model "Case_model" initialized
INFO - 2021-12-15 01:05:10 --> Final output sent to browser
DEBUG - 2021-12-15 01:05:10 --> Total execution time: 0.0724
ERROR - 2021-12-15 01:05:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 01:05:18 --> Config Class Initialized
INFO - 2021-12-15 01:05:18 --> Hooks Class Initialized
DEBUG - 2021-12-15 01:05:18 --> UTF-8 Support Enabled
INFO - 2021-12-15 01:05:18 --> Utf8 Class Initialized
INFO - 2021-12-15 01:05:18 --> URI Class Initialized
INFO - 2021-12-15 01:05:18 --> Router Class Initialized
INFO - 2021-12-15 01:05:18 --> Output Class Initialized
INFO - 2021-12-15 01:05:18 --> Security Class Initialized
DEBUG - 2021-12-15 01:05:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 01:05:18 --> Input Class Initialized
INFO - 2021-12-15 01:05:18 --> Language Class Initialized
INFO - 2021-12-15 01:05:18 --> Loader Class Initialized
INFO - 2021-12-15 01:05:18 --> Helper loaded: url_helper
INFO - 2021-12-15 01:05:18 --> Helper loaded: form_helper
INFO - 2021-12-15 01:05:18 --> Helper loaded: common_helper
INFO - 2021-12-15 01:05:18 --> Database Driver Class Initialized
DEBUG - 2021-12-15 01:05:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 01:05:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 01:05:18 --> Controller Class Initialized
INFO - 2021-12-15 01:05:18 --> Form Validation Class Initialized
DEBUG - 2021-12-15 01:05:18 --> Encrypt Class Initialized
INFO - 2021-12-15 01:05:18 --> Model "Login_model" initialized
INFO - 2021-12-15 01:05:18 --> Model "Dashboard_model" initialized
INFO - 2021-12-15 01:05:18 --> Model "Case_model" initialized
INFO - 2021-12-15 01:05:26 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-15 01:05:36 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2021-12-15 01:05:36 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-15 01:05:36 --> Final output sent to browser
DEBUG - 2021-12-15 01:05:36 --> Total execution time: 17.9270
ERROR - 2021-12-15 01:05:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 01:05:37 --> Config Class Initialized
INFO - 2021-12-15 01:05:37 --> Hooks Class Initialized
DEBUG - 2021-12-15 01:05:37 --> UTF-8 Support Enabled
INFO - 2021-12-15 01:05:37 --> Utf8 Class Initialized
INFO - 2021-12-15 01:05:37 --> URI Class Initialized
INFO - 2021-12-15 01:05:37 --> Router Class Initialized
INFO - 2021-12-15 01:05:37 --> Output Class Initialized
INFO - 2021-12-15 01:05:37 --> Security Class Initialized
DEBUG - 2021-12-15 01:05:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 01:05:37 --> Input Class Initialized
INFO - 2021-12-15 01:05:37 --> Language Class Initialized
ERROR - 2021-12-15 01:05:37 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-12-15 01:06:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 01:06:40 --> Config Class Initialized
INFO - 2021-12-15 01:06:40 --> Hooks Class Initialized
DEBUG - 2021-12-15 01:06:40 --> UTF-8 Support Enabled
INFO - 2021-12-15 01:06:40 --> Utf8 Class Initialized
INFO - 2021-12-15 01:06:40 --> URI Class Initialized
INFO - 2021-12-15 01:06:40 --> Router Class Initialized
INFO - 2021-12-15 01:06:40 --> Output Class Initialized
INFO - 2021-12-15 01:06:40 --> Security Class Initialized
DEBUG - 2021-12-15 01:06:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 01:06:40 --> Input Class Initialized
INFO - 2021-12-15 01:06:40 --> Language Class Initialized
ERROR - 2021-12-15 01:06:40 --> 404 Page Not Found: Blog/wp-includes
ERROR - 2021-12-15 01:06:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 01:06:41 --> Config Class Initialized
INFO - 2021-12-15 01:06:41 --> Hooks Class Initialized
DEBUG - 2021-12-15 01:06:41 --> UTF-8 Support Enabled
INFO - 2021-12-15 01:06:41 --> Utf8 Class Initialized
INFO - 2021-12-15 01:06:41 --> URI Class Initialized
INFO - 2021-12-15 01:06:41 --> Router Class Initialized
INFO - 2021-12-15 01:06:41 --> Output Class Initialized
INFO - 2021-12-15 01:06:41 --> Security Class Initialized
DEBUG - 2021-12-15 01:06:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 01:06:41 --> Input Class Initialized
INFO - 2021-12-15 01:06:41 --> Language Class Initialized
ERROR - 2021-12-15 01:06:41 --> 404 Page Not Found: Web/wp-includes
ERROR - 2021-12-15 01:06:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 01:06:41 --> Config Class Initialized
INFO - 2021-12-15 01:06:41 --> Hooks Class Initialized
DEBUG - 2021-12-15 01:06:41 --> UTF-8 Support Enabled
INFO - 2021-12-15 01:06:41 --> Utf8 Class Initialized
INFO - 2021-12-15 01:06:41 --> URI Class Initialized
INFO - 2021-12-15 01:06:41 --> Router Class Initialized
INFO - 2021-12-15 01:06:41 --> Output Class Initialized
INFO - 2021-12-15 01:06:41 --> Security Class Initialized
DEBUG - 2021-12-15 01:06:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 01:06:41 --> Input Class Initialized
INFO - 2021-12-15 01:06:41 --> Language Class Initialized
ERROR - 2021-12-15 01:06:41 --> 404 Page Not Found: Wordpress/wp-includes
ERROR - 2021-12-15 01:06:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 01:06:42 --> Config Class Initialized
INFO - 2021-12-15 01:06:42 --> Hooks Class Initialized
DEBUG - 2021-12-15 01:06:42 --> UTF-8 Support Enabled
INFO - 2021-12-15 01:06:42 --> Utf8 Class Initialized
INFO - 2021-12-15 01:06:42 --> URI Class Initialized
INFO - 2021-12-15 01:06:42 --> Router Class Initialized
INFO - 2021-12-15 01:06:42 --> Output Class Initialized
INFO - 2021-12-15 01:06:42 --> Security Class Initialized
DEBUG - 2021-12-15 01:06:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 01:06:42 --> Input Class Initialized
INFO - 2021-12-15 01:06:42 --> Language Class Initialized
ERROR - 2021-12-15 01:06:42 --> 404 Page Not Found: Website/wp-includes
ERROR - 2021-12-15 01:06:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 01:06:42 --> Config Class Initialized
INFO - 2021-12-15 01:06:42 --> Hooks Class Initialized
DEBUG - 2021-12-15 01:06:42 --> UTF-8 Support Enabled
INFO - 2021-12-15 01:06:42 --> Utf8 Class Initialized
INFO - 2021-12-15 01:06:42 --> URI Class Initialized
INFO - 2021-12-15 01:06:42 --> Router Class Initialized
INFO - 2021-12-15 01:06:42 --> Output Class Initialized
INFO - 2021-12-15 01:06:42 --> Security Class Initialized
DEBUG - 2021-12-15 01:06:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 01:06:42 --> Input Class Initialized
INFO - 2021-12-15 01:06:42 --> Language Class Initialized
ERROR - 2021-12-15 01:06:42 --> 404 Page Not Found: Wp/wp-includes
ERROR - 2021-12-15 01:06:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 01:06:43 --> Config Class Initialized
INFO - 2021-12-15 01:06:43 --> Hooks Class Initialized
DEBUG - 2021-12-15 01:06:43 --> UTF-8 Support Enabled
INFO - 2021-12-15 01:06:43 --> Utf8 Class Initialized
INFO - 2021-12-15 01:06:43 --> URI Class Initialized
INFO - 2021-12-15 01:06:43 --> Router Class Initialized
INFO - 2021-12-15 01:06:43 --> Output Class Initialized
INFO - 2021-12-15 01:06:43 --> Security Class Initialized
DEBUG - 2021-12-15 01:06:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 01:06:43 --> Input Class Initialized
INFO - 2021-12-15 01:06:43 --> Language Class Initialized
ERROR - 2021-12-15 01:06:43 --> 404 Page Not Found: News/wp-includes
ERROR - 2021-12-15 01:06:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 01:06:43 --> Config Class Initialized
INFO - 2021-12-15 01:06:43 --> Hooks Class Initialized
DEBUG - 2021-12-15 01:06:43 --> UTF-8 Support Enabled
INFO - 2021-12-15 01:06:43 --> Utf8 Class Initialized
INFO - 2021-12-15 01:06:43 --> URI Class Initialized
INFO - 2021-12-15 01:06:43 --> Router Class Initialized
INFO - 2021-12-15 01:06:43 --> Output Class Initialized
INFO - 2021-12-15 01:06:43 --> Security Class Initialized
DEBUG - 2021-12-15 01:06:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 01:06:43 --> Input Class Initialized
INFO - 2021-12-15 01:06:43 --> Language Class Initialized
ERROR - 2021-12-15 01:06:43 --> 404 Page Not Found: 2018/wp-includes
ERROR - 2021-12-15 01:06:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 01:06:44 --> Config Class Initialized
INFO - 2021-12-15 01:06:44 --> Hooks Class Initialized
DEBUG - 2021-12-15 01:06:44 --> UTF-8 Support Enabled
INFO - 2021-12-15 01:06:44 --> Utf8 Class Initialized
INFO - 2021-12-15 01:06:44 --> URI Class Initialized
INFO - 2021-12-15 01:06:44 --> Router Class Initialized
INFO - 2021-12-15 01:06:44 --> Output Class Initialized
INFO - 2021-12-15 01:06:44 --> Security Class Initialized
DEBUG - 2021-12-15 01:06:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 01:06:44 --> Input Class Initialized
INFO - 2021-12-15 01:06:44 --> Language Class Initialized
ERROR - 2021-12-15 01:06:44 --> 404 Page Not Found: 2019/wp-includes
ERROR - 2021-12-15 01:06:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 01:06:44 --> Config Class Initialized
INFO - 2021-12-15 01:06:44 --> Hooks Class Initialized
DEBUG - 2021-12-15 01:06:44 --> UTF-8 Support Enabled
INFO - 2021-12-15 01:06:44 --> Utf8 Class Initialized
INFO - 2021-12-15 01:06:44 --> URI Class Initialized
INFO - 2021-12-15 01:06:44 --> Router Class Initialized
INFO - 2021-12-15 01:06:44 --> Output Class Initialized
INFO - 2021-12-15 01:06:44 --> Security Class Initialized
DEBUG - 2021-12-15 01:06:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 01:06:44 --> Input Class Initialized
INFO - 2021-12-15 01:06:44 --> Language Class Initialized
ERROR - 2021-12-15 01:06:44 --> 404 Page Not Found: Shop/wp-includes
ERROR - 2021-12-15 01:06:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 01:06:45 --> Config Class Initialized
INFO - 2021-12-15 01:06:45 --> Hooks Class Initialized
DEBUG - 2021-12-15 01:06:45 --> UTF-8 Support Enabled
INFO - 2021-12-15 01:06:45 --> Utf8 Class Initialized
INFO - 2021-12-15 01:06:45 --> URI Class Initialized
INFO - 2021-12-15 01:06:45 --> Router Class Initialized
INFO - 2021-12-15 01:06:45 --> Output Class Initialized
INFO - 2021-12-15 01:06:45 --> Security Class Initialized
DEBUG - 2021-12-15 01:06:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 01:06:45 --> Input Class Initialized
INFO - 2021-12-15 01:06:45 --> Language Class Initialized
ERROR - 2021-12-15 01:06:45 --> 404 Page Not Found: Wp1/wp-includes
ERROR - 2021-12-15 01:06:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 01:06:45 --> Config Class Initialized
INFO - 2021-12-15 01:06:45 --> Hooks Class Initialized
DEBUG - 2021-12-15 01:06:45 --> UTF-8 Support Enabled
INFO - 2021-12-15 01:06:45 --> Utf8 Class Initialized
INFO - 2021-12-15 01:06:45 --> URI Class Initialized
INFO - 2021-12-15 01:06:45 --> Router Class Initialized
INFO - 2021-12-15 01:06:45 --> Output Class Initialized
INFO - 2021-12-15 01:06:45 --> Security Class Initialized
DEBUG - 2021-12-15 01:06:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 01:06:45 --> Input Class Initialized
INFO - 2021-12-15 01:06:45 --> Language Class Initialized
ERROR - 2021-12-15 01:06:45 --> 404 Page Not Found: Test/wp-includes
ERROR - 2021-12-15 01:06:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 01:06:46 --> Config Class Initialized
INFO - 2021-12-15 01:06:46 --> Hooks Class Initialized
DEBUG - 2021-12-15 01:06:46 --> UTF-8 Support Enabled
INFO - 2021-12-15 01:06:46 --> Utf8 Class Initialized
INFO - 2021-12-15 01:06:46 --> URI Class Initialized
INFO - 2021-12-15 01:06:46 --> Router Class Initialized
INFO - 2021-12-15 01:06:46 --> Output Class Initialized
INFO - 2021-12-15 01:06:46 --> Security Class Initialized
DEBUG - 2021-12-15 01:06:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 01:06:46 --> Input Class Initialized
INFO - 2021-12-15 01:06:46 --> Language Class Initialized
ERROR - 2021-12-15 01:06:46 --> 404 Page Not Found: Media/wp-includes
ERROR - 2021-12-15 01:06:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 01:06:46 --> Config Class Initialized
INFO - 2021-12-15 01:06:46 --> Hooks Class Initialized
DEBUG - 2021-12-15 01:06:46 --> UTF-8 Support Enabled
INFO - 2021-12-15 01:06:46 --> Utf8 Class Initialized
INFO - 2021-12-15 01:06:46 --> URI Class Initialized
INFO - 2021-12-15 01:06:46 --> Router Class Initialized
INFO - 2021-12-15 01:06:46 --> Output Class Initialized
INFO - 2021-12-15 01:06:46 --> Security Class Initialized
DEBUG - 2021-12-15 01:06:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 01:06:46 --> Input Class Initialized
INFO - 2021-12-15 01:06:46 --> Language Class Initialized
ERROR - 2021-12-15 01:06:46 --> 404 Page Not Found: Wp2/wp-includes
ERROR - 2021-12-15 01:06:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 01:06:47 --> Config Class Initialized
INFO - 2021-12-15 01:06:47 --> Hooks Class Initialized
DEBUG - 2021-12-15 01:06:47 --> UTF-8 Support Enabled
INFO - 2021-12-15 01:06:47 --> Utf8 Class Initialized
INFO - 2021-12-15 01:06:47 --> URI Class Initialized
INFO - 2021-12-15 01:06:47 --> Router Class Initialized
INFO - 2021-12-15 01:06:47 --> Output Class Initialized
INFO - 2021-12-15 01:06:47 --> Security Class Initialized
DEBUG - 2021-12-15 01:06:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 01:06:47 --> Input Class Initialized
INFO - 2021-12-15 01:06:47 --> Language Class Initialized
ERROR - 2021-12-15 01:06:47 --> 404 Page Not Found: Site/wp-includes
ERROR - 2021-12-15 01:06:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 01:06:48 --> Config Class Initialized
INFO - 2021-12-15 01:06:48 --> Hooks Class Initialized
DEBUG - 2021-12-15 01:06:48 --> UTF-8 Support Enabled
INFO - 2021-12-15 01:06:48 --> Utf8 Class Initialized
INFO - 2021-12-15 01:06:48 --> URI Class Initialized
INFO - 2021-12-15 01:06:48 --> Router Class Initialized
INFO - 2021-12-15 01:06:48 --> Output Class Initialized
INFO - 2021-12-15 01:06:48 --> Security Class Initialized
DEBUG - 2021-12-15 01:06:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 01:06:48 --> Input Class Initialized
INFO - 2021-12-15 01:06:48 --> Language Class Initialized
ERROR - 2021-12-15 01:06:48 --> 404 Page Not Found: Cms/wp-includes
ERROR - 2021-12-15 01:06:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 01:06:48 --> Config Class Initialized
INFO - 2021-12-15 01:06:48 --> Hooks Class Initialized
DEBUG - 2021-12-15 01:06:48 --> UTF-8 Support Enabled
INFO - 2021-12-15 01:06:48 --> Utf8 Class Initialized
INFO - 2021-12-15 01:06:48 --> URI Class Initialized
INFO - 2021-12-15 01:06:48 --> Router Class Initialized
INFO - 2021-12-15 01:06:48 --> Output Class Initialized
INFO - 2021-12-15 01:06:48 --> Security Class Initialized
DEBUG - 2021-12-15 01:06:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 01:06:48 --> Input Class Initialized
INFO - 2021-12-15 01:06:48 --> Language Class Initialized
ERROR - 2021-12-15 01:06:48 --> 404 Page Not Found: Sito/wp-includes
ERROR - 2021-12-15 01:14:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 01:14:11 --> Config Class Initialized
INFO - 2021-12-15 01:14:11 --> Hooks Class Initialized
DEBUG - 2021-12-15 01:14:11 --> UTF-8 Support Enabled
INFO - 2021-12-15 01:14:11 --> Utf8 Class Initialized
INFO - 2021-12-15 01:14:11 --> URI Class Initialized
INFO - 2021-12-15 01:14:11 --> Router Class Initialized
INFO - 2021-12-15 01:14:11 --> Output Class Initialized
INFO - 2021-12-15 01:14:11 --> Security Class Initialized
DEBUG - 2021-12-15 01:14:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 01:14:11 --> Input Class Initialized
INFO - 2021-12-15 01:14:11 --> Language Class Initialized
INFO - 2021-12-15 01:14:11 --> Loader Class Initialized
INFO - 2021-12-15 01:14:11 --> Helper loaded: url_helper
INFO - 2021-12-15 01:14:11 --> Helper loaded: form_helper
INFO - 2021-12-15 01:14:11 --> Helper loaded: common_helper
INFO - 2021-12-15 01:14:11 --> Database Driver Class Initialized
DEBUG - 2021-12-15 01:14:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 01:14:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 01:14:11 --> Controller Class Initialized
INFO - 2021-12-15 01:14:11 --> Form Validation Class Initialized
DEBUG - 2021-12-15 01:14:11 --> Encrypt Class Initialized
INFO - 2021-12-15 01:14:11 --> Model "Login_model" initialized
INFO - 2021-12-15 01:14:11 --> Model "Dashboard_model" initialized
INFO - 2021-12-15 01:14:11 --> Model "Case_model" initialized
INFO - 2021-12-15 01:14:11 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-15 01:14:11 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/birthday.php
INFO - 2021-12-15 01:14:11 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-15 01:14:11 --> Final output sent to browser
DEBUG - 2021-12-15 01:14:11 --> Total execution time: 0.0520
ERROR - 2021-12-15 01:14:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 01:14:12 --> Config Class Initialized
INFO - 2021-12-15 01:14:12 --> Hooks Class Initialized
DEBUG - 2021-12-15 01:14:12 --> UTF-8 Support Enabled
INFO - 2021-12-15 01:14:12 --> Utf8 Class Initialized
INFO - 2021-12-15 01:14:12 --> URI Class Initialized
INFO - 2021-12-15 01:14:12 --> Router Class Initialized
INFO - 2021-12-15 01:14:12 --> Output Class Initialized
INFO - 2021-12-15 01:14:12 --> Security Class Initialized
DEBUG - 2021-12-15 01:14:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 01:14:12 --> Input Class Initialized
INFO - 2021-12-15 01:14:12 --> Language Class Initialized
ERROR - 2021-12-15 01:14:12 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-12-15 01:14:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 01:14:53 --> Config Class Initialized
INFO - 2021-12-15 01:14:53 --> Hooks Class Initialized
DEBUG - 2021-12-15 01:14:53 --> UTF-8 Support Enabled
INFO - 2021-12-15 01:14:53 --> Utf8 Class Initialized
INFO - 2021-12-15 01:14:53 --> URI Class Initialized
INFO - 2021-12-15 01:14:53 --> Router Class Initialized
INFO - 2021-12-15 01:14:53 --> Output Class Initialized
INFO - 2021-12-15 01:14:53 --> Security Class Initialized
DEBUG - 2021-12-15 01:14:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 01:14:53 --> Input Class Initialized
INFO - 2021-12-15 01:14:53 --> Language Class Initialized
INFO - 2021-12-15 01:14:53 --> Loader Class Initialized
INFO - 2021-12-15 01:14:53 --> Helper loaded: url_helper
INFO - 2021-12-15 01:14:53 --> Helper loaded: form_helper
INFO - 2021-12-15 01:14:53 --> Helper loaded: common_helper
INFO - 2021-12-15 01:14:53 --> Database Driver Class Initialized
DEBUG - 2021-12-15 01:14:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 01:14:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 01:14:53 --> Controller Class Initialized
INFO - 2021-12-15 01:14:53 --> Form Validation Class Initialized
INFO - 2021-12-15 01:14:53 --> Model "Case_model" initialized
INFO - 2021-12-15 01:14:53 --> Model "Hospital_model" initialized
INFO - 2021-12-15 01:14:53 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-15 01:14:53 --> File loaded: /home3/karoteam/public_html/application/views/transaction/upcomingFollowup.php
INFO - 2021-12-15 01:14:53 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-15 01:14:53 --> Final output sent to browser
DEBUG - 2021-12-15 01:14:53 --> Total execution time: 0.0341
ERROR - 2021-12-15 01:14:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 01:14:53 --> Config Class Initialized
INFO - 2021-12-15 01:14:53 --> Hooks Class Initialized
DEBUG - 2021-12-15 01:14:53 --> UTF-8 Support Enabled
INFO - 2021-12-15 01:14:53 --> Utf8 Class Initialized
INFO - 2021-12-15 01:14:53 --> URI Class Initialized
INFO - 2021-12-15 01:14:53 --> Router Class Initialized
INFO - 2021-12-15 01:14:53 --> Output Class Initialized
INFO - 2021-12-15 01:14:53 --> Security Class Initialized
DEBUG - 2021-12-15 01:14:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 01:14:53 --> Input Class Initialized
INFO - 2021-12-15 01:14:53 --> Language Class Initialized
ERROR - 2021-12-15 01:14:53 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-12-15 01:15:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 01:15:03 --> Config Class Initialized
INFO - 2021-12-15 01:15:03 --> Hooks Class Initialized
DEBUG - 2021-12-15 01:15:03 --> UTF-8 Support Enabled
INFO - 2021-12-15 01:15:03 --> Utf8 Class Initialized
INFO - 2021-12-15 01:15:03 --> URI Class Initialized
INFO - 2021-12-15 01:15:03 --> Router Class Initialized
INFO - 2021-12-15 01:15:03 --> Output Class Initialized
INFO - 2021-12-15 01:15:03 --> Security Class Initialized
DEBUG - 2021-12-15 01:15:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 01:15:03 --> Input Class Initialized
INFO - 2021-12-15 01:15:03 --> Language Class Initialized
INFO - 2021-12-15 01:15:03 --> Loader Class Initialized
INFO - 2021-12-15 01:15:03 --> Helper loaded: url_helper
INFO - 2021-12-15 01:15:03 --> Helper loaded: form_helper
INFO - 2021-12-15 01:15:03 --> Helper loaded: common_helper
INFO - 2021-12-15 01:15:03 --> Database Driver Class Initialized
DEBUG - 2021-12-15 01:15:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 01:15:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 01:15:03 --> Controller Class Initialized
INFO - 2021-12-15 01:15:03 --> Form Validation Class Initialized
INFO - 2021-12-15 01:15:03 --> Model "Case_model" initialized
INFO - 2021-12-15 01:15:07 --> Model "Hospital_model" initialized
INFO - 2021-12-15 01:15:07 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-15 01:15:07 --> File loaded: /home3/karoteam/public_html/application/views/transaction/upcomingFollowup.php
INFO - 2021-12-15 01:15:07 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-15 01:15:07 --> Final output sent to browser
DEBUG - 2021-12-15 01:15:07 --> Total execution time: 4.2156
ERROR - 2021-12-15 01:15:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 01:15:08 --> Config Class Initialized
INFO - 2021-12-15 01:15:08 --> Hooks Class Initialized
DEBUG - 2021-12-15 01:15:08 --> UTF-8 Support Enabled
INFO - 2021-12-15 01:15:08 --> Utf8 Class Initialized
INFO - 2021-12-15 01:15:08 --> URI Class Initialized
INFO - 2021-12-15 01:15:08 --> Router Class Initialized
INFO - 2021-12-15 01:15:08 --> Output Class Initialized
INFO - 2021-12-15 01:15:08 --> Security Class Initialized
DEBUG - 2021-12-15 01:15:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 01:15:08 --> Input Class Initialized
INFO - 2021-12-15 01:15:08 --> Language Class Initialized
ERROR - 2021-12-15 01:15:08 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-12-15 01:15:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 01:15:17 --> Config Class Initialized
INFO - 2021-12-15 01:15:17 --> Hooks Class Initialized
DEBUG - 2021-12-15 01:15:17 --> UTF-8 Support Enabled
INFO - 2021-12-15 01:15:17 --> Utf8 Class Initialized
INFO - 2021-12-15 01:15:17 --> URI Class Initialized
INFO - 2021-12-15 01:15:17 --> Router Class Initialized
INFO - 2021-12-15 01:15:17 --> Output Class Initialized
INFO - 2021-12-15 01:15:17 --> Security Class Initialized
DEBUG - 2021-12-15 01:15:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 01:15:17 --> Input Class Initialized
INFO - 2021-12-15 01:15:17 --> Language Class Initialized
INFO - 2021-12-15 01:15:17 --> Loader Class Initialized
INFO - 2021-12-15 01:15:17 --> Helper loaded: url_helper
INFO - 2021-12-15 01:15:17 --> Helper loaded: form_helper
INFO - 2021-12-15 01:15:17 --> Helper loaded: common_helper
INFO - 2021-12-15 01:15:17 --> Database Driver Class Initialized
DEBUG - 2021-12-15 01:15:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 01:15:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 01:15:17 --> Controller Class Initialized
INFO - 2021-12-15 01:15:17 --> Form Validation Class Initialized
DEBUG - 2021-12-15 01:15:17 --> Encrypt Class Initialized
INFO - 2021-12-15 01:15:17 --> Model "Login_model" initialized
INFO - 2021-12-15 01:15:17 --> Model "Dashboard_model" initialized
INFO - 2021-12-15 01:15:17 --> Model "Case_model" initialized
ERROR - 2021-12-15 01:15:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 01:15:24 --> Config Class Initialized
INFO - 2021-12-15 01:15:24 --> Hooks Class Initialized
DEBUG - 2021-12-15 01:15:24 --> UTF-8 Support Enabled
INFO - 2021-12-15 01:15:24 --> Utf8 Class Initialized
INFO - 2021-12-15 01:15:24 --> URI Class Initialized
INFO - 2021-12-15 01:15:24 --> Router Class Initialized
INFO - 2021-12-15 01:15:24 --> Output Class Initialized
INFO - 2021-12-15 01:15:24 --> Security Class Initialized
DEBUG - 2021-12-15 01:15:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 01:15:24 --> Input Class Initialized
INFO - 2021-12-15 01:15:24 --> Language Class Initialized
INFO - 2021-12-15 01:15:24 --> Loader Class Initialized
INFO - 2021-12-15 01:15:24 --> Helper loaded: url_helper
INFO - 2021-12-15 01:15:24 --> Helper loaded: form_helper
INFO - 2021-12-15 01:15:24 --> Helper loaded: common_helper
INFO - 2021-12-15 01:15:24 --> Database Driver Class Initialized
DEBUG - 2021-12-15 01:15:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 01:15:24 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-15 01:15:33 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2021-12-15 01:15:33 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-15 01:15:33 --> Final output sent to browser
DEBUG - 2021-12-15 01:15:33 --> Total execution time: 16.1409
INFO - 2021-12-15 01:15:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 01:15:33 --> Controller Class Initialized
INFO - 2021-12-15 01:15:33 --> Form Validation Class Initialized
INFO - 2021-12-15 01:15:33 --> Model "Case_model" initialized
INFO - 2021-12-15 01:15:33 --> Model "Patientcase_model" initialized
ERROR - 2021-12-15 01:15:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 01:15:33 --> Config Class Initialized
INFO - 2021-12-15 01:15:33 --> Hooks Class Initialized
DEBUG - 2021-12-15 01:15:33 --> UTF-8 Support Enabled
INFO - 2021-12-15 01:15:33 --> Utf8 Class Initialized
INFO - 2021-12-15 01:15:33 --> URI Class Initialized
INFO - 2021-12-15 01:15:33 --> Router Class Initialized
INFO - 2021-12-15 01:15:33 --> Output Class Initialized
INFO - 2021-12-15 01:15:33 --> Security Class Initialized
DEBUG - 2021-12-15 01:15:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 01:15:33 --> Input Class Initialized
INFO - 2021-12-15 01:15:33 --> Language Class Initialized
INFO - 2021-12-15 01:15:33 --> Loader Class Initialized
INFO - 2021-12-15 01:15:33 --> Helper loaded: url_helper
INFO - 2021-12-15 01:15:33 --> Helper loaded: form_helper
INFO - 2021-12-15 01:15:33 --> Helper loaded: common_helper
INFO - 2021-12-15 01:15:33 --> Database Driver Class Initialized
DEBUG - 2021-12-15 01:15:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 01:15:35 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-15 01:15:35 --> Model "Case_model" initialized
INFO - 2021-12-15 01:15:38 --> File loaded: /home3/karoteam/public_html/application/views/cases/open_case.php
INFO - 2021-12-15 01:15:38 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-15 01:15:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 01:15:38 --> Controller Class Initialized
INFO - 2021-12-15 01:15:38 --> Form Validation Class Initialized
INFO - 2021-12-15 01:15:38 --> Model "Case_model" initialized
INFO - 2021-12-15 01:15:38 --> Model "Patientcase_model" initialized
INFO - 2021-12-15 01:15:40 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-15 01:15:40 --> Model "Case_model" initialized
INFO - 2021-12-15 01:15:44 --> File loaded: /home3/karoteam/public_html/application/views/cases/open_case.php
INFO - 2021-12-15 01:15:44 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
ERROR - 2021-12-15 01:15:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 01:15:46 --> Config Class Initialized
INFO - 2021-12-15 01:15:46 --> Hooks Class Initialized
DEBUG - 2021-12-15 01:15:46 --> UTF-8 Support Enabled
INFO - 2021-12-15 01:15:46 --> Utf8 Class Initialized
INFO - 2021-12-15 01:15:46 --> URI Class Initialized
INFO - 2021-12-15 01:15:46 --> Router Class Initialized
INFO - 2021-12-15 01:15:46 --> Output Class Initialized
INFO - 2021-12-15 01:15:46 --> Security Class Initialized
DEBUG - 2021-12-15 01:15:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 01:15:46 --> Input Class Initialized
INFO - 2021-12-15 01:15:46 --> Language Class Initialized
INFO - 2021-12-15 01:15:46 --> Loader Class Initialized
INFO - 2021-12-15 01:15:46 --> Helper loaded: url_helper
INFO - 2021-12-15 01:15:46 --> Helper loaded: form_helper
INFO - 2021-12-15 01:15:46 --> Helper loaded: common_helper
INFO - 2021-12-15 01:15:46 --> Database Driver Class Initialized
DEBUG - 2021-12-15 01:15:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 01:15:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 01:15:46 --> Controller Class Initialized
INFO - 2021-12-15 01:15:46 --> Form Validation Class Initialized
INFO - 2021-12-15 01:15:46 --> Model "Case_model" initialized
INFO - 2021-12-15 01:15:51 --> Model "Hospital_model" initialized
INFO - 2021-12-15 01:15:51 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-15 01:15:51 --> File loaded: /home3/karoteam/public_html/application/views/transaction/upcomingFollowup.php
INFO - 2021-12-15 01:15:51 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-15 01:15:51 --> Final output sent to browser
DEBUG - 2021-12-15 01:15:51 --> Total execution time: 4.9318
ERROR - 2021-12-15 01:15:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 01:15:51 --> Config Class Initialized
INFO - 2021-12-15 01:15:51 --> Hooks Class Initialized
DEBUG - 2021-12-15 01:15:51 --> UTF-8 Support Enabled
INFO - 2021-12-15 01:15:51 --> Utf8 Class Initialized
INFO - 2021-12-15 01:15:51 --> URI Class Initialized
INFO - 2021-12-15 01:15:51 --> Router Class Initialized
INFO - 2021-12-15 01:15:51 --> Output Class Initialized
INFO - 2021-12-15 01:15:51 --> Security Class Initialized
DEBUG - 2021-12-15 01:15:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 01:15:51 --> Input Class Initialized
INFO - 2021-12-15 01:15:51 --> Language Class Initialized
ERROR - 2021-12-15 01:15:51 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-12-15 01:16:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 01:16:12 --> Config Class Initialized
INFO - 2021-12-15 01:16:12 --> Hooks Class Initialized
DEBUG - 2021-12-15 01:16:12 --> UTF-8 Support Enabled
INFO - 2021-12-15 01:16:12 --> Utf8 Class Initialized
INFO - 2021-12-15 01:16:12 --> URI Class Initialized
INFO - 2021-12-15 01:16:12 --> Router Class Initialized
INFO - 2021-12-15 01:16:12 --> Output Class Initialized
INFO - 2021-12-15 01:16:12 --> Security Class Initialized
DEBUG - 2021-12-15 01:16:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 01:16:12 --> Input Class Initialized
INFO - 2021-12-15 01:16:12 --> Language Class Initialized
INFO - 2021-12-15 01:16:12 --> Loader Class Initialized
INFO - 2021-12-15 01:16:12 --> Helper loaded: url_helper
INFO - 2021-12-15 01:16:12 --> Helper loaded: form_helper
INFO - 2021-12-15 01:16:12 --> Helper loaded: common_helper
INFO - 2021-12-15 01:16:12 --> Database Driver Class Initialized
DEBUG - 2021-12-15 01:16:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 01:16:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 01:16:12 --> Controller Class Initialized
INFO - 2021-12-15 01:16:12 --> Form Validation Class Initialized
INFO - 2021-12-15 01:16:12 --> Model "Case_model" initialized
INFO - 2021-12-15 01:16:16 --> Model "Hospital_model" initialized
INFO - 2021-12-15 01:16:16 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-15 01:16:16 --> File loaded: /home3/karoteam/public_html/application/views/transaction/upcomingFollowup.php
INFO - 2021-12-15 01:16:16 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-15 01:16:16 --> Final output sent to browser
DEBUG - 2021-12-15 01:16:16 --> Total execution time: 4.1964
ERROR - 2021-12-15 01:16:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 01:16:17 --> Config Class Initialized
INFO - 2021-12-15 01:16:17 --> Hooks Class Initialized
DEBUG - 2021-12-15 01:16:17 --> UTF-8 Support Enabled
INFO - 2021-12-15 01:16:17 --> Utf8 Class Initialized
INFO - 2021-12-15 01:16:17 --> URI Class Initialized
INFO - 2021-12-15 01:16:17 --> Router Class Initialized
INFO - 2021-12-15 01:16:17 --> Output Class Initialized
INFO - 2021-12-15 01:16:17 --> Security Class Initialized
DEBUG - 2021-12-15 01:16:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 01:16:17 --> Input Class Initialized
INFO - 2021-12-15 01:16:17 --> Language Class Initialized
ERROR - 2021-12-15 01:16:17 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-12-15 01:16:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 01:16:19 --> Config Class Initialized
INFO - 2021-12-15 01:16:19 --> Hooks Class Initialized
DEBUG - 2021-12-15 01:16:19 --> UTF-8 Support Enabled
INFO - 2021-12-15 01:16:19 --> Utf8 Class Initialized
INFO - 2021-12-15 01:16:19 --> URI Class Initialized
INFO - 2021-12-15 01:16:19 --> Router Class Initialized
INFO - 2021-12-15 01:16:19 --> Output Class Initialized
INFO - 2021-12-15 01:16:19 --> Security Class Initialized
DEBUG - 2021-12-15 01:16:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 01:16:19 --> Input Class Initialized
INFO - 2021-12-15 01:16:19 --> Language Class Initialized
INFO - 2021-12-15 01:16:19 --> Loader Class Initialized
INFO - 2021-12-15 01:16:19 --> Helper loaded: url_helper
INFO - 2021-12-15 01:16:19 --> Helper loaded: form_helper
INFO - 2021-12-15 01:16:19 --> Helper loaded: common_helper
INFO - 2021-12-15 01:16:19 --> Database Driver Class Initialized
DEBUG - 2021-12-15 01:16:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 01:16:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 01:16:19 --> Controller Class Initialized
INFO - 2021-12-15 01:16:19 --> Form Validation Class Initialized
INFO - 2021-12-15 01:16:19 --> Model "Case_model" initialized
ERROR - 2021-12-15 01:16:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 01:16:22 --> Config Class Initialized
INFO - 2021-12-15 01:16:22 --> Hooks Class Initialized
DEBUG - 2021-12-15 01:16:22 --> UTF-8 Support Enabled
INFO - 2021-12-15 01:16:22 --> Utf8 Class Initialized
INFO - 2021-12-15 01:16:22 --> URI Class Initialized
INFO - 2021-12-15 01:16:22 --> Router Class Initialized
INFO - 2021-12-15 01:16:22 --> Output Class Initialized
INFO - 2021-12-15 01:16:22 --> Security Class Initialized
DEBUG - 2021-12-15 01:16:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 01:16:22 --> Input Class Initialized
INFO - 2021-12-15 01:16:22 --> Language Class Initialized
INFO - 2021-12-15 01:16:22 --> Loader Class Initialized
INFO - 2021-12-15 01:16:22 --> Helper loaded: url_helper
INFO - 2021-12-15 01:16:22 --> Helper loaded: form_helper
INFO - 2021-12-15 01:16:22 --> Helper loaded: common_helper
INFO - 2021-12-15 01:16:22 --> Database Driver Class Initialized
DEBUG - 2021-12-15 01:16:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 01:16:22 --> Model "Hospital_model" initialized
INFO - 2021-12-15 01:16:22 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-15 01:16:22 --> File loaded: /home3/karoteam/public_html/application/views/transaction/upcomingFollowup.php
INFO - 2021-12-15 01:16:22 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-15 01:16:22 --> Final output sent to browser
DEBUG - 2021-12-15 01:16:22 --> Total execution time: 3.8054
INFO - 2021-12-15 01:16:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 01:16:22 --> Controller Class Initialized
INFO - 2021-12-15 01:16:22 --> Form Validation Class Initialized
INFO - 2021-12-15 01:16:22 --> Model "Case_model" initialized
INFO - 2021-12-15 01:16:26 --> Model "Hospital_model" initialized
INFO - 2021-12-15 01:16:26 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-15 01:16:26 --> File loaded: /home3/karoteam/public_html/application/views/transaction/upcomingFollowup.php
INFO - 2021-12-15 01:16:26 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-15 01:16:26 --> Final output sent to browser
DEBUG - 2021-12-15 01:16:26 --> Total execution time: 4.4070
ERROR - 2021-12-15 01:16:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 01:16:27 --> Config Class Initialized
INFO - 2021-12-15 01:16:27 --> Hooks Class Initialized
DEBUG - 2021-12-15 01:16:27 --> UTF-8 Support Enabled
INFO - 2021-12-15 01:16:27 --> Utf8 Class Initialized
INFO - 2021-12-15 01:16:27 --> URI Class Initialized
INFO - 2021-12-15 01:16:27 --> Router Class Initialized
INFO - 2021-12-15 01:16:27 --> Output Class Initialized
INFO - 2021-12-15 01:16:27 --> Security Class Initialized
DEBUG - 2021-12-15 01:16:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 01:16:27 --> Input Class Initialized
INFO - 2021-12-15 01:16:27 --> Language Class Initialized
ERROR - 2021-12-15 01:16:27 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-12-15 01:16:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 01:16:31 --> Config Class Initialized
INFO - 2021-12-15 01:16:31 --> Hooks Class Initialized
DEBUG - 2021-12-15 01:16:31 --> UTF-8 Support Enabled
INFO - 2021-12-15 01:16:31 --> Utf8 Class Initialized
INFO - 2021-12-15 01:16:31 --> URI Class Initialized
INFO - 2021-12-15 01:16:31 --> Router Class Initialized
INFO - 2021-12-15 01:16:31 --> Output Class Initialized
INFO - 2021-12-15 01:16:31 --> Security Class Initialized
DEBUG - 2021-12-15 01:16:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 01:16:31 --> Input Class Initialized
INFO - 2021-12-15 01:16:31 --> Language Class Initialized
INFO - 2021-12-15 01:16:31 --> Loader Class Initialized
INFO - 2021-12-15 01:16:31 --> Helper loaded: url_helper
INFO - 2021-12-15 01:16:31 --> Helper loaded: form_helper
INFO - 2021-12-15 01:16:31 --> Helper loaded: common_helper
INFO - 2021-12-15 01:16:31 --> Database Driver Class Initialized
DEBUG - 2021-12-15 01:16:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 01:16:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 01:16:31 --> Controller Class Initialized
INFO - 2021-12-15 01:16:31 --> Form Validation Class Initialized
INFO - 2021-12-15 01:16:31 --> Model "Case_model" initialized
INFO - 2021-12-15 01:16:31 --> Model "Patientcase_model" initialized
INFO - 2021-12-15 01:16:33 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-15 01:16:33 --> Model "Case_model" initialized
INFO - 2021-12-15 01:16:36 --> File loaded: /home3/karoteam/public_html/application/views/cases/open_case.php
INFO - 2021-12-15 01:16:36 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-15 01:16:36 --> Final output sent to browser
DEBUG - 2021-12-15 01:16:36 --> Total execution time: 4.7814
ERROR - 2021-12-15 01:16:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 01:16:37 --> Config Class Initialized
INFO - 2021-12-15 01:16:37 --> Hooks Class Initialized
DEBUG - 2021-12-15 01:16:37 --> UTF-8 Support Enabled
INFO - 2021-12-15 01:16:37 --> Utf8 Class Initialized
INFO - 2021-12-15 01:16:37 --> URI Class Initialized
INFO - 2021-12-15 01:16:37 --> Router Class Initialized
INFO - 2021-12-15 01:16:37 --> Output Class Initialized
INFO - 2021-12-15 01:16:37 --> Security Class Initialized
DEBUG - 2021-12-15 01:16:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 01:16:37 --> Input Class Initialized
INFO - 2021-12-15 01:16:37 --> Language Class Initialized
ERROR - 2021-12-15 01:16:37 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-12-15 01:16:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 01:16:45 --> Config Class Initialized
INFO - 2021-12-15 01:16:45 --> Hooks Class Initialized
DEBUG - 2021-12-15 01:16:45 --> UTF-8 Support Enabled
INFO - 2021-12-15 01:16:45 --> Utf8 Class Initialized
INFO - 2021-12-15 01:16:45 --> URI Class Initialized
INFO - 2021-12-15 01:16:45 --> Router Class Initialized
INFO - 2021-12-15 01:16:45 --> Output Class Initialized
INFO - 2021-12-15 01:16:45 --> Security Class Initialized
DEBUG - 2021-12-15 01:16:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 01:16:45 --> Input Class Initialized
INFO - 2021-12-15 01:16:45 --> Language Class Initialized
INFO - 2021-12-15 01:16:45 --> Loader Class Initialized
INFO - 2021-12-15 01:16:45 --> Helper loaded: url_helper
INFO - 2021-12-15 01:16:45 --> Helper loaded: form_helper
INFO - 2021-12-15 01:16:45 --> Helper loaded: common_helper
INFO - 2021-12-15 01:16:45 --> Database Driver Class Initialized
DEBUG - 2021-12-15 01:16:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 01:16:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 01:16:45 --> Controller Class Initialized
INFO - 2021-12-15 01:16:45 --> Form Validation Class Initialized
INFO - 2021-12-15 01:16:45 --> Model "Case_model" initialized
INFO - 2021-12-15 01:16:45 --> Model "Patientcase_model" initialized
INFO - 2021-12-15 01:16:45 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-15 01:16:45 --> File loaded: /home3/karoteam/public_html/application/views/cases/patient_amount_disbursed.php
INFO - 2021-12-15 01:16:45 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-15 01:16:45 --> Final output sent to browser
DEBUG - 2021-12-15 01:16:45 --> Total execution time: 0.0476
ERROR - 2021-12-15 01:16:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 01:16:46 --> Config Class Initialized
INFO - 2021-12-15 01:16:46 --> Hooks Class Initialized
DEBUG - 2021-12-15 01:16:46 --> UTF-8 Support Enabled
INFO - 2021-12-15 01:16:46 --> Utf8 Class Initialized
INFO - 2021-12-15 01:16:46 --> URI Class Initialized
INFO - 2021-12-15 01:16:46 --> Router Class Initialized
INFO - 2021-12-15 01:16:46 --> Output Class Initialized
INFO - 2021-12-15 01:16:46 --> Security Class Initialized
DEBUG - 2021-12-15 01:16:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 01:16:46 --> Input Class Initialized
INFO - 2021-12-15 01:16:46 --> Language Class Initialized
ERROR - 2021-12-15 01:16:46 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-12-15 01:17:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 01:17:38 --> Config Class Initialized
INFO - 2021-12-15 01:17:38 --> Hooks Class Initialized
DEBUG - 2021-12-15 01:17:38 --> UTF-8 Support Enabled
INFO - 2021-12-15 01:17:38 --> Utf8 Class Initialized
INFO - 2021-12-15 01:17:38 --> URI Class Initialized
INFO - 2021-12-15 01:17:38 --> Router Class Initialized
INFO - 2021-12-15 01:17:38 --> Output Class Initialized
INFO - 2021-12-15 01:17:38 --> Security Class Initialized
DEBUG - 2021-12-15 01:17:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 01:17:38 --> Input Class Initialized
INFO - 2021-12-15 01:17:38 --> Language Class Initialized
INFO - 2021-12-15 01:17:38 --> Loader Class Initialized
INFO - 2021-12-15 01:17:38 --> Helper loaded: url_helper
INFO - 2021-12-15 01:17:38 --> Helper loaded: form_helper
INFO - 2021-12-15 01:17:38 --> Helper loaded: common_helper
INFO - 2021-12-15 01:17:38 --> Database Driver Class Initialized
DEBUG - 2021-12-15 01:17:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 01:17:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 01:17:38 --> Controller Class Initialized
INFO - 2021-12-15 01:17:38 --> Form Validation Class Initialized
INFO - 2021-12-15 01:17:38 --> Model "Case_model" initialized
INFO - 2021-12-15 01:17:38 --> Model "Patientcase_model" initialized
INFO - 2021-12-15 01:17:38 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-15 01:17:38 --> File loaded: /home3/karoteam/public_html/application/views/cases/edit_sanction_details.php
INFO - 2021-12-15 01:17:38 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-15 01:17:38 --> Final output sent to browser
DEBUG - 2021-12-15 01:17:38 --> Total execution time: 0.0661
ERROR - 2021-12-15 01:17:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 01:17:39 --> Config Class Initialized
INFO - 2021-12-15 01:17:39 --> Hooks Class Initialized
DEBUG - 2021-12-15 01:17:39 --> UTF-8 Support Enabled
INFO - 2021-12-15 01:17:39 --> Utf8 Class Initialized
INFO - 2021-12-15 01:17:39 --> URI Class Initialized
INFO - 2021-12-15 01:17:39 --> Router Class Initialized
INFO - 2021-12-15 01:17:39 --> Output Class Initialized
INFO - 2021-12-15 01:17:39 --> Security Class Initialized
DEBUG - 2021-12-15 01:17:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 01:17:39 --> Input Class Initialized
INFO - 2021-12-15 01:17:39 --> Language Class Initialized
ERROR - 2021-12-15 01:17:39 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-12-15 01:17:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 01:17:48 --> Config Class Initialized
INFO - 2021-12-15 01:17:48 --> Hooks Class Initialized
DEBUG - 2021-12-15 01:17:48 --> UTF-8 Support Enabled
INFO - 2021-12-15 01:17:48 --> Utf8 Class Initialized
INFO - 2021-12-15 01:17:48 --> URI Class Initialized
INFO - 2021-12-15 01:17:48 --> Router Class Initialized
INFO - 2021-12-15 01:17:48 --> Output Class Initialized
INFO - 2021-12-15 01:17:48 --> Security Class Initialized
DEBUG - 2021-12-15 01:17:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 01:17:48 --> Input Class Initialized
INFO - 2021-12-15 01:17:48 --> Language Class Initialized
INFO - 2021-12-15 01:17:48 --> Loader Class Initialized
INFO - 2021-12-15 01:17:48 --> Helper loaded: url_helper
INFO - 2021-12-15 01:17:48 --> Helper loaded: form_helper
INFO - 2021-12-15 01:17:48 --> Helper loaded: common_helper
INFO - 2021-12-15 01:17:48 --> Database Driver Class Initialized
DEBUG - 2021-12-15 01:17:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 01:17:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 01:17:48 --> Controller Class Initialized
INFO - 2021-12-15 01:17:48 --> Form Validation Class Initialized
INFO - 2021-12-15 01:17:48 --> Model "Case_model" initialized
INFO - 2021-12-15 01:17:48 --> Model "Patientcase_model" initialized
INFO - 2021-12-15 01:17:48 --> Final output sent to browser
DEBUG - 2021-12-15 01:17:48 --> Total execution time: 0.0260
ERROR - 2021-12-15 01:18:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 01:18:01 --> Config Class Initialized
INFO - 2021-12-15 01:18:01 --> Hooks Class Initialized
DEBUG - 2021-12-15 01:18:01 --> UTF-8 Support Enabled
INFO - 2021-12-15 01:18:01 --> Utf8 Class Initialized
INFO - 2021-12-15 01:18:01 --> URI Class Initialized
INFO - 2021-12-15 01:18:01 --> Router Class Initialized
INFO - 2021-12-15 01:18:01 --> Output Class Initialized
INFO - 2021-12-15 01:18:01 --> Security Class Initialized
DEBUG - 2021-12-15 01:18:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 01:18:01 --> Input Class Initialized
INFO - 2021-12-15 01:18:01 --> Language Class Initialized
INFO - 2021-12-15 01:18:01 --> Loader Class Initialized
INFO - 2021-12-15 01:18:01 --> Helper loaded: url_helper
INFO - 2021-12-15 01:18:01 --> Helper loaded: form_helper
INFO - 2021-12-15 01:18:01 --> Helper loaded: common_helper
INFO - 2021-12-15 01:18:01 --> Database Driver Class Initialized
DEBUG - 2021-12-15 01:18:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 01:18:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 01:18:01 --> Controller Class Initialized
INFO - 2021-12-15 01:18:01 --> Form Validation Class Initialized
INFO - 2021-12-15 01:18:01 --> Model "Case_model" initialized
INFO - 2021-12-15 01:18:01 --> Model "Patientcase_model" initialized
INFO - 2021-12-15 01:18:01 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-15 01:18:01 --> File loaded: /home3/karoteam/public_html/application/views/cases/patient_amount_disbursed.php
INFO - 2021-12-15 01:18:01 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-15 01:18:01 --> Final output sent to browser
DEBUG - 2021-12-15 01:18:01 --> Total execution time: 0.0460
ERROR - 2021-12-15 01:18:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 01:18:01 --> Config Class Initialized
INFO - 2021-12-15 01:18:01 --> Hooks Class Initialized
DEBUG - 2021-12-15 01:18:01 --> UTF-8 Support Enabled
INFO - 2021-12-15 01:18:01 --> Utf8 Class Initialized
INFO - 2021-12-15 01:18:01 --> URI Class Initialized
INFO - 2021-12-15 01:18:01 --> Router Class Initialized
INFO - 2021-12-15 01:18:01 --> Output Class Initialized
INFO - 2021-12-15 01:18:01 --> Security Class Initialized
DEBUG - 2021-12-15 01:18:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 01:18:01 --> Input Class Initialized
INFO - 2021-12-15 01:18:01 --> Language Class Initialized
ERROR - 2021-12-15 01:18:01 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-12-15 01:20:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 01:20:21 --> Config Class Initialized
INFO - 2021-12-15 01:20:21 --> Hooks Class Initialized
DEBUG - 2021-12-15 01:20:21 --> UTF-8 Support Enabled
INFO - 2021-12-15 01:20:21 --> Utf8 Class Initialized
INFO - 2021-12-15 01:20:21 --> URI Class Initialized
INFO - 2021-12-15 01:20:21 --> Router Class Initialized
INFO - 2021-12-15 01:20:21 --> Output Class Initialized
INFO - 2021-12-15 01:20:21 --> Security Class Initialized
DEBUG - 2021-12-15 01:20:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 01:20:21 --> Input Class Initialized
INFO - 2021-12-15 01:20:21 --> Language Class Initialized
INFO - 2021-12-15 01:20:21 --> Loader Class Initialized
INFO - 2021-12-15 01:20:21 --> Helper loaded: url_helper
INFO - 2021-12-15 01:20:21 --> Helper loaded: form_helper
INFO - 2021-12-15 01:20:21 --> Helper loaded: common_helper
INFO - 2021-12-15 01:20:21 --> Database Driver Class Initialized
DEBUG - 2021-12-15 01:20:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 01:20:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 01:20:21 --> Controller Class Initialized
INFO - 2021-12-15 01:20:21 --> Form Validation Class Initialized
INFO - 2021-12-15 01:20:21 --> Model "Case_model" initialized
INFO - 2021-12-15 01:20:21 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-15 01:20:21 --> File loaded: /home3/karoteam/public_html/application/views/transaction/donner_donation.php
INFO - 2021-12-15 01:20:21 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-15 01:20:21 --> Final output sent to browser
DEBUG - 2021-12-15 01:20:21 --> Total execution time: 0.0282
ERROR - 2021-12-15 01:20:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 01:20:21 --> Config Class Initialized
INFO - 2021-12-15 01:20:21 --> Hooks Class Initialized
DEBUG - 2021-12-15 01:20:21 --> UTF-8 Support Enabled
INFO - 2021-12-15 01:20:21 --> Utf8 Class Initialized
INFO - 2021-12-15 01:20:21 --> URI Class Initialized
INFO - 2021-12-15 01:20:21 --> Router Class Initialized
INFO - 2021-12-15 01:20:21 --> Output Class Initialized
INFO - 2021-12-15 01:20:21 --> Security Class Initialized
DEBUG - 2021-12-15 01:20:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 01:20:21 --> Input Class Initialized
INFO - 2021-12-15 01:20:21 --> Language Class Initialized
ERROR - 2021-12-15 01:20:21 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-12-15 02:33:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 02:33:51 --> Config Class Initialized
INFO - 2021-12-15 02:33:51 --> Hooks Class Initialized
DEBUG - 2021-12-15 02:33:51 --> UTF-8 Support Enabled
INFO - 2021-12-15 02:33:51 --> Utf8 Class Initialized
INFO - 2021-12-15 02:33:51 --> URI Class Initialized
INFO - 2021-12-15 02:33:51 --> Router Class Initialized
INFO - 2021-12-15 02:33:51 --> Output Class Initialized
INFO - 2021-12-15 02:33:51 --> Security Class Initialized
DEBUG - 2021-12-15 02:33:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 02:33:51 --> Input Class Initialized
INFO - 2021-12-15 02:33:51 --> Language Class Initialized
INFO - 2021-12-15 02:33:51 --> Loader Class Initialized
INFO - 2021-12-15 02:33:51 --> Helper loaded: url_helper
INFO - 2021-12-15 02:33:51 --> Helper loaded: form_helper
INFO - 2021-12-15 02:33:51 --> Helper loaded: common_helper
INFO - 2021-12-15 02:33:51 --> Database Driver Class Initialized
DEBUG - 2021-12-15 02:33:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 02:33:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 02:33:51 --> Controller Class Initialized
INFO - 2021-12-15 02:33:51 --> Form Validation Class Initialized
DEBUG - 2021-12-15 02:33:51 --> Encrypt Class Initialized
INFO - 2021-12-15 02:33:51 --> Model "Login_model" initialized
INFO - 2021-12-15 02:33:51 --> Model "Dashboard_model" initialized
INFO - 2021-12-15 02:33:51 --> Model "Case_model" initialized
INFO - 2021-12-15 02:33:59 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-15 02:34:08 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2021-12-15 02:34:08 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-15 02:34:08 --> Final output sent to browser
DEBUG - 2021-12-15 02:34:08 --> Total execution time: 17.8695
ERROR - 2021-12-15 02:34:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 02:34:11 --> Config Class Initialized
INFO - 2021-12-15 02:34:11 --> Hooks Class Initialized
DEBUG - 2021-12-15 02:34:11 --> UTF-8 Support Enabled
INFO - 2021-12-15 02:34:11 --> Utf8 Class Initialized
INFO - 2021-12-15 02:34:11 --> URI Class Initialized
INFO - 2021-12-15 02:34:11 --> Router Class Initialized
INFO - 2021-12-15 02:34:11 --> Output Class Initialized
INFO - 2021-12-15 02:34:11 --> Security Class Initialized
DEBUG - 2021-12-15 02:34:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 02:34:11 --> Input Class Initialized
INFO - 2021-12-15 02:34:11 --> Language Class Initialized
ERROR - 2021-12-15 02:34:11 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-12-15 04:48:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 04:48:27 --> Config Class Initialized
INFO - 2021-12-15 04:48:27 --> Hooks Class Initialized
DEBUG - 2021-12-15 04:48:27 --> UTF-8 Support Enabled
INFO - 2021-12-15 04:48:27 --> Utf8 Class Initialized
INFO - 2021-12-15 04:48:27 --> URI Class Initialized
DEBUG - 2021-12-15 04:48:27 --> No URI present. Default controller set.
INFO - 2021-12-15 04:48:27 --> Router Class Initialized
INFO - 2021-12-15 04:48:27 --> Output Class Initialized
INFO - 2021-12-15 04:48:27 --> Security Class Initialized
DEBUG - 2021-12-15 04:48:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 04:48:27 --> Input Class Initialized
INFO - 2021-12-15 04:48:27 --> Language Class Initialized
INFO - 2021-12-15 04:48:27 --> Loader Class Initialized
INFO - 2021-12-15 04:48:27 --> Helper loaded: url_helper
INFO - 2021-12-15 04:48:27 --> Helper loaded: form_helper
INFO - 2021-12-15 04:48:27 --> Helper loaded: common_helper
INFO - 2021-12-15 04:48:27 --> Database Driver Class Initialized
DEBUG - 2021-12-15 04:48:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 04:48:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 04:48:27 --> Controller Class Initialized
INFO - 2021-12-15 04:48:27 --> Form Validation Class Initialized
DEBUG - 2021-12-15 04:48:27 --> Encrypt Class Initialized
DEBUG - 2021-12-15 04:48:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-15 04:48:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-15 04:48:27 --> Email Class Initialized
INFO - 2021-12-15 04:48:27 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-15 04:48:27 --> Calendar Class Initialized
INFO - 2021-12-15 04:48:27 --> Model "Login_model" initialized
INFO - 2021-12-15 04:48:27 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-15 04:48:27 --> Final output sent to browser
DEBUG - 2021-12-15 04:48:27 --> Total execution time: 0.0273
ERROR - 2021-12-15 04:48:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 04:48:33 --> Config Class Initialized
INFO - 2021-12-15 04:48:33 --> Hooks Class Initialized
DEBUG - 2021-12-15 04:48:33 --> UTF-8 Support Enabled
INFO - 2021-12-15 04:48:33 --> Utf8 Class Initialized
INFO - 2021-12-15 04:48:33 --> URI Class Initialized
DEBUG - 2021-12-15 04:48:33 --> No URI present. Default controller set.
INFO - 2021-12-15 04:48:33 --> Router Class Initialized
INFO - 2021-12-15 04:48:33 --> Output Class Initialized
INFO - 2021-12-15 04:48:33 --> Security Class Initialized
DEBUG - 2021-12-15 04:48:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 04:48:33 --> Input Class Initialized
INFO - 2021-12-15 04:48:33 --> Language Class Initialized
INFO - 2021-12-15 04:48:33 --> Loader Class Initialized
INFO - 2021-12-15 04:48:33 --> Helper loaded: url_helper
INFO - 2021-12-15 04:48:33 --> Helper loaded: form_helper
INFO - 2021-12-15 04:48:33 --> Helper loaded: common_helper
INFO - 2021-12-15 04:48:33 --> Database Driver Class Initialized
DEBUG - 2021-12-15 04:48:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 04:48:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 04:48:33 --> Controller Class Initialized
INFO - 2021-12-15 04:48:33 --> Form Validation Class Initialized
DEBUG - 2021-12-15 04:48:33 --> Encrypt Class Initialized
DEBUG - 2021-12-15 04:48:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-15 04:48:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-15 04:48:33 --> Email Class Initialized
INFO - 2021-12-15 04:48:33 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-15 04:48:33 --> Calendar Class Initialized
INFO - 2021-12-15 04:48:33 --> Model "Login_model" initialized
INFO - 2021-12-15 04:48:33 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-15 04:48:33 --> Final output sent to browser
DEBUG - 2021-12-15 04:48:33 --> Total execution time: 0.0335
ERROR - 2021-12-15 04:52:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 04:52:05 --> Config Class Initialized
INFO - 2021-12-15 04:52:05 --> Hooks Class Initialized
DEBUG - 2021-12-15 04:52:05 --> UTF-8 Support Enabled
INFO - 2021-12-15 04:52:05 --> Utf8 Class Initialized
INFO - 2021-12-15 04:52:05 --> URI Class Initialized
DEBUG - 2021-12-15 04:52:05 --> No URI present. Default controller set.
INFO - 2021-12-15 04:52:05 --> Router Class Initialized
INFO - 2021-12-15 04:52:05 --> Output Class Initialized
INFO - 2021-12-15 04:52:05 --> Security Class Initialized
DEBUG - 2021-12-15 04:52:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 04:52:05 --> Input Class Initialized
INFO - 2021-12-15 04:52:05 --> Language Class Initialized
INFO - 2021-12-15 04:52:05 --> Loader Class Initialized
INFO - 2021-12-15 04:52:05 --> Helper loaded: url_helper
INFO - 2021-12-15 04:52:05 --> Helper loaded: form_helper
INFO - 2021-12-15 04:52:05 --> Helper loaded: common_helper
INFO - 2021-12-15 04:52:05 --> Database Driver Class Initialized
DEBUG - 2021-12-15 04:52:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 04:52:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 04:52:05 --> Controller Class Initialized
INFO - 2021-12-15 04:52:05 --> Form Validation Class Initialized
DEBUG - 2021-12-15 04:52:05 --> Encrypt Class Initialized
DEBUG - 2021-12-15 04:52:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-15 04:52:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-15 04:52:05 --> Email Class Initialized
INFO - 2021-12-15 04:52:05 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-15 04:52:05 --> Calendar Class Initialized
INFO - 2021-12-15 04:52:05 --> Model "Login_model" initialized
INFO - 2021-12-15 04:52:05 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-15 04:52:05 --> Final output sent to browser
DEBUG - 2021-12-15 04:52:05 --> Total execution time: 0.0247
ERROR - 2021-12-15 06:11:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 06:11:02 --> Config Class Initialized
INFO - 2021-12-15 06:11:02 --> Hooks Class Initialized
DEBUG - 2021-12-15 06:11:02 --> UTF-8 Support Enabled
INFO - 2021-12-15 06:11:02 --> Utf8 Class Initialized
INFO - 2021-12-15 06:11:02 --> URI Class Initialized
DEBUG - 2021-12-15 06:11:02 --> No URI present. Default controller set.
INFO - 2021-12-15 06:11:02 --> Router Class Initialized
INFO - 2021-12-15 06:11:02 --> Output Class Initialized
INFO - 2021-12-15 06:11:02 --> Security Class Initialized
DEBUG - 2021-12-15 06:11:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 06:11:02 --> Input Class Initialized
INFO - 2021-12-15 06:11:02 --> Language Class Initialized
INFO - 2021-12-15 06:11:02 --> Loader Class Initialized
INFO - 2021-12-15 06:11:02 --> Helper loaded: url_helper
INFO - 2021-12-15 06:11:02 --> Helper loaded: form_helper
INFO - 2021-12-15 06:11:02 --> Helper loaded: common_helper
INFO - 2021-12-15 06:11:02 --> Database Driver Class Initialized
DEBUG - 2021-12-15 06:11:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 06:11:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 06:11:02 --> Controller Class Initialized
INFO - 2021-12-15 06:11:02 --> Form Validation Class Initialized
DEBUG - 2021-12-15 06:11:02 --> Encrypt Class Initialized
DEBUG - 2021-12-15 06:11:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-15 06:11:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-15 06:11:02 --> Email Class Initialized
INFO - 2021-12-15 06:11:02 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-15 06:11:02 --> Calendar Class Initialized
INFO - 2021-12-15 06:11:02 --> Model "Login_model" initialized
INFO - 2021-12-15 06:11:02 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-15 06:11:02 --> Final output sent to browser
DEBUG - 2021-12-15 06:11:02 --> Total execution time: 0.0315
ERROR - 2021-12-15 06:16:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 06:16:32 --> Config Class Initialized
INFO - 2021-12-15 06:16:32 --> Hooks Class Initialized
DEBUG - 2021-12-15 06:16:32 --> UTF-8 Support Enabled
INFO - 2021-12-15 06:16:32 --> Utf8 Class Initialized
INFO - 2021-12-15 06:16:32 --> URI Class Initialized
DEBUG - 2021-12-15 06:16:32 --> No URI present. Default controller set.
INFO - 2021-12-15 06:16:32 --> Router Class Initialized
INFO - 2021-12-15 06:16:32 --> Output Class Initialized
INFO - 2021-12-15 06:16:32 --> Security Class Initialized
DEBUG - 2021-12-15 06:16:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 06:16:32 --> Input Class Initialized
INFO - 2021-12-15 06:16:32 --> Language Class Initialized
INFO - 2021-12-15 06:16:32 --> Loader Class Initialized
INFO - 2021-12-15 06:16:32 --> Helper loaded: url_helper
INFO - 2021-12-15 06:16:32 --> Helper loaded: form_helper
INFO - 2021-12-15 06:16:32 --> Helper loaded: common_helper
INFO - 2021-12-15 06:16:32 --> Database Driver Class Initialized
DEBUG - 2021-12-15 06:16:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 06:16:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 06:16:32 --> Controller Class Initialized
INFO - 2021-12-15 06:16:32 --> Form Validation Class Initialized
DEBUG - 2021-12-15 06:16:32 --> Encrypt Class Initialized
DEBUG - 2021-12-15 06:16:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-15 06:16:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-15 06:16:32 --> Email Class Initialized
INFO - 2021-12-15 06:16:32 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-15 06:16:32 --> Calendar Class Initialized
INFO - 2021-12-15 06:16:32 --> Model "Login_model" initialized
INFO - 2021-12-15 06:16:32 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-15 06:16:32 --> Final output sent to browser
DEBUG - 2021-12-15 06:16:32 --> Total execution time: 0.0264
ERROR - 2021-12-15 06:24:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 06:24:15 --> Config Class Initialized
INFO - 2021-12-15 06:24:15 --> Hooks Class Initialized
DEBUG - 2021-12-15 06:24:15 --> UTF-8 Support Enabled
INFO - 2021-12-15 06:24:15 --> Utf8 Class Initialized
INFO - 2021-12-15 06:24:15 --> URI Class Initialized
DEBUG - 2021-12-15 06:24:15 --> No URI present. Default controller set.
INFO - 2021-12-15 06:24:15 --> Router Class Initialized
INFO - 2021-12-15 06:24:15 --> Output Class Initialized
INFO - 2021-12-15 06:24:15 --> Security Class Initialized
DEBUG - 2021-12-15 06:24:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 06:24:15 --> Input Class Initialized
INFO - 2021-12-15 06:24:15 --> Language Class Initialized
INFO - 2021-12-15 06:24:15 --> Loader Class Initialized
INFO - 2021-12-15 06:24:15 --> Helper loaded: url_helper
INFO - 2021-12-15 06:24:15 --> Helper loaded: form_helper
INFO - 2021-12-15 06:24:15 --> Helper loaded: common_helper
INFO - 2021-12-15 06:24:15 --> Database Driver Class Initialized
DEBUG - 2021-12-15 06:24:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 06:24:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 06:24:15 --> Controller Class Initialized
INFO - 2021-12-15 06:24:15 --> Form Validation Class Initialized
DEBUG - 2021-12-15 06:24:15 --> Encrypt Class Initialized
DEBUG - 2021-12-15 06:24:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-15 06:24:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-15 06:24:15 --> Email Class Initialized
INFO - 2021-12-15 06:24:15 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-15 06:24:15 --> Calendar Class Initialized
INFO - 2021-12-15 06:24:15 --> Model "Login_model" initialized
INFO - 2021-12-15 06:24:15 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-15 06:24:15 --> Final output sent to browser
DEBUG - 2021-12-15 06:24:15 --> Total execution time: 0.0339
ERROR - 2021-12-15 06:24:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 06:24:20 --> Config Class Initialized
INFO - 2021-12-15 06:24:20 --> Hooks Class Initialized
DEBUG - 2021-12-15 06:24:20 --> UTF-8 Support Enabled
INFO - 2021-12-15 06:24:20 --> Utf8 Class Initialized
INFO - 2021-12-15 06:24:20 --> URI Class Initialized
INFO - 2021-12-15 06:24:20 --> Router Class Initialized
INFO - 2021-12-15 06:24:20 --> Output Class Initialized
INFO - 2021-12-15 06:24:20 --> Security Class Initialized
DEBUG - 2021-12-15 06:24:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 06:24:20 --> Input Class Initialized
INFO - 2021-12-15 06:24:20 --> Language Class Initialized
INFO - 2021-12-15 06:24:20 --> Loader Class Initialized
INFO - 2021-12-15 06:24:20 --> Helper loaded: url_helper
INFO - 2021-12-15 06:24:20 --> Helper loaded: form_helper
INFO - 2021-12-15 06:24:20 --> Helper loaded: common_helper
INFO - 2021-12-15 06:24:20 --> Database Driver Class Initialized
DEBUG - 2021-12-15 06:24:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 06:24:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 06:24:20 --> Controller Class Initialized
INFO - 2021-12-15 06:24:20 --> Form Validation Class Initialized
DEBUG - 2021-12-15 06:24:20 --> Encrypt Class Initialized
DEBUG - 2021-12-15 06:24:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-15 06:24:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-15 06:24:20 --> Email Class Initialized
INFO - 2021-12-15 06:24:20 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-15 06:24:20 --> Calendar Class Initialized
INFO - 2021-12-15 06:24:20 --> Model "Login_model" initialized
INFO - 2021-12-15 06:24:20 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2021-12-15 06:24:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 06:24:21 --> Config Class Initialized
INFO - 2021-12-15 06:24:21 --> Hooks Class Initialized
DEBUG - 2021-12-15 06:24:21 --> UTF-8 Support Enabled
INFO - 2021-12-15 06:24:21 --> Utf8 Class Initialized
INFO - 2021-12-15 06:24:21 --> URI Class Initialized
INFO - 2021-12-15 06:24:21 --> Router Class Initialized
INFO - 2021-12-15 06:24:21 --> Output Class Initialized
INFO - 2021-12-15 06:24:21 --> Security Class Initialized
DEBUG - 2021-12-15 06:24:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 06:24:21 --> Input Class Initialized
INFO - 2021-12-15 06:24:21 --> Language Class Initialized
INFO - 2021-12-15 06:24:21 --> Loader Class Initialized
INFO - 2021-12-15 06:24:21 --> Helper loaded: url_helper
INFO - 2021-12-15 06:24:21 --> Helper loaded: form_helper
INFO - 2021-12-15 06:24:21 --> Helper loaded: common_helper
INFO - 2021-12-15 06:24:21 --> Database Driver Class Initialized
DEBUG - 2021-12-15 06:24:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 06:24:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 06:24:21 --> Controller Class Initialized
INFO - 2021-12-15 06:24:21 --> Form Validation Class Initialized
DEBUG - 2021-12-15 06:24:21 --> Encrypt Class Initialized
INFO - 2021-12-15 06:24:21 --> Model "Login_model" initialized
INFO - 2021-12-15 06:24:21 --> Model "Dashboard_model" initialized
INFO - 2021-12-15 06:24:21 --> Model "Case_model" initialized
INFO - 2021-12-15 06:24:33 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-15 06:24:44 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2021-12-15 06:24:44 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-15 06:24:44 --> Final output sent to browser
DEBUG - 2021-12-15 06:24:44 --> Total execution time: 22.5394
ERROR - 2021-12-15 06:24:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 06:24:45 --> Config Class Initialized
INFO - 2021-12-15 06:24:45 --> Hooks Class Initialized
DEBUG - 2021-12-15 06:24:45 --> UTF-8 Support Enabled
INFO - 2021-12-15 06:24:45 --> Utf8 Class Initialized
INFO - 2021-12-15 06:24:45 --> URI Class Initialized
INFO - 2021-12-15 06:24:45 --> Router Class Initialized
INFO - 2021-12-15 06:24:45 --> Output Class Initialized
INFO - 2021-12-15 06:24:45 --> Security Class Initialized
DEBUG - 2021-12-15 06:24:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 06:24:45 --> Input Class Initialized
INFO - 2021-12-15 06:24:45 --> Language Class Initialized
ERROR - 2021-12-15 06:24:45 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-12-15 06:26:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 06:26:21 --> Config Class Initialized
INFO - 2021-12-15 06:26:21 --> Hooks Class Initialized
DEBUG - 2021-12-15 06:26:21 --> UTF-8 Support Enabled
INFO - 2021-12-15 06:26:21 --> Utf8 Class Initialized
INFO - 2021-12-15 06:26:21 --> URI Class Initialized
INFO - 2021-12-15 06:26:21 --> Router Class Initialized
INFO - 2021-12-15 06:26:21 --> Output Class Initialized
INFO - 2021-12-15 06:26:21 --> Security Class Initialized
DEBUG - 2021-12-15 06:26:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 06:26:21 --> Input Class Initialized
INFO - 2021-12-15 06:26:21 --> Language Class Initialized
INFO - 2021-12-15 06:26:21 --> Loader Class Initialized
INFO - 2021-12-15 06:26:21 --> Helper loaded: url_helper
INFO - 2021-12-15 06:26:21 --> Helper loaded: form_helper
INFO - 2021-12-15 06:26:21 --> Helper loaded: common_helper
INFO - 2021-12-15 06:26:21 --> Database Driver Class Initialized
DEBUG - 2021-12-15 06:26:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 06:26:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 06:26:21 --> Controller Class Initialized
INFO - 2021-12-15 06:26:21 --> Form Validation Class Initialized
DEBUG - 2021-12-15 06:26:21 --> Encrypt Class Initialized
INFO - 2021-12-15 06:26:21 --> Model "Login_model" initialized
INFO - 2021-12-15 06:26:21 --> Model "Dashboard_model" initialized
INFO - 2021-12-15 06:26:21 --> Model "Case_model" initialized
ERROR - 2021-12-15 06:26:21 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'GROUP BY  CALCULATEAGE(YEAR(patient_dob))
     
     UNION 
     
  SELECT calcu' at line 7 - Invalid query: SELECT SUM(TotalPatient) as TotalPatient ,AgeGroup
FROM
( 
SELECT CALCULATEAGE(YEAR(patient_dob)) AS AgeGroup, COUNT(CALCULATEAGE(YEAR(patient_dob)))  AS TotalPatient FROM patient_master
       
    WHERE  IFNULL(`status`,0)!= '1' AND patient_dob IS NOT NULL AND patient_dob != '0000-00-00'  AND patient_master.created_by = 
     GROUP BY  CALCULATEAGE(YEAR(patient_dob))
     
     UNION 
     
  SELECT calculateWithoutDOBAge(SUBSTRING(patient_age,1,2)) AS AgeGroup, COUNT(calculateWithoutDOBAge(SUBSTRING(patient_age,1,2))) AS 
  TotalPatient FROM patient_master WHERE IFNULL(`status`,0)!= '1' AND IFNULL(patient_dob,'')='0000-00-00'  AND IFNULL(patient_age,'')!=''  AND patient_master.created_by = 
        GROUP BY calculateWithoutDOBAge(SUBSTRING(patient_age,1,2))
        )B GROUP BY AgeGroup
INFO - 2021-12-15 06:26:21 --> Language file loaded: language/english/db_lang.php
ERROR - 2021-12-15 06:27:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 06:27:49 --> Config Class Initialized
INFO - 2021-12-15 06:27:49 --> Hooks Class Initialized
DEBUG - 2021-12-15 06:27:49 --> UTF-8 Support Enabled
INFO - 2021-12-15 06:27:49 --> Utf8 Class Initialized
INFO - 2021-12-15 06:27:49 --> URI Class Initialized
INFO - 2021-12-15 06:27:49 --> Router Class Initialized
INFO - 2021-12-15 06:27:49 --> Output Class Initialized
INFO - 2021-12-15 06:27:49 --> Security Class Initialized
DEBUG - 2021-12-15 06:27:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 06:27:49 --> Input Class Initialized
INFO - 2021-12-15 06:27:49 --> Language Class Initialized
INFO - 2021-12-15 06:27:49 --> Loader Class Initialized
INFO - 2021-12-15 06:27:49 --> Helper loaded: url_helper
INFO - 2021-12-15 06:27:49 --> Helper loaded: form_helper
INFO - 2021-12-15 06:27:49 --> Helper loaded: common_helper
INFO - 2021-12-15 06:27:49 --> Database Driver Class Initialized
DEBUG - 2021-12-15 06:27:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 06:27:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 06:27:49 --> Controller Class Initialized
INFO - 2021-12-15 06:27:49 --> Form Validation Class Initialized
DEBUG - 2021-12-15 06:27:49 --> Encrypt Class Initialized
INFO - 2021-12-15 06:27:49 --> Model "Patient_model" initialized
INFO - 2021-12-15 06:27:49 --> Model "Patientcase_model" initialized
INFO - 2021-12-15 06:27:49 --> Model "Prefix_master" initialized
INFO - 2021-12-15 06:27:49 --> Model "Users_model" initialized
INFO - 2021-12-15 06:27:49 --> Model "Hospital_model" initialized
INFO - 2021-12-15 06:27:49 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-15 06:27:49 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2021-12-15 06:27:49 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-15 06:27:49 --> Final output sent to browser
DEBUG - 2021-12-15 06:27:49 --> Total execution time: 0.3250
ERROR - 2021-12-15 06:27:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 06:27:50 --> Config Class Initialized
INFO - 2021-12-15 06:27:50 --> Hooks Class Initialized
DEBUG - 2021-12-15 06:27:50 --> UTF-8 Support Enabled
INFO - 2021-12-15 06:27:50 --> Utf8 Class Initialized
INFO - 2021-12-15 06:27:50 --> URI Class Initialized
INFO - 2021-12-15 06:27:50 --> Router Class Initialized
INFO - 2021-12-15 06:27:50 --> Output Class Initialized
INFO - 2021-12-15 06:27:50 --> Security Class Initialized
DEBUG - 2021-12-15 06:27:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 06:27:50 --> Input Class Initialized
INFO - 2021-12-15 06:27:50 --> Language Class Initialized
ERROR - 2021-12-15 06:27:50 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-12-15 06:28:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 06:28:46 --> Config Class Initialized
INFO - 2021-12-15 06:28:46 --> Hooks Class Initialized
DEBUG - 2021-12-15 06:28:46 --> UTF-8 Support Enabled
INFO - 2021-12-15 06:28:46 --> Utf8 Class Initialized
INFO - 2021-12-15 06:28:46 --> URI Class Initialized
INFO - 2021-12-15 06:28:46 --> Router Class Initialized
INFO - 2021-12-15 06:28:46 --> Output Class Initialized
INFO - 2021-12-15 06:28:46 --> Security Class Initialized
DEBUG - 2021-12-15 06:28:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 06:28:46 --> Input Class Initialized
INFO - 2021-12-15 06:28:46 --> Language Class Initialized
INFO - 2021-12-15 06:28:46 --> Loader Class Initialized
INFO - 2021-12-15 06:28:46 --> Helper loaded: url_helper
INFO - 2021-12-15 06:28:46 --> Helper loaded: form_helper
INFO - 2021-12-15 06:28:46 --> Helper loaded: common_helper
INFO - 2021-12-15 06:28:46 --> Database Driver Class Initialized
DEBUG - 2021-12-15 06:28:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 06:28:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 06:28:46 --> Controller Class Initialized
INFO - 2021-12-15 06:28:46 --> Form Validation Class Initialized
DEBUG - 2021-12-15 06:28:46 --> Encrypt Class Initialized
INFO - 2021-12-15 06:28:46 --> Model "Login_model" initialized
INFO - 2021-12-15 06:28:46 --> Model "Dashboard_model" initialized
INFO - 2021-12-15 06:28:46 --> Model "Case_model" initialized
INFO - 2021-12-15 06:28:54 --> File loaded: /home3/karoteam/public_html/application/views/header.php
ERROR - 2021-12-15 06:29:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 06:29:00 --> Config Class Initialized
INFO - 2021-12-15 06:29:00 --> Hooks Class Initialized
DEBUG - 2021-12-15 06:29:00 --> UTF-8 Support Enabled
INFO - 2021-12-15 06:29:00 --> Utf8 Class Initialized
INFO - 2021-12-15 06:29:00 --> URI Class Initialized
INFO - 2021-12-15 06:29:00 --> Router Class Initialized
INFO - 2021-12-15 06:29:00 --> Output Class Initialized
INFO - 2021-12-15 06:29:00 --> Security Class Initialized
DEBUG - 2021-12-15 06:29:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 06:29:00 --> Input Class Initialized
INFO - 2021-12-15 06:29:00 --> Language Class Initialized
INFO - 2021-12-15 06:29:00 --> Loader Class Initialized
INFO - 2021-12-15 06:29:00 --> Helper loaded: url_helper
INFO - 2021-12-15 06:29:00 --> Helper loaded: form_helper
INFO - 2021-12-15 06:29:00 --> Helper loaded: common_helper
INFO - 2021-12-15 06:29:00 --> Database Driver Class Initialized
DEBUG - 2021-12-15 06:29:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 06:29:04 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2021-12-15 06:29:04 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-15 06:29:04 --> Final output sent to browser
DEBUG - 2021-12-15 06:29:04 --> Total execution time: 18.3126
INFO - 2021-12-15 06:29:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 06:29:04 --> Controller Class Initialized
INFO - 2021-12-15 06:29:04 --> Form Validation Class Initialized
DEBUG - 2021-12-15 06:29:04 --> Encrypt Class Initialized
INFO - 2021-12-15 06:29:04 --> Model "Login_model" initialized
INFO - 2021-12-15 06:29:04 --> Model "Dashboard_model" initialized
INFO - 2021-12-15 06:29:04 --> Model "Case_model" initialized
INFO - 2021-12-15 06:29:12 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-15 06:29:24 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2021-12-15 06:29:24 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-15 06:29:24 --> Final output sent to browser
DEBUG - 2021-12-15 06:29:24 --> Total execution time: 24.1130
ERROR - 2021-12-15 06:29:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 06:29:24 --> Config Class Initialized
INFO - 2021-12-15 06:29:24 --> Hooks Class Initialized
DEBUG - 2021-12-15 06:29:24 --> UTF-8 Support Enabled
INFO - 2021-12-15 06:29:24 --> Utf8 Class Initialized
INFO - 2021-12-15 06:29:24 --> URI Class Initialized
INFO - 2021-12-15 06:29:24 --> Router Class Initialized
INFO - 2021-12-15 06:29:24 --> Output Class Initialized
INFO - 2021-12-15 06:29:24 --> Security Class Initialized
DEBUG - 2021-12-15 06:29:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 06:29:24 --> Input Class Initialized
INFO - 2021-12-15 06:29:24 --> Language Class Initialized
ERROR - 2021-12-15 06:29:24 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-12-15 06:33:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 06:33:50 --> Config Class Initialized
INFO - 2021-12-15 06:33:50 --> Hooks Class Initialized
DEBUG - 2021-12-15 06:33:50 --> UTF-8 Support Enabled
INFO - 2021-12-15 06:33:50 --> Utf8 Class Initialized
INFO - 2021-12-15 06:33:50 --> URI Class Initialized
INFO - 2021-12-15 06:33:50 --> Router Class Initialized
INFO - 2021-12-15 06:33:50 --> Output Class Initialized
INFO - 2021-12-15 06:33:50 --> Security Class Initialized
DEBUG - 2021-12-15 06:33:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 06:33:50 --> Input Class Initialized
INFO - 2021-12-15 06:33:50 --> Language Class Initialized
INFO - 2021-12-15 06:33:50 --> Loader Class Initialized
INFO - 2021-12-15 06:33:50 --> Helper loaded: url_helper
INFO - 2021-12-15 06:33:50 --> Helper loaded: form_helper
INFO - 2021-12-15 06:33:50 --> Helper loaded: common_helper
INFO - 2021-12-15 06:33:50 --> Database Driver Class Initialized
DEBUG - 2021-12-15 06:33:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 06:33:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 06:33:50 --> Controller Class Initialized
INFO - 2021-12-15 06:33:50 --> Form Validation Class Initialized
INFO - 2021-12-15 06:33:50 --> Model "Case_model" initialized
INFO - 2021-12-15 06:33:50 --> Model "Patientcase_model" initialized
INFO - 2021-12-15 06:33:51 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-15 06:33:51 --> File loaded: /home3/karoteam/public_html/application/views/cases/new_case.php
INFO - 2021-12-15 06:33:51 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-15 06:33:51 --> Final output sent to browser
DEBUG - 2021-12-15 06:33:51 --> Total execution time: 0.6042
ERROR - 2021-12-15 06:33:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 06:33:52 --> Config Class Initialized
INFO - 2021-12-15 06:33:52 --> Hooks Class Initialized
DEBUG - 2021-12-15 06:33:52 --> UTF-8 Support Enabled
INFO - 2021-12-15 06:33:52 --> Utf8 Class Initialized
INFO - 2021-12-15 06:33:52 --> URI Class Initialized
INFO - 2021-12-15 06:33:52 --> Router Class Initialized
INFO - 2021-12-15 06:33:52 --> Output Class Initialized
INFO - 2021-12-15 06:33:52 --> Security Class Initialized
DEBUG - 2021-12-15 06:33:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 06:33:52 --> Input Class Initialized
INFO - 2021-12-15 06:33:52 --> Language Class Initialized
ERROR - 2021-12-15 06:33:52 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-12-15 06:33:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 06:33:59 --> Config Class Initialized
INFO - 2021-12-15 06:33:59 --> Hooks Class Initialized
DEBUG - 2021-12-15 06:33:59 --> UTF-8 Support Enabled
INFO - 2021-12-15 06:33:59 --> Utf8 Class Initialized
INFO - 2021-12-15 06:33:59 --> URI Class Initialized
INFO - 2021-12-15 06:33:59 --> Router Class Initialized
INFO - 2021-12-15 06:33:59 --> Output Class Initialized
INFO - 2021-12-15 06:33:59 --> Security Class Initialized
DEBUG - 2021-12-15 06:33:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 06:33:59 --> Input Class Initialized
INFO - 2021-12-15 06:33:59 --> Language Class Initialized
INFO - 2021-12-15 06:33:59 --> Loader Class Initialized
INFO - 2021-12-15 06:33:59 --> Helper loaded: url_helper
INFO - 2021-12-15 06:33:59 --> Helper loaded: form_helper
INFO - 2021-12-15 06:33:59 --> Helper loaded: common_helper
INFO - 2021-12-15 06:33:59 --> Database Driver Class Initialized
DEBUG - 2021-12-15 06:33:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 06:33:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 06:33:59 --> Controller Class Initialized
INFO - 2021-12-15 06:33:59 --> Form Validation Class Initialized
DEBUG - 2021-12-15 06:33:59 --> Encrypt Class Initialized
INFO - 2021-12-15 06:33:59 --> Model "Login_model" initialized
INFO - 2021-12-15 06:33:59 --> Model "Dashboard_model" initialized
INFO - 2021-12-15 06:33:59 --> Model "Case_model" initialized
INFO - 2021-12-15 06:34:06 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-15 06:34:16 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2021-12-15 06:34:16 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-15 06:34:16 --> Final output sent to browser
DEBUG - 2021-12-15 06:34:16 --> Total execution time: 17.1561
ERROR - 2021-12-15 06:34:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 06:34:17 --> Config Class Initialized
INFO - 2021-12-15 06:34:17 --> Hooks Class Initialized
DEBUG - 2021-12-15 06:34:17 --> UTF-8 Support Enabled
INFO - 2021-12-15 06:34:17 --> Utf8 Class Initialized
INFO - 2021-12-15 06:34:17 --> URI Class Initialized
INFO - 2021-12-15 06:34:17 --> Router Class Initialized
INFO - 2021-12-15 06:34:17 --> Output Class Initialized
INFO - 2021-12-15 06:34:17 --> Security Class Initialized
DEBUG - 2021-12-15 06:34:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 06:34:17 --> Input Class Initialized
INFO - 2021-12-15 06:34:17 --> Language Class Initialized
ERROR - 2021-12-15 06:34:17 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-12-15 06:34:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 06:34:20 --> Config Class Initialized
INFO - 2021-12-15 06:34:20 --> Hooks Class Initialized
DEBUG - 2021-12-15 06:34:20 --> UTF-8 Support Enabled
INFO - 2021-12-15 06:34:20 --> Utf8 Class Initialized
INFO - 2021-12-15 06:34:20 --> URI Class Initialized
INFO - 2021-12-15 06:34:20 --> Router Class Initialized
INFO - 2021-12-15 06:34:20 --> Output Class Initialized
INFO - 2021-12-15 06:34:20 --> Security Class Initialized
DEBUG - 2021-12-15 06:34:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 06:34:20 --> Input Class Initialized
INFO - 2021-12-15 06:34:20 --> Language Class Initialized
INFO - 2021-12-15 06:34:20 --> Loader Class Initialized
INFO - 2021-12-15 06:34:20 --> Helper loaded: url_helper
INFO - 2021-12-15 06:34:20 --> Helper loaded: form_helper
INFO - 2021-12-15 06:34:20 --> Helper loaded: common_helper
INFO - 2021-12-15 06:34:20 --> Database Driver Class Initialized
DEBUG - 2021-12-15 06:34:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 06:34:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 06:34:20 --> Controller Class Initialized
INFO - 2021-12-15 06:34:20 --> Form Validation Class Initialized
INFO - 2021-12-15 06:34:20 --> Model "Report_model" initialized
INFO - 2021-12-15 06:34:20 --> Model "Case_model" initialized
INFO - 2021-12-15 06:34:20 --> Model "Hospital_model" initialized
INFO - 2021-12-15 06:34:20 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-15 06:34:20 --> File loaded: /home3/karoteam/public_html/application/views/reports/patientwise_finacial_details.php
INFO - 2021-12-15 06:34:20 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-15 06:34:20 --> Final output sent to browser
DEBUG - 2021-12-15 06:34:20 --> Total execution time: 0.0296
ERROR - 2021-12-15 06:34:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 06:34:20 --> Config Class Initialized
INFO - 2021-12-15 06:34:20 --> Hooks Class Initialized
DEBUG - 2021-12-15 06:34:20 --> UTF-8 Support Enabled
INFO - 2021-12-15 06:34:20 --> Utf8 Class Initialized
INFO - 2021-12-15 06:34:20 --> URI Class Initialized
INFO - 2021-12-15 06:34:20 --> Router Class Initialized
INFO - 2021-12-15 06:34:20 --> Output Class Initialized
INFO - 2021-12-15 06:34:20 --> Security Class Initialized
DEBUG - 2021-12-15 06:34:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 06:34:20 --> Input Class Initialized
INFO - 2021-12-15 06:34:20 --> Language Class Initialized
ERROR - 2021-12-15 06:34:20 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-12-15 06:34:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 06:34:31 --> Config Class Initialized
INFO - 2021-12-15 06:34:31 --> Hooks Class Initialized
DEBUG - 2021-12-15 06:34:31 --> UTF-8 Support Enabled
INFO - 2021-12-15 06:34:31 --> Utf8 Class Initialized
INFO - 2021-12-15 06:34:31 --> URI Class Initialized
INFO - 2021-12-15 06:34:31 --> Router Class Initialized
INFO - 2021-12-15 06:34:31 --> Output Class Initialized
INFO - 2021-12-15 06:34:31 --> Security Class Initialized
DEBUG - 2021-12-15 06:34:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 06:34:31 --> Input Class Initialized
INFO - 2021-12-15 06:34:31 --> Language Class Initialized
INFO - 2021-12-15 06:34:31 --> Loader Class Initialized
INFO - 2021-12-15 06:34:31 --> Helper loaded: url_helper
INFO - 2021-12-15 06:34:31 --> Helper loaded: form_helper
INFO - 2021-12-15 06:34:31 --> Helper loaded: common_helper
INFO - 2021-12-15 06:34:31 --> Database Driver Class Initialized
DEBUG - 2021-12-15 06:34:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 06:34:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 06:34:31 --> Controller Class Initialized
INFO - 2021-12-15 06:34:31 --> Form Validation Class Initialized
DEBUG - 2021-12-15 06:34:31 --> Encrypt Class Initialized
INFO - 2021-12-15 06:34:31 --> Model "Login_model" initialized
INFO - 2021-12-15 06:34:31 --> Model "Dashboard_model" initialized
INFO - 2021-12-15 06:34:31 --> Model "Case_model" initialized
ERROR - 2021-12-15 06:34:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 06:34:38 --> Config Class Initialized
INFO - 2021-12-15 06:34:38 --> Hooks Class Initialized
DEBUG - 2021-12-15 06:34:38 --> UTF-8 Support Enabled
INFO - 2021-12-15 06:34:38 --> Utf8 Class Initialized
INFO - 2021-12-15 06:34:38 --> URI Class Initialized
INFO - 2021-12-15 06:34:38 --> Router Class Initialized
INFO - 2021-12-15 06:34:38 --> Output Class Initialized
INFO - 2021-12-15 06:34:38 --> Security Class Initialized
DEBUG - 2021-12-15 06:34:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 06:34:38 --> Input Class Initialized
INFO - 2021-12-15 06:34:38 --> Language Class Initialized
INFO - 2021-12-15 06:34:38 --> Loader Class Initialized
INFO - 2021-12-15 06:34:38 --> Helper loaded: url_helper
INFO - 2021-12-15 06:34:38 --> Helper loaded: form_helper
INFO - 2021-12-15 06:34:38 --> Helper loaded: common_helper
INFO - 2021-12-15 06:34:38 --> Database Driver Class Initialized
DEBUG - 2021-12-15 06:34:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 06:34:38 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-15 06:34:48 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2021-12-15 06:34:48 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-15 06:34:48 --> Final output sent to browser
DEBUG - 2021-12-15 06:34:48 --> Total execution time: 17.6839
INFO - 2021-12-15 06:34:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 06:34:48 --> Controller Class Initialized
INFO - 2021-12-15 06:34:48 --> Form Validation Class Initialized
DEBUG - 2021-12-15 06:34:48 --> Encrypt Class Initialized
INFO - 2021-12-15 06:34:48 --> Model "Login_model" initialized
INFO - 2021-12-15 06:34:48 --> Model "Dashboard_model" initialized
INFO - 2021-12-15 06:34:48 --> Model "Case_model" initialized
INFO - 2021-12-15 06:34:57 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-15 06:35:07 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2021-12-15 06:35:07 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-15 06:35:07 --> Final output sent to browser
DEBUG - 2021-12-15 06:35:07 --> Total execution time: 28.8384
ERROR - 2021-12-15 06:35:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 06:35:08 --> Config Class Initialized
INFO - 2021-12-15 06:35:08 --> Hooks Class Initialized
DEBUG - 2021-12-15 06:35:08 --> UTF-8 Support Enabled
INFO - 2021-12-15 06:35:08 --> Utf8 Class Initialized
INFO - 2021-12-15 06:35:08 --> URI Class Initialized
INFO - 2021-12-15 06:35:08 --> Router Class Initialized
INFO - 2021-12-15 06:35:08 --> Output Class Initialized
INFO - 2021-12-15 06:35:08 --> Security Class Initialized
DEBUG - 2021-12-15 06:35:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 06:35:08 --> Input Class Initialized
INFO - 2021-12-15 06:35:08 --> Language Class Initialized
ERROR - 2021-12-15 06:35:08 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-12-15 06:35:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 06:35:42 --> Config Class Initialized
INFO - 2021-12-15 06:35:42 --> Hooks Class Initialized
DEBUG - 2021-12-15 06:35:42 --> UTF-8 Support Enabled
INFO - 2021-12-15 06:35:42 --> Utf8 Class Initialized
INFO - 2021-12-15 06:35:42 --> URI Class Initialized
INFO - 2021-12-15 06:35:42 --> Router Class Initialized
INFO - 2021-12-15 06:35:42 --> Output Class Initialized
INFO - 2021-12-15 06:35:42 --> Security Class Initialized
DEBUG - 2021-12-15 06:35:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 06:35:42 --> Input Class Initialized
INFO - 2021-12-15 06:35:42 --> Language Class Initialized
INFO - 2021-12-15 06:35:42 --> Loader Class Initialized
INFO - 2021-12-15 06:35:42 --> Helper loaded: url_helper
INFO - 2021-12-15 06:35:42 --> Helper loaded: form_helper
INFO - 2021-12-15 06:35:42 --> Helper loaded: common_helper
INFO - 2021-12-15 06:35:42 --> Database Driver Class Initialized
DEBUG - 2021-12-15 06:35:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 06:35:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 06:35:42 --> Controller Class Initialized
INFO - 2021-12-15 06:35:42 --> Form Validation Class Initialized
INFO - 2021-12-15 06:35:42 --> Model "Case_model" initialized
INFO - 2021-12-15 06:35:42 --> Model "Patientcase_model" initialized
INFO - 2021-12-15 06:35:47 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-15 06:35:47 --> Model "Case_model" initialized
INFO - 2021-12-15 06:35:53 --> File loaded: /home3/karoteam/public_html/application/views/cases/all_case.php
INFO - 2021-12-15 06:35:53 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-15 06:35:54 --> Final output sent to browser
DEBUG - 2021-12-15 06:35:54 --> Total execution time: 11.2601
ERROR - 2021-12-15 06:35:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 06:35:55 --> Config Class Initialized
INFO - 2021-12-15 06:35:55 --> Hooks Class Initialized
DEBUG - 2021-12-15 06:35:55 --> UTF-8 Support Enabled
INFO - 2021-12-15 06:35:55 --> Utf8 Class Initialized
INFO - 2021-12-15 06:35:55 --> URI Class Initialized
INFO - 2021-12-15 06:35:55 --> Router Class Initialized
INFO - 2021-12-15 06:35:55 --> Output Class Initialized
INFO - 2021-12-15 06:35:55 --> Security Class Initialized
DEBUG - 2021-12-15 06:35:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 06:35:55 --> Input Class Initialized
INFO - 2021-12-15 06:35:55 --> Language Class Initialized
ERROR - 2021-12-15 06:35:55 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-12-15 14:17:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 14:17:32 --> Config Class Initialized
INFO - 2021-12-15 14:17:32 --> Hooks Class Initialized
DEBUG - 2021-12-15 14:17:32 --> UTF-8 Support Enabled
INFO - 2021-12-15 14:17:32 --> Utf8 Class Initialized
INFO - 2021-12-15 14:17:32 --> URI Class Initialized
DEBUG - 2021-12-15 14:17:32 --> No URI present. Default controller set.
INFO - 2021-12-15 14:17:32 --> Router Class Initialized
INFO - 2021-12-15 14:17:32 --> Output Class Initialized
INFO - 2021-12-15 14:17:32 --> Security Class Initialized
DEBUG - 2021-12-15 14:17:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 14:17:32 --> Input Class Initialized
INFO - 2021-12-15 14:17:32 --> Language Class Initialized
INFO - 2021-12-15 14:17:32 --> Loader Class Initialized
INFO - 2021-12-15 14:17:32 --> Helper loaded: url_helper
INFO - 2021-12-15 14:17:32 --> Helper loaded: form_helper
INFO - 2021-12-15 14:17:32 --> Helper loaded: common_helper
INFO - 2021-12-15 14:17:32 --> Database Driver Class Initialized
DEBUG - 2021-12-15 14:17:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 14:17:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 14:17:32 --> Controller Class Initialized
INFO - 2021-12-15 14:17:32 --> Form Validation Class Initialized
DEBUG - 2021-12-15 14:17:32 --> Encrypt Class Initialized
DEBUG - 2021-12-15 14:17:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-15 14:17:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-15 14:17:32 --> Email Class Initialized
INFO - 2021-12-15 14:17:32 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-15 14:17:32 --> Calendar Class Initialized
INFO - 2021-12-15 14:17:32 --> Model "Login_model" initialized
INFO - 2021-12-15 14:17:32 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-15 14:17:32 --> Final output sent to browser
DEBUG - 2021-12-15 14:17:32 --> Total execution time: 0.0258
ERROR - 2021-12-15 14:17:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 14:17:33 --> Config Class Initialized
INFO - 2021-12-15 14:17:33 --> Hooks Class Initialized
DEBUG - 2021-12-15 14:17:33 --> UTF-8 Support Enabled
INFO - 2021-12-15 14:17:33 --> Utf8 Class Initialized
INFO - 2021-12-15 14:17:33 --> URI Class Initialized
INFO - 2021-12-15 14:17:33 --> Router Class Initialized
INFO - 2021-12-15 14:17:33 --> Output Class Initialized
INFO - 2021-12-15 14:17:33 --> Security Class Initialized
DEBUG - 2021-12-15 14:17:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 14:17:33 --> Input Class Initialized
INFO - 2021-12-15 14:17:33 --> Language Class Initialized
ERROR - 2021-12-15 14:17:33 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2021-12-15 14:17:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 14:17:58 --> Config Class Initialized
INFO - 2021-12-15 14:17:58 --> Hooks Class Initialized
DEBUG - 2021-12-15 14:17:58 --> UTF-8 Support Enabled
INFO - 2021-12-15 14:17:58 --> Utf8 Class Initialized
INFO - 2021-12-15 14:17:58 --> URI Class Initialized
DEBUG - 2021-12-15 14:17:58 --> No URI present. Default controller set.
INFO - 2021-12-15 14:17:58 --> Router Class Initialized
INFO - 2021-12-15 14:17:58 --> Output Class Initialized
INFO - 2021-12-15 14:17:58 --> Security Class Initialized
DEBUG - 2021-12-15 14:17:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 14:17:58 --> Input Class Initialized
INFO - 2021-12-15 14:17:58 --> Language Class Initialized
INFO - 2021-12-15 14:17:58 --> Loader Class Initialized
INFO - 2021-12-15 14:17:58 --> Helper loaded: url_helper
INFO - 2021-12-15 14:17:58 --> Helper loaded: form_helper
INFO - 2021-12-15 14:17:58 --> Helper loaded: common_helper
INFO - 2021-12-15 14:17:58 --> Database Driver Class Initialized
DEBUG - 2021-12-15 14:17:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 14:17:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 14:17:58 --> Controller Class Initialized
INFO - 2021-12-15 14:17:58 --> Form Validation Class Initialized
DEBUG - 2021-12-15 14:17:58 --> Encrypt Class Initialized
DEBUG - 2021-12-15 14:17:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-15 14:17:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-15 14:17:58 --> Email Class Initialized
INFO - 2021-12-15 14:17:58 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-15 14:17:58 --> Calendar Class Initialized
INFO - 2021-12-15 14:17:58 --> Model "Login_model" initialized
INFO - 2021-12-15 14:17:58 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-15 14:17:58 --> Final output sent to browser
DEBUG - 2021-12-15 14:17:58 --> Total execution time: 0.0257
ERROR - 2021-12-15 14:17:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 14:17:59 --> Config Class Initialized
INFO - 2021-12-15 14:17:59 --> Hooks Class Initialized
DEBUG - 2021-12-15 14:17:59 --> UTF-8 Support Enabled
INFO - 2021-12-15 14:17:59 --> Utf8 Class Initialized
INFO - 2021-12-15 14:17:59 --> URI Class Initialized
INFO - 2021-12-15 14:17:59 --> Router Class Initialized
INFO - 2021-12-15 14:17:59 --> Output Class Initialized
INFO - 2021-12-15 14:17:59 --> Security Class Initialized
DEBUG - 2021-12-15 14:17:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 14:17:59 --> Input Class Initialized
INFO - 2021-12-15 14:17:59 --> Language Class Initialized
INFO - 2021-12-15 14:17:59 --> Loader Class Initialized
INFO - 2021-12-15 14:17:59 --> Helper loaded: url_helper
INFO - 2021-12-15 14:17:59 --> Helper loaded: form_helper
INFO - 2021-12-15 14:17:59 --> Helper loaded: common_helper
INFO - 2021-12-15 14:17:59 --> Database Driver Class Initialized
DEBUG - 2021-12-15 14:17:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 14:17:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 14:17:59 --> Controller Class Initialized
INFO - 2021-12-15 14:17:59 --> Form Validation Class Initialized
DEBUG - 2021-12-15 14:17:59 --> Encrypt Class Initialized
DEBUG - 2021-12-15 14:17:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-15 14:17:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-15 14:17:59 --> Email Class Initialized
INFO - 2021-12-15 14:17:59 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-15 14:17:59 --> Calendar Class Initialized
INFO - 2021-12-15 14:17:59 --> Model "Login_model" initialized
INFO - 2021-12-15 14:17:59 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-15 14:17:59 --> Final output sent to browser
DEBUG - 2021-12-15 14:17:59 --> Total execution time: 0.0381
ERROR - 2021-12-15 14:18:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 14:18:00 --> Config Class Initialized
INFO - 2021-12-15 14:18:00 --> Hooks Class Initialized
DEBUG - 2021-12-15 14:18:00 --> UTF-8 Support Enabled
INFO - 2021-12-15 14:18:00 --> Utf8 Class Initialized
INFO - 2021-12-15 14:18:00 --> URI Class Initialized
INFO - 2021-12-15 14:18:00 --> Router Class Initialized
INFO - 2021-12-15 14:18:00 --> Output Class Initialized
INFO - 2021-12-15 14:18:00 --> Security Class Initialized
DEBUG - 2021-12-15 14:18:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 14:18:00 --> Input Class Initialized
INFO - 2021-12-15 14:18:00 --> Language Class Initialized
INFO - 2021-12-15 14:18:00 --> Loader Class Initialized
INFO - 2021-12-15 14:18:00 --> Helper loaded: url_helper
INFO - 2021-12-15 14:18:00 --> Helper loaded: form_helper
INFO - 2021-12-15 14:18:00 --> Helper loaded: common_helper
INFO - 2021-12-15 14:18:00 --> Database Driver Class Initialized
DEBUG - 2021-12-15 14:18:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 14:18:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 14:18:00 --> Controller Class Initialized
INFO - 2021-12-15 14:18:00 --> Form Validation Class Initialized
DEBUG - 2021-12-15 14:18:00 --> Encrypt Class Initialized
DEBUG - 2021-12-15 14:18:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-15 14:18:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-15 14:18:00 --> Email Class Initialized
INFO - 2021-12-15 14:18:00 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-15 14:18:00 --> Calendar Class Initialized
INFO - 2021-12-15 14:18:00 --> Model "Login_model" initialized
ERROR - 2021-12-15 14:18:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 14:18:00 --> Config Class Initialized
INFO - 2021-12-15 14:18:00 --> Hooks Class Initialized
DEBUG - 2021-12-15 14:18:00 --> UTF-8 Support Enabled
INFO - 2021-12-15 14:18:00 --> Utf8 Class Initialized
INFO - 2021-12-15 14:18:00 --> URI Class Initialized
INFO - 2021-12-15 14:18:00 --> Router Class Initialized
INFO - 2021-12-15 14:18:00 --> Output Class Initialized
INFO - 2021-12-15 14:18:00 --> Security Class Initialized
DEBUG - 2021-12-15 14:18:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 14:18:00 --> Input Class Initialized
INFO - 2021-12-15 14:18:00 --> Language Class Initialized
INFO - 2021-12-15 14:18:00 --> Loader Class Initialized
INFO - 2021-12-15 14:18:00 --> Helper loaded: url_helper
INFO - 2021-12-15 14:18:00 --> Helper loaded: form_helper
INFO - 2021-12-15 14:18:00 --> Helper loaded: common_helper
INFO - 2021-12-15 14:18:00 --> Database Driver Class Initialized
DEBUG - 2021-12-15 14:18:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 14:18:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 14:18:00 --> Controller Class Initialized
INFO - 2021-12-15 14:18:00 --> Form Validation Class Initialized
DEBUG - 2021-12-15 14:18:00 --> Encrypt Class Initialized
DEBUG - 2021-12-15 14:18:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-15 14:18:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-15 14:18:00 --> Email Class Initialized
INFO - 2021-12-15 14:18:00 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-15 14:18:00 --> Calendar Class Initialized
INFO - 2021-12-15 14:18:00 --> Model "Login_model" initialized
ERROR - 2021-12-15 15:38:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 15:38:29 --> Config Class Initialized
INFO - 2021-12-15 15:38:29 --> Hooks Class Initialized
DEBUG - 2021-12-15 15:38:29 --> UTF-8 Support Enabled
INFO - 2021-12-15 15:38:29 --> Utf8 Class Initialized
INFO - 2021-12-15 15:38:29 --> URI Class Initialized
DEBUG - 2021-12-15 15:38:29 --> No URI present. Default controller set.
INFO - 2021-12-15 15:38:29 --> Router Class Initialized
INFO - 2021-12-15 15:38:29 --> Output Class Initialized
INFO - 2021-12-15 15:38:29 --> Security Class Initialized
DEBUG - 2021-12-15 15:38:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 15:38:29 --> Input Class Initialized
INFO - 2021-12-15 15:38:29 --> Language Class Initialized
INFO - 2021-12-15 15:38:29 --> Loader Class Initialized
INFO - 2021-12-15 15:38:29 --> Helper loaded: url_helper
INFO - 2021-12-15 15:38:29 --> Helper loaded: form_helper
INFO - 2021-12-15 15:38:29 --> Helper loaded: common_helper
INFO - 2021-12-15 15:38:29 --> Database Driver Class Initialized
DEBUG - 2021-12-15 15:38:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 15:38:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 15:38:29 --> Controller Class Initialized
INFO - 2021-12-15 15:38:29 --> Form Validation Class Initialized
DEBUG - 2021-12-15 15:38:29 --> Encrypt Class Initialized
DEBUG - 2021-12-15 15:38:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-15 15:38:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-15 15:38:29 --> Email Class Initialized
INFO - 2021-12-15 15:38:29 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-15 15:38:29 --> Calendar Class Initialized
INFO - 2021-12-15 15:38:29 --> Model "Login_model" initialized
INFO - 2021-12-15 15:38:29 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-15 15:38:29 --> Final output sent to browser
DEBUG - 2021-12-15 15:38:29 --> Total execution time: 0.0227
ERROR - 2021-12-15 22:26:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 22:26:56 --> Config Class Initialized
INFO - 2021-12-15 22:26:56 --> Hooks Class Initialized
DEBUG - 2021-12-15 22:26:56 --> UTF-8 Support Enabled
INFO - 2021-12-15 22:26:56 --> Utf8 Class Initialized
INFO - 2021-12-15 22:26:56 --> URI Class Initialized
INFO - 2021-12-15 22:26:56 --> Router Class Initialized
INFO - 2021-12-15 22:26:56 --> Output Class Initialized
INFO - 2021-12-15 22:26:56 --> Security Class Initialized
DEBUG - 2021-12-15 22:26:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 22:26:56 --> Input Class Initialized
INFO - 2021-12-15 22:26:56 --> Language Class Initialized
ERROR - 2021-12-15 22:26:56 --> 404 Page Not Found: Dasboard/index
ERROR - 2021-12-15 22:37:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 22:37:16 --> Config Class Initialized
INFO - 2021-12-15 22:37:16 --> Hooks Class Initialized
DEBUG - 2021-12-15 22:37:16 --> UTF-8 Support Enabled
INFO - 2021-12-15 22:37:16 --> Utf8 Class Initialized
INFO - 2021-12-15 22:37:16 --> URI Class Initialized
INFO - 2021-12-15 22:37:16 --> Router Class Initialized
INFO - 2021-12-15 22:37:16 --> Output Class Initialized
INFO - 2021-12-15 22:37:16 --> Security Class Initialized
DEBUG - 2021-12-15 22:37:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 22:37:16 --> Input Class Initialized
INFO - 2021-12-15 22:37:16 --> Language Class Initialized
INFO - 2021-12-15 22:37:16 --> Loader Class Initialized
INFO - 2021-12-15 22:37:16 --> Helper loaded: url_helper
INFO - 2021-12-15 22:37:16 --> Helper loaded: form_helper
INFO - 2021-12-15 22:37:16 --> Helper loaded: common_helper
INFO - 2021-12-15 22:37:16 --> Database Driver Class Initialized
DEBUG - 2021-12-15 22:37:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 22:37:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 22:37:16 --> Controller Class Initialized
INFO - 2021-12-15 22:37:16 --> Form Validation Class Initialized
DEBUG - 2021-12-15 22:37:16 --> Encrypt Class Initialized
INFO - 2021-12-15 22:37:16 --> Model "Login_model" initialized
INFO - 2021-12-15 22:37:16 --> Model "Dashboard_model" initialized
INFO - 2021-12-15 22:37:16 --> Model "Case_model" initialized
ERROR - 2021-12-15 22:37:16 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'GROUP BY  CALCULATEAGE(YEAR(patient_dob))
     
     UNION 
     
  SELECT calcu' at line 7 - Invalid query: SELECT SUM(TotalPatient) as TotalPatient ,AgeGroup
FROM
( 
SELECT CALCULATEAGE(YEAR(patient_dob)) AS AgeGroup, COUNT(CALCULATEAGE(YEAR(patient_dob)))  AS TotalPatient FROM patient_master
       
    WHERE  IFNULL(`status`,0)!= '1' AND patient_dob IS NOT NULL AND patient_dob != '0000-00-00'  AND patient_master.created_by = 
     GROUP BY  CALCULATEAGE(YEAR(patient_dob))
     
     UNION 
     
  SELECT calculateWithoutDOBAge(SUBSTRING(patient_age,1,2)) AS AgeGroup, COUNT(calculateWithoutDOBAge(SUBSTRING(patient_age,1,2))) AS 
  TotalPatient FROM patient_master WHERE IFNULL(`status`,0)!= '1' AND IFNULL(patient_dob,'')='0000-00-00'  AND IFNULL(patient_age,'')!=''  AND patient_master.created_by = 
        GROUP BY calculateWithoutDOBAge(SUBSTRING(patient_age,1,2))
        )B GROUP BY AgeGroup
INFO - 2021-12-15 22:37:16 --> Language file loaded: language/english/db_lang.php
ERROR - 2021-12-15 23:34:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 23:34:14 --> Config Class Initialized
INFO - 2021-12-15 23:34:14 --> Hooks Class Initialized
DEBUG - 2021-12-15 23:34:14 --> UTF-8 Support Enabled
INFO - 2021-12-15 23:34:14 --> Utf8 Class Initialized
INFO - 2021-12-15 23:34:14 --> URI Class Initialized
INFO - 2021-12-15 23:34:14 --> Router Class Initialized
INFO - 2021-12-15 23:34:14 --> Output Class Initialized
INFO - 2021-12-15 23:34:14 --> Security Class Initialized
DEBUG - 2021-12-15 23:34:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 23:34:14 --> Input Class Initialized
INFO - 2021-12-15 23:34:14 --> Language Class Initialized
INFO - 2021-12-15 23:34:14 --> Loader Class Initialized
INFO - 2021-12-15 23:34:14 --> Helper loaded: url_helper
INFO - 2021-12-15 23:34:14 --> Helper loaded: form_helper
INFO - 2021-12-15 23:34:14 --> Helper loaded: common_helper
INFO - 2021-12-15 23:34:14 --> Database Driver Class Initialized
DEBUG - 2021-12-15 23:34:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 23:34:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 23:34:15 --> Controller Class Initialized
INFO - 2021-12-15 23:34:15 --> Form Validation Class Initialized
DEBUG - 2021-12-15 23:34:15 --> Encrypt Class Initialized
INFO - 2021-12-15 23:34:15 --> Model "Login_model" initialized
INFO - 2021-12-15 23:34:15 --> Model "Dashboard_model" initialized
INFO - 2021-12-15 23:34:15 --> Model "Case_model" initialized
ERROR - 2021-12-15 23:34:15 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'GROUP BY  CALCULATEAGE(YEAR(patient_dob))
     
     UNION 
     
  SELECT calcu' at line 7 - Invalid query: SELECT SUM(TotalPatient) as TotalPatient ,AgeGroup
FROM
( 
SELECT CALCULATEAGE(YEAR(patient_dob)) AS AgeGroup, COUNT(CALCULATEAGE(YEAR(patient_dob)))  AS TotalPatient FROM patient_master
       
    WHERE  IFNULL(`status`,0)!= '1' AND patient_dob IS NOT NULL AND patient_dob != '0000-00-00'  AND patient_master.created_by = 
     GROUP BY  CALCULATEAGE(YEAR(patient_dob))
     
     UNION 
     
  SELECT calculateWithoutDOBAge(SUBSTRING(patient_age,1,2)) AS AgeGroup, COUNT(calculateWithoutDOBAge(SUBSTRING(patient_age,1,2))) AS 
  TotalPatient FROM patient_master WHERE IFNULL(`status`,0)!= '1' AND IFNULL(patient_dob,'')='0000-00-00'  AND IFNULL(patient_age,'')!=''  AND patient_master.created_by = 
        GROUP BY calculateWithoutDOBAge(SUBSTRING(patient_age,1,2))
        )B GROUP BY AgeGroup
INFO - 2021-12-15 23:34:15 --> Language file loaded: language/english/db_lang.php
ERROR - 2021-12-15 23:34:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 23:34:25 --> Config Class Initialized
INFO - 2021-12-15 23:34:25 --> Hooks Class Initialized
DEBUG - 2021-12-15 23:34:25 --> UTF-8 Support Enabled
INFO - 2021-12-15 23:34:25 --> Utf8 Class Initialized
INFO - 2021-12-15 23:34:25 --> URI Class Initialized
INFO - 2021-12-15 23:34:25 --> Router Class Initialized
INFO - 2021-12-15 23:34:25 --> Output Class Initialized
INFO - 2021-12-15 23:34:25 --> Security Class Initialized
DEBUG - 2021-12-15 23:34:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 23:34:25 --> Input Class Initialized
INFO - 2021-12-15 23:34:25 --> Language Class Initialized
INFO - 2021-12-15 23:34:25 --> Loader Class Initialized
INFO - 2021-12-15 23:34:25 --> Helper loaded: url_helper
INFO - 2021-12-15 23:34:25 --> Helper loaded: form_helper
INFO - 2021-12-15 23:34:25 --> Helper loaded: common_helper
INFO - 2021-12-15 23:34:25 --> Database Driver Class Initialized
DEBUG - 2021-12-15 23:34:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 23:34:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 23:34:25 --> Controller Class Initialized
INFO - 2021-12-15 23:34:25 --> Form Validation Class Initialized
DEBUG - 2021-12-15 23:34:25 --> Encrypt Class Initialized
INFO - 2021-12-15 23:34:25 --> Model "Login_model" initialized
INFO - 2021-12-15 23:34:25 --> Model "Dashboard_model" initialized
INFO - 2021-12-15 23:34:25 --> Model "Case_model" initialized
ERROR - 2021-12-15 23:34:25 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'GROUP BY  CALCULATEAGE(YEAR(patient_dob))
     
     UNION 
     
  SELECT calcu' at line 7 - Invalid query: SELECT SUM(TotalPatient) as TotalPatient ,AgeGroup
FROM
( 
SELECT CALCULATEAGE(YEAR(patient_dob)) AS AgeGroup, COUNT(CALCULATEAGE(YEAR(patient_dob)))  AS TotalPatient FROM patient_master
       
    WHERE  IFNULL(`status`,0)!= '1' AND patient_dob IS NOT NULL AND patient_dob != '0000-00-00'  AND patient_master.created_by = 
     GROUP BY  CALCULATEAGE(YEAR(patient_dob))
     
     UNION 
     
  SELECT calculateWithoutDOBAge(SUBSTRING(patient_age,1,2)) AS AgeGroup, COUNT(calculateWithoutDOBAge(SUBSTRING(patient_age,1,2))) AS 
  TotalPatient FROM patient_master WHERE IFNULL(`status`,0)!= '1' AND IFNULL(patient_dob,'')='0000-00-00'  AND IFNULL(patient_age,'')!=''  AND patient_master.created_by = 
        GROUP BY calculateWithoutDOBAge(SUBSTRING(patient_age,1,2))
        )B GROUP BY AgeGroup
INFO - 2021-12-15 23:34:25 --> Language file loaded: language/english/db_lang.php
ERROR - 2021-12-15 23:40:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 23:40:44 --> Config Class Initialized
INFO - 2021-12-15 23:40:44 --> Hooks Class Initialized
DEBUG - 2021-12-15 23:40:44 --> UTF-8 Support Enabled
INFO - 2021-12-15 23:40:44 --> Utf8 Class Initialized
INFO - 2021-12-15 23:40:44 --> URI Class Initialized
INFO - 2021-12-15 23:40:44 --> Router Class Initialized
INFO - 2021-12-15 23:40:44 --> Output Class Initialized
INFO - 2021-12-15 23:40:44 --> Security Class Initialized
DEBUG - 2021-12-15 23:40:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 23:40:44 --> Input Class Initialized
INFO - 2021-12-15 23:40:44 --> Language Class Initialized
INFO - 2021-12-15 23:40:44 --> Loader Class Initialized
INFO - 2021-12-15 23:40:44 --> Helper loaded: url_helper
INFO - 2021-12-15 23:40:44 --> Helper loaded: form_helper
INFO - 2021-12-15 23:40:44 --> Helper loaded: common_helper
INFO - 2021-12-15 23:40:44 --> Database Driver Class Initialized
DEBUG - 2021-12-15 23:40:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 23:40:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 23:40:44 --> Controller Class Initialized
INFO - 2021-12-15 23:40:44 --> Form Validation Class Initialized
DEBUG - 2021-12-15 23:40:44 --> Encrypt Class Initialized
INFO - 2021-12-15 23:40:44 --> Model "Login_model" initialized
INFO - 2021-12-15 23:40:44 --> Model "Dashboard_model" initialized
INFO - 2021-12-15 23:40:44 --> Model "Case_model" initialized
ERROR - 2021-12-15 23:40:44 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'GROUP BY  CALCULATEAGE(YEAR(patient_dob))
     
     UNION 
     
  SELECT calcu' at line 7 - Invalid query: SELECT SUM(TotalPatient) as TotalPatient ,AgeGroup
FROM
( 
SELECT CALCULATEAGE(YEAR(patient_dob)) AS AgeGroup, COUNT(CALCULATEAGE(YEAR(patient_dob)))  AS TotalPatient FROM patient_master
       
    WHERE  IFNULL(`status`,0)!= '1' AND patient_dob IS NOT NULL AND patient_dob != '0000-00-00'  AND patient_master.created_by = 
     GROUP BY  CALCULATEAGE(YEAR(patient_dob))
     
     UNION 
     
  SELECT calculateWithoutDOBAge(SUBSTRING(patient_age,1,2)) AS AgeGroup, COUNT(calculateWithoutDOBAge(SUBSTRING(patient_age,1,2))) AS 
  TotalPatient FROM patient_master WHERE IFNULL(`status`,0)!= '1' AND IFNULL(patient_dob,'')='0000-00-00'  AND IFNULL(patient_age,'')!=''  AND patient_master.created_by = 
        GROUP BY calculateWithoutDOBAge(SUBSTRING(patient_age,1,2))
        )B GROUP BY AgeGroup
INFO - 2021-12-15 23:40:44 --> Language file loaded: language/english/db_lang.php
ERROR - 2021-12-15 23:42:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-15 23:42:21 --> Config Class Initialized
INFO - 2021-12-15 23:42:21 --> Hooks Class Initialized
DEBUG - 2021-12-15 23:42:21 --> UTF-8 Support Enabled
INFO - 2021-12-15 23:42:21 --> Utf8 Class Initialized
INFO - 2021-12-15 23:42:21 --> URI Class Initialized
INFO - 2021-12-15 23:42:21 --> Router Class Initialized
INFO - 2021-12-15 23:42:21 --> Output Class Initialized
INFO - 2021-12-15 23:42:21 --> Security Class Initialized
DEBUG - 2021-12-15 23:42:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 23:42:21 --> Input Class Initialized
INFO - 2021-12-15 23:42:21 --> Language Class Initialized
INFO - 2021-12-15 23:42:21 --> Loader Class Initialized
INFO - 2021-12-15 23:42:21 --> Helper loaded: url_helper
INFO - 2021-12-15 23:42:21 --> Helper loaded: form_helper
INFO - 2021-12-15 23:42:21 --> Helper loaded: common_helper
INFO - 2021-12-15 23:42:21 --> Database Driver Class Initialized
DEBUG - 2021-12-15 23:42:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 23:42:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 23:42:21 --> Controller Class Initialized
INFO - 2021-12-15 23:42:21 --> Form Validation Class Initialized
DEBUG - 2021-12-15 23:42:21 --> Encrypt Class Initialized
INFO - 2021-12-15 23:42:21 --> Model "Login_model" initialized
INFO - 2021-12-15 23:42:21 --> Model "Dashboard_model" initialized
INFO - 2021-12-15 23:42:21 --> Model "Case_model" initialized
ERROR - 2021-12-15 23:42:21 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'GROUP BY  CALCULATEAGE(YEAR(patient_dob))
     
     UNION 
     
  SELECT calcu' at line 7 - Invalid query: SELECT SUM(TotalPatient) as TotalPatient ,AgeGroup
FROM
( 
SELECT CALCULATEAGE(YEAR(patient_dob)) AS AgeGroup, COUNT(CALCULATEAGE(YEAR(patient_dob)))  AS TotalPatient FROM patient_master
       
    WHERE  IFNULL(`status`,0)!= '1' AND patient_dob IS NOT NULL AND patient_dob != '0000-00-00'  AND patient_master.created_by = 
     GROUP BY  CALCULATEAGE(YEAR(patient_dob))
     
     UNION 
     
  SELECT calculateWithoutDOBAge(SUBSTRING(patient_age,1,2)) AS AgeGroup, COUNT(calculateWithoutDOBAge(SUBSTRING(patient_age,1,2))) AS 
  TotalPatient FROM patient_master WHERE IFNULL(`status`,0)!= '1' AND IFNULL(patient_dob,'')='0000-00-00'  AND IFNULL(patient_age,'')!=''  AND patient_master.created_by = 
        GROUP BY calculateWithoutDOBAge(SUBSTRING(patient_age,1,2))
        )B GROUP BY AgeGroup
INFO - 2021-12-15 23:42:21 --> Language file loaded: language/english/db_lang.php
