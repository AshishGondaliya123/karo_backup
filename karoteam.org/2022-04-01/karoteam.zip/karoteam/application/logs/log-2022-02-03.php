<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-02-03 03:29:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-03 03:29:50 --> Config Class Initialized
INFO - 2022-02-03 03:29:50 --> Hooks Class Initialized
DEBUG - 2022-02-03 03:29:50 --> UTF-8 Support Enabled
INFO - 2022-02-03 03:29:50 --> Utf8 Class Initialized
INFO - 2022-02-03 03:29:50 --> URI Class Initialized
DEBUG - 2022-02-03 03:29:50 --> No URI present. Default controller set.
INFO - 2022-02-03 03:29:50 --> Router Class Initialized
INFO - 2022-02-03 03:29:50 --> Output Class Initialized
INFO - 2022-02-03 03:29:50 --> Security Class Initialized
DEBUG - 2022-02-03 03:29:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-03 03:29:50 --> Input Class Initialized
INFO - 2022-02-03 03:29:50 --> Language Class Initialized
INFO - 2022-02-03 03:29:50 --> Loader Class Initialized
INFO - 2022-02-03 03:29:50 --> Helper loaded: url_helper
INFO - 2022-02-03 03:29:50 --> Helper loaded: form_helper
INFO - 2022-02-03 03:29:50 --> Helper loaded: common_helper
INFO - 2022-02-03 03:29:50 --> Database Driver Class Initialized
DEBUG - 2022-02-03 03:29:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-03 03:29:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-03 03:29:50 --> Controller Class Initialized
INFO - 2022-02-03 03:29:50 --> Form Validation Class Initialized
DEBUG - 2022-02-03 03:29:50 --> Encrypt Class Initialized
DEBUG - 2022-02-03 03:29:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-03 03:29:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-03 03:29:50 --> Email Class Initialized
INFO - 2022-02-03 03:29:50 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-03 03:29:50 --> Calendar Class Initialized
INFO - 2022-02-03 03:29:50 --> Model "Login_model" initialized
INFO - 2022-02-03 03:29:50 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-03 03:29:50 --> Final output sent to browser
DEBUG - 2022-02-03 03:29:50 --> Total execution time: 0.0259
ERROR - 2022-02-03 10:27:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-03 10:27:46 --> Config Class Initialized
INFO - 2022-02-03 10:27:46 --> Hooks Class Initialized
DEBUG - 2022-02-03 10:27:46 --> UTF-8 Support Enabled
INFO - 2022-02-03 10:27:46 --> Utf8 Class Initialized
INFO - 2022-02-03 10:27:46 --> URI Class Initialized
DEBUG - 2022-02-03 10:27:46 --> No URI present. Default controller set.
INFO - 2022-02-03 10:27:46 --> Router Class Initialized
INFO - 2022-02-03 10:27:46 --> Output Class Initialized
INFO - 2022-02-03 10:27:46 --> Security Class Initialized
DEBUG - 2022-02-03 10:27:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-03 10:27:46 --> Input Class Initialized
INFO - 2022-02-03 10:27:46 --> Language Class Initialized
INFO - 2022-02-03 10:27:46 --> Loader Class Initialized
INFO - 2022-02-03 10:27:46 --> Helper loaded: url_helper
INFO - 2022-02-03 10:27:46 --> Helper loaded: form_helper
INFO - 2022-02-03 10:27:46 --> Helper loaded: common_helper
INFO - 2022-02-03 10:27:46 --> Database Driver Class Initialized
DEBUG - 2022-02-03 10:27:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-03 10:27:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-03 10:27:46 --> Controller Class Initialized
INFO - 2022-02-03 10:27:46 --> Form Validation Class Initialized
DEBUG - 2022-02-03 10:27:46 --> Encrypt Class Initialized
DEBUG - 2022-02-03 10:27:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-03 10:27:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-03 10:27:46 --> Email Class Initialized
INFO - 2022-02-03 10:27:46 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-03 10:27:46 --> Calendar Class Initialized
INFO - 2022-02-03 10:27:46 --> Model "Login_model" initialized
INFO - 2022-02-03 10:27:46 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-03 10:27:46 --> Final output sent to browser
DEBUG - 2022-02-03 10:27:46 --> Total execution time: 0.0300
ERROR - 2022-02-03 10:27:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-03 10:27:51 --> Config Class Initialized
INFO - 2022-02-03 10:27:51 --> Hooks Class Initialized
DEBUG - 2022-02-03 10:27:51 --> UTF-8 Support Enabled
INFO - 2022-02-03 10:27:51 --> Utf8 Class Initialized
INFO - 2022-02-03 10:27:51 --> URI Class Initialized
DEBUG - 2022-02-03 10:27:51 --> No URI present. Default controller set.
INFO - 2022-02-03 10:27:51 --> Router Class Initialized
INFO - 2022-02-03 10:27:51 --> Output Class Initialized
INFO - 2022-02-03 10:27:51 --> Security Class Initialized
DEBUG - 2022-02-03 10:27:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-03 10:27:51 --> Input Class Initialized
INFO - 2022-02-03 10:27:51 --> Language Class Initialized
INFO - 2022-02-03 10:27:51 --> Loader Class Initialized
INFO - 2022-02-03 10:27:51 --> Helper loaded: url_helper
INFO - 2022-02-03 10:27:51 --> Helper loaded: form_helper
INFO - 2022-02-03 10:27:51 --> Helper loaded: common_helper
INFO - 2022-02-03 10:27:51 --> Database Driver Class Initialized
DEBUG - 2022-02-03 10:27:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-03 10:27:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-03 10:27:51 --> Controller Class Initialized
INFO - 2022-02-03 10:27:51 --> Form Validation Class Initialized
DEBUG - 2022-02-03 10:27:51 --> Encrypt Class Initialized
DEBUG - 2022-02-03 10:27:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-03 10:27:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-03 10:27:51 --> Email Class Initialized
INFO - 2022-02-03 10:27:51 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-03 10:27:51 --> Calendar Class Initialized
INFO - 2022-02-03 10:27:51 --> Model "Login_model" initialized
INFO - 2022-02-03 10:27:51 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-03 10:27:51 --> Final output sent to browser
DEBUG - 2022-02-03 10:27:51 --> Total execution time: 0.0210
ERROR - 2022-02-03 10:46:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-03 10:46:38 --> Config Class Initialized
INFO - 2022-02-03 10:46:38 --> Hooks Class Initialized
DEBUG - 2022-02-03 10:46:38 --> UTF-8 Support Enabled
INFO - 2022-02-03 10:46:38 --> Utf8 Class Initialized
INFO - 2022-02-03 10:46:38 --> URI Class Initialized
DEBUG - 2022-02-03 10:46:38 --> No URI present. Default controller set.
INFO - 2022-02-03 10:46:38 --> Router Class Initialized
INFO - 2022-02-03 10:46:38 --> Output Class Initialized
INFO - 2022-02-03 10:46:38 --> Security Class Initialized
DEBUG - 2022-02-03 10:46:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-03 10:46:38 --> Input Class Initialized
INFO - 2022-02-03 10:46:38 --> Language Class Initialized
INFO - 2022-02-03 10:46:38 --> Loader Class Initialized
INFO - 2022-02-03 10:46:38 --> Helper loaded: url_helper
INFO - 2022-02-03 10:46:38 --> Helper loaded: form_helper
INFO - 2022-02-03 10:46:38 --> Helper loaded: common_helper
INFO - 2022-02-03 10:46:38 --> Database Driver Class Initialized
DEBUG - 2022-02-03 10:46:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-03 10:46:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-03 10:46:38 --> Controller Class Initialized
INFO - 2022-02-03 10:46:38 --> Form Validation Class Initialized
DEBUG - 2022-02-03 10:46:38 --> Encrypt Class Initialized
DEBUG - 2022-02-03 10:46:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-03 10:46:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-03 10:46:38 --> Email Class Initialized
INFO - 2022-02-03 10:46:38 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-03 10:46:38 --> Calendar Class Initialized
INFO - 2022-02-03 10:46:38 --> Model "Login_model" initialized
INFO - 2022-02-03 10:46:38 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-03 10:46:38 --> Final output sent to browser
DEBUG - 2022-02-03 10:46:38 --> Total execution time: 0.0353
ERROR - 2022-02-03 10:46:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-03 10:46:42 --> Config Class Initialized
INFO - 2022-02-03 10:46:42 --> Hooks Class Initialized
DEBUG - 2022-02-03 10:46:42 --> UTF-8 Support Enabled
INFO - 2022-02-03 10:46:42 --> Utf8 Class Initialized
INFO - 2022-02-03 10:46:42 --> URI Class Initialized
DEBUG - 2022-02-03 10:46:42 --> No URI present. Default controller set.
INFO - 2022-02-03 10:46:42 --> Router Class Initialized
INFO - 2022-02-03 10:46:42 --> Output Class Initialized
INFO - 2022-02-03 10:46:42 --> Security Class Initialized
DEBUG - 2022-02-03 10:46:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-03 10:46:42 --> Input Class Initialized
INFO - 2022-02-03 10:46:42 --> Language Class Initialized
INFO - 2022-02-03 10:46:42 --> Loader Class Initialized
INFO - 2022-02-03 10:46:42 --> Helper loaded: url_helper
INFO - 2022-02-03 10:46:42 --> Helper loaded: form_helper
INFO - 2022-02-03 10:46:42 --> Helper loaded: common_helper
INFO - 2022-02-03 10:46:42 --> Database Driver Class Initialized
DEBUG - 2022-02-03 10:46:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-03 10:46:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-03 10:46:42 --> Controller Class Initialized
INFO - 2022-02-03 10:46:42 --> Form Validation Class Initialized
DEBUG - 2022-02-03 10:46:42 --> Encrypt Class Initialized
DEBUG - 2022-02-03 10:46:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-03 10:46:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-03 10:46:42 --> Email Class Initialized
INFO - 2022-02-03 10:46:42 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-03 10:46:42 --> Calendar Class Initialized
INFO - 2022-02-03 10:46:42 --> Model "Login_model" initialized
INFO - 2022-02-03 10:46:42 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-03 10:46:42 --> Final output sent to browser
DEBUG - 2022-02-03 10:46:42 --> Total execution time: 0.0474
ERROR - 2022-02-03 11:59:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-03 11:59:51 --> Config Class Initialized
INFO - 2022-02-03 11:59:51 --> Hooks Class Initialized
DEBUG - 2022-02-03 11:59:51 --> UTF-8 Support Enabled
INFO - 2022-02-03 11:59:51 --> Utf8 Class Initialized
INFO - 2022-02-03 11:59:51 --> URI Class Initialized
DEBUG - 2022-02-03 11:59:51 --> No URI present. Default controller set.
INFO - 2022-02-03 11:59:51 --> Router Class Initialized
INFO - 2022-02-03 11:59:51 --> Output Class Initialized
INFO - 2022-02-03 11:59:51 --> Security Class Initialized
DEBUG - 2022-02-03 11:59:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-03 11:59:51 --> Input Class Initialized
INFO - 2022-02-03 11:59:51 --> Language Class Initialized
INFO - 2022-02-03 11:59:51 --> Loader Class Initialized
INFO - 2022-02-03 11:59:51 --> Helper loaded: url_helper
INFO - 2022-02-03 11:59:51 --> Helper loaded: form_helper
INFO - 2022-02-03 11:59:51 --> Helper loaded: common_helper
INFO - 2022-02-03 11:59:51 --> Database Driver Class Initialized
DEBUG - 2022-02-03 11:59:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-03 11:59:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-03 11:59:51 --> Controller Class Initialized
INFO - 2022-02-03 11:59:51 --> Form Validation Class Initialized
DEBUG - 2022-02-03 11:59:51 --> Encrypt Class Initialized
DEBUG - 2022-02-03 11:59:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-03 11:59:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-03 11:59:51 --> Email Class Initialized
INFO - 2022-02-03 11:59:51 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-03 11:59:51 --> Calendar Class Initialized
INFO - 2022-02-03 11:59:51 --> Model "Login_model" initialized
INFO - 2022-02-03 11:59:51 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-03 11:59:51 --> Final output sent to browser
DEBUG - 2022-02-03 11:59:51 --> Total execution time: 0.0397
ERROR - 2022-02-03 11:59:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-03 11:59:51 --> Config Class Initialized
INFO - 2022-02-03 11:59:51 --> Hooks Class Initialized
DEBUG - 2022-02-03 11:59:51 --> UTF-8 Support Enabled
INFO - 2022-02-03 11:59:51 --> Utf8 Class Initialized
INFO - 2022-02-03 11:59:51 --> URI Class Initialized
DEBUG - 2022-02-03 11:59:51 --> No URI present. Default controller set.
INFO - 2022-02-03 11:59:51 --> Router Class Initialized
INFO - 2022-02-03 11:59:51 --> Output Class Initialized
INFO - 2022-02-03 11:59:51 --> Security Class Initialized
DEBUG - 2022-02-03 11:59:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-03 11:59:51 --> Input Class Initialized
INFO - 2022-02-03 11:59:51 --> Language Class Initialized
INFO - 2022-02-03 11:59:51 --> Loader Class Initialized
INFO - 2022-02-03 11:59:51 --> Helper loaded: url_helper
INFO - 2022-02-03 11:59:51 --> Helper loaded: form_helper
INFO - 2022-02-03 11:59:51 --> Helper loaded: common_helper
INFO - 2022-02-03 11:59:51 --> Database Driver Class Initialized
DEBUG - 2022-02-03 11:59:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-03 11:59:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-03 11:59:51 --> Controller Class Initialized
INFO - 2022-02-03 11:59:51 --> Form Validation Class Initialized
DEBUG - 2022-02-03 11:59:51 --> Encrypt Class Initialized
DEBUG - 2022-02-03 11:59:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-03 11:59:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-03 11:59:51 --> Email Class Initialized
INFO - 2022-02-03 11:59:51 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-03 11:59:51 --> Calendar Class Initialized
INFO - 2022-02-03 11:59:51 --> Model "Login_model" initialized
INFO - 2022-02-03 11:59:51 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-03 11:59:51 --> Final output sent to browser
DEBUG - 2022-02-03 11:59:51 --> Total execution time: 0.0249
ERROR - 2022-02-03 12:04:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-03 12:04:34 --> Config Class Initialized
INFO - 2022-02-03 12:04:34 --> Hooks Class Initialized
DEBUG - 2022-02-03 12:04:34 --> UTF-8 Support Enabled
INFO - 2022-02-03 12:04:34 --> Utf8 Class Initialized
INFO - 2022-02-03 12:04:34 --> URI Class Initialized
DEBUG - 2022-02-03 12:04:34 --> No URI present. Default controller set.
INFO - 2022-02-03 12:04:34 --> Router Class Initialized
INFO - 2022-02-03 12:04:34 --> Output Class Initialized
INFO - 2022-02-03 12:04:34 --> Security Class Initialized
DEBUG - 2022-02-03 12:04:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-03 12:04:34 --> Input Class Initialized
INFO - 2022-02-03 12:04:34 --> Language Class Initialized
INFO - 2022-02-03 12:04:34 --> Loader Class Initialized
INFO - 2022-02-03 12:04:34 --> Helper loaded: url_helper
INFO - 2022-02-03 12:04:34 --> Helper loaded: form_helper
INFO - 2022-02-03 12:04:34 --> Helper loaded: common_helper
INFO - 2022-02-03 12:04:34 --> Database Driver Class Initialized
DEBUG - 2022-02-03 12:04:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-03 12:04:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-03 12:04:34 --> Controller Class Initialized
INFO - 2022-02-03 12:04:34 --> Form Validation Class Initialized
DEBUG - 2022-02-03 12:04:34 --> Encrypt Class Initialized
DEBUG - 2022-02-03 12:04:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-03 12:04:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-03 12:04:34 --> Email Class Initialized
INFO - 2022-02-03 12:04:34 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-03 12:04:34 --> Calendar Class Initialized
INFO - 2022-02-03 12:04:34 --> Model "Login_model" initialized
INFO - 2022-02-03 12:04:34 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-03 12:04:34 --> Final output sent to browser
DEBUG - 2022-02-03 12:04:34 --> Total execution time: 0.0363
ERROR - 2022-02-03 12:04:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-03 12:04:35 --> Config Class Initialized
INFO - 2022-02-03 12:04:35 --> Hooks Class Initialized
DEBUG - 2022-02-03 12:04:35 --> UTF-8 Support Enabled
INFO - 2022-02-03 12:04:35 --> Utf8 Class Initialized
INFO - 2022-02-03 12:04:35 --> URI Class Initialized
DEBUG - 2022-02-03 12:04:35 --> No URI present. Default controller set.
INFO - 2022-02-03 12:04:35 --> Router Class Initialized
INFO - 2022-02-03 12:04:35 --> Output Class Initialized
INFO - 2022-02-03 12:04:35 --> Security Class Initialized
DEBUG - 2022-02-03 12:04:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-03 12:04:35 --> Input Class Initialized
INFO - 2022-02-03 12:04:35 --> Language Class Initialized
INFO - 2022-02-03 12:04:35 --> Loader Class Initialized
INFO - 2022-02-03 12:04:35 --> Helper loaded: url_helper
INFO - 2022-02-03 12:04:35 --> Helper loaded: form_helper
INFO - 2022-02-03 12:04:35 --> Helper loaded: common_helper
INFO - 2022-02-03 12:04:35 --> Database Driver Class Initialized
DEBUG - 2022-02-03 12:04:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-03 12:04:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-03 12:04:35 --> Controller Class Initialized
INFO - 2022-02-03 12:04:35 --> Form Validation Class Initialized
DEBUG - 2022-02-03 12:04:35 --> Encrypt Class Initialized
DEBUG - 2022-02-03 12:04:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-03 12:04:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-03 12:04:35 --> Email Class Initialized
INFO - 2022-02-03 12:04:35 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-03 12:04:35 --> Calendar Class Initialized
INFO - 2022-02-03 12:04:35 --> Model "Login_model" initialized
INFO - 2022-02-03 12:04:35 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-03 12:04:35 --> Final output sent to browser
DEBUG - 2022-02-03 12:04:35 --> Total execution time: 0.0375
ERROR - 2022-02-03 14:20:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-03 14:20:02 --> Config Class Initialized
INFO - 2022-02-03 14:20:02 --> Hooks Class Initialized
DEBUG - 2022-02-03 14:20:02 --> UTF-8 Support Enabled
INFO - 2022-02-03 14:20:02 --> Utf8 Class Initialized
INFO - 2022-02-03 14:20:02 --> URI Class Initialized
DEBUG - 2022-02-03 14:20:02 --> No URI present. Default controller set.
INFO - 2022-02-03 14:20:02 --> Router Class Initialized
INFO - 2022-02-03 14:20:02 --> Output Class Initialized
INFO - 2022-02-03 14:20:02 --> Security Class Initialized
DEBUG - 2022-02-03 14:20:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-03 14:20:02 --> Input Class Initialized
INFO - 2022-02-03 14:20:02 --> Language Class Initialized
INFO - 2022-02-03 14:20:02 --> Loader Class Initialized
INFO - 2022-02-03 14:20:02 --> Helper loaded: url_helper
INFO - 2022-02-03 14:20:02 --> Helper loaded: form_helper
INFO - 2022-02-03 14:20:02 --> Helper loaded: common_helper
INFO - 2022-02-03 14:20:02 --> Database Driver Class Initialized
DEBUG - 2022-02-03 14:20:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-03 14:20:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-03 14:20:02 --> Controller Class Initialized
INFO - 2022-02-03 14:20:02 --> Form Validation Class Initialized
DEBUG - 2022-02-03 14:20:02 --> Encrypt Class Initialized
DEBUG - 2022-02-03 14:20:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-03 14:20:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-03 14:20:02 --> Email Class Initialized
INFO - 2022-02-03 14:20:02 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-03 14:20:02 --> Calendar Class Initialized
INFO - 2022-02-03 14:20:02 --> Model "Login_model" initialized
INFO - 2022-02-03 14:20:02 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-03 14:20:02 --> Final output sent to browser
DEBUG - 2022-02-03 14:20:02 --> Total execution time: 0.0472
ERROR - 2022-02-03 14:20:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-03 14:20:04 --> Config Class Initialized
INFO - 2022-02-03 14:20:04 --> Hooks Class Initialized
DEBUG - 2022-02-03 14:20:04 --> UTF-8 Support Enabled
INFO - 2022-02-03 14:20:04 --> Utf8 Class Initialized
INFO - 2022-02-03 14:20:04 --> URI Class Initialized
INFO - 2022-02-03 14:20:04 --> Router Class Initialized
INFO - 2022-02-03 14:20:04 --> Output Class Initialized
INFO - 2022-02-03 14:20:04 --> Security Class Initialized
DEBUG - 2022-02-03 14:20:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-03 14:20:04 --> Input Class Initialized
INFO - 2022-02-03 14:20:04 --> Language Class Initialized
ERROR - 2022-02-03 14:20:04 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2022-02-03 14:20:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-03 14:20:15 --> Config Class Initialized
INFO - 2022-02-03 14:20:15 --> Hooks Class Initialized
DEBUG - 2022-02-03 14:20:15 --> UTF-8 Support Enabled
INFO - 2022-02-03 14:20:15 --> Utf8 Class Initialized
INFO - 2022-02-03 14:20:15 --> URI Class Initialized
DEBUG - 2022-02-03 14:20:15 --> No URI present. Default controller set.
INFO - 2022-02-03 14:20:15 --> Router Class Initialized
INFO - 2022-02-03 14:20:15 --> Output Class Initialized
INFO - 2022-02-03 14:20:15 --> Security Class Initialized
DEBUG - 2022-02-03 14:20:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-03 14:20:15 --> Input Class Initialized
INFO - 2022-02-03 14:20:15 --> Language Class Initialized
INFO - 2022-02-03 14:20:15 --> Loader Class Initialized
INFO - 2022-02-03 14:20:15 --> Helper loaded: url_helper
INFO - 2022-02-03 14:20:15 --> Helper loaded: form_helper
INFO - 2022-02-03 14:20:15 --> Helper loaded: common_helper
INFO - 2022-02-03 14:20:15 --> Database Driver Class Initialized
DEBUG - 2022-02-03 14:20:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-03 14:20:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-03 14:20:15 --> Controller Class Initialized
INFO - 2022-02-03 14:20:15 --> Form Validation Class Initialized
DEBUG - 2022-02-03 14:20:15 --> Encrypt Class Initialized
DEBUG - 2022-02-03 14:20:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-03 14:20:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-03 14:20:15 --> Email Class Initialized
INFO - 2022-02-03 14:20:15 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-03 14:20:15 --> Calendar Class Initialized
INFO - 2022-02-03 14:20:15 --> Model "Login_model" initialized
INFO - 2022-02-03 14:20:15 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-03 14:20:15 --> Final output sent to browser
DEBUG - 2022-02-03 14:20:15 --> Total execution time: 0.0211
ERROR - 2022-02-03 14:20:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-03 14:20:16 --> Config Class Initialized
INFO - 2022-02-03 14:20:16 --> Hooks Class Initialized
DEBUG - 2022-02-03 14:20:16 --> UTF-8 Support Enabled
INFO - 2022-02-03 14:20:16 --> Utf8 Class Initialized
INFO - 2022-02-03 14:20:16 --> URI Class Initialized
INFO - 2022-02-03 14:20:16 --> Router Class Initialized
INFO - 2022-02-03 14:20:16 --> Output Class Initialized
INFO - 2022-02-03 14:20:16 --> Security Class Initialized
DEBUG - 2022-02-03 14:20:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-03 14:20:16 --> Input Class Initialized
INFO - 2022-02-03 14:20:16 --> Language Class Initialized
INFO - 2022-02-03 14:20:16 --> Loader Class Initialized
INFO - 2022-02-03 14:20:16 --> Helper loaded: url_helper
INFO - 2022-02-03 14:20:16 --> Helper loaded: form_helper
INFO - 2022-02-03 14:20:16 --> Helper loaded: common_helper
INFO - 2022-02-03 14:20:16 --> Database Driver Class Initialized
DEBUG - 2022-02-03 14:20:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-03 14:20:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-03 14:20:16 --> Controller Class Initialized
INFO - 2022-02-03 14:20:16 --> Form Validation Class Initialized
DEBUG - 2022-02-03 14:20:16 --> Encrypt Class Initialized
DEBUG - 2022-02-03 14:20:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-03 14:20:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-03 14:20:16 --> Email Class Initialized
INFO - 2022-02-03 14:20:16 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-03 14:20:16 --> Calendar Class Initialized
INFO - 2022-02-03 14:20:16 --> Model "Login_model" initialized
ERROR - 2022-02-03 14:20:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-03 14:20:16 --> Config Class Initialized
INFO - 2022-02-03 14:20:16 --> Hooks Class Initialized
DEBUG - 2022-02-03 14:20:16 --> UTF-8 Support Enabled
INFO - 2022-02-03 14:20:16 --> Utf8 Class Initialized
INFO - 2022-02-03 14:20:16 --> URI Class Initialized
INFO - 2022-02-03 14:20:16 --> Router Class Initialized
INFO - 2022-02-03 14:20:16 --> Output Class Initialized
INFO - 2022-02-03 14:20:16 --> Security Class Initialized
DEBUG - 2022-02-03 14:20:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-03 14:20:16 --> Input Class Initialized
INFO - 2022-02-03 14:20:16 --> Language Class Initialized
INFO - 2022-02-03 14:20:16 --> Loader Class Initialized
INFO - 2022-02-03 14:20:16 --> Helper loaded: url_helper
INFO - 2022-02-03 14:20:16 --> Helper loaded: form_helper
INFO - 2022-02-03 14:20:16 --> Helper loaded: common_helper
INFO - 2022-02-03 14:20:16 --> Database Driver Class Initialized
DEBUG - 2022-02-03 14:20:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-03 14:20:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-03 14:20:16 --> Controller Class Initialized
INFO - 2022-02-03 14:20:16 --> Form Validation Class Initialized
DEBUG - 2022-02-03 14:20:16 --> Encrypt Class Initialized
DEBUG - 2022-02-03 14:20:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-03 14:20:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-03 14:20:16 --> Email Class Initialized
INFO - 2022-02-03 14:20:16 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-03 14:20:16 --> Calendar Class Initialized
INFO - 2022-02-03 14:20:16 --> Model "Login_model" initialized
ERROR - 2022-02-03 14:20:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-03 14:20:17 --> Config Class Initialized
INFO - 2022-02-03 14:20:17 --> Hooks Class Initialized
DEBUG - 2022-02-03 14:20:17 --> UTF-8 Support Enabled
INFO - 2022-02-03 14:20:17 --> Utf8 Class Initialized
INFO - 2022-02-03 14:20:17 --> URI Class Initialized
INFO - 2022-02-03 14:20:17 --> Router Class Initialized
INFO - 2022-02-03 14:20:17 --> Output Class Initialized
INFO - 2022-02-03 14:20:17 --> Security Class Initialized
DEBUG - 2022-02-03 14:20:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-03 14:20:17 --> Input Class Initialized
INFO - 2022-02-03 14:20:17 --> Language Class Initialized
INFO - 2022-02-03 14:20:17 --> Loader Class Initialized
INFO - 2022-02-03 14:20:17 --> Helper loaded: url_helper
INFO - 2022-02-03 14:20:17 --> Helper loaded: form_helper
INFO - 2022-02-03 14:20:17 --> Helper loaded: common_helper
INFO - 2022-02-03 14:20:17 --> Database Driver Class Initialized
DEBUG - 2022-02-03 14:20:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-03 14:20:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-03 14:20:17 --> Controller Class Initialized
INFO - 2022-02-03 14:20:17 --> Form Validation Class Initialized
DEBUG - 2022-02-03 14:20:17 --> Encrypt Class Initialized
DEBUG - 2022-02-03 14:20:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-03 14:20:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-03 14:20:17 --> Email Class Initialized
INFO - 2022-02-03 14:20:17 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-03 14:20:17 --> Calendar Class Initialized
INFO - 2022-02-03 14:20:17 --> Model "Login_model" initialized
INFO - 2022-02-03 14:20:17 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-03 14:20:17 --> Final output sent to browser
DEBUG - 2022-02-03 14:20:17 --> Total execution time: 0.0350
ERROR - 2022-02-03 17:47:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-03 17:47:39 --> Config Class Initialized
INFO - 2022-02-03 17:47:39 --> Hooks Class Initialized
DEBUG - 2022-02-03 17:47:39 --> UTF-8 Support Enabled
INFO - 2022-02-03 17:47:39 --> Utf8 Class Initialized
INFO - 2022-02-03 17:47:39 --> URI Class Initialized
DEBUG - 2022-02-03 17:47:39 --> No URI present. Default controller set.
INFO - 2022-02-03 17:47:39 --> Router Class Initialized
INFO - 2022-02-03 17:47:39 --> Output Class Initialized
INFO - 2022-02-03 17:47:39 --> Security Class Initialized
DEBUG - 2022-02-03 17:47:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-03 17:47:39 --> Input Class Initialized
INFO - 2022-02-03 17:47:39 --> Language Class Initialized
INFO - 2022-02-03 17:47:39 --> Loader Class Initialized
INFO - 2022-02-03 17:47:39 --> Helper loaded: url_helper
INFO - 2022-02-03 17:47:39 --> Helper loaded: form_helper
INFO - 2022-02-03 17:47:39 --> Helper loaded: common_helper
INFO - 2022-02-03 17:47:39 --> Database Driver Class Initialized
DEBUG - 2022-02-03 17:47:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-03 17:47:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-03 17:47:39 --> Controller Class Initialized
INFO - 2022-02-03 17:47:39 --> Form Validation Class Initialized
DEBUG - 2022-02-03 17:47:39 --> Encrypt Class Initialized
DEBUG - 2022-02-03 17:47:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-03 17:47:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-03 17:47:39 --> Email Class Initialized
INFO - 2022-02-03 17:47:39 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-03 17:47:39 --> Calendar Class Initialized
INFO - 2022-02-03 17:47:39 --> Model "Login_model" initialized
INFO - 2022-02-03 17:47:39 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-03 17:47:39 --> Final output sent to browser
DEBUG - 2022-02-03 17:47:39 --> Total execution time: 0.0290
ERROR - 2022-02-03 19:53:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-03 19:53:18 --> Config Class Initialized
INFO - 2022-02-03 19:53:18 --> Hooks Class Initialized
DEBUG - 2022-02-03 19:53:18 --> UTF-8 Support Enabled
INFO - 2022-02-03 19:53:18 --> Utf8 Class Initialized
INFO - 2022-02-03 19:53:18 --> URI Class Initialized
DEBUG - 2022-02-03 19:53:18 --> No URI present. Default controller set.
INFO - 2022-02-03 19:53:18 --> Router Class Initialized
INFO - 2022-02-03 19:53:18 --> Output Class Initialized
INFO - 2022-02-03 19:53:18 --> Security Class Initialized
DEBUG - 2022-02-03 19:53:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-03 19:53:18 --> Input Class Initialized
INFO - 2022-02-03 19:53:18 --> Language Class Initialized
INFO - 2022-02-03 19:53:18 --> Loader Class Initialized
INFO - 2022-02-03 19:53:18 --> Helper loaded: url_helper
INFO - 2022-02-03 19:53:18 --> Helper loaded: form_helper
INFO - 2022-02-03 19:53:18 --> Helper loaded: common_helper
INFO - 2022-02-03 19:53:18 --> Database Driver Class Initialized
DEBUG - 2022-02-03 19:53:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-03 19:53:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-03 19:53:18 --> Controller Class Initialized
INFO - 2022-02-03 19:53:18 --> Form Validation Class Initialized
DEBUG - 2022-02-03 19:53:18 --> Encrypt Class Initialized
DEBUG - 2022-02-03 19:53:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-03 19:53:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-03 19:53:18 --> Email Class Initialized
INFO - 2022-02-03 19:53:18 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-03 19:53:18 --> Calendar Class Initialized
INFO - 2022-02-03 19:53:18 --> Model "Login_model" initialized
INFO - 2022-02-03 19:53:18 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-03 19:53:18 --> Final output sent to browser
DEBUG - 2022-02-03 19:53:18 --> Total execution time: 0.0258
ERROR - 2022-02-03 20:24:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-03 20:24:18 --> Config Class Initialized
INFO - 2022-02-03 20:24:18 --> Hooks Class Initialized
DEBUG - 2022-02-03 20:24:18 --> UTF-8 Support Enabled
INFO - 2022-02-03 20:24:18 --> Utf8 Class Initialized
INFO - 2022-02-03 20:24:18 --> URI Class Initialized
DEBUG - 2022-02-03 20:24:18 --> No URI present. Default controller set.
INFO - 2022-02-03 20:24:18 --> Router Class Initialized
INFO - 2022-02-03 20:24:18 --> Output Class Initialized
INFO - 2022-02-03 20:24:18 --> Security Class Initialized
DEBUG - 2022-02-03 20:24:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-03 20:24:18 --> Input Class Initialized
INFO - 2022-02-03 20:24:18 --> Language Class Initialized
INFO - 2022-02-03 20:24:18 --> Loader Class Initialized
INFO - 2022-02-03 20:24:18 --> Helper loaded: url_helper
INFO - 2022-02-03 20:24:18 --> Helper loaded: form_helper
INFO - 2022-02-03 20:24:18 --> Helper loaded: common_helper
INFO - 2022-02-03 20:24:18 --> Database Driver Class Initialized
DEBUG - 2022-02-03 20:24:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-03 20:24:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-03 20:24:18 --> Controller Class Initialized
INFO - 2022-02-03 20:24:18 --> Form Validation Class Initialized
DEBUG - 2022-02-03 20:24:18 --> Encrypt Class Initialized
DEBUG - 2022-02-03 20:24:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-03 20:24:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-03 20:24:18 --> Email Class Initialized
INFO - 2022-02-03 20:24:18 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-03 20:24:18 --> Calendar Class Initialized
INFO - 2022-02-03 20:24:18 --> Model "Login_model" initialized
INFO - 2022-02-03 20:24:18 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-03 20:24:18 --> Final output sent to browser
DEBUG - 2022-02-03 20:24:18 --> Total execution time: 0.0227
ERROR - 2022-02-03 20:24:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-03 20:24:19 --> Config Class Initialized
INFO - 2022-02-03 20:24:19 --> Hooks Class Initialized
DEBUG - 2022-02-03 20:24:19 --> UTF-8 Support Enabled
INFO - 2022-02-03 20:24:19 --> Utf8 Class Initialized
INFO - 2022-02-03 20:24:19 --> URI Class Initialized
INFO - 2022-02-03 20:24:19 --> Router Class Initialized
INFO - 2022-02-03 20:24:19 --> Output Class Initialized
INFO - 2022-02-03 20:24:19 --> Security Class Initialized
DEBUG - 2022-02-03 20:24:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-03 20:24:19 --> Input Class Initialized
INFO - 2022-02-03 20:24:19 --> Language Class Initialized
ERROR - 2022-02-03 20:24:19 --> 404 Page Not Found: Blog/wp-includes
ERROR - 2022-02-03 20:24:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-03 20:24:20 --> Config Class Initialized
INFO - 2022-02-03 20:24:20 --> Hooks Class Initialized
DEBUG - 2022-02-03 20:24:20 --> UTF-8 Support Enabled
INFO - 2022-02-03 20:24:20 --> Utf8 Class Initialized
INFO - 2022-02-03 20:24:20 --> URI Class Initialized
INFO - 2022-02-03 20:24:20 --> Router Class Initialized
INFO - 2022-02-03 20:24:20 --> Output Class Initialized
INFO - 2022-02-03 20:24:20 --> Security Class Initialized
DEBUG - 2022-02-03 20:24:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-03 20:24:20 --> Input Class Initialized
INFO - 2022-02-03 20:24:20 --> Language Class Initialized
ERROR - 2022-02-03 20:24:20 --> 404 Page Not Found: Wordpress/wp-includes
ERROR - 2022-02-03 20:24:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-03 20:24:20 --> Config Class Initialized
INFO - 2022-02-03 20:24:20 --> Hooks Class Initialized
DEBUG - 2022-02-03 20:24:20 --> UTF-8 Support Enabled
INFO - 2022-02-03 20:24:20 --> Utf8 Class Initialized
INFO - 2022-02-03 20:24:20 --> URI Class Initialized
INFO - 2022-02-03 20:24:20 --> Router Class Initialized
INFO - 2022-02-03 20:24:20 --> Output Class Initialized
INFO - 2022-02-03 20:24:20 --> Security Class Initialized
DEBUG - 2022-02-03 20:24:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-03 20:24:20 --> Input Class Initialized
INFO - 2022-02-03 20:24:20 --> Language Class Initialized
ERROR - 2022-02-03 20:24:20 --> 404 Page Not Found: Wp/wp-includes
ERROR - 2022-02-03 20:24:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-03 20:24:21 --> Config Class Initialized
INFO - 2022-02-03 20:24:21 --> Hooks Class Initialized
DEBUG - 2022-02-03 20:24:21 --> UTF-8 Support Enabled
INFO - 2022-02-03 20:24:21 --> Utf8 Class Initialized
INFO - 2022-02-03 20:24:21 --> URI Class Initialized
INFO - 2022-02-03 20:24:21 --> Router Class Initialized
INFO - 2022-02-03 20:24:21 --> Output Class Initialized
INFO - 2022-02-03 20:24:21 --> Security Class Initialized
DEBUG - 2022-02-03 20:24:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-03 20:24:21 --> Input Class Initialized
INFO - 2022-02-03 20:24:21 --> Language Class Initialized
ERROR - 2022-02-03 20:24:21 --> 404 Page Not Found: Site/wp-includes
ERROR - 2022-02-03 20:24:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-03 20:24:21 --> Config Class Initialized
INFO - 2022-02-03 20:24:21 --> Hooks Class Initialized
DEBUG - 2022-02-03 20:24:21 --> UTF-8 Support Enabled
INFO - 2022-02-03 20:24:21 --> Utf8 Class Initialized
INFO - 2022-02-03 20:24:21 --> URI Class Initialized
INFO - 2022-02-03 20:24:21 --> Router Class Initialized
INFO - 2022-02-03 20:24:21 --> Output Class Initialized
INFO - 2022-02-03 20:24:21 --> Security Class Initialized
DEBUG - 2022-02-03 20:24:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-03 20:24:21 --> Input Class Initialized
INFO - 2022-02-03 20:24:21 --> Language Class Initialized
ERROR - 2022-02-03 20:24:21 --> 404 Page Not Found: Cms/wp-includes
