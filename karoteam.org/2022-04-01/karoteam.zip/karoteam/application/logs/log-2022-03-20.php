<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-03-20 00:01:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-20 00:01:04 --> Config Class Initialized
INFO - 2022-03-20 00:01:04 --> Hooks Class Initialized
DEBUG - 2022-03-20 00:01:04 --> UTF-8 Support Enabled
INFO - 2022-03-20 00:01:04 --> Utf8 Class Initialized
INFO - 2022-03-20 00:01:04 --> URI Class Initialized
DEBUG - 2022-03-20 00:01:04 --> No URI present. Default controller set.
INFO - 2022-03-20 00:01:04 --> Router Class Initialized
INFO - 2022-03-20 00:01:04 --> Output Class Initialized
INFO - 2022-03-20 00:01:04 --> Security Class Initialized
DEBUG - 2022-03-20 00:01:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-20 00:01:04 --> Input Class Initialized
INFO - 2022-03-20 00:01:04 --> Language Class Initialized
INFO - 2022-03-20 00:01:04 --> Loader Class Initialized
INFO - 2022-03-20 00:01:04 --> Helper loaded: url_helper
INFO - 2022-03-20 00:01:04 --> Helper loaded: form_helper
INFO - 2022-03-20 00:01:04 --> Helper loaded: common_helper
INFO - 2022-03-20 00:01:04 --> Database Driver Class Initialized
DEBUG - 2022-03-20 00:01:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-20 00:01:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-20 00:01:04 --> Controller Class Initialized
INFO - 2022-03-20 00:01:04 --> Form Validation Class Initialized
DEBUG - 2022-03-20 00:01:04 --> Encrypt Class Initialized
DEBUG - 2022-03-20 00:01:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-20 00:01:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-20 00:01:04 --> Email Class Initialized
INFO - 2022-03-20 00:01:04 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-20 00:01:04 --> Calendar Class Initialized
INFO - 2022-03-20 00:01:04 --> Model "Login_model" initialized
INFO - 2022-03-20 00:01:04 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-20 00:01:04 --> Final output sent to browser
DEBUG - 2022-03-20 00:01:04 --> Total execution time: 0.0268
ERROR - 2022-03-20 02:17:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-20 02:17:39 --> Config Class Initialized
INFO - 2022-03-20 02:17:39 --> Hooks Class Initialized
DEBUG - 2022-03-20 02:17:39 --> UTF-8 Support Enabled
INFO - 2022-03-20 02:17:39 --> Utf8 Class Initialized
INFO - 2022-03-20 02:17:39 --> URI Class Initialized
DEBUG - 2022-03-20 02:17:39 --> No URI present. Default controller set.
INFO - 2022-03-20 02:17:39 --> Router Class Initialized
INFO - 2022-03-20 02:17:39 --> Output Class Initialized
INFO - 2022-03-20 02:17:39 --> Security Class Initialized
DEBUG - 2022-03-20 02:17:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-20 02:17:39 --> Input Class Initialized
INFO - 2022-03-20 02:17:39 --> Language Class Initialized
INFO - 2022-03-20 02:17:39 --> Loader Class Initialized
INFO - 2022-03-20 02:17:39 --> Helper loaded: url_helper
INFO - 2022-03-20 02:17:39 --> Helper loaded: form_helper
INFO - 2022-03-20 02:17:39 --> Helper loaded: common_helper
INFO - 2022-03-20 02:17:39 --> Database Driver Class Initialized
DEBUG - 2022-03-20 02:17:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-20 02:17:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-20 02:17:39 --> Controller Class Initialized
INFO - 2022-03-20 02:17:39 --> Form Validation Class Initialized
DEBUG - 2022-03-20 02:17:39 --> Encrypt Class Initialized
DEBUG - 2022-03-20 02:17:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-20 02:17:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-20 02:17:39 --> Email Class Initialized
INFO - 2022-03-20 02:17:39 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-20 02:17:39 --> Calendar Class Initialized
INFO - 2022-03-20 02:17:39 --> Model "Login_model" initialized
INFO - 2022-03-20 02:17:39 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-20 02:17:39 --> Final output sent to browser
DEBUG - 2022-03-20 02:17:39 --> Total execution time: 0.0364
ERROR - 2022-03-20 13:49:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-20 13:49:26 --> Config Class Initialized
INFO - 2022-03-20 13:49:26 --> Hooks Class Initialized
DEBUG - 2022-03-20 13:49:26 --> UTF-8 Support Enabled
INFO - 2022-03-20 13:49:26 --> Utf8 Class Initialized
INFO - 2022-03-20 13:49:26 --> URI Class Initialized
DEBUG - 2022-03-20 13:49:26 --> No URI present. Default controller set.
INFO - 2022-03-20 13:49:26 --> Router Class Initialized
INFO - 2022-03-20 13:49:26 --> Output Class Initialized
INFO - 2022-03-20 13:49:26 --> Security Class Initialized
DEBUG - 2022-03-20 13:49:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-20 13:49:26 --> Input Class Initialized
INFO - 2022-03-20 13:49:26 --> Language Class Initialized
INFO - 2022-03-20 13:49:26 --> Loader Class Initialized
INFO - 2022-03-20 13:49:26 --> Helper loaded: url_helper
INFO - 2022-03-20 13:49:26 --> Helper loaded: form_helper
INFO - 2022-03-20 13:49:26 --> Helper loaded: common_helper
INFO - 2022-03-20 13:49:26 --> Database Driver Class Initialized
DEBUG - 2022-03-20 13:49:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-20 13:49:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-20 13:49:26 --> Controller Class Initialized
INFO - 2022-03-20 13:49:26 --> Form Validation Class Initialized
DEBUG - 2022-03-20 13:49:26 --> Encrypt Class Initialized
DEBUG - 2022-03-20 13:49:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-20 13:49:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-20 13:49:26 --> Email Class Initialized
INFO - 2022-03-20 13:49:26 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-20 13:49:26 --> Calendar Class Initialized
INFO - 2022-03-20 13:49:26 --> Model "Login_model" initialized
INFO - 2022-03-20 13:49:26 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-20 13:49:26 --> Final output sent to browser
DEBUG - 2022-03-20 13:49:26 --> Total execution time: 0.0443
ERROR - 2022-03-20 14:20:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-20 14:20:23 --> Config Class Initialized
INFO - 2022-03-20 14:20:23 --> Hooks Class Initialized
DEBUG - 2022-03-20 14:20:23 --> UTF-8 Support Enabled
INFO - 2022-03-20 14:20:23 --> Utf8 Class Initialized
INFO - 2022-03-20 14:20:23 --> URI Class Initialized
DEBUG - 2022-03-20 14:20:23 --> No URI present. Default controller set.
INFO - 2022-03-20 14:20:23 --> Router Class Initialized
INFO - 2022-03-20 14:20:23 --> Output Class Initialized
INFO - 2022-03-20 14:20:23 --> Security Class Initialized
DEBUG - 2022-03-20 14:20:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-20 14:20:23 --> Input Class Initialized
INFO - 2022-03-20 14:20:23 --> Language Class Initialized
INFO - 2022-03-20 14:20:23 --> Loader Class Initialized
INFO - 2022-03-20 14:20:23 --> Helper loaded: url_helper
INFO - 2022-03-20 14:20:23 --> Helper loaded: form_helper
INFO - 2022-03-20 14:20:23 --> Helper loaded: common_helper
INFO - 2022-03-20 14:20:23 --> Database Driver Class Initialized
DEBUG - 2022-03-20 14:20:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-20 14:20:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-20 14:20:23 --> Controller Class Initialized
INFO - 2022-03-20 14:20:23 --> Form Validation Class Initialized
DEBUG - 2022-03-20 14:20:23 --> Encrypt Class Initialized
DEBUG - 2022-03-20 14:20:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-20 14:20:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-20 14:20:23 --> Email Class Initialized
INFO - 2022-03-20 14:20:23 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-20 14:20:23 --> Calendar Class Initialized
INFO - 2022-03-20 14:20:23 --> Model "Login_model" initialized
INFO - 2022-03-20 14:20:23 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-20 14:20:23 --> Final output sent to browser
DEBUG - 2022-03-20 14:20:23 --> Total execution time: 0.0346
ERROR - 2022-03-20 14:20:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-20 14:20:23 --> Config Class Initialized
INFO - 2022-03-20 14:20:23 --> Hooks Class Initialized
DEBUG - 2022-03-20 14:20:23 --> UTF-8 Support Enabled
INFO - 2022-03-20 14:20:23 --> Utf8 Class Initialized
INFO - 2022-03-20 14:20:23 --> URI Class Initialized
INFO - 2022-03-20 14:20:23 --> Router Class Initialized
INFO - 2022-03-20 14:20:23 --> Output Class Initialized
INFO - 2022-03-20 14:20:23 --> Security Class Initialized
DEBUG - 2022-03-20 14:20:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-20 14:20:23 --> Input Class Initialized
INFO - 2022-03-20 14:20:23 --> Language Class Initialized
ERROR - 2022-03-20 14:20:23 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2022-03-20 14:20:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-20 14:20:35 --> Config Class Initialized
INFO - 2022-03-20 14:20:35 --> Hooks Class Initialized
DEBUG - 2022-03-20 14:20:35 --> UTF-8 Support Enabled
INFO - 2022-03-20 14:20:35 --> Utf8 Class Initialized
INFO - 2022-03-20 14:20:35 --> URI Class Initialized
DEBUG - 2022-03-20 14:20:35 --> No URI present. Default controller set.
INFO - 2022-03-20 14:20:35 --> Router Class Initialized
INFO - 2022-03-20 14:20:35 --> Output Class Initialized
INFO - 2022-03-20 14:20:35 --> Security Class Initialized
DEBUG - 2022-03-20 14:20:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-20 14:20:35 --> Input Class Initialized
INFO - 2022-03-20 14:20:35 --> Language Class Initialized
INFO - 2022-03-20 14:20:35 --> Loader Class Initialized
INFO - 2022-03-20 14:20:35 --> Helper loaded: url_helper
INFO - 2022-03-20 14:20:35 --> Helper loaded: form_helper
INFO - 2022-03-20 14:20:35 --> Helper loaded: common_helper
INFO - 2022-03-20 14:20:35 --> Database Driver Class Initialized
DEBUG - 2022-03-20 14:20:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-20 14:20:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-20 14:20:35 --> Controller Class Initialized
INFO - 2022-03-20 14:20:35 --> Form Validation Class Initialized
DEBUG - 2022-03-20 14:20:35 --> Encrypt Class Initialized
DEBUG - 2022-03-20 14:20:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-20 14:20:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-20 14:20:35 --> Email Class Initialized
INFO - 2022-03-20 14:20:35 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-20 14:20:35 --> Calendar Class Initialized
INFO - 2022-03-20 14:20:35 --> Model "Login_model" initialized
INFO - 2022-03-20 14:20:35 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-20 14:20:35 --> Final output sent to browser
DEBUG - 2022-03-20 14:20:35 --> Total execution time: 0.0350
ERROR - 2022-03-20 14:20:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-20 14:20:36 --> Config Class Initialized
INFO - 2022-03-20 14:20:36 --> Hooks Class Initialized
DEBUG - 2022-03-20 14:20:36 --> UTF-8 Support Enabled
INFO - 2022-03-20 14:20:36 --> Utf8 Class Initialized
INFO - 2022-03-20 14:20:36 --> URI Class Initialized
INFO - 2022-03-20 14:20:36 --> Router Class Initialized
INFO - 2022-03-20 14:20:36 --> Output Class Initialized
INFO - 2022-03-20 14:20:36 --> Security Class Initialized
DEBUG - 2022-03-20 14:20:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-20 14:20:36 --> Input Class Initialized
INFO - 2022-03-20 14:20:36 --> Language Class Initialized
INFO - 2022-03-20 14:20:36 --> Loader Class Initialized
INFO - 2022-03-20 14:20:36 --> Helper loaded: url_helper
INFO - 2022-03-20 14:20:36 --> Helper loaded: form_helper
INFO - 2022-03-20 14:20:36 --> Helper loaded: common_helper
INFO - 2022-03-20 14:20:36 --> Database Driver Class Initialized
DEBUG - 2022-03-20 14:20:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-20 14:20:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-20 14:20:36 --> Controller Class Initialized
INFO - 2022-03-20 14:20:36 --> Form Validation Class Initialized
DEBUG - 2022-03-20 14:20:36 --> Encrypt Class Initialized
DEBUG - 2022-03-20 14:20:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-20 14:20:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-20 14:20:36 --> Email Class Initialized
INFO - 2022-03-20 14:20:36 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-20 14:20:36 --> Calendar Class Initialized
INFO - 2022-03-20 14:20:36 --> Model "Login_model" initialized
ERROR - 2022-03-20 14:20:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-20 14:20:37 --> Config Class Initialized
INFO - 2022-03-20 14:20:37 --> Hooks Class Initialized
DEBUG - 2022-03-20 14:20:37 --> UTF-8 Support Enabled
INFO - 2022-03-20 14:20:37 --> Utf8 Class Initialized
INFO - 2022-03-20 14:20:37 --> URI Class Initialized
INFO - 2022-03-20 14:20:37 --> Router Class Initialized
INFO - 2022-03-20 14:20:37 --> Output Class Initialized
INFO - 2022-03-20 14:20:37 --> Security Class Initialized
DEBUG - 2022-03-20 14:20:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-20 14:20:37 --> Input Class Initialized
INFO - 2022-03-20 14:20:37 --> Language Class Initialized
INFO - 2022-03-20 14:20:37 --> Loader Class Initialized
INFO - 2022-03-20 14:20:37 --> Helper loaded: url_helper
INFO - 2022-03-20 14:20:37 --> Helper loaded: form_helper
INFO - 2022-03-20 14:20:37 --> Helper loaded: common_helper
INFO - 2022-03-20 14:20:37 --> Database Driver Class Initialized
DEBUG - 2022-03-20 14:20:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-20 14:20:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-20 14:20:37 --> Controller Class Initialized
INFO - 2022-03-20 14:20:37 --> Form Validation Class Initialized
DEBUG - 2022-03-20 14:20:37 --> Encrypt Class Initialized
DEBUG - 2022-03-20 14:20:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-20 14:20:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-20 14:20:37 --> Email Class Initialized
INFO - 2022-03-20 14:20:37 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-20 14:20:37 --> Calendar Class Initialized
INFO - 2022-03-20 14:20:37 --> Model "Login_model" initialized
ERROR - 2022-03-20 14:20:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-20 14:20:37 --> Config Class Initialized
INFO - 2022-03-20 14:20:37 --> Hooks Class Initialized
DEBUG - 2022-03-20 14:20:37 --> UTF-8 Support Enabled
INFO - 2022-03-20 14:20:37 --> Utf8 Class Initialized
INFO - 2022-03-20 14:20:37 --> URI Class Initialized
INFO - 2022-03-20 14:20:37 --> Router Class Initialized
INFO - 2022-03-20 14:20:37 --> Output Class Initialized
INFO - 2022-03-20 14:20:37 --> Security Class Initialized
DEBUG - 2022-03-20 14:20:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-20 14:20:37 --> Input Class Initialized
INFO - 2022-03-20 14:20:37 --> Language Class Initialized
INFO - 2022-03-20 14:20:37 --> Loader Class Initialized
INFO - 2022-03-20 14:20:37 --> Helper loaded: url_helper
INFO - 2022-03-20 14:20:37 --> Helper loaded: form_helper
INFO - 2022-03-20 14:20:37 --> Helper loaded: common_helper
INFO - 2022-03-20 14:20:37 --> Database Driver Class Initialized
DEBUG - 2022-03-20 14:20:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-20 14:20:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-20 14:20:37 --> Controller Class Initialized
INFO - 2022-03-20 14:20:37 --> Form Validation Class Initialized
DEBUG - 2022-03-20 14:20:37 --> Encrypt Class Initialized
DEBUG - 2022-03-20 14:20:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-20 14:20:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-20 14:20:37 --> Email Class Initialized
INFO - 2022-03-20 14:20:37 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-20 14:20:37 --> Calendar Class Initialized
INFO - 2022-03-20 14:20:37 --> Model "Login_model" initialized
INFO - 2022-03-20 14:20:37 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-20 14:20:37 --> Final output sent to browser
DEBUG - 2022-03-20 14:20:37 --> Total execution time: 0.0316
ERROR - 2022-03-20 14:49:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-20 14:49:47 --> Config Class Initialized
INFO - 2022-03-20 14:49:47 --> Hooks Class Initialized
DEBUG - 2022-03-20 14:49:47 --> UTF-8 Support Enabled
INFO - 2022-03-20 14:49:47 --> Utf8 Class Initialized
INFO - 2022-03-20 14:49:47 --> URI Class Initialized
DEBUG - 2022-03-20 14:49:47 --> No URI present. Default controller set.
INFO - 2022-03-20 14:49:47 --> Router Class Initialized
INFO - 2022-03-20 14:49:47 --> Output Class Initialized
INFO - 2022-03-20 14:49:47 --> Security Class Initialized
DEBUG - 2022-03-20 14:49:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-20 14:49:47 --> Input Class Initialized
INFO - 2022-03-20 14:49:47 --> Language Class Initialized
INFO - 2022-03-20 14:49:47 --> Loader Class Initialized
INFO - 2022-03-20 14:49:47 --> Helper loaded: url_helper
INFO - 2022-03-20 14:49:47 --> Helper loaded: form_helper
INFO - 2022-03-20 14:49:47 --> Helper loaded: common_helper
INFO - 2022-03-20 14:49:47 --> Database Driver Class Initialized
DEBUG - 2022-03-20 14:49:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-20 14:49:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-20 14:49:47 --> Controller Class Initialized
INFO - 2022-03-20 14:49:47 --> Form Validation Class Initialized
DEBUG - 2022-03-20 14:49:47 --> Encrypt Class Initialized
DEBUG - 2022-03-20 14:49:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-20 14:49:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-20 14:49:47 --> Email Class Initialized
INFO - 2022-03-20 14:49:47 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-20 14:49:47 --> Calendar Class Initialized
INFO - 2022-03-20 14:49:47 --> Model "Login_model" initialized
INFO - 2022-03-20 14:49:47 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-20 14:49:47 --> Final output sent to browser
DEBUG - 2022-03-20 14:49:47 --> Total execution time: 0.0376
ERROR - 2022-03-20 19:15:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-20 19:15:14 --> Config Class Initialized
INFO - 2022-03-20 19:15:14 --> Hooks Class Initialized
DEBUG - 2022-03-20 19:15:14 --> UTF-8 Support Enabled
INFO - 2022-03-20 19:15:14 --> Utf8 Class Initialized
INFO - 2022-03-20 19:15:14 --> URI Class Initialized
DEBUG - 2022-03-20 19:15:14 --> No URI present. Default controller set.
INFO - 2022-03-20 19:15:14 --> Router Class Initialized
INFO - 2022-03-20 19:15:14 --> Output Class Initialized
INFO - 2022-03-20 19:15:14 --> Security Class Initialized
DEBUG - 2022-03-20 19:15:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-20 19:15:14 --> Input Class Initialized
INFO - 2022-03-20 19:15:14 --> Language Class Initialized
INFO - 2022-03-20 19:15:14 --> Loader Class Initialized
INFO - 2022-03-20 19:15:14 --> Helper loaded: url_helper
INFO - 2022-03-20 19:15:14 --> Helper loaded: form_helper
INFO - 2022-03-20 19:15:14 --> Helper loaded: common_helper
INFO - 2022-03-20 19:15:14 --> Database Driver Class Initialized
DEBUG - 2022-03-20 19:15:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-20 19:15:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-20 19:15:14 --> Controller Class Initialized
INFO - 2022-03-20 19:15:14 --> Form Validation Class Initialized
DEBUG - 2022-03-20 19:15:14 --> Encrypt Class Initialized
DEBUG - 2022-03-20 19:15:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-20 19:15:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-20 19:15:14 --> Email Class Initialized
INFO - 2022-03-20 19:15:14 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-20 19:15:14 --> Calendar Class Initialized
INFO - 2022-03-20 19:15:14 --> Model "Login_model" initialized
INFO - 2022-03-20 19:15:14 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-20 19:15:14 --> Final output sent to browser
DEBUG - 2022-03-20 19:15:14 --> Total execution time: 0.0367
