<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-07-23 03:30:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-23 03:30:58 --> Config Class Initialized
INFO - 2021-07-23 03:30:58 --> Hooks Class Initialized
DEBUG - 2021-07-23 03:30:58 --> UTF-8 Support Enabled
INFO - 2021-07-23 03:30:58 --> Utf8 Class Initialized
INFO - 2021-07-23 03:30:58 --> URI Class Initialized
INFO - 2021-07-23 03:30:58 --> Router Class Initialized
INFO - 2021-07-23 03:30:58 --> Output Class Initialized
INFO - 2021-07-23 03:30:58 --> Security Class Initialized
DEBUG - 2021-07-23 03:30:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-23 03:30:58 --> Input Class Initialized
INFO - 2021-07-23 03:30:58 --> Language Class Initialized
ERROR - 2021-07-23 03:30:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-23 03:34:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-23 03:34:04 --> Config Class Initialized
INFO - 2021-07-23 03:34:04 --> Hooks Class Initialized
DEBUG - 2021-07-23 03:34:04 --> UTF-8 Support Enabled
INFO - 2021-07-23 03:34:04 --> Utf8 Class Initialized
INFO - 2021-07-23 03:34:04 --> URI Class Initialized
INFO - 2021-07-23 03:34:04 --> Router Class Initialized
INFO - 2021-07-23 03:34:04 --> Output Class Initialized
INFO - 2021-07-23 03:34:04 --> Security Class Initialized
DEBUG - 2021-07-23 03:34:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-23 03:34:04 --> Input Class Initialized
INFO - 2021-07-23 03:34:04 --> Language Class Initialized
ERROR - 2021-07-23 03:34:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-23 03:38:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-23 03:38:24 --> Config Class Initialized
INFO - 2021-07-23 03:38:24 --> Hooks Class Initialized
DEBUG - 2021-07-23 03:38:24 --> UTF-8 Support Enabled
INFO - 2021-07-23 03:38:24 --> Utf8 Class Initialized
INFO - 2021-07-23 03:38:24 --> URI Class Initialized
INFO - 2021-07-23 03:38:24 --> Router Class Initialized
INFO - 2021-07-23 03:38:24 --> Output Class Initialized
INFO - 2021-07-23 03:38:24 --> Security Class Initialized
DEBUG - 2021-07-23 03:38:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-23 03:38:24 --> Input Class Initialized
INFO - 2021-07-23 03:38:24 --> Language Class Initialized
ERROR - 2021-07-23 03:38:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-23 06:38:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-23 06:38:15 --> Config Class Initialized
INFO - 2021-07-23 06:38:15 --> Hooks Class Initialized
DEBUG - 2021-07-23 06:38:15 --> UTF-8 Support Enabled
INFO - 2021-07-23 06:38:15 --> Utf8 Class Initialized
INFO - 2021-07-23 06:38:15 --> URI Class Initialized
INFO - 2021-07-23 06:38:15 --> Router Class Initialized
INFO - 2021-07-23 06:38:15 --> Output Class Initialized
INFO - 2021-07-23 06:38:15 --> Security Class Initialized
DEBUG - 2021-07-23 06:38:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-23 06:38:15 --> Input Class Initialized
INFO - 2021-07-23 06:38:15 --> Language Class Initialized
ERROR - 2021-07-23 06:38:15 --> 404 Page Not Found: Wp-content/uploads
ERROR - 2021-07-23 06:50:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-23 06:50:19 --> Config Class Initialized
INFO - 2021-07-23 06:50:19 --> Hooks Class Initialized
DEBUG - 2021-07-23 06:50:19 --> UTF-8 Support Enabled
INFO - 2021-07-23 06:50:19 --> Utf8 Class Initialized
INFO - 2021-07-23 06:50:19 --> URI Class Initialized
INFO - 2021-07-23 06:50:19 --> Router Class Initialized
INFO - 2021-07-23 06:50:19 --> Output Class Initialized
INFO - 2021-07-23 06:50:19 --> Security Class Initialized
DEBUG - 2021-07-23 06:50:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-23 06:50:19 --> Input Class Initialized
INFO - 2021-07-23 06:50:19 --> Language Class Initialized
ERROR - 2021-07-23 06:50:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-23 07:54:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-23 07:54:12 --> Config Class Initialized
INFO - 2021-07-23 07:54:12 --> Hooks Class Initialized
DEBUG - 2021-07-23 07:54:12 --> UTF-8 Support Enabled
INFO - 2021-07-23 07:54:12 --> Utf8 Class Initialized
INFO - 2021-07-23 07:54:12 --> URI Class Initialized
DEBUG - 2021-07-23 07:54:12 --> No URI present. Default controller set.
INFO - 2021-07-23 07:54:12 --> Router Class Initialized
INFO - 2021-07-23 07:54:12 --> Output Class Initialized
INFO - 2021-07-23 07:54:12 --> Security Class Initialized
DEBUG - 2021-07-23 07:54:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-23 07:54:12 --> Input Class Initialized
INFO - 2021-07-23 07:54:12 --> Language Class Initialized
INFO - 2021-07-23 07:54:12 --> Loader Class Initialized
INFO - 2021-07-23 07:54:12 --> Helper loaded: url_helper
INFO - 2021-07-23 07:54:12 --> Helper loaded: form_helper
INFO - 2021-07-23 07:54:12 --> Helper loaded: common_helper
INFO - 2021-07-23 07:54:12 --> Database Driver Class Initialized
DEBUG - 2021-07-23 07:54:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-23 07:54:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-23 07:54:12 --> Controller Class Initialized
INFO - 2021-07-23 07:54:12 --> Form Validation Class Initialized
DEBUG - 2021-07-23 07:54:12 --> Encrypt Class Initialized
DEBUG - 2021-07-23 07:54:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-07-23 07:54:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-07-23 07:54:12 --> Email Class Initialized
INFO - 2021-07-23 07:54:12 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-07-23 07:54:12 --> Calendar Class Initialized
INFO - 2021-07-23 07:54:12 --> Model "Login_model" initialized
INFO - 2021-07-23 07:54:12 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-07-23 07:54:12 --> Final output sent to browser
DEBUG - 2021-07-23 07:54:12 --> Total execution time: 0.0674
ERROR - 2021-07-23 22:06:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-23 22:06:52 --> Config Class Initialized
INFO - 2021-07-23 22:06:52 --> Hooks Class Initialized
DEBUG - 2021-07-23 22:06:52 --> UTF-8 Support Enabled
INFO - 2021-07-23 22:06:52 --> Utf8 Class Initialized
INFO - 2021-07-23 22:06:52 --> URI Class Initialized
DEBUG - 2021-07-23 22:06:52 --> No URI present. Default controller set.
INFO - 2021-07-23 22:06:52 --> Router Class Initialized
INFO - 2021-07-23 22:06:52 --> Output Class Initialized
INFO - 2021-07-23 22:06:52 --> Security Class Initialized
DEBUG - 2021-07-23 22:06:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-23 22:06:52 --> Input Class Initialized
INFO - 2021-07-23 22:06:52 --> Language Class Initialized
INFO - 2021-07-23 22:06:52 --> Loader Class Initialized
INFO - 2021-07-23 22:06:52 --> Helper loaded: url_helper
INFO - 2021-07-23 22:06:52 --> Helper loaded: form_helper
INFO - 2021-07-23 22:06:52 --> Helper loaded: common_helper
INFO - 2021-07-23 22:06:52 --> Database Driver Class Initialized
DEBUG - 2021-07-23 22:06:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-23 22:06:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-23 22:06:52 --> Controller Class Initialized
INFO - 2021-07-23 22:06:52 --> Form Validation Class Initialized
DEBUG - 2021-07-23 22:06:52 --> Encrypt Class Initialized
DEBUG - 2021-07-23 22:06:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-07-23 22:06:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-07-23 22:06:52 --> Email Class Initialized
INFO - 2021-07-23 22:06:52 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-07-23 22:06:52 --> Calendar Class Initialized
INFO - 2021-07-23 22:06:52 --> Model "Login_model" initialized
INFO - 2021-07-23 22:06:52 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-07-23 22:06:52 --> Final output sent to browser
DEBUG - 2021-07-23 22:06:52 --> Total execution time: 0.0523
ERROR - 2021-07-23 22:38:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-23 22:38:18 --> Config Class Initialized
INFO - 2021-07-23 22:38:18 --> Hooks Class Initialized
DEBUG - 2021-07-23 22:38:18 --> UTF-8 Support Enabled
INFO - 2021-07-23 22:38:18 --> Utf8 Class Initialized
INFO - 2021-07-23 22:38:18 --> URI Class Initialized
DEBUG - 2021-07-23 22:38:18 --> No URI present. Default controller set.
INFO - 2021-07-23 22:38:18 --> Router Class Initialized
INFO - 2021-07-23 22:38:18 --> Output Class Initialized
INFO - 2021-07-23 22:38:18 --> Security Class Initialized
DEBUG - 2021-07-23 22:38:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-23 22:38:18 --> Input Class Initialized
INFO - 2021-07-23 22:38:18 --> Language Class Initialized
INFO - 2021-07-23 22:38:18 --> Loader Class Initialized
INFO - 2021-07-23 22:38:18 --> Helper loaded: url_helper
INFO - 2021-07-23 22:38:18 --> Helper loaded: form_helper
INFO - 2021-07-23 22:38:18 --> Helper loaded: common_helper
INFO - 2021-07-23 22:38:18 --> Database Driver Class Initialized
DEBUG - 2021-07-23 22:38:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-23 22:38:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-23 22:38:18 --> Controller Class Initialized
INFO - 2021-07-23 22:38:18 --> Form Validation Class Initialized
DEBUG - 2021-07-23 22:38:18 --> Encrypt Class Initialized
DEBUG - 2021-07-23 22:38:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-07-23 22:38:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-07-23 22:38:18 --> Email Class Initialized
INFO - 2021-07-23 22:38:18 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-07-23 22:38:18 --> Calendar Class Initialized
INFO - 2021-07-23 22:38:18 --> Model "Login_model" initialized
INFO - 2021-07-23 22:38:18 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-07-23 22:38:18 --> Final output sent to browser
DEBUG - 2021-07-23 22:38:18 --> Total execution time: 0.0655
ERROR - 2021-07-23 22:51:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-23 22:51:17 --> Config Class Initialized
INFO - 2021-07-23 22:51:17 --> Hooks Class Initialized
DEBUG - 2021-07-23 22:51:17 --> UTF-8 Support Enabled
INFO - 2021-07-23 22:51:17 --> Utf8 Class Initialized
INFO - 2021-07-23 22:51:17 --> URI Class Initialized
DEBUG - 2021-07-23 22:51:17 --> No URI present. Default controller set.
INFO - 2021-07-23 22:51:17 --> Router Class Initialized
INFO - 2021-07-23 22:51:17 --> Output Class Initialized
INFO - 2021-07-23 22:51:17 --> Security Class Initialized
DEBUG - 2021-07-23 22:51:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-23 22:51:17 --> Input Class Initialized
INFO - 2021-07-23 22:51:17 --> Language Class Initialized
INFO - 2021-07-23 22:51:17 --> Loader Class Initialized
INFO - 2021-07-23 22:51:17 --> Helper loaded: url_helper
INFO - 2021-07-23 22:51:17 --> Helper loaded: form_helper
INFO - 2021-07-23 22:51:17 --> Helper loaded: common_helper
INFO - 2021-07-23 22:51:17 --> Database Driver Class Initialized
DEBUG - 2021-07-23 22:51:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-23 22:51:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-23 22:51:17 --> Controller Class Initialized
INFO - 2021-07-23 22:51:17 --> Form Validation Class Initialized
DEBUG - 2021-07-23 22:51:17 --> Encrypt Class Initialized
DEBUG - 2021-07-23 22:51:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-07-23 22:51:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-07-23 22:51:17 --> Email Class Initialized
INFO - 2021-07-23 22:51:17 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-07-23 22:51:17 --> Calendar Class Initialized
INFO - 2021-07-23 22:51:17 --> Model "Login_model" initialized
INFO - 2021-07-23 22:51:17 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-07-23 22:51:17 --> Final output sent to browser
DEBUG - 2021-07-23 22:51:17 --> Total execution time: 0.0201
