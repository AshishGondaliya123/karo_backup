<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-02-01 06:40:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-01 06:40:33 --> Config Class Initialized
INFO - 2022-02-01 06:40:33 --> Hooks Class Initialized
DEBUG - 2022-02-01 06:40:33 --> UTF-8 Support Enabled
INFO - 2022-02-01 06:40:33 --> Utf8 Class Initialized
INFO - 2022-02-01 06:40:33 --> URI Class Initialized
DEBUG - 2022-02-01 06:40:33 --> No URI present. Default controller set.
INFO - 2022-02-01 06:40:33 --> Router Class Initialized
INFO - 2022-02-01 06:40:33 --> Output Class Initialized
INFO - 2022-02-01 06:40:33 --> Security Class Initialized
DEBUG - 2022-02-01 06:40:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-01 06:40:33 --> Input Class Initialized
INFO - 2022-02-01 06:40:33 --> Language Class Initialized
INFO - 2022-02-01 06:40:33 --> Loader Class Initialized
INFO - 2022-02-01 06:40:33 --> Helper loaded: url_helper
INFO - 2022-02-01 06:40:33 --> Helper loaded: form_helper
INFO - 2022-02-01 06:40:33 --> Helper loaded: common_helper
INFO - 2022-02-01 06:40:33 --> Database Driver Class Initialized
DEBUG - 2022-02-01 06:40:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-01 06:40:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-01 06:40:33 --> Controller Class Initialized
INFO - 2022-02-01 06:40:33 --> Form Validation Class Initialized
DEBUG - 2022-02-01 06:40:33 --> Encrypt Class Initialized
DEBUG - 2022-02-01 06:40:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-01 06:40:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-01 06:40:33 --> Email Class Initialized
INFO - 2022-02-01 06:40:33 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-01 06:40:33 --> Calendar Class Initialized
INFO - 2022-02-01 06:40:33 --> Model "Login_model" initialized
INFO - 2022-02-01 06:40:33 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-01 06:40:33 --> Final output sent to browser
DEBUG - 2022-02-01 06:40:33 --> Total execution time: 0.0258
ERROR - 2022-02-01 08:00:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-01 08:00:37 --> Config Class Initialized
INFO - 2022-02-01 08:00:37 --> Hooks Class Initialized
DEBUG - 2022-02-01 08:00:37 --> UTF-8 Support Enabled
INFO - 2022-02-01 08:00:37 --> Utf8 Class Initialized
INFO - 2022-02-01 08:00:37 --> URI Class Initialized
DEBUG - 2022-02-01 08:00:37 --> No URI present. Default controller set.
INFO - 2022-02-01 08:00:37 --> Router Class Initialized
INFO - 2022-02-01 08:00:37 --> Output Class Initialized
INFO - 2022-02-01 08:00:37 --> Security Class Initialized
DEBUG - 2022-02-01 08:00:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-01 08:00:37 --> Input Class Initialized
INFO - 2022-02-01 08:00:37 --> Language Class Initialized
INFO - 2022-02-01 08:00:37 --> Loader Class Initialized
INFO - 2022-02-01 08:00:37 --> Helper loaded: url_helper
INFO - 2022-02-01 08:00:37 --> Helper loaded: form_helper
INFO - 2022-02-01 08:00:37 --> Helper loaded: common_helper
INFO - 2022-02-01 08:00:37 --> Database Driver Class Initialized
DEBUG - 2022-02-01 08:00:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-01 08:00:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-01 08:00:37 --> Controller Class Initialized
INFO - 2022-02-01 08:00:37 --> Form Validation Class Initialized
DEBUG - 2022-02-01 08:00:37 --> Encrypt Class Initialized
DEBUG - 2022-02-01 08:00:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-01 08:00:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-01 08:00:37 --> Email Class Initialized
INFO - 2022-02-01 08:00:37 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-01 08:00:37 --> Calendar Class Initialized
INFO - 2022-02-01 08:00:37 --> Model "Login_model" initialized
INFO - 2022-02-01 08:00:37 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-01 08:00:37 --> Final output sent to browser
DEBUG - 2022-02-01 08:00:37 --> Total execution time: 0.0366
ERROR - 2022-02-01 08:35:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-01 08:35:31 --> Config Class Initialized
INFO - 2022-02-01 08:35:31 --> Hooks Class Initialized
DEBUG - 2022-02-01 08:35:31 --> UTF-8 Support Enabled
INFO - 2022-02-01 08:35:31 --> Utf8 Class Initialized
INFO - 2022-02-01 08:35:31 --> URI Class Initialized
DEBUG - 2022-02-01 08:35:31 --> No URI present. Default controller set.
INFO - 2022-02-01 08:35:31 --> Router Class Initialized
INFO - 2022-02-01 08:35:31 --> Output Class Initialized
INFO - 2022-02-01 08:35:31 --> Security Class Initialized
DEBUG - 2022-02-01 08:35:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-01 08:35:31 --> Input Class Initialized
INFO - 2022-02-01 08:35:31 --> Language Class Initialized
INFO - 2022-02-01 08:35:31 --> Loader Class Initialized
INFO - 2022-02-01 08:35:31 --> Helper loaded: url_helper
INFO - 2022-02-01 08:35:31 --> Helper loaded: form_helper
INFO - 2022-02-01 08:35:31 --> Helper loaded: common_helper
INFO - 2022-02-01 08:35:31 --> Database Driver Class Initialized
DEBUG - 2022-02-01 08:35:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-01 08:35:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-01 08:35:31 --> Controller Class Initialized
INFO - 2022-02-01 08:35:31 --> Form Validation Class Initialized
DEBUG - 2022-02-01 08:35:31 --> Encrypt Class Initialized
DEBUG - 2022-02-01 08:35:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-01 08:35:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-01 08:35:31 --> Email Class Initialized
INFO - 2022-02-01 08:35:31 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-01 08:35:31 --> Calendar Class Initialized
INFO - 2022-02-01 08:35:31 --> Model "Login_model" initialized
INFO - 2022-02-01 08:35:31 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-01 08:35:31 --> Final output sent to browser
DEBUG - 2022-02-01 08:35:31 --> Total execution time: 0.0354
ERROR - 2022-02-01 09:09:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-01 09:09:45 --> Config Class Initialized
INFO - 2022-02-01 09:09:45 --> Hooks Class Initialized
DEBUG - 2022-02-01 09:09:45 --> UTF-8 Support Enabled
INFO - 2022-02-01 09:09:45 --> Utf8 Class Initialized
INFO - 2022-02-01 09:09:45 --> URI Class Initialized
DEBUG - 2022-02-01 09:09:45 --> No URI present. Default controller set.
INFO - 2022-02-01 09:09:45 --> Router Class Initialized
INFO - 2022-02-01 09:09:45 --> Output Class Initialized
INFO - 2022-02-01 09:09:45 --> Security Class Initialized
DEBUG - 2022-02-01 09:09:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-01 09:09:45 --> Input Class Initialized
INFO - 2022-02-01 09:09:45 --> Language Class Initialized
INFO - 2022-02-01 09:09:45 --> Loader Class Initialized
INFO - 2022-02-01 09:09:45 --> Helper loaded: url_helper
INFO - 2022-02-01 09:09:45 --> Helper loaded: form_helper
INFO - 2022-02-01 09:09:45 --> Helper loaded: common_helper
INFO - 2022-02-01 09:09:45 --> Database Driver Class Initialized
DEBUG - 2022-02-01 09:09:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-01 09:09:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-01 09:09:45 --> Controller Class Initialized
INFO - 2022-02-01 09:09:45 --> Form Validation Class Initialized
DEBUG - 2022-02-01 09:09:45 --> Encrypt Class Initialized
DEBUG - 2022-02-01 09:09:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-01 09:09:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-01 09:09:45 --> Email Class Initialized
INFO - 2022-02-01 09:09:45 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-01 09:09:45 --> Calendar Class Initialized
INFO - 2022-02-01 09:09:45 --> Model "Login_model" initialized
INFO - 2022-02-01 09:09:45 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-01 09:09:45 --> Final output sent to browser
DEBUG - 2022-02-01 09:09:45 --> Total execution time: 0.0228
ERROR - 2022-02-01 10:11:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-01 10:11:51 --> Config Class Initialized
INFO - 2022-02-01 10:11:51 --> Hooks Class Initialized
DEBUG - 2022-02-01 10:11:51 --> UTF-8 Support Enabled
INFO - 2022-02-01 10:11:51 --> Utf8 Class Initialized
INFO - 2022-02-01 10:11:51 --> URI Class Initialized
DEBUG - 2022-02-01 10:11:51 --> No URI present. Default controller set.
INFO - 2022-02-01 10:11:51 --> Router Class Initialized
INFO - 2022-02-01 10:11:51 --> Output Class Initialized
INFO - 2022-02-01 10:11:51 --> Security Class Initialized
DEBUG - 2022-02-01 10:11:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-01 10:11:51 --> Input Class Initialized
INFO - 2022-02-01 10:11:51 --> Language Class Initialized
INFO - 2022-02-01 10:11:51 --> Loader Class Initialized
INFO - 2022-02-01 10:11:51 --> Helper loaded: url_helper
INFO - 2022-02-01 10:11:51 --> Helper loaded: form_helper
INFO - 2022-02-01 10:11:51 --> Helper loaded: common_helper
INFO - 2022-02-01 10:11:51 --> Database Driver Class Initialized
DEBUG - 2022-02-01 10:11:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-01 10:11:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-01 10:11:51 --> Controller Class Initialized
INFO - 2022-02-01 10:11:51 --> Form Validation Class Initialized
DEBUG - 2022-02-01 10:11:51 --> Encrypt Class Initialized
DEBUG - 2022-02-01 10:11:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-01 10:11:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-01 10:11:51 --> Email Class Initialized
INFO - 2022-02-01 10:11:51 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-01 10:11:51 --> Calendar Class Initialized
INFO - 2022-02-01 10:11:51 --> Model "Login_model" initialized
INFO - 2022-02-01 10:11:51 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-01 10:11:51 --> Final output sent to browser
DEBUG - 2022-02-01 10:11:51 --> Total execution time: 0.0324
ERROR - 2022-02-01 10:12:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-01 10:12:24 --> Config Class Initialized
INFO - 2022-02-01 10:12:24 --> Hooks Class Initialized
DEBUG - 2022-02-01 10:12:24 --> UTF-8 Support Enabled
INFO - 2022-02-01 10:12:24 --> Utf8 Class Initialized
INFO - 2022-02-01 10:12:24 --> URI Class Initialized
DEBUG - 2022-02-01 10:12:24 --> No URI present. Default controller set.
INFO - 2022-02-01 10:12:24 --> Router Class Initialized
INFO - 2022-02-01 10:12:24 --> Output Class Initialized
INFO - 2022-02-01 10:12:24 --> Security Class Initialized
DEBUG - 2022-02-01 10:12:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-01 10:12:24 --> Input Class Initialized
INFO - 2022-02-01 10:12:24 --> Language Class Initialized
INFO - 2022-02-01 10:12:24 --> Loader Class Initialized
INFO - 2022-02-01 10:12:24 --> Helper loaded: url_helper
INFO - 2022-02-01 10:12:24 --> Helper loaded: form_helper
INFO - 2022-02-01 10:12:24 --> Helper loaded: common_helper
INFO - 2022-02-01 10:12:24 --> Database Driver Class Initialized
DEBUG - 2022-02-01 10:12:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-01 10:12:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-01 10:12:24 --> Controller Class Initialized
INFO - 2022-02-01 10:12:24 --> Form Validation Class Initialized
DEBUG - 2022-02-01 10:12:24 --> Encrypt Class Initialized
DEBUG - 2022-02-01 10:12:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-01 10:12:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-01 10:12:24 --> Email Class Initialized
INFO - 2022-02-01 10:12:24 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-01 10:12:24 --> Calendar Class Initialized
INFO - 2022-02-01 10:12:24 --> Model "Login_model" initialized
INFO - 2022-02-01 10:12:24 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-01 10:12:24 --> Final output sent to browser
DEBUG - 2022-02-01 10:12:24 --> Total execution time: 0.0433
ERROR - 2022-02-01 14:21:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-01 14:21:33 --> Config Class Initialized
INFO - 2022-02-01 14:21:33 --> Hooks Class Initialized
DEBUG - 2022-02-01 14:21:33 --> UTF-8 Support Enabled
INFO - 2022-02-01 14:21:33 --> Utf8 Class Initialized
INFO - 2022-02-01 14:21:33 --> URI Class Initialized
DEBUG - 2022-02-01 14:21:33 --> No URI present. Default controller set.
INFO - 2022-02-01 14:21:33 --> Router Class Initialized
INFO - 2022-02-01 14:21:33 --> Output Class Initialized
INFO - 2022-02-01 14:21:33 --> Security Class Initialized
DEBUG - 2022-02-01 14:21:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-01 14:21:33 --> Input Class Initialized
INFO - 2022-02-01 14:21:33 --> Language Class Initialized
INFO - 2022-02-01 14:21:33 --> Loader Class Initialized
INFO - 2022-02-01 14:21:33 --> Helper loaded: url_helper
INFO - 2022-02-01 14:21:33 --> Helper loaded: form_helper
INFO - 2022-02-01 14:21:33 --> Helper loaded: common_helper
INFO - 2022-02-01 14:21:33 --> Database Driver Class Initialized
DEBUG - 2022-02-01 14:21:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-01 14:21:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-01 14:21:33 --> Controller Class Initialized
INFO - 2022-02-01 14:21:33 --> Form Validation Class Initialized
DEBUG - 2022-02-01 14:21:33 --> Encrypt Class Initialized
DEBUG - 2022-02-01 14:21:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-01 14:21:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-01 14:21:33 --> Email Class Initialized
INFO - 2022-02-01 14:21:33 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-01 14:21:33 --> Calendar Class Initialized
INFO - 2022-02-01 14:21:33 --> Model "Login_model" initialized
INFO - 2022-02-01 14:21:33 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-01 14:21:33 --> Final output sent to browser
DEBUG - 2022-02-01 14:21:33 --> Total execution time: 0.1790
ERROR - 2022-02-01 14:21:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-01 14:21:35 --> Config Class Initialized
INFO - 2022-02-01 14:21:35 --> Hooks Class Initialized
DEBUG - 2022-02-01 14:21:35 --> UTF-8 Support Enabled
INFO - 2022-02-01 14:21:35 --> Utf8 Class Initialized
INFO - 2022-02-01 14:21:35 --> URI Class Initialized
INFO - 2022-02-01 14:21:35 --> Router Class Initialized
INFO - 2022-02-01 14:21:35 --> Output Class Initialized
INFO - 2022-02-01 14:21:35 --> Security Class Initialized
DEBUG - 2022-02-01 14:21:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-01 14:21:35 --> Input Class Initialized
INFO - 2022-02-01 14:21:35 --> Language Class Initialized
ERROR - 2022-02-01 14:21:35 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2022-02-01 14:21:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-01 14:21:46 --> Config Class Initialized
INFO - 2022-02-01 14:21:46 --> Hooks Class Initialized
DEBUG - 2022-02-01 14:21:46 --> UTF-8 Support Enabled
INFO - 2022-02-01 14:21:46 --> Utf8 Class Initialized
INFO - 2022-02-01 14:21:46 --> URI Class Initialized
DEBUG - 2022-02-01 14:21:46 --> No URI present. Default controller set.
INFO - 2022-02-01 14:21:46 --> Router Class Initialized
INFO - 2022-02-01 14:21:46 --> Output Class Initialized
INFO - 2022-02-01 14:21:46 --> Security Class Initialized
DEBUG - 2022-02-01 14:21:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-01 14:21:46 --> Input Class Initialized
INFO - 2022-02-01 14:21:46 --> Language Class Initialized
INFO - 2022-02-01 14:21:46 --> Loader Class Initialized
INFO - 2022-02-01 14:21:46 --> Helper loaded: url_helper
INFO - 2022-02-01 14:21:46 --> Helper loaded: form_helper
INFO - 2022-02-01 14:21:46 --> Helper loaded: common_helper
INFO - 2022-02-01 14:21:46 --> Database Driver Class Initialized
DEBUG - 2022-02-01 14:21:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-01 14:21:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-01 14:21:46 --> Controller Class Initialized
INFO - 2022-02-01 14:21:46 --> Form Validation Class Initialized
DEBUG - 2022-02-01 14:21:46 --> Encrypt Class Initialized
DEBUG - 2022-02-01 14:21:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-01 14:21:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-01 14:21:46 --> Email Class Initialized
INFO - 2022-02-01 14:21:46 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-01 14:21:46 --> Calendar Class Initialized
INFO - 2022-02-01 14:21:46 --> Model "Login_model" initialized
INFO - 2022-02-01 14:21:46 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-01 14:21:46 --> Final output sent to browser
DEBUG - 2022-02-01 14:21:46 --> Total execution time: 0.0727
ERROR - 2022-02-01 14:21:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-01 14:21:47 --> Config Class Initialized
INFO - 2022-02-01 14:21:47 --> Hooks Class Initialized
DEBUG - 2022-02-01 14:21:47 --> UTF-8 Support Enabled
INFO - 2022-02-01 14:21:47 --> Utf8 Class Initialized
INFO - 2022-02-01 14:21:47 --> URI Class Initialized
INFO - 2022-02-01 14:21:47 --> Router Class Initialized
INFO - 2022-02-01 14:21:47 --> Output Class Initialized
INFO - 2022-02-01 14:21:47 --> Security Class Initialized
DEBUG - 2022-02-01 14:21:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-01 14:21:47 --> Input Class Initialized
INFO - 2022-02-01 14:21:47 --> Language Class Initialized
INFO - 2022-02-01 14:21:47 --> Loader Class Initialized
INFO - 2022-02-01 14:21:47 --> Helper loaded: url_helper
INFO - 2022-02-01 14:21:47 --> Helper loaded: form_helper
INFO - 2022-02-01 14:21:47 --> Helper loaded: common_helper
INFO - 2022-02-01 14:21:47 --> Database Driver Class Initialized
DEBUG - 2022-02-01 14:21:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-01 14:21:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-01 14:21:47 --> Controller Class Initialized
INFO - 2022-02-01 14:21:47 --> Form Validation Class Initialized
DEBUG - 2022-02-01 14:21:47 --> Encrypt Class Initialized
DEBUG - 2022-02-01 14:21:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-01 14:21:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-01 14:21:47 --> Email Class Initialized
INFO - 2022-02-01 14:21:47 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-01 14:21:47 --> Calendar Class Initialized
INFO - 2022-02-01 14:21:47 --> Model "Login_model" initialized
ERROR - 2022-02-01 14:21:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-01 14:21:48 --> Config Class Initialized
INFO - 2022-02-01 14:21:48 --> Hooks Class Initialized
DEBUG - 2022-02-01 14:21:48 --> UTF-8 Support Enabled
INFO - 2022-02-01 14:21:48 --> Utf8 Class Initialized
INFO - 2022-02-01 14:21:48 --> URI Class Initialized
INFO - 2022-02-01 14:21:48 --> Router Class Initialized
INFO - 2022-02-01 14:21:48 --> Output Class Initialized
INFO - 2022-02-01 14:21:48 --> Security Class Initialized
DEBUG - 2022-02-01 14:21:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-01 14:21:48 --> Input Class Initialized
INFO - 2022-02-01 14:21:48 --> Language Class Initialized
INFO - 2022-02-01 14:21:48 --> Loader Class Initialized
INFO - 2022-02-01 14:21:48 --> Helper loaded: url_helper
INFO - 2022-02-01 14:21:48 --> Helper loaded: form_helper
INFO - 2022-02-01 14:21:48 --> Helper loaded: common_helper
INFO - 2022-02-01 14:21:48 --> Database Driver Class Initialized
DEBUG - 2022-02-01 14:21:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-01 14:21:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-01 14:21:48 --> Controller Class Initialized
INFO - 2022-02-01 14:21:48 --> Form Validation Class Initialized
DEBUG - 2022-02-01 14:21:48 --> Encrypt Class Initialized
DEBUG - 2022-02-01 14:21:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-01 14:21:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-01 14:21:48 --> Email Class Initialized
INFO - 2022-02-01 14:21:48 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-01 14:21:48 --> Calendar Class Initialized
INFO - 2022-02-01 14:21:48 --> Model "Login_model" initialized
ERROR - 2022-02-01 14:21:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-01 14:21:49 --> Config Class Initialized
INFO - 2022-02-01 14:21:49 --> Hooks Class Initialized
DEBUG - 2022-02-01 14:21:49 --> UTF-8 Support Enabled
INFO - 2022-02-01 14:21:49 --> Utf8 Class Initialized
INFO - 2022-02-01 14:21:49 --> URI Class Initialized
INFO - 2022-02-01 14:21:49 --> Router Class Initialized
INFO - 2022-02-01 14:21:49 --> Output Class Initialized
INFO - 2022-02-01 14:21:49 --> Security Class Initialized
DEBUG - 2022-02-01 14:21:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-01 14:21:49 --> Input Class Initialized
INFO - 2022-02-01 14:21:49 --> Language Class Initialized
INFO - 2022-02-01 14:21:49 --> Loader Class Initialized
INFO - 2022-02-01 14:21:49 --> Helper loaded: url_helper
INFO - 2022-02-01 14:21:49 --> Helper loaded: form_helper
INFO - 2022-02-01 14:21:49 --> Helper loaded: common_helper
INFO - 2022-02-01 14:21:49 --> Database Driver Class Initialized
DEBUG - 2022-02-01 14:21:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-01 14:21:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-01 14:21:49 --> Controller Class Initialized
INFO - 2022-02-01 14:21:49 --> Form Validation Class Initialized
DEBUG - 2022-02-01 14:21:49 --> Encrypt Class Initialized
DEBUG - 2022-02-01 14:21:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-01 14:21:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-01 14:21:49 --> Email Class Initialized
INFO - 2022-02-01 14:21:49 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-01 14:21:49 --> Calendar Class Initialized
INFO - 2022-02-01 14:21:49 --> Model "Login_model" initialized
INFO - 2022-02-01 14:21:49 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-01 14:21:49 --> Final output sent to browser
DEBUG - 2022-02-01 14:21:49 --> Total execution time: 0.0636
ERROR - 2022-02-01 14:25:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-01 14:25:54 --> Config Class Initialized
INFO - 2022-02-01 14:25:54 --> Hooks Class Initialized
DEBUG - 2022-02-01 14:25:55 --> UTF-8 Support Enabled
INFO - 2022-02-01 14:25:55 --> Utf8 Class Initialized
INFO - 2022-02-01 14:25:55 --> URI Class Initialized
DEBUG - 2022-02-01 14:25:55 --> No URI present. Default controller set.
INFO - 2022-02-01 14:25:55 --> Router Class Initialized
INFO - 2022-02-01 14:25:55 --> Output Class Initialized
INFO - 2022-02-01 14:25:55 --> Security Class Initialized
DEBUG - 2022-02-01 14:25:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-01 14:25:55 --> Input Class Initialized
INFO - 2022-02-01 14:25:55 --> Language Class Initialized
INFO - 2022-02-01 14:25:55 --> Loader Class Initialized
INFO - 2022-02-01 14:25:55 --> Helper loaded: url_helper
INFO - 2022-02-01 14:25:55 --> Helper loaded: form_helper
INFO - 2022-02-01 14:25:55 --> Helper loaded: common_helper
INFO - 2022-02-01 14:25:55 --> Database Driver Class Initialized
DEBUG - 2022-02-01 14:25:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-01 14:25:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-01 14:25:55 --> Controller Class Initialized
INFO - 2022-02-01 14:25:55 --> Form Validation Class Initialized
DEBUG - 2022-02-01 14:25:55 --> Encrypt Class Initialized
DEBUG - 2022-02-01 14:25:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-01 14:25:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-01 14:25:55 --> Email Class Initialized
INFO - 2022-02-01 14:25:55 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-01 14:25:55 --> Calendar Class Initialized
INFO - 2022-02-01 14:25:55 --> Model "Login_model" initialized
INFO - 2022-02-01 14:25:55 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-01 14:25:55 --> Final output sent to browser
DEBUG - 2022-02-01 14:25:55 --> Total execution time: 0.0241
ERROR - 2022-02-01 14:25:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-01 14:25:56 --> Config Class Initialized
INFO - 2022-02-01 14:25:56 --> Hooks Class Initialized
DEBUG - 2022-02-01 14:25:56 --> UTF-8 Support Enabled
INFO - 2022-02-01 14:25:56 --> Utf8 Class Initialized
INFO - 2022-02-01 14:25:56 --> URI Class Initialized
INFO - 2022-02-01 14:25:56 --> Router Class Initialized
INFO - 2022-02-01 14:25:56 --> Output Class Initialized
INFO - 2022-02-01 14:25:56 --> Security Class Initialized
DEBUG - 2022-02-01 14:25:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-01 14:25:56 --> Input Class Initialized
INFO - 2022-02-01 14:25:56 --> Language Class Initialized
ERROR - 2022-02-01 14:25:56 --> 404 Page Not Found: Register/index
ERROR - 2022-02-01 14:26:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-01 14:26:00 --> Config Class Initialized
INFO - 2022-02-01 14:26:00 --> Hooks Class Initialized
DEBUG - 2022-02-01 14:26:00 --> UTF-8 Support Enabled
INFO - 2022-02-01 14:26:00 --> Utf8 Class Initialized
INFO - 2022-02-01 14:26:00 --> URI Class Initialized
INFO - 2022-02-01 14:26:00 --> Router Class Initialized
INFO - 2022-02-01 14:26:00 --> Output Class Initialized
INFO - 2022-02-01 14:26:00 --> Security Class Initialized
DEBUG - 2022-02-01 14:26:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-01 14:26:00 --> Input Class Initialized
INFO - 2022-02-01 14:26:00 --> Language Class Initialized
INFO - 2022-02-01 14:26:00 --> Loader Class Initialized
INFO - 2022-02-01 14:26:00 --> Helper loaded: url_helper
INFO - 2022-02-01 14:26:00 --> Helper loaded: form_helper
INFO - 2022-02-01 14:26:00 --> Helper loaded: common_helper
INFO - 2022-02-01 14:26:00 --> Database Driver Class Initialized
DEBUG - 2022-02-01 14:26:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-01 14:26:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-01 14:26:00 --> Controller Class Initialized
INFO - 2022-02-01 14:26:00 --> Form Validation Class Initialized
DEBUG - 2022-02-01 14:26:00 --> Encrypt Class Initialized
DEBUG - 2022-02-01 14:26:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-01 14:26:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-01 14:26:00 --> Email Class Initialized
INFO - 2022-02-01 14:26:00 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-01 14:26:00 --> Calendar Class Initialized
INFO - 2022-02-01 14:26:00 --> Model "Login_model" initialized
INFO - 2022-02-01 14:26:00 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-01 14:26:00 --> Final output sent to browser
DEBUG - 2022-02-01 14:26:00 --> Total execution time: 0.0341
ERROR - 2022-02-01 14:26:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-01 14:26:03 --> Config Class Initialized
INFO - 2022-02-01 14:26:03 --> Hooks Class Initialized
DEBUG - 2022-02-01 14:26:03 --> UTF-8 Support Enabled
INFO - 2022-02-01 14:26:03 --> Utf8 Class Initialized
INFO - 2022-02-01 14:26:03 --> URI Class Initialized
DEBUG - 2022-02-01 14:26:03 --> No URI present. Default controller set.
INFO - 2022-02-01 14:26:03 --> Router Class Initialized
INFO - 2022-02-01 14:26:03 --> Output Class Initialized
INFO - 2022-02-01 14:26:03 --> Security Class Initialized
DEBUG - 2022-02-01 14:26:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-01 14:26:03 --> Input Class Initialized
INFO - 2022-02-01 14:26:03 --> Language Class Initialized
INFO - 2022-02-01 14:26:03 --> Loader Class Initialized
INFO - 2022-02-01 14:26:03 --> Helper loaded: url_helper
INFO - 2022-02-01 14:26:03 --> Helper loaded: form_helper
INFO - 2022-02-01 14:26:03 --> Helper loaded: common_helper
INFO - 2022-02-01 14:26:03 --> Database Driver Class Initialized
DEBUG - 2022-02-01 14:26:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-01 14:26:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-01 14:26:03 --> Controller Class Initialized
INFO - 2022-02-01 14:26:03 --> Form Validation Class Initialized
DEBUG - 2022-02-01 14:26:03 --> Encrypt Class Initialized
DEBUG - 2022-02-01 14:26:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-01 14:26:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-01 14:26:03 --> Email Class Initialized
INFO - 2022-02-01 14:26:03 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-01 14:26:03 --> Calendar Class Initialized
INFO - 2022-02-01 14:26:03 --> Model "Login_model" initialized
INFO - 2022-02-01 14:26:03 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-01 14:26:03 --> Final output sent to browser
DEBUG - 2022-02-01 14:26:03 --> Total execution time: 0.0812
ERROR - 2022-02-01 14:26:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-01 14:26:08 --> Config Class Initialized
INFO - 2022-02-01 14:26:08 --> Hooks Class Initialized
DEBUG - 2022-02-01 14:26:08 --> UTF-8 Support Enabled
INFO - 2022-02-01 14:26:08 --> Utf8 Class Initialized
INFO - 2022-02-01 14:26:08 --> URI Class Initialized
INFO - 2022-02-01 14:26:08 --> Router Class Initialized
INFO - 2022-02-01 14:26:08 --> Output Class Initialized
INFO - 2022-02-01 14:26:08 --> Security Class Initialized
DEBUG - 2022-02-01 14:26:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-01 14:26:08 --> Input Class Initialized
INFO - 2022-02-01 14:26:08 --> Language Class Initialized
INFO - 2022-02-01 14:26:08 --> Loader Class Initialized
INFO - 2022-02-01 14:26:08 --> Helper loaded: url_helper
INFO - 2022-02-01 14:26:08 --> Helper loaded: form_helper
INFO - 2022-02-01 14:26:08 --> Helper loaded: common_helper
INFO - 2022-02-01 14:26:08 --> Database Driver Class Initialized
DEBUG - 2022-02-01 14:26:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-01 14:26:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-01 14:26:08 --> Controller Class Initialized
INFO - 2022-02-01 14:26:08 --> Form Validation Class Initialized
DEBUG - 2022-02-01 14:26:08 --> Encrypt Class Initialized
DEBUG - 2022-02-01 14:26:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-01 14:26:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-01 14:26:08 --> Email Class Initialized
INFO - 2022-02-01 14:26:08 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-01 14:26:08 --> Calendar Class Initialized
INFO - 2022-02-01 14:26:08 --> Model "Login_model" initialized
ERROR - 2022-02-01 14:26:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-01 14:26:14 --> Config Class Initialized
INFO - 2022-02-01 14:26:14 --> Hooks Class Initialized
DEBUG - 2022-02-01 14:26:14 --> UTF-8 Support Enabled
INFO - 2022-02-01 14:26:14 --> Utf8 Class Initialized
INFO - 2022-02-01 14:26:14 --> URI Class Initialized
INFO - 2022-02-01 14:26:14 --> Router Class Initialized
INFO - 2022-02-01 14:26:14 --> Output Class Initialized
INFO - 2022-02-01 14:26:14 --> Security Class Initialized
DEBUG - 2022-02-01 14:26:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-01 14:26:14 --> Input Class Initialized
INFO - 2022-02-01 14:26:14 --> Language Class Initialized
INFO - 2022-02-01 14:26:14 --> Loader Class Initialized
INFO - 2022-02-01 14:26:14 --> Helper loaded: url_helper
INFO - 2022-02-01 14:26:14 --> Helper loaded: form_helper
INFO - 2022-02-01 14:26:14 --> Helper loaded: common_helper
INFO - 2022-02-01 14:26:14 --> Database Driver Class Initialized
DEBUG - 2022-02-01 14:26:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-01 14:26:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-01 14:26:14 --> Controller Class Initialized
INFO - 2022-02-01 14:26:14 --> Form Validation Class Initialized
DEBUG - 2022-02-01 14:26:14 --> Encrypt Class Initialized
DEBUG - 2022-02-01 14:26:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-01 14:26:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-01 14:26:14 --> Email Class Initialized
INFO - 2022-02-01 14:26:14 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-01 14:26:14 --> Calendar Class Initialized
INFO - 2022-02-01 14:26:14 --> Model "Login_model" initialized
INFO - 2022-02-01 14:26:14 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-01 14:26:14 --> Final output sent to browser
DEBUG - 2022-02-01 14:26:14 --> Total execution time: 0.0227
ERROR - 2022-02-01 15:45:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-01 15:45:02 --> Config Class Initialized
INFO - 2022-02-01 15:45:02 --> Hooks Class Initialized
DEBUG - 2022-02-01 15:45:02 --> UTF-8 Support Enabled
INFO - 2022-02-01 15:45:02 --> Utf8 Class Initialized
INFO - 2022-02-01 15:45:02 --> URI Class Initialized
DEBUG - 2022-02-01 15:45:02 --> No URI present. Default controller set.
INFO - 2022-02-01 15:45:02 --> Router Class Initialized
INFO - 2022-02-01 15:45:02 --> Output Class Initialized
INFO - 2022-02-01 15:45:02 --> Security Class Initialized
DEBUG - 2022-02-01 15:45:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-01 15:45:02 --> Input Class Initialized
INFO - 2022-02-01 15:45:02 --> Language Class Initialized
INFO - 2022-02-01 15:45:02 --> Loader Class Initialized
INFO - 2022-02-01 15:45:02 --> Helper loaded: url_helper
INFO - 2022-02-01 15:45:02 --> Helper loaded: form_helper
INFO - 2022-02-01 15:45:02 --> Helper loaded: common_helper
INFO - 2022-02-01 15:45:02 --> Database Driver Class Initialized
DEBUG - 2022-02-01 15:45:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-01 15:45:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-01 15:45:02 --> Controller Class Initialized
INFO - 2022-02-01 15:45:02 --> Form Validation Class Initialized
DEBUG - 2022-02-01 15:45:02 --> Encrypt Class Initialized
DEBUG - 2022-02-01 15:45:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-01 15:45:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-01 15:45:02 --> Email Class Initialized
INFO - 2022-02-01 15:45:02 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-01 15:45:02 --> Calendar Class Initialized
INFO - 2022-02-01 15:45:02 --> Model "Login_model" initialized
INFO - 2022-02-01 15:45:02 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-01 15:45:02 --> Final output sent to browser
DEBUG - 2022-02-01 15:45:02 --> Total execution time: 0.0425
