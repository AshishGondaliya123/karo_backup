<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-07-31 02:18:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-31 02:18:09 --> Config Class Initialized
INFO - 2021-07-31 02:18:09 --> Hooks Class Initialized
DEBUG - 2021-07-31 02:18:09 --> UTF-8 Support Enabled
INFO - 2021-07-31 02:18:09 --> Utf8 Class Initialized
INFO - 2021-07-31 02:18:09 --> URI Class Initialized
DEBUG - 2021-07-31 02:18:09 --> No URI present. Default controller set.
INFO - 2021-07-31 02:18:09 --> Router Class Initialized
INFO - 2021-07-31 02:18:09 --> Output Class Initialized
INFO - 2021-07-31 02:18:09 --> Security Class Initialized
DEBUG - 2021-07-31 02:18:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-31 02:18:09 --> Input Class Initialized
INFO - 2021-07-31 02:18:09 --> Language Class Initialized
INFO - 2021-07-31 02:18:09 --> Loader Class Initialized
INFO - 2021-07-31 02:18:09 --> Helper loaded: url_helper
INFO - 2021-07-31 02:18:09 --> Helper loaded: form_helper
INFO - 2021-07-31 02:18:09 --> Helper loaded: common_helper
INFO - 2021-07-31 02:18:09 --> Database Driver Class Initialized
DEBUG - 2021-07-31 02:18:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-31 02:18:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-31 02:18:09 --> Controller Class Initialized
INFO - 2021-07-31 02:18:09 --> Form Validation Class Initialized
DEBUG - 2021-07-31 02:18:09 --> Encrypt Class Initialized
DEBUG - 2021-07-31 02:18:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-07-31 02:18:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-07-31 02:18:09 --> Email Class Initialized
INFO - 2021-07-31 02:18:09 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-07-31 02:18:09 --> Calendar Class Initialized
INFO - 2021-07-31 02:18:09 --> Model "Login_model" initialized
INFO - 2021-07-31 02:18:09 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-07-31 02:18:09 --> Final output sent to browser
DEBUG - 2021-07-31 02:18:09 --> Total execution time: 0.0385
ERROR - 2021-07-31 07:45:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-31 07:45:21 --> Config Class Initialized
INFO - 2021-07-31 07:45:21 --> Hooks Class Initialized
DEBUG - 2021-07-31 07:45:21 --> UTF-8 Support Enabled
INFO - 2021-07-31 07:45:21 --> Utf8 Class Initialized
INFO - 2021-07-31 07:45:21 --> URI Class Initialized
DEBUG - 2021-07-31 07:45:21 --> No URI present. Default controller set.
INFO - 2021-07-31 07:45:21 --> Router Class Initialized
INFO - 2021-07-31 07:45:21 --> Output Class Initialized
INFO - 2021-07-31 07:45:21 --> Security Class Initialized
DEBUG - 2021-07-31 07:45:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-31 07:45:21 --> Input Class Initialized
INFO - 2021-07-31 07:45:21 --> Language Class Initialized
INFO - 2021-07-31 07:45:21 --> Loader Class Initialized
INFO - 2021-07-31 07:45:21 --> Helper loaded: url_helper
INFO - 2021-07-31 07:45:21 --> Helper loaded: form_helper
INFO - 2021-07-31 07:45:21 --> Helper loaded: common_helper
INFO - 2021-07-31 07:45:21 --> Database Driver Class Initialized
DEBUG - 2021-07-31 07:45:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-31 07:45:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-31 07:45:21 --> Controller Class Initialized
INFO - 2021-07-31 07:45:21 --> Form Validation Class Initialized
DEBUG - 2021-07-31 07:45:21 --> Encrypt Class Initialized
DEBUG - 2021-07-31 07:45:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-07-31 07:45:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-07-31 07:45:21 --> Email Class Initialized
INFO - 2021-07-31 07:45:21 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-07-31 07:45:21 --> Calendar Class Initialized
INFO - 2021-07-31 07:45:21 --> Model "Login_model" initialized
INFO - 2021-07-31 07:45:21 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-07-31 07:45:21 --> Final output sent to browser
DEBUG - 2021-07-31 07:45:21 --> Total execution time: 0.0512
