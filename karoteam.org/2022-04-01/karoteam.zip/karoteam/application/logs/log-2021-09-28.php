<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-09-28 04:06:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-28 04:06:00 --> Config Class Initialized
INFO - 2021-09-28 04:06:00 --> Hooks Class Initialized
DEBUG - 2021-09-28 04:06:00 --> UTF-8 Support Enabled
INFO - 2021-09-28 04:06:00 --> Utf8 Class Initialized
INFO - 2021-09-28 04:06:00 --> URI Class Initialized
INFO - 2021-09-28 04:06:00 --> Router Class Initialized
INFO - 2021-09-28 04:06:00 --> Output Class Initialized
INFO - 2021-09-28 04:06:00 --> Security Class Initialized
DEBUG - 2021-09-28 04:06:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-28 04:06:00 --> Input Class Initialized
INFO - 2021-09-28 04:06:00 --> Language Class Initialized
ERROR - 2021-09-28 04:06:00 --> 404 Page Not Found: Wp-content/index
ERROR - 2021-09-28 12:21:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-28 12:21:18 --> Config Class Initialized
INFO - 2021-09-28 12:21:18 --> Hooks Class Initialized
DEBUG - 2021-09-28 12:21:18 --> UTF-8 Support Enabled
INFO - 2021-09-28 12:21:18 --> Utf8 Class Initialized
INFO - 2021-09-28 12:21:18 --> URI Class Initialized
INFO - 2021-09-28 12:21:18 --> Router Class Initialized
INFO - 2021-09-28 12:21:18 --> Output Class Initialized
INFO - 2021-09-28 12:21:18 --> Security Class Initialized
DEBUG - 2021-09-28 12:21:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-28 12:21:18 --> Input Class Initialized
INFO - 2021-09-28 12:21:18 --> Language Class Initialized
ERROR - 2021-09-28 12:21:18 --> 404 Page Not Found: Git/config
ERROR - 2021-09-28 12:21:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-28 12:21:19 --> Config Class Initialized
INFO - 2021-09-28 12:21:19 --> Hooks Class Initialized
DEBUG - 2021-09-28 12:21:19 --> UTF-8 Support Enabled
INFO - 2021-09-28 12:21:19 --> Utf8 Class Initialized
INFO - 2021-09-28 12:21:19 --> URI Class Initialized
INFO - 2021-09-28 12:21:19 --> Router Class Initialized
INFO - 2021-09-28 12:21:19 --> Output Class Initialized
INFO - 2021-09-28 12:21:19 --> Security Class Initialized
DEBUG - 2021-09-28 12:21:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-28 12:21:19 --> Input Class Initialized
INFO - 2021-09-28 12:21:19 --> Language Class Initialized
ERROR - 2021-09-28 12:21:19 --> 404 Page Not Found: Git/config
ERROR - 2021-09-28 12:21:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-28 12:21:21 --> Config Class Initialized
INFO - 2021-09-28 12:21:21 --> Hooks Class Initialized
DEBUG - 2021-09-28 12:21:21 --> UTF-8 Support Enabled
INFO - 2021-09-28 12:21:21 --> Utf8 Class Initialized
INFO - 2021-09-28 12:21:21 --> URI Class Initialized
INFO - 2021-09-28 12:21:21 --> Router Class Initialized
INFO - 2021-09-28 12:21:21 --> Output Class Initialized
INFO - 2021-09-28 12:21:21 --> Security Class Initialized
DEBUG - 2021-09-28 12:21:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-28 12:21:21 --> Input Class Initialized
INFO - 2021-09-28 12:21:21 --> Language Class Initialized
ERROR - 2021-09-28 12:21:21 --> 404 Page Not Found: Git/config
ERROR - 2021-09-28 12:21:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-28 12:21:34 --> Config Class Initialized
INFO - 2021-09-28 12:21:34 --> Hooks Class Initialized
DEBUG - 2021-09-28 12:21:34 --> UTF-8 Support Enabled
INFO - 2021-09-28 12:21:34 --> Utf8 Class Initialized
INFO - 2021-09-28 12:21:34 --> URI Class Initialized
INFO - 2021-09-28 12:21:34 --> Router Class Initialized
INFO - 2021-09-28 12:21:34 --> Output Class Initialized
INFO - 2021-09-28 12:21:34 --> Security Class Initialized
DEBUG - 2021-09-28 12:21:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-28 12:21:34 --> Input Class Initialized
INFO - 2021-09-28 12:21:34 --> Language Class Initialized
ERROR - 2021-09-28 12:21:34 --> 404 Page Not Found: Git/config
ERROR - 2021-09-28 18:21:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-28 18:21:53 --> Config Class Initialized
INFO - 2021-09-28 18:21:53 --> Hooks Class Initialized
DEBUG - 2021-09-28 18:21:53 --> UTF-8 Support Enabled
INFO - 2021-09-28 18:21:53 --> Utf8 Class Initialized
INFO - 2021-09-28 18:21:53 --> URI Class Initialized
DEBUG - 2021-09-28 18:21:53 --> No URI present. Default controller set.
INFO - 2021-09-28 18:21:53 --> Router Class Initialized
INFO - 2021-09-28 18:21:53 --> Output Class Initialized
INFO - 2021-09-28 18:21:53 --> Security Class Initialized
DEBUG - 2021-09-28 18:21:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-28 18:21:53 --> Input Class Initialized
INFO - 2021-09-28 18:21:53 --> Language Class Initialized
INFO - 2021-09-28 18:21:53 --> Loader Class Initialized
INFO - 2021-09-28 18:21:53 --> Helper loaded: url_helper
INFO - 2021-09-28 18:21:53 --> Helper loaded: form_helper
INFO - 2021-09-28 18:21:53 --> Helper loaded: common_helper
INFO - 2021-09-28 18:21:53 --> Database Driver Class Initialized
DEBUG - 2021-09-28 18:21:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-28 18:21:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-28 18:21:53 --> Controller Class Initialized
INFO - 2021-09-28 18:21:53 --> Form Validation Class Initialized
DEBUG - 2021-09-28 18:21:53 --> Encrypt Class Initialized
DEBUG - 2021-09-28 18:21:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-09-28 18:21:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-09-28 18:21:53 --> Email Class Initialized
INFO - 2021-09-28 18:21:53 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-09-28 18:21:53 --> Calendar Class Initialized
INFO - 2021-09-28 18:21:53 --> Model "Login_model" initialized
INFO - 2021-09-28 18:21:53 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-09-28 18:21:53 --> Final output sent to browser
DEBUG - 2021-09-28 18:21:53 --> Total execution time: 0.0613
