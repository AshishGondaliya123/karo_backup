<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-09-10 12:57:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-10 12:57:32 --> Config Class Initialized
INFO - 2021-09-10 12:57:32 --> Hooks Class Initialized
DEBUG - 2021-09-10 12:57:32 --> UTF-8 Support Enabled
INFO - 2021-09-10 12:57:32 --> Utf8 Class Initialized
INFO - 2021-09-10 12:57:32 --> URI Class Initialized
DEBUG - 2021-09-10 12:57:32 --> No URI present. Default controller set.
INFO - 2021-09-10 12:57:32 --> Router Class Initialized
INFO - 2021-09-10 12:57:32 --> Output Class Initialized
INFO - 2021-09-10 12:57:32 --> Security Class Initialized
DEBUG - 2021-09-10 12:57:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-10 12:57:32 --> Input Class Initialized
INFO - 2021-09-10 12:57:32 --> Language Class Initialized
INFO - 2021-09-10 12:57:32 --> Loader Class Initialized
INFO - 2021-09-10 12:57:32 --> Helper loaded: url_helper
INFO - 2021-09-10 12:57:32 --> Helper loaded: form_helper
INFO - 2021-09-10 12:57:32 --> Helper loaded: common_helper
INFO - 2021-09-10 12:57:32 --> Database Driver Class Initialized
DEBUG - 2021-09-10 12:57:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-10 12:57:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-10 12:57:32 --> Controller Class Initialized
INFO - 2021-09-10 12:57:32 --> Form Validation Class Initialized
DEBUG - 2021-09-10 12:57:32 --> Encrypt Class Initialized
DEBUG - 2021-09-10 12:57:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-09-10 12:57:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-09-10 12:57:32 --> Email Class Initialized
INFO - 2021-09-10 12:57:32 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-09-10 12:57:32 --> Calendar Class Initialized
INFO - 2021-09-10 12:57:32 --> Model "Login_model" initialized
INFO - 2021-09-10 12:57:32 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-09-10 12:57:32 --> Final output sent to browser
DEBUG - 2021-09-10 12:57:32 --> Total execution time: 0.0528
ERROR - 2021-09-10 13:48:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-10 13:48:25 --> Config Class Initialized
INFO - 2021-09-10 13:48:25 --> Hooks Class Initialized
DEBUG - 2021-09-10 13:48:25 --> UTF-8 Support Enabled
INFO - 2021-09-10 13:48:25 --> Utf8 Class Initialized
INFO - 2021-09-10 13:48:25 --> URI Class Initialized
INFO - 2021-09-10 13:48:25 --> Router Class Initialized
INFO - 2021-09-10 13:48:25 --> Output Class Initialized
INFO - 2021-09-10 13:48:25 --> Security Class Initialized
DEBUG - 2021-09-10 13:48:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-10 13:48:25 --> Input Class Initialized
INFO - 2021-09-10 13:48:25 --> Language Class Initialized
ERROR - 2021-09-10 13:48:25 --> 404 Page Not Found: Wp-content/index
