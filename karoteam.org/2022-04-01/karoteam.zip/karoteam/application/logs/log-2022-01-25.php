<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-01-25 03:00:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 03:00:10 --> Config Class Initialized
INFO - 2022-01-25 03:00:10 --> Hooks Class Initialized
DEBUG - 2022-01-25 03:00:10 --> UTF-8 Support Enabled
INFO - 2022-01-25 03:00:10 --> Utf8 Class Initialized
INFO - 2022-01-25 03:00:10 --> URI Class Initialized
DEBUG - 2022-01-25 03:00:10 --> No URI present. Default controller set.
INFO - 2022-01-25 03:00:10 --> Router Class Initialized
INFO - 2022-01-25 03:00:10 --> Output Class Initialized
INFO - 2022-01-25 03:00:10 --> Security Class Initialized
DEBUG - 2022-01-25 03:00:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 03:00:10 --> Input Class Initialized
INFO - 2022-01-25 03:00:10 --> Language Class Initialized
INFO - 2022-01-25 03:00:10 --> Loader Class Initialized
INFO - 2022-01-25 03:00:10 --> Helper loaded: url_helper
INFO - 2022-01-25 03:00:10 --> Helper loaded: form_helper
INFO - 2022-01-25 03:00:10 --> Helper loaded: common_helper
INFO - 2022-01-25 03:00:10 --> Database Driver Class Initialized
DEBUG - 2022-01-25 03:00:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-25 03:00:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-25 03:00:10 --> Controller Class Initialized
INFO - 2022-01-25 03:00:10 --> Form Validation Class Initialized
DEBUG - 2022-01-25 03:00:10 --> Encrypt Class Initialized
DEBUG - 2022-01-25 03:00:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 03:00:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-25 03:00:10 --> Email Class Initialized
INFO - 2022-01-25 03:00:10 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-25 03:00:10 --> Calendar Class Initialized
INFO - 2022-01-25 03:00:10 --> Model "Login_model" initialized
INFO - 2022-01-25 03:00:10 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-25 03:00:10 --> Final output sent to browser
DEBUG - 2022-01-25 03:00:10 --> Total execution time: 0.0268
ERROR - 2022-01-25 03:44:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 03:44:00 --> Config Class Initialized
INFO - 2022-01-25 03:44:00 --> Hooks Class Initialized
DEBUG - 2022-01-25 03:44:00 --> UTF-8 Support Enabled
INFO - 2022-01-25 03:44:00 --> Utf8 Class Initialized
INFO - 2022-01-25 03:44:00 --> URI Class Initialized
DEBUG - 2022-01-25 03:44:00 --> No URI present. Default controller set.
INFO - 2022-01-25 03:44:00 --> Router Class Initialized
INFO - 2022-01-25 03:44:00 --> Output Class Initialized
INFO - 2022-01-25 03:44:00 --> Security Class Initialized
DEBUG - 2022-01-25 03:44:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 03:44:00 --> Input Class Initialized
INFO - 2022-01-25 03:44:00 --> Language Class Initialized
INFO - 2022-01-25 03:44:00 --> Loader Class Initialized
INFO - 2022-01-25 03:44:00 --> Helper loaded: url_helper
INFO - 2022-01-25 03:44:00 --> Helper loaded: form_helper
INFO - 2022-01-25 03:44:00 --> Helper loaded: common_helper
INFO - 2022-01-25 03:44:00 --> Database Driver Class Initialized
DEBUG - 2022-01-25 03:44:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-25 03:44:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-25 03:44:00 --> Controller Class Initialized
INFO - 2022-01-25 03:44:00 --> Form Validation Class Initialized
DEBUG - 2022-01-25 03:44:00 --> Encrypt Class Initialized
DEBUG - 2022-01-25 03:44:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 03:44:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-25 03:44:00 --> Email Class Initialized
INFO - 2022-01-25 03:44:00 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-25 03:44:00 --> Calendar Class Initialized
INFO - 2022-01-25 03:44:00 --> Model "Login_model" initialized
INFO - 2022-01-25 03:44:00 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-25 03:44:00 --> Final output sent to browser
DEBUG - 2022-01-25 03:44:00 --> Total execution time: 0.0320
ERROR - 2022-01-25 04:53:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 04:53:42 --> Config Class Initialized
INFO - 2022-01-25 04:53:42 --> Hooks Class Initialized
DEBUG - 2022-01-25 04:53:42 --> UTF-8 Support Enabled
INFO - 2022-01-25 04:53:42 --> Utf8 Class Initialized
INFO - 2022-01-25 04:53:42 --> URI Class Initialized
DEBUG - 2022-01-25 04:53:42 --> No URI present. Default controller set.
INFO - 2022-01-25 04:53:42 --> Router Class Initialized
INFO - 2022-01-25 04:53:42 --> Output Class Initialized
INFO - 2022-01-25 04:53:42 --> Security Class Initialized
DEBUG - 2022-01-25 04:53:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 04:53:42 --> Input Class Initialized
INFO - 2022-01-25 04:53:42 --> Language Class Initialized
INFO - 2022-01-25 04:53:42 --> Loader Class Initialized
INFO - 2022-01-25 04:53:42 --> Helper loaded: url_helper
INFO - 2022-01-25 04:53:42 --> Helper loaded: form_helper
INFO - 2022-01-25 04:53:42 --> Helper loaded: common_helper
INFO - 2022-01-25 04:53:42 --> Database Driver Class Initialized
DEBUG - 2022-01-25 04:53:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-25 04:53:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-25 04:53:42 --> Controller Class Initialized
INFO - 2022-01-25 04:53:42 --> Form Validation Class Initialized
DEBUG - 2022-01-25 04:53:42 --> Encrypt Class Initialized
DEBUG - 2022-01-25 04:53:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 04:53:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-25 04:53:42 --> Email Class Initialized
INFO - 2022-01-25 04:53:42 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-25 04:53:42 --> Calendar Class Initialized
INFO - 2022-01-25 04:53:42 --> Model "Login_model" initialized
INFO - 2022-01-25 04:53:42 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-25 04:53:42 --> Final output sent to browser
DEBUG - 2022-01-25 04:53:42 --> Total execution time: 0.0360
ERROR - 2022-01-25 05:28:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 05:28:48 --> Config Class Initialized
INFO - 2022-01-25 05:28:48 --> Hooks Class Initialized
DEBUG - 2022-01-25 05:28:48 --> UTF-8 Support Enabled
INFO - 2022-01-25 05:28:48 --> Utf8 Class Initialized
INFO - 2022-01-25 05:28:48 --> URI Class Initialized
INFO - 2022-01-25 05:28:48 --> Router Class Initialized
INFO - 2022-01-25 05:28:48 --> Output Class Initialized
INFO - 2022-01-25 05:28:48 --> Security Class Initialized
DEBUG - 2022-01-25 05:28:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 05:28:48 --> Input Class Initialized
INFO - 2022-01-25 05:28:48 --> Language Class Initialized
ERROR - 2022-01-25 05:28:48 --> 404 Page Not Found: Filemanager/dialog.php
ERROR - 2022-01-25 05:28:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 05:28:49 --> Config Class Initialized
INFO - 2022-01-25 05:28:49 --> Hooks Class Initialized
DEBUG - 2022-01-25 05:28:49 --> UTF-8 Support Enabled
INFO - 2022-01-25 05:28:49 --> Utf8 Class Initialized
INFO - 2022-01-25 05:28:49 --> URI Class Initialized
INFO - 2022-01-25 05:28:49 --> Router Class Initialized
INFO - 2022-01-25 05:28:49 --> Output Class Initialized
INFO - 2022-01-25 05:28:49 --> Security Class Initialized
DEBUG - 2022-01-25 05:28:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 05:28:49 --> Input Class Initialized
INFO - 2022-01-25 05:28:49 --> Language Class Initialized
ERROR - 2022-01-25 05:28:49 --> 404 Page Not Found: Assets/filemanager
ERROR - 2022-01-25 11:38:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 11:38:50 --> Config Class Initialized
INFO - 2022-01-25 11:38:50 --> Hooks Class Initialized
DEBUG - 2022-01-25 11:38:50 --> UTF-8 Support Enabled
INFO - 2022-01-25 11:38:50 --> Utf8 Class Initialized
INFO - 2022-01-25 11:38:50 --> URI Class Initialized
DEBUG - 2022-01-25 11:38:50 --> No URI present. Default controller set.
INFO - 2022-01-25 11:38:50 --> Router Class Initialized
INFO - 2022-01-25 11:38:50 --> Output Class Initialized
INFO - 2022-01-25 11:38:50 --> Security Class Initialized
DEBUG - 2022-01-25 11:38:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 11:38:50 --> Input Class Initialized
INFO - 2022-01-25 11:38:50 --> Language Class Initialized
INFO - 2022-01-25 11:38:50 --> Loader Class Initialized
INFO - 2022-01-25 11:38:50 --> Helper loaded: url_helper
INFO - 2022-01-25 11:38:50 --> Helper loaded: form_helper
INFO - 2022-01-25 11:38:50 --> Helper loaded: common_helper
INFO - 2022-01-25 11:38:50 --> Database Driver Class Initialized
DEBUG - 2022-01-25 11:38:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-25 11:38:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-25 11:38:50 --> Controller Class Initialized
INFO - 2022-01-25 11:38:50 --> Form Validation Class Initialized
DEBUG - 2022-01-25 11:38:50 --> Encrypt Class Initialized
DEBUG - 2022-01-25 11:38:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 11:38:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-25 11:38:50 --> Email Class Initialized
INFO - 2022-01-25 11:38:50 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-25 11:38:50 --> Calendar Class Initialized
INFO - 2022-01-25 11:38:50 --> Model "Login_model" initialized
INFO - 2022-01-25 11:38:50 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-25 11:38:50 --> Final output sent to browser
DEBUG - 2022-01-25 11:38:50 --> Total execution time: 0.0380
ERROR - 2022-01-25 13:11:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 13:11:39 --> Config Class Initialized
INFO - 2022-01-25 13:11:39 --> Hooks Class Initialized
DEBUG - 2022-01-25 13:11:39 --> UTF-8 Support Enabled
INFO - 2022-01-25 13:11:39 --> Utf8 Class Initialized
INFO - 2022-01-25 13:11:39 --> URI Class Initialized
DEBUG - 2022-01-25 13:11:39 --> No URI present. Default controller set.
INFO - 2022-01-25 13:11:39 --> Router Class Initialized
INFO - 2022-01-25 13:11:39 --> Output Class Initialized
INFO - 2022-01-25 13:11:39 --> Security Class Initialized
DEBUG - 2022-01-25 13:11:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 13:11:39 --> Input Class Initialized
INFO - 2022-01-25 13:11:39 --> Language Class Initialized
INFO - 2022-01-25 13:11:39 --> Loader Class Initialized
INFO - 2022-01-25 13:11:39 --> Helper loaded: url_helper
INFO - 2022-01-25 13:11:39 --> Helper loaded: form_helper
INFO - 2022-01-25 13:11:39 --> Helper loaded: common_helper
INFO - 2022-01-25 13:11:39 --> Database Driver Class Initialized
DEBUG - 2022-01-25 13:11:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-25 13:11:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-25 13:11:39 --> Controller Class Initialized
INFO - 2022-01-25 13:11:39 --> Form Validation Class Initialized
DEBUG - 2022-01-25 13:11:39 --> Encrypt Class Initialized
DEBUG - 2022-01-25 13:11:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 13:11:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-25 13:11:39 --> Email Class Initialized
INFO - 2022-01-25 13:11:39 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-25 13:11:39 --> Calendar Class Initialized
INFO - 2022-01-25 13:11:39 --> Model "Login_model" initialized
INFO - 2022-01-25 13:11:39 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-25 13:11:39 --> Final output sent to browser
DEBUG - 2022-01-25 13:11:39 --> Total execution time: 0.0243
ERROR - 2022-01-25 13:11:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 13:11:40 --> Config Class Initialized
INFO - 2022-01-25 13:11:40 --> Hooks Class Initialized
DEBUG - 2022-01-25 13:11:40 --> UTF-8 Support Enabled
INFO - 2022-01-25 13:11:40 --> Utf8 Class Initialized
INFO - 2022-01-25 13:11:40 --> URI Class Initialized
DEBUG - 2022-01-25 13:11:40 --> No URI present. Default controller set.
INFO - 2022-01-25 13:11:40 --> Router Class Initialized
INFO - 2022-01-25 13:11:40 --> Output Class Initialized
INFO - 2022-01-25 13:11:40 --> Security Class Initialized
DEBUG - 2022-01-25 13:11:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 13:11:40 --> Input Class Initialized
INFO - 2022-01-25 13:11:40 --> Language Class Initialized
INFO - 2022-01-25 13:11:40 --> Loader Class Initialized
INFO - 2022-01-25 13:11:40 --> Helper loaded: url_helper
INFO - 2022-01-25 13:11:40 --> Helper loaded: form_helper
INFO - 2022-01-25 13:11:40 --> Helper loaded: common_helper
INFO - 2022-01-25 13:11:40 --> Database Driver Class Initialized
DEBUG - 2022-01-25 13:11:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-25 13:11:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-25 13:11:40 --> Controller Class Initialized
INFO - 2022-01-25 13:11:40 --> Form Validation Class Initialized
DEBUG - 2022-01-25 13:11:40 --> Encrypt Class Initialized
DEBUG - 2022-01-25 13:11:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 13:11:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-25 13:11:40 --> Email Class Initialized
INFO - 2022-01-25 13:11:40 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-25 13:11:40 --> Calendar Class Initialized
INFO - 2022-01-25 13:11:40 --> Model "Login_model" initialized
INFO - 2022-01-25 13:11:40 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-25 13:11:40 --> Final output sent to browser
DEBUG - 2022-01-25 13:11:40 --> Total execution time: 0.0209
ERROR - 2022-01-25 13:11:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 13:11:40 --> Config Class Initialized
INFO - 2022-01-25 13:11:40 --> Hooks Class Initialized
DEBUG - 2022-01-25 13:11:40 --> UTF-8 Support Enabled
INFO - 2022-01-25 13:11:40 --> Utf8 Class Initialized
INFO - 2022-01-25 13:11:40 --> URI Class Initialized
INFO - 2022-01-25 13:11:40 --> Router Class Initialized
INFO - 2022-01-25 13:11:40 --> Output Class Initialized
INFO - 2022-01-25 13:11:40 --> Security Class Initialized
DEBUG - 2022-01-25 13:11:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 13:11:40 --> Input Class Initialized
INFO - 2022-01-25 13:11:40 --> Language Class Initialized
ERROR - 2022-01-25 13:11:40 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
ERROR - 2022-01-25 13:11:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 13:11:41 --> Config Class Initialized
INFO - 2022-01-25 13:11:41 --> Hooks Class Initialized
DEBUG - 2022-01-25 13:11:41 --> UTF-8 Support Enabled
INFO - 2022-01-25 13:11:41 --> Utf8 Class Initialized
INFO - 2022-01-25 13:11:41 --> URI Class Initialized
INFO - 2022-01-25 13:11:41 --> Router Class Initialized
INFO - 2022-01-25 13:11:41 --> Output Class Initialized
INFO - 2022-01-25 13:11:41 --> Security Class Initialized
DEBUG - 2022-01-25 13:11:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 13:11:41 --> Input Class Initialized
INFO - 2022-01-25 13:11:41 --> Language Class Initialized
ERROR - 2022-01-25 13:11:41 --> 404 Page Not Found: Blog/wp-includes
ERROR - 2022-01-25 13:11:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 13:11:42 --> Config Class Initialized
INFO - 2022-01-25 13:11:42 --> Hooks Class Initialized
DEBUG - 2022-01-25 13:11:42 --> UTF-8 Support Enabled
INFO - 2022-01-25 13:11:42 --> Utf8 Class Initialized
INFO - 2022-01-25 13:11:42 --> URI Class Initialized
INFO - 2022-01-25 13:11:42 --> Router Class Initialized
INFO - 2022-01-25 13:11:42 --> Output Class Initialized
INFO - 2022-01-25 13:11:42 --> Security Class Initialized
DEBUG - 2022-01-25 13:11:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 13:11:42 --> Input Class Initialized
INFO - 2022-01-25 13:11:42 --> Language Class Initialized
ERROR - 2022-01-25 13:11:42 --> 404 Page Not Found: Web/wp-includes
ERROR - 2022-01-25 13:11:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 13:11:42 --> Config Class Initialized
INFO - 2022-01-25 13:11:42 --> Hooks Class Initialized
DEBUG - 2022-01-25 13:11:42 --> UTF-8 Support Enabled
INFO - 2022-01-25 13:11:42 --> Utf8 Class Initialized
INFO - 2022-01-25 13:11:42 --> URI Class Initialized
INFO - 2022-01-25 13:11:42 --> Router Class Initialized
INFO - 2022-01-25 13:11:42 --> Output Class Initialized
INFO - 2022-01-25 13:11:42 --> Security Class Initialized
DEBUG - 2022-01-25 13:11:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 13:11:42 --> Input Class Initialized
INFO - 2022-01-25 13:11:42 --> Language Class Initialized
ERROR - 2022-01-25 13:11:42 --> 404 Page Not Found: Wordpress/wp-includes
ERROR - 2022-01-25 13:11:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 13:11:43 --> Config Class Initialized
INFO - 2022-01-25 13:11:43 --> Hooks Class Initialized
DEBUG - 2022-01-25 13:11:43 --> UTF-8 Support Enabled
INFO - 2022-01-25 13:11:43 --> Utf8 Class Initialized
INFO - 2022-01-25 13:11:43 --> URI Class Initialized
INFO - 2022-01-25 13:11:43 --> Router Class Initialized
INFO - 2022-01-25 13:11:43 --> Output Class Initialized
INFO - 2022-01-25 13:11:43 --> Security Class Initialized
DEBUG - 2022-01-25 13:11:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 13:11:43 --> Input Class Initialized
INFO - 2022-01-25 13:11:43 --> Language Class Initialized
ERROR - 2022-01-25 13:11:43 --> 404 Page Not Found: Website/wp-includes
ERROR - 2022-01-25 13:11:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 13:11:43 --> Config Class Initialized
INFO - 2022-01-25 13:11:43 --> Hooks Class Initialized
DEBUG - 2022-01-25 13:11:43 --> UTF-8 Support Enabled
INFO - 2022-01-25 13:11:43 --> Utf8 Class Initialized
INFO - 2022-01-25 13:11:43 --> URI Class Initialized
INFO - 2022-01-25 13:11:43 --> Router Class Initialized
INFO - 2022-01-25 13:11:43 --> Output Class Initialized
INFO - 2022-01-25 13:11:43 --> Security Class Initialized
DEBUG - 2022-01-25 13:11:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 13:11:43 --> Input Class Initialized
INFO - 2022-01-25 13:11:43 --> Language Class Initialized
ERROR - 2022-01-25 13:11:43 --> 404 Page Not Found: Wp/wp-includes
ERROR - 2022-01-25 13:11:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 13:11:44 --> Config Class Initialized
INFO - 2022-01-25 13:11:44 --> Hooks Class Initialized
DEBUG - 2022-01-25 13:11:44 --> UTF-8 Support Enabled
INFO - 2022-01-25 13:11:44 --> Utf8 Class Initialized
INFO - 2022-01-25 13:11:44 --> URI Class Initialized
INFO - 2022-01-25 13:11:44 --> Router Class Initialized
INFO - 2022-01-25 13:11:44 --> Output Class Initialized
INFO - 2022-01-25 13:11:44 --> Security Class Initialized
DEBUG - 2022-01-25 13:11:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 13:11:44 --> Input Class Initialized
INFO - 2022-01-25 13:11:44 --> Language Class Initialized
ERROR - 2022-01-25 13:11:44 --> 404 Page Not Found: News/wp-includes
ERROR - 2022-01-25 13:11:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 13:11:44 --> Config Class Initialized
INFO - 2022-01-25 13:11:44 --> Hooks Class Initialized
DEBUG - 2022-01-25 13:11:44 --> UTF-8 Support Enabled
INFO - 2022-01-25 13:11:44 --> Utf8 Class Initialized
INFO - 2022-01-25 13:11:44 --> URI Class Initialized
INFO - 2022-01-25 13:11:44 --> Router Class Initialized
INFO - 2022-01-25 13:11:44 --> Output Class Initialized
INFO - 2022-01-25 13:11:44 --> Security Class Initialized
DEBUG - 2022-01-25 13:11:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 13:11:44 --> Input Class Initialized
INFO - 2022-01-25 13:11:44 --> Language Class Initialized
ERROR - 2022-01-25 13:11:44 --> 404 Page Not Found: 2018/wp-includes
ERROR - 2022-01-25 13:11:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 13:11:45 --> Config Class Initialized
INFO - 2022-01-25 13:11:45 --> Hooks Class Initialized
DEBUG - 2022-01-25 13:11:45 --> UTF-8 Support Enabled
INFO - 2022-01-25 13:11:45 --> Utf8 Class Initialized
INFO - 2022-01-25 13:11:45 --> URI Class Initialized
INFO - 2022-01-25 13:11:45 --> Router Class Initialized
INFO - 2022-01-25 13:11:45 --> Output Class Initialized
INFO - 2022-01-25 13:11:45 --> Security Class Initialized
DEBUG - 2022-01-25 13:11:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 13:11:45 --> Input Class Initialized
INFO - 2022-01-25 13:11:45 --> Language Class Initialized
ERROR - 2022-01-25 13:11:45 --> 404 Page Not Found: 2019/wp-includes
ERROR - 2022-01-25 13:11:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 13:11:45 --> Config Class Initialized
INFO - 2022-01-25 13:11:45 --> Hooks Class Initialized
DEBUG - 2022-01-25 13:11:45 --> UTF-8 Support Enabled
INFO - 2022-01-25 13:11:45 --> Utf8 Class Initialized
INFO - 2022-01-25 13:11:45 --> URI Class Initialized
INFO - 2022-01-25 13:11:45 --> Router Class Initialized
INFO - 2022-01-25 13:11:45 --> Output Class Initialized
INFO - 2022-01-25 13:11:45 --> Security Class Initialized
DEBUG - 2022-01-25 13:11:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 13:11:45 --> Input Class Initialized
INFO - 2022-01-25 13:11:45 --> Language Class Initialized
ERROR - 2022-01-25 13:11:45 --> 404 Page Not Found: Shop/wp-includes
ERROR - 2022-01-25 13:11:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 13:11:46 --> Config Class Initialized
INFO - 2022-01-25 13:11:46 --> Hooks Class Initialized
DEBUG - 2022-01-25 13:11:46 --> UTF-8 Support Enabled
INFO - 2022-01-25 13:11:46 --> Utf8 Class Initialized
INFO - 2022-01-25 13:11:46 --> URI Class Initialized
INFO - 2022-01-25 13:11:46 --> Router Class Initialized
INFO - 2022-01-25 13:11:46 --> Output Class Initialized
INFO - 2022-01-25 13:11:46 --> Security Class Initialized
DEBUG - 2022-01-25 13:11:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 13:11:46 --> Input Class Initialized
INFO - 2022-01-25 13:11:46 --> Language Class Initialized
ERROR - 2022-01-25 13:11:46 --> 404 Page Not Found: Wp1/wp-includes
ERROR - 2022-01-25 13:11:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 13:11:46 --> Config Class Initialized
INFO - 2022-01-25 13:11:46 --> Hooks Class Initialized
DEBUG - 2022-01-25 13:11:46 --> UTF-8 Support Enabled
INFO - 2022-01-25 13:11:46 --> Utf8 Class Initialized
INFO - 2022-01-25 13:11:46 --> URI Class Initialized
INFO - 2022-01-25 13:11:46 --> Router Class Initialized
INFO - 2022-01-25 13:11:46 --> Output Class Initialized
INFO - 2022-01-25 13:11:46 --> Security Class Initialized
DEBUG - 2022-01-25 13:11:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 13:11:46 --> Input Class Initialized
INFO - 2022-01-25 13:11:46 --> Language Class Initialized
ERROR - 2022-01-25 13:11:46 --> 404 Page Not Found: Test/wp-includes
ERROR - 2022-01-25 13:11:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 13:11:47 --> Config Class Initialized
INFO - 2022-01-25 13:11:47 --> Hooks Class Initialized
DEBUG - 2022-01-25 13:11:47 --> UTF-8 Support Enabled
INFO - 2022-01-25 13:11:47 --> Utf8 Class Initialized
INFO - 2022-01-25 13:11:47 --> URI Class Initialized
INFO - 2022-01-25 13:11:47 --> Router Class Initialized
INFO - 2022-01-25 13:11:47 --> Output Class Initialized
INFO - 2022-01-25 13:11:47 --> Security Class Initialized
DEBUG - 2022-01-25 13:11:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 13:11:47 --> Input Class Initialized
INFO - 2022-01-25 13:11:47 --> Language Class Initialized
ERROR - 2022-01-25 13:11:47 --> 404 Page Not Found: Media/wp-includes
ERROR - 2022-01-25 13:11:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 13:11:47 --> Config Class Initialized
INFO - 2022-01-25 13:11:47 --> Hooks Class Initialized
DEBUG - 2022-01-25 13:11:47 --> UTF-8 Support Enabled
INFO - 2022-01-25 13:11:47 --> Utf8 Class Initialized
INFO - 2022-01-25 13:11:47 --> URI Class Initialized
INFO - 2022-01-25 13:11:47 --> Router Class Initialized
INFO - 2022-01-25 13:11:47 --> Output Class Initialized
INFO - 2022-01-25 13:11:47 --> Security Class Initialized
DEBUG - 2022-01-25 13:11:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 13:11:47 --> Input Class Initialized
INFO - 2022-01-25 13:11:47 --> Language Class Initialized
ERROR - 2022-01-25 13:11:47 --> 404 Page Not Found: Wp2/wp-includes
ERROR - 2022-01-25 13:11:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 13:11:48 --> Config Class Initialized
INFO - 2022-01-25 13:11:48 --> Hooks Class Initialized
DEBUG - 2022-01-25 13:11:48 --> UTF-8 Support Enabled
INFO - 2022-01-25 13:11:48 --> Utf8 Class Initialized
INFO - 2022-01-25 13:11:48 --> URI Class Initialized
INFO - 2022-01-25 13:11:48 --> Router Class Initialized
INFO - 2022-01-25 13:11:48 --> Output Class Initialized
INFO - 2022-01-25 13:11:48 --> Security Class Initialized
DEBUG - 2022-01-25 13:11:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 13:11:48 --> Input Class Initialized
INFO - 2022-01-25 13:11:48 --> Language Class Initialized
ERROR - 2022-01-25 13:11:48 --> 404 Page Not Found: Site/wp-includes
ERROR - 2022-01-25 13:11:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 13:11:48 --> Config Class Initialized
INFO - 2022-01-25 13:11:48 --> Hooks Class Initialized
DEBUG - 2022-01-25 13:11:48 --> UTF-8 Support Enabled
INFO - 2022-01-25 13:11:48 --> Utf8 Class Initialized
INFO - 2022-01-25 13:11:48 --> URI Class Initialized
INFO - 2022-01-25 13:11:48 --> Router Class Initialized
INFO - 2022-01-25 13:11:48 --> Output Class Initialized
INFO - 2022-01-25 13:11:48 --> Security Class Initialized
DEBUG - 2022-01-25 13:11:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 13:11:48 --> Input Class Initialized
INFO - 2022-01-25 13:11:48 --> Language Class Initialized
ERROR - 2022-01-25 13:11:48 --> 404 Page Not Found: Cms/wp-includes
ERROR - 2022-01-25 13:11:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 13:11:49 --> Config Class Initialized
INFO - 2022-01-25 13:11:49 --> Hooks Class Initialized
DEBUG - 2022-01-25 13:11:49 --> UTF-8 Support Enabled
INFO - 2022-01-25 13:11:49 --> Utf8 Class Initialized
INFO - 2022-01-25 13:11:49 --> URI Class Initialized
INFO - 2022-01-25 13:11:49 --> Router Class Initialized
INFO - 2022-01-25 13:11:49 --> Output Class Initialized
INFO - 2022-01-25 13:11:49 --> Security Class Initialized
DEBUG - 2022-01-25 13:11:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 13:11:49 --> Input Class Initialized
INFO - 2022-01-25 13:11:49 --> Language Class Initialized
ERROR - 2022-01-25 13:11:49 --> 404 Page Not Found: Sito/wp-includes
ERROR - 2022-01-25 13:47:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 13:47:10 --> Config Class Initialized
INFO - 2022-01-25 13:47:10 --> Hooks Class Initialized
DEBUG - 2022-01-25 13:47:10 --> UTF-8 Support Enabled
INFO - 2022-01-25 13:47:10 --> Utf8 Class Initialized
INFO - 2022-01-25 13:47:10 --> URI Class Initialized
DEBUG - 2022-01-25 13:47:10 --> No URI present. Default controller set.
INFO - 2022-01-25 13:47:10 --> Router Class Initialized
INFO - 2022-01-25 13:47:10 --> Output Class Initialized
INFO - 2022-01-25 13:47:10 --> Security Class Initialized
DEBUG - 2022-01-25 13:47:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 13:47:10 --> Input Class Initialized
INFO - 2022-01-25 13:47:10 --> Language Class Initialized
INFO - 2022-01-25 13:47:10 --> Loader Class Initialized
INFO - 2022-01-25 13:47:10 --> Helper loaded: url_helper
INFO - 2022-01-25 13:47:10 --> Helper loaded: form_helper
INFO - 2022-01-25 13:47:10 --> Helper loaded: common_helper
INFO - 2022-01-25 13:47:10 --> Database Driver Class Initialized
DEBUG - 2022-01-25 13:47:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-25 13:47:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-25 13:47:10 --> Controller Class Initialized
INFO - 2022-01-25 13:47:10 --> Form Validation Class Initialized
DEBUG - 2022-01-25 13:47:10 --> Encrypt Class Initialized
DEBUG - 2022-01-25 13:47:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 13:47:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-25 13:47:10 --> Email Class Initialized
INFO - 2022-01-25 13:47:10 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-25 13:47:10 --> Calendar Class Initialized
INFO - 2022-01-25 13:47:10 --> Model "Login_model" initialized
INFO - 2022-01-25 13:47:10 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-25 13:47:10 --> Final output sent to browser
DEBUG - 2022-01-25 13:47:10 --> Total execution time: 0.0216
ERROR - 2022-01-25 13:51:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 13:51:25 --> Config Class Initialized
INFO - 2022-01-25 13:51:25 --> Hooks Class Initialized
DEBUG - 2022-01-25 13:51:25 --> UTF-8 Support Enabled
INFO - 2022-01-25 13:51:25 --> Utf8 Class Initialized
INFO - 2022-01-25 13:51:25 --> URI Class Initialized
DEBUG - 2022-01-25 13:51:25 --> No URI present. Default controller set.
INFO - 2022-01-25 13:51:25 --> Router Class Initialized
INFO - 2022-01-25 13:51:25 --> Output Class Initialized
INFO - 2022-01-25 13:51:25 --> Security Class Initialized
DEBUG - 2022-01-25 13:51:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 13:51:25 --> Input Class Initialized
INFO - 2022-01-25 13:51:25 --> Language Class Initialized
INFO - 2022-01-25 13:51:25 --> Loader Class Initialized
INFO - 2022-01-25 13:51:25 --> Helper loaded: url_helper
INFO - 2022-01-25 13:51:25 --> Helper loaded: form_helper
INFO - 2022-01-25 13:51:25 --> Helper loaded: common_helper
INFO - 2022-01-25 13:51:25 --> Database Driver Class Initialized
DEBUG - 2022-01-25 13:51:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-25 13:51:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-25 13:51:25 --> Controller Class Initialized
INFO - 2022-01-25 13:51:25 --> Form Validation Class Initialized
DEBUG - 2022-01-25 13:51:25 --> Encrypt Class Initialized
DEBUG - 2022-01-25 13:51:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 13:51:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-25 13:51:25 --> Email Class Initialized
INFO - 2022-01-25 13:51:25 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-25 13:51:25 --> Calendar Class Initialized
INFO - 2022-01-25 13:51:25 --> Model "Login_model" initialized
INFO - 2022-01-25 13:51:25 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-25 13:51:25 --> Final output sent to browser
DEBUG - 2022-01-25 13:51:25 --> Total execution time: 0.0358
ERROR - 2022-01-25 13:51:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 13:51:26 --> Config Class Initialized
INFO - 2022-01-25 13:51:26 --> Hooks Class Initialized
DEBUG - 2022-01-25 13:51:26 --> UTF-8 Support Enabled
INFO - 2022-01-25 13:51:26 --> Utf8 Class Initialized
INFO - 2022-01-25 13:51:26 --> URI Class Initialized
INFO - 2022-01-25 13:51:26 --> Router Class Initialized
INFO - 2022-01-25 13:51:26 --> Output Class Initialized
INFO - 2022-01-25 13:51:26 --> Security Class Initialized
DEBUG - 2022-01-25 13:51:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 13:51:26 --> Input Class Initialized
INFO - 2022-01-25 13:51:26 --> Language Class Initialized
ERROR - 2022-01-25 13:51:26 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
ERROR - 2022-01-25 13:51:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 13:51:27 --> Config Class Initialized
INFO - 2022-01-25 13:51:27 --> Hooks Class Initialized
DEBUG - 2022-01-25 13:51:27 --> UTF-8 Support Enabled
INFO - 2022-01-25 13:51:27 --> Utf8 Class Initialized
INFO - 2022-01-25 13:51:27 --> URI Class Initialized
DEBUG - 2022-01-25 13:51:27 --> No URI present. Default controller set.
INFO - 2022-01-25 13:51:27 --> Router Class Initialized
INFO - 2022-01-25 13:51:27 --> Output Class Initialized
INFO - 2022-01-25 13:51:27 --> Security Class Initialized
DEBUG - 2022-01-25 13:51:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 13:51:27 --> Input Class Initialized
INFO - 2022-01-25 13:51:27 --> Language Class Initialized
INFO - 2022-01-25 13:51:27 --> Loader Class Initialized
INFO - 2022-01-25 13:51:27 --> Helper loaded: url_helper
INFO - 2022-01-25 13:51:27 --> Helper loaded: form_helper
INFO - 2022-01-25 13:51:27 --> Helper loaded: common_helper
INFO - 2022-01-25 13:51:27 --> Database Driver Class Initialized
DEBUG - 2022-01-25 13:51:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-25 13:51:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-25 13:51:27 --> Controller Class Initialized
INFO - 2022-01-25 13:51:27 --> Form Validation Class Initialized
DEBUG - 2022-01-25 13:51:27 --> Encrypt Class Initialized
DEBUG - 2022-01-25 13:51:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 13:51:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-25 13:51:27 --> Email Class Initialized
INFO - 2022-01-25 13:51:27 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-25 13:51:27 --> Calendar Class Initialized
INFO - 2022-01-25 13:51:27 --> Model "Login_model" initialized
INFO - 2022-01-25 13:51:27 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-25 13:51:27 --> Final output sent to browser
DEBUG - 2022-01-25 13:51:27 --> Total execution time: 0.0556
ERROR - 2022-01-25 13:51:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 13:51:27 --> Config Class Initialized
INFO - 2022-01-25 13:51:27 --> Hooks Class Initialized
DEBUG - 2022-01-25 13:51:27 --> UTF-8 Support Enabled
INFO - 2022-01-25 13:51:27 --> Utf8 Class Initialized
INFO - 2022-01-25 13:51:27 --> URI Class Initialized
INFO - 2022-01-25 13:51:27 --> Router Class Initialized
INFO - 2022-01-25 13:51:27 --> Output Class Initialized
INFO - 2022-01-25 13:51:27 --> Security Class Initialized
DEBUG - 2022-01-25 13:51:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 13:51:27 --> Input Class Initialized
INFO - 2022-01-25 13:51:27 --> Language Class Initialized
ERROR - 2022-01-25 13:51:27 --> 404 Page Not Found: Blog/wp-includes
ERROR - 2022-01-25 13:51:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 13:51:28 --> Config Class Initialized
INFO - 2022-01-25 13:51:28 --> Hooks Class Initialized
DEBUG - 2022-01-25 13:51:28 --> UTF-8 Support Enabled
INFO - 2022-01-25 13:51:28 --> Utf8 Class Initialized
INFO - 2022-01-25 13:51:28 --> URI Class Initialized
INFO - 2022-01-25 13:51:28 --> Router Class Initialized
INFO - 2022-01-25 13:51:28 --> Output Class Initialized
INFO - 2022-01-25 13:51:28 --> Security Class Initialized
DEBUG - 2022-01-25 13:51:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 13:51:28 --> Input Class Initialized
INFO - 2022-01-25 13:51:28 --> Language Class Initialized
ERROR - 2022-01-25 13:51:28 --> 404 Page Not Found: Web/wp-includes
ERROR - 2022-01-25 13:51:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 13:51:28 --> Config Class Initialized
INFO - 2022-01-25 13:51:28 --> Hooks Class Initialized
DEBUG - 2022-01-25 13:51:28 --> UTF-8 Support Enabled
INFO - 2022-01-25 13:51:28 --> Utf8 Class Initialized
INFO - 2022-01-25 13:51:28 --> URI Class Initialized
INFO - 2022-01-25 13:51:28 --> Router Class Initialized
INFO - 2022-01-25 13:51:28 --> Output Class Initialized
INFO - 2022-01-25 13:51:28 --> Security Class Initialized
DEBUG - 2022-01-25 13:51:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 13:51:28 --> Input Class Initialized
INFO - 2022-01-25 13:51:28 --> Language Class Initialized
ERROR - 2022-01-25 13:51:28 --> 404 Page Not Found: Wordpress/wp-includes
ERROR - 2022-01-25 13:51:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 13:51:29 --> Config Class Initialized
INFO - 2022-01-25 13:51:29 --> Hooks Class Initialized
DEBUG - 2022-01-25 13:51:29 --> UTF-8 Support Enabled
INFO - 2022-01-25 13:51:29 --> Utf8 Class Initialized
INFO - 2022-01-25 13:51:29 --> URI Class Initialized
INFO - 2022-01-25 13:51:29 --> Router Class Initialized
INFO - 2022-01-25 13:51:29 --> Output Class Initialized
INFO - 2022-01-25 13:51:29 --> Security Class Initialized
DEBUG - 2022-01-25 13:51:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 13:51:29 --> Input Class Initialized
INFO - 2022-01-25 13:51:29 --> Language Class Initialized
ERROR - 2022-01-25 13:51:29 --> 404 Page Not Found: Website/wp-includes
ERROR - 2022-01-25 13:51:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 13:51:29 --> Config Class Initialized
INFO - 2022-01-25 13:51:29 --> Hooks Class Initialized
DEBUG - 2022-01-25 13:51:29 --> UTF-8 Support Enabled
INFO - 2022-01-25 13:51:29 --> Utf8 Class Initialized
INFO - 2022-01-25 13:51:29 --> URI Class Initialized
INFO - 2022-01-25 13:51:29 --> Router Class Initialized
INFO - 2022-01-25 13:51:29 --> Output Class Initialized
INFO - 2022-01-25 13:51:29 --> Security Class Initialized
DEBUG - 2022-01-25 13:51:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 13:51:29 --> Input Class Initialized
INFO - 2022-01-25 13:51:29 --> Language Class Initialized
ERROR - 2022-01-25 13:51:29 --> 404 Page Not Found: Wp/wp-includes
ERROR - 2022-01-25 13:51:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 13:51:29 --> Config Class Initialized
INFO - 2022-01-25 13:51:29 --> Hooks Class Initialized
DEBUG - 2022-01-25 13:51:29 --> UTF-8 Support Enabled
INFO - 2022-01-25 13:51:29 --> Utf8 Class Initialized
INFO - 2022-01-25 13:51:29 --> URI Class Initialized
INFO - 2022-01-25 13:51:29 --> Router Class Initialized
INFO - 2022-01-25 13:51:29 --> Output Class Initialized
INFO - 2022-01-25 13:51:29 --> Security Class Initialized
DEBUG - 2022-01-25 13:51:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 13:51:29 --> Input Class Initialized
INFO - 2022-01-25 13:51:29 --> Language Class Initialized
ERROR - 2022-01-25 13:51:29 --> 404 Page Not Found: News/wp-includes
ERROR - 2022-01-25 13:51:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 13:51:30 --> Config Class Initialized
INFO - 2022-01-25 13:51:30 --> Hooks Class Initialized
DEBUG - 2022-01-25 13:51:30 --> UTF-8 Support Enabled
INFO - 2022-01-25 13:51:30 --> Utf8 Class Initialized
INFO - 2022-01-25 13:51:30 --> URI Class Initialized
INFO - 2022-01-25 13:51:30 --> Router Class Initialized
INFO - 2022-01-25 13:51:30 --> Output Class Initialized
INFO - 2022-01-25 13:51:30 --> Security Class Initialized
DEBUG - 2022-01-25 13:51:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 13:51:30 --> Input Class Initialized
INFO - 2022-01-25 13:51:30 --> Language Class Initialized
ERROR - 2022-01-25 13:51:30 --> 404 Page Not Found: 2018/wp-includes
ERROR - 2022-01-25 13:51:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 13:51:30 --> Config Class Initialized
INFO - 2022-01-25 13:51:30 --> Hooks Class Initialized
DEBUG - 2022-01-25 13:51:30 --> UTF-8 Support Enabled
INFO - 2022-01-25 13:51:30 --> Utf8 Class Initialized
INFO - 2022-01-25 13:51:30 --> URI Class Initialized
INFO - 2022-01-25 13:51:30 --> Router Class Initialized
INFO - 2022-01-25 13:51:30 --> Output Class Initialized
INFO - 2022-01-25 13:51:30 --> Security Class Initialized
DEBUG - 2022-01-25 13:51:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 13:51:30 --> Input Class Initialized
INFO - 2022-01-25 13:51:30 --> Language Class Initialized
ERROR - 2022-01-25 13:51:30 --> 404 Page Not Found: 2019/wp-includes
ERROR - 2022-01-25 13:51:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 13:51:31 --> Config Class Initialized
INFO - 2022-01-25 13:51:31 --> Hooks Class Initialized
DEBUG - 2022-01-25 13:51:31 --> UTF-8 Support Enabled
INFO - 2022-01-25 13:51:31 --> Utf8 Class Initialized
INFO - 2022-01-25 13:51:31 --> URI Class Initialized
INFO - 2022-01-25 13:51:31 --> Router Class Initialized
INFO - 2022-01-25 13:51:31 --> Output Class Initialized
INFO - 2022-01-25 13:51:31 --> Security Class Initialized
DEBUG - 2022-01-25 13:51:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 13:51:31 --> Input Class Initialized
INFO - 2022-01-25 13:51:31 --> Language Class Initialized
ERROR - 2022-01-25 13:51:31 --> 404 Page Not Found: Shop/wp-includes
ERROR - 2022-01-25 13:51:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 13:51:31 --> Config Class Initialized
INFO - 2022-01-25 13:51:31 --> Hooks Class Initialized
DEBUG - 2022-01-25 13:51:31 --> UTF-8 Support Enabled
INFO - 2022-01-25 13:51:31 --> Utf8 Class Initialized
INFO - 2022-01-25 13:51:31 --> URI Class Initialized
INFO - 2022-01-25 13:51:31 --> Router Class Initialized
INFO - 2022-01-25 13:51:31 --> Output Class Initialized
INFO - 2022-01-25 13:51:31 --> Security Class Initialized
DEBUG - 2022-01-25 13:51:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 13:51:31 --> Input Class Initialized
INFO - 2022-01-25 13:51:31 --> Language Class Initialized
ERROR - 2022-01-25 13:51:31 --> 404 Page Not Found: Wp1/wp-includes
ERROR - 2022-01-25 13:51:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 13:51:32 --> Config Class Initialized
INFO - 2022-01-25 13:51:32 --> Hooks Class Initialized
DEBUG - 2022-01-25 13:51:32 --> UTF-8 Support Enabled
INFO - 2022-01-25 13:51:32 --> Utf8 Class Initialized
INFO - 2022-01-25 13:51:32 --> URI Class Initialized
INFO - 2022-01-25 13:51:32 --> Router Class Initialized
INFO - 2022-01-25 13:51:32 --> Output Class Initialized
INFO - 2022-01-25 13:51:32 --> Security Class Initialized
DEBUG - 2022-01-25 13:51:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 13:51:32 --> Input Class Initialized
INFO - 2022-01-25 13:51:32 --> Language Class Initialized
ERROR - 2022-01-25 13:51:32 --> 404 Page Not Found: Test/wp-includes
ERROR - 2022-01-25 13:51:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 13:51:32 --> Config Class Initialized
INFO - 2022-01-25 13:51:32 --> Hooks Class Initialized
DEBUG - 2022-01-25 13:51:32 --> UTF-8 Support Enabled
INFO - 2022-01-25 13:51:32 --> Utf8 Class Initialized
INFO - 2022-01-25 13:51:32 --> URI Class Initialized
INFO - 2022-01-25 13:51:32 --> Router Class Initialized
INFO - 2022-01-25 13:51:32 --> Output Class Initialized
INFO - 2022-01-25 13:51:32 --> Security Class Initialized
DEBUG - 2022-01-25 13:51:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 13:51:32 --> Input Class Initialized
INFO - 2022-01-25 13:51:32 --> Language Class Initialized
ERROR - 2022-01-25 13:51:32 --> 404 Page Not Found: Media/wp-includes
ERROR - 2022-01-25 13:51:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 13:51:33 --> Config Class Initialized
INFO - 2022-01-25 13:51:33 --> Hooks Class Initialized
DEBUG - 2022-01-25 13:51:33 --> UTF-8 Support Enabled
INFO - 2022-01-25 13:51:33 --> Utf8 Class Initialized
INFO - 2022-01-25 13:51:33 --> URI Class Initialized
INFO - 2022-01-25 13:51:33 --> Router Class Initialized
INFO - 2022-01-25 13:51:33 --> Output Class Initialized
INFO - 2022-01-25 13:51:33 --> Security Class Initialized
DEBUG - 2022-01-25 13:51:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 13:51:33 --> Input Class Initialized
INFO - 2022-01-25 13:51:33 --> Language Class Initialized
ERROR - 2022-01-25 13:51:33 --> 404 Page Not Found: Wp2/wp-includes
ERROR - 2022-01-25 13:51:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 13:51:33 --> Config Class Initialized
INFO - 2022-01-25 13:51:34 --> Hooks Class Initialized
DEBUG - 2022-01-25 13:51:34 --> UTF-8 Support Enabled
INFO - 2022-01-25 13:51:34 --> Utf8 Class Initialized
INFO - 2022-01-25 13:51:34 --> URI Class Initialized
INFO - 2022-01-25 13:51:34 --> Router Class Initialized
INFO - 2022-01-25 13:51:34 --> Output Class Initialized
INFO - 2022-01-25 13:51:34 --> Security Class Initialized
DEBUG - 2022-01-25 13:51:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 13:51:34 --> Input Class Initialized
INFO - 2022-01-25 13:51:34 --> Language Class Initialized
ERROR - 2022-01-25 13:51:34 --> 404 Page Not Found: Site/wp-includes
ERROR - 2022-01-25 13:51:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 13:51:34 --> Config Class Initialized
INFO - 2022-01-25 13:51:34 --> Hooks Class Initialized
DEBUG - 2022-01-25 13:51:34 --> UTF-8 Support Enabled
INFO - 2022-01-25 13:51:34 --> Utf8 Class Initialized
INFO - 2022-01-25 13:51:34 --> URI Class Initialized
INFO - 2022-01-25 13:51:34 --> Router Class Initialized
INFO - 2022-01-25 13:51:34 --> Output Class Initialized
INFO - 2022-01-25 13:51:34 --> Security Class Initialized
DEBUG - 2022-01-25 13:51:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 13:51:34 --> Input Class Initialized
INFO - 2022-01-25 13:51:34 --> Language Class Initialized
ERROR - 2022-01-25 13:51:34 --> 404 Page Not Found: Cms/wp-includes
ERROR - 2022-01-25 13:51:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 13:51:35 --> Config Class Initialized
INFO - 2022-01-25 13:51:35 --> Hooks Class Initialized
DEBUG - 2022-01-25 13:51:35 --> UTF-8 Support Enabled
INFO - 2022-01-25 13:51:35 --> Utf8 Class Initialized
INFO - 2022-01-25 13:51:35 --> URI Class Initialized
INFO - 2022-01-25 13:51:35 --> Router Class Initialized
INFO - 2022-01-25 13:51:35 --> Output Class Initialized
INFO - 2022-01-25 13:51:35 --> Security Class Initialized
DEBUG - 2022-01-25 13:51:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 13:51:35 --> Input Class Initialized
INFO - 2022-01-25 13:51:35 --> Language Class Initialized
ERROR - 2022-01-25 13:51:35 --> 404 Page Not Found: Sito/wp-includes
ERROR - 2022-01-25 13:52:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 13:52:33 --> Config Class Initialized
INFO - 2022-01-25 13:52:33 --> Hooks Class Initialized
DEBUG - 2022-01-25 13:52:33 --> UTF-8 Support Enabled
INFO - 2022-01-25 13:52:33 --> Utf8 Class Initialized
INFO - 2022-01-25 13:52:33 --> URI Class Initialized
DEBUG - 2022-01-25 13:52:33 --> No URI present. Default controller set.
INFO - 2022-01-25 13:52:33 --> Router Class Initialized
INFO - 2022-01-25 13:52:33 --> Output Class Initialized
INFO - 2022-01-25 13:52:33 --> Security Class Initialized
DEBUG - 2022-01-25 13:52:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 13:52:33 --> Input Class Initialized
INFO - 2022-01-25 13:52:33 --> Language Class Initialized
INFO - 2022-01-25 13:52:33 --> Loader Class Initialized
INFO - 2022-01-25 13:52:33 --> Helper loaded: url_helper
INFO - 2022-01-25 13:52:33 --> Helper loaded: form_helper
INFO - 2022-01-25 13:52:33 --> Helper loaded: common_helper
INFO - 2022-01-25 13:52:33 --> Database Driver Class Initialized
DEBUG - 2022-01-25 13:52:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-25 13:52:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-25 13:52:33 --> Controller Class Initialized
INFO - 2022-01-25 13:52:33 --> Form Validation Class Initialized
DEBUG - 2022-01-25 13:52:33 --> Encrypt Class Initialized
DEBUG - 2022-01-25 13:52:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 13:52:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-25 13:52:33 --> Email Class Initialized
INFO - 2022-01-25 13:52:33 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-25 13:52:33 --> Calendar Class Initialized
INFO - 2022-01-25 13:52:33 --> Model "Login_model" initialized
INFO - 2022-01-25 13:52:33 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-25 13:52:33 --> Final output sent to browser
DEBUG - 2022-01-25 13:52:33 --> Total execution time: 0.0586
ERROR - 2022-01-25 13:52:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 13:52:33 --> Config Class Initialized
INFO - 2022-01-25 13:52:33 --> Hooks Class Initialized
DEBUG - 2022-01-25 13:52:33 --> UTF-8 Support Enabled
INFO - 2022-01-25 13:52:33 --> Utf8 Class Initialized
INFO - 2022-01-25 13:52:33 --> URI Class Initialized
DEBUG - 2022-01-25 13:52:33 --> No URI present. Default controller set.
INFO - 2022-01-25 13:52:33 --> Router Class Initialized
INFO - 2022-01-25 13:52:33 --> Output Class Initialized
INFO - 2022-01-25 13:52:33 --> Security Class Initialized
DEBUG - 2022-01-25 13:52:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 13:52:33 --> Input Class Initialized
INFO - 2022-01-25 13:52:33 --> Language Class Initialized
INFO - 2022-01-25 13:52:33 --> Loader Class Initialized
INFO - 2022-01-25 13:52:33 --> Helper loaded: url_helper
INFO - 2022-01-25 13:52:33 --> Helper loaded: form_helper
INFO - 2022-01-25 13:52:33 --> Helper loaded: common_helper
INFO - 2022-01-25 13:52:33 --> Database Driver Class Initialized
DEBUG - 2022-01-25 13:52:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-25 13:52:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-25 13:52:33 --> Controller Class Initialized
INFO - 2022-01-25 13:52:33 --> Form Validation Class Initialized
DEBUG - 2022-01-25 13:52:33 --> Encrypt Class Initialized
DEBUG - 2022-01-25 13:52:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 13:52:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-25 13:52:33 --> Email Class Initialized
INFO - 2022-01-25 13:52:33 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-25 13:52:33 --> Calendar Class Initialized
INFO - 2022-01-25 13:52:33 --> Model "Login_model" initialized
INFO - 2022-01-25 13:52:33 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-25 13:52:33 --> Final output sent to browser
DEBUG - 2022-01-25 13:52:33 --> Total execution time: 0.0901
ERROR - 2022-01-25 13:52:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 13:52:34 --> Config Class Initialized
INFO - 2022-01-25 13:52:34 --> Hooks Class Initialized
DEBUG - 2022-01-25 13:52:34 --> UTF-8 Support Enabled
INFO - 2022-01-25 13:52:34 --> Utf8 Class Initialized
INFO - 2022-01-25 13:52:34 --> URI Class Initialized
INFO - 2022-01-25 13:52:34 --> Router Class Initialized
INFO - 2022-01-25 13:52:34 --> Output Class Initialized
INFO - 2022-01-25 13:52:34 --> Security Class Initialized
DEBUG - 2022-01-25 13:52:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 13:52:34 --> Input Class Initialized
INFO - 2022-01-25 13:52:34 --> Language Class Initialized
ERROR - 2022-01-25 13:52:34 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
ERROR - 2022-01-25 13:52:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 13:52:36 --> Config Class Initialized
INFO - 2022-01-25 13:52:36 --> Hooks Class Initialized
DEBUG - 2022-01-25 13:52:36 --> UTF-8 Support Enabled
INFO - 2022-01-25 13:52:36 --> Utf8 Class Initialized
INFO - 2022-01-25 13:52:36 --> URI Class Initialized
INFO - 2022-01-25 13:52:36 --> Router Class Initialized
INFO - 2022-01-25 13:52:36 --> Output Class Initialized
INFO - 2022-01-25 13:52:36 --> Security Class Initialized
DEBUG - 2022-01-25 13:52:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 13:52:36 --> Input Class Initialized
INFO - 2022-01-25 13:52:36 --> Language Class Initialized
ERROR - 2022-01-25 13:52:36 --> 404 Page Not Found: Blog/wp-includes
ERROR - 2022-01-25 13:52:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 13:52:37 --> Config Class Initialized
INFO - 2022-01-25 13:52:37 --> Hooks Class Initialized
DEBUG - 2022-01-25 13:52:37 --> UTF-8 Support Enabled
INFO - 2022-01-25 13:52:37 --> Utf8 Class Initialized
INFO - 2022-01-25 13:52:37 --> URI Class Initialized
INFO - 2022-01-25 13:52:37 --> Router Class Initialized
INFO - 2022-01-25 13:52:37 --> Output Class Initialized
INFO - 2022-01-25 13:52:37 --> Security Class Initialized
DEBUG - 2022-01-25 13:52:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 13:52:37 --> Input Class Initialized
INFO - 2022-01-25 13:52:37 --> Language Class Initialized
ERROR - 2022-01-25 13:52:37 --> 404 Page Not Found: Web/wp-includes
ERROR - 2022-01-25 13:52:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 13:52:38 --> Config Class Initialized
INFO - 2022-01-25 13:52:38 --> Hooks Class Initialized
DEBUG - 2022-01-25 13:52:38 --> UTF-8 Support Enabled
INFO - 2022-01-25 13:52:38 --> Utf8 Class Initialized
INFO - 2022-01-25 13:52:38 --> URI Class Initialized
INFO - 2022-01-25 13:52:38 --> Router Class Initialized
INFO - 2022-01-25 13:52:38 --> Output Class Initialized
INFO - 2022-01-25 13:52:38 --> Security Class Initialized
DEBUG - 2022-01-25 13:52:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 13:52:38 --> Input Class Initialized
INFO - 2022-01-25 13:52:38 --> Language Class Initialized
ERROR - 2022-01-25 13:52:38 --> 404 Page Not Found: Wordpress/wp-includes
ERROR - 2022-01-25 13:52:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 13:52:40 --> Config Class Initialized
INFO - 2022-01-25 13:52:40 --> Hooks Class Initialized
DEBUG - 2022-01-25 13:52:40 --> UTF-8 Support Enabled
INFO - 2022-01-25 13:52:40 --> Utf8 Class Initialized
INFO - 2022-01-25 13:52:40 --> URI Class Initialized
INFO - 2022-01-25 13:52:40 --> Router Class Initialized
INFO - 2022-01-25 13:52:40 --> Output Class Initialized
INFO - 2022-01-25 13:52:40 --> Security Class Initialized
DEBUG - 2022-01-25 13:52:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 13:52:40 --> Input Class Initialized
INFO - 2022-01-25 13:52:40 --> Language Class Initialized
ERROR - 2022-01-25 13:52:40 --> 404 Page Not Found: Website/wp-includes
ERROR - 2022-01-25 13:52:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 13:52:41 --> Config Class Initialized
INFO - 2022-01-25 13:52:41 --> Hooks Class Initialized
DEBUG - 2022-01-25 13:52:41 --> UTF-8 Support Enabled
INFO - 2022-01-25 13:52:41 --> Utf8 Class Initialized
INFO - 2022-01-25 13:52:41 --> URI Class Initialized
INFO - 2022-01-25 13:52:41 --> Router Class Initialized
INFO - 2022-01-25 13:52:41 --> Output Class Initialized
INFO - 2022-01-25 13:52:41 --> Security Class Initialized
DEBUG - 2022-01-25 13:52:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 13:52:41 --> Input Class Initialized
INFO - 2022-01-25 13:52:41 --> Language Class Initialized
ERROR - 2022-01-25 13:52:41 --> 404 Page Not Found: Wp/wp-includes
ERROR - 2022-01-25 13:52:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 13:52:42 --> Config Class Initialized
INFO - 2022-01-25 13:52:42 --> Hooks Class Initialized
DEBUG - 2022-01-25 13:52:42 --> UTF-8 Support Enabled
INFO - 2022-01-25 13:52:42 --> Utf8 Class Initialized
INFO - 2022-01-25 13:52:42 --> URI Class Initialized
INFO - 2022-01-25 13:52:42 --> Router Class Initialized
INFO - 2022-01-25 13:52:42 --> Output Class Initialized
INFO - 2022-01-25 13:52:42 --> Security Class Initialized
DEBUG - 2022-01-25 13:52:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 13:52:42 --> Input Class Initialized
INFO - 2022-01-25 13:52:42 --> Language Class Initialized
ERROR - 2022-01-25 13:52:42 --> 404 Page Not Found: News/wp-includes
ERROR - 2022-01-25 13:52:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 13:52:43 --> Config Class Initialized
INFO - 2022-01-25 13:52:43 --> Hooks Class Initialized
DEBUG - 2022-01-25 13:52:43 --> UTF-8 Support Enabled
INFO - 2022-01-25 13:52:43 --> Utf8 Class Initialized
INFO - 2022-01-25 13:52:43 --> URI Class Initialized
INFO - 2022-01-25 13:52:43 --> Router Class Initialized
INFO - 2022-01-25 13:52:43 --> Output Class Initialized
INFO - 2022-01-25 13:52:43 --> Security Class Initialized
DEBUG - 2022-01-25 13:52:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 13:52:43 --> Input Class Initialized
INFO - 2022-01-25 13:52:43 --> Language Class Initialized
ERROR - 2022-01-25 13:52:43 --> 404 Page Not Found: 2018/wp-includes
ERROR - 2022-01-25 13:52:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 13:52:44 --> Config Class Initialized
INFO - 2022-01-25 13:52:44 --> Hooks Class Initialized
DEBUG - 2022-01-25 13:52:44 --> UTF-8 Support Enabled
INFO - 2022-01-25 13:52:44 --> Utf8 Class Initialized
INFO - 2022-01-25 13:52:44 --> URI Class Initialized
INFO - 2022-01-25 13:52:44 --> Router Class Initialized
INFO - 2022-01-25 13:52:44 --> Output Class Initialized
INFO - 2022-01-25 13:52:44 --> Security Class Initialized
DEBUG - 2022-01-25 13:52:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 13:52:44 --> Input Class Initialized
INFO - 2022-01-25 13:52:44 --> Language Class Initialized
ERROR - 2022-01-25 13:52:44 --> 404 Page Not Found: 2019/wp-includes
ERROR - 2022-01-25 13:52:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 13:52:45 --> Config Class Initialized
INFO - 2022-01-25 13:52:45 --> Hooks Class Initialized
DEBUG - 2022-01-25 13:52:45 --> UTF-8 Support Enabled
INFO - 2022-01-25 13:52:45 --> Utf8 Class Initialized
INFO - 2022-01-25 13:52:45 --> URI Class Initialized
INFO - 2022-01-25 13:52:45 --> Router Class Initialized
INFO - 2022-01-25 13:52:45 --> Output Class Initialized
INFO - 2022-01-25 13:52:45 --> Security Class Initialized
DEBUG - 2022-01-25 13:52:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 13:52:45 --> Input Class Initialized
INFO - 2022-01-25 13:52:45 --> Language Class Initialized
ERROR - 2022-01-25 13:52:45 --> 404 Page Not Found: Shop/wp-includes
ERROR - 2022-01-25 13:52:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 13:52:45 --> Config Class Initialized
INFO - 2022-01-25 13:52:45 --> Hooks Class Initialized
DEBUG - 2022-01-25 13:52:45 --> UTF-8 Support Enabled
INFO - 2022-01-25 13:52:45 --> Utf8 Class Initialized
INFO - 2022-01-25 13:52:45 --> URI Class Initialized
INFO - 2022-01-25 13:52:45 --> Router Class Initialized
INFO - 2022-01-25 13:52:45 --> Output Class Initialized
INFO - 2022-01-25 13:52:45 --> Security Class Initialized
DEBUG - 2022-01-25 13:52:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 13:52:45 --> Input Class Initialized
INFO - 2022-01-25 13:52:45 --> Language Class Initialized
ERROR - 2022-01-25 13:52:45 --> 404 Page Not Found: Wp1/wp-includes
ERROR - 2022-01-25 13:52:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 13:52:46 --> Config Class Initialized
INFO - 2022-01-25 13:52:46 --> Hooks Class Initialized
DEBUG - 2022-01-25 13:52:46 --> UTF-8 Support Enabled
INFO - 2022-01-25 13:52:46 --> Utf8 Class Initialized
INFO - 2022-01-25 13:52:46 --> URI Class Initialized
INFO - 2022-01-25 13:52:46 --> Router Class Initialized
INFO - 2022-01-25 13:52:46 --> Output Class Initialized
INFO - 2022-01-25 13:52:46 --> Security Class Initialized
DEBUG - 2022-01-25 13:52:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 13:52:46 --> Input Class Initialized
INFO - 2022-01-25 13:52:46 --> Language Class Initialized
ERROR - 2022-01-25 13:52:46 --> 404 Page Not Found: Test/wp-includes
ERROR - 2022-01-25 13:52:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 13:52:47 --> Config Class Initialized
INFO - 2022-01-25 13:52:47 --> Hooks Class Initialized
DEBUG - 2022-01-25 13:52:47 --> UTF-8 Support Enabled
INFO - 2022-01-25 13:52:47 --> Utf8 Class Initialized
INFO - 2022-01-25 13:52:47 --> URI Class Initialized
INFO - 2022-01-25 13:52:47 --> Router Class Initialized
INFO - 2022-01-25 13:52:47 --> Output Class Initialized
INFO - 2022-01-25 13:52:47 --> Security Class Initialized
DEBUG - 2022-01-25 13:52:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 13:52:47 --> Input Class Initialized
INFO - 2022-01-25 13:52:47 --> Language Class Initialized
ERROR - 2022-01-25 13:52:47 --> 404 Page Not Found: Media/wp-includes
ERROR - 2022-01-25 13:52:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 13:52:48 --> Config Class Initialized
INFO - 2022-01-25 13:52:48 --> Hooks Class Initialized
DEBUG - 2022-01-25 13:52:48 --> UTF-8 Support Enabled
INFO - 2022-01-25 13:52:48 --> Utf8 Class Initialized
INFO - 2022-01-25 13:52:48 --> URI Class Initialized
INFO - 2022-01-25 13:52:48 --> Router Class Initialized
INFO - 2022-01-25 13:52:48 --> Output Class Initialized
INFO - 2022-01-25 13:52:48 --> Security Class Initialized
DEBUG - 2022-01-25 13:52:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 13:52:48 --> Input Class Initialized
INFO - 2022-01-25 13:52:48 --> Language Class Initialized
ERROR - 2022-01-25 13:52:48 --> 404 Page Not Found: Wp2/wp-includes
ERROR - 2022-01-25 13:52:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 13:52:49 --> Config Class Initialized
INFO - 2022-01-25 13:52:49 --> Hooks Class Initialized
DEBUG - 2022-01-25 13:52:49 --> UTF-8 Support Enabled
INFO - 2022-01-25 13:52:49 --> Utf8 Class Initialized
INFO - 2022-01-25 13:52:49 --> URI Class Initialized
INFO - 2022-01-25 13:52:49 --> Router Class Initialized
INFO - 2022-01-25 13:52:49 --> Output Class Initialized
INFO - 2022-01-25 13:52:49 --> Security Class Initialized
DEBUG - 2022-01-25 13:52:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 13:52:49 --> Input Class Initialized
INFO - 2022-01-25 13:52:49 --> Language Class Initialized
ERROR - 2022-01-25 13:52:49 --> 404 Page Not Found: Site/wp-includes
ERROR - 2022-01-25 13:52:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 13:52:50 --> Config Class Initialized
INFO - 2022-01-25 13:52:50 --> Hooks Class Initialized
DEBUG - 2022-01-25 13:52:50 --> UTF-8 Support Enabled
INFO - 2022-01-25 13:52:50 --> Utf8 Class Initialized
INFO - 2022-01-25 13:52:50 --> URI Class Initialized
INFO - 2022-01-25 13:52:50 --> Router Class Initialized
INFO - 2022-01-25 13:52:50 --> Output Class Initialized
INFO - 2022-01-25 13:52:50 --> Security Class Initialized
DEBUG - 2022-01-25 13:52:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 13:52:50 --> Input Class Initialized
INFO - 2022-01-25 13:52:50 --> Language Class Initialized
ERROR - 2022-01-25 13:52:50 --> 404 Page Not Found: Cms/wp-includes
ERROR - 2022-01-25 13:52:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 13:52:51 --> Config Class Initialized
INFO - 2022-01-25 13:52:51 --> Hooks Class Initialized
DEBUG - 2022-01-25 13:52:51 --> UTF-8 Support Enabled
INFO - 2022-01-25 13:52:51 --> Utf8 Class Initialized
INFO - 2022-01-25 13:52:51 --> URI Class Initialized
INFO - 2022-01-25 13:52:51 --> Router Class Initialized
INFO - 2022-01-25 13:52:51 --> Output Class Initialized
INFO - 2022-01-25 13:52:51 --> Security Class Initialized
DEBUG - 2022-01-25 13:52:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 13:52:51 --> Input Class Initialized
INFO - 2022-01-25 13:52:51 --> Language Class Initialized
ERROR - 2022-01-25 13:52:51 --> 404 Page Not Found: Sito/wp-includes
ERROR - 2022-01-25 14:04:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 14:04:39 --> Config Class Initialized
INFO - 2022-01-25 14:04:39 --> Hooks Class Initialized
DEBUG - 2022-01-25 14:04:39 --> UTF-8 Support Enabled
INFO - 2022-01-25 14:04:39 --> Utf8 Class Initialized
INFO - 2022-01-25 14:04:39 --> URI Class Initialized
DEBUG - 2022-01-25 14:04:39 --> No URI present. Default controller set.
INFO - 2022-01-25 14:04:39 --> Router Class Initialized
INFO - 2022-01-25 14:04:39 --> Output Class Initialized
INFO - 2022-01-25 14:04:39 --> Security Class Initialized
DEBUG - 2022-01-25 14:04:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 14:04:39 --> Input Class Initialized
INFO - 2022-01-25 14:04:39 --> Language Class Initialized
INFO - 2022-01-25 14:04:39 --> Loader Class Initialized
INFO - 2022-01-25 14:04:39 --> Helper loaded: url_helper
INFO - 2022-01-25 14:04:39 --> Helper loaded: form_helper
INFO - 2022-01-25 14:04:39 --> Helper loaded: common_helper
INFO - 2022-01-25 14:04:39 --> Database Driver Class Initialized
DEBUG - 2022-01-25 14:04:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-25 14:04:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-25 14:04:39 --> Controller Class Initialized
INFO - 2022-01-25 14:04:39 --> Form Validation Class Initialized
DEBUG - 2022-01-25 14:04:39 --> Encrypt Class Initialized
DEBUG - 2022-01-25 14:04:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 14:04:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-25 14:04:39 --> Email Class Initialized
INFO - 2022-01-25 14:04:39 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-25 14:04:39 --> Calendar Class Initialized
INFO - 2022-01-25 14:04:39 --> Model "Login_model" initialized
INFO - 2022-01-25 14:04:39 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-25 14:04:39 --> Final output sent to browser
DEBUG - 2022-01-25 14:04:39 --> Total execution time: 0.0370
ERROR - 2022-01-25 14:04:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 14:04:39 --> Config Class Initialized
INFO - 2022-01-25 14:04:39 --> Hooks Class Initialized
DEBUG - 2022-01-25 14:04:39 --> UTF-8 Support Enabled
INFO - 2022-01-25 14:04:39 --> Utf8 Class Initialized
INFO - 2022-01-25 14:04:39 --> URI Class Initialized
DEBUG - 2022-01-25 14:04:39 --> No URI present. Default controller set.
INFO - 2022-01-25 14:04:39 --> Router Class Initialized
INFO - 2022-01-25 14:04:39 --> Output Class Initialized
INFO - 2022-01-25 14:04:39 --> Security Class Initialized
DEBUG - 2022-01-25 14:04:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 14:04:39 --> Input Class Initialized
INFO - 2022-01-25 14:04:39 --> Language Class Initialized
INFO - 2022-01-25 14:04:39 --> Loader Class Initialized
INFO - 2022-01-25 14:04:39 --> Helper loaded: url_helper
INFO - 2022-01-25 14:04:39 --> Helper loaded: form_helper
INFO - 2022-01-25 14:04:39 --> Helper loaded: common_helper
INFO - 2022-01-25 14:04:39 --> Database Driver Class Initialized
DEBUG - 2022-01-25 14:04:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-25 14:04:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-25 14:04:39 --> Controller Class Initialized
INFO - 2022-01-25 14:04:39 --> Form Validation Class Initialized
DEBUG - 2022-01-25 14:04:39 --> Encrypt Class Initialized
DEBUG - 2022-01-25 14:04:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 14:04:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-25 14:04:39 --> Email Class Initialized
INFO - 2022-01-25 14:04:39 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-25 14:04:39 --> Calendar Class Initialized
INFO - 2022-01-25 14:04:39 --> Model "Login_model" initialized
INFO - 2022-01-25 14:04:39 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-25 14:04:39 --> Final output sent to browser
DEBUG - 2022-01-25 14:04:39 --> Total execution time: 0.0348
ERROR - 2022-01-25 14:04:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 14:04:40 --> Config Class Initialized
INFO - 2022-01-25 14:04:40 --> Hooks Class Initialized
DEBUG - 2022-01-25 14:04:40 --> UTF-8 Support Enabled
INFO - 2022-01-25 14:04:40 --> Utf8 Class Initialized
INFO - 2022-01-25 14:04:40 --> URI Class Initialized
INFO - 2022-01-25 14:04:40 --> Router Class Initialized
INFO - 2022-01-25 14:04:40 --> Output Class Initialized
INFO - 2022-01-25 14:04:40 --> Security Class Initialized
DEBUG - 2022-01-25 14:04:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 14:04:40 --> Input Class Initialized
INFO - 2022-01-25 14:04:40 --> Language Class Initialized
ERROR - 2022-01-25 14:04:40 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
ERROR - 2022-01-25 14:04:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 14:04:41 --> Config Class Initialized
INFO - 2022-01-25 14:04:41 --> Hooks Class Initialized
DEBUG - 2022-01-25 14:04:41 --> UTF-8 Support Enabled
INFO - 2022-01-25 14:04:41 --> Utf8 Class Initialized
INFO - 2022-01-25 14:04:41 --> URI Class Initialized
DEBUG - 2022-01-25 14:04:41 --> No URI present. Default controller set.
INFO - 2022-01-25 14:04:41 --> Router Class Initialized
INFO - 2022-01-25 14:04:41 --> Output Class Initialized
INFO - 2022-01-25 14:04:41 --> Security Class Initialized
DEBUG - 2022-01-25 14:04:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 14:04:41 --> Input Class Initialized
INFO - 2022-01-25 14:04:41 --> Language Class Initialized
INFO - 2022-01-25 14:04:41 --> Loader Class Initialized
INFO - 2022-01-25 14:04:41 --> Helper loaded: url_helper
INFO - 2022-01-25 14:04:41 --> Helper loaded: form_helper
INFO - 2022-01-25 14:04:41 --> Helper loaded: common_helper
INFO - 2022-01-25 14:04:41 --> Database Driver Class Initialized
DEBUG - 2022-01-25 14:04:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-25 14:04:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-25 14:04:41 --> Controller Class Initialized
INFO - 2022-01-25 14:04:41 --> Form Validation Class Initialized
DEBUG - 2022-01-25 14:04:41 --> Encrypt Class Initialized
DEBUG - 2022-01-25 14:04:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 14:04:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-25 14:04:41 --> Email Class Initialized
INFO - 2022-01-25 14:04:41 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-25 14:04:41 --> Calendar Class Initialized
INFO - 2022-01-25 14:04:41 --> Model "Login_model" initialized
INFO - 2022-01-25 14:04:41 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-25 14:04:41 --> Final output sent to browser
DEBUG - 2022-01-25 14:04:41 --> Total execution time: 0.0513
ERROR - 2022-01-25 14:04:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 14:04:42 --> Config Class Initialized
INFO - 2022-01-25 14:04:42 --> Hooks Class Initialized
DEBUG - 2022-01-25 14:04:42 --> UTF-8 Support Enabled
INFO - 2022-01-25 14:04:42 --> Utf8 Class Initialized
INFO - 2022-01-25 14:04:42 --> URI Class Initialized
INFO - 2022-01-25 14:04:42 --> Router Class Initialized
INFO - 2022-01-25 14:04:42 --> Output Class Initialized
INFO - 2022-01-25 14:04:42 --> Security Class Initialized
DEBUG - 2022-01-25 14:04:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 14:04:42 --> Input Class Initialized
INFO - 2022-01-25 14:04:42 --> Language Class Initialized
ERROR - 2022-01-25 14:04:42 --> 404 Page Not Found: Blog/wp-includes
ERROR - 2022-01-25 14:04:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 14:04:43 --> Config Class Initialized
INFO - 2022-01-25 14:04:43 --> Hooks Class Initialized
DEBUG - 2022-01-25 14:04:43 --> UTF-8 Support Enabled
INFO - 2022-01-25 14:04:43 --> Utf8 Class Initialized
INFO - 2022-01-25 14:04:43 --> URI Class Initialized
INFO - 2022-01-25 14:04:43 --> Router Class Initialized
INFO - 2022-01-25 14:04:43 --> Output Class Initialized
INFO - 2022-01-25 14:04:43 --> Security Class Initialized
DEBUG - 2022-01-25 14:04:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 14:04:43 --> Input Class Initialized
INFO - 2022-01-25 14:04:43 --> Language Class Initialized
ERROR - 2022-01-25 14:04:43 --> 404 Page Not Found: Web/wp-includes
ERROR - 2022-01-25 14:04:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 14:04:44 --> Config Class Initialized
INFO - 2022-01-25 14:04:44 --> Hooks Class Initialized
DEBUG - 2022-01-25 14:04:44 --> UTF-8 Support Enabled
INFO - 2022-01-25 14:04:44 --> Utf8 Class Initialized
INFO - 2022-01-25 14:04:44 --> URI Class Initialized
INFO - 2022-01-25 14:04:44 --> Router Class Initialized
INFO - 2022-01-25 14:04:44 --> Output Class Initialized
INFO - 2022-01-25 14:04:44 --> Security Class Initialized
DEBUG - 2022-01-25 14:04:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 14:04:44 --> Input Class Initialized
INFO - 2022-01-25 14:04:44 --> Language Class Initialized
ERROR - 2022-01-25 14:04:44 --> 404 Page Not Found: Wordpress/wp-includes
ERROR - 2022-01-25 14:04:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 14:04:44 --> Config Class Initialized
INFO - 2022-01-25 14:04:44 --> Hooks Class Initialized
DEBUG - 2022-01-25 14:04:44 --> UTF-8 Support Enabled
INFO - 2022-01-25 14:04:44 --> Utf8 Class Initialized
INFO - 2022-01-25 14:04:44 --> URI Class Initialized
INFO - 2022-01-25 14:04:44 --> Router Class Initialized
INFO - 2022-01-25 14:04:44 --> Output Class Initialized
INFO - 2022-01-25 14:04:44 --> Security Class Initialized
DEBUG - 2022-01-25 14:04:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 14:04:44 --> Input Class Initialized
INFO - 2022-01-25 14:04:44 --> Language Class Initialized
ERROR - 2022-01-25 14:04:44 --> 404 Page Not Found: Website/wp-includes
ERROR - 2022-01-25 14:04:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 14:04:45 --> Config Class Initialized
INFO - 2022-01-25 14:04:45 --> Hooks Class Initialized
DEBUG - 2022-01-25 14:04:45 --> UTF-8 Support Enabled
INFO - 2022-01-25 14:04:45 --> Utf8 Class Initialized
INFO - 2022-01-25 14:04:45 --> URI Class Initialized
INFO - 2022-01-25 14:04:45 --> Router Class Initialized
INFO - 2022-01-25 14:04:45 --> Output Class Initialized
INFO - 2022-01-25 14:04:45 --> Security Class Initialized
DEBUG - 2022-01-25 14:04:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 14:04:45 --> Input Class Initialized
INFO - 2022-01-25 14:04:45 --> Language Class Initialized
ERROR - 2022-01-25 14:04:45 --> 404 Page Not Found: Wp/wp-includes
ERROR - 2022-01-25 14:04:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 14:04:45 --> Config Class Initialized
INFO - 2022-01-25 14:04:45 --> Hooks Class Initialized
DEBUG - 2022-01-25 14:04:45 --> UTF-8 Support Enabled
INFO - 2022-01-25 14:04:45 --> Utf8 Class Initialized
INFO - 2022-01-25 14:04:45 --> URI Class Initialized
INFO - 2022-01-25 14:04:45 --> Router Class Initialized
INFO - 2022-01-25 14:04:46 --> Output Class Initialized
INFO - 2022-01-25 14:04:46 --> Security Class Initialized
DEBUG - 2022-01-25 14:04:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 14:04:46 --> Input Class Initialized
INFO - 2022-01-25 14:04:46 --> Language Class Initialized
ERROR - 2022-01-25 14:04:46 --> 404 Page Not Found: News/wp-includes
ERROR - 2022-01-25 14:04:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 14:04:46 --> Config Class Initialized
INFO - 2022-01-25 14:04:46 --> Hooks Class Initialized
DEBUG - 2022-01-25 14:04:46 --> UTF-8 Support Enabled
INFO - 2022-01-25 14:04:46 --> Utf8 Class Initialized
INFO - 2022-01-25 14:04:46 --> URI Class Initialized
INFO - 2022-01-25 14:04:46 --> Router Class Initialized
INFO - 2022-01-25 14:04:46 --> Output Class Initialized
INFO - 2022-01-25 14:04:46 --> Security Class Initialized
DEBUG - 2022-01-25 14:04:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 14:04:46 --> Input Class Initialized
INFO - 2022-01-25 14:04:46 --> Language Class Initialized
ERROR - 2022-01-25 14:04:46 --> 404 Page Not Found: 2018/wp-includes
ERROR - 2022-01-25 14:04:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 14:04:47 --> Config Class Initialized
INFO - 2022-01-25 14:04:47 --> Hooks Class Initialized
DEBUG - 2022-01-25 14:04:47 --> UTF-8 Support Enabled
INFO - 2022-01-25 14:04:47 --> Utf8 Class Initialized
INFO - 2022-01-25 14:04:47 --> URI Class Initialized
INFO - 2022-01-25 14:04:47 --> Router Class Initialized
INFO - 2022-01-25 14:04:47 --> Output Class Initialized
INFO - 2022-01-25 14:04:47 --> Security Class Initialized
DEBUG - 2022-01-25 14:04:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 14:04:47 --> Input Class Initialized
INFO - 2022-01-25 14:04:47 --> Language Class Initialized
ERROR - 2022-01-25 14:04:47 --> 404 Page Not Found: 2019/wp-includes
ERROR - 2022-01-25 14:04:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 14:04:47 --> Config Class Initialized
INFO - 2022-01-25 14:04:47 --> Hooks Class Initialized
DEBUG - 2022-01-25 14:04:47 --> UTF-8 Support Enabled
INFO - 2022-01-25 14:04:47 --> Utf8 Class Initialized
INFO - 2022-01-25 14:04:47 --> URI Class Initialized
INFO - 2022-01-25 14:04:47 --> Router Class Initialized
INFO - 2022-01-25 14:04:47 --> Output Class Initialized
INFO - 2022-01-25 14:04:47 --> Security Class Initialized
DEBUG - 2022-01-25 14:04:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 14:04:47 --> Input Class Initialized
INFO - 2022-01-25 14:04:47 --> Language Class Initialized
ERROR - 2022-01-25 14:04:47 --> 404 Page Not Found: Shop/wp-includes
ERROR - 2022-01-25 14:04:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 14:04:48 --> Config Class Initialized
INFO - 2022-01-25 14:04:48 --> Hooks Class Initialized
DEBUG - 2022-01-25 14:04:48 --> UTF-8 Support Enabled
INFO - 2022-01-25 14:04:48 --> Utf8 Class Initialized
INFO - 2022-01-25 14:04:48 --> URI Class Initialized
INFO - 2022-01-25 14:04:48 --> Router Class Initialized
INFO - 2022-01-25 14:04:48 --> Output Class Initialized
INFO - 2022-01-25 14:04:48 --> Security Class Initialized
DEBUG - 2022-01-25 14:04:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 14:04:48 --> Input Class Initialized
INFO - 2022-01-25 14:04:48 --> Language Class Initialized
ERROR - 2022-01-25 14:04:48 --> 404 Page Not Found: Wp1/wp-includes
ERROR - 2022-01-25 14:04:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 14:04:49 --> Config Class Initialized
INFO - 2022-01-25 14:04:49 --> Hooks Class Initialized
DEBUG - 2022-01-25 14:04:49 --> UTF-8 Support Enabled
INFO - 2022-01-25 14:04:49 --> Utf8 Class Initialized
INFO - 2022-01-25 14:04:49 --> URI Class Initialized
INFO - 2022-01-25 14:04:49 --> Router Class Initialized
INFO - 2022-01-25 14:04:49 --> Output Class Initialized
INFO - 2022-01-25 14:04:49 --> Security Class Initialized
DEBUG - 2022-01-25 14:04:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 14:04:49 --> Input Class Initialized
INFO - 2022-01-25 14:04:49 --> Language Class Initialized
ERROR - 2022-01-25 14:04:49 --> 404 Page Not Found: Test/wp-includes
ERROR - 2022-01-25 14:04:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 14:04:49 --> Config Class Initialized
INFO - 2022-01-25 14:04:49 --> Hooks Class Initialized
DEBUG - 2022-01-25 14:04:49 --> UTF-8 Support Enabled
INFO - 2022-01-25 14:04:49 --> Utf8 Class Initialized
INFO - 2022-01-25 14:04:49 --> URI Class Initialized
INFO - 2022-01-25 14:04:49 --> Router Class Initialized
INFO - 2022-01-25 14:04:49 --> Output Class Initialized
INFO - 2022-01-25 14:04:49 --> Security Class Initialized
DEBUG - 2022-01-25 14:04:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 14:04:49 --> Input Class Initialized
INFO - 2022-01-25 14:04:49 --> Language Class Initialized
ERROR - 2022-01-25 14:04:49 --> 404 Page Not Found: Media/wp-includes
ERROR - 2022-01-25 14:04:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 14:04:50 --> Config Class Initialized
INFO - 2022-01-25 14:04:50 --> Hooks Class Initialized
DEBUG - 2022-01-25 14:04:50 --> UTF-8 Support Enabled
INFO - 2022-01-25 14:04:50 --> Utf8 Class Initialized
INFO - 2022-01-25 14:04:50 --> URI Class Initialized
INFO - 2022-01-25 14:04:50 --> Router Class Initialized
INFO - 2022-01-25 14:04:50 --> Output Class Initialized
INFO - 2022-01-25 14:04:50 --> Security Class Initialized
DEBUG - 2022-01-25 14:04:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 14:04:50 --> Input Class Initialized
INFO - 2022-01-25 14:04:50 --> Language Class Initialized
ERROR - 2022-01-25 14:04:50 --> 404 Page Not Found: Wp2/wp-includes
ERROR - 2022-01-25 14:04:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 14:04:51 --> Config Class Initialized
INFO - 2022-01-25 14:04:51 --> Hooks Class Initialized
DEBUG - 2022-01-25 14:04:51 --> UTF-8 Support Enabled
INFO - 2022-01-25 14:04:51 --> Utf8 Class Initialized
INFO - 2022-01-25 14:04:51 --> URI Class Initialized
INFO - 2022-01-25 14:04:51 --> Router Class Initialized
INFO - 2022-01-25 14:04:51 --> Output Class Initialized
INFO - 2022-01-25 14:04:51 --> Security Class Initialized
DEBUG - 2022-01-25 14:04:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 14:04:51 --> Input Class Initialized
INFO - 2022-01-25 14:04:51 --> Language Class Initialized
ERROR - 2022-01-25 14:04:51 --> 404 Page Not Found: Site/wp-includes
ERROR - 2022-01-25 14:04:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 14:04:52 --> Config Class Initialized
INFO - 2022-01-25 14:04:52 --> Hooks Class Initialized
DEBUG - 2022-01-25 14:04:52 --> UTF-8 Support Enabled
INFO - 2022-01-25 14:04:52 --> Utf8 Class Initialized
INFO - 2022-01-25 14:04:52 --> URI Class Initialized
INFO - 2022-01-25 14:04:52 --> Router Class Initialized
INFO - 2022-01-25 14:04:52 --> Output Class Initialized
INFO - 2022-01-25 14:04:52 --> Security Class Initialized
DEBUG - 2022-01-25 14:04:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 14:04:52 --> Input Class Initialized
INFO - 2022-01-25 14:04:52 --> Language Class Initialized
ERROR - 2022-01-25 14:04:52 --> 404 Page Not Found: Cms/wp-includes
ERROR - 2022-01-25 14:04:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 14:04:52 --> Config Class Initialized
INFO - 2022-01-25 14:04:52 --> Hooks Class Initialized
DEBUG - 2022-01-25 14:04:52 --> UTF-8 Support Enabled
INFO - 2022-01-25 14:04:52 --> Utf8 Class Initialized
INFO - 2022-01-25 14:04:52 --> URI Class Initialized
INFO - 2022-01-25 14:04:52 --> Router Class Initialized
INFO - 2022-01-25 14:04:52 --> Output Class Initialized
INFO - 2022-01-25 14:04:52 --> Security Class Initialized
DEBUG - 2022-01-25 14:04:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 14:04:52 --> Input Class Initialized
INFO - 2022-01-25 14:04:52 --> Language Class Initialized
ERROR - 2022-01-25 14:04:52 --> 404 Page Not Found: Sito/wp-includes
ERROR - 2022-01-25 14:22:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 14:22:37 --> Config Class Initialized
INFO - 2022-01-25 14:22:37 --> Hooks Class Initialized
DEBUG - 2022-01-25 14:22:37 --> UTF-8 Support Enabled
INFO - 2022-01-25 14:22:37 --> Utf8 Class Initialized
INFO - 2022-01-25 14:22:37 --> URI Class Initialized
DEBUG - 2022-01-25 14:22:37 --> No URI present. Default controller set.
INFO - 2022-01-25 14:22:37 --> Router Class Initialized
INFO - 2022-01-25 14:22:37 --> Output Class Initialized
INFO - 2022-01-25 14:22:37 --> Security Class Initialized
DEBUG - 2022-01-25 14:22:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 14:22:37 --> Input Class Initialized
INFO - 2022-01-25 14:22:37 --> Language Class Initialized
INFO - 2022-01-25 14:22:37 --> Loader Class Initialized
INFO - 2022-01-25 14:22:37 --> Helper loaded: url_helper
INFO - 2022-01-25 14:22:37 --> Helper loaded: form_helper
INFO - 2022-01-25 14:22:37 --> Helper loaded: common_helper
INFO - 2022-01-25 14:22:37 --> Database Driver Class Initialized
DEBUG - 2022-01-25 14:22:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-25 14:22:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-25 14:22:38 --> Controller Class Initialized
INFO - 2022-01-25 14:22:38 --> Form Validation Class Initialized
DEBUG - 2022-01-25 14:22:38 --> Encrypt Class Initialized
DEBUG - 2022-01-25 14:22:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 14:22:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-25 14:22:38 --> Email Class Initialized
INFO - 2022-01-25 14:22:38 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-25 14:22:38 --> Calendar Class Initialized
INFO - 2022-01-25 14:22:38 --> Model "Login_model" initialized
INFO - 2022-01-25 14:22:38 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-25 14:22:38 --> Final output sent to browser
DEBUG - 2022-01-25 14:22:38 --> Total execution time: 0.3622
ERROR - 2022-01-25 14:22:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 14:22:39 --> Config Class Initialized
INFO - 2022-01-25 14:22:39 --> Hooks Class Initialized
DEBUG - 2022-01-25 14:22:39 --> UTF-8 Support Enabled
INFO - 2022-01-25 14:22:39 --> Utf8 Class Initialized
INFO - 2022-01-25 14:22:39 --> URI Class Initialized
INFO - 2022-01-25 14:22:39 --> Router Class Initialized
INFO - 2022-01-25 14:22:39 --> Output Class Initialized
INFO - 2022-01-25 14:22:39 --> Security Class Initialized
DEBUG - 2022-01-25 14:22:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 14:22:39 --> Input Class Initialized
INFO - 2022-01-25 14:22:39 --> Language Class Initialized
ERROR - 2022-01-25 14:22:39 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2022-01-25 14:22:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 14:22:46 --> Config Class Initialized
INFO - 2022-01-25 14:22:46 --> Hooks Class Initialized
DEBUG - 2022-01-25 14:22:46 --> UTF-8 Support Enabled
INFO - 2022-01-25 14:22:46 --> Utf8 Class Initialized
INFO - 2022-01-25 14:22:46 --> URI Class Initialized
INFO - 2022-01-25 14:22:46 --> Router Class Initialized
INFO - 2022-01-25 14:22:46 --> Output Class Initialized
INFO - 2022-01-25 14:22:46 --> Security Class Initialized
DEBUG - 2022-01-25 14:22:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 14:22:46 --> Input Class Initialized
INFO - 2022-01-25 14:22:46 --> Language Class Initialized
INFO - 2022-01-25 14:22:46 --> Loader Class Initialized
INFO - 2022-01-25 14:22:46 --> Helper loaded: url_helper
INFO - 2022-01-25 14:22:46 --> Helper loaded: form_helper
INFO - 2022-01-25 14:22:46 --> Helper loaded: common_helper
INFO - 2022-01-25 14:22:46 --> Database Driver Class Initialized
DEBUG - 2022-01-25 14:22:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-25 14:22:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-25 14:22:46 --> Controller Class Initialized
INFO - 2022-01-25 14:22:46 --> Form Validation Class Initialized
DEBUG - 2022-01-25 14:22:46 --> Encrypt Class Initialized
DEBUG - 2022-01-25 14:22:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 14:22:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-25 14:22:46 --> Email Class Initialized
INFO - 2022-01-25 14:22:46 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-25 14:22:46 --> Calendar Class Initialized
INFO - 2022-01-25 14:22:46 --> Model "Login_model" initialized
INFO - 2022-01-25 14:22:46 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-25 14:22:46 --> Final output sent to browser
DEBUG - 2022-01-25 14:22:46 --> Total execution time: 0.0353
ERROR - 2022-01-25 14:22:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 14:22:46 --> Config Class Initialized
INFO - 2022-01-25 14:22:46 --> Hooks Class Initialized
DEBUG - 2022-01-25 14:22:46 --> UTF-8 Support Enabled
INFO - 2022-01-25 14:22:46 --> Utf8 Class Initialized
INFO - 2022-01-25 14:22:46 --> URI Class Initialized
INFO - 2022-01-25 14:22:46 --> Router Class Initialized
INFO - 2022-01-25 14:22:46 --> Output Class Initialized
INFO - 2022-01-25 14:22:46 --> Security Class Initialized
DEBUG - 2022-01-25 14:22:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 14:22:46 --> Input Class Initialized
INFO - 2022-01-25 14:22:46 --> Language Class Initialized
INFO - 2022-01-25 14:22:46 --> Loader Class Initialized
INFO - 2022-01-25 14:22:46 --> Helper loaded: url_helper
INFO - 2022-01-25 14:22:46 --> Helper loaded: form_helper
INFO - 2022-01-25 14:22:46 --> Helper loaded: common_helper
INFO - 2022-01-25 14:22:46 --> Database Driver Class Initialized
DEBUG - 2022-01-25 14:22:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-25 14:22:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-25 14:22:46 --> Controller Class Initialized
INFO - 2022-01-25 14:22:46 --> Form Validation Class Initialized
DEBUG - 2022-01-25 14:22:46 --> Encrypt Class Initialized
DEBUG - 2022-01-25 14:22:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 14:22:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-25 14:22:46 --> Email Class Initialized
INFO - 2022-01-25 14:22:46 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-25 14:22:46 --> Calendar Class Initialized
INFO - 2022-01-25 14:22:46 --> Model "Login_model" initialized
ERROR - 2022-01-25 14:22:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 14:22:47 --> Config Class Initialized
INFO - 2022-01-25 14:22:47 --> Hooks Class Initialized
DEBUG - 2022-01-25 14:22:47 --> UTF-8 Support Enabled
INFO - 2022-01-25 14:22:47 --> Utf8 Class Initialized
INFO - 2022-01-25 14:22:47 --> URI Class Initialized
INFO - 2022-01-25 14:22:47 --> Router Class Initialized
INFO - 2022-01-25 14:22:47 --> Output Class Initialized
INFO - 2022-01-25 14:22:47 --> Security Class Initialized
DEBUG - 2022-01-25 14:22:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 14:22:47 --> Input Class Initialized
INFO - 2022-01-25 14:22:47 --> Language Class Initialized
INFO - 2022-01-25 14:22:47 --> Loader Class Initialized
INFO - 2022-01-25 14:22:47 --> Helper loaded: url_helper
INFO - 2022-01-25 14:22:47 --> Helper loaded: form_helper
INFO - 2022-01-25 14:22:47 --> Helper loaded: common_helper
INFO - 2022-01-25 14:22:47 --> Database Driver Class Initialized
DEBUG - 2022-01-25 14:22:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-25 14:22:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-25 14:22:47 --> Controller Class Initialized
INFO - 2022-01-25 14:22:47 --> Form Validation Class Initialized
DEBUG - 2022-01-25 14:22:47 --> Encrypt Class Initialized
DEBUG - 2022-01-25 14:22:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 14:22:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-25 14:22:47 --> Email Class Initialized
INFO - 2022-01-25 14:22:47 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-25 14:22:47 --> Calendar Class Initialized
INFO - 2022-01-25 14:22:47 --> Model "Login_model" initialized
ERROR - 2022-01-25 14:22:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 14:22:47 --> Config Class Initialized
INFO - 2022-01-25 14:22:47 --> Hooks Class Initialized
DEBUG - 2022-01-25 14:22:47 --> UTF-8 Support Enabled
INFO - 2022-01-25 14:22:47 --> Utf8 Class Initialized
INFO - 2022-01-25 14:22:47 --> URI Class Initialized
DEBUG - 2022-01-25 14:22:47 --> No URI present. Default controller set.
INFO - 2022-01-25 14:22:47 --> Router Class Initialized
INFO - 2022-01-25 14:22:47 --> Output Class Initialized
INFO - 2022-01-25 14:22:47 --> Security Class Initialized
DEBUG - 2022-01-25 14:22:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 14:22:47 --> Input Class Initialized
INFO - 2022-01-25 14:22:47 --> Language Class Initialized
INFO - 2022-01-25 14:22:47 --> Loader Class Initialized
INFO - 2022-01-25 14:22:47 --> Helper loaded: url_helper
INFO - 2022-01-25 14:22:47 --> Helper loaded: form_helper
INFO - 2022-01-25 14:22:47 --> Helper loaded: common_helper
INFO - 2022-01-25 14:22:47 --> Database Driver Class Initialized
DEBUG - 2022-01-25 14:22:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-25 14:22:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-25 14:22:47 --> Controller Class Initialized
INFO - 2022-01-25 14:22:47 --> Form Validation Class Initialized
DEBUG - 2022-01-25 14:22:47 --> Encrypt Class Initialized
DEBUG - 2022-01-25 14:22:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 14:22:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-25 14:22:47 --> Email Class Initialized
INFO - 2022-01-25 14:22:47 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-25 14:22:47 --> Calendar Class Initialized
INFO - 2022-01-25 14:22:47 --> Model "Login_model" initialized
INFO - 2022-01-25 14:22:47 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-25 14:22:47 --> Final output sent to browser
DEBUG - 2022-01-25 14:22:47 --> Total execution time: 0.0281
ERROR - 2022-01-25 14:25:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 14:25:45 --> Config Class Initialized
INFO - 2022-01-25 14:25:45 --> Hooks Class Initialized
DEBUG - 2022-01-25 14:25:45 --> UTF-8 Support Enabled
INFO - 2022-01-25 14:25:45 --> Utf8 Class Initialized
INFO - 2022-01-25 14:25:45 --> URI Class Initialized
DEBUG - 2022-01-25 14:25:45 --> No URI present. Default controller set.
INFO - 2022-01-25 14:25:45 --> Router Class Initialized
INFO - 2022-01-25 14:25:45 --> Output Class Initialized
INFO - 2022-01-25 14:25:45 --> Security Class Initialized
DEBUG - 2022-01-25 14:25:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 14:25:45 --> Input Class Initialized
INFO - 2022-01-25 14:25:45 --> Language Class Initialized
INFO - 2022-01-25 14:25:45 --> Loader Class Initialized
INFO - 2022-01-25 14:25:45 --> Helper loaded: url_helper
INFO - 2022-01-25 14:25:45 --> Helper loaded: form_helper
INFO - 2022-01-25 14:25:45 --> Helper loaded: common_helper
INFO - 2022-01-25 14:25:45 --> Database Driver Class Initialized
DEBUG - 2022-01-25 14:25:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-25 14:25:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-25 14:25:45 --> Controller Class Initialized
INFO - 2022-01-25 14:25:45 --> Form Validation Class Initialized
DEBUG - 2022-01-25 14:25:45 --> Encrypt Class Initialized
DEBUG - 2022-01-25 14:25:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 14:25:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-25 14:25:45 --> Email Class Initialized
INFO - 2022-01-25 14:25:45 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-25 14:25:45 --> Calendar Class Initialized
INFO - 2022-01-25 14:25:45 --> Model "Login_model" initialized
INFO - 2022-01-25 14:25:45 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-25 14:25:45 --> Final output sent to browser
DEBUG - 2022-01-25 14:25:45 --> Total execution time: 0.0280
ERROR - 2022-01-25 14:25:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 14:25:45 --> Config Class Initialized
INFO - 2022-01-25 14:25:45 --> Hooks Class Initialized
DEBUG - 2022-01-25 14:25:45 --> UTF-8 Support Enabled
INFO - 2022-01-25 14:25:45 --> Utf8 Class Initialized
INFO - 2022-01-25 14:25:45 --> URI Class Initialized
DEBUG - 2022-01-25 14:25:45 --> No URI present. Default controller set.
INFO - 2022-01-25 14:25:45 --> Router Class Initialized
INFO - 2022-01-25 14:25:45 --> Output Class Initialized
INFO - 2022-01-25 14:25:45 --> Security Class Initialized
DEBUG - 2022-01-25 14:25:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 14:25:45 --> Input Class Initialized
INFO - 2022-01-25 14:25:45 --> Language Class Initialized
INFO - 2022-01-25 14:25:45 --> Loader Class Initialized
INFO - 2022-01-25 14:25:45 --> Helper loaded: url_helper
INFO - 2022-01-25 14:25:45 --> Helper loaded: form_helper
INFO - 2022-01-25 14:25:45 --> Helper loaded: common_helper
INFO - 2022-01-25 14:25:45 --> Database Driver Class Initialized
DEBUG - 2022-01-25 14:25:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-25 14:25:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-25 14:25:45 --> Controller Class Initialized
INFO - 2022-01-25 14:25:45 --> Form Validation Class Initialized
DEBUG - 2022-01-25 14:25:45 --> Encrypt Class Initialized
DEBUG - 2022-01-25 14:25:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 14:25:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-25 14:25:45 --> Email Class Initialized
INFO - 2022-01-25 14:25:45 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-25 14:25:45 --> Calendar Class Initialized
INFO - 2022-01-25 14:25:45 --> Model "Login_model" initialized
INFO - 2022-01-25 14:25:45 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-25 14:25:45 --> Final output sent to browser
DEBUG - 2022-01-25 14:25:45 --> Total execution time: 0.0236
ERROR - 2022-01-25 14:25:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 14:25:46 --> Config Class Initialized
INFO - 2022-01-25 14:25:46 --> Hooks Class Initialized
DEBUG - 2022-01-25 14:25:46 --> UTF-8 Support Enabled
INFO - 2022-01-25 14:25:46 --> Utf8 Class Initialized
INFO - 2022-01-25 14:25:46 --> URI Class Initialized
INFO - 2022-01-25 14:25:46 --> Router Class Initialized
INFO - 2022-01-25 14:25:46 --> Output Class Initialized
INFO - 2022-01-25 14:25:46 --> Security Class Initialized
DEBUG - 2022-01-25 14:25:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 14:25:46 --> Input Class Initialized
INFO - 2022-01-25 14:25:46 --> Language Class Initialized
ERROR - 2022-01-25 14:25:46 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
ERROR - 2022-01-25 14:25:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 14:25:47 --> Config Class Initialized
INFO - 2022-01-25 14:25:47 --> Hooks Class Initialized
DEBUG - 2022-01-25 14:25:47 --> UTF-8 Support Enabled
INFO - 2022-01-25 14:25:47 --> Utf8 Class Initialized
INFO - 2022-01-25 14:25:47 --> URI Class Initialized
INFO - 2022-01-25 14:25:47 --> Router Class Initialized
INFO - 2022-01-25 14:25:47 --> Output Class Initialized
INFO - 2022-01-25 14:25:47 --> Security Class Initialized
DEBUG - 2022-01-25 14:25:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 14:25:47 --> Input Class Initialized
INFO - 2022-01-25 14:25:47 --> Language Class Initialized
ERROR - 2022-01-25 14:25:47 --> 404 Page Not Found: Blog/wp-includes
ERROR - 2022-01-25 14:25:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 14:25:47 --> Config Class Initialized
INFO - 2022-01-25 14:25:47 --> Hooks Class Initialized
DEBUG - 2022-01-25 14:25:47 --> UTF-8 Support Enabled
INFO - 2022-01-25 14:25:47 --> Utf8 Class Initialized
INFO - 2022-01-25 14:25:47 --> URI Class Initialized
INFO - 2022-01-25 14:25:47 --> Router Class Initialized
INFO - 2022-01-25 14:25:47 --> Output Class Initialized
INFO - 2022-01-25 14:25:47 --> Security Class Initialized
DEBUG - 2022-01-25 14:25:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 14:25:47 --> Input Class Initialized
INFO - 2022-01-25 14:25:47 --> Language Class Initialized
ERROR - 2022-01-25 14:25:47 --> 404 Page Not Found: Web/wp-includes
ERROR - 2022-01-25 14:25:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 14:25:48 --> Config Class Initialized
INFO - 2022-01-25 14:25:48 --> Hooks Class Initialized
DEBUG - 2022-01-25 14:25:48 --> UTF-8 Support Enabled
INFO - 2022-01-25 14:25:48 --> Utf8 Class Initialized
INFO - 2022-01-25 14:25:48 --> URI Class Initialized
INFO - 2022-01-25 14:25:48 --> Router Class Initialized
INFO - 2022-01-25 14:25:48 --> Output Class Initialized
INFO - 2022-01-25 14:25:48 --> Security Class Initialized
DEBUG - 2022-01-25 14:25:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 14:25:48 --> Input Class Initialized
INFO - 2022-01-25 14:25:48 --> Language Class Initialized
ERROR - 2022-01-25 14:25:48 --> 404 Page Not Found: Wordpress/wp-includes
ERROR - 2022-01-25 14:25:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 14:25:48 --> Config Class Initialized
INFO - 2022-01-25 14:25:48 --> Hooks Class Initialized
DEBUG - 2022-01-25 14:25:48 --> UTF-8 Support Enabled
INFO - 2022-01-25 14:25:48 --> Utf8 Class Initialized
INFO - 2022-01-25 14:25:48 --> URI Class Initialized
INFO - 2022-01-25 14:25:48 --> Router Class Initialized
INFO - 2022-01-25 14:25:48 --> Output Class Initialized
INFO - 2022-01-25 14:25:48 --> Security Class Initialized
DEBUG - 2022-01-25 14:25:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 14:25:48 --> Input Class Initialized
INFO - 2022-01-25 14:25:48 --> Language Class Initialized
ERROR - 2022-01-25 14:25:48 --> 404 Page Not Found: Website/wp-includes
ERROR - 2022-01-25 14:25:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 14:25:49 --> Config Class Initialized
INFO - 2022-01-25 14:25:49 --> Hooks Class Initialized
DEBUG - 2022-01-25 14:25:49 --> UTF-8 Support Enabled
INFO - 2022-01-25 14:25:49 --> Utf8 Class Initialized
INFO - 2022-01-25 14:25:49 --> URI Class Initialized
INFO - 2022-01-25 14:25:49 --> Router Class Initialized
INFO - 2022-01-25 14:25:49 --> Output Class Initialized
INFO - 2022-01-25 14:25:49 --> Security Class Initialized
DEBUG - 2022-01-25 14:25:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 14:25:49 --> Input Class Initialized
INFO - 2022-01-25 14:25:49 --> Language Class Initialized
ERROR - 2022-01-25 14:25:49 --> 404 Page Not Found: Wp/wp-includes
ERROR - 2022-01-25 14:25:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 14:25:49 --> Config Class Initialized
INFO - 2022-01-25 14:25:49 --> Hooks Class Initialized
DEBUG - 2022-01-25 14:25:49 --> UTF-8 Support Enabled
INFO - 2022-01-25 14:25:49 --> Utf8 Class Initialized
INFO - 2022-01-25 14:25:49 --> URI Class Initialized
INFO - 2022-01-25 14:25:49 --> Router Class Initialized
INFO - 2022-01-25 14:25:49 --> Output Class Initialized
INFO - 2022-01-25 14:25:49 --> Security Class Initialized
DEBUG - 2022-01-25 14:25:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 14:25:49 --> Input Class Initialized
INFO - 2022-01-25 14:25:49 --> Language Class Initialized
ERROR - 2022-01-25 14:25:49 --> 404 Page Not Found: News/wp-includes
ERROR - 2022-01-25 14:25:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 14:25:50 --> Config Class Initialized
INFO - 2022-01-25 14:25:50 --> Hooks Class Initialized
DEBUG - 2022-01-25 14:25:50 --> UTF-8 Support Enabled
INFO - 2022-01-25 14:25:50 --> Utf8 Class Initialized
INFO - 2022-01-25 14:25:50 --> URI Class Initialized
INFO - 2022-01-25 14:25:50 --> Router Class Initialized
INFO - 2022-01-25 14:25:50 --> Output Class Initialized
INFO - 2022-01-25 14:25:50 --> Security Class Initialized
DEBUG - 2022-01-25 14:25:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 14:25:50 --> Input Class Initialized
INFO - 2022-01-25 14:25:50 --> Language Class Initialized
ERROR - 2022-01-25 14:25:50 --> 404 Page Not Found: 2018/wp-includes
ERROR - 2022-01-25 14:25:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 14:25:50 --> Config Class Initialized
INFO - 2022-01-25 14:25:50 --> Hooks Class Initialized
DEBUG - 2022-01-25 14:25:50 --> UTF-8 Support Enabled
INFO - 2022-01-25 14:25:50 --> Utf8 Class Initialized
INFO - 2022-01-25 14:25:50 --> URI Class Initialized
INFO - 2022-01-25 14:25:50 --> Router Class Initialized
INFO - 2022-01-25 14:25:50 --> Output Class Initialized
INFO - 2022-01-25 14:25:50 --> Security Class Initialized
DEBUG - 2022-01-25 14:25:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 14:25:50 --> Input Class Initialized
INFO - 2022-01-25 14:25:50 --> Language Class Initialized
ERROR - 2022-01-25 14:25:50 --> 404 Page Not Found: 2019/wp-includes
ERROR - 2022-01-25 14:25:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 14:25:51 --> Config Class Initialized
INFO - 2022-01-25 14:25:51 --> Hooks Class Initialized
DEBUG - 2022-01-25 14:25:51 --> UTF-8 Support Enabled
INFO - 2022-01-25 14:25:51 --> Utf8 Class Initialized
INFO - 2022-01-25 14:25:51 --> URI Class Initialized
INFO - 2022-01-25 14:25:51 --> Router Class Initialized
INFO - 2022-01-25 14:25:51 --> Output Class Initialized
INFO - 2022-01-25 14:25:51 --> Security Class Initialized
DEBUG - 2022-01-25 14:25:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 14:25:51 --> Input Class Initialized
INFO - 2022-01-25 14:25:51 --> Language Class Initialized
ERROR - 2022-01-25 14:25:51 --> 404 Page Not Found: Shop/wp-includes
ERROR - 2022-01-25 14:25:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 14:25:51 --> Config Class Initialized
INFO - 2022-01-25 14:25:51 --> Hooks Class Initialized
DEBUG - 2022-01-25 14:25:51 --> UTF-8 Support Enabled
INFO - 2022-01-25 14:25:51 --> Utf8 Class Initialized
INFO - 2022-01-25 14:25:51 --> URI Class Initialized
INFO - 2022-01-25 14:25:51 --> Router Class Initialized
INFO - 2022-01-25 14:25:51 --> Output Class Initialized
INFO - 2022-01-25 14:25:51 --> Security Class Initialized
DEBUG - 2022-01-25 14:25:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 14:25:51 --> Input Class Initialized
INFO - 2022-01-25 14:25:51 --> Language Class Initialized
ERROR - 2022-01-25 14:25:51 --> 404 Page Not Found: Wp1/wp-includes
ERROR - 2022-01-25 14:25:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 14:25:52 --> Config Class Initialized
INFO - 2022-01-25 14:25:52 --> Hooks Class Initialized
DEBUG - 2022-01-25 14:25:52 --> UTF-8 Support Enabled
INFO - 2022-01-25 14:25:52 --> Utf8 Class Initialized
INFO - 2022-01-25 14:25:52 --> URI Class Initialized
INFO - 2022-01-25 14:25:52 --> Router Class Initialized
INFO - 2022-01-25 14:25:52 --> Output Class Initialized
INFO - 2022-01-25 14:25:52 --> Security Class Initialized
DEBUG - 2022-01-25 14:25:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 14:25:52 --> Input Class Initialized
INFO - 2022-01-25 14:25:52 --> Language Class Initialized
ERROR - 2022-01-25 14:25:52 --> 404 Page Not Found: Test/wp-includes
ERROR - 2022-01-25 14:25:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 14:25:52 --> Config Class Initialized
INFO - 2022-01-25 14:25:52 --> Hooks Class Initialized
DEBUG - 2022-01-25 14:25:52 --> UTF-8 Support Enabled
INFO - 2022-01-25 14:25:52 --> Utf8 Class Initialized
INFO - 2022-01-25 14:25:52 --> URI Class Initialized
INFO - 2022-01-25 14:25:52 --> Router Class Initialized
INFO - 2022-01-25 14:25:52 --> Output Class Initialized
INFO - 2022-01-25 14:25:52 --> Security Class Initialized
DEBUG - 2022-01-25 14:25:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 14:25:52 --> Input Class Initialized
INFO - 2022-01-25 14:25:52 --> Language Class Initialized
ERROR - 2022-01-25 14:25:52 --> 404 Page Not Found: Media/wp-includes
ERROR - 2022-01-25 14:25:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 14:25:53 --> Config Class Initialized
INFO - 2022-01-25 14:25:53 --> Hooks Class Initialized
DEBUG - 2022-01-25 14:25:53 --> UTF-8 Support Enabled
INFO - 2022-01-25 14:25:53 --> Utf8 Class Initialized
INFO - 2022-01-25 14:25:53 --> URI Class Initialized
INFO - 2022-01-25 14:25:53 --> Router Class Initialized
INFO - 2022-01-25 14:25:53 --> Output Class Initialized
INFO - 2022-01-25 14:25:53 --> Security Class Initialized
DEBUG - 2022-01-25 14:25:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 14:25:53 --> Input Class Initialized
INFO - 2022-01-25 14:25:53 --> Language Class Initialized
ERROR - 2022-01-25 14:25:53 --> 404 Page Not Found: Wp2/wp-includes
ERROR - 2022-01-25 14:25:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 14:25:53 --> Config Class Initialized
INFO - 2022-01-25 14:25:53 --> Hooks Class Initialized
DEBUG - 2022-01-25 14:25:53 --> UTF-8 Support Enabled
INFO - 2022-01-25 14:25:53 --> Utf8 Class Initialized
INFO - 2022-01-25 14:25:53 --> URI Class Initialized
INFO - 2022-01-25 14:25:53 --> Router Class Initialized
INFO - 2022-01-25 14:25:53 --> Output Class Initialized
INFO - 2022-01-25 14:25:53 --> Security Class Initialized
DEBUG - 2022-01-25 14:25:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 14:25:53 --> Input Class Initialized
INFO - 2022-01-25 14:25:53 --> Language Class Initialized
ERROR - 2022-01-25 14:25:53 --> 404 Page Not Found: Site/wp-includes
ERROR - 2022-01-25 14:25:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 14:25:54 --> Config Class Initialized
INFO - 2022-01-25 14:25:54 --> Hooks Class Initialized
DEBUG - 2022-01-25 14:25:54 --> UTF-8 Support Enabled
INFO - 2022-01-25 14:25:54 --> Utf8 Class Initialized
INFO - 2022-01-25 14:25:54 --> URI Class Initialized
INFO - 2022-01-25 14:25:54 --> Router Class Initialized
INFO - 2022-01-25 14:25:54 --> Output Class Initialized
INFO - 2022-01-25 14:25:54 --> Security Class Initialized
DEBUG - 2022-01-25 14:25:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 14:25:54 --> Input Class Initialized
INFO - 2022-01-25 14:25:54 --> Language Class Initialized
ERROR - 2022-01-25 14:25:54 --> 404 Page Not Found: Cms/wp-includes
ERROR - 2022-01-25 14:25:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 14:25:54 --> Config Class Initialized
INFO - 2022-01-25 14:25:54 --> Hooks Class Initialized
DEBUG - 2022-01-25 14:25:54 --> UTF-8 Support Enabled
INFO - 2022-01-25 14:25:54 --> Utf8 Class Initialized
INFO - 2022-01-25 14:25:54 --> URI Class Initialized
INFO - 2022-01-25 14:25:54 --> Router Class Initialized
INFO - 2022-01-25 14:25:54 --> Output Class Initialized
INFO - 2022-01-25 14:25:54 --> Security Class Initialized
DEBUG - 2022-01-25 14:25:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 14:25:54 --> Input Class Initialized
INFO - 2022-01-25 14:25:54 --> Language Class Initialized
ERROR - 2022-01-25 14:25:54 --> 404 Page Not Found: Sito/wp-includes
ERROR - 2022-01-25 14:40:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 14:40:32 --> Config Class Initialized
INFO - 2022-01-25 14:40:32 --> Hooks Class Initialized
DEBUG - 2022-01-25 14:40:32 --> UTF-8 Support Enabled
INFO - 2022-01-25 14:40:32 --> Utf8 Class Initialized
INFO - 2022-01-25 14:40:32 --> URI Class Initialized
DEBUG - 2022-01-25 14:40:32 --> No URI present. Default controller set.
INFO - 2022-01-25 14:40:32 --> Router Class Initialized
INFO - 2022-01-25 14:40:32 --> Output Class Initialized
INFO - 2022-01-25 14:40:32 --> Security Class Initialized
DEBUG - 2022-01-25 14:40:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 14:40:32 --> Input Class Initialized
INFO - 2022-01-25 14:40:32 --> Language Class Initialized
INFO - 2022-01-25 14:40:32 --> Loader Class Initialized
INFO - 2022-01-25 14:40:32 --> Helper loaded: url_helper
INFO - 2022-01-25 14:40:32 --> Helper loaded: form_helper
INFO - 2022-01-25 14:40:32 --> Helper loaded: common_helper
INFO - 2022-01-25 14:40:32 --> Database Driver Class Initialized
DEBUG - 2022-01-25 14:40:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-25 14:40:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-25 14:40:32 --> Controller Class Initialized
INFO - 2022-01-25 14:40:32 --> Form Validation Class Initialized
DEBUG - 2022-01-25 14:40:32 --> Encrypt Class Initialized
DEBUG - 2022-01-25 14:40:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 14:40:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-25 14:40:32 --> Email Class Initialized
INFO - 2022-01-25 14:40:32 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-25 14:40:32 --> Calendar Class Initialized
INFO - 2022-01-25 14:40:32 --> Model "Login_model" initialized
INFO - 2022-01-25 14:40:32 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-25 14:40:32 --> Final output sent to browser
DEBUG - 2022-01-25 14:40:32 --> Total execution time: 0.0344
ERROR - 2022-01-25 14:40:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 14:40:32 --> Config Class Initialized
INFO - 2022-01-25 14:40:32 --> Hooks Class Initialized
DEBUG - 2022-01-25 14:40:32 --> UTF-8 Support Enabled
INFO - 2022-01-25 14:40:32 --> Utf8 Class Initialized
INFO - 2022-01-25 14:40:32 --> URI Class Initialized
DEBUG - 2022-01-25 14:40:32 --> No URI present. Default controller set.
INFO - 2022-01-25 14:40:32 --> Router Class Initialized
INFO - 2022-01-25 14:40:32 --> Output Class Initialized
INFO - 2022-01-25 14:40:32 --> Security Class Initialized
DEBUG - 2022-01-25 14:40:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 14:40:32 --> Input Class Initialized
INFO - 2022-01-25 14:40:32 --> Language Class Initialized
INFO - 2022-01-25 14:40:32 --> Loader Class Initialized
INFO - 2022-01-25 14:40:32 --> Helper loaded: url_helper
INFO - 2022-01-25 14:40:32 --> Helper loaded: form_helper
INFO - 2022-01-25 14:40:32 --> Helper loaded: common_helper
INFO - 2022-01-25 14:40:32 --> Database Driver Class Initialized
DEBUG - 2022-01-25 14:40:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-25 14:40:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-25 14:40:32 --> Controller Class Initialized
INFO - 2022-01-25 14:40:32 --> Form Validation Class Initialized
DEBUG - 2022-01-25 14:40:32 --> Encrypt Class Initialized
DEBUG - 2022-01-25 14:40:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 14:40:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-25 14:40:32 --> Email Class Initialized
INFO - 2022-01-25 14:40:32 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-25 14:40:32 --> Calendar Class Initialized
INFO - 2022-01-25 14:40:32 --> Model "Login_model" initialized
INFO - 2022-01-25 14:40:32 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-25 14:40:32 --> Final output sent to browser
DEBUG - 2022-01-25 14:40:32 --> Total execution time: 0.0369
ERROR - 2022-01-25 14:40:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 14:40:33 --> Config Class Initialized
INFO - 2022-01-25 14:40:33 --> Hooks Class Initialized
DEBUG - 2022-01-25 14:40:33 --> UTF-8 Support Enabled
INFO - 2022-01-25 14:40:33 --> Utf8 Class Initialized
INFO - 2022-01-25 14:40:33 --> URI Class Initialized
INFO - 2022-01-25 14:40:33 --> Router Class Initialized
INFO - 2022-01-25 14:40:33 --> Output Class Initialized
INFO - 2022-01-25 14:40:33 --> Security Class Initialized
DEBUG - 2022-01-25 14:40:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 14:40:33 --> Input Class Initialized
INFO - 2022-01-25 14:40:33 --> Language Class Initialized
ERROR - 2022-01-25 14:40:33 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
ERROR - 2022-01-25 14:40:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 14:40:34 --> Config Class Initialized
INFO - 2022-01-25 14:40:34 --> Hooks Class Initialized
DEBUG - 2022-01-25 14:40:34 --> UTF-8 Support Enabled
INFO - 2022-01-25 14:40:34 --> Utf8 Class Initialized
INFO - 2022-01-25 14:40:34 --> URI Class Initialized
INFO - 2022-01-25 14:40:34 --> Router Class Initialized
INFO - 2022-01-25 14:40:34 --> Output Class Initialized
INFO - 2022-01-25 14:40:34 --> Security Class Initialized
DEBUG - 2022-01-25 14:40:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 14:40:34 --> Input Class Initialized
INFO - 2022-01-25 14:40:34 --> Language Class Initialized
ERROR - 2022-01-25 14:40:34 --> 404 Page Not Found: Blog/wp-includes
ERROR - 2022-01-25 14:40:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 14:40:35 --> Config Class Initialized
INFO - 2022-01-25 14:40:35 --> Hooks Class Initialized
DEBUG - 2022-01-25 14:40:35 --> UTF-8 Support Enabled
INFO - 2022-01-25 14:40:35 --> Utf8 Class Initialized
INFO - 2022-01-25 14:40:35 --> URI Class Initialized
INFO - 2022-01-25 14:40:35 --> Router Class Initialized
INFO - 2022-01-25 14:40:35 --> Output Class Initialized
INFO - 2022-01-25 14:40:35 --> Security Class Initialized
DEBUG - 2022-01-25 14:40:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 14:40:35 --> Input Class Initialized
INFO - 2022-01-25 14:40:35 --> Language Class Initialized
ERROR - 2022-01-25 14:40:35 --> 404 Page Not Found: Web/wp-includes
ERROR - 2022-01-25 14:40:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 14:40:35 --> Config Class Initialized
INFO - 2022-01-25 14:40:35 --> Hooks Class Initialized
DEBUG - 2022-01-25 14:40:35 --> UTF-8 Support Enabled
INFO - 2022-01-25 14:40:35 --> Utf8 Class Initialized
INFO - 2022-01-25 14:40:35 --> URI Class Initialized
INFO - 2022-01-25 14:40:35 --> Router Class Initialized
INFO - 2022-01-25 14:40:35 --> Output Class Initialized
INFO - 2022-01-25 14:40:35 --> Security Class Initialized
DEBUG - 2022-01-25 14:40:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 14:40:35 --> Input Class Initialized
INFO - 2022-01-25 14:40:35 --> Language Class Initialized
ERROR - 2022-01-25 14:40:35 --> 404 Page Not Found: Wordpress/wp-includes
ERROR - 2022-01-25 14:40:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 14:40:36 --> Config Class Initialized
INFO - 2022-01-25 14:40:36 --> Hooks Class Initialized
DEBUG - 2022-01-25 14:40:36 --> UTF-8 Support Enabled
INFO - 2022-01-25 14:40:36 --> Utf8 Class Initialized
INFO - 2022-01-25 14:40:36 --> URI Class Initialized
INFO - 2022-01-25 14:40:36 --> Router Class Initialized
INFO - 2022-01-25 14:40:36 --> Output Class Initialized
INFO - 2022-01-25 14:40:36 --> Security Class Initialized
DEBUG - 2022-01-25 14:40:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 14:40:36 --> Input Class Initialized
INFO - 2022-01-25 14:40:36 --> Language Class Initialized
ERROR - 2022-01-25 14:40:36 --> 404 Page Not Found: Website/wp-includes
ERROR - 2022-01-25 14:40:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 14:40:37 --> Config Class Initialized
INFO - 2022-01-25 14:40:37 --> Hooks Class Initialized
DEBUG - 2022-01-25 14:40:37 --> UTF-8 Support Enabled
INFO - 2022-01-25 14:40:37 --> Utf8 Class Initialized
INFO - 2022-01-25 14:40:37 --> URI Class Initialized
INFO - 2022-01-25 14:40:37 --> Router Class Initialized
INFO - 2022-01-25 14:40:37 --> Output Class Initialized
INFO - 2022-01-25 14:40:37 --> Security Class Initialized
DEBUG - 2022-01-25 14:40:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 14:40:37 --> Input Class Initialized
INFO - 2022-01-25 14:40:37 --> Language Class Initialized
ERROR - 2022-01-25 14:40:37 --> 404 Page Not Found: Wp/wp-includes
ERROR - 2022-01-25 14:40:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 14:40:38 --> Config Class Initialized
INFO - 2022-01-25 14:40:38 --> Hooks Class Initialized
DEBUG - 2022-01-25 14:40:38 --> UTF-8 Support Enabled
INFO - 2022-01-25 14:40:38 --> Utf8 Class Initialized
INFO - 2022-01-25 14:40:38 --> URI Class Initialized
INFO - 2022-01-25 14:40:38 --> Router Class Initialized
INFO - 2022-01-25 14:40:38 --> Output Class Initialized
INFO - 2022-01-25 14:40:38 --> Security Class Initialized
DEBUG - 2022-01-25 14:40:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 14:40:38 --> Input Class Initialized
INFO - 2022-01-25 14:40:38 --> Language Class Initialized
ERROR - 2022-01-25 14:40:38 --> 404 Page Not Found: News/wp-includes
ERROR - 2022-01-25 14:40:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 14:40:38 --> Config Class Initialized
INFO - 2022-01-25 14:40:38 --> Hooks Class Initialized
DEBUG - 2022-01-25 14:40:38 --> UTF-8 Support Enabled
INFO - 2022-01-25 14:40:38 --> Utf8 Class Initialized
INFO - 2022-01-25 14:40:38 --> URI Class Initialized
INFO - 2022-01-25 14:40:38 --> Router Class Initialized
INFO - 2022-01-25 14:40:38 --> Output Class Initialized
INFO - 2022-01-25 14:40:38 --> Security Class Initialized
DEBUG - 2022-01-25 14:40:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 14:40:38 --> Input Class Initialized
INFO - 2022-01-25 14:40:38 --> Language Class Initialized
ERROR - 2022-01-25 14:40:38 --> 404 Page Not Found: 2018/wp-includes
ERROR - 2022-01-25 14:40:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 14:40:39 --> Config Class Initialized
INFO - 2022-01-25 14:40:39 --> Hooks Class Initialized
DEBUG - 2022-01-25 14:40:39 --> UTF-8 Support Enabled
INFO - 2022-01-25 14:40:39 --> Utf8 Class Initialized
INFO - 2022-01-25 14:40:39 --> URI Class Initialized
INFO - 2022-01-25 14:40:39 --> Router Class Initialized
INFO - 2022-01-25 14:40:39 --> Output Class Initialized
INFO - 2022-01-25 14:40:39 --> Security Class Initialized
DEBUG - 2022-01-25 14:40:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 14:40:39 --> Input Class Initialized
INFO - 2022-01-25 14:40:39 --> Language Class Initialized
ERROR - 2022-01-25 14:40:39 --> 404 Page Not Found: 2019/wp-includes
ERROR - 2022-01-25 14:40:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 14:40:39 --> Config Class Initialized
INFO - 2022-01-25 14:40:39 --> Hooks Class Initialized
DEBUG - 2022-01-25 14:40:39 --> UTF-8 Support Enabled
INFO - 2022-01-25 14:40:39 --> Utf8 Class Initialized
INFO - 2022-01-25 14:40:39 --> URI Class Initialized
INFO - 2022-01-25 14:40:39 --> Router Class Initialized
INFO - 2022-01-25 14:40:39 --> Output Class Initialized
INFO - 2022-01-25 14:40:39 --> Security Class Initialized
DEBUG - 2022-01-25 14:40:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 14:40:39 --> Input Class Initialized
INFO - 2022-01-25 14:40:39 --> Language Class Initialized
ERROR - 2022-01-25 14:40:39 --> 404 Page Not Found: Shop/wp-includes
ERROR - 2022-01-25 14:40:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 14:40:40 --> Config Class Initialized
INFO - 2022-01-25 14:40:40 --> Hooks Class Initialized
DEBUG - 2022-01-25 14:40:40 --> UTF-8 Support Enabled
INFO - 2022-01-25 14:40:40 --> Utf8 Class Initialized
INFO - 2022-01-25 14:40:40 --> URI Class Initialized
INFO - 2022-01-25 14:40:40 --> Router Class Initialized
INFO - 2022-01-25 14:40:40 --> Output Class Initialized
INFO - 2022-01-25 14:40:40 --> Security Class Initialized
DEBUG - 2022-01-25 14:40:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 14:40:40 --> Input Class Initialized
INFO - 2022-01-25 14:40:40 --> Language Class Initialized
ERROR - 2022-01-25 14:40:40 --> 404 Page Not Found: Wp1/wp-includes
ERROR - 2022-01-25 14:40:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 14:40:40 --> Config Class Initialized
INFO - 2022-01-25 14:40:40 --> Hooks Class Initialized
DEBUG - 2022-01-25 14:40:40 --> UTF-8 Support Enabled
INFO - 2022-01-25 14:40:40 --> Utf8 Class Initialized
INFO - 2022-01-25 14:40:40 --> URI Class Initialized
INFO - 2022-01-25 14:40:40 --> Router Class Initialized
INFO - 2022-01-25 14:40:40 --> Output Class Initialized
INFO - 2022-01-25 14:40:40 --> Security Class Initialized
DEBUG - 2022-01-25 14:40:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 14:40:40 --> Input Class Initialized
INFO - 2022-01-25 14:40:40 --> Language Class Initialized
ERROR - 2022-01-25 14:40:40 --> 404 Page Not Found: Test/wp-includes
ERROR - 2022-01-25 14:40:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 14:40:41 --> Config Class Initialized
INFO - 2022-01-25 14:40:41 --> Hooks Class Initialized
DEBUG - 2022-01-25 14:40:41 --> UTF-8 Support Enabled
INFO - 2022-01-25 14:40:41 --> Utf8 Class Initialized
INFO - 2022-01-25 14:40:41 --> URI Class Initialized
INFO - 2022-01-25 14:40:41 --> Router Class Initialized
INFO - 2022-01-25 14:40:41 --> Output Class Initialized
INFO - 2022-01-25 14:40:41 --> Security Class Initialized
DEBUG - 2022-01-25 14:40:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 14:40:41 --> Input Class Initialized
INFO - 2022-01-25 14:40:41 --> Language Class Initialized
ERROR - 2022-01-25 14:40:41 --> 404 Page Not Found: Media/wp-includes
ERROR - 2022-01-25 14:40:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 14:40:41 --> Config Class Initialized
INFO - 2022-01-25 14:40:41 --> Hooks Class Initialized
DEBUG - 2022-01-25 14:40:41 --> UTF-8 Support Enabled
INFO - 2022-01-25 14:40:41 --> Utf8 Class Initialized
INFO - 2022-01-25 14:40:41 --> URI Class Initialized
INFO - 2022-01-25 14:40:41 --> Router Class Initialized
INFO - 2022-01-25 14:40:41 --> Output Class Initialized
INFO - 2022-01-25 14:40:41 --> Security Class Initialized
DEBUG - 2022-01-25 14:40:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 14:40:41 --> Input Class Initialized
INFO - 2022-01-25 14:40:41 --> Language Class Initialized
ERROR - 2022-01-25 14:40:41 --> 404 Page Not Found: Wp2/wp-includes
ERROR - 2022-01-25 14:40:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 14:40:42 --> Config Class Initialized
INFO - 2022-01-25 14:40:42 --> Hooks Class Initialized
DEBUG - 2022-01-25 14:40:42 --> UTF-8 Support Enabled
INFO - 2022-01-25 14:40:42 --> Utf8 Class Initialized
INFO - 2022-01-25 14:40:42 --> URI Class Initialized
INFO - 2022-01-25 14:40:42 --> Router Class Initialized
INFO - 2022-01-25 14:40:42 --> Output Class Initialized
INFO - 2022-01-25 14:40:42 --> Security Class Initialized
DEBUG - 2022-01-25 14:40:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 14:40:42 --> Input Class Initialized
INFO - 2022-01-25 14:40:42 --> Language Class Initialized
ERROR - 2022-01-25 14:40:42 --> 404 Page Not Found: Site/wp-includes
ERROR - 2022-01-25 14:40:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 14:40:43 --> Config Class Initialized
INFO - 2022-01-25 14:40:43 --> Hooks Class Initialized
DEBUG - 2022-01-25 14:40:43 --> UTF-8 Support Enabled
INFO - 2022-01-25 14:40:43 --> Utf8 Class Initialized
INFO - 2022-01-25 14:40:43 --> URI Class Initialized
INFO - 2022-01-25 14:40:43 --> Router Class Initialized
INFO - 2022-01-25 14:40:43 --> Output Class Initialized
INFO - 2022-01-25 14:40:43 --> Security Class Initialized
DEBUG - 2022-01-25 14:40:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 14:40:43 --> Input Class Initialized
INFO - 2022-01-25 14:40:43 --> Language Class Initialized
ERROR - 2022-01-25 14:40:43 --> 404 Page Not Found: Cms/wp-includes
ERROR - 2022-01-25 14:40:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 14:40:43 --> Config Class Initialized
INFO - 2022-01-25 14:40:43 --> Hooks Class Initialized
DEBUG - 2022-01-25 14:40:43 --> UTF-8 Support Enabled
INFO - 2022-01-25 14:40:43 --> Utf8 Class Initialized
INFO - 2022-01-25 14:40:43 --> URI Class Initialized
INFO - 2022-01-25 14:40:43 --> Router Class Initialized
INFO - 2022-01-25 14:40:43 --> Output Class Initialized
INFO - 2022-01-25 14:40:43 --> Security Class Initialized
DEBUG - 2022-01-25 14:40:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 14:40:43 --> Input Class Initialized
INFO - 2022-01-25 14:40:43 --> Language Class Initialized
ERROR - 2022-01-25 14:40:43 --> 404 Page Not Found: Sito/wp-includes
ERROR - 2022-01-25 15:08:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 15:08:53 --> Config Class Initialized
INFO - 2022-01-25 15:08:53 --> Hooks Class Initialized
DEBUG - 2022-01-25 15:08:53 --> UTF-8 Support Enabled
INFO - 2022-01-25 15:08:53 --> Utf8 Class Initialized
INFO - 2022-01-25 15:08:53 --> URI Class Initialized
DEBUG - 2022-01-25 15:08:53 --> No URI present. Default controller set.
INFO - 2022-01-25 15:08:53 --> Router Class Initialized
INFO - 2022-01-25 15:08:53 --> Output Class Initialized
INFO - 2022-01-25 15:08:53 --> Security Class Initialized
DEBUG - 2022-01-25 15:08:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 15:08:53 --> Input Class Initialized
INFO - 2022-01-25 15:08:53 --> Language Class Initialized
INFO - 2022-01-25 15:08:53 --> Loader Class Initialized
INFO - 2022-01-25 15:08:53 --> Helper loaded: url_helper
INFO - 2022-01-25 15:08:53 --> Helper loaded: form_helper
INFO - 2022-01-25 15:08:53 --> Helper loaded: common_helper
INFO - 2022-01-25 15:08:53 --> Database Driver Class Initialized
DEBUG - 2022-01-25 15:08:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-25 15:08:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-25 15:08:53 --> Controller Class Initialized
INFO - 2022-01-25 15:08:53 --> Form Validation Class Initialized
DEBUG - 2022-01-25 15:08:53 --> Encrypt Class Initialized
DEBUG - 2022-01-25 15:08:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 15:08:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-25 15:08:53 --> Email Class Initialized
INFO - 2022-01-25 15:08:53 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-25 15:08:53 --> Calendar Class Initialized
INFO - 2022-01-25 15:08:53 --> Model "Login_model" initialized
INFO - 2022-01-25 15:08:53 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-25 15:08:53 --> Final output sent to browser
DEBUG - 2022-01-25 15:08:53 --> Total execution time: 0.0284
ERROR - 2022-01-25 15:17:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 15:17:34 --> Config Class Initialized
INFO - 2022-01-25 15:17:34 --> Hooks Class Initialized
DEBUG - 2022-01-25 15:17:34 --> UTF-8 Support Enabled
INFO - 2022-01-25 15:17:34 --> Utf8 Class Initialized
INFO - 2022-01-25 15:17:34 --> URI Class Initialized
DEBUG - 2022-01-25 15:17:34 --> No URI present. Default controller set.
INFO - 2022-01-25 15:17:34 --> Router Class Initialized
INFO - 2022-01-25 15:17:34 --> Output Class Initialized
INFO - 2022-01-25 15:17:34 --> Security Class Initialized
DEBUG - 2022-01-25 15:17:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 15:17:34 --> Input Class Initialized
INFO - 2022-01-25 15:17:34 --> Language Class Initialized
INFO - 2022-01-25 15:17:34 --> Loader Class Initialized
INFO - 2022-01-25 15:17:34 --> Helper loaded: url_helper
INFO - 2022-01-25 15:17:34 --> Helper loaded: form_helper
INFO - 2022-01-25 15:17:34 --> Helper loaded: common_helper
INFO - 2022-01-25 15:17:34 --> Database Driver Class Initialized
DEBUG - 2022-01-25 15:17:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-25 15:17:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-25 15:17:34 --> Controller Class Initialized
INFO - 2022-01-25 15:17:34 --> Form Validation Class Initialized
DEBUG - 2022-01-25 15:17:34 --> Encrypt Class Initialized
DEBUG - 2022-01-25 15:17:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 15:17:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-25 15:17:34 --> Email Class Initialized
INFO - 2022-01-25 15:17:34 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-25 15:17:34 --> Calendar Class Initialized
INFO - 2022-01-25 15:17:34 --> Model "Login_model" initialized
INFO - 2022-01-25 15:17:34 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-25 15:17:34 --> Final output sent to browser
DEBUG - 2022-01-25 15:17:34 --> Total execution time: 0.0268
ERROR - 2022-01-25 15:17:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 15:17:35 --> Config Class Initialized
INFO - 2022-01-25 15:17:35 --> Hooks Class Initialized
DEBUG - 2022-01-25 15:17:35 --> UTF-8 Support Enabled
INFO - 2022-01-25 15:17:35 --> Utf8 Class Initialized
INFO - 2022-01-25 15:17:35 --> URI Class Initialized
DEBUG - 2022-01-25 15:17:35 --> No URI present. Default controller set.
INFO - 2022-01-25 15:17:35 --> Router Class Initialized
INFO - 2022-01-25 15:17:35 --> Output Class Initialized
INFO - 2022-01-25 15:17:35 --> Security Class Initialized
DEBUG - 2022-01-25 15:17:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 15:17:35 --> Input Class Initialized
INFO - 2022-01-25 15:17:35 --> Language Class Initialized
INFO - 2022-01-25 15:17:35 --> Loader Class Initialized
INFO - 2022-01-25 15:17:35 --> Helper loaded: url_helper
INFO - 2022-01-25 15:17:35 --> Helper loaded: form_helper
INFO - 2022-01-25 15:17:35 --> Helper loaded: common_helper
INFO - 2022-01-25 15:17:35 --> Database Driver Class Initialized
DEBUG - 2022-01-25 15:17:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-25 15:17:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-25 15:17:35 --> Controller Class Initialized
INFO - 2022-01-25 15:17:35 --> Form Validation Class Initialized
DEBUG - 2022-01-25 15:17:35 --> Encrypt Class Initialized
DEBUG - 2022-01-25 15:17:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 15:17:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-25 15:17:35 --> Email Class Initialized
INFO - 2022-01-25 15:17:35 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-25 15:17:35 --> Calendar Class Initialized
INFO - 2022-01-25 15:17:35 --> Model "Login_model" initialized
INFO - 2022-01-25 15:17:35 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-25 15:17:35 --> Final output sent to browser
DEBUG - 2022-01-25 15:17:35 --> Total execution time: 0.0218
ERROR - 2022-01-25 15:17:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 15:17:35 --> Config Class Initialized
INFO - 2022-01-25 15:17:35 --> Hooks Class Initialized
DEBUG - 2022-01-25 15:17:35 --> UTF-8 Support Enabled
INFO - 2022-01-25 15:17:35 --> Utf8 Class Initialized
INFO - 2022-01-25 15:17:35 --> URI Class Initialized
INFO - 2022-01-25 15:17:35 --> Router Class Initialized
INFO - 2022-01-25 15:17:35 --> Output Class Initialized
INFO - 2022-01-25 15:17:35 --> Security Class Initialized
DEBUG - 2022-01-25 15:17:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 15:17:35 --> Input Class Initialized
INFO - 2022-01-25 15:17:35 --> Language Class Initialized
ERROR - 2022-01-25 15:17:35 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
ERROR - 2022-01-25 15:17:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 15:17:36 --> Config Class Initialized
INFO - 2022-01-25 15:17:36 --> Hooks Class Initialized
DEBUG - 2022-01-25 15:17:36 --> UTF-8 Support Enabled
INFO - 2022-01-25 15:17:36 --> Utf8 Class Initialized
INFO - 2022-01-25 15:17:36 --> URI Class Initialized
DEBUG - 2022-01-25 15:17:36 --> No URI present. Default controller set.
INFO - 2022-01-25 15:17:36 --> Router Class Initialized
INFO - 2022-01-25 15:17:36 --> Output Class Initialized
INFO - 2022-01-25 15:17:36 --> Security Class Initialized
DEBUG - 2022-01-25 15:17:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 15:17:36 --> Input Class Initialized
INFO - 2022-01-25 15:17:36 --> Language Class Initialized
INFO - 2022-01-25 15:17:36 --> Loader Class Initialized
INFO - 2022-01-25 15:17:36 --> Helper loaded: url_helper
INFO - 2022-01-25 15:17:36 --> Helper loaded: form_helper
INFO - 2022-01-25 15:17:36 --> Helper loaded: common_helper
INFO - 2022-01-25 15:17:36 --> Database Driver Class Initialized
DEBUG - 2022-01-25 15:17:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-25 15:17:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-25 15:17:36 --> Controller Class Initialized
INFO - 2022-01-25 15:17:36 --> Form Validation Class Initialized
DEBUG - 2022-01-25 15:17:36 --> Encrypt Class Initialized
DEBUG - 2022-01-25 15:17:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 15:17:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-25 15:17:36 --> Email Class Initialized
INFO - 2022-01-25 15:17:36 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-25 15:17:36 --> Calendar Class Initialized
INFO - 2022-01-25 15:17:36 --> Model "Login_model" initialized
INFO - 2022-01-25 15:17:36 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-25 15:17:36 --> Final output sent to browser
DEBUG - 2022-01-25 15:17:36 --> Total execution time: 0.0245
ERROR - 2022-01-25 15:17:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 15:17:37 --> Config Class Initialized
INFO - 2022-01-25 15:17:37 --> Hooks Class Initialized
DEBUG - 2022-01-25 15:17:37 --> UTF-8 Support Enabled
INFO - 2022-01-25 15:17:37 --> Utf8 Class Initialized
INFO - 2022-01-25 15:17:37 --> URI Class Initialized
INFO - 2022-01-25 15:17:37 --> Router Class Initialized
INFO - 2022-01-25 15:17:37 --> Output Class Initialized
INFO - 2022-01-25 15:17:37 --> Security Class Initialized
DEBUG - 2022-01-25 15:17:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 15:17:37 --> Input Class Initialized
INFO - 2022-01-25 15:17:37 --> Language Class Initialized
ERROR - 2022-01-25 15:17:37 --> 404 Page Not Found: Blog/wp-includes
ERROR - 2022-01-25 15:17:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 15:17:37 --> Config Class Initialized
INFO - 2022-01-25 15:17:37 --> Hooks Class Initialized
DEBUG - 2022-01-25 15:17:37 --> UTF-8 Support Enabled
INFO - 2022-01-25 15:17:37 --> Utf8 Class Initialized
INFO - 2022-01-25 15:17:37 --> URI Class Initialized
INFO - 2022-01-25 15:17:37 --> Router Class Initialized
INFO - 2022-01-25 15:17:37 --> Output Class Initialized
INFO - 2022-01-25 15:17:37 --> Security Class Initialized
DEBUG - 2022-01-25 15:17:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 15:17:37 --> Input Class Initialized
INFO - 2022-01-25 15:17:37 --> Language Class Initialized
ERROR - 2022-01-25 15:17:37 --> 404 Page Not Found: Web/wp-includes
ERROR - 2022-01-25 15:17:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 15:17:38 --> Config Class Initialized
INFO - 2022-01-25 15:17:38 --> Hooks Class Initialized
DEBUG - 2022-01-25 15:17:38 --> UTF-8 Support Enabled
INFO - 2022-01-25 15:17:38 --> Utf8 Class Initialized
INFO - 2022-01-25 15:17:38 --> URI Class Initialized
INFO - 2022-01-25 15:17:38 --> Router Class Initialized
INFO - 2022-01-25 15:17:38 --> Output Class Initialized
INFO - 2022-01-25 15:17:38 --> Security Class Initialized
DEBUG - 2022-01-25 15:17:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 15:17:38 --> Input Class Initialized
INFO - 2022-01-25 15:17:38 --> Language Class Initialized
ERROR - 2022-01-25 15:17:38 --> 404 Page Not Found: Wordpress/wp-includes
ERROR - 2022-01-25 15:17:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 15:17:38 --> Config Class Initialized
INFO - 2022-01-25 15:17:38 --> Hooks Class Initialized
DEBUG - 2022-01-25 15:17:38 --> UTF-8 Support Enabled
INFO - 2022-01-25 15:17:38 --> Utf8 Class Initialized
INFO - 2022-01-25 15:17:38 --> URI Class Initialized
INFO - 2022-01-25 15:17:38 --> Router Class Initialized
INFO - 2022-01-25 15:17:38 --> Output Class Initialized
INFO - 2022-01-25 15:17:38 --> Security Class Initialized
DEBUG - 2022-01-25 15:17:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 15:17:38 --> Input Class Initialized
INFO - 2022-01-25 15:17:38 --> Language Class Initialized
ERROR - 2022-01-25 15:17:38 --> 404 Page Not Found: Website/wp-includes
ERROR - 2022-01-25 15:17:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 15:17:39 --> Config Class Initialized
INFO - 2022-01-25 15:17:39 --> Hooks Class Initialized
DEBUG - 2022-01-25 15:17:39 --> UTF-8 Support Enabled
INFO - 2022-01-25 15:17:39 --> Utf8 Class Initialized
INFO - 2022-01-25 15:17:39 --> URI Class Initialized
INFO - 2022-01-25 15:17:39 --> Router Class Initialized
INFO - 2022-01-25 15:17:39 --> Output Class Initialized
INFO - 2022-01-25 15:17:39 --> Security Class Initialized
DEBUG - 2022-01-25 15:17:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 15:17:39 --> Input Class Initialized
INFO - 2022-01-25 15:17:39 --> Language Class Initialized
ERROR - 2022-01-25 15:17:39 --> 404 Page Not Found: Wp/wp-includes
ERROR - 2022-01-25 15:17:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 15:17:39 --> Config Class Initialized
INFO - 2022-01-25 15:17:39 --> Hooks Class Initialized
DEBUG - 2022-01-25 15:17:39 --> UTF-8 Support Enabled
INFO - 2022-01-25 15:17:39 --> Utf8 Class Initialized
INFO - 2022-01-25 15:17:39 --> URI Class Initialized
INFO - 2022-01-25 15:17:39 --> Router Class Initialized
INFO - 2022-01-25 15:17:39 --> Output Class Initialized
INFO - 2022-01-25 15:17:39 --> Security Class Initialized
DEBUG - 2022-01-25 15:17:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 15:17:39 --> Input Class Initialized
INFO - 2022-01-25 15:17:39 --> Language Class Initialized
ERROR - 2022-01-25 15:17:39 --> 404 Page Not Found: News/wp-includes
ERROR - 2022-01-25 15:17:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 15:17:39 --> Config Class Initialized
INFO - 2022-01-25 15:17:39 --> Hooks Class Initialized
DEBUG - 2022-01-25 15:17:39 --> UTF-8 Support Enabled
INFO - 2022-01-25 15:17:39 --> Utf8 Class Initialized
INFO - 2022-01-25 15:17:39 --> URI Class Initialized
INFO - 2022-01-25 15:17:39 --> Router Class Initialized
INFO - 2022-01-25 15:17:39 --> Output Class Initialized
INFO - 2022-01-25 15:17:39 --> Security Class Initialized
DEBUG - 2022-01-25 15:17:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 15:17:39 --> Input Class Initialized
INFO - 2022-01-25 15:17:39 --> Language Class Initialized
ERROR - 2022-01-25 15:17:39 --> 404 Page Not Found: 2018/wp-includes
ERROR - 2022-01-25 15:17:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 15:17:40 --> Config Class Initialized
INFO - 2022-01-25 15:17:40 --> Hooks Class Initialized
DEBUG - 2022-01-25 15:17:40 --> UTF-8 Support Enabled
INFO - 2022-01-25 15:17:40 --> Utf8 Class Initialized
INFO - 2022-01-25 15:17:40 --> URI Class Initialized
INFO - 2022-01-25 15:17:40 --> Router Class Initialized
INFO - 2022-01-25 15:17:40 --> Output Class Initialized
INFO - 2022-01-25 15:17:40 --> Security Class Initialized
DEBUG - 2022-01-25 15:17:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 15:17:40 --> Input Class Initialized
INFO - 2022-01-25 15:17:40 --> Language Class Initialized
ERROR - 2022-01-25 15:17:40 --> 404 Page Not Found: 2019/wp-includes
ERROR - 2022-01-25 15:17:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 15:17:40 --> Config Class Initialized
INFO - 2022-01-25 15:17:40 --> Hooks Class Initialized
DEBUG - 2022-01-25 15:17:40 --> UTF-8 Support Enabled
INFO - 2022-01-25 15:17:40 --> Utf8 Class Initialized
INFO - 2022-01-25 15:17:40 --> URI Class Initialized
INFO - 2022-01-25 15:17:40 --> Router Class Initialized
INFO - 2022-01-25 15:17:40 --> Output Class Initialized
INFO - 2022-01-25 15:17:40 --> Security Class Initialized
DEBUG - 2022-01-25 15:17:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 15:17:40 --> Input Class Initialized
INFO - 2022-01-25 15:17:40 --> Language Class Initialized
ERROR - 2022-01-25 15:17:40 --> 404 Page Not Found: Shop/wp-includes
ERROR - 2022-01-25 15:17:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 15:17:41 --> Config Class Initialized
INFO - 2022-01-25 15:17:41 --> Hooks Class Initialized
DEBUG - 2022-01-25 15:17:41 --> UTF-8 Support Enabled
INFO - 2022-01-25 15:17:41 --> Utf8 Class Initialized
INFO - 2022-01-25 15:17:41 --> URI Class Initialized
INFO - 2022-01-25 15:17:41 --> Router Class Initialized
INFO - 2022-01-25 15:17:41 --> Output Class Initialized
INFO - 2022-01-25 15:17:41 --> Security Class Initialized
DEBUG - 2022-01-25 15:17:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 15:17:41 --> Input Class Initialized
INFO - 2022-01-25 15:17:41 --> Language Class Initialized
ERROR - 2022-01-25 15:17:41 --> 404 Page Not Found: Wp1/wp-includes
ERROR - 2022-01-25 15:17:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 15:17:41 --> Config Class Initialized
INFO - 2022-01-25 15:17:41 --> Hooks Class Initialized
DEBUG - 2022-01-25 15:17:41 --> UTF-8 Support Enabled
INFO - 2022-01-25 15:17:41 --> Utf8 Class Initialized
INFO - 2022-01-25 15:17:41 --> URI Class Initialized
INFO - 2022-01-25 15:17:41 --> Router Class Initialized
INFO - 2022-01-25 15:17:41 --> Output Class Initialized
INFO - 2022-01-25 15:17:41 --> Security Class Initialized
DEBUG - 2022-01-25 15:17:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 15:17:41 --> Input Class Initialized
INFO - 2022-01-25 15:17:41 --> Language Class Initialized
ERROR - 2022-01-25 15:17:41 --> 404 Page Not Found: Test/wp-includes
ERROR - 2022-01-25 15:17:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 15:17:42 --> Config Class Initialized
INFO - 2022-01-25 15:17:42 --> Hooks Class Initialized
DEBUG - 2022-01-25 15:17:42 --> UTF-8 Support Enabled
INFO - 2022-01-25 15:17:42 --> Utf8 Class Initialized
INFO - 2022-01-25 15:17:42 --> URI Class Initialized
INFO - 2022-01-25 15:17:42 --> Router Class Initialized
INFO - 2022-01-25 15:17:42 --> Output Class Initialized
INFO - 2022-01-25 15:17:42 --> Security Class Initialized
DEBUG - 2022-01-25 15:17:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 15:17:42 --> Input Class Initialized
INFO - 2022-01-25 15:17:42 --> Language Class Initialized
ERROR - 2022-01-25 15:17:42 --> 404 Page Not Found: Media/wp-includes
ERROR - 2022-01-25 15:17:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 15:17:42 --> Config Class Initialized
INFO - 2022-01-25 15:17:42 --> Hooks Class Initialized
DEBUG - 2022-01-25 15:17:42 --> UTF-8 Support Enabled
INFO - 2022-01-25 15:17:42 --> Utf8 Class Initialized
INFO - 2022-01-25 15:17:42 --> URI Class Initialized
INFO - 2022-01-25 15:17:42 --> Router Class Initialized
INFO - 2022-01-25 15:17:42 --> Output Class Initialized
INFO - 2022-01-25 15:17:42 --> Security Class Initialized
DEBUG - 2022-01-25 15:17:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 15:17:42 --> Input Class Initialized
INFO - 2022-01-25 15:17:42 --> Language Class Initialized
ERROR - 2022-01-25 15:17:42 --> 404 Page Not Found: Wp2/wp-includes
ERROR - 2022-01-25 15:17:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 15:17:43 --> Config Class Initialized
INFO - 2022-01-25 15:17:43 --> Hooks Class Initialized
DEBUG - 2022-01-25 15:17:43 --> UTF-8 Support Enabled
INFO - 2022-01-25 15:17:43 --> Utf8 Class Initialized
INFO - 2022-01-25 15:17:43 --> URI Class Initialized
INFO - 2022-01-25 15:17:43 --> Router Class Initialized
INFO - 2022-01-25 15:17:43 --> Output Class Initialized
INFO - 2022-01-25 15:17:43 --> Security Class Initialized
DEBUG - 2022-01-25 15:17:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 15:17:43 --> Input Class Initialized
INFO - 2022-01-25 15:17:43 --> Language Class Initialized
ERROR - 2022-01-25 15:17:43 --> 404 Page Not Found: Site/wp-includes
ERROR - 2022-01-25 15:17:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 15:17:43 --> Config Class Initialized
INFO - 2022-01-25 15:17:43 --> Hooks Class Initialized
DEBUG - 2022-01-25 15:17:43 --> UTF-8 Support Enabled
INFO - 2022-01-25 15:17:43 --> Utf8 Class Initialized
INFO - 2022-01-25 15:17:43 --> URI Class Initialized
INFO - 2022-01-25 15:17:43 --> Router Class Initialized
INFO - 2022-01-25 15:17:43 --> Output Class Initialized
INFO - 2022-01-25 15:17:43 --> Security Class Initialized
DEBUG - 2022-01-25 15:17:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 15:17:43 --> Input Class Initialized
INFO - 2022-01-25 15:17:43 --> Language Class Initialized
ERROR - 2022-01-25 15:17:43 --> 404 Page Not Found: Cms/wp-includes
ERROR - 2022-01-25 15:17:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 15:17:44 --> Config Class Initialized
INFO - 2022-01-25 15:17:44 --> Hooks Class Initialized
DEBUG - 2022-01-25 15:17:44 --> UTF-8 Support Enabled
INFO - 2022-01-25 15:17:44 --> Utf8 Class Initialized
INFO - 2022-01-25 15:17:44 --> URI Class Initialized
INFO - 2022-01-25 15:17:44 --> Router Class Initialized
INFO - 2022-01-25 15:17:44 --> Output Class Initialized
INFO - 2022-01-25 15:17:44 --> Security Class Initialized
DEBUG - 2022-01-25 15:17:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 15:17:44 --> Input Class Initialized
INFO - 2022-01-25 15:17:44 --> Language Class Initialized
ERROR - 2022-01-25 15:17:44 --> 404 Page Not Found: Sito/wp-includes
ERROR - 2022-01-25 17:23:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 17:23:22 --> Config Class Initialized
INFO - 2022-01-25 17:23:22 --> Hooks Class Initialized
DEBUG - 2022-01-25 17:23:22 --> UTF-8 Support Enabled
INFO - 2022-01-25 17:23:22 --> Utf8 Class Initialized
INFO - 2022-01-25 17:23:22 --> URI Class Initialized
INFO - 2022-01-25 17:23:22 --> Router Class Initialized
INFO - 2022-01-25 17:23:22 --> Output Class Initialized
INFO - 2022-01-25 17:23:22 --> Security Class Initialized
DEBUG - 2022-01-25 17:23:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 17:23:22 --> Input Class Initialized
INFO - 2022-01-25 17:23:22 --> Language Class Initialized
ERROR - 2022-01-25 17:23:22 --> 404 Page Not Found: Filemanager/dialog.php
ERROR - 2022-01-25 17:23:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 17:23:23 --> Config Class Initialized
INFO - 2022-01-25 17:23:23 --> Hooks Class Initialized
DEBUG - 2022-01-25 17:23:23 --> UTF-8 Support Enabled
INFO - 2022-01-25 17:23:23 --> Utf8 Class Initialized
INFO - 2022-01-25 17:23:23 --> URI Class Initialized
INFO - 2022-01-25 17:23:23 --> Router Class Initialized
INFO - 2022-01-25 17:23:23 --> Output Class Initialized
INFO - 2022-01-25 17:23:23 --> Security Class Initialized
DEBUG - 2022-01-25 17:23:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 17:23:23 --> Input Class Initialized
INFO - 2022-01-25 17:23:23 --> Language Class Initialized
ERROR - 2022-01-25 17:23:23 --> 404 Page Not Found: Assets/filemanager
ERROR - 2022-01-25 20:23:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 20:23:28 --> Config Class Initialized
INFO - 2022-01-25 20:23:28 --> Hooks Class Initialized
DEBUG - 2022-01-25 20:23:28 --> UTF-8 Support Enabled
INFO - 2022-01-25 20:23:28 --> Utf8 Class Initialized
INFO - 2022-01-25 20:23:28 --> URI Class Initialized
DEBUG - 2022-01-25 20:23:28 --> No URI present. Default controller set.
INFO - 2022-01-25 20:23:28 --> Router Class Initialized
INFO - 2022-01-25 20:23:28 --> Output Class Initialized
INFO - 2022-01-25 20:23:28 --> Security Class Initialized
DEBUG - 2022-01-25 20:23:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 20:23:28 --> Input Class Initialized
INFO - 2022-01-25 20:23:28 --> Language Class Initialized
INFO - 2022-01-25 20:23:28 --> Loader Class Initialized
INFO - 2022-01-25 20:23:28 --> Helper loaded: url_helper
INFO - 2022-01-25 20:23:28 --> Helper loaded: form_helper
INFO - 2022-01-25 20:23:28 --> Helper loaded: common_helper
INFO - 2022-01-25 20:23:28 --> Database Driver Class Initialized
DEBUG - 2022-01-25 20:23:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-25 20:23:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-25 20:23:28 --> Controller Class Initialized
INFO - 2022-01-25 20:23:28 --> Form Validation Class Initialized
DEBUG - 2022-01-25 20:23:28 --> Encrypt Class Initialized
DEBUG - 2022-01-25 20:23:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 20:23:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-25 20:23:28 --> Email Class Initialized
INFO - 2022-01-25 20:23:28 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-25 20:23:28 --> Calendar Class Initialized
INFO - 2022-01-25 20:23:28 --> Model "Login_model" initialized
INFO - 2022-01-25 20:23:28 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-25 20:23:28 --> Final output sent to browser
DEBUG - 2022-01-25 20:23:28 --> Total execution time: 0.0284
ERROR - 2022-01-25 20:23:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 20:23:29 --> Config Class Initialized
INFO - 2022-01-25 20:23:29 --> Hooks Class Initialized
DEBUG - 2022-01-25 20:23:29 --> UTF-8 Support Enabled
INFO - 2022-01-25 20:23:29 --> Utf8 Class Initialized
INFO - 2022-01-25 20:23:29 --> URI Class Initialized
DEBUG - 2022-01-25 20:23:29 --> No URI present. Default controller set.
INFO - 2022-01-25 20:23:29 --> Router Class Initialized
INFO - 2022-01-25 20:23:29 --> Output Class Initialized
INFO - 2022-01-25 20:23:29 --> Security Class Initialized
DEBUG - 2022-01-25 20:23:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 20:23:29 --> Input Class Initialized
INFO - 2022-01-25 20:23:29 --> Language Class Initialized
INFO - 2022-01-25 20:23:29 --> Loader Class Initialized
INFO - 2022-01-25 20:23:29 --> Helper loaded: url_helper
INFO - 2022-01-25 20:23:29 --> Helper loaded: form_helper
INFO - 2022-01-25 20:23:29 --> Helper loaded: common_helper
INFO - 2022-01-25 20:23:29 --> Database Driver Class Initialized
DEBUG - 2022-01-25 20:23:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-25 20:23:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-25 20:23:29 --> Controller Class Initialized
INFO - 2022-01-25 20:23:29 --> Form Validation Class Initialized
DEBUG - 2022-01-25 20:23:29 --> Encrypt Class Initialized
DEBUG - 2022-01-25 20:23:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 20:23:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-25 20:23:29 --> Email Class Initialized
INFO - 2022-01-25 20:23:29 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-25 20:23:29 --> Calendar Class Initialized
INFO - 2022-01-25 20:23:29 --> Model "Login_model" initialized
INFO - 2022-01-25 20:23:29 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-25 20:23:29 --> Final output sent to browser
DEBUG - 2022-01-25 20:23:29 --> Total execution time: 0.0468
ERROR - 2022-01-25 20:23:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 20:23:29 --> Config Class Initialized
INFO - 2022-01-25 20:23:29 --> Hooks Class Initialized
DEBUG - 2022-01-25 20:23:29 --> UTF-8 Support Enabled
INFO - 2022-01-25 20:23:29 --> Utf8 Class Initialized
INFO - 2022-01-25 20:23:29 --> URI Class Initialized
INFO - 2022-01-25 20:23:29 --> Router Class Initialized
INFO - 2022-01-25 20:23:29 --> Output Class Initialized
INFO - 2022-01-25 20:23:29 --> Security Class Initialized
DEBUG - 2022-01-25 20:23:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 20:23:29 --> Input Class Initialized
INFO - 2022-01-25 20:23:29 --> Language Class Initialized
ERROR - 2022-01-25 20:23:29 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
ERROR - 2022-01-25 20:23:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 20:23:30 --> Config Class Initialized
INFO - 2022-01-25 20:23:30 --> Hooks Class Initialized
DEBUG - 2022-01-25 20:23:30 --> UTF-8 Support Enabled
INFO - 2022-01-25 20:23:30 --> Utf8 Class Initialized
INFO - 2022-01-25 20:23:30 --> URI Class Initialized
INFO - 2022-01-25 20:23:30 --> Router Class Initialized
INFO - 2022-01-25 20:23:30 --> Output Class Initialized
INFO - 2022-01-25 20:23:30 --> Security Class Initialized
DEBUG - 2022-01-25 20:23:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 20:23:30 --> Input Class Initialized
INFO - 2022-01-25 20:23:30 --> Language Class Initialized
ERROR - 2022-01-25 20:23:30 --> 404 Page Not Found: Blog/wp-includes
ERROR - 2022-01-25 20:23:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 20:23:31 --> Config Class Initialized
INFO - 2022-01-25 20:23:31 --> Hooks Class Initialized
DEBUG - 2022-01-25 20:23:31 --> UTF-8 Support Enabled
INFO - 2022-01-25 20:23:31 --> Utf8 Class Initialized
INFO - 2022-01-25 20:23:31 --> URI Class Initialized
INFO - 2022-01-25 20:23:31 --> Router Class Initialized
INFO - 2022-01-25 20:23:31 --> Output Class Initialized
INFO - 2022-01-25 20:23:31 --> Security Class Initialized
DEBUG - 2022-01-25 20:23:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 20:23:31 --> Input Class Initialized
INFO - 2022-01-25 20:23:31 --> Language Class Initialized
ERROR - 2022-01-25 20:23:31 --> 404 Page Not Found: Web/wp-includes
ERROR - 2022-01-25 20:23:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 20:23:31 --> Config Class Initialized
INFO - 2022-01-25 20:23:31 --> Hooks Class Initialized
DEBUG - 2022-01-25 20:23:31 --> UTF-8 Support Enabled
INFO - 2022-01-25 20:23:31 --> Utf8 Class Initialized
INFO - 2022-01-25 20:23:31 --> URI Class Initialized
INFO - 2022-01-25 20:23:31 --> Router Class Initialized
INFO - 2022-01-25 20:23:31 --> Output Class Initialized
INFO - 2022-01-25 20:23:31 --> Security Class Initialized
DEBUG - 2022-01-25 20:23:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 20:23:31 --> Input Class Initialized
INFO - 2022-01-25 20:23:31 --> Language Class Initialized
ERROR - 2022-01-25 20:23:31 --> 404 Page Not Found: Wordpress/wp-includes
ERROR - 2022-01-25 20:23:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 20:23:32 --> Config Class Initialized
INFO - 2022-01-25 20:23:32 --> Hooks Class Initialized
DEBUG - 2022-01-25 20:23:32 --> UTF-8 Support Enabled
INFO - 2022-01-25 20:23:32 --> Utf8 Class Initialized
INFO - 2022-01-25 20:23:32 --> URI Class Initialized
INFO - 2022-01-25 20:23:32 --> Router Class Initialized
INFO - 2022-01-25 20:23:32 --> Output Class Initialized
INFO - 2022-01-25 20:23:32 --> Security Class Initialized
DEBUG - 2022-01-25 20:23:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 20:23:32 --> Input Class Initialized
INFO - 2022-01-25 20:23:32 --> Language Class Initialized
ERROR - 2022-01-25 20:23:32 --> 404 Page Not Found: Website/wp-includes
ERROR - 2022-01-25 20:23:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 20:23:32 --> Config Class Initialized
INFO - 2022-01-25 20:23:32 --> Hooks Class Initialized
DEBUG - 2022-01-25 20:23:32 --> UTF-8 Support Enabled
INFO - 2022-01-25 20:23:32 --> Utf8 Class Initialized
INFO - 2022-01-25 20:23:32 --> URI Class Initialized
INFO - 2022-01-25 20:23:32 --> Router Class Initialized
INFO - 2022-01-25 20:23:32 --> Output Class Initialized
INFO - 2022-01-25 20:23:32 --> Security Class Initialized
DEBUG - 2022-01-25 20:23:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 20:23:32 --> Input Class Initialized
INFO - 2022-01-25 20:23:32 --> Language Class Initialized
ERROR - 2022-01-25 20:23:32 --> 404 Page Not Found: Wp/wp-includes
ERROR - 2022-01-25 20:23:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 20:23:33 --> Config Class Initialized
INFO - 2022-01-25 20:23:33 --> Hooks Class Initialized
DEBUG - 2022-01-25 20:23:33 --> UTF-8 Support Enabled
INFO - 2022-01-25 20:23:33 --> Utf8 Class Initialized
INFO - 2022-01-25 20:23:33 --> URI Class Initialized
INFO - 2022-01-25 20:23:33 --> Router Class Initialized
INFO - 2022-01-25 20:23:33 --> Output Class Initialized
INFO - 2022-01-25 20:23:33 --> Security Class Initialized
DEBUG - 2022-01-25 20:23:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 20:23:33 --> Input Class Initialized
INFO - 2022-01-25 20:23:33 --> Language Class Initialized
ERROR - 2022-01-25 20:23:33 --> 404 Page Not Found: News/wp-includes
ERROR - 2022-01-25 20:23:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 20:23:33 --> Config Class Initialized
INFO - 2022-01-25 20:23:33 --> Hooks Class Initialized
DEBUG - 2022-01-25 20:23:33 --> UTF-8 Support Enabled
INFO - 2022-01-25 20:23:33 --> Utf8 Class Initialized
INFO - 2022-01-25 20:23:33 --> URI Class Initialized
INFO - 2022-01-25 20:23:33 --> Router Class Initialized
INFO - 2022-01-25 20:23:33 --> Output Class Initialized
INFO - 2022-01-25 20:23:33 --> Security Class Initialized
DEBUG - 2022-01-25 20:23:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 20:23:33 --> Input Class Initialized
INFO - 2022-01-25 20:23:33 --> Language Class Initialized
ERROR - 2022-01-25 20:23:33 --> 404 Page Not Found: 2020/wp-includes
ERROR - 2022-01-25 20:23:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 20:23:34 --> Config Class Initialized
INFO - 2022-01-25 20:23:34 --> Hooks Class Initialized
DEBUG - 2022-01-25 20:23:34 --> UTF-8 Support Enabled
INFO - 2022-01-25 20:23:34 --> Utf8 Class Initialized
INFO - 2022-01-25 20:23:34 --> URI Class Initialized
INFO - 2022-01-25 20:23:34 --> Router Class Initialized
INFO - 2022-01-25 20:23:34 --> Output Class Initialized
INFO - 2022-01-25 20:23:34 --> Security Class Initialized
DEBUG - 2022-01-25 20:23:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 20:23:34 --> Input Class Initialized
INFO - 2022-01-25 20:23:34 --> Language Class Initialized
ERROR - 2022-01-25 20:23:34 --> 404 Page Not Found: 2019/wp-includes
ERROR - 2022-01-25 20:23:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 20:23:34 --> Config Class Initialized
INFO - 2022-01-25 20:23:34 --> Hooks Class Initialized
DEBUG - 2022-01-25 20:23:34 --> UTF-8 Support Enabled
INFO - 2022-01-25 20:23:34 --> Utf8 Class Initialized
INFO - 2022-01-25 20:23:34 --> URI Class Initialized
INFO - 2022-01-25 20:23:34 --> Router Class Initialized
INFO - 2022-01-25 20:23:34 --> Output Class Initialized
INFO - 2022-01-25 20:23:34 --> Security Class Initialized
DEBUG - 2022-01-25 20:23:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 20:23:34 --> Input Class Initialized
INFO - 2022-01-25 20:23:34 --> Language Class Initialized
ERROR - 2022-01-25 20:23:34 --> 404 Page Not Found: Shop/wp-includes
ERROR - 2022-01-25 20:23:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 20:23:35 --> Config Class Initialized
INFO - 2022-01-25 20:23:35 --> Hooks Class Initialized
DEBUG - 2022-01-25 20:23:35 --> UTF-8 Support Enabled
INFO - 2022-01-25 20:23:35 --> Utf8 Class Initialized
INFO - 2022-01-25 20:23:35 --> URI Class Initialized
INFO - 2022-01-25 20:23:35 --> Router Class Initialized
INFO - 2022-01-25 20:23:35 --> Output Class Initialized
INFO - 2022-01-25 20:23:35 --> Security Class Initialized
DEBUG - 2022-01-25 20:23:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 20:23:35 --> Input Class Initialized
INFO - 2022-01-25 20:23:35 --> Language Class Initialized
ERROR - 2022-01-25 20:23:35 --> 404 Page Not Found: Wp1/wp-includes
ERROR - 2022-01-25 20:23:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 20:23:35 --> Config Class Initialized
INFO - 2022-01-25 20:23:35 --> Hooks Class Initialized
DEBUG - 2022-01-25 20:23:35 --> UTF-8 Support Enabled
INFO - 2022-01-25 20:23:35 --> Utf8 Class Initialized
INFO - 2022-01-25 20:23:35 --> URI Class Initialized
INFO - 2022-01-25 20:23:35 --> Router Class Initialized
INFO - 2022-01-25 20:23:35 --> Output Class Initialized
INFO - 2022-01-25 20:23:35 --> Security Class Initialized
DEBUG - 2022-01-25 20:23:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 20:23:35 --> Input Class Initialized
INFO - 2022-01-25 20:23:35 --> Language Class Initialized
ERROR - 2022-01-25 20:23:35 --> 404 Page Not Found: Test/wp-includes
ERROR - 2022-01-25 20:23:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 20:23:36 --> Config Class Initialized
INFO - 2022-01-25 20:23:36 --> Hooks Class Initialized
DEBUG - 2022-01-25 20:23:36 --> UTF-8 Support Enabled
INFO - 2022-01-25 20:23:36 --> Utf8 Class Initialized
INFO - 2022-01-25 20:23:36 --> URI Class Initialized
INFO - 2022-01-25 20:23:36 --> Router Class Initialized
INFO - 2022-01-25 20:23:36 --> Output Class Initialized
INFO - 2022-01-25 20:23:36 --> Security Class Initialized
DEBUG - 2022-01-25 20:23:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 20:23:36 --> Input Class Initialized
INFO - 2022-01-25 20:23:36 --> Language Class Initialized
ERROR - 2022-01-25 20:23:36 --> 404 Page Not Found: Wp2/wp-includes
ERROR - 2022-01-25 20:23:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 20:23:36 --> Config Class Initialized
INFO - 2022-01-25 20:23:36 --> Hooks Class Initialized
DEBUG - 2022-01-25 20:23:36 --> UTF-8 Support Enabled
INFO - 2022-01-25 20:23:36 --> Utf8 Class Initialized
INFO - 2022-01-25 20:23:36 --> URI Class Initialized
INFO - 2022-01-25 20:23:36 --> Router Class Initialized
INFO - 2022-01-25 20:23:36 --> Output Class Initialized
INFO - 2022-01-25 20:23:36 --> Security Class Initialized
DEBUG - 2022-01-25 20:23:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 20:23:36 --> Input Class Initialized
INFO - 2022-01-25 20:23:36 --> Language Class Initialized
ERROR - 2022-01-25 20:23:36 --> 404 Page Not Found: Site/wp-includes
ERROR - 2022-01-25 20:23:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 20:23:37 --> Config Class Initialized
INFO - 2022-01-25 20:23:37 --> Hooks Class Initialized
DEBUG - 2022-01-25 20:23:37 --> UTF-8 Support Enabled
INFO - 2022-01-25 20:23:37 --> Utf8 Class Initialized
INFO - 2022-01-25 20:23:37 --> URI Class Initialized
INFO - 2022-01-25 20:23:37 --> Router Class Initialized
INFO - 2022-01-25 20:23:37 --> Output Class Initialized
INFO - 2022-01-25 20:23:37 --> Security Class Initialized
DEBUG - 2022-01-25 20:23:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 20:23:37 --> Input Class Initialized
INFO - 2022-01-25 20:23:37 --> Language Class Initialized
ERROR - 2022-01-25 20:23:37 --> 404 Page Not Found: Cms/wp-includes
ERROR - 2022-01-25 20:23:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 20:23:37 --> Config Class Initialized
INFO - 2022-01-25 20:23:37 --> Hooks Class Initialized
DEBUG - 2022-01-25 20:23:37 --> UTF-8 Support Enabled
INFO - 2022-01-25 20:23:37 --> Utf8 Class Initialized
INFO - 2022-01-25 20:23:37 --> URI Class Initialized
INFO - 2022-01-25 20:23:37 --> Router Class Initialized
INFO - 2022-01-25 20:23:37 --> Output Class Initialized
INFO - 2022-01-25 20:23:37 --> Security Class Initialized
DEBUG - 2022-01-25 20:23:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 20:23:37 --> Input Class Initialized
INFO - 2022-01-25 20:23:37 --> Language Class Initialized
ERROR - 2022-01-25 20:23:37 --> 404 Page Not Found: Sito/wp-includes
ERROR - 2022-01-25 20:29:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 20:29:41 --> Config Class Initialized
INFO - 2022-01-25 20:29:41 --> Hooks Class Initialized
DEBUG - 2022-01-25 20:29:41 --> UTF-8 Support Enabled
INFO - 2022-01-25 20:29:41 --> Utf8 Class Initialized
INFO - 2022-01-25 20:29:41 --> URI Class Initialized
DEBUG - 2022-01-25 20:29:41 --> No URI present. Default controller set.
INFO - 2022-01-25 20:29:41 --> Router Class Initialized
INFO - 2022-01-25 20:29:41 --> Output Class Initialized
INFO - 2022-01-25 20:29:41 --> Security Class Initialized
DEBUG - 2022-01-25 20:29:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 20:29:41 --> Input Class Initialized
INFO - 2022-01-25 20:29:41 --> Language Class Initialized
INFO - 2022-01-25 20:29:41 --> Loader Class Initialized
INFO - 2022-01-25 20:29:41 --> Helper loaded: url_helper
INFO - 2022-01-25 20:29:41 --> Helper loaded: form_helper
INFO - 2022-01-25 20:29:41 --> Helper loaded: common_helper
INFO - 2022-01-25 20:29:41 --> Database Driver Class Initialized
DEBUG - 2022-01-25 20:29:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-25 20:29:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-25 20:29:41 --> Controller Class Initialized
INFO - 2022-01-25 20:29:41 --> Form Validation Class Initialized
DEBUG - 2022-01-25 20:29:41 --> Encrypt Class Initialized
DEBUG - 2022-01-25 20:29:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 20:29:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-25 20:29:41 --> Email Class Initialized
INFO - 2022-01-25 20:29:41 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-25 20:29:41 --> Calendar Class Initialized
INFO - 2022-01-25 20:29:41 --> Model "Login_model" initialized
INFO - 2022-01-25 20:29:41 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-25 20:29:41 --> Final output sent to browser
DEBUG - 2022-01-25 20:29:41 --> Total execution time: 0.0239
ERROR - 2022-01-25 20:29:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 20:29:56 --> Config Class Initialized
INFO - 2022-01-25 20:29:56 --> Hooks Class Initialized
DEBUG - 2022-01-25 20:29:56 --> UTF-8 Support Enabled
INFO - 2022-01-25 20:29:56 --> Utf8 Class Initialized
INFO - 2022-01-25 20:29:56 --> URI Class Initialized
DEBUG - 2022-01-25 20:29:56 --> No URI present. Default controller set.
INFO - 2022-01-25 20:29:56 --> Router Class Initialized
INFO - 2022-01-25 20:29:56 --> Output Class Initialized
INFO - 2022-01-25 20:29:56 --> Security Class Initialized
DEBUG - 2022-01-25 20:29:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 20:29:56 --> Input Class Initialized
INFO - 2022-01-25 20:29:56 --> Language Class Initialized
INFO - 2022-01-25 20:29:56 --> Loader Class Initialized
INFO - 2022-01-25 20:29:56 --> Helper loaded: url_helper
INFO - 2022-01-25 20:29:56 --> Helper loaded: form_helper
INFO - 2022-01-25 20:29:56 --> Helper loaded: common_helper
INFO - 2022-01-25 20:29:56 --> Database Driver Class Initialized
DEBUG - 2022-01-25 20:29:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-25 20:29:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-25 20:29:56 --> Controller Class Initialized
INFO - 2022-01-25 20:29:56 --> Form Validation Class Initialized
DEBUG - 2022-01-25 20:29:56 --> Encrypt Class Initialized
DEBUG - 2022-01-25 20:29:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 20:29:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-25 20:29:56 --> Email Class Initialized
INFO - 2022-01-25 20:29:56 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-25 20:29:56 --> Calendar Class Initialized
INFO - 2022-01-25 20:29:56 --> Model "Login_model" initialized
INFO - 2022-01-25 20:29:56 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-25 20:29:56 --> Final output sent to browser
DEBUG - 2022-01-25 20:29:56 --> Total execution time: 0.0274
ERROR - 2022-01-25 21:32:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-25 21:32:01 --> Config Class Initialized
INFO - 2022-01-25 21:32:01 --> Hooks Class Initialized
DEBUG - 2022-01-25 21:32:01 --> UTF-8 Support Enabled
INFO - 2022-01-25 21:32:01 --> Utf8 Class Initialized
INFO - 2022-01-25 21:32:01 --> URI Class Initialized
DEBUG - 2022-01-25 21:32:01 --> No URI present. Default controller set.
INFO - 2022-01-25 21:32:01 --> Router Class Initialized
INFO - 2022-01-25 21:32:01 --> Output Class Initialized
INFO - 2022-01-25 21:32:01 --> Security Class Initialized
DEBUG - 2022-01-25 21:32:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-25 21:32:01 --> Input Class Initialized
INFO - 2022-01-25 21:32:01 --> Language Class Initialized
INFO - 2022-01-25 21:32:01 --> Loader Class Initialized
INFO - 2022-01-25 21:32:01 --> Helper loaded: url_helper
INFO - 2022-01-25 21:32:01 --> Helper loaded: form_helper
INFO - 2022-01-25 21:32:01 --> Helper loaded: common_helper
INFO - 2022-01-25 21:32:01 --> Database Driver Class Initialized
DEBUG - 2022-01-25 21:32:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-25 21:32:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-25 21:32:01 --> Controller Class Initialized
INFO - 2022-01-25 21:32:01 --> Form Validation Class Initialized
DEBUG - 2022-01-25 21:32:01 --> Encrypt Class Initialized
DEBUG - 2022-01-25 21:32:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 21:32:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-25 21:32:01 --> Email Class Initialized
INFO - 2022-01-25 21:32:01 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-25 21:32:01 --> Calendar Class Initialized
INFO - 2022-01-25 21:32:01 --> Model "Login_model" initialized
INFO - 2022-01-25 21:32:01 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-25 21:32:01 --> Final output sent to browser
DEBUG - 2022-01-25 21:32:01 --> Total execution time: 0.3104
