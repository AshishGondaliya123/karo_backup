<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-12-31 07:33:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-31 07:33:46 --> Config Class Initialized
INFO - 2021-12-31 07:33:46 --> Hooks Class Initialized
DEBUG - 2021-12-31 07:33:46 --> UTF-8 Support Enabled
INFO - 2021-12-31 07:33:46 --> Utf8 Class Initialized
INFO - 2021-12-31 07:33:46 --> URI Class Initialized
DEBUG - 2021-12-31 07:33:46 --> No URI present. Default controller set.
INFO - 2021-12-31 07:33:46 --> Router Class Initialized
INFO - 2021-12-31 07:33:46 --> Output Class Initialized
INFO - 2021-12-31 07:33:46 --> Security Class Initialized
DEBUG - 2021-12-31 07:33:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-31 07:33:46 --> Input Class Initialized
INFO - 2021-12-31 07:33:46 --> Language Class Initialized
INFO - 2021-12-31 07:33:46 --> Loader Class Initialized
INFO - 2021-12-31 07:33:46 --> Helper loaded: url_helper
INFO - 2021-12-31 07:33:46 --> Helper loaded: form_helper
INFO - 2021-12-31 07:33:46 --> Helper loaded: common_helper
INFO - 2021-12-31 07:33:46 --> Database Driver Class Initialized
DEBUG - 2021-12-31 07:33:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-31 07:33:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-31 07:33:46 --> Controller Class Initialized
INFO - 2021-12-31 07:33:46 --> Form Validation Class Initialized
DEBUG - 2021-12-31 07:33:46 --> Encrypt Class Initialized
DEBUG - 2021-12-31 07:33:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-31 07:33:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-31 07:33:46 --> Email Class Initialized
INFO - 2021-12-31 07:33:46 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-31 07:33:46 --> Calendar Class Initialized
INFO - 2021-12-31 07:33:46 --> Model "Login_model" initialized
INFO - 2021-12-31 07:33:46 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-31 07:33:46 --> Final output sent to browser
DEBUG - 2021-12-31 07:33:46 --> Total execution time: 0.0323
ERROR - 2021-12-31 07:45:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-31 07:45:12 --> Config Class Initialized
INFO - 2021-12-31 07:45:12 --> Hooks Class Initialized
DEBUG - 2021-12-31 07:45:12 --> UTF-8 Support Enabled
INFO - 2021-12-31 07:45:12 --> Utf8 Class Initialized
INFO - 2021-12-31 07:45:12 --> URI Class Initialized
INFO - 2021-12-31 07:45:12 --> Router Class Initialized
INFO - 2021-12-31 07:45:12 --> Output Class Initialized
INFO - 2021-12-31 07:45:12 --> Security Class Initialized
DEBUG - 2021-12-31 07:45:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-31 07:45:12 --> Input Class Initialized
INFO - 2021-12-31 07:45:12 --> Language Class Initialized
ERROR - 2021-12-31 07:45:12 --> 404 Page Not Found: _profiler/phpinfo
ERROR - 2021-12-31 07:45:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-31 07:45:12 --> Config Class Initialized
INFO - 2021-12-31 07:45:12 --> Hooks Class Initialized
DEBUG - 2021-12-31 07:45:12 --> UTF-8 Support Enabled
INFO - 2021-12-31 07:45:12 --> Utf8 Class Initialized
INFO - 2021-12-31 07:45:12 --> URI Class Initialized
INFO - 2021-12-31 07:45:12 --> Router Class Initialized
INFO - 2021-12-31 07:45:12 --> Output Class Initialized
INFO - 2021-12-31 07:45:12 --> Security Class Initialized
DEBUG - 2021-12-31 07:45:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-31 07:45:12 --> Input Class Initialized
INFO - 2021-12-31 07:45:12 --> Language Class Initialized
ERROR - 2021-12-31 07:45:12 --> 404 Page Not Found: Phpinfophp/index
ERROR - 2021-12-31 07:45:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-31 07:45:13 --> Config Class Initialized
INFO - 2021-12-31 07:45:13 --> Hooks Class Initialized
DEBUG - 2021-12-31 07:45:13 --> UTF-8 Support Enabled
INFO - 2021-12-31 07:45:13 --> Utf8 Class Initialized
INFO - 2021-12-31 07:45:13 --> URI Class Initialized
INFO - 2021-12-31 07:45:13 --> Router Class Initialized
INFO - 2021-12-31 07:45:13 --> Output Class Initialized
INFO - 2021-12-31 07:45:13 --> Security Class Initialized
DEBUG - 2021-12-31 07:45:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-31 07:45:13 --> Input Class Initialized
INFO - 2021-12-31 07:45:13 --> Language Class Initialized
ERROR - 2021-12-31 07:45:13 --> 404 Page Not Found: Phpinfo/index
ERROR - 2021-12-31 07:45:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-31 07:45:14 --> Config Class Initialized
INFO - 2021-12-31 07:45:14 --> Hooks Class Initialized
DEBUG - 2021-12-31 07:45:14 --> UTF-8 Support Enabled
INFO - 2021-12-31 07:45:14 --> Utf8 Class Initialized
INFO - 2021-12-31 07:45:14 --> URI Class Initialized
INFO - 2021-12-31 07:45:14 --> Router Class Initialized
INFO - 2021-12-31 07:45:14 --> Output Class Initialized
INFO - 2021-12-31 07:45:14 --> Security Class Initialized
DEBUG - 2021-12-31 07:45:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-31 07:45:14 --> Input Class Initialized
INFO - 2021-12-31 07:45:14 --> Language Class Initialized
ERROR - 2021-12-31 07:45:14 --> 404 Page Not Found: Infophp/index
ERROR - 2021-12-31 07:45:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-31 07:45:15 --> Config Class Initialized
INFO - 2021-12-31 07:45:15 --> Hooks Class Initialized
DEBUG - 2021-12-31 07:45:15 --> UTF-8 Support Enabled
INFO - 2021-12-31 07:45:15 --> Utf8 Class Initialized
INFO - 2021-12-31 07:45:15 --> URI Class Initialized
INFO - 2021-12-31 07:45:15 --> Router Class Initialized
INFO - 2021-12-31 07:45:15 --> Output Class Initialized
INFO - 2021-12-31 07:45:15 --> Security Class Initialized
DEBUG - 2021-12-31 07:45:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-31 07:45:15 --> Input Class Initialized
INFO - 2021-12-31 07:45:15 --> Language Class Initialized
ERROR - 2021-12-31 07:45:15 --> 404 Page Not Found: Aws/credentials
ERROR - 2021-12-31 07:45:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-31 07:45:16 --> Config Class Initialized
INFO - 2021-12-31 07:45:16 --> Hooks Class Initialized
DEBUG - 2021-12-31 07:45:16 --> UTF-8 Support Enabled
INFO - 2021-12-31 07:45:16 --> Utf8 Class Initialized
INFO - 2021-12-31 07:45:16 --> URI Class Initialized
INFO - 2021-12-31 07:45:16 --> Router Class Initialized
INFO - 2021-12-31 07:45:16 --> Output Class Initialized
INFO - 2021-12-31 07:45:16 --> Security Class Initialized
DEBUG - 2021-12-31 07:45:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-31 07:45:16 --> Input Class Initialized
INFO - 2021-12-31 07:45:16 --> Language Class Initialized
ERROR - 2021-12-31 07:45:16 --> 404 Page Not Found: Awsyml/index
ERROR - 2021-12-31 07:45:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-31 07:45:17 --> Config Class Initialized
INFO - 2021-12-31 07:45:17 --> Hooks Class Initialized
DEBUG - 2021-12-31 07:45:17 --> UTF-8 Support Enabled
INFO - 2021-12-31 07:45:17 --> Utf8 Class Initialized
INFO - 2021-12-31 07:45:17 --> URI Class Initialized
INFO - 2021-12-31 07:45:17 --> Router Class Initialized
INFO - 2021-12-31 07:45:17 --> Output Class Initialized
INFO - 2021-12-31 07:45:17 --> Security Class Initialized
DEBUG - 2021-12-31 07:45:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-31 07:45:17 --> Input Class Initialized
INFO - 2021-12-31 07:45:17 --> Language Class Initialized
ERROR - 2021-12-31 07:45:17 --> 404 Page Not Found: Config/aws.yml
ERROR - 2021-12-31 07:45:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-31 07:45:18 --> Config Class Initialized
INFO - 2021-12-31 07:45:18 --> Hooks Class Initialized
DEBUG - 2021-12-31 07:45:18 --> UTF-8 Support Enabled
INFO - 2021-12-31 07:45:18 --> Utf8 Class Initialized
INFO - 2021-12-31 07:45:18 --> URI Class Initialized
INFO - 2021-12-31 07:45:18 --> Router Class Initialized
INFO - 2021-12-31 07:45:18 --> Output Class Initialized
INFO - 2021-12-31 07:45:18 --> Security Class Initialized
DEBUG - 2021-12-31 07:45:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-31 07:45:18 --> Input Class Initialized
INFO - 2021-12-31 07:45:18 --> Language Class Initialized
ERROR - 2021-12-31 07:45:18 --> 404 Page Not Found: Configjs/index
ERROR - 2021-12-31 09:14:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-31 09:14:53 --> Config Class Initialized
INFO - 2021-12-31 09:14:53 --> Hooks Class Initialized
DEBUG - 2021-12-31 09:14:53 --> UTF-8 Support Enabled
INFO - 2021-12-31 09:14:53 --> Utf8 Class Initialized
INFO - 2021-12-31 09:14:53 --> URI Class Initialized
DEBUG - 2021-12-31 09:14:53 --> No URI present. Default controller set.
INFO - 2021-12-31 09:14:53 --> Router Class Initialized
INFO - 2021-12-31 09:14:53 --> Output Class Initialized
INFO - 2021-12-31 09:14:53 --> Security Class Initialized
DEBUG - 2021-12-31 09:14:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-31 09:14:53 --> Input Class Initialized
INFO - 2021-12-31 09:14:53 --> Language Class Initialized
INFO - 2021-12-31 09:14:53 --> Loader Class Initialized
INFO - 2021-12-31 09:14:53 --> Helper loaded: url_helper
INFO - 2021-12-31 09:14:53 --> Helper loaded: form_helper
INFO - 2021-12-31 09:14:53 --> Helper loaded: common_helper
INFO - 2021-12-31 09:14:53 --> Database Driver Class Initialized
DEBUG - 2021-12-31 09:14:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-31 09:14:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-31 09:14:53 --> Controller Class Initialized
INFO - 2021-12-31 09:14:53 --> Form Validation Class Initialized
DEBUG - 2021-12-31 09:14:53 --> Encrypt Class Initialized
DEBUG - 2021-12-31 09:14:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-31 09:14:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-31 09:14:53 --> Email Class Initialized
INFO - 2021-12-31 09:14:53 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-31 09:14:53 --> Calendar Class Initialized
INFO - 2021-12-31 09:14:53 --> Model "Login_model" initialized
INFO - 2021-12-31 09:14:53 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-31 09:14:53 --> Final output sent to browser
DEBUG - 2021-12-31 09:14:53 --> Total execution time: 0.0215
ERROR - 2021-12-31 09:14:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-31 09:14:55 --> Config Class Initialized
INFO - 2021-12-31 09:14:55 --> Hooks Class Initialized
DEBUG - 2021-12-31 09:14:55 --> UTF-8 Support Enabled
INFO - 2021-12-31 09:14:55 --> Utf8 Class Initialized
INFO - 2021-12-31 09:14:55 --> URI Class Initialized
INFO - 2021-12-31 09:14:55 --> Router Class Initialized
INFO - 2021-12-31 09:14:55 --> Output Class Initialized
INFO - 2021-12-31 09:14:55 --> Security Class Initialized
DEBUG - 2021-12-31 09:14:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-31 09:14:55 --> Input Class Initialized
INFO - 2021-12-31 09:14:55 --> Language Class Initialized
ERROR - 2021-12-31 09:14:55 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2021-12-31 09:14:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-31 09:14:55 --> Config Class Initialized
INFO - 2021-12-31 09:14:55 --> Hooks Class Initialized
DEBUG - 2021-12-31 09:14:55 --> UTF-8 Support Enabled
INFO - 2021-12-31 09:14:55 --> Utf8 Class Initialized
INFO - 2021-12-31 09:14:55 --> URI Class Initialized
DEBUG - 2021-12-31 09:14:55 --> No URI present. Default controller set.
INFO - 2021-12-31 09:14:55 --> Router Class Initialized
INFO - 2021-12-31 09:14:55 --> Output Class Initialized
INFO - 2021-12-31 09:14:55 --> Security Class Initialized
DEBUG - 2021-12-31 09:14:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-31 09:14:55 --> Input Class Initialized
INFO - 2021-12-31 09:14:55 --> Language Class Initialized
INFO - 2021-12-31 09:14:55 --> Loader Class Initialized
INFO - 2021-12-31 09:14:55 --> Helper loaded: url_helper
INFO - 2021-12-31 09:14:55 --> Helper loaded: form_helper
INFO - 2021-12-31 09:14:55 --> Helper loaded: common_helper
INFO - 2021-12-31 09:14:55 --> Database Driver Class Initialized
DEBUG - 2021-12-31 09:14:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-31 09:14:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-31 09:14:55 --> Controller Class Initialized
INFO - 2021-12-31 09:14:55 --> Form Validation Class Initialized
DEBUG - 2021-12-31 09:14:55 --> Encrypt Class Initialized
DEBUG - 2021-12-31 09:14:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-31 09:14:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-31 09:14:55 --> Email Class Initialized
INFO - 2021-12-31 09:14:55 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-31 09:14:55 --> Calendar Class Initialized
INFO - 2021-12-31 09:14:55 --> Model "Login_model" initialized
INFO - 2021-12-31 09:14:55 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-31 09:14:55 --> Final output sent to browser
DEBUG - 2021-12-31 09:14:55 --> Total execution time: 0.0265
ERROR - 2021-12-31 09:14:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-31 09:14:57 --> Config Class Initialized
INFO - 2021-12-31 09:14:57 --> Hooks Class Initialized
DEBUG - 2021-12-31 09:14:57 --> UTF-8 Support Enabled
INFO - 2021-12-31 09:14:57 --> Utf8 Class Initialized
INFO - 2021-12-31 09:14:57 --> URI Class Initialized
INFO - 2021-12-31 09:14:57 --> Router Class Initialized
INFO - 2021-12-31 09:14:57 --> Output Class Initialized
INFO - 2021-12-31 09:14:57 --> Security Class Initialized
DEBUG - 2021-12-31 09:14:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-31 09:14:57 --> Input Class Initialized
INFO - 2021-12-31 09:14:57 --> Language Class Initialized
ERROR - 2021-12-31 09:14:57 --> 404 Page Not Found: Adstxt/index
ERROR - 2021-12-31 09:14:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-31 09:14:58 --> Config Class Initialized
INFO - 2021-12-31 09:14:58 --> Hooks Class Initialized
DEBUG - 2021-12-31 09:14:58 --> UTF-8 Support Enabled
INFO - 2021-12-31 09:14:58 --> Utf8 Class Initialized
INFO - 2021-12-31 09:14:58 --> URI Class Initialized
DEBUG - 2021-12-31 09:14:58 --> No URI present. Default controller set.
INFO - 2021-12-31 09:14:58 --> Router Class Initialized
INFO - 2021-12-31 09:14:58 --> Output Class Initialized
INFO - 2021-12-31 09:14:58 --> Security Class Initialized
DEBUG - 2021-12-31 09:14:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-31 09:14:58 --> Input Class Initialized
INFO - 2021-12-31 09:14:58 --> Language Class Initialized
INFO - 2021-12-31 09:14:58 --> Loader Class Initialized
INFO - 2021-12-31 09:14:58 --> Helper loaded: url_helper
INFO - 2021-12-31 09:14:58 --> Helper loaded: form_helper
INFO - 2021-12-31 09:14:58 --> Helper loaded: common_helper
INFO - 2021-12-31 09:14:58 --> Database Driver Class Initialized
DEBUG - 2021-12-31 09:14:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-31 09:14:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-31 09:14:58 --> Controller Class Initialized
INFO - 2021-12-31 09:14:58 --> Form Validation Class Initialized
DEBUG - 2021-12-31 09:14:58 --> Encrypt Class Initialized
DEBUG - 2021-12-31 09:14:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-31 09:14:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-31 09:14:58 --> Email Class Initialized
INFO - 2021-12-31 09:14:58 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-31 09:14:58 --> Calendar Class Initialized
INFO - 2021-12-31 09:14:58 --> Model "Login_model" initialized
INFO - 2021-12-31 09:14:58 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-31 09:14:58 --> Final output sent to browser
DEBUG - 2021-12-31 09:14:58 --> Total execution time: 0.0341
ERROR - 2021-12-31 09:40:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-31 09:40:31 --> Config Class Initialized
INFO - 2021-12-31 09:40:31 --> Hooks Class Initialized
DEBUG - 2021-12-31 09:40:31 --> UTF-8 Support Enabled
INFO - 2021-12-31 09:40:31 --> Utf8 Class Initialized
INFO - 2021-12-31 09:40:31 --> URI Class Initialized
DEBUG - 2021-12-31 09:40:31 --> No URI present. Default controller set.
INFO - 2021-12-31 09:40:31 --> Router Class Initialized
INFO - 2021-12-31 09:40:31 --> Output Class Initialized
INFO - 2021-12-31 09:40:31 --> Security Class Initialized
DEBUG - 2021-12-31 09:40:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-31 09:40:31 --> Input Class Initialized
INFO - 2021-12-31 09:40:31 --> Language Class Initialized
INFO - 2021-12-31 09:40:31 --> Loader Class Initialized
INFO - 2021-12-31 09:40:31 --> Helper loaded: url_helper
INFO - 2021-12-31 09:40:31 --> Helper loaded: form_helper
INFO - 2021-12-31 09:40:31 --> Helper loaded: common_helper
INFO - 2021-12-31 09:40:31 --> Database Driver Class Initialized
DEBUG - 2021-12-31 09:40:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-31 09:40:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-31 09:40:31 --> Controller Class Initialized
INFO - 2021-12-31 09:40:31 --> Form Validation Class Initialized
DEBUG - 2021-12-31 09:40:31 --> Encrypt Class Initialized
DEBUG - 2021-12-31 09:40:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-31 09:40:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-31 09:40:31 --> Email Class Initialized
INFO - 2021-12-31 09:40:31 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-31 09:40:31 --> Calendar Class Initialized
INFO - 2021-12-31 09:40:31 --> Model "Login_model" initialized
INFO - 2021-12-31 09:40:31 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-31 09:40:31 --> Final output sent to browser
DEBUG - 2021-12-31 09:40:31 --> Total execution time: 0.0235
ERROR - 2021-12-31 14:18:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-31 14:18:58 --> Config Class Initialized
INFO - 2021-12-31 14:18:58 --> Hooks Class Initialized
DEBUG - 2021-12-31 14:18:58 --> UTF-8 Support Enabled
INFO - 2021-12-31 14:18:58 --> Utf8 Class Initialized
INFO - 2021-12-31 14:18:58 --> URI Class Initialized
DEBUG - 2021-12-31 14:18:58 --> No URI present. Default controller set.
INFO - 2021-12-31 14:18:58 --> Router Class Initialized
INFO - 2021-12-31 14:18:58 --> Output Class Initialized
INFO - 2021-12-31 14:18:58 --> Security Class Initialized
DEBUG - 2021-12-31 14:18:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-31 14:18:58 --> Input Class Initialized
INFO - 2021-12-31 14:18:58 --> Language Class Initialized
INFO - 2021-12-31 14:18:58 --> Loader Class Initialized
INFO - 2021-12-31 14:18:58 --> Helper loaded: url_helper
INFO - 2021-12-31 14:18:58 --> Helper loaded: form_helper
INFO - 2021-12-31 14:18:58 --> Helper loaded: common_helper
INFO - 2021-12-31 14:18:58 --> Database Driver Class Initialized
DEBUG - 2021-12-31 14:18:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-31 14:18:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-31 14:18:58 --> Controller Class Initialized
INFO - 2021-12-31 14:18:58 --> Form Validation Class Initialized
DEBUG - 2021-12-31 14:18:58 --> Encrypt Class Initialized
DEBUG - 2021-12-31 14:18:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-31 14:18:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-31 14:18:58 --> Email Class Initialized
INFO - 2021-12-31 14:18:58 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-31 14:18:58 --> Calendar Class Initialized
INFO - 2021-12-31 14:18:58 --> Model "Login_model" initialized
INFO - 2021-12-31 14:18:58 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-31 14:18:58 --> Final output sent to browser
DEBUG - 2021-12-31 14:18:58 --> Total execution time: 0.0275
ERROR - 2021-12-31 14:18:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-31 14:18:59 --> Config Class Initialized
INFO - 2021-12-31 14:18:59 --> Hooks Class Initialized
DEBUG - 2021-12-31 14:18:59 --> UTF-8 Support Enabled
INFO - 2021-12-31 14:18:59 --> Utf8 Class Initialized
INFO - 2021-12-31 14:18:59 --> URI Class Initialized
INFO - 2021-12-31 14:18:59 --> Router Class Initialized
INFO - 2021-12-31 14:18:59 --> Output Class Initialized
INFO - 2021-12-31 14:18:59 --> Security Class Initialized
DEBUG - 2021-12-31 14:18:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-31 14:18:59 --> Input Class Initialized
INFO - 2021-12-31 14:18:59 --> Language Class Initialized
ERROR - 2021-12-31 14:18:59 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2021-12-31 14:19:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-31 14:19:06 --> Config Class Initialized
INFO - 2021-12-31 14:19:06 --> Hooks Class Initialized
DEBUG - 2021-12-31 14:19:06 --> UTF-8 Support Enabled
INFO - 2021-12-31 14:19:06 --> Utf8 Class Initialized
INFO - 2021-12-31 14:19:06 --> URI Class Initialized
INFO - 2021-12-31 14:19:06 --> Router Class Initialized
INFO - 2021-12-31 14:19:06 --> Output Class Initialized
INFO - 2021-12-31 14:19:06 --> Security Class Initialized
DEBUG - 2021-12-31 14:19:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-31 14:19:06 --> Input Class Initialized
INFO - 2021-12-31 14:19:06 --> Language Class Initialized
INFO - 2021-12-31 14:19:06 --> Loader Class Initialized
INFO - 2021-12-31 14:19:06 --> Helper loaded: url_helper
INFO - 2021-12-31 14:19:06 --> Helper loaded: form_helper
INFO - 2021-12-31 14:19:06 --> Helper loaded: common_helper
INFO - 2021-12-31 14:19:06 --> Database Driver Class Initialized
DEBUG - 2021-12-31 14:19:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-31 14:19:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-31 14:19:06 --> Controller Class Initialized
INFO - 2021-12-31 14:19:06 --> Form Validation Class Initialized
DEBUG - 2021-12-31 14:19:06 --> Encrypt Class Initialized
DEBUG - 2021-12-31 14:19:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-31 14:19:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-31 14:19:06 --> Email Class Initialized
INFO - 2021-12-31 14:19:06 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-31 14:19:06 --> Calendar Class Initialized
INFO - 2021-12-31 14:19:06 --> Model "Login_model" initialized
ERROR - 2021-12-31 14:19:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-31 14:19:07 --> Config Class Initialized
INFO - 2021-12-31 14:19:07 --> Hooks Class Initialized
DEBUG - 2021-12-31 14:19:07 --> UTF-8 Support Enabled
INFO - 2021-12-31 14:19:07 --> Utf8 Class Initialized
INFO - 2021-12-31 14:19:07 --> URI Class Initialized
INFO - 2021-12-31 14:19:07 --> Router Class Initialized
INFO - 2021-12-31 14:19:07 --> Output Class Initialized
INFO - 2021-12-31 14:19:07 --> Security Class Initialized
DEBUG - 2021-12-31 14:19:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-31 14:19:07 --> Input Class Initialized
INFO - 2021-12-31 14:19:07 --> Language Class Initialized
INFO - 2021-12-31 14:19:07 --> Loader Class Initialized
INFO - 2021-12-31 14:19:07 --> Helper loaded: url_helper
INFO - 2021-12-31 14:19:07 --> Helper loaded: form_helper
INFO - 2021-12-31 14:19:07 --> Helper loaded: common_helper
INFO - 2021-12-31 14:19:07 --> Database Driver Class Initialized
DEBUG - 2021-12-31 14:19:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-31 14:19:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-31 14:19:07 --> Controller Class Initialized
INFO - 2021-12-31 14:19:07 --> Form Validation Class Initialized
DEBUG - 2021-12-31 14:19:07 --> Encrypt Class Initialized
DEBUG - 2021-12-31 14:19:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-31 14:19:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-31 14:19:07 --> Email Class Initialized
INFO - 2021-12-31 14:19:07 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-31 14:19:07 --> Calendar Class Initialized
INFO - 2021-12-31 14:19:07 --> Model "Login_model" initialized
ERROR - 2021-12-31 14:19:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-31 14:19:07 --> Config Class Initialized
INFO - 2021-12-31 14:19:07 --> Hooks Class Initialized
DEBUG - 2021-12-31 14:19:07 --> UTF-8 Support Enabled
INFO - 2021-12-31 14:19:07 --> Utf8 Class Initialized
INFO - 2021-12-31 14:19:07 --> URI Class Initialized
DEBUG - 2021-12-31 14:19:07 --> No URI present. Default controller set.
INFO - 2021-12-31 14:19:07 --> Router Class Initialized
INFO - 2021-12-31 14:19:07 --> Output Class Initialized
INFO - 2021-12-31 14:19:07 --> Security Class Initialized
DEBUG - 2021-12-31 14:19:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-31 14:19:07 --> Input Class Initialized
INFO - 2021-12-31 14:19:07 --> Language Class Initialized
INFO - 2021-12-31 14:19:07 --> Loader Class Initialized
INFO - 2021-12-31 14:19:07 --> Helper loaded: url_helper
INFO - 2021-12-31 14:19:07 --> Helper loaded: form_helper
INFO - 2021-12-31 14:19:07 --> Helper loaded: common_helper
INFO - 2021-12-31 14:19:07 --> Database Driver Class Initialized
DEBUG - 2021-12-31 14:19:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-31 14:19:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-31 14:19:07 --> Controller Class Initialized
INFO - 2021-12-31 14:19:07 --> Form Validation Class Initialized
DEBUG - 2021-12-31 14:19:07 --> Encrypt Class Initialized
DEBUG - 2021-12-31 14:19:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-31 14:19:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-31 14:19:07 --> Email Class Initialized
INFO - 2021-12-31 14:19:07 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-31 14:19:07 --> Calendar Class Initialized
INFO - 2021-12-31 14:19:07 --> Model "Login_model" initialized
INFO - 2021-12-31 14:19:07 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-31 14:19:07 --> Final output sent to browser
DEBUG - 2021-12-31 14:19:07 --> Total execution time: 0.0222
ERROR - 2021-12-31 14:19:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-31 14:19:08 --> Config Class Initialized
INFO - 2021-12-31 14:19:08 --> Hooks Class Initialized
DEBUG - 2021-12-31 14:19:08 --> UTF-8 Support Enabled
INFO - 2021-12-31 14:19:08 --> Utf8 Class Initialized
INFO - 2021-12-31 14:19:08 --> URI Class Initialized
INFO - 2021-12-31 14:19:08 --> Router Class Initialized
INFO - 2021-12-31 14:19:08 --> Output Class Initialized
INFO - 2021-12-31 14:19:08 --> Security Class Initialized
DEBUG - 2021-12-31 14:19:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-31 14:19:08 --> Input Class Initialized
INFO - 2021-12-31 14:19:08 --> Language Class Initialized
INFO - 2021-12-31 14:19:08 --> Loader Class Initialized
INFO - 2021-12-31 14:19:08 --> Helper loaded: url_helper
INFO - 2021-12-31 14:19:08 --> Helper loaded: form_helper
INFO - 2021-12-31 14:19:08 --> Helper loaded: common_helper
INFO - 2021-12-31 14:19:08 --> Database Driver Class Initialized
DEBUG - 2021-12-31 14:19:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-31 14:19:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-31 14:19:08 --> Controller Class Initialized
INFO - 2021-12-31 14:19:08 --> Form Validation Class Initialized
DEBUG - 2021-12-31 14:19:08 --> Encrypt Class Initialized
DEBUG - 2021-12-31 14:19:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-31 14:19:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-31 14:19:08 --> Email Class Initialized
INFO - 2021-12-31 14:19:08 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-31 14:19:08 --> Calendar Class Initialized
INFO - 2021-12-31 14:19:08 --> Model "Login_model" initialized
INFO - 2021-12-31 14:19:08 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-31 14:19:08 --> Final output sent to browser
DEBUG - 2021-12-31 14:19:08 --> Total execution time: 0.0240
ERROR - 2021-12-31 14:34:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-31 14:34:31 --> Config Class Initialized
INFO - 2021-12-31 14:34:31 --> Hooks Class Initialized
DEBUG - 2021-12-31 14:34:31 --> UTF-8 Support Enabled
INFO - 2021-12-31 14:34:31 --> Utf8 Class Initialized
INFO - 2021-12-31 14:34:31 --> URI Class Initialized
DEBUG - 2021-12-31 14:34:31 --> No URI present. Default controller set.
INFO - 2021-12-31 14:34:31 --> Router Class Initialized
INFO - 2021-12-31 14:34:31 --> Output Class Initialized
INFO - 2021-12-31 14:34:31 --> Security Class Initialized
DEBUG - 2021-12-31 14:34:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-31 14:34:31 --> Input Class Initialized
INFO - 2021-12-31 14:34:31 --> Language Class Initialized
INFO - 2021-12-31 14:34:31 --> Loader Class Initialized
INFO - 2021-12-31 14:34:31 --> Helper loaded: url_helper
INFO - 2021-12-31 14:34:31 --> Helper loaded: form_helper
INFO - 2021-12-31 14:34:31 --> Helper loaded: common_helper
INFO - 2021-12-31 14:34:31 --> Database Driver Class Initialized
DEBUG - 2021-12-31 14:34:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-31 14:34:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-31 14:34:31 --> Controller Class Initialized
INFO - 2021-12-31 14:34:31 --> Form Validation Class Initialized
DEBUG - 2021-12-31 14:34:31 --> Encrypt Class Initialized
DEBUG - 2021-12-31 14:34:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-31 14:34:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-31 14:34:31 --> Email Class Initialized
INFO - 2021-12-31 14:34:31 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-31 14:34:31 --> Calendar Class Initialized
INFO - 2021-12-31 14:34:31 --> Model "Login_model" initialized
INFO - 2021-12-31 14:34:31 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-31 14:34:31 --> Final output sent to browser
DEBUG - 2021-12-31 14:34:31 --> Total execution time: 0.0289
ERROR - 2021-12-31 15:24:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-31 15:24:53 --> Config Class Initialized
INFO - 2021-12-31 15:24:53 --> Hooks Class Initialized
DEBUG - 2021-12-31 15:24:53 --> UTF-8 Support Enabled
INFO - 2021-12-31 15:24:53 --> Utf8 Class Initialized
INFO - 2021-12-31 15:24:53 --> URI Class Initialized
DEBUG - 2021-12-31 15:24:53 --> No URI present. Default controller set.
INFO - 2021-12-31 15:24:53 --> Router Class Initialized
INFO - 2021-12-31 15:24:53 --> Output Class Initialized
INFO - 2021-12-31 15:24:53 --> Security Class Initialized
DEBUG - 2021-12-31 15:24:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-31 15:24:53 --> Input Class Initialized
INFO - 2021-12-31 15:24:53 --> Language Class Initialized
INFO - 2021-12-31 15:24:53 --> Loader Class Initialized
INFO - 2021-12-31 15:24:53 --> Helper loaded: url_helper
INFO - 2021-12-31 15:24:53 --> Helper loaded: form_helper
INFO - 2021-12-31 15:24:53 --> Helper loaded: common_helper
INFO - 2021-12-31 15:24:53 --> Database Driver Class Initialized
DEBUG - 2021-12-31 15:24:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-31 15:24:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-31 15:24:53 --> Controller Class Initialized
INFO - 2021-12-31 15:24:53 --> Form Validation Class Initialized
DEBUG - 2021-12-31 15:24:53 --> Encrypt Class Initialized
DEBUG - 2021-12-31 15:24:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-31 15:24:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-31 15:24:53 --> Email Class Initialized
INFO - 2021-12-31 15:24:53 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-31 15:24:53 --> Calendar Class Initialized
INFO - 2021-12-31 15:24:53 --> Model "Login_model" initialized
INFO - 2021-12-31 15:24:53 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-31 15:24:53 --> Final output sent to browser
DEBUG - 2021-12-31 15:24:53 --> Total execution time: 0.0295
ERROR - 2021-12-31 19:28:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-31 19:28:11 --> Config Class Initialized
INFO - 2021-12-31 19:28:11 --> Hooks Class Initialized
DEBUG - 2021-12-31 19:28:11 --> UTF-8 Support Enabled
INFO - 2021-12-31 19:28:11 --> Utf8 Class Initialized
INFO - 2021-12-31 19:28:11 --> URI Class Initialized
DEBUG - 2021-12-31 19:28:11 --> No URI present. Default controller set.
INFO - 2021-12-31 19:28:11 --> Router Class Initialized
INFO - 2021-12-31 19:28:11 --> Output Class Initialized
INFO - 2021-12-31 19:28:11 --> Security Class Initialized
DEBUG - 2021-12-31 19:28:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-31 19:28:11 --> Input Class Initialized
INFO - 2021-12-31 19:28:11 --> Language Class Initialized
INFO - 2021-12-31 19:28:11 --> Loader Class Initialized
INFO - 2021-12-31 19:28:11 --> Helper loaded: url_helper
INFO - 2021-12-31 19:28:11 --> Helper loaded: form_helper
INFO - 2021-12-31 19:28:11 --> Helper loaded: common_helper
INFO - 2021-12-31 19:28:11 --> Database Driver Class Initialized
DEBUG - 2021-12-31 19:28:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-31 19:28:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-31 19:28:11 --> Controller Class Initialized
INFO - 2021-12-31 19:28:11 --> Form Validation Class Initialized
DEBUG - 2021-12-31 19:28:11 --> Encrypt Class Initialized
DEBUG - 2021-12-31 19:28:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-31 19:28:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-31 19:28:11 --> Email Class Initialized
INFO - 2021-12-31 19:28:11 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-31 19:28:11 --> Calendar Class Initialized
INFO - 2021-12-31 19:28:11 --> Model "Login_model" initialized
INFO - 2021-12-31 19:28:11 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-31 19:28:11 --> Final output sent to browser
DEBUG - 2021-12-31 19:28:11 --> Total execution time: 0.0250
