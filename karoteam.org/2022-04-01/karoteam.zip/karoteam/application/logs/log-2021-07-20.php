<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-07-20 08:31:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-20 08:31:22 --> Config Class Initialized
INFO - 2021-07-20 08:31:22 --> Hooks Class Initialized
DEBUG - 2021-07-20 08:31:22 --> UTF-8 Support Enabled
INFO - 2021-07-20 08:31:22 --> Utf8 Class Initialized
INFO - 2021-07-20 08:31:22 --> URI Class Initialized
DEBUG - 2021-07-20 08:31:22 --> No URI present. Default controller set.
INFO - 2021-07-20 08:31:22 --> Router Class Initialized
INFO - 2021-07-20 08:31:22 --> Output Class Initialized
INFO - 2021-07-20 08:31:22 --> Security Class Initialized
DEBUG - 2021-07-20 08:31:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-20 08:31:22 --> Input Class Initialized
INFO - 2021-07-20 08:31:22 --> Language Class Initialized
INFO - 2021-07-20 08:31:22 --> Loader Class Initialized
INFO - 2021-07-20 08:31:22 --> Helper loaded: url_helper
INFO - 2021-07-20 08:31:22 --> Helper loaded: form_helper
INFO - 2021-07-20 08:31:22 --> Helper loaded: common_helper
INFO - 2021-07-20 08:31:22 --> Database Driver Class Initialized
DEBUG - 2021-07-20 08:31:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-20 08:31:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-20 08:31:22 --> Controller Class Initialized
INFO - 2021-07-20 08:31:22 --> Form Validation Class Initialized
DEBUG - 2021-07-20 08:31:22 --> Encrypt Class Initialized
DEBUG - 2021-07-20 08:31:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-07-20 08:31:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-07-20 08:31:22 --> Email Class Initialized
INFO - 2021-07-20 08:31:22 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-07-20 08:31:22 --> Calendar Class Initialized
INFO - 2021-07-20 08:31:22 --> Model "Login_model" initialized
INFO - 2021-07-20 08:31:22 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-07-20 08:31:22 --> Final output sent to browser
DEBUG - 2021-07-20 08:31:22 --> Total execution time: 0.0334
ERROR - 2021-07-20 16:56:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-20 16:56:02 --> Config Class Initialized
INFO - 2021-07-20 16:56:02 --> Hooks Class Initialized
DEBUG - 2021-07-20 16:56:02 --> UTF-8 Support Enabled
INFO - 2021-07-20 16:56:02 --> Utf8 Class Initialized
INFO - 2021-07-20 16:56:02 --> URI Class Initialized
DEBUG - 2021-07-20 16:56:02 --> No URI present. Default controller set.
INFO - 2021-07-20 16:56:02 --> Router Class Initialized
INFO - 2021-07-20 16:56:02 --> Output Class Initialized
INFO - 2021-07-20 16:56:02 --> Security Class Initialized
DEBUG - 2021-07-20 16:56:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-20 16:56:02 --> Input Class Initialized
INFO - 2021-07-20 16:56:02 --> Language Class Initialized
INFO - 2021-07-20 16:56:02 --> Loader Class Initialized
INFO - 2021-07-20 16:56:02 --> Helper loaded: url_helper
INFO - 2021-07-20 16:56:02 --> Helper loaded: form_helper
INFO - 2021-07-20 16:56:02 --> Helper loaded: common_helper
INFO - 2021-07-20 16:56:02 --> Database Driver Class Initialized
DEBUG - 2021-07-20 16:56:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-20 16:56:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-20 16:56:02 --> Controller Class Initialized
INFO - 2021-07-20 16:56:02 --> Form Validation Class Initialized
DEBUG - 2021-07-20 16:56:02 --> Encrypt Class Initialized
DEBUG - 2021-07-20 16:56:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-07-20 16:56:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-07-20 16:56:02 --> Email Class Initialized
INFO - 2021-07-20 16:56:02 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-07-20 16:56:02 --> Calendar Class Initialized
INFO - 2021-07-20 16:56:02 --> Model "Login_model" initialized
INFO - 2021-07-20 16:56:02 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-07-20 16:56:02 --> Final output sent to browser
DEBUG - 2021-07-20 16:56:02 --> Total execution time: 0.0437
