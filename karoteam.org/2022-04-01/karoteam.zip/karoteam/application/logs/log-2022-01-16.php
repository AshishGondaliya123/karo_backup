<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-01-16 08:50:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-16 08:50:22 --> Config Class Initialized
INFO - 2022-01-16 08:50:22 --> Hooks Class Initialized
DEBUG - 2022-01-16 08:50:22 --> UTF-8 Support Enabled
INFO - 2022-01-16 08:50:22 --> Utf8 Class Initialized
INFO - 2022-01-16 08:50:22 --> URI Class Initialized
DEBUG - 2022-01-16 08:50:22 --> No URI present. Default controller set.
INFO - 2022-01-16 08:50:22 --> Router Class Initialized
INFO - 2022-01-16 08:50:22 --> Output Class Initialized
INFO - 2022-01-16 08:50:22 --> Security Class Initialized
DEBUG - 2022-01-16 08:50:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-16 08:50:22 --> Input Class Initialized
INFO - 2022-01-16 08:50:22 --> Language Class Initialized
INFO - 2022-01-16 08:50:22 --> Loader Class Initialized
INFO - 2022-01-16 08:50:22 --> Helper loaded: url_helper
INFO - 2022-01-16 08:50:22 --> Helper loaded: form_helper
INFO - 2022-01-16 08:50:23 --> Helper loaded: common_helper
INFO - 2022-01-16 08:50:23 --> Database Driver Class Initialized
DEBUG - 2022-01-16 08:50:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-16 08:50:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-16 08:50:23 --> Controller Class Initialized
INFO - 2022-01-16 08:50:23 --> Form Validation Class Initialized
DEBUG - 2022-01-16 08:50:23 --> Encrypt Class Initialized
DEBUG - 2022-01-16 08:50:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-16 08:50:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-16 08:50:23 --> Email Class Initialized
INFO - 2022-01-16 08:50:23 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-16 08:50:23 --> Calendar Class Initialized
INFO - 2022-01-16 08:50:23 --> Model "Login_model" initialized
INFO - 2022-01-16 08:50:23 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-16 08:50:23 --> Final output sent to browser
DEBUG - 2022-01-16 08:50:23 --> Total execution time: 0.0645
ERROR - 2022-01-16 10:04:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-16 10:04:29 --> Config Class Initialized
INFO - 2022-01-16 10:04:29 --> Hooks Class Initialized
DEBUG - 2022-01-16 10:04:29 --> UTF-8 Support Enabled
INFO - 2022-01-16 10:04:29 --> Utf8 Class Initialized
INFO - 2022-01-16 10:04:29 --> URI Class Initialized
DEBUG - 2022-01-16 10:04:29 --> No URI present. Default controller set.
INFO - 2022-01-16 10:04:29 --> Router Class Initialized
INFO - 2022-01-16 10:04:29 --> Output Class Initialized
INFO - 2022-01-16 10:04:29 --> Security Class Initialized
DEBUG - 2022-01-16 10:04:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-16 10:04:29 --> Input Class Initialized
INFO - 2022-01-16 10:04:29 --> Language Class Initialized
INFO - 2022-01-16 10:04:29 --> Loader Class Initialized
INFO - 2022-01-16 10:04:29 --> Helper loaded: url_helper
INFO - 2022-01-16 10:04:29 --> Helper loaded: form_helper
INFO - 2022-01-16 10:04:29 --> Helper loaded: common_helper
INFO - 2022-01-16 10:04:29 --> Database Driver Class Initialized
DEBUG - 2022-01-16 10:04:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-16 10:04:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-16 10:04:29 --> Controller Class Initialized
INFO - 2022-01-16 10:04:29 --> Form Validation Class Initialized
DEBUG - 2022-01-16 10:04:29 --> Encrypt Class Initialized
DEBUG - 2022-01-16 10:04:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-16 10:04:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-16 10:04:29 --> Email Class Initialized
INFO - 2022-01-16 10:04:29 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-16 10:04:29 --> Calendar Class Initialized
INFO - 2022-01-16 10:04:29 --> Model "Login_model" initialized
INFO - 2022-01-16 10:04:29 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-16 10:04:29 --> Final output sent to browser
DEBUG - 2022-01-16 10:04:29 --> Total execution time: 0.0239
ERROR - 2022-01-16 10:31:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-16 10:31:13 --> Config Class Initialized
INFO - 2022-01-16 10:31:13 --> Hooks Class Initialized
DEBUG - 2022-01-16 10:31:13 --> UTF-8 Support Enabled
INFO - 2022-01-16 10:31:13 --> Utf8 Class Initialized
INFO - 2022-01-16 10:31:13 --> URI Class Initialized
DEBUG - 2022-01-16 10:31:13 --> No URI present. Default controller set.
INFO - 2022-01-16 10:31:13 --> Router Class Initialized
INFO - 2022-01-16 10:31:13 --> Output Class Initialized
INFO - 2022-01-16 10:31:13 --> Security Class Initialized
DEBUG - 2022-01-16 10:31:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-16 10:31:13 --> Input Class Initialized
INFO - 2022-01-16 10:31:13 --> Language Class Initialized
INFO - 2022-01-16 10:31:13 --> Loader Class Initialized
INFO - 2022-01-16 10:31:13 --> Helper loaded: url_helper
INFO - 2022-01-16 10:31:13 --> Helper loaded: form_helper
INFO - 2022-01-16 10:31:13 --> Helper loaded: common_helper
INFO - 2022-01-16 10:31:13 --> Database Driver Class Initialized
DEBUG - 2022-01-16 10:31:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-16 10:31:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-16 10:31:13 --> Controller Class Initialized
INFO - 2022-01-16 10:31:13 --> Form Validation Class Initialized
DEBUG - 2022-01-16 10:31:13 --> Encrypt Class Initialized
DEBUG - 2022-01-16 10:31:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-16 10:31:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-16 10:31:13 --> Email Class Initialized
INFO - 2022-01-16 10:31:13 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-16 10:31:13 --> Calendar Class Initialized
INFO - 2022-01-16 10:31:13 --> Model "Login_model" initialized
INFO - 2022-01-16 10:31:13 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-16 10:31:13 --> Final output sent to browser
DEBUG - 2022-01-16 10:31:13 --> Total execution time: 0.0233
ERROR - 2022-01-16 10:34:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-16 10:34:29 --> Config Class Initialized
INFO - 2022-01-16 10:34:29 --> Hooks Class Initialized
DEBUG - 2022-01-16 10:34:29 --> UTF-8 Support Enabled
INFO - 2022-01-16 10:34:29 --> Utf8 Class Initialized
INFO - 2022-01-16 10:34:29 --> URI Class Initialized
DEBUG - 2022-01-16 10:34:29 --> No URI present. Default controller set.
INFO - 2022-01-16 10:34:29 --> Router Class Initialized
INFO - 2022-01-16 10:34:29 --> Output Class Initialized
INFO - 2022-01-16 10:34:29 --> Security Class Initialized
DEBUG - 2022-01-16 10:34:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-16 10:34:29 --> Input Class Initialized
INFO - 2022-01-16 10:34:29 --> Language Class Initialized
INFO - 2022-01-16 10:34:29 --> Loader Class Initialized
INFO - 2022-01-16 10:34:29 --> Helper loaded: url_helper
INFO - 2022-01-16 10:34:29 --> Helper loaded: form_helper
INFO - 2022-01-16 10:34:29 --> Helper loaded: common_helper
INFO - 2022-01-16 10:34:29 --> Database Driver Class Initialized
DEBUG - 2022-01-16 10:34:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-16 10:34:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-16 10:34:29 --> Controller Class Initialized
INFO - 2022-01-16 10:34:29 --> Form Validation Class Initialized
DEBUG - 2022-01-16 10:34:29 --> Encrypt Class Initialized
DEBUG - 2022-01-16 10:34:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-16 10:34:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-16 10:34:29 --> Email Class Initialized
INFO - 2022-01-16 10:34:29 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-16 10:34:29 --> Calendar Class Initialized
INFO - 2022-01-16 10:34:29 --> Model "Login_model" initialized
INFO - 2022-01-16 10:34:29 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-16 10:34:29 --> Final output sent to browser
DEBUG - 2022-01-16 10:34:29 --> Total execution time: 0.0282
ERROR - 2022-01-16 10:34:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-16 10:34:30 --> Config Class Initialized
INFO - 2022-01-16 10:34:30 --> Hooks Class Initialized
DEBUG - 2022-01-16 10:34:30 --> UTF-8 Support Enabled
INFO - 2022-01-16 10:34:30 --> Utf8 Class Initialized
INFO - 2022-01-16 10:34:30 --> URI Class Initialized
DEBUG - 2022-01-16 10:34:30 --> No URI present. Default controller set.
INFO - 2022-01-16 10:34:30 --> Router Class Initialized
INFO - 2022-01-16 10:34:30 --> Output Class Initialized
INFO - 2022-01-16 10:34:30 --> Security Class Initialized
DEBUG - 2022-01-16 10:34:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-16 10:34:30 --> Input Class Initialized
INFO - 2022-01-16 10:34:30 --> Language Class Initialized
INFO - 2022-01-16 10:34:30 --> Loader Class Initialized
INFO - 2022-01-16 10:34:30 --> Helper loaded: url_helper
INFO - 2022-01-16 10:34:30 --> Helper loaded: form_helper
INFO - 2022-01-16 10:34:30 --> Helper loaded: common_helper
INFO - 2022-01-16 10:34:30 --> Database Driver Class Initialized
DEBUG - 2022-01-16 10:34:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-16 10:34:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-16 10:34:30 --> Controller Class Initialized
INFO - 2022-01-16 10:34:30 --> Form Validation Class Initialized
DEBUG - 2022-01-16 10:34:30 --> Encrypt Class Initialized
DEBUG - 2022-01-16 10:34:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-16 10:34:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-16 10:34:30 --> Email Class Initialized
INFO - 2022-01-16 10:34:30 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-16 10:34:30 --> Calendar Class Initialized
INFO - 2022-01-16 10:34:30 --> Model "Login_model" initialized
INFO - 2022-01-16 10:34:30 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-16 10:34:30 --> Final output sent to browser
DEBUG - 2022-01-16 10:34:30 --> Total execution time: 0.0288
ERROR - 2022-01-16 10:34:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-16 10:34:30 --> Config Class Initialized
INFO - 2022-01-16 10:34:30 --> Hooks Class Initialized
DEBUG - 2022-01-16 10:34:30 --> UTF-8 Support Enabled
INFO - 2022-01-16 10:34:30 --> Utf8 Class Initialized
INFO - 2022-01-16 10:34:30 --> URI Class Initialized
DEBUG - 2022-01-16 10:34:30 --> No URI present. Default controller set.
INFO - 2022-01-16 10:34:30 --> Router Class Initialized
INFO - 2022-01-16 10:34:30 --> Output Class Initialized
INFO - 2022-01-16 10:34:30 --> Security Class Initialized
DEBUG - 2022-01-16 10:34:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-16 10:34:30 --> Input Class Initialized
INFO - 2022-01-16 10:34:30 --> Language Class Initialized
INFO - 2022-01-16 10:34:30 --> Loader Class Initialized
INFO - 2022-01-16 10:34:30 --> Helper loaded: url_helper
INFO - 2022-01-16 10:34:30 --> Helper loaded: form_helper
INFO - 2022-01-16 10:34:30 --> Helper loaded: common_helper
INFO - 2022-01-16 10:34:30 --> Database Driver Class Initialized
DEBUG - 2022-01-16 10:34:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-16 10:34:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-16 10:34:30 --> Controller Class Initialized
INFO - 2022-01-16 10:34:30 --> Form Validation Class Initialized
DEBUG - 2022-01-16 10:34:30 --> Encrypt Class Initialized
DEBUG - 2022-01-16 10:34:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-16 10:34:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-16 10:34:30 --> Email Class Initialized
INFO - 2022-01-16 10:34:30 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-16 10:34:30 --> Calendar Class Initialized
INFO - 2022-01-16 10:34:30 --> Model "Login_model" initialized
INFO - 2022-01-16 10:34:30 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-16 10:34:30 --> Final output sent to browser
DEBUG - 2022-01-16 10:34:30 --> Total execution time: 0.0273
ERROR - 2022-01-16 10:35:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-16 10:35:04 --> Config Class Initialized
INFO - 2022-01-16 10:35:04 --> Hooks Class Initialized
DEBUG - 2022-01-16 10:35:04 --> UTF-8 Support Enabled
INFO - 2022-01-16 10:35:04 --> Utf8 Class Initialized
INFO - 2022-01-16 10:35:04 --> URI Class Initialized
DEBUG - 2022-01-16 10:35:04 --> No URI present. Default controller set.
INFO - 2022-01-16 10:35:04 --> Router Class Initialized
INFO - 2022-01-16 10:35:04 --> Output Class Initialized
INFO - 2022-01-16 10:35:04 --> Security Class Initialized
DEBUG - 2022-01-16 10:35:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-16 10:35:04 --> Input Class Initialized
INFO - 2022-01-16 10:35:04 --> Language Class Initialized
INFO - 2022-01-16 10:35:04 --> Loader Class Initialized
INFO - 2022-01-16 10:35:04 --> Helper loaded: url_helper
INFO - 2022-01-16 10:35:04 --> Helper loaded: form_helper
INFO - 2022-01-16 10:35:04 --> Helper loaded: common_helper
INFO - 2022-01-16 10:35:04 --> Database Driver Class Initialized
DEBUG - 2022-01-16 10:35:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-16 10:35:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-16 10:35:04 --> Controller Class Initialized
INFO - 2022-01-16 10:35:04 --> Form Validation Class Initialized
DEBUG - 2022-01-16 10:35:04 --> Encrypt Class Initialized
DEBUG - 2022-01-16 10:35:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-16 10:35:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-16 10:35:04 --> Email Class Initialized
INFO - 2022-01-16 10:35:04 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-16 10:35:04 --> Calendar Class Initialized
INFO - 2022-01-16 10:35:04 --> Model "Login_model" initialized
INFO - 2022-01-16 10:35:04 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-16 10:35:04 --> Final output sent to browser
DEBUG - 2022-01-16 10:35:04 --> Total execution time: 0.0218
ERROR - 2022-01-16 10:35:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-16 10:35:14 --> Config Class Initialized
INFO - 2022-01-16 10:35:14 --> Hooks Class Initialized
DEBUG - 2022-01-16 10:35:14 --> UTF-8 Support Enabled
INFO - 2022-01-16 10:35:14 --> Utf8 Class Initialized
INFO - 2022-01-16 10:35:14 --> URI Class Initialized
DEBUG - 2022-01-16 10:35:14 --> No URI present. Default controller set.
INFO - 2022-01-16 10:35:14 --> Router Class Initialized
INFO - 2022-01-16 10:35:14 --> Output Class Initialized
INFO - 2022-01-16 10:35:14 --> Security Class Initialized
DEBUG - 2022-01-16 10:35:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-16 10:35:14 --> Input Class Initialized
INFO - 2022-01-16 10:35:14 --> Language Class Initialized
INFO - 2022-01-16 10:35:14 --> Loader Class Initialized
INFO - 2022-01-16 10:35:14 --> Helper loaded: url_helper
INFO - 2022-01-16 10:35:14 --> Helper loaded: form_helper
INFO - 2022-01-16 10:35:14 --> Helper loaded: common_helper
INFO - 2022-01-16 10:35:14 --> Database Driver Class Initialized
DEBUG - 2022-01-16 10:35:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-16 10:35:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-16 10:35:14 --> Controller Class Initialized
INFO - 2022-01-16 10:35:14 --> Form Validation Class Initialized
DEBUG - 2022-01-16 10:35:14 --> Encrypt Class Initialized
DEBUG - 2022-01-16 10:35:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-16 10:35:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-16 10:35:14 --> Email Class Initialized
INFO - 2022-01-16 10:35:14 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-16 10:35:14 --> Calendar Class Initialized
INFO - 2022-01-16 10:35:14 --> Model "Login_model" initialized
INFO - 2022-01-16 10:35:14 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-16 10:35:14 --> Final output sent to browser
DEBUG - 2022-01-16 10:35:14 --> Total execution time: 0.0361
ERROR - 2022-01-16 11:05:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-16 11:05:21 --> Config Class Initialized
INFO - 2022-01-16 11:05:21 --> Hooks Class Initialized
DEBUG - 2022-01-16 11:05:21 --> UTF-8 Support Enabled
INFO - 2022-01-16 11:05:21 --> Utf8 Class Initialized
INFO - 2022-01-16 11:05:21 --> URI Class Initialized
DEBUG - 2022-01-16 11:05:21 --> No URI present. Default controller set.
INFO - 2022-01-16 11:05:21 --> Router Class Initialized
INFO - 2022-01-16 11:05:21 --> Output Class Initialized
INFO - 2022-01-16 11:05:21 --> Security Class Initialized
DEBUG - 2022-01-16 11:05:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-16 11:05:21 --> Input Class Initialized
INFO - 2022-01-16 11:05:21 --> Language Class Initialized
INFO - 2022-01-16 11:05:21 --> Loader Class Initialized
INFO - 2022-01-16 11:05:21 --> Helper loaded: url_helper
INFO - 2022-01-16 11:05:21 --> Helper loaded: form_helper
INFO - 2022-01-16 11:05:21 --> Helper loaded: common_helper
INFO - 2022-01-16 11:05:21 --> Database Driver Class Initialized
DEBUG - 2022-01-16 11:05:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-16 11:05:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-16 11:05:21 --> Controller Class Initialized
INFO - 2022-01-16 11:05:21 --> Form Validation Class Initialized
DEBUG - 2022-01-16 11:05:21 --> Encrypt Class Initialized
DEBUG - 2022-01-16 11:05:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-16 11:05:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-16 11:05:21 --> Email Class Initialized
INFO - 2022-01-16 11:05:21 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-16 11:05:21 --> Calendar Class Initialized
INFO - 2022-01-16 11:05:21 --> Model "Login_model" initialized
INFO - 2022-01-16 11:05:21 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-16 11:05:21 --> Final output sent to browser
DEBUG - 2022-01-16 11:05:21 --> Total execution time: 0.0291
ERROR - 2022-01-16 11:05:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-16 11:05:40 --> Config Class Initialized
INFO - 2022-01-16 11:05:40 --> Hooks Class Initialized
DEBUG - 2022-01-16 11:05:40 --> UTF-8 Support Enabled
INFO - 2022-01-16 11:05:40 --> Utf8 Class Initialized
INFO - 2022-01-16 11:05:40 --> URI Class Initialized
DEBUG - 2022-01-16 11:05:40 --> No URI present. Default controller set.
INFO - 2022-01-16 11:05:40 --> Router Class Initialized
INFO - 2022-01-16 11:05:40 --> Output Class Initialized
INFO - 2022-01-16 11:05:40 --> Security Class Initialized
DEBUG - 2022-01-16 11:05:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-16 11:05:40 --> Input Class Initialized
INFO - 2022-01-16 11:05:40 --> Language Class Initialized
INFO - 2022-01-16 11:05:40 --> Loader Class Initialized
INFO - 2022-01-16 11:05:40 --> Helper loaded: url_helper
INFO - 2022-01-16 11:05:40 --> Helper loaded: form_helper
INFO - 2022-01-16 11:05:40 --> Helper loaded: common_helper
INFO - 2022-01-16 11:05:40 --> Database Driver Class Initialized
DEBUG - 2022-01-16 11:05:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-16 11:05:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-16 11:05:40 --> Controller Class Initialized
INFO - 2022-01-16 11:05:40 --> Form Validation Class Initialized
DEBUG - 2022-01-16 11:05:40 --> Encrypt Class Initialized
DEBUG - 2022-01-16 11:05:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-16 11:05:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-16 11:05:40 --> Email Class Initialized
INFO - 2022-01-16 11:05:40 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-16 11:05:40 --> Calendar Class Initialized
INFO - 2022-01-16 11:05:40 --> Model "Login_model" initialized
INFO - 2022-01-16 11:05:40 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-16 11:05:40 --> Final output sent to browser
DEBUG - 2022-01-16 11:05:40 --> Total execution time: 0.0293
ERROR - 2022-01-16 11:05:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-16 11:05:59 --> Config Class Initialized
INFO - 2022-01-16 11:05:59 --> Hooks Class Initialized
DEBUG - 2022-01-16 11:05:59 --> UTF-8 Support Enabled
INFO - 2022-01-16 11:05:59 --> Utf8 Class Initialized
INFO - 2022-01-16 11:05:59 --> URI Class Initialized
DEBUG - 2022-01-16 11:05:59 --> No URI present. Default controller set.
INFO - 2022-01-16 11:05:59 --> Router Class Initialized
INFO - 2022-01-16 11:05:59 --> Output Class Initialized
INFO - 2022-01-16 11:05:59 --> Security Class Initialized
DEBUG - 2022-01-16 11:05:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-16 11:05:59 --> Input Class Initialized
INFO - 2022-01-16 11:05:59 --> Language Class Initialized
INFO - 2022-01-16 11:05:59 --> Loader Class Initialized
INFO - 2022-01-16 11:05:59 --> Helper loaded: url_helper
INFO - 2022-01-16 11:05:59 --> Helper loaded: form_helper
INFO - 2022-01-16 11:05:59 --> Helper loaded: common_helper
INFO - 2022-01-16 11:05:59 --> Database Driver Class Initialized
DEBUG - 2022-01-16 11:05:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-16 11:05:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-16 11:05:59 --> Controller Class Initialized
INFO - 2022-01-16 11:05:59 --> Form Validation Class Initialized
DEBUG - 2022-01-16 11:05:59 --> Encrypt Class Initialized
DEBUG - 2022-01-16 11:05:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-16 11:05:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-16 11:05:59 --> Email Class Initialized
INFO - 2022-01-16 11:05:59 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-16 11:05:59 --> Calendar Class Initialized
INFO - 2022-01-16 11:05:59 --> Model "Login_model" initialized
INFO - 2022-01-16 11:05:59 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-16 11:05:59 --> Final output sent to browser
DEBUG - 2022-01-16 11:05:59 --> Total execution time: 0.0227
ERROR - 2022-01-16 11:06:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-16 11:06:00 --> Config Class Initialized
INFO - 2022-01-16 11:06:00 --> Hooks Class Initialized
DEBUG - 2022-01-16 11:06:00 --> UTF-8 Support Enabled
INFO - 2022-01-16 11:06:00 --> Utf8 Class Initialized
INFO - 2022-01-16 11:06:00 --> URI Class Initialized
DEBUG - 2022-01-16 11:06:00 --> No URI present. Default controller set.
INFO - 2022-01-16 11:06:00 --> Router Class Initialized
INFO - 2022-01-16 11:06:00 --> Output Class Initialized
INFO - 2022-01-16 11:06:00 --> Security Class Initialized
DEBUG - 2022-01-16 11:06:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-16 11:06:00 --> Input Class Initialized
INFO - 2022-01-16 11:06:00 --> Language Class Initialized
INFO - 2022-01-16 11:06:00 --> Loader Class Initialized
INFO - 2022-01-16 11:06:00 --> Helper loaded: url_helper
INFO - 2022-01-16 11:06:00 --> Helper loaded: form_helper
INFO - 2022-01-16 11:06:00 --> Helper loaded: common_helper
INFO - 2022-01-16 11:06:00 --> Database Driver Class Initialized
DEBUG - 2022-01-16 11:06:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-16 11:06:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-16 11:06:00 --> Controller Class Initialized
INFO - 2022-01-16 11:06:00 --> Form Validation Class Initialized
DEBUG - 2022-01-16 11:06:00 --> Encrypt Class Initialized
DEBUG - 2022-01-16 11:06:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-16 11:06:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-16 11:06:00 --> Email Class Initialized
INFO - 2022-01-16 11:06:00 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-16 11:06:00 --> Calendar Class Initialized
INFO - 2022-01-16 11:06:00 --> Model "Login_model" initialized
INFO - 2022-01-16 11:06:00 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-16 11:06:00 --> Final output sent to browser
DEBUG - 2022-01-16 11:06:00 --> Total execution time: 0.0206
ERROR - 2022-01-16 11:28:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-16 11:28:09 --> Config Class Initialized
INFO - 2022-01-16 11:28:09 --> Hooks Class Initialized
DEBUG - 2022-01-16 11:28:09 --> UTF-8 Support Enabled
INFO - 2022-01-16 11:28:09 --> Utf8 Class Initialized
INFO - 2022-01-16 11:28:09 --> URI Class Initialized
DEBUG - 2022-01-16 11:28:09 --> No URI present. Default controller set.
INFO - 2022-01-16 11:28:09 --> Router Class Initialized
INFO - 2022-01-16 11:28:09 --> Output Class Initialized
INFO - 2022-01-16 11:28:09 --> Security Class Initialized
DEBUG - 2022-01-16 11:28:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-16 11:28:09 --> Input Class Initialized
INFO - 2022-01-16 11:28:09 --> Language Class Initialized
INFO - 2022-01-16 11:28:09 --> Loader Class Initialized
INFO - 2022-01-16 11:28:09 --> Helper loaded: url_helper
INFO - 2022-01-16 11:28:09 --> Helper loaded: form_helper
INFO - 2022-01-16 11:28:09 --> Helper loaded: common_helper
INFO - 2022-01-16 11:28:09 --> Database Driver Class Initialized
DEBUG - 2022-01-16 11:28:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-16 11:28:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-16 11:28:09 --> Controller Class Initialized
INFO - 2022-01-16 11:28:09 --> Form Validation Class Initialized
DEBUG - 2022-01-16 11:28:09 --> Encrypt Class Initialized
DEBUG - 2022-01-16 11:28:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-16 11:28:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-16 11:28:09 --> Email Class Initialized
INFO - 2022-01-16 11:28:09 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-16 11:28:09 --> Calendar Class Initialized
INFO - 2022-01-16 11:28:09 --> Model "Login_model" initialized
INFO - 2022-01-16 11:28:09 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-16 11:28:09 --> Final output sent to browser
DEBUG - 2022-01-16 11:28:09 --> Total execution time: 0.0291
ERROR - 2022-01-16 11:28:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-16 11:28:10 --> Config Class Initialized
INFO - 2022-01-16 11:28:10 --> Hooks Class Initialized
DEBUG - 2022-01-16 11:28:10 --> UTF-8 Support Enabled
INFO - 2022-01-16 11:28:10 --> Utf8 Class Initialized
INFO - 2022-01-16 11:28:10 --> URI Class Initialized
DEBUG - 2022-01-16 11:28:10 --> No URI present. Default controller set.
INFO - 2022-01-16 11:28:10 --> Router Class Initialized
INFO - 2022-01-16 11:28:10 --> Output Class Initialized
INFO - 2022-01-16 11:28:10 --> Security Class Initialized
DEBUG - 2022-01-16 11:28:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-16 11:28:10 --> Input Class Initialized
INFO - 2022-01-16 11:28:10 --> Language Class Initialized
INFO - 2022-01-16 11:28:10 --> Loader Class Initialized
INFO - 2022-01-16 11:28:10 --> Helper loaded: url_helper
INFO - 2022-01-16 11:28:10 --> Helper loaded: form_helper
INFO - 2022-01-16 11:28:10 --> Helper loaded: common_helper
INFO - 2022-01-16 11:28:10 --> Database Driver Class Initialized
DEBUG - 2022-01-16 11:28:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-16 11:28:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-16 11:28:10 --> Controller Class Initialized
INFO - 2022-01-16 11:28:10 --> Form Validation Class Initialized
DEBUG - 2022-01-16 11:28:10 --> Encrypt Class Initialized
DEBUG - 2022-01-16 11:28:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-16 11:28:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-16 11:28:10 --> Email Class Initialized
INFO - 2022-01-16 11:28:10 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-16 11:28:10 --> Calendar Class Initialized
INFO - 2022-01-16 11:28:10 --> Model "Login_model" initialized
INFO - 2022-01-16 11:28:10 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-16 11:28:10 --> Final output sent to browser
DEBUG - 2022-01-16 11:28:10 --> Total execution time: 0.0221
ERROR - 2022-01-16 11:28:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-16 11:28:16 --> Config Class Initialized
INFO - 2022-01-16 11:28:16 --> Hooks Class Initialized
DEBUG - 2022-01-16 11:28:16 --> UTF-8 Support Enabled
INFO - 2022-01-16 11:28:16 --> Utf8 Class Initialized
INFO - 2022-01-16 11:28:16 --> URI Class Initialized
DEBUG - 2022-01-16 11:28:16 --> No URI present. Default controller set.
INFO - 2022-01-16 11:28:16 --> Router Class Initialized
INFO - 2022-01-16 11:28:16 --> Output Class Initialized
INFO - 2022-01-16 11:28:16 --> Security Class Initialized
DEBUG - 2022-01-16 11:28:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-16 11:28:16 --> Input Class Initialized
INFO - 2022-01-16 11:28:16 --> Language Class Initialized
INFO - 2022-01-16 11:28:16 --> Loader Class Initialized
INFO - 2022-01-16 11:28:16 --> Helper loaded: url_helper
INFO - 2022-01-16 11:28:16 --> Helper loaded: form_helper
INFO - 2022-01-16 11:28:16 --> Helper loaded: common_helper
INFO - 2022-01-16 11:28:16 --> Database Driver Class Initialized
DEBUG - 2022-01-16 11:28:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-16 11:28:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-16 11:28:16 --> Controller Class Initialized
INFO - 2022-01-16 11:28:16 --> Form Validation Class Initialized
DEBUG - 2022-01-16 11:28:16 --> Encrypt Class Initialized
DEBUG - 2022-01-16 11:28:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-16 11:28:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-16 11:28:16 --> Email Class Initialized
INFO - 2022-01-16 11:28:16 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-16 11:28:16 --> Calendar Class Initialized
INFO - 2022-01-16 11:28:16 --> Model "Login_model" initialized
INFO - 2022-01-16 11:28:16 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-16 11:28:16 --> Final output sent to browser
DEBUG - 2022-01-16 11:28:16 --> Total execution time: 0.0225
ERROR - 2022-01-16 11:28:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-16 11:28:19 --> Config Class Initialized
INFO - 2022-01-16 11:28:19 --> Hooks Class Initialized
DEBUG - 2022-01-16 11:28:19 --> UTF-8 Support Enabled
INFO - 2022-01-16 11:28:19 --> Utf8 Class Initialized
INFO - 2022-01-16 11:28:19 --> URI Class Initialized
DEBUG - 2022-01-16 11:28:19 --> No URI present. Default controller set.
INFO - 2022-01-16 11:28:19 --> Router Class Initialized
INFO - 2022-01-16 11:28:19 --> Output Class Initialized
INFO - 2022-01-16 11:28:19 --> Security Class Initialized
DEBUG - 2022-01-16 11:28:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-16 11:28:19 --> Input Class Initialized
INFO - 2022-01-16 11:28:19 --> Language Class Initialized
INFO - 2022-01-16 11:28:19 --> Loader Class Initialized
INFO - 2022-01-16 11:28:19 --> Helper loaded: url_helper
INFO - 2022-01-16 11:28:19 --> Helper loaded: form_helper
INFO - 2022-01-16 11:28:19 --> Helper loaded: common_helper
INFO - 2022-01-16 11:28:19 --> Database Driver Class Initialized
DEBUG - 2022-01-16 11:28:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-16 11:28:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-16 11:28:19 --> Controller Class Initialized
INFO - 2022-01-16 11:28:19 --> Form Validation Class Initialized
DEBUG - 2022-01-16 11:28:19 --> Encrypt Class Initialized
DEBUG - 2022-01-16 11:28:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-16 11:28:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-16 11:28:19 --> Email Class Initialized
INFO - 2022-01-16 11:28:19 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-16 11:28:19 --> Calendar Class Initialized
INFO - 2022-01-16 11:28:19 --> Model "Login_model" initialized
INFO - 2022-01-16 11:28:19 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-16 11:28:19 --> Final output sent to browser
DEBUG - 2022-01-16 11:28:19 --> Total execution time: 0.0291
ERROR - 2022-01-16 11:53:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-16 11:53:50 --> Config Class Initialized
INFO - 2022-01-16 11:53:50 --> Hooks Class Initialized
DEBUG - 2022-01-16 11:53:50 --> UTF-8 Support Enabled
INFO - 2022-01-16 11:53:50 --> Utf8 Class Initialized
INFO - 2022-01-16 11:53:50 --> URI Class Initialized
DEBUG - 2022-01-16 11:53:50 --> No URI present. Default controller set.
INFO - 2022-01-16 11:53:50 --> Router Class Initialized
INFO - 2022-01-16 11:53:50 --> Output Class Initialized
INFO - 2022-01-16 11:53:50 --> Security Class Initialized
DEBUG - 2022-01-16 11:53:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-16 11:53:50 --> Input Class Initialized
INFO - 2022-01-16 11:53:50 --> Language Class Initialized
INFO - 2022-01-16 11:53:50 --> Loader Class Initialized
INFO - 2022-01-16 11:53:50 --> Helper loaded: url_helper
INFO - 2022-01-16 11:53:50 --> Helper loaded: form_helper
INFO - 2022-01-16 11:53:50 --> Helper loaded: common_helper
INFO - 2022-01-16 11:53:50 --> Database Driver Class Initialized
DEBUG - 2022-01-16 11:53:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-16 11:53:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-16 11:53:50 --> Controller Class Initialized
INFO - 2022-01-16 11:53:50 --> Form Validation Class Initialized
DEBUG - 2022-01-16 11:53:50 --> Encrypt Class Initialized
DEBUG - 2022-01-16 11:53:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-16 11:53:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-16 11:53:50 --> Email Class Initialized
INFO - 2022-01-16 11:53:50 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-16 11:53:50 --> Calendar Class Initialized
INFO - 2022-01-16 11:53:50 --> Model "Login_model" initialized
INFO - 2022-01-16 11:53:50 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-16 11:53:50 --> Final output sent to browser
DEBUG - 2022-01-16 11:53:50 --> Total execution time: 0.0257
ERROR - 2022-01-16 11:53:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-16 11:53:50 --> Config Class Initialized
INFO - 2022-01-16 11:53:50 --> Hooks Class Initialized
DEBUG - 2022-01-16 11:53:50 --> UTF-8 Support Enabled
INFO - 2022-01-16 11:53:50 --> Utf8 Class Initialized
INFO - 2022-01-16 11:53:50 --> URI Class Initialized
DEBUG - 2022-01-16 11:53:50 --> No URI present. Default controller set.
INFO - 2022-01-16 11:53:50 --> Router Class Initialized
INFO - 2022-01-16 11:53:51 --> Output Class Initialized
INFO - 2022-01-16 11:53:51 --> Security Class Initialized
DEBUG - 2022-01-16 11:53:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-16 11:53:51 --> Input Class Initialized
INFO - 2022-01-16 11:53:51 --> Language Class Initialized
INFO - 2022-01-16 11:53:51 --> Loader Class Initialized
INFO - 2022-01-16 11:53:51 --> Helper loaded: url_helper
INFO - 2022-01-16 11:53:51 --> Helper loaded: form_helper
INFO - 2022-01-16 11:53:51 --> Helper loaded: common_helper
INFO - 2022-01-16 11:53:51 --> Database Driver Class Initialized
DEBUG - 2022-01-16 11:53:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-16 11:53:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-16 11:53:51 --> Controller Class Initialized
INFO - 2022-01-16 11:53:51 --> Form Validation Class Initialized
DEBUG - 2022-01-16 11:53:51 --> Encrypt Class Initialized
DEBUG - 2022-01-16 11:53:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-16 11:53:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-16 11:53:51 --> Email Class Initialized
INFO - 2022-01-16 11:53:51 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-16 11:53:51 --> Calendar Class Initialized
INFO - 2022-01-16 11:53:51 --> Model "Login_model" initialized
INFO - 2022-01-16 11:53:51 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-16 11:53:51 --> Final output sent to browser
DEBUG - 2022-01-16 11:53:51 --> Total execution time: 0.0346
ERROR - 2022-01-16 11:53:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-16 11:53:55 --> Config Class Initialized
INFO - 2022-01-16 11:53:55 --> Hooks Class Initialized
DEBUG - 2022-01-16 11:53:55 --> UTF-8 Support Enabled
INFO - 2022-01-16 11:53:55 --> Utf8 Class Initialized
INFO - 2022-01-16 11:53:55 --> URI Class Initialized
DEBUG - 2022-01-16 11:53:55 --> No URI present. Default controller set.
INFO - 2022-01-16 11:53:55 --> Router Class Initialized
INFO - 2022-01-16 11:53:55 --> Output Class Initialized
INFO - 2022-01-16 11:53:55 --> Security Class Initialized
DEBUG - 2022-01-16 11:53:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-16 11:53:55 --> Input Class Initialized
INFO - 2022-01-16 11:53:55 --> Language Class Initialized
INFO - 2022-01-16 11:53:55 --> Loader Class Initialized
INFO - 2022-01-16 11:53:55 --> Helper loaded: url_helper
INFO - 2022-01-16 11:53:55 --> Helper loaded: form_helper
INFO - 2022-01-16 11:53:55 --> Helper loaded: common_helper
INFO - 2022-01-16 11:53:55 --> Database Driver Class Initialized
DEBUG - 2022-01-16 11:53:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-16 11:53:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-16 11:53:55 --> Controller Class Initialized
INFO - 2022-01-16 11:53:55 --> Form Validation Class Initialized
DEBUG - 2022-01-16 11:53:55 --> Encrypt Class Initialized
DEBUG - 2022-01-16 11:53:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-16 11:53:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-16 11:53:55 --> Email Class Initialized
INFO - 2022-01-16 11:53:55 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-16 11:53:55 --> Calendar Class Initialized
INFO - 2022-01-16 11:53:55 --> Model "Login_model" initialized
INFO - 2022-01-16 11:53:55 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-16 11:53:55 --> Final output sent to browser
DEBUG - 2022-01-16 11:53:55 --> Total execution time: 0.0222
ERROR - 2022-01-16 11:54:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-16 11:54:17 --> Config Class Initialized
INFO - 2022-01-16 11:54:17 --> Hooks Class Initialized
DEBUG - 2022-01-16 11:54:17 --> UTF-8 Support Enabled
INFO - 2022-01-16 11:54:17 --> Utf8 Class Initialized
INFO - 2022-01-16 11:54:17 --> URI Class Initialized
DEBUG - 2022-01-16 11:54:17 --> No URI present. Default controller set.
INFO - 2022-01-16 11:54:17 --> Router Class Initialized
INFO - 2022-01-16 11:54:17 --> Output Class Initialized
INFO - 2022-01-16 11:54:17 --> Security Class Initialized
DEBUG - 2022-01-16 11:54:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-16 11:54:17 --> Input Class Initialized
INFO - 2022-01-16 11:54:17 --> Language Class Initialized
INFO - 2022-01-16 11:54:17 --> Loader Class Initialized
INFO - 2022-01-16 11:54:17 --> Helper loaded: url_helper
INFO - 2022-01-16 11:54:17 --> Helper loaded: form_helper
INFO - 2022-01-16 11:54:17 --> Helper loaded: common_helper
INFO - 2022-01-16 11:54:17 --> Database Driver Class Initialized
DEBUG - 2022-01-16 11:54:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-16 11:54:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-16 11:54:17 --> Controller Class Initialized
INFO - 2022-01-16 11:54:17 --> Form Validation Class Initialized
DEBUG - 2022-01-16 11:54:17 --> Encrypt Class Initialized
DEBUG - 2022-01-16 11:54:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-16 11:54:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-16 11:54:17 --> Email Class Initialized
INFO - 2022-01-16 11:54:17 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-16 11:54:17 --> Calendar Class Initialized
INFO - 2022-01-16 11:54:17 --> Model "Login_model" initialized
INFO - 2022-01-16 11:54:17 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-16 11:54:17 --> Final output sent to browser
DEBUG - 2022-01-16 11:54:17 --> Total execution time: 0.0348
ERROR - 2022-01-16 12:43:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-16 12:43:26 --> Config Class Initialized
INFO - 2022-01-16 12:43:26 --> Hooks Class Initialized
DEBUG - 2022-01-16 12:43:26 --> UTF-8 Support Enabled
INFO - 2022-01-16 12:43:26 --> Utf8 Class Initialized
INFO - 2022-01-16 12:43:26 --> URI Class Initialized
INFO - 2022-01-16 12:43:26 --> Router Class Initialized
INFO - 2022-01-16 12:43:26 --> Output Class Initialized
INFO - 2022-01-16 12:43:26 --> Security Class Initialized
DEBUG - 2022-01-16 12:43:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-16 12:43:26 --> Input Class Initialized
INFO - 2022-01-16 12:43:26 --> Language Class Initialized
ERROR - 2022-01-16 12:43:26 --> 404 Page Not Found: Old-indexphp/index
ERROR - 2022-01-16 14:17:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-16 14:17:28 --> Config Class Initialized
INFO - 2022-01-16 14:17:28 --> Hooks Class Initialized
DEBUG - 2022-01-16 14:17:28 --> UTF-8 Support Enabled
INFO - 2022-01-16 14:17:28 --> Utf8 Class Initialized
INFO - 2022-01-16 14:17:28 --> URI Class Initialized
DEBUG - 2022-01-16 14:17:28 --> No URI present. Default controller set.
INFO - 2022-01-16 14:17:28 --> Router Class Initialized
INFO - 2022-01-16 14:17:28 --> Output Class Initialized
INFO - 2022-01-16 14:17:28 --> Security Class Initialized
DEBUG - 2022-01-16 14:17:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-16 14:17:28 --> Input Class Initialized
INFO - 2022-01-16 14:17:28 --> Language Class Initialized
INFO - 2022-01-16 14:17:28 --> Loader Class Initialized
INFO - 2022-01-16 14:17:28 --> Helper loaded: url_helper
INFO - 2022-01-16 14:17:28 --> Helper loaded: form_helper
INFO - 2022-01-16 14:17:28 --> Helper loaded: common_helper
INFO - 2022-01-16 14:17:28 --> Database Driver Class Initialized
DEBUG - 2022-01-16 14:17:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-16 14:17:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-16 14:17:28 --> Controller Class Initialized
INFO - 2022-01-16 14:17:28 --> Form Validation Class Initialized
DEBUG - 2022-01-16 14:17:28 --> Encrypt Class Initialized
DEBUG - 2022-01-16 14:17:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-16 14:17:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-16 14:17:28 --> Email Class Initialized
INFO - 2022-01-16 14:17:28 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-16 14:17:28 --> Calendar Class Initialized
INFO - 2022-01-16 14:17:28 --> Model "Login_model" initialized
INFO - 2022-01-16 14:17:28 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-16 14:17:28 --> Final output sent to browser
DEBUG - 2022-01-16 14:17:28 --> Total execution time: 0.0241
ERROR - 2022-01-16 14:17:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-16 14:17:30 --> Config Class Initialized
INFO - 2022-01-16 14:17:30 --> Hooks Class Initialized
DEBUG - 2022-01-16 14:17:30 --> UTF-8 Support Enabled
INFO - 2022-01-16 14:17:30 --> Utf8 Class Initialized
INFO - 2022-01-16 14:17:30 --> URI Class Initialized
INFO - 2022-01-16 14:17:30 --> Router Class Initialized
INFO - 2022-01-16 14:17:30 --> Output Class Initialized
INFO - 2022-01-16 14:17:30 --> Security Class Initialized
DEBUG - 2022-01-16 14:17:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-16 14:17:30 --> Input Class Initialized
INFO - 2022-01-16 14:17:30 --> Language Class Initialized
ERROR - 2022-01-16 14:17:30 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2022-01-16 14:17:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-16 14:17:59 --> Config Class Initialized
INFO - 2022-01-16 14:17:59 --> Hooks Class Initialized
DEBUG - 2022-01-16 14:17:59 --> UTF-8 Support Enabled
INFO - 2022-01-16 14:17:59 --> Utf8 Class Initialized
INFO - 2022-01-16 14:17:59 --> URI Class Initialized
INFO - 2022-01-16 14:17:59 --> Router Class Initialized
INFO - 2022-01-16 14:17:59 --> Output Class Initialized
INFO - 2022-01-16 14:17:59 --> Security Class Initialized
DEBUG - 2022-01-16 14:17:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-16 14:17:59 --> Input Class Initialized
INFO - 2022-01-16 14:17:59 --> Language Class Initialized
INFO - 2022-01-16 14:17:59 --> Loader Class Initialized
INFO - 2022-01-16 14:17:59 --> Helper loaded: url_helper
INFO - 2022-01-16 14:17:59 --> Helper loaded: form_helper
INFO - 2022-01-16 14:17:59 --> Helper loaded: common_helper
INFO - 2022-01-16 14:17:59 --> Database Driver Class Initialized
DEBUG - 2022-01-16 14:17:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-16 14:17:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-16 14:17:59 --> Controller Class Initialized
INFO - 2022-01-16 14:17:59 --> Form Validation Class Initialized
DEBUG - 2022-01-16 14:17:59 --> Encrypt Class Initialized
DEBUG - 2022-01-16 14:17:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-16 14:17:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-16 14:17:59 --> Email Class Initialized
INFO - 2022-01-16 14:17:59 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-16 14:17:59 --> Calendar Class Initialized
INFO - 2022-01-16 14:17:59 --> Model "Login_model" initialized
ERROR - 2022-01-16 14:18:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-16 14:18:00 --> Config Class Initialized
INFO - 2022-01-16 14:18:00 --> Hooks Class Initialized
DEBUG - 2022-01-16 14:18:00 --> UTF-8 Support Enabled
INFO - 2022-01-16 14:18:00 --> Utf8 Class Initialized
INFO - 2022-01-16 14:18:00 --> URI Class Initialized
INFO - 2022-01-16 14:18:00 --> Router Class Initialized
INFO - 2022-01-16 14:18:00 --> Output Class Initialized
INFO - 2022-01-16 14:18:00 --> Security Class Initialized
DEBUG - 2022-01-16 14:18:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-16 14:18:00 --> Input Class Initialized
INFO - 2022-01-16 14:18:00 --> Language Class Initialized
INFO - 2022-01-16 14:18:00 --> Loader Class Initialized
INFO - 2022-01-16 14:18:00 --> Helper loaded: url_helper
INFO - 2022-01-16 14:18:00 --> Helper loaded: form_helper
INFO - 2022-01-16 14:18:00 --> Helper loaded: common_helper
INFO - 2022-01-16 14:18:00 --> Database Driver Class Initialized
DEBUG - 2022-01-16 14:18:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-16 14:18:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-16 14:18:00 --> Controller Class Initialized
INFO - 2022-01-16 14:18:00 --> Form Validation Class Initialized
DEBUG - 2022-01-16 14:18:00 --> Encrypt Class Initialized
DEBUG - 2022-01-16 14:18:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-16 14:18:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-16 14:18:00 --> Email Class Initialized
INFO - 2022-01-16 14:18:00 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-16 14:18:00 --> Calendar Class Initialized
INFO - 2022-01-16 14:18:00 --> Model "Login_model" initialized
ERROR - 2022-01-16 14:18:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-16 14:18:01 --> Config Class Initialized
INFO - 2022-01-16 14:18:01 --> Hooks Class Initialized
DEBUG - 2022-01-16 14:18:01 --> UTF-8 Support Enabled
INFO - 2022-01-16 14:18:01 --> Utf8 Class Initialized
INFO - 2022-01-16 14:18:01 --> URI Class Initialized
DEBUG - 2022-01-16 14:18:01 --> No URI present. Default controller set.
INFO - 2022-01-16 14:18:01 --> Router Class Initialized
INFO - 2022-01-16 14:18:01 --> Output Class Initialized
INFO - 2022-01-16 14:18:01 --> Security Class Initialized
DEBUG - 2022-01-16 14:18:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-16 14:18:01 --> Input Class Initialized
INFO - 2022-01-16 14:18:01 --> Language Class Initialized
INFO - 2022-01-16 14:18:01 --> Loader Class Initialized
INFO - 2022-01-16 14:18:01 --> Helper loaded: url_helper
INFO - 2022-01-16 14:18:01 --> Helper loaded: form_helper
INFO - 2022-01-16 14:18:01 --> Helper loaded: common_helper
INFO - 2022-01-16 14:18:01 --> Database Driver Class Initialized
DEBUG - 2022-01-16 14:18:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-16 14:18:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-16 14:18:01 --> Controller Class Initialized
INFO - 2022-01-16 14:18:01 --> Form Validation Class Initialized
DEBUG - 2022-01-16 14:18:01 --> Encrypt Class Initialized
DEBUG - 2022-01-16 14:18:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-16 14:18:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-16 14:18:01 --> Email Class Initialized
INFO - 2022-01-16 14:18:01 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-16 14:18:01 --> Calendar Class Initialized
INFO - 2022-01-16 14:18:01 --> Model "Login_model" initialized
INFO - 2022-01-16 14:18:01 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-16 14:18:01 --> Final output sent to browser
DEBUG - 2022-01-16 14:18:01 --> Total execution time: 0.0228
ERROR - 2022-01-16 14:18:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-16 14:18:01 --> Config Class Initialized
INFO - 2022-01-16 14:18:01 --> Hooks Class Initialized
DEBUG - 2022-01-16 14:18:01 --> UTF-8 Support Enabled
INFO - 2022-01-16 14:18:01 --> Utf8 Class Initialized
INFO - 2022-01-16 14:18:01 --> URI Class Initialized
INFO - 2022-01-16 14:18:01 --> Router Class Initialized
INFO - 2022-01-16 14:18:01 --> Output Class Initialized
INFO - 2022-01-16 14:18:01 --> Security Class Initialized
DEBUG - 2022-01-16 14:18:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-16 14:18:01 --> Input Class Initialized
INFO - 2022-01-16 14:18:01 --> Language Class Initialized
INFO - 2022-01-16 14:18:01 --> Loader Class Initialized
INFO - 2022-01-16 14:18:01 --> Helper loaded: url_helper
INFO - 2022-01-16 14:18:01 --> Helper loaded: form_helper
INFO - 2022-01-16 14:18:01 --> Helper loaded: common_helper
INFO - 2022-01-16 14:18:01 --> Database Driver Class Initialized
DEBUG - 2022-01-16 14:18:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-16 14:18:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-16 14:18:02 --> Controller Class Initialized
INFO - 2022-01-16 14:18:02 --> Form Validation Class Initialized
DEBUG - 2022-01-16 14:18:02 --> Encrypt Class Initialized
DEBUG - 2022-01-16 14:18:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-16 14:18:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-16 14:18:02 --> Email Class Initialized
INFO - 2022-01-16 14:18:02 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-16 14:18:02 --> Calendar Class Initialized
INFO - 2022-01-16 14:18:02 --> Model "Login_model" initialized
INFO - 2022-01-16 14:18:02 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-16 14:18:02 --> Final output sent to browser
DEBUG - 2022-01-16 14:18:02 --> Total execution time: 0.0237
ERROR - 2022-01-16 19:12:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-16 19:12:23 --> Config Class Initialized
INFO - 2022-01-16 19:12:23 --> Hooks Class Initialized
DEBUG - 2022-01-16 19:12:23 --> UTF-8 Support Enabled
INFO - 2022-01-16 19:12:23 --> Utf8 Class Initialized
INFO - 2022-01-16 19:12:23 --> URI Class Initialized
INFO - 2022-01-16 19:12:23 --> Router Class Initialized
INFO - 2022-01-16 19:12:23 --> Output Class Initialized
INFO - 2022-01-16 19:12:23 --> Security Class Initialized
DEBUG - 2022-01-16 19:12:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-16 19:12:23 --> Input Class Initialized
INFO - 2022-01-16 19:12:23 --> Language Class Initialized
ERROR - 2022-01-16 19:12:23 --> 404 Page Not Found: Humanstxt/index
ERROR - 2022-01-16 19:12:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-16 19:12:23 --> Config Class Initialized
INFO - 2022-01-16 19:12:23 --> Hooks Class Initialized
DEBUG - 2022-01-16 19:12:23 --> UTF-8 Support Enabled
INFO - 2022-01-16 19:12:23 --> Utf8 Class Initialized
INFO - 2022-01-16 19:12:23 --> URI Class Initialized
INFO - 2022-01-16 19:12:23 --> Router Class Initialized
INFO - 2022-01-16 19:12:23 --> Output Class Initialized
INFO - 2022-01-16 19:12:23 --> Security Class Initialized
DEBUG - 2022-01-16 19:12:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-16 19:12:23 --> Input Class Initialized
INFO - 2022-01-16 19:12:23 --> Language Class Initialized
ERROR - 2022-01-16 19:12:23 --> 404 Page Not Found: Adstxt/index
ERROR - 2022-01-16 19:12:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-16 19:12:24 --> Config Class Initialized
INFO - 2022-01-16 19:12:24 --> Hooks Class Initialized
DEBUG - 2022-01-16 19:12:24 --> UTF-8 Support Enabled
INFO - 2022-01-16 19:12:24 --> Utf8 Class Initialized
INFO - 2022-01-16 19:12:24 --> URI Class Initialized
DEBUG - 2022-01-16 19:12:24 --> No URI present. Default controller set.
INFO - 2022-01-16 19:12:24 --> Router Class Initialized
INFO - 2022-01-16 19:12:24 --> Output Class Initialized
INFO - 2022-01-16 19:12:24 --> Security Class Initialized
DEBUG - 2022-01-16 19:12:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-16 19:12:24 --> Input Class Initialized
INFO - 2022-01-16 19:12:24 --> Language Class Initialized
INFO - 2022-01-16 19:12:24 --> Loader Class Initialized
INFO - 2022-01-16 19:12:24 --> Helper loaded: url_helper
INFO - 2022-01-16 19:12:24 --> Helper loaded: form_helper
INFO - 2022-01-16 19:12:24 --> Helper loaded: common_helper
INFO - 2022-01-16 19:12:24 --> Database Driver Class Initialized
DEBUG - 2022-01-16 19:12:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-16 19:12:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-16 19:12:24 --> Controller Class Initialized
INFO - 2022-01-16 19:12:24 --> Form Validation Class Initialized
DEBUG - 2022-01-16 19:12:24 --> Encrypt Class Initialized
DEBUG - 2022-01-16 19:12:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-16 19:12:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-16 19:12:24 --> Email Class Initialized
INFO - 2022-01-16 19:12:24 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-16 19:12:24 --> Calendar Class Initialized
INFO - 2022-01-16 19:12:24 --> Model "Login_model" initialized
INFO - 2022-01-16 19:12:24 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-16 19:12:24 --> Final output sent to browser
DEBUG - 2022-01-16 19:12:24 --> Total execution time: 0.0341
ERROR - 2022-01-16 19:23:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-16 19:23:06 --> Config Class Initialized
INFO - 2022-01-16 19:23:06 --> Hooks Class Initialized
DEBUG - 2022-01-16 19:23:06 --> UTF-8 Support Enabled
INFO - 2022-01-16 19:23:06 --> Utf8 Class Initialized
INFO - 2022-01-16 19:23:06 --> URI Class Initialized
DEBUG - 2022-01-16 19:23:06 --> No URI present. Default controller set.
INFO - 2022-01-16 19:23:06 --> Router Class Initialized
INFO - 2022-01-16 19:23:06 --> Output Class Initialized
INFO - 2022-01-16 19:23:06 --> Security Class Initialized
DEBUG - 2022-01-16 19:23:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-16 19:23:06 --> Input Class Initialized
INFO - 2022-01-16 19:23:06 --> Language Class Initialized
INFO - 2022-01-16 19:23:06 --> Loader Class Initialized
INFO - 2022-01-16 19:23:06 --> Helper loaded: url_helper
INFO - 2022-01-16 19:23:06 --> Helper loaded: form_helper
INFO - 2022-01-16 19:23:06 --> Helper loaded: common_helper
INFO - 2022-01-16 19:23:06 --> Database Driver Class Initialized
DEBUG - 2022-01-16 19:23:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-16 19:23:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-16 19:23:06 --> Controller Class Initialized
INFO - 2022-01-16 19:23:06 --> Form Validation Class Initialized
DEBUG - 2022-01-16 19:23:06 --> Encrypt Class Initialized
DEBUG - 2022-01-16 19:23:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-16 19:23:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-16 19:23:06 --> Email Class Initialized
INFO - 2022-01-16 19:23:06 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-16 19:23:06 --> Calendar Class Initialized
INFO - 2022-01-16 19:23:06 --> Model "Login_model" initialized
INFO - 2022-01-16 19:23:06 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-16 19:23:06 --> Final output sent to browser
DEBUG - 2022-01-16 19:23:06 --> Total execution time: 0.0346
ERROR - 2022-01-16 21:15:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-16 21:15:09 --> Config Class Initialized
INFO - 2022-01-16 21:15:09 --> Hooks Class Initialized
DEBUG - 2022-01-16 21:15:09 --> UTF-8 Support Enabled
INFO - 2022-01-16 21:15:09 --> Utf8 Class Initialized
INFO - 2022-01-16 21:15:09 --> URI Class Initialized
DEBUG - 2022-01-16 21:15:09 --> No URI present. Default controller set.
INFO - 2022-01-16 21:15:09 --> Router Class Initialized
INFO - 2022-01-16 21:15:09 --> Output Class Initialized
INFO - 2022-01-16 21:15:09 --> Security Class Initialized
DEBUG - 2022-01-16 21:15:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-16 21:15:09 --> Input Class Initialized
INFO - 2022-01-16 21:15:09 --> Language Class Initialized
INFO - 2022-01-16 21:15:09 --> Loader Class Initialized
INFO - 2022-01-16 21:15:09 --> Helper loaded: url_helper
INFO - 2022-01-16 21:15:09 --> Helper loaded: form_helper
INFO - 2022-01-16 21:15:09 --> Helper loaded: common_helper
INFO - 2022-01-16 21:15:09 --> Database Driver Class Initialized
DEBUG - 2022-01-16 21:15:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-16 21:15:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-16 21:15:09 --> Controller Class Initialized
INFO - 2022-01-16 21:15:09 --> Form Validation Class Initialized
DEBUG - 2022-01-16 21:15:09 --> Encrypt Class Initialized
DEBUG - 2022-01-16 21:15:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-16 21:15:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-16 21:15:09 --> Email Class Initialized
INFO - 2022-01-16 21:15:09 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-16 21:15:09 --> Calendar Class Initialized
INFO - 2022-01-16 21:15:09 --> Model "Login_model" initialized
INFO - 2022-01-16 21:15:09 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-16 21:15:09 --> Final output sent to browser
DEBUG - 2022-01-16 21:15:09 --> Total execution time: 0.0526
ERROR - 2022-01-16 23:57:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-16 23:57:58 --> Config Class Initialized
INFO - 2022-01-16 23:57:58 --> Hooks Class Initialized
DEBUG - 2022-01-16 23:57:58 --> UTF-8 Support Enabled
INFO - 2022-01-16 23:57:58 --> Utf8 Class Initialized
INFO - 2022-01-16 23:57:58 --> URI Class Initialized
DEBUG - 2022-01-16 23:57:58 --> No URI present. Default controller set.
INFO - 2022-01-16 23:57:58 --> Router Class Initialized
INFO - 2022-01-16 23:57:58 --> Output Class Initialized
INFO - 2022-01-16 23:57:58 --> Security Class Initialized
DEBUG - 2022-01-16 23:57:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-16 23:57:58 --> Input Class Initialized
INFO - 2022-01-16 23:57:58 --> Language Class Initialized
INFO - 2022-01-16 23:57:58 --> Loader Class Initialized
INFO - 2022-01-16 23:57:58 --> Helper loaded: url_helper
INFO - 2022-01-16 23:57:58 --> Helper loaded: form_helper
INFO - 2022-01-16 23:57:58 --> Helper loaded: common_helper
INFO - 2022-01-16 23:57:58 --> Database Driver Class Initialized
DEBUG - 2022-01-16 23:57:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-16 23:57:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-16 23:57:58 --> Controller Class Initialized
INFO - 2022-01-16 23:57:58 --> Form Validation Class Initialized
DEBUG - 2022-01-16 23:57:58 --> Encrypt Class Initialized
DEBUG - 2022-01-16 23:57:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-16 23:57:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-16 23:57:58 --> Email Class Initialized
INFO - 2022-01-16 23:57:58 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-16 23:57:58 --> Calendar Class Initialized
INFO - 2022-01-16 23:57:58 --> Model "Login_model" initialized
INFO - 2022-01-16 23:57:58 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-16 23:57:58 --> Final output sent to browser
DEBUG - 2022-01-16 23:57:58 --> Total execution time: 0.0274
