<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-01-10 04:49:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-10 04:49:04 --> Config Class Initialized
INFO - 2022-01-10 04:49:04 --> Hooks Class Initialized
DEBUG - 2022-01-10 04:49:04 --> UTF-8 Support Enabled
INFO - 2022-01-10 04:49:04 --> Utf8 Class Initialized
INFO - 2022-01-10 04:49:04 --> URI Class Initialized
DEBUG - 2022-01-10 04:49:04 --> No URI present. Default controller set.
INFO - 2022-01-10 04:49:04 --> Router Class Initialized
INFO - 2022-01-10 04:49:04 --> Output Class Initialized
INFO - 2022-01-10 04:49:04 --> Security Class Initialized
DEBUG - 2022-01-10 04:49:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-10 04:49:04 --> Input Class Initialized
INFO - 2022-01-10 04:49:04 --> Language Class Initialized
INFO - 2022-01-10 04:49:04 --> Loader Class Initialized
INFO - 2022-01-10 04:49:04 --> Helper loaded: url_helper
INFO - 2022-01-10 04:49:04 --> Helper loaded: form_helper
INFO - 2022-01-10 04:49:04 --> Helper loaded: common_helper
INFO - 2022-01-10 04:49:04 --> Database Driver Class Initialized
DEBUG - 2022-01-10 04:49:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-10 04:49:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-10 04:49:04 --> Controller Class Initialized
INFO - 2022-01-10 04:49:04 --> Form Validation Class Initialized
DEBUG - 2022-01-10 04:49:04 --> Encrypt Class Initialized
DEBUG - 2022-01-10 04:49:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 04:49:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-10 04:49:04 --> Email Class Initialized
INFO - 2022-01-10 04:49:04 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-10 04:49:04 --> Calendar Class Initialized
INFO - 2022-01-10 04:49:04 --> Model "Login_model" initialized
INFO - 2022-01-10 04:49:04 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-10 04:49:04 --> Final output sent to browser
DEBUG - 2022-01-10 04:49:04 --> Total execution time: 0.0212
ERROR - 2022-01-10 04:50:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-10 04:50:39 --> Config Class Initialized
INFO - 2022-01-10 04:50:39 --> Hooks Class Initialized
DEBUG - 2022-01-10 04:50:39 --> UTF-8 Support Enabled
INFO - 2022-01-10 04:50:39 --> Utf8 Class Initialized
INFO - 2022-01-10 04:50:39 --> URI Class Initialized
DEBUG - 2022-01-10 04:50:39 --> No URI present. Default controller set.
INFO - 2022-01-10 04:50:39 --> Router Class Initialized
INFO - 2022-01-10 04:50:39 --> Output Class Initialized
INFO - 2022-01-10 04:50:39 --> Security Class Initialized
DEBUG - 2022-01-10 04:50:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-10 04:50:39 --> Input Class Initialized
INFO - 2022-01-10 04:50:39 --> Language Class Initialized
INFO - 2022-01-10 04:50:39 --> Loader Class Initialized
INFO - 2022-01-10 04:50:39 --> Helper loaded: url_helper
INFO - 2022-01-10 04:50:39 --> Helper loaded: form_helper
INFO - 2022-01-10 04:50:39 --> Helper loaded: common_helper
INFO - 2022-01-10 04:50:39 --> Database Driver Class Initialized
DEBUG - 2022-01-10 04:50:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-10 04:50:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-10 04:50:39 --> Controller Class Initialized
INFO - 2022-01-10 04:50:39 --> Form Validation Class Initialized
DEBUG - 2022-01-10 04:50:39 --> Encrypt Class Initialized
DEBUG - 2022-01-10 04:50:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 04:50:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-10 04:50:39 --> Email Class Initialized
INFO - 2022-01-10 04:50:39 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-10 04:50:39 --> Calendar Class Initialized
INFO - 2022-01-10 04:50:39 --> Model "Login_model" initialized
INFO - 2022-01-10 04:50:39 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-10 04:50:39 --> Final output sent to browser
DEBUG - 2022-01-10 04:50:39 --> Total execution time: 0.0226
ERROR - 2022-01-10 09:33:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-10 09:33:29 --> Config Class Initialized
INFO - 2022-01-10 09:33:29 --> Hooks Class Initialized
DEBUG - 2022-01-10 09:33:29 --> UTF-8 Support Enabled
INFO - 2022-01-10 09:33:29 --> Utf8 Class Initialized
INFO - 2022-01-10 09:33:29 --> URI Class Initialized
INFO - 2022-01-10 09:33:29 --> Router Class Initialized
INFO - 2022-01-10 09:33:29 --> Output Class Initialized
INFO - 2022-01-10 09:33:29 --> Security Class Initialized
DEBUG - 2022-01-10 09:33:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-10 09:33:29 --> Input Class Initialized
INFO - 2022-01-10 09:33:29 --> Language Class Initialized
ERROR - 2022-01-10 09:33:29 --> 404 Page Not Found: Humanstxt/index
ERROR - 2022-01-10 09:33:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-10 09:33:30 --> Config Class Initialized
INFO - 2022-01-10 09:33:30 --> Hooks Class Initialized
DEBUG - 2022-01-10 09:33:30 --> UTF-8 Support Enabled
INFO - 2022-01-10 09:33:30 --> Utf8 Class Initialized
INFO - 2022-01-10 09:33:30 --> URI Class Initialized
INFO - 2022-01-10 09:33:30 --> Router Class Initialized
INFO - 2022-01-10 09:33:30 --> Output Class Initialized
INFO - 2022-01-10 09:33:30 --> Security Class Initialized
DEBUG - 2022-01-10 09:33:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-10 09:33:30 --> Input Class Initialized
INFO - 2022-01-10 09:33:30 --> Language Class Initialized
ERROR - 2022-01-10 09:33:30 --> 404 Page Not Found: Adstxt/index
ERROR - 2022-01-10 09:33:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-10 09:33:31 --> Config Class Initialized
INFO - 2022-01-10 09:33:31 --> Hooks Class Initialized
DEBUG - 2022-01-10 09:33:31 --> UTF-8 Support Enabled
INFO - 2022-01-10 09:33:31 --> Utf8 Class Initialized
INFO - 2022-01-10 09:33:31 --> URI Class Initialized
DEBUG - 2022-01-10 09:33:31 --> No URI present. Default controller set.
INFO - 2022-01-10 09:33:31 --> Router Class Initialized
INFO - 2022-01-10 09:33:31 --> Output Class Initialized
INFO - 2022-01-10 09:33:31 --> Security Class Initialized
DEBUG - 2022-01-10 09:33:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-10 09:33:31 --> Input Class Initialized
INFO - 2022-01-10 09:33:31 --> Language Class Initialized
INFO - 2022-01-10 09:33:31 --> Loader Class Initialized
INFO - 2022-01-10 09:33:31 --> Helper loaded: url_helper
INFO - 2022-01-10 09:33:31 --> Helper loaded: form_helper
INFO - 2022-01-10 09:33:31 --> Helper loaded: common_helper
INFO - 2022-01-10 09:33:31 --> Database Driver Class Initialized
DEBUG - 2022-01-10 09:33:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-10 09:33:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-10 09:33:31 --> Controller Class Initialized
INFO - 2022-01-10 09:33:31 --> Form Validation Class Initialized
DEBUG - 2022-01-10 09:33:31 --> Encrypt Class Initialized
DEBUG - 2022-01-10 09:33:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 09:33:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-10 09:33:31 --> Email Class Initialized
INFO - 2022-01-10 09:33:31 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-10 09:33:31 --> Calendar Class Initialized
INFO - 2022-01-10 09:33:31 --> Model "Login_model" initialized
INFO - 2022-01-10 09:33:31 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-10 09:33:31 --> Final output sent to browser
DEBUG - 2022-01-10 09:33:31 --> Total execution time: 0.0242
ERROR - 2022-01-10 12:12:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-10 12:12:32 --> Config Class Initialized
INFO - 2022-01-10 12:12:32 --> Hooks Class Initialized
DEBUG - 2022-01-10 12:12:32 --> UTF-8 Support Enabled
INFO - 2022-01-10 12:12:32 --> Utf8 Class Initialized
INFO - 2022-01-10 12:12:32 --> URI Class Initialized
DEBUG - 2022-01-10 12:12:32 --> No URI present. Default controller set.
INFO - 2022-01-10 12:12:32 --> Router Class Initialized
INFO - 2022-01-10 12:12:32 --> Output Class Initialized
INFO - 2022-01-10 12:12:32 --> Security Class Initialized
DEBUG - 2022-01-10 12:12:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-10 12:12:32 --> Input Class Initialized
INFO - 2022-01-10 12:12:32 --> Language Class Initialized
INFO - 2022-01-10 12:12:32 --> Loader Class Initialized
INFO - 2022-01-10 12:12:32 --> Helper loaded: url_helper
INFO - 2022-01-10 12:12:32 --> Helper loaded: form_helper
INFO - 2022-01-10 12:12:32 --> Helper loaded: common_helper
INFO - 2022-01-10 12:12:32 --> Database Driver Class Initialized
DEBUG - 2022-01-10 12:12:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-10 12:12:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-10 12:12:32 --> Controller Class Initialized
INFO - 2022-01-10 12:12:32 --> Form Validation Class Initialized
DEBUG - 2022-01-10 12:12:32 --> Encrypt Class Initialized
DEBUG - 2022-01-10 12:12:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 12:12:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-10 12:12:32 --> Email Class Initialized
INFO - 2022-01-10 12:12:32 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-10 12:12:32 --> Calendar Class Initialized
INFO - 2022-01-10 12:12:32 --> Model "Login_model" initialized
INFO - 2022-01-10 12:12:32 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-10 12:12:32 --> Final output sent to browser
DEBUG - 2022-01-10 12:12:32 --> Total execution time: 0.0247
ERROR - 2022-01-10 14:18:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-10 14:18:16 --> Config Class Initialized
INFO - 2022-01-10 14:18:16 --> Hooks Class Initialized
DEBUG - 2022-01-10 14:18:16 --> UTF-8 Support Enabled
INFO - 2022-01-10 14:18:16 --> Utf8 Class Initialized
INFO - 2022-01-10 14:18:16 --> URI Class Initialized
DEBUG - 2022-01-10 14:18:16 --> No URI present. Default controller set.
INFO - 2022-01-10 14:18:16 --> Router Class Initialized
INFO - 2022-01-10 14:18:16 --> Output Class Initialized
INFO - 2022-01-10 14:18:16 --> Security Class Initialized
DEBUG - 2022-01-10 14:18:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-10 14:18:16 --> Input Class Initialized
INFO - 2022-01-10 14:18:16 --> Language Class Initialized
INFO - 2022-01-10 14:18:16 --> Loader Class Initialized
INFO - 2022-01-10 14:18:16 --> Helper loaded: url_helper
INFO - 2022-01-10 14:18:16 --> Helper loaded: form_helper
INFO - 2022-01-10 14:18:16 --> Helper loaded: common_helper
INFO - 2022-01-10 14:18:16 --> Database Driver Class Initialized
DEBUG - 2022-01-10 14:18:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-10 14:18:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-10 14:18:16 --> Controller Class Initialized
INFO - 2022-01-10 14:18:16 --> Form Validation Class Initialized
DEBUG - 2022-01-10 14:18:16 --> Encrypt Class Initialized
DEBUG - 2022-01-10 14:18:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 14:18:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-10 14:18:16 --> Email Class Initialized
INFO - 2022-01-10 14:18:16 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-10 14:18:16 --> Calendar Class Initialized
INFO - 2022-01-10 14:18:16 --> Model "Login_model" initialized
INFO - 2022-01-10 14:18:16 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-10 14:18:16 --> Final output sent to browser
DEBUG - 2022-01-10 14:18:16 --> Total execution time: 0.0233
ERROR - 2022-01-10 14:18:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-10 14:18:18 --> Config Class Initialized
INFO - 2022-01-10 14:18:18 --> Hooks Class Initialized
DEBUG - 2022-01-10 14:18:18 --> UTF-8 Support Enabled
INFO - 2022-01-10 14:18:18 --> Utf8 Class Initialized
INFO - 2022-01-10 14:18:18 --> URI Class Initialized
INFO - 2022-01-10 14:18:18 --> Router Class Initialized
INFO - 2022-01-10 14:18:18 --> Output Class Initialized
INFO - 2022-01-10 14:18:18 --> Security Class Initialized
DEBUG - 2022-01-10 14:18:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-10 14:18:18 --> Input Class Initialized
INFO - 2022-01-10 14:18:18 --> Language Class Initialized
ERROR - 2022-01-10 14:18:18 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2022-01-10 14:18:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-10 14:18:31 --> Config Class Initialized
INFO - 2022-01-10 14:18:31 --> Hooks Class Initialized
DEBUG - 2022-01-10 14:18:31 --> UTF-8 Support Enabled
INFO - 2022-01-10 14:18:31 --> Utf8 Class Initialized
INFO - 2022-01-10 14:18:31 --> URI Class Initialized
INFO - 2022-01-10 14:18:31 --> Router Class Initialized
INFO - 2022-01-10 14:18:31 --> Output Class Initialized
INFO - 2022-01-10 14:18:31 --> Security Class Initialized
DEBUG - 2022-01-10 14:18:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-10 14:18:31 --> Input Class Initialized
INFO - 2022-01-10 14:18:31 --> Language Class Initialized
INFO - 2022-01-10 14:18:31 --> Loader Class Initialized
INFO - 2022-01-10 14:18:31 --> Helper loaded: url_helper
INFO - 2022-01-10 14:18:31 --> Helper loaded: form_helper
INFO - 2022-01-10 14:18:31 --> Helper loaded: common_helper
INFO - 2022-01-10 14:18:31 --> Database Driver Class Initialized
DEBUG - 2022-01-10 14:18:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-10 14:18:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-10 14:18:31 --> Controller Class Initialized
INFO - 2022-01-10 14:18:31 --> Form Validation Class Initialized
DEBUG - 2022-01-10 14:18:31 --> Encrypt Class Initialized
DEBUG - 2022-01-10 14:18:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 14:18:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-10 14:18:31 --> Email Class Initialized
INFO - 2022-01-10 14:18:31 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-10 14:18:31 --> Calendar Class Initialized
INFO - 2022-01-10 14:18:31 --> Model "Login_model" initialized
INFO - 2022-01-10 14:18:31 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-10 14:18:31 --> Final output sent to browser
DEBUG - 2022-01-10 14:18:31 --> Total execution time: 0.0345
ERROR - 2022-01-10 14:18:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-10 14:18:31 --> Config Class Initialized
INFO - 2022-01-10 14:18:31 --> Hooks Class Initialized
DEBUG - 2022-01-10 14:18:31 --> UTF-8 Support Enabled
INFO - 2022-01-10 14:18:31 --> Utf8 Class Initialized
INFO - 2022-01-10 14:18:31 --> URI Class Initialized
DEBUG - 2022-01-10 14:18:31 --> No URI present. Default controller set.
INFO - 2022-01-10 14:18:31 --> Router Class Initialized
INFO - 2022-01-10 14:18:31 --> Output Class Initialized
INFO - 2022-01-10 14:18:31 --> Security Class Initialized
DEBUG - 2022-01-10 14:18:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-10 14:18:31 --> Input Class Initialized
INFO - 2022-01-10 14:18:31 --> Language Class Initialized
INFO - 2022-01-10 14:18:31 --> Loader Class Initialized
INFO - 2022-01-10 14:18:31 --> Helper loaded: url_helper
INFO - 2022-01-10 14:18:31 --> Helper loaded: form_helper
INFO - 2022-01-10 14:18:31 --> Helper loaded: common_helper
INFO - 2022-01-10 14:18:31 --> Database Driver Class Initialized
DEBUG - 2022-01-10 14:18:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-10 14:18:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-10 14:18:31 --> Controller Class Initialized
INFO - 2022-01-10 14:18:31 --> Form Validation Class Initialized
DEBUG - 2022-01-10 14:18:31 --> Encrypt Class Initialized
DEBUG - 2022-01-10 14:18:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 14:18:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-10 14:18:31 --> Email Class Initialized
INFO - 2022-01-10 14:18:31 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-10 14:18:31 --> Calendar Class Initialized
INFO - 2022-01-10 14:18:31 --> Model "Login_model" initialized
INFO - 2022-01-10 14:18:31 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-10 14:18:31 --> Final output sent to browser
DEBUG - 2022-01-10 14:18:31 --> Total execution time: 0.0382
ERROR - 2022-01-10 14:18:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-10 14:18:32 --> Config Class Initialized
INFO - 2022-01-10 14:18:32 --> Hooks Class Initialized
DEBUG - 2022-01-10 14:18:32 --> UTF-8 Support Enabled
INFO - 2022-01-10 14:18:32 --> Utf8 Class Initialized
INFO - 2022-01-10 14:18:32 --> URI Class Initialized
INFO - 2022-01-10 14:18:32 --> Router Class Initialized
INFO - 2022-01-10 14:18:32 --> Output Class Initialized
INFO - 2022-01-10 14:18:32 --> Security Class Initialized
DEBUG - 2022-01-10 14:18:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-10 14:18:32 --> Input Class Initialized
INFO - 2022-01-10 14:18:32 --> Language Class Initialized
INFO - 2022-01-10 14:18:32 --> Loader Class Initialized
INFO - 2022-01-10 14:18:32 --> Helper loaded: url_helper
INFO - 2022-01-10 14:18:32 --> Helper loaded: form_helper
INFO - 2022-01-10 14:18:32 --> Helper loaded: common_helper
INFO - 2022-01-10 14:18:32 --> Database Driver Class Initialized
DEBUG - 2022-01-10 14:18:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-10 14:18:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-10 14:18:32 --> Controller Class Initialized
INFO - 2022-01-10 14:18:32 --> Form Validation Class Initialized
DEBUG - 2022-01-10 14:18:32 --> Encrypt Class Initialized
DEBUG - 2022-01-10 14:18:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 14:18:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-10 14:18:32 --> Email Class Initialized
INFO - 2022-01-10 14:18:32 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-10 14:18:32 --> Calendar Class Initialized
INFO - 2022-01-10 14:18:32 --> Model "Login_model" initialized
ERROR - 2022-01-10 14:18:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-10 14:18:32 --> Config Class Initialized
INFO - 2022-01-10 14:18:32 --> Hooks Class Initialized
DEBUG - 2022-01-10 14:18:32 --> UTF-8 Support Enabled
INFO - 2022-01-10 14:18:32 --> Utf8 Class Initialized
INFO - 2022-01-10 14:18:32 --> URI Class Initialized
INFO - 2022-01-10 14:18:32 --> Router Class Initialized
INFO - 2022-01-10 14:18:32 --> Output Class Initialized
INFO - 2022-01-10 14:18:32 --> Security Class Initialized
DEBUG - 2022-01-10 14:18:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-10 14:18:32 --> Input Class Initialized
INFO - 2022-01-10 14:18:32 --> Language Class Initialized
INFO - 2022-01-10 14:18:32 --> Loader Class Initialized
INFO - 2022-01-10 14:18:32 --> Helper loaded: url_helper
INFO - 2022-01-10 14:18:32 --> Helper loaded: form_helper
INFO - 2022-01-10 14:18:32 --> Helper loaded: common_helper
INFO - 2022-01-10 14:18:32 --> Database Driver Class Initialized
DEBUG - 2022-01-10 14:18:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-10 14:18:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-10 14:18:32 --> Controller Class Initialized
INFO - 2022-01-10 14:18:32 --> Form Validation Class Initialized
DEBUG - 2022-01-10 14:18:32 --> Encrypt Class Initialized
DEBUG - 2022-01-10 14:18:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 14:18:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-10 14:18:32 --> Email Class Initialized
INFO - 2022-01-10 14:18:32 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-10 14:18:32 --> Calendar Class Initialized
INFO - 2022-01-10 14:18:32 --> Model "Login_model" initialized
ERROR - 2022-01-10 15:46:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-10 15:46:26 --> Config Class Initialized
INFO - 2022-01-10 15:46:26 --> Hooks Class Initialized
DEBUG - 2022-01-10 15:46:26 --> UTF-8 Support Enabled
INFO - 2022-01-10 15:46:26 --> Utf8 Class Initialized
INFO - 2022-01-10 15:46:26 --> URI Class Initialized
DEBUG - 2022-01-10 15:46:26 --> No URI present. Default controller set.
INFO - 2022-01-10 15:46:26 --> Router Class Initialized
INFO - 2022-01-10 15:46:26 --> Output Class Initialized
INFO - 2022-01-10 15:46:26 --> Security Class Initialized
DEBUG - 2022-01-10 15:46:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-10 15:46:26 --> Input Class Initialized
INFO - 2022-01-10 15:46:26 --> Language Class Initialized
INFO - 2022-01-10 15:46:26 --> Loader Class Initialized
INFO - 2022-01-10 15:46:26 --> Helper loaded: url_helper
INFO - 2022-01-10 15:46:26 --> Helper loaded: form_helper
INFO - 2022-01-10 15:46:26 --> Helper loaded: common_helper
INFO - 2022-01-10 15:46:26 --> Database Driver Class Initialized
DEBUG - 2022-01-10 15:46:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-10 15:46:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-10 15:46:26 --> Controller Class Initialized
INFO - 2022-01-10 15:46:26 --> Form Validation Class Initialized
DEBUG - 2022-01-10 15:46:26 --> Encrypt Class Initialized
DEBUG - 2022-01-10 15:46:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-10 15:46:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-10 15:46:26 --> Email Class Initialized
INFO - 2022-01-10 15:46:26 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-10 15:46:26 --> Calendar Class Initialized
INFO - 2022-01-10 15:46:26 --> Model "Login_model" initialized
INFO - 2022-01-10 15:46:26 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-10 15:46:26 --> Final output sent to browser
DEBUG - 2022-01-10 15:46:26 --> Total execution time: 0.0973
