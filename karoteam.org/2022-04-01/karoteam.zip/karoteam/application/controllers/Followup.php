<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Followup extends CI_Controller {

    public function __construct() {
        parent::__construct();
        if (!$this->session->userdata('UsertId')) {
            redirect('login');
        }
        $this->load->library('form_validation');
        $this->load->model('case_model', 'cm');
    }
    public function index() {
        $post = $this->input->post();
        if ($post['save']) {
            
            $patient_details = $this->cm->getOpenCaseDetails($params);
            $follow_up = $this->cm->getNextFollowupDate(0, $post['from_date'], $post['to_date'], $post['department']);

            if ($follow_up) {
                foreach ($follow_up as $key => $value) {
                    foreach ($patient_details as $k => $v) {
                        if ($value['case_id'] == $v['id']) {
                            $follow_up[$key] = $v;
                            $follow_up[$key]['follow_up_done'] = $value['folowup_done'] == 1 ? 'YES' : 'NO';
                            $follow_up[$key]['next_followup_date'] = $value['next_followup_date'];
                            $follow_up[$key]['remark'] = $value['remark'];
                            break;
                        }
                    }
                }
            }
            $data['from_date'] = $post['from_date'];
            $data['to_date'] = $post['to_date'];
        }
        $data['result'] = $follow_up;
        
        $this->load->model('hospital_model', 'hm');
        $data['active_department'] = $this->hm->getActiveDept();

        $this->load->view('header');
        $this->load->view('transaction/upcomingFollowup', $data);
        $this->load->view('footer');
    }

}
