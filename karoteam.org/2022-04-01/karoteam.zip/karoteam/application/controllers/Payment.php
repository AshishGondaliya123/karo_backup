<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Payment extends CI_Controller {

    public function __construct() {
        parent::__construct();
        if (!$this->session->userdata('UsertId')) {
            redirect('login');
        } 
        // else if (empty($this->session->userdata('IsAdmin'))) {
        //     redirect('dashboard');
        // }
        $this->load->library('form_validation');
        $this->load->library('encrypt');
        $this->load->model('payment_model');
    }

    function index() {
        /* Check submit button */
        if ($this->input->post('save')) {
            $payment_name = trim($this->input->post('PaymentMode'));
            if ($payment_name != '') {
                $save = $this->payment_model->savepayment($payment_name);
                $this->session->set_flashdata('message', $save);
            } else {
                $this->session->set_flashdata('message', '<div class="alert alert-danger">Please enter payment name</div>');
            }
        }
        $getpayment = $this->payment_model->getpayment();
        $getpaymentData['payment'] = $getpayment;
        $this->load->view('header');
        $this->load->view('payment/index', $getpaymentData);
        $this->load->view('footer');
    }

    function changestatus() {
        if ($_REQUEST['id'] != '') {
            $id = base64_decode($_REQUEST['id']);
            if ($_REQUEST['status'] == 1) {
                $status = 0;
            } else {
                $status = 1;
            }
            $save = $this->payment_model->changeStatus($id, $status);
            $this->session->set_flashdata('message', $save);
            redirect('payment');
        }
    }

    function changepaymentName() {
        if ($this->input->post('save')) {
            $payment_name = ltrim($this->input->post('PaymentMode'));
            $payment_id = base64_decode($this->input->post('payment_id'));
            if ($payment_name != '' && $payment_id != '') {
                $save = $this->payment_model->changepaymentName($payment_name, $payment_id);
                $this->session->set_flashdata('message', $save);
            }
            redirect('payment');
        }
    }

}

?>
