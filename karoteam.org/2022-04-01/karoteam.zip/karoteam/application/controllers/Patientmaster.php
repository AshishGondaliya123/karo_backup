<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Patientmaster extends CI_Controller {

    public function __construct() {
        parent::__construct();
        if (!$this->session->userdata('UsertId')) {
            redirect('login');
        }
        $this->load->library('form_validation');
        $this->load->library('encrypt');
        $this->load->model('patient_model');
        $this->load->model('patientcase_model');
        $this->load->model('referredby_model');
        $this->load->model('prefix_master');
        $this->load->model('hospital_model', 'hm');
    }

    function index() {
        $patientId = $nextCaseId = $nextPatientId = "";
        if (!empty($this->input->get("uid"))) {
            $patientId = $this->input->get("uid");
            $patient = $this->patient_model->getPatient($patientId,'','','','');
            $getDisease = $this->patient_model->getDisease($patient[0]["patient_id"]);
            $data["disease_diagnosed"] = $getDisease[0]->disease_diagnosed;

            if ($this->session->userdata("IsAdmin") != 1) {
                if ($patient[0]["created_by"] != $this->session->userdata('UsertId')) {
                    redirect("patientmaster/viewpatient");
                }
            }

            $patientFamily = $this->patient_model->getPatientFamily($patientId);
            $temp_state = $patient[0]["pt_state"];
            $prem_state = $patient[0]["pp_state"];
            $temp_cities = $this->referredby_model->getcities($temp_state);
            $perm_cities = $this->referredby_model->getcities($prem_state);
        } else {
            $nextCaseId = $this->prefix_master->getNextId('Case');
            $nextPatientId = $this->prefix_master->getNextId('Patient');
        }

        //$getreferedby = $this->referredby_model->getreferedby();
        // $getreferedby = $this->hm->getActiveRecord('referedby', 'IsActive', 'ReferedByName' ,'asc');
        $getState = $this->referredby_model->getstates();

        // $data['referedby'] = $getreferedby;
        $data['states'] = $getState;
        $data['case_id'] = $nextCaseId;
        $data['patient_id'] = $nextPatientId;
        $data['patient'] = isset($patient) ? $patient[0] : null;

        $data['ppcities'] = isset($patient) ? $perm_cities : null;
        $data['ptcities'] = isset($patient) ? $temp_cities : null;
        $data['pfamily_data'] = isset($patientFamily) ? $patientFamily : null;
        $select = "UserId , CONCAT(FirstName, ' ', MiddleName,' ',LastName,' ') as full_name ";
        $data['active_user'] = $this->hm->getActiveRecords('usermaster', 'IsActive','UserType', 'FirstName', 'asc', $select);
		$data['all_user'] = $this->hm->getActive();
        // prx($data);
        $this->load->view('header');
        $this->load->view('patient/index', $data);
        $this->load->view('footer');
    }

    function viewpatient() {

        $post = $this->input->post();
        $department = isset($post['department'])?$post['department']:'';
        $hospital = isset($post['hospital'])?$post['hospital']:'';
        $representative_name = isset($post['representative_name'])?$post['representative_name']:'';
        $status = isset($post['status'])?$post['status']:'';
        
        $data['patient'] = $this->patient_model->getPatient(0,$department,$hospital,$representative_name,$status);
        if ($post['save']) {
            
            if ($data['patient']) {
                $this->session->set_flashdata('msg', '<div class="alert alert-success"> View patient list fetch successfully</div>');
            } else {
                $this->session->set_flashdata('msg', '<div class="alert alert-danger"> Record not found </div>');
            }
        }

        $data['active_department'] = $this->hm->getActiveDept();
        $data['active_hospital'] = $this->hm->getactivehospital();
        $select = "UserId , CONCAT(FirstName, ' ', MiddleName,' ',LastName,' ') as full_name ";
        $data['active_user'] = $this->hm->getActiveRecords('usermaster', 'IsActive','UserType', 'FirstName', 'asc', $select);

        $this->load->view('header');
        $this->load->view('patient/patientview', $data);
        $this->load->view('footer');
    }
	
	function viewMobileList(){
		 $phone= $this->input->post('phone_number');
		// prx($phone);
		 $phone_id=$this->input->post('phone_id');
		// prx($phone_id);
        $getData = $this->patient_model->getPhoneList($phone,$phone_id);
	
        $html = "";

      //  if (!$getData) {
      //      echo "<p style='text-align:center;'>No data found</p>";
      //  } else {
            echo "<table border='1' width='400' cellpadding='10' cellspacing='20'>";
            echo "<tr>";
            echo "<th>Patient Name</th>";
            echo "<th>Mobile no.</th>";         
            echo "<tr>";
            foreach ($getData as $result) {
            echo "<tr>";
                echo "<td>" . $result->patient_name .  "</td>";
				
			if($phone==$result->patient_phone){
                echo "<td>" . $result->patient_phone . "</td>";
				
			}else if($phone==$result->caregiver_phone){
				echo "<td>" . $result->caregiver_phone . "</td>";
				
			}else if($phone==$result->caregiver_phone2){
				echo "<td>" . $result->caregiver_phone2 . "</td>";
			}
                echo "<tr>";
            }
            echo "</table>";

            echo $html;
        //}
		
	}
	

    function getcities($state) {
        $getcities = $this->referredby_model->getcities($state);
        return $getcities;
    }

    function save() {
      // print_r($this->input->get("uid")); exit;
	  $value=$this->input->get('patient_phone');
        $patient_id = 0;
        if (!empty($this->input->get("uid"))) {
            $patient_id = $this->input->get("uid");
        }

        $data = $this->input->post();

        //check if the case no record already exists
        $patient_karo_case_no = $data["patient_karo_case_no"];
        $checkCaseNo = $this->patient_model->checkCaseNoExists($patient_karo_case_no);

        if (!empty($patient_karo_case_no)) {
            if (count($checkCaseNo) != 0) {
                $this->session->set_flashdata('msg', 'Patient Karo case no. already exists');
                redirect('patientmaster/index/');
            }
        }
		
		//check if the phone no already exists
        // $patient_phone_no = $data["patient_phone"];
	
        // $checkPhoneNo = $this->patient_model->checkPhoneNoExists($patient_phone_no);

        // if (!empty($patient_phone_no)) {
            // if (count($checkPhoneNo) != 0) {
                // $this->session->set_flashdata('msg', 'Patient phone no. already exists');
               // redirect('patientmaster/index/');
            // }
        // }
		

        unset($data['assiged_user']);
        unset($data['age_year']);
        unset($data['age_month']);
        unset($data['age_day']);
        // prx($data);
        $fvalue = array('relative_name', 'relation', 'relative_age', 'occupation', 'salary', 'duration', 'income_details', 'frows', 'family_id');

        $patientData = array();
        $familyData = array();

        foreach ($data as $key => $value) {
            if (!in_array($key, $fvalue)) {
                $patientData[$key] = $value;
            } else {
                $familyData[$key] = $value;
            }
        }

        if (empty($this->input->get("uid"))) {
            $patientData["patient_case"] = $this->prefix_master->getNextId('Case');
            $patientData["patient_id"] = $this->prefix_master->getNextId('Patient');
        }

        $patientData["patient_language"] = implode(",", $patientData["patient_language"]);
        $this->db->trans_start();
        $patientData['check_add'] = $data['check_add'] ? "on" : "off";

        // if($patientData['other_refered_by'])
        //     $patientData['refered_by'] = $patientData['other_refered_by'];
        // unset($patientData['other_refered_by']);
        $patient_dob = explode('/', $patientData['patient_dob']);
        $patientData['patient_dob'] = $patient_dob[2] . '-' . $patient_dob[1] . '-' . $patient_dob[0];


        $patient_id = $this->patient_model->savePatient($patientData, $patient_id);

        $familyData["patient_id"] = $patient_id;
        $familyDataFinal = array();
        $familyDataCount = count($familyData['relative_name']); // count(explode(",", $familyData['frows']));

        for ($i = 0; $i < $familyDataCount; $i++) {
            if (!empty($familyData["family_id"][$i])) {
                $familyDataFinalUpdate = array("patient_id" => $patient_id, "relative_name" => $familyData["relative_name"][$i], "relation" => $familyData["relation"][$i], "relative_age" => $familyData["relative_age"][$i], "occupation" => $familyData["occupation"][$i], "salary" => $familyData["salary"][$i], "income_details" => $familyData['income_details'][$i], "duration" => $familyData['duration'][$i]);
                $this->db->where('id', $familyData["family_id"][$i]);
                $str1 = $this->db->update('patient_family_details', $familyDataFinalUpdate);
            } else {
                array_push($familyDataFinal, array("patient_id" => $patient_id, "relative_name" => $familyData["relative_name"][$i], "relation" => $familyData["relation"][$i], "relative_age" => $familyData["relative_age"][$i], "occupation" => $familyData["occupation"][$i], "salary" => $familyData["salary"][$i], "income_details" => $familyData['income_details'][$i], "duration" => $familyData['duration'][$i]));
            }
        }

        if (!empty($data['frows'])) {
            $str2 = $this->db->insert_batch('patient_family_details', $familyDataFinal);
        }

        $this->db->trans_complete();

        $patient_case = $this->patientcase_model->getPatientCaseByCaseNumber($patientData['patient_case']);

        $patient_caseId = "";
        foreach ($patient_case as $case) {
            $patient_caseId = $case['id'];
        }
        $this->session->set_flashdata('msg', 'Saved successfully');
        redirect('patientmaster/index/?uid=' . $patient_id . '&cid=' . $patient_caseId);
    }

    function updateimage() {
        if (!empty($_FILES)) {
            $config['upload_path'] = "./karoclient/images/uploads/";
            $config['allowed_types'] = 'jpg|png|gif|jpeg|bmp|JPG|PNG|GIF|JPEG|BMP';
            $config['max_size'] = '2048';
            //$config['max_width'] = '200';
            //$config['max_height'] = '200';
            $this->load->library('upload', $config);
            if (!$this->upload->do_upload('image')) {
                echo $this->upload->display_errors();
            } else {
                $data = $this->upload->data();
                echo '<img src="' . base_url() . 'karoclient/images/uploads/' . $data['file_name'] . '" /><input type="hidden" name="patient_image" value="karoclient/images/uploads/' . $data['file_name'] . '">';
            }
        }
    }

    function deletepatientfamily() {
        if (!empty($this->input->get("fid"))) {
            $family_id = $this->input->get("fid");
            $this->db->delete('patient_family_details', array('id' => $family_id));
        }
    }

    function assignedDiffUser() {

        $post = $this->input->get();
        // $session = $this->session->userdata();
        $select_data['table'] = "patient_case_details";
        $select_data['select'] = "id, patient_id,created_by";
        $select_data['where'] = "case_number='" . $post['patient_case'] . "'";
        $patient_details = $this->patient_model->getTableData($select_data);
        // prx($patient_details);
        if ($patient_details) {
            $patient_details = $patient_details[0];
            $insert_data['patient_id'] = $patient_details->patient_id;
            $insert_data['assigned_from'] = $patient_details->created_by;
            $insert_data['assigned_to'] = $post['Assigned_UserId'];
            $this->patient_model->insertDataIntoTable('patient_assignee_history', $insert_data);

            $update_data['created_by'] = $post['Assigned_UserId'];
            $where_data = 'patient_id="' . $patient_details->patient_id . '"';

            $this->patient_model->updateDataIntoTable('patient_master', $update_data, $where_data);
            $this->patient_model->updateDataIntoTable('patient_case_details', $update_data, $where_data);
            echo 'success';
            exit;
        } else
            echo "fail";exit;
    }

    function assignedpatientToDiffUser(){
        $post = $this->input->get();
        $update_data['representative_name'] = $post['UserId'];
        $where_data = 'id="' . $post['patient_id'] . '"';

        $this->patient_model->updateDataIntoTable('patient_master', $update_data, $where_data);

        echo 'success';
    }
    public function viewSelectedPatient() {
        $data = array();
        $id = $this->input->get("id");
        $label = $this->input->get("label");
        $category = $this->input->get("category");
        if ($category == 'agedob') {
            $column = 'patient_age';
        } else if ($category == 'age') {
            $column = 'patient_dob';
        } else if ($category == 'gender') {
            $column = 'patient_gender';
        } else if ($category == 'state') {
            $column = 'pp_state';
        } else if ($category == 'disease') {
            $column = 'disease';
        } else if ($category == 'user1') {
            $column = 'userName';
        } else {
            $column = '';
        }

        if (isset($id) && $id != '' && isset($label) && $label != '' && isset($category) && $category != '') {
            $data = $this->patient_model->getResultByCategory($category, $id, $label);
        }
        $data['show_column'] = $column;

        $this->load->view('header');
        $this->load->view('patient/patient_by_category', $data);
        $this->load->view('footer');
    }

    function checkPtKaroCaseNo() {
        $patient_karo_case_no = $_GET["patient_karo_case_no"];

        //check karo case no.
        $check = $this->patient_model->checkPtKaroCaseNoModel($patient_karo_case_no);

        if (count($check) != 0) {
            echo 1;
        } else {
            echo 0;
        }
    }
	
	function checkPhoneNo() {
        $patient_phone_no = $_GET["patient_phone"];
		$patient_id=$_GET["patient_id"];

        //check karo case no.
        $check = $this->patient_model->checkPhoneNoExists($patient_phone_no,$patient_id);

        if (count($check) != 0) {
            echo 1;
        } else {
            echo 0;
        }
    }

    //akash rai 5 march 2020
    function deletePatient() {
        $patient_id = $this->input->post("patient_id");
        $reason_of_deletion = ltrim($this->input->post("reason_of_deletion"));
        $str_pt_id = $this->input->post("str_pt_id");


        //get case state
        $getState = $this->patient_model->getCaseState($str_pt_id);

       // if ($getState[0]->case_status == "New") {
            $this->patient_model->deletePatientModel($patient_id, $reason_of_deletion);
			//$this->patient_model->deleteCase($str_pt_id);
			
       // } else {
        //    echo 1;
       // }
    }

    //akash rai 13 march 2020
    function checkState() {
        $str_pt_id = $this->input->post("str_pt_id");

        //get case state
        $getState = $this->patient_model->getCaseState($str_pt_id);
        echo $getState[0]->case_status;
    }

}

?>
