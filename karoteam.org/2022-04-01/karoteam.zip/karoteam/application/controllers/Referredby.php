<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Referredby extends CI_Controller {

    public function __construct() {
        parent::__construct();
        if (!$this->session->userdata('UsertId')) {
            redirect('login');
        } else if (empty($this->session->userdata('IsAdmin'))) {
            redirect('dashboard');
        }
        $this->load->library('form_validation');
        $this->load->library('encrypt');
        $this->load->model('referredby_model');
    }

    function index() {
        /* Check submit button */
        if ($this->input->post('save')) {

            $refered_by_name = trim($this->input->post('refered_by_name'));
            $city = trim($this->input->post('city'));
            $state = trim($this->input->post('state'));
            $zipcode = trim($this->input->post('zipcode'));
            $contact_no = trim($this->input->post('contact_no'));
            $address = trim(str_replace("'", "`", $this->input->post('address')));
            // if ($refered_by_name != '' && $city != '' && $state != '' && $zipcode != '' && $contact_no != '' && $address != '')
            if ($refered_by_name != '') {
                $save = $this->referredby_model->savereferedby($refered_by_name, $city, $state, $zipcode, $contact_no, $address);
                $this->session->set_flashdata('message', $save);
            } else {
                $this->session->set_flashdata('message', '<div class="alert alert-danger">Please enter all required fields</div>');
            }
        }
        $getreferedby = $this->referredby_model->getreferedby();
        $getState = $this->referredby_model->getstates();

        //$getcity = $this->referredby_model->getreferedby();
        $getreferedbyData['referedby'] = $getreferedby;
        $getreferedbyData['states'] = $getState;
        if (isset($_REQUEST['act'])) {
            if ($_REQUEST['act'] == 'update') {
                $values = explode("|", base64_decode($_REQUEST['id']));
                $city = $this->getcities($values[3]);
                $getreferedbyData['cities'] = $city;
            }
        }
        $this->load->view('header');
        $this->load->view('referredby/index', $getreferedbyData);
        $this->load->view('footer');
    }

    function getcities($state) {
        $getcities = $this->referredby_model->getcities($state);
        return $getcities;
    }

    function changestatus() {
        if ($_REQUEST['id'] != '') {
            $id = base64_decode($_REQUEST['id']);
            if ($_REQUEST['status'] == 1) {
                $status = 0;
            } else {
                $status = 1;
            }
            $save = $this->referredby_model->changeStatus($id, $status);
            $this->session->set_flashdata('message', $save);
            redirect('referredby');
        }
    }

    function updatereferred() {
        if ($this->input->post('save')) {
            $refered_by_name = trim($this->input->post('refered_by_name'));
            $city = trim($this->input->post('city'));
            $state = trim($this->input->post('state'));
            $zipcode = trim($this->input->post('zipcode'));
            $contact_no = trim($this->input->post('contact_no'));
            $address = trim(str_replace("'", "`", $this->input->post('address')));
            $ReferedById = base64_decode($this->input->post('ReferedById'));
            //if ($refered_by_name != '' && $city != '' && $state != '' && $zipcode != '' && $contact_no != '' && $address != '' && $ReferedById !='') 
            if ($refered_by_name != '') {
                $save = $this->referredby_model->updatereferedby($refered_by_name, $city, $state, $zipcode, $contact_no, $address, $ReferedById);
                $this->session->set_flashdata('message', $save);
            } else {
                $this->session->set_flashdata('message', '<div class="alert alert-danger">Please enter all requred fileds</div>');
            }
            redirect('referredby');
        }
    }

}

?>
