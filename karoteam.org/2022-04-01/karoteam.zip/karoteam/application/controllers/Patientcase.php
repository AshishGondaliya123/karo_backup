<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Patientcase extends CI_Controller {

    public function __construct() {
        parent::__construct();
        if (!$this->session->userdata('UsertId')) {
            redirect('login');
        }
        $this->load->library('form_validation');
        $this->load->library('encrypt');
        $this->load->model('patient_model');
        $this->load->model('patientcase_model');
        $this->load->model('prefix_master');
        $this->load->model('users_model');
        $this->load->model('hospital_model', 'hm');
    }

    function index() {

        /* Check submit button */
        $data = array();
        if (!empty($this->input->get("cid"))) {
            $cid = $this->input->get("cid");
            $case = $this->patientcase_model->getPatientCase($cid)[0];
            $patient = $this->patient_model->getPatientById($case['patient_id'])[0];
            $social_workers = $this->patientcase_model->getAllActiveSocialWorkers();
//prx( $patient);
            $cid = $case['id'];

            if (!empty($this->input->get("tabstatus"))) {
                $case['tab_status'] = $this->input->get("tabstatus");
            }

            if ($this->session->userdata("IsAdmin") != 1) {
                if ($patient['created_by'] != $this->session->userdata('UsertId')) {
                  redirect("patientmaster/viewpatient");
                }
            } else {
                $data['social_workers'] = $social_workers;
            }

            $finance = $this->patientcase_model->getPatientFinance($cid);
            $followup = $this->patientcase_model->getPatientFollowup($cid);
            $documents = $this->patientcase_model->getPatientDocument($cid);
            $case_trust = $this->patientcase_model->getPatientCaseTrusts($cid);

//            echo "<pre>";
//            print_r($followup);
//            exit;

            $notes = $this->patientcase_model->getPatientNotes($cid);

            if ($notes['social_worker_name']) {
                $notes['social_worker_id'] = $notes['social_worker_name'];
                $notes['social_worker_name'] = $social_workers[$notes['social_worker_name']]['FirstName'] . ' ' . $social_workers[$notes['social_worker_name']]['MiddleName'] . ' ' . $social_workers[$notes['social_worker_name']]['LastName'];
            }

            $user = $this->users_model->getUserById($patient['created_by']);
            $data['patient'] = $patient;
            $data['case'] = $case;
            $data['finance'] = $finance;
            $data['followup'] = $followup;
            $data['documents'] = $documents;
            $data['case_trust'] = $case_trust;
            $data['user'] = $user;
            $data['notes'] = $notes;
            // $data['createdby'] = !empty($this->users_model->getUserById($patient['created_by'])[0]) ? $this->users_model->getUserById($patient['created_by'])[0] : 1;
            $data['createdby'] = $user[0]['FirstName'] . ' ' . $user[0]['MiddleName'] . ' ' . $user[0]['LastName'];
            $hospital_name = $this->hm->getActiveRecord('hospitalmaster', 'IsActive', 'HospitalName', 'asc');
            $diseases = $this->hm->getActiveRecord('diseasesmaster', 'IsActive', 'DiseaseName', 'asc');
            $data['hospital_name'] = $hospital_name;
            $data ['diseases'] = $diseases;
        }
        // prx($data);
        //get department list
        $data["department"] = $this->hm->getDept();

        //akash file upload code
        $data["res11"] = $this->patientcase_model->getPatientFiles($cid);

        $this->load->view('header');
        $this->load->view('patientcase/index', $data);
        $this->load->view('footer');
    }
    
    function updatefileurls() {
     
        $query = $this->db->select('id,file_urls')
                        ->from('patient_documents_details')
                        ->where('file_urls != "" AND file_urls!= "[]"')
                        ->get();
            
        
        if ($query->num_rows() > 0) {
            $data = $query->result_array();
            
            foreach($data as $i=>$row){
                $json = json_decode($row['file_urls'], true);
                 
                $replace=array(); 
                foreach($json as $k=>$file){
                    $replace[] = str_replace("http://karosoftware.esoftech.in", "https://karoteam.org", $file);
                }
                $data[$i]['file_urls'] = json_encode($replace);
            }
            
            $this->db->update_batch('patient_documents_details', $data, "id");
        }
        
        
        $query = $this->db->select('id,file_url')
                        ->from('patient_document_details_test')
                        ->where('file_url != ""')
                        ->get();
        
        if ($query->num_rows() > 0) {
            $test_data = $query->result_array();
            
            foreach($test_data as $j=>$row){
                
                $test_data[$j]['file_url'] = str_replace("http://karosoftware.esoftech.in", "https://karoteam.org", $row['file_url']);
            }
            
            $this->db->update_batch('patient_document_details_test', $test_data, "id");
        }                
                        
    }
    
    
    function save() {
        if (!$this->session->userdata('UsertId')) {
            redirect('login');
        } else {
            $case_id = $this->input->get("cid");
            $data = $this->input->post();
            $tab_status = $data['tab_status'];
            unset($data['tab_status']);
            $data["pre_surgery_or_transplant"] = (in_array('pre_surgery_or_transplant', $data['medication'])) ? "1" : "0";
            $data["pre_transplant"] = (in_array('pre_transplant', $data['medication'])) ? "1" : "0";
            $data["medicines"] = (in_array('medicines', $data['medication'])) ? "1" : "0";
            $data["hospitalized"] = (in_array('hospitalized', $data['medication'])) ? "1" : "0";
            $data["post-surgery_or_treatment"] = (in_array('post-surgery_or_treatment', $data['medication'])) ? "1" : "0";
            $data["post-treatment"] = (in_array('post-treatment', $data['medication'])) ? "1" : "0";
            $data["exercise"] = (in_array('exercise', $data['medication'])) ? "1" : "0";
            $data["updated_by"] = $this->session->userdata('UsertId');
            $data['medicines_details'] = $data['medicines_details'] ? trim($data['medicines_details']) : '';
            unset($data['medication']);
            $id = $this->patientcase_model->savePatientCase($case_id, $data);
            $this->patientcase_model->updateTabStatus($tab_status, $case_id);
            $this->session->set_flashdata('msg', 'Saved successfully');
            redirect('patientcase/index/?task=medical&cid=' . $case_id);
        }
    }

    private function upload_files($title, $files, $file_url = "") {
        $images = array();

        if (!empty($file_url)) {
            $images = json_decode($file_url, true);
        }

        $config = array(
            'upload_path' => 'karoclient/file_uploads/',
            'allowed_types' => 'jpg|gif|png|jpeg|html|pdf|txt|csv|doc|docx|xlsx|xls',
            'max_size' => '5000',
        );

        $this->load->library('upload', $config);


        //$fileArray = array();

        foreach ($files['name'] as $key => $image) {
            $_FILES['files[]']['name'] = $files['name'][$key];
            $_FILES['files[]']['type'] = $files['type'][$key];
            $_FILES['files[]']['tmp_name'] = $files['tmp_name'][$key];
            $_FILES['files[]']['error'] = $files['error'][$key];
            $_FILES['files[]']['size'] = $files['size'][$key];
            $fileName = $title . '_' . $image;
            $fileName = str_replace(" ", "_", $fileName);

            if (strpos($file_url, $fileName) !== false) {
                
            } else {
                $images[] = base_url() . 'karoclient/file_uploads/' . $fileName;
				//prx($images);
            }

            $config['file_name'] = $fileName;
            $this->upload->initialize($config);
            if ($this->upload->do_upload('files[]')) {
                $data = $this->upload->data();
            } else {
                
            }
        }

        return json_encode($images);
    }

    public function deleteuploaddoc() {
        $doc_id = $this->input->get("id");
        $documents = $this->patientcase_model->getPatientNotesById($doc_id);
        $file = $this->input->get("file");
        $file_urls = $documents['file_urls'];
        $file_array = json_decode($file_urls, true);
        $file_array_urls = array();

        foreach ($file_array as $files) {
            if (!strstr($files, $file)) {
                $file_array_urls[] = $files;
            }
        }



        try {
            unlink(FCPATH . 'karoclient/file_uploads/' . $file);
        } catch (Exception $e) {
            return $file_urls;
        }

        $documents = $this->patientcase_model->updatePatientUploads(json_encode($file_array_urls), $doc_id);

        return $file_array_urls;
    }

    public function uploaddoc() {
        $case_id = $this->input->get("cid");

        $documents = $this->patientcase_model->getPatientDocument($case_id);

        if (!empty($documents['id'])) {
            $result = $this->upload_files($case_id, $_FILES['files'], $documents['file_urls']);
        } else {
            $result = $this->upload_files($case_id, $_FILES['files']);
        }

        echo $result;
    }

    public function savedoc() {
        if (!$this->session->userdata('UsertId')) {
            redirect('login');
        } else {
            $data = $this->input->post();
            $case_id = $this->input->get("cid");
            $tab_status = $data['tab_status'];
            unset($data['tab_status']);

            $data["birth_certificates"] = isset($data["birth_certificates"]) ? "1" : "0";
            $data["ration_card"] = isset($data["ration_card"]) ? "1" : "0";
            $data["adhaar_card"] = isset($data["adhaar_card"]) ? "1" : "0";
            $data["salary_slips"] = isset($data["salary_slips"]) ? "1" : "0";
            $data["pan_card_or_election_id"] = isset($data["pan_card_or_election_id"]) ? "1" : "0";
            $data["photograph"] = isset($data["photograph"]) ? "1" : "0";
            $data["insurance_paper"] = isset($data["insurance_paper"]) ? "1" : "0";
            $data["ref_or_contact_people"] = isset($data["ref_or_contact_people"]) ? "1" : "0";
            $data["income_certificate"] = isset($data["income_certificate"]) ? "1" : "0";
            $data["hla_match_report"] = isset($data["hla_match_report"]) ? "1" : "0";
            $data["affidavit"] = isset($data["affidavit"]) ? "1" : "0";
            $data["doctors_letter"] = isset($data["doctors_letter"]) ? "1" : "0";
            $data["appeal_letter"] = isset($data["appeal_letter"]) ? "1" : "0";
            $data["medical_report"] = isset($data["medical_report"]) ? "1" : "0";
            $data["medical_bills_current"] = isset($data["medical_bills_current"]) ? "1" : "0";
            $data["transplant_doc"] = isset($data["transplant_doc"]) ? "1" : "0";

            $data["updated_by"] = $this->session->userdata('UsertId');
            if (empty($data['file_urls']))
                unset($data['file_urls']);
            $id = $this->patientcase_model->savePatientDocument($case_id, $data, $data['document_id']);
            $this->patientcase_model->updateTabStatus($tab_status, $case_id);
            $this->session->set_flashdata('msg', 'Saved successfully');
            redirect('patientcase/index/?task=upload&cid=' . $case_id);
        }
    }

    function savenotes() {
        if (!$this->session->userdata('UsertId')) {
            redirect('login');
        } else {
            $case_id = $this->input->get("cid");
            $data = $this->input->post();
            $tab_status = $data['tab_status'];
            unset($data['tab_status']);

            $data['social_worker_name'] = ($this->session->userdata("IsAdmin") == 1) ? $data['social_worker_name'] : $data['UserId'];
            unset($data['UserId']);
            $this->patientcase_model->savePatientNotes($case_id, $data, $data['note_id']);
            $this->patientcase_model->updateTabStatus($tab_status, $case_id);
            $this->session->set_flashdata('msg', 'Saved successfully');
            redirect('patientcase/index/?task=notes&cid=' . $case_id);
        }
    }

    function savefin() {
        if (!$this->session->userdata('UsertId')) {
            redirect('login');
        } else {
            $case_id = $this->input->get("cid");
            $data = $this->input->post();
            $trust_insert_data = $trust_update_data = array();
            //saving and updating trust data
            $tab_status = $data['tab_status'];
            unset($data['tab_status']);
            if ($data['trustname']) {
                foreach ($data['trustname'] as $key => $value) {
                    if (empty($data['trustid'][$key])) {
                        if ($data['trustname'][$key] && ($data['trustamount'][$key] >= 0) && $data['trust_status']) {
                            $trust_insert_data [$key]['trust_name'] = $data['trustname'][$key];
                            $trust_insert_data [$key]['amount'] = $data['trustamount'][$key];
                            $trust_insert_data[$key]['trust_status'] = $data['trust_status'][$key];
                            $trust_insert_data[$key]['case_id'] = $case_id;
                            $trust_insert_data[$key]['created_by'] = $this->session->userdata('UsertId');
                            $trust_insert_data[$key]['created_at'] = date('Y-m-d H:i:s');
                        }
                    } else {
                        $trust_update_data [$key]['id'] = $data['trustid'][$key];
                        $trust_update_data [$key]['trust_name'] = $data['trustname'][$key];
                        $trust_update_data [$key]['amount'] = $data['trustamount'][$key];
                        $trust_update_data[$key]['trust_status'] = $data['trust_status'][$key];
                        $trust_update_data[$key]['case_id'] = $case_id;
                        $trust_update_data[$key]['updated_by'] = $this->session->userdata('UsertId');
                        $trust_update_data[$key]['updated_at'] = date('Y-m-d H:i:s');
                    }
                }

                if ($trust_insert_data)
                    $this->db->insert_batch("case_trust", $trust_insert_data);
                if ($trust_update_data)
                    $this->db->update_batch('case_trust', $trust_update_data, 'id');
            }

            $financial = $data["financial"];
            $trust = $data["trust"]; //getting case details trust data
            $data = $financial;
            //saving and updating trust data
            /* if ($trust && !empty($trust)) {
              $trust_row0 = $trust["trust_row0"];
              $trust_row1 = $trust["trust_row1"];
              $trust_row2 = $trust["trust_row2"];

              for ($i = 0; $i <= 2; $i++) {
              if (count(array_filter(${'trust_row' . $i})) != 0) {
              if (!empty(${'trust_row' . $i}[4])) {
              $dat = array(
              "col1" => ${'trust_row' . $i}[0],
              "col2" => ${'trust_row' . $i}[1],
              "col3" => ${'trust_row' . $i}[2],
              "col4" => ${'trust_row' . $i}[3],
              );

              $this->patientcase_model->saveUpdateTrusts($dat, (${'trust_row' . $i}[4]), "update");
              } else {
              $dat = array(
              "case_id" => $case_id,
              "col1" => ${'trust_row' . $i}[0],
              "col2" => ${'trust_row' . $i}[1],
              "col3" => ${'trust_row' . $i}[2],
              "col4" => ${'trust_row' . $i}[3],
              "created_at" => date("Y-m-d H:i:s")
              );

              $this->patientcase_model->saveUpdateTrusts($dat, "", "save");
              }
              }
              }
              } */

            $data["owned_house"] = isset($data["owned_house"]) ? "1" : "0";
            $data["owned_land"] = isset($data["owned_land"]) ? "1" : "0";
            $data["owned_shop"] = isset($data["owned_shop"]) ? "1" : "0";
            $data["owned_vechicle"] = isset($data["owned_vechicle"]) ? "1" : "0";
            $data["owned_other"] = isset($data["owned_other"]) ? "1" : "0";
            $data["treatment_expenses_own"] = isset($data["treatment_expenses_own"]) ? "1" : "0";
            $data["treatment_expenses_relatives"] = isset($data["treatment_expenses_relatives"]) ? "1" : "0";
            $data["treatment_expenses_friend"] = isset($data["treatment_expenses_friend"]) ? "1" : "0";
            $data["treatment_expenses_loan"] = isset($data["treatment_expenses_loan"]) ? "1" : "0";
            $data["treatment_expenses_othertrust"] = isset($data["treatment_expenses_othertrust"]) ? "1" : "0";
            $data["updated_by"] = $this->session->userdata('UsertId');

            $id = $this->patientcase_model->savePatientFinance($case_id, $data, $data['finance_id']);
            $this->patientcase_model->updateTabStatus($tab_status, $case_id);
            $this->session->set_flashdata('msg', 'Saved successfully');
            redirect('patientcase/index/?task=finance&cid=' . $case_id);
        }
    }

    function followup() {
        if (!$this->session->userdata('UsertId')) {
            redirect('login');
        } else {
            $case_id = $this->input->get("cid");
            $data = $this->input->post();
            $tab_status = $data['tab_status'];
            unset($data['tab_status']);
            $recordCount = count($data['followup_date']);
            $followupDataFinal = array();

            for ($i = 0; $i < $recordCount; $i++) {
                if (!empty($data["followup_date"][$i])) {
                    if (!empty($data["f_id"][$i])) {
                        $familyDataFinalUpdate = array("case_id" => $case_id, "folowup_done" => $data["folowup_done"][$i], "followup_date" => $data["followup_date"][$i], "remark" => $data["remark"][$i], "next_followup_date" => $data["next_followup_date"][$i], "created_at" => date("Y-m-d H:i:s"), "created_by" => $this->session->get_userdata('UsertId')['UsertId'],
                            'final_status' => (array_keys($data['final_status'])[0] === $i) ? 1 : 0,
                        );
                        $this->db->where('id', $data["f_id"][$i]);
                        $str1 = $this->db->update('patient_followup_details', $familyDataFinalUpdate);
                    } else {
                        array_push($followupDataFinal, array("case_id" => $case_id, "folowup_done" => isset($data["folowup_done"][$i]) ? $data["folowup_done"][$i] : 0, "followup_date" => $data["followup_date"][$i], "remark" => $data["remark"][$i], "next_followup_date" => $data["next_followup_date"][$i], "created_at" => date("Y-m-d H:i:s"), "created_by" => $this->session->get_userdata('UsertId')['UsertId'], 'final_status' => (array_keys($data['final_status'])[0] === $i) ? 1 : 0,
                        ));
                    }
                }
            }

            if ($followupDataFinal) {
                $id = $this->db->insert_batch("patient_followup_details", $followupDataFinal);
            }
            $this->patientcase_model->updateTabStatus($tab_status, $case_id);
            $this->session->set_flashdata('msg', 'Saved successfully');
            redirect('patientcase/index/?task=followup&cid=' . $case_id);
        }
    }

    function deletepatientfollowup() {
        // prx($this->input->get("fid"));
        if (!empty($this->input->get("fid"))) {
            $followup_id = $this->input->get("fid");
            $this->db->delete('patient_followup_details', array('id' => $followup_id));
        }
    }

    function citiesByState() {
        $state = $_REQUEST['state'];
        if ($_REQUEST['cityid'] != '') {
            $cityname = $_REQUEST['cityid'];
        } else {
            $cityname = '';
        }
        $getcities = $this->referredby_model->getcities($state);
        foreach ($getcities as $city) {
            if ($city['city_name'] == $cityname) {
                $selected = "selected='selected'";
            } else {
                $selected = '';
            }
            echo "<option value='" . $city['city_name'] . "' " . $selected . ">" . $city['city_name'] . "</option>";
        }
    }

    function getcities($state) {
        $getcities = $this->referredby_model->getcities($state);
        return $getcities;
    }

    function changestatus() {
        if ($_REQUEST['id'] != '') {
            $id = base64_decode($_REQUEST['id']);
            if ($_REQUEST['status'] == 1) {
                $status = 0;
            } else {
                $status = 1;
            }
            $save = $this->referredby_model->changeStatus($id, $status);
            $this->session->set_flashdata('message', $save);
            redirect('referredby');
        }
    }

    function updatereferred() {
        if ($this->input->post('save')) {
            $refered_by_name = $this->input->post('refered_by_name');
            $city = $this->input->post('city');
            $state = $this->input->post('state');
            $zipcode = $this->input->post('zipcode');
            $contact_no = $this->input->post('contact_no');
            $address = $this->input->post('address');
            $ReferedById = base64_decode($this->input->post('ReferedById'));
            if ($refered_by_name != '' && $city != '' && $state != '' && $zipcode != '' && $contact_no != '' && $address != '' && $ReferedById != '') {
                $save = $this->referredby_model->updatereferedby($refered_by_name, $city, $state, $zipcode, $contact_no, $address, $ReferedById);
                $this->session->set_flashdata('message', $save);
            } else {
                $this->session->set_flashdata('message', '<div class="alert alert-danger">Please enter all requred fields</div>');
            }
            redirect('referredby');
        }
    }

    function exportptdata() {
        $patient_id = $this->input->get("patient_id");
        $data = array();

        //patient master details
        $ptMasterDetails = $this->patientcase_model->getPtMasterDetails($patient_id);

        $ptFamilyDetails = $this->patientcase_model->getPtFamilyDetails($patient_id);
        $ptMedicalDetails = $this->patientcase_model->getPtMedicalDetails($patient_id);
        $ptFinancialDetails = $this->patientcase_model->getPtFinancialDetails($patient_id);
        $ptOtherDetails = $this->patientcase_model->getptOtherDetails($patient_id);
        $ptDocumentDetails = $this->patientcase_model->getPtDocumentDetails($patient_id);
        $ptNotesDetails = $this->patientcase_model->getPtNotesDetails($patient_id);
		$karoIntervention = $this->patientcase_model->getKaroIntervention($patient_id);
	
		$KaroInterventionDetails = $this->patientcase_model->getKaroIntervention1($patient_id);
			//prx($karoIntervention);
        $disbursedAmountDetails = $this->patientcase_model->displayDisburselListById($patient_id);
	    $refundAmountDetails = $this->patientcase_model->displayRefundListById($patient_id);
        $ptMasterDetails[0]->patient_image = $ptMasterDetails[0]->patient_image ? base_url() . $ptMasterDetails[0]->patient_image : '';
        $Rating = '';
        if ($ptNotesDetails[0]->Rating) {
            for ($i = 0; $i < $ptNotesDetails[0]->Rating; $i++) {
                $Rating.="<img src='" . base_url() . "karoclient/images/icon_star.png' />";
            }
        }
        $ptNotesDetails[0]->Rating = $Rating;

        $data['ptMasterDetails'] = $ptMasterDetails;
        $data['ptFamilyDetails'] = $ptFamilyDetails;
        $data['ptMedicalDetails'] = $ptMedicalDetails;
        $data['ptFinancialDetails'] = $ptFinancialDetails;
        $data['ptOtherDetails'] = $ptOtherDetails;
        $data['logo'] = base_url() . "karoclient/images/logo.png";
        $data['ptDocumentDetails'] = $ptDocumentDetails;
        $data['ptNotesDetails'] = $ptNotesDetails;
        $data['disbursedAmountDetails'] = $disbursedAmountDetails;
		$data['refundAmountDetails'] = $refundAmountDetails;
		$data['karoIntervention'] = $karoIntervention;
		$data['KaroInterventionDetails'] = $KaroInterventionDetails;
        $data['checkbox_checked'] = "<img src='" . base_url() . "karoclient/images/checked.png' />";
        $data['checkbox_uncheck'] = "<img src='" . base_url() . "karoclient/images/uncheck.png' />";

//        echo "<pre>";
//        prx($ptMasterDetails);
//        exit;

        $html = $this->load->view('/patientcase/patient_pdf', $data, true);
        // echo "<pre>";
        // print_r($html);
        // exit;
        $this->load->library('M_pdf');
        //actually, you can pass mPDF parameter on this load() function
        $pdf = $this->m_pdf->load();

        // Set a simple Footer including the page number
        $pdf->setFooter('Side {PAGENO} af {nb}');
        $pdf->WriteHTML($html,0);

        //offer it to user via browser download! (The PDF won't be saved on your server HDD)
        $pdf->Output($ptMasterDetails[0]->patient_case . '.pdf', 'I');
        // $mpdf = new \Mpdf\Mpdf();
        // $mpdf->setFooter('{PAGENO}');
        // $pdf->WriteHTML($html);
        // $pdf->Output($ptMasterDetails[0]->patient_case . '.pdf', 'D');
    }

    function removeTrustDetails() {
        $data = $this->input->post();
        if ($data['trust_id']) {
            $this->db->delete('case_trust', array('id' => $data['trust_id']));
            echo 'success';
        } else
            echo 'failure';
    }

    function update_document_record() {
        $cid = $_GET["cid"];
        $data = $_REQUEST["data1"];

        //insert data if no there or update
        $insert = $this->patientcase_model->insertDocumentDetails($cid, $data);

        //get file urls and display html
        $getFileUurls = $this->patientcase_model->getFileUurls($cid);
        $url = json_decode($getFileUurls[0]->file_urls);
        $document_id = $getFileUurls[0]->id;
        $html = "";

        if (!empty($url)) {
            foreach ($url as $key => $link) {
                $linkarr = explode("/", $link);
                $html .= '<div class="filCol" id="filCol">';
                $html .= "<a class='first' href='" . $link . "' target='_blank' download title='documents'>" . ($linkarr[count($linkarr) - 1]) . '</a>';
                $html .= "<a href='javascript:void(0)' id='delFile" . ($key + 1) . "' class='btn btn-danger fa fa-trash-o space last' onclick='confirmFileDelete(" . '"' . $document_id . '"' . "," . '"' . $linkarr[count($linkarr) - 1] . '"' . ", this);'></a><br/>";
                $html .= '<div class="clearfix"></div>';
                $html .= '</div>';
            }
        }

        echo $html;
    }

    //akash file upload code
    function uploaddocnew() {

        $files = $_FILES['files'];
        $title = $this->input->get("cid");
        $page = $this->input->get("page");
        
        //check if any file atill exists in the table for that case id
        foreach ($files['name'] as $key => $image) {
            $_FILES['files[]']['name'] = $files['name'][$key];
            $_FILES['files[]']['type'] = $files['type'][$key];
            $_FILES['files[]']['tmp_name'] = $files['tmp_name'][$key];
            $_FILES['files[]']['error'] = $files['error'][$key];
            $_FILES['files[]']['size'] = $files['size'][$key];
            $images_check[] = base_url() . 'karoclient/file_uploads/' . $image;
        }

        $images_check_result = $this->patientcase_model->ImagesCheckResult($images_check, $title);

        if ($images_check_result == 0) {
            $date = date("dmY");
            $length = 10;
            $intMin = (10 ** $length) / 10;
            $intMax = (10 ** $length) - 1;
            $codeRandom = mt_rand($intMin, $intMax);

            $config = array(
                'upload_path' => 'karoclient/file_uploads/',
                'allowed_types' => 'jpg|gif|png|jpeg|html|pdf|txt|csv|doc|docx|xlsx|xls',
                'max_size' => '5000',
            );

            $this->load->library('upload', $config);

            foreach ($files['name'] as $key => $image) {
                $_FILES['files[]']['name'] = $files['name'][$key];
                $_FILES['files[]']['type'] = $files['type'][$key];
                $_FILES['files[]']['tmp_name'] = $files['tmp_name'][$key];
                $_FILES['files[]']['error'] = $files['error'][$key];
                $_FILES['files[]']['size'] = $files['size'][$key];
                $fileName = $image;
                $fileName = str_replace(" ", "_", $fileName);
                $final_image = preg_replace("/(\.)(?=\S+\.)/", "_", $fileName);
                $images[] = base_url() . 'karoclient/file_uploads/' . $final_image;
                $insert_val = base_url() . 'karoclient/file_uploads/' . ($title . $final_image);
                $this->patientcase_model->insertPatientDocument($page, $title, $insert_val);
                $config['file_name'] = $title.$fileName;
                $this->upload->initialize($config);
                if ($this->upload->do_upload('files[]')) {
                    $data = $this->upload->data();
                } else {
                    
                }
            }

            //render new html
            $getData = $this->patientcase_model->getPatientFiles($title);
            $html = "";
            $i = 1;
            foreach ($getData as $res) {

                if (strpos($res->file_url, 'karosoftware.esoftech.in') !== false) {
                    $file_name = str_replace("http://karosoftware.esoftech.in/karoclient/file_uploads/", "", $res->file_url);
                } else {
                    $file_name = str_replace(base_url() . "karoclient/file_uploads/", "", $res->file_url);
                }

                $file_url = $res->file_url;
                $id = $res->id;

                $html .= "<div class='filCol' id='delFile$i'>";
                $html .= "<a class='first' href='$file_url' target='_blank' download title='documents'>" . $file_name . "</a>";
                $html .= '<a href="javascript:void(0)" class="btn btn-danger fa fa-trash-o space last" onclick="remove_file(' . $i . ',' . $id . ',\'' . $file_name . '\');"></a>';
                $html .= "<br/>";
                $html .= "<div class='clearfix'></div>";
                $html .= "</div>";
                $i++;
            }

            echo $html;
        } else {
            echo 1;
        }
    }

//akash file upload code
    function deletepatientfile() {
        $div_id = $this->input->post("div_id");
        $record_id = $this->input->post("record_id");
        $file_name = $this->input->post("file_name");
        $this->patientcase_model->removePatientFile($record_id);
        unlink(FCPATH . 'karoclient/file_uploads/' . $file_name);
    }

    function crawlscript() {
        try {
            $data = $this->patientcase_model->getCrawlingData();

            foreach ($data as $row) {
                $case_id = $row->case_id;
                $file_name = $row->file_urls;

                if (strpos($file_name, '[') !== false) {
                    $replace_1 = str_replace("[", "", $file_name);
                    $replace_2 = str_replace("]", "", $replace_1);
                    $file_urls = $replace_2;
                } else {
                    $file_urls = $file_name;
                }

                $str_arr = explode(",", $file_urls);

                foreach ($str_arr as $arr) {
                    $rep = str_replace('"', "", $arr);
                    $final_rep = str_replace("\/", "/", $rep);
                    $insert = array(
                        'case_id' => $case_id,
                        'file_url' => $final_rep
                    );

                    $this->patientcase_model->insertCrawl($insert);
                }
            }
        } catch (Exception $ex) {
            echo $ex->getMessage();
        }
    }

}

?>
