<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Example extends CI_Controller {
    public function __construct() {
        parent::__construct();
        // $this->ci_db = $this->load->database($db['codeigniter'],true);
        $this->DB2 = $this->load->database('codeigniter', TRUE);

        /*parent::__construct();
        if (!$this->session->userdata('UsertId')) {
            redirect('login');
        } else if (empty($this->session->userdata('IsAdmin'))) {
            redirect('dashboard');
        }
        $this->load->library('form_validation');
        $this->load->library('encrypt');
        $this->load->model('referredby_model');
        $this->load->model('users_model');*/
        header("Access-Control-Allow-Origin: *");
        header("Access-Control-Allow-Methods: PUT, GET, POST, DELETE, OPTIONS");
        header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");

    if ( "OPTIONS" === $_SERVER['REQUEST_METHOD'] ) {
    die();
}
        // header('Content-Type: application/json');


    }

 public function getUser()
 {

    $result[0]['first_name'] ='Puja';
    $result[0]['last_name']='khamkar';
    $result[0]['age']=50;

    $result[1]['first_name'] ='Neelam';
    $result[1]['last_name']='khamkar';
    $result[1]['age']=22;
    $data['data']=$result;

   echo json_encode($data);
 }

 public function readPolicy()
 {

    $this->DB2->from ('policies');
    $query = $this->DB2->get();
    $result = $query->result ();
    echo json_encode($result);
 }

 public function createPolicy()
 {
    $post =json_decode(file_get_contents('php://input'),true); //$this->input->post('number');
    $insert['number'] =$post['number'];
    $insert['amount']= $post['amount'];
    $this->DB2->insert('policies',$insert);
    $insert_id = $this->DB2->insert_id();
    if($insert_id)
    {
         http_response_code(201);
        echo json_encode($insert_id);
    }
 }

 public function deletePolicy()
 {
    $post=$this->input->get('id');

    $this->DB2->where('id', $post);
    $this->DB2->delete('policies');
    echo  json_encode('order has successfully been deleted');
 
 }

 public function updatePolicy()
 {
    $post =json_decode(file_get_contents('php://input'),true);
    // $post =$this->input->post();
    $where['id'] = $post['id'];
    $update['number'] = $post['number'];
    $update['amount']=$post['amount'];
        $this->DB2->where($where);
        $this->DB2->update('policies', $update);
        echo json_encode('order has successfully been updated');
 }

 public function createUser()
 {
    $post =json_decode(file_get_contents('php://input'),true); 
    $insert_data['first_name']= $post['firstname'];
    $insert_data['last_name']= $post['lastname'];
    $insert_data['email']=$post['email'];
    $insert_data['password'] =md5($post['password']);
    $insert_data['confirm_password'] =md5($post['confirm_password']);
    $this->DB2->insert('users',$insert_data);
    $insert_id = $this->DB2->insert_id();

     if($insert_id)
    {
         http_response_code(201);
        echo json_encode($insert_id);
    }

 }

 public function validateUser()
 {
    $return = array();
    $post =json_decode(file_get_contents('php://input'),true); 
    $where['email']= $post['username'];
    $this->DB2->where($where);
    $this->DB2->order_by("id", "desc");
    $this->DB2->limit(1);
    $query = $this->DB2->get('users');
    $data =$query->result();
    if($data)
    {
        
        if (md5($post['password'])== $data[0]->password) 
            echo json_encode(array('status'=>'success', 'data'=>$data,'msg'=>'Data Fetched successfully'));
        else
            echo json_encode(array('status'=>'error', 'data'=>'','msg'=>'Password not matched'));

    }
    else
            echo json_encode(array('status'=>'error', 'data'=>'','msg'=>'Record not found'));

 }


}
