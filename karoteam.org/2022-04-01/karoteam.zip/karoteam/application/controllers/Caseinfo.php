<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Caseinfo extends CI_Controller {

    public function __construct() {
        parent::__construct();
        if (!$this->session->userdata('UsertId')) {
            redirect('login');
        }
        $this->load->library('form_validation');
        $this->load->model('case_model', 'cm');
        $this->load->model('patientcase_model');
    }

    public function getCaseData() {
        $request = $this->input->get();
        $case = $request['case'];
        $params = [];
        $params['pcd.case_status'] = $case;
        switch ($case) {
            case 'new':
                $data['result'] = $this->cm->getCaseDetails($params);
                $doner = $this->cm->getActiveDoner();
                foreach ($doner as $key => $value) {
                    $result[$key]['doner_id'] = $value->DonerId;
                    $result[$key]['name'] = $value->firstName . ' ' . $value->middleName . ' ' . $value->lastName;
                }
                $data['active_doner'] = $result;
                break;

            case 'open':
                $patient_details = $this->cm->getOpenCaseDetails($params);
                // prx($patient_details);
                $case_id = array_column($patient_details, 'id');
                $follow_up_next = $this->cm->getNextFollowUpdata($case_id);
                $disbursed_amt_array = $this->cm->getDisbursedAmountSum($case_id);
                // prx($disbursed_amt_array);
                $result = array();
                if ($patient_details)
                    foreach ($patient_details as $key => $value) {
                        if (array_key_exists($value['id'], $disbursed_amt_array)) {
                            if ($disbursed_amt_array[$value['id']]['DisbursedAmt'])
                                $patient_details[$key]['DisbursedAmt'] = $disbursed_amt_array[$value['id']]['DisbursedAmt'];
                        } else
                            $patient_details[$key]['DisbursedAmt'] = 0;

                        if ($follow_up_next)
                            foreach ($follow_up_next as $k => $v) {
                                if ($value['id'] == $v['case_id']) {
                                    $patient_details[$key]['next_followup_date'] = $v['next_followup_date'];
                                    break;
                                } else
                                    $patient_details[$key]['next_followup_date'] = '';
                            } else
                            $patient_details[$key]['next_followup_date'] = '';
                    }
                $data['result'] = $patient_details;
                break;
            case 'closed':
                $patient_details = $this->cm->getOpenCaseDetails($params);
                $follow_up = $this->cm->getLastFollowupData();

                $case_id = array_column($patient_details, 'id');
                $disbursed_amt_array = $this->cm->getDisbursedAmountSum($case_id);
                $result = array();
                if ($patient_details)
                    foreach ($patient_details as $key => $value) {
                        if (array_key_exists($value['id'], $disbursed_amt_array)) {
                            if ($disbursed_amt_array[$value['id']]['DisbursedAmt'])
                                $patient_details[$key]['DisbursedAmt'] = $disbursed_amt_array[$value['id']]['DisbursedAmt'];
                        } else
                            $patient_details[$key]['DisbursedAmt'] = 0;
                        if ($follow_up)
                            foreach ($follow_up as $k => $v) {
                                if ($value['id'] == $v['case_id']) {
                                    $patient_details[$key]['followup_date'] = $v['followup_date'];
                                    $patient_details[$key]['remark'] = $v['remark'];
                                    break;
                                } else {
                                    $patient_details[$key]['followup_date'] = '';
                                    $patient_details[$key]['remark'] = '';
                                }
                            } else {
                            $patient_details[$key]['followup_date'] = '';
                            $patient_details[$key]['remark'] = '';
                        }
                    }
                $data['result'] = $patient_details;
                break;
            case 'reject':
                $data['result'] = $this->getRejectHoldCaseData($params);
                $doner = $this->cm->getActiveDoner();
                foreach ($doner as $key => $value) {
                    $result[$key]['doner_id'] = $value->DonerId;
                    $result[$key]['name'] = $value->firstName . ' ' . $value->middleName . ' ' . $value->lastName;
                }
                $data['active_doner'] = $result;
                break;
            case 'hold':
                $data['result'] = $this->getRejectHoldCaseData($params);
                $doner = $this->cm->getActiveDoner();
                foreach ($doner as $key => $value) {
                    $result[$key]['doner_id'] = $value->DonerId;
                    $result[$key]['name'] = $value->firstName . ' ' . $value->middleName . ' ' . $value->lastName;
                }
                $data['active_doner'] = $result;
                break;
            case 'all':
                $data['result'] = $this->getRejectHoldCaseData($params);
                break;


            default:
                break;
        }
        // prx($data);
        $data['case_name'] = $case;
        $this->load->view('header');
        $this->load->view('cases/' . $case . '_case', $data);
        $this->load->view('footer');
    }

    public function rejectOrHoldCase() {
        $case_number = $this->input->post('case_number');
        $reason = $this->input->post('reason');
        $action = $this->input->post('action');
        if (empty($reason)) {
            echo json_encode(array('msg' => 'Enter the reason', 'class' => 'alert alert-danger', 'status' => 'error'));
            die();
        }
        $where_status['id'] = $case_number;
        $patient_status = $this->cm->selectDataFromTable('patient_case_details', ' ', $where_status);

        if ($action != 'closed')
            if ($patient_status[0]->case_status != 'New' && $patient_status[0]->case_status != 'hold') {
                echo json_encode(array('msg' => 'status is already approved for the patient', 'class' => 'alert alert-success', 'status' => 'success'));
                exit;
            }

        $insert_data['case_id'] = $case_number;
        $insert_data['case_status'] = $action;
        $insert_data['case_status_reason'] = $reason;
        $insert_data['case_status_date'] = date('Y-m-d H:i:s');
        $insert_data['created_by'] = $this->session->userdata('UsertId');
        $insert_data['created_at'] = date('Y-m-d H:i:s');
        // prx($insert_data);
        //insert data into patient_case_status_detail
        $this->cm->insertDataIntoTable('patient_case_status_detail', $insert_data);
        $update_data['case_status'] = $action;
        $update_data['updated_at'] = date('Y-m-d H:i:s');
        $where_data ['id'] = $case_number;

        //update the case status in patient_case_details
        $this->cm->updateDataIntoTable('patient_case_details', $update_data, $where_data);


        echo json_encode(array('msg' => 'Status updated Successfully', 'class' => 'alert alert-success', 'status' => 'success'));
    }

    public function approveNewCase() {
        $post = $this->input->post();
        $params = [];
        $params['pcd.id'] = $post['case_number'];
        $patient_data = $this->cm->getCaseDetails($params);
        // prx($patient_data);

        if (empty($post['case_number']) || empty($post['required_fund']) || empty($post['approve_amt']) || empty($post['doner_id']) || empty(date('y-m-d', strtotime($post['sanct_date'])))) {
            echo json_encode(array('msg' => 'Enter the details', 'class' => 'alert alert-danger', 'status' => 'error'));
            die();
        }


        $where_status['id'] = $post['case_number'];
        $patient_status = $this->cm->selectDataFromTable('patient_case_details', ' ', $where_status);

        if ($patient_status[0]->case_status != 'New' && $patient_status[0]->case_status != 'hold' && $patient_status[0]->case_status != 'reject') {
            echo json_encode(array('msg' => 'Amount is already approved for the patient', 'class' => 'alert alert-success', 'status' => 'success'));
            exit;
        }


        $chage_case_status = 'open';
        //update statue into patient_case_details table
        $update_data = array();
        $update_data['case_status'] = $chage_case_status;
        $update_data['updated_at'] = date('Y-m-d H:i:s');
        $where_data ['id'] = $post['case_number'];
        $this->cm->updateDataIntoTable('patient_case_details', $update_data, $where_data);

        //update amount in patient_financetial_details 
        $update_data = array();
        $where_data = array();
        $update_data['approved_amount'] = $post['approve_amt'];
        $where_data['case_id'] = $post['case_number'];
        $this->cm->updateDataIntoTable('patient_financetial_details', $update_data, $where_data);

        //insert data into patient_case_status_detail
        $insert_data['case_id'] = $post['case_number'];
        $insert_data['case_status'] = $chage_case_status;
        $insert_data['approved_amount'] = $post['approve_amt'];
        $insert_data['required_fund'] = $post['required_fund'];
        $insert_data['doner_id'] = $post['doner_id'];
        $insert_data['case_status_date'] = date('Y-m-d H:i:s');
        $insert_data['created_by'] = $this->session->userdata('UsertId');
        $insert_data['created_at'] = date('Y-m-d H:i:s');
        $insert_data['rehelp_date'] = date('Y-m-d', strtotime($post['rehelp_date']));

        $insert_data['case_status_reason'] = $patient_data[0]->current_diagnosed_detail;
        //prx($insert_data['rehelp_date']);
        $this->cm->insertDataIntoTable('patient_case_status_detail', $insert_data);

        echo json_encode(array('msg' => 'Case approved successfully', 'class' => 'alert alert-success', 'status' => 'success'));
    }

    public function getRejectHoldCaseData($params) {
        $patient_details = $this->cm->getOpenCaseDetails($params);
        $case_id = array_column($patient_details, 'id');
        $follow_up = $this->cm->getNumberOfFollowupData($case_id);
        $status_reason = $this->cm->getStatusReason($case_id, $params['pcd.case_status']);

        $result = array();

        if ($patient_details)
            foreach ($patient_details as $key => $value) {
                if ($status_reason)
                    $patient_details[$key]['status_reason'] = $status_reason[$value['id']]['case_status_reason'];

                if ($follow_up)
                    foreach ($follow_up as $k => $v) {
                        if ($value['id'] == $v['case_id']) {
                            $patient_details[$key]['no_of_followup'] = $v['no_of_followup'];
                            break;
                        } else
                            $patient_details[$key]['no_of_followup'] = 0;
                    } else
                    $patient_details[$key]['no_of_followup'] = 0;
            }

        return $patient_details;
    }

    public function getAmountDisbursed() {
        $get = $this->input->get();
        $args['pcd.id'] = $get['cid'];


        $data['patient_details'] = $this->cm->getOpenCaseDetails($args);

        $where_data['IsActive'] = 1;
        $data['mode'] = $this->cm->selectDataFromTable('paymentmaster', ' ', $where_data);
		$data['sanction_rehelp_date'] = $this->cm->getSanctionDate($args['pcd.id']);
		$sanc_id=$data['sanction_rehelp_date'][0]->id;

        $where_data = array();
        $where_data['CaseId'] = $args['pcd.id'];
		$where_data['SancId'] = $sanc_id;

        $data['result'] = json_decode(json_encode($this->cm->getDisbursedData($where_data)), true);
        $donor_disbured_amt = $this->cm->getDisbursedAmountSumDonorWise($where_data);
        // prx($donor_disbured_amt);

        $disbursed_donner = $this->cm->getDisbursedDonor($args['pcd.id']);
        // prx($disbursed_donner);
        $sanction_date = $this->cm->getLastSanctionDate($args['pcd.id']);
		
		
		//prx($data['sanction_rehelp_date']);
        $data['sanction_date'] = $sanction_date;
        $d_result = new stdClass();
		

        foreach ($disbursed_donner as $dk => $dv) {
            $d_result->$dk = $dv;
            if ($donor_disbured_amt[$dv->doner_id]) {
                $d_result->$dk->donorwise_amt = $donor_disbured_amt[$dv->doner_id];
            }
            $d_result->$dk->avaliable_amt = $dv->donner_approved_amount - $donor_disbured_amt[$dv->doner_id];
        }
		
		
        // prx($d_result);
        $data['disbursed_donner'] = $d_result;
        $post = '';
        if ($this->input->post() && $this->input->post('save') == 'add') {

            $post = $this->input->post();
			//prx($post);
            if (empty($post['fund_required']) || empty($post['approved_amount']) || empty($post['disbursed_amount']) || empty($post['disbursed_mode']) || empty($post['disbursed_donor']) ||  empty($post['sanction_date']) ) {
                $this->session->set_flashdata('message', '<div class="alert alert-danger">Please enter all the Details</div>');
            } else {
                $flag = 1;
                foreach ($d_result as $kk => $vv) {
                    if ($vv->doner_id == $post['disbursed_donor']) {
                        if ($post['disbursed_amount'] > $vv->avaliable_amt) {
                            $flag = 0;
                            break;
                        }
                    }
                }
                if ($flag == 0) {
                    $this->session->set_flashdata('message', '<div class="alert alert-danger">Total disbursed amount can not be grater than approved amount</div>');
                } else {
                    if ($_FILES ['reciept_upload'] && !empty($_FILES ['reciept_upload']["name"])) {
                        $receipt_image = $this->uploadImage($_FILES, $get['cid']);
                        if ($receipt_image['error']) {
                            $this->session->set_flashdata('message', '<div class="alert alert-danger">' . $receipt_image['error'] . '</div>');
                            redirect('/Caseinfo/getAmountDisbursed?cid=' . $get['cid']);
                        } else
                            $image_path = base_url() . 'karoclient/images/disbursed_images/' . $receipt_image['file_name'];
                    }else {
                        $image_path = "";
                    }
                    $insert_data['CaseId'] = $get['cid'];
                    $insert_data['CreatedBy'] = $this->session->userdata('UsertId');
                    $insert_data['CreatedDate'] = date('Y-m-d H:i:s');
                    $insert_data['DisbursedAmt'] = $post['disbursed_amount'];
                    $insert_data['PaymentModeId'] = $post['disbursed_mode'];
                    $insert_data['DisburesedDate'] = $post['disbursed_date'];
                    $insert_data['DisbursedBank'] = $post['bank_name'];
                    $insert_data['DisbursedRefNo'] = $post['cheque_dd'];
                    $insert_data['DonorId'] = $post['disbursed_donor'];
                    $insert_data['receipt_no'] = $post['reciept_memo_no'];
				    $insert_data['sanction_id'] = $post['sanction_id'];
					//$insert_data['sanction_id'] = 4208;
										
                    $insert_data['receipt_file'] = $image_path;
					//prx($insert_data);

                    $this->cm->insertDataIntoTable('patient_case_disbursed_detail', $insert_data);
                    $this->session->set_flashdata('message', '<div class="alert alert-success">Amount Disbursed Successfully</div>');
                }
            }
        }

        $data['case_id'] = $args['pcd.id'];
        $sum = 0;
        if ($data['result'])
            foreach ($data['result'] as $item) {
                $sum += $item['DisbursedAmt'];
            }
        $data['total_approved_amount'] = $sum;
        if ($post) {
            redirect('/Caseinfo/getAmountDisbursed?cid=' . $args['pcd.id']);
        } else {
            $this->load->view('header');
            $this->load->view('cases/patient_amount_disbursed', $data);
            $this->load->view('footer');
        }
    }
	
	function donorBySanctionDate(){
        $date =  $this->input->post('sanc_date');
	//	prx($date);

		$sanc_doner=$this->cm->getDonorBySanctionDate($date);

				 $html = "";
        //$html .="<select class='form-control' name='disbursed_donor' id='disbursed_donor'><option value=''>Select donor</option>";
        foreach ($sanc_doner as $donor) {
            $html .="<option value='" . $donor->doner_id . "' data-donoramount='" . $donor->total . "' data-avaliabledonneramt='" . $donor->avaliable_amt . "' data-disbId='" . $donor->id . "' >" .  $donor->Donerss  . "</option>";
        }
        $html .="</select>";
        echo $html;

	} 
	

    function editcasedisbursedetails() {
        date_default_timezone_set('Asia/kolkata');
        $get = $this->input->get();
        $args['pcd.id'] = $get['cid'];

        $did = $get['did'];


        $data['patient_details'] = $this->cm->getOpenCaseDetails($args);

        $where_data['IsActive'] = 1;
        $data['mode'] = $this->cm->selectDataFromTable('paymentmaster', ' ', $where_data);

        $where_data = array();
        $where_data['CaseId'] = $args['pcd.id'];

        $data['result'] = json_decode(json_encode($this->cm->getDisbursedData($where_data)), true);
        $donor_disbured_amt = $this->cm->getDisbursedAmountSumDonorWise($where_data);

        $data["getData"] = $this->cm->getDisbursalDataById($_GET["did"]);

        $disbursed_donner = $this->cm->getDisbursedDonor($args['pcd.id']);
		//prx($data["getData"]);
		$data['sanc_doner']=$this->cm->getDonorBySanctionDate($data['getData'][0]->sanction_id);
		//prx($sanc_doner);
		
        $sanction_date = $this->cm->getLastSanctionDate($args['pcd.id']);
		$data['sanction_rehelp_id'] = $this->cm->getSanctionDate($args['pcd.id']);
        $data['sanction_date'] = $sanction_date;
        $d_result = new stdClass();
        foreach ($disbursed_donner as $dk => $dv) {
            $d_result->$dk = $dv;
            if ($donor_disbured_amt[$dv->doner_id]) {
                $d_result->$dk->donorwise_amt = $donor_disbured_amt[$dv->doner_id];
            }
            $d_result->$dk->avaliable_amt = $dv->donner_approved_amount - $donor_disbured_amt[$dv->doner_id];
        }
        // prx($d_result);
        $data['disbursed_donner'] = $d_result;
        $post = '';
        if ($this->input->post() && $this->input->post('save') == 'add') {

            $post = $this->input->post();
            if (empty($post['fund_required']) || empty($post['approved_amount']) || empty($post['disbursed_amount']) || empty($post['disbursed_mode']) || empty($post['disbursed_donor'])) {
                $this->session->set_flashdata('message', '<div class="alert alert-danger">Please enter all the Details</div>');
            } else {
                $flag = 1;
                foreach ($d_result as $kk => $vv) {
                    if ($vv->doner_id == $post['disbursed_donor']) {
                        if ($post['disbursed_amount'] > $vv->avaliable_amt) {
                            $flag = 0;
                            break;
                        }
                    }
                }
//                if ($flag == 0) {
//                    $this->session->set_flashdata('message', '<div class="alert alert-danger">Total disbursed amount can not be grater than approved amount</div>');
//                } else {
                if ($_FILES ['reciept_upload'] && !empty($_FILES ['reciept_upload']["name"])) {
                    $receipt_image = $this->uploadImage($_FILES, $get['cid']);
                    if ($receipt_image['error']) {
                        $this->session->set_flashdata('message', '<div class="alert alert-danger">' . $receipt_image['error'] . '</div>');
                        redirect('/Caseinfo/getAmountDisbursed?cid=' . $get['cid']);
                    } else
                        $image_path = base_url() . 'karoclient/images/disbursed_images/' . $receipt_image['file_name'];
                }else {
                    $image_path = "";
                }

                $insert_data['DonorId'] = $post['disbursed_donor'];
                $insert_data['DisbursedAmt'] = $post['disbursed_amount'];

                if (!empty($post['disbursed_date'])) {
                    $insert_data['DisburesedDate'] = $post['disbursed_date'];
                }

                $insert_data['PaymentModeId'] = $post['disbursed_mode'];
                $insert_data['DisbursedBank'] = $post['bank_name'];
                $insert_data['DisbursedRefNo'] = $post['cheque_dd'];
                $insert_data['receipt_no'] = $post['reciept_memo_no'];

                if (!empty($image_path)) {
                    $insert_data['receipt_file'] = $image_path;
                }

                //before updating store previous data
                $getPrevDisbData = $this->cm->getPrevDisbData($did);

                $insertd_data['UpdatedBy'] = $this->session->userdata('UsertId');
                $insertd_data['UpdatedDate'] = date('Y-m-d H:i:s');
                $insertd_data["CaseId"] = $getPrevDisbData[0]->CaseId;
                $insertd_data["Did"] = $getPrevDisbData[0]->id;
                $insertd_data["DonorId"] = $getPrevDisbData[0]->DonorId;
                $insertd_data["DisbursedAmt"] = $getPrevDisbData[0]->DisbursedAmt;
                $insertd_data["DisburesedDate"] = $getPrevDisbData[0]->DisburesedDate;
                $insertd_data["PaymentModeId"] = $getPrevDisbData[0]->PaymentModeId;
                $insertd_data["DisbursedBank"] = $getPrevDisbData[0]->DisbursedBank;
                $insertd_data["DisbursedRefNo"] = $getPrevDisbData[0]->DisbursedRefNo;
                $insertd_data["receipt_no"] = $getPrevDisbData[0]->receipt_no;
                $insertd_data["receipt_file"] = $getPrevDisbData[0]->receipt_file;
				$insertd_data["sanction_id"] = $getPrevDisbData[0]->sanction_id;

                $this->cm->insertDataIntoTable('patient_case_disbursed_detail_log', $insertd_data);

                //update data
                $this->cm->updateDisburseDetails($insert_data, $did);
                $this->session->set_flashdata('message', '<div class="alert alert-success">Record updated successfully</div>');
                //}
            }
        }

        $data['case_id'] = $args['pcd.id'];
        $sum = 0;
        if ($data['result'])
            foreach ($data['result'] as $item) {
                $sum += $item['DisbursedAmt'];
            }
        $data['total_approved_amount'] = $sum;


        //get data

        if ($post) {
            redirect('/Caseinfo/editcasedisbursedetails?cid=' . $args['pcd.id'] . '&did=' . $did);
        } else {
            $this->load->view('header');
            $this->load->view('cases/edit_patient_amount_disbursed', $data);
            $this->load->view('footer');
        }
    }

    function deletedisburse() {
        date_default_timezone_set('Asia/kolkata');
        $fid = $_GET["fid"];
        $reason = $_GET["reason"];

        //before updating store previous data
        $getPrevDisbData = $this->cm->getPrevDisbData($fid);

        $insertd_data['UpdatedBy'] = $this->session->userdata('UsertId');
        $insertd_data['UpdatedDate'] = date('Y-m-d H:i:s');
        $insertd_data["CaseId"] = $getPrevDisbData[0]->CaseId;
        $insertd_data["Did"] = $getPrevDisbData[0]->id;
        $insertd_data["DonorId"] = $getPrevDisbData[0]->DonorId;
        $insertd_data["DisbursedAmt"] = $getPrevDisbData[0]->DisbursedAmt;
        $insertd_data["DisburesedDate"] = $getPrevDisbData[0]->DisburesedDate;
        $insertd_data["PaymentModeId"] = $getPrevDisbData[0]->PaymentModeId;
        $insertd_data["DisbursedBank"] = $getPrevDisbData[0]->DisbursedBank;
        $insertd_data["DisbursedRefNo"] = $getPrevDisbData[0]->DisbursedRefNo;
        $insertd_data["receipt_no"] = $getPrevDisbData[0]->receipt_no;
        $insertd_data["receipt_file"] = $getPrevDisbData[0]->receipt_file;
        $insertd_data["reason"] = $reason;

        $this->cm->insertDataIntoTable('patient_case_disbursed_detail_delete_log', $insertd_data);

        $this->db->where('id', $fid);
        $this->db->delete('patient_case_disbursed_detail');
    }

    function displayDisburselList() {
        $case_id = $this->input->post('case_number');
        $getData = $this->cm->displayDisburselListById($case_id);
        $html = "";

        if (empty($getData)) {
            echo "<p style='text-align:center;'>No data found</p>";
        } else {
            echo "<table border='1'>";
            echo "<tr>";
            echo "<th>Donor Name</th>";
            echo "<th>Disburse Amount</th>";
            echo "<th>Disburse Date</th>";
            echo "<th>Payment Mode</th>";
            echo "<th>Bank Name</th>";
            echo "<th>Cheque / DD No.</th>";
            echo "<th>Reciept No./Memo No.</th>";
            echo "<th>Download Receipt</th>";
            echo "<tr>";
            foreach ($getData as $result) {
                $donor_name = $this->cm->getDonorDetailsById($result->DonorId);
                $payment_name = $this->cm->getPaymentModeById($result->PaymentModeId);

                echo "<tr>";
                echo "<td>" . $donor_name[0]->FirstName . ' ' . $donor_name[0]->Name . "</td>";
                echo "<td>" . $result->DisbursedAmt . "</td>";
                echo "<td>" . date("m/d/Y", strtotime($result->DisburesedDate)) . "</td>";
                echo "<td>" . $payment_name[0]->PaymentMode . "</td>";
                echo "<td>" . $result->DisbursedBank . "</td>";
                echo "<td>" . $result->DisbursedRefNo . "</td>";
                echo "<td>" . $result->receipt_no . "</td>";
                echo "<td>" . ((!empty($result->receipt_file)) ? "<a href='" . $result->receipt_file . "' target='_blank'><button class='btn btn-info btn-xs' title='Download Receipt' style='width: 37px;height: 29px;padding: 0px;margin: 4px;margin-bottom: 3px;'><i class='fa fa-download'></i></button></a>" : "") . "</th>";
                echo "<tr>";
            }
            echo "</table>";

            echo $html;
        }
    }

    function displayDeleteDisburselList() {
        $case_id = $this->input->post('case_number');
        $getData = $this->cm->displayDeleteDisburselListById($case_id);
        $html = "";

        if (empty($getData)) {
            echo "<p style='text-align:center;'>No data found</p>";
        } else {
            echo "<table border='1'>";
            echo "<tr>";
            echo "<th>Donor Name</th>";
            echo "<th>Disburse Amount</th>";
            echo "<th>Disburse Date</th>";
            echo "<th>Payment Mode</th>";
            echo "<th>Bank Name</th>";
            echo "<th>Cheque / DD No.</th>";
            echo "<th>Reciept No./Memo No.</th>";
            echo "<th>Download Reciept</th>";
            echo "<th>Reason</th>";
            echo "<tr>";
            foreach ($getData as $result) {
                $donor_name = $this->cm->getDonorDetailsById($result->DonorId);
                $payment_name = $this->cm->getPaymentModeById($result->PaymentModeId);

                echo "<tr>";
                echo "<td>" . $donor_name[0]->FirstName . ' ' . $donor_name[0]->Name . "</td>";
                echo "<td>" . $result->DisbursedAmt . "</td>";
                echo "<td>" . date("m/d/Y", strtotime($result->DisburesedDate)) . "</td>";
                echo "<td>" . $payment_name[0]->PaymentMode . "</td>";
                echo "<td>" . $result->DisbursedBank . "</td>";
                echo "<td>" . $result->DisbursedRefNo . "</td>";
                echo "<td>" . $result->receipt_no . "</td>";
                echo "<td>" . ((!empty($result->receipt_file)) ? "<a href='" . $result->receipt_file . "' target='_blank'><button class='btn btn-info btn-xs' title='Download Receipt' style='width: 37px;height: 29px;padding: 0px;margin: 4px;margin-bottom: 3px;'><i class='fa fa-download'></i></button></a>" : "") . "</th>";
                echo "<td>" . $result->reason . "</td>";
                echo "<tr>";
            }
            echo "</table>";

            echo $html;
        }
    }

    public function uploadImage($files, $case_id) {
        $folder = FCPATH . 'karoclient/images/disbursed_images/';
        if (!file_exists($folder))
            mkdir($folder, 0777, true);
        $name = $files['reciept_upload']["name"];
        $fileName = $case_id . '_' . date('Y-m-dH:i:s') . '.' . end((explode(".", $name)));
        $config['upload_path'] = $folder;
        $config['allowed_types'] = 'jpg|png|gif|jpeg|bmp|pdf';
        $config['max_size'] = '2048';
        $config['file_name'] = $fileName;
        $this->load->library('upload', $config);
        if (!$this->upload->do_upload('reciept_upload'))
            $data['error'] = $this->upload->display_errors();
        else
            $data = $this->upload->data();

        return $data;
    }

    public function loadRehelp() {

        $get = $this->input->get();
        $documents = $this->patientcase_model->getPatientDocument($get['cid']);
        $doner = $this->cm->getActiveDoner();
        foreach ($doner as $key => $value) {
            $result[$key]['doner_id'] = $value->DonerId;
            $result[$key]['name'] = $value->firstName . ' ' . $value->middleName . ' ' . $value->lastName;
        }

        $data = [];
        if ($get) {
            $patient_id = $get['patient_id'];
            $case_id = $get['cid'];
            $where_data['pcd.patient_id'] = $patient_id;
            $where_data['pcd.id'] = $case_id;

            $data['result'] = $this->cm->getCaseDetails($where_data);
        }
        $data['case_id'] = $get['cid'];
        $data['documents'] = $documents;
        $data['active_doner'] = $result;

        //akash
        $data["rehelp_data"] = $this->cm->getRehelpDataByCaseId($get['cid']);

        $this->load->view('header');
        $this->load->view('cases/rehelp', $data);
        $this->load->view('footer');
    }

    public function saveRehelpDetails() {
        $post = $this->input->post();
        $get = $this->input->get();
        $case_id = $get['cid'];
        $where_data['case_id'] = $case_id;
        $finance_details = $this->cm->selectDataFromTable('patient_financetial_details', ' ', $where_data);
        $patient_case_details = $this->cm->selectDataFromTable('patient_case_details', ' ', array('id' => $case_id, 'patient_id' => $get['patient_id']));

        // history of previous  current_diagnosed_detail 
        $insert_data['case_id'] = $case_id;
        $insert_data['doner_id'] = $post['active_doner'];
        $insert_data['case_status'] = ($patient_case_details[0]->case_status == 'open') ? 'rehelp' : 'reopen';
        $insert_data['approved_amount'] = $post['rehelp_approve_amt'];
        $insert_data['required_fund'] = $post['rehelp_req_amt'];
        $insert_data['rehelp_date'] = $post['rehelp_date'];
        $insert_data['case_status_date'] = date('Y-m-d H:i:s');
        $insert_data['created_by'] = $this->session->userdata('UsertId');
        $insert_data['created_at'] = date('Y-m-d H:i:s');
        $insert_data['case_status_reason'] = $patient_case_details[0]->current_diagnosed_detail;
        $insert_id = $this->cm->insertDataIntoTable('patient_case_status_detail', $insert_data);

        // update current  current_diagnosed_detail

        $update_data['current_diagnosed_detail'] = $post['rehelp_treatment'];
        $update_data['updated_at'] = date('Y-m-d H:i:s');
        if ($patient_case_details[0]->case_status == 'closed')
            $update_data['case_status'] = 'open';
        unset($where_data['case_id']);
        $where_data ['id'] = $case_id;
        $where_data['patient_id'] = $get['patient_id'];
        $this->cm->updateDataIntoTable('patient_case_details', $update_data, $where_data);


        $update_data = array();

        $total_req_amount = $finance_details[0]->required_fund + $post['rehelp_req_amt'];
        $total_approve_amount = $finance_details[0]->approved_amount + $post['rehelp_approve_amt'];

        // update funds 
        $update_data['required_fund'] = $total_req_amount;
        $update_data['approved_amount'] = $total_approve_amount;
        $where_data = array();
        $where_data['case_id'] = $case_id;
        $this->cm->updateDataIntoTable('patient_financetial_details', $update_data, $where_data);

        //update document path 
        //$update_data = array();
        //$update_data['file_urls'] = $post['file_urls'];
        //$this->cm->updateDataIntoTable('patient_documents_details', $update_data, $where_data);
        $file_count = $post['file_count'];
        $caseid = $case_id;
        $rehelp_insert_id = $insert_id;
        //select last n rehelp doc records inserted against case id
        if (!empty($file_count)) {
            $get = $this->cm->getLastNRecordsCaseId($file_count, $caseid);


            if (!empty($get)) {
                foreach ($get as $getres) {
                    $this->cm->updateRehelpDocs($getres->id, $rehelp_insert_id);
                }
            }
        }

        $this->session->set_flashdata('msg', 'Requested Amount updated successfully');
        redirect('patientcase/index?cid=' . $case_id);
    }

    public function getAvaliableAmountDonner() {
        $data = $this->input->post();
        $result = 0;
        if ($data) {
            $res = $this->cm->getDonnerAvailableAmount($data['donner_id']);
            if ($res)
                $result = $res[0]['AmountRemaining'];
        }
        echo $result;
    }

    function displayRehelpDocsList() {
        $title = $this->input->post("case_number");
        //render new html
        $getData = $this->cm->getPatientRehelpFiles($title);

        if (!empty($getData)) {
            $html = "";
            $i = 1;
            foreach ($getData as $res) {

                if (strpos($res->file_url, 'karosoftware.esoftech.in') !== false) {
                    $file_name = str_replace("http://karosoftware.esoftech.in/karoclient/file_uploads/", "", $res->file_url);
                } else {
                    $file_name = str_replace(base_url() . "karoclient/file_uploads/", "", $res->file_url);
                }

                $file_url = $res->file_url;
                $id = $res->id;

                $html .= "<div class='filCol' id='delFile$i'>";
                $html .= "<a class='first' href='$file_url' target='_blank' download title='documents'>" . $file_name . "</a>";
                $html .= '<a href="javascript:void(0)" class="btn btn-danger fa fa-trash-o space last" onclick="remove_file(' . $i . ',' . $id . ',\'' . $file_name . '\');"></a>';
                $html .= "<br/>";
                $html .= "<div class='clearfix'></div>";
                $html .= "</div>";
                $i++;
            }

            echo $html;
        } else {
            echo "1";
        }
    }

    function uploaddocs() {
        $files = $_FILES['uploadfiles'];
        $file_names = $this->input->post("file_names");
        $farr = explode(",", $file_names);

        $title = $this->input->post("cid");
        $pid = $this->input->post("pid");
        $rid = $this->input->post("rid");
        $page = "rehelp";

        $config = array(
            'upload_path' => 'karoclient/file_uploads/',
            'allowed_types' => 'jpg|gif|png|jpeg|html|pdf|txt|csv|doc|docx|xlsx|xls',
            'max_size' => '2048',
        );

        $this->load->library('upload', $config);

//        echo "<pre>";
//        print_r($farr);
//        exit;

        foreach ($files['name'] as $key => $image) {
            $_FILES['uploadfiles[]']['name'] = $files['name'][$key];
            $_FILES['uploadfiles[]']['type'] = $files['type'][$key];
            $_FILES['uploadfiles[]']['tmp_name'] = $files['tmp_name'][$key];
            $_FILES['uploadfiles[]']['error'] = $files['error'][$key];
            $_FILES['uploadfiles[]']['size'] = $files['size'][$key];
            $fileName = $image;

            //check if filename in array
            if (!in_array($fileName, $farr)) {
                $fileName = str_replace(" ", "_", $fileName);
                $final_image = preg_replace("/(\.)(?=\S+\.)/", "_", $fileName);
                $images[] = base_url() . 'karoclient/file_uploads/' . $final_image;
                $insert_val = base_url() . 'karoclient/file_uploads/' . ($title . $final_image);

                //check if document already exists
                $check = $this->patientcase_model->checkPatientDocumentRehelp($page, $title, $insert_val, $rid);

                if (count($check) == 0) {
                    $this->patientcase_model->insertPatientDocumentRehelp($page, $title, $insert_val, $rid);
                }

                $config['file_name'] = $title . $fileName;
                $this->upload->initialize($config);
                if ($this->upload->do_upload('uploadfiles[]')) {
                    $data = $this->upload->data();
                } else {
                    
                }
            }
        }

        $this->session->set_flashdata('msg1', 'Files uploaded successfully');
        header("Location:" . base_url() . "index.php/Caseinfo/loadRehelp?patient_id=" . $pid . "&cid=" . $title . "&rid=" . $rid);
    }

    function editrehelp() {
        $get = $this->input->get();
        $documents = $this->patientcase_model->getPatientDocument($get['cid']);
        $doner = $this->cm->getActiveDoner();
        foreach ($doner as $key => $value) {
            $result[$key]['doner_id'] = $value->DonerId;
            $result[$key]['name'] = $value->firstName . ' ' . $value->middleName . ' ' . $value->lastName;
        }

        $data = [];
        if ($get) {
            $patient_id = $get['patient_id'];
            $case_id = $get['cid'];
            $where_data['pcd.patient_id'] = $patient_id;
            $where_data['pcd.id'] = $case_id;

            $data['result'] = $this->cm->getCaseDetails($where_data);
        }
        $data['case_id'] = $get['cid'];
        $data['documents'] = $documents;
        $data['active_doner'] = $result;

        //akash
        $data["rehelp_data"] = $this->cm->getRehelpDataByCaseId($get['cid']);

        $id = $this->input->get("rid");

        $data["res"] = $this->cm->getRehelpDataById($id);

        $this->load->view('header');
        $this->load->view('cases/rehelp_edit', $data);
        $this->load->view('footer');
    }

    function updateRehelpDetails() {
        $get = $this->input->get();
        $post = $this->input->post();

        $documents = $this->patientcase_model->getPatientDocument($get['cid']);
        $doner = $this->cm->getActiveDoner();
        foreach ($doner as $key => $value) {
            $result[$key]['doner_id'] = $value->DonerId;
            $result[$key]['name'] = $value->firstName . ' ' . $value->middleName . ' ' . $value->lastName;
        }

        $data = [];
        if ($get) {
            $patient_id = $get['patient_id'];
            $case_id = $get['cid'];
            $where_data['pcd.patient_id'] = $patient_id;
            $where_data['pcd.id'] = $case_id;

            $data['result'] = $this->cm->getCaseDetails($where_data);
        }
        $data['case_id'] = $get['cid'];
        $data['documents'] = $documents;
        $data['active_doner'] = $result;

        //akash
        $data["rehelp_data"] = $this->cm->getRehelpDataByCaseId($get['cid']);

        $id = $this->input->get("rid");
        //prx($id);
        $darr = array(
            'doner_id' => $post['active_doner'],
            'approved_amount' => $post['rehelp_approve_amt'],
            'required_fund' => $post['rehelp_req_amt'],
            'rehelp_date' => $post['rehelp_date'],
            'case_status_reason' => $post["rehelp_treatment"]
        );

        $this->cm->updateRehelpData('patient_case_status_detail', $darr, $id);
        $this->cm->updateRehelpFinancial($get['cid']);
        //prx($this->cm-> updateRehelpFinancial($id));
        $data["rehelp_data"] = $this->cm->getRehelpDataByCaseId($get['cid']);


        $data["res"] = $this->cm->getRehelpDataById($id);

        $this->session->set_flashdata('message', 'Record updated successfully');

        $this->load->view('header');
        $this->load->view('cases/rehelp_edit', $data);
        $this->load->view('footer');
    }
	
	
	 public function loadRehelpDetails() {

        $get = $this->input->get();
        $documents = $this->patientcase_model->getPatientDocument($get['cid']);
        $doner = $this->cm->getActiveDoner();
        foreach ($doner as $key => $value) {
            $result[$key]['doner_id'] = $value->DonerId;
            $result[$key]['name'] = $value->firstName . ' ' . $value->middleName . ' ' . $value->lastName;
        }

        $data = [];
        if ($get) {
            $patient_id = $get['patient_id'];
            $case_id = $get['cid'];
            $where_data['pcd.patient_id'] = $patient_id;
            $where_data['pcd.id'] = $case_id;

            $data['result'] = $this->cm->getCaseDetails($where_data);
        }
        $data['case_id'] = $get['cid'];
        $data['documents'] = $documents;
        $data['active_doner'] = $result;

        //akash
        $data["rehelp_data"] = $this->cm->getRehelpDataByCaseId($get['cid']);

        $this->load->view('header');
        $this->load->view('cases/edit_sanction_details', $data);
        $this->load->view('footer');
    }
	
	
	function updateSanctionDetails() {
        $get = $this->input->get();
        $post = $this->input->post();
		//$patient_id = $post['approve_amt'];
		
	//	echo $patient_id;
		
		//prx($patient_id);
	
        $documents = $this->patientcase_model->getPatientDocument($post['case_number']);
		//prx($get['case_number']);
        $doner = $this->cm->getActiveDoner();
        foreach ($doner as $key => $value) {
            $result[$key]['doner_id'] = $value->DonerId;
            $result[$key]['name'] = $value->firstName . ' ' . $value->middleName . ' ' . $value->lastName;
        }

        $data = [];
        if ($get) {
            $patient_id = $get['patient_id'];
            $case_id = $post['case_number'];
            $where_data['pcd.patient_id'] = $patient_id;
            $where_data['pcd.id'] = $case_id;

            $data['result'] = $this->cm->getCaseDetails($where_data);
        }
        $data['case_id'] = $post['case_number'];
        $data['documents'] = $documents;
        $data['active_doner'] = $result;

        //akash
        $data["rehelp_data"] = $this->cm->getRehelpDataByCaseId($post['case_number']);

        $id = $this->input->post("edit_id");
       // prx($id);
	   //prx($post['doner_id']);
        $darr = array(
            'doner_id' => $post['doner_id'],
            'approved_amount' => $post['approve_amt'],
            'rehelp_date' => $post['rehelp_date'],
        );

        $this->cm->updateRehelpData('patient_case_status_detail', $darr, $id);
        $this->cm->updateRehelpFinancial($post['case_number']);
        //prx($this->cm-> updateRehelpFinancial($id));
        $data["rehelp_data"] = $this->cm->getRehelpDataByCaseId($post['case_number']);


        $data["res"] = $this->cm->getRehelpDataById($id);

        //$this->session->set_flashdata('message', 'Record updated successfully');
		 echo json_encode(array('msg' => 'Record updated successfully', 'class' => 'alert alert-success', 'status' => 'success'));

        // $this->load->view('header');
        // $this->load->view('cases/edit_sanction_details', $data);
        // $this->load->view('footer');
    }
	
	
	     function checkIsRefund() {
        $donor_id = $this->input->post("str_donor_id");

        //get case state
        $getRefund = $this->cm->getRefund($donor_id);
        echo $getRefund[0]->donor_id ;
		//echo $getRefund[0]->is_refund ;
      
       // echo $getState[0]->case_status;
    }

}

?>
