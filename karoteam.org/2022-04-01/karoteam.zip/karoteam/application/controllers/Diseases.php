<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Diseases extends CI_Controller {

    public function __construct() {
        parent::__construct();
        if (!$this->session->userdata('UsertId')) {
            redirect('login');
        }
        // else if (empty($this->session->userdata('IsAdmin'))) {
        //     redirect('dashboard');
        // }
		
        $this->load->library('form_validation');
        $this->load->library('encrypt');
        $this->load->model('diseases_model');
    }

    function index() {
        /* Check submit button */
        if ($this->input->post('save')) {
            $diseases_name = trim($this->input->post('diseases_name'));
            if ($diseases_name != '') {
                $save = $this->diseases_model->saveDisease($diseases_name);
                $this->session->set_flashdata('message', $save);
            } else {
                $this->session->set_flashdata('message', '<div class="alert alert-danger">Please enter disease name</div>');
            }
        }
        $getDisease = $this->diseases_model->getDisease();
        $getDiseaseData['diseases'] = $getDisease;
        $this->load->view('header');
        $this->load->view('diseases/index', $getDiseaseData);
        $this->load->view('footer');
    }

    function changestatus() {
        if ($_REQUEST['id'] != '') {
            $id = base64_decode($_REQUEST['id']);
            if ($_REQUEST['status'] == 1) {
                $status = 0;
            } else {
                $status = 1;
            }
            $save = $this->diseases_model->changeStatus($id, $status);
            $this->session->set_flashdata('message', $save);
            redirect('diseases');
        }
    }

    function changediseasesName() {
        if ($this->input->post('save')) {
            $diseases_name = ltrim($this->input->post('diseases_name'));
            $diseases_id = base64_decode($this->input->post('diseases_id'));
            if ($diseases_name != '' && $diseases_id != '') {
                $save = $this->diseases_model->changeDiseasesName($diseases_name, $diseases_id);
                $this->session->set_flashdata('message', $save);
            }
            redirect('diseases');
        }
    }

}

?>
