<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->library('form_validation');
        $this->load->library('encrypt', 'email');
        $this->load->library(array('session', 'form_validation', 'email', 'calendar'));
        $this->load->model('Login_model','login_model');
    }

    function index() {
        if ($this->session->userdata('UsertId')) {
            redirect('diseases');
        }

        $this->load->view('login/index');
    }

    //For Login & validation written By Rizwan 
    function validation() {
        $this->form_validation->set_rules('user_email', 'Email Address', 'required|trim|valid_email');
        $this->form_validation->set_rules('user_password', 'Password', 'required');
        if ($this->form_validation->run()) {
            $result = $this->login_model->can_login($this->input->post('user_email'), $this->input->post('user_password'));
            if ($result == '') {
                //$this->session->set_flashdata('message', '<div class="alert alert-success">login successfully</div>');
               // if ($this->session->userdata('IsAdmin') == 1) {
                 //   redirect('diseases');
                //} else {
                  //  redirect('dashboard');
                //}
				redirect('dashboard');
				
            } else {
                $this->session->set_flashdata('message', $result);
                redirect('login');
            }
        } else {
            $this->index();
        }
    }

    function logout() {
        $this->session->sess_destroy();
        $this->session->set_flashdata('message', '<div class="alert alert-success">Logout successfully</div>');
        redirect('login');
    }

    function forgotpassword() {
        $reseult = $this->login_model->checkemailforresetpass($this->input->post('forgetemail'));
        if ($reseult) {
            $rand = rand(11111, 99999);
            $rand = md5($rand . date('Y-m-d H:s:i'));
            $email = base64_encode($this->input->post('forgetemail'));
            $veryfylink = $email . "___" . $rand;
            // $message = "Click here to reset password <a href='" . site_url() . "/login/resetpassword?id=" . $veryfylink . "'>Click</a>";
            $link['veryfylink'] = $veryfylink;
            $link['email']=$this->input->post('forgetemail');
            $message= $this->load->view('reset_password', $link, true);
            // prx($message);
            $updatedata = array('randomno' => $rand);
            $this->db->where('UserId', $reseult);
            $this->db->update('usermaster', $updatedata);
            $config['protocol'] = 'smtp';
            $config['smtp_host'] = 'ssl://smtp.gmail.com'; //smtp host name
            $config['smtp_port'] = 465; //smtp port number
            $config['smtp_user'] = 'esoft4usr2@gmail.com';
            $config['smtp_pass'] = 'Esoft1234'; //$from_email password
            $config['mailtype'] = 'html';
            $config['charset'] = 'iso-8859-1';
            $config['wordwrap'] = TRUE;
            $config['newline'] = "\r\n"; //use double quotes
            $this->email->initialize($config);

            //send mail
            $from_email = "rizwankamalsiddiqui@gmail.com";
            $this->email->from($from_email, 'karo');
            $this->email->to($this->input->post('forgetemail'));
            $this->email->subject('Karo reset password');
            $this->email->message($message);
            $this->email->send();
            $this->session->set_flashdata('message', '<div class="alert alert-success">Reset password link has been sent your registered email id</div>');
        } else {
            $this->session->set_flashdata('message', "<div class='alert alert-danger'>You have enter wrong email id</div>");
        }
        redirect('login');
    }

    function resetpassword() {
        $idexplode = explode("___", $_REQUEST['id']);
        if ($this->login_model->checkran($idexplode[1])) {
            if ($this->input->post('rpassword')) {
                $updatedata = array('randomno' => '', 'Password' => md5($this->input->post('rpassword')));
                $this->db->where('PrimaryEmailId', base64_decode($idexplode[0]));
                $this->db->update('usermaster', $updatedata);
                $this->session->set_flashdata('message', '<div class="alert alert-success">Password save successfully</div>');
                redirect('login');
            }
        } else {
            redirect('login');
        }
        $this->load->view('login/reset');
        $this->load->view('footer');
    }

}

?>
