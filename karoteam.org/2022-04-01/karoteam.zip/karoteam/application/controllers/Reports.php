<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Reports extends CI_Controller {

    public function __construct() {
        parent::__construct();
        if (!$this->session->userdata('UsertId')) {
            redirect('login');
        }
        $this->load->library('form_validation');
        $this->load->model('report_model', 'rm');
        $this->load->model('case_model', 'cm');
    }

    /**
     * Patient Details
     */
    public function getPatientsReports() {
        $post = $this->input->post();
        if ($post['save']) {
            $patient_details = $this->rm->getPatientsReportDetails($post);
            $data['result'] = $patient_details;
            $data['patient_name'] = $post['patient_name'];
            $data['karo'] = $post['karo_no'];
            $data['reg_date'] = $post['reg_date'];

            if ($data['result']) {
                $this->session->set_flashdata('msg', '<div class="alert alert-success"> Patient details fetch successfully</div>');
            } else {
                $this->session->set_flashdata('msg', '<div class="alert alert-danger"> Record not found </div>');
            }
        }
        $this->load->model('hospital_model', 'hm');
        $this->load->model('Donner_model', 'Donner');
        $data['active_department'] = $this->hm->getActiveDept();
        $data['active_hospital'] = $this->hm->getactivehospital();
        $data['donnerlist'] = $this->Donner->getdonnerlist();

        $this->load->view('header');
        $this->load->view('reports/patient_details', $data);
        $this->load->view('footer');
    }

    /**
     * Patient Wise Details By Ajax
     */
    public function ajaxPatientDetails() {
        $post = $this->input->post();

        $result = array();
        $patient_details = $this->rm->getPatientsReportDetails($post);
        foreach ($patient_details as $key => $value) {
            // implode(',', array_values($value ))
            $result[] = array_values($value);
        }
//        prx($patient_details);
//        exit;

        if ($patient_details) {
            echo json_encode(array('status' => 'success', 'data' => $result));
        } else
            echo json_encode(array('status' => 'failure', 'data' => $patient_details));
    }

    /**
     * Donor Wise Patient Details
     */
    public function getDonorWisePatientDetails() {
        $post = $this->input->post();
        $data['active_donor'] = $this->cm->getActiveDoner();
        
        if ($post['save']) {
            $donorWisePatientDetails = $this->rm->getDonorWisePatientsReportDetails($post);
            $data['result'] = $donorWisePatientDetails;
            $data['patient_name'] = $post['patient_name'];
            $data['karo'] = $post['karo_no'];
            $data['reg_date'] = $post['reg_date'];
            $data['selected_donor'] = $post['donor'];
            
            if ($data['result']) {
                $this->session->set_flashdata('msg', '<div class="alert alert-success"> Donor Wise Patient details fetch successfully</div>');
            } else {
                $this->session->set_flashdata('msg', '<div class="alert alert-danger"> Record not found </div>');
            }
        }
        $this->load->model('hospital_model', 'hm');
        $data['active_department'] = $this->hm->getActiveDept();
        $data['active_hospital'] = $this->hm->getactivehospital();

        $this->load->view('header');
        $this->load->view('reports/donor_wise_patient_details', $data);
        $this->load->view('footer');
    }

    /**
     * Donor Wise Patient Details By Ajax
     */
    public function getAjaxDonorWisePatientDetails() {
        $result = array();
        $post = $this->input->post();
        $patient_details = $this->rm->getDonorWisePatientsReportDetailsNew($post);
        foreach ($patient_details as $key => $value) {
            $result[] = array_values($value);
        }

        if ($patient_details) {
            echo json_encode(array('status' => 'success', 'data' => $result));
        } else {
            echo json_encode(array('status' => 'failure', 'data' => $patient_details));
        }
    }

    /**
     * Case Wise Patient Details
     */
    public function getPatientsCaseReports() {
        $post = $this->input->post();
        if ($post['save']) {
            $caseWisePatientDetails = $this->rm->getCaseWisePatientsReport($post);
            $data['result'] = $caseWisePatientDetails;
            $data['patient_name'] = $post['patient_name'];
            $data['karo'] = $post['karo_no'];
            $data['reg_date'] = $post['reg_date'];

            if ($data['result']) {
                $this->session->set_flashdata('msg', '<div class="alert alert-success"> Case Wise Patient details fetch successfully</div>');
            } else {
                $this->session->set_flashdata('msg', '<div class="alert alert-danger"> Record not found </div>');
            }
        }
        $this->load->model('hospital_model', 'hm');
        $this->load->model('Donner_model', 'Donner');
        $data['active_department'] = $this->hm->getActiveDept();
        $data['active_hospital'] = $this->hm->getactivehospital();
        $data['donnerlist'] = $this->Donner->getdonnerlist();

        $this->load->view('header');
        $this->load->view('reports/case_wise_patient_details', $data);
        $this->load->view('footer');
    }

    /**
     * Case Wise Patient Details By Ajax
     */
    public function getAjaxPatientsCaseReports() {
        $post = $this->input->post();

        $result = array();
        $patient_details = $this->rm->getCaseWisePatientsReport($post);
        foreach ($patient_details as $key => $value) {
            $result[] = array_values($value);
        }

        if ($patient_details) {
            echo json_encode(array('status' => 'success', 'data' => $result));
        } else {
            echo json_encode(array('status' => 'failure', 'data' => $patient_details));
        }
    }

    /**
     * Patient Wise Financial Reports
     */
    public function getPatientsWiseFinacialReports() {
        $post = $this->input->post();
        $data['active_donor'] = $this->cm->getActiveDoner();
        if ($post['save']) {
            $patient_details = $this->rm->getPatientsWiseFinacialReports($post);
            $data['result'] = $patient_details;
            $data['from_date'] = $post['from_date'];
            $data['to_date'] = $post['to_date'];
            $data['patient_name'] = $post['patient_name'];
            $data['karo'] = $post['karo_no'];
            $data['reg_date'] = $post['reg_date'];
            $data['selected_donor'] = $post['donor'];
            if ($data['result'])
                $this->session->set_flashdata('message', '<div class="alert alert-success"> Patient Finacial details fetch successfully</div>');
            else
                $this->session->set_flashdata('message', '<div class="alert alert-danger"> Record not found </div>');
        }
        $this->load->model('hospital_model', 'hm');
        $data['active_department'] = $this->hm->getActiveDept();
        $data['active_hospital'] = $this->hm->getactivehospital();

        $this->load->view('header');
        $this->load->view('reports/patientwise_finacial_details', $data);
        $this->load->view('footer');
    }

    /**
     * Get Donor Wise Financial Details
     */
    public function getPatientsDonorWiseFinacialReports() {
        $post = $this->input->post();
        $data['active_donor'] = $this->cm->getActiveDoner();

        if ($post['save']) {
            $patient_details = $this->rm->getPatientsDonorWiseFinacialReports($post);
            $data['result'] = $patient_details;
            $data['total_donation_amount'] = $this->rm->getDonorWiseDonationAmount($post);
            $data['total_approved_amount'] = $this->rm->getDonorWiseApprovedAmount($post);
            $data['total_disbursed_amount'] = $this->rm->getDonorWiseDisbursedAmount($post);
            $data['from_date'] = $post['from_date'];
            $data['to_date'] = $post['to_date'];
            $data['patient_name'] = $post['patient_name'];
            $data['karo'] = $post['karo_no'];
            $data['reg_date'] = $post['reg_date'];
            $data['selected_donor'] = $post['donor'];
            foreach ($data['active_donor'] as $key => $value) {
                if ($value->DonerId == $post['donor']) {
                    $data['donor'] = $value->firstName . ' ' . $value->middleName . ' ' . $value->lastName;
                    break;
                }
            }

            if ($data['result']) {
                $this->session->set_flashdata('message', '<div class="alert alert-success"> Patient Donor wise Finacial details fetch successfully</div>');
            } else {
                $this->session->set_flashdata('message', '<div class="alert alert-danger"> Record not found </div>');
            }
        }
        $this->load->model('hospital_model', 'hm');
        $data['active_department'] = $this->hm->getActiveDept();
        $data['active_hospital'] = $this->hm->getactivehospital();

        $this->load->view('header');
        $this->load->view('reports/patient_donor_wise_details', $data);
        $this->load->view('footer');
    }

    public function generatePatientExcelReport() {
        $post = $this->input->get();

        if ($post['report_type'] == 'patient') {
            $patient_details = $this->rm->getPatientsReportDetails($post);
        } else if ($post['report_type'] == 'case') {
            $patient_details = $this->rm->getCaseWisePatientsReport($post);
        } else if ($post['report_type'] == 'donor') {
            $patient_details = $this->rm->getDonorWisePatientsReportDetails($post);
        }

        if ($patient_details) {
            foreach (array_keys($patient_details[0]) as $key => $value) {
                $result[$value] = array_column($patient_details, $value);
                array_unshift($result[$value], $value);
            }
            $pt_filename = 'PatientDetails_From_' . $post['from_date'] . '_To_' . $post['to_date'] . '.xls';
            header("Content-Disposition: attachment; filename=$pt_filename");
            header("Content-Type: application/vnd.ms-excel;");
            header("Pragma: no-cache");
            header("Expires: 0");
            $out = fopen("php://output", 'w');
            foreach ($result as $data) {
                fputcsv($out, $data, "\t");
            }
            fclose($out);
        }
    }

    function filterPatientsDonorWiseFinacialReports() {
        $post = $this->input->get();
        $data["label"] = $this->input->get("label");
        $data['active_donor'] = $this->cm->getActiveDoner();

        $patient_details = $this->rm->getPatientsDonorWiseFinacialReports($post);
        $data['result'] = $patient_details;
        $data['total_donation_amount'] = $this->rm->getDonorWiseDonationAmount($post);
        $data['total_approved_amount'] = $this->rm->getDonorWiseApprovedAmount($post);
        //$data['total_disbursed_amount'] = $this->rm->getDonorWiseDisbursedAmount($post);
		$data['total_disbursed_amount'] = $this->rm->filterDonorWiseDisbursedAmount($post);
        $data['from_date'] = $post['from_date'];
        $data['to_date'] = $post['to_date'];
        $data['patient_name'] = $post['patient_name'];
        $data['karo'] = $post['karo_no'];
        $data['reg_date'] = $post['reg_date'];
        $data['selected_donor'] = $post['donor'];
        foreach ($data['active_donor'] as $key => $value) {
            if ($value->DonerId == $post['donor']) {
                $data['donor'] = $value->firstName . ' ' . $value->middleName . ' ' . $value->lastName;
                break;
            }
        }

        if ($data['result']) {
            $this->session->set_flashdata('message', '<div class="alert alert-success"> Patient Donor wise Finacial details fetch successfully</div>');
        } else {
            $this->session->set_flashdata('message', '<div class="alert alert-danger"> Record not found </div>');
        }

        $this->load->view('header');
        $this->load->view('reports/filterPatientsDonorWiseFinacialReports', $data);
        $this->load->view('footer');
    }
	
	 public function getDeleteDisbursedReports() {
        $post = $this->input->post();
        $data['active_donor'] = $this->cm->getActiveDoner();
        if ($post['save']) {
            $patient_details = $this->rm->getDeleteDisbursedReports($post);
            $data['result'] = $patient_details;
            $data['from_date'] = $post['from_date'];
            $data['to_date'] = $post['to_date'];
            $data['selected_donor'] = $post['donor'];
            if ($data['result'])
                $this->session->set_flashdata('message', '<div class="alert alert-success">Delete Disbursed Details fetch successfully</div>');
            else
                $this->session->set_flashdata('message', '<div class="alert alert-danger"> Record not found </div>');
        }
        $this->load->model('hospital_model', 'hm');
        $data['active_department'] = $this->hm->getActiveDept();
        $data['active_hospital'] = $this->hm->getactivehospital();

        $this->load->view('header');
        $this->load->view('reports/delete_disbursal_detail', $data);
        $this->load->view('footer');
    }

}
