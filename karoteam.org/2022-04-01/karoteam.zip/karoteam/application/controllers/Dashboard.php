<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends CI_Controller {

    public function __construct() {
        parent::__construct();
        if (!$this->session->userdata('UsertId')) {
            // redirect('login');
        }
        $this->load->library('form_validation');
        $this->load->library('encrypt');
        $this->load->model('login_model');
        $this->load->model('dashboard_model', 'dm');
        $this->load->model('case_model', 'cm');
    }

    function index() {
        $count = $this->dm->getCaseCounts();
        $cnt = $this->dm->getcnt();

        $sum = array_sum(array_column($count, 'count'));
        $data['count'] = array();
        if ($count)
        // foreach ($count as $key => $value) {
        //     $data['count'][$value['case_status']] = $value['count'];
        //     $data['count']['all'] = $data['count']['all'] + $value['count'];
        //     $data['pie_chart'][]=array('label'=>$value['case_status'] , 'y'=> $value['count']);
        // }
            foreach ($count as $key => $cv) {
                $data['count'][$cv['case_status']] = $cv['count'];
                $data['count']['all'] = $data['count']['all'] + $cv['count'];
                $case_label[] = $cv['case_status'];
                // $case_dataset ['label']= 'case_chart';
                $case_dataset['backgroundColor'][] = '#' . $this->random_color();
                // $case_dataset['data'][]=round(($cv['count']*100)/$sum);
                $case_dataset['data'][] = $cv['count'];
                // $case_dataset['borderColor'][]=array('black');
                // $case_dataset['borderWidth'][]= array(2,2);
            }
        $data['case_label'] = json_encode($case_label);
        $data['case_datasets'] = json_encode(array($case_dataset));

        // Age Chart
        $patinetAgeInfo = $this->dm->getAgeChartInfo();
        if (count($patinetAgeInfo) > 0) {
            foreach ($patinetAgeInfo as $ageInfo) {
				
                if ($ageInfo['AgeGroup'] == '30/30+') {
                    $ageId[] = '30/30';
                } else {
                    $ageId[] = $ageInfo['AgeGroup'];
                }
				
                $ageLables[] = $ageInfo['AgeGroup'];
                $ageDataset['backgroundColor'][] = '#' . $this->random_color();
                $ageDataset['data'][] = $ageInfo['TotalPatient'];
				
            }
            $data['age_id'] = json_encode($ageId);
            $data['ageLabels'] = json_encode($ageLables);
            $data['ageDatasets'] = json_encode(array($ageDataset));

        }

        //Age Chart 2
        // $patinetAgeInfo2 = $this->dm->getAgeChartInfo2();

        // if (count($patinetAgeInfo2) > 0) {
            // foreach ($patinetAgeInfo2 as $ageInfo2) {
                // if ($ageInfo2['AgeGroup'] == '30/30+') {
                    // $ageId2[] = '30/30';
                // } else {
                    // $ageId2[] = $ageInfo2['AgeGroup'];
                // }
                // $ageLables2[] = $ageInfo2['AgeGroup'];
                // $ageDataset2['backgroundColor'][] = '#' . $this->random_color();
                // $ageDataset2['data'][] = $ageInfo2['TotalPatient'];
            // }
            // $data['age_id2'] = json_encode($ageId2);
            // $data['ageLabels2'] = json_encode($ageLables2);
            // $data['ageDatasets2'] = json_encode(array($ageDataset2));
        // }

        // Gender Chart
        $patinetGenderInfo = $this->dm->getGenderChartInfo();
        if (count($patinetGenderInfo) > 0) {
            foreach ($patinetGenderInfo as $genderInfo) {
                $genderLables[] = $genderInfo['patient_gender'];
                $genderDataset['backgroundColor'][] = '#' . $this->random_color();
                $genderDataset['data'][] = $genderInfo['total'];
            }
            $data['gender'] = json_encode($genderLables);
            $data['genderLabels'] = json_encode($genderLables);
            $data['genderDataset'] = json_encode(array($genderDataset));
        }

        // State Chart Data
        $patinetStateInfo = $this->dm->getStateChartInfo();
        // echo "<pre>"; print_r($patinetStateInfo); exit;
        if (count($patinetStateInfo) > 0) {
            foreach ($patinetStateInfo as $stateInfo) {
                $stateId[] = $stateInfo['state_id'];
                $stateLabel[] = $stateInfo['patinet_state'];
                $stateDataset ['label'] = 'Number of patients';
                $stateDataset['backgroundColor'][] = '#' . $this->random_color();
                $stateDataset['data'][] = $stateInfo['total'];
            }

            $data['state_id'] = json_encode($stateId);
            $data['stateLabels'] = json_encode($stateLabel);
            $data['stateCount'] = json_encode(array($stateDataset));
        }

        // Disease Chart
        $disease_count = $this->dm->getDiseaseCount();
        foreach ($disease_count as $key => $value) {
            $diseaseId[] = $value->DeptId;
            $disease_label[] = $value->DiseaseName;
            $disease_dataset ['label'] = 'Number of patients';
            $disease_dataset['data'][] = $value->patient_count;
            $disease_dataset['backgroundColor'][] = '#' . $this->random_color();
        }
        $data['disease_id'] = json_encode($diseaseId);
        $data['disease_label'] = json_encode($disease_label);
        $data['disease_datasets'] = json_encode(array($disease_dataset));

        // Hospital Chart
        $hospital_count = $this->dm->getHospitalCount();
        foreach ($hospital_count as $key => $v) {
            $hospital_label[] = $v['name'];
            $hospitalId[] = $v['hospital_id'];
            $hospital_dataset['data'][] = $v['patient_count'];
            $hospital_dataset ['label'] = 'Number of patients';
            $hospital_dataset['backgroundColor'][] = '#' . $this->random_color();
        }

        $data['hospital_id'] = json_encode($hospitalId);
        $data['hospital_label'] = json_encode($hospital_label);
        $data['hospital_datasets'] = json_encode(array($hospital_dataset));
		//prx($data );

        // User Chart
        $user_count = $this->dm->getUserCount();
        foreach ($user_count as $key => $v) {
            $user_label[] = $v->re_name;
            $userId[] = $v->UserId;
            $user_dataset['data'][] = $v->patient_count;
            $user_dataset ['label'] = 'Number of patients';
            $user_dataset['backgroundColor'][] = '#' . $this->random_color();
        }

        $data['user_id'] = json_encode($userId);
        $data['user_label'] = json_encode($user_label);
        $data['user_datasets'] = json_encode(array($user_dataset));
		
		
		    // deepa.....create donor Chart
		        // $donor_count = $this->dm->getDonorDonationAmount();
        // foreach ($donor_count as $key => $v) {
            // $donor_label[] = $v->Doners;
           // $donorId[] = $v->doner_ids;
            // $donor_dataset_donate['data'][]= $v->Total_DonateAmount;
            // $donor_dataset_donate ['label'] = 'Total Donated Amount';
            // $donor_dataset_donate['backgroundColor'] = '#808000' ;
        // }	
			
         // $donor_count = $this->dm->getDonorApprovedAmount();
        // foreach ($donor_count as $key => $v) {
      
            // $donor_dataset['data'][] = $v->donor_approved_amount;
            // $donor_dataset ['label']= 'Total Approved Amount';
            // $donor_dataset['backgroundColor'] = '#FF8C00'  ;
        // }


        // $donor_count = $this->dm->getDonorDisbursedAmount();
        // foreach ($donor_count as $key => $v) {
         
            // $donor_dataset_disburs['data'][] = $v->BalanceAmount;
            // $donor_dataset_disburs ['label'] = 'Balance Amount';
            // $donor_dataset_disburs['backgroundColor'] = '#6495ED' ;
        // }
		
		 $donor_count = $this->dm->getDonorAmountDetail();
        foreach ($donor_count as $key => $v) {
           $donor_label[] = trim($v->Doners);
		   
           $donorId[] = $v->doner_ids;
		   
            $donor_dataset_donate['data'][]= $v->Total_DonateAmount;
           		
		   $donor_dataset_approve['data'][] = $v->approved_amount;
			
			 $donor_dataset_balence['data'][] = $v->BalanceAmount;
			 
			 $donor_dataset_disburs['data'][] = $v->disbursed_amount;
			 
        }
		   $donor_dataset_donate ['label'] = 'Total Donated Amount';
           $donor_dataset_donate['backgroundColor'] = '#608000' ;
		    $donor_dataset_donate['type']= "bar";
            $donor_dataset_donate['stack']= "Sensitivity"; //Base
			
			
             $donor_dataset_approve['label']= 'Total Approved Amount';
             $donor_dataset_approve['backgroundColor'] = '#AA5C00'  ;
			$donor_dataset_approve['type']= "bar";
            $donor_dataset_approve['stack']= "Sensitivity";
			
            $donor_dataset_balence ['label'] = 'Balance Amount';
            $donor_dataset_balence['backgroundColor'] = '#6495ED' ;
			$donor_dataset_balence['type']= "bar";
            $donor_dataset_balence['stack']= "Sensitivity";
			
			$donor_dataset_disburs ['label'] = 'Total Disbursed Amount';
            $donor_dataset_disburs['backgroundColor'] = '#FF8C00' ;
			$donor_dataset_disburs['type'] = "bar";
            $donor_dataset_disburs['stack'] ="Sensitivity";
			

        $data['donor_id'] = json_encode($donorId);
        $data['donor_label'] =  json_encode($donor_label);
        $data['donor_datasets'] = json_encode(array($donor_dataset_donate,$donor_dataset_approve,$donor_dataset_disburs,$donor_dataset_balence));
		//$data['donor_datasetss'] = json_encode($donor_dataset_disburs);
		//$data['donor_datasetsss'] = json_encode($donor_dataset_balence);
		
		//prx($data['donor_label']);
		 // exit;

        $data['follow_up'] = $this->upcomingFollowUpData();
        // $data['upcoming_birdays'] =$this->dm->getUpcomingBirthdays();

        $data["cnt"] = $cnt[0]->COUNT;
        $this->load->view('header');
        $this->load->view('dashboard/index', $data);
        $this->load->view('footer');
    }
	
	

    function random_color_part() {
        return str_pad(dechex(mt_rand(0, 255)), 2, '0', STR_PAD_LEFT);
    }

    function random_color() {
        return $this->random_color_part() . $this->random_color_part() . $this->random_color_part();
    }

    function upcomingFollowUpData() {
        $patient_details = $this->cm->getOpenCaseDetails($params);
        $follow_up = $this->cm->getNextFollowupDate(1);

        if ($follow_up) {
            foreach ($follow_up as $key => $value) {
                foreach ($patient_details as $k => $v) {
                    if ($value['case_id'] == $v['id']) {
                        $follow_up[$key] = $v;
                        $follow_up[$key]['follow_up_done'] = $value['folowup_done'] == 1 ? 'YES' : 'NO';
                        $follow_up[$key]['next_followup_date'] = $value['next_followup_date'];

                        break;
                    }
                }
            }
        }
        return $follow_up;
    }

    function upcomingBirthdays() {

        if (isset($_POST["filter"])) {
            $data["f"] = $_POST["filter"];
        } else {
            $data["f"] = date('m');
        }

        $data['upcoming_birdays'] = $this->dm->getUpcomingBirthdays($data["f"]);

        $this->load->view('header');

        $this->load->view('dashboard/birthday', $data);
        $this->load->view('footer');
        // prx($data);
    }

}

?>
