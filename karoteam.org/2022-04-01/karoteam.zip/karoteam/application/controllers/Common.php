<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Common extends CI_Controller {

    public function __construct() {
        parent::__construct();
        if (!$this->session->userdata('UsertId')) {
            redirect('login');
        }
        $this->load->model('referredby_model');
    }

    function citiesByState() {
        $state = $_REQUEST['state'];
        if ($_REQUEST['cityid'] != '') {
            $cityname = $_REQUEST['cityid'];
        } else {
            $cityname = '';
        }
        $getcities = $this->referredby_model->getcities($state);
        echo "<option value=''>--Select City--</option>";
        foreach ($getcities as $city) {
            if ($city['city_name'] == $cityname) {
                $selected = "selected='selected'";
            } else {
                $selected = '';
            }
            echo "<option value='" . $city['city_name'] . "' " . $selected . ">" . $city['city_name'] . "</option>";
        }
    }

}

?>
