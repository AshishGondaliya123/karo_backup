<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Location extends CI_Controller {

    public function __construct() {
        parent::__construct();
        if (!$this->session->userdata('UsertId')) {
            redirect('login');
        } else if (empty($this->session->userdata('IsAdmin'))) {
            redirect('dashboard');
        }
        $this->load->library('form_validation');
        $this->load->library('encrypt');
        $this->load->model('location_model');
    }

    function index() {
        /* Check submit button */
        if ($this->input->post('save')) {
            $location_name = trim($this->input->post('location_name'));
            if ($location_name != '') {
                $save = $this->location_model->savelocation($location_name);
                $this->session->set_flashdata('message', $save);
            } else {
                $this->session->set_flashdata('message', '<div class="alert alert-danger">Please enter location name</div>');
            }
        }
        $getlocation = $this->location_model->getlocation();
        $getlocationData['location'] = $getlocation;
        $this->load->view('header');
        $this->load->view('location/index', $getlocationData);
        $this->load->view('footer');
    }

    function changestatus() {
        if ($_REQUEST['id'] != '') {
            $id = base64_decode($_REQUEST['id']);
            if ($_REQUEST['status'] == 1) {
                $status = 0;
            } else {
                $status = 1;
            }
            $save = $this->location_model->changeStatus($id, $status);
            $this->session->set_flashdata('message', $save);
            redirect('location');
        }
    }

    function changelocationName() {
        if ($this->input->post('save')) {
            $location_name = ltrim($this->input->post('location_name'));
            $location_id = base64_decode($this->input->post('location_id'));
            if ($location_name != '' && $location_id != '') {
                $save = $this->location_model->changelocationName($location_name, $location_id);
                $this->session->set_flashdata('message', $save);
            }
            redirect('location');
        }
    }

}

?>