<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Users extends CI_Controller {

    /**
     * Index Page for this controller.
     *
     * Maps to the following URL
     * 		http://example.com/index.php/welcome
     * 	- or -
     * 		http://example.com/index.php/welcome/index
     * 	- or -
     * Since this controller is set as the default controller in
     * config/routes.php, it's displayed at http://example.com/
     *
     * So any other public methods not prefixed with an underscore will
     * map to /index.php/welcome/<method_name>
     * @see https://codeigniter.com/user_guide/general/urls.html
     */
    public function __construct() {
        parent::__construct();
        if (!$this->session->userdata('UsertId')) {
            redirect('login');
        } else if (empty($this->session->userdata('IsAdmin'))) {
            redirect('dashboard');
        }
        $this->load->library('form_validation');
        $this->load->library('encrypt');
        $this->load->model('referredby_model');
        $this->load->model('users_model');
    }

    function index() {
        /* Check submit button */

        if ($this->input->post('save')) {
            $config['upload_path'] = realpath(APPPATH . '../karoclient/usersprofile/');
            $config['allowed_types'] = 'gif|jpg|png|jpeg';
            $config['max_size'] = '2048';
            $image = '';
            $this->load->library('upload', $config);

            if (!$this->upload->do_upload('userimage')) {
                $error = array('error' => $this->upload->display_errors());
                foreach ($error as $item => $value) {
                        if (strpos($value, 'You did not select a file to upload') === false) {
                         // echo '<ol class="alert alert-danger"><li>' . $value . '</ol></li>'; exit;
                        $this->session->set_flashdata('message', '<div class="alert alert-danger">'.$value.'</div>');
                        $this->load->view('header');
                        $this->load->view('users/index', $getUsersData);
                        $this->load->view('footer');

                        }
                }
            } else {
                $upload_data = array('upload_data' => $this->upload->data());
                foreach ($upload_data as $key => $value) {
                    $image = $value['file_name'];
                }
            }
            $PrimaryEmailId = trim($this->input->post('primary_email'));
            $Password = md5($this->input->post('password'));
            $FirstName = trim($this->input->post('first_name'));
            $MiddleName = trim($this->input->post('middle_name'));
            $LastName = trim($this->input->post('last_name'));
            $Age = trim($this->input->post('age'));
            $State = trim($this->input->post('state'));
            $City = trim($this->input->post('city'));
            $ZipCode = trim($this->input->post('zipcode'));
            $PrimaryContactNo = trim($this->input->post('primary_contact'));
            $SecondaryContactNo = trim($this->input->post('secondary_contact'));
            $UserType = trim($this->input->post('user_type'));
            // $IsAdmin                = trim($this->input->post('is_admin'));
            $IsAdmin = ($UserType == 'Social Worker') ? 0 : 1; //trim($this->input->post('is_admin'));
            $IsActive = trim($this->input->post('is_active'));
            $Address = trim(str_replace("'", "`", $this->input->post('address')));
            $UserImage = $image;
            $Gender = $this->input->post('gender');
            // echo "<pre>";print_r($this->input->post()); die;
            if ($PrimaryEmailId != '' && $Password != '' && $FirstName != '' && $PrimaryContactNo != '' && $UserType != '' && $Address != '') {
                $save = $this->users_model->saveusers($PrimaryEmailId, $Password, $FirstName, $MiddleName, $LastName, $Age, $State, $City, $ZipCode, $PrimaryContactNo, $SecondaryContactNo, $UserType, $IsAdmin, $IsActive, $Address, $UserImage, $Gender);
                $this->session->set_flashdata('message', $save);
            } else {
                $this->session->set_flashdata('message', '<div class="alert alert-danger">Please enter all required fields </div>');
            }
        }
        $getUsers = $this->users_model->getUsers();
        // echo '<pre>'; print_r($getUsers);exit;


        $getState = $this->referredby_model->getstates();

        //$getcity = $this->referredby_model->getreferedby();
        $getUsersData['getUsers'] = $getUsers;
        $getUsersData['states'] = $getState;
        if (isset($_REQUEST['act'])) {
            if ($_REQUEST['act'] == 'update') {
                $usersData = $this->users_model->getUserById(base64_decode($_REQUEST['id']));
                $getUsersData['userByID'] = $usersData;
                $city = $this->getcities($usersData[0]['State']);
                $getUsersData['cities'] = $city;
            }
        }
        $this->load->view('header');
        $this->load->view('users/index', $getUsersData);
        $this->load->view('footer');
    }

    function citiesByState() {
        $state = $_REQUEST['state'];
        if ($_REQUEST['cityid'] != '') {
            $cityname = $_REQUEST['cityid'];
        } else {
            $cityname = '';
        }
        $getcities = $this->referredby_model->getcities($state);
        echo "<option value=''>--Select City--</option>";
        foreach ($getcities as $city) {
            if ($city['city_name'] == $cityname) {
                $selected = "selected='selected'";
            } else {
                $selected = '';
            }
            echo "<option value='" . $city['city_name'] . "' " . $selected . ">" . $city['city_name'] . "</option>";
        }
    }

    function getcities($state) {
        $getcities = $this->referredby_model->getcities($state);
        return $getcities;
    }

    function changestatus() {
        if ($_REQUEST['id'] != '') {
            $id = base64_decode($_REQUEST['id']);
            if ($_REQUEST['status'] == 1) {
                $status = 0;
            } else {
                $status = 1;
            }
            $save = $this->users_model->changeStatus($id, $status);
            $this->session->set_flashdata('message', $save);
            redirect('users');
        }
    }

    function updateuser() {
        if ($this->input->post('save')) {
            $config['upload_path'] = realpath(APPPATH . '../karoclient/usersprofile/');
            $config['allowed_types'] = 'gif|jpg|png|jpeg';
            $config['max_size'] = '2048';
            $image = '';
            $this->load->library('upload', $config);
            $getUsersDetails = $this->users_model->getExistingRecord($this->input->post('primary_email'));
            if($getUsersDetails){
                $image_update = $getUsersDetails[0]['UserImage'];

            }
            if($_FILES['userimage']['name'])
            {
              if (!$this->upload->do_upload('userimage')) {
                $error = array('error' => $this->upload->display_errors());
                foreach ($error as $item => $value) {
                    echo '<ol class="alert alert-danger"><li>' . $value . '</ol></li>';
                }
                $image = $this->input->post('preuserimage');
            }  
            }
             // else {
                $upload_data = array('upload_data' => $this->upload->data());
                foreach ($upload_data as $key => $value) {
                    $image = $value['file_name'];
                }
            $PrimaryEmailId         = trim($this->input->post('primary_email'));
            $Password               = md5($this->input->post('password'));
            $FirstName              = trim($this->input->post('first_name'));
            $MiddleName             = trim($this->input->post('middle_name'));
            $LastName               = trim($this->input->post('last_name'));
            $Age                    = trim($this->input->post('age'));
            $State                  = trim($this->input->post('state'));
            $City                   = trim($this->input->post('city'));
            $ZipCode                = trim($this->input->post('zipcode'));
            $PrimaryContactNo       = trim($this->input->post('primary_contact'));
            $SecondaryContactNo     = trim($this->input->post('secondary_contact'));
            $UserType               = trim($this->input->post('user_type'));
            $IsAdmin                = (trim($this->input->post('user_type'))=='Social Worker')?0:1;
            $IsActive               = trim($this->input->post('is_active'));            
            $Address                = trim(str_replace("'", "`",$this->input->post('address')));
            $UserId                = base64_decode($this->input->post('UserId'));
            $UserImage              = $image ?$image:$image_update;
            $Gender                 = $this->input->post('gender') ;
            // echo "<pre>";print_r($this->input->post());die;
            if ($PrimaryEmailId != '' && $FirstName != '' && $PrimaryContactNo != '' && $UserType != '' && $Address != '' && $UserId !='') {               
                $save = $this->users_model->updateusermaster($PrimaryEmailId , $FirstName , $MiddleName , $LastName , $Age , $State , $City , $ZipCode , $PrimaryContactNo , $SecondaryContactNo , $UserType , $IsAdmin , $IsActive , $Address , $UserImage ,$UserId,$Gender);
                $this->session->set_flashdata('message', $save);
            } else {
                $this->session->set_flashdata('message', '<div class="alert alert-danger">Please enter all requred fileds</div>');
            }
            redirect('users');
        // }
        }
    }

    function checkemail() {
        if (isset($_REQUEST['email'])) {
            $checkemail = $this->users_model->checkemail($_REQUEST['email']);
            echo $checkemail;
        }
    }


}
