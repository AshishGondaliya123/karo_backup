<?php
class Patientclassification_model extends CI_Model {
    function savepatientclassification($ClassificationName) {
        $CreatedByUserId = $this->session->userdata('UsertId');
        $query = $this->db->get_where('patientclassification', array('ClassificationName' => $ClassificationName));      
        if($query->num_rows()==0){
        $query="insert into patientclassification (ClassificationName,CreatedByUserId)values('".$ClassificationName."','".$CreatedByUserId."')";
        if($this->db->query($query)){
            return '<div class="alert alert-success">Saved successfully</div>';
			}else{
				return '<div class="alert alert-danger">Something went wrong</div>';
			}
        }else{
            return '<div class="alert alert-danger">Classification name already exist</div>';
        }
    }
    function getpatientclassification() {
        $this->db->order_by('ClassificationId', 'DESC');  //actual field name of id
        $query=$this->db->get('patientclassification');
        return $query->result_array();
    }
    function changeStatus($id,$status) {       
        $query="update patientclassification set IsActive='".$status."' where ClassificationId='".$id."'";
        if($this->db->query($query)){
            return '<div class="alert alert-success">Status updated successfully</div>';
        }else{
            return '<div class="alert alert-danger">Something went wrong</div>';
        }
    }
    function changepatientclassificationName($name,$id) {   
        $query = $this->db->get_where('patientclassification', array('ClassificationName' => $name,'ClassificationId !=' => $id));      
        if($query->num_rows()==0){
        $query="update patientclassification set ClassificationName = '".$name."' where ClassificationId='".$id."'";
        if($this->db->query($query)){
            return '<div class="alert alert-success">Updated successfully</div>';
        }else{
            return '<div class="alert alert-danger">Something went wrong,/div>';
        }
        }else{
            return '<div class="alert alert-danger">Classification name already exist</div>';
        }
    }
}
?>