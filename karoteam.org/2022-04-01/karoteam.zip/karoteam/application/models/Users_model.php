<?php
class Users_model extends CI_Model {
    function saveusers($PrimaryEmailId , $Password , $FirstName , $MiddleName , $LastName , $Age , $State , $City , $ZipCode , $PrimaryContactNo , $SecondaryContactNo , $UserType , $IsAdmin , $IsActive , $Address , $UserImage,$Gender) {
        $CreatedByUserId = $this->session->userdata('UsertId');
        $query = $this->db->get_where('usermaster', array('PrimaryEmailId' => $PrimaryEmailId));      
        if($query->num_rows()==0){
        $query="insert into usermaster (PrimaryEmailId , Password , FirstName , MiddleName , LastName , Age , State , City , ZipCode , PrimaryContactNo , SecondaryContactNo , UserType , IsAdmin , IsActive , Address , UserImage,Gender)values('".$PrimaryEmailId."' , '".$Password."' , '".$FirstName."' , '".$MiddleName."' , '".$LastName."' , '".$Age."' , '".$State."' , '".$City."' , '".$ZipCode."' , '".$PrimaryContactNo."' , '".$SecondaryContactNo."' , '".$UserType."' , '".$IsAdmin."' , '".$IsActive."' , '".$Address."' , '".$UserImage."' , '".$Gender."')";
            if($this->db->query($query)){
				return '<div class="alert alert-success">Saved successfully</div>';
			}else{
				return '<div class="alert alert-danger">Something went wrong</div>';
			}
        }else{
            return '<div class="alert alert-danger">Primary email already exist</div>';
        }
    }
    function getUsers() {
        $this->db->order_by('UserId', 'DESC');  //actual field name of id
        $query=$this->db->get('usermaster');
        return $query->result_array();
    }
    function getUserById($id){
        $this->db->where('UserId',$id);  //actual field name of id
        $query=$this->db->get('usermaster');
        return $query->result_array();
    }
    function changeStatus($id,$status) {       
        $query="update usermaster set IsActive='".$status."' where UserId='".$id."'";
        if($this->db->query($query)){
            return '<div class="alert alert-success">Updated successfully</div>';
        }else{
            return '<div class="alert alert-danger">Something went wrong</div>';
        }
    }
   
    function updateusermaster($PrimaryEmailId , $FirstName , $MiddleName , $LastName , $Age , $State , $City , $ZipCode , $PrimaryContactNo , $SecondaryContactNo , $UserType , $IsAdmin , $IsActive , $Address , $UserImage ,$UserId,$Gender) { 
        $query = $this->db->get_where('usermaster', array('PrimaryEmailId' => $PrimaryEmailId,'UserId !=' => $UserId));      
        if($query->num_rows()==0){
        $query="update usermaster set PrimaryEmailId = '".$PrimaryEmailId."',FirstName = '".$FirstName."',MiddleName = '".$MiddleName."',LastName = '".$LastName."',Age = '".$Age."',State = '".$State."' ,City = '".$City."' ,ZipCode = '".$ZipCode."' ,PrimaryContactNo = '".$PrimaryContactNo."' ,SecondaryContactNo = '".$SecondaryContactNo."' ,UserType = '".$UserType."' ,IsAdmin = '".$IsAdmin."' ,IsActive = '".$IsActive."' ,Address = '".$Address."' ,UserImage='".$UserImage."' ,Gender='".$Gender."' where UserId='".$UserId."'";
        if($this->db->query($query)){
            return '<div class="alert alert-success">Updated successfully</div>';
        }else{
            return '<div class="alert alert-danger">Something went wrong</div>';
        }
        }else{
             return '<div class="alert alert-danger">Primary email already exist</div>';
        }
    }
    function checkemail($email){
        $query = $this->db->get_where('usermaster', array('PrimaryEmailId' => $email));    
        if($query->num_rows()>0){
            return 'Email id already exist</div>';
        }
    }

    function getExistingRecord($email)
    {
        $query =$this->db->get_where('usermaster', array('PrimaryEmailId' => $email));
        return $query->result_array();
    }
}
?>