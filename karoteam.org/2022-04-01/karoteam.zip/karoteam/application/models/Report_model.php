<?php

class Report_model extends CI_Model {

    /**
     *
     * Patient Wise Details
     */
    public function getPatientsReportDetails($data) {
        $toDate = '';
        $fromDate = '';
        $whereIsAdmin = '';
        $wherePatientCases = '';
		$wherePatientName = '';
        $wherePatientKaro = '';
        $whereDept = '';
        $whereHospital = '';

        $isAdmin = $this->session->userdata('IsAdmin');
        if ($isAdmin != 1) {
            $whereIsAdmin = " AND patient_master.created_by = " . $this->session->userdata('UsertId');
        }

        if (isset($data['from_date']) && $data['from_date'] != '') {
            $fromDate = date('Y-m-d', strtotime($data['from_date']));
        } else {
            $frmDateQuery = "SELECT date(min(registration_date)) as from_date FROM patient_master";
            $frmDateQueryResult = $this->db->query($frmDateQuery);
            $dataRow = $frmDateQueryResult->row();

            if (isset($dataRow) && isset($dataRow->from_date)) {
                $fromDate = date('Y-m-d', strtotime($dataRow->from_date));
            }
        }

        if (isset($data['to_date']) && $data['to_date'] != '') {
            $toDate = date('Y-m-d', strtotime($data['to_date']));
        } else {
            $toDate = date('Y-m-d');
        }
		
        if ($data['patient_name'] && $data['patient_name'] != '') {
            $wherePatientName = " AND patient_name='" . $data['patient_name'] . "'";
        } else if ($data['patient_name'] == '') {
            $wherePatientName = " ";
        }
        if ($data['department'] && $data['department'] != '') {
            $whereDept = " AND `departmentmaster`.`DeptId`='" . $data['department'] . "'";
        } else if ($data['department'] == '') {
            $whereDept = " ";
        }
        if ($data['hospital'] && $data['hospital'] != '') {
            $whereHospital = " AND `hospitalmaster`.`HospitalId`='" . $data['hospital'] . "'";
        } else if ($data['hospital'] == '') {
            $whereHospital = " ";
        }
        if ($data['karo_no'] && $data['karo_no'] != '') {
            $wherePatientKaro = " AND (patient_karo_case_no='" . $data['karo_no'] . "' OR patient_case ='" . $data['karo_no'] . "' OR patient_master.patient_id ='" . $data['karo_no'] . "')";
        } else if ($data['karo_no'] == '') {
            $wherePatientKaro = " ";
        }

        if (isset($data['reg_date']) && $data['reg_date'] != '') {
            $regDate = " AND registration_date='" . date('Y-m-d', strtotime($data['reg_date'])) . "'";
        } else {
            $regDate = '';
        }

        if (isset($data['patient_cases']) && is_array($data['patient_cases']) && count($data['patient_cases']) > 0) {
            $patientCases = implode("','", $data['patient_cases']);
            $wherePatientCases = " AND patient_case_details.case_status IN ('" . $patientCases . "')";
        } else if (isset($data['patient_cases']) && $data['patient_cases'] != '') {
            $patientCases = str_replace(",", "','", $data['patient_cases']);
            $wherePatientCases = " AND patient_case_details.case_status IN ('" . $patientCases . "')";
        }

        //                            `patient_case_details`.`case_status` AS `Case Status`,
     $query = "SELECT
                            patient_case AS CaseNo,patient_master.id AS CaseId,
                            DATE_FORMAT(`registration_date`, '%d/%m/%Y') AS `Registration Date`,
                            `patient_name` AS `Patient Name`,
                            `pt_address` AS Address,
                            `pp_address` AS PpAddress,
                            CONCAT(`pt_city`, ' - ', `pt_state`) AS Location,
                            CASE WHEN DATE_FORMAT(`patient_dob`, '%d/%m/%Y')='00/00/0000' THEN '' ELSE DATE_FORMAT(`patient_dob`, '%d/%m/%Y') END AS DOB,
                            `patient_age`,
                            `patient_gender` AS Gender,
                            CONCAT(patient_phone,',',caregiver_phone,',',caregiver_phone2) AS `Contact No`,
                            `HospitalName` AS `Refered To`,
                            patient_master.refered_by AS `Refered By`,
                            `doctor_name` AS `Name Of Treating Doctor`,
                            CONCAT(usermaster.FirstName, ' ', `MiddleName`, ' ', LastName) 
                                   AS `Team Member`,
                            DATE_FORMAT(patient_case_details.updated_at,
                                    '%d/%m/%Y') AS `Case Receive Date`,
                            `disease_diagnosed` AS `Disease Name`,
                            `departmentmaster`.`DeptName` AS `Depatment Of The Hospital`,
                            `required_fund` AS `Required Fund`,
                            DATE_FORMAT(`patient_master`.`created_at`,
                                    '%d/%m/%Y') AS `Initial Team Evaluation`,
                            IFNULL(DisbursedAmount, 0) AS `Disbursed Amount`,
                            IFNULL(`patient_financetial_details`.`approved_amount`,
                                    0) AS `Approved Amount`,
                            IF(`patient_case_details`.`case_status` = 'reject', 'rejected', `patient_case_details`.`case_status`) AS `Case Status`,
                            IFNULL(REMARK, '-') AS `Additional Comment`
                            FROM
                            patient_master
                                LEFT OUTER JOIN
                            `patient_case_details` ON `patient_case_details`.`case_number` = patient_master.`patient_case`
                                LEFT OUTER JOIN
                            `patient_financetial_details` ON `patient_financetial_details`.`case_id` = `patient_case_details`.`id`
                                LEFT OUTER JOIN
                            (SELECT
                                SUM(`DisbursedAmt`) AS DisbursedAmount, `CaseId`
                            FROM
                                `patient_case_disbursed_detail`
                            GROUP BY `CaseId`) AS DisbursedDetail ON `patient_case_details`.`id` = DisbursedDetail.CaseId
                                LEFT OUTER JOIN
                            `hospitalmaster` ON `hospitalmaster`.`HospitalId` = `patient_case_details`.`hospital_name`
                                LEFT OUTER JOIN
                            `departmentmaster` ON `departmentmaster`.`DeptId` = `patient_case_details`.`department_name`
                                LEFT OUTER JOIN
                            `referedby` ON `referedby`.`ReferedById` = `patient_master`.`refered_by`
                                LEFT OUTER JOIN
                            `usermaster` ON `usermaster`.`UserId` = `patient_master`.`representative_name`
                                LEFT OUTER JOIN
                            (SELECT
                                REMARK, `case_id`
                            FROM
                                `patient_followup_details`
                            WHERE
                                `final_status` = 1) AS Remarks ON Remarks.`case_id` = `patient_case_details`.`id`
                            WHERE
                            IFNULL(patient_master.status,0)!=1 AND /*akash rai 9 march 2020*/
                            DATE(registration_date) >= '" . $fromDate . "'
                               AND DATE(registration_date) <= '" . $toDate . "'" . $wherePatientName . $whereDept . $whereHospital . $wherePatientKaro . $regDate . $whereIsAdmin . $wherePatientCases;
        //prx($query);

        $query = $this->db->query($query);
        $result = $query->result();
        return json_decode(json_encode($result), true);
    }

    /**
     *
     * Case Wise Patient Details
     */
    public function getCaseWisePatientsReport($data) {
        $toDate = '';
        $fromDate = '';
        $whereIsAdmin = '';
        $wherePatientCases = '';
	    $wherePatientName = '';
        $wherePatientKaro = '';
        $whereDept = '';
        $whereHospital = '';

        $isAdmin = $this->session->userdata('IsAdmin');
        if ($isAdmin != 1) {
            $whereIsAdmin = " AND patient_master.created_by = " . $this->session->userdata('UsertId');
        }

        if (isset($data['from_date']) && $data['from_date'] != '') {
            $fromDate = date('Y-m-d', strtotime($data['from_date']));
        } else {
            $frmDateQuery = "SELECT date(min(registration_date)) as from_date FROM patient_master";
            $frmDateQueryResult = $this->db->query($frmDateQuery);
            $dataRow = $frmDateQueryResult->row();

            if (isset($dataRow) && isset($dataRow->from_date)) {
                $fromDate = date('Y-m-d', strtotime($dataRow->from_date));
            }
        }

        if (isset($data['to_date']) && $data['to_date'] != '') {
            $toDate = date('Y-m-d', strtotime($data['to_date']));
        } else {
            $toDate = date('Y-m-d');
        }
		
        if ($data['patient_name'] && $data['patient_name'] != '') {
            $wherePatientName = " AND patient_name='" . $data['patient_name'] . "'";
        } else if ($data['patient_name'] == '') {
            $wherePatientName = " ";
        }

        if ($data['department'] && $data['department'] != '') {
            $whereDept = " AND `departmentmaster`.`DeptId`='" . $data['department'] . "'";
        } else if ($data['department'] == '') {
            $whereDept = " ";
        }

        if ($data['hospital'] && $data['hospital'] != '') {
            $whereHospital = " AND `hospitalmaster`.`HospitalId`='" . $data['hospital'] . "'";
        } else if ($data['hospital'] == '') {
            $whereHospital = " ";
        }

        if ($data['karo_no'] && $data['karo_no'] != '') {
            $wherePatientKaro = " AND (patient_karo_case_no='" . $data['karo_no'] . "' OR patient_case ='" . $data['karo_no'] . "' OR patient_master.patient_id ='" . $data['karo_no'] . "')";
        } else if ($data['karo_no'] == '') {
            $wherePatientKaro = " ";
        }

        if (isset($data['reg_date']) && $data['reg_date'] != '') {
            $regDate = " AND registration_date='" . date('Y-m-d', strtotime($data['reg_date'])) . "'";
        } else {
            $regDate = '';
        }

//        if (isset($data['patient_cases']) && count($data['patient_cases']) > 0) {
//            $patientCases = implode("','", $data['patient_cases']);
//            $wherePatientCases = " AND patient_case_details.case_status IN ('" . $patientCases . "')";
//        }

        $query = "SELECT
                            patient_case AS CaseNo,patient_master.id AS CaseId,
                            DATE_FORMAT(`registration_date`, '%d/%m/%Y') AS `Registration Date`,
                            `patient_name` AS `Patient Name`,
                            `pt_address` AS Address,
                            `pp_address` AS PpAddress,
                            CONCAT(`pt_city`, ' - ', `pt_state`) AS Location,
                            CASE WHEN DATE_FORMAT(`patient_dob`, '%d/%m/%Y')='00/00/0000' THEN '' ELSE DATE_FORMAT(`patient_dob`, '%d/%m/%Y') END AS DOB,
                            `patient_age`,
                            `patient_gender` AS Gender,
                            CONCAT(patient_phone,',',caregiver_phone,',',caregiver_phone2) AS `Contact No`,
                            `HospitalName` AS `Refered To`,
                            patient_master.refered_by AS `Refered By`,
                            `doctor_name` AS `Name Of Treating Doctor`,
                            CONCAT(usermaster.FirstName, ' ', `MiddleName`, ' ', LastName) 
                                   AS `Team Member`,
                            DATE_FORMAT(patient_case_details.updated_at,
                                    '%d/%m/%Y') AS `Case Receive Date`,
                            `disease_diagnosed` AS `Disease Name`,
                            `departmentmaster`.`DeptName` AS `Depatment Of The Hospital`,
                            `required_fund` AS `Required Fund`,
                            DATE_FORMAT(`patient_master`.`created_at`,
                                    '%d/%m/%Y') AS `Initial Team Evaluation`,
                            IFNULL(DisbursedAmount, 0) AS `Disbursed Amount`,
                            IFNULL(`patient_financetial_details`.`approved_amount`,
                                    0) AS `Approved Amount`,
                            IF(`patient_case_details`.`case_status` = 'reject', 'rejected', `patient_case_details`.`case_status`) AS `Case Status`,
                            IFNULL(REMARK, '-') AS `Additional Comment`,
                            CaseStatus.case_status_date
                            FROM
                            patient_master
                                LEFT OUTER JOIN
                            `patient_case_details` ON `patient_case_details`.`case_number` = patient_master.`patient_case`
                                LEFT OUTER JOIN
                            `patient_financetial_details` ON `patient_financetial_details`.`case_id` = `patient_case_details`.`id`
                                LEFT OUTER JOIN
                            (SELECT
                                SUM(`DisbursedAmt`) AS DisbursedAmount, `CaseId`
                            FROM
                                `patient_case_disbursed_detail`
                            GROUP BY `CaseId`) AS DisbursedDetail ON `patient_case_details`.`id` = DisbursedDetail.CaseId
                                LEFT OUTER JOIN
                            `hospitalmaster` ON `hospitalmaster`.`HospitalId` = `patient_case_details`.`hospital_name`
                                LEFT OUTER JOIN
                            `departmentmaster` ON `departmentmaster`.`DeptId` = `patient_case_details`.`department_name`
                                LEFT OUTER JOIN
                            `referedby` ON `referedby`.`ReferedById` = `patient_master`.`refered_by`
                                LEFT OUTER JOIN
                            `usermaster` ON `usermaster`.`UserId` = `patient_master`.`representative_name`
                                LEFT OUTER JOIN
                            (SELECT
                                REMARK, `case_id`
                            FROM
                                `patient_followup_details`
                            WHERE
                                `final_status` = 1) AS Remarks ON Remarks.`case_id` = `patient_case_details`.`id`
                                LEFT OUTER JOIN
                            (SELECT
                                `case_status_date`, `case_id`
                            FROM
                                `patient_case_status_detail`
                            WHERE
                                `case_status_date` IN (SELECT MAX(case_status_date) FROM patient_case_status_detail GROUP BY case_id)) AS CaseStatus ON CaseStatus.`case_id` = `patient_case_details`.`id`
                            WHERE
                            IFNULL(patient_master.status,0)!=1 AND /*akash rai 9 march 2020*/
                            `patient_case_details`.`case_status` = 'closed' AND DATE(CaseStatus.case_status_date) >= '" . $fromDate . "'
                                 AND DATE(CaseStatus.case_status_date) <= '" . $toDate . "'" . $wherePatientName . $whereDept . $whereHospital . $wherePatientKaro . $regDate . $whereIsAdmin . $wherePatientCases;
  // prx($query);

        $query = $this->db->query($query);
        $result = $query->result();
        return json_decode(json_encode($result), true);
    }

    /**
     * Get Donor Wise Patient Details
     */
    function getDonorWisePatientsReportDetails($data) {
        $toDate = '';
        $fromDate = '';
        $whereDonor = '';
        $whereIsAdmin = '';
		$wherePatientName = '';
        $wherePatientKaro = '';
        $whereDept = '';
        $whereHospital = '';

        $isAdmin = $this->session->userdata('IsAdmin');
        if ($isAdmin != 1) {
            $whereIsAdmin = " AND patient_master.created_by = " . $this->session->userdata('UsertId');
        }

        if (isset($data['from_date']) && $data['from_date'] != '') {
            $fromDate = date('Y-m-d', strtotime($data['from_date']));
        } else {
            $frmDateQuery = "SELECT date(min(registration_date)) as from_date FROM patient_master";
            $frmDateQueryResult = $this->db->query($frmDateQuery);
            $dataRow = $frmDateQueryResult->row();

            if (isset($dataRow) && isset($dataRow->from_date)) {
                $fromDate = date('Y-m-d', strtotime($dataRow->from_date));
            }
        }

        if (isset($data['to_date']) && $data['to_date'] != '') {
            $toDate = date('Y-m-d', strtotime($data['to_date']));
        } else {
            $toDate = date('Y-m-d');
        }

        if (isset($data['donor_id']) && $data['donor_id'] != '') {
            $whereDonor = "AND ApprovalDetail.doner_id = '" . $data['donor_id'] . "'";
        }
		
	    if ($data['patient_name'] && $data['patient_name'] != '') {

            $wherePatientName = " AND patient_name='" . $data['patient_name'] . "'";
        } else if ($data['patient_name'] == '') {
            $wherePatientName = " ";
        }

        if ($data['karo_no'] && $data['karo_no'] != '') {
            $wherePatientKaro = " AND (patient_karo_case_no='" . $data['karo_no'] . "' OR patient_case ='" . $data['karo_no'] . "' OR patient_master.patient_id ='" . $data['karo_no'] . "')";
        } else if ($data['karo_no'] == '') {
            $wherePatientKaro = " ";
        }

        if (isset($data['reg_date']) && $data['reg_date'] != '') {
            $regDate = " AND registration_date='" . date('Y-m-d', strtotime($data['reg_date'])) . "'";
        } else {
            $regDate = '';
        }

        if ($data['department'] && $data['department'] != '') {
            $whereDept = " AND `departmentmaster`.`DeptId`='" . $data['department'] . "'";
        } else if ($data['department'] == '') {
            $whereDept = " ";
        }

        if ($data['hospital'] && $data['hospital'] != '') {
            $whereHospital = " AND `hospitalmaster`.`HospitalId`='" . $data['hospital'] . "'";
        } else if ($data['hospital'] == '') {
            $whereHospital = " ";
        }

        $query = "SELECT
                            patient_case AS CaseNo,
                            DATE_FORMAT(`registration_date`, '%d/%m/%Y') AS `Registration Date`,
                            `patient_name` AS `Patient Name`,
                            `pt_address` AS Address,
                            CONCAT(`pt_city`, ' - ', `pt_state`) AS Location,
                            CASE WHEN DATE_FORMAT(`patient_dob`, '%d/%m/%Y')='00/00/0000' THEN '' ELSE DATE_FORMAT(`patient_dob`, '%d/%m/%Y') END AS DOB,
                            `patient_age`,
                            `patient_gender` AS Gender,
                            `patient_phone` AS `Contact No`,
                            `HospitalName` AS `Refered To`,
                            patient_master.refered_by AS `Refered By`,
                            `doctor_name` AS `Name Of Treating Doctor`,
                            CONCAT(usermaster.FirstName, ' ', `MiddleName`, ' ', LastName) 
                                   AS `Team Member`,
                            DATE_FORMAT(patient_case_details.updated_at,
                                    '%d/%m/%Y') AS `Case Receive Date`,
                   			`disease_diagnosed` AS `Disease Name`,
                            `departmentmaster`.`DeptName` AS `Depatment Of The Hospital`,
                            `required_fund` AS `Required Fund`,
                            DATE_FORMAT(`patient_master`.`created_at`,
                                    '%d/%m/%Y') AS `Initial Team Evaluation`,
                            IFNULL(DisbursedAmount, 0) AS `Disbursed Amount`,
                           IFNULL(`ApprovalDetail`.`approved_amount`,0) AS `Approved Amount`,
                              IFNULL(refundamount,0) AS RefundAmount,
                            IF(`patient_case_details`.`case_status` = 'reject', 'rejected', `patient_case_details`.`case_status`) AS `Case Status`,
                            IFNULL(REMARK, '-') AS `Additional Comment`
                            FROM
                            patient_master
                                LEFT OUTER JOIN
                            `patient_case_details` ON `patient_case_details`.`case_number` = patient_master.`patient_case`
                                LEFT OUTER JOIN
                            `patient_financetial_details` ON `patient_financetial_details`.`case_id` = `patient_case_details`.`id`
                               LEFT OUTER JOIN
(SELECT
SUM(`approved_amount`) AS approved_amount,`case_id`, `doner_id`
FROM
`patient_case_status_detail` WHERE  DATE(IFNULL(`rehelp_date`,`case_status_date`)) BETWEEN '" . $fromDate . "' AND '" . $toDate . "'

GROUP BY `case_id`, `doner_id`) AS ApprovalDetail  ON `patient_case_details`.`id` = ApprovalDetail.case_id 

LEFT OUTER JOIN
(SELECT
SUM(`DisbursedAmt`) AS DisbursedAmount, `CaseId`, DonorId
FROM
`patient_case_disbursed_detail` WHERE DATE(patient_case_disbursed_detail.DisburesedDate) BETWEEN '" . $fromDate . "' AND '" . $toDate . "'
GROUP BY `CaseId`, `DonorId`) AS DisbursedDetail ON `patient_case_details`.`id` = DisbursedDetail.CaseId 
AND DisbursedDetail.DonorId=ApprovalDetail.doner_id
LEFT OUTER JOIN
(SELECT
SUM(`refund_amount`) AS RefundAmount, `case_id`, `donor_id`
FROM
`refund_amount_details` WHERE DATE(`refund_amount_details`.`refund_date`) BETWEEN '" . $fromDate . "' AND '" . $toDate . "'
GROUP BY `case_id`, `donor_id`) AS `refund_amount_details` ON `patient_case_details`.`id` = refund_amount_details.`case_id`
AND `refund_amount_details`.`donor_id`=ApprovalDetail.doner_id
                                LEFT OUTER JOIN
                            `hospitalmaster` ON `hospitalmaster`.`HospitalId` = `patient_case_details`.`hospital_name`
                                LEFT OUTER JOIN
                            `departmentmaster` ON `departmentmaster`.`DeptId` = `patient_case_details`.`department_name`
                                LEFT OUTER JOIN
                            `referedby` ON `referedby`.`ReferedById` = `patient_master`.`refered_by`
                                LEFT OUTER JOIN
                            `usermaster` ON `usermaster`.`UserId` = `patient_master`.`representative_name`
                                LEFT OUTER JOIN
                            (SELECT
                                REMARK, `case_id`
                            FROM
                                `patient_followup_details`
                            WHERE
                                `final_status` = 1) AS Remarks ON Remarks.`case_id` = `patient_case_details`.`id`
                            WHERE
                               IFNULL(patient_master.status,0)!=1 "  
                             . $wherePatientName . $wherePatientKaro . $regDate . $whereDonor . $whereIsAdmin . $whereDept . $whereHospital;
     //prx($query);

        $query = $this->db->query($query);
        $result = $query->result();
        
        return json_decode(json_encode($result), true);
    }

    /**
     * Get Patient Wise Financial Details
     */
    function getPatientsWiseFinacialReports($data) {
        $wherePatientName = '';
        $wherePatientKaro = '';
        $whereDonor = '';
        $whereDept = '';
        $whereHospital = '';

        $isAdmin = $this->session->userdata('IsAdmin');
         if ($isAdmin != 1)
            $whereclause = " where patient_case_details.created_by = '". $this->session->userdata('UsertId')."' AND";
        else {
             $whereclause=" where";
        }
		
        // $from_date = date('Y-m-d', strtotime($data['from_date']));
        // $to_date = date('Y-m-d', strtotime($data['to_date']));
		
        if (isset($data['from_date']) && $data['from_date'] != '') {
            $from_date = date('Y-m-d', strtotime($data['from_date']));
        } else{
            $from_date = date('Y-m-d', strtotime('2015-01-01'));
        }

        if (isset($data['to_date']) && $data['to_date'] != '') {
            $to_date = date('Y-m-d', strtotime($data['to_date']));
        } else{
            $to_date = date('Y-m-d');
        }
		
        if ($data['patient_name'] && $data['patient_name'] != '') {
            $wherePatientName = " AND patient_name='" . $data['patient_name'] . "'";
        } else if ($data['patient_name'] == '') {
            $wherePatientName = " ";
        }

        if ($data['karo_no'] && $data['karo_no'] != '') {
            $wherePatientKaro = " AND (patient_karo_case_no='" . $data['karo_no'] . "' OR patient_case ='" . $data['karo_no'] . "' OR patient_master.patient_id ='" . $data['karo_no'] . "')";
        } else if ($data['karo_no'] == '') {
            $wherePatientKaro = " ";
        }

        if (isset($data['reg_date']) && $data['reg_date'] != '') {
            $regDate = " AND registration_date='" . date('Y-m-d', strtotime($data['reg_date'])) . "'";
        } else {
            $regDate = '';
        }

        if (isset($data['donor_id']) && $data['donor_id'] != '') {
            // $whereDonor = "AND ApprovalDetail.doner_id = '" . $data['donor_id'] . "'";
        }

        if ($data['department'] && $data['department'] != '') {
            $whereDept = " AND `departmentmaster`.`DeptId`='" . $data['department'] . "'";
        } else if ($data['department'] == '') {
            $whereDept = " ";
        }

        if ($data['hospital'] && $data['hospital'] != '') {
            $whereHospital = " AND `hospitalmaster`.`HospitalId`='" . $data['hospital'] . "'";
        } else if ($data['hospital'] == '') {
            $whereHospital = " ";
        }

       // $query = "SELECT `patient_name` AS Patient,`patient_case_details`.`case_number` AS CASE_NO,
				// CASE WHEN SanctionedAmount>0 THEN 'Sanctioned' ELSE 'Disbursed'  END AS CASEStatus ,
				// PaymentMode,
				// APDIDetail.CaseId,
				// APDIDetail.SanctionedAmount,
				// APDIDetail.SanctionDate,
				// APDIDetail.Disbursed_Amt,
				// APDIDetail.Disbursed_Date FROM
				// (
				// SELECT case_id AS CaseId,approved_amount AS SanctionedAmount,DATE_FORMAT(rehelp_date,'%d/%m/%Y') AS SanctionDate,'' AS Disbursed_Amt,'' AS Disbursed_Date,'' AS `PaymentMode` FROM `patient_case_status_detail`  WHERE case_status IN ('open','rehelp','reopen') AND DATE(case_status_date) >= '" . $from_date . "' AND DATE(case_status_date)<='" . $to_date . "'
				// UNION
				// SELECT Caseid AS CaseId ,'' AS SanctionedAmount,'' AS  SanctionDate, `DisbursedAmt` AS Disbursed_Amt,DATE_FORMAT(`DisburesedDate`,'%d/%m/%Y') AS Disbursed_Date,`PaymentMode`  FROM `patient_case_disbursed_detail`
				// LEFT OUTER JOIN `paymentmaster` ON `paymentmaster`.`PaymentId`=`patient_case_disbursed_detail`.`PaymentModeId`
				 // WHERE DATE(DisburesedDate) >= '" . $from_date . "' AND DATE(DisburesedDate) <='" . $to_date . "')
				// AS  APDIDetail
				// LEFT OUTER JOIN `patient_case_details` ON `patient_case_details`.`id`=APDIDetail.CaseId
				// LEFT OUTER JOIN `patient_master` ON `patient_master`.`patient_case`=`patient_case_details`.`case_number` " . $whereclause . " IFNULL(patient_master.status,0)!=1" . $wherePatientName . $wherePatientKaro . $regDate . "  ORDER BY `patient_master`.Id ";
		
		$query="SELECT `patient_name` AS Patient,`patient_case_details`.`case_number` AS CASE_NO,
'' AS CASEStatus ,
PaymentMode,
APDIDetail.CaseId,
APDIDetail.SanctionedAmount,
APDIDetail.SanctionDate,
APDIDetail.Disbursed_Amt,
APDIDetail.Disbursed_Date FROM
(

     SELECT case_id AS CaseId,id ,approved_amount AS SanctionedAmount,
	 DATE_FORMAT(case_status_date,'%d/%m/%Y') AS SanctionDate,
	 Disbursed_Amt,
	 Disbursed_Date,
	 PaymentMode
	 FROM `patient_case_status_detail`
	 LEFT OUTER JOIN 
	 (
	    SELECT Caseid AS CaseId ,sanction_id,SUM(`DisbursedAmt`) AS Disbursed_Amt,
		MAX(DATE_FORMAT(`DisburesedDate`,'%d/%m/%Y')) AS Disbursed_Date,MAX(PaymentModeId) as PaymentModeId
		FROM `patient_case_disbursed_detail`
		WHERE DATE(DisburesedDate) >= '" . $from_date . "' AND DATE(DisburesedDate) <='" . $to_date . "'
		GROUP BY sanction_id,caseid
	 )Disbursed 
	 ON Disbursed.sanction_id=patient_case_status_detail.id
	 LEFT OUTER JOIN `paymentmaster` ON `paymentmaster`.`PaymentId`=`Disbursed`.`PaymentModeId`
	 WHERE case_status IN ('open','rehelp','reopen')
	 AND DATE(case_status_date) >= '" . $from_date . "' AND DATE(case_status_date)<='" . $to_date . "'
	 
)
AS APDIDetail
LEFT OUTER JOIN `patient_case_details` ON `patient_case_details`.`id`=APDIDetail.CaseId
LEFT OUTER JOIN `patient_master` ON `patient_master`.`patient_case`=`patient_case_details`.`case_number`
LEFT OUTER JOIN `hospitalmaster` ON `hospitalmaster`.`HospitalId` = `patient_case_details`.`hospital_name`
LEFT OUTER JOIN `departmentmaster` ON `departmentmaster`.`DeptId` = `patient_case_details`.`department_name` " . $whereclause . " IFNULL(patient_master.status,0)!=1" . $wherePatientName . $wherePatientKaro . $regDate . $whereDonor . $whereDept . $whereHospital . " ORDER BY `patient_master`.Id ";
		//prx($query);					
        $query = $this->db->query($query);
		//exit;
        $result = $query->result();
        return json_decode(json_encode($result), true);
    }

    /**
     * Get Donor Wise Patient Financial Details
     */
    function getPatientsDonorWiseFinacialReports($data) {
        $wherePatientName = '';
        $wherePatientKaro = '';
        $whereDept = '';
        $whereHospital = '';

        $isAdmin = $this->session->userdata('IsAdmin');
         if ($isAdmin != 1)
            $whereclause = " where patient_case_details.created_by = '" . $this->session->userdata('UsertId')."' AND";
         else {
             $whereclause=" where";
        }
      
	   if (isset($data['from_date']) && $data['from_date'] != '') {
            $from_date = date('Y-m-d', strtotime($data['from_date']));
        } else{
        $from_date = date('Y-m-d', strtotime('2015-01-01'));
        }

          if (isset($data['to_date']) && $data['to_date'] != '') {
            $to_date = date('Y-m-d', strtotime($data['to_date']));
        } else{
        $to_date = date('Y-m-d');
        }
	  
	  
        $where_donor = $where_dis_donoe = '';

        if ($data['donor']) {
            $where_donor = 'and doner_id = ' . $data['donor'];
            $where_dis_donoe = 'and DonorId = ' . $data['donor'];
        }
 
          if ($data['patient_name'] && $data['patient_name'] != '') {

            $wherePatientName = " AND patient_name='" . $data['patient_name'] . "'";
        } else if ($data['patient_name'] == '') {
            $wherePatientName = " ";
        }

        if ($data['karo_no'] && $data['karo_no'] != '') {
            $wherePatientKaro = " AND (patient_karo_case_no='" . $data['karo_no'] . "' OR patient_case ='" . $data['karo_no'] . "' OR patient_master.patient_id ='" . $data['karo_no'] . "')";
        } else if ($data['karo_no'] == '') {
            $wherePatientKaro = " ";
        }

        if (isset($data['reg_date']) && $data['reg_date'] != '') {
            $regDate = " AND registration_date='" . date('Y-m-d', strtotime($data['reg_date'])) . "'";
        } else {
            $regDate = '';
        }
       if ($data['department'] && $data['department'] != '') {
            $whereDept = " AND `departmentmaster`.`DeptId`='" . $data['department'] . "'";
        } else if ($data['department'] == '') {
            $whereDept = " ";
        }

        if ($data['hospital'] && $data['hospital'] != '') {
            $whereHospital = " AND `hospitalmaster`.`HospitalId`='" . $data['hospital'] . "'";
        } else if ($data['hospital'] == '') {
            $whereHospital = " ";
        }
	   // $query="SELECT `patient_name` AS Patient,`patient_case_details`.`case_number` AS CASE_NO,
// CASE WHEN Disbursed_Amt='' THEN 'Sanctioned' ELSE 'Disbursed' END AS CASEStatus ,
// PaymentMode,
// APDIDetail.CaseId,
// APDIDetail.SanctionedAmount,
// APDIDetail.SanctionDate,
// APDIDetail.Disbursed_Amt,
// APDIDetail.Disbursed_Date,
// CONCAT(`donermaster`.`FirstName` , ' ', `MiddleName`, ' ',`LastName` )AS Doner FROM
// (
	// SELECT case_id AS CaseId,approved_amount AS SanctionedAmount,DATE_FORMAT(rehelp_date,'%d/%m/%Y') AS SanctionDate,'' AS Disbursed_Amt,'' AS Disbursed_Date,'' AS `PaymentMode`,doner_id AS DonerID FROM `patient_case_status_detail` 
	//WHERE case_status IN ('open','rehelp','reopen') AND DATE(case_status_date) >= '" . $from_date . "' AND DATE(case_status_date)<='" . $to_date . "'$where_donor
	// UNION
	// SELECT patient_case_disbursed_detail.CaseId AS CaseId ,
	// SanctionDetail.SanctionedAmount AS SanctionedAmount,SanctionDetail.SanctionDate  AS SanctionDate, 
	// `DisbursedAmt` AS Disbursed_Amt,
	// DATE_FORMAT(`DisburesedDate`,'%d/%m/%Y') AS Disbursed_Date,
	// `PaymentMode` ,`DonorId` AS DonerID 
	// FROM `patient_case_disbursed_detail`
	// LEFT OUTER JOIN 
// (
          // SELECT case_id AS CaseId,SUM(approved_amount) AS SanctionedAmount,MIN(DATE_FORMAT(rehelp_date,'%d/%m/%Y')) AS SanctionDate
           // FROM `patient_case_status_detail`  WHERE case_status IN ('open','rehelp','reopen') 
            // $where_donor GROUP BY case_id
	// )SanctionDetail ON patient_case_disbursed_detail.CaseId=SanctionDetail.CaseId
	// LEFT OUTER JOIN `paymentmaster` ON `paymentmaster`.`PaymentId`=`patient_case_disbursed_detail`.`PaymentModeId`
	// WHERE DATE(DisburesedDate) >= '" . $from_date . "' AND DATE(DisburesedDate) <='" . $to_date . "'$where_dis_donoe
// )
// AS APDIDetail
// LEFT OUTER JOIN `patient_case_details` ON `patient_case_details`.`id`=APDIDetail.CaseId
// LEFT OUTER JOIN `patient_master` ON `patient_master`.`patient_case`=`patient_case_details`.`case_number` LEFT OUTER JOIN `donermaster` ON APDIDetail.DonerID=donermaster.`DonerId` " . $whereclause . " IFNULL(patient_master.status,0)!=1" /*akash rai*/ .$wherePatientName . $wherePatientKaro . $regDate . " ORDER BY `patient_master`.Id";

$query="SELECT `patient_name` AS Patient,`patient_case_details`.`case_number` AS CASE_NO,
CONCAT(`hospitalmaster`.`HospitalName`,' - ',`hospitalmaster`.`City`) AS HospitalName,
`patient_case_details`.`treatment_completed_details` AS TreatmentCompleted,
'' AS CASEStatus ,
PaymentMode,
APDIDetail.CaseId,
APDIDetail.SanctionedAmount,
APDIDetail.SanctionDate,
APDIDetail.Disbursed_Amt,
APDIDetail.Disbursed_Date,
CONCAT(`donermaster`.`FirstName` , ' ', `MiddleName`, ' ',`LastName` )AS Doner FROM
(
	SELECT case_id AS CaseId,approved_amount AS SanctionedAmount,DATE_FORMAT(case_status_date,'%d/%m/%Y') AS SanctionDate
	,Disbursed_Amt,Disbursed_Date,`PaymentMode`,doner_id AS DonerID 
	FROM `patient_case_status_detail`
	LEFT OUTER JOIN 
	(
		 SELECT Caseid AS CaseId ,sanction_id,SUM(`DisbursedAmt`) AS Disbursed_Amt,
		MAX(DATE_FORMAT(`DisburesedDate`,'%d/%m/%Y')) AS Disbursed_Date,MAX(PaymentModeId) AS PaymentModeId
		FROM `patient_case_disbursed_detail`
		WHERE DATE(DisburesedDate) >= '" . $from_date . "' AND DATE(DisburesedDate) <='" . $to_date . "'$where_dis_donoe GROUP BY sanction_id,CaseId
	)Disbursed ON Disbursed.sanction_id=patient_case_status_detail.id
	LEFT OUTER JOIN `paymentmaster` ON `paymentmaster`.`PaymentId`=`Disbursed`.`PaymentModeId`
	WHERE case_status IN ('open','rehelp','reopen') AND DATE(case_status_date) >= '" . $from_date . "' AND DATE(case_status_date)<='" . $to_date . "'$where_donor

)
AS APDIDetail
LEFT OUTER JOIN `patient_case_details` ON `patient_case_details`.`id`=APDIDetail.CaseId
LEFT OUTER JOIN `hospitalmaster` ON `hospitalmaster`.`HospitalId`=`patient_case_details`.`hospital_name`
LEFT OUTER JOIN `patient_master` ON `patient_master`.`patient_case`=`patient_case_details`.`case_number` 
LEFT OUTER JOIN `departmentmaster` ON `departmentmaster`.`DeptId` = `patient_case_details`.`department_name` LEFT OUTER JOIN `donermaster` ON APDIDetail.DonerID=donermaster.`DonerId` " . $whereclause . " IFNULL(patient_master.status,0)!=1" .$wherePatientName . $wherePatientKaro . $regDate . $whereDept . $whereHospital . " ORDER BY `patient_master`.Id";	 
	   
	//  prx($query);	
	   $query = $this->db->query($query);
        $result = $query->result();
        return json_decode(json_encode($result), true);
    }

    function getDonorWiseApprovedAmount($data) {
        // $from_date = date('Y-m-d', strtotime($data['from_date']));
        // $to_date = date('Y-m-d', strtotime($data['to_date']));
		
		 if (isset($data['from_date']) && $data['from_date'] != '') {
            $from_date = date('Y-m-d', strtotime($data['from_date']));
        } else{
        $from_date = date('Y-m-d', strtotime('2015-01-01'));
        }

          if (isset($data['to_date']) && $data['to_date'] != '') {
            $to_date = date('Y-m-d', strtotime($data['to_date']));
        } else{
        $to_date = date('Y-m-d');
        }
        $donor_id = $data['donor'];
		
		 if ($data['patient_name'] && $data['patient_name'] != '') {

            $wherePatientName = " AND patient_name='" . $data['patient_name'] . "'";
        } else if ($data['patient_name'] == '') {
            $wherePatientName = " ";
        }

        if ($data['karo_no'] && $data['karo_no'] != '') {
            $wherePatientKaro = " AND (patient_karo_case_no='" . $data['karo_no'] . "' OR patient_case ='" . $data['karo_no'] . "' OR patient_master.patient_id ='" . $data['karo_no'] . "')";
        } else if ($data['karo_no'] == '') {
            $wherePatientKaro = " ";
        }

        if (isset($data['reg_date']) && $data['reg_date'] != '') {
            $regDate = " AND registration_date='" . date('Y-m-d', strtotime($data['reg_date'])) . "'";
        } else {
            $regDate = '';
        }
		
        $query = "select IFNULL(sum(approved_amount),0) as donor_approved_amount from  patient_case_status_detail
				LEFT OUTER JOIN 
				`patient_case_details` ON patient_case_status_detail.case_id=`patient_case_details`.id
				LEFT OUTER JOIN `patient_master` ON patient_master.`patient_id`=`patient_case_details`.`patient_id`
				WHERE patient_case_status_detail.case_status IN ('open','rehelp','reopen')
				AND DATE(case_status_date) >= '$from_date' AND DATE(case_status_date)<='$to_date' and doner_id =$donor_id " .$wherePatientName . $wherePatientKaro . $regDate ;

        $query = $this->db->query($query);
	
        $result = $query->result();
        return json_decode(json_encode($result), true);
    }	 
		 
		 
    function getDonorWiseDonationAmount($data) {
        // $from_date = date('Y-m-d', strtotime($data['from_date']));
        // $to_date = date('Y-m-d', strtotime($data['to_date']));
		
		 if (isset($data['from_date']) && $data['from_date'] != '') {
            $from_date = date('Y-m-d', strtotime($data['from_date']));
        } else{
        $from_date = date('Y-m-d', strtotime('2015-01-01'));
        }

          if (isset($data['to_date']) && $data['to_date'] != '') {
            $to_date = date('Y-m-d', strtotime($data['to_date']));
        } else{
        $to_date = date('Y-m-d');
        }
        $donor_id = $data['donor'];
				
		
        $query = "SELECT IFNULL(SUM(`DonationAmount`),0) AS Total_DonateAmount FROM `doner_donation_detail`
 				WHERE `DonerId`= $donor_id AND  date (`DonationDate`)>='$from_date' AND DATE(DonationDate)<='$to_date';";

        $query = $this->db->query($query);
        $result = $query->result();
        return json_decode(json_encode($result), true);
    }

    function getDonorWiseDisbursedAmount($data) {
        // $from_date = date('Y-m-d', strtotime($data['from_date']));
        // $to_date = date('Y-m-d', strtotime($data['to_date']));
		
		 if (isset($data['from_date']) && $data['from_date'] != '') {
            $from_date = date('Y-m-d', strtotime($data['from_date']));
        } else{
        $from_date = date('Y-m-d', strtotime('2015-01-01'));
        }

          if (isset($data['to_date']) && $data['to_date'] != '') {
            $to_date = date('Y-m-d', strtotime($data['to_date']));
        } else{
        $to_date = date('Y-m-d');
        }
        $donor_id = $data['donor'];
		
		 if ($data['patient_name'] && $data['patient_name'] != '') {

            $wherePatientName = " AND patient_name='" . $data['patient_name'] . "'";
        } else if ($data['patient_name'] == '') {
            $wherePatientName = " ";
        }

        if ($data['karo_no'] && $data['karo_no'] != '') {
            $wherePatientKaro = " AND (patient_karo_case_no='" . $data['karo_no'] . "' OR patient_case ='" . $data['karo_no'] . "' OR patient_master.patient_id ='" . $data['karo_no'] . "')";
        } else if ($data['karo_no'] == '') {
            $wherePatientKaro = " ";
        }

        if (isset($data['reg_date']) && $data['reg_date'] != '') {
            $regDate = " AND registration_date='" . date('Y-m-d', strtotime($data['reg_date'])) . "'";
        } else {
            $regDate = '';
        }
		
        $query = "SELECT IFNULL(SUM(`DisbursedAmt`),0) AS Total_DisbursedAmt FROM `patient_case_disbursed_detail` LEFT OUTER JOIN 
				`patient_case_details` ON patient_case_disbursed_detail.caseid=`patient_case_details`.id
				LEFT OUTER JOIN `patient_master` ON patient_master.`patient_id`=`patient_case_details`.`patient_id`  WHERE `DonorId`=$donor_id AND `DisburesedDate` BETWEEN '$from_date' AND '$to_date'"  .$wherePatientName . $wherePatientKaro . $regDate ;

        $query = $this->db->query($query);
        $result = $query->result();
        return json_decode(json_encode($result), true);
    }
    
	function filterDonorWiseDisbursedAmount($data) {
		
		$donor_id = $data['donor'];
        
	// $query="SELECT donor_disburse_amount AS Total_DisbursedAmt,
       // donermaster.DonerId AS doner_ids FROM `doner_donation_detail`
// LEFT OUTER JOIN 
// (
	// SELECT IFNULL(SUM(DisbursedAmt),0) AS donor_disburse_amount,DonorId
	// FROM patient_case_disbursed_detail  GROUP BY DonorId
	// )tbldisburse
	// ON tbldisburse.DonorId =doner_donation_detail.DonerId	
// INNER JOIN donermaster ON donermaster.DonerId=doner_donation_detail.DonerId  WHERE `DonorId`=$donor_id
// GROUP BY
// donermaster.DonerId";

$query="SELECT IFNULL(SUM(doner_donation_detail.`DonationAmount`),0) AS Total_DonateAmount,donor_approved_amount,
(IFNULL(donor_disburse_amount,0)-IFNULL(refund_amount,0)) AS disbursed_amount,
(IFNULL(donor_approved_amount,0)-IFNULL(donor_disburse_amount,0)+IFNULL(refund_amount,0)) AS approved_amount ,
(IFNULL(SUM(doner_donation_detail.`DonationAmount`),0)-IFNULL(donor_approved_amount,0)+IFNULL(refund_amount,0)) AS BalanceAmount ,
       CASE WHEN DonerType='Organisation' THEN OrganizationName ELSE CONCAT( CONCAT(donermaster.firstName,' ',donermaster.MiddleName),' ',donermaster.LastName)
       END AS Doners ,donermaster.DonerId AS doner_ids FROM `doner_donation_detail`
LEFT OUTER JOIN 
(
	SELECT IFNULL(SUM(approved_amount),0) AS donor_approved_amount,doner_id
	FROM patient_case_status_detail WHERE case_status IN ('open','rehelp','reopen') GROUP BY doner_id
	)tblapprove
	ON tblapprove.doner_id =doner_donation_detail.DonerId
LEFT OUTER JOIN 
(
	SELECT IFNULL(SUM(DisbursedAmt),0) AS donor_disburse_amount,DonorId
	FROM patient_case_disbursed_detail  GROUP BY DonorId
	)tbldisburse
	ON tbldisburse.DonorId =doner_donation_detail.DonerId	
INNER JOIN donermaster ON donermaster.DonerId=doner_donation_detail.DonerId
LEFT OUTER JOIN 
(SELECT IFNULL(SUM(refund_amount),0) AS refund_amount,Donor_id
	FROM refund_amount_details  GROUP BY Donor_id
	)tblrefund 
	ON tblrefund.Donor_id=doner_donation_detail.DonerId
	WHERE `DonorId`=$donor_id
GROUP BY
donermaster.DonerId";
        $query = $this->db->query($query);
        $result = $query->result();
        return json_decode(json_encode($result), true);
    }
	
	
	
	
     function getDonorWisePatientsReportDetailsNew($data) {
        $toDate = '';
        $fromDate = '';
        $whereDonor = '';
        $whereIsAdmin = '';
		$wherePatientName = '';
        $wherePatientKaro = '';
        $whereDept = '';
        $whereHospital = '';

        $isAdmin = $this->session->userdata('IsAdmin');
        if ($isAdmin != 1) {
            $whereIsAdmin = " AND patient_master.created_by = " . $this->session->userdata('UsertId');
        }

        if (isset($data['from_date']) && $data['from_date'] != '') {
            $fromDate = date('Y-m-d', strtotime($data['from_date']));
        } else {
            $frmDateQuery = "SELECT date(min(registration_date)) as from_date FROM patient_master";
            $frmDateQueryResult = $this->db->query($frmDateQuery);
            $dataRow = $frmDateQueryResult->row();

            if (isset($dataRow) && isset($dataRow->from_date)) {
                $fromDate = date('Y-m-d', strtotime($dataRow->from_date));
            }
        }

        if (isset($data['to_date']) && $data['to_date'] != '') {
            $toDate = date('Y-m-d', strtotime($data['to_date']));
        } else {
            $toDate = date('Y-m-d');
        }

        if (isset($data['donor_id']) && $data['donor_id'] != '') {
            $whereDonor = "AND ApprovalDetail.doner_id = '" . $data['donor_id'] . "'";
        }
		
	    if ($data['patient_name'] && $data['patient_name'] != '') {

            $wherePatientName = " AND patient_name='" . $data['patient_name'] . "'";
        } else if ($data['patient_name'] == '') {
            $wherePatientName = " ";
        }

        if ($data['karo_no'] && $data['karo_no'] != '') {
            $wherePatientKaro = " AND (patient_karo_case_no='" . $data['karo_no'] . "' OR patient_case ='" . $data['karo_no'] . "' OR patient_master.patient_id ='" . $data['karo_no'] . "')";
        } else if ($data['karo_no'] == '') {
            $wherePatientKaro = " ";
        }

        if (isset($data['reg_date']) && $data['reg_date'] != '') {
            $regDate = " AND registration_date='" . date('Y-m-d', strtotime($data['reg_date'])) . "'";
        } else {
            $regDate = '';
        }
        if ($data['department'] && $data['department'] != '') {
            $whereDept = " AND `departmentmaster`.`DeptId`='" . $data['department'] . "'";
        } else if ($data['department'] == '') {
            $whereDept = " ";
        }

        if ($data['hospital'] && $data['hospital'] != '') {
            $whereHospital = " AND `hospitalmaster`.`HospitalId`='" . $data['hospital'] . "'";
        } else if ($data['hospital'] == '') {
            $whereHospital = " ";
        }

        $query = "SELECT
                            patient_case AS CaseNo,patient_master.id AS CaseId,
                            DATE_FORMAT(`registration_date`, '%d/%m/%Y') AS `Registration Date`,
                            `patient_name` AS `Patient Name`,
                            `pt_address` AS Address,
                            CONCAT(`pt_city`, ' - ', `pt_state`) AS Location,
                            CASE WHEN DATE_FORMAT(`patient_dob`, '%d/%m/%Y')='00/00/0000' THEN '' ELSE DATE_FORMAT(`patient_dob`, '%d/%m/%Y') END AS DOB,
                            `patient_age`,
                            `patient_gender` AS Gender,
                            `patient_phone` AS `Contact No`,
                            `HospitalName` AS `Refered To`,
                            patient_master.refered_by AS `Refered By`,
                            `doctor_name` AS `Name Of Treating Doctor`,
                            patient_master.representative_name AS `Responsible Karo Representative`,
                            DATE_FORMAT(patient_case_details.updated_at,
                                    '%d/%m/%Y') AS `Case Receive Date`,
                   			`disease_diagnosed` AS `Disease Name`,
                            `departmentmaster`.`DeptName` AS `Depatment Of The Hospital`,
                            `required_fund` AS `Required Fund`,
                            DATE_FORMAT(`patient_master`.`created_at`,
                                    '%d/%m/%Y') AS `Initial Team Evaluation`,
                            IFNULL(DisbursedAmount, 0) AS `Disbursed Amount`,
                           IFNULL(`ApprovalDetail`.`approved_amount`,0) AS `Approved Amount`,
                            IF(`patient_case_details`.`case_status` = 'reject', 'rejected', `patient_case_details`.`case_status`) AS `Case Status`,
                            IFNULL(REMARK, '-') AS `Additional Comment`
                            FROM
                            patient_master
                                LEFT OUTER JOIN
                            `patient_case_details` ON `patient_case_details`.`case_number` = patient_master.`patient_case`
                                LEFT OUTER JOIN
                            `patient_financetial_details` ON `patient_financetial_details`.`case_id` = `patient_case_details`.`id`
                               LEFT OUTER JOIN
(SELECT
SUM(`approved_amount`) AS approved_amount,`case_id`, `doner_id`
FROM
`patient_case_status_detail` WHERE  DATE(IFNULL(`rehelp_date`,`case_status_date`)) BETWEEN '" . $fromDate . "' AND '" . $toDate . "'

GROUP BY `case_id`, `doner_id`) AS ApprovalDetail  ON `patient_case_details`.`id` = ApprovalDetail.case_id 

LEFT OUTER JOIN
(SELECT
SUM(`DisbursedAmt`) AS DisbursedAmount, `CaseId`, DonorId
FROM
`patient_case_disbursed_detail` WHERE DATE(patient_case_disbursed_detail.DisburesedDate) BETWEEN '" . $fromDate . "' AND '" . $toDate . "'
GROUP BY `CaseId`, `DonorId`) AS DisbursedDetail ON `patient_case_details`.`id` = DisbursedDetail.CaseId 
AND DisbursedDetail.DonorId=ApprovalDetail.doner_id
LEFT OUTER JOIN
(SELECT
SUM(`refund_amount`) AS RefundAmount, `case_id`, `donor_id`
FROM
`refund_amount_details` WHERE DATE(`refund_amount_details`.`refund_date`) BETWEEN '" . $fromDate . "' AND '" . $toDate . "'
GROUP BY `case_id`, `donor_id`) AS `refund_amount_details` ON `patient_case_details`.`id` = refund_amount_details.`case_id`
AND `refund_amount_details`.`donor_id`=ApprovalDetail.doner_id
                                LEFT OUTER JOIN
                            `hospitalmaster` ON `hospitalmaster`.`HospitalId` = `patient_case_details`.`hospital_name`
                                LEFT OUTER JOIN
                            `departmentmaster` ON `departmentmaster`.`DeptId` = `patient_case_details`.`department_name`
                                LEFT OUTER JOIN
                            `referedby` ON `referedby`.`ReferedById` = `patient_master`.`refered_by`
                                LEFT OUTER JOIN
                            `usermaster` ON `usermaster`.`UserId` = `patient_master`.`created_by`
                                LEFT OUTER JOIN
                            (SELECT
                                REMARK, `case_id`
                            FROM
                                `patient_followup_details`
                            WHERE
                                `final_status` = 1) AS Remarks ON Remarks.`case_id` = `patient_case_details`.`id`
                            WHERE
                               IFNULL(patient_master.status,0)!=1 "  
                             . $wherePatientName . $wherePatientKaro . $regDate . $whereDonor . $whereIsAdmin . $whereDept . $whereHospital;
     //prx($query);

        $query = $this->db->query($query);
        $result = $query->result();
        return json_decode(json_encode($result), true);
    }
    
    function getCaseDetailsById($CASE_NO){
        $query = $this->db->query("select id,patient_id from patient_case_details where case_number='$CASE_NO'");
        $result = $query->result();
        return $result;
    }
	
	/**
     * Get delete disbursed Details-Deepa
     */
    function getDeleteDisbursedReports($data) {
        $wherePatientName = '';
        $wherePatientKaro = '';
        $whereDept = '';
        $whereHospital = '';
        $isAdmin = $this->session->userdata('IsAdmin');
        if ($isAdmin != 1)
            $whereclause = " where patient_case_details.created_by = '" . $this->session->userdata('UsertId') . "' AND";
        else {
            $whereclause = " where";
        }

        // $from_date = date('Y-m-d', strtotime($data['from_date']));
        // $to_date = date('Y-m-d', strtotime($data['to_date']));

        if (isset($data['from_date']) && $data['from_date'] != '') {
            $from_date = date('Y-m-d', strtotime($data['from_date']));
        } else {
            $from_date = date('Y-m-d', strtotime('2015-01-01'));
        }

        if (isset($data['to_date']) && $data['to_date'] != '') {
            $to_date = date('Y-m-d', strtotime($data['to_date']));
        } else {
            $to_date = date('Y-m-d');
        }
        if ($data['department'] && $data['department'] != '') {
            $whereDept = " AND `departmentmaster`.`DeptId`='" . $data['department'] . "'";
        } else if ($data['department'] == '') {
            $whereDept = " ";
        }

        if ($data['hospital'] && $data['hospital'] != '') {
            $whereHospital = " AND `hospitalmaster`.`HospitalId`='" . $data['hospital'] . "'";
        } else if ($data['hospital'] == '') {
            $whereHospital = " ";
        }
        $where_donor = '';

        if ($data['donor']) {
            $where_donor = 'and dm.DonerId = ' . $data['donor'];
        }
 

        $query = "SELECT pcl.*,pm.patient_name,pay.PaymentMode,CASE WHEN `DonerType`='Organisation' THEN `OrganizationName` ELSE CONCAT( CONCAT(dm.FirstName,' ',dm.MiddleName),' ',dm.LastName) END AS Doner FROM patient_case_disbursed_detail_delete_log AS pcl
                  LEFT OUTER JOIN `patient_case_details` ON pcl.`caseid`=`patient_case_details`.id
                  LEFT OUTER JOIN patient_master AS pm ON pm.id=pcl.CaseId
                  INNER JOIN donermaster AS dm ON dm.DonerId=pcl.DonorId
                  INNER JOIN paymentmaster AS pay ON pay.PaymentId=pcl.PaymentModeId
                  LEFT OUTER JOIN  `hospitalmaster` ON `hospitalmaster`.`HospitalId` = `patient_case_details`.`hospital_name`
                  LEFT OUTER JOIN `departmentmaster` ON `departmentmaster`.`DeptId` = `patient_case_details`.`department_name`
                  WHERE DATE(UpdatedDate) >= '".$from_date."' AND DATE(UpdatedDate) <='".$to_date."'" . $where_donor . $whereDept . $whereHospital;
       // prx($query);
        $query = $this->db->query($query);
        $result = $query->result();
        return json_decode(json_encode($result), true);
    }

}
