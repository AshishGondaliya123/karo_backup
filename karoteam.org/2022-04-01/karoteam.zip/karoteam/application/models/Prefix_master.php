<?php
class Prefix_master extends CI_Model {
    function getNextId($type) {
        $query = $this->db->get_where('prefix_master', array('prefix_name' => $type));      
        if($query->num_rows()!=0){
            foreach($query->result() as $result){
                return $result->prefix . $result->padding . $result->last_id  ;
            }
            
        }
    }
    
       
}
?>