<?php
class Donner_model extends CI_Model {
    function savedonner($FirstName,$MiddleName,$LastName,$DonerType,$DonerAddress,$Country,$State,$City,$ZipCode,$ContactNo,$EmailId,$PANCardNumber,$OrganizationName,$MobileNo) {
        $CreatedByUserId = $this->session->userdata('UsertId');
        $query = $this->db->get_where('donermaster', array('EmailId' => $EmailId));      
        if($query->num_rows()==0){
        $query="insert into donermaster (OrganizationName,FirstName,MiddleName,LastName,DonerType,DonerAddress,Country,State,City,ZipCode,ContactNo,MobileNo,EmailId,PANCardNumber,CreatedByUserId)values('".$OrganizationName."','".$FirstName."','".$MiddleName."','".$LastName."','".$DonerType."','".$DonerAddress."','".$Country."','".$State."','".$City."','".$ZipCode."','".$ContactNo."','".$MobileNo."','".$EmailId."','".$PANCardNumber."','".$CreatedByUserId."')";            if($this->db->query($query)){
				return '<div class="alert alert-success">Saved successfully</div>';
			}else{
				return '<div class="alert alert-danger">Something went wrong</div>';
			}
        }else{
            return '<div class="alert alert-danger">Donor email already exist</div>';
        }
    }
    function getdonnerlist() {
        $this->db->select("DonerId, CONCAT(FirstName,' ',MiddleName,' ',LastName) as name");
        $this->db->order_by('DonerId', 'DESC');  //actual field name of id
        $query=$this->db->get('donermaster');
        return $query->result_array();
    }
    function getdonner() {
        $this->db->order_by('DonerId', 'DESC');  //actual field name of id
        $query=$this->db->get('donermaster');
        return $query->result_array();
    }
    function getDonnerById($id){
        $this->db->where('DonerId',$id);  //actual field name of id
        $query=$this->db->get('donermaster');
        return $query->result_array();
    }
    function getcountry() {      
        $query=$this->db->get('countries');
        return $query->result_array();
    }
    function changeStatus($id,$status) {       
        $query="update donermaster set IsActive='".$status."' where DonerId='".$id."'";
        if($this->db->query($query)){
            return '<div class="alert alert-success">Updated successfully</div>';
        }else{
            return '<div class="alert alert-danger">Something went wrong</div>';
        }
    }
   
    function updatedonner($FirstName,$MiddleName,$LastName,$DonerType,$DonerAddress,$Country,$State,$City,$ZipCode,$ContactNo,$EmailId,$PANCardNumber,$DonerId,$OrganizationName,$MobileNo) { 
        $DonerId = base64_decode($DonerId);
        $query = $this->db->get_where('donermaster', array('EmailId' => $EmailId,'DonerId !=' => $DonerId));      
        if($query->num_rows()==0){
        $query="update donermaster set FirstName = '".$FirstName."',LastName = '".$LastName."',MiddleName = '".$MiddleName."',DonerType = '".$DonerType."',DonerAddress = '".$DonerAddress."',Country = '".$Country."' ,State = '".$State."',City = '".$City."',ZipCode = '".$ZipCode."',EmailId = '".$EmailId."',PANCardNumber='".$PANCardNumber."',OrganizationName='".$OrganizationName."',MobileNO='".$MobileNo."' where DonerId='".$DonerId."'"; 
        if($this->db->query($query)){
            return '<div class="alert alert-success">Updated successfully</div>';
        }else{
            return '<div class="alert alert-danger">Something went wrong</div>';
        }
        }else{
             return '<div class="alert alert-danger">Donner email already exist</div>';
        }
    }

    function checkDonoremail($email,$donnerId){
        $this->db->select('*');
        $this->db->from('donermaster');
        if($donnerId)
            $this->db->where(array('EmailId'=>$email , 'DonerId != '=>$donnerId));
        else
            $this->db->where(array('EmailId'=>$email));
        $query = $this->db->get(); 
        // echo $this->db->last_query();exit;

        $result =  $query->result();
        if($result){
            return 'Email id already exist</div>';
        }
    }
}
?>