<?php

class Dashboard_model extends CI_Model {

    public function getCaseCounts() {
        $isAdmin = $this->session->userdata('IsAdmin');
        if ($isAdmin != 1)
            $data['created_by'] = $this->session->userdata('UsertId');

        $this->db->select('case_status, count(case_status) count ');
        $this->db->group_by('case_status');
        if ($data['created_by'])
            $this->db->where($data);
        $query = $this->db->get('patient_case_details');
        //echo $this->db->last_query();exit;
        $result = $query->result();
        return json_decode(json_encode($result), true);
    }

    public function getAgeChartInfo() {
		$whereIsAdmin = '';
        $isAdmin = $this->session->userdata('IsAdmin');


        if ($isAdmin != 1) {
       //   $data['created_by'] = $this->session->userdata('UsertId');
		  $whereIsAdmin = " AND patient_master.created_by = " . $this->session->userdata('UsertId');
        }
			
       $qu="SELECT SUM(TotalPatient) as TotalPatient ,AgeGroup
FROM
( 
SELECT CALCULATEAGE(YEAR(patient_dob)) AS AgeGroup, COUNT(CALCULATEAGE(YEAR(patient_dob)))  AS TotalPatient FROM patient_master
       
    WHERE  IFNULL(`status`,0)!= '1' AND patient_dob IS NOT NULL AND patient_dob != '0000-00-00' ". $whereIsAdmin ."
     GROUP BY  CALCULATEAGE(YEAR(patient_dob))
     
     UNION 
     
  SELECT calculateWithoutDOBAge(SUBSTRING(patient_age,1,2)) AS AgeGroup, COUNT(calculateWithoutDOBAge(SUBSTRING(patient_age,1,2))) AS 
  TotalPatient FROM patient_master WHERE IFNULL(`status`,0)!= '1' AND IFNULL(patient_dob,'')='0000-00-00'  AND IFNULL(patient_age,'')!='' ". $whereIsAdmin ."
        GROUP BY calculateWithoutDOBAge(SUBSTRING(patient_age,1,2))
        )B GROUP BY AgeGroup";
	
	$query = $this->db->query($qu);
    
    $result = $query->result();
	//echo "<pre>";
		//print_r($result);
	//	exit;	
		
       return json_decode(json_encode($result), true);
		
    }

    // public function getAgeChartInfo2() {
        // $isAdmin = $this->session->userdata('IsAdmin');
        // if ($isAdmin != 1) {
            // $data['created_by'] = $this->session->userdata('UsertId');
        // }

        // $this->db->select('calculateWithoutDOBAge(SUBSTRING(patient_age,1,2)) AS AgeGroup, COUNT(calculateWithoutDOBAge(SUBSTRING(patient_age,1,2))) AS TotalPatient');
        // $this->db->group_by('calculateWithoutDOBAge(SUBSTRING(patient_age,1,2))');
        // $this->db->where("IFNULL(patient_dob,'')='0000-00-00'  AND IFNULL(patient_age,'')!='' ");

        // if ($data['created_by']) {
            // $this->db->where("created_by", $data['created_by']);
        // }

        // $this->db->where('IFNULL(`status`,0)!=', '1');

        // $query = $this->db->get('patient_master');
       // echo $this->db->last_query();exit;
        // $result = $query->result();

        // return json_decode(json_encode($result), true);
    // }

    public function getGenderChartInfo() {
        $isAdmin = $this->session->userdata('IsAdmin');
        if ($isAdmin != 1) {
            $data['created_by'] = $this->session->userdata('UsertId');
        }

        $this->db->select('patient_gender, COUNT(patient_gender) AS total');
        $this->db->group_by('patient_gender');
        $this->db->where('patient_gender IS NOT NULL');
        $this->db->where('patient_gender != ""');

        if ($data['created_by']) {
            $this->db->where($data);
        }
        $this->db->where('IFNULL(`status`,0)!=', '1');
        $query = $this->db->get('patient_master');
        $result = $query->result();

        return json_decode(json_encode($result), true);
    }

    public function getStateChartInfo() {
        $whereIsAdmin = '';
        $isAdmin = $this->session->userdata('IsAdmin');
        if ($isAdmin != 1) {
            $whereIsAdmin = " AND patient_master.created_by = " . $this->session->userdata('UsertId');
        }

        $query = "SELECT
                            pp_state AS patinet_state, COUNT(Id) AS total, id as state_id
                        FROM
                            (SELECT
                                (id),
                                    CASE
                                        WHEN
                                            pp_state = 'Maharashtra'
                                                AND `pp_city` = 'Mumbai City'
                                        THEN
                                            pp_city
                                        WHEN
                                            pp_state = 'Maharashtra'
                                                AND pp_city = 'Thane'
                                        THEN
                                            pp_city
                                        WHEN
                                            pp_state = 'Maharashtra'
                                                AND `pp_city` <> 'Mumbai City'
                                                AND pp_city <> 'Thane'
                                        THEN
                                            pp_state
                                        ELSE pp_state
                                    END AS State,
                                    pp_state,
                                    pp_city
                            FROM
                                patient_master 
                                WHERE IFNULL(`status`,0)!= '1' and pp_state IS NOT NULL AND pp_state != '' " . $whereIsAdmin . ") A
                        GROUP BY pp_state";
						//exit;
        $query = $this->db->query($query);
        $result = $query->result();

        return json_decode(json_encode($result), true);
    }

    public function getDiseaseCount() {
        $isAdmin = $this->session->userdata('IsAdmin');
        if ($isAdmin != 1) {
            $data['pcd.created_by'] = $this->session->userdata('UsertId');
        }

        $this->db->select('count(1) as patient_count ,pcd.department_name , dm.DeptName as DiseaseName, dm.DeptId');
        $this->db->from('patient_case_details pcd');
        $this->db->join('departmentmaster dm', 'dm.DeptId = pcd.department_name');
        $this->db->join('patient_master pm', 'pm.patient_id = pcd.patient_id');
        $this->db->where('IFNULL(pm.status,0)!=', '1');
        $this->db->group_by('pcd.department_name');
        if ($data)
            $this->db->where($data);
        $query = $this->db->get();
        $result = $query->result();

        return $result;
    }

    public function getHospitalCount() {
        // $isAdmin = $this->session->userdata('IsAdmin');
        // if ($isAdmin != 1)
            // $data['pcd.created_by'] = $this->session->userdata('UsertId');

        // $this->db->select('count(1) as patient_count ,pcd.hospital_name , pcd.hospital_name as hospital_id, hm.HospitalName as name ');
        // $this->db->from('patient_case_details pcd');
        // $this->db->join('hospitalmaster hm', 'hm.HospitalId = pcd.hospital_name');
        // $this->db->join('patient_master pm', 'pm.patient_id = pcd.patient_id');
        // $this->db->where('IFNULL(pm.status,0)!=', '1');
        // $this->db->group_by('pcd.hospital_name');
        // if ($data)
            // $this->db->where($data);
        // $query = $this->db->get();
        // $result = $query->result();

        // return $result;
		
			$whereIsAdmin = '';
        $isAdmin = $this->session->userdata('IsAdmin');


        if ($isAdmin != 1) {
       //   $data['created_by'] = $this->session->userdata('UsertId');
		  $whereIsAdmin = " AND pcd.created_by = " . $this->session->userdata('UsertId');
        }
			
       $qu="SELECT COUNT(1) AS patient_count, 
`pcd`.`hospital_name`, 
`pcd`.`hospital_name` AS `hospital_id`, 
`hm`.`HospitalName` AS `name` 
FROM `patient_case_details` `pcd` 
JOIN `hospitalmaster` `hm` ON `hm`.`HospitalId` = `pcd`.`hospital_name` 
JOIN `patient_master` `pm` ON `pm`.`patient_id` = `pcd`.`patient_id` 
WHERE IFNULL(pm.status,0) != '1' ". $whereIsAdmin ."  GROUP BY `pcd`.`hospital_name` HAVING COUNT(1)>=50 

UNION


SELECT SUM(patient_count) AS patient_count,
'other' AS `hospital_name`, 
-1 AS `hospital_id`, 
'other' AS `name` FROM 
(
SELECT COUNT(pcd.patient_id) AS patient_count 
FROM `patient_case_details` `pcd` 
JOIN `patient_master` `pm` ON `pm`.`patient_id` = `pcd`.`patient_id`
JOIN `hospitalmaster` `hm` ON `hm`.`HospitalId` = `pcd`.`hospital_name` 
WHERE IFNULL(pm.status,0) !='1'  ". $whereIsAdmin ." GROUP BY `pcd`.`hospital_name` HAVING COUNT(1)<50 
 ) AS a";
	
	$query = $this->db->query($qu);

    $result = $query->result();
	// echo "<pre>";
		// print_r($result);
		// exit;	
		
       return json_decode(json_encode($result), true);
    }

    public function getUserCount() {
        $isAdmin = $this->session->userdata('IsAdmin');
		if ($isAdmin != 1)
            $data['pcd.created_by'] = $this->session->userdata('UsertId');
        $this->db->select("count(pcd.id) as patient_count ,pm.representative_name as UserId,CONCAT(um.FirstName ,' ',MiddleName,' ', LastName) AS re_name");
        $this->db->from('patient_case_details pcd');
        $this->db->join('patient_master pm', 'pm.patient_id = pcd.patient_id');
		$this->db->join('usermaster um', 'pm.representative_name = um.UserId','LEFT OUTER');
        $this->db->where('(pcd.created_by IS NOT NULL OR pcd.created_by != "")');
        $this->db->where('IFNULL(`status`,0)!=', '1');
        $this->db->group_by('pm.representative_name');
		if ($data)
            $this->db->where($data);
        $query = $this->db->get();
		//echo $this->db->last_query() ;exit;
        $result = $query->result();

        return $result;
			
    }

    public function getUpcomingBirthdays($f) {
        $isAdmin = $this->session->userdata('IsAdmin');
        if ($isAdmin != 1)
            $where = ' and created_by =' . $this->session->userdata('UsertId');
        else
            $where = "";
//         $query ="SELECT patient_id,patient_name,DATE_FORMAT(patient_dob,'%d/%m/%Y') AS patient_dob ,patient_phone
//         		FROM patient_master
//         		WHERE MONTH(patient_dob) BETWEEN MONTH(NOW()) AND (MONTH(NOW()))+2".$where;
//        $query = "SELECT patient_id,patient_name,DATE_FORMAT(DATE_ADD(patient_dob, INTERVAL YEAR(CURDATE())-YEAR(patient_dob) YEAR),'%d/%m/%Y') AS patient_dob ,patient_phone
//			FROM patient_master
//			WHERE (MONTH(patient_dob) BETWEEN MONTH(NOW()) AND (MONTH(NOW()))+2 )
//			AND DATE_ADD(patient_dob, INTERVAL YEAR(CURDATE())-YEAR(patient_dob) YEAR)>DATE_ADD(DATE(NOW()),INTERVAL -2 DAY)
//			ORDER BY DATE_ADD(patient_dob, INTERVAL YEAR(CURDATE())-YEAR(patient_dob) YEAR)";
        
        if(empty($f)){
            $var = date("m");
        }else{
            $var = $f;
        }
        $where_day = "";
        if($var == date("m")){
            $where_day = " AND (DAY(patient_dob) >= ".date('d').")";
        }
        
       // $query = "SELECT patient_id, 
        //          patient_name, 
       //           CASE WHEN (MONTH(patient_dob)=1 OR MONTH(patient_dob)=2) AND (MONTH(NOW())=11 OR MONTH(NOW())=12) THEN 
       //           DATE_FORMAT(DATE_ADD(patient_dob, INTERVAL YEAR(CURDATE())-YEAR( 
        //                                         patient_dob) +1
        //                                         YEAR), '%d/%m/%Y')
       //                                          ELSE
       //                                           DATE_FORMAT(DATE_ADD(patient_dob, INTERVAL YEAR(CURDATE())-YEAR( 
       //                                          patient_dob)
       //                                          YEAR), '%d/%m/%Y')
       //                                          END  AS patient_dob, 
      //            patient_phone 
       //           FROM   patient_master 
       //           WHERE  CASE WHEN MONTH(NOW())=11 THEN MONTH(patient_dob) = 11 OR MONTH(patient_dob) = 12 OR MONTH(patient_dob)=1
		//	WHEN MONTH(NOW())=12 THEN MONTH(patient_dob) = 12 OR MONTH(patient_dob) = 2 OR MONTH(patient_dob)=1
		//	ELSE (MONTH(patient_dob) BETWEEN MONTH(NOW()) AND (MONTH(NOW()))".$var." )
		//	END 
       //           and IFNULL(`patient_master`.`status`,0)!= '1'
       //           ORDER BY Date_add(patient_dob, INTERVAL Year(Curdate())-Year(patient_dob)+1 
       //                         year) ";

$query = "SELECT id,patient_id, 
                  patient_name, DATE_FORMAT(patient_dob, '%d/%m/%Y') as dob,patient_age,
                  CASE WHEN (MONTH(patient_dob)< MONTH(NOW())) THEN  
                  DATE_FORMAT(DATE_ADD(patient_dob, INTERVAL YEAR(CURDATE())-YEAR( 
                                                 patient_dob) +1
                                                 YEAR), '%d/%m/%Y')
                                                 ELSE
                                                  DATE_FORMAT(DATE_ADD(patient_dob, INTERVAL YEAR(CURDATE())-YEAR( 
                                                 patient_dob)
                                                 YEAR), '%d/%m/%Y')
                                                 END  AS patient_dob, 
                  patient_phone 
                  FROM   patient_master 
                  WHERE  (MONTH(patient_dob) =".$var." ) $where_day
			
                  and IFNULL(`patient_master`.`status`,0)!= '1' $where
                  ORDER BY Date_add(patient_dob, INTERVAL Year(Curdate())-Year(patient_dob)+1 
                                year) ";
								
								
        $result = $this->db->query($query);
        return $result->result();
    }

    //akash rai 13 march 2020
    public function getcnt() {
        $sql = "SELECT `case_status`, COUNT(case_status) COUNT FROM `patient_case_details` 
                WHERE patient_id NOT IN (SELECT patient_id FROM patient_master WHERE IFNULL(`status`,0)!= '1')
                GROUP BY `case_status`";
        $result = $this->db->query($sql);
        return $result->result();
    }
	
	// deepa ...Create graph for donor wise approve/sanction/disbursed amount
	 function getDonorApprovedAmount() {

        $query = "SELECT IFNULL(SUM(approved_amount),0) AS donor_approved_amount,CASE WHEN DonerType='Organisation' THEN OrganizationName ELSE CONCAT( CONCAT(donermaster.firstName,' ',donermaster.MiddleName),' ',donermaster.LastName) END AS Doner ,donermaster.DonerId as doner_id FROM  patient_case_status_detail
                  INNER JOIN donermaster ON donermaster.DonerId=patient_case_status_detail.doner_id WHERE case_status IN ('open','rehelp','reopen') GROUP BY
    donermaster.DonerId";

        $query = $this->db->query($query);
        $result = $query->result();
        return $result;
    }

    function getDonorDonationAmount() {

        $query = "SELECT IFNULL(SUM(`DonationAmount`),0) AS Total_DonateAmount,CASE WHEN DonerType='Organisation' THEN OrganizationName ELSE CONCAT( CONCAT(donermaster.firstName,' ',donermaster.MiddleName),' ',donermaster.LastName) END AS Doners ,donermaster.DonerId as doner_ids FROM `doner_donation_detail`
  INNER JOIN donermaster ON donermaster.DonerId=doner_donation_detail.DonerId GROUP BY
    donermaster.DonerId";


        $query = $this->db->query($query);
        $result = $query->result();
        return $result;
    }

    function getDonorDisbursedAmount() {

        $query = "SELECT IFNULL(SUM(`DisbursedAmt`),0) AS Total_DisbursedAmt,CASE WHEN DonerType='Organisation' THEN OrganizationName ELSE CONCAT( CONCAT(donermaster.firstName,' ',donermaster.MiddleName),' ',donermaster.LastName) END AS Donerss ,donermaster.DonerId as doner_idss FROM `patient_case_disbursed_detail`
  INNER JOIN donermaster ON donermaster.DonerId=patient_case_disbursed_detail.DonorId GROUP BY
    donermaster.DonerId";
	
	// $query="SELECT   CASE WHEN DonerType='Organisation' THEN OrganizationName ELSE CONCAT( CONCAT(donermaster.firstName,' ',donermaster.MiddleName),' ',donermaster.LastName) END AS Doner
// ,(donate.Total_DonateAmount - approved.donor_approved_amount) as BalanceAmount 
// FROM     donermaster 
// LEFT JOIN 
        // (
        // select  DonerId
        // ,       sum(DonationAmount) as Total_DonateAmount
        // from  doner_donation_detail
        // group by
                // DonerId
        // ) as donate
// ON      donate.DonerId = donermaster.DonerId
// LEFT JOIN 
        // (
        // select  doner_id
        // ,       SUM(approved_amount) as donor_approved_amount
        // from    patient_case_status_detail
		 // WHERE case_status IN ('open','rehelp','reopen')
        // group by
                // doner_id
        // ) as approved 
// ON      approved.doner_id = donermaster.DonerId";

        $query = $this->db->query($query);
        $result = $query->result();
        return $result;
    }
	
	function getDonorAmountDetail(){
		
		// $query="SELECT IFNULL(SUM(doner_donation_detail.`DonationAmount`),0) AS Total_DonateAmount,donor_approved_amount,donor_disburse_amount,
       // (IFNULL(SUM(doner_donation_detail.`DonationAmount`),0)-donor_disburse_amount) AS BalanceAmount ,
       // CASE WHEN DonerType='Organisation' THEN OrganizationName ELSE CONCAT( CONCAT(donermaster.firstName,' ',donermaster.MiddleName),' ',donermaster.LastName)
       // END AS Doners ,donermaster.DonerId AS doner_ids FROM `doner_donation_detail`
// LEFT OUTER JOIN 
// (
	// SELECT IFNULL(SUM(approved_amount),0) AS donor_approved_amount,doner_id
	// FROM patient_case_status_detail WHERE case_status IN ('open','rehelp','reopen') GROUP BY doner_id
	// )tblapprove
	// ON tblapprove.doner_id =doner_donation_detail.DonerId
// LEFT OUTER JOIN 
// (
	// SELECT IFNULL(SUM(DisbursedAmt),0) AS donor_disburse_amount,DonorId
	// FROM patient_case_disbursed_detail  GROUP BY DonorId
	// )tbldisburse
	// ON tbldisburse.DonorId =doner_donation_detail.DonerId	
// INNER JOIN donermaster ON donermaster.DonerId=doner_donation_detail.DonerId
// GROUP BY
// donermaster.DonerId";

$query="SELECT IFNULL(SUM(doner_donation_detail.`DonationAmount`),0) AS Total_DonateAmount,donor_approved_amount,
(IFNULL(donor_disburse_amount,0)-IFNULL(refund_amount,0)) AS disbursed_amount,
(IFNULL(donor_approved_amount,0)-IFNULL(donor_disburse_amount,0)+IFNULL(refund_amount,0)) AS approved_amount ,
(IFNULL(SUM(doner_donation_detail.`DonationAmount`),0)-IFNULL(donor_approved_amount,0)+IFNULL(refund_amount,0)) AS BalanceAmount ,
       CASE WHEN DonerType='Organisation' THEN OrganizationName ELSE CONCAT( CONCAT(donermaster.firstName,' ',donermaster.MiddleName),' ',donermaster.LastName)
       END AS Doners ,donermaster.DonerId AS doner_ids FROM `doner_donation_detail`
LEFT OUTER JOIN 
(
	SELECT IFNULL(SUM(approved_amount),0) AS donor_approved_amount,doner_id
	FROM patient_case_status_detail WHERE case_status IN ('open','rehelp','reopen') GROUP BY doner_id
	)tblapprove
	ON tblapprove.doner_id =doner_donation_detail.DonerId
LEFT OUTER JOIN 
(
	SELECT IFNULL(SUM(DisbursedAmt),0) AS donor_disburse_amount,DonorId
	FROM patient_case_disbursed_detail  GROUP BY DonorId
	)tbldisburse
	ON tbldisburse.DonorId =doner_donation_detail.DonerId	
INNER JOIN donermaster ON donermaster.DonerId=doner_donation_detail.DonerId
LEFT OUTER JOIN 
(SELECT IFNULL(SUM(refund_amount),0) AS refund_amount,Donor_id
	FROM refund_amount_details  GROUP BY Donor_id
	)tblrefund 
	ON tblrefund.Donor_id=doner_donation_detail.DonerId
GROUP BY
donermaster.DonerId";

$query = $this->db->query($query);
        $result = $query->result();
        return $result;
	}

}
