<?php
class Patientstatus_model extends CI_Model {
    function savePatientStatus($PatientStatus) {
        $CreatedByUserId = $this->session->userdata('UsertId');
        $query = $this->db->get_where('patientstatus', array('PatientStatus' => $PatientStatus));      
        if($query->num_rows()==0){
        $query="insert into patientstatus (PatientStatus,CreatedByUserId)values('".$PatientStatus."','".$CreatedByUserId."')";
            if($this->db->query($query)){
            return '<div class="alert alert-success">Saved successfully</div>';
			}else{
				return '<div class="alert alert-danger">Something went wrong</div>';
			}
        }else{
            return '<div class="alert alert-danger">Patient status already exist</div>';
        }
    }
    function getPatientStatus() {
        $this->db->order_by('PatientStatusId', 'DESC');  //actual field name of id
        $query=$this->db->get('patientstatus');
        return $query->result_array();
    }
    function changeStatus($id,$status) {       
        $query="update patientstatus set IsActive='".$status."' where PatientStatusId='".$id."'";
        if($this->db->query($query)){
            return '<div class="alert alert-success">Status updated successfully</div>';
        }else{
            return '<div class="alert alert-danger">Something went wrong</div>';
        }
    }
    function changePatientStatus($name,$id) { 
        $query = $this->db->get_where('patientstatus', array('PatientStatus' => $name,'PatientStatusId !=' => $id));      
        if($query->num_rows()==0){
            $query="update patientstatus set PatientStatus = '".$name."' where PatientStatusId='".$id."'";
            if($this->db->query($query)){
                return '<div class="alert alert-success">Updated successfully</div>';
            }else{
                return '<div class="alert alert-danger">Something went wrong</div>';
            }
        }else{
            return '<div class="alert alert-danger">Patient status already exist</div>';
        }
    }
}
?>