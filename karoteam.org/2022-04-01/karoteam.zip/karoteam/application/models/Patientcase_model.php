<?php

class Patientcase_model extends CI_Model {

    function getPatientCase($case_id) {
        $query = $this->db->get_where('patient_case_details', array('id' => $case_id));
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
    }

    function getPatientCaseByCaseNumber($case_number) {
        $query = $this->db->get_where('patient_case_details', array('case_number' => $case_number));
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
    }

    function savePatientCase($caseId, $data, $patient_id = 0) {
        if ($caseId && !$patient_id) {
            // prx(111);
            $data['created_at'] = date("Y-m-d H:i:s");
            $data['updated_by'] = $this->session->get_userdata('UsertId')['UsertId'];
            $this->db->where('id', $caseId);
            $str1 = $this->db->update('patient_case_details', $data);
            // prx($this->db->last_query());
            $case_id = $caseId;
        } else {
            $data['created_by'] = $this->session->get_userdata('UsertId')['UsertId'];
            $data['patient_id'] = $patient_id;
            $data["case_number"] = $this->prefix_master->getNextId('Case');
            $str1 = $this->db->insert('patient_case_details', $data);
            //opening a new case of patient
            $case_id = $this->db->insert_id();
        }

        return $case_id;
    }

    function savePatientFinance($caseId, $data, $finance_id = 0) {
        if ($data['required_fund1']) {
            $data['required_fund'] = $data['required_fund1'];
            unset($data['required_fund1']);
        }
        $this->db->where('case_id', $caseId);
        $query_check = $this->db->get('patient_financetial_details');
        // echo $this->db->last_query();exit;
        $case_exist = $query_check->result();
        // if ($caseId && empty($finance_id)) {
        if (empty($case_exist)) {

            unset($data["finance_id"]);
            $data['case_id'] = $caseId;
            $data['created_at'] = date("Y-m-d H:i:s");
            $data['created_by'] = $this->session->get_userdata('UsertId')['UsertId'];
            $this->db->where('id', $caseId);
            $str1 = $this->db->insert('patient_financetial_details', $data);
        } else {
            unset($data["finance_id"]);
            $data['case_id'] = $caseId;
            $data['updated_by'] = $this->session->get_userdata('UsertId')['UsertId'];
            $this->db->where('id', $case_exist[0]->id);
            $str1 = $this->db->update('patient_financetial_details', $data);
        }
        return $caseId;
    }

    function savePatientDocument($caseId, $data, $document_id = 0) {
        if ($caseId && empty($document_id)) {
            unset($data["document_id"]);
            $data['case_id'] = $caseId;
            $data['created_at'] = date("Y-m-d H:i:s");
            $data['created_by'] = $this->session->get_userdata('UsertId')['UsertId'];
            //$this->db->where('id', $caseId);
            $str1 = $this->db->insert('patient_documents_details', $data);
        } else {
            unset($data["document_id"]);
            $data['case_id'] = $caseId;
            $data['updated_by'] = $this->session->get_userdata('UsertId')['UsertId'];
            $this->db->where('id', $document_id);
            $str1 = $this->db->update('patient_documents_details', $data);
        }
        return $caseId;
    }

    function savePatientFollowup($caseId, $data, $finance_id = 0) {
        if ($caseId && empty($finance_id)) {
            unset($data["finance_id"]);
            $data['case_id'] = $caseId;
            $data['created_at'] = date("Y-m-d H:i:s");
            $data['created_by'] = $this->session->get_userdata('UsertId')['UsertId'];
            $this->db->where('id', $caseId);
            $str1 = $this->db->insert('patient_financetial_details', $data);
        } else {
            unset($data["finance_id"]);
            $data['case_id'] = $caseId;
            $data['updated_by'] = $this->session->get_userdata('UsertId')['UsertId'];
            $this->db->where('id', $finance_id);
            $str1 = $this->db->update('patient_financetial_details', $data);
        }
        return $caseId;
    }

    function savePatientNotes($caseId, $data, $note_id = 0) {
        if ($caseId && empty($note_id)) {
            unset($data["note_id"]);
            $data['case_id'] = $caseId;
            $data['created_at'] = date("Y-m-d H:i:s");
            $data['created_by'] = $this->session->get_userdata('UsertId')['UsertId'];
            $str1 = $this->db->insert('patient_case_notes', $data);
        } else {
            unset($data["note_id"]);
            $data['case_id'] = $caseId;
            $data['updated_by'] = $this->session->get_userdata('UsertId')['UsertId'];
            // $data["updated_by"] = $this->session->userdata('UsertId');
            $this->db->where('id', $note_id);
            $str1 = $this->db->update('patient_case_notes', $data);
        }
        return $caseId;
    }

    function updatePatientUploads($file_url, $id) {
        $data['file_urls'] = $file_url;
        $data['updated_by'] = $this->session->get_userdata('UsertId')['UsertId'];
        $this->db->where('id', $id);
        $str1 = $this->db->update('patient_documents_details', $data);
    }

    function getPatientFinance($caseId) {
        if ($caseId) {
            $query = $this->db->get_where('patient_financetial_details', array('case_id' => $caseId));

            if ($query->num_rows() > 0) {
                return $query->result_array()[0];
            }
        }
    }

    function getPatientDocument($caseId) {
        if ($caseId) {
            $query = $this->db->get_where('patient_documents_details', array('case_id' => $caseId));

            if ($query->num_rows() > 0) {
                return $query->result_array()[0];
            }
        }
    }

    function getPatientNotes($caseId) {
        if ($caseId) {
            $query = $this->db->get_where('patient_case_notes', array('case_id' => $caseId));

            if ($query->num_rows() > 0) {
                return $query->result_array()[0];
            }
        }
    }

    function getPatientNotesById($id) {
        if ($id) {
            $query = $this->db->get_where('patient_documents_details', array('id' => $id));
            if ($query->num_rows() > 0) {
                return $query->result_array()[0];
            }
        }
    }

    function getPatientFollowup($caseId) {
        if ($caseId) {
            $query = $this->db->get_where('patient_followup_details', array('case_id' => $caseId));

            if ($query->num_rows() > 0) {
                return $query->result_array();
            }
        }
    }

    function saveUpdateTrusts($data, $rec_id, $case) {
        switch ($case) {
            case "save":
                $this->db->insert('case_trust', $data);
                break;
            case "update":
                $this->db->where('id', $rec_id);
                $this->db->update('case_trust', $data);
                break;
        }
    }

    function getPatientCaseTrusts($caseId) {
        if ($caseId) {
            $query = $this->db->get_where('case_trust', array('case_id' => $caseId)); //,'amount >'=>0.00

            if ($query->num_rows() > 0) {
                return $query->result_array();
            }
        }
    }

    function getAllActiveSocialWorkers() {
		

        $this->db->select('UserId,FirstName,MiddleName,LastName');
         $this->db->where(array('IsActive' => 1));
        $this->db->where_in('UserType',array('Manager','Social Worker'));
        $query = $this->db->get('usermaster');
        // echo $this->db->last_query();exit;
        $result_array = $query->result_array();
        $result = array();
        if ($result_array)
            foreach ($result_array as $key => $value) {
                $result[$value['UserId']] = $value;
            }
        return $result;
    }

    function getPtMasterDetails($cu_id) {
        $query = "SELECT
		            CONCAT(um.FirstName, ' ', `MiddleName`, ' ', LastName)  AS representative_name,
                    pm.caregiver_name,
                    pm.caregiver_phone,
                    pm.caregiver_name2,
                    pm.caregiver_phone2,
                    pm.registration_date,
                    pm.patient_name,
                    pm.patient_image,
                    pm.refered_by  as ReferedByName,
                   
                    pm.referral_name,
                    pm.referral_details as  Contact_Details_Of_Referral,
                    pm. registration_site,
                    pm.patient_case,
                    pm.patient_karo_case_no,
                    -- RF.ReferedByName,
                    -- RF.ContactNo AS Contact_Details_Of_Referral,
                    pm.patient_gender AS Patient_Gender,
                    pm.patient_dob,
                    pm.patient_age AS Patient_Age,
                    CONCAT(patient_language,
                            ' ',
                            patient_language_other) AS Language_Spoken,
                    CONCAT(pt_address, ' ',pt_state,' ,', pt_city, ' ', pt_zip) AS Patient_Address,
                    CONCAT(pp_address, ' ',pp_state,' ,', pp_city, ' ', pp_zip) AS Patient_Permanent_Address,
                    --CONCAT(patient_phone, ',', caregiver_phone) AS ContactNOs,
                    --case when (patient_phone = '') then caregiver_phone Else  CONCAT(patient_phone, ',', caregiver_phone, ',', caregiver_phone2)end AS ContactNOs,
                    case when (patient_phone = '') then caregiver_phone Else  CONCAT(patient_phone)end AS ContactNOs,

                    IFNULL(TotalFamilyMembers, 0) AS TotalFamilyMembers
                FROM
                    patient_master AS pm
                        LEFT OUTER JOIN
                    (SELECT
                        COUNT(id) AS TotalFamilyMembers, patient_id
                    FROM
                        patient_family_details
                    GROUP BY patient_id) AS FamilyCount ON pm.id = FamilyCount.patient_id
                        LEFT OUTER JOIN
                    referedby RF ON RF.ReferedById = pm.refered_by 
					LEFT OUTER JOIN usermaster um ON um.UserId=pm.representative_name WHERE pm.patient_id ='" . $cu_id . "'";
       //prx($query);
        $result = $this->db->query($query);
        return $result->result();
    }

    function getPtFamilyDetails($cu_id) {
        //$query = "SELECT `relative_name` AS Relative_Name,`relative_age` ,`relation`,`occupation`,`salary`,duration,income_details,`patient_master`.id,`patient_master`.`patient_id` FROM `patient_master`
        //JOIN `patient_family_details` ON `patient_master`.id=`patient_family_details`.`patient_id` WHERE `patient_master`.`patient_id`= '$cu_id' AND (patient_family_details.relative_age!='YY,MM' OR patient_family_details.relative_age!='0') ";

        $query = "SELECT `relative_name` AS Relative_Name,`relative_age` ,`relation`,`occupation`,`salary`,duration,income_details,`patient_master`.id,`patient_master`.`patient_id` FROM `patient_master`
            JOIN `patient_family_details` ON `patient_master`.id=`patient_family_details`.`patient_id` WHERE `patient_master`.`patient_id`= '$cu_id'";

// prx($query);
        $result = $this->db->query($query);
        return $result->result();
    }

    function getPtMedicalDetails($patient_id) {
        $query = "SELECT `case_number` AS Patient_CaseNo ,
                        `blood_group` AS Blood_Group ,
                        CONCAT(`HospitalName`,', ',`Address`, ' ', `City`, ' ', `State`,' ',`ZipCode`) AS Hospital_Name_Address,
                        departmentmaster.`DeptName` AS Department,
                        `disease_diagnosed`,
                        
                        `doctor_name` AS Doctor_Name,
                        medicines_details,
                        
                         `current_diagnosed_detail`  AS Disease_Detail,
                         `problem_detected_date` AS Disease_Detect_date,
                         `treatment_completed_details` AS Treatment_Complete_Details,
                         IFNULL(`healing_time`,'') AS Healing_Time,
                         IFNULL(`path_to_heal`,'') AS Healing_Details,
                         CASE WHEN (IFNULL(`pre_surgery_or_transplant`,0)=1)THEN 'Pre-Surgery' ELSE ''  END AS Pre_Surgery,
                          CASE WHEN IFNULL(`medicines`,0)=1 THEN 'Medicine'  ELSE '' END AS Medicine,
                          CASE WHEN IFNULL(`pre_transplant`,0)=1 THEN 'pre_transplant'  ELSE '' END AS pre_transplant,
                         CASE WHEN IFNULL(`post-surgery_or_treatment`,0)=1 THEN 'Post-Surgery' ELSE ' ' END AS Post_Surgery,
                         CASE WHEN IFNULL(`post-treatment`,0)=1 THEN 'post-treatment' ELSE ' ' END AS post_treatment,

                         CASE WHEN IFNULL(`hospitalized`,0)=1 THEN 'Hospitalized' ELSE ' ' END AS Hospitalized,
                         CASE WHEN IFNULL(`exercise`,0)=1 THEN 'Exercise' ELSE ' ' END AS Excercise
                         FROM `patient_case_details`
                         LEFT OUTER JOIN `hospitalmaster` ON `hospitalmaster`.`HospitalId`=`patient_case_details`.`hospital_name`
                         LEFT OUTER JOIN `departmentmaster` ON `departmentmaster`.`DeptId`=`patient_case_details`.`department_name`
                         WHERE `patient_case_details`.`patient_id`='$patient_id'
                         ";
        $result = $this->db->query($query);
        return $result->result();
    }

    function getPtFinancialDetails($patient_id) {
        $query = "SELECT `case_id`,
                    CASE WHEN (`owned_house`)=1 THEN 'House - Yes' ELSE 'House - No' END AS `owned_house`,
                    CASE WHEN (`owned_land`)=1 THEN 'Land - Yes' ELSE 'Land - No' END AS `owned_land`,
                    CASE WHEN (`owned_shop`)=1 THEN 'Shop - Yes' ELSE 'Shop - No' END AS `owned_shop`,
                    CASE WHEN (`owned_vechicle`)=1 THEN 'vechicle - Yes' ELSE 'Vechicle - No' END AS `owned_vechicle`,
                    CASE WHEN (`owned_other`)=1 THEN CONCAT ('Other - ', `other_accets_details`)  ELSE 'Other - No' END AS `owned_other`,
                    CASE WHEN (`rent_amount`)>0 THEN CONCAT ('Rent - Rs ', `rent_amount`)  ELSE 'Rent - No ' END AS `rent_amount`,
                    CASE WHEN (`school_fees_amount`)>0 THEN CONCAT ('School Fee - Rs ', `school_fees_amount`)  ELSE 'School Fee - No ' END AS `school_fees_amount`,
                    CASE WHEN (`cable_amount`)>0 THEN CONCAT ('Cable - Rs ', `cable_amount`)  ELSE 'Cable - No' END AS `cable_amount`,
                    CASE WHEN (`electric_city_amount`)>0 THEN CONCAT ('Electricity - Rs ', `electric_city_amount`)  ELSE 'Electricity - No' END AS `electric_city_amount`,
                    CASE WHEN (`food_amount`)>0 THEN CONCAT ('Food - Rs ', `food_amount`)  ELSE 'Food - NO ' END AS `food_amount`,
                    CASE WHEN (`transport_amount`)>0 THEN CONCAT ('Transport - Rs ', `transport_amount`)  ELSE 'Transport - No' END AS `transport_amount`,
                    CASE WHEN (`other_expense_amount`)>0 THEN CONCAT ('Other - Rs ', `other_expense_amount`)  ELSE 'Other - No' END AS `other_expense_amount`,
                    `other_expense_detail`,
                    `money_already_expend`,
                    CASE WHEN (IFNULL(`sale_any_assest`,0)=1) THEN CONCAT ('YES - ', `sale_assest_detail`) ELSE 'NO'END AS `sale_any_assest`,
                    CASE WHEN (IFNULL(`any_loan`,0)=1) THEN CONCAT ('YES - ', `loan_detail`) ELSE 'NO' END AS `loan_detail`,
                    CASE WHEN (IFNULL(`insurance_or_Medicalim`,0)=1) THEN CONCAT ('YES - ', `insurance_detail`) ELSE 'NO' END AS `insurance_detail`,

                    CASE WHEN (IFNULL(`treatment_expenses_own`,0)=1 )THEN CONCAT ('Own Savings -  Yes') ELSE 'Own Savings -  No' END AS `treatment_expenses_own`,
                    CASE WHEN (IFNULL(`treatment_expenses_friend`,0)=1) THEN CONCAT ('Friends -  Yes') ELSE 'Friends -  No' END AS `treatment_expenses_friend`,
                    CASE WHEN (IFNULL(`treatment_expenses_loan`,0)=1) THEN CONCAT ('Loan -  Yes') ELSE 'Loan -  No' END AS `treatment_expenses_loan`,
                    CASE WHEN (IFNULL(`treatment_expenses_relatives`,0)=1 )THEN CONCAT ('Relative -  Yes') ELSE 'Relative -  No' END AS `treatment_expenses_relatives`,
                    CASE WHEN (IFNULL(`treatment_expenses_othertrust`,0)=1) THEN CONCAT ('Other Trusts -  Yes ') ELSE 'Other Trusts -  No' END AS `treatment_expenses_othertrust`,
                    `other_trust_amount`,
                    `required_fund`,
                    `approved_amount`,
                    CASE WHEN (IFNULL(`requirement_for`,'')='ST') THEN 'Short Term' WHEN (IFNULL(`requirement_for`,'')='LT') THEN 'Long Term' ELSE '' END AS Fund_Required_For,
                    CASE WHEN (IFNULL(`fund_requirement`,'')='OT') THEN 'Open Time' WHEN (IFNULL(`fund_requirement`,'')='RT') THEN 'Recurring' ELSE '' END AS Funding_Requirement_For,
                    CASE WHEN (IFNULL(`funding_cover_surgery`,0)='') THEN ''  ELSE 'Surgery' END AS `funding_cover_surgery`,
                    CASE WHEN (IFNULL(`funding_cover_treatment`,0)='') THEN ''  ELSE 'Treatment' END AS `funding_cover_treatment`,
                    CASE WHEN (IFNULL(`funding_cover_meditation`,0)='') THEN ''  ELSE 'Meditaion' END AS `funding_cover_meditation`,
                    CASE WHEN (IFNULL(`funding_cover_dalyexpense`,0)='') THEN ''  ELSE 'DailyExpenses' END AS `funding_cover_dalyexpense`,
                    CASE WHEN (IFNULL(`funding_cover_travelling`,0)='') THEN ''  ELSE 'Travelling' END AS `funding_cover_travelling`,
                    CASE WHEN (IFNULL(`funding_cover_food`,0)='') THEN ''  ELSE 'Food' END AS `funding_cover_food`,
                    CASE WHEN (IFNULL(`funding_cover_other`,0)='') THEN ''  ELSE funding_cover_other_details END AS `funding_cover_other`,
                    -- CASE WHEN (IFNULL(`pbf_pcf`,0)=0) THEN 'No' WHEN (IFNULL(`pbf_pcf`,1)='1') THEN 'Yes'  ELSE 'NA' END AS `pbf_pcf`,
                    -- CASE WHEN (IFNULL(`prev_funding`,'')=1) THEN  'Because of their policy'  WHEN (IFNULL(`prev_funding`,'')=0) THEN  'Rules and regulations' ELSE 'NA'   END AS `prev_funding`,
                    `fund_specify`,pbf_pcf_amt,fund_requirement,prev_funding,pbf_pcf



                    FROM `patient_financetial_details`
                    JOIN    `patient_case_details` ON `patient_case_details`.`id`=`patient_financetial_details`.`case_id`
                    WHERE `patient_case_details`.`patient_id`='$patient_id'";

        $result = $this->db->query($query);
        return $result->result();
    }

    function getptOtherDetails($patient_id) {
//        $query = " SELECT trust_name ,amount,trust_status  FROM `case_trust` JOIN `patient_case_details` ON `case_trust`.`case_id`=`patient_case_details`.`id`
//            WHERE `patient_case_details`.`patient_id`='$patient_id' and amount >0.00";
        $query = " SELECT trust_name ,amount,trust_status  FROM `case_trust` JOIN `patient_case_details` ON `case_trust`.`case_id`=`patient_case_details`.`id`
            WHERE `patient_case_details`.`patient_id`='$patient_id'";
        $result = $this->db->query($query);
        return $result->result();
    }

    function getPtDocumentDetails($patient_id) {

        $query = " SELECT `patient_id`,
                    CASE WHEN IFNULL(`birth_certificates`,0)=0 THEN 0 ELSE 1 END AS Birth_certificate,
                    CASE WHEN IFNULL(`income_certificate`,0)=0 THEN 0 ELSE 1 END AS income_certificate,
                    CASE WHEN IFNULL(`ration_card`,0)=0 THEN 0 ELSE 1 END AS ration_card,
                    CASE WHEN IFNULL(`adhaar_card`,0)=0 THEN 0 ELSE 1 END AS adhaar_card,
                    CASE WHEN IFNULL(`salary_slips`,0)=0 THEN 0 ELSE 1 END AS salary_slips,
                    CASE WHEN IFNULL(`pan_card_or_election_id`,0)=0 THEN 0 ELSE 1 END AS pan_card_or_election_id,
                    CASE WHEN IFNULL(`photograph`,0)=0 THEN 0 ELSE 1 END AS photograph,
                    CASE WHEN IFNULL(`insurance_paper`,0)=0 THEN 0 ELSE 1 END AS insurance_paper,
                    CASE WHEN IFNULL(`ref_or_contact_people`,0)=0 THEN 0 ELSE 1 END AS ref_or_contact_people,
                    CASE WHEN IFNULL(`hla_match_report`,0)=0 THEN 0 ELSE 1 END AS hla_match_report,
                    CASE WHEN IFNULL(`affidavit`,0)=0 THEN 0 ELSE 1 END AS affidavit,
                    CASE WHEN IFNULL(`doctors_letter`,0)=0 THEN 0 ELSE 1 END AS doctors_letter,
                    CASE WHEN IFNULL(`appeal_letter`,0)=0 THEN 0 ELSE 1 END AS appeal_letter,
                    CASE WHEN IFNULL(`medical_report`,0)=0 THEN 0 ELSE 1 END AS medical_report,
                    CASE WHEN IFNULL(`appeal_letter`,0)=0 THEN 0 ELSE 1 END AS appeal_letter,
                    CASE WHEN IFNULL(`medical_report`,0)=0 THEN 0 ELSE 1 END AS medical_report,
                    CASE WHEN IFNULL(`medical_bills_current`,0)=0 THEN 0 ELSE 1 END AS medical_bills_current,
                    CASE WHEN IFNULL(`transplant_doc`,0)=0 THEN 0 ELSE 1 END AS transplant_doc
                    FROM
                    `patient_documents_details` JOIN `patient_case_details` ON `patient_documents_details`.`case_id`=`patient_case_details`.id WHERE `patient_id`='$patient_id'";
        $result = $this->db->query($query);
        return $result->result();
    }

    function getPtNotesDetails($patient_id) {

        $query = " SELECT patient_id,
                    CONCAT(`FirstName`,' ', `MiddleName`,' ', `LastName`) AS SocailWorkerName,
                    -- CASE WHEN IFNULL(`profiling_is_genuine`,0)THEN 'NO' ELSE 'YES' END  AS IsProfileGenuine,
                    CASE profiling_is_genuine when 1 then 'YES' when 0 then 'NO' else ' 'END AS IsProfileGenuine,

                    -- CASE WHEN IFNULL(`rating`,0)THEN 0 ELSE `rating` END AS Rating,
                     `rating`  AS Rating,
                    CASE investigation_recommend when 1 then 'YES' when 0 then 'NO' else ' 'END AS Investigation_Recommend,
                    CASE `patient_case_notes`.`case_status` when 1 then 'Accept' when 0 then 'Reject' else ' 'END AS Case_Status,

                    -- CASE WHEN IFNULL(`patient_case_notes`.`case_status`,0)THEN 'Accept' ELSE 'Reject' END AS Case_Status,
                    `remarks`
                    FROM `patient_case_notes`
                    JOIN `patient_case_details` ON `patient_case_notes`.`case_id`=`patient_case_details`.id
                    LEFT JOIN `usermaster` ON `patient_case_notes`.`social_worker_name`=`usermaster`.`UserId`
                    WHERE `patient_case_details`.patient_id='$patient_id'";

        $result = $this->db->query($query);
        return $result->result();
    }

    function updateTabStatus($current_status, $case_id) {
        $db_tab_status = $this->getPatientCase($case_id);

        if ($db_tab_status[0]['tab_status'] == $current_status && (int) $db_tab_status[0]['tab_status'] < 5) { //less than follow up tab
            $data['tab_status'] = $current_status + 1;
            $this->db->where('id', $case_id);
            $this->db->update('patient_case_details', $data);
        }
        return true;
    }

    function getDeptName($Department) {
        $query = "select *from departmentmaster where DeptId=$Department";
        $result = $this->db->query($query);
        return $result->result();
    }

    function getFinanceDetails($patient_id) {
        $query = "select funding_cover_surgery,"
                . "funding_cover_treatment,"
                . "funding_cover_meditation,"
                . "funding_cover_dalyexpense,"
                . "funding_cover_travelling,"
                . "funding_cover_food,"
                . "funding_cover_other from patient_financetial_details where case_id=(select id from patient_case_details where patient_id='$patient_id')";
        $result = $this->db->query($query);
        return $result->result();
    }

    function insertDocumentDetails($cid, $data) {
        //check if record exists
        $query = "select * from patient_documents_details where case_id=$cid";
        $result = $this->db->query($query);
        $rs = $result->result();

        if (count($rs) == 0) {
            //insert new record
            $data1 = array(
                'file_urls' => $data,
                'case_id' => $cid,
                'transplant_doc' => 0,
                'created_by' => $this->session->get_userdata('UsertId')['UsertId'],
                'created_at' => date("Y-m-d H:i:s")
            );
            $this->db->insert('patient_documents_details', $data1);
        } else {
            //update record
            $data1 = array(
                'file_urls' => $data,
                'updated_by' => $this->session->get_userdata('UsertId')['UsertId']
            );

            $this->db->where('case_id', $cid);
            $this->db->update('patient_documents_details', $data1);
        }
    }

    function getFileUurls($cid) {
        $query = "select id,file_urls from patient_documents_details where case_id=$cid";
        $result = $this->db->query($query);
        return $result->result();
    }

    //akash file upload code
    function insertPatientDocument($page, $title, $insert_val) {
        $param = array(
            "page" => $page,
            "case_id" => $title,
            "file_url" => $insert_val
        );

        $this->db->insert("patient_document_details_test", $param);
    }

    //akash file upload code
    function getPatientFiles($cid) {
        $query = "select id,file_url from patient_document_details_test where case_id=$cid";
        $result = $this->db->query($query);
        return $result->result();
    }

    //akash file upload code
    function removePatientFile($record_id) {
        $this->db->where('id', $record_id);
        $this->db->delete('patient_document_details_test');
    }

    //akash file upload code
    function ImagesCheckResult($images_check, $title) {
        foreach ($images_check as $check) {
            $file_name = str_replace(base_url() . "karoclient/file_uploads/", "", $check);
            $query = "SELECT file_url from patient_document_details_test WHERE case_id=$title and file_url LIKE ('%$file_name%')";
            $result = $this->db->query($query);
            $cnt[] = $result->num_rows();
        }

        return array_sum($cnt);
    }

    function getCrawlingData() {
        $query = "select case_id,file_urls from patient_documents_details where file_urls not like('[]') order by case_id";
        $result = $this->db->query($query);
        return $result->result();
    }

    function insertCrawl($insert) {
        $this->db->insert("patient_document_details_test", $insert);
    }

// Deepa- disbursed amount export pdf in view patient

    function getKaroIntervention($patient_id) {
        $query = "SELECT 
`patient_case_details`.id AS CaseID,
patient_case_details.`case_status` AS CurrentSttatus,
patient_financetial_details.`approved_amount` AS TotalApprovedAmount,
IFNULL(`rehelp_date`,case_status_date) AS ApprovalDate,
CASE WHEN DonerType='Organisation' THEN OrganizationName ELSE CONCAT( CONCAT(firstName,' ',MiddleName),' ',LastName) END AS DonerName
FROM `patient_case_details`
LEFT OUTER JOIN `patient_case_status_detail` ON `patient_case_details`.id=`patient_case_status_detail`.`case_id` AND patient_case_status_detail.case_status ='Open'
LEFT OUTER JOIN `patient_financetial_details` ON `patient_financetial_details`.`case_id`=`patient_case_details`.id
LEFT OUTER JOIN `donermaster` ON `patient_case_status_detail`.`doner_id`=`donermaster`.`DonerId` WHERE `patient_case_details`.patient_id='$patient_id'";

// echo $query;
// exit;
        $query = $this->db->query($query);
        $result = $query->result();
        return $result;
    }

    function getKaroIntervention1($patient_id) {

        $query = "SELECT case_id,
IFNULL(`rehelp_date`,case_status_date) AS CaseDate,
patient_case_status_detail.case_status AS CaseStatus,
`approved_amount` AS AmountApproved,
CASE WHEN DonerType='Organisation' THEN OrganizationName ELSE CONCAT( CONCAT(firstName,' ',MiddleName),' ',LastName) END AS DonerName,
`case_status_reason` AS CaseStatusReason,
CASE WHEN patient_case_status_detail.case_status='open' THEN '0' ELSE '1' END AS RecurringSupport ,
CASE WHEN patient_case_status_detail.case_status='open' THEN `medicines_details`ELSE  `case_status_reason` END AS Reason
FROM `patient_case_status_detail` 
LEFT OUTER JOIN `donermaster` ON `patient_case_status_detail`.`doner_id`=`donermaster`.`DonerId`
LEFT OUTER JOIN `patient_case_details` ON `patient_case_status_detail`.case_id=patient_case_details.id
 
WHERE `patient_case_details`.patient_id='$patient_id'
AND patient_case_status_detail.case_status IN ('Open','Rehelp')
ORDER BY patient_case_status_detail.case_status,IFNULL(`rehelp_date`,case_status_date) ASC";
// echo $query;
// exit;
        $query = $this->db->query($query);
        $result = $query->result();
        return $result;
    }

    function displayDisburselListById($case_id) {
        // $query = "SELECT *FROM patient_case_disbursed_detail INNER JOIN patient_master ON patient_master.id=patient_case_disbursed_detail.CaseId
// INNER JOIN donermaster ON donermaster.donerId=patient_case_disbursed_detail.DonorId
// WHERE patient_master.patient_id='$case_id'";

        $query = " SELECT `patient_case_details`.`case_number` AS CASE_NO,
`patient_case_details`.`id` AS CaseId,
CASE WHEN APDIDetail.case_status='open' THEN 'Support' WHEN APDIDetail.case_status='Disburse' THEN '' ELSE 'Recurring Support' END AS TransType ,
PaymentMode AS PaymentMethod,
APDIDetail.SanctionedAmount AS TransAmt,
APDIDetail.SanctionDate AS TransDate,
APDIDetail.Disbursed_Amt AS DisburseAmt,
APDIDetail.Disbursed_Date AS DisburseDate,
CASE WHEN DonerType='Organisation' THEN OrganizationName ELSE CONCAT( CONCAT(firstName,' ',MiddleName),' ',LastName) END AS DonerName ,
APDIDetail.case_status,
Bank,RecdeiptNo,ReceiptUploaded,
casedate
FROM
(
SELECT case_id AS CaseId,approved_amount AS SanctionedAmount,DATE_FORMAT(IFNULL(`rehelp_date`,`case_status_date`),'%d/%m/%Y') AS SanctionDate,
'' AS Disbursed_Amt,'' AS Disbursed_Date,'' AS `PaymentMode`,doner_id AS DonerID,case_status,
'' AS Bank,'' AS RecdeiptNo,
'' ReceiptUploaded ,DATE_FORMAT(IFNULL(`rehelp_date`,`case_status_date`),'%d/%m/%Y') AS casedate,'' AS disburseid,
id AS SanctionId

FROM `patient_case_status_detail`
WHERE case_status IN ('open','rehelp','reopen')
UNION
SELECT Caseid AS CaseId ,'' AS SanctionedAmount,'' AS SanctionDate, `DisbursedAmt` AS Disbursed_Amt,
`DisburesedDate` AS Disbursed_Date,`PaymentMode` ,`DonorId` AS DonerID ,'Disburse' AS case_status,
`DisbursedBank` AS Bank,`receipt_no` AS RecdeiptNo,
CASE WHEN IFNULL(`receipt_file`,'')='' THEN 'NO' ELSE 'YES' END AS ReceiptUploaded ,DATE_FORMAT(`DisburesedDate`,'%d/%m/%Y') AS casedate,patient_case_disbursed_detail.id AS disburseid,
Sanction_Id  AS SanctionId
FROM `patient_case_disbursed_detail`
LEFT OUTER JOIN `paymentmaster` ON `paymentmaster`.`PaymentId`=`patient_case_disbursed_detail`.`PaymentModeId`
)
AS APDIDetail
LEFT OUTER JOIN `patient_case_details` ON `patient_case_details`.`id`=APDIDetail.CaseId
LEFT OUTER JOIN `patient_master` ON `patient_master`.`patient_case`=`patient_case_details`.`case_number`
LEFT OUTER JOIN `donermaster` ON APDIDetail.DonerID=donermaster.`DonerId`
AND IFNULL(patient_master.status,0)!=1
WHERE `patient_case_details`.patient_id='$case_id'
ORDER BY APDIDetail.SanctionId ASC ,disburseid
";
// echo $query;
// exit;

        $query = $this->db->query($query);
        $result = $query->result();
        return $result;
    }

    function displayRefundListById($case_id) {


        $query = "SELECT 
`patient_case_details`.`id` AS CaseId,
CASE WHEN DonerType='Organisation' THEN OrganizationName ELSE CONCAT( CONCAT(firstName,' ',MiddleName),' ',LastName) END AS DonerName,
'Refund' AS TransType,
`refund_date` AS TransDate,
`refund_amount` AS TransAmt,
`PaymentMode` AS PaymentMethod,
`bank_name` AS Bank,
`cheque_no` AS TransNo,
'' AS RecdeiptNo,
CASE WHEN IFNULL(`reference_1`,'')='' THEN 'NO' ELSE 'YES' END  AS ReceiptUploaded 

FROM `refund_amount_details` 
LEFT OUTER JOIN `patient_case_details` ON `patient_case_details`.`case_number`=`refund_amount_details`.`case_id`
LEFT OUTER JOIN `donermaster` ON `refund_amount_details`.`donor_id`=`donermaster`.`DonerId`
LEFT OUTER JOIN `paymentmaster` ON `paymentmaster`.`PaymentId`=`refund_amount_details`.`mode_of_refund`
				WHERE `patient_case_details`.patient_id='$case_id'
				
";
        // echo $query;
// exit;

        $query = $this->db->query($query);
        $result = $query->result();
        return $result;
    }

    function insertPatientDocumentRehelp($page, $title, $insert_val, $rid) {
        $param = array(
            "page" => $page,
            "case_id" => $title,
            "file_url" => $insert_val,
            "rehelp_id" => $rid
        );

        $this->db->insert("patient_document_details_test", $param);
    }

    function checkPatientDocumentRehelp($page, $title, $insert_val, $rid) {
        $query = $this->db->query("select *from patient_document_details_test where page='$page' and
            case_id = $title and
            file_url = '$insert_val' and
            rehelp_id = $rid");
        $result = $query->result();
        return $result;
    }

}
