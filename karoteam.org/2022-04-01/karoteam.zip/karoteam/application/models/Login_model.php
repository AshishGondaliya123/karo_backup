<?php
class Login_model extends CI_Model {
    function can_login($email, $password) {
        $this->db->where('PrimaryEmailId', $email);
        $query = $this->db->get('usermaster');
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                if ($row->IsActive == '1') {
                    $store_password = $row->Password;                    
                    if (md5($password) == $store_password) {
                        $this->session->set_userdata('UsertId', $row->UserId);
                        $this->session->set_userdata('FirstName', $row->FirstName);
                        $this->session->set_userdata('LastName', $row->LastName);
                        $this->session->set_userdata('UserImage', $row->UserImage);
                        $this->session->set_userdata('IsAdmin', $row->IsAdmin);
                    } else {
                        return 'Incorrect email or password';
                    }
                } else {
                    return "User account is not active.Please contact administrator";
                }
            }
        } else {
            return 'Wrong Email Address';
        }
    }
    function checkemailforresetpass($email) {
        $this->db->where('PrimaryEmailId', $email);
        $query = $this->db->get('usermaster');
        if ($query->num_rows() > 0) {
             foreach ($query->result() as $row) {
                 return $row->UserId;
             }
        } else {
            return false;
        }
    }
    function checkran($values) {
        $this->db->where('randomno', $values);
        $query = $this->db->get('usermaster');
        //echo $str = $this->db->last_query();
        if ($query->num_rows() > 0) {
             return true;
        } else {
           return false;
        }
    }
}
?>