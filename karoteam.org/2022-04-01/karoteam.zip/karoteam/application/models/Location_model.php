<?php
class Location_model extends CI_Model {
    function savelocation($LocationName) {
        $CreatedByUserId = $this->session->userdata('UsertId');
        $query = $this->db->get_where('locationmaster', array('LocationName' => $LocationName));      
        if($query->num_rows()==0){
            $query="insert into locationmaster (LocationName,CreatedByUserId)values('".$LocationName."','".$CreatedByUserId."')";
            if($this->db->query($query)){
                return '<div class="alert alert-success">Saved successfully</div>';
			}else{
				return '<div class="alert alert-danger">Something went wrong</div>';
			}
        }else{
            return '<div class="alert alert-danger">Location name already exist</div>';
        }
    }
    function getlocation() {
        $this->db->order_by('LocationId', 'DESC');  //actual field name of id
        $query=$this->db->get('locationmaster');
        return $query->result_array();
    }
    function changeStatus($id,$status) {       
        $query="update locationmaster set IsActive='".$status."' where LocationId='".$id."'";
        if($this->db->query($query)){
            return '<div class="alert alert-success">status updated successfully</div>';
        }else{
            return '<div class="alert alert-danger">Something went wrong</div>';
        }
    }
    function changelocationName($name,$id) {  
        $query = $this->db->get_where('locationmaster', array('LocationName' => $name,'LocationId !=' => $id));      
        if($query->num_rows()==0){
        $query="update locationmaster set LocationName = '".$name."' where LocationId='".$id."'";
            if($this->db->query($query)){
                return '<div class="alert alert-success">Updated successfully</div>';
            }else{
                return '<div class="alert alert-danger">Something went wrong</div>';
            }
        }else{
             return '<div class="alert alert-danger">Location name already exist</div>';
        }
    }
}
?>