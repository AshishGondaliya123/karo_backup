<?php
class Payment_model extends CI_Model {
    function savePayment($PaymentMode) {
        $CreatedByUserId = $this->session->userdata('UsertId');
        $query = $this->db->get_where('paymentmaster', array('PaymentMode' => $PaymentMode));      
        if($query->num_rows()==0){
        $query="insert into paymentmaster (PaymentMode,CreatedByUserId)values('".$PaymentMode."','".$CreatedByUserId."')";
            if($this->db->query($query)){
				return '<div class="alert alert-success">Saved successfully</div>';
			}else{
				return '<div class="alert alert-danger">Something went wrong</div>';
			}
        }else{
            return '<div class="alert alert-danger">Payment mode already exist</div>';
        }
    }
    function getPayment() {
        $this->db->order_by('PaymentId', 'DESC');  //actual field name of id
        $query=$this->db->get('paymentmaster');
        return $query->result_array();
    }
    function changeStatus($id,$status) {       
        $query="update paymentmaster set IsActive='".$status."' where PaymentId='".$id."'";
        if($this->db->query($query)){
            return '<div class="alert alert-success">Updated successfully</div>';
        }else{
            return '<div class="alert alert-danger">Something went wrong</div>';
        }
    }
    function changePaymentName($name,$id) { 
        $query = $this->db->get_where('paymentmaster', array('PaymentMode' => $name,'PaymentId !=' => $id));      
        if($query->num_rows()==0){
       $query="update paymentmaster set PaymentMode = '".$name."' where PaymentId='".$id."'";
        if($this->db->query($query)){
            return '<div class="alert alert-success">Updated successfully</div>';
        }else{
            return '<div class="alert alert-danger">Something went wrong</div>';
        }
        }else{
             return '<div class="alert alert-danger">Payment mode already exist</div>';
        }
    }
}
?>