<?php
class Diseases_model extends CI_Model {
    function saveDisease($DiseaseName) {
        $CreatedByUserId = $this->session->userdata('UsertId');
        $query = $this->db->get_where('diseasesmaster', array('DiseaseName' => $DiseaseName));      
        if($query->num_rows()==0){
        $query="insert into diseasesmaster (DiseaseName,CreatedByUserId)values('".$DiseaseName."','".$CreatedByUserId."')";
        if($this->db->query($query)){
            return '<div class="alert alert-success">Saved successfully</div>';
        }else{
            return '<div class="alert alert-danger">Something went wrong</div>';
        }
        }else{
            return '<div class="alert alert-danger">Disease name already exist</div>';
        }
    }
    function getDisease() {
        $this->db->order_by('DiseaseId', 'DESC');  //actual field name of id
        $query=$this->db->get('diseasesmaster');
        return $query->result_array();
    }
    function changeStatus($id,$status) {       
        $query="update diseasesmaster set IsActive='".$status."' where DiseaseId='".$id."'";
        if($this->db->query($query)){
            return '<div class="alert alert-success">Status updated successfully</div>';
        }else{
            return '<div class="alert alert-danger">Something went wrong</div>';
        }
    }
    function changeDiseasesName($name,$id) {    
        $query = $this->db->get_where('diseasesmaster', array('DiseaseName' => $name,'DiseaseId !=' => $id));      
        if($query->num_rows()==0){
            $query="update diseasesmaster set DiseaseName = '".$name."' where DiseaseId='".$id."'";
            if($this->db->query($query)){
                return '<div class="alert alert-success">Updated successfully</div>';
            }else{
                return '<div class="alert alert-danger">Something went wrong</div>';
            }
        }else{
            return '<div class="alert alert-danger">Disease name already exist</div>';
        }
    }
}
?>