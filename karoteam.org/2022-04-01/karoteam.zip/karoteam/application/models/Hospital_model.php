<?php

class Hospital_model extends CI_Model {

    function savehospital($HospitalName, $city, $state, $zipcode, $contact_no, $address) {
        $CreatedByUserId = $this->session->userdata('UsertId');
        $query = $this->db->get_where('hospitalmaster', array('HospitalName' => $HospitalName));
        if ($query->num_rows() == 0) {
            $query = "insert into hospitalmaster (HospitalName,City,State,ZipCode,ContactNo,Address,IsActive,CreatedByUserId)values('" . $HospitalName . "','" . $city . "','" . $state . "','" . $zipcode . "','" . $contact_no . "','" . $address . "','1','" . $CreatedByUserId . "')";
            if ($this->db->query($query)) {
                return '<div class="alert alert-success">Save successfully</div>';
            } else {
                return '<div class="alert alert-danger">Something went wrong</div>';
            }
        } else {
            return '<div class="alert alert-danger">Hospital already exist</div>';
        }
    }

    function gethospital() {
        $this->db->order_by('HospitalId', 'DESC');  //actual field name of id
        $query = $this->db->get('hospitalmaster');
        return $query->result_array();
    }
    function getactivehospital() {
        $this->db->where("IsActive","1");
        $this->db->order_by('HospitalName', 'ASC');  //actual field name of id
        $query = $this->db->get('hospitalmaster');
        return $query->result_array();
    }
    function getstates() {
        $this->db->order_by('city_id', 'ASC');
        $this->db->group_by('city_state');
        $query = $this->db->get('cities');
        return $query->result_array();
    }

    function getcities($statename) {
        if ($statename == 'Andaman') {
            $statename = 'Andaman and Nicobar';
        }
        $query = $this->db->get_where('cities', array('city_state' => $statename));
        return $query->result_array();
    }

    function changeStatus($id, $status) {
        $query = "update hospitalmaster set IsActive='" . $status . "' where HospitalId='" . $id . "'";
        if ($this->db->query($query)) {
            return '<div class="alert alert-success">Updated successfully</div>';
        } else {
            return '<div class="alert alert-danger">Something went wrong</div>';
        }
    }

    function updatehospital($HospitalName, $city, $state, $zipcode, $contact_no, $address, $HospitalId) {
        $query = $this->db->get_where('hospitalmaster', array('HospitalName' => $HospitalName, 'HospitalId !=' => $HospitalId));
        if ($query->num_rows() == 0) {
            $query = "update hospitalmaster set HospitalName = '" . $HospitalName . "',City = '" . $city . "',State = '" . $state . "',ZipCode = '" . $zipcode . "',ContactNo = '" . $contact_no . "',Address = '" . $address . "' where HospitalId='" . $HospitalId . "'";
            if ($this->db->query($query)) {
                return '<div class="alert alert-success">Updated successfully</div>';
            } else {
                return '<div class="alert alert-danger">Something went wrong</div>';
            }
        } else {
            return '<div class="alert alert-danger">Hospital already exist</div>';
        }
    }

    function getActiveRecord($table_name, $col_name, $order_by_col = '', $order_by = '', $select = '') {
        if ($select)
            $this->db->select($select);
        $this->db->from($table_name);
        $this->db->where(array($col_name => 1));
        if ($order_by)
            $this->db->order_by($order_by_col, $order_by);
        $query = $this->db->get();
 //echo $this->db->last_query() ;exit;
// $query = $this->db->get_where($table_name, array($col_name => 1)); 
        return $query->result_array();
    }
	
	 function getActiveRecords($table_name, $col_name,$col_name1, $order_by_col = '', $order_by = '', $select = '') {
        if ($select)
            $this->db->select($select);
        $this->db->from($table_name);
        $this->db->where(array($col_name => 1));
		 $this->db->where_in($col_name1,array('Manager','Social Worker'));
        if ($order_by)
            $this->db->order_by($order_by_col, $order_by);
        $query = $this->db->get();
 //echo $this->db->last_query() ;exit;
// $query = $this->db->get_where($table_name, array($col_name => 1)); 
        return $query->result_array();
    }
	
	function getActive() {
      
	  $query="select UserId , CONCAT(FirstName, ' ', MiddleName,' ',LastName,' ') as full_name from usermaster where UserType in ('Manager','Social Worker') order by FirstName asc";

	   $query = $this->db->query($query);
        $result = $query->result_array();

        return $result;
    }
	

    function saveDept($DeptName) {
        $CreatedByUserId = $this->session->userdata('UsertId');
        $query = $this->db->query("SELECT *FROM departmentmaster WHERE DeptName LIKE('$DeptName')");
      
        if ($query->num_rows() == 0) {
            $query = "insert into departmentmaster (DeptName,CreatedByUserId)values('" . $DeptName . "','" . $CreatedByUserId . "')";
            if ($this->db->query($query)) {
                return '<div class="alert alert-success">Saved successfully</div>';
            } else {
                return '<div class="alert alert-danger">Something went wrong</div>';
            }
        } else {
            return '<div class="alert alert-danger">Department name already exist</div>';
        }
    }

    function getDept() {
        $this->db->order_by('DeptName', 'ASC');  //actual field name of id
        $query = $this->db->get('departmentmaster');
        return $query->result_array();
    }

    function getActiveDept() {
        $this->db->where("IsActive","1");
        $this->db->order_by('DeptName', 'ASC');  //actual field name of id
        $query = $this->db->get('departmentmaster');
        return $query->result_array();
    }

    function changeDeptName($name, $id) {
        $query = $this->db->get_where('departmentmaster', array('DeptName' => $name, 'DeptId !=' => $id));
        if ($query->num_rows() == 0) {
            $query = "update departmentmaster set DeptName = '" . $name . "' where DeptId='" . $id . "'";
            if ($this->db->query($query)) {
                return '<div class="alert alert-success">Updated successfully</div>';
            } else {
                return '<div class="alert alert-danger">Something went wrong</div>';
            }
        } else {
            return '<div class="alert alert-danger">Department name already exist</div>';
        }
    }

    function changeDeptStatus($id, $status) {
        $query = "update departmentmaster set IsActive='" . $status . "' where DeptId='" . $id . "'";
        if ($this->db->query($query)) {
            return '<div class="alert alert-success">Status updated successfully</div>';
        } else {
            return '<div class="alert alert-danger">Something went wrong</div>';
        }
    }

}

?>