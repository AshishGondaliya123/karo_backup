<?php

class Case_model extends CI_Model {

    function getCaseDetails($data) {
        $isAdmin = $this->session->userdata('IsAdmin');
        if ($isAdmin != 1)
            $data['pcd.created_by'] = $this->session->userdata('UsertId');

        $this->db->select('pm.patient_id,pm.status,pm.patient_name,pm.patient_age,DATE_FORMAT(pcd.problem_detected_date,"%d/%m/%Y")AS problem_detected_date,DATE_FORMAT(pcd.created_at,"%d/%m/%Y") AS created_at,pm.patient_phone,pm.patient_phone,pm.caregiver_phone,dm.DeptName,hm.HospitalName,pcd.case_number,pfd.required_fund,pfd.case_id,pcd.current_diagnosed_detail ,DATE_Format(pm.registration_date,"%d/%m/%Y") AS registration_date,pcd.id, DATE_FORMAT(pm.patient_dob,"%d/%m/%Y") AS dob');
        $this->db->from('patient_case_details pcd');
        $this->db->join('departmentmaster dm', 'dm.DeptId = pcd.department_name', 'left');
        $this->db->join('hospitalmaster hm', 'hm.HospitalId = pcd.hospital_name', 'left');
        $this->db->join('patient_master pm ', 'pm.patient_id = pcd.patient_id', 'left');
        $this->db->join('patient_financetial_details pfd ', 'pfd.case_id = pcd.id', 'left');
        $this->db->where('IFNULL(pm.status,0)!=', '1'); //akash rai 6 march 2020
        $this->db->where($data);
        $query = $this->db->get();
//        echo $this->db->last_query();
//        exit;
        $result = $query->result();
        return $result;
    }

    function getActiveDoner() {
        // $where_data['IsActive'] =1;
        // $this->db->select('dm.DonerId, dm.firstName,dm.middleName,dm.lastName');
        // $this->db->from('donermaster dm');
        // $this->db->join('usermaster um', 'dm.CreatedByUserId =um .UserId');
        // $this->db->order_by("dm.firstName", "asc");
        // $this->db->where($where_data);
        // $query = $this->db->get(); 
        // echo $this->db->last_query();exit;
        $query = "SELECT dm.`DonerId`,CASE WHEN `DonerType`='Organisation' THEN `OrganizationName` ELSE concat( CONCAT(dm.firstName,' ',dm.MiddleName),' ',dm.LastName) END AS firstName  FROM `donermaster` dm  ORDER BY `dm`.`firstName` ASC";
        $query = $this->db->query($query);
        $result = $query->result();
        return $result;
    }

    function getDonnerAvailableAmount($donner_id) {
        //        $query = "SELECT DonerId,Total_DonateAmount,ApprovedAmount,(Total_DonateAmount-IFNULL(ApprovedAmount,0))AS AmountRemaining FROM (
//				SELECT SUM(`DonationAmount`)AS Total_DonateAmount ,`DonerId` FROM `doner_donation_detail` GROUP BY `DonerId`)Donation
//				LEFT OUTER JOIN
//				(
//				SELECT SUM(`approved_amount`)AS ApprovedAmount,`doner_id` FROM `patient_case_status_detail` GROUP BY `doner_id` HAVING doner_id IS NOT NULL)
//				Approval ON Donation.DonerId=Approval.doner_id where DonerId =" . $donner_id;
        $query = "SELECT DonerId,Total_DonateAmount,ApprovedAmount,((Total_DonateAmount-IFNULL(ApprovedAmount,0))+IFNULL(refund_amounts,0))AS AmountRemaining FROM (
				SELECT SUM(`DonationAmount`)AS Total_DonateAmount ,`DonerId` FROM `doner_donation_detail` GROUP BY `DonerId`)Donation
				LEFT OUTER JOIN
				(
				SELECT SUM(`approved_amount`)AS ApprovedAmount,`doner_id` FROM `patient_case_status_detail` GROUP BY `doner_id` HAVING doner_id IS NOT NULL)
				Approval ON Donation.DonerId=Approval.doner_id
				LEFT OUTER JOIN (SELECT SUM(refund_amount) AS refund_amounts ,donor_id,case_id FROM refund_amount_details GROUP BY case_id,donor_id) AS rad ON Donation.DonerId=rad.donor_id
				WHERE DonerId =" . $donner_id;
        $query = $this->db->query($query);
        $result = $query->result();
        return json_decode(json_encode($result), true);
    }

    function insertDataIntoTable($table, $insert_data) {
        $this->db->insert($table, $insert_data);
        $insert_id = $this->db->insert_id();
        return $insert_id;
    }

    function updateDisburseDetails($insert_data, $did) {
        $this->db->where("id", $did);
        return $this->db->update("patient_case_disbursed_detail", $insert_data);
    }

    function displayDisburselListById($case_id) {
        $query = "select *from patient_case_disbursed_detail where CaseId='$case_id'";
        $query = $this->db->query($query);
        $result = $query->result();
        return $result;
    }

    function displayDeleteDisburselListById($case_id) {
        $query = "select *from patient_case_disbursed_detail_delete_log where CaseId=$case_id";
        $query = $this->db->query($query);
        $result = $query->result();
        return $result;
    }

    function getPrevDisbData($did) {
        $query = "select * from patient_case_disbursed_detail where id=$did";
        $query = $this->db->query($query);
        $result = $query->result();
        return $result;
    }

    function updateDataIntoTable($table, $update_data, $where_data) {
        $this->db->where($where_data);
        // echo $this->db->last_query();exit;

        return $this->db->update($table, $update_data);
    }

    function getOpenCaseDetails($data) {
        $isAdmin = $this->session->userdata('IsAdmin');
        
        if ($isAdmin != 1)
            $data['pcd.created_by'] = $this->session->userdata('UsertId');
        $this->db->select('DISTINCT(pcd.id),pcd.patient_id,pcd.case_number, pcd.case_status,pm.id AS pm_id, pm.patient_name,dm.DeptName,hm.HospitalName,DATE_FORMAT(pm.registration_date,"%d/%m/%Y") AS registration_date , pfd.required_fund,pfd.approved_amount,DATE_FORMAT(pcd.created_at,"%d/%m/%Y") AS created_at ');
        $this->db->from('patient_case_details pcd');
        $this->db->join('departmentmaster dm', 'dm.DeptId = pcd.department_name', 'left');
        $this->db->join('hospitalmaster hm', 'hm.HospitalId = pcd.hospital_name', 'left');
        $this->db->join('patient_master pm ', 'pm.patient_id = pcd.patient_id', 'left');
        $this->db->join('patient_financetial_details pfd ', 'pfd.case_id = pcd.id', 'left');
        $this->db->where('IFNULL(pm.status,0)!=', '1'); //akash rai 6 march 2020
        if ($data) {
            if (array_key_exists("pcd.case_status", $data))
                if ($data['pcd.case_status'] == 'all')
                    unset($data['pcd.case_status']);
            $this->db->where($data);
        }
      /*   if(!empty($_POST['department'])){
            $this->db->where('(dm.DeptId="'.$_POST['department'].'" OR "'.$_POST['department'].'"="")');
        } */
        $query = $this->db->get();
     // echo $this->db->last_query();exit;
        $result = $query->result();
        return json_decode(json_encode($result), true);
    }

    function getNextFollowUpdata($case_id) {
        $this->db->select('case_id, DATE_FORMAT(max(next_followup_date),"%d/%m/%Y") as next_followup_date');
        $this->db->group_by('case_id');
        if ($case_id)
            $this->db->where_in('case_id', $case_id);
        $query = $this->db->get('patient_followup_details');
        // echo $this->db->last_query();exit;
        $result = $query->result();
        return json_decode(json_encode($result), true);
    }

    function getLastFollowupData() {
        $query = "SELECT PFD.case_id,id , DATE_FORMAT(followup_date,'%d/%m/%Y') AS followup_date, remark FROM patient_followup_details PFD
			 LEFT JOIN (SELECT case_id ,MAX(followup_date) AS nextdate FROM patient_followup_details  GROUP BY Case_id ) AS MPFD
			 ON PFD.case_id=MPFD.case_id WHERE PFD.followup_date=MPFD.nextdate";
        $query = $this->db->query($query);
        $result = $query->result();
        return json_decode(json_encode($result), true);
    }

    function getNumberOfFollowupData($case_id) {
        $this->db->select('count(case_id) as no_of_followup,case_id ');
        $this->db->group_by('case_id');
        if ($case_id)
            $this->db->where_in('case_id', $case_id);
        $query = $this->db->get('patient_followup_details');
        $result = $query->result();
        return json_decode(json_encode($result), true);
    }

    function selectDataFromTable($table, $select = '', $where_data = '') {
        if ($where_data)
            $this->db->where($where_data);
        if ($select)
            $this->db->select($select);
        if ($table == 'paymentmaster')
            $this->db->order_by("PaymentMode", "asc");
        $query = $this->db->get($table);
        $result = $query->result();
        return $result;
    }

    function getDonnerDetails() {
        $isAdmin = $this->session->userdata('IsAdmin');
        $where_data = [];
        if ($isAdmin != 1)
            $where_data['ddd.CreatedById'] = $this->session->userdata('UsertId');

        $this->db->select('ddd.*,dm.FirstName,dm.MiddleName,dm.LastName,dm.OrganizationName	');
        $this->db->from('doner_donation_detail ddd');
        $this->db->join('donermaster dm ', 'dm.DonerId = ddd.DonerId', 'left');
        if ($where_data)
            $this->db->where($where_data);
        $query = $this->db->get();
        // echo $this->db->last_query();exit;
        $result = $query->result();
        return $result;
    }

    function getStatusReason($case_id, $status) {
        $this->db->select('case_id, case_status,case_status_reason');
        if ($case_id)
            $this->db->where_in('case_id', $case_id);
        $this->db->where(array('case_status' => $status));
        $query = $this->db->get('patient_case_status_detail');
        // echo $this->db->last_query();exit;
        $result = $query->result();
        $result = json_decode(json_encode($result), true);
        $final_result = array();
        if ($result)
            foreach ($result as $key => $value) {
                $final_result[$value ['case_id']] = $value;
            }
        return $final_result;
    }

    function getDisbursedAmountSum($case_id) {
        $this->db->select('sum(DisbursedAmt)as DisbursedAmt ,caseId  ');
        $this->db->group_by('caseId');
        if ($case_id)
            $this->db->where_in('caseId', $case_id);
        $query = $this->db->get('patient_case_disbursed_detail');
        $result = $query->result();
        $result = json_decode(json_encode($result), true);
        $data = array();
        foreach ($result as $key => $value) {
            $data[$value['caseId']]['DisbursedAmt'] = $value['DisbursedAmt'];
        }
        return $data;
    }

    function getDisbursedDonor($cid) {

        /*
          $where_data['pcsd.case_id']= $cid;
          $this->db->select('DISTINCT(pcsd.doner_id),SUM(pcsd.Approved_amount) donner_approved_amount, dm.FirstName, dm.MiddleName, dm.lastname');
          $this->db->from('patient_case_status_detail pcsd');
          $this->db->join('donermaster dm', 'pcsd.doner_id = dm.DonerId');
          $this->db->group_by("Doner_id");
          $this->db->where($where_data);
          $query = $this->db->get();
          // echo $this->db->last_query();exit;
         */
        $query = "SELECT DISTINCT(pcsd.doner_id), SUM(pcsd.Approved_amount) donner_approved_amount, CASE WHEN `DonerType`='Organisation' THEN `OrganizationName` ELSE concat( CONCAT(dm.firstName,' ',dm.MiddleName),' ',dm.LastName) END AS FirstName FROM `patient_case_status_detail` `pcsd` JOIN `donermaster` `dm` ON `pcsd`.`doner_id` = `dm`.`DonerId` WHERE `pcsd`.`case_id` = '" . $cid . "' GROUP BY `Doner_id`";
        // prx($query);
        $query = $this->db->query($query);

        $result = $query->result();
        return $result;
    }

    function getDisbursedData($data) {

        /* $this->db->select('pcd.*,dm.FirstName, dm.MiddleName, dm.lastname');
          $this->db->from('patient_case_disbursed_detail pcd');
          $this->db->join('donermaster dm', 'pcd.DonorId = dm.DonerId');
          $this->db->where(array('pcd.CaseId'=>$data['CaseId']));
          $query = $this->db->get();
          echo $this->db->last_query();exit; */
     $query = "SELECT `pcd`.*, CASE WHEN `DonerType`='Organisation' THEN `OrganizationName` ELSE concat( CONCAT(dm.firstName,' ',dm.MiddleName),' ',dm.LastName) END AS FirstName FROM `patient_case_disbursed_detail` `pcd` JOIN `donermaster` `dm` ON `pcd`.`DonorId` = `dm`.`DonerId` WHERE `pcd`.`CaseId` = '" . $data['CaseId'] . "'";
       // exit;
		$query = $this->db->query($query);
        $result = $query->result();
        return $result;
    }

    function getDisbursedAmountSumDonorWise($where_data) {
        $this->db->select('sum(DisbursedAmt)as DisbursedAmt ,DonorId  ');
        $this->db->group_by('DonorId');
        if ($where_data)
            $this->db->where_in('caseId', $where_data);
        $query = $this->db->get('patient_case_disbursed_detail');
        $result = $query->result();
        // echo $this->db->last_query();exit;

        foreach ($result as $key => $value) {
            $data[$value->DonorId] = $value->DisbursedAmt;
        }
        return $data;
    }

    function getNextFollowupDate($flag = 0, $from_date = "", $to_date = "", $department = "") {
        // and created_by = ".$this->session->userdata('UsertId').
        $isAdmin = $this->session->userdata('IsAdmin');
        // $where_data = 'date(next_followup_date) >= CURDATE()';
        // $where_data = "date(next_followup_date) >= '" .$from_date ."' and date(next_followup_date)<= '".$to_date."'";

        if ($flag)
            $where_data = " date(next_followup_date) >= CURDATE() and MONTH(next_followup_date)= MONTH(CURDATE())"; //date(next_followup_date)<= DATE_ADD(CURDATE(), INTERVAL 1 DAY)
        else
            $where_data = "date(next_followup_date) >= '" . $from_date . "' and date(next_followup_date)<= '" . $to_date . "'";


        if ($isAdmin != 1) {
            $query = "SELECT PFD.case_id,PFD.id , DATE_FORMAT(next_followup_date,'%d/%m/%Y' ) AS next_followup_date , remark, ifnull(folowup_done,0) folowup_done FROM patient_followup_details PFD
				LEFT JOIN (SELECT case_id ,MAX(next_followup_date) AS nextdate FROM patient_followup_details where $where_data   GROUP BY Case_id ) AS MPFD
				LEFT JOIN `patient_case_details` ON MPFD.case_id =`patient_case_details`.id 
                LEFT JOIN departmentmaster dm ON dm.DeptId = `patient_case_details`.department_name
				ON PFD.case_id=MPFD.case_id WHERE PFD.next_followup_date=MPFD.nextdate
                AND (dm.DeptId='".$department."' OR '".$department."'='') AND  patient_case_details.created_by =" . $this->session->userdata('UsertId') . " order by next_followup_date ";
        } else {
            $query = "SELECT PFD.case_id,PFD.id , DATE_FORMAT(next_followup_date,'%d/%m/%Y') AS next_followup_date , remark, ifnull(folowup_done,0) folowup_done FROM patient_followup_details PFD
				LEFT JOIN (SELECT case_id ,MAX(next_followup_date) AS nextdate FROM patient_followup_details where $where_data   GROUP BY Case_id ) AS MPFD
				LEFT JOIN `patient_case_details` ON MPFD.case_id =`patient_case_details`.id 
                LEFT JOIN departmentmaster dm ON dm.DeptId = `patient_case_details`.department_name
				ON PFD.case_id=MPFD.case_id WHERE PFD.next_followup_date=MPFD.nextdate  AND (dm.DeptId='".$department."' OR '".$department."'='') order by next_followup_date ";
        }

        $query = $this->db->query($query);
        $result = $query->result();
        return json_decode(json_encode($result), true);
    }

    function getLastSanctionDate($case_id) {
        $query = "select DATE_FORMAT(case_status_date,'%d/%m/%Y') sanction_date  from patient_case_status_detail where case_status in ('open','rehelp','reopen') and case_id= " . $case_id . " order by case_status_date desc limit 1";
        $query = $this->db->query($query);
        $result = $query->result();
        return json_decode(json_encode($result), true);
    }
	
	 function getSanctionDate($case_id) {
       // $query = "SELECT distinct DATE_FORMAT(rehelp_date,'%d/%m/%Y') as rehelp_date  FROM patient_case_status_detail WHERE case_status IN ('open','rehelp','reopen')";
	    $query = "SELECT id FROM patient_case_status_detail WHERE case_status IN ('open','rehelp','reopen') AND case_id=" . $case_id . " ORDER BY id";
        $query = $this->db->query($query);
        $result = $query->result();
         return $result;
    }
	
    function getDonorBySanctionDate($sanc_date) {
     //echo $query = "SELECT doner_id,id,approved_amount AS total,CASE WHEN DonerType='Organisation' THEN OrganizationName ELSE CONCAT( CONCAT(donermaster.firstName,' ',donermaster.MiddleName),' ',donermaster.LastName) END AS Donerss 
    //FROM patient_case_status_detail INNER JOIN donermaster ON donermaster.DonerId=patient_case_status_detail.doner_id WHERE case_status IN ('open','rehelp','reopen') AND id='" . $sanc_date . "'";

       $query="SELECT doner_id,patient_case_status_detail.id,approved_amount AS total,SUM(pcd.DisbursedAmt) AS avaliable_amt,
CASE WHEN DonerType='Organisation' THEN OrganizationName ELSE CONCAT( CONCAT(donermaster.firstName,' ',donermaster.MiddleName),' ',donermaster.LastName) 
END AS Donerss FROM patient_case_status_detail 
INNER JOIN patient_case_disbursed_detail AS pcd ON pcd.sanction_id=patient_case_status_detail.id
INNER JOIN donermaster ON donermaster.DonerId=patient_case_status_detail.doner_id 
WHERE case_status IN ('open','rehelp','reopen') AND patient_case_status_detail.id='" . $sanc_date . "'";
//exit;
	  $query = $this->db->query($query);
        $result = $query->result();
         return $result;
    }	
	   

    function getPaymentModeById($id) {
        $query = "select *from paymentmaster where PaymentId=$id";
        $query = $this->db->query($query);
        $result = $query->result();
        return $result;
    }

    function getDonorDetailsById($id) {
        $query = "select *from donermaster where DonerId='$id'";
        $query = $this->db->query($query);
        $result = $query->result();
        return $result;
    }

    function getDisbursalDataById($id) {
        $query = "select *from patient_case_disbursed_detail where id=$id";
        $query = $this->db->query($query);
        $result = $query->result();
        return $result;
    }

    //Deepa ....for refund amount

    function viewForRefundAmount($data) {

        $whereIsAdmin = '';

        $isAdmin = $this->session->userdata('IsAdmin');
        if ($isAdmin != 1) {
            $whereIsAdmin = " AND patient_case_details.created_by = " . $this->session->userdata('UsertId');
        }
        if (isset($data['from_date']) && $data['from_date'] != '') {
            $from_date = date('Y-m-d', strtotime($data['from_date']));
        } else {
            $from_date = date('Y-m-d', strtotime('2015-01-01'));
        }

        if (isset($data['to_date']) && $data['to_date'] != '') {
            $to_date = date('Y-m-d', strtotime($data['to_date']));
        } else {
            $to_date = date('Y-m-d');
        }
        if ($data['karo_no'] && $data['karo_no'] != '') {

            $karo = "AND pm.patient_karo_case_no = '" . $data['karo_no'] . "' OR pm.patient_case ='" . $data['karo_no'] . "' OR pm.patient_id ='" . $data['karo_no'] . "' OR pm.patient_name='" . $data['karo_no'] . "'";
        }
        if ($data['department'] && $data['department'] != '') {
            $whereDept = " AND `departmentmaster`.`DeptId`='" . $data['department'] . "'";
        } else if ($data['department'] == '') {
            $whereDept = " ";
        }


        $query = "  SELECT DISTINCT(pcd.id) as caseId,pcd.patient_id,pcd.case_number,IFNULL(SUM(pcdd.DisbursedAmt),0) AS total_amount, pm.patient_name,pm.patient_id,pm.patient_case,pm.id,pfd.approved_amount,IFNULL(rad.refund_amount,'') as refund_amount,IFNULL(rad.refund_date,'') as refund_date
                    FROM patient_case_details pcd LEFT JOIN patient_master pm ON pm.patient_id = pcd.patient_id
                    LEFT JOIN patient_financetial_details pfd ON pfd.case_id = pcd.id
                    LEFT JOIN patient_case_disbursed_detail pcdd ON pcdd.CaseId=pcd.id
                    LEFT JOIN refund_amount_details rad ON rad.patient_id=pcd.patient_id
                    LEFT JOIN `departmentmaster` ON `departmentmaster`.`DeptId` = pcd.`department_name`
                    WHERE IFNULL(pm.status,0)!= '1' " . $karo . $whereIsAdmin . $whereDept . " AND (DATE(rad.refund_date) >= '".$from_date."' OR 1=1) AND (DATE(rad.refund_date) <='".$to_date."' OR 1=1) group by pm.id";
        //prx($query);
        $query = $this->db->query($query);
        $result = $query->result();
        return json_decode(json_encode($result), true);
    }
	
	 function getSanctionId($case_id) {
       // $query = "SELECT distinct DATE_FORMAT(rehelp_date,'%d/%m/%Y') as rehelp_date  FROM patient_case_status_detail WHERE case_status IN ('open','rehelp','reopen')";
	    $query = "SELECT DISTINCT(sanction_id) FROM patient_case_disbursed_detail WHERE  CaseId=" . $case_id . " ORDER BY id";
        $query = $this->db->query($query);
        $result = $query->result();
         return $result;
    }

    function getDonorDetail($get) {
   

         // $query = "SELECT pcd.id,pcd.DonorId AS d ,
// SUM(pcd.DisbursedAmt) AS TotalDisbursed,
// IFNULL(rad.refund_amount,0) AS TotalRefund,
// (SUM(pcd.DisbursedAmt)-IFNULL(rad.refund_amount,0)) AS total,
// pcd.CaseID,
// dm.DonerId,
// CASE WHEN DonerType='Organisation' THEN OrganizationName ELSE CONCAT( CONCAT(dm.firstName,' ',dm.MiddleName),' ',dm.LastName) END AS Doner
// FROM patient_case_disbursed_detail pcd
// INNER JOIN `patient_case_details` patientcase ON patientcase.id=pcd.CaseId
// INNER JOIN donermaster dm ON dm.donerId=pcd.DonorId
// LEFT OUTER JOIN 
// (
// SELECT SUM(IFNULL(refund_amount,0)) AS refund_amount ,donor_id,case_id FROM refund_amount_details GROUP BY case_id,donor_id) AS rad ON rad.donor_id=pcd.DonorId AND rad.case_id=patientcase.case_number
// WHERE pcd.CaseId='$get' GROUP BY dm.DonerId";

$query="SELECT pcd.id,pcd.DonorId AS d ,pcd.sanction_id,
SUM(pcd.DisbursedAmt) AS TotalDisbursed,
IFNULL(rad.refund_amount,0) AS TotalRefund,
(SUM(pcd.DisbursedAmt)-IFNULL(rad.refund_amount,0)) AS total,
pcd.CaseID,
dm.DonerId,
CASE WHEN DonerType='Organisation' THEN OrganizationName ELSE CONCAT( CONCAT(dm.firstName,' ',dm.MiddleName),' ',dm.LastName) END AS Doner
FROM patient_case_disbursed_detail pcd
INNER JOIN `patient_case_details` patientcase ON patientcase.id=pcd.CaseId
INNER JOIN donermaster dm ON dm.donerId=pcd.DonorId
LEFT OUTER JOIN 
(
SELECT SUM(IFNULL(refund_amount,0)) AS refund_amount,sanction_id ,donor_id,case_id FROM refund_amount_details GROUP BY case_id,donor_id,sanction_id) AS rad
 ON rad.donor_id=pcd.DonorId AND rad.case_id=patientcase.case_number AND rad.sanction_id=pcd.sanction_id
WHERE pcd.sanction_id='$get' GROUP BY dm.DonerId ,pcd.sanction_id";

        $query = $this->db->query($query);
        $result = $query->result();
        return $result;
    }

    function getDonateByDonor() {
        $query = "SELECT dd.id,dd.DonerId,SUM(dd.DonationAmount) AS total FROM doner_donation_detail AS dd WHERE DonerId=1";
        $query = $this->db->query($query);
        $result = $query->result();
        return $result;
    }

    function getRefundByDonor($get) {
        $query = "SELECT rad.*,CASE WHEN `DonerType`='Organisation' THEN `OrganizationName` ELSE CONCAT( CONCAT(dm.FirstName,' ',dm.MiddleName),' ',dm.LastName) END AS Doner,
	pay.PaymentId,pay.PaymentMode
	FROM refund_amount_details AS rad INNER JOIN donermaster AS dm ON dm.donerId=rad.donor_id INNER JOIN paymentmaster AS pay ON pay.PaymentId=rad.mode_of_refund 
	INNER JOIN patient_master AS pm ON pm.patient_case=rad.case_id WHERE pm.id='$get' ";
// echo $query;
// exit;
        $query = $this->db->query($query);
        $result = $query->result();
        return $result;
    }

    function getRehelpDataByCaseId($cid) {
        $query = "select id,case_id,doner_id,case_status,required_fund,approved_amount,case_status_reason,case_status_date,created_by,DATE_FORMAT(created_at,'%d/%m/%Y') created_at,DATE_FORMAT(rehelp_date,'%d/%m/%Y') rehelp_date from patient_case_status_detail where case_id=$cid and case_status not in('hold','reject','closed')";
        $query = $this->db->query($query);
        $result = $query->result();
        return $result;
    }

    function getLastNRecordsCaseId($file_count, $caseid) {
        $query = "SELECT id FROM patient_document_details_test WHERE page='rehelp' AND case_id=$caseid and rehelp_id IS NULL ORDER BY id DESC LIMIT $file_count";
        $query = $this->db->query($query);
        $result = $query->result();
        return $result;
    }

    function updateRehelpDocs($id, $rehelp_insert_id) {
        $this->db->query("update patient_document_details_test set rehelp_id=$rehelp_insert_id where id=$id");
    }
	
	function updateRehelpFinancial($id) {
		$query="UPDATE `patient_financetial_details` 
LEFT OUTER  JOIN 
(
SELECT SUM(`required_fund`) AS Required, SUM(approved_amount)AS Approved ,Case_id 
FROM `patient_case_status_detail`
GROUP BY Case_id)AS Fund
ON Fund.Case_id=patient_financetial_details.case_id 

SET `required_fund`= Fund.Required , 
`approved_amount`=Fund.Approved

WHERE patient_financetial_details.`case_id`=$id";
//exit;
        $this->db->query($query);

    }
	

    function getPatientRehelpFiles($title) {
        $query = "SELECT *FROM patient_document_details_test WHERE rehelp_id=$title";
        $query = $this->db->query($query);
        $result = $query->result();
        return $result;
    }

    function getRehelpDataById($id) {
      //  $query = "SELECT *FROM patient_case_status_detail WHERE id=$id";
		$query="SELECT * FROM patient_case_status_detail INNER JOIN patient_case_disbursed_detail ON patient_case_disbursed_detail.CaseId=patient_case_status_detail.case_id  WHERE patient_case_status_detail.id=$id";
		// echo $query;
		// exit;
        $query = $this->db->query($query);
        $result = $query->result();
        return $result;
    }

    function updateRehelpData($table, $insert_data, $id) {
        $this->db->where("id", $id);
        $this->db->update($table, $insert_data);
    }
	
	 function getRefund($donor_id ) {
		 
      $query = "SELECT * FROM refund_amount_details AS rad INNER JOIN patient_case_disbursed_detail AS pcd ON pcd.DonorId=rad.donor_id WHERE rad.donor_id='$donor_id' AND is_refund=1 GROUP BY rad.donor_id";
		//exit;
		//"SELECT * FROM refund_amount_details WHERE donor_id =$donor_id";
      $query = $this->db->query($query);

        return $query->result();
    }
	
	function updateStatusForRefund($donor_id){
		$query="UPDATE  patient_case_disbursed_detail SET is_refund=1 WHERE  id=$donor_id";
	
		        $query = $this->db->query($query);
	}

}
