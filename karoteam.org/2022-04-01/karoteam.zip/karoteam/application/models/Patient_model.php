<?php

class Patient_model extends CI_Model {

    //akash rai 5 march 2020
    public function getPatient($id = 0,$department,$hospital,$representative_name,$status) {
        $role = $this->session->userdata("IsAdmin");
        if ($id) {
            $this->db->select("* ,CASE WHEN INSTR(patient_age,'years') >0 THEN SUBSTRING(patient_age,1,2) ELSE 0 END  AS age_year ,CASE WHEN INSTR(patient_age,'month') >0 THEN SUBSTRING(patient_age,INSTR(patient_age,'month')-2,2) ELSE 0 END  AS age_month,CASE WHEN INSTR(patient_age,'days') >0 THEN SUBSTRING(patient_age,INSTR(patient_age,'days')-2,2) ELSE 0 END  AS age_day from patient_master where id=$id and IFNULL(`status`,0)!= '1'");
            $query = $this->db->get();
            if ($query->num_rows() > 0) {
                return $query->result_array();
            }
        } else {
            // $query = $this->db->get_where('patient_master', array('1' => 1));
            // if ($query->num_rows() > 0) {
            //     return $query->result_array();
            // }
            if ($role == 1) {
                $this->db->select('pm.* ,CONCAT(um.FirstName, " ", `MiddleName`, " ", LastName) AS team_member,DATE_FORMAT(pm.registration_date,"%d/%m/%Y") AS reg_date,pcd.hospital_name as hospital_id ,hm.HospitalName, dm.deptname as DepartmentName,pcd.id as Caseid,CASE WHEN INSTR(patient_age,"years") >0 THEN SUBSTRING(patient_age,1,2) ELSE 0 END  AS age_year ,CASE WHEN INSTR(patient_age,"month") >0 THEN SUBSTRING(patient_age,INSTR(patient_age,"month")-2,2) ELSE 0 END  AS age_month,CASE WHEN INSTR(patient_age,"days") >0 THEN SUBSTRING(patient_age,INSTR(patient_age,"days")-2,2) ELSE 0 END  AS age_day,pcd.case_status');
                $this->db->from('patient_case_details pcd');
                $this->db->join('patient_master pm ', 'pm.patient_id = pcd.patient_id', 'left');
				$this->db->join('usermaster um ', 'um.UserId = pm.representative_name', 'left');
                $this->db->join('hospitalmaster hm', 'hm.HospitalId = pcd.hospital_name', 'left');
                $this->db->join('departmentmaster dm', 'dm.DeptId = pcd.department_name', 'left');
                $this->db->where('IFNULL(`status`,0)!=', '1');
                $this->db->where('(representative_name="'.$representative_name.'" OR "'.$representative_name.'"="")');
                $this->db->where('(hospital_name="'.$hospital.'" OR "'.$hospital.'"="")');
                $this->db->where('(dm.DeptId="'.$department.'" OR "'.$department.'"="")');
                $this->db->where('(pcd.case_status="'.$status.'" OR "'.$status.'"="")');
                // $this->db->limit(10);
                $query = $this->db->get();
			//echo $this->db->last_query();exit;
                $result = $query->result_array();
            } else {
                $user_id = $this->session->userdata('UsertId');
                $query = "SELECT pm.*,CONCAT(um.FirstName, ' ', `MiddleName`, ' ', LastName) AS team_member,DATE_FORMAT(pm.registration_date,'%d/%m/%Y') AS reg_date, pcd.hospital_name as hospital_id, hm.HospitalName,dm.deptname as DepartmentName ,pcd.id as Caseid,CASE WHEN INSTR(patient_age,'years') >0 THEN SUBSTRING(patient_age,1,2) ELSE 0 END  AS age_year ,CASE WHEN INSTR(patient_age,'month') >0 THEN SUBSTRING(patient_age,INSTR(patient_age,'month')-2,2) ELSE 0 END  AS age_month,CASE WHEN INSTR(patient_age,'days') >0 THEN SUBSTRING(patient_age,INSTR(patient_age,'days')-2,2) ELSE 0 END  AS age_day FROM patient_case_details pcd "
                        . "LEFT JOIN patient_master pm ON pm.patient_id = pcd.patient_id "
						. "LEFT JOIN usermaster um ON um.UserId = pm.representative_name "
                        . "LEFT JOIN hospitalmaster hm ON hm.HospitalId = pcd.hospital_name "
                        . "LEFT JOIN departmentmaster dm ON dm.DeptId = pcd.department_name "
                        . "where (representative_name='".$representative_name."' OR '".$representative_name."'='') AND (hospital_name='".$hospital."' OR '".$hospital."'='') AND (dm.DeptId='".$department."' OR '".$department."'='') AND (pcd.case_status='".$status."' OR '".$status."'='') AND pm.created_by = $user_id and IFNULL(`pm`.`status`,0)!= '1'";
                $query = $this->db->query($query);
				
			
                $result = $query->result_array();
            }


            return $result;
        }
    }

    public function getPatientById($patient_id) {
		
		$this->db->select('pm.*,CONCAT(um.FirstName, " ", MiddleName, " ", LastName) AS team_member,IFNULL((SELECT DeptName FROM departmentmaster WHERE DeptId=pcd.department_name),"") as department_name');
		$this->db->from('patient_master pm');
		$this->db->join('usermaster um ' , 'um.UserId=pm.representative_name' ,'left');
        $this->db->join('patient_case_details pcd ' , 'pcd.patient_id=pm.patient_id' ,'left');
        //$this->db->join('patient_case_details pcd ' , 'um.UserId=pm.representative_name' ,'left ');
		$this->db->where('pm.patient_id' , $patient_id);
		$query = $this->db->get();
        //$query = $this->db->get_where('patient_master', array('patient_id' => $patient_id));
		//echo $this->db->last_query();exit;
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
    }

    public function getPatientFamily($id) {
        $query = $this->db->get_where('patient_family_details', array('patient_id' => $id));
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
    }

    public function savePatient($patientData, $id = 0) {
        if ($id) {
            $patientData["updated_by"] = $this->session->userdata('UsertId');
            $this->db->where('id', $id);
            $str1 = $this->db->update('patient_master', $patientData);
            $patient_id = $id;
        } else {
            $patientData['created_by'] = $this->session->get_userdata('UsertId')['UsertId'];
            $patientData["created_at"] = date("Y-m-d H:i:s");
            $str1 = $this->db->insert('patient_master', $patientData);
            //opening a new case of patient
            $patient_id = $this->db->insert_id();
            $casedata["patient_id"] = $patientData["patient_id"];
            $casedata["case_number"] = $patientData["patient_case"];
            $casedata['created_by'] = $this->session->userdata('UsertId');
            $str1 = $this->db->insert('patient_case_details', $casedata);
        }
        return $patient_id;
    }

    public function getTableData($params) {
        $this->db->select($params['select']);
        if ($params['where']) {
            $this->db->where($params['where']);
        }

        $query = $this->db->get($params['table']);
        $result = $query->result();

        return $result;
    }

    public function insertDataIntoTable($table, $insert_data) {
        return $this->db->insert($table, $insert_data);
    }

    public function updateDataIntoTable($table, $update_data, $where_data) {
        $this->db->where($where_data);
        // echo $this->db->last_query();exit;

        return $this->db->update($table, $update_data);
    }

    public function getResultByCategory($chartType, $id, $label) {
        switch ($chartType) {
            case "age":
                $patientData = $this->getPatientByAgeGroup($id);
                if ($id == '30/30') {
                    $data['label'] = "Age Group:- " . $label . "+";
                } else {
                    $data['label'] = "Age Group:- " . $label;
                }
                $data['patient'] = $patientData;
                return $data;
                break;
            case "gender":
                $patientData = $this->getPatientByGender($id);
                $data['label'] = "Gender:- " . $label;
                $data['patient'] = $patientData;
                return $data;
                break;
            case "state":
                $patientData = $this->getPatientByState($id, $label);
                $data['label'] = "State:- " . $label;
                $data['patient'] = $patientData;
                return $data;
                break;
            case "disease":
                $patientData = $this->getPatientByDisease("", $id);
                $data['label'] = "Department Name:- " . $label;
                $data['patient'] = $patientData;
                return $data;
                break;
            case "hospital":
                $patientData = $this->getPatientByHospital($id);
                $data['label'] = "Hospital Name:- " . $label;
                $data['patient'] = $patientData;
                return $data;
                break;
            case "user1":
                $patientData = $this->getPatientByUser($id,$label);
                $data['label'] = "Representative Name:- " . $label;
                $data['patient'] = $patientData;
                return $data;
                break;
            case "agedob":
                $patientData = $this->getPatientByWithoutDOBAgeGroup($id);
                if ($id == '30/30') {
                    $data['label'] = "Age Group:- " . $label . "+";
                } else {
                    $data['label'] = "Age Group:- " . $label;
                }
                $data['patient'] = $patientData;
                return $data;
                break;
        }
    }

    public function getPatientByAgeGroup($ageGroup) {
        $startAge = '';
        $endAge = '';
        $whereIsAdmin = '';

        $isAdmin = $this->session->userdata('IsAdmin');
        if ($isAdmin != 1) {
            $whereIsAdmin = " AND pm.created_by = " . $this->session->userdata('UsertId');
        }

        $ageGroupArr = explode("-", $ageGroup);
        if (isset($ageGroupArr[0])) {
            $startAge = $ageGroupArr[0];
        }
        if (isset($ageGroupArr[1])) {
            $endAge = $ageGroupArr[1];
        }

        if ($ageGroup == "30/30") {
            $startAge = 30;
            $endAge = 150;
        }

       $query = "SELECT
                                pm.*,
                                DATE_FORMAT(pm.registration_date, '%d/%m/%Y') AS reg_date,CONCAT(um.FirstName, ' ', `MiddleName`, ' ', LastName) AS re_name,
                                pcd.hospital_name AS hospital_id,pcd.id as case_id,
                                hm.HospitalName
                            FROM
                                patient_case_details pcd
                                    LEFT JOIN
                                patient_master pm ON pm.patient_id = pcd.patient_id
								LEFT JOIN 
								usermaster um ON um.UserId=pm.representative_name
                                    LEFT JOIN
                                hospitalmaster hm ON hm.HospitalId = pcd.hospital_name
                            WHERE
								patient_dob IS NOT NULL AND patient_dob != '0000-00-00' AND
                                                                IFNULL(`pm`.`status`,0)!= '1' AND
                                CALCULATEAGE(YEAR(pm.patient_dob)) >= $startAge
                                AND CALCULATEAGE(YEAR(pm.patient_dob)) <= $endAge " . $whereIsAdmin ."
								
								 UNION 
								 
								SELECT
                                pm.*,
                                DATE_FORMAT(pm.registration_date, '%d/%m/%Y') AS reg_date,CONCAT(um.FirstName, ' ', `MiddleName`, ' ', LastName) AS re_name,
                                pcd.hospital_name AS hospital_id,pcd.id as case_id,
                                hm.HospitalName
                            FROM
                                patient_case_details pcd
                                    LEFT JOIN
                                patient_master pm ON pm.patient_id = pcd.patient_id
								LEFT JOIN 
								usermaster um ON um.UserId=pm.representative_name
                                    LEFT JOIN
                                hospitalmaster hm ON hm.HospitalId = pcd.hospital_name
                            WHERE
				IFNULL(`pm`.`status`,0)!= '1' and				
                                IFNULL(patient_dob,'')='0000-00-00'  AND IFNULL(patient_age,'')!='' AND
                                SUBSTRING(patient_age,1,2) >= $startAge
                                AND SUBSTRING(patient_age,1,2) <= $endAge " . $whereIsAdmin;
							//	exit;

        $query = $this->db->query($query);
        $result = $query->result_array();

        return $result;
    }

    // public function getPatientByWithoutDOBAgeGroup($ageGroup) {
        // $startAge = '';
        // $endAge = '';
        // $whereIsAdmin = '';

        // $isAdmin = $this->session->userdata('IsAdmin');
        // if ($isAdmin != 1) {
            // $whereIsAdmin = " AND pm.created_by = " . $this->session->userdata('UsertId');
        // }

        // $ageGroupArr = explode("-", $ageGroup);
        // if (isset($ageGroupArr[0])) {
            // $startAge = $ageGroupArr[0];
        // }
        // if (isset($ageGroupArr[1])) {
            // $endAge = $ageGroupArr[1];
        // }

        // if ($ageGroup == "30/30") {
            // $startAge = 30;
            // $endAge = 150;
        // }

        // $query = "SELECT
                                // pm.*,
                                // DATE_FORMAT(pm.registration_date, '%d/%m/%Y') AS reg_date,
                                // pcd.hospital_name AS hospital_id,
                                // hm.HospitalName
                            // FROM
                                // patient_case_details pcd
                                    // LEFT JOIN
                                // patient_master pm ON pm.patient_id = pcd.patient_id
                                    // LEFT JOIN
                                // hospitalmaster hm ON hm.HospitalId = pcd.hospital_name
                            // WHERE
				// IFNULL(`pm`.`status`,0)!= '1' and				
                                // IFNULL(patient_dob,'')='0000-00-00'  AND IFNULL(patient_age,'')!='' AND
                                // SUBSTRING(patient_age,1,2) >= $startAge
                                // AND SUBSTRING(patient_age,1,2) <= $endAge " . $whereIsAdmin;

        // $query = $this->db->query($query);
        // $result = $query->result_array();

        // return $result;
    // }

    public function getPatientByGender($gender) {
        $whereIsAdmin = '';

        $isAdmin = $this->session->userdata('IsAdmin');
        if ($isAdmin != 1) {
            $whereIsAdmin = " AND pm.created_by = " . $this->session->userdata('UsertId');
        }

        $query = "SELECT
                                pm.*,
                                DATE_FORMAT(pm.registration_date, '%d/%m/%Y') AS reg_date,CONCAT(um.FirstName, ' ', `MiddleName`, ' ', LastName) AS re_name,
                                pcd.hospital_name AS hospital_id,pcd.id as case_id,
                                hm.HospitalName
                            FROM
                                patient_case_details pcd
                                    LEFT JOIN
                                patient_master pm ON pm.patient_id = pcd.patient_id
								LEFT JOIN 
								usermaster um ON um.UserId=pm.representative_name
                                    LEFT JOIN
                                hospitalmaster hm ON hm.HospitalId = pcd.hospital_name
                            WHERE
                                IFNULL(`pm`.`status`,0)!= '1' and 
                                pm.patient_gender = '" . $gender . "'" . $whereIsAdmin;
        $query = $this->db->query($query);
        $result = $query->result_array();

        return $result;
    }

    public function getPatientByState($stateId, $stateName) {
        $whereState = '';
        $whereIsAdmin = '';

        $isAdmin = $this->session->userdata('IsAdmin');
        if ($isAdmin != 1) {
            $whereIsAdmin = " AND pm.created_by = " . $this->session->userdata('UsertId');
        }

        if ($stateName == 'Mumbai City') {
            $whereState = "pm.pp_city = 'Mumbai City'";
        } else
        if ($stateName == 'Thane') {
            $whereState = "pm.pp_city = 'Thane'";
        } else {
            if ($stateName == 'Maharashtra') {
                $whereState = "pm.pp_state = '" . $stateName . "' AND pm.pp_city NOT IN ('Mumbai City', 'Thane')";
            } else {
                $whereState = "pm.pp_state = '" . $stateName . "'";
            }
        }

        $query = "SELECT
                                pm.*,
                                DATE_FORMAT(pm.registration_date, '%d/%m/%Y') AS reg_date,CONCAT(um.FirstName, ' ', `MiddleName`, ' ', LastName) AS re_name,
                                pcd.hospital_name AS hospital_id,pcd.id as case_id,
                                hm.HospitalName
                            FROM
                                patient_case_details pcd
                                    LEFT JOIN
                                patient_master pm ON pm.patient_id = pcd.patient_id
								LEFT JOIN 
								usermaster um ON um.UserId=pm.representative_name
                                    LEFT JOIN
                                hospitalmaster hm ON hm.HospitalId = pcd.hospital_name
                            WHERE
                                " . $whereState . $whereIsAdmin . " AND  IFNULL(`pm`.`status`,0)!= '1'";
								//exit;
        $query = $this->db->query($query);
        $result = $query->result_array();

        return $result;
    }

    public function getPatientByDisease($id = 0, $cat_id) {
        $role = $this->session->userdata("IsAdmin");

        if ($id) {
            $query = $this->db->get_where('patient_master', array('id' => $id));
            if ($query->num_rows() > 0) {
                return $query->result_array();
            }
        } else {
            if ($role == 1) {
                $this->db->select('pm.* ,pcd.id as case_id,DATE_FORMAT(pm.registration_date,"%d/%m/%Y") AS reg_date,pcd.disease_diagnosed AS disease,pcd.hospital_name as hospital_id ,hm.HospitalName,CONCAT(um.FirstName, " ", `MiddleName`, " ", LastName) AS re_name');
                $this->db->from('patient_case_details pcd');
                $this->db->join('patient_master pm ', 'pm.patient_id = pcd.patient_id', 'left');
				 $this->db->join('usermaster um ', 'um.UserId=pm.representative_name', 'left');
                $this->db->join('hospitalmaster hm', 'hm.HospitalId = pcd.hospital_name', 'left');
                $this->db->join('departmentmaster dm', 'dm.DeptId = pcd.department_name', 'left');
                $this->db->where('pcd.department_name', $cat_id);
                $this->db->where('IFNULL(pm.`status`,0)!=', '1');
                $query = $this->db->get();
                $result = $query->result_array();
            } else {
                $user_id = $this->session->userdata('UsertId');
                $query = "SELECT pm.*, pcd.id as case_id,DATE_FORMAT(pm.registration_date,'%d/%m/%Y') AS reg_date, pcd.disease_diagnosed AS disease, pcd.hospital_name as hospital_id, hm.HospitalName ,CONCAT(um.FirstName, ' ', `MiddleName`, ' ', LastName) AS re_name FROM patient_case_details pcd "
                        . "LEFT JOIN patient_master pm ON pm.patient_id = pcd.patient_id "
						. "LEFT JOIN usermaster um ON um.UserId=pm.representative_name "
                        . "LEFT JOIN hospitalmaster hm ON hm.HospitalId = pcd.hospital_name "
                        . "LEFT JOIN departmentmaster dm ON dm.DeptId = pcd.department_name "
                        . "where pm.created_by = $user_id and pcd.department_name=$cat_id and IFNULL(pm.`status`,0)!='1'";
                $query = $this->db->query($query);
                $result = $query->result_array();
            }
            return $result;
        }
    }

    public function getPatientByHospital($hospitalId) {
        $whereIsAdmin = '';

        $isAdmin = $this->session->userdata('IsAdmin');
        if ($isAdmin != 1) {
            $whereIsAdmin = " AND pcd.created_by = " . $this->session->userdata('UsertId');
        }
      
	  if($hospitalId!= -1){
        $query = "SELECT
                                pm.*,
                                DATE_FORMAT(pm.registration_date, '%d/%m/%Y') AS reg_date,CONCAT(um.FirstName, ' ', `MiddleName`, ' ', LastName) AS re_name,
                                pcd.hospital_name AS hospital_id,pcd.id as case_id,
                                hm.HospitalName
                            FROM
                                patient_case_details pcd
                                    LEFT JOIN
                                patient_master pm ON pm.patient_id = pcd.patient_id
								LEFT JOIN 
								usermaster um ON um.UserId=pm.representative_name
                                    LEFT JOIN
                                hospitalmaster hm ON hm.HospitalId = pcd.hospital_name
                            WHERE
                                IFNULL(`pm`.`status`,0) != '1'  AND 
                                pcd.hospital_name = '" . $hospitalId . "'" . $whereIsAdmin;
							//	exit;
        $query = $this->db->query($query);
        $result = $query->result_array();
		
	  }else{
		   $query="SELECT pm.*,pcd.id as case_id, DATE_FORMAT(pm.registration_date, '%d/%m/%Y') AS reg_date, pcd.hospital_name AS hospital_id, CONCAT(um.FirstName, ' ', `MiddleName`, ' ', LastName) AS re_name,
hm.HospitalName FROM patient_case_details pcd LEFT JOIN patient_master pm ON pm.patient_id = pcd.patient_id 
LEFT JOIN usermaster um ON um.UserId=pm.representative_name
LEFT JOIN hospitalmaster hm ON hm.HospitalId = pcd.hospital_name WHERE IFNULL(`pm`.`status`,0)!= '1' AND 
pcd.hospital_name IN 
(
SELECT DISTINCT(pcd.hospital_name)AS hospital_name
FROM `patient_case_details` `pcd`
JOIN `patient_master` `pm` ON `pm`.`patient_id` = `pcd`.`patient_id`
JOIN `hospitalmaster` `hm` ON `hm`.`HospitalId` = `pcd`.`hospital_name` 
WHERE IFNULL(pm.status,0) != '1' " . $whereIsAdmin . " GROUP BY `pcd`.`hospital_name` HAVING COUNT(1)<50
)" . $whereIsAdmin ;
								
 $query = $this->db->query($query);
        $result = $query->result_array();
	  }

        return $result;
    }

    public function getPatientByUser($userId,$repres_name) {
        $isAdmin = $this->session->userdata('IsAdmin');
		  if ($isAdmin != 1) {
           $whereIsAdmin = " AND pcd.created_by = " . $this->session->userdata('UsertId');
       }
      $query = "SELECT
                                pm.*,
                                DATE_FORMAT(pm.registration_date, '%d/%m/%Y') AS reg_date,CONCAT(umt.FirstName, ' ', umt.MiddleName, ' ', umt.LastName) AS re_name,
                                pcd.hospital_name AS hospital_id,pcd.id as case_id,
                                CONCAT(um.FirstName, ' ', um.MiddleName, ' ', um.LastName) AS userName,
                                hm.HospitalName
                            FROM
                                patient_case_details pcd
                                    LEFT JOIN
                                patient_master pm ON pm.patient_id = pcd.patient_id
                                    LEFT JOIN
                                hospitalmaster hm ON hm.HospitalId = pcd.hospital_name
                                    LEFT JOIN
                                usermaster um ON um.UserId = pcd.created_by
								LEFT JOIN 
								usermaster umt ON umt.UserId=pm.representative_name
                            WHERE
                                IFNULL(`pm`.`status`,0)!= '1' and 
                                pm.representative_name = '" . $userId . "'". $whereIsAdmin;
							//	exit;
        $query = $this->db->query($query);
        $result = $query->result_array();

        return $result;
    }

    function checkCaseNoExists($patient_karo_case_no) {
        $query = "select id from patient_master where patient_karo_case_no='$patient_karo_case_no'";
        $query = $this->db->query($query);
        return $query->result();
    }
	
	function checkPhoneNoExists($patient_phone_no,$patient_id) {
       $query = "SELECT id,patient_phone,caregiver_phone,caregiver_phone2 FROM patient_master WHERE '$patient_phone_no' IN (patient_phone,caregiver_phone,caregiver_phone2)  AND id !='$patient_id'";
     // exit; 
	   $query = $this->db->query($query);
        return $query->result();
    }

    function getDisease($patient_id) {
        $query = "select disease_diagnosed from patient_case_details where patient_id='$patient_id'";
        $query = $this->db->query($query);
        return $query->result();
    }

    function checkPtKaroCaseNoModel($patient_karo_case_no) {
        $query = "select patient_karo_case_no from patient_master where patient_karo_case_no='$patient_karo_case_no'";
        $query = $this->db->query($query);
        return $query->result();
    }

    //akash rai 5 march 2020
    function deletePatientModel($patient_id, $reason_of_deletion) {
        $query = "update patient_master set status=1,delete_reason='$reason_of_deletion' where id=$patient_id";
        $this->db->query($query);
		
		$query = "DELETE FROM patient_case_status_detail WHERE  case_status IN ('open','rehelp','reopen','close','reject') AND case_id=$patient_id";
        $this->db->query($query);
		

		$query = "DELETE FROM patient_case_disbursed_detail WHERE  CaseId=$patient_id";
        $this->db->query($query);
		
    }
	
	// function deleteCase($str_pt_id){
		
		// $query="DELETE FROM patient_case_details WHERE  case_status IN ('open','hold','New','closed','reject') AND case_id=$str_pt_id";
	//exit;
		// $this->db->query($query);
	// }

    //akash rai 6 march 2020
    function getCaseState($str_pt_id) {
        $query = "select case_status from patient_case_details where patient_id='$str_pt_id'";
        $query = $this->db->query($query);
        return $query->result();
    }
	
	//deepa for phn list
	 function getPhoneList($phone,$phone_id) {
     $query = "SELECT id,patient_name,patient_phone,caregiver_phone,caregiver_phone2 FROM patient_master WHERE id !='$phone_id' AND '$phone' IN (patient_phone,caregiver_phone,caregiver_phone2) ";
    // exit;
	   $query = $this->db->query($query);
        return $query->result();
    }

}

?>