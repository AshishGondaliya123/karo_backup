<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');


    function prx($data)
    {
    	echo '<pre>';
        print_r($data);
        exit();
    }   

    function pr($v = null,$data)
    {
    	echo '<pre>';
        print_r($data);
    } 

    function numberformat($number){
        // setlocale(LC_MONETARY, 'en_IN');
        
        // $number = money_format('%.'.$decimal.'n', $number);
        // echo $number;
        // $number = preg_replace("/(\d+?)(?=(\d\d)+(\d)(?!\d))(\.\d+)?/i", "$1,", $number);
        $amt = '';
        return addCommaToRs($number,$amt,0);
    }

    function addCommaToRs($amt, &$ret, $dec='', $sign=''){
        if(preg_match("/-/",$amt)){
            $amts=explode('-',$amt);
            $amt=$amts['1'];
            static $sign='-';
        } 
        if(preg_match("/\./",$amt)){
            $amts=explode('.',$amt);
            $amt=$amts['0'];
            $l=strlen($amt);
            static $dec;
            $dec=$amts['1'];
        } else {
            $l=strlen($amt);
        }
        if($l>3){
            if($l%2==0){
                $ret.= substr($amt,0,1);
                $ret.= ",";
                addCommaToRs(substr($amt,1,$l),$ret,$dec);
            } else{
                $ret.=substr($amt,0,2);
                $ret.= ",";     
                addCommaToRs(substr($amt,2,$l),$ret,$dec);
            }
        } else {
            $ret.= $amt;
            if($dec) $ret.=".".$dec;
        }
        return $sign.$ret; 
    }
    